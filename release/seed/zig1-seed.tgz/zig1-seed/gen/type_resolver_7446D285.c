#include "type_resolver_7446D285.h"
#include <stdio.h>
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* localConstScopeInit */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_E2DF2801_LocalConstScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.nodes = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localConstScopePush */
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_12;
    int zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_C6536882_EU_532 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_3E40CD83_Sand* zT_28;
    zT_C6536882_EU_532 zT_35 = {0};
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int* zT_40;
    unsigned int* zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    unsigned int* zT_55;
    unsigned int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_d;
    unsigned int* nn;
    unsigned int* nd;
    unsigned int i;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = scope->cap;
    if ((int)(zT_7 < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_55 = scope->names;
    zT_56 = scope->count;
    zT_55[zT_56] = name_id;
    zT_57 = scope->nodes;
    zT_58 = scope->count;
    zT_57[zT_58] = decl_node;
    zT_59 = scope->count;
    scope->count = (unsigned int)(zT_59 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_10 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_12 = scope->cap;
    zT_13 = 2;
    zT_10 = zT_12 * zT_13;
    goto z_bb_5;
    z_bb_5:
    nc = zT_10;
    zT_16 = scope->alloc;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_25 = zT_23.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_n = zT_25;
    zT_28 = scope->alloc;
    zT_35 = zF_1395EB68_sandAlloc(zT_28, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_37 = zT_35.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_d = zT_37;
    zT_40 = (unsigned int*)raw_n;
    nn = zT_40;
    zT_42 = (unsigned int*)raw_d;
    nd = zT_42;
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    i = zT_45;
    goto z_bb_12;
    z_bb_12:
    zT_46 = scope->count;
    if ((int)(i < zT_46)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_48 = scope->names;
    zT_49 = zT_48[i];
    nn[i] = zT_49;
    zT_50 = scope->nodes;
    zT_51 = zT_50[i];
    nd[i] = zT_51;
    goto z_bb_15;
    z_bb_14:
    scope->names = nn;
    scope->nodes = nd;
    scope->cap = nc;
    goto z_bb_2;
    z_bb_15:
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_12;
}

/* localConstScopeLookup */
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id) {
    unsigned int zT_3;
    unsigned int zT_7;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    unsigned int i;
    zT_3 = scope->count;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((int)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = i - (unsigned int)(1);
    i = zT_7;
    zT_8 = scope->names;
    zT_9 = zT_8[i];
    if ((int)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = scope->nodes;
    zT_12 = zT_11[i];
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    goto z_bb_4;
}

/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_6F32B01B_Opt_235 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_C6536882_EU_532 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->depend_len;
    zT_2 = self->depend_cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->depend_cap;
    zT_6 = 8;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->depend_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->depend_cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->depend_items;
    zT_25 = self->depend_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->depend_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->depend_items;
    zT_48 = self->depend_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->depend_items = new_items;
    self->depend_cap = nc;
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    self->depend_len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    unsigned int* zT_23;
    unsigned int zT_25;
    zT_6F32B01B_Opt_235 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_C6536882_EU_532 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned int* zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_1 = self->worklist_len;
    zT_2 = self->worklist_cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->worklist_cap;
    zT_6 = 64;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->worklist_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->worklist_cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->worklist_items;
    zT_25 = self->worklist_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(4)), (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->worklist_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (unsigned int*)raw;
    new_items = zT_46;
    zT_47 = self->worklist_items;
    zT_48 = self->worklist_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->worklist_items = new_items;
    self->worklist_cap = nc;
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 + (unsigned int)((unsigned int)zT_6));
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((int)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_C6536882_EU_532 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((int)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((int)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_19 = zT_17.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_5;
    zT_D155D06D_Type* zT_6;
    zT_D155D06D_Type zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_406493CE_StructPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_406493CE_StructPayload zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned short zT_31;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    unsigned int zT_46;
    zT_2DF01B61_FieldEntry zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_D155D06D_Type* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_D155D06D_Type zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_2DF01B61_FieldEntry* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_2DF01B61_FieldEntry* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_73;
    int zT_74;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79 = 0;
    unsigned int zT_80;
    zT_338B7C76_TypeRegistry* zT_85;
    zT_D155D06D_Type* zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_338B7C76_TypeRegistry* zT_93;
    zT_457ECFEE_EnumPayload* zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_457ECFEE_EnumPayload zT_97;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_D155D06D_Type* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_D155D06D_Type zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_338B7C76_TypeRegistry* zT_106;
    zT_D155D06D_Type* zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_AF9231A2_UnionPayload* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_AF9231A2_UnionPayload zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned short zT_123;
    unsigned int zT_124;
    int zT_126;
    unsigned int zT_127;
    int zT_129;
    unsigned int zT_130;
    int zT_132;
    unsigned int zT_133;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_2DF01B61_FieldEntry* zT_137;
    unsigned int zT_138;
    zT_2DF01B61_FieldEntry zT_139;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_D155D06D_Type* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_D155D06D_Type zT_145;
    zT_33EF6BFB_TypeKind zT_146;
    unsigned int zT_151;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162 = 0;
    unsigned int zT_163;
    zT_338B7C76_TypeRegistry* zT_168;
    zT_D155D06D_Type* zT_169;
    zT_33EF6BFB_TypeKind zT_170;
    zT_338B7C76_TypeRegistry* zT_175;
    unsigned int zT_176;
    zT_33EF6BFB_TypeKind zT_178;
    zT_338B7C76_TypeRegistry* zT_184;
    zT_54FF90FA_TaggedUnionPayload* zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_54FF90FA_TaggedUnionPayload zT_188;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_D155D06D_Type* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_D155D06D_Type zT_194;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned short zT_199;
    unsigned int zT_200;
    int zT_202;
    unsigned int zT_203;
    int zT_205;
    unsigned int zT_206;
    int zT_208;
    unsigned int zT_209;
    zT_338B7C76_TypeRegistry* zT_212;
    zT_2DF01B61_FieldEntry* zT_213;
    unsigned int zT_214;
    zT_2DF01B61_FieldEntry zT_215;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    unsigned int zT_229;
    zT_338B7C76_TypeRegistry* zT_232;
    zT_D155D06D_Type* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_D155D06D_Type zT_236;
    zT_33EF6BFB_TypeKind zT_237;
    unsigned int zT_242;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned int zT_247;
    int zT_248;
    unsigned int zT_250;
    unsigned int zT_252;
    unsigned int zT_254;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260 = 0;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263 = 0;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267 = 0;
    zT_338B7C76_TypeRegistry* zT_268;
    zT_D155D06D_Type* zT_269;
    zT_33EF6BFB_TypeKind zT_270;
    zT_338B7C76_TypeRegistry* zT_276;
    zT_0B10E8E9_OptionalPayload* zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    zT_0B10E8E9_OptionalPayload zT_280;
    zT_338B7C76_TypeRegistry* zT_282;
    zT_D155D06D_Type* zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    zT_D155D06D_Type zT_286;
    unsigned int zT_288;
    unsigned int zT_291;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_300 = 0;
    unsigned int zT_303 = 0;
    zT_338B7C76_TypeRegistry* zT_304;
    zT_D155D06D_Type* zT_305;
    zT_33EF6BFB_TypeKind zT_306;
    zT_338B7C76_TypeRegistry* zT_312;
    zT_42C2D6BF_EUPayload* zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    zT_42C2D6BF_EUPayload zT_316;
    zT_338B7C76_TypeRegistry* zT_318;
    zT_D155D06D_Type* zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    zT_D155D06D_Type zT_322;
    unsigned int zT_324;
    unsigned int zT_327;
    unsigned int zT_331;
    unsigned int zT_334;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_340 = 0;
    unsigned int zT_341;
    unsigned int zT_344 = 0;
    unsigned int zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    unsigned int zT_349 = 0;
    zT_338B7C76_TypeRegistry* zT_350;
    zT_D155D06D_Type* zT_351;
    zT_33EF6BFB_TypeKind zT_352;
    zT_338B7C76_TypeRegistry* zT_358;
    zT_E834303C_ArrayPayload* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_E834303C_ArrayPayload zT_362;
    zT_338B7C76_TypeRegistry* zT_364;
    zT_D155D06D_Type* zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    zT_D155D06D_Type zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned int zT_372;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_D155D06D_Type* zT_374;
    zT_33EF6BFB_TypeKind zT_375;
    zT_338B7C76_TypeRegistry* zT_381;
    zT_666DC2E1_TuplePayload* zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    zT_666DC2E1_TuplePayload zT_385;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned short zT_390;
    unsigned int zT_391;
    int zT_393;
    unsigned int zT_394;
    int zT_396;
    unsigned int zT_397;
    int zT_399;
    unsigned int zT_400;
    zT_338B7C76_TypeRegistry* zT_403;
    unsigned int* zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_338B7C76_TypeRegistry* zT_408;
    zT_D155D06D_Type* zT_409;
    unsigned int zT_410;
    zT_D155D06D_Type zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_415 = 0;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned int zT_420;
    int zT_421;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned int zT_426 = 0;
    unsigned int zT_427;
    zT_338B7C76_TypeRegistry* zT_432;
    zT_D155D06D_Type* zT_433;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->registry;
    zT_6 = zT_5->types_items;
    zT_7 = zT_6[idx];
    ty = zT_7;
    zT_8 = ty.kind;
    if ((int)(zT_8 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_13 = ty.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_87 = ty.kind;
    if ((int)(zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = tid;
    zF_331152CD_typeRegistryCompute(zT_18, zT_19);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_22 = self->registry;
    zT_23 = zT_22->st_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    sp = zT_26;
    zT_28 = sp.fields_start;
    zT_29 = (unsigned int)zT_28;
    fstart = zT_29;
    zT_31 = sp.fields_count;
    zT_32 = (unsigned int)zT_31;
    fcount = zT_32;
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    offset = zT_35;
    zT_37 = 1;
    zT_38 = (unsigned int)zT_37;
    max_align = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_7;
    z_bb_7:
    if ((int)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = fstart + fi;
    zT_47 = zT_45[zT_46];
    fe = zT_47;
    zT_49 = self->registry;
    zT_50 = zT_49->types_items;
    zT_51 = fe.type_id;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    ft = zT_53;
    zT_54 = ft.kind;
    if ((int)(zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_77 = offset;
    zT_78 = max_align;
    zT_79 = zF_D2BAC673_alignUp_1(zT_77, zT_78);
    ty.size = zT_79;
    ty.alignment = max_align;
    zT_80 = ty.size;
    if ((int)(zT_80 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_74 = 1;
    zT_76 = fi + (unsigned int)((unsigned int)zT_74);
    fi = zT_76;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_59 = self->registry;
    zT_60 = zT_59->fe_items;
    zT_61 = fstart + fi;
    zT_60[zT_61] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_62 = offset;
    zT_63 = ft.alignment;
    zT_65 = zF_D2BAC673_alignUp_1(zT_62, zT_63);
    offset = zT_65;
    fe.offset = offset;
    zT_66 = self->registry;
    zT_67 = zT_66->fe_items;
    zT_68 = fstart + fi;
    zT_67[zT_68] = fe;
    zT_69 = ft.size;
    zT_70 = offset + zT_69;
    offset = zT_70;
    zT_71 = ft.alignment;
    if ((int)(zT_71 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_73 = ft.alignment;
    max_align = zT_73;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_17;
    z_bb_17:
    zT_85 = self->registry;
    zT_86 = zT_85->types_items;
    zT_86[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_93 = self->registry;
    zT_94 = zT_93->en_items;
    zT_95 = ty.payload_idx;
    zT_96 = (unsigned int)zT_95;
    zT_97 = zT_94[zT_96];
    ep = zT_97;
    zT_99 = self->registry;
    zT_100 = zT_99->types_items;
    zT_101 = ep.backing_type;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    bt = zT_103;
    zT_104 = bt.size;
    ty.size = zT_104;
    zT_105 = bt.alignment;
    ty.alignment = zT_105;
    zT_106 = self->registry;
    zT_107 = zT_106->types_items;
    zT_107[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_108 = ty.kind;
    if ((int)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_114 = self->registry;
    zT_115 = zT_114->un_items;
    zT_116 = ty.payload_idx;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    up = zT_118;
    zT_120 = up.fields_start;
    zT_121 = (unsigned int)zT_120;
    fstart = zT_121;
    zT_123 = up.fields_count;
    zT_124 = (unsigned int)zT_123;
    fcount = zT_124;
    zT_126 = 0;
    zT_127 = (unsigned int)zT_126;
    max_sz = zT_127;
    zT_129 = 1;
    zT_130 = (unsigned int)zT_129;
    max_align = zT_130;
    zT_132 = 0;
    zT_133 = (unsigned int)zT_132;
    fi = zT_133;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_170 = ty.kind;
    if ((int)(zT_170 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((int)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_136 = self->registry;
    zT_137 = zT_136->fe_items;
    zT_138 = fstart + fi;
    zT_139 = zT_137[zT_138];
    fe = zT_139;
    zT_141 = self->registry;
    zT_142 = zT_141->types_items;
    zT_143 = fe.type_id;
    zT_144 = (unsigned int)zT_143;
    zT_145 = zT_142[zT_144];
    ft = zT_145;
    zT_146 = ft.kind;
    if ((int)(zT_146 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_160 = max_sz;
    zT_161 = max_align;
    zT_162 = zF_D2BAC673_alignUp_1(zT_160, zT_161);
    ty.size = zT_162;
    ty.alignment = max_align;
    zT_163 = ty.size;
    if ((int)(zT_163 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_157 = 1;
    zT_159 = fi + (unsigned int)((unsigned int)zT_157);
    fi = zT_159;
    goto z_bb_24;
    z_bb_28:
    zT_151 = ft.size;
    if ((int)(zT_151 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_153 = ft.size;
    max_sz = zT_153;
    goto z_bb_31;
    z_bb_31:
    zT_154 = ft.alignment;
    if ((int)(zT_154 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_156 = ft.alignment;
    max_align = zT_156;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_35;
    z_bb_35:
    zT_168 = self->registry;
    zT_169 = zT_168->types_items;
    zT_169[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_175 = self->registry;
    zT_176 = tid;
    zF_62A8E268_typeRegistryCompute(zT_175, zT_176);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_178 = ty.kind;
    if ((int)(zT_178 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_184 = self->registry;
    zT_185 = zT_184->tu_items;
    zT_186 = ty.payload_idx;
    zT_187 = (unsigned int)zT_186;
    zT_188 = zT_185[zT_187];
    tp = zT_188;
    zT_190 = self->registry;
    zT_191 = zT_190->types_items;
    zT_192 = tp.tag_type;
    zT_193 = (unsigned int)zT_192;
    zT_194 = zT_191[zT_193];
    tag_ty = zT_194;
    zT_196 = tp.fields_start;
    zT_197 = (unsigned int)zT_196;
    fstart = zT_197;
    zT_199 = tp.fields_count;
    zT_200 = (unsigned int)zT_199;
    fcount = zT_200;
    zT_202 = 0;
    zT_203 = (unsigned int)zT_202;
    max_ps = zT_203;
    zT_205 = 1;
    zT_206 = (unsigned int)zT_205;
    max_pa = zT_206;
    zT_208 = 0;
    zT_209 = (unsigned int)zT_208;
    fi = zT_209;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_270 = ty.kind;
    if ((int)(zT_270 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((int)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_212 = self->registry;
    zT_213 = zT_212->fe_items;
    zT_214 = fstart + fi;
    zT_215 = zT_213[zT_214];
    fe = zT_215;
    zT_217 = "FER:n";
    zT_219 = 5;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    fer_nm = zT_218;
    zT_220 = fer_nm;
    zF_C914CB83_markerWriteInt(zT_220, (unsigned int)((unsigned int)(unsigned int)(fstart + fi)));
    zT_225 = "FER:t";
    zT_227 = 5;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    fer_tm = zT_226;
    zT_228 = fer_tm;
    zT_229 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_228, zT_229);
    zT_232 = self->registry;
    zT_233 = zT_232->types_items;
    zT_234 = fe.type_id;
    zT_235 = (unsigned int)zT_234;
    zT_236 = zT_233[zT_235];
    ft = zT_236;
    zT_237 = ft.kind;
    if ((int)(zT_237 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_252 = tag_ty.alignment;
    if ((int)(zT_252 > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_248 = 1;
    zT_250 = fi + (unsigned int)((unsigned int)zT_248);
    fi = zT_250;
    goto z_bb_42;
    z_bb_46:
    zT_242 = ft.size;
    if ((int)(zT_242 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_244 = ft.size;
    max_ps = zT_244;
    goto z_bb_49;
    z_bb_49:
    zT_245 = ft.alignment;
    if ((int)(zT_245 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_247 = ft.alignment;
    max_pa = zT_247;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_254 = tag_ty.alignment;
    goto z_bb_54;
    z_bb_53:
    zT_254 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_254;
    zT_257 = tag_ty.size;
    total = zT_257;
    zT_258 = total;
    zT_259 = max_pa;
    zT_260 = zF_D2BAC673_alignUp_1(zT_258, zT_259);
    total = zT_260;
    zT_261 = max_ps;
    zT_262 = max_pa;
    zT_263 = zF_D2BAC673_alignUp_1(zT_261, zT_262);
    zT_264 = total + zT_263;
    total = zT_264;
    zT_265 = total;
    zT_266 = overall_align;
    zT_267 = zF_D2BAC673_alignUp_1(zT_265, zT_266);
    ty.size = zT_267;
    ty.alignment = overall_align;
    zT_268 = self->registry;
    zT_269 = zT_268->types_items;
    zT_269[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_276 = self->registry;
    zT_277 = zT_276->opt_items;
    zT_278 = ty.payload_idx;
    zT_279 = (unsigned int)zT_278;
    zT_280 = zT_277[zT_279];
    op = zT_280;
    zT_282 = self->registry;
    zT_283 = zT_282->types_items;
    zT_284 = op.payload;
    zT_285 = (unsigned int)zT_284;
    zT_286 = zT_283[zT_285];
    pt = zT_286;
    zT_288 = pt.alignment;
    if ((int)(zT_288 > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_306 = ty.kind;
    if ((int)(zT_306 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_291 = pt.alignment;
    goto z_bb_60;
    z_bb_59:
    zT_291 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_291;
    zT_296 = pt.size;
    zT_300 = zF_D2BAC673_alignUp_1(zT_296, (unsigned int)(4));
    zT_295 = pay_align;
    zT_303 = zF_D2BAC673_alignUp_1((unsigned int)(zT_300 + (unsigned int)(4)), zT_295);
    ty.size = zT_303;
    ty.alignment = pay_align;
    zT_304 = self->registry;
    zT_305 = zT_304->types_items;
    zT_305[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_312 = self->registry;
    zT_313 = zT_312->eu_items;
    zT_314 = ty.payload_idx;
    zT_315 = (unsigned int)zT_314;
    zT_316 = zT_313[zT_315];
    ep_1 = zT_316;
    zT_318 = self->registry;
    zT_319 = zT_318->types_items;
    zT_320 = ep_1.payload;
    zT_321 = (unsigned int)zT_320;
    zT_322 = zT_319[zT_321];
    pt = zT_322;
    zT_324 = pt.size;
    if ((int)(zT_324 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_352 = ty.kind;
    if ((int)(zT_352 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_327 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_327 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_327;
    zT_331 = pt.alignment;
    if ((int)(zT_331 > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_334 = pt.alignment;
    goto z_bb_69;
    z_bb_68:
    zT_334 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_334;
    zT_338 = union_sz;
    zT_339 = union_align;
    zT_340 = zF_D2BAC673_alignUp_1(zT_338, zT_339);
    total = zT_340;
    zT_341 = total;
    zT_344 = zF_D2BAC673_alignUp_1(zT_341, (unsigned int)(4));
    zT_346 = zT_344 + (unsigned int)(4);
    total = zT_346;
    zT_347 = total;
    zT_348 = union_align;
    zT_349 = zF_D2BAC673_alignUp_1(zT_347, zT_348);
    ty.size = zT_349;
    ty.alignment = union_align;
    zT_350 = self->registry;
    zT_351 = zT_350->types_items;
    zT_351[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_358 = self->registry;
    zT_359 = zT_358->array_items;
    zT_360 = ty.payload_idx;
    zT_361 = (unsigned int)zT_360;
    zT_362 = zT_359[zT_361];
    ap = zT_362;
    zT_364 = self->registry;
    zT_365 = zT_364->types_items;
    zT_366 = ap.elem;
    zT_367 = (unsigned int)zT_366;
    zT_368 = zT_365[zT_367];
    et = zT_368;
    zT_369 = et.size;
    zT_370 = ap.length;
    ty.size = (unsigned int)(zT_369 * zT_370);
    zT_372 = et.alignment;
    ty.alignment = zT_372;
    zT_373 = self->registry;
    zT_374 = zT_373->types_items;
    zT_374[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_375 = ty.kind;
    if ((int)(zT_375 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_381 = self->registry;
    zT_382 = zT_381->tup_items;
    zT_383 = ty.payload_idx;
    zT_384 = (unsigned int)zT_383;
    zT_385 = zT_382[zT_384];
    tp_2 = zT_385;
    zT_387 = tp_2.elems_start;
    zT_388 = (unsigned int)zT_387;
    estr = zT_388;
    zT_390 = tp_2.elems_count;
    zT_391 = (unsigned int)zT_390;
    ecount = zT_391;
    zT_393 = 0;
    zT_394 = (unsigned int)zT_393;
    offset = zT_394;
    zT_396 = 1;
    zT_397 = (unsigned int)zT_396;
    max_align = zT_397;
    zT_399 = 0;
    zT_400 = (unsigned int)zT_399;
    ei = zT_400;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    if ((int)(ei < ecount)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_403 = self->registry;
    zT_404 = zT_403->xt_items;
    zT_405 = estr + ei;
    zT_406 = zT_404[zT_405];
    elem_tid = zT_406;
    zT_408 = self->registry;
    zT_409 = zT_408->types_items;
    zT_410 = (unsigned int)elem_tid;
    zT_411 = zT_409[zT_410];
    et = zT_411;
    zT_412 = offset;
    zT_413 = et.alignment;
    zT_415 = zF_D2BAC673_alignUp_1(zT_412, zT_413);
    offset = zT_415;
    zT_416 = et.size;
    zT_417 = offset + zT_416;
    offset = zT_417;
    zT_418 = et.alignment;
    if ((int)(zT_418 > max_align)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_424 = offset;
    zT_425 = max_align;
    zT_426 = zF_D2BAC673_alignUp_1(zT_424, zT_425);
    ty.size = zT_426;
    ty.alignment = max_align;
    zT_427 = ty.size;
    if ((int)(zT_427 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_421 = 1;
    zT_423 = ei + (unsigned int)((unsigned int)zT_421);
    ei = zT_423;
    goto z_bb_75;
    z_bb_79:
    zT_420 = et.alignment;
    max_align = zT_420;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_82;
    z_bb_82:
    zT_432 = self->registry;
    zT_433 = zT_432->types_items;
    zT_433[idx] = ty;
    goto z_bb_74;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    zT_C6536882_EU_532 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((int)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_18 = i + (unsigned int)((unsigned int)zT_16);
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_25 = self->alloc;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(type_count * (unsigned int)(4)), (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_34 = zT_32.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    if ((int)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_45 = zi + (unsigned int)((unsigned int)zT_43);
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    if ((int)(ei < zT_49)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    if ((int)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_62 = zT_59 + (unsigned int)((unsigned int)zT_60);
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_67 = ei + (unsigned int)((unsigned int)zT_65);
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    int zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_D155D06D_Type* zT_119;
    int zT_120;
    unsigned int zT_122;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((int)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((int)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((int)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_19 = ti + (unsigned int)((unsigned int)zT_17);
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    self->sorted_len = (unsigned int)(zT_30 + (unsigned int)(1));
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_39 = zT_37 + (unsigned int)((unsigned int)tid);
    zT_39->state = (unsigned char)(2);
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    if ((int)(ei < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    if ((int)(zT_47 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    if ((int)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_74 = ei + (unsigned int)((unsigned int)zT_72);
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    if ((int)(zT_57 > (unsigned int)zT_58)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_64 = zT_61 - (unsigned int)((unsigned int)zT_62);
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    if ((int)(zT_67 == (unsigned int)zT_68)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((int)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    zT_83 = ty.state;
    if ((int)(zT_83 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_120 = 1;
    zT_122 = ci + (unsigned int)((unsigned int)zT_120);
    ci = zT_122;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_86 = zT_88 > (unsigned int)zT_89;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = self->diag;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_101);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    ty.alignment = (unsigned int)(1);
    ty.state = (unsigned char)(2);
    zT_118 = self->registry;
    zT_119 = zT_118->types_items;
    zT_119[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* fieldEmbedsByValue */
int zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* requiresFullDef */
int zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* layoutFieldNeedsEdge */
int zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    return (int)(0);
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    if ((int)(field_type >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    zT_12 = ft.kind;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    int zT_18;
    unsigned int zT_20;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((int)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_15 = (unsigned int)((unsigned int)fstart) + fi;
    zT_16 = zT_13[zT_15];
    zT_10 = zT_16.type_id;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_20 = fi + (unsigned int)((unsigned int)zT_18);
    fi = zT_20;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_406493CE_StructPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_406493CE_StructPayload zT_23;
    zT_C890C8CB_TypeResolver* zT_24;
    unsigned int zT_25;
    unsigned short zT_26;
    unsigned int zT_27;
    zT_33EF6BFB_TypeKind zT_30;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_54FF90FA_TaggedUnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_54FF90FA_TaggedUnionPayload zT_40;
    zT_C890C8CB_TypeResolver* zT_41;
    unsigned int zT_42;
    unsigned short zT_43;
    unsigned int zT_44;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_AF9231A2_UnionPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_AF9231A2_UnionPayload zT_57;
    zT_C890C8CB_TypeResolver* zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    unsigned int zT_61;
    zT_33EF6BFB_TypeKind zT_64;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_AF9231A2_UnionPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_AF9231A2_UnionPayload zT_74;
    zT_C890C8CB_TypeResolver* zT_75;
    unsigned int zT_76;
    unsigned short zT_77;
    unsigned int zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    zT_C890C8CB_TypeResolver* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_E834303C_ArrayPayload* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_E834303C_ArrayPayload zT_93;
    zT_33EF6BFB_TypeKind zT_95;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_666DC2E1_TuplePayload* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_666DC2E1_TuplePayload zT_105;
    int zT_107;
    unsigned int zT_108;
    unsigned short zT_109;
    zT_C890C8CB_TypeResolver* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int* zT_116;
    unsigned int zT_117;
    unsigned int zT_119;
    int zT_121;
    unsigned int zT_123;
    zT_33EF6BFB_TypeKind zT_124;
    zT_C890C8CB_TypeResolver* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    zT_338B7C76_TypeRegistry* zT_132;
    zT_0B10E8E9_OptionalPayload* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_0B10E8E9_OptionalPayload zT_136;
    zT_33EF6BFB_TypeKind zT_138;
    zT_C890C8CB_TypeResolver* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_338B7C76_TypeRegistry* zT_146;
    zT_42C2D6BF_EUPayload* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_42C2D6BF_EUPayload zT_150;
    int zT_152;
    unsigned int zT_154;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((int)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    zT_13 = ty.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_152 = 1;
    zT_154 = ti + (unsigned int)((unsigned int)zT_152);
    ti = zT_154;
    goto z_bb_1;
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->st_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    sp = zT_23;
    zT_24 = self;
    zT_25 = sp.fields_start;
    zT_26 = sp.fields_count;
    zT_27 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_24, zT_25, zT_26, zT_27);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = ty.kind;
    if ((int)(zT_30 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_36 = self->registry;
    zT_37 = zT_36->tu_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    tp = zT_40;
    zT_41 = self;
    zT_42 = tp.fields_start;
    zT_43 = tp.fields_count;
    zT_44 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_47 = ty.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_53 = self->registry;
    zT_54 = zT_53->un_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    up = zT_57;
    zT_58 = self;
    zT_59 = up.fields_start;
    zT_60 = up.fields_count;
    zT_61 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_58, zT_59, zT_60, zT_61);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_64 = ty.kind;
    if ((int)(zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_70 = self->registry;
    zT_71 = zT_70->un_items;
    zT_72 = ty.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    pup = zT_74;
    zT_75 = self;
    zT_76 = pup.fields_start;
    zT_77 = pup.fields_count;
    zT_78 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_75, zT_76, zT_77, zT_78);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_81 = ty.kind;
    if ((int)(zT_81 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_86 = self;
    zT_89 = self->registry;
    zT_90 = zT_89->array_items;
    zT_91 = ty.payload_idx;
    zT_92 = (unsigned int)zT_91;
    zT_93 = zT_90[zT_92];
    zT_87 = zT_93.elem;
    zT_88 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_86, zT_87, zT_88);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_95 = ty.kind;
    if ((int)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_101 = self->registry;
    zT_102 = zT_101->tup_items;
    zT_103 = ty.payload_idx;
    zT_104 = (unsigned int)zT_103;
    zT_105 = zT_102[zT_104];
    tp_1 = zT_105;
    zT_107 = 0;
    zT_108 = (unsigned int)zT_107;
    ei = zT_108;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_124 = ty.kind;
    if ((int)(zT_124 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_27; else goto z_bb_29;
    z_bb_23:
    zT_109 = tp_1.elems_count;
    if ((int)(ei < (unsigned int)((unsigned int)zT_109))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_112 = self;
    zT_115 = self->registry;
    zT_116 = zT_115->xt_items;
    zT_117 = tp_1.elems_start;
    zT_119 = (unsigned int)((unsigned int)zT_117) + ei;
    zT_113 = zT_116[zT_119];
    zT_114 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_112, zT_113, zT_114);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_21;
    z_bb_26:
    zT_121 = 1;
    zT_123 = ei + (unsigned int)((unsigned int)zT_121);
    ei = zT_123;
    goto z_bb_23;
    z_bb_27:
    zT_129 = self;
    zT_132 = self->registry;
    zT_133 = zT_132->opt_items;
    zT_134 = ty.payload_idx;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zT_133[zT_135];
    zT_130 = zT_136.payload;
    zT_131 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_129, zT_130, zT_131);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_138 = ty.kind;
    if ((int)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_143 = self;
    zT_146 = self->registry;
    zT_147 = zT_146->eu_items;
    zT_148 = ty.payload_idx;
    zT_149 = (unsigned int)zT_148;
    zT_150 = zT_147[zT_149];
    zT_144 = zT_150.payload;
    zT_145 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_143, zT_144, zT_145);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_28;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    int zT_9;
    int zT_11;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    int zT_26;
    int zT_28;
    zT_C6536882_EU_532 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    int zT_40;
    int zT_42;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    int zT_54;
    int zT_56;
    zT_C6536882_EU_532 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_71;
    unsigned int zT_73;
    zT_3E40CD83_Sand* zT_75;
    int zT_78;
    int zT_80;
    zT_C6536882_EU_532 zT_82 = {0};
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int* zT_87;
    unsigned int zT_89;
    unsigned int zT_91;
    int zT_93;
    unsigned int zT_94;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type* zT_98;
    zT_D155D06D_Type zT_99;
    unsigned char zT_101;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_406493CE_StructPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_406493CE_StructPayload zT_112;
    int zT_114;
    unsigned int zT_115;
    unsigned short zT_116;
    int zT_119;
    int zT_120;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_2DF01B61_FieldEntry* zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    zT_2DF01B61_FieldEntry zT_128;
    unsigned int zT_129;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D155D06D_Type* zT_132;
    unsigned int zT_133;
    zT_D155D06D_Type zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_137 = 0;
    unsigned char zT_138;
    zT_33EF6BFB_TypeKind zT_139;
    zT_3E40CD83_Sand* zT_144;
    unsigned int** zT_145;
    unsigned int** zT_146;
    unsigned int* zT_147;
    unsigned int zT_148;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_159;
    zT_33EF6BFB_TypeKind zT_160;
    zT_3E40CD83_Sand* zT_165;
    unsigned int** zT_166;
    unsigned int** zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    int zT_181;
    unsigned int zT_183;
    zT_33EF6BFB_TypeKind zT_184;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_54FF90FA_TaggedUnionPayload* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_54FF90FA_TaggedUnionPayload zT_194;
    int zT_196;
    unsigned int zT_197;
    unsigned short zT_198;
    int zT_201;
    int zT_202;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_2DF01B61_FieldEntry* zT_206;
    unsigned int zT_207;
    unsigned int zT_209;
    zT_2DF01B61_FieldEntry zT_210;
    unsigned int zT_211;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_D155D06D_Type* zT_214;
    unsigned int zT_215;
    zT_D155D06D_Type zT_216;
    zT_33EF6BFB_TypeKind zT_217;
    int zT_219 = 0;
    unsigned char zT_220;
    zT_33EF6BFB_TypeKind zT_221;
    zT_3E40CD83_Sand* zT_226;
    unsigned int** zT_227;
    unsigned int** zT_228;
    unsigned int* zT_229;
    unsigned int zT_230;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_241;
    zT_33EF6BFB_TypeKind zT_242;
    zT_3E40CD83_Sand* zT_247;
    unsigned int** zT_248;
    unsigned int** zT_249;
    unsigned int* zT_250;
    unsigned int zT_251;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_262;
    int zT_263;
    unsigned int zT_265;
    zT_33EF6BFB_TypeKind zT_266;
    zT_338B7C76_TypeRegistry* zT_272;
    zT_AF9231A2_UnionPayload* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_AF9231A2_UnionPayload zT_276;
    int zT_278;
    unsigned int zT_279;
    unsigned short zT_280;
    int zT_283;
    int zT_284;
    zT_338B7C76_TypeRegistry* zT_287;
    zT_2DF01B61_FieldEntry* zT_288;
    unsigned int zT_289;
    unsigned int zT_291;
    zT_2DF01B61_FieldEntry zT_292;
    unsigned int zT_293;
    zT_338B7C76_TypeRegistry* zT_295;
    zT_D155D06D_Type* zT_296;
    unsigned int zT_297;
    zT_D155D06D_Type zT_298;
    zT_33EF6BFB_TypeKind zT_299;
    int zT_301 = 0;
    unsigned char zT_302;
    zT_33EF6BFB_TypeKind zT_303;
    zT_3E40CD83_Sand* zT_308;
    unsigned int** zT_309;
    unsigned int** zT_310;
    unsigned int* zT_311;
    unsigned int zT_312;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    unsigned int zT_323;
    zT_33EF6BFB_TypeKind zT_324;
    zT_3E40CD83_Sand* zT_329;
    unsigned int** zT_330;
    unsigned int** zT_331;
    unsigned int* zT_332;
    unsigned int zT_333;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    unsigned int zT_344;
    int zT_345;
    unsigned int zT_347;
    zT_33EF6BFB_TypeKind zT_348;
    zT_338B7C76_TypeRegistry* zT_354;
    zT_AF9231A2_UnionPayload* zT_355;
    unsigned int zT_356;
    unsigned int zT_357;
    zT_AF9231A2_UnionPayload zT_358;
    int zT_360;
    unsigned int zT_361;
    unsigned short zT_362;
    int zT_365;
    int zT_366;
    zT_338B7C76_TypeRegistry* zT_369;
    zT_2DF01B61_FieldEntry* zT_370;
    unsigned int zT_371;
    unsigned int zT_373;
    zT_2DF01B61_FieldEntry zT_374;
    unsigned int zT_375;
    zT_338B7C76_TypeRegistry* zT_377;
    zT_D155D06D_Type* zT_378;
    unsigned int zT_379;
    zT_D155D06D_Type zT_380;
    zT_33EF6BFB_TypeKind zT_381;
    int zT_383 = 0;
    unsigned char zT_384;
    zT_33EF6BFB_TypeKind zT_385;
    zT_3E40CD83_Sand* zT_390;
    unsigned int** zT_391;
    unsigned int** zT_392;
    unsigned int* zT_393;
    unsigned int zT_394;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_405;
    zT_33EF6BFB_TypeKind zT_406;
    zT_3E40CD83_Sand* zT_411;
    unsigned int** zT_412;
    unsigned int** zT_413;
    unsigned int* zT_414;
    unsigned int zT_415;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned int zT_426;
    int zT_427;
    unsigned int zT_429;
    zT_33EF6BFB_TypeKind zT_430;
    zT_338B7C76_TypeRegistry* zT_436;
    zT_E834303C_ArrayPayload* zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    zT_E834303C_ArrayPayload zT_440;
    unsigned int zT_441;
    zT_338B7C76_TypeRegistry* zT_443;
    zT_D155D06D_Type* zT_444;
    unsigned int zT_445;
    zT_D155D06D_Type zT_446;
    zT_33EF6BFB_TypeKind zT_447;
    int zT_449 = 0;
    unsigned char zT_450;
    zT_33EF6BFB_TypeKind zT_451;
    zT_3E40CD83_Sand* zT_456;
    unsigned int** zT_457;
    unsigned int** zT_458;
    unsigned int* zT_459;
    unsigned int zT_460;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    unsigned int zT_471;
    zT_33EF6BFB_TypeKind zT_472;
    zT_3E40CD83_Sand* zT_477;
    unsigned int** zT_478;
    unsigned int** zT_479;
    unsigned int* zT_480;
    unsigned int zT_481;
    unsigned int zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned int zT_492;
    zT_33EF6BFB_TypeKind zT_493;
    zT_338B7C76_TypeRegistry* zT_499;
    zT_42C2D6BF_EUPayload* zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    zT_42C2D6BF_EUPayload zT_503;
    unsigned int zT_504;
    zT_338B7C76_TypeRegistry* zT_506;
    zT_D155D06D_Type* zT_507;
    unsigned int zT_508;
    zT_D155D06D_Type zT_509;
    zT_33EF6BFB_TypeKind zT_510;
    int zT_512 = 0;
    unsigned char zT_513;
    zT_33EF6BFB_TypeKind zT_514;
    zT_3E40CD83_Sand* zT_519;
    unsigned int** zT_520;
    unsigned int** zT_521;
    unsigned int* zT_522;
    unsigned int zT_523;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_534;
    zT_33EF6BFB_TypeKind zT_535;
    zT_3E40CD83_Sand* zT_540;
    unsigned int** zT_541;
    unsigned int** zT_542;
    unsigned int* zT_543;
    unsigned int zT_544;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    unsigned int zT_553;
    unsigned int zT_555;
    zT_33EF6BFB_TypeKind zT_556;
    zT_338B7C76_TypeRegistry* zT_562;
    zT_0B10E8E9_OptionalPayload* zT_563;
    unsigned int zT_564;
    unsigned int zT_565;
    zT_0B10E8E9_OptionalPayload zT_566;
    unsigned int zT_567;
    zT_338B7C76_TypeRegistry* zT_569;
    zT_D155D06D_Type* zT_570;
    unsigned int zT_571;
    zT_D155D06D_Type zT_572;
    zT_33EF6BFB_TypeKind zT_573;
    int zT_575 = 0;
    unsigned char zT_576;
    zT_33EF6BFB_TypeKind zT_577;
    zT_3E40CD83_Sand* zT_582;
    unsigned int** zT_583;
    unsigned int** zT_584;
    unsigned int* zT_585;
    unsigned int zT_586;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned int zT_597;
    zT_33EF6BFB_TypeKind zT_598;
    zT_3E40CD83_Sand* zT_603;
    unsigned int** zT_604;
    unsigned int** zT_605;
    unsigned int* zT_606;
    unsigned int zT_607;
    unsigned int zT_611;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_616;
    unsigned int zT_618;
    unsigned int zT_621;
    unsigned int zT_622;
    unsigned int zT_624;
    int zT_625;
    unsigned int zT_627;
    unsigned int zT_630;
    unsigned int zT_631;
    unsigned int zT_633;
    unsigned int zT_635;
    unsigned int zT_636;
    unsigned int zT_640;
    unsigned int zT_641;
    unsigned int zT_642;
    unsigned char zT_643;
    unsigned char zT_646;
    unsigned int zT_647;
    unsigned int zT_648;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    zT_3E40CD83_Sand* zT_654;
    int zT_657;
    int zT_659;
    zT_C6536882_EU_532 zT_661 = {0};
    unsigned char zT_662;
    unsigned char* zT_663;
    unsigned int* zT_666;
    unsigned int zT_668;
    int zT_669;
    unsigned int zT_670;
    unsigned char zT_672;
    unsigned int zT_675;
    unsigned int zT_676;
    unsigned int zT_678;
    int zT_679;
    unsigned int zT_681;
    unsigned char* zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_684;
    unsigned int zT_685;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_686;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_688;
    unsigned int zT_690;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_691;
    int zT_694;
    unsigned char* zT_695;
    unsigned int zT_696;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    unsigned int zT_698 = 0;
    unsigned int zT_702;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_703;
    unsigned char* zT_707;
    unsigned int zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    unsigned char* zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_712;
    unsigned int zT_713;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_714;
    int zT_715;
    unsigned int zT_716;
    unsigned char zT_718;
    unsigned char* zT_722;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_723;
    unsigned int zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_725;
    unsigned char* zT_727;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_728;
    unsigned int zT_729;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_730;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_732;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    int zT_739;
    unsigned char* zT_740;
    unsigned int zT_741;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_742;
    unsigned int zT_743 = 0;
    unsigned int zT_747;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_748;
    unsigned char* zT_752;
    unsigned int zT_753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_754;
    unsigned char* zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_761;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_764;
    zT_338B7C76_TypeRegistry* zT_765;
    zT_D155D06D_Type* zT_766;
    zT_D155D06D_Type zT_767;
    zT_33EF6BFB_TypeKind zT_768;
    int zT_772;
    unsigned char* zT_773;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    unsigned int zT_776 = 0;
    unsigned int zT_780;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_781;
    unsigned char* zT_785;
    unsigned int zT_786;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_787;
    unsigned char* zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    unsigned int zT_791;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_792;
    int zT_793;
    unsigned int zT_795;
    zT_010C8DF0_ClassificationResul zT_796;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_5A26C2ED_Arr_unsigned_char_1 cls_b;
    unsigned int cls_l;
    unsigned int cls_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_5A26C2ED_Arr_unsigned_char_1 ctb;
    unsigned int ctl;
    unsigned int cts;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_5A26C2ED_Arr_unsigned_char_1 ckb;
    unsigned int ckl;
    unsigned int cks;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_11 = 1;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(zT_9 * tl), (unsigned int)((unsigned int)zT_11));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_28 = 4;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)(zT_26 * wp_edge_cap), (unsigned int)((unsigned int)zT_28));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_42 = 4;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)(zT_40 * wp_edge_cap), (unsigned int)((unsigned int)zT_42));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_46 = zT_44.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_56 = 4;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, (unsigned int)(zT_54 * tl), (unsigned int)((unsigned int)zT_56));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_60 = zT_58.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    if ((int)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_73 = 0;
    wp_count = zT_73;
    zT_75 = perm_alloc;
    zT_78 = 4;
    zT_80 = 4;
    zT_82 = zF_1395EB68_sandAlloc(zT_75, (unsigned int)(zT_78 * tl), (unsigned int)((unsigned int)zT_80));
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_71 = whi + (unsigned int)((unsigned int)zT_69);
    whi = zT_71;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_84 = zT_82.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_84;
    zT_87 = (unsigned int*)wl_raw;
    worklist = zT_87;
    zT_89 = 0;
    wl_head = zT_89;
    zT_91 = 0;
    wl_tail = zT_91;
    zT_93 = 0;
    zT_94 = (unsigned int)zT_93;
    ti = zT_94;
    goto z_bb_20;
    z_bb_20:
    if ((int)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_97 = self->registry;
    zT_98 = zT_97->types_items;
    zT_99 = zT_98[ti];
    ty = zT_99;
    zT_101 = 1;
    is_po = zT_101;
    zT_102 = ty.kind;
    if ((int)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_625 = 1;
    zT_627 = ti + (unsigned int)((unsigned int)zT_625);
    ti = zT_627;
    goto z_bb_20;
    z_bb_24:
    zT_108 = self->registry;
    zT_109 = zT_108->st_items;
    zT_110 = ty.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    sp = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned int)zT_114;
    fi = zT_115;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((int)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_184 = ty.kind;
    if ((int)(zT_184 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_116 = sp.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_116))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_123 = self->registry;
    zT_124 = zT_123->fe_items;
    zT_125 = sp.fields_start;
    zT_127 = (unsigned int)((unsigned int)zT_125) + fi;
    zT_128 = zT_124[zT_127];
    zT_129 = zT_128.type_id;
    ft_id = zT_129;
    zT_131 = self->registry;
    zT_132 = zT_131->types_items;
    zT_133 = (unsigned int)ft_id;
    zT_134 = zT_132[zT_133];
    ft = zT_134;
    zT_135 = ft.kind;
    zT_137 = zF_A47239A9_fieldEmbedsByValue(zT_135);
    if (zT_137) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_181 = 1;
    zT_183 = fi + (unsigned int)((unsigned int)zT_181);
    fi = zT_183;
    goto z_bb_27;
    z_bb_31:
    zT_120 = 0;
    zT_119 = is_po != zT_120;
    goto z_bb_33;
    z_bb_32:
    zT_119 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_119) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_138 = 0;
    is_po = zT_138;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_139 = ft.kind;
    if ((int)(zT_139 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_144 = perm_alloc;
    zT_145 = &wp_to;
    zT_146 = &wp_next;
    zT_147 = &wp_edge_cap;
    zT_148 = wp_count;
    zF_25C377BD_growWpEdges(zT_144, zT_145, zT_146, zT_147, zT_148);
    zT_152 = (unsigned int)ti;
    zT_153 = (unsigned int)wp_count;
    wp_to[zT_153] = zT_152;
    zT_154 = (unsigned int)ft_id;
    zT_155 = wp_head[zT_154];
    zT_156 = (unsigned int)wp_count;
    wp_next[zT_156] = zT_155;
    zT_157 = (unsigned int)ft_id;
    wp_head[zT_157] = wp_count;
    zT_159 = wp_count + (unsigned int)(1);
    wp_count = zT_159;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_160 = ft.kind;
    if ((int)(zT_160 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_165 = perm_alloc;
    zT_166 = &wp_to;
    zT_167 = &wp_next;
    zT_168 = &wp_edge_cap;
    zT_169 = wp_count;
    zF_25C377BD_growWpEdges(zT_165, zT_166, zT_167, zT_168, zT_169);
    zT_173 = (unsigned int)ti;
    zT_174 = (unsigned int)wp_count;
    wp_to[zT_174] = zT_173;
    zT_175 = (unsigned int)ft_id;
    zT_176 = wp_head[zT_175];
    zT_177 = (unsigned int)wp_count;
    wp_next[zT_177] = zT_176;
    zT_178 = (unsigned int)ft_id;
    wp_head[zT_178] = wp_count;
    zT_180 = wp_count + (unsigned int)(1);
    wp_count = zT_180;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_190 = self->registry;
    zT_191 = zT_190->tu_items;
    zT_192 = ty.payload_idx;
    zT_193 = (unsigned int)zT_192;
    zT_194 = zT_191[zT_193];
    tp = zT_194;
    zT_196 = 0;
    zT_197 = (unsigned int)zT_196;
    fi = zT_197;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_266 = ty.kind;
    if ((int)(zT_266 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_198 = tp.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_198))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_205 = self->registry;
    zT_206 = zT_205->fe_items;
    zT_207 = tp.fields_start;
    zT_209 = (unsigned int)((unsigned int)zT_207) + fi;
    zT_210 = zT_206[zT_209];
    zT_211 = zT_210.type_id;
    ft_id = zT_211;
    zT_213 = self->registry;
    zT_214 = zT_213->types_items;
    zT_215 = (unsigned int)ft_id;
    zT_216 = zT_214[zT_215];
    ft = zT_216;
    zT_217 = ft.kind;
    zT_219 = zF_A47239A9_fieldEmbedsByValue(zT_217);
    if (zT_219) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_263 = 1;
    zT_265 = fi + (unsigned int)((unsigned int)zT_263);
    fi = zT_265;
    goto z_bb_45;
    z_bb_49:
    zT_202 = 0;
    zT_201 = is_po != zT_202;
    goto z_bb_51;
    z_bb_50:
    zT_201 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_201) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_220 = 0;
    is_po = zT_220;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_221 = ft.kind;
    if ((int)(zT_221 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_226 = perm_alloc;
    zT_227 = &wp_to;
    zT_228 = &wp_next;
    zT_229 = &wp_edge_cap;
    zT_230 = wp_count;
    zF_25C377BD_growWpEdges(zT_226, zT_227, zT_228, zT_229, zT_230);
    zT_234 = (unsigned int)ti;
    zT_235 = (unsigned int)wp_count;
    wp_to[zT_235] = zT_234;
    zT_236 = (unsigned int)ft_id;
    zT_237 = wp_head[zT_236];
    zT_238 = (unsigned int)wp_count;
    wp_next[zT_238] = zT_237;
    zT_239 = (unsigned int)ft_id;
    wp_head[zT_239] = wp_count;
    zT_241 = wp_count + (unsigned int)(1);
    wp_count = zT_241;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_242 = ft.kind;
    if ((int)(zT_242 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_247 = perm_alloc;
    zT_248 = &wp_to;
    zT_249 = &wp_next;
    zT_250 = &wp_edge_cap;
    zT_251 = wp_count;
    zF_25C377BD_growWpEdges(zT_247, zT_248, zT_249, zT_250, zT_251);
    zT_255 = (unsigned int)ti;
    zT_256 = (unsigned int)wp_count;
    wp_to[zT_256] = zT_255;
    zT_257 = (unsigned int)ft_id;
    zT_258 = wp_head[zT_257];
    zT_259 = (unsigned int)wp_count;
    wp_next[zT_259] = zT_258;
    zT_260 = (unsigned int)ft_id;
    wp_head[zT_260] = wp_count;
    zT_262 = wp_count + (unsigned int)(1);
    wp_count = zT_262;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_272 = self->registry;
    zT_273 = zT_272->un_items;
    zT_274 = ty.payload_idx;
    zT_275 = (unsigned int)zT_274;
    zT_276 = zT_273[zT_275];
    up = zT_276;
    zT_278 = 0;
    zT_279 = (unsigned int)zT_278;
    fi = zT_279;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_348 = ty.kind;
    if ((int)(zT_348 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_280 = up.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_280))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_287 = self->registry;
    zT_288 = zT_287->fe_items;
    zT_289 = up.fields_start;
    zT_291 = (unsigned int)((unsigned int)zT_289) + fi;
    zT_292 = zT_288[zT_291];
    zT_293 = zT_292.type_id;
    ft_id = zT_293;
    zT_295 = self->registry;
    zT_296 = zT_295->types_items;
    zT_297 = (unsigned int)ft_id;
    zT_298 = zT_296[zT_297];
    ft = zT_298;
    zT_299 = ft.kind;
    zT_301 = zF_A47239A9_fieldEmbedsByValue(zT_299);
    if (zT_301) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_345 = 1;
    zT_347 = fi + (unsigned int)((unsigned int)zT_345);
    fi = zT_347;
    goto z_bb_63;
    z_bb_67:
    zT_284 = 0;
    zT_283 = is_po != zT_284;
    goto z_bb_69;
    z_bb_68:
    zT_283 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_283) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_302 = 0;
    is_po = zT_302;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_303 = ft.kind;
    if ((int)(zT_303 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_308 = perm_alloc;
    zT_309 = &wp_to;
    zT_310 = &wp_next;
    zT_311 = &wp_edge_cap;
    zT_312 = wp_count;
    zF_25C377BD_growWpEdges(zT_308, zT_309, zT_310, zT_311, zT_312);
    zT_316 = (unsigned int)ti;
    zT_317 = (unsigned int)wp_count;
    wp_to[zT_317] = zT_316;
    zT_318 = (unsigned int)ft_id;
    zT_319 = wp_head[zT_318];
    zT_320 = (unsigned int)wp_count;
    wp_next[zT_320] = zT_319;
    zT_321 = (unsigned int)ft_id;
    wp_head[zT_321] = wp_count;
    zT_323 = wp_count + (unsigned int)(1);
    wp_count = zT_323;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_324 = ft.kind;
    if ((int)(zT_324 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_329 = perm_alloc;
    zT_330 = &wp_to;
    zT_331 = &wp_next;
    zT_332 = &wp_edge_cap;
    zT_333 = wp_count;
    zF_25C377BD_growWpEdges(zT_329, zT_330, zT_331, zT_332, zT_333);
    zT_337 = (unsigned int)ti;
    zT_338 = (unsigned int)wp_count;
    wp_to[zT_338] = zT_337;
    zT_339 = (unsigned int)ft_id;
    zT_340 = wp_head[zT_339];
    zT_341 = (unsigned int)wp_count;
    wp_next[zT_341] = zT_340;
    zT_342 = (unsigned int)ft_id;
    wp_head[zT_342] = wp_count;
    zT_344 = wp_count + (unsigned int)(1);
    wp_count = zT_344;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_354 = self->registry;
    zT_355 = zT_354->un_items;
    zT_356 = ty.payload_idx;
    zT_357 = (unsigned int)zT_356;
    zT_358 = zT_355[zT_357];
    p_up = zT_358;
    zT_360 = 0;
    zT_361 = (unsigned int)zT_360;
    pfi = zT_361;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_430 = ty.kind;
    if ((int)(zT_430 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_362 = p_up.fields_count;
    if ((int)(pfi < (unsigned int)((unsigned int)zT_362))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_369 = self->registry;
    zT_370 = zT_369->fe_items;
    zT_371 = p_up.fields_start;
    zT_373 = (unsigned int)((unsigned int)zT_371) + pfi;
    zT_374 = zT_370[zT_373];
    zT_375 = zT_374.type_id;
    ft_id = zT_375;
    zT_377 = self->registry;
    zT_378 = zT_377->types_items;
    zT_379 = (unsigned int)ft_id;
    zT_380 = zT_378[zT_379];
    ft = zT_380;
    zT_381 = ft.kind;
    zT_383 = zF_A47239A9_fieldEmbedsByValue(zT_381);
    if (zT_383) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_427 = 1;
    zT_429 = pfi + (unsigned int)((unsigned int)zT_427);
    pfi = zT_429;
    goto z_bb_81;
    z_bb_85:
    zT_366 = 0;
    zT_365 = is_po != zT_366;
    goto z_bb_87;
    z_bb_86:
    zT_365 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_365) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_384 = 0;
    is_po = zT_384;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_385 = ft.kind;
    if ((int)(zT_385 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_390 = perm_alloc;
    zT_391 = &wp_to;
    zT_392 = &wp_next;
    zT_393 = &wp_edge_cap;
    zT_394 = wp_count;
    zF_25C377BD_growWpEdges(zT_390, zT_391, zT_392, zT_393, zT_394);
    zT_398 = (unsigned int)ti;
    zT_399 = (unsigned int)wp_count;
    wp_to[zT_399] = zT_398;
    zT_400 = (unsigned int)ft_id;
    zT_401 = wp_head[zT_400];
    zT_402 = (unsigned int)wp_count;
    wp_next[zT_402] = zT_401;
    zT_403 = (unsigned int)ft_id;
    wp_head[zT_403] = wp_count;
    zT_405 = wp_count + (unsigned int)(1);
    wp_count = zT_405;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_406 = ft.kind;
    if ((int)(zT_406 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_411 = perm_alloc;
    zT_412 = &wp_to;
    zT_413 = &wp_next;
    zT_414 = &wp_edge_cap;
    zT_415 = wp_count;
    zF_25C377BD_growWpEdges(zT_411, zT_412, zT_413, zT_414, zT_415);
    zT_419 = (unsigned int)ti;
    zT_420 = (unsigned int)wp_count;
    wp_to[zT_420] = zT_419;
    zT_421 = (unsigned int)ft_id;
    zT_422 = wp_head[zT_421];
    zT_423 = (unsigned int)wp_count;
    wp_next[zT_423] = zT_422;
    zT_424 = (unsigned int)ft_id;
    wp_head[zT_424] = wp_count;
    zT_426 = wp_count + (unsigned int)(1);
    wp_count = zT_426;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_436 = self->registry;
    zT_437 = zT_436->array_items;
    zT_438 = ty.payload_idx;
    zT_439 = (unsigned int)zT_438;
    zT_440 = zT_437[zT_439];
    zT_441 = zT_440.elem;
    et = zT_441;
    zT_443 = self->registry;
    zT_444 = zT_443->types_items;
    zT_445 = (unsigned int)et;
    zT_446 = zT_444[zT_445];
    et_ty = zT_446;
    zT_447 = et_ty.kind;
    zT_449 = zF_A47239A9_fieldEmbedsByValue(zT_447);
    if (zT_449) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_493 = ty.kind;
    if ((int)(zT_493 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_450 = 0;
    is_po = zT_450;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_451 = et_ty.kind;
    if ((int)(zT_451 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_456 = perm_alloc;
    zT_457 = &wp_to;
    zT_458 = &wp_next;
    zT_459 = &wp_edge_cap;
    zT_460 = wp_count;
    zF_25C377BD_growWpEdges(zT_456, zT_457, zT_458, zT_459, zT_460);
    zT_464 = (unsigned int)ti;
    zT_465 = (unsigned int)wp_count;
    wp_to[zT_465] = zT_464;
    zT_466 = (unsigned int)et;
    zT_467 = wp_head[zT_466];
    zT_468 = (unsigned int)wp_count;
    wp_next[zT_468] = zT_467;
    zT_469 = (unsigned int)et;
    wp_head[zT_469] = wp_count;
    zT_471 = wp_count + (unsigned int)(1);
    wp_count = zT_471;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_472 = et_ty.kind;
    if ((int)(zT_472 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_477 = perm_alloc;
    zT_478 = &wp_to;
    zT_479 = &wp_next;
    zT_480 = &wp_edge_cap;
    zT_481 = wp_count;
    zF_25C377BD_growWpEdges(zT_477, zT_478, zT_479, zT_480, zT_481);
    zT_485 = (unsigned int)ti;
    zT_486 = (unsigned int)wp_count;
    wp_to[zT_486] = zT_485;
    zT_487 = (unsigned int)et;
    zT_488 = wp_head[zT_487];
    zT_489 = (unsigned int)wp_count;
    wp_next[zT_489] = zT_488;
    zT_490 = (unsigned int)et;
    wp_head[zT_490] = wp_count;
    zT_492 = wp_count + (unsigned int)(1);
    wp_count = zT_492;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_499 = self->registry;
    zT_500 = zT_499->eu_items;
    zT_501 = ty.payload_idx;
    zT_502 = (unsigned int)zT_501;
    zT_503 = zT_500[zT_502];
    zT_504 = zT_503.payload;
    eup = zT_504;
    zT_506 = self->registry;
    zT_507 = zT_506->types_items;
    zT_508 = (unsigned int)eup;
    zT_509 = zT_507[zT_508];
    eup_ty = zT_509;
    zT_510 = eup_ty.kind;
    zT_512 = zF_A47239A9_fieldEmbedsByValue(zT_510);
    if (zT_512) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_556 = ty.kind;
    if ((int)(zT_556 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_513 = 0;
    is_po = zT_513;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_514 = eup_ty.kind;
    if ((int)(zT_514 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_519 = perm_alloc;
    zT_520 = &wp_to;
    zT_521 = &wp_next;
    zT_522 = &wp_edge_cap;
    zT_523 = wp_count;
    zF_25C377BD_growWpEdges(zT_519, zT_520, zT_521, zT_522, zT_523);
    zT_527 = (unsigned int)ti;
    zT_528 = (unsigned int)wp_count;
    wp_to[zT_528] = zT_527;
    zT_529 = (unsigned int)eup;
    zT_530 = wp_head[zT_529];
    zT_531 = (unsigned int)wp_count;
    wp_next[zT_531] = zT_530;
    zT_532 = (unsigned int)eup;
    wp_head[zT_532] = wp_count;
    zT_534 = wp_count + (unsigned int)(1);
    wp_count = zT_534;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_535 = eup_ty.kind;
    if ((int)(zT_535 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_540 = perm_alloc;
    zT_541 = &wp_to;
    zT_542 = &wp_next;
    zT_543 = &wp_edge_cap;
    zT_544 = wp_count;
    zF_25C377BD_growWpEdges(zT_540, zT_541, zT_542, zT_543, zT_544);
    zT_548 = (unsigned int)ti;
    zT_549 = (unsigned int)wp_count;
    wp_to[zT_549] = zT_548;
    zT_550 = (unsigned int)eup;
    zT_551 = wp_head[zT_550];
    zT_552 = (unsigned int)wp_count;
    wp_next[zT_552] = zT_551;
    zT_553 = (unsigned int)eup;
    wp_head[zT_553] = wp_count;
    zT_555 = wp_count + (unsigned int)(1);
    wp_count = zT_555;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_562 = self->registry;
    zT_563 = zT_562->opt_items;
    zT_564 = ty.payload_idx;
    zT_565 = (unsigned int)zT_564;
    zT_566 = zT_563[zT_565];
    zT_567 = zT_566.payload;
    op_p = zT_567;
    zT_569 = self->registry;
    zT_570 = zT_569->types_items;
    zT_571 = (unsigned int)op_p;
    zT_572 = zT_570[zT_571];
    op_ty = zT_572;
    zT_573 = op_ty.kind;
    zT_575 = zF_EA3ED3F3_requiresFullDef(zT_573);
    if (zT_575) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_576 = 0;
    is_po = zT_576;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_577 = op_ty.kind;
    if ((int)(zT_577 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_582 = perm_alloc;
    zT_583 = &wp_to;
    zT_584 = &wp_next;
    zT_585 = &wp_edge_cap;
    zT_586 = wp_count;
    zF_25C377BD_growWpEdges(zT_582, zT_583, zT_584, zT_585, zT_586);
    zT_590 = (unsigned int)ti;
    zT_591 = (unsigned int)wp_count;
    wp_to[zT_591] = zT_590;
    zT_592 = (unsigned int)op_p;
    zT_593 = wp_head[zT_592];
    zT_594 = (unsigned int)wp_count;
    wp_next[zT_594] = zT_593;
    zT_595 = (unsigned int)op_p;
    wp_head[zT_595] = wp_count;
    zT_597 = wp_count + (unsigned int)(1);
    wp_count = zT_597;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_598 = op_ty.kind;
    if ((int)(zT_598 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_603 = perm_alloc;
    zT_604 = &wp_to;
    zT_605 = &wp_next;
    zT_606 = &wp_edge_cap;
    zT_607 = wp_count;
    zF_25C377BD_growWpEdges(zT_603, zT_604, zT_605, zT_606, zT_607);
    zT_611 = (unsigned int)ti;
    zT_612 = (unsigned int)wp_count;
    wp_to[zT_612] = zT_611;
    zT_613 = (unsigned int)op_p;
    zT_614 = wp_head[zT_613];
    zT_615 = (unsigned int)wp_count;
    wp_next[zT_615] = zT_614;
    zT_616 = (unsigned int)op_p;
    wp_head[zT_616] = wp_count;
    zT_618 = wp_count + (unsigned int)(1);
    wp_count = zT_618;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_621 = (unsigned int)ti;
    zT_622 = (unsigned int)wl_tail;
    worklist[zT_622] = zT_621;
    zT_624 = wl_tail + (unsigned int)(1);
    wl_tail = zT_624;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((int)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_630 = (unsigned int)wl_head;
    zT_631 = worklist[zT_630];
    cur = zT_631;
    zT_633 = wl_head + (unsigned int)(1);
    wl_head = zT_633;
    zT_635 = (unsigned int)cur;
    zT_636 = wp_head[zT_635];
    e = zT_636;
    goto z_bb_134;
    z_bb_132:
    zT_654 = perm_alloc;
    zT_657 = 4;
    zT_659 = 4;
    zT_661 = zF_1395EB68_sandAlloc(zT_654, (unsigned int)(zT_657 * tl), (unsigned int)((unsigned int)zT_659));
    zT_662 = zT_661.is_error;
    if (zT_662) goto z_bb_140; else goto z_bb_141;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((int)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_640 = (unsigned int)e;
    zT_641 = wp_to[zT_640];
    parent_tid = zT_641;
    zT_642 = (unsigned int)parent_tid;
    zT_643 = pointer_only[zT_642];
    if ((int)(zT_643 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_646 = 0;
    zT_647 = (unsigned int)parent_tid;
    pointer_only[zT_647] = zT_646;
    zT_648 = (unsigned int)wl_tail;
    worklist[zT_648] = parent_tid;
    zT_650 = wl_tail + (unsigned int)(1);
    wl_tail = zT_650;
    goto z_bb_139;
    z_bb_139:
    zT_651 = (unsigned int)e;
    zT_652 = wp_next[zT_651];
    e = zT_652;
    goto z_bb_137;
    z_bb_140:
    pal_trap();
    z_bb_141:
    zT_663 = zT_661.data.payload;
    goto z_bb_142;
    z_bb_142:
    ids_raw = zT_663;
    zT_666 = (unsigned int*)ids_raw;
    ids = zT_666;
    zT_668 = 0;
    plen = zT_668;
    zT_669 = 0;
    zT_670 = (unsigned int)zT_669;
    ti = zT_670;
    goto z_bb_143;
    z_bb_143:
    if ((int)(ti < tl)) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_672 = pointer_only[ti];
    if ((int)(zT_672 != (unsigned char)(0))) goto z_bb_147; else goto z_bb_148;
    z_bb_145:
    zT_683 = "CLS:c";
    zT_685 = 5;
    zT_684.ptr = zT_683;
    zT_684.len = zT_685;
    cls_m = zT_684;
    zT_686 = cls_m;
    zF_48AC7B3A_markerWrite(zT_686);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_688[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cls_b[_i] = zT_688[_i];
        _i++;
    }
}
    zT_690 = plen;
    zT_694 = 0;
    zT_695 = (unsigned char*)((unsigned char*)cls_b) + zT_694;
    zT_696 = (unsigned int)(10) - zT_694;
    zT_697.ptr = zT_695;
    zT_697.len = zT_696;
    zT_691 = zT_697;
    zT_698 = zF_A7504564_itoa(zT_690, zT_691);
    cls_l = zT_698;
    zT_702 = (unsigned int)(9) - (unsigned int)((unsigned int)cls_l);
    cls_s = zT_702;
    zT_707 = (unsigned char*)((unsigned char*)cls_b) + cls_s;
    zT_708 = (unsigned int)(9) - cls_s;
    zT_709.ptr = zT_707;
    zT_709.len = zT_708;
    zT_703 = zT_709;
    zF_48AC7B3A_markerWrite(zT_703);
    zT_711 = "\n";
    zT_713 = 1;
    zT_712.ptr = zT_711;
    zT_712.len = zT_713;
    cls_nl = zT_712;
    zT_714 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_714);
    zT_715 = 0;
    zT_716 = (unsigned int)zT_715;
    ti = zT_716;
    goto z_bb_149;
    z_bb_146:
    zT_679 = 1;
    zT_681 = ti + (unsigned int)((unsigned int)zT_679);
    ti = zT_681;
    goto z_bb_143;
    z_bb_147:
    zT_675 = (unsigned int)ti;
    zT_676 = (unsigned int)plen;
    ids[zT_676] = zT_675;
    zT_678 = plen + (unsigned int)(1);
    plen = zT_678;
    goto z_bb_148;
    z_bb_148:
    goto z_bb_146;
    z_bb_149:
    if ((int)(ti < tl)) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_718 = pointer_only[ti];
    if ((int)(zT_718 != (unsigned char)(0))) goto z_bb_153; else goto z_bb_155;
    z_bb_151:
    zT_796.ids = ids;
    zT_796.len = plen;
    return zT_796;
    z_bb_152:
    zT_793 = 1;
    zT_795 = ti + (unsigned int)((unsigned int)zT_793);
    ti = zT_795;
    goto z_bb_149;
    z_bb_153:
    zT_722 = "CLS:p";
    zT_724 = 5;
    zT_723.ptr = zT_722;
    zT_723.len = zT_724;
    pfx = zT_723;
    zT_725 = pfx;
    zF_48AC7B3A_markerWrite(zT_725);
    goto z_bb_154;
    z_bb_154:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_732[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ctb[_i] = zT_732[_i];
        _i++;
    }
}
    zT_739 = 0;
    zT_740 = (unsigned char*)((unsigned char*)ctb) + zT_739;
    zT_741 = (unsigned int)(10) - zT_739;
    zT_742.ptr = zT_740;
    zT_742.len = zT_741;
    zT_735 = zT_742;
    zT_743 = zF_A7504564_itoa((unsigned int)((unsigned int)ti), zT_735);
    ctl = zT_743;
    zT_747 = (unsigned int)(9) - (unsigned int)((unsigned int)ctl);
    cts = zT_747;
    zT_752 = (unsigned char*)((unsigned char*)ctb) + cts;
    zT_753 = (unsigned int)(9) - cts;
    zT_754.ptr = zT_752;
    zT_754.len = zT_753;
    zT_748 = zT_754;
    zF_48AC7B3A_markerWrite(zT_748);
    zT_756 = "k";
    zT_758 = 1;
    zT_757.ptr = zT_756;
    zT_757.len = zT_758;
    ck = zT_757;
    zT_759 = ck;
    zF_48AC7B3A_markerWrite(zT_759);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_761[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ckb[_i] = zT_761[_i];
        _i++;
    }
}
    zT_765 = self->registry;
    zT_766 = zT_765->types_items;
    zT_767 = zT_766[ti];
    zT_768 = zT_767.kind;
    zT_772 = 0;
    zT_773 = (unsigned char*)((unsigned char*)ckb) + zT_772;
    zT_774 = (unsigned int)(10) - zT_772;
    zT_775.ptr = zT_773;
    zT_775.len = zT_774;
    zT_764 = zT_775;
    zT_776 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_768), zT_764);
    ckl = zT_776;
    zT_780 = (unsigned int)(9) - (unsigned int)((unsigned int)ckl);
    cks = zT_780;
    zT_785 = (unsigned char*)((unsigned char*)ckb) + cks;
    zT_786 = (unsigned int)(9) - cks;
    zT_787.ptr = zT_785;
    zT_787.len = zT_786;
    zT_781 = zT_787;
    zF_48AC7B3A_markerWrite(zT_781);
    zT_789 = "\n";
    zT_791 = 1;
    zT_790.ptr = zT_789;
    zT_790.len = zT_791;
    cnl = zT_790;
    zT_792 = cnl;
    zF_48AC7B3A_markerWrite(zT_792);
    goto z_bb_152;
    z_bb_155:
    zT_727 = "CLS:v";
    zT_729 = 5;
    zT_728.ptr = zT_727;
    zT_728.len = zT_729;
    pfx = zT_728;
    zT_730 = pfx;
    zF_48AC7B3A_markerWrite(zT_730);
    goto z_bb_154;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_14;
    int zT_17;
    int zT_19;
    zT_C6536882_EU_532 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_3E40CD83_Sand* zT_26;
    int zT_29;
    int zT_31;
    zT_C6536882_EU_532 zT_33 = {0};
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned int* zT_38;
    unsigned int* zT_40;
    int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* new_to_raw;
    unsigned char* new_nx_raw;
    unsigned int* new_to;
    unsigned int* new_nx;
    unsigned int ci;
    zT_6 = *cap_ptr;
    if ((int)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap_ptr;
    old_cap = zT_9;
    zT_11 = 2;
    zT_12 = old_cap * zT_11;
    new_cap = zT_12;
    zT_14 = perm_a;
    zT_17 = 4;
    zT_19 = 4;
    zT_21 = zF_1395EB68_sandAlloc(zT_14, (unsigned int)(zT_17 * new_cap), (unsigned int)((unsigned int)zT_19));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_23 = zT_21.data.payload;
    goto z_bb_5;
    z_bb_5:
    new_to_raw = zT_23;
    zT_26 = perm_a;
    zT_29 = 4;
    zT_31 = 4;
    zT_33 = zF_1395EB68_sandAlloc(zT_26, (unsigned int)(zT_29 * new_cap), (unsigned int)((unsigned int)zT_31));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    new_nx_raw = zT_35;
    zT_38 = (unsigned int*)new_to_raw;
    new_to = zT_38;
    zT_40 = (unsigned int*)new_nx_raw;
    new_nx = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_9;
    z_bb_9:
    if ((int)(ci < (unsigned int)((unsigned int)count))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *wp_to_ptr;
    zT_47 = zT_46[ci];
    new_to[ci] = zT_47;
    zT_48 = *wp_next_ptr;
    zT_49 = zT_48[ci];
    new_nx[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *wp_to_ptr = new_to;
    *wp_next_ptr = new_nx;
    *cap_ptr = new_cap;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_52 = ci + (unsigned int)((unsigned int)zT_50);
    ci = zT_52;
    goto z_bb_9;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstModuleOfExpr */
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_3D7259E2_SymbolRegistry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_D4761958_Opt_858 zT_28 = {0};
    unsigned char zT_29;
    zT_3C598AEF_SymbolKind zT_31;
    unsigned int zT_36;
    unsigned int zT_37;
    int zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_43;
    unsigned int zT_44;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D155D06D_Type* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_D155D06D_Type zT_51;
    zT_33EF6BFB_TypeKind zT_52;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_60;
    zT_3D7259E2_SymbolRegistry* zT_61;
    unsigned int zT_62;
    zT_3D7259E2_SymbolRegistry* zT_66;
    unsigned int zT_68;
    zT_D4761958_Opt_858 zT_71 = {0};
    unsigned char zT_72;
    zT_3C598AEF_SymbolKind zT_74;
    unsigned int zT_79;
    unsigned int zT_80;
    int zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_90;
    zT_D155D06D_Type* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_D155D06D_Type zT_94;
    zT_33EF6BFB_TypeKind zT_95;
    unsigned int zT_100;
    int zT_101;
    unsigned int zT_103;
    zT_8143F551_AstKind zT_105;
    zT_ABC1EBBE_TypeResolveEnv* zT_111;
    unsigned int zT_112;
    unsigned int zT_114 = 0;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    unsigned int zT_122 = 0;
    zT_3D7259E2_SymbolRegistry* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_D4761958_Opt_858 zT_127 = {0};
    unsigned char zT_128;
    zT_3C598AEF_SymbolKind zT_130;
    unsigned int zT_135;
    unsigned int zT_136;
    int zT_139;
    unsigned int zT_140;
    zT_338B7C76_TypeRegistry* zT_142;
    unsigned int zT_143;
    zT_338B7C76_TypeRegistry* zT_146;
    zT_D155D06D_Type* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_D155D06D_Type zT_150;
    zT_33EF6BFB_TypeKind zT_151;
    unsigned int zT_156;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    zT_D4761958_Opt_858 sym;
    zT_3A105EF1_Symbol* s2;
    zT_D155D06D_Type sty2;
    unsigned int base_mod;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* msym;
    zT_D155D06D_Type mty;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = env->store;
    zT_17 = node_idx;
    zT_19 = zF_53458827_astStoreIdentifier(zT_16, zT_17);
    name_id = zT_19;
    zT_20 = env->module_id;
    if ((int)(zT_20 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_105 = node.kind;
    if ((int)(zT_105 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_23 = env->symbol_reg;
    zT_24 = env->module_id;
    zT_25 = name_id;
    zT_28 = zF_A398987E_symbolRegistryQuali(zT_23, zT_24, zT_25);
    zT_29 = zT_28.has_value;
    if (zT_29) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_59 = 0;
    zT_60 = (unsigned int)zT_59;
    si = zT_60;
    goto z_bb_18;
    z_bb_7:
    s = zT_28.value;
    zT_31 = s->kind;
    if ((int)(zT_31 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_36 = s->module_id;
    return zT_36;
    z_bb_10:
    zT_37 = s->type_id;
    if ((int)(zT_37 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = s->type_id;
    zT_43 = env->typereg;
    zT_44 = zT_43->types_len;
    zT_40 = (unsigned int)((unsigned int)zT_41) < zT_44;
    goto z_bb_13;
    z_bb_12:
    zT_40 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_40) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_47 = env->typereg;
    zT_48 = zT_47->types_items;
    zT_49 = s->type_id;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    sty = zT_51;
    zT_52 = sty.kind;
    if ((int)(zT_52 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_57 = sty.module_id;
    return zT_57;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_61 = env->symbol_reg;
    zT_62 = zT_61->tables_len;
    if ((int)(si < (unsigned int)((unsigned int)zT_62))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_66 = env->symbol_reg;
    zT_68 = name_id;
    zT_71 = zF_A398987E_symbolRegistryQuali(zT_66, (unsigned int)((unsigned int)si), zT_68);
    sym = zT_71;
    zT_72 = sym.has_value;
    if (zT_72) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    zT_101 = 1;
    zT_103 = si + (unsigned int)((unsigned int)zT_101);
    si = zT_103;
    goto z_bb_18;
    z_bb_22:
    s2 = sym.value;
    zT_74 = s2->kind;
    if ((int)(zT_74 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_79 = s2->module_id;
    return zT_79;
    z_bb_25:
    zT_80 = s2->type_id;
    if ((int)(zT_80 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_84 = s2->type_id;
    zT_86 = env->typereg;
    zT_87 = zT_86->types_len;
    zT_83 = (unsigned int)((unsigned int)zT_84) < zT_87;
    goto z_bb_28;
    z_bb_27:
    zT_83 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_83) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_90 = env->typereg;
    zT_91 = zT_90->types_items;
    zT_92 = s2->type_id;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    sty2 = zT_94;
    zT_95 = sty2.kind;
    if ((int)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_23;
    z_bb_31:
    zT_100 = sty2.module_id;
    return zT_100;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_111 = env;
    zT_112 = node.child_0;
    zT_114 = zF_0E4084E4_evalConstModuleOfEx(zT_111, zT_112);
    base_mod = zT_114;
    if ((int)(base_mod == (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    return (unsigned int)(0);
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_119 = env->store;
    zT_120 = node_idx;
    zT_122 = zF_8BA26B9E_astStoreNodePayload(zT_119, zT_120);
    field_name_id = zT_122;
    zT_123 = env->symbol_reg;
    zT_124 = base_mod;
    zT_125 = field_name_id;
    zT_127 = zF_A398987E_symbolRegistryQuali(zT_123, zT_124, zT_125);
    zT_128 = zT_127.has_value;
    if (zT_128) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    msym = zT_127.value;
    zT_130 = msym->kind;
    if ((int)(zT_130 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    return (unsigned int)(0);
    z_bb_39:
    zT_135 = msym->module_id;
    return zT_135;
    z_bb_40:
    zT_136 = msym->type_id;
    if ((int)(zT_136 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_140 = msym->type_id;
    zT_142 = env->typereg;
    zT_143 = zT_142->types_len;
    zT_139 = (unsigned int)((unsigned int)zT_140) < zT_143;
    goto z_bb_43;
    z_bb_42:
    zT_139 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_139) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_146 = env->typereg;
    zT_147 = zT_146->types_items;
    zT_148 = msym->type_id;
    zT_149 = (unsigned int)zT_148;
    zT_150 = zT_147[zT_149];
    mty = zT_150;
    zT_151 = mty.kind;
    if ((int)(zT_151 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_38;
    z_bb_46:
    zT_156 = mty.module_id;
    return zT_156;
    z_bb_47:
    goto z_bb_45;
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_22 = 0;
    zT_8143F551_AstKind zT_24;
    int zT_29;
    zT_8143F551_AstKind zT_30;
    int zT_35;
    zT_8143F551_AstKind zT_36;
    int zT_41;
    zT_8143F551_AstKind zT_42;
    int zT_47;
    zT_8143F551_AstKind zT_48;
    zT_ABC1EBBE_TypeResolveEnv* zT_54;
    unsigned int zT_55;
    unsigned int zT_60 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_62;
    unsigned int zT_63;
    unsigned int zT_68 = 0;
    int zT_71;
    zT_8143F551_AstKind zT_74;
    zT_8143F551_AstKind zT_80;
    zT_8143F551_AstKind zT_86;
    zT_8143F551_AstKind zT_92;
    zT_8143F551_AstKind zT_105;
    unsigned int zT_110;
    zT_ABC1EBBE_TypeResolveEnv* zT_114;
    unsigned int zT_115;
    unsigned int zT_120 = 0;
    zT_8143F551_AstKind zT_126;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    unsigned int zT_135 = 0;
    zT_F6B96876_Opt_395 zT_136;
    unsigned char zT_137;
    zT_E2DF2801_LocalConstScope* zT_139;
    unsigned int zT_140;
    zT_BAEE192E_Opt_10 zT_141 = {0};
    unsigned char zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_22A7C88B_AstNode zT_148 = {0};
    unsigned int zT_149;
    int zT_150;
    zT_ABC1EBBE_TypeResolveEnv* zT_152;
    unsigned int zT_155;
    unsigned int zT_157;
    zT_ABC1EBBE_TypeResolveEnv* zT_160;
    unsigned int zT_161;
    zT_D4761958_Opt_858 zT_162 = {0};
    unsigned char zT_163;
    unsigned short zT_165;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_172;
    zT_22A7C88B_AstNode zT_175 = {0};
    unsigned int zT_176;
    int zT_177;
    zT_ABC1EBBE_TypeResolveEnv* zT_179;
    unsigned int zT_182;
    unsigned int zT_184;
    zT_8143F551_AstKind zT_186;
    zT_ABC1EBBE_TypeResolveEnv* zT_192;
    unsigned int zT_193;
    unsigned int zT_195 = 0;
    zT_6B0A7D14_AstStore* zT_199;
    unsigned int zT_200;
    unsigned int zT_202 = 0;
    zT_3D7259E2_SymbolRegistry* zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    zT_D4761958_Opt_858 zT_207 = {0};
    unsigned char zT_208;
    unsigned short zT_210;
    zT_6B0A7D14_AstStore* zT_216;
    unsigned int zT_217;
    zT_22A7C88B_AstNode zT_220 = {0};
    unsigned int zT_221;
    int zT_222;
    zT_ABC1EBBE_TypeResolveEnv* zT_224;
    unsigned int zT_227;
    unsigned int zT_229;
    zT_22A7C88B_AstNode node;
    unsigned int bl;
    unsigned int br;
    unsigned int nv;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    zT_D4761958_Opt_858 c_sym;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int fa_mod_id;
    unsigned int fa_field_id;
    zT_3A105EF1_Symbol* fa_sym;
    zT_22A7C88B_AstNode fa_decl;
    z_bb_0:
    if ((int)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((int)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = env->store;
    zT_20 = node_idx;
    zT_22 = zF_678B9A72_astStoreIntValue(zT_19, zT_20);
    return (unsigned int)((unsigned int)zT_22);
    z_bb_6:
    zT_24 = node.kind;
    if ((int)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_30 = node.kind;
    zT_29 = zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_9;
    z_bb_8:
    zT_29 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_29) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_36 = node.kind;
    zT_35 = zT_36 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_12;
    z_bb_11:
    zT_35 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_35) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_42 = node.kind;
    zT_41 = zT_42 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_15;
    z_bb_14:
    zT_41 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_41) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_48 = node.kind;
    zT_47 = zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_18;
    z_bb_17:
    zT_47 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_47) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_54 = env;
    zT_55 = node.child_0;
    zT_60 = zF_6D0DD27D_evalConstU32Full(zT_54, zT_55, (unsigned int)(depth + (unsigned int)(1)));
    bl = zT_60;
    zT_62 = env;
    zT_63 = node.child_1;
    zT_68 = zF_6D0DD27D_evalConstU32Full(zT_62, zT_63, (unsigned int)(depth + (unsigned int)(1)));
    br = zT_68;
    if ((int)(bl != (unsigned int)(4294967295u))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_105 = node.kind;
    if ((int)(zT_105 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_38; else goto z_bb_39;
    z_bb_21:
    zT_71 = br != (unsigned int)(4294967295u);
    goto z_bb_23;
    z_bb_22:
    zT_71 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_71) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_74 = node.kind;
    if ((int)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    return (unsigned int)(4294967295u);
    z_bb_26:
    return (unsigned int)(bl + br);
    z_bb_27:
    zT_80 = node.kind;
    if ((int)(zT_80 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(bl - br);
    z_bb_29:
    zT_86 = node.kind;
    if ((int)(zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    return (unsigned int)(bl * br);
    z_bb_31:
    zT_92 = node.kind;
    if ((int)(zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    if ((int)(br != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    if ((int)(br != (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    return (unsigned int)(bl / br);
    z_bb_35:
    return (unsigned int)(4294967295u);
    z_bb_36:
    return (unsigned int)(bl % br);
    z_bb_37:
    goto z_bb_25;
    z_bb_38:
    zT_110 = node.child_0;
    if ((int)(zT_110 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_126 = node.kind;
    if ((int)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_44; else goto z_bb_45;
    z_bb_40:
    zT_114 = env;
    zT_115 = node.child_0;
    zT_120 = zF_6D0DD27D_evalConstU32Full(zT_114, zT_115, (unsigned int)(depth + (unsigned int)(1)));
    nv = zT_120;
    if ((int)(nv != (unsigned int)(4294967295u))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    return (unsigned int)(4294967295u);
    z_bb_42:
    return (unsigned int)((unsigned int)(0) - nv);
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_132 = env->store;
    zT_133 = node_idx;
    zT_135 = zF_53458827_astStoreIdentifier(zT_132, zT_133);
    name_id = zT_135;
    zT_136 = env->local_consts;
    zT_137 = zT_136.has_value;
    if (zT_137) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_186 = node.kind;
    if ((int)(zT_186 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_58; else goto z_bb_59;
    z_bb_46:
    lcs = zT_136.value;
    zT_139 = lcs;
    zT_140 = name_id;
    zT_141 = zF_6532C387_localConstScopeLook(zT_139, zT_140);
    zT_142 = zT_141.has_value;
    if (zT_142) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_160 = env;
    zT_161 = name_id;
    zT_162 = zF_04FED007_symbolLookupAllModu(zT_160, zT_161);
    c_sym = zT_162;
    zT_163 = c_sym.has_value;
    if (zT_163) goto z_bb_52; else goto z_bb_53;
    z_bb_48:
    l_decl_node = zT_141.value;
    zT_145 = env->store;
    zT_146 = l_decl_node;
    zT_148 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    l_decl = zT_148;
    zT_149 = l_decl.child_1;
    zT_150 = 0;
    if ((int)(zT_149 != (unsigned int)zT_150)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_152 = env;
    zT_155 = l_decl.child_1;
    zT_157 = depth + (unsigned int)(1);
    env = zT_152;
    node_idx = zT_155;
    depth = zT_157;
    goto z_bb_0;
    z_bb_51:
    goto z_bb_49;
    z_bb_52:
    cs = c_sym.value;
    zT_165 = cs->flags;
    if ((int)((unsigned short)(zT_165 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    goto z_bb_45;
    z_bb_54:
    zT_171 = env->store;
    zT_172 = cs->decl_node;
    zT_175 = zF_FCDD1D35_astStoreNodeAt(zT_171, zT_172);
    c_decl = zT_175;
    zT_176 = c_decl.child_1;
    zT_177 = 0;
    if ((int)(zT_176 != (unsigned int)zT_177)) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_179 = env;
    zT_182 = c_decl.child_1;
    zT_184 = depth + (unsigned int)(1);
    env = zT_179;
    node_idx = zT_182;
    depth = zT_184;
    goto z_bb_0;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_192 = env;
    zT_193 = node.child_0;
    zT_195 = zF_0E4084E4_evalConstModuleOfEx(zT_192, zT_193);
    fa_mod_id = zT_195;
    if ((int)(fa_mod_id != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    return (unsigned int)(4294967295u);
    z_bb_60:
    zT_199 = env->store;
    zT_200 = node_idx;
    zT_202 = zF_8BA26B9E_astStoreNodePayload(zT_199, zT_200);
    fa_field_id = zT_202;
    zT_203 = env->symbol_reg;
    zT_204 = fa_mod_id;
    zT_205 = fa_field_id;
    zT_207 = zF_A398987E_symbolRegistryQuali(zT_203, zT_204, zT_205);
    zT_208 = zT_207.has_value;
    if (zT_208) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    fa_sym = zT_207.value;
    zT_210 = fa_sym->flags;
    if ((int)((unsigned short)(zT_210 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    goto z_bb_61;
    z_bb_64:
    zT_216 = env->store;
    zT_217 = fa_sym->decl_node;
    zT_220 = zF_FCDD1D35_astStoreNodeAt(zT_216, zT_217);
    fa_decl = zT_220;
    zT_221 = fa_decl.child_1;
    zT_222 = 0;
    if ((int)(zT_221 != (unsigned int)zT_222)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_224 = env;
    zT_227 = fa_decl.child_1;
    zT_229 = depth + (unsigned int)(1);
    env = zT_224;
    node_idx = zT_227;
    depth = zT_229;
    goto z_bb_0;
    z_bb_67:
    goto z_bb_65;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_44E16D78_Opt_7 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_18 = 0;
    zT_C69B2266_i64 zT_19;
    zT_44E16D78_Opt_7 zT_20;
    zT_8143F551_AstKind zT_21;
    unsigned int zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_30;
    unsigned int zT_31;
    zT_44E16D78_Opt_7 zT_33 = {0};
    unsigned char zT_34;
    zT_79FAE712_u64 zT_37;
    zT_79FAE712_u64 zT_40;
    zT_C69B2266_i64 zT_41;
    zT_44E16D78_Opt_7 zT_42;
    zT_44E16D78_Opt_7 zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_55;
    unsigned int zT_56;
    zT_D4761958_Opt_858 zT_57 = {0};
    unsigned char zT_58;
    unsigned short zT_60;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_70 = {0};
    unsigned int zT_71;
    int zT_72;
    zT_ABC1EBBE_TypeResolveEnv* zT_74;
    unsigned int zT_76;
    zT_44E16D78_Opt_7 zT_78 = {0};
    zT_22A7C88B_AstNode node;
    zT_44E16D78_Opt_7 nv_opt;
    zT_C69B2266_i64 nv;
    zT_79FAE712_u64 as_u;
    zT_79FAE712_u64 neg_u;
    unsigned int name_id;
    zT_D4761958_Opt_858 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_678B9A72_astStoreIntValue(zT_15, zT_16);
    zT_19 = (zT_C69B2266_i64)zT_18;
    zT_20.has_value = 1;
    zT_20.value = zT_19;
    return zT_20;
    z_bb_4:
    zT_21 = node.kind;
    if ((int)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = node.child_0;
    if ((int)(zT_26 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_44 = node.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_7:
    zT_30 = env;
    zT_31 = node.child_0;
    zT_33 = zF_FFFAAD16_evalConstI64Full(zT_30, zT_31);
    nv_opt = zT_33;
    zT_34 = nv_opt.has_value;
    if (zT_34) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_43.has_value = 0;
    return zT_43;
    z_bb_9:
    nv = nv_opt.value;
    zT_37 = (zT_79FAE712_u64)nv;
    as_u = zT_37;
    zT_40 = (zT_79FAE712_u64)(0) - as_u;
    neg_u = zT_40;
    zT_41 = (zT_C69B2266_i64)neg_u;
    zT_42.has_value = 1;
    zT_42.value = zT_41;
    return zT_42;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_50 = env->store;
    zT_51 = node_idx;
    zT_53 = zF_53458827_astStoreIdentifier(zT_50, zT_51);
    name_id = zT_53;
    zT_55 = env;
    zT_56 = name_id;
    zT_57 = zF_04FED007_symbolLookupAllModu(zT_55, zT_56);
    c_sym = zT_57;
    zT_58 = c_sym.has_value;
    if (zT_58) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_78.has_value = 0;
    return zT_78;
    z_bb_13:
    cs = c_sym.value;
    zT_60 = cs->flags;
    if ((int)((unsigned short)(zT_60 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_66 = env->store;
    zT_67 = cs->decl_node;
    zT_70 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    c_decl = zT_70;
    zT_71 = c_decl.child_1;
    zT_72 = 0;
    if ((int)(zT_71 != (unsigned int)zT_72)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_74 = env;
    zT_76 = c_decl.child_1;
    env = zT_74;
    node_idx = zT_76;
    goto z_bb_0;
    z_bb_18:
    goto z_bb_16;
}

/* symbolLookupAllModules */
zT_D4761958_Opt_858 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_D4761958_Opt_858 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_19;
    zT_D4761958_Opt_858 zT_20 = {0};
    unsigned int si;
    zT_D4761958_Opt_858 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((int)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_79FAE712_u64 zT_63;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_BAEE192E_Opt_10 zT_73 = {0};
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_90;
    unsigned int zT_91;
    zT_79FAE712_u64 zT_99;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_79FAE712_u64 zT_102;
    zT_BAEE192E_Opt_10 zT_104 = {0};
    unsigned char zT_105;
    int zT_107;
    unsigned int zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_D4761958_Opt_858 zT_124 = {0};
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_130;
    int zT_132;
    unsigned int zT_133;
    zT_3D7259E2_SymbolRegistry* zT_134;
    unsigned int zT_135;
    zT_3D7259E2_SymbolRegistry* zT_139;
    unsigned int zT_141;
    zT_D4761958_Opt_858 zT_144 = {0};
    unsigned char zT_145;
    unsigned int zT_147;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    int zT_158;
    unsigned int zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int* zT_171;
    unsigned int zT_173 = 0;
    zT_338B7C76_TypeRegistry* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_179 = 0;
    zT_8143F551_AstKind zT_181;
    zT_5826BFC7_Arr_unsigned_char_1 zT_187;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    int zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197 = 0;
    unsigned int zT_201;
    zT_4428DEE2_Arr_unsigned_char_2 zT_203;
    unsigned char zT_204;
    int zT_205;
    unsigned char zT_206;
    int zT_207;
    unsigned char zT_208;
    int zT_209;
    unsigned char zT_210;
    int zT_211;
    unsigned char zT_212;
    int zT_213;
    int zT_215;
    unsigned int zT_216;
    unsigned int zT_219;
    unsigned char zT_220;
    unsigned int zT_222;
    int zT_223;
    unsigned int zT_225;
    unsigned int zT_229;
    zT_D3EB6303_StringInterner* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    int zT_236;
    unsigned char* zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240 = 0;
    zT_338B7C76_TypeRegistry* zT_242;
    zT_BAEE192E_Opt_10 zT_246 = {0};
    unsigned char zT_247;
    zT_338B7C76_TypeRegistry* zT_250;
    unsigned int zT_252;
    unsigned int zT_259 = 0;
    unsigned char zT_260;
    zT_338B7C76_TypeRegistry* zT_265;
    unsigned int zT_266;
    zT_6B0A7D14_AstStore* zT_268;
    unsigned int zT_269;
    unsigned int zT_271 = 0;
    zT_6B0A7D14_AstStore* zT_275;
    unsigned int zT_276;
    unsigned int zT_278 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_280;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_282;
    int zT_284;
    unsigned int zT_285;
    int zT_287;
    unsigned int zT_288;
    int zT_291;
    zT_6B0A7D14_AstStore* zT_295;
    unsigned int zT_296;
    unsigned int zT_300 = 0;
    zT_6B0A7D14_AstStore* zT_302;
    unsigned int zT_303;
    zT_22A7C88B_AstNode zT_305 = {0};
    zT_8143F551_AstKind zT_306;
    zT_ABC1EBBE_TypeResolveEnv* zT_312;
    unsigned int zT_313;
    unsigned int zT_318 = 0;
    zT_6B0A7D14_AstStore* zT_319;
    unsigned int zT_320;
    unsigned int zT_322 = 0;
    int zT_323;
    unsigned int zT_325;
    int zT_326;
    unsigned int zT_328;
    zT_338B7C76_TypeRegistry* zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    int zT_336;
    unsigned int zT_337;
    zT_338B7C76_TypeRegistry* zT_339;
    zT_2DF01B61_FieldEntry zT_340;
    zT_2DF01B61_FieldEntry zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    int zT_346;
    unsigned int zT_348;
    zT_338B7C76_TypeRegistry* zT_349;
    zT_406493CE_StructPayload zT_350;
    zT_406493CE_StructPayload zT_352;
    unsigned int zT_353;
    unsigned short zT_354;
    zT_338B7C76_TypeRegistry* zT_356;
    unsigned int zT_357;
    unsigned int zT_360;
    zT_338B7C76_TypeRegistry* zT_362;
    zT_D155D06D_Type* zT_363;
    unsigned int zT_364;
    zT_D155D06D_Type zT_365;
    zT_338B7C76_TypeRegistry* zT_366;
    zT_D155D06D_Type* zT_367;
    unsigned int zT_368;
    zT_8143F551_AstKind zT_369;
    unsigned char zT_375;
    zT_ABC1EBBE_TypeResolveEnv* zT_377;
    unsigned int zT_378;
    unsigned int zT_383 = 0;
    zT_6B0A7D14_AstStore* zT_387;
    unsigned int zT_388;
    zT_22A7C88B_AstNode zT_391 = {0};
    zT_8143F551_AstKind zT_392;
    zT_6B0A7D14_AstStore* zT_398;
    unsigned int zT_399;
    unsigned int zT_402 = 0;
    int zT_404;
    unsigned int zT_405;
    zT_3D7259E2_SymbolRegistry* zT_406;
    unsigned int zT_407;
    zT_3D7259E2_SymbolRegistry* zT_411;
    unsigned int zT_413;
    zT_D4761958_Opt_858 zT_416 = {0};
    unsigned char zT_417;
    zT_3C598AEF_SymbolKind zT_419;
    unsigned int zT_425;
    zT_3D7259E2_SymbolRegistry* zT_427;
    unsigned int zT_428;
    unsigned int zT_429;
    zT_6B0A7D14_AstStore* zT_431;
    unsigned int zT_432;
    unsigned int zT_434 = 0;
    zT_D4761958_Opt_858 zT_435 = {0};
    unsigned char zT_436;
    unsigned int zT_438;
    unsigned char zT_441;
    unsigned char* zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    unsigned int zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    unsigned int zT_449;
    int zT_450;
    unsigned int zT_452;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457;
    unsigned int zT_458;
    zT_338B7C76_TypeRegistry* zT_462;
    zT_D155D06D_Type* zT_463;
    unsigned int zT_464;
    zT_D155D06D_Type zT_465;
    zT_33EF6BFB_TypeKind zT_466;
    unsigned int zT_472;
    zT_3D7259E2_SymbolRegistry* zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_6B0A7D14_AstStore* zT_478;
    unsigned int zT_479;
    unsigned int zT_481 = 0;
    zT_D4761958_Opt_858 zT_482 = {0};
    unsigned char zT_483;
    unsigned int zT_485;
    unsigned char zT_488;
    unsigned char* zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned int zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned int zT_494;
    unsigned int zT_496;
    unsigned char* zT_500;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_501;
    unsigned int zT_502;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_503;
    unsigned int zT_504;
    zT_8143F551_AstKind zT_505;
    zT_939EE900_Arr_unsigned_int_1 zT_511;
    zT_338B7C76_TypeRegistry* zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    zT_EDD37787_Arr_unsigned_short_ zT_517;
    unsigned short zT_518;
    unsigned int zT_519;
    zT_6B0A7D14_AstStore* zT_520;
    unsigned int zT_521;
    unsigned int zT_523 = 0;
    zT_6B0A7D14_AstStore* zT_527;
    unsigned int zT_528;
    unsigned int zT_530 = 0;
    unsigned short zT_531;
    int zT_532;
    int zT_534;
    unsigned int zT_535;
    zT_338B7C76_TypeRegistry* zT_538;
    unsigned int zT_539;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    unsigned int zT_546 = 0;
    int zT_547;
    unsigned int zT_549;
    zT_338B7C76_TypeRegistry* zT_550;
    unsigned int zT_551;
    unsigned short zT_552;
    int zT_554;
    int zT_556;
    unsigned int zT_558 = 0;
    zT_8143F551_AstKind zT_559;
    zT_ABC1EBBE_TypeResolveEnv* zT_565;
    unsigned int zT_566;
    unsigned int zT_571 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_576;
    unsigned int zT_577;
    unsigned int zT_578;
    unsigned int zT_579;
    int zT_580;
    zT_ABC1EBBE_TypeResolveEnv* zT_583;
    unsigned int zT_584;
    unsigned int zT_589 = 0;
    int zT_593;
    unsigned int zT_594;
    int zT_595;
    zT_338B7C76_TypeRegistry* zT_596;
    unsigned int zT_597;
    unsigned int zT_598;
    int zT_600;
    unsigned int zT_602 = 0;
    zT_8143F551_AstKind zT_603;
    zT_939EE900_Arr_unsigned_int_1 zT_609;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_612;
    int zT_613;
    unsigned int zT_614;
    int zT_615;
    zT_ABC1EBBE_TypeResolveEnv* zT_617;
    unsigned int zT_618;
    unsigned int zT_623 = 0;
    int zT_624;
    unsigned char* zT_626;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_627;
    unsigned int zT_628;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_629;
    unsigned int zT_630;
    int zT_631;
    int zT_633;
    unsigned int zT_634;
    zT_99292002_Arr_unsigned_int_16 zT_639;
    unsigned int zT_641;
    zT_6B0A7D14_AstStore* zT_642;
    unsigned int zT_643;
    unsigned int zT_645 = 0;
    zT_6B0A7D14_AstStore* zT_649;
    unsigned int zT_650;
    unsigned int zT_652 = 0;
    unsigned int zT_654;
    int zT_657;
    zT_ABC1EBBE_TypeResolveEnv* zT_661;
    unsigned int zT_662;
    zT_6B0A7D14_AstStore* zT_664;
    unsigned int zT_665;
    unsigned int zT_669 = 0;
    unsigned int zT_672 = 0;
    unsigned int zT_677;
    unsigned int zT_679;
    unsigned char zT_681;
    unsigned char zT_682;
    unsigned char zT_687;
    zT_443A2803_Arr_unsigned_char_9 zT_689;
    unsigned int zT_691;
    unsigned char* zT_693;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_694;
    unsigned int zT_695;
    unsigned char* zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    unsigned int zT_700;
    unsigned int zT_702;
    unsigned int zT_704;
    int zT_706;
    unsigned char* zT_709;
    unsigned char zT_710;
    unsigned int zT_712;
    unsigned int zT_714;
    zT_5826BFC7_Arr_unsigned_char_1 zT_716;
    unsigned int zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    int zT_720;
    int zT_724;
    unsigned char* zT_725;
    unsigned int zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_728 = 0;
    unsigned int zT_732;
    int zT_735;
    unsigned char zT_738;
    unsigned int zT_740;
    unsigned int zT_742;
    unsigned int zT_744;
    int zT_746;
    unsigned char zT_751;
    unsigned int zT_753;
    zT_5826BFC7_Arr_unsigned_char_1 zT_755;
    unsigned int zT_757;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_758;
    int zT_762;
    unsigned char* zT_763;
    unsigned int zT_764;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_765;
    unsigned int zT_766 = 0;
    unsigned int zT_770;
    int zT_773;
    unsigned char zT_776;
    unsigned int zT_778;
    unsigned int zT_780;
    unsigned int zT_782;
    zT_D3EB6303_StringInterner* zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    int zT_789;
    unsigned char* zT_790;
    unsigned int zT_791;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_792;
    unsigned int zT_793 = 0;
    zT_338B7C76_TypeRegistry* zT_795;
    unsigned int zT_796;
    unsigned int zT_797;
    unsigned int zT_799;
    zT_338B7C76_TypeRegistry* zT_801;
    unsigned int zT_802;
    unsigned int zT_806;
    zT_338B7C76_TypeRegistry* zT_808;
    unsigned int zT_809;
    unsigned int zT_815;
    unsigned char zT_816;
    int zT_823;
    unsigned int zT_825 = 0;
    unsigned char* zT_827;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_828;
    unsigned int zT_829;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_830;
    unsigned int zT_831;
    zT_338B7C76_TypeRegistry* zT_832;
    unsigned int zT_833;
    zT_338B7C76_TypeRegistry* zT_835;
    unsigned int zT_836;
    unsigned int zT_840 = 0;
    unsigned int zT_841;
    int zT_842;
    zT_ABC1EBBE_TypeResolveEnv* zT_845;
    unsigned int zT_846;
    unsigned int zT_851 = 0;
    zT_8143F551_AstKind zT_855;
    int zT_860;
    zT_8143F551_AstKind zT_861;
    unsigned char* zT_867;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_868;
    unsigned int zT_869;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_870;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_872;
    unsigned int zT_874;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_875;
    int zT_878;
    unsigned char* zT_879;
    unsigned int zT_880;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_881;
    unsigned int zT_882 = 0;
    unsigned int zT_886;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_887;
    unsigned char* zT_891;
    unsigned int zT_892;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_893;
    unsigned char* zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    unsigned int zT_897;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_898;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_900;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_903;
    zT_8143F551_AstKind zT_904;
    int zT_908;
    unsigned char* zT_909;
    unsigned int zT_910;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_911;
    unsigned int zT_912 = 0;
    unsigned int zT_916;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_917;
    unsigned char* zT_921;
    unsigned int zT_922;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_923;
    unsigned char* zT_925;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_926;
    unsigned int zT_927;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_928;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_930;
    unsigned int zT_932;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_933;
    int zT_936;
    unsigned char* zT_937;
    unsigned int zT_938;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_939;
    unsigned int zT_940 = 0;
    unsigned int zT_944;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_945;
    unsigned char* zT_949;
    unsigned int zT_950;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_951;
    unsigned char zT_953;
    int zT_957;
    unsigned char zT_959;
    int zT_963;
    zT_8143F551_AstKind zT_964;
    zT_338B7C76_TypeRegistry* zT_970;
    unsigned int zT_971;
    int zT_972;
    int zT_973;
    unsigned int zT_975 = 0;
    unsigned char* zT_977;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_978;
    unsigned int zT_979;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_980;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_982;
    unsigned int zT_984;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_985;
    int zT_988;
    unsigned char* zT_989;
    unsigned int zT_990;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_991;
    unsigned int zT_992 = 0;
    unsigned int zT_996;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_997;
    unsigned char* zT_1001;
    unsigned int zT_1002;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1003;
    unsigned char* zT_1005;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1006;
    unsigned int zT_1007;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1008;
    zT_338B7C76_TypeRegistry* zT_1010;
    unsigned int zT_1011;
    int zT_1012;
    int zT_1013;
    unsigned int zT_1015 = 0;
    unsigned char* zT_1017;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1018;
    unsigned int zT_1019;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1020;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_1022;
    unsigned int zT_1024;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1025;
    int zT_1028;
    unsigned char* zT_1029;
    unsigned int zT_1030;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1031;
    unsigned int zT_1032 = 0;
    unsigned int zT_1036;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1037;
    unsigned char* zT_1041;
    unsigned int zT_1042;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1043;
    unsigned char* zT_1045;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1046;
    unsigned int zT_1047;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1048;
    zT_8143F551_AstKind zT_1049;
    unsigned char zT_1055;
    int zT_1059;
    zT_338B7C76_TypeRegistry* zT_1061;
    unsigned int zT_1062;
    int zT_1063;
    unsigned int zT_1065 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_1067;
    unsigned int zT_1069;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1070;
    int zT_1073;
    unsigned char* zT_1074;
    unsigned int zT_1075;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1076;
    unsigned int zT_1077 = 0;
    unsigned int zT_1081;
    unsigned char* zT_1083;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1084;
    unsigned int zT_1085;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1086;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1087;
    unsigned char* zT_1091;
    unsigned int zT_1092;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1093;
    zT_4028D896_Arr_unsigned_char_2 zT_1095;
    unsigned int zT_1097;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1098;
    int zT_1101;
    unsigned char* zT_1102;
    unsigned int zT_1103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1104;
    unsigned int zT_1105 = 0;
    unsigned int zT_1109;
    unsigned char* zT_1111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1112;
    unsigned int zT_1113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1115;
    unsigned char* zT_1119;
    unsigned int zT_1120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1121;
    unsigned char* zT_1123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1124;
    unsigned int zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    zT_8143F551_AstKind zT_1127;
    unsigned char* zT_1133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1134;
    unsigned int zT_1135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1136;
    unsigned int zT_1137;
    zT_338B7C76_TypeRegistry* zT_1139;
    unsigned int zT_1140;
    unsigned int zT_1142 = 0;
    unsigned char* zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1147;
    unsigned int zT_1148;
    zT_8143F551_AstKind zT_1149;
    unsigned char* zT_1155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1156;
    unsigned int zT_1157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1158;
    unsigned char* zT_1160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1161;
    unsigned int zT_1162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1163;
    zT_4028D896_Arr_unsigned_char_2 zT_1165;
    unsigned int zT_1167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1168;
    int zT_1171;
    unsigned char* zT_1172;
    unsigned int zT_1173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1174;
    unsigned int zT_1175 = 0;
    unsigned int zT_1179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1180;
    unsigned char* zT_1184;
    unsigned int zT_1185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1186;
    unsigned int zT_1187;
    int zT_1188;
    zT_6B0A7D14_AstStore* zT_1191;
    unsigned int zT_1192;
    zT_22A7C88B_AstNode zT_1195 = {0};
    unsigned int zT_1197;
    int zT_1199;
    zT_8143F551_AstKind zT_1200;
    zT_6B0A7D14_AstStore* zT_1205;
    unsigned int zT_1206;
    zT_79FAE712_u64 zT_1209 = 0;
    unsigned int zT_1210;
    int zT_1211;
    zT_8143F551_AstKind zT_1212;
    int zT_1217;
    zT_8143F551_AstKind zT_1218;
    zT_ABC1EBBE_TypeResolveEnv* zT_1224;
    unsigned int zT_1225;
    unsigned int zT_1229 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1231;
    unsigned int zT_1232;
    unsigned int zT_1236 = 0;
    int zT_1239;
    int zT_1242;
    zT_8143F551_AstKind zT_1243;
    unsigned int zT_1248;
    unsigned int zT_1249;
    zT_8143F551_AstKind zT_1250;
    int zT_1255;
    zT_8143F551_AstKind zT_1256;
    int zT_1261;
    zT_8143F551_AstKind zT_1262;
    zT_ABC1EBBE_TypeResolveEnv* zT_1268;
    unsigned int zT_1269;
    unsigned int zT_1273 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1275;
    unsigned int zT_1276;
    unsigned int zT_1280 = 0;
    int zT_1283;
    int zT_1286;
    int zT_1289;
    zT_8143F551_AstKind zT_1290;
    unsigned int zT_1295;
    zT_8143F551_AstKind zT_1296;
    unsigned int zT_1301;
    unsigned int zT_1302;
    zT_8143F551_AstKind zT_1303;
    zT_ABC1EBBE_TypeResolveEnv* zT_1309;
    unsigned int zT_1310;
    unsigned int zT_1314 = 0;
    int zT_1317;
    zT_ABC1EBBE_TypeResolveEnv* zT_1319;
    unsigned int zT_1320;
    unsigned int zT_1324 = 0;
    int zT_1327;
    unsigned char* zT_1329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1330;
    unsigned int zT_1331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1332;
    zT_4028D896_Arr_unsigned_char_2 zT_1334;
    unsigned int zT_1336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1337;
    int zT_1340;
    unsigned char* zT_1341;
    unsigned int zT_1342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1343;
    unsigned int zT_1344 = 0;
    unsigned int zT_1348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1349;
    unsigned char* zT_1353;
    unsigned int zT_1354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1355;
    zT_338B7C76_TypeRegistry* zT_1357;
    unsigned int zT_1358;
    unsigned int zT_1359;
    unsigned int zT_1361 = 0;
    unsigned char* zT_1363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1364;
    unsigned int zT_1365;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1366;
    zT_4028D896_Arr_unsigned_char_2 zT_1368;
    unsigned int zT_1370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1371;
    int zT_1374;
    unsigned char* zT_1375;
    unsigned int zT_1376;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1377;
    unsigned int zT_1378 = 0;
    unsigned int zT_1382;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1383;
    unsigned char* zT_1387;
    unsigned int zT_1388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1389;
    unsigned char* zT_1393;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1394;
    unsigned int zT_1395;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1396;
    unsigned char* zT_1398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1399;
    unsigned int zT_1400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1401;
    int zT_1403;
    zT_8143F551_AstKind zT_1404;
    zT_6B0A7D14_AstStore* zT_1410;
    unsigned int zT_1411;
    unsigned int zT_1414 = 0;
    zT_D3EB6303_StringInterner* zT_1416;
    unsigned int zT_1417;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1419 = {0};
    unsigned int zT_1421;
    int zT_1424;
    unsigned char* zT_1425;
    int zT_1426;
    unsigned char zT_1427;
    int zT_1430;
    zT_7334F4FE_Opt_225 zT_1432;
    unsigned char zT_1433;
    zT_F85C5DED_DiagnosticCollector* zT_1435;
    unsigned int zT_1436;
    int zT_1437 = 0;
    unsigned char* zT_1439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1440;
    unsigned int zT_1441;
    zT_F85C5DED_DiagnosticCollector* zT_1442;
    unsigned int zT_1445;
    unsigned int zT_1446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1448;
    unsigned int zT_1456;
    unsigned int zT_1457;
    unsigned int zT_1460 = 0;
    unsigned char* zT_1463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1464;
    unsigned int zT_1465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1466;
    unsigned int zT_1467;
    unsigned char* zT_1469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1470;
    unsigned int zT_1471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1472;
    zT_8143F551_AstKind zT_1474;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    zT_D4761958_Opt_858 sym_cur;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D4761958_Opt_858 sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    int arbu;
    unsigned int arbw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_5826BFC7_Arr_unsigned_char_1 sd_id;
    unsigned int sd_idl;
    unsigned int sd_ids;
    zT_4428DEE2_Arr_unsigned_char_2 sd_nm;
    unsigned int sd_di;
    unsigned int sd_namelen;
    unsigned int sd_name_id;
    zT_BAEE192E_Opt_10 sd_existing;
    unsigned int se;
    unsigned int sd_tid;
    unsigned int sd_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    unsigned int sd_child;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_ft;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_D4761958_Opt_858 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_D4761958_Opt_858 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    unsigned int esd_children_n;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    unsigned int fnt_extra_n;
    unsigned int fnt_i;
    unsigned char fnt_conv;
    unsigned int fnt_pt;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptib;
    unsigned int ptil;
    unsigned int ptis;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptkb;
    unsigned int ptkl;
    unsigned int ptks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptcb;
    unsigned int ptcl;
    unsigned int ptcs;
    int is_const;
    int is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb;
    unsigned int ppl;
    unsigned int pps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb2;
    unsigned int ppl2;
    unsigned int pps2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_4028D896_Arr_unsigned_char_2 sl_e;
    unsigned int sl_el;
    unsigned int sl_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_4028D896_Arr_unsigned_char_2 sl_r;
    unsigned int sl_rl;
    unsigned int sl_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_4028D896_Arr_unsigned_char_2 t1b;
    unsigned int t1l;
    unsigned int t1s;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    int arr_resolved;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    zT_4028D896_Arr_unsigned_char_2 t2b;
    unsigned int t2l;
    unsigned int t2s;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int al;
    unsigned int alf;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    zT_4028D896_Arr_unsigned_char_2 t3b;
    unsigned int t3l;
    unsigned int t3s;
    int sz_is_inferred;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asn_msg;
    if ((int)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((int)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = env->store;
    zT_32 = node_idx;
    zT_34 = zF_53458827_astStoreIdentifier(zT_31, zT_32);
    name_id = zT_34;
    zT_36 = "OPTVOID:id";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    opm4_m = zT_37;
    zT_39 = opm4_m;
    zT_40 = name_id;
    zF_C914CB83_markerWriteInt(zT_39, zT_40);
    zT_42 = env->interner;
    zT_43 = name_id;
    zT_45 = zF_9134020D_stringInternerGet(zT_42, zT_43);
    text = zT_45;
    zT_47 = env->interner;
    zT_48 = text;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    canonical_id = zT_50;
    zT_51 = env->module_id;
    if ((int)(zT_51 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_181 = node.kind;
    if ((int)(zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_55 = env->module_id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_55) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck_cur = zT_60;
    zT_62 = env->typereg;
    zT_63 = ck_cur;
    zT_65 = zF_0EB68360_nameCacheGet(zT_62, zT_63);
    tc_cur = zT_65;
    zT_66 = tc_cur.has_value;
    if (zT_66) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_69 = env->typereg;
    zT_73 = zF_0EB68360_nameCacheGet(zT_69, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_73;
    zT_75 = "OPTVOID:nc";
    zT_77 = 10;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    opnc_m = zT_76;
    zT_78 = opnc_m;
    zT_79 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_78, zT_79);
    zT_80 = tid.has_value;
    if (zT_80) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    t = tc_cur.value;
    return t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    t = tid.value;
    return t;
    z_bb_10:
    zT_83 = "NF";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    nf = zT_84;
    zT_86 = nf;
    zF_48AC7B3A_markerWrite(zT_86);
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    mi = zT_89;
    goto z_bb_11;
    z_bb_11:
    zT_90 = env->symbol_reg;
    zT_91 = zT_90->tables_len;
    if ((int)(mi < (unsigned int)((unsigned int)zT_91))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_99 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck = zT_99;
    zT_101 = env->typereg;
    zT_102 = ck;
    zT_104 = zF_0EB68360_nameCacheGet(zT_101, zT_102);
    tc = zT_104;
    zT_105 = tc.has_value;
    if (zT_105) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_111 = "N2";
    zT_113 = 2;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    n2 = zT_112;
    zT_114 = n2;
    zF_48AC7B3A_markerWrite(zT_114);
    zT_115 = env->module_id;
    if ((int)(zT_115 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_107 = 1;
    zT_109 = mi + (unsigned int)((unsigned int)zT_107);
    mi = zT_109;
    goto z_bb_11;
    z_bb_15:
    t = tc.value;
    return t;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_119 = env->symbol_reg;
    zT_120 = env->module_id;
    zT_121 = name_id;
    zT_124 = zF_A398987E_symbolRegistryQuali(zT_119, zT_120, zT_121);
    sym_cur = zT_124;
    zT_125 = sym_cur.has_value;
    if (zT_125) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_132 = 0;
    zT_133 = (unsigned int)zT_132;
    si = zT_133;
    goto z_bb_23;
    z_bb_19:
    s = sym_cur.value;
    zT_127 = s->type_id;
    if ((int)(zT_127 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_130 = s->type_id;
    return zT_130;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_134 = env->symbol_reg;
    zT_135 = zT_134->tables_len;
    if ((int)(si < (unsigned int)((unsigned int)zT_135))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_139 = env->symbol_reg;
    zT_141 = name_id;
    zT_144 = zF_A398987E_symbolRegistryQuali(zT_139, (unsigned int)((unsigned int)si), zT_141);
    sym = zT_144;
    zT_145 = sym.has_value;
    if (zT_145) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_162 = "OPTVOID:idF";
    zT_164 = 11;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    opm4f_m = zT_163;
    zT_165 = opm4f_m;
    zT_166 = name_id;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    zT_168 = 0;
    arbu = zT_168;
    zT_170 = text;
    zT_171 = &arbu;
    zT_173 = zF_741B5264_parseArbIntWidth(zT_170, zT_171);
    arbw = zT_173;
    if ((int)(arbw != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    zT_158 = 1;
    zT_160 = si + (unsigned int)((unsigned int)zT_158);
    si = zT_160;
    goto z_bb_23;
    z_bb_27:
    s = sym.value;
    zT_147 = s->type_id;
    if ((int)(zT_147 != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_151 = "OPTVOID:ids";
    zT_153 = 11;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    ops_m = zT_152;
    zT_154 = ops_m;
    zT_155 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_154, zT_155);
    zT_157 = s->type_id;
    return zT_157;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_176 = env->typereg;
    zT_177 = text;
    zT_179 = zF_B8CF3697_typeRegistryGetOrCr(zT_176, zT_177);
    return zT_179;
    z_bb_32:
    return (unsigned int)(18);
    z_bb_33:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_187[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        sd_id[_i] = zT_187[_i];
        _i++;
    }
}
    zT_189 = node_idx;
    zT_193 = 0;
    zT_194 = (unsigned char*)((unsigned char*)sd_id) + zT_193;
    zT_195 = (unsigned int)(12) - zT_193;
    zT_196.ptr = zT_194;
    zT_196.len = zT_195;
    zT_190 = zT_196;
    zT_197 = zF_A7504564_itoa(zT_189, zT_190);
    sd_idl = zT_197;
    zT_201 = (unsigned int)(11) - (unsigned int)((unsigned int)sd_idl);
    sd_ids = zT_201;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_203[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        sd_nm[_i] = zT_203[_i];
        _i++;
    }
}
    zT_204 = 97;
    zT_205 = 0;
    sd_nm[zT_205] = zT_204;
    zT_206 = 110;
    zT_207 = 1;
    sd_nm[zT_207] = zT_206;
    zT_208 = 111;
    zT_209 = 2;
    sd_nm[zT_209] = zT_208;
    zT_210 = 110;
    zT_211 = 3;
    sd_nm[zT_211] = zT_210;
    zT_212 = 95;
    zT_213 = 4;
    sd_nm[zT_213] = zT_212;
    zT_215 = 0;
    zT_216 = (unsigned int)zT_215;
    sd_di = zT_216;
    goto z_bb_35;
    z_bb_34:
    zT_369 = node.kind;
    if ((int)(zT_369 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_60; else goto z_bb_61;
    z_bb_35:
    if ((int)(sd_di < (unsigned int)((unsigned int)sd_idl))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_219 = sd_ids + sd_di;
    zT_220 = sd_id[zT_219];
    zT_222 = (unsigned int)(5) + sd_di;
    sd_nm[zT_222] = zT_220;
    goto z_bb_38;
    z_bb_37:
    zT_229 = (unsigned int)(5) + (unsigned int)((unsigned int)sd_idl);
    sd_namelen = zT_229;
    zT_231 = env->interner;
    zT_236 = 0;
    zT_237 = (unsigned char*)((unsigned char*)sd_nm) + zT_236;
    zT_238 = sd_namelen - zT_236;
    zT_239.ptr = zT_237;
    zT_239.len = zT_238;
    zT_232 = zT_239;
    zT_240 = zF_50C274AF_stringInternerInter(zT_231, zT_232);
    sd_name_id = zT_240;
    zT_242 = env->typereg;
    zT_246 = zF_0EB68360_nameCacheGet(zT_242, (zT_79FAE712_u64)((zT_79FAE712_u64)sd_name_id));
    sd_existing = zT_246;
    zT_247 = sd_existing.has_value;
    if (zT_247) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_223 = 1;
    zT_225 = sd_di + (unsigned int)((unsigned int)zT_223);
    sd_di = zT_225;
    goto z_bb_35;
    z_bb_39:
    se = sd_existing.value;
    return se;
    z_bb_40:
    zT_250 = env->typereg;
    zT_252 = sd_name_id;
    zT_259 = zF_3A64E2E0_typeRegistryRegiste(zT_250, (unsigned int)(0), zT_252, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type));
    sd_tid = zT_259;
    zT_260 = node.flags;
    if ((int)((unsigned char)(zT_260 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_265 = env->typereg;
    zT_266 = sd_tid;
    zF_52816016_typeRegistrySetPack(zT_265, zT_266);
    goto z_bb_42;
    z_bb_42:
    zT_268 = env->store;
    zT_269 = node_idx;
    zT_271 = zF_8BA26B9E_astStoreNodePayload(zT_268, zT_269);
    if ((int)(zT_271 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_275 = env->store;
    zT_276 = node_idx;
    zT_278 = zF_152E19CB_astStoreNodeExtraCh(zT_275, zT_276);
    sd_children_n = zT_278;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_280[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_280[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_282[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_282[_i];
        _i++;
    }
}
    zT_284 = 0;
    zT_285 = (unsigned int)zT_284;
    sd_fc = zT_285;
    zT_287 = 0;
    zT_288 = (unsigned int)zT_287;
    sd_i = zT_288;
    goto z_bb_45;
    z_bb_44:
    return sd_tid;
    z_bb_45:
    if ((int)(sd_i < (unsigned int)((unsigned int)sd_children_n))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_295 = env->store;
    zT_296 = node_idx;
    zT_300 = zF_B10B1BC1_astStoreNodeExtraCh(zT_295, zT_296, (unsigned int)((unsigned int)sd_i));
    sd_child = zT_300;
    zT_302 = env->store;
    zT_303 = sd_child;
    zT_305 = zF_FCDD1D35_astStoreNodeAt(zT_302, zT_303);
    sd_fd = zT_305;
    zT_306 = sd_fd.kind;
    if ((int)(zT_306 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_52; else goto z_bb_53;
    z_bb_47:
    if ((int)(sd_fc > (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_48:
    zT_326 = 1;
    zT_328 = sd_i + (unsigned int)((unsigned int)zT_326);
    sd_i = zT_328;
    goto z_bb_45;
    z_bb_49:
    zT_291 = sd_fc < (unsigned int)(32);
    goto z_bb_51;
    z_bb_50:
    zT_291 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_291) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_312 = env;
    zT_313 = sd_fd.child_0;
    zT_318 = zF_F2107C15_resolveTypeExprFull(zT_312, zT_313, (unsigned int)(depth + (unsigned int)(1)));
    sd_ft = zT_318;
    sd_fty[sd_fc] = sd_ft;
    zT_319 = env->store;
    zT_320 = sd_child;
    zT_322 = zF_8BA26B9E_astStoreNodePayload(zT_319, zT_320);
    sd_fnm[sd_fc] = zT_322;
    zT_323 = 1;
    zT_325 = sd_fc + (unsigned int)((unsigned int)zT_323);
    sd_fc = zT_325;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_332 = env->typereg;
    zT_333 = zT_332->fe_len;
    zT_334 = (unsigned int)zT_333;
    sd_fstart = zT_334;
    zT_336 = 0;
    zT_337 = (unsigned int)zT_336;
    sd_j = zT_337;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_44;
    z_bb_56:
    if ((int)(sd_j < sd_fc)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_339 = env->typereg;
    zT_343 = sd_fnm[sd_j];
    zT_342.name_id = zT_343;
    zT_344 = sd_fty[sd_j];
    zT_342.type_id = zT_344;
    zT_345 = 0;
    zT_342.offset = zT_345;
    zT_340 = zT_342;
    zF_701DF154_feAppend(zT_339, zT_340);
    goto z_bb_59;
    z_bb_58:
    zT_349 = env->typereg;
    zT_353 = (unsigned int)sd_fstart;
    zT_352.fields_start = zT_353;
    zT_354 = (unsigned short)sd_fc;
    zT_352.fields_count = zT_354;
    zT_350 = zT_352;
    zF_CF849366_stAppend(zT_349, zT_350);
    zT_356 = env->typereg;
    zT_357 = zT_356->st_len;
    zT_360 = (unsigned int)(unsigned int)(zT_357 - (unsigned int)(1));
    sd_st_idx = zT_360;
    zT_362 = env->typereg;
    zT_363 = zT_362->types_items;
    zT_364 = (unsigned int)sd_tid;
    zT_365 = zT_363[zT_364];
    sd_ty = zT_365;
    sd_ty.payload_idx = sd_st_idx;
    zT_366 = env->typereg;
    zT_367 = zT_366->types_items;
    zT_368 = (unsigned int)sd_tid;
    zT_367[zT_368] = sd_ty;
    goto z_bb_55;
    z_bb_59:
    zT_346 = 1;
    zT_348 = sd_j + (unsigned int)((unsigned int)zT_346);
    sd_j = zT_348;
    goto z_bb_56;
    z_bb_60:
    zT_375 = 0;
    fah_matched = zT_375;
    zT_377 = env;
    zT_378 = node.child_0;
    zT_383 = zF_F2107C15_resolveTypeExprFull(zT_377, zT_378, (unsigned int)(depth + (unsigned int)(1)));
    base_type = zT_383;
    if ((int)(base_type == (unsigned int)(18))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_505 = node.kind;
    if ((int)(zT_505 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_86; else goto z_bb_87;
    z_bb_62:
    zT_387 = env->store;
    zT_388 = node.child_0;
    zT_391 = zF_FCDD1D35_astStoreNodeAt(zT_387, zT_388);
    base_node = zT_391;
    zT_392 = base_node.kind;
    if ((int)(zT_392 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    zT_462 = env->typereg;
    zT_463 = zT_462->types_items;
    zT_464 = (unsigned int)base_type;
    zT_465 = zT_463[zT_464];
    base_ty = zT_465;
    zT_466 = base_ty.kind;
    if ((int)(zT_466 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_64:
    zT_398 = env->store;
    zT_399 = node.child_0;
    zT_402 = zF_53458827_astStoreIdentifier(zT_398, zT_399);
    base_name_id = zT_402;
    zT_404 = 0;
    zT_405 = (unsigned int)zT_404;
    smi = zT_405;
    goto z_bb_66;
    z_bb_65:
    zT_454 = "FAH:m";
    zT_456 = 5;
    zT_455.ptr = zT_454;
    zT_455.len = zT_456;
    fam_m = zT_455;
    zT_457 = fam_m;
    zT_458 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_457, zT_458);
    return (unsigned int)(18);
    z_bb_66:
    zT_406 = env->symbol_reg;
    zT_407 = zT_406->tables_len;
    if ((int)(smi < (unsigned int)((unsigned int)zT_407))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_411 = env->symbol_reg;
    zT_413 = base_name_id;
    zT_416 = zF_A398987E_symbolRegistryQuali(zT_411, (unsigned int)((unsigned int)smi), zT_413);
    base_sym = zT_416;
    zT_417 = base_sym.has_value;
    if (zT_417) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_450 = 1;
    zT_452 = smi + (unsigned int)((unsigned int)zT_450);
    smi = zT_452;
    goto z_bb_66;
    z_bb_70:
    bs = base_sym.value;
    zT_419 = bs->kind;
    if ((int)(zT_419 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_69;
    z_bb_72:
    zT_425 = bs->module_id;
    mod_id = zT_425;
    zT_427 = env->symbol_reg;
    zT_428 = mod_id;
    zT_431 = env->store;
    zT_432 = node_idx;
    zT_434 = zF_8BA26B9E_astStoreNodePayload(zT_431, zT_432);
    zT_429 = zT_434;
    zT_435 = zF_A398987E_symbolRegistryQuali(zT_427, zT_428, zT_429);
    payload_sym = zT_435;
    zT_436 = payload_sym.has_value;
    if (zT_436) goto z_bb_74; else goto z_bb_75;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    ps = payload_sym.value;
    zT_438 = ps->type_id;
    if ((int)(zT_438 != (unsigned int)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    zT_441 = 1;
    fah_matched = zT_441;
    zT_443 = "FAH:r";
    zT_445 = 5;
    zT_444.ptr = zT_443;
    zT_444.len = zT_445;
    fam = zT_444;
    zT_446 = fam;
    zT_447 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_446, zT_447);
    zT_449 = ps->type_id;
    return zT_449;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_472 = base_ty.module_id;
    mod_id = zT_472;
    zT_474 = env->symbol_reg;
    zT_475 = mod_id;
    zT_478 = env->store;
    zT_479 = node_idx;
    zT_481 = zF_8BA26B9E_astStoreNodePayload(zT_478, zT_479);
    zT_476 = zT_481;
    zT_482 = zF_A398987E_symbolRegistryQuali(zT_474, zT_475, zT_476);
    sym = zT_482;
    zT_483 = sym.has_value;
    if (zT_483) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    if ((int)(fah_matched == (unsigned char)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_80:
    s = sym.value;
    zT_485 = s->type_id;
    if ((int)(zT_485 != (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_488 = 1;
    fah_matched = zT_488;
    zT_490 = "FAH:r";
    zT_492 = 5;
    zT_491.ptr = zT_490;
    zT_491.len = zT_492;
    fam = zT_491;
    zT_493 = fam;
    zT_494 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_493, zT_494);
    zT_496 = s->type_id;
    return zT_496;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_500 = "FAH:N";
    zT_502 = 5;
    zT_501.ptr = zT_500;
    zT_501.len = zT_502;
    fnm = zT_501;
    zT_503 = fnm;
    zT_504 = node_idx;
    zF_C914CB83_markerWriteInt(zT_503, zT_504);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_61;
    z_bb_86:
    zT_512 = env->typereg;
    zT_513 = zT_512->xn_len;
    zT_514 = (unsigned int)zT_513;
    zT_515 = 0;
    zT_511[zT_515] = zT_514;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_511[_i];
        _i++;
    }
}
    zT_518 = 0;
    zT_519 = 0;
    zT_517[zT_519] = zT_518;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_517[_i];
        _i++;
    }
}
    zT_520 = env->store;
    zT_521 = node_idx;
    zT_523 = zF_8BA26B9E_astStoreNodePayload(zT_520, zT_521);
    if ((int)(zT_523 != (unsigned int)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    zT_559 = node.kind;
    if ((int)(zT_559 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_88:
    zT_527 = env->store;
    zT_528 = node_idx;
    zT_530 = zF_152E19CB_astStoreNodeExtraCh(zT_527, zT_528);
    esd_children_n = zT_530;
    zT_531 = (unsigned short)esd_children_n;
    zT_532 = 0;
    esd_count_box[zT_532] = zT_531;
    zT_534 = 0;
    zT_535 = (unsigned int)zT_534;
    esd_i = zT_535;
    goto z_bb_90;
    z_bb_89:
    zT_550 = env->typereg;
    zT_554 = 0;
    zT_551 = esd_start_box[zT_554];
    zT_556 = 0;
    zT_552 = esd_count_box[zT_556];
    zT_558 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_550, zT_551, zT_552);
    return zT_558;
    z_bb_90:
    if ((int)(esd_i < (unsigned int)((unsigned int)esd_children_n))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_538 = env->typereg;
    zT_541 = env->store;
    zT_542 = node_idx;
    zT_546 = zF_B10B1BC1_astStoreNodeExtraCh(zT_541, zT_542, (unsigned int)((unsigned int)esd_i));
    zT_539 = zT_546;
    zF_A648B1CB_xnAppend(zT_538, zT_539);
    goto z_bb_93;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_547 = 1;
    zT_549 = esd_i + (unsigned int)((unsigned int)zT_547);
    esd_i = zT_549;
    goto z_bb_90;
    z_bb_94:
    zT_565 = env;
    zT_566 = node.child_1;
    zT_571 = zF_F2107C15_resolveTypeExprFull(zT_565, zT_566, (unsigned int)(depth + (unsigned int)(1)));
    eu_payload_type = zT_571;
    if ((int)(eu_payload_type == (unsigned int)(18))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    zT_603 = node.kind;
    if ((int)(zT_603 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_103; else goto z_bb_104;
    z_bb_96:
    return (unsigned int)(18);
    z_bb_97:
    zT_577 = 0;
    zT_578 = 0;
    zT_576[zT_578] = zT_577;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_576[_i];
        _i++;
    }
}
    zT_579 = node.child_0;
    zT_580 = 0;
    if ((int)(zT_579 != (unsigned int)zT_580)) goto z_bb_98; else goto z_bb_100;
    z_bb_98:
    zT_583 = env;
    zT_584 = node.child_0;
    zT_589 = zF_F2107C15_resolveTypeExprFull(zT_583, zT_584, (unsigned int)(depth + (unsigned int)(1)));
    eu_resolved_es = zT_589;
    if ((int)(eu_resolved_es == (unsigned int)(18))) goto z_bb_101; else goto z_bb_102;
    z_bb_99:
    zT_596 = env->typereg;
    zT_597 = eu_payload_type;
    zT_600 = 0;
    zT_598 = eu_es_box[zT_600];
    zT_602 = zF_16D1A6EE_typeRegistryGetOrCr(zT_596, zT_597, zT_598);
    return zT_602;
    z_bb_100:
    zT_594 = 0;
    zT_595 = 0;
    eu_es_box[zT_595] = zT_594;
    goto z_bb_99;
    z_bb_101:
    return (unsigned int)(18);
    z_bb_102:
    zT_593 = 0;
    eu_es_box[zT_593] = eu_resolved_es;
    goto z_bb_99;
    z_bb_103:
    zT_610 = 0;
    zT_611 = 0;
    zT_609[zT_611] = zT_610;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_609[_i];
        _i++;
    }
}
    zT_612 = 1;
    zT_613 = 0;
    fnt_ret_box[zT_613] = zT_612;
    zT_614 = node.child_0;
    zT_615 = 0;
    if ((int)(zT_614 != (unsigned int)zT_615)) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_841 = node.child_0;
    zT_842 = 0;
    if ((int)(zT_841 != (unsigned int)zT_842)) goto z_bb_158; else goto z_bb_159;
    z_bb_105:
    zT_617 = env;
    zT_618 = node.child_0;
    zT_623 = zF_F2107C15_resolveTypeExprFull(zT_617, zT_618, (unsigned int)(depth + (unsigned int)(1)));
    zT_624 = 0;
    fnt_ret_box[zT_624] = zT_623;
    zT_626 = "OPTVOID:fntR";
    zT_628 = 12;
    zT_627.ptr = zT_626;
    zT_627.len = zT_628;
    opm2_m = zT_627;
    zT_629 = opm2_m;
    zT_631 = 0;
    zT_630 = fnt_ret_box[zT_631];
    zF_C914CB83_markerWriteInt(zT_629, zT_630);
    zT_633 = 0;
    zT_634 = fnt_ret_box[zT_633];
    if ((int)(zT_634 == (unsigned int)(18))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_639[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_639[_i];
        _i++;
    }
}
    zT_641 = 0;
    fnt_pc = zT_641;
    zT_642 = env->store;
    zT_643 = node_idx;
    zT_645 = zF_8BA26B9E_astStoreNodePayload(zT_642, zT_643);
    if ((int)(zT_645 != (unsigned int)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_107:
    return (unsigned int)(18);
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_649 = env->store;
    zT_650 = node_idx;
    zT_652 = zF_152E19CB_astStoreNodeExtraCh(zT_649, zT_650);
    fnt_extra_n = zT_652;
    zT_654 = 0;
    fnt_i = zT_654;
    goto z_bb_111;
    z_bb_110:
    zT_681 = 0;
    fnt_conv = zT_681;
    zT_682 = node.flags;
    if ((int)((unsigned char)(zT_682 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_111:
    if ((int)(fnt_i < (unsigned int)((unsigned int)fnt_extra_n))) goto z_bb_115; else goto z_bb_116;
    z_bb_112:
    zT_661 = env;
    zT_664 = env->store;
    zT_665 = node_idx;
    zT_669 = zF_B10B1BC1_astStoreNodeExtraCh(zT_664, zT_665, (unsigned int)((unsigned int)fnt_i));
    zT_662 = zT_669;
    zT_672 = zF_F2107C15_resolveTypeExprFull(zT_661, zT_662, (unsigned int)(depth + (unsigned int)(1)));
    fnt_pt = zT_672;
    if ((int)(fnt_pt == (unsigned int)(18))) goto z_bb_118; else goto z_bb_119;
    z_bb_113:
    goto z_bb_110;
    z_bb_114:
    zT_679 = fnt_i + (unsigned int)(1);
    fnt_i = zT_679;
    goto z_bb_111;
    z_bb_115:
    zT_657 = fnt_pc < (unsigned int)(16);
    goto z_bb_117;
    z_bb_116:
    zT_657 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_657) goto z_bb_112; else goto z_bb_113;
    z_bb_118:
    return (unsigned int)(18);
    z_bb_119:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_677 = fnt_pc + (unsigned int)(1);
    fnt_pc = zT_677;
    goto z_bb_114;
    z_bb_120:
    zT_687 = 1;
    fnt_conv = zT_687;
    goto z_bb_121;
    z_bb_121:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_689[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_689[_i];
        _i++;
    }
}
    zT_691 = 0;
    fnt_np = zT_691;
    zT_693 = "fnt_";
    zT_695 = 4;
    zT_694.ptr = zT_693;
    zT_694.len = zT_695;
    fnt_pre = zT_694;
    if ((int)(fnt_conv == (unsigned char)(1))) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_698 = "fnts_";
    zT_700 = 5;
    zT_699.ptr = zT_698;
    zT_699.len = zT_700;
    fnt_pre = zT_699;
    goto z_bb_123;
    z_bb_123:
    zT_702 = 0;
    fnt_pri = zT_702;
    goto z_bb_124;
    z_bb_124:
    zT_704 = fnt_pre.len;
    if ((int)(fnt_pri < zT_704)) goto z_bb_128; else goto z_bb_129;
    z_bb_125:
    zT_709 = fnt_pre.ptr;
    zT_710 = zT_709[fnt_pri];
    fnt_nb[fnt_np] = zT_710;
    zT_712 = fnt_np + (unsigned int)(1);
    fnt_np = zT_712;
    goto z_bb_127;
    z_bb_126:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_716[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_716[_i];
        _i++;
    }
}
    zT_720 = 0;
    zT_718 = fnt_ret_box[zT_720];
    zT_724 = 0;
    zT_725 = (unsigned char*)((unsigned char*)fnt_rb) + zT_724;
    zT_726 = (unsigned int)(12) - zT_724;
    zT_727.ptr = zT_725;
    zT_727.len = zT_726;
    zT_719 = zT_727;
    zT_728 = zF_A7504564_itoa(zT_718, zT_719);
    fnt_rl = zT_728;
    zT_732 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_rl);
    fnt_rs = zT_732;
    goto z_bb_131;
    z_bb_127:
    zT_714 = fnt_pri + (unsigned int)(1);
    fnt_pri = zT_714;
    goto z_bb_124;
    z_bb_128:
    zT_706 = fnt_np < (unsigned int)(95);
    goto z_bb_130;
    z_bb_129:
    zT_706 = 0;
    goto z_bb_130;
    z_bb_130:
    if (zT_706) goto z_bb_125; else goto z_bb_126;
    z_bb_131:
    if ((int)(fnt_rs < (unsigned int)(11))) goto z_bb_135; else goto z_bb_136;
    z_bb_132:
    zT_738 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_738;
    zT_740 = fnt_np + (unsigned int)(1);
    fnt_np = zT_740;
    goto z_bb_134;
    z_bb_133:
    zT_744 = 0;
    fnt_k = zT_744;
    goto z_bb_138;
    z_bb_134:
    zT_742 = fnt_rs + (unsigned int)(1);
    fnt_rs = zT_742;
    goto z_bb_131;
    z_bb_135:
    zT_735 = fnt_np < (unsigned int)(95);
    goto z_bb_137;
    z_bb_136:
    zT_735 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_735) goto z_bb_132; else goto z_bb_133;
    z_bb_138:
    if ((int)(fnt_k < fnt_pc)) goto z_bb_142; else goto z_bb_143;
    z_bb_139:
    if ((int)(fnt_np < (unsigned int)(95))) goto z_bb_145; else goto z_bb_146;
    z_bb_140:
    zT_784 = env->interner;
    zT_789 = 0;
    zT_790 = (unsigned char*)((unsigned char*)fnt_nb) + zT_789;
    zT_791 = fnt_np - zT_789;
    zT_792.ptr = zT_790;
    zT_792.len = zT_791;
    zT_785 = zT_792;
    zT_793 = zF_50C274AF_stringInternerInter(zT_784, zT_785);
    fnt_name_id = zT_793;
    zT_795 = env->typereg;
    zT_796 = zT_795->xt_len;
    zT_797 = (unsigned int)zT_796;
    fnt_pstart = zT_797;
    zT_799 = 0;
    fnt_a = zT_799;
    goto z_bb_154;
    z_bb_141:
    zT_782 = fnt_k + (unsigned int)(1);
    fnt_k = zT_782;
    goto z_bb_138;
    z_bb_142:
    zT_746 = fnt_np < (unsigned int)(95);
    goto z_bb_144;
    z_bb_143:
    zT_746 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_746) goto z_bb_139; else goto z_bb_140;
    z_bb_145:
    zT_751 = 95;
    fnt_nb[fnt_np] = zT_751;
    zT_753 = fnt_np + (unsigned int)(1);
    fnt_np = zT_753;
    goto z_bb_146;
    z_bb_146:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_755[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_755[_i];
        _i++;
    }
}
    zT_757 = fnt_ptypes[fnt_k];
    zT_762 = 0;
    zT_763 = (unsigned char*)((unsigned char*)fnt_pb) + zT_762;
    zT_764 = (unsigned int)(12) - zT_762;
    zT_765.ptr = zT_763;
    zT_765.len = zT_764;
    zT_758 = zT_765;
    zT_766 = zF_A7504564_itoa(zT_757, zT_758);
    fnt_pl = zT_766;
    zT_770 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_pl);
    fnt_ps = zT_770;
    goto z_bb_147;
    z_bb_147:
    if ((int)(fnt_ps < (unsigned int)(11))) goto z_bb_151; else goto z_bb_152;
    z_bb_148:
    zT_776 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_776;
    zT_778 = fnt_np + (unsigned int)(1);
    fnt_np = zT_778;
    goto z_bb_150;
    z_bb_149:
    goto z_bb_141;
    z_bb_150:
    zT_780 = fnt_ps + (unsigned int)(1);
    fnt_ps = zT_780;
    goto z_bb_147;
    z_bb_151:
    zT_773 = fnt_np < (unsigned int)(95);
    goto z_bb_153;
    z_bb_152:
    zT_773 = 0;
    goto z_bb_153;
    z_bb_153:
    if (zT_773) goto z_bb_148; else goto z_bb_149;
    z_bb_154:
    if ((int)(fnt_a < fnt_pc)) goto z_bb_155; else goto z_bb_156;
    z_bb_155:
    zT_801 = env->typereg;
    zT_802 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_801, zT_802);
    goto z_bb_157;
    z_bb_156:
    zT_808 = env->typereg;
    zT_809 = fnt_name_id;
    zT_823 = 0;
    zT_815 = fnt_ret_box[zT_823];
    zT_816 = fnt_conv;
    zT_825 = zF_474336D7_typeRegistryGetOrCr(zT_808, zT_809, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), (unsigned short)((unsigned short)fnt_pc), zT_815, zT_816);
    fnt_tid = zT_825;
    zT_827 = "OPTVOID:fntT";
    zT_829 = 12;
    zT_828.ptr = zT_827;
    zT_828.len = zT_829;
    opm3_m = zT_828;
    zT_830 = opm3_m;
    zT_831 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_830, zT_831);
    zT_832 = env->typereg;
    zT_833 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_832, zT_833);
    zT_835 = env->typereg;
    zT_836 = fnt_tid;
    zT_840 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_835, zT_836, (int)(0));
    return zT_840;
    z_bb_157:
    zT_806 = fnt_a + (unsigned int)(1);
    fnt_a = zT_806;
    goto z_bb_154;
    z_bb_158:
    zT_845 = env;
    zT_846 = node.child_0;
    zT_851 = zF_F2107C15_resolveTypeExprFull(zT_845, zT_846, (unsigned int)(depth + (unsigned int)(1)));
    child_type = zT_851;
    if ((int)(child_type == (unsigned int)(18))) goto z_bb_160; else goto z_bb_161;
    z_bb_159:
    zT_1463 = "UND:n";
    zT_1465 = 5;
    zT_1464.ptr = zT_1463;
    zT_1464.len = zT_1465;
    und_nm2 = zT_1464;
    zT_1466 = und_nm2;
    zT_1467 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1466, zT_1467);
    zT_1469 = "UND:k";
    zT_1471 = 5;
    zT_1470.ptr = zT_1469;
    zT_1470.len = zT_1471;
    und_km = zT_1470;
    zT_1472 = und_km;
    zT_1474 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1472, (unsigned int)((unsigned int)zT_1474));
    return (unsigned int)(18);
    z_bb_160:
    return (unsigned int)(18);
    z_bb_161:
    zT_855 = node.kind;
    if ((int)(zT_855 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_163; else goto z_bb_162;
    z_bb_162:
    zT_861 = node.kind;
    zT_860 = zT_861 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_164;
    z_bb_163:
    zT_860 = 1;
    goto z_bb_164;
    z_bb_164:
    if (zT_860) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_867 = "PTR:i";
    zT_869 = 5;
    zT_868.ptr = zT_867;
    zT_868.len = zT_869;
    ptm = zT_868;
    zT_870 = ptm;
    zF_48AC7B3A_markerWrite(zT_870);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_872[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptib[_i] = zT_872[_i];
        _i++;
    }
}
    zT_874 = node_idx;
    zT_878 = 0;
    zT_879 = (unsigned char*)((unsigned char*)ptib) + zT_878;
    zT_880 = (unsigned int)(10) - zT_878;
    zT_881.ptr = zT_879;
    zT_881.len = zT_880;
    zT_875 = zT_881;
    zT_882 = zF_A7504564_itoa(zT_874, zT_875);
    ptil = zT_882;
    zT_886 = (unsigned int)(9) - (unsigned int)((unsigned int)ptil);
    ptis = zT_886;
    zT_891 = (unsigned char*)((unsigned char*)ptib) + ptis;
    zT_892 = (unsigned int)(9) - ptis;
    zT_893.ptr = zT_891;
    zT_893.len = zT_892;
    zT_887 = zT_893;
    zF_48AC7B3A_markerWrite(zT_887);
    zT_895 = "k";
    zT_897 = 1;
    zT_896.ptr = zT_895;
    zT_896.len = zT_897;
    ptkm = zT_896;
    zT_898 = ptkm;
    zF_48AC7B3A_markerWrite(zT_898);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_900[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptkb[_i] = zT_900[_i];
        _i++;
    }
}
    zT_904 = node.kind;
    zT_908 = 0;
    zT_909 = (unsigned char*)((unsigned char*)ptkb) + zT_908;
    zT_910 = (unsigned int)(10) - zT_908;
    zT_911.ptr = zT_909;
    zT_911.len = zT_910;
    zT_903 = zT_911;
    zT_912 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_904), zT_903);
    ptkl = zT_912;
    zT_916 = (unsigned int)(9) - (unsigned int)((unsigned int)ptkl);
    ptks = zT_916;
    zT_921 = (unsigned char*)((unsigned char*)ptkb) + ptks;
    zT_922 = (unsigned int)(9) - ptks;
    zT_923.ptr = zT_921;
    zT_923.len = zT_922;
    zT_917 = zT_923;
    zF_48AC7B3A_markerWrite(zT_917);
    zT_925 = "c";
    zT_927 = 1;
    zT_926.ptr = zT_925;
    zT_926.len = zT_927;
    ptcm = zT_926;
    zT_928 = ptcm;
    zF_48AC7B3A_markerWrite(zT_928);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_930[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptcb[_i] = zT_930[_i];
        _i++;
    }
}
    zT_932 = child_type;
    zT_936 = 0;
    zT_937 = (unsigned char*)((unsigned char*)ptcb) + zT_936;
    zT_938 = (unsigned int)(10) - zT_936;
    zT_939.ptr = zT_937;
    zT_939.len = zT_938;
    zT_933 = zT_939;
    zT_940 = zF_A7504564_itoa(zT_932, zT_933);
    ptcl = zT_940;
    zT_944 = (unsigned int)(9) - (unsigned int)((unsigned int)ptcl);
    ptcs = zT_944;
    zT_949 = (unsigned char*)((unsigned char*)ptcb) + ptcs;
    zT_950 = (unsigned int)(9) - ptcs;
    zT_951.ptr = zT_949;
    zT_951.len = zT_950;
    zT_945 = zT_951;
    zF_48AC7B3A_markerWrite(zT_945);
    zT_953 = node.flags;
    zT_957 = (unsigned char)(zT_953 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_957;
    zT_959 = node.flags;
    zT_963 = (unsigned char)(zT_959 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_963;
    zT_964 = node.kind;
    if ((int)(zT_964 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_167; else goto z_bb_169;
    z_bb_166:
    zT_1049 = node.kind;
    if ((int)(zT_1049 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_170; else goto z_bb_171;
    z_bb_167:
    zT_970 = env->typereg;
    zT_971 = child_type;
    zT_972 = is_const;
    zT_973 = is_volatile;
    zT_975 = zF_0C0306D6_typeRegistryGetOrCr(zT_970, zT_971, zT_972, zT_973);
    ptr_tid = zT_975;
    zT_977 = "P";
    zT_979 = 1;
    zT_978.ptr = zT_977;
    zT_978.len = zT_979;
    ppm = zT_978;
    zT_980 = ppm;
    zF_48AC7B3A_markerWrite(zT_980);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_982[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb[_i] = zT_982[_i];
        _i++;
    }
}
    zT_984 = ptr_tid;
    zT_988 = 0;
    zT_989 = (unsigned char*)((unsigned char*)ppb) + zT_988;
    zT_990 = (unsigned int)(10) - zT_988;
    zT_991.ptr = zT_989;
    zT_991.len = zT_990;
    zT_985 = zT_991;
    zT_992 = zF_A7504564_itoa(zT_984, zT_985);
    ppl = zT_992;
    zT_996 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl);
    pps = zT_996;
    zT_1001 = (unsigned char*)((unsigned char*)ppb) + pps;
    zT_1002 = (unsigned int)(9) - pps;
    zT_1003.ptr = zT_1001;
    zT_1003.len = zT_1002;
    zT_997 = zT_1003;
    zF_48AC7B3A_markerWrite(zT_997);
    zT_1005 = "\n";
    zT_1007 = 1;
    zT_1006.ptr = zT_1005;
    zT_1006.len = zT_1007;
    pnl = zT_1006;
    zT_1008 = pnl;
    zF_48AC7B3A_markerWrite(zT_1008);
    return ptr_tid;
    goto z_bb_166;
    z_bb_169:
    zT_1010 = env->typereg;
    zT_1011 = child_type;
    zT_1012 = is_const;
    zT_1013 = is_volatile;
    zT_1015 = zF_827207A1_typeRegistryGetOrCr(zT_1010, zT_1011, zT_1012, zT_1013);
    ptr_tid2 = zT_1015;
    zT_1017 = "M";
    zT_1019 = 1;
    zT_1018.ptr = zT_1017;
    zT_1018.len = zT_1019;
    ppm2 = zT_1018;
    zT_1020 = ppm2;
    zF_48AC7B3A_markerWrite(zT_1020);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_1022[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb2[_i] = zT_1022[_i];
        _i++;
    }
}
    zT_1024 = ptr_tid2;
    zT_1028 = 0;
    zT_1029 = (unsigned char*)((unsigned char*)ppb2) + zT_1028;
    zT_1030 = (unsigned int)(10) - zT_1028;
    zT_1031.ptr = zT_1029;
    zT_1031.len = zT_1030;
    zT_1025 = zT_1031;
    zT_1032 = zF_A7504564_itoa(zT_1024, zT_1025);
    ppl2 = zT_1032;
    zT_1036 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl2);
    pps2 = zT_1036;
    zT_1041 = (unsigned char*)((unsigned char*)ppb2) + pps2;
    zT_1042 = (unsigned int)(9) - pps2;
    zT_1043.ptr = zT_1041;
    zT_1043.len = zT_1042;
    zT_1037 = zT_1043;
    zF_48AC7B3A_markerWrite(zT_1037);
    zT_1045 = "\n";
    zT_1047 = 1;
    zT_1046.ptr = zT_1045;
    zT_1046.len = zT_1047;
    pnl2 = zT_1046;
    zT_1048 = pnl2;
    zF_48AC7B3A_markerWrite(zT_1048);
    return ptr_tid2;
    z_bb_170:
    zT_1055 = node.flags;
    zT_1059 = (unsigned char)(zT_1055 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_1059;
    zT_1061 = env->typereg;
    zT_1062 = child_type;
    zT_1063 = is_const;
    zT_1065 = zF_8FC81A87_typeRegistryGetOrCr(zT_1061, zT_1062, zT_1063);
    sl_tid = zT_1065;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1067[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_e[_i] = zT_1067[_i];
        _i++;
    }
}
    zT_1069 = child_type;
    zT_1073 = 0;
    zT_1074 = (unsigned char*)((unsigned char*)sl_e) + zT_1073;
    zT_1075 = (unsigned int)(20) - zT_1073;
    zT_1076.ptr = zT_1074;
    zT_1076.len = zT_1075;
    zT_1070 = zT_1076;
    zT_1077 = zF_A7504564_itoa(zT_1069, zT_1070);
    sl_el = zT_1077;
    zT_1081 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_el);
    sl_es = zT_1081;
    zT_1083 = "SL:e";
    zT_1085 = 4;
    zT_1084.ptr = zT_1083;
    zT_1084.len = zT_1085;
    sm = zT_1084;
    zT_1086 = sm;
    zF_48AC7B3A_markerWrite(zT_1086);
    zT_1091 = (unsigned char*)((unsigned char*)sl_e) + sl_es;
    zT_1092 = (unsigned int)(19) - sl_es;
    zT_1093.ptr = zT_1091;
    zT_1093.len = zT_1092;
    zT_1087 = zT_1093;
    zF_48AC7B3A_markerWrite(zT_1087);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1095[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_r[_i] = zT_1095[_i];
        _i++;
    }
}
    zT_1097 = sl_tid;
    zT_1101 = 0;
    zT_1102 = (unsigned char*)((unsigned char*)sl_r) + zT_1101;
    zT_1103 = (unsigned int)(20) - zT_1101;
    zT_1104.ptr = zT_1102;
    zT_1104.len = zT_1103;
    zT_1098 = zT_1104;
    zT_1105 = zF_A7504564_itoa(zT_1097, zT_1098);
    sl_rl = zT_1105;
    zT_1109 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_rl);
    sl_rs = zT_1109;
    zT_1111 = "s";
    zT_1113 = 1;
    zT_1112.ptr = zT_1111;
    zT_1112.len = zT_1113;
    s2 = zT_1112;
    zT_1114 = s2;
    zF_48AC7B3A_markerWrite(zT_1114);
    zT_1119 = (unsigned char*)((unsigned char*)sl_r) + sl_rs;
    zT_1120 = (unsigned int)(19) - sl_rs;
    zT_1121.ptr = zT_1119;
    zT_1121.len = zT_1120;
    zT_1115 = zT_1121;
    zF_48AC7B3A_markerWrite(zT_1115);
    zT_1123 = "\n";
    zT_1125 = 1;
    zT_1124.ptr = zT_1123;
    zT_1124.len = zT_1125;
    s3 = zT_1124;
    zT_1126 = s3;
    zF_48AC7B3A_markerWrite(zT_1126);
    return sl_tid;
    z_bb_171:
    zT_1127 = node.kind;
    if ((int)(zT_1127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    zT_1133 = "OPTVOID:opt";
    zT_1135 = 11;
    zT_1134.ptr = zT_1133;
    zT_1134.len = zT_1135;
    optvd_m = zT_1134;
    zT_1136 = optvd_m;
    zT_1137 = child_type;
    zF_C914CB83_markerWriteInt(zT_1136, zT_1137);
    zT_1139 = env->typereg;
    zT_1140 = child_type;
    zT_1142 = zF_74A7234F_typeRegistryGetOrCr(zT_1139, zT_1140);
    optvd_tid = zT_1142;
    zT_1144 = "OPTVOID:optR";
    zT_1146 = 12;
    zT_1145.ptr = zT_1144;
    zT_1145.len = zT_1146;
    optvd_rm = zT_1145;
    zT_1147 = optvd_rm;
    zT_1148 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_1147, zT_1148);
    return optvd_tid;
    z_bb_173:
    zT_1149 = node.kind;
    if ((int)(zT_1149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_174; else goto z_bb_175;
    z_bb_174:
    zT_1155 = "T0";
    zT_1157 = 2;
    zT_1156.ptr = zT_1155;
    zT_1156.len = zT_1157;
    t0m = zT_1156;
    zT_1158 = t0m;
    zF_48AC7B3A_markerWrite(zT_1158);
    zT_1160 = "T1e";
    zT_1162 = 3;
    zT_1161.ptr = zT_1160;
    zT_1161.len = zT_1162;
    t1m = zT_1161;
    zT_1163 = t1m;
    zF_48AC7B3A_markerWrite(zT_1163);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1165[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t1b[_i] = zT_1165[_i];
        _i++;
    }
}
    zT_1167 = child_type;
    zT_1171 = 0;
    zT_1172 = (unsigned char*)((unsigned char*)t1b) + zT_1171;
    zT_1173 = (unsigned int)(20) - zT_1171;
    zT_1174.ptr = zT_1172;
    zT_1174.len = zT_1173;
    zT_1168 = zT_1174;
    zT_1175 = zF_A7504564_itoa(zT_1167, zT_1168);
    t1l = zT_1175;
    zT_1179 = (unsigned int)(19) - (unsigned int)((unsigned int)t1l);
    t1s = zT_1179;
    zT_1184 = (unsigned char*)((unsigned char*)t1b) + t1s;
    zT_1185 = (unsigned int)(19) - t1s;
    zT_1186.ptr = zT_1184;
    zT_1186.len = zT_1185;
    zT_1180 = zT_1186;
    zF_48AC7B3A_markerWrite(zT_1180);
    zT_1187 = node.child_1;
    zT_1188 = 0;
    if ((int)(zT_1187 != (unsigned int)zT_1188)) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    goto z_bb_159;
    z_bb_176:
    zT_1191 = env->store;
    zT_1192 = node.child_1;
    zT_1195 = zF_FCDD1D35_astStoreNodeAt(zT_1191, zT_1192);
    sz_node = zT_1195;
    zT_1197 = 0;
    arr_len = zT_1197;
    zT_1199 = 0;
    arr_resolved = zT_1199;
    zT_1200 = sz_node.kind;
    if ((int)(zT_1200 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_178; else goto z_bb_180;
    z_bb_177:
    return (unsigned int)(18);
    z_bb_178:
    zT_1205 = env->store;
    zT_1206 = node.child_1;
    zT_1209 = zF_678B9A72_astStoreIntValue(zT_1205, zT_1206);
    zT_1210 = (unsigned int)zT_1209;
    arr_len = zT_1210;
    zT_1211 = 1;
    arr_resolved = zT_1211;
    goto z_bb_179;
    z_bb_179:
    zT_1329 = "T2L";
    zT_1331 = 3;
    zT_1330.ptr = zT_1329;
    zT_1330.len = zT_1331;
    t2m = zT_1330;
    zT_1332 = t2m;
    zF_48AC7B3A_markerWrite(zT_1332);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1334[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t2b[_i] = zT_1334[_i];
        _i++;
    }
}
    zT_1336 = arr_len;
    zT_1340 = 0;
    zT_1341 = (unsigned char*)((unsigned char*)t2b) + zT_1340;
    zT_1342 = (unsigned int)(20) - zT_1340;
    zT_1343.ptr = zT_1341;
    zT_1343.len = zT_1342;
    zT_1337 = zT_1343;
    zT_1344 = zF_A7504564_itoa(zT_1336, zT_1337);
    t2l = zT_1344;
    zT_1348 = (unsigned int)(19) - (unsigned int)((unsigned int)t2l);
    t2s = zT_1348;
    zT_1353 = (unsigned char*)((unsigned char*)t2b) + t2s;
    zT_1354 = (unsigned int)(19) - t2s;
    zT_1355.ptr = zT_1353;
    zT_1355.len = zT_1354;
    zT_1349 = zT_1355;
    zF_48AC7B3A_markerWrite(zT_1349);
    if (arr_resolved) goto z_bb_225; else goto z_bb_226;
    z_bb_180:
    zT_1212 = sz_node.kind;
    if ((int)(zT_1212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_182; else goto z_bb_181;
    z_bb_181:
    zT_1218 = sz_node.kind;
    zT_1217 = zT_1218 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_183;
    z_bb_182:
    zT_1217 = 1;
    goto z_bb_183;
    z_bb_183:
    if (zT_1217) goto z_bb_184; else goto z_bb_186;
    z_bb_184:
    zT_1224 = env;
    zT_1225 = sz_node.child_0;
    zT_1229 = zF_6D0DD27D_evalConstU32Full(zT_1224, zT_1225, (unsigned int)(0));
    lhs = zT_1229;
    zT_1231 = env;
    zT_1232 = sz_node.child_1;
    zT_1236 = zF_6D0DD27D_evalConstU32Full(zT_1231, zT_1232, (unsigned int)(0));
    rhs = zT_1236;
    if ((int)(lhs != (unsigned int)(4294967295u))) goto z_bb_187; else goto z_bb_188;
    z_bb_185:
    goto z_bb_179;
    z_bb_186:
    zT_1250 = sz_node.kind;
    if ((int)(zT_1250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_196; else goto z_bb_195;
    z_bb_187:
    zT_1239 = rhs != (unsigned int)(4294967295u);
    goto z_bb_189;
    z_bb_188:
    zT_1239 = 0;
    goto z_bb_189;
    z_bb_189:
    if (zT_1239) goto z_bb_190; else goto z_bb_191;
    z_bb_190:
    zT_1242 = 1;
    arr_resolved = zT_1242;
    zT_1243 = sz_node.kind;
    if ((int)(zT_1243 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_192; else goto z_bb_194;
    z_bb_191:
    goto z_bb_185;
    z_bb_192:
    zT_1248 = lhs + rhs;
    arr_len = zT_1248;
    goto z_bb_193;
    z_bb_193:
    goto z_bb_191;
    z_bb_194:
    zT_1249 = lhs - rhs;
    arr_len = zT_1249;
    goto z_bb_193;
    z_bb_195:
    zT_1256 = sz_node.kind;
    zT_1255 = zT_1256 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_197;
    z_bb_196:
    zT_1255 = 1;
    goto z_bb_197;
    z_bb_197:
    if (zT_1255) goto z_bb_199; else goto z_bb_198;
    z_bb_198:
    zT_1262 = sz_node.kind;
    zT_1261 = zT_1262 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_200;
    z_bb_199:
    zT_1261 = 1;
    goto z_bb_200;
    z_bb_200:
    if (zT_1261) goto z_bb_201; else goto z_bb_203;
    z_bb_201:
    zT_1268 = env;
    zT_1269 = sz_node.child_0;
    zT_1273 = zF_6D0DD27D_evalConstU32Full(zT_1268, zT_1269, (unsigned int)(0));
    lhs = zT_1273;
    zT_1275 = env;
    zT_1276 = sz_node.child_1;
    zT_1280 = zF_6D0DD27D_evalConstU32Full(zT_1275, zT_1276, (unsigned int)(0));
    rhs = zT_1280;
    if ((int)(lhs != (unsigned int)(4294967295u))) goto z_bb_204; else goto z_bb_205;
    z_bb_202:
    goto z_bb_185;
    z_bb_203:
    zT_1303 = sz_node.kind;
    if ((int)(zT_1303 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_218; else goto z_bb_220;
    z_bb_204:
    zT_1283 = rhs != (unsigned int)(4294967295u);
    goto z_bb_206;
    z_bb_205:
    zT_1283 = 0;
    goto z_bb_206;
    z_bb_206:
    if (zT_1283) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_1286 = rhs != (unsigned int)(0);
    goto z_bb_209;
    z_bb_208:
    zT_1286 = 0;
    goto z_bb_209;
    z_bb_209:
    if (zT_1286) goto z_bb_210; else goto z_bb_211;
    z_bb_210:
    zT_1289 = 1;
    arr_resolved = zT_1289;
    zT_1290 = sz_node.kind;
    if ((int)(zT_1290 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_212; else goto z_bb_214;
    z_bb_211:
    goto z_bb_202;
    z_bb_212:
    zT_1295 = lhs * rhs;
    arr_len = zT_1295;
    goto z_bb_213;
    z_bb_213:
    goto z_bb_211;
    z_bb_214:
    zT_1296 = sz_node.kind;
    if ((int)(zT_1296 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_215; else goto z_bb_217;
    z_bb_215:
    zT_1301 = lhs / rhs;
    arr_len = zT_1301;
    goto z_bb_216;
    z_bb_216:
    goto z_bb_213;
    z_bb_217:
    zT_1302 = lhs % rhs;
    arr_len = zT_1302;
    goto z_bb_216;
    z_bb_218:
    zT_1309 = env;
    zT_1310 = node.child_1;
    zT_1314 = zF_6D0DD27D_evalConstU32Full(zT_1309, zT_1310, (unsigned int)(0));
    al = zT_1314;
    if ((int)(al != (unsigned int)(4294967295u))) goto z_bb_221; else goto z_bb_222;
    z_bb_219:
    goto z_bb_202;
    z_bb_220:
    zT_1319 = env;
    zT_1320 = node.child_1;
    zT_1324 = zF_6D0DD27D_evalConstU32Full(zT_1319, zT_1320, (unsigned int)(0));
    alf = zT_1324;
    if ((int)(alf != (unsigned int)(4294967295u))) goto z_bb_223; else goto z_bb_224;
    z_bb_221:
    arr_len = al;
    zT_1317 = 1;
    arr_resolved = zT_1317;
    goto z_bb_222;
    z_bb_222:
    goto z_bb_219;
    z_bb_223:
    arr_len = alf;
    zT_1327 = 1;
    arr_resolved = zT_1327;
    goto z_bb_224;
    z_bb_224:
    goto z_bb_219;
    z_bb_225:
    zT_1357 = env->typereg;
    zT_1358 = child_type;
    zT_1359 = arr_len;
    zT_1361 = zF_BA693C74_typeRegistryGetOrCr(zT_1357, zT_1358, zT_1359);
    at = zT_1361;
    zT_1363 = "T3a";
    zT_1365 = 3;
    zT_1364.ptr = zT_1363;
    zT_1364.len = zT_1365;
    t3m = zT_1364;
    zT_1366 = t3m;
    zF_48AC7B3A_markerWrite(zT_1366);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1368[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t3b[_i] = zT_1368[_i];
        _i++;
    }
}
    zT_1370 = at;
    zT_1374 = 0;
    zT_1375 = (unsigned char*)((unsigned char*)t3b) + zT_1374;
    zT_1376 = (unsigned int)(20) - zT_1374;
    zT_1377.ptr = zT_1375;
    zT_1377.len = zT_1376;
    zT_1371 = zT_1377;
    zT_1378 = zF_A7504564_itoa(zT_1370, zT_1371);
    t3l = zT_1378;
    zT_1382 = (unsigned int)(19) - (unsigned int)((unsigned int)t3l);
    t3s = zT_1382;
    zT_1387 = (unsigned char*)((unsigned char*)t3b) + t3s;
    zT_1388 = (unsigned int)(19) - t3s;
    zT_1389.ptr = zT_1387;
    zT_1389.len = zT_1388;
    zT_1383 = zT_1389;
    zF_48AC7B3A_markerWrite(zT_1383);
    if ((int)(at != (unsigned int)(18))) goto z_bb_227; else goto z_bb_229;
    z_bb_226:
    zT_1403 = 0;
    sz_is_inferred = zT_1403;
    zT_1404 = sz_node.kind;
    if ((int)(zT_1404 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_230; else goto z_bb_231;
    z_bb_227:
    zT_1393 = "A";
    zT_1395 = 1;
    zT_1394.ptr = zT_1393;
    zT_1394.len = zT_1395;
    am = zT_1394;
    zT_1396 = am;
    zF_48AC7B3A_markerWrite(zT_1396);
    goto z_bb_228;
    z_bb_228:
    return at;
    z_bb_229:
    zT_1398 = "a";
    zT_1400 = 1;
    zT_1399.ptr = zT_1398;
    zT_1399.len = zT_1400;
    am = zT_1399;
    zT_1401 = am;
    zF_48AC7B3A_markerWrite(zT_1401);
    goto z_bb_228;
    z_bb_230:
    zT_1410 = env->store;
    zT_1411 = node.child_1;
    zT_1414 = zF_53458827_astStoreIdentifier(zT_1410, zT_1411);
    sz_name = zT_1414;
    zT_1416 = env->interner;
    zT_1417 = sz_name;
    zT_1419 = zF_9134020D_stringInternerGet(zT_1416, zT_1417);
    sz_text = zT_1419;
    zT_1421 = sz_text.len;
    if ((int)(zT_1421 == (unsigned int)(1))) goto z_bb_232; else goto z_bb_233;
    z_bb_231:
    if ((int)(!sz_is_inferred)) goto z_bb_237; else goto z_bb_238;
    z_bb_232:
    zT_1425 = sz_text.ptr;
    zT_1426 = 0;
    zT_1427 = zT_1425[zT_1426];
    zT_1424 = zT_1427 == (unsigned char)(95);
    goto z_bb_234;
    z_bb_233:
    zT_1424 = 0;
    goto z_bb_234;
    z_bb_234:
    if (zT_1424) goto z_bb_235; else goto z_bb_236;
    z_bb_235:
    zT_1430 = 1;
    sz_is_inferred = zT_1430;
    goto z_bb_236;
    z_bb_236:
    goto z_bb_231;
    z_bb_237:
    zT_1432 = env->diag;
    zT_1433 = zT_1432.has_value;
    if (zT_1433) goto z_bb_239; else goto z_bb_240;
    z_bb_238:
    goto z_bb_177;
    z_bb_239:
    dg = zT_1432.value;
    zT_1435 = dg;
    zT_1436 = node_idx;
    zT_1437 = zF_4DD9DB2D_diagnosticCollector(zT_1435, zT_1436);
    if (zT_1437) goto z_bb_241; else goto z_bb_242;
    z_bb_240:
    goto z_bb_238;
    z_bb_241:
    zT_1439 = "array size is not a constant expression";
    zT_1441 = 39;
    zT_1440.ptr = zT_1439;
    zT_1440.len = zT_1441;
    asn_msg = zT_1440;
    zT_1442 = dg;
    zT_1445 = env->source_file_id;
    zT_1446 = sz_node.span_start;
    zT_1456 = sz_node.span_start;
    zT_1457 = sz_node.span_len;
    zT_1448 = asn_msg;
    zT_1460 = zF_C82559AC_diagnosticCollector(zT_1442, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3050_ARRAY_SIZE_NOT_CONSTANT)), zT_1445, zT_1446, (unsigned int)(zT_1456 + (unsigned int)((unsigned int)zT_1457)), zT_1448);
    (void)zT_1460;
    goto z_bb_242;
    z_bb_242:
    goto z_bb_240;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_406493CE_StructPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_406493CE_StructPayload zT_54;
    unsigned short zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_65 = 0;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode zT_70 = {0};
    zT_8143F551_AstKind zT_71;
    int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_4028D896_Arr_unsigned_char_2 zT_93;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_98;
    unsigned int zT_100 = 0;
    int zT_103;
    unsigned char* zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107 = 0;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned char* zT_116;
    unsigned int zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_4028D896_Arr_unsigned_char_2 zT_125;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    int zT_131;
    unsigned char* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    zT_338B7C76_TypeRegistry* zT_149;
    zT_2DF01B61_FieldEntry* zT_150;
    unsigned int zT_151;
    zT_2DF01B61_FieldEntry* zT_154;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_161;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    int zT_171;
    unsigned int zT_173;
    zT_33EF6BFB_TypeKind zT_174;
    zT_338B7C76_TypeRegistry* zT_180;
    zT_54FF90FA_TaggedUnionPayload* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_54FF90FA_TaggedUnionPayload zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned short zT_199;
    unsigned short zT_201;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_206;
    zT_6B0A7D14_AstStore* zT_208;
    unsigned int zT_209;
    unsigned int zT_214 = 0;
    zT_22A7C88B_AstNode zT_215 = {0};
    zT_8143F551_AstKind zT_216;
    int zT_221;
    unsigned int zT_222;
    int zT_223;
    zT_ABC1EBBE_TypeResolveEnv* zT_226;
    unsigned int zT_227;
    unsigned int zT_231 = 0;
    unsigned char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    unsigned char* zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned int zT_248;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_249;
    zT_4028D896_Arr_unsigned_char_2 zT_251;
    unsigned int zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_6B0A7D14_AstStore* zT_255;
    unsigned int zT_256;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_264 = 0;
    unsigned int zT_265 = 0;
    int zT_268;
    unsigned char* zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272 = 0;
    unsigned int zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    unsigned char* zT_281;
    unsigned int zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_4028D896_Arr_unsigned_char_2 zT_290;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    int zT_296;
    unsigned char* zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300 = 0;
    unsigned int zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned char* zT_309;
    unsigned int zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char* zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    zT_338B7C76_TypeRegistry* zT_319;
    zT_2DF01B61_FieldEntry* zT_320;
    unsigned int zT_321;
    zT_2DF01B61_FieldEntry* zT_324;
    unsigned char* zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned int zT_331;
    unsigned char* zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    unsigned char* zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    unsigned int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    int zT_346;
    unsigned int zT_348;
    zT_33EF6BFB_TypeKind zT_349;
    int zT_354;
    zT_33EF6BFB_TypeKind zT_355;
    zT_338B7C76_TypeRegistry* zT_361;
    zT_AF9231A2_UnionPayload* zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_AF9231A2_UnionPayload zT_365;
    unsigned short zT_366;
    zT_6B0A7D14_AstStore* zT_370;
    unsigned int zT_371;
    zT_6B0A7D14_AstStore* zT_373;
    unsigned int zT_374;
    unsigned int zT_379 = 0;
    zT_22A7C88B_AstNode zT_380 = {0};
    zT_8143F551_AstKind zT_381;
    int zT_386;
    unsigned int zT_387;
    int zT_388;
    zT_ABC1EBBE_TypeResolveEnv* zT_391;
    unsigned int zT_392;
    unsigned int zT_396 = 0;
    zT_338B7C76_TypeRegistry* zT_399;
    zT_2DF01B61_FieldEntry* zT_400;
    unsigned int zT_401;
    zT_2DF01B61_FieldEntry* zT_404;
    int zT_405;
    unsigned int zT_407;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    unsigned int fchild;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_4028D896_Arr_unsigned_char_2 b2_pb;
    unsigned int b2_pl;
    unsigned int b2_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_4028D896_Arr_unsigned_char_2 b2_tb;
    unsigned int b2_tl;
    unsigned int b2_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_21 = env->store;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_24)));
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_36 = env->store;
    zT_37 = decl.child_1;
    (void)zF_152E19CB_astStoreNodeExtraCh(zT_36, zT_37);
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    zT_44 = sty.kind;
    if ((int)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_50 = env->typereg;
    zT_51 = zT_50->st_items;
    zT_52 = sty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    sp = zT_54;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_174 = sty.kind;
    if ((int)(zT_174 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_55 = sp.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_55))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_59 = env->store;
    zT_60 = decl.child_1;
    zT_65 = zF_B10B1BC1_astStoreNodeExtraCh(zT_59, zT_60, (unsigned int)((unsigned int)fi2));
    fchild = zT_65;
    zT_67 = env->store;
    zT_68 = fchild;
    zT_70 = zF_FCDD1D35_astStoreNodeAt(zT_67, zT_68);
    fd = zT_70;
    zT_71 = fd.kind;
    if ((int)(zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_171 = 1;
    zT_173 = fi2 + (unsigned int)((unsigned int)zT_171);
    fi2 = zT_173;
    goto z_bb_6;
    z_bb_10:
    zT_77 = fd.child_0;
    zT_78 = 0;
    zT_76 = zT_77 != (unsigned int)zT_78;
    goto z_bb_12;
    z_bb_11:
    zT_76 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_76) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_81 = env;
    zT_82 = fd.child_0;
    zT_86 = zF_F2107C15_resolveTypeExprFull(zT_81, zT_82, (unsigned int)(0));
    ft = zT_86;
    zT_88 = "B2:p";
    zT_90 = 4;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    b2_pn = zT_89;
    zT_91 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_91);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_93[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_93[_i];
        _i++;
    }
}
    zT_97 = env->store;
    zT_98 = fchild;
    zT_100 = zF_8BA26B9E_astStoreNodePayload(zT_97, zT_98);
    zT_95 = zT_100;
    zT_103 = 0;
    zT_104 = (unsigned char*)((unsigned char*)b2_pb) + zT_103;
    zT_105 = (unsigned int)(20) - zT_103;
    zT_106.ptr = zT_104;
    zT_106.len = zT_105;
    zT_96 = zT_106;
    zT_107 = zF_A7504564_itoa(zT_95, zT_96);
    b2_pl = zT_107;
    zT_111 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_111;
    zT_116 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_117 = (unsigned int)(19) - b2_ps;
    zT_118.ptr = zT_116;
    zT_118.len = zT_117;
    zT_112 = zT_118;
    zF_48AC7B3A_markerWrite(zT_112);
    zT_120 = "t";
    zT_122 = 1;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    b2_tn = zT_121;
    zT_123 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_123);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_125[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_125[_i];
        _i++;
    }
}
    zT_127 = ft;
    zT_131 = 0;
    zT_132 = (unsigned char*)((unsigned char*)b2_tb) + zT_131;
    zT_133 = (unsigned int)(20) - zT_131;
    zT_134.ptr = zT_132;
    zT_134.len = zT_133;
    zT_128 = zT_134;
    zT_135 = zF_A7504564_itoa(zT_127, zT_128);
    b2_tl = zT_135;
    zT_139 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_139;
    zT_144 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_145 = (unsigned int)(19) - b2_ts;
    zT_146.ptr = zT_144;
    zT_146.len = zT_145;
    zT_140 = zT_146;
    zF_48AC7B3A_markerWrite(zT_140);
    if ((int)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_149 = env->typereg;
    zT_150 = zT_149->fe_items;
    zT_151 = sp.fields_start;
    zT_154 = zT_150 + (unsigned int)((unsigned int)((unsigned int)zT_151) + fi2);
    zT_154->type_id = ft;
    zT_156 = "FSW:n";
    zT_158 = 5;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    fsw_nm = zT_157;
    zT_159 = fsw_nm;
    zT_161 = sp.fields_start;
    zF_C914CB83_markerWriteInt(zT_159, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_161) + fi2)));
    zT_166 = "FSW:t";
    zT_168 = 5;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    fsw_tm = zT_167;
    zT_169 = fsw_tm;
    zT_170 = ft;
    zF_C914CB83_markerWriteInt(zT_169, zT_170);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_180 = env->typereg;
    zT_181 = zT_180->tu_items;
    zT_182 = sty.payload_idx;
    zT_183 = (unsigned int)zT_182;
    zT_184 = zT_181[zT_183];
    tp = zT_184;
    zT_186 = "TUI:fs";
    zT_188 = 6;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    tui_fsm = zT_187;
    zT_189 = tui_fsm;
    zT_191 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_189, (unsigned int)((unsigned int)zT_191));
    zT_194 = "TUI:fc";
    zT_196 = 6;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    tui_fcm = zT_195;
    zT_197 = tui_fcm;
    zT_199 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_197, (unsigned int)((unsigned int)zT_199));
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_349 = sty.kind;
    if ((int)(zT_349 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_33; else goto z_bb_32;
    z_bb_20:
    zT_201 = tp.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_201))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_205 = env->store;
    zT_208 = env->store;
    zT_209 = decl.child_1;
    zT_214 = zF_B10B1BC1_astStoreNodeExtraCh(zT_208, zT_209, (unsigned int)((unsigned int)fi2));
    zT_206 = zT_214;
    zT_215 = zF_FCDD1D35_astStoreNodeAt(zT_205, zT_206);
    fd = zT_215;
    zT_216 = fd.kind;
    if ((int)(zT_216 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_346 = 1;
    zT_348 = fi2 + (unsigned int)((unsigned int)zT_346);
    fi2 = zT_348;
    goto z_bb_20;
    z_bb_24:
    zT_222 = fd.child_0;
    zT_223 = 0;
    zT_221 = zT_222 != (unsigned int)zT_223;
    goto z_bb_26;
    z_bb_25:
    zT_221 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_221) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_226 = env;
    zT_227 = fd.child_0;
    zT_231 = zF_F2107C15_resolveTypeExprFull(zT_226, zT_227, (unsigned int)(0));
    ft = zT_231;
    zT_233 = "DFT:n";
    zT_235 = 5;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    dft_nm = zT_234;
    zT_236 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_236, (unsigned int)((unsigned int)fi2));
    zT_240 = "DFT:t";
    zT_242 = 5;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    dft_tm = zT_241;
    zT_243 = dft_tm;
    zT_244 = ft;
    zF_C914CB83_markerWriteInt(zT_243, zT_244);
    zT_246 = "B2:p";
    zT_248 = 4;
    zT_247.ptr = zT_246;
    zT_247.len = zT_248;
    b2_pn = zT_247;
    zT_249 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_249);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_251[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_251[_i];
        _i++;
    }
}
    zT_255 = env->store;
    zT_258 = env->store;
    zT_259 = decl.child_1;
    zT_264 = zF_B10B1BC1_astStoreNodeExtraCh(zT_258, zT_259, (unsigned int)((unsigned int)fi2));
    zT_256 = zT_264;
    zT_265 = zF_8BA26B9E_astStoreNodePayload(zT_255, zT_256);
    zT_253 = zT_265;
    zT_268 = 0;
    zT_269 = (unsigned char*)((unsigned char*)b2_pb) + zT_268;
    zT_270 = (unsigned int)(20) - zT_268;
    zT_271.ptr = zT_269;
    zT_271.len = zT_270;
    zT_254 = zT_271;
    zT_272 = zF_A7504564_itoa(zT_253, zT_254);
    b2_pl = zT_272;
    zT_276 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_276;
    zT_281 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_282 = (unsigned int)(19) - b2_ps;
    zT_283.ptr = zT_281;
    zT_283.len = zT_282;
    zT_277 = zT_283;
    zF_48AC7B3A_markerWrite(zT_277);
    zT_285 = "t";
    zT_287 = 1;
    zT_286.ptr = zT_285;
    zT_286.len = zT_287;
    b2_tn = zT_286;
    zT_288 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_288);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_290[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_290[_i];
        _i++;
    }
}
    zT_292 = ft;
    zT_296 = 0;
    zT_297 = (unsigned char*)((unsigned char*)b2_tb) + zT_296;
    zT_298 = (unsigned int)(20) - zT_296;
    zT_299.ptr = zT_297;
    zT_299.len = zT_298;
    zT_293 = zT_299;
    zT_300 = zF_A7504564_itoa(zT_292, zT_293);
    b2_tl = zT_300;
    zT_304 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_304;
    zT_309 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_310 = (unsigned int)(19) - b2_ts;
    zT_311.ptr = zT_309;
    zT_311.len = zT_310;
    zT_305 = zT_311;
    zF_48AC7B3A_markerWrite(zT_305);
    zT_313 = "DTWR\n";
    zT_315 = 5;
    zT_314.ptr = zT_313;
    zT_314.len = zT_315;
    dtwr_m = zT_314;
    zT_316 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_316);
    if ((int)(ft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_319 = env->typereg;
    zT_320 = zT_319->fe_items;
    zT_321 = tp.fields_start;
    zT_324 = zT_320 + (unsigned int)((unsigned int)((unsigned int)zT_321) + fi2);
    zT_324->type_id = ft;
    zT_326 = "FTW:n";
    zT_328 = 5;
    zT_327.ptr = zT_326;
    zT_327.len = zT_328;
    ftw_nm = zT_327;
    zT_329 = ftw_nm;
    zT_331 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_329, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_331) + fi2)));
    zT_336 = "FTW:t";
    zT_338 = 5;
    zT_337.ptr = zT_336;
    zT_337.len = zT_338;
    ftw_tm = zT_337;
    zT_339 = ftw_tm;
    zT_340 = ft;
    zF_C914CB83_markerWriteInt(zT_339, zT_340);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_342 = "DTSK\n";
    zT_344 = 5;
    zT_343.ptr = zT_342;
    zT_343.len = zT_344;
    dtsk_m = zT_343;
    zT_345 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_345);
    goto z_bb_30;
    z_bb_32:
    zT_355 = sty.kind;
    zT_354 = zT_355 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_34;
    z_bb_33:
    zT_354 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_354) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_361 = env->typereg;
    zT_362 = zT_361->un_items;
    zT_363 = sty.payload_idx;
    zT_364 = (unsigned int)zT_363;
    zT_365 = zT_362[zT_364];
    up = zT_365;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_18;
    z_bb_37:
    zT_366 = up.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_366))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_370 = env->store;
    zT_373 = env->store;
    zT_374 = decl.child_1;
    zT_379 = zF_B10B1BC1_astStoreNodeExtraCh(zT_373, zT_374, (unsigned int)((unsigned int)fi2));
    zT_371 = zT_379;
    zT_380 = zF_FCDD1D35_astStoreNodeAt(zT_370, zT_371);
    fd = zT_380;
    zT_381 = fd.kind;
    if ((int)(zT_381 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_405 = 1;
    zT_407 = fi2 + (unsigned int)((unsigned int)zT_405);
    fi2 = zT_407;
    goto z_bb_37;
    z_bb_41:
    zT_387 = fd.child_0;
    zT_388 = 0;
    zT_386 = zT_387 != (unsigned int)zT_388;
    goto z_bb_43;
    z_bb_42:
    zT_386 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_386) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_391 = env;
    zT_392 = fd.child_0;
    zT_396 = zF_F2107C15_resolveTypeExprFull(zT_391, zT_392, (unsigned int)(0));
    ft = zT_396;
    if ((int)(ft != (unsigned int)(18))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_40;
    z_bb_46:
    zT_399 = env->typereg;
    zT_400 = zT_399->fe_items;
    zT_401 = up.fields_start;
    zT_404 = zT_400 + (unsigned int)((unsigned int)((unsigned int)zT_401) + fi2);
    zT_404->type_id = ft;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_45;
}

/* varDeclInitNeedsNameCache */
int zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    return (int)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    zT_6E8D187B_ModuleEntry zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    int zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    int zT_64 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_66;
    unsigned int zT_67;
    unsigned int zT_71 = 0;
    zT_6E8D187B_ModuleEntry* zT_75;
    zT_6E8D187B_ModuleEntry zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_84 = 0;
    zT_79FAE712_u64 zT_86;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_79FAE712_u64 zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_96;
    zT_6E8D187B_ModuleEntry zT_97;
    zT_6B0A7D14_AstStore* zT_99;
    unsigned int zT_100;
    unsigned int zT_102 = 0;
    zT_D4761958_Opt_858 zT_103 = {0};
    unsigned char zT_104;
    int zT_106;
    unsigned int zT_108;
    int zT_109;
    unsigned int zT_111;
    unsigned int ci;
    unsigned int cr;
    unsigned int cd_n;
    unsigned int cdi;
    unsigned int cd_i;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_D4761958_Opt_858 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((int)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    if ((int)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_109 = 1;
    zT_111 = ci + (unsigned int)((unsigned int)zT_109);
    ci = zT_111;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_17 = mods.ptr;
    zT_18 = zT_17[ci];
    zT_19 = zT_18.source_file_id;
    env->source_file_id = zT_19;
    zT_21 = env->store;
    zT_22 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    zT_26 = env->store;
    zT_27 = cr;
    zT_29 = zF_152E19CB_astStoreNodeExtraCh(zT_26, zT_27);
    cd_n = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    cdi = zT_32;
    goto z_bb_7;
    z_bb_7:
    if ((int)(cdi < (unsigned int)((unsigned int)cd_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_37 = cr;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)cdi));
    cd_i = zT_41;
    zT_43 = env->store;
    zT_44 = cd_i;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_43, zT_44);
    cdcl = zT_46;
    zT_47 = cdcl.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_106 = 1;
    zT_108 = cdi + (unsigned int)((unsigned int)zT_106);
    cdi = zT_108;
    goto z_bb_7;
    z_bb_11:
    zT_53 = cdcl.child_1;
    zT_52 = zT_53 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_52 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_52) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = env->store;
    zT_58 = cdcl.child_1;
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    cdinit = zT_61;
    zT_62 = cdinit.kind;
    zT_64 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_62);
    if (zT_64) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_66 = env;
    zT_67 = cdcl.child_1;
    zT_71 = zF_F2107C15_resolveTypeExprFull(zT_66, zT_67, (unsigned int)(0));
    cdtype = zT_71;
    if ((int)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_75 = mods.ptr;
    zT_76 = zT_75[ci];
    zT_77 = zT_76.id;
    zT_81 = env->store;
    zT_82 = cd_i;
    zT_84 = zF_8BA26B9E_astStoreNodePayload(zT_81, zT_82);
    zT_86 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_77) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_84);
    ck = zT_86;
    zT_87 = env->typereg;
    zT_88 = ck;
    zT_89 = cdtype;
    zF_5E95558D_nameCachePut(zT_87, zT_88, zT_89);
    zT_92 = env->symbol_reg;
    zT_96 = mods.ptr;
    zT_97 = zT_96[ci];
    zT_93 = zT_97.id;
    zT_99 = env->store;
    zT_100 = cd_i;
    zT_102 = zF_8BA26B9E_astStoreNodePayload(zT_99, zT_100);
    zT_94 = zT_102;
    zT_103 = zF_A398987E_symbolRegistryQuali(zT_92, zT_93, zT_94);
    cdsym = zT_103;
    zT_104 = cdsym.has_value;
    if (zT_104) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_D4761958_Opt_858 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_072B53A6_ModuleRegistry* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_64 = 0;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_ABC1EBBE_TypeResolveEnv* zT_68;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_78 = 0;
    unsigned int zT_80;
    zT_D4761958_Opt_858 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((int)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((int)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_34 = env->store;
    zT_35 = fd.child_1;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    fi = zT_38;
    zT_39 = fi.kind;
    if ((int)(zT_39 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_46 = env->store;
    zT_47 = fi.child_0;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_46, zT_47);
    fb = zT_50;
    zT_51 = fb.kind;
    if ((int)(zT_51 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_58 = module_reg;
    zT_60 = env->store;
    zT_61 = fi.child_0;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_59 = zT_64;
    zT_65 = zF_A258E183_moduleRegistryPathT(zT_58, zT_59);
    t2 = zT_65;
    zT_66 = t2.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_68 = env;
    zT_69 = module_reg;
    zT_70 = importer_mod_id;
    zT_71 = m2;
    zT_74 = env->store;
    zT_75 = fd.child_1;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_72 = zT_78;
    zT_80 = depth + (unsigned int)(1);
    env = zT_68;
    module_reg = zT_69;
    importer_mod_id = zT_70;
    target_mod_id = zT_71;
    field_name_id = zT_72;
    depth = zT_80;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_36 = 0;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_55 = {0};
    zT_8143F551_AstKind zT_56;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_072B53A6_ModuleRegistry* zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_79 = 0;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    zT_ABC1EBBE_TypeResolveEnv* zT_84;
    zT_072B53A6_ModuleRegistry* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_6E8D187B_ModuleEntry* zT_90;
    zT_6E8D187B_ModuleEntry zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_97 = 0;
    unsigned int zT_99 = 0;
    zT_3D7259E2_SymbolRegistry* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_6E8D187B_ModuleEntry* zT_107;
    zT_6E8D187B_ModuleEntry zT_108;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    unsigned int zT_113 = 0;
    zT_D4761958_Opt_858 zT_114 = {0};
    unsigned char zT_115;
    zT_6E8D187B_ModuleEntry* zT_118;
    zT_6E8D187B_ModuleEntry zT_119;
    unsigned int zT_120;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_127 = 0;
    zT_79FAE712_u64 zT_129;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    int zT_134;
    unsigned int zT_136;
    int zT_137;
    unsigned int zT_139;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_D4761958_Opt_858 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((int)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_137 = 1;
    zT_139 = mi + (unsigned int)((unsigned int)zT_137);
    mi = zT_139;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = env->store;
    zT_17 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    zT_21 = env->store;
    zT_22 = root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_21, zT_22);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = env->store;
    zT_32 = root;
    zT_36 = zF_B10B1BC1_astStoreNodeExtraCh(zT_31, zT_32, (unsigned int)((unsigned int)di));
    decl_idx = zT_36;
    zT_38 = env->store;
    zT_39 = decl_idx;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    decl = zT_41;
    zT_42 = decl.kind;
    if ((int)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_134 = 1;
    zT_136 = di + (unsigned int)((unsigned int)zT_134);
    di = zT_136;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = decl.child_1;
    if ((int)(zT_47 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_51 = env->store;
    zT_52 = decl.child_1;
    zT_55 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    init = zT_55;
    zT_56 = init.kind;
    if ((int)(zT_56 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_62 = env->store;
    zT_63 = init.child_0;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_62, zT_63);
    base = zT_66;
    zT_67 = base.kind;
    if ((int)(zT_67 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_73 = module_reg;
    zT_75 = env->store;
    zT_76 = init.child_0;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_75, zT_76);
    zT_74 = zT_79;
    zT_80 = zF_A258E183_moduleRegistryPathT(zT_73, zT_74);
    target = zT_80;
    zT_81 = target.has_value;
    if (zT_81) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_84 = env;
    zT_85 = module_reg;
    zT_90 = mods.ptr;
    zT_91 = zT_90[mi];
    zT_86 = zT_91.id;
    zT_87 = mtid;
    zT_93 = env->store;
    zT_94 = decl.child_1;
    zT_97 = zF_8BA26B9E_astStoreNodePayload(zT_93, zT_94);
    zT_88 = zT_97;
    zT_99 = zF_E8C2AADA_resolveImportFieldA(zT_84, zT_85, zT_86, zT_87, zT_88, (unsigned int)(0));
    resolved = zT_99;
    if ((int)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_103 = env->symbol_reg;
    zT_107 = mods.ptr;
    zT_108 = zT_107[mi];
    zT_104 = zT_108.id;
    zT_110 = env->store;
    zT_111 = decl_idx;
    zT_113 = zF_8BA26B9E_astStoreNodePayload(zT_110, zT_111);
    zT_105 = zT_113;
    zT_114 = zF_A398987E_symbolRegistryQuali(zT_103, zT_104, zT_105);
    sym = zT_114;
    zT_115 = sym.has_value;
    if (zT_115) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_118 = mods.ptr;
    zT_119 = zT_118[mi];
    zT_120 = zT_119.id;
    zT_124 = env->store;
    zT_125 = decl_idx;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_124, zT_125);
    zT_129 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_120) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_127);
    ck = zT_129;
    zT_130 = env->typereg;
    zT_131 = ck;
    zT_132 = resolved;
    zF_5E95558D_nameCachePut(zT_130, zT_131, zT_132);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    int zT_49;
    unsigned int zT_50;
    int zT_51;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_22A7C88B_AstNode zT_58 = {0};
    zT_8143F551_AstKind zT_59;
    int zT_64;
    zT_8143F551_AstKind zT_65;
    zT_ABC1EBBE_TypeResolveEnv* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_6E8D187B_ModuleEntry* zT_73;
    zT_6E8D187B_ModuleEntry zT_74;
    int zT_76;
    unsigned int zT_78;
    int zT_79;
    unsigned int zT_81;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((int)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_79 = 1;
    zT_81 = mi + (unsigned int)((unsigned int)zT_79);
    mi = zT_81;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[mi];
    zT_16 = zT_15.source_file_id;
    env->source_file_id = zT_16;
    zT_18 = env->store;
    zT_19 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = root;
    zT_38 = zF_B10B1BC1_astStoreNodeExtraCh(zT_33, zT_34, (unsigned int)((unsigned int)di));
    decl_idx = zT_38;
    zT_40 = env->store;
    zT_41 = decl_idx;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    decl = zT_43;
    zT_44 = decl.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_76 = 1;
    zT_78 = di + (unsigned int)((unsigned int)zT_76);
    di = zT_78;
    goto z_bb_7;
    z_bb_11:
    zT_50 = decl.child_1;
    zT_51 = 0;
    zT_49 = zT_50 != (unsigned int)zT_51;
    goto z_bb_13;
    z_bb_12:
    zT_49 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = env->store;
    zT_55 = decl.child_1;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    init = zT_58;
    zT_59 = init.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_65 = init.kind;
    zT_64 = zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_64 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_64) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_70 = env;
    zT_73 = mods.ptr;
    zT_74 = zT_73[mi];
    zT_71 = zT_74.id;
    zT_72 = decl_idx;
    zF_F5C3193B_resolveDeclAggregat(zT_70, zT_71, zT_72);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6E8D187B_ModuleEntry* zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_47 = {0};
    zT_8143F551_AstKind zT_48;
    zT_6B0A7D14_AstStore* zT_54;
    zT_90A00C33_anon_229378 zT_55;
    zT_243D6A41_FnProto* zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    unsigned int zT_61;
    zT_243D6A41_FnProto zT_62;
    zT_3D7259E2_SymbolRegistry* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    zT_D4761958_Opt_858 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_75;
    zT_939EE900_Arr_unsigned_int_1 zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    int zT_83;
    zT_ABC1EBBE_TypeResolveEnv* zT_86;
    unsigned int zT_87;
    unsigned int zT_91 = 0;
    int zT_94;
    zT_8EED1867_ResolvedTypeTable* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_106;
    unsigned char zT_108;
    unsigned char zT_109;
    unsigned char zT_114;
    zT_993A6923_Arr_unsigned_int_64 zT_116;
    unsigned int zT_118;
    unsigned short zT_119;
    char* zT_123;
    unsigned int zT_124;
    char* zT_125;
    unsigned int zT_126;
    char* zT_127;
    unsigned int zT_128;
    unsigned short zT_130;
    unsigned int zT_134;
    unsigned short zT_138;
    zT_79FAE712_u64 zT_140;
    zT_6B0A7D14_AstStore* zT_142;
    zT_79FAE712_u64 zT_143;
    unsigned int zT_145 = 0;
    int zT_147;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_152;
    unsigned int zT_153;
    zT_6B0A7D14_AstStore* zT_155;
    zT_79FAE712_u64 zT_156;
    unsigned int zT_160 = 0;
    zT_22A7C88B_AstNode zT_161 = {0};
    unsigned int zT_162;
    int zT_163;
    zT_ABC1EBBE_TypeResolveEnv* zT_166;
    unsigned int zT_167;
    unsigned int zT_171 = 0;
    char* zT_174;
    unsigned int zT_175;
    char* zT_176;
    unsigned int zT_177;
    char* zT_178;
    unsigned int zT_179;
    unsigned int zT_182;
    zT_8EED1867_ResolvedTypeTable* zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    int zT_189;
    unsigned int zT_191;
    zT_338B7C76_TypeRegistry* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned int zT_197;
    zT_338B7C76_TypeRegistry* zT_199;
    unsigned int zT_200;
    int zT_203;
    unsigned int zT_205;
    zT_338B7C76_TypeRegistry* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned char zT_210;
    unsigned char zT_211;
    unsigned int zT_212;
    unsigned short zT_213;
    unsigned int zT_214;
    unsigned char zT_215;
    zT_6E8D187B_ModuleEntry* zT_218;
    zT_6E8D187B_ModuleEntry zT_219;
    int zT_222;
    unsigned int zT_225 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_3D7259E2_SymbolRegistry* zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    zT_6E8D187B_ModuleEntry* zT_234;
    zT_6E8D187B_ModuleEntry zT_235;
    zT_D4761958_Opt_858 zT_238 = {0};
    unsigned char zT_239;
    zT_8143F551_AstKind zT_241;
    int zT_246;
    unsigned int zT_247;
    int zT_248;
    zT_ABC1EBBE_TypeResolveEnv* zT_251;
    unsigned int zT_252;
    unsigned int zT_256 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_8EED1867_ResolvedTypeTable* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_3D7259E2_SymbolRegistry* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    zT_6E8D187B_ModuleEntry* zT_271;
    zT_6E8D187B_ModuleEntry zT_272;
    zT_6B0A7D14_AstStore* zT_274;
    unsigned int zT_275;
    unsigned int zT_277 = 0;
    zT_D4761958_Opt_858 zT_278 = {0};
    unsigned char zT_279;
    int zT_281;
    unsigned int zT_283;
    int zT_284;
    unsigned int zT_286;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_D4761958_Opt_858 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    zT_993A6923_Arr_unsigned_int_64 ptypes_buf;
    unsigned int ptypes_n;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int fn_start;
    unsigned int pf;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    unsigned int tid;
    zT_D4761958_Opt_858 sym;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((int)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_284 = 1;
    zT_286 = mi + (unsigned int)((unsigned int)zT_284);
    mi = zT_286;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_18 = mods.ptr;
    zT_19 = zT_18[mi];
    zT_20 = zT_19.source_file_id;
    env->source_file_id = zT_20;
    zT_22 = env->store;
    zT_23 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_27 = env->store;
    zT_28 = root;
    zT_30 = zF_152E19CB_astStoreNodeExtraCh(zT_27, zT_28);
    decls_n = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    di = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_38 = root;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)di));
    decl_idx = zT_42;
    zT_44 = env->store;
    zT_45 = decl_idx;
    zT_47 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    decl = zT_47;
    zT_48 = decl.kind;
    if ((int)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_281 = 1;
    zT_283 = di + (unsigned int)((unsigned int)zT_281);
    di = zT_283;
    goto z_bb_7;
    z_bb_11:
    zT_54 = env->store;
    zT_55 = zT_54->fn_protos;
    zT_56 = zT_55.items;
    zT_57 = env->store;
    zT_58 = decl_idx;
    zT_60 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    zT_61 = (unsigned int)zT_60;
    zT_62 = zT_56[zT_61];
    proto = zT_62;
    zT_64 = env->symbol_reg;
    zT_68 = mods.ptr;
    zT_69 = zT_68[mi];
    zT_65 = zT_69.id;
    zT_66 = proto.name_id;
    zT_72 = zF_A398987E_symbolRegistryQuali(zT_64, zT_65, zT_66);
    sym_check = zT_72;
    zT_73 = sym_check.has_value;
    if (zT_73) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_241 = decl.kind;
    if ((int)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_14:
    sc = sym_check.value;
    zT_75 = sc->type_id;
    if ((int)(zT_75 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_80 = 1;
    zT_81 = 0;
    zT_79[zT_81] = zT_80;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_79[_i];
        _i++;
    }
}
    zT_82 = proto.return_type_node;
    zT_83 = 0;
    if ((int)(zT_82 != (unsigned int)zT_83)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_86 = env;
    zT_87 = proto.return_type_node;
    zT_91 = zF_F2107C15_resolveTypeExprFull(zT_86, zT_87, (unsigned int)(0));
    rtype = zT_91;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_100 = 0;
    is_ext = zT_100;
    zT_101 = decl.flags;
    if ((int)((unsigned char)(zT_101 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_94 = 0;
    rt_box[zT_94] = rtype;
    zT_95 = resolved_types;
    zT_96 = proto.return_type_node;
    zT_97 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_95, zT_96, zT_97);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_106 = 1;
    is_ext = zT_106;
    goto z_bb_23;
    z_bb_23:
    zT_108 = 0;
    is_variadic = zT_108;
    zT_109 = decl.flags;
    if ((int)((unsigned char)(zT_109 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_114 = 1;
    is_variadic = zT_114;
    goto z_bb_25;
    z_bb_25:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_116[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        ptypes_buf[_i] = zT_116[_i];
        _i++;
    }
}
    zT_118 = 0;
    ptypes_n = zT_118;
    zT_119 = proto.params_count;
    if ((int)((unsigned int)((unsigned int)zT_119) > (unsigned int)(64))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_123 = "panic: ";
    zT_124 = 7;
    fwrite(zT_123, 1, zT_124, stderr);
    zT_125 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_126 = 72;
    fwrite(zT_125, 1, zT_126, stderr);
    zT_127 = "\n";
    zT_128 = 1;
    fwrite(zT_127, 1, zT_128, stderr);
    pal_trap();
    z_bb_27:
    zT_130 = proto.params_count;
    if ((int)(zT_130 > (unsigned short)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_134 = proto.params_start;
    zT_138 = proto.params_count;
    zT_140 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_134) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_138);
    p_payload = zT_140;
    zT_142 = env->store;
    zT_143 = p_payload;
    zT_145 = zF_03CE8CAB_astStoreGetExtraChi(zT_142, zT_143);
    pnodes_n = zT_145;
    zT_147 = 0;
    zT_148 = (unsigned int)zT_147;
    pi = zT_148;
    goto z_bb_30;
    z_bb_29:
    zT_193 = env->typereg;
    zT_194 = zT_193->xt_len;
    zT_195 = (unsigned int)zT_194;
    fn_start = zT_195;
    zT_197 = 0;
    pf = zT_197;
    goto z_bb_40;
    z_bb_30:
    if ((int)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_152 = env->store;
    zT_155 = env->store;
    zT_156 = p_payload;
    zT_160 = zF_E5B10421_astStoreGetExtraChi(zT_155, zT_156, (unsigned int)((unsigned int)pi));
    zT_153 = zT_160;
    zT_161 = zF_FCDD1D35_astStoreNodeAt(zT_152, zT_153);
    pnode = zT_161;
    zT_162 = pnode.child_0;
    zT_163 = 0;
    if ((int)(zT_162 != (unsigned int)zT_163)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_189 = 1;
    zT_191 = pi + (unsigned int)((unsigned int)zT_189);
    pi = zT_191;
    goto z_bb_30;
    z_bb_34:
    zT_166 = env;
    zT_167 = pnode.child_0;
    zT_171 = zF_F2107C15_resolveTypeExprFull(zT_166, zT_167, (unsigned int)(0));
    ptype = zT_171;
    if ((int)(ptypes_n >= (unsigned int)(64))) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    zT_174 = "panic: ";
    zT_175 = 7;
    fwrite(zT_174, 1, zT_175, stderr);
    zT_176 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_177 = 72;
    fwrite(zT_176, 1, zT_177, stderr);
    zT_178 = "\n";
    zT_179 = 1;
    fwrite(zT_178, 1, zT_179, stderr);
    pal_trap();
    z_bb_37:
    ptypes_buf[ptypes_n] = ptype;
    zT_182 = ptypes_n + (unsigned int)(1);
    ptypes_n = zT_182;
    if ((int)(ptype != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_185 = resolved_types;
    zT_186 = pnode.child_0;
    zT_187 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_185, zT_186, zT_187);
    goto z_bb_39;
    z_bb_39:
    goto z_bb_35;
    z_bb_40:
    if ((int)(pf < ptypes_n)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_199 = env->typereg;
    zT_200 = ptypes_buf[pf];
    zF_4C03AE3D_xtAppend(zT_199, zT_200);
    goto z_bb_43;
    z_bb_42:
    zT_207 = env->typereg;
    zT_208 = proto.name_id;
    zT_218 = mods.ptr;
    zT_219 = zT_218[mi];
    zT_209 = zT_219.id;
    zT_210 = is_ext;
    zT_211 = is_variadic;
    zT_212 = fn_start;
    zT_213 = proto.params_count;
    zT_222 = 0;
    zT_214 = rt_box[zT_222];
    zT_215 = proto.call_conv;
    zT_225 = zF_474336D7_typeRegistryGetOrCr(zT_207, zT_208, zT_209, zT_210, zT_211, zT_212, zT_213, zT_214, zT_215);
    tid = zT_225;
    zT_226 = resolved_types;
    zT_227 = decl_idx;
    zT_228 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_226, zT_227, zT_228);
    zT_230 = env->symbol_reg;
    zT_234 = mods.ptr;
    zT_235 = zT_234[mi];
    zT_231 = zT_235.id;
    zT_232 = proto.name_id;
    zT_238 = zF_A398987E_symbolRegistryQuali(zT_230, zT_231, zT_232);
    sym = zT_238;
    zT_239 = sym.has_value;
    if (zT_239) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_203 = 1;
    zT_205 = pf + (unsigned int)((unsigned int)zT_203);
    pf = zT_205;
    goto z_bb_40;
    z_bb_44:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_247 = decl.child_0;
    zT_248 = 0;
    zT_246 = zT_247 != (unsigned int)zT_248;
    goto z_bb_48;
    z_bb_47:
    zT_246 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_246) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_251 = env;
    zT_252 = decl.child_0;
    zT_256 = zF_F2107C15_resolveTypeExprFull(zT_251, zT_252, (unsigned int)(0));
    vtype = zT_256;
    if ((int)(vtype != (unsigned int)(18))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_12;
    z_bb_51:
    zT_259 = resolved_types;
    zT_260 = decl.child_0;
    zT_261 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_259, zT_260, zT_261);
    zT_263 = resolved_types;
    zT_264 = decl_idx;
    zT_265 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_263, zT_264, zT_265);
    zT_267 = env->symbol_reg;
    zT_271 = mods.ptr;
    zT_272 = zT_271[mi];
    zT_268 = zT_272.id;
    zT_274 = env->store;
    zT_275 = decl_idx;
    zT_277 = zF_8BA26B9E_astStoreNodePayload(zT_274, zT_275);
    zT_269 = zT_277;
    zT_278 = zF_A398987E_symbolRegistryQuali(zT_267, zT_268, zT_269);
    sym = zT_278;
    zT_279 = sym.has_value;
    if (zT_279) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_52;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_9;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_10 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_12;
    unsigned int zT_14;
    zT_7334F4FE_Opt_225 zT_15;
    zT_F6B96876_Opt_395 zT_16 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_17;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_18;
    zT_ABC1EBBE_TypeResolveEnv* zT_20;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_21;
    zT_072B53A6_ModuleRegistry* zT_22;
    zT_ABC1EBBE_TypeResolveEnv* zT_24;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_25;
    zT_ABC1EBBE_TypeResolveEnv* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_28;
    zT_8EED1867_ResolvedTypeTable* zT_29;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_9 = module_reg;
    zT_10 = zF_3452C137_moduleRegistryGetMo(zT_9);
    mods = zT_10;
    zT_12.store = store;
    zT_12.typereg = typereg;
    zT_12.symbol_reg = symbol_reg;
    zT_12.interner = interner;
    zT_12.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_14 = 0;
    zT_12.source_file_id = zT_14;
    zT_15.has_value = 1;
    zT_15.value = diag;
    zT_12.diag = zT_15;
    zT_16.has_value = 0;
    zT_12.local_consts = zT_16;
    env = zT_12;
    (void)perm_alloc;
    zT_17 = &env;
    zT_18 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_17, zT_18);
    zT_20 = &env;
    zT_21 = mods;
    zT_22 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_20, zT_21, zT_22);
    zT_24 = &env;
    zT_25 = mods;
    zF_E2882212_resolveAggregateFie(zT_24, zT_25);
    zT_27 = &env;
    zT_28 = mods;
    zT_29 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_27, zT_28, zT_29);
    return;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
    return;
}

/* EOF */
