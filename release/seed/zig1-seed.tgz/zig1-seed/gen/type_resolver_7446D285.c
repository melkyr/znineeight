#include "type_resolver_7446D285.h"
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_7834FCDD_Opt_220 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_A62CFBCC_EU_022 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned char* zT_44;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->depend_len;
    zT_2 = self->depend_cap;
    zT_3 = zT_1 < zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->depend_cap;
    zT_6 = 8;
    zT_7 = zT_5 < (unsigned int)zT_6;
    if (zT_7) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = 8;
    zT_8 = zT_9;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->depend_cap;
    zT_11 = 2;
    zT_12 = zT_10 * zT_11;
    zT_8 = zT_12;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    nc = zT_8;
    nc = zT_8;
    zT_13 = self->depend_cap;
    zT_14 = 0;
    zT_15 = zT_13 > (unsigned int)zT_14;
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self->alloc;
    zT_17 = zT_22;
    zT_23 = self->depend_items;
    zT_24 = (unsigned char*)zT_23;
    zT_18 = zT_24;
    zT_25 = self->depend_cap;
    zT_26 = 8;
    zT_27 = zT_25 * zT_26;
    zT_19 = zT_27;
    zT_28 = 8;
    zT_29 = nc * zT_28;
    zT_20 = zT_29;
    zT_30 = 4;
    zT_21 = zT_30;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, zT_18, zT_19, zT_20, zT_21);
    grown = zT_31;
    grown = zT_31;
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_37 = self->alloc;
    zT_34 = zT_37;
    zT_38 = 8;
    zT_39 = nc * zT_38;
    zT_35 = zT_39;
    zT_40 = 4;
    zT_36 = zT_40;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, zT_35, zT_36);
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->depend_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    z_bb_11:
    zT_44 = zT_41.data.payload;
    zT_43 = zT_44;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    raw = zT_43;
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    new_items = zT_46;
    new_items = zT_46;
    zT_47 = self->depend_items;
    zT_48 = self->depend_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    zT_56 = i < zT_54;
    if (zT_56) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_58 = 1;
    zT_59 = i + zT_58;
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->depend_items = new_items;
    self->depend_cap = nc;
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    zT_9 = (unsigned int)zT_8;
    zT_10 = zT_7 + zT_9;
    self->depend_len = zT_10;
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned int* zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_7834FCDD_Opt_220 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_A62CFBCC_EU_022 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned char* zT_44;
    unsigned int* zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_1 = self->worklist_len;
    zT_2 = self->worklist_cap;
    zT_3 = zT_1 < zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->worklist_cap;
    zT_6 = 64;
    zT_7 = zT_5 < (unsigned int)zT_6;
    if (zT_7) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = 64;
    zT_8 = zT_9;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->worklist_cap;
    zT_11 = 2;
    zT_12 = zT_10 * zT_11;
    zT_8 = zT_12;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    nc = zT_8;
    nc = zT_8;
    zT_13 = self->worklist_cap;
    zT_14 = 0;
    zT_15 = zT_13 > (unsigned int)zT_14;
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self->alloc;
    zT_17 = zT_22;
    zT_23 = self->worklist_items;
    zT_24 = (unsigned char*)zT_23;
    zT_18 = zT_24;
    zT_25 = self->worklist_cap;
    zT_26 = 4;
    zT_27 = zT_25 * zT_26;
    zT_19 = zT_27;
    zT_28 = 4;
    zT_29 = nc * zT_28;
    zT_20 = zT_29;
    zT_30 = 4;
    zT_21 = zT_30;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, zT_18, zT_19, zT_20, zT_21);
    grown = zT_31;
    grown = zT_31;
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_37 = self->alloc;
    zT_34 = zT_37;
    zT_38 = 4;
    zT_39 = nc * zT_38;
    zT_35 = zT_39;
    zT_40 = 4;
    zT_36 = zT_40;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, zT_35, zT_36);
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->worklist_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    z_bb_11:
    zT_44 = zT_41.data.payload;
    zT_43 = zT_44;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    raw = zT_43;
    raw = zT_43;
    zT_46 = (unsigned int*)raw;
    new_items = zT_46;
    new_items = zT_46;
    new_items = zT_46;
    zT_47 = self->worklist_items;
    zT_48 = self->worklist_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    zT_56 = i < zT_54;
    if (zT_56) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_58 = 1;
    zT_59 = i + zT_58;
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->worklist_items = new_items;
    self->worklist_cap = nc;
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zT_5 + zT_7;
    self->worklist_len = zT_8;
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    int zT_3;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    zT_3 = zT_1 == (unsigned int)zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zT_5 - zT_7;
    self->worklist_len = zT_8;
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_3;
    int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_A62CFBCC_EU_022 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char* zT_20;
    unsigned int* zT_21;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    zT_3 = capacity <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    nc = capacity;
    nc = capacity;
    zT_5 = 64;
    zT_6 = nc < (unsigned int)zT_5;
    if (zT_6) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_13 = self->alloc;
    zT_10 = zT_13;
    zT_14 = 4;
    zT_15 = nc * zT_14;
    zT_11 = zT_15;
    zT_16 = 4;
    zT_12 = zT_16;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, zT_11, zT_12);
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    z_bb_6:
    zT_20 = zT_17.data.payload;
    zT_19 = zT_20;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    raw = zT_19;
    raw = zT_19;
    zT_21 = (unsigned int*)raw;
    self->in_degree_items = zT_21;
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = v + a;
    zT_3 = 1;
    zT_4 = zT_2 - zT_3;
    zT_5 = 1;
    zT_6 = a - zT_5;
    zT_7 = ~zT_6;
    zT_8 = zT_4 & zT_7;
    return zT_8;
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_5;
    zT_D155D06D_Type* zT_6;
    zT_D155D06D_Type zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    int zT_17;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_406493CE_StructPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_406493CE_StructPayload zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned short zT_31;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    unsigned int zT_46;
    zT_2DF01B61_FieldEntry zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_D155D06D_Type* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_D155D06D_Type zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    zT_33EF6BFB_TypeKind zT_57;
    int zT_58;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_2DF01B61_FieldEntry* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_2DF01B61_FieldEntry* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78 = 0;
    unsigned int zT_79;
    unsigned int zT_80;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_D155D06D_Type* zT_85;
    zT_33EF6BFB_TypeKind zT_86;
    zT_33EF6BFB_TypeKind zT_89;
    int zT_90;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_457ECFEE_EnumPayload* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_457ECFEE_EnumPayload zT_96;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_D155D06D_Type* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_D155D06D_Type zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    zT_33EF6BFB_TypeKind zT_110;
    int zT_111;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_AF9231A2_UnionPayload* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_AF9231A2_UnionPayload zT_117;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned short zT_122;
    unsigned int zT_123;
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    int zT_133;
    zT_338B7C76_TypeRegistry* zT_135;
    zT_2DF01B61_FieldEntry* zT_136;
    unsigned int zT_137;
    zT_2DF01B61_FieldEntry zT_138;
    zT_338B7C76_TypeRegistry* zT_140;
    zT_D155D06D_Type* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_D155D06D_Type zT_144;
    zT_33EF6BFB_TypeKind zT_145;
    zT_33EF6BFB_TypeKind zT_148;
    int zT_149;
    unsigned int zT_150;
    int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    int zT_154;
    unsigned int zT_155;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160 = 0;
    unsigned int zT_161;
    unsigned int zT_162;
    int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_338B7C76_TypeRegistry* zT_166;
    zT_D155D06D_Type* zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_33EF6BFB_TypeKind zT_171;
    int zT_172;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_54FF90FA_TaggedUnionPayload* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    zT_54FF90FA_TaggedUnionPayload zT_178;
    zT_338B7C76_TypeRegistry* zT_180;
    zT_D155D06D_Type* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_D155D06D_Type zT_184;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned short zT_189;
    unsigned int zT_190;
    int zT_192;
    unsigned int zT_193;
    int zT_195;
    unsigned int zT_196;
    int zT_198;
    unsigned int zT_199;
    int zT_200;
    zT_338B7C76_TypeRegistry* zT_202;
    zT_2DF01B61_FieldEntry* zT_203;
    unsigned int zT_204;
    zT_2DF01B61_FieldEntry zT_205;
    char* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_222;
    zT_D155D06D_Type* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_D155D06D_Type zT_226;
    zT_33EF6BFB_TypeKind zT_227;
    zT_33EF6BFB_TypeKind zT_230;
    int zT_231;
    unsigned int zT_232;
    int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    int zT_236;
    unsigned int zT_237;
    int zT_238;
    unsigned int zT_239;
    unsigned int zT_241;
    int zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned int zT_249 = 0;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252 = 0;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256 = 0;
    zT_338B7C76_TypeRegistry* zT_257;
    zT_D155D06D_Type* zT_258;
    zT_33EF6BFB_TypeKind zT_259;
    zT_33EF6BFB_TypeKind zT_262;
    int zT_263;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_0B10E8E9_OptionalPayload* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_0B10E8E9_OptionalPayload zT_269;
    zT_338B7C76_TypeRegistry* zT_271;
    zT_D155D06D_Type* zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    zT_D155D06D_Type zT_275;
    unsigned int zT_277;
    unsigned int zT_278;
    int zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289 = 0;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_292 = 0;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_D155D06D_Type* zT_294;
    zT_33EF6BFB_TypeKind zT_295;
    zT_33EF6BFB_TypeKind zT_298;
    int zT_299;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_42C2D6BF_EUPayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_42C2D6BF_EUPayload zT_305;
    zT_338B7C76_TypeRegistry* zT_307;
    zT_D155D06D_Type* zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    zT_D155D06D_Type zT_311;
    unsigned int zT_313;
    unsigned int zT_314;
    int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_320;
    unsigned int zT_321;
    int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned int zT_329 = 0;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333 = 0;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338 = 0;
    zT_338B7C76_TypeRegistry* zT_339;
    zT_D155D06D_Type* zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    zT_33EF6BFB_TypeKind zT_344;
    int zT_345;
    zT_338B7C76_TypeRegistry* zT_347;
    zT_E834303C_ArrayPayload* zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_E834303C_ArrayPayload zT_351;
    zT_338B7C76_TypeRegistry* zT_353;
    zT_D155D06D_Type* zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    zT_D155D06D_Type zT_357;
    unsigned int zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_338B7C76_TypeRegistry* zT_362;
    zT_D155D06D_Type* zT_363;
    zT_33EF6BFB_TypeKind zT_364;
    zT_33EF6BFB_TypeKind zT_367;
    int zT_368;
    zT_338B7C76_TypeRegistry* zT_370;
    zT_666DC2E1_TuplePayload* zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    zT_666DC2E1_TuplePayload zT_374;
    unsigned int zT_376;
    unsigned int zT_377;
    unsigned short zT_379;
    unsigned int zT_380;
    int zT_382;
    unsigned int zT_383;
    int zT_385;
    unsigned int zT_386;
    int zT_388;
    unsigned int zT_389;
    int zT_390;
    zT_338B7C76_TypeRegistry* zT_392;
    unsigned int* zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    zT_338B7C76_TypeRegistry* zT_397;
    zT_D155D06D_Type* zT_398;
    unsigned int zT_399;
    zT_D155D06D_Type zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_404 = 0;
    unsigned int zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    int zT_408;
    unsigned int zT_409;
    int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_414 = 0;
    unsigned int zT_415;
    unsigned int zT_416;
    int zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    zT_338B7C76_TypeRegistry* zT_420;
    zT_D155D06D_Type* zT_421;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    idx = zT_3;
    idx = zT_3;
    zT_5 = self->registry;
    zT_6 = zT_5->types_items;
    zT_7 = zT_6[idx];
    ty = zT_7;
    ty = zT_7;
    ty = zT_7;
    zT_8 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_struct_type;
    zT_12 = zT_8 == zT_11;
    if (zT_12) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_13 = ty.flags;
    zT_14 = 16;
    zT_15 = zT_13 & zT_14;
    zT_16 = 0;
    zT_17 = zT_15 != zT_16;
    if (zT_17) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_86 = ty.kind;
    zT_89 = zT_33EF6BFB_TypeKind_enum_type;
    zT_90 = zT_86 == zT_89;
    if (zT_90) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_20 = self->registry;
    zT_18 = zT_20;
    zT_19 = tid;
    zF_331152CD_typeRegistryCompute(zT_18, zT_19);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_22 = self->registry;
    zT_23 = zT_22->st_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    sp = zT_26;
    sp = zT_26;
    sp = zT_26;
    zT_28 = sp.fields_start;
    zT_29 = (unsigned int)zT_28;
    fstart = zT_29;
    fstart = zT_29;
    fstart = zT_29;
    zT_31 = sp.fields_count;
    zT_32 = (unsigned int)zT_31;
    fcount = zT_32;
    fcount = zT_32;
    fcount = zT_32;
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    offset = zT_35;
    offset = zT_35;
    offset = zT_35;
    zT_37 = 1;
    zT_38 = (unsigned int)zT_37;
    max_align = zT_38;
    max_align = zT_38;
    max_align = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    fi = zT_41;
    fi = zT_41;
    goto z_bb_7;
    z_bb_7:
    zT_42 = fi < fcount;
    if (zT_42) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = fstart + fi;
    zT_47 = zT_45[zT_46];
    fe = zT_47;
    fe = zT_47;
    fe = zT_47;
    zT_49 = self->registry;
    zT_50 = zT_49->types_items;
    zT_51 = fe.type_id;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    ft = zT_53;
    ft = zT_53;
    ft = zT_53;
    zT_54 = ft.kind;
    zT_57 = zT_33EF6BFB_TypeKind_void_type;
    zT_58 = zT_54 == zT_57;
    if (zT_58) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_76 = offset;
    zT_77 = max_align;
    zT_78 = zF_D2BAC673_alignUp_1(zT_76, zT_77);
    ty.size = zT_78;
    ty.alignment = max_align;
    zT_79 = ty.size;
    zT_80 = 0;
    zT_81 = zT_79 == zT_80;
    if (zT_81) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_74 = 1;
    zT_75 = fi + zT_74;
    fi = zT_75;
    fi = zT_75;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_59 = self->registry;
    zT_60 = zT_59->fe_items;
    zT_61 = fstart + fi;
    zT_60[zT_61] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_62 = offset;
    zT_64 = ft.alignment;
    zT_63 = zT_64;
    zT_65 = zF_D2BAC673_alignUp_1(zT_62, zT_63);
    offset = zT_65;
    offset = zT_65;
    fe.offset = offset;
    zT_66 = self->registry;
    zT_67 = zT_66->fe_items;
    zT_68 = fstart + fi;
    zT_67[zT_68] = fe;
    zT_69 = ft.size;
    zT_70 = offset + zT_69;
    offset = zT_70;
    offset = zT_70;
    zT_71 = ft.alignment;
    zT_72 = zT_71 > max_align;
    if (zT_72) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_73 = ft.alignment;
    max_align = zT_73;
    max_align = zT_73;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_82 = 1;
    ty.size = zT_82;
    zT_83 = 1;
    ty.alignment = zT_83;
    goto z_bb_17;
    z_bb_17:
    zT_84 = self->registry;
    zT_85 = zT_84->types_items;
    zT_85[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_92 = self->registry;
    zT_93 = zT_92->en_items;
    zT_94 = ty.payload_idx;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_93[zT_95];
    ep = zT_96;
    ep = zT_96;
    ep = zT_96;
    zT_98 = self->registry;
    zT_99 = zT_98->types_items;
    zT_100 = ep.backing_type;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zT_99[zT_101];
    bt = zT_102;
    bt = zT_102;
    bt = zT_102;
    zT_103 = bt.size;
    ty.size = zT_103;
    zT_104 = bt.alignment;
    ty.alignment = zT_104;
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_106[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_107 = ty.kind;
    zT_110 = zT_33EF6BFB_TypeKind_union_type;
    zT_111 = zT_107 == zT_110;
    if (zT_111) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_113 = self->registry;
    zT_114 = zT_113->un_items;
    zT_115 = ty.payload_idx;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    up = zT_117;
    up = zT_117;
    up = zT_117;
    zT_119 = up.fields_start;
    zT_120 = (unsigned int)zT_119;
    fstart = zT_120;
    fstart = zT_120;
    fstart = zT_120;
    zT_122 = up.fields_count;
    zT_123 = (unsigned int)zT_122;
    fcount = zT_123;
    fcount = zT_123;
    fcount = zT_123;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    max_sz = zT_126;
    max_sz = zT_126;
    max_sz = zT_126;
    zT_128 = 1;
    zT_129 = (unsigned int)zT_128;
    max_align = zT_129;
    max_align = zT_129;
    max_align = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    fi = zT_132;
    fi = zT_132;
    fi = zT_132;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_168 = ty.kind;
    zT_171 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_172 = zT_168 == zT_171;
    if (zT_172) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    zT_133 = fi < fcount;
    if (zT_133) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_135 = self->registry;
    zT_136 = zT_135->fe_items;
    zT_137 = fstart + fi;
    zT_138 = zT_136[zT_137];
    fe = zT_138;
    fe = zT_138;
    fe = zT_138;
    zT_140 = self->registry;
    zT_141 = zT_140->types_items;
    zT_142 = fe.type_id;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    ft = zT_144;
    ft = zT_144;
    ft = zT_144;
    zT_145 = ft.kind;
    zT_148 = zT_33EF6BFB_TypeKind_void_type;
    zT_149 = zT_145 != zT_148;
    if (zT_149) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_158 = max_sz;
    zT_159 = max_align;
    zT_160 = zF_D2BAC673_alignUp_1(zT_158, zT_159);
    ty.size = zT_160;
    ty.alignment = max_align;
    zT_161 = ty.size;
    zT_162 = 0;
    zT_163 = zT_161 == zT_162;
    if (zT_163) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_156 = 1;
    zT_157 = fi + zT_156;
    fi = zT_157;
    fi = zT_157;
    goto z_bb_24;
    z_bb_28:
    zT_150 = ft.size;
    zT_151 = zT_150 > max_sz;
    if (zT_151) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_152 = ft.size;
    max_sz = zT_152;
    max_sz = zT_152;
    goto z_bb_31;
    z_bb_31:
    zT_153 = ft.alignment;
    zT_154 = zT_153 > max_align;
    if (zT_154) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_155 = ft.alignment;
    max_align = zT_155;
    max_align = zT_155;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_164 = 1;
    ty.size = zT_164;
    zT_165 = 1;
    ty.alignment = zT_165;
    goto z_bb_35;
    z_bb_35:
    zT_166 = self->registry;
    zT_167 = zT_166->types_items;
    zT_167[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_174 = self->registry;
    zT_175 = zT_174->tu_items;
    zT_176 = ty.payload_idx;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zT_175[zT_177];
    tp = zT_178;
    tp = zT_178;
    tp = zT_178;
    zT_180 = self->registry;
    zT_181 = zT_180->types_items;
    zT_182 = tp.tag_type;
    zT_183 = (unsigned int)zT_182;
    zT_184 = zT_181[zT_183];
    tag_ty = zT_184;
    tag_ty = zT_184;
    tag_ty = zT_184;
    zT_186 = tp.fields_start;
    zT_187 = (unsigned int)zT_186;
    fstart = zT_187;
    fstart = zT_187;
    fstart = zT_187;
    zT_189 = tp.fields_count;
    zT_190 = (unsigned int)zT_189;
    fcount = zT_190;
    fcount = zT_190;
    fcount = zT_190;
    zT_192 = 0;
    zT_193 = (unsigned int)zT_192;
    max_ps = zT_193;
    max_ps = zT_193;
    max_ps = zT_193;
    zT_195 = 1;
    zT_196 = (unsigned int)zT_195;
    max_pa = zT_196;
    max_pa = zT_196;
    max_pa = zT_196;
    zT_198 = 0;
    zT_199 = (unsigned int)zT_198;
    fi = zT_199;
    fi = zT_199;
    fi = zT_199;
    goto z_bb_39;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_259 = ty.kind;
    zT_262 = zT_33EF6BFB_TypeKind_optional_type;
    zT_263 = zT_259 == zT_262;
    if (zT_263) goto z_bb_52; else goto z_bb_54;
    z_bb_39:
    zT_200 = fi < fcount;
    if (zT_200) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_202 = self->registry;
    zT_203 = zT_202->fe_items;
    zT_204 = fstart + fi;
    zT_205 = zT_203[zT_204];
    fe = zT_205;
    fe = zT_205;
    fe = zT_205;
    zT_207 = "FER:n";
    zT_209 = 5;
    zT_208.ptr = zT_207;
    zT_208.len = zT_209;
    fer_nm = zT_208;
    fer_nm = zT_208;
    fer_nm = zT_208;
    zT_210 = fer_nm;
    zT_212 = fstart + fi;
    zT_213 = (unsigned int)zT_212;
    zT_211 = zT_213;
    zF_C914CB83_markerWriteInt(zT_210, zT_211);
    zT_215 = "FER:t";
    zT_217 = 5;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    fer_tm = zT_216;
    fer_tm = zT_216;
    fer_tm = zT_216;
    zT_218 = fer_tm;
    zT_220 = fe.type_id;
    zT_219 = zT_220;
    zF_C914CB83_markerWriteInt(zT_218, zT_219);
    zT_222 = self->registry;
    zT_223 = zT_222->types_items;
    zT_224 = fe.type_id;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    ft = zT_226;
    ft = zT_226;
    ft = zT_226;
    zT_227 = ft.kind;
    zT_230 = zT_33EF6BFB_TypeKind_void_type;
    zT_231 = zT_227 != zT_230;
    if (zT_231) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_241 = tag_ty.alignment;
    zT_242 = zT_241 > max_pa;
    if (zT_242) goto z_bb_49; else goto z_bb_50;
    z_bb_42:
    zT_238 = 1;
    zT_239 = fi + zT_238;
    fi = zT_239;
    fi = zT_239;
    goto z_bb_39;
    z_bb_43:
    zT_232 = ft.size;
    zT_233 = zT_232 > max_ps;
    if (zT_233) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_234 = ft.size;
    max_ps = zT_234;
    max_ps = zT_234;
    goto z_bb_46;
    z_bb_46:
    zT_235 = ft.alignment;
    zT_236 = zT_235 > max_pa;
    if (zT_236) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_237 = ft.alignment;
    max_pa = zT_237;
    max_pa = zT_237;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_44;
    z_bb_49:
    zT_244 = tag_ty.alignment;
    zT_243 = zT_244;
    goto z_bb_51;
    z_bb_50:
    zT_243 = max_pa;
    goto z_bb_51;
    z_bb_51:
    overall_align = zT_243;
    overall_align = zT_243;
    overall_align = zT_243;
    zT_246 = tag_ty.size;
    total = zT_246;
    total = zT_246;
    total = zT_246;
    zT_247 = total;
    zT_248 = max_pa;
    zT_249 = zF_D2BAC673_alignUp_1(zT_247, zT_248);
    total = zT_249;
    total = zT_249;
    zT_250 = max_ps;
    zT_251 = max_pa;
    zT_252 = zF_D2BAC673_alignUp_1(zT_250, zT_251);
    zT_253 = total + zT_252;
    total = zT_253;
    total = zT_253;
    zT_254 = total;
    zT_255 = overall_align;
    zT_256 = zF_D2BAC673_alignUp_1(zT_254, zT_255);
    ty.size = zT_256;
    ty.alignment = overall_align;
    zT_257 = self->registry;
    zT_258 = zT_257->types_items;
    zT_258[idx] = ty;
    goto z_bb_37;
    z_bb_52:
    zT_265 = self->registry;
    zT_266 = zT_265->opt_items;
    zT_267 = ty.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    op = zT_269;
    op = zT_269;
    op = zT_269;
    zT_271 = self->registry;
    zT_272 = zT_271->types_items;
    zT_273 = op.payload;
    zT_274 = (unsigned int)zT_273;
    zT_275 = zT_272[zT_274];
    pt = zT_275;
    pt = zT_275;
    pt = zT_275;
    zT_277 = pt.alignment;
    zT_278 = 4;
    zT_279 = zT_277 > zT_278;
    if (zT_279) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_37;
    z_bb_54:
    zT_295 = ty.kind;
    zT_298 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_299 = zT_295 == zT_298;
    if (zT_299) goto z_bb_58; else goto z_bb_60;
    z_bb_55:
    zT_281 = pt.alignment;
    zT_280 = zT_281;
    goto z_bb_57;
    z_bb_56:
    zT_282 = 4;
    zT_280 = zT_282;
    goto z_bb_57;
    z_bb_57:
    pay_align = zT_280;
    pay_align = zT_280;
    pay_align = zT_280;
    zT_287 = pt.size;
    zT_285 = zT_287;
    zT_288 = 4;
    zT_286 = zT_288;
    zT_289 = zF_D2BAC673_alignUp_1(zT_285, zT_286);
    zT_290 = 4;
    zT_291 = zT_289 + zT_290;
    zT_283 = zT_291;
    zT_284 = pay_align;
    zT_292 = zF_D2BAC673_alignUp_1(zT_283, zT_284);
    ty.size = zT_292;
    ty.alignment = pay_align;
    zT_293 = self->registry;
    zT_294 = zT_293->types_items;
    zT_294[idx] = ty;
    goto z_bb_53;
    z_bb_58:
    zT_301 = self->registry;
    zT_302 = zT_301->eu_items;
    zT_303 = ty.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    ep_1 = zT_305;
    ep_1 = zT_305;
    ep_1 = zT_305;
    zT_307 = self->registry;
    zT_308 = zT_307->types_items;
    zT_309 = ep_1.payload;
    zT_310 = (unsigned int)zT_309;
    zT_311 = zT_308[zT_310];
    pt = zT_311;
    pt = zT_311;
    pt = zT_311;
    zT_313 = pt.size;
    zT_314 = 4;
    zT_315 = zT_313 > zT_314;
    if (zT_315) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_53;
    z_bb_60:
    zT_341 = ty.kind;
    zT_344 = zT_33EF6BFB_TypeKind_array_type;
    zT_345 = zT_341 == zT_344;
    if (zT_345) goto z_bb_67; else goto z_bb_69;
    z_bb_61:
    zT_317 = pt.size;
    zT_316 = zT_317;
    goto z_bb_63;
    z_bb_62:
    zT_318 = 4;
    zT_316 = zT_318;
    goto z_bb_63;
    z_bb_63:
    union_sz = zT_316;
    union_sz = zT_316;
    union_sz = zT_316;
    zT_320 = pt.alignment;
    zT_321 = 4;
    zT_322 = zT_320 > zT_321;
    if (zT_322) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_324 = pt.alignment;
    zT_323 = zT_324;
    goto z_bb_66;
    z_bb_65:
    zT_325 = 4;
    zT_323 = zT_325;
    goto z_bb_66;
    z_bb_66:
    union_align = zT_323;
    union_align = zT_323;
    union_align = zT_323;
    zT_327 = union_sz;
    zT_328 = union_align;
    zT_329 = zF_D2BAC673_alignUp_1(zT_327, zT_328);
    total = zT_329;
    total = zT_329;
    total = zT_329;
    zT_330 = total;
    zT_332 = 4;
    zT_331 = zT_332;
    zT_333 = zF_D2BAC673_alignUp_1(zT_330, zT_331);
    zT_334 = 4;
    zT_335 = zT_333 + zT_334;
    total = zT_335;
    total = zT_335;
    zT_336 = total;
    zT_337 = union_align;
    zT_338 = zF_D2BAC673_alignUp_1(zT_336, zT_337);
    ty.size = zT_338;
    ty.alignment = union_align;
    zT_339 = self->registry;
    zT_340 = zT_339->types_items;
    zT_340[idx] = ty;
    goto z_bb_59;
    z_bb_67:
    zT_347 = self->registry;
    zT_348 = zT_347->array_items;
    zT_349 = ty.payload_idx;
    zT_350 = (unsigned int)zT_349;
    zT_351 = zT_348[zT_350];
    ap = zT_351;
    ap = zT_351;
    ap = zT_351;
    zT_353 = self->registry;
    zT_354 = zT_353->types_items;
    zT_355 = ap.elem;
    zT_356 = (unsigned int)zT_355;
    zT_357 = zT_354[zT_356];
    et = zT_357;
    et = zT_357;
    et = zT_357;
    zT_358 = et.size;
    zT_359 = ap.length;
    zT_360 = zT_358 * zT_359;
    ty.size = zT_360;
    zT_361 = et.alignment;
    ty.alignment = zT_361;
    zT_362 = self->registry;
    zT_363 = zT_362->types_items;
    zT_363[idx] = ty;
    goto z_bb_68;
    z_bb_68:
    goto z_bb_59;
    z_bb_69:
    zT_364 = ty.kind;
    zT_367 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_368 = zT_364 == zT_367;
    if (zT_368) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_370 = self->registry;
    zT_371 = zT_370->tup_items;
    zT_372 = ty.payload_idx;
    zT_373 = (unsigned int)zT_372;
    zT_374 = zT_371[zT_373];
    tp_2 = zT_374;
    tp_2 = zT_374;
    tp_2 = zT_374;
    zT_376 = tp_2.elems_start;
    zT_377 = (unsigned int)zT_376;
    estr = zT_377;
    estr = zT_377;
    estr = zT_377;
    zT_379 = tp_2.elems_count;
    zT_380 = (unsigned int)zT_379;
    ecount = zT_380;
    ecount = zT_380;
    ecount = zT_380;
    zT_382 = 0;
    zT_383 = (unsigned int)zT_382;
    offset = zT_383;
    offset = zT_383;
    offset = zT_383;
    zT_385 = 1;
    zT_386 = (unsigned int)zT_385;
    max_align = zT_386;
    max_align = zT_386;
    max_align = zT_386;
    zT_388 = 0;
    zT_389 = (unsigned int)zT_388;
    ei = zT_389;
    ei = zT_389;
    ei = zT_389;
    goto z_bb_72;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    zT_390 = ei < ecount;
    if (zT_390) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_392 = self->registry;
    zT_393 = zT_392->xt_items;
    zT_394 = estr + ei;
    zT_395 = zT_393[zT_394];
    elem_tid = zT_395;
    elem_tid = zT_395;
    elem_tid = zT_395;
    zT_397 = self->registry;
    zT_398 = zT_397->types_items;
    zT_399 = (unsigned int)elem_tid;
    zT_400 = zT_398[zT_399];
    et = zT_400;
    et = zT_400;
    et = zT_400;
    zT_401 = offset;
    zT_403 = et.alignment;
    zT_402 = zT_403;
    zT_404 = zF_D2BAC673_alignUp_1(zT_401, zT_402);
    offset = zT_404;
    offset = zT_404;
    zT_405 = et.size;
    zT_406 = offset + zT_405;
    offset = zT_406;
    offset = zT_406;
    zT_407 = et.alignment;
    zT_408 = zT_407 > max_align;
    if (zT_408) goto z_bb_76; else goto z_bb_77;
    z_bb_74:
    zT_412 = offset;
    zT_413 = max_align;
    zT_414 = zF_D2BAC673_alignUp_1(zT_412, zT_413);
    ty.size = zT_414;
    ty.alignment = max_align;
    zT_415 = ty.size;
    zT_416 = 0;
    zT_417 = zT_415 == zT_416;
    if (zT_417) goto z_bb_78; else goto z_bb_79;
    z_bb_75:
    zT_410 = 1;
    zT_411 = ei + zT_410;
    ei = zT_411;
    ei = zT_411;
    goto z_bb_72;
    z_bb_76:
    zT_409 = et.alignment;
    max_align = zT_409;
    max_align = zT_409;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_418 = 1;
    ty.size = zT_418;
    zT_419 = 1;
    ty.alignment = zT_419;
    goto z_bb_79;
    z_bb_79:
    zT_420 = self->registry;
    zT_421 = zT_420->types_items;
    zT_421[idx] = ty;
    goto z_bb_71;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    unsigned int zT_12;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_A62CFBCC_EU_022 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    unsigned char* zT_35;
    unsigned int* zT_36;
    int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_12 = zT_11.from;
    zT_8 = zT_12;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_15 = zT_14.to;
    zT_9 = zT_15;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = i + zT_17;
    i = zT_18;
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    type_count = zT_21;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_28 = self->alloc;
    zT_25 = zT_28;
    zT_29 = 4;
    zT_30 = type_count * zT_29;
    zT_26 = zT_30;
    zT_31 = 4;
    zT_27 = zT_31;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, zT_26, zT_27);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    z_bb_6:
    zT_35 = zT_32.data.payload;
    zT_34 = zT_35;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    raw_sorted = zT_34;
    raw_sorted = zT_34;
    zT_36 = (unsigned int*)raw_sorted;
    self->sorted_items = zT_36;
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    zi = zT_39;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    zT_40 = zi < type_count;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zi + zT_44;
    zi = zT_45;
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    ei = zT_48;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    zT_50 = ei < zT_49;
    if (zT_50) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    target = zT_54;
    target = zT_54;
    zT_55 = (unsigned int)target;
    zT_56 = zT_55 < type_count;
    if (zT_56) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    zT_62 = zT_59 + zT_61;
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_66 = (unsigned int)zT_65;
    zT_67 = ei + zT_66;
    ei = zT_67;
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    zT_C890C8CB_TypeResolver* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    int zT_22;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    int zT_44;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    int zT_48;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    int zT_55;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    int zT_59;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    int zT_69;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    unsigned char zT_84;
    int zT_85;
    int zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    int zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    unsigned char zT_96;
    unsigned short zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_F85C5DED_DiagnosticCollector* zT_102;
    unsigned char zT_103;
    zT_A210EB18_ErrorCode zT_106;
    unsigned short zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_D155D06D_Type* zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    type_count = zT_3;
    type_count = zT_3;
    zT_4 = 0;
    zT_5 = type_count == (unsigned int)zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    ti = zT_8;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = ti < type_count;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    zT_13 = zT_11 == (unsigned int)zT_12;
    if (zT_13) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zT_16 = (unsigned int)ti;
    zT_15 = zT_16;
    zF_352BC6BC_worklistPush(zT_14, zT_15);
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = ti + zT_18;
    ti = zT_19;
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    zT_22 = zT_20 > (unsigned int)zT_21;
    if (zT_22) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    tid_val = zT_25;
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    ci = zT_77;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    zT_31 = 1;
    zT_32 = zT_30 + zT_31;
    self->sorted_len = zT_32;
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_35 = 2;
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = (unsigned int)tid;
    zT_39 = zT_37 + zT_38;
    zT_39->state = zT_35;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    ei = zT_42;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    zT_44 = ei < zT_43;
    if (zT_44) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    zT_48 = zT_47 == tid;
    if (zT_48) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    dep = zT_52;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    dep_idx = zT_54;
    dep_idx = zT_54;
    zT_55 = dep_idx < type_count;
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_73 = (unsigned int)zT_72;
    zT_74 = ei + zT_73;
    ei = zT_74;
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    zT_59 = zT_57 > (unsigned int)zT_58;
    if (zT_59) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zT_61 - zT_63;
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    zT_69 = zT_67 == (unsigned int)zT_68;
    if (zT_69) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_78 = ci < type_count;
    if (zT_78) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    ty = zT_82;
    ty = zT_82;
    zT_83 = ty.state;
    zT_84 = 2;
    zT_85 = zT_83 != zT_84;
    if (zT_85) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_120 = 1;
    zT_121 = ci + zT_120;
    ci = zT_121;
    ci = zT_121;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_90 = zT_88 > (unsigned int)zT_89;
    zT_86 = zT_90;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    msg = zT_93;
    msg = zT_93;
    zT_102 = self->diag;
    zT_95 = zT_102;
    zT_103 = 0;
    zT_96 = zT_103;
    zT_106 = zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY;
    zT_107 = (unsigned short)zT_106;
    zT_97 = zT_107;
    zT_108 = 0;
    zT_98 = zT_108;
    zT_109 = 0;
    zT_99 = zT_109;
    zT_110 = 0;
    zT_100 = zT_110;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, zT_96, zT_97, zT_98, zT_99, zT_100, zT_101);
    zT_114 = zT_33EF6BFB_TypeKind_void_type;
    ty.kind = zT_114;
    zT_115 = 0;
    ty.size = zT_115;
    zT_116 = 1;
    ty.alignment = zT_116;
    zT_117 = 2;
    ty.state = zT_117;
    zT_118 = self->registry;
    zT_119 = zT_118->types_items;
    zT_119[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* fieldEmbedsByValue */
int zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_array_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_enum_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_36 = 0;
    return zT_36;
}

/* requiresFullDef */
int zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_array_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_optional_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_36 = 0;
    return zT_36;
}

/* layoutFieldNeedsEdge */
int zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_38;
    int zT_39;
    int zT_40;
    int zT_41;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_enum_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_array_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_optional_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_38 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_39 = kind == zT_38;
    if (zT_39) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_40 = 1;
    return zT_40;
    z_bb_16:
    zT_41 = 0;
    return zT_41;
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    zT_5 = (unsigned int)zT_4;
    zT_6 = field_type >= zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    ft = zT_11;
    ft = zT_11;
    zT_13 = ft.kind;
    zT_12 = zT_13;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    fi = zT_6;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = (unsigned int)fcount;
    zT_8 = fi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_14 = (unsigned int)fstart;
    zT_15 = zT_14 + fi;
    zT_16 = zT_13[zT_15];
    zT_17 = zT_16.type_id;
    zT_10 = zT_17;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_19 = fi + zT_18;
    fi = zT_19;
    fi = zT_19;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_406493CE_StructPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_406493CE_StructPayload zT_23;
    zT_C890C8CB_TypeResolver* zT_24;
    unsigned int zT_25;
    unsigned short zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_54FF90FA_TaggedUnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_54FF90FA_TaggedUnionPayload zT_40;
    zT_C890C8CB_TypeResolver* zT_41;
    unsigned int zT_42;
    unsigned short zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_51;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_AF9231A2_UnionPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_AF9231A2_UnionPayload zT_57;
    zT_C890C8CB_TypeResolver* zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned short zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    zT_33EF6BFB_TypeKind zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    int zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_666DC2E1_TuplePayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_666DC2E1_TuplePayload zT_88;
    int zT_90;
    unsigned int zT_91;
    unsigned short zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_C890C8CB_TypeResolver* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    unsigned int* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    int zT_104;
    unsigned int zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    zT_C890C8CB_TypeResolver* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_0B10E8E9_OptionalPayload* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_0B10E8E9_OptionalPayload zT_118;
    unsigned int zT_119;
    zT_33EF6BFB_TypeKind zT_120;
    zT_33EF6BFB_TypeKind zT_123;
    int zT_124;
    zT_C890C8CB_TypeResolver* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_128;
    zT_42C2D6BF_EUPayload* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    zT_42C2D6BF_EUPayload zT_132;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_135;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    ti = zT_3;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    zT_6 = ti < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    container_tid = zT_12;
    container_tid = zT_12;
    zT_13 = ty.kind;
    zT_16 = zT_33EF6BFB_TypeKind_struct_type;
    zT_17 = zT_13 == zT_16;
    if (zT_17) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_134 = 1;
    zT_135 = ti + zT_134;
    ti = zT_135;
    ti = zT_135;
    goto z_bb_1;
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->st_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    sp = zT_23;
    sp = zT_23;
    sp = zT_23;
    zT_24 = self;
    zT_28 = sp.fields_start;
    zT_25 = zT_28;
    zT_29 = sp.fields_count;
    zT_26 = zT_29;
    zT_27 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_24, zT_25, zT_26, zT_27);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = ty.kind;
    zT_33 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_34 = zT_30 == zT_33;
    if (zT_34) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_36 = self->registry;
    zT_37 = zT_36->tu_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    tp = zT_40;
    tp = zT_40;
    tp = zT_40;
    zT_41 = self;
    zT_45 = tp.fields_start;
    zT_42 = zT_45;
    zT_46 = tp.fields_count;
    zT_43 = zT_46;
    zT_44 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_47 = ty.kind;
    zT_50 = zT_33EF6BFB_TypeKind_union_type;
    zT_51 = zT_47 == zT_50;
    if (zT_51) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_53 = self->registry;
    zT_54 = zT_53->un_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    up = zT_57;
    up = zT_57;
    up = zT_57;
    zT_58 = self;
    zT_62 = up.fields_start;
    zT_59 = zT_62;
    zT_63 = up.fields_count;
    zT_60 = zT_63;
    zT_61 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_58, zT_59, zT_60, zT_61);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_64 = ty.kind;
    zT_67 = zT_33EF6BFB_TypeKind_array_type;
    zT_68 = zT_64 == zT_67;
    if (zT_68) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_69 = self;
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = ty.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    zT_70 = zT_77;
    zT_71 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_69, zT_70, zT_71);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_78 = ty.kind;
    zT_81 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_82 = zT_78 == zT_81;
    if (zT_82) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_84 = self->registry;
    zT_85 = zT_84->tup_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    tp_1 = zT_88;
    tp_1 = zT_88;
    tp_1 = zT_88;
    zT_90 = 0;
    zT_91 = (unsigned int)zT_90;
    ei = zT_91;
    ei = zT_91;
    ei = zT_91;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_106 = ty.kind;
    zT_109 = zT_33EF6BFB_TypeKind_optional_type;
    zT_110 = zT_106 == zT_109;
    if (zT_110) goto z_bb_24; else goto z_bb_26;
    z_bb_20:
    zT_92 = tp_1.elems_count;
    zT_93 = (unsigned int)zT_92;
    zT_94 = ei < zT_93;
    if (zT_94) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_95 = self;
    zT_98 = self->registry;
    zT_99 = zT_98->xt_items;
    zT_100 = tp_1.elems_start;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zT_101 + ei;
    zT_103 = zT_99[zT_102];
    zT_96 = zT_103;
    zT_97 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_95, zT_96, zT_97);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_104 = 1;
    zT_105 = ei + zT_104;
    ei = zT_105;
    ei = zT_105;
    goto z_bb_20;
    z_bb_24:
    zT_111 = self;
    zT_114 = self->registry;
    zT_115 = zT_114->opt_items;
    zT_116 = ty.payload_idx;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    zT_119 = zT_118.payload;
    zT_112 = zT_119;
    zT_113 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_111, zT_112, zT_113);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_120 = ty.kind;
    zT_123 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_124 = zT_120 == zT_123;
    if (zT_124) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_125 = self;
    zT_128 = self->registry;
    zT_129 = zT_128->eu_items;
    zT_130 = ty.payload_idx;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zT_129[zT_131];
    zT_133 = zT_132.payload;
    zT_126 = zT_133;
    zT_127 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_125, zT_126, zT_127);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_25;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    zT_A62CFBCC_EU_022 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_16;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    zT_A62CFBCC_EU_022 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned char* zT_33;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_43;
    zT_A62CFBCC_EU_022 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_57;
    zT_A62CFBCC_EU_022 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned char* zT_61;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_72;
    zT_3E40CD83_Sand* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_78;
    int zT_79;
    unsigned int zT_80;
    zT_A62CFBCC_EU_022 zT_81 = {0};
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned char* zT_84;
    unsigned int* zT_86;
    unsigned int zT_88;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_D155D06D_Type* zT_97;
    zT_D155D06D_Type zT_98;
    unsigned char zT_100;
    zT_33EF6BFB_TypeKind zT_101;
    zT_33EF6BFB_TypeKind zT_104;
    int zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_406493CE_StructPayload* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_406493CE_StructPayload zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned short zT_115;
    unsigned int zT_116;
    int zT_117;
    int zT_118;
    int zT_119;
    int zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_2DF01B61_FieldEntry* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_2DF01B61_FieldEntry zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_136 = 0;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_33EF6BFB_TypeKind zT_141;
    int zT_142;
    zT_3E40CD83_Sand* zT_143;
    unsigned int** zT_144;
    unsigned int** zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int** zT_148;
    unsigned int** zT_149;
    unsigned int* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    zT_33EF6BFB_TypeKind zT_162;
    int zT_163;
    zT_3E40CD83_Sand* zT_164;
    unsigned int** zT_165;
    unsigned int** zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    unsigned int** zT_169;
    unsigned int** zT_170;
    unsigned int* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_33EF6BFB_TypeKind zT_185;
    int zT_186;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_54FF90FA_TaggedUnionPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_54FF90FA_TaggedUnionPayload zT_192;
    int zT_194;
    unsigned int zT_195;
    unsigned short zT_196;
    unsigned int zT_197;
    int zT_198;
    int zT_199;
    int zT_200;
    int zT_201;
    zT_338B7C76_TypeRegistry* zT_203;
    zT_2DF01B61_FieldEntry* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_2DF01B61_FieldEntry zT_208;
    unsigned int zT_209;
    zT_338B7C76_TypeRegistry* zT_211;
    zT_D155D06D_Type* zT_212;
    unsigned int zT_213;
    zT_D155D06D_Type zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    int zT_217 = 0;
    unsigned char zT_218;
    zT_33EF6BFB_TypeKind zT_219;
    zT_33EF6BFB_TypeKind zT_222;
    int zT_223;
    zT_3E40CD83_Sand* zT_224;
    unsigned int** zT_225;
    unsigned int** zT_226;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int** zT_229;
    unsigned int** zT_230;
    unsigned int* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_33EF6BFB_TypeKind zT_240;
    zT_33EF6BFB_TypeKind zT_243;
    int zT_244;
    zT_3E40CD83_Sand* zT_245;
    unsigned int** zT_246;
    unsigned int** zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int** zT_250;
    unsigned int** zT_251;
    unsigned int* zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    int zT_261;
    unsigned int zT_262;
    zT_33EF6BFB_TypeKind zT_263;
    zT_33EF6BFB_TypeKind zT_266;
    int zT_267;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_AF9231A2_UnionPayload* zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_AF9231A2_UnionPayload zT_273;
    int zT_275;
    unsigned int zT_276;
    unsigned short zT_277;
    unsigned int zT_278;
    int zT_279;
    int zT_280;
    int zT_281;
    int zT_282;
    zT_338B7C76_TypeRegistry* zT_284;
    zT_2DF01B61_FieldEntry* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_2DF01B61_FieldEntry zT_289;
    unsigned int zT_290;
    zT_338B7C76_TypeRegistry* zT_292;
    zT_D155D06D_Type* zT_293;
    unsigned int zT_294;
    zT_D155D06D_Type zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_33EF6BFB_TypeKind zT_297;
    int zT_298 = 0;
    unsigned char zT_299;
    zT_33EF6BFB_TypeKind zT_300;
    zT_33EF6BFB_TypeKind zT_303;
    int zT_304;
    zT_3E40CD83_Sand* zT_305;
    unsigned int** zT_306;
    unsigned int** zT_307;
    unsigned int* zT_308;
    unsigned int zT_309;
    unsigned int** zT_310;
    unsigned int** zT_311;
    unsigned int* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    zT_33EF6BFB_TypeKind zT_321;
    zT_33EF6BFB_TypeKind zT_324;
    int zT_325;
    zT_3E40CD83_Sand* zT_326;
    unsigned int** zT_327;
    unsigned int** zT_328;
    unsigned int* zT_329;
    unsigned int zT_330;
    unsigned int** zT_331;
    unsigned int** zT_332;
    unsigned int* zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    int zT_342;
    unsigned int zT_343;
    zT_33EF6BFB_TypeKind zT_344;
    zT_33EF6BFB_TypeKind zT_347;
    int zT_348;
    zT_338B7C76_TypeRegistry* zT_350;
    zT_E834303C_ArrayPayload* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_E834303C_ArrayPayload zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_D155D06D_Type* zT_358;
    unsigned int zT_359;
    zT_D155D06D_Type zT_360;
    zT_33EF6BFB_TypeKind zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    int zT_363 = 0;
    unsigned char zT_364;
    zT_33EF6BFB_TypeKind zT_365;
    zT_33EF6BFB_TypeKind zT_368;
    int zT_369;
    zT_3E40CD83_Sand* zT_370;
    unsigned int** zT_371;
    unsigned int** zT_372;
    unsigned int* zT_373;
    unsigned int zT_374;
    unsigned int** zT_375;
    unsigned int** zT_376;
    unsigned int* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    zT_33EF6BFB_TypeKind zT_386;
    zT_33EF6BFB_TypeKind zT_389;
    int zT_390;
    zT_3E40CD83_Sand* zT_391;
    unsigned int** zT_392;
    unsigned int** zT_393;
    unsigned int* zT_394;
    unsigned int zT_395;
    unsigned int** zT_396;
    unsigned int** zT_397;
    unsigned int* zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_33EF6BFB_TypeKind zT_407;
    zT_33EF6BFB_TypeKind zT_410;
    int zT_411;
    zT_338B7C76_TypeRegistry* zT_413;
    zT_42C2D6BF_EUPayload* zT_414;
    unsigned int zT_415;
    unsigned int zT_416;
    zT_42C2D6BF_EUPayload zT_417;
    unsigned int zT_418;
    zT_338B7C76_TypeRegistry* zT_420;
    zT_D155D06D_Type* zT_421;
    unsigned int zT_422;
    zT_D155D06D_Type zT_423;
    zT_33EF6BFB_TypeKind zT_424;
    zT_33EF6BFB_TypeKind zT_425;
    int zT_426 = 0;
    unsigned char zT_427;
    zT_33EF6BFB_TypeKind zT_428;
    zT_33EF6BFB_TypeKind zT_431;
    int zT_432;
    zT_3E40CD83_Sand* zT_433;
    unsigned int** zT_434;
    unsigned int** zT_435;
    unsigned int* zT_436;
    unsigned int zT_437;
    unsigned int** zT_438;
    unsigned int** zT_439;
    unsigned int* zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    zT_33EF6BFB_TypeKind zT_449;
    zT_33EF6BFB_TypeKind zT_452;
    int zT_453;
    zT_3E40CD83_Sand* zT_454;
    unsigned int** zT_455;
    unsigned int** zT_456;
    unsigned int* zT_457;
    unsigned int zT_458;
    unsigned int** zT_459;
    unsigned int** zT_460;
    unsigned int* zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_33EF6BFB_TypeKind zT_470;
    zT_33EF6BFB_TypeKind zT_473;
    int zT_474;
    zT_338B7C76_TypeRegistry* zT_476;
    zT_0B10E8E9_OptionalPayload* zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    zT_0B10E8E9_OptionalPayload zT_480;
    unsigned int zT_481;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_D155D06D_Type* zT_484;
    unsigned int zT_485;
    zT_D155D06D_Type zT_486;
    zT_33EF6BFB_TypeKind zT_487;
    zT_33EF6BFB_TypeKind zT_488;
    int zT_489 = 0;
    unsigned char zT_490;
    zT_33EF6BFB_TypeKind zT_491;
    zT_33EF6BFB_TypeKind zT_494;
    int zT_495;
    zT_3E40CD83_Sand* zT_496;
    unsigned int** zT_497;
    unsigned int** zT_498;
    unsigned int* zT_499;
    unsigned int zT_500;
    unsigned int** zT_501;
    unsigned int** zT_502;
    unsigned int* zT_503;
    unsigned int zT_504;
    unsigned int zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int zT_508;
    unsigned int zT_509;
    unsigned int zT_510;
    unsigned int zT_511;
    zT_33EF6BFB_TypeKind zT_512;
    zT_33EF6BFB_TypeKind zT_515;
    int zT_516;
    zT_3E40CD83_Sand* zT_517;
    unsigned int** zT_518;
    unsigned int** zT_519;
    unsigned int* zT_520;
    unsigned int zT_521;
    unsigned int** zT_522;
    unsigned int** zT_523;
    unsigned int* zT_524;
    unsigned int zT_525;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned char zT_533;
    int zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    int zT_539;
    unsigned int zT_540;
    int zT_541;
    unsigned int zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    int zT_551;
    unsigned int zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    unsigned char zT_556;
    unsigned char zT_557;
    int zT_558;
    unsigned char zT_559;
    unsigned int zT_560;
    unsigned int zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    unsigned int zT_564;
    unsigned int zT_565;
    zT_3E40CD83_Sand* zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    int zT_570;
    unsigned int zT_571;
    int zT_572;
    unsigned int zT_573;
    zT_A62CFBCC_EU_022 zT_574 = {0};
    unsigned char zT_575;
    unsigned char* zT_576;
    unsigned char* zT_577;
    unsigned int* zT_579;
    unsigned int zT_581;
    int zT_582;
    unsigned int zT_583;
    int zT_584;
    unsigned char zT_585;
    unsigned char zT_586;
    int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    int zT_592;
    unsigned int zT_593;
    char* zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_600;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned char* zT_604;
    unsigned int zT_605;
    int zT_606;
    unsigned char* zT_607;
    unsigned int zT_608;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_609;
    unsigned int zT_610 = 0;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    unsigned char* zT_616;
    unsigned int zT_618;
    unsigned char* zT_619;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_621;
    char* zT_623;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_624;
    unsigned int zT_625;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_626;
    int zT_627;
    unsigned int zT_628;
    int zT_629;
    unsigned char zT_630;
    unsigned char zT_631;
    int zT_632;
    char* zT_634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_635;
    unsigned int zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_637;
    char* zT_639;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_640;
    unsigned int zT_641;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_642;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_644;
    unsigned int zT_646;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_647;
    unsigned int zT_648;
    unsigned char* zT_649;
    unsigned int zT_650;
    int zT_651;
    unsigned char* zT_652;
    unsigned int zT_653;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_654;
    unsigned int zT_655 = 0;
    unsigned int zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_660;
    unsigned char* zT_661;
    unsigned int zT_663;
    unsigned char* zT_664;
    unsigned int zT_665;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_666;
    char* zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_671;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_673;
    unsigned int zT_675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_676;
    zT_338B7C76_TypeRegistry* zT_677;
    zT_D155D06D_Type* zT_678;
    zT_D155D06D_Type zT_679;
    zT_33EF6BFB_TypeKind zT_680;
    unsigned int zT_681;
    unsigned char* zT_682;
    unsigned int zT_683;
    int zT_684;
    unsigned char* zT_685;
    unsigned int zT_686;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_687;
    unsigned int zT_688 = 0;
    unsigned int zT_690;
    unsigned int zT_691;
    unsigned int zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_693;
    unsigned char* zT_694;
    unsigned int zT_696;
    unsigned char* zT_697;
    unsigned int zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    char* zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    unsigned int zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    int zT_705;
    unsigned int zT_706;
    zT_010C8DF0_ClassificationResul zT_707;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_5A26C2ED_Arr_unsigned_char_1 cls_b;
    unsigned int cls_l;
    unsigned int cls_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_5A26C2ED_Arr_unsigned_char_1 ctb;
    unsigned int ctl;
    unsigned int cts;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_5A26C2ED_Arr_unsigned_char_1 ckb;
    unsigned int ckl;
    unsigned int cks;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    tl = zT_4;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_10 = zT_9 * tl;
    zT_7 = zT_10;
    zT_11 = 1;
    zT_12 = (unsigned int)zT_11;
    zT_8 = zT_12;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, zT_7, zT_8);
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_16 = zT_13.data.payload;
    zT_15 = zT_16;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    po_raw = zT_15;
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    pointer_only = zT_18;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    wp_edge_cap = zT_21;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_27 = zT_26 * wp_edge_cap;
    zT_24 = zT_27;
    zT_28 = 4;
    zT_29 = (unsigned int)zT_28;
    zT_25 = zT_29;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, zT_24, zT_25);
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_33 = zT_30.data.payload;
    zT_32 = zT_33;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    wp_to_raw = zT_32;
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    wp_to = zT_35;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_41 = zT_40 * wp_edge_cap;
    zT_38 = zT_41;
    zT_42 = 4;
    zT_43 = (unsigned int)zT_42;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    wp_next_raw = zT_46;
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    wp_next = zT_49;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_55 = zT_54 * tl;
    zT_52 = zT_55;
    zT_56 = 4;
    zT_57 = (unsigned int)zT_56;
    zT_53 = zT_57;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, zT_52, zT_53);
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    z_bb_11:
    zT_61 = zT_58.data.payload;
    zT_60 = zT_61;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    wp_head_raw = zT_60;
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    wp_head = zT_63;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    whi = zT_66;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    zT_67 = whi < tl;
    if (zT_67) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_72 = 0;
    wp_count = zT_72;
    wp_count = zT_72;
    wp_count = zT_72;
    zT_74 = perm_alloc;
    zT_77 = 4;
    zT_78 = zT_77 * tl;
    zT_75 = zT_78;
    zT_79 = 4;
    zT_80 = (unsigned int)zT_79;
    zT_76 = zT_80;
    zT_81 = zF_1395EB68_sandAlloc(zT_74, zT_75, zT_76);
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_70 = whi + zT_69;
    whi = zT_70;
    whi = zT_70;
    goto z_bb_13;
    z_bb_17:
    z_bb_18:
    zT_84 = zT_81.data.payload;
    zT_83 = zT_84;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_83;
    wl_raw = zT_83;
    wl_raw = zT_83;
    zT_86 = (unsigned int*)wl_raw;
    worklist = zT_86;
    worklist = zT_86;
    worklist = zT_86;
    zT_88 = 0;
    wl_head = zT_88;
    wl_head = zT_88;
    wl_head = zT_88;
    zT_90 = 0;
    wl_tail = zT_90;
    wl_tail = zT_90;
    wl_tail = zT_90;
    zT_92 = 0;
    zT_93 = (unsigned int)zT_92;
    ti = zT_93;
    ti = zT_93;
    ti = zT_93;
    goto z_bb_20;
    z_bb_20:
    zT_94 = ti < tl;
    if (zT_94) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_96 = self->registry;
    zT_97 = zT_96->types_items;
    zT_98 = zT_97[ti];
    ty = zT_98;
    ty = zT_98;
    ty = zT_98;
    zT_100 = 1;
    is_po = zT_100;
    is_po = zT_100;
    is_po = zT_100;
    zT_101 = ty.kind;
    zT_104 = zT_33EF6BFB_TypeKind_struct_type;
    zT_105 = zT_101 == zT_104;
    if (zT_105) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_112;
    z_bb_23:
    zT_539 = 1;
    zT_540 = ti + zT_539;
    ti = zT_540;
    ti = zT_540;
    goto z_bb_20;
    z_bb_24:
    zT_107 = self->registry;
    zT_108 = zT_107->st_items;
    zT_109 = ty.payload_idx;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zT_108[zT_110];
    sp = zT_111;
    sp = zT_111;
    sp = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fi = zT_114;
    fi = zT_114;
    fi = zT_114;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    zT_533 = 0;
    zT_534 = is_po == zT_533;
    if (zT_534) goto z_bb_110; else goto z_bb_111;
    z_bb_26:
    zT_182 = ty.kind;
    zT_185 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_186 = zT_182 == zT_185;
    if (zT_186) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_115 = sp.fields_count;
    zT_116 = (unsigned int)zT_115;
    zT_117 = fi < zT_116;
    if (zT_117) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_122 = self->registry;
    zT_123 = zT_122->fe_items;
    zT_124 = sp.fields_start;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_125 + fi;
    zT_127 = zT_123[zT_126];
    zT_128 = zT_127.type_id;
    ft_id = zT_128;
    ft_id = zT_128;
    ft_id = zT_128;
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)ft_id;
    zT_133 = zT_131[zT_132];
    ft = zT_133;
    ft = zT_133;
    ft = zT_133;
    zT_135 = ft.kind;
    zT_134 = zT_135;
    zT_136 = zF_A47239A9_fieldEmbedsByValue(zT_134);
    if (zT_136) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_180 = 1;
    zT_181 = fi + zT_180;
    fi = zT_181;
    fi = zT_181;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 0;
    zT_120 = is_po != zT_119;
    zT_118 = zT_120;
    goto z_bb_33;
    z_bb_32:
    zT_118 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_118) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_137 = 0;
    is_po = zT_137;
    is_po = zT_137;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_138 = ft.kind;
    zT_141 = zT_33EF6BFB_TypeKind_optional_type;
    zT_142 = zT_138 == zT_141;
    if (zT_142) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_143 = perm_alloc;
    zT_148 = &wp_to;
    zT_144 = zT_148;
    zT_149 = &wp_next;
    zT_145 = zT_149;
    zT_150 = &wp_edge_cap;
    zT_146 = zT_150;
    zT_147 = wp_count;
    zF_25C377BD_growWpEdges(zT_143, zT_144, zT_145, zT_146, zT_147);
    zT_151 = (unsigned int)ti;
    zT_152 = (unsigned int)wp_count;
    wp_to[zT_152] = zT_151;
    zT_153 = (unsigned int)ft_id;
    zT_154 = wp_head[zT_153];
    zT_155 = (unsigned int)wp_count;
    wp_next[zT_155] = zT_154;
    zT_156 = (unsigned int)ft_id;
    wp_head[zT_156] = wp_count;
    zT_157 = 1;
    zT_158 = wp_count + zT_157;
    wp_count = zT_158;
    wp_count = zT_158;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_159 = ft.kind;
    zT_162 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_163 = zT_159 == zT_162;
    if (zT_163) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_164 = perm_alloc;
    zT_169 = &wp_to;
    zT_165 = zT_169;
    zT_170 = &wp_next;
    zT_166 = zT_170;
    zT_171 = &wp_edge_cap;
    zT_167 = zT_171;
    zT_168 = wp_count;
    zF_25C377BD_growWpEdges(zT_164, zT_165, zT_166, zT_167, zT_168);
    zT_172 = (unsigned int)ti;
    zT_173 = (unsigned int)wp_count;
    wp_to[zT_173] = zT_172;
    zT_174 = (unsigned int)ft_id;
    zT_175 = wp_head[zT_174];
    zT_176 = (unsigned int)wp_count;
    wp_next[zT_176] = zT_175;
    zT_177 = (unsigned int)ft_id;
    wp_head[zT_177] = wp_count;
    zT_178 = 1;
    zT_179 = wp_count + zT_178;
    wp_count = zT_179;
    wp_count = zT_179;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_188 = self->registry;
    zT_189 = zT_188->tu_items;
    zT_190 = ty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tp = zT_192;
    tp = zT_192;
    tp = zT_192;
    zT_194 = 0;
    zT_195 = (unsigned int)zT_194;
    fi = zT_195;
    fi = zT_195;
    fi = zT_195;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_263 = ty.kind;
    zT_266 = zT_33EF6BFB_TypeKind_union_type;
    zT_267 = zT_263 == zT_266;
    if (zT_267) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_196 = tp.fields_count;
    zT_197 = (unsigned int)zT_196;
    zT_198 = fi < zT_197;
    if (zT_198) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_203 = self->registry;
    zT_204 = zT_203->fe_items;
    zT_205 = tp.fields_start;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_206 + fi;
    zT_208 = zT_204[zT_207];
    zT_209 = zT_208.type_id;
    ft_id = zT_209;
    ft_id = zT_209;
    ft_id = zT_209;
    zT_211 = self->registry;
    zT_212 = zT_211->types_items;
    zT_213 = (unsigned int)ft_id;
    zT_214 = zT_212[zT_213];
    ft = zT_214;
    ft = zT_214;
    ft = zT_214;
    zT_216 = ft.kind;
    zT_215 = zT_216;
    zT_217 = zF_A47239A9_fieldEmbedsByValue(zT_215);
    if (zT_217) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_261 = 1;
    zT_262 = fi + zT_261;
    fi = zT_262;
    fi = zT_262;
    goto z_bb_45;
    z_bb_49:
    zT_200 = 0;
    zT_201 = is_po != zT_200;
    zT_199 = zT_201;
    goto z_bb_51;
    z_bb_50:
    zT_199 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_199) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_218 = 0;
    is_po = zT_218;
    is_po = zT_218;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_219 = ft.kind;
    zT_222 = zT_33EF6BFB_TypeKind_optional_type;
    zT_223 = zT_219 == zT_222;
    if (zT_223) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_224 = perm_alloc;
    zT_229 = &wp_to;
    zT_225 = zT_229;
    zT_230 = &wp_next;
    zT_226 = zT_230;
    zT_231 = &wp_edge_cap;
    zT_227 = zT_231;
    zT_228 = wp_count;
    zF_25C377BD_growWpEdges(zT_224, zT_225, zT_226, zT_227, zT_228);
    zT_232 = (unsigned int)ti;
    zT_233 = (unsigned int)wp_count;
    wp_to[zT_233] = zT_232;
    zT_234 = (unsigned int)ft_id;
    zT_235 = wp_head[zT_234];
    zT_236 = (unsigned int)wp_count;
    wp_next[zT_236] = zT_235;
    zT_237 = (unsigned int)ft_id;
    wp_head[zT_237] = wp_count;
    zT_238 = 1;
    zT_239 = wp_count + zT_238;
    wp_count = zT_239;
    wp_count = zT_239;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_240 = ft.kind;
    zT_243 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_244 = zT_240 == zT_243;
    if (zT_244) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_245 = perm_alloc;
    zT_250 = &wp_to;
    zT_246 = zT_250;
    zT_251 = &wp_next;
    zT_247 = zT_251;
    zT_252 = &wp_edge_cap;
    zT_248 = zT_252;
    zT_249 = wp_count;
    zF_25C377BD_growWpEdges(zT_245, zT_246, zT_247, zT_248, zT_249);
    zT_253 = (unsigned int)ti;
    zT_254 = (unsigned int)wp_count;
    wp_to[zT_254] = zT_253;
    zT_255 = (unsigned int)ft_id;
    zT_256 = wp_head[zT_255];
    zT_257 = (unsigned int)wp_count;
    wp_next[zT_257] = zT_256;
    zT_258 = (unsigned int)ft_id;
    wp_head[zT_258] = wp_count;
    zT_259 = 1;
    zT_260 = wp_count + zT_259;
    wp_count = zT_260;
    wp_count = zT_260;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_269 = self->registry;
    zT_270 = zT_269->un_items;
    zT_271 = ty.payload_idx;
    zT_272 = (unsigned int)zT_271;
    zT_273 = zT_270[zT_272];
    up = zT_273;
    up = zT_273;
    up = zT_273;
    zT_275 = 0;
    zT_276 = (unsigned int)zT_275;
    fi = zT_276;
    fi = zT_276;
    fi = zT_276;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_344 = ty.kind;
    zT_347 = zT_33EF6BFB_TypeKind_array_type;
    zT_348 = zT_344 == zT_347;
    if (zT_348) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_277 = up.fields_count;
    zT_278 = (unsigned int)zT_277;
    zT_279 = fi < zT_278;
    if (zT_279) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_284 = self->registry;
    zT_285 = zT_284->fe_items;
    zT_286 = up.fields_start;
    zT_287 = (unsigned int)zT_286;
    zT_288 = zT_287 + fi;
    zT_289 = zT_285[zT_288];
    zT_290 = zT_289.type_id;
    ft_id = zT_290;
    ft_id = zT_290;
    ft_id = zT_290;
    zT_292 = self->registry;
    zT_293 = zT_292->types_items;
    zT_294 = (unsigned int)ft_id;
    zT_295 = zT_293[zT_294];
    ft = zT_295;
    ft = zT_295;
    ft = zT_295;
    zT_297 = ft.kind;
    zT_296 = zT_297;
    zT_298 = zF_A47239A9_fieldEmbedsByValue(zT_296);
    if (zT_298) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_342 = 1;
    zT_343 = fi + zT_342;
    fi = zT_343;
    fi = zT_343;
    goto z_bb_63;
    z_bb_67:
    zT_281 = 0;
    zT_282 = is_po != zT_281;
    zT_280 = zT_282;
    goto z_bb_69;
    z_bb_68:
    zT_280 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_280) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_299 = 0;
    is_po = zT_299;
    is_po = zT_299;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_300 = ft.kind;
    zT_303 = zT_33EF6BFB_TypeKind_optional_type;
    zT_304 = zT_300 == zT_303;
    if (zT_304) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_305 = perm_alloc;
    zT_310 = &wp_to;
    zT_306 = zT_310;
    zT_311 = &wp_next;
    zT_307 = zT_311;
    zT_312 = &wp_edge_cap;
    zT_308 = zT_312;
    zT_309 = wp_count;
    zF_25C377BD_growWpEdges(zT_305, zT_306, zT_307, zT_308, zT_309);
    zT_313 = (unsigned int)ti;
    zT_314 = (unsigned int)wp_count;
    wp_to[zT_314] = zT_313;
    zT_315 = (unsigned int)ft_id;
    zT_316 = wp_head[zT_315];
    zT_317 = (unsigned int)wp_count;
    wp_next[zT_317] = zT_316;
    zT_318 = (unsigned int)ft_id;
    wp_head[zT_318] = wp_count;
    zT_319 = 1;
    zT_320 = wp_count + zT_319;
    wp_count = zT_320;
    wp_count = zT_320;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_321 = ft.kind;
    zT_324 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_325 = zT_321 == zT_324;
    if (zT_325) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_326 = perm_alloc;
    zT_331 = &wp_to;
    zT_327 = zT_331;
    zT_332 = &wp_next;
    zT_328 = zT_332;
    zT_333 = &wp_edge_cap;
    zT_329 = zT_333;
    zT_330 = wp_count;
    zF_25C377BD_growWpEdges(zT_326, zT_327, zT_328, zT_329, zT_330);
    zT_334 = (unsigned int)ti;
    zT_335 = (unsigned int)wp_count;
    wp_to[zT_335] = zT_334;
    zT_336 = (unsigned int)ft_id;
    zT_337 = wp_head[zT_336];
    zT_338 = (unsigned int)wp_count;
    wp_next[zT_338] = zT_337;
    zT_339 = (unsigned int)ft_id;
    wp_head[zT_339] = wp_count;
    zT_340 = 1;
    zT_341 = wp_count + zT_340;
    wp_count = zT_341;
    wp_count = zT_341;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_350 = self->registry;
    zT_351 = zT_350->array_items;
    zT_352 = ty.payload_idx;
    zT_353 = (unsigned int)zT_352;
    zT_354 = zT_351[zT_353];
    zT_355 = zT_354.elem;
    et = zT_355;
    et = zT_355;
    et = zT_355;
    zT_357 = self->registry;
    zT_358 = zT_357->types_items;
    zT_359 = (unsigned int)et;
    zT_360 = zT_358[zT_359];
    et_ty = zT_360;
    et_ty = zT_360;
    et_ty = zT_360;
    zT_362 = et_ty.kind;
    zT_361 = zT_362;
    zT_363 = zF_A47239A9_fieldEmbedsByValue(zT_361);
    if (zT_363) goto z_bb_81; else goto z_bb_83;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_407 = ty.kind;
    zT_410 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_411 = zT_407 == zT_410;
    if (zT_411) goto z_bb_89; else goto z_bb_91;
    z_bb_81:
    zT_364 = 0;
    is_po = zT_364;
    is_po = zT_364;
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_365 = et_ty.kind;
    zT_368 = zT_33EF6BFB_TypeKind_optional_type;
    zT_369 = zT_365 == zT_368;
    if (zT_369) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    zT_370 = perm_alloc;
    zT_375 = &wp_to;
    zT_371 = zT_375;
    zT_376 = &wp_next;
    zT_372 = zT_376;
    zT_377 = &wp_edge_cap;
    zT_373 = zT_377;
    zT_374 = wp_count;
    zF_25C377BD_growWpEdges(zT_370, zT_371, zT_372, zT_373, zT_374);
    zT_378 = (unsigned int)ti;
    zT_379 = (unsigned int)wp_count;
    wp_to[zT_379] = zT_378;
    zT_380 = (unsigned int)et;
    zT_381 = wp_head[zT_380];
    zT_382 = (unsigned int)wp_count;
    wp_next[zT_382] = zT_381;
    zT_383 = (unsigned int)et;
    wp_head[zT_383] = wp_count;
    zT_384 = 1;
    zT_385 = wp_count + zT_384;
    wp_count = zT_385;
    wp_count = zT_385;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_386 = et_ty.kind;
    zT_389 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_390 = zT_386 == zT_389;
    if (zT_390) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_391 = perm_alloc;
    zT_396 = &wp_to;
    zT_392 = zT_396;
    zT_397 = &wp_next;
    zT_393 = zT_397;
    zT_398 = &wp_edge_cap;
    zT_394 = zT_398;
    zT_395 = wp_count;
    zF_25C377BD_growWpEdges(zT_391, zT_392, zT_393, zT_394, zT_395);
    zT_399 = (unsigned int)ti;
    zT_400 = (unsigned int)wp_count;
    wp_to[zT_400] = zT_399;
    zT_401 = (unsigned int)et;
    zT_402 = wp_head[zT_401];
    zT_403 = (unsigned int)wp_count;
    wp_next[zT_403] = zT_402;
    zT_404 = (unsigned int)et;
    wp_head[zT_404] = wp_count;
    zT_405 = 1;
    zT_406 = wp_count + zT_405;
    wp_count = zT_406;
    wp_count = zT_406;
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_413 = self->registry;
    zT_414 = zT_413->eu_items;
    zT_415 = ty.payload_idx;
    zT_416 = (unsigned int)zT_415;
    zT_417 = zT_414[zT_416];
    zT_418 = zT_417.payload;
    eup = zT_418;
    eup = zT_418;
    eup = zT_418;
    zT_420 = self->registry;
    zT_421 = zT_420->types_items;
    zT_422 = (unsigned int)eup;
    zT_423 = zT_421[zT_422];
    eup_ty = zT_423;
    eup_ty = zT_423;
    eup_ty = zT_423;
    zT_425 = eup_ty.kind;
    zT_424 = zT_425;
    zT_426 = zF_A47239A9_fieldEmbedsByValue(zT_424);
    if (zT_426) goto z_bb_92; else goto z_bb_94;
    z_bb_90:
    goto z_bb_79;
    z_bb_91:
    zT_470 = ty.kind;
    zT_473 = zT_33EF6BFB_TypeKind_optional_type;
    zT_474 = zT_470 == zT_473;
    if (zT_474) goto z_bb_100; else goto z_bb_101;
    z_bb_92:
    zT_427 = 0;
    is_po = zT_427;
    is_po = zT_427;
    goto z_bb_93;
    z_bb_93:
    goto z_bb_90;
    z_bb_94:
    zT_428 = eup_ty.kind;
    zT_431 = zT_33EF6BFB_TypeKind_optional_type;
    zT_432 = zT_428 == zT_431;
    if (zT_432) goto z_bb_95; else goto z_bb_97;
    z_bb_95:
    zT_433 = perm_alloc;
    zT_438 = &wp_to;
    zT_434 = zT_438;
    zT_439 = &wp_next;
    zT_435 = zT_439;
    zT_440 = &wp_edge_cap;
    zT_436 = zT_440;
    zT_437 = wp_count;
    zF_25C377BD_growWpEdges(zT_433, zT_434, zT_435, zT_436, zT_437);
    zT_441 = (unsigned int)ti;
    zT_442 = (unsigned int)wp_count;
    wp_to[zT_442] = zT_441;
    zT_443 = (unsigned int)eup;
    zT_444 = wp_head[zT_443];
    zT_445 = (unsigned int)wp_count;
    wp_next[zT_445] = zT_444;
    zT_446 = (unsigned int)eup;
    wp_head[zT_446] = wp_count;
    zT_447 = 1;
    zT_448 = wp_count + zT_447;
    wp_count = zT_448;
    wp_count = zT_448;
    goto z_bb_96;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_449 = eup_ty.kind;
    zT_452 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_453 = zT_449 == zT_452;
    if (zT_453) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_454 = perm_alloc;
    zT_459 = &wp_to;
    zT_455 = zT_459;
    zT_460 = &wp_next;
    zT_456 = zT_460;
    zT_461 = &wp_edge_cap;
    zT_457 = zT_461;
    zT_458 = wp_count;
    zF_25C377BD_growWpEdges(zT_454, zT_455, zT_456, zT_457, zT_458);
    zT_462 = (unsigned int)ti;
    zT_463 = (unsigned int)wp_count;
    wp_to[zT_463] = zT_462;
    zT_464 = (unsigned int)eup;
    zT_465 = wp_head[zT_464];
    zT_466 = (unsigned int)wp_count;
    wp_next[zT_466] = zT_465;
    zT_467 = (unsigned int)eup;
    wp_head[zT_467] = wp_count;
    zT_468 = 1;
    zT_469 = wp_count + zT_468;
    wp_count = zT_469;
    wp_count = zT_469;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_96;
    z_bb_100:
    zT_476 = self->registry;
    zT_477 = zT_476->opt_items;
    zT_478 = ty.payload_idx;
    zT_479 = (unsigned int)zT_478;
    zT_480 = zT_477[zT_479];
    zT_481 = zT_480.payload;
    op_p = zT_481;
    op_p = zT_481;
    op_p = zT_481;
    zT_483 = self->registry;
    zT_484 = zT_483->types_items;
    zT_485 = (unsigned int)op_p;
    zT_486 = zT_484[zT_485];
    op_ty = zT_486;
    op_ty = zT_486;
    op_ty = zT_486;
    zT_488 = op_ty.kind;
    zT_487 = zT_488;
    zT_489 = zF_EA3ED3F3_requiresFullDef(zT_487);
    if (zT_489) goto z_bb_102; else goto z_bb_104;
    z_bb_101:
    goto z_bb_90;
    z_bb_102:
    zT_490 = 0;
    is_po = zT_490;
    is_po = zT_490;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_101;
    z_bb_104:
    zT_491 = op_ty.kind;
    zT_494 = zT_33EF6BFB_TypeKind_optional_type;
    zT_495 = zT_491 == zT_494;
    if (zT_495) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_496 = perm_alloc;
    zT_501 = &wp_to;
    zT_497 = zT_501;
    zT_502 = &wp_next;
    zT_498 = zT_502;
    zT_503 = &wp_edge_cap;
    zT_499 = zT_503;
    zT_500 = wp_count;
    zF_25C377BD_growWpEdges(zT_496, zT_497, zT_498, zT_499, zT_500);
    zT_504 = (unsigned int)ti;
    zT_505 = (unsigned int)wp_count;
    wp_to[zT_505] = zT_504;
    zT_506 = (unsigned int)op_p;
    zT_507 = wp_head[zT_506];
    zT_508 = (unsigned int)wp_count;
    wp_next[zT_508] = zT_507;
    zT_509 = (unsigned int)op_p;
    wp_head[zT_509] = wp_count;
    zT_510 = 1;
    zT_511 = wp_count + zT_510;
    wp_count = zT_511;
    wp_count = zT_511;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_512 = op_ty.kind;
    zT_515 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_516 = zT_512 == zT_515;
    if (zT_516) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_517 = perm_alloc;
    zT_522 = &wp_to;
    zT_518 = zT_522;
    zT_523 = &wp_next;
    zT_519 = zT_523;
    zT_524 = &wp_edge_cap;
    zT_520 = zT_524;
    zT_521 = wp_count;
    zF_25C377BD_growWpEdges(zT_517, zT_518, zT_519, zT_520, zT_521);
    zT_525 = (unsigned int)ti;
    zT_526 = (unsigned int)wp_count;
    wp_to[zT_526] = zT_525;
    zT_527 = (unsigned int)op_p;
    zT_528 = wp_head[zT_527];
    zT_529 = (unsigned int)wp_count;
    wp_next[zT_529] = zT_528;
    zT_530 = (unsigned int)op_p;
    wp_head[zT_530] = wp_count;
    zT_531 = 1;
    zT_532 = wp_count + zT_531;
    wp_count = zT_532;
    wp_count = zT_532;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_535 = (unsigned int)ti;
    zT_536 = (unsigned int)wl_tail;
    worklist[zT_536] = zT_535;
    zT_537 = 1;
    zT_538 = wl_tail + zT_537;
    wl_tail = zT_538;
    wl_tail = zT_538;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_23;
    z_bb_112:
    zT_541 = wl_head < wl_tail;
    if (zT_541) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_543 = (unsigned int)wl_head;
    zT_544 = worklist[zT_543];
    cur = zT_544;
    cur = zT_544;
    cur = zT_544;
    zT_545 = 1;
    zT_546 = wl_head + zT_545;
    wl_head = zT_546;
    wl_head = zT_546;
    zT_548 = (unsigned int)cur;
    zT_549 = wp_head[zT_548];
    e = zT_549;
    e = zT_549;
    e = zT_549;
    goto z_bb_116;
    z_bb_114:
    zT_567 = perm_alloc;
    zT_570 = 4;
    zT_571 = zT_570 * tl;
    zT_568 = zT_571;
    zT_572 = 4;
    zT_573 = (unsigned int)zT_572;
    zT_569 = zT_573;
    zT_574 = zF_1395EB68_sandAlloc(zT_567, zT_568, zT_569);
    zT_575 = zT_574.is_error;
    if (zT_575) goto z_bb_122; else goto z_bb_123;
    z_bb_115:
    goto z_bb_112;
    z_bb_116:
    zT_550 = 4294967295u;
    zT_551 = e != zT_550;
    if (zT_551) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_553 = (unsigned int)e;
    zT_554 = wp_to[zT_553];
    parent_tid = zT_554;
    parent_tid = zT_554;
    parent_tid = zT_554;
    zT_555 = (unsigned int)parent_tid;
    zT_556 = pointer_only[zT_555];
    zT_557 = 0;
    zT_558 = zT_556 != zT_557;
    if (zT_558) goto z_bb_120; else goto z_bb_121;
    z_bb_118:
    goto z_bb_115;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_559 = 0;
    zT_560 = (unsigned int)parent_tid;
    pointer_only[zT_560] = zT_559;
    zT_561 = (unsigned int)wl_tail;
    worklist[zT_561] = parent_tid;
    zT_562 = 1;
    zT_563 = wl_tail + zT_562;
    wl_tail = zT_563;
    wl_tail = zT_563;
    goto z_bb_121;
    z_bb_121:
    zT_564 = (unsigned int)e;
    zT_565 = wp_next[zT_564];
    e = zT_565;
    e = zT_565;
    goto z_bb_119;
    z_bb_122:
    z_bb_123:
    zT_577 = zT_574.data.payload;
    zT_576 = zT_577;
    goto z_bb_124;
    z_bb_124:
    ids_raw = zT_576;
    ids_raw = zT_576;
    ids_raw = zT_576;
    zT_579 = (unsigned int*)ids_raw;
    ids = zT_579;
    ids = zT_579;
    ids = zT_579;
    zT_581 = 0;
    plen = zT_581;
    plen = zT_581;
    plen = zT_581;
    zT_582 = 0;
    zT_583 = (unsigned int)zT_582;
    ti = zT_583;
    ti = zT_583;
    goto z_bb_125;
    z_bb_125:
    zT_584 = ti < tl;
    if (zT_584) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_585 = pointer_only[ti];
    zT_586 = 0;
    zT_587 = zT_585 != zT_586;
    if (zT_587) goto z_bb_129; else goto z_bb_130;
    z_bb_127:
    zT_595 = "CLS:c";
    zT_597 = 5;
    zT_596.ptr = zT_595;
    zT_596.len = zT_597;
    cls_m = zT_596;
    cls_m = zT_596;
    cls_m = zT_596;
    zT_598 = cls_m;
    zF_48AC7B3A_markerWrite(zT_598);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_600[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cls_b[_i] = zT_600[_i];
        _i++;
    }
}
    zT_602 = plen;
    zT_604 = (unsigned char*)cls_b;
    zT_605 = 10;
    zT_606 = 0;
    zT_607 = zT_604 + zT_606;
    zT_608 = zT_605 - zT_606;
    zT_609.ptr = zT_607;
    zT_609.len = zT_608;
    zT_603 = zT_609;
    zT_610 = zF_A7504564_itoa(zT_602, zT_603);
    cls_l = zT_610;
    cls_l = zT_610;
    cls_l = zT_610;
    zT_612 = 9;
    zT_613 = (unsigned int)cls_l;
    zT_614 = zT_612 - zT_613;
    cls_s = zT_614;
    cls_s = zT_614;
    cls_s = zT_614;
    zT_616 = (unsigned char*)cls_b;
    zT_618 = 9;
    zT_619 = zT_616 + cls_s;
    zT_620 = zT_618 - cls_s;
    zT_621.ptr = zT_619;
    zT_621.len = zT_620;
    zT_615 = zT_621;
    zF_48AC7B3A_markerWrite(zT_615);
    zT_623 = "\n";
    zT_625 = 1;
    zT_624.ptr = zT_623;
    zT_624.len = zT_625;
    cls_nl = zT_624;
    cls_nl = zT_624;
    cls_nl = zT_624;
    zT_626 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_626);
    zT_627 = 0;
    zT_628 = (unsigned int)zT_627;
    ti = zT_628;
    ti = zT_628;
    goto z_bb_131;
    z_bb_128:
    zT_592 = 1;
    zT_593 = ti + zT_592;
    ti = zT_593;
    ti = zT_593;
    goto z_bb_125;
    z_bb_129:
    zT_588 = (unsigned int)ti;
    zT_589 = (unsigned int)plen;
    ids[zT_589] = zT_588;
    zT_590 = 1;
    zT_591 = plen + zT_590;
    plen = zT_591;
    plen = zT_591;
    goto z_bb_130;
    z_bb_130:
    goto z_bb_128;
    z_bb_131:
    zT_629 = ti < tl;
    if (zT_629) goto z_bb_132; else goto z_bb_133;
    z_bb_132:
    zT_630 = pointer_only[ti];
    zT_631 = 0;
    zT_632 = zT_630 != zT_631;
    if (zT_632) goto z_bb_135; else goto z_bb_137;
    z_bb_133:
    zT_707.ids = ids;
    zT_707.len = plen;
    return zT_707;
    z_bb_134:
    zT_705 = 1;
    zT_706 = ti + zT_705;
    ti = zT_706;
    ti = zT_706;
    goto z_bb_131;
    z_bb_135:
    zT_634 = "CLS:p";
    zT_636 = 5;
    zT_635.ptr = zT_634;
    zT_635.len = zT_636;
    pfx = zT_635;
    pfx = zT_635;
    pfx = zT_635;
    zT_637 = pfx;
    zF_48AC7B3A_markerWrite(zT_637);
    goto z_bb_136;
    z_bb_136:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_644[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ctb[_i] = zT_644[_i];
        _i++;
    }
}
    zT_648 = (unsigned int)ti;
    zT_646 = zT_648;
    zT_649 = (unsigned char*)ctb;
    zT_650 = 10;
    zT_651 = 0;
    zT_652 = zT_649 + zT_651;
    zT_653 = zT_650 - zT_651;
    zT_654.ptr = zT_652;
    zT_654.len = zT_653;
    zT_647 = zT_654;
    zT_655 = zF_A7504564_itoa(zT_646, zT_647);
    ctl = zT_655;
    ctl = zT_655;
    ctl = zT_655;
    zT_657 = 9;
    zT_658 = (unsigned int)ctl;
    zT_659 = zT_657 - zT_658;
    cts = zT_659;
    cts = zT_659;
    cts = zT_659;
    zT_661 = (unsigned char*)ctb;
    zT_663 = 9;
    zT_664 = zT_661 + cts;
    zT_665 = zT_663 - cts;
    zT_666.ptr = zT_664;
    zT_666.len = zT_665;
    zT_660 = zT_666;
    zF_48AC7B3A_markerWrite(zT_660);
    zT_668 = "k";
    zT_670 = 1;
    zT_669.ptr = zT_668;
    zT_669.len = zT_670;
    ck = zT_669;
    ck = zT_669;
    ck = zT_669;
    zT_671 = ck;
    zF_48AC7B3A_markerWrite(zT_671);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_673[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ckb[_i] = zT_673[_i];
        _i++;
    }
}
    zT_677 = self->registry;
    zT_678 = zT_677->types_items;
    zT_679 = zT_678[ti];
    zT_680 = zT_679.kind;
    zT_681 = (unsigned int)zT_680;
    zT_675 = zT_681;
    zT_682 = (unsigned char*)ckb;
    zT_683 = 10;
    zT_684 = 0;
    zT_685 = zT_682 + zT_684;
    zT_686 = zT_683 - zT_684;
    zT_687.ptr = zT_685;
    zT_687.len = zT_686;
    zT_676 = zT_687;
    zT_688 = zF_A7504564_itoa(zT_675, zT_676);
    ckl = zT_688;
    ckl = zT_688;
    ckl = zT_688;
    zT_690 = 9;
    zT_691 = (unsigned int)ckl;
    zT_692 = zT_690 - zT_691;
    cks = zT_692;
    cks = zT_692;
    cks = zT_692;
    zT_694 = (unsigned char*)ckb;
    zT_696 = 9;
    zT_697 = zT_694 + cks;
    zT_698 = zT_696 - cks;
    zT_699.ptr = zT_697;
    zT_699.len = zT_698;
    zT_693 = zT_699;
    zF_48AC7B3A_markerWrite(zT_693);
    zT_701 = "\n";
    zT_703 = 1;
    zT_702.ptr = zT_701;
    zT_702.len = zT_703;
    cnl = zT_702;
    cnl = zT_702;
    cnl = zT_702;
    zT_704 = cnl;
    zF_48AC7B3A_markerWrite(zT_704);
    goto z_bb_134;
    z_bb_137:
    zT_639 = "CLS:v";
    zT_641 = 5;
    zT_640.ptr = zT_639;
    zT_640.len = zT_641;
    pfx = zT_640;
    pfx = zT_640;
    pfx = zT_640;
    zT_642 = pfx;
    zF_48AC7B3A_markerWrite(zT_642);
    goto z_bb_136;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A62CFBCC_EU_022 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char* zT_24;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    zT_A62CFBCC_EU_022 zT_33 = {0};
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned char* zT_36;
    unsigned int* zT_38;
    unsigned int* zT_40;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    int zT_45;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* new_to_raw;
    unsigned char* new_nx_raw;
    unsigned int* new_to;
    unsigned int* new_nx;
    unsigned int ci;
    zT_5 = (unsigned int)count;
    zT_6 = *cap_ptr;
    zT_7 = zT_5 < zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap_ptr;
    old_cap = zT_9;
    old_cap = zT_9;
    old_cap = zT_9;
    zT_11 = 2;
    zT_12 = old_cap * zT_11;
    new_cap = zT_12;
    new_cap = zT_12;
    new_cap = zT_12;
    zT_14 = perm_a;
    zT_17 = 4;
    zT_18 = zT_17 * new_cap;
    zT_15 = zT_18;
    zT_19 = 4;
    zT_20 = (unsigned int)zT_19;
    zT_16 = zT_20;
    zT_21 = zF_1395EB68_sandAlloc(zT_14, zT_15, zT_16);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    z_bb_4:
    zT_24 = zT_21.data.payload;
    zT_23 = zT_24;
    goto z_bb_5;
    z_bb_5:
    new_to_raw = zT_23;
    new_to_raw = zT_23;
    new_to_raw = zT_23;
    zT_26 = perm_a;
    zT_29 = 4;
    zT_30 = zT_29 * new_cap;
    zT_27 = zT_30;
    zT_31 = 4;
    zT_32 = (unsigned int)zT_31;
    zT_28 = zT_32;
    zT_33 = zF_1395EB68_sandAlloc(zT_26, zT_27, zT_28);
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    z_bb_7:
    zT_36 = zT_33.data.payload;
    zT_35 = zT_36;
    goto z_bb_8;
    z_bb_8:
    new_nx_raw = zT_35;
    new_nx_raw = zT_35;
    new_nx_raw = zT_35;
    zT_38 = (unsigned int*)new_to_raw;
    new_to = zT_38;
    new_to = zT_38;
    new_to = zT_38;
    zT_40 = (unsigned int*)new_nx_raw;
    new_nx = zT_40;
    new_nx = zT_40;
    new_nx = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    ci = zT_43;
    ci = zT_43;
    goto z_bb_9;
    z_bb_9:
    zT_44 = (unsigned int)count;
    zT_45 = ci < zT_44;
    if (zT_45) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *wp_to_ptr;
    zT_47 = zT_46[ci];
    new_to[ci] = zT_47;
    zT_48 = *wp_next_ptr;
    zT_49 = zT_48[ci];
    new_nx[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *wp_to_ptr = new_to;
    *wp_next_ptr = new_nx;
    *cap_ptr = new_cap;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    ci = zT_51;
    goto z_bb_9;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8143F551_AstKind zT_13;
    int zT_14;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_79FAE712_u64 zT_18 = 0;
    unsigned int zT_19;
    zT_8143F551_AstKind zT_20;
    zT_8143F551_AstKind zT_23;
    int zT_24;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_31;
    unsigned int zT_32;
    zT_E68301A1_Opt_804 zT_33 = {0};
    unsigned char zT_34;
    unsigned short zT_36;
    unsigned short zT_37;
    unsigned short zT_38;
    unsigned short zT_39;
    int zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_46 = {0};
    unsigned int zT_47;
    int zT_48;
    int zT_49;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E68301A1_Opt_804 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    zT_2 = 0;
    zT_3 = node_idx == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 4294967295u;
    return zT_4;
    z_bb_2:
    zT_8 = env->store;
    zT_6 = zT_8;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    node = zT_9;
    node = zT_9;
    zT_10 = node.kind;
    zT_13 = zT_8143F551_AstKind_int_literal;
    zT_14 = zT_10 == zT_13;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = env->store;
    zT_15 = zT_17;
    zT_16 = node_idx;
    zT_18 = zF_678B9A72_astStoreIntValue(zT_15, zT_16);
    zT_19 = __bootstrap_u32_from_u64(zT_18);
    return zT_19;
    z_bb_4:
    zT_20 = node.kind;
    zT_23 = zT_8143F551_AstKind_ident_expr;
    zT_24 = zT_20 == zT_23;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_28 = env->store;
    zT_26 = zT_28;
    zT_27 = node_idx;
    zT_29 = zF_53458827_astStoreIdentifier(zT_26, zT_27);
    name_id = zT_29;
    name_id = zT_29;
    name_id = zT_29;
    zT_31 = env;
    zT_32 = name_id;
    zT_33 = zF_04FED007_symbolLookupAllModu(zT_31, zT_32);
    c_sym = zT_33;
    c_sym = zT_33;
    c_sym = zT_33;
    zT_34 = c_sym.has_value;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_54 = 4294967295u;
    return zT_54;
    z_bb_7:
    cs = c_sym.value;
    zT_36 = cs->flags;
    zT_37 = 1;
    zT_38 = zT_36 & zT_37;
    zT_39 = 0;
    zT_40 = zT_38 == zT_39;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_44 = env->store;
    zT_42 = zT_44;
    zT_45 = cs->decl_node;
    zT_43 = zT_45;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    c_decl = zT_46;
    c_decl = zT_46;
    c_decl = zT_46;
    zT_47 = c_decl.child_1;
    zT_48 = 0;
    zT_49 = zT_47 != (unsigned int)zT_48;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_50 = env;
    zT_52 = c_decl.child_1;
    zT_51 = zT_52;
    env = zT_50;
    node_idx = zT_51;
    goto z_bb_0;
    z_bb_12:
    goto z_bb_10;
}

/* symbolLookupAllModules */
zT_E68301A1_Opt_804 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    unsigned int zT_14;
    zT_E68301A1_Opt_804 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_E68301A1_Opt_804 zT_19 = {0};
    unsigned int si;
    zT_E68301A1_Opt_804 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    si = zT_4;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    zT_7 = (unsigned int)zT_6;
    zT_8 = si < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = env->symbol_reg;
    zT_10 = zT_13;
    zT_14 = (unsigned int)si;
    zT_11 = zT_14;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    sym = zT_15;
    sym = zT_15;
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_4:
    zT_17 = 1;
    zT_18 = si + zT_17;
    si = zT_18;
    si = zT_18;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_3;
    int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_22A7C88B_AstNode zT_10 = {0};
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    unsigned int zT_24;
    zT_8143F551_AstKind zT_25;
    zT_8143F551_AstKind zT_28;
    int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34 = 0;
    char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    int zT_53;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_56;
    zT_79FAE712_u64 zT_57;
    zT_79FAE712_u64 zT_58;
    zT_79FAE712_u64 zT_59;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_64;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_338B7C76_TypeRegistry* zT_71;
    zT_79FAE712_u64 zT_72;
    zT_BAEE192E_Opt_10 zT_73 = {0};
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_96;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_98;
    zT_79FAE712_u64 zT_99;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_79FAE712_u64 zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_BAEE192E_Opt_10 zT_104 = {0};
    unsigned char zT_105;
    int zT_107;
    unsigned int zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    int zT_116;
    zT_3D7259E2_SymbolRegistry* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_3D7259E2_SymbolRegistry* zT_121;
    unsigned int zT_122;
    zT_E68301A1_Opt_804 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_3D7259E2_SymbolRegistry* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_136;
    zT_3D7259E2_SymbolRegistry* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_3D7259E2_SymbolRegistry* zT_141;
    unsigned int zT_142;
    zT_E68301A1_Opt_804 zT_143 = {0};
    unsigned char zT_144;
    unsigned int zT_146;
    unsigned int zT_147;
    int zT_148;
    char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    int* zT_169;
    int* zT_170;
    unsigned int zT_171 = 0;
    unsigned int zT_172;
    int zT_173;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    unsigned int zT_177 = 0;
    unsigned int zT_178;
    zT_8143F551_AstKind zT_179;
    zT_8143F551_AstKind zT_182;
    int zT_183;
    zT_5826BFC7_Arr_unsigned_char_1 zT_185;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned char* zT_189;
    unsigned int zT_190;
    int zT_191;
    unsigned char* zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195 = 0;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    zT_4428DEE2_Arr_unsigned_char_2 zT_201;
    unsigned char zT_202;
    int zT_203;
    unsigned char zT_204;
    int zT_205;
    unsigned char zT_206;
    int zT_207;
    unsigned char zT_208;
    int zT_209;
    unsigned char zT_210;
    int zT_211;
    int zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    int zT_216;
    unsigned int zT_217;
    unsigned char zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    int zT_221;
    unsigned int zT_222;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_D3EB6303_StringInterner* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    zT_D3EB6303_StringInterner* zT_230;
    unsigned char* zT_231;
    int zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237 = 0;
    zT_338B7C76_TypeRegistry* zT_239;
    zT_79FAE712_u64 zT_240;
    zT_338B7C76_TypeRegistry* zT_241;
    zT_79FAE712_u64 zT_242;
    zT_BAEE192E_Opt_10 zT_243 = {0};
    unsigned char zT_244;
    zT_338B7C76_TypeRegistry* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    zT_33EF6BFB_TypeKind zT_250;
    zT_338B7C76_TypeRegistry* zT_251;
    unsigned int zT_252;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned int zT_256 = 0;
    unsigned char zT_257;
    unsigned char zT_258;
    unsigned char zT_259;
    unsigned char zT_260;
    int zT_261;
    zT_338B7C76_TypeRegistry* zT_262;
    unsigned int zT_263;
    zT_338B7C76_TypeRegistry* zT_264;
    zT_6B0A7D14_AstStore* zT_265;
    unsigned int zT_266;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268 = 0;
    unsigned int zT_269;
    int zT_270;
    zT_6B0A7D14_AstStore* zT_272;
    unsigned int zT_273;
    zT_6B0A7D14_AstStore* zT_274;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_275 = {0};
    zT_9D2DA37C_Arr_unsigned_int_32 zT_277;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_279;
    int zT_281;
    unsigned int zT_282;
    int zT_284;
    unsigned int zT_285;
    unsigned int zT_287;
    int zT_288;
    int zT_289;
    unsigned int zT_290;
    int zT_291;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_294;
    zT_6B0A7D14_AstStore* zT_295;
    unsigned int* zT_296;
    unsigned int zT_297;
    zT_22A7C88B_AstNode zT_298 = {0};
    zT_8143F551_AstKind zT_299;
    zT_8143F551_AstKind zT_302;
    int zT_303;
    zT_ABC1EBBE_TypeResolveEnv* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_311 = 0;
    zT_6B0A7D14_AstStore* zT_312;
    unsigned int zT_313;
    zT_6B0A7D14_AstStore* zT_314;
    unsigned int* zT_315;
    unsigned int zT_316;
    unsigned int zT_317 = 0;
    int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    int zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    int zT_324;
    zT_338B7C76_TypeRegistry* zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    int zT_330;
    unsigned int zT_331;
    int zT_332;
    zT_338B7C76_TypeRegistry* zT_333;
    zT_2DF01B61_FieldEntry zT_334;
    zT_338B7C76_TypeRegistry* zT_335;
    zT_2DF01B61_FieldEntry zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    int zT_340;
    unsigned int zT_341;
    zT_338B7C76_TypeRegistry* zT_342;
    zT_406493CE_StructPayload zT_343;
    zT_338B7C76_TypeRegistry* zT_344;
    zT_406493CE_StructPayload zT_345;
    unsigned int zT_346;
    unsigned short zT_347;
    zT_338B7C76_TypeRegistry* zT_349;
    unsigned int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_D155D06D_Type* zT_356;
    unsigned int zT_357;
    zT_D155D06D_Type zT_358;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_D155D06D_Type* zT_360;
    unsigned int zT_361;
    zT_8143F551_AstKind zT_362;
    zT_8143F551_AstKind zT_365;
    int zT_366;
    unsigned char zT_368;
    zT_ABC1EBBE_TypeResolveEnv* zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned int zT_374;
    unsigned int zT_375;
    unsigned int zT_376 = 0;
    unsigned int zT_377;
    int zT_378;
    zT_6B0A7D14_AstStore* zT_380;
    unsigned int zT_381;
    zT_6B0A7D14_AstStore* zT_382;
    unsigned int zT_383;
    zT_22A7C88B_AstNode zT_384 = {0};
    zT_8143F551_AstKind zT_385;
    zT_8143F551_AstKind zT_388;
    int zT_389;
    zT_6B0A7D14_AstStore* zT_391;
    unsigned int zT_392;
    zT_6B0A7D14_AstStore* zT_393;
    unsigned int zT_394;
    unsigned int zT_395 = 0;
    int zT_397;
    unsigned int zT_398;
    zT_3D7259E2_SymbolRegistry* zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    int zT_402;
    zT_3D7259E2_SymbolRegistry* zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_3D7259E2_SymbolRegistry* zT_407;
    unsigned int zT_408;
    zT_E68301A1_Opt_804 zT_409 = {0};
    unsigned char zT_410;
    zT_3C598AEF_SymbolKind zT_412;
    zT_3C598AEF_SymbolKind zT_415;
    int zT_416;
    unsigned int zT_418;
    zT_3D7259E2_SymbolRegistry* zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    zT_3D7259E2_SymbolRegistry* zT_423;
    zT_6B0A7D14_AstStore* zT_424;
    unsigned int zT_425;
    zT_6B0A7D14_AstStore* zT_426;
    unsigned int zT_427 = 0;
    zT_E68301A1_Opt_804 zT_428 = {0};
    unsigned char zT_429;
    unsigned int zT_431;
    unsigned int zT_432;
    int zT_433;
    unsigned char zT_434;
    char* zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    unsigned int zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    int zT_443;
    unsigned int zT_444;
    char* zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_447;
    unsigned int zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    zT_338B7C76_TypeRegistry* zT_454;
    zT_D155D06D_Type* zT_455;
    unsigned int zT_456;
    zT_D155D06D_Type zT_457;
    zT_33EF6BFB_TypeKind zT_458;
    zT_33EF6BFB_TypeKind zT_461;
    int zT_462;
    unsigned int zT_464;
    zT_3D7259E2_SymbolRegistry* zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    zT_3D7259E2_SymbolRegistry* zT_469;
    zT_6B0A7D14_AstStore* zT_470;
    unsigned int zT_471;
    zT_6B0A7D14_AstStore* zT_472;
    unsigned int zT_473 = 0;
    zT_E68301A1_Opt_804 zT_474 = {0};
    unsigned char zT_475;
    unsigned int zT_477;
    unsigned int zT_478;
    int zT_479;
    unsigned char zT_480;
    char* zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned char zT_489;
    int zT_490;
    char* zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned int zT_494;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    unsigned int zT_496;
    zT_8143F551_AstKind zT_497;
    zT_8143F551_AstKind zT_500;
    int zT_501;
    zT_939EE900_Arr_unsigned_int_1 zT_503;
    zT_338B7C76_TypeRegistry* zT_504;
    unsigned int zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    zT_EDD37787_Arr_unsigned_short_ zT_509;
    unsigned short zT_510;
    unsigned int zT_511;
    zT_6B0A7D14_AstStore* zT_512;
    unsigned int zT_513;
    zT_6B0A7D14_AstStore* zT_514;
    unsigned int zT_515 = 0;
    unsigned int zT_516;
    int zT_517;
    zT_6B0A7D14_AstStore* zT_519;
    unsigned int zT_520;
    zT_6B0A7D14_AstStore* zT_521;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_522 = {0};
    unsigned int zT_524;
    unsigned short zT_525;
    int zT_526;
    int zT_528;
    unsigned int zT_529;
    unsigned int zT_531;
    int zT_532;
    zT_338B7C76_TypeRegistry* zT_533;
    unsigned int zT_534;
    zT_338B7C76_TypeRegistry* zT_535;
    unsigned int* zT_536;
    unsigned int zT_537;
    int zT_538;
    unsigned int zT_539;
    zT_338B7C76_TypeRegistry* zT_540;
    unsigned int zT_541;
    unsigned short zT_542;
    zT_338B7C76_TypeRegistry* zT_543;
    int zT_544;
    unsigned int zT_545;
    int zT_546;
    unsigned short zT_547;
    unsigned int zT_548 = 0;
    zT_8143F551_AstKind zT_549;
    zT_8143F551_AstKind zT_552;
    int zT_553;
    zT_ABC1EBBE_TypeResolveEnv* zT_555;
    unsigned int zT_556;
    unsigned int zT_557;
    unsigned int zT_558;
    unsigned int zT_559;
    unsigned int zT_560;
    unsigned int zT_561 = 0;
    unsigned int zT_562;
    int zT_563;
    unsigned int zT_564;
    zT_939EE900_Arr_unsigned_int_1 zT_566;
    unsigned int zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    int zT_570;
    int zT_571;
    zT_ABC1EBBE_TypeResolveEnv* zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    unsigned int zT_578;
    unsigned int zT_579 = 0;
    unsigned int zT_580;
    int zT_581;
    unsigned int zT_582;
    int zT_583;
    unsigned int zT_584;
    int zT_585;
    zT_338B7C76_TypeRegistry* zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    zT_338B7C76_TypeRegistry* zT_589;
    int zT_590;
    unsigned int zT_591;
    unsigned int zT_592 = 0;
    zT_8143F551_AstKind zT_593;
    zT_8143F551_AstKind zT_596;
    int zT_597;
    zT_939EE900_Arr_unsigned_int_1 zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned int zT_602;
    int zT_603;
    unsigned int zT_604;
    int zT_605;
    int zT_606;
    zT_ABC1EBBE_TypeResolveEnv* zT_607;
    unsigned int zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_612;
    unsigned int zT_613 = 0;
    int zT_614;
    char* zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    unsigned int zT_618;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_619;
    unsigned int zT_620;
    int zT_621;
    unsigned int zT_622;
    int zT_623;
    unsigned int zT_624;
    unsigned int zT_625;
    int zT_626;
    unsigned int zT_627;
    zT_99292002_Arr_unsigned_int_16 zT_629;
    unsigned int zT_631;
    zT_6B0A7D14_AstStore* zT_632;
    unsigned int zT_633;
    zT_6B0A7D14_AstStore* zT_634;
    unsigned int zT_635 = 0;
    unsigned int zT_636;
    int zT_637;
    zT_6B0A7D14_AstStore* zT_639;
    unsigned int zT_640;
    zT_6B0A7D14_AstStore* zT_641;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_642 = {0};
    unsigned int zT_644;
    unsigned int zT_646;
    int zT_647;
    int zT_648;
    unsigned int zT_649;
    int zT_650;
    zT_ABC1EBBE_TypeResolveEnv* zT_652;
    unsigned int zT_653;
    unsigned int zT_654;
    unsigned int* zT_655;
    unsigned int zT_656;
    unsigned int zT_657;
    unsigned int zT_658;
    unsigned int zT_659 = 0;
    unsigned int zT_660;
    int zT_661;
    unsigned int zT_662;
    unsigned int zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    zT_443A2803_Arr_unsigned_char_9 zT_668;
    unsigned int zT_670;
    char* zT_672;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_673;
    unsigned int zT_674;
    unsigned int zT_676;
    unsigned int zT_678;
    int zT_679;
    int zT_680;
    unsigned int zT_681;
    int zT_682;
    unsigned char* zT_683;
    unsigned char zT_684;
    unsigned int zT_685;
    unsigned int zT_686;
    unsigned int zT_687;
    unsigned int zT_688;
    zT_5826BFC7_Arr_unsigned_char_1 zT_690;
    unsigned int zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_693;
    int zT_694;
    unsigned int zT_695;
    unsigned char* zT_696;
    unsigned int zT_697;
    int zT_698;
    unsigned char* zT_699;
    unsigned int zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_701;
    unsigned int zT_702 = 0;
    unsigned int zT_704;
    unsigned int zT_705;
    unsigned int zT_706;
    unsigned int zT_707;
    int zT_708;
    int zT_709;
    unsigned int zT_710;
    int zT_711;
    unsigned char zT_712;
    unsigned int zT_713;
    unsigned int zT_714;
    unsigned int zT_715;
    unsigned int zT_716;
    unsigned int zT_718;
    int zT_719;
    int zT_720;
    unsigned int zT_721;
    int zT_722;
    unsigned int zT_723;
    int zT_724;
    unsigned char zT_725;
    unsigned int zT_726;
    unsigned int zT_727;
    zT_5826BFC7_Arr_unsigned_char_1 zT_729;
    unsigned int zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    unsigned int zT_733;
    unsigned char* zT_734;
    unsigned int zT_735;
    int zT_736;
    unsigned char* zT_737;
    unsigned int zT_738;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_739;
    unsigned int zT_740 = 0;
    unsigned int zT_742;
    unsigned int zT_743;
    unsigned int zT_744;
    unsigned int zT_745;
    int zT_746;
    int zT_747;
    unsigned int zT_748;
    int zT_749;
    unsigned char zT_750;
    unsigned int zT_751;
    unsigned int zT_752;
    unsigned int zT_753;
    unsigned int zT_754;
    unsigned int zT_755;
    unsigned int zT_756;
    zT_D3EB6303_StringInterner* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    zT_D3EB6303_StringInterner* zT_760;
    unsigned char* zT_761;
    int zT_763;
    unsigned char* zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767 = 0;
    zT_338B7C76_TypeRegistry* zT_769;
    unsigned int zT_770;
    unsigned int zT_771;
    unsigned int zT_773;
    int zT_774;
    zT_338B7C76_TypeRegistry* zT_775;
    unsigned int zT_776;
    zT_338B7C76_TypeRegistry* zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    unsigned int zT_780;
    zT_338B7C76_TypeRegistry* zT_782;
    unsigned int zT_783;
    unsigned int zT_784;
    unsigned char zT_785;
    unsigned char zT_786;
    unsigned int zT_787;
    unsigned short zT_788;
    unsigned int zT_789;
    zT_338B7C76_TypeRegistry* zT_790;
    unsigned int zT_791;
    unsigned char zT_792;
    unsigned char zT_793;
    unsigned int zT_794;
    unsigned short zT_795;
    int zT_796;
    unsigned int zT_797;
    unsigned int zT_798 = 0;
    char* zT_800;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_801;
    unsigned int zT_802;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_803;
    unsigned int zT_804;
    zT_338B7C76_TypeRegistry* zT_805;
    unsigned int zT_806;
    zT_338B7C76_TypeRegistry* zT_807;
    zT_338B7C76_TypeRegistry* zT_808;
    unsigned int zT_809;
    int zT_810;
    zT_338B7C76_TypeRegistry* zT_811;
    int zT_812;
    unsigned int zT_813 = 0;
    unsigned int zT_814;
    int zT_815;
    int zT_816;
    zT_ABC1EBBE_TypeResolveEnv* zT_818;
    unsigned int zT_819;
    unsigned int zT_820;
    unsigned int zT_821;
    unsigned int zT_822;
    unsigned int zT_823;
    unsigned int zT_824 = 0;
    unsigned int zT_825;
    int zT_826;
    unsigned int zT_827;
    zT_8143F551_AstKind zT_828;
    zT_8143F551_AstKind zT_831;
    int zT_832;
    int zT_833;
    zT_8143F551_AstKind zT_834;
    zT_8143F551_AstKind zT_837;
    int zT_838;
    char* zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    unsigned int zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_843;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_845;
    unsigned int zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned char* zT_849;
    unsigned int zT_850;
    int zT_851;
    unsigned char* zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned int zT_855 = 0;
    unsigned int zT_857;
    unsigned int zT_858;
    unsigned int zT_859;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_860;
    unsigned char* zT_861;
    unsigned int zT_863;
    unsigned char* zT_864;
    unsigned int zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_866;
    char* zT_868;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    unsigned int zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_873;
    unsigned int zT_875;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_876;
    zT_8143F551_AstKind zT_877;
    unsigned int zT_878;
    unsigned char* zT_879;
    unsigned int zT_880;
    int zT_881;
    unsigned char* zT_882;
    unsigned int zT_883;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_884;
    unsigned int zT_885 = 0;
    unsigned int zT_887;
    unsigned int zT_888;
    unsigned int zT_889;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_890;
    unsigned char* zT_891;
    unsigned int zT_893;
    unsigned char* zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    char* zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    unsigned int zT_900;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_901;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_903;
    unsigned int zT_905;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_906;
    unsigned char* zT_907;
    unsigned int zT_908;
    int zT_909;
    unsigned char* zT_910;
    unsigned int zT_911;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_912;
    unsigned int zT_913 = 0;
    unsigned int zT_915;
    unsigned int zT_916;
    unsigned int zT_917;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_918;
    unsigned char* zT_919;
    unsigned int zT_921;
    unsigned char* zT_922;
    unsigned int zT_923;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_924;
    unsigned char zT_926;
    unsigned char zT_927;
    unsigned char zT_928;
    unsigned char zT_929;
    int zT_930;
    zT_8143F551_AstKind zT_931;
    zT_8143F551_AstKind zT_934;
    int zT_935;
    zT_338B7C76_TypeRegistry* zT_937;
    unsigned int zT_938;
    int zT_939;
    zT_338B7C76_TypeRegistry* zT_940;
    unsigned int zT_941 = 0;
    char* zT_943;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_944;
    unsigned int zT_945;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_946;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_948;
    unsigned int zT_950;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_951;
    unsigned char* zT_952;
    unsigned int zT_953;
    int zT_954;
    unsigned char* zT_955;
    unsigned int zT_956;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_957;
    unsigned int zT_958 = 0;
    unsigned int zT_960;
    unsigned int zT_961;
    unsigned int zT_962;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_963;
    unsigned char* zT_964;
    unsigned int zT_966;
    unsigned char* zT_967;
    unsigned int zT_968;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_969;
    char* zT_971;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_972;
    unsigned int zT_973;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_974;
    zT_338B7C76_TypeRegistry* zT_976;
    unsigned int zT_977;
    int zT_978;
    zT_338B7C76_TypeRegistry* zT_979;
    unsigned int zT_980 = 0;
    char* zT_982;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_983;
    unsigned int zT_984;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_985;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_987;
    unsigned int zT_989;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_990;
    unsigned char* zT_991;
    unsigned int zT_992;
    int zT_993;
    unsigned char* zT_994;
    unsigned int zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    unsigned int zT_997 = 0;
    unsigned int zT_999;
    unsigned int zT_1000;
    unsigned int zT_1001;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1002;
    unsigned char* zT_1003;
    unsigned int zT_1005;
    unsigned char* zT_1006;
    unsigned int zT_1007;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1008;
    char* zT_1010;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1011;
    unsigned int zT_1012;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1013;
    zT_8143F551_AstKind zT_1014;
    zT_8143F551_AstKind zT_1017;
    int zT_1018;
    unsigned char zT_1020;
    unsigned char zT_1021;
    unsigned char zT_1022;
    unsigned char zT_1023;
    int zT_1024;
    zT_338B7C76_TypeRegistry* zT_1026;
    unsigned int zT_1027;
    int zT_1028;
    zT_338B7C76_TypeRegistry* zT_1029;
    unsigned int zT_1030 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_1032;
    unsigned int zT_1034;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1035;
    unsigned char* zT_1036;
    unsigned int zT_1037;
    int zT_1038;
    unsigned char* zT_1039;
    unsigned int zT_1040;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1041;
    unsigned int zT_1042 = 0;
    unsigned int zT_1044;
    unsigned int zT_1045;
    unsigned int zT_1046;
    char* zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1049;
    unsigned int zT_1050;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1051;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1052;
    unsigned char* zT_1053;
    unsigned int zT_1055;
    unsigned char* zT_1056;
    unsigned int zT_1057;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1058;
    zT_4028D896_Arr_unsigned_char_2 zT_1060;
    unsigned int zT_1062;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1063;
    unsigned char* zT_1064;
    unsigned int zT_1065;
    int zT_1066;
    unsigned char* zT_1067;
    unsigned int zT_1068;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1069;
    unsigned int zT_1070 = 0;
    unsigned int zT_1072;
    unsigned int zT_1073;
    unsigned int zT_1074;
    char* zT_1076;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1077;
    unsigned int zT_1078;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1079;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1080;
    unsigned char* zT_1081;
    unsigned int zT_1083;
    unsigned char* zT_1084;
    unsigned int zT_1085;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1086;
    char* zT_1088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1089;
    unsigned int zT_1090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1091;
    zT_8143F551_AstKind zT_1092;
    zT_8143F551_AstKind zT_1095;
    int zT_1096;
    char* zT_1098;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1099;
    unsigned int zT_1100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1101;
    unsigned int zT_1102;
    zT_338B7C76_TypeRegistry* zT_1104;
    unsigned int zT_1105;
    zT_338B7C76_TypeRegistry* zT_1106;
    unsigned int zT_1107 = 0;
    char* zT_1109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1110;
    unsigned int zT_1111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1112;
    unsigned int zT_1113;
    zT_8143F551_AstKind zT_1114;
    zT_8143F551_AstKind zT_1117;
    int zT_1118;
    char* zT_1120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1121;
    unsigned int zT_1122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1123;
    char* zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    unsigned int zT_1127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1128;
    zT_4028D896_Arr_unsigned_char_2 zT_1130;
    unsigned int zT_1132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1133;
    unsigned char* zT_1134;
    unsigned int zT_1135;
    int zT_1136;
    unsigned char* zT_1137;
    unsigned int zT_1138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1139;
    unsigned int zT_1140 = 0;
    unsigned int zT_1142;
    unsigned int zT_1143;
    unsigned int zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1145;
    unsigned char* zT_1146;
    unsigned int zT_1148;
    unsigned char* zT_1149;
    unsigned int zT_1150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1151;
    unsigned int zT_1152;
    int zT_1153;
    int zT_1154;
    zT_6B0A7D14_AstStore* zT_1156;
    unsigned int zT_1157;
    zT_6B0A7D14_AstStore* zT_1158;
    unsigned int zT_1159;
    zT_22A7C88B_AstNode zT_1160 = {0};
    unsigned int zT_1162;
    int zT_1164;
    zT_8143F551_AstKind zT_1165;
    zT_8143F551_AstKind zT_1168;
    int zT_1169;
    zT_6B0A7D14_AstStore* zT_1170;
    unsigned int zT_1171;
    zT_6B0A7D14_AstStore* zT_1172;
    unsigned int zT_1173;
    zT_79FAE712_u64 zT_1174 = 0;
    unsigned int zT_1175;
    int zT_1176;
    zT_8143F551_AstKind zT_1177;
    zT_8143F551_AstKind zT_1180;
    int zT_1181;
    int zT_1182;
    zT_8143F551_AstKind zT_1183;
    zT_8143F551_AstKind zT_1186;
    int zT_1187;
    zT_ABC1EBBE_TypeResolveEnv* zT_1189;
    unsigned int zT_1190;
    unsigned int zT_1191;
    unsigned int zT_1192 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1194;
    unsigned int zT_1195;
    unsigned int zT_1196;
    unsigned int zT_1197 = 0;
    unsigned int zT_1198;
    int zT_1199;
    int zT_1200;
    unsigned int zT_1201;
    int zT_1202;
    int zT_1203;
    zT_8143F551_AstKind zT_1204;
    zT_8143F551_AstKind zT_1207;
    int zT_1208;
    unsigned int zT_1209;
    unsigned int zT_1210;
    zT_8143F551_AstKind zT_1211;
    zT_8143F551_AstKind zT_1214;
    int zT_1215;
    int zT_1216;
    zT_8143F551_AstKind zT_1217;
    zT_8143F551_AstKind zT_1220;
    int zT_1221;
    int zT_1222;
    zT_8143F551_AstKind zT_1223;
    zT_8143F551_AstKind zT_1226;
    int zT_1227;
    zT_ABC1EBBE_TypeResolveEnv* zT_1229;
    unsigned int zT_1230;
    unsigned int zT_1231;
    unsigned int zT_1232 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1234;
    unsigned int zT_1235;
    unsigned int zT_1236;
    unsigned int zT_1237 = 0;
    unsigned int zT_1238;
    int zT_1239;
    int zT_1240;
    unsigned int zT_1241;
    int zT_1242;
    int zT_1243;
    unsigned int zT_1244;
    int zT_1245;
    int zT_1246;
    zT_8143F551_AstKind zT_1247;
    zT_8143F551_AstKind zT_1250;
    int zT_1251;
    unsigned int zT_1252;
    zT_8143F551_AstKind zT_1253;
    zT_8143F551_AstKind zT_1256;
    int zT_1257;
    unsigned int zT_1258;
    unsigned int zT_1259;
    zT_8143F551_AstKind zT_1260;
    zT_8143F551_AstKind zT_1263;
    int zT_1264;
    zT_ABC1EBBE_TypeResolveEnv* zT_1266;
    unsigned int zT_1267;
    unsigned int zT_1268;
    unsigned int zT_1269 = 0;
    unsigned int zT_1270;
    int zT_1271;
    int zT_1272;
    char* zT_1274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1275;
    unsigned int zT_1276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1277;
    zT_4028D896_Arr_unsigned_char_2 zT_1279;
    unsigned int zT_1281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1282;
    unsigned char* zT_1283;
    unsigned int zT_1284;
    int zT_1285;
    unsigned char* zT_1286;
    unsigned int zT_1287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1288;
    unsigned int zT_1289 = 0;
    unsigned int zT_1291;
    unsigned int zT_1292;
    unsigned int zT_1293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1294;
    unsigned char* zT_1295;
    unsigned int zT_1297;
    unsigned char* zT_1298;
    unsigned int zT_1299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1300;
    zT_338B7C76_TypeRegistry* zT_1302;
    unsigned int zT_1303;
    unsigned int zT_1304;
    zT_338B7C76_TypeRegistry* zT_1305;
    unsigned int zT_1306 = 0;
    char* zT_1308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1309;
    unsigned int zT_1310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1311;
    zT_4028D896_Arr_unsigned_char_2 zT_1313;
    unsigned int zT_1315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1316;
    unsigned char* zT_1317;
    unsigned int zT_1318;
    int zT_1319;
    unsigned char* zT_1320;
    unsigned int zT_1321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1322;
    unsigned int zT_1323 = 0;
    unsigned int zT_1325;
    unsigned int zT_1326;
    unsigned int zT_1327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1328;
    unsigned char* zT_1329;
    unsigned int zT_1331;
    unsigned char* zT_1332;
    unsigned int zT_1333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1334;
    unsigned int zT_1335;
    int zT_1336;
    char* zT_1338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1339;
    unsigned int zT_1340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1341;
    char* zT_1343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1344;
    unsigned int zT_1345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1346;
    unsigned int zT_1347;
    char* zT_1349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1350;
    unsigned int zT_1351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1352;
    unsigned int zT_1353;
    char* zT_1355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1356;
    unsigned int zT_1357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1358;
    unsigned int zT_1359;
    zT_8143F551_AstKind zT_1360;
    unsigned int zT_1361;
    unsigned int zT_1362;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    zT_E68301A1_Opt_804 sym_cur;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_E68301A1_Opt_804 sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    int arbu;
    unsigned int arbw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_5826BFC7_Arr_unsigned_char_1 sd_id;
    unsigned int sd_idl;
    unsigned int sd_ids;
    zT_4428DEE2_Arr_unsigned_char_2 sd_nm;
    unsigned int sd_di;
    unsigned int sd_namelen;
    unsigned int sd_name_id;
    zT_BAEE192E_Opt_10 sd_existing;
    unsigned int se;
    unsigned int sd_tid;
    zT_3CB0179A_Slice_zT_05F374B1_u sd_children;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_ft;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_E68301A1_Opt_804 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_E68301A1_Opt_804 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    zT_3CB0179A_Slice_zT_05F374B1_u esd_children;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    zT_3CB0179A_Slice_zT_05F374B1_u fnt_extra;
    unsigned int fnt_i;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    unsigned int fnt_pt;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptib;
    unsigned int ptil;
    unsigned int ptis;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptkb;
    unsigned int ptkl;
    unsigned int ptks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptcb;
    unsigned int ptcl;
    unsigned int ptcs;
    int is_const;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb;
    unsigned int ppl;
    unsigned int pps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb2;
    unsigned int ppl2;
    unsigned int pps2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_4028D896_Arr_unsigned_char_2 sl_e;
    unsigned int sl_el;
    unsigned int sl_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_4028D896_Arr_unsigned_char_2 sl_r;
    unsigned int sl_rl;
    unsigned int sl_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_4028D896_Arr_unsigned_char_2 t1b;
    unsigned int t1l;
    unsigned int t1s;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    int arr_resolved;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    zT_4028D896_Arr_unsigned_char_2 t2b;
    unsigned int t2l;
    unsigned int t2s;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int al;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    zT_4028D896_Arr_unsigned_char_2 t3b;
    unsigned int t3l;
    unsigned int t3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    zT_3 = 16;
    zT_4 = depth > zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 18;
    return zT_5;
    z_bb_2:
    zT_9 = env->store;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    node = zT_10;
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    rtd_nm = zT_13;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    rtd_km = zT_19;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zT_24 = (unsigned int)zT_23;
    zT_22 = zT_24;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_25 = node.kind;
    zT_28 = zT_8143F551_AstKind_ident_expr;
    zT_29 = zT_25 == zT_28;
    if (zT_29) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_33 = env->store;
    zT_31 = zT_33;
    zT_32 = node_idx;
    zT_34 = zF_53458827_astStoreIdentifier(zT_31, zT_32);
    name_id = zT_34;
    name_id = zT_34;
    name_id = zT_34;
    zT_36 = "OPTVOID:id";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    opm4_m = zT_37;
    opm4_m = zT_37;
    opm4_m = zT_37;
    zT_39 = opm4_m;
    zT_40 = name_id;
    zF_C914CB83_markerWriteInt(zT_39, zT_40);
    zT_44 = env->interner;
    zT_42 = zT_44;
    zT_43 = name_id;
    zT_45 = zF_9134020D_stringInternerGet(zT_42, zT_43);
    text = zT_45;
    text = zT_45;
    text = zT_45;
    zT_49 = env->interner;
    zT_47 = zT_49;
    zT_48 = text;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    canonical_id = zT_50;
    canonical_id = zT_50;
    canonical_id = zT_50;
    zT_51 = env->module_id;
    zT_53 = zT_51 != zG_E6DB2ACE_MODULE_ID_NONE;
    if (zT_53) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_179 = node.kind;
    zT_182 = zT_8143F551_AstKind_struct_decl;
    zT_183 = zT_179 == zT_182;
    if (zT_183) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_55 = env->module_id;
    zT_56 = (zT_79FAE712_u64)zT_55;
    zT_57 = 4294967296ULL;
    zT_58 = zT_56 * zT_57;
    zT_59 = (zT_79FAE712_u64)canonical_id;
    zT_60 = zT_58 + zT_59;
    ck_cur = zT_60;
    ck_cur = zT_60;
    ck_cur = zT_60;
    zT_64 = env->typereg;
    zT_62 = zT_64;
    zT_63 = ck_cur;
    zT_65 = zF_0EB68360_nameCacheGet(zT_62, zT_63);
    tc_cur = zT_65;
    tc_cur = zT_65;
    tc_cur = zT_65;
    zT_66 = tc_cur.has_value;
    if (zT_66) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_71 = env->typereg;
    zT_69 = zT_71;
    zT_72 = (zT_79FAE712_u64)canonical_id;
    zT_70 = zT_72;
    zT_73 = zF_0EB68360_nameCacheGet(zT_69, zT_70);
    tid = zT_73;
    tid = zT_73;
    tid = zT_73;
    zT_75 = "OPTVOID:nc";
    zT_77 = 10;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    opnc_m = zT_76;
    opnc_m = zT_76;
    opnc_m = zT_76;
    zT_78 = opnc_m;
    zT_79 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_78, zT_79);
    zT_80 = tid.has_value;
    if (zT_80) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    t = tc_cur.value;
    return t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    t = tid.value;
    return t;
    z_bb_10:
    zT_83 = "NF";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    nf = zT_84;
    nf = zT_84;
    nf = zT_84;
    zT_86 = nf;
    zF_48AC7B3A_markerWrite(zT_86);
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    mi = zT_89;
    mi = zT_89;
    mi = zT_89;
    goto z_bb_11;
    z_bb_11:
    zT_90 = env->symbol_reg;
    zT_91 = zT_90->tables_len;
    zT_92 = (unsigned int)zT_91;
    zT_93 = mi < zT_92;
    if (zT_93) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_95 = (zT_79FAE712_u64)mi;
    zT_96 = 4294967296ULL;
    zT_97 = zT_95 * zT_96;
    zT_98 = (zT_79FAE712_u64)canonical_id;
    zT_99 = zT_97 + zT_98;
    ck = zT_99;
    ck = zT_99;
    ck = zT_99;
    zT_103 = env->typereg;
    zT_101 = zT_103;
    zT_102 = ck;
    zT_104 = zF_0EB68360_nameCacheGet(zT_101, zT_102);
    tc = zT_104;
    tc = zT_104;
    tc = zT_104;
    zT_105 = tc.has_value;
    if (zT_105) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_110 = "N2";
    zT_112 = 2;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    n2 = zT_111;
    n2 = zT_111;
    n2 = zT_111;
    zT_113 = n2;
    zF_48AC7B3A_markerWrite(zT_113);
    zT_114 = env->module_id;
    zT_116 = zT_114 != zG_E6DB2ACE_MODULE_ID_NONE;
    if (zT_116) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_107 = 1;
    zT_108 = mi + zT_107;
    mi = zT_108;
    mi = zT_108;
    goto z_bb_11;
    z_bb_15:
    t = tc.value;
    return t;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_121 = env->symbol_reg;
    zT_118 = zT_121;
    zT_122 = env->module_id;
    zT_119 = zT_122;
    zT_120 = name_id;
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_118, zT_119, zT_120);
    sym_cur = zT_123;
    sym_cur = zT_123;
    sym_cur = zT_123;
    zT_124 = sym_cur.has_value;
    if (zT_124) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    si = zT_132;
    si = zT_132;
    si = zT_132;
    goto z_bb_23;
    z_bb_19:
    s = sym_cur.value;
    zT_126 = s->type_id;
    zT_127 = 0;
    zT_128 = zT_126 != zT_127;
    if (zT_128) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_129 = s->type_id;
    return zT_129;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_133 = env->symbol_reg;
    zT_134 = zT_133->tables_len;
    zT_135 = (unsigned int)zT_134;
    zT_136 = si < zT_135;
    if (zT_136) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_141 = env->symbol_reg;
    zT_138 = zT_141;
    zT_142 = (unsigned int)si;
    zT_139 = zT_142;
    zT_140 = name_id;
    zT_143 = zF_A398987E_symbolRegistryQuali(zT_138, zT_139, zT_140);
    sym = zT_143;
    sym = zT_143;
    sym = zT_143;
    zT_144 = sym.has_value;
    if (zT_144) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_160 = "OPTVOID:idF";
    zT_162 = 11;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    opm4f_m = zT_161;
    opm4f_m = zT_161;
    opm4f_m = zT_161;
    zT_163 = opm4f_m;
    zT_164 = name_id;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_166 = 0;
    arbu = zT_166;
    arbu = zT_166;
    arbu = zT_166;
    zT_168 = text;
    zT_170 = &arbu;
    zT_169 = zT_170;
    zT_171 = zF_741B5264_parseArbIntWidth(zT_168, zT_169);
    arbw = zT_171;
    arbw = zT_171;
    arbw = zT_171;
    zT_172 = 0;
    zT_173 = arbw != zT_172;
    if (zT_173) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    zT_157 = 1;
    zT_158 = si + zT_157;
    si = zT_158;
    si = zT_158;
    goto z_bb_23;
    z_bb_27:
    s = sym.value;
    zT_146 = s->type_id;
    zT_147 = 0;
    zT_148 = zT_146 != zT_147;
    if (zT_148) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_150 = "OPTVOID:ids";
    zT_152 = 11;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    ops_m = zT_151;
    ops_m = zT_151;
    ops_m = zT_151;
    zT_153 = ops_m;
    zT_155 = s->type_id;
    zT_154 = zT_155;
    zF_C914CB83_markerWriteInt(zT_153, zT_154);
    zT_156 = s->type_id;
    return zT_156;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_176 = env->typereg;
    zT_174 = zT_176;
    zT_175 = text;
    zT_177 = zF_B8CF3697_typeRegistryGetOrCr(zT_174, zT_175);
    return zT_177;
    z_bb_32:
    zT_178 = 18;
    return zT_178;
    z_bb_33:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_185[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        sd_id[_i] = zT_185[_i];
        _i++;
    }
}
    zT_187 = node_idx;
    zT_189 = (unsigned char*)sd_id;
    zT_190 = 12;
    zT_191 = 0;
    zT_192 = zT_189 + zT_191;
    zT_193 = zT_190 - zT_191;
    zT_194.ptr = zT_192;
    zT_194.len = zT_193;
    zT_188 = zT_194;
    zT_195 = zF_A7504564_itoa(zT_187, zT_188);
    sd_idl = zT_195;
    sd_idl = zT_195;
    sd_idl = zT_195;
    zT_197 = 11;
    zT_198 = (unsigned int)sd_idl;
    zT_199 = zT_197 - zT_198;
    sd_ids = zT_199;
    sd_ids = zT_199;
    sd_ids = zT_199;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_201[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        sd_nm[_i] = zT_201[_i];
        _i++;
    }
}
    zT_202 = 97;
    zT_203 = 0;
    sd_nm[zT_203] = zT_202;
    zT_204 = 110;
    zT_205 = 1;
    sd_nm[zT_205] = zT_204;
    zT_206 = 111;
    zT_207 = 2;
    sd_nm[zT_207] = zT_206;
    zT_208 = 110;
    zT_209 = 3;
    sd_nm[zT_209] = zT_208;
    zT_210 = 95;
    zT_211 = 4;
    sd_nm[zT_211] = zT_210;
    zT_213 = 0;
    zT_214 = (unsigned int)zT_213;
    sd_di = zT_214;
    sd_di = zT_214;
    sd_di = zT_214;
    goto z_bb_35;
    z_bb_34:
    zT_362 = node.kind;
    zT_365 = zT_8143F551_AstKind_field_access;
    zT_366 = zT_362 == zT_365;
    if (zT_366) goto z_bb_60; else goto z_bb_61;
    z_bb_35:
    zT_215 = (unsigned int)sd_idl;
    zT_216 = sd_di < zT_215;
    if (zT_216) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_217 = sd_ids + sd_di;
    zT_218 = sd_id[zT_217];
    zT_219 = 5;
    zT_220 = zT_219 + sd_di;
    sd_nm[zT_220] = zT_218;
    goto z_bb_38;
    z_bb_37:
    zT_224 = 5;
    zT_225 = (unsigned int)sd_idl;
    zT_226 = zT_224 + zT_225;
    sd_namelen = zT_226;
    sd_namelen = zT_226;
    sd_namelen = zT_226;
    zT_230 = env->interner;
    zT_228 = zT_230;
    zT_231 = (unsigned char*)sd_nm;
    zT_233 = 0;
    zT_234 = zT_231 + zT_233;
    zT_235 = sd_namelen - zT_233;
    zT_236.ptr = zT_234;
    zT_236.len = zT_235;
    zT_229 = zT_236;
    zT_237 = zF_50C274AF_stringInternerInter(zT_228, zT_229);
    sd_name_id = zT_237;
    sd_name_id = zT_237;
    sd_name_id = zT_237;
    zT_241 = env->typereg;
    zT_239 = zT_241;
    zT_242 = (zT_79FAE712_u64)sd_name_id;
    zT_240 = zT_242;
    zT_243 = zF_0EB68360_nameCacheGet(zT_239, zT_240);
    sd_existing = zT_243;
    sd_existing = zT_243;
    sd_existing = zT_243;
    zT_244 = sd_existing.has_value;
    if (zT_244) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_221 = 1;
    zT_222 = sd_di + zT_221;
    sd_di = zT_222;
    sd_di = zT_222;
    goto z_bb_35;
    z_bb_39:
    se = sd_existing.value;
    return se;
    z_bb_40:
    zT_251 = env->typereg;
    zT_247 = zT_251;
    zT_252 = 0;
    zT_248 = zT_252;
    zT_249 = sd_name_id;
    zT_255 = zT_33EF6BFB_TypeKind_struct_type;
    zT_250 = zT_255;
    zT_256 = zF_3A64E2E0_typeRegistryRegiste(zT_247, zT_248, zT_249, zT_250);
    sd_tid = zT_256;
    sd_tid = zT_256;
    sd_tid = zT_256;
    zT_257 = node.flags;
    zT_258 = 16;
    zT_259 = zT_257 & zT_258;
    zT_260 = 0;
    zT_261 = zT_259 != zT_260;
    if (zT_261) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_264 = env->typereg;
    zT_262 = zT_264;
    zT_263 = sd_tid;
    zF_52816016_typeRegistrySetPack(zT_262, zT_263);
    goto z_bb_42;
    z_bb_42:
    zT_267 = env->store;
    zT_265 = zT_267;
    zT_266 = node_idx;
    zT_268 = zF_8BA26B9E_astStoreNodePayload(zT_265, zT_266);
    zT_269 = 0;
    zT_270 = zT_268 != zT_269;
    if (zT_270) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_274 = env->store;
    zT_272 = zT_274;
    zT_273 = node_idx;
    zT_275 = zF_850FDF81_astStoreNodeExtraCh(zT_272, zT_273);
    sd_children = zT_275;
    sd_children = zT_275;
    sd_children = zT_275;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_277[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_277[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_279[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_279[_i];
        _i++;
    }
}
    zT_281 = 0;
    zT_282 = (unsigned int)zT_281;
    sd_fc = zT_282;
    sd_fc = zT_282;
    sd_fc = zT_282;
    zT_284 = 0;
    zT_285 = (unsigned int)zT_284;
    sd_i = zT_285;
    sd_i = zT_285;
    sd_i = zT_285;
    goto z_bb_45;
    z_bb_44:
    return sd_tid;
    z_bb_45:
    zT_287 = sd_children.len;
    zT_288 = sd_i < zT_287;
    if (zT_288) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_295 = env->store;
    zT_293 = zT_295;
    zT_296 = sd_children.ptr;
    zT_297 = zT_296[sd_i];
    zT_294 = zT_297;
    zT_298 = zF_FCDD1D35_astStoreNodeAt(zT_293, zT_294);
    sd_fd = zT_298;
    sd_fd = zT_298;
    sd_fd = zT_298;
    zT_299 = sd_fd.kind;
    zT_302 = zT_8143F551_AstKind_field_decl;
    zT_303 = zT_299 == zT_302;
    if (zT_303) goto z_bb_52; else goto z_bb_53;
    z_bb_47:
    zT_323 = 0;
    zT_324 = sd_fc > zT_323;
    if (zT_324) goto z_bb_54; else goto z_bb_55;
    z_bb_48:
    zT_321 = 1;
    zT_322 = sd_i + zT_321;
    sd_i = zT_322;
    sd_i = zT_322;
    goto z_bb_45;
    z_bb_49:
    zT_290 = 32;
    zT_291 = sd_fc < zT_290;
    zT_289 = zT_291;
    goto z_bb_51;
    z_bb_50:
    zT_289 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_289) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_305 = env;
    zT_308 = sd_fd.child_0;
    zT_306 = zT_308;
    zT_309 = 1;
    zT_310 = depth + zT_309;
    zT_307 = zT_310;
    zT_311 = zF_F2107C15_resolveTypeExprFull(zT_305, zT_306, zT_307);
    sd_ft = zT_311;
    sd_ft = zT_311;
    sd_ft = zT_311;
    sd_fty[sd_fc] = sd_ft;
    zT_314 = env->store;
    zT_312 = zT_314;
    zT_315 = sd_children.ptr;
    zT_316 = zT_315[sd_i];
    zT_313 = zT_316;
    zT_317 = zF_8BA26B9E_astStoreNodePayload(zT_312, zT_313);
    sd_fnm[sd_fc] = zT_317;
    zT_318 = 1;
    zT_319 = (unsigned int)zT_318;
    zT_320 = sd_fc + zT_319;
    sd_fc = zT_320;
    sd_fc = zT_320;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_326 = env->typereg;
    zT_327 = zT_326->fe_len;
    zT_328 = (unsigned int)zT_327;
    sd_fstart = zT_328;
    sd_fstart = zT_328;
    sd_fstart = zT_328;
    zT_330 = 0;
    zT_331 = (unsigned int)zT_330;
    sd_j = zT_331;
    sd_j = zT_331;
    sd_j = zT_331;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_44;
    z_bb_56:
    zT_332 = sd_j < sd_fc;
    if (zT_332) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_335 = env->typereg;
    zT_333 = zT_335;
    zT_337 = sd_fnm[sd_j];
    zT_336.name_id = zT_337;
    zT_338 = sd_fty[sd_j];
    zT_336.type_id = zT_338;
    zT_339 = 0;
    zT_336.offset = zT_339;
    zT_334 = zT_336;
    zF_701DF154_feAppend(zT_333, zT_334);
    goto z_bb_59;
    z_bb_58:
    zT_344 = env->typereg;
    zT_342 = zT_344;
    zT_346 = (unsigned int)sd_fstart;
    zT_345.fields_start = zT_346;
    zT_347 = (unsigned short)sd_fc;
    zT_345.fields_count = zT_347;
    zT_343 = zT_345;
    zF_CF849366_stAppend(zT_342, zT_343);
    zT_349 = env->typereg;
    zT_350 = zT_349->st_len;
    zT_351 = 1;
    zT_352 = zT_350 - zT_351;
    zT_353 = (unsigned int)zT_352;
    sd_st_idx = zT_353;
    sd_st_idx = zT_353;
    sd_st_idx = zT_353;
    zT_355 = env->typereg;
    zT_356 = zT_355->types_items;
    zT_357 = (unsigned int)sd_tid;
    zT_358 = zT_356[zT_357];
    sd_ty = zT_358;
    sd_ty = zT_358;
    sd_ty = zT_358;
    sd_ty.payload_idx = sd_st_idx;
    zT_359 = env->typereg;
    zT_360 = zT_359->types_items;
    zT_361 = (unsigned int)sd_tid;
    zT_360[zT_361] = sd_ty;
    goto z_bb_55;
    z_bb_59:
    zT_340 = 1;
    zT_341 = sd_j + zT_340;
    sd_j = zT_341;
    sd_j = zT_341;
    goto z_bb_56;
    z_bb_60:
    zT_368 = 0;
    fah_matched = zT_368;
    fah_matched = zT_368;
    fah_matched = zT_368;
    zT_370 = env;
    zT_373 = node.child_0;
    zT_371 = zT_373;
    zT_374 = 1;
    zT_375 = depth + zT_374;
    zT_372 = zT_375;
    zT_376 = zF_F2107C15_resolveTypeExprFull(zT_370, zT_371, zT_372);
    base_type = zT_376;
    base_type = zT_376;
    base_type = zT_376;
    zT_377 = 18;
    zT_378 = base_type == zT_377;
    if (zT_378) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_497 = node.kind;
    zT_500 = zT_8143F551_AstKind_error_set_decl;
    zT_501 = zT_497 == zT_500;
    if (zT_501) goto z_bb_86; else goto z_bb_87;
    z_bb_62:
    zT_382 = env->store;
    zT_380 = zT_382;
    zT_383 = node.child_0;
    zT_381 = zT_383;
    zT_384 = zF_FCDD1D35_astStoreNodeAt(zT_380, zT_381);
    base_node = zT_384;
    base_node = zT_384;
    base_node = zT_384;
    zT_385 = base_node.kind;
    zT_388 = zT_8143F551_AstKind_ident_expr;
    zT_389 = zT_385 == zT_388;
    if (zT_389) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    zT_454 = env->typereg;
    zT_455 = zT_454->types_items;
    zT_456 = (unsigned int)base_type;
    zT_457 = zT_455[zT_456];
    base_ty = zT_457;
    base_ty = zT_457;
    base_ty = zT_457;
    zT_458 = base_ty.kind;
    zT_461 = zT_33EF6BFB_TypeKind_module_type;
    zT_462 = zT_458 == zT_461;
    if (zT_462) goto z_bb_78; else goto z_bb_79;
    z_bb_64:
    zT_393 = env->store;
    zT_391 = zT_393;
    zT_394 = node.child_0;
    zT_392 = zT_394;
    zT_395 = zF_53458827_astStoreIdentifier(zT_391, zT_392);
    base_name_id = zT_395;
    base_name_id = zT_395;
    base_name_id = zT_395;
    zT_397 = 0;
    zT_398 = (unsigned int)zT_397;
    smi = zT_398;
    smi = zT_398;
    smi = zT_398;
    goto z_bb_66;
    z_bb_65:
    zT_446 = "FAH:m";
    zT_448 = 5;
    zT_447.ptr = zT_446;
    zT_447.len = zT_448;
    fam_m = zT_447;
    fam_m = zT_447;
    fam_m = zT_447;
    zT_449 = fam_m;
    zT_451 = node.child_0;
    zT_450 = zT_451;
    zF_C914CB83_markerWriteInt(zT_449, zT_450);
    zT_452 = 18;
    return zT_452;
    z_bb_66:
    zT_399 = env->symbol_reg;
    zT_400 = zT_399->tables_len;
    zT_401 = (unsigned int)zT_400;
    zT_402 = smi < zT_401;
    if (zT_402) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_407 = env->symbol_reg;
    zT_404 = zT_407;
    zT_408 = (unsigned int)smi;
    zT_405 = zT_408;
    zT_406 = base_name_id;
    zT_409 = zF_A398987E_symbolRegistryQuali(zT_404, zT_405, zT_406);
    base_sym = zT_409;
    base_sym = zT_409;
    base_sym = zT_409;
    zT_410 = base_sym.has_value;
    if (zT_410) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_443 = 1;
    zT_444 = smi + zT_443;
    smi = zT_444;
    smi = zT_444;
    goto z_bb_66;
    z_bb_70:
    bs = base_sym.value;
    zT_412 = bs->kind;
    zT_415 = zT_3C598AEF_SymbolKind_module;
    zT_416 = zT_412 == zT_415;
    if (zT_416) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_69;
    z_bb_72:
    zT_418 = bs->module_id;
    mod_id = zT_418;
    mod_id = zT_418;
    mod_id = zT_418;
    zT_423 = env->symbol_reg;
    zT_420 = zT_423;
    zT_421 = mod_id;
    zT_426 = env->store;
    zT_424 = zT_426;
    zT_425 = node_idx;
    zT_427 = zF_8BA26B9E_astStoreNodePayload(zT_424, zT_425);
    zT_422 = zT_427;
    zT_428 = zF_A398987E_symbolRegistryQuali(zT_420, zT_421, zT_422);
    payload_sym = zT_428;
    payload_sym = zT_428;
    payload_sym = zT_428;
    zT_429 = payload_sym.has_value;
    if (zT_429) goto z_bb_74; else goto z_bb_75;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    ps = payload_sym.value;
    zT_431 = ps->type_id;
    zT_432 = 0;
    zT_433 = zT_431 != zT_432;
    if (zT_433) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    zT_434 = 1;
    fah_matched = zT_434;
    fah_matched = zT_434;
    zT_436 = "FAH:r";
    zT_438 = 5;
    zT_437.ptr = zT_436;
    zT_437.len = zT_438;
    fam = zT_437;
    fam = zT_437;
    fam = zT_437;
    zT_439 = fam;
    zT_441 = ps->type_id;
    zT_440 = zT_441;
    zF_C914CB83_markerWriteInt(zT_439, zT_440);
    zT_442 = ps->type_id;
    return zT_442;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_464 = base_ty.module_id;
    mod_id = zT_464;
    mod_id = zT_464;
    mod_id = zT_464;
    zT_469 = env->symbol_reg;
    zT_466 = zT_469;
    zT_467 = mod_id;
    zT_472 = env->store;
    zT_470 = zT_472;
    zT_471 = node_idx;
    zT_473 = zF_8BA26B9E_astStoreNodePayload(zT_470, zT_471);
    zT_468 = zT_473;
    zT_474 = zF_A398987E_symbolRegistryQuali(zT_466, zT_467, zT_468);
    sym = zT_474;
    sym = zT_474;
    sym = zT_474;
    zT_475 = sym.has_value;
    if (zT_475) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_489 = 0;
    zT_490 = fah_matched == zT_489;
    if (zT_490) goto z_bb_84; else goto z_bb_85;
    z_bb_80:
    s = sym.value;
    zT_477 = s->type_id;
    zT_478 = 0;
    zT_479 = zT_477 != zT_478;
    if (zT_479) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_480 = 1;
    fah_matched = zT_480;
    fah_matched = zT_480;
    zT_482 = "FAH:r";
    zT_484 = 5;
    zT_483.ptr = zT_482;
    zT_483.len = zT_484;
    fam = zT_483;
    fam = zT_483;
    fam = zT_483;
    zT_485 = fam;
    zT_487 = s->type_id;
    zT_486 = zT_487;
    zF_C914CB83_markerWriteInt(zT_485, zT_486);
    zT_488 = s->type_id;
    return zT_488;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_492 = "FAH:N";
    zT_494 = 5;
    zT_493.ptr = zT_492;
    zT_493.len = zT_494;
    fnm = zT_493;
    fnm = zT_493;
    fnm = zT_493;
    zT_495 = fnm;
    zT_496 = node_idx;
    zF_C914CB83_markerWriteInt(zT_495, zT_496);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_61;
    z_bb_86:
    zT_504 = env->typereg;
    zT_505 = zT_504->xn_len;
    zT_506 = (unsigned int)zT_505;
    zT_507 = 0;
    zT_503[zT_507] = zT_506;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_503[_i];
        _i++;
    }
}
    zT_510 = 0;
    zT_511 = 0;
    zT_509[zT_511] = zT_510;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_509[_i];
        _i++;
    }
}
    zT_514 = env->store;
    zT_512 = zT_514;
    zT_513 = node_idx;
    zT_515 = zF_8BA26B9E_astStoreNodePayload(zT_512, zT_513);
    zT_516 = 0;
    zT_517 = zT_515 != zT_516;
    if (zT_517) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    zT_549 = node.kind;
    zT_552 = zT_8143F551_AstKind_error_union_type;
    zT_553 = zT_549 == zT_552;
    if (zT_553) goto z_bb_94; else goto z_bb_95;
    z_bb_88:
    zT_521 = env->store;
    zT_519 = zT_521;
    zT_520 = node_idx;
    zT_522 = zF_850FDF81_astStoreNodeExtraCh(zT_519, zT_520);
    esd_children = zT_522;
    esd_children = zT_522;
    esd_children = zT_522;
    zT_524 = esd_children.len;
    zT_525 = (unsigned short)zT_524;
    zT_526 = 0;
    esd_count_box[zT_526] = zT_525;
    zT_528 = 0;
    zT_529 = (unsigned int)zT_528;
    esd_i = zT_529;
    esd_i = zT_529;
    esd_i = zT_529;
    goto z_bb_90;
    z_bb_89:
    zT_543 = env->typereg;
    zT_540 = zT_543;
    zT_544 = 0;
    zT_545 = esd_start_box[zT_544];
    zT_541 = zT_545;
    zT_546 = 0;
    zT_547 = esd_count_box[zT_546];
    zT_542 = zT_547;
    zT_548 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_540, zT_541, zT_542);
    return zT_548;
    z_bb_90:
    zT_531 = esd_children.len;
    zT_532 = esd_i < zT_531;
    if (zT_532) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_535 = env->typereg;
    zT_533 = zT_535;
    zT_536 = esd_children.ptr;
    zT_537 = zT_536[esd_i];
    zT_534 = zT_537;
    zF_A648B1CB_xnAppend(zT_533, zT_534);
    goto z_bb_93;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_538 = 1;
    zT_539 = esd_i + zT_538;
    esd_i = zT_539;
    esd_i = zT_539;
    goto z_bb_90;
    z_bb_94:
    zT_555 = env;
    zT_558 = node.child_1;
    zT_556 = zT_558;
    zT_559 = 1;
    zT_560 = depth + zT_559;
    zT_557 = zT_560;
    zT_561 = zF_F2107C15_resolveTypeExprFull(zT_555, zT_556, zT_557);
    eu_payload_type = zT_561;
    eu_payload_type = zT_561;
    eu_payload_type = zT_561;
    zT_562 = 18;
    zT_563 = eu_payload_type == zT_562;
    if (zT_563) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    zT_593 = node.kind;
    zT_596 = zT_8143F551_AstKind_fn_type;
    zT_597 = zT_593 == zT_596;
    if (zT_597) goto z_bb_103; else goto z_bb_104;
    z_bb_96:
    zT_564 = 18;
    return zT_564;
    z_bb_97:
    zT_567 = 0;
    zT_568 = 0;
    zT_566[zT_568] = zT_567;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_566[_i];
        _i++;
    }
}
    zT_569 = node.child_0;
    zT_570 = 0;
    zT_571 = zT_569 != (unsigned int)zT_570;
    if (zT_571) goto z_bb_98; else goto z_bb_100;
    z_bb_98:
    zT_573 = env;
    zT_576 = node.child_0;
    zT_574 = zT_576;
    zT_577 = 1;
    zT_578 = depth + zT_577;
    zT_575 = zT_578;
    zT_579 = zF_F2107C15_resolveTypeExprFull(zT_573, zT_574, zT_575);
    eu_resolved_es = zT_579;
    eu_resolved_es = zT_579;
    eu_resolved_es = zT_579;
    zT_580 = 18;
    zT_581 = eu_resolved_es == zT_580;
    if (zT_581) goto z_bb_101; else goto z_bb_102;
    z_bb_99:
    zT_589 = env->typereg;
    zT_586 = zT_589;
    zT_587 = eu_payload_type;
    zT_590 = 0;
    zT_591 = eu_es_box[zT_590];
    zT_588 = zT_591;
    zT_592 = zF_16D1A6EE_typeRegistryGetOrCr(zT_586, zT_587, zT_588);
    return zT_592;
    z_bb_100:
    zT_584 = 0;
    zT_585 = 0;
    eu_es_box[zT_585] = zT_584;
    goto z_bb_99;
    z_bb_101:
    zT_582 = 18;
    return zT_582;
    z_bb_102:
    zT_583 = 0;
    eu_es_box[zT_583] = eu_resolved_es;
    goto z_bb_99;
    z_bb_103:
    zT_600 = 0;
    zT_601 = 0;
    zT_599[zT_601] = zT_600;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_599[_i];
        _i++;
    }
}
    zT_602 = 1;
    zT_603 = 0;
    fnt_ret_box[zT_603] = zT_602;
    zT_604 = node.child_0;
    zT_605 = 0;
    zT_606 = zT_604 != (unsigned int)zT_605;
    if (zT_606) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_814 = node.child_0;
    zT_815 = 0;
    zT_816 = zT_814 != (unsigned int)zT_815;
    if (zT_816) goto z_bb_154; else goto z_bb_155;
    z_bb_105:
    zT_607 = env;
    zT_610 = node.child_0;
    zT_608 = zT_610;
    zT_611 = 1;
    zT_612 = depth + zT_611;
    zT_609 = zT_612;
    zT_613 = zF_F2107C15_resolveTypeExprFull(zT_607, zT_608, zT_609);
    zT_614 = 0;
    fnt_ret_box[zT_614] = zT_613;
    zT_616 = "OPTVOID:fntR";
    zT_618 = 12;
    zT_617.ptr = zT_616;
    zT_617.len = zT_618;
    opm2_m = zT_617;
    opm2_m = zT_617;
    opm2_m = zT_617;
    zT_619 = opm2_m;
    zT_621 = 0;
    zT_622 = fnt_ret_box[zT_621];
    zT_620 = zT_622;
    zF_C914CB83_markerWriteInt(zT_619, zT_620);
    zT_623 = 0;
    zT_624 = fnt_ret_box[zT_623];
    zT_625 = 18;
    zT_626 = zT_624 == zT_625;
    if (zT_626) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_629[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_629[_i];
        _i++;
    }
}
    zT_631 = 0;
    fnt_pc = zT_631;
    fnt_pc = zT_631;
    fnt_pc = zT_631;
    zT_634 = env->store;
    zT_632 = zT_634;
    zT_633 = node_idx;
    zT_635 = zF_8BA26B9E_astStoreNodePayload(zT_632, zT_633);
    zT_636 = 0;
    zT_637 = zT_635 != zT_636;
    if (zT_637) goto z_bb_109; else goto z_bb_110;
    z_bb_107:
    zT_627 = 18;
    return zT_627;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_641 = env->store;
    zT_639 = zT_641;
    zT_640 = node_idx;
    zT_642 = zF_850FDF81_astStoreNodeExtraCh(zT_639, zT_640);
    fnt_extra = zT_642;
    fnt_extra = zT_642;
    fnt_extra = zT_642;
    zT_644 = 0;
    fnt_i = zT_644;
    fnt_i = zT_644;
    fnt_i = zT_644;
    goto z_bb_111;
    z_bb_110:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_668[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_668[_i];
        _i++;
    }
}
    zT_670 = 0;
    fnt_np = zT_670;
    fnt_np = zT_670;
    fnt_np = zT_670;
    zT_672 = "fnt_";
    zT_674 = 4;
    zT_673.ptr = zT_672;
    zT_673.len = zT_674;
    fnt_pre = zT_673;
    fnt_pre = zT_673;
    fnt_pre = zT_673;
    zT_676 = 0;
    fnt_pri = zT_676;
    fnt_pri = zT_676;
    fnt_pri = zT_676;
    goto z_bb_120;
    z_bb_111:
    zT_646 = fnt_extra.len;
    zT_647 = fnt_i < zT_646;
    if (zT_647) goto z_bb_115; else goto z_bb_116;
    z_bb_112:
    zT_652 = env;
    zT_655 = fnt_extra.ptr;
    zT_656 = zT_655[fnt_i];
    zT_653 = zT_656;
    zT_657 = 1;
    zT_658 = depth + zT_657;
    zT_654 = zT_658;
    zT_659 = zF_F2107C15_resolveTypeExprFull(zT_652, zT_653, zT_654);
    fnt_pt = zT_659;
    fnt_pt = zT_659;
    fnt_pt = zT_659;
    zT_660 = 18;
    zT_661 = fnt_pt == zT_660;
    if (zT_661) goto z_bb_118; else goto z_bb_119;
    z_bb_113:
    goto z_bb_110;
    z_bb_114:
    zT_665 = 1;
    zT_666 = fnt_i + zT_665;
    fnt_i = zT_666;
    fnt_i = zT_666;
    goto z_bb_111;
    z_bb_115:
    zT_649 = 16;
    zT_650 = fnt_pc < zT_649;
    zT_648 = zT_650;
    goto z_bb_117;
    z_bb_116:
    zT_648 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_648) goto z_bb_112; else goto z_bb_113;
    z_bb_118:
    zT_662 = 18;
    return zT_662;
    z_bb_119:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_663 = 1;
    zT_664 = fnt_pc + zT_663;
    fnt_pc = zT_664;
    fnt_pc = zT_664;
    goto z_bb_114;
    z_bb_120:
    zT_678 = fnt_pre.len;
    zT_679 = fnt_pri < zT_678;
    if (zT_679) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_683 = fnt_pre.ptr;
    zT_684 = zT_683[fnt_pri];
    fnt_nb[fnt_np] = zT_684;
    zT_685 = 1;
    zT_686 = fnt_np + zT_685;
    fnt_np = zT_686;
    fnt_np = zT_686;
    goto z_bb_123;
    z_bb_122:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_690[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_690[_i];
        _i++;
    }
}
    zT_694 = 0;
    zT_695 = fnt_ret_box[zT_694];
    zT_692 = zT_695;
    zT_696 = (unsigned char*)fnt_rb;
    zT_697 = 12;
    zT_698 = 0;
    zT_699 = zT_696 + zT_698;
    zT_700 = zT_697 - zT_698;
    zT_701.ptr = zT_699;
    zT_701.len = zT_700;
    zT_693 = zT_701;
    zT_702 = zF_A7504564_itoa(zT_692, zT_693);
    fnt_rl = zT_702;
    fnt_rl = zT_702;
    fnt_rl = zT_702;
    zT_704 = 11;
    zT_705 = (unsigned int)fnt_rl;
    zT_706 = zT_704 - zT_705;
    fnt_rs = zT_706;
    fnt_rs = zT_706;
    fnt_rs = zT_706;
    goto z_bb_127;
    z_bb_123:
    zT_687 = 1;
    zT_688 = fnt_pri + zT_687;
    fnt_pri = zT_688;
    fnt_pri = zT_688;
    goto z_bb_120;
    z_bb_124:
    zT_681 = 95;
    zT_682 = fnt_np < zT_681;
    zT_680 = zT_682;
    goto z_bb_126;
    z_bb_125:
    zT_680 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_680) goto z_bb_121; else goto z_bb_122;
    z_bb_127:
    zT_707 = 11;
    zT_708 = fnt_rs < zT_707;
    if (zT_708) goto z_bb_131; else goto z_bb_132;
    z_bb_128:
    zT_712 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_712;
    zT_713 = 1;
    zT_714 = fnt_np + zT_713;
    fnt_np = zT_714;
    fnt_np = zT_714;
    goto z_bb_130;
    z_bb_129:
    zT_718 = 0;
    fnt_k = zT_718;
    fnt_k = zT_718;
    fnt_k = zT_718;
    goto z_bb_134;
    z_bb_130:
    zT_715 = 1;
    zT_716 = fnt_rs + zT_715;
    fnt_rs = zT_716;
    fnt_rs = zT_716;
    goto z_bb_127;
    z_bb_131:
    zT_710 = 95;
    zT_711 = fnt_np < zT_710;
    zT_709 = zT_711;
    goto z_bb_133;
    z_bb_132:
    zT_709 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_709) goto z_bb_128; else goto z_bb_129;
    z_bb_134:
    zT_719 = fnt_k < fnt_pc;
    if (zT_719) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    zT_723 = 95;
    zT_724 = fnt_np < zT_723;
    if (zT_724) goto z_bb_141; else goto z_bb_142;
    z_bb_136:
    zT_760 = env->interner;
    zT_758 = zT_760;
    zT_761 = (unsigned char*)fnt_nb;
    zT_763 = 0;
    zT_764 = zT_761 + zT_763;
    zT_765 = fnt_np - zT_763;
    zT_766.ptr = zT_764;
    zT_766.len = zT_765;
    zT_759 = zT_766;
    zT_767 = zF_50C274AF_stringInternerInter(zT_758, zT_759);
    fnt_name_id = zT_767;
    fnt_name_id = zT_767;
    fnt_name_id = zT_767;
    zT_769 = env->typereg;
    zT_770 = zT_769->xt_len;
    zT_771 = (unsigned int)zT_770;
    fnt_pstart = zT_771;
    fnt_pstart = zT_771;
    fnt_pstart = zT_771;
    zT_773 = 0;
    fnt_a = zT_773;
    fnt_a = zT_773;
    fnt_a = zT_773;
    goto z_bb_150;
    z_bb_137:
    zT_755 = 1;
    zT_756 = fnt_k + zT_755;
    fnt_k = zT_756;
    fnt_k = zT_756;
    goto z_bb_134;
    z_bb_138:
    zT_721 = 95;
    zT_722 = fnt_np < zT_721;
    zT_720 = zT_722;
    goto z_bb_140;
    z_bb_139:
    zT_720 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_720) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    zT_725 = 95;
    fnt_nb[fnt_np] = zT_725;
    zT_726 = 1;
    zT_727 = fnt_np + zT_726;
    fnt_np = zT_727;
    fnt_np = zT_727;
    goto z_bb_142;
    z_bb_142:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_729[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_729[_i];
        _i++;
    }
}
    zT_733 = fnt_ptypes[fnt_k];
    zT_731 = zT_733;
    zT_734 = (unsigned char*)fnt_pb;
    zT_735 = 12;
    zT_736 = 0;
    zT_737 = zT_734 + zT_736;
    zT_738 = zT_735 - zT_736;
    zT_739.ptr = zT_737;
    zT_739.len = zT_738;
    zT_732 = zT_739;
    zT_740 = zF_A7504564_itoa(zT_731, zT_732);
    fnt_pl = zT_740;
    fnt_pl = zT_740;
    fnt_pl = zT_740;
    zT_742 = 11;
    zT_743 = (unsigned int)fnt_pl;
    zT_744 = zT_742 - zT_743;
    fnt_ps = zT_744;
    fnt_ps = zT_744;
    fnt_ps = zT_744;
    goto z_bb_143;
    z_bb_143:
    zT_745 = 11;
    zT_746 = fnt_ps < zT_745;
    if (zT_746) goto z_bb_147; else goto z_bb_148;
    z_bb_144:
    zT_750 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_750;
    zT_751 = 1;
    zT_752 = fnt_np + zT_751;
    fnt_np = zT_752;
    fnt_np = zT_752;
    goto z_bb_146;
    z_bb_145:
    goto z_bb_137;
    z_bb_146:
    zT_753 = 1;
    zT_754 = fnt_ps + zT_753;
    fnt_ps = zT_754;
    fnt_ps = zT_754;
    goto z_bb_143;
    z_bb_147:
    zT_748 = 95;
    zT_749 = fnt_np < zT_748;
    zT_747 = zT_749;
    goto z_bb_149;
    z_bb_148:
    zT_747 = 0;
    goto z_bb_149;
    z_bb_149:
    if (zT_747) goto z_bb_144; else goto z_bb_145;
    z_bb_150:
    zT_774 = fnt_a < fnt_pc;
    if (zT_774) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_777 = env->typereg;
    zT_775 = zT_777;
    zT_778 = fnt_ptypes[fnt_a];
    zT_776 = zT_778;
    zF_4C03AE3D_xtAppend(zT_775, zT_776);
    goto z_bb_153;
    z_bb_152:
    zT_790 = env->typereg;
    zT_782 = zT_790;
    zT_783 = fnt_name_id;
    zT_791 = 0;
    zT_784 = zT_791;
    zT_792 = 0;
    zT_785 = zT_792;
    zT_793 = 0;
    zT_786 = zT_793;
    zT_794 = (unsigned int)fnt_pstart;
    zT_787 = zT_794;
    zT_795 = (unsigned short)fnt_pc;
    zT_788 = zT_795;
    zT_796 = 0;
    zT_797 = fnt_ret_box[zT_796];
    zT_789 = zT_797;
    zT_798 = zF_474336D7_typeRegistryGetOrCr(zT_782, zT_783, zT_784, zT_785, zT_786, zT_787, zT_788, zT_789);
    fnt_tid = zT_798;
    fnt_tid = zT_798;
    fnt_tid = zT_798;
    zT_800 = "OPTVOID:fntT";
    zT_802 = 12;
    zT_801.ptr = zT_800;
    zT_801.len = zT_802;
    opm3_m = zT_801;
    opm3_m = zT_801;
    opm3_m = zT_801;
    zT_803 = opm3_m;
    zT_804 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_803, zT_804);
    zT_807 = env->typereg;
    zT_805 = zT_807;
    zT_806 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_805, zT_806);
    zT_811 = env->typereg;
    zT_808 = zT_811;
    zT_809 = fnt_tid;
    zT_812 = 0;
    zT_810 = zT_812;
    zT_813 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_808, zT_809, zT_810);
    return zT_813;
    z_bb_153:
    zT_779 = 1;
    zT_780 = fnt_a + zT_779;
    fnt_a = zT_780;
    fnt_a = zT_780;
    goto z_bb_150;
    z_bb_154:
    zT_818 = env;
    zT_821 = node.child_0;
    zT_819 = zT_821;
    zT_822 = 1;
    zT_823 = depth + zT_822;
    zT_820 = zT_823;
    zT_824 = zF_F2107C15_resolveTypeExprFull(zT_818, zT_819, zT_820);
    child_type = zT_824;
    child_type = zT_824;
    child_type = zT_824;
    zT_825 = 18;
    zT_826 = child_type == zT_825;
    if (zT_826) goto z_bb_156; else goto z_bb_157;
    z_bb_155:
    zT_1349 = "UND:n";
    zT_1351 = 5;
    zT_1350.ptr = zT_1349;
    zT_1350.len = zT_1351;
    und_nm2 = zT_1350;
    und_nm2 = zT_1350;
    und_nm2 = zT_1350;
    zT_1352 = und_nm2;
    zT_1353 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1352, zT_1353);
    zT_1355 = "UND:k";
    zT_1357 = 5;
    zT_1356.ptr = zT_1355;
    zT_1356.len = zT_1357;
    und_km = zT_1356;
    und_km = zT_1356;
    und_km = zT_1356;
    zT_1358 = und_km;
    zT_1360 = node.kind;
    zT_1361 = (unsigned int)zT_1360;
    zT_1359 = zT_1361;
    zF_C914CB83_markerWriteInt(zT_1358, zT_1359);
    zT_1362 = 18;
    return zT_1362;
    z_bb_156:
    zT_827 = 18;
    return zT_827;
    z_bb_157:
    zT_828 = node.kind;
    zT_831 = zT_8143F551_AstKind_ptr_type;
    zT_832 = zT_828 == zT_831;
    if (zT_832) goto z_bb_159; else goto z_bb_158;
    z_bb_158:
    zT_834 = node.kind;
    zT_837 = zT_8143F551_AstKind_many_ptr_type;
    zT_838 = zT_834 == zT_837;
    zT_833 = zT_838;
    goto z_bb_160;
    z_bb_159:
    zT_833 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_833) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_840 = "PTR:i";
    zT_842 = 5;
    zT_841.ptr = zT_840;
    zT_841.len = zT_842;
    ptm = zT_841;
    ptm = zT_841;
    ptm = zT_841;
    zT_843 = ptm;
    zF_48AC7B3A_markerWrite(zT_843);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_845[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptib[_i] = zT_845[_i];
        _i++;
    }
}
    zT_847 = node_idx;
    zT_849 = (unsigned char*)ptib;
    zT_850 = 10;
    zT_851 = 0;
    zT_852 = zT_849 + zT_851;
    zT_853 = zT_850 - zT_851;
    zT_854.ptr = zT_852;
    zT_854.len = zT_853;
    zT_848 = zT_854;
    zT_855 = zF_A7504564_itoa(zT_847, zT_848);
    ptil = zT_855;
    ptil = zT_855;
    ptil = zT_855;
    zT_857 = 9;
    zT_858 = (unsigned int)ptil;
    zT_859 = zT_857 - zT_858;
    ptis = zT_859;
    ptis = zT_859;
    ptis = zT_859;
    zT_861 = (unsigned char*)ptib;
    zT_863 = 9;
    zT_864 = zT_861 + ptis;
    zT_865 = zT_863 - ptis;
    zT_866.ptr = zT_864;
    zT_866.len = zT_865;
    zT_860 = zT_866;
    zF_48AC7B3A_markerWrite(zT_860);
    zT_868 = "k";
    zT_870 = 1;
    zT_869.ptr = zT_868;
    zT_869.len = zT_870;
    ptkm = zT_869;
    ptkm = zT_869;
    ptkm = zT_869;
    zT_871 = ptkm;
    zF_48AC7B3A_markerWrite(zT_871);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_873[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptkb[_i] = zT_873[_i];
        _i++;
    }
}
    zT_877 = node.kind;
    zT_878 = (unsigned int)zT_877;
    zT_875 = zT_878;
    zT_879 = (unsigned char*)ptkb;
    zT_880 = 10;
    zT_881 = 0;
    zT_882 = zT_879 + zT_881;
    zT_883 = zT_880 - zT_881;
    zT_884.ptr = zT_882;
    zT_884.len = zT_883;
    zT_876 = zT_884;
    zT_885 = zF_A7504564_itoa(zT_875, zT_876);
    ptkl = zT_885;
    ptkl = zT_885;
    ptkl = zT_885;
    zT_887 = 9;
    zT_888 = (unsigned int)ptkl;
    zT_889 = zT_887 - zT_888;
    ptks = zT_889;
    ptks = zT_889;
    ptks = zT_889;
    zT_891 = (unsigned char*)ptkb;
    zT_893 = 9;
    zT_894 = zT_891 + ptks;
    zT_895 = zT_893 - ptks;
    zT_896.ptr = zT_894;
    zT_896.len = zT_895;
    zT_890 = zT_896;
    zF_48AC7B3A_markerWrite(zT_890);
    zT_898 = "c";
    zT_900 = 1;
    zT_899.ptr = zT_898;
    zT_899.len = zT_900;
    ptcm = zT_899;
    ptcm = zT_899;
    ptcm = zT_899;
    zT_901 = ptcm;
    zF_48AC7B3A_markerWrite(zT_901);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_903[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptcb[_i] = zT_903[_i];
        _i++;
    }
}
    zT_905 = child_type;
    zT_907 = (unsigned char*)ptcb;
    zT_908 = 10;
    zT_909 = 0;
    zT_910 = zT_907 + zT_909;
    zT_911 = zT_908 - zT_909;
    zT_912.ptr = zT_910;
    zT_912.len = zT_911;
    zT_906 = zT_912;
    zT_913 = zF_A7504564_itoa(zT_905, zT_906);
    ptcl = zT_913;
    ptcl = zT_913;
    ptcl = zT_913;
    zT_915 = 9;
    zT_916 = (unsigned int)ptcl;
    zT_917 = zT_915 - zT_916;
    ptcs = zT_917;
    ptcs = zT_917;
    ptcs = zT_917;
    zT_919 = (unsigned char*)ptcb;
    zT_921 = 9;
    zT_922 = zT_919 + ptcs;
    zT_923 = zT_921 - ptcs;
    zT_924.ptr = zT_922;
    zT_924.len = zT_923;
    zT_918 = zT_924;
    zF_48AC7B3A_markerWrite(zT_918);
    zT_926 = node.flags;
    zT_927 = 1;
    zT_928 = zT_926 & zT_927;
    zT_929 = 0;
    zT_930 = zT_928 != zT_929;
    is_const = zT_930;
    is_const = zT_930;
    is_const = zT_930;
    zT_931 = node.kind;
    zT_934 = zT_8143F551_AstKind_ptr_type;
    zT_935 = zT_931 == zT_934;
    if (zT_935) goto z_bb_163; else goto z_bb_165;
    z_bb_162:
    zT_1014 = node.kind;
    zT_1017 = zT_8143F551_AstKind_slice_type;
    zT_1018 = zT_1014 == zT_1017;
    if (zT_1018) goto z_bb_166; else goto z_bb_167;
    z_bb_163:
    zT_940 = env->typereg;
    zT_937 = zT_940;
    zT_938 = child_type;
    zT_939 = is_const;
    zT_941 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_937, zT_938, zT_939);
    ptr_tid = zT_941;
    ptr_tid = zT_941;
    ptr_tid = zT_941;
    zT_943 = "P";
    zT_945 = 1;
    zT_944.ptr = zT_943;
    zT_944.len = zT_945;
    ppm = zT_944;
    ppm = zT_944;
    ppm = zT_944;
    zT_946 = ppm;
    zF_48AC7B3A_markerWrite(zT_946);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_948[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb[_i] = zT_948[_i];
        _i++;
    }
}
    zT_950 = ptr_tid;
    zT_952 = (unsigned char*)ppb;
    zT_953 = 10;
    zT_954 = 0;
    zT_955 = zT_952 + zT_954;
    zT_956 = zT_953 - zT_954;
    zT_957.ptr = zT_955;
    zT_957.len = zT_956;
    zT_951 = zT_957;
    zT_958 = zF_A7504564_itoa(zT_950, zT_951);
    ppl = zT_958;
    ppl = zT_958;
    ppl = zT_958;
    zT_960 = 9;
    zT_961 = (unsigned int)ppl;
    zT_962 = zT_960 - zT_961;
    pps = zT_962;
    pps = zT_962;
    pps = zT_962;
    zT_964 = (unsigned char*)ppb;
    zT_966 = 9;
    zT_967 = zT_964 + pps;
    zT_968 = zT_966 - pps;
    zT_969.ptr = zT_967;
    zT_969.len = zT_968;
    zT_963 = zT_969;
    zF_48AC7B3A_markerWrite(zT_963);
    zT_971 = "\n";
    zT_973 = 1;
    zT_972.ptr = zT_971;
    zT_972.len = zT_973;
    pnl = zT_972;
    pnl = zT_972;
    pnl = zT_972;
    zT_974 = pnl;
    zF_48AC7B3A_markerWrite(zT_974);
    return ptr_tid;
    goto z_bb_162;
    z_bb_165:
    zT_979 = env->typereg;
    zT_976 = zT_979;
    zT_977 = child_type;
    zT_978 = is_const;
    zT_980 = zF_402D622A_typeRegistryGetOrCr(zT_976, zT_977, zT_978);
    ptr_tid2 = zT_980;
    ptr_tid2 = zT_980;
    ptr_tid2 = zT_980;
    zT_982 = "M";
    zT_984 = 1;
    zT_983.ptr = zT_982;
    zT_983.len = zT_984;
    ppm2 = zT_983;
    ppm2 = zT_983;
    ppm2 = zT_983;
    zT_985 = ppm2;
    zF_48AC7B3A_markerWrite(zT_985);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_987[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb2[_i] = zT_987[_i];
        _i++;
    }
}
    zT_989 = ptr_tid2;
    zT_991 = (unsigned char*)ppb2;
    zT_992 = 10;
    zT_993 = 0;
    zT_994 = zT_991 + zT_993;
    zT_995 = zT_992 - zT_993;
    zT_996.ptr = zT_994;
    zT_996.len = zT_995;
    zT_990 = zT_996;
    zT_997 = zF_A7504564_itoa(zT_989, zT_990);
    ppl2 = zT_997;
    ppl2 = zT_997;
    ppl2 = zT_997;
    zT_999 = 9;
    zT_1000 = (unsigned int)ppl2;
    zT_1001 = zT_999 - zT_1000;
    pps2 = zT_1001;
    pps2 = zT_1001;
    pps2 = zT_1001;
    zT_1003 = (unsigned char*)ppb2;
    zT_1005 = 9;
    zT_1006 = zT_1003 + pps2;
    zT_1007 = zT_1005 - pps2;
    zT_1008.ptr = zT_1006;
    zT_1008.len = zT_1007;
    zT_1002 = zT_1008;
    zF_48AC7B3A_markerWrite(zT_1002);
    zT_1010 = "\n";
    zT_1012 = 1;
    zT_1011.ptr = zT_1010;
    zT_1011.len = zT_1012;
    pnl2 = zT_1011;
    pnl2 = zT_1011;
    pnl2 = zT_1011;
    zT_1013 = pnl2;
    zF_48AC7B3A_markerWrite(zT_1013);
    return ptr_tid2;
    z_bb_166:
    zT_1020 = node.flags;
    zT_1021 = 1;
    zT_1022 = zT_1020 & zT_1021;
    zT_1023 = 0;
    zT_1024 = zT_1022 != zT_1023;
    is_const = zT_1024;
    is_const = zT_1024;
    is_const = zT_1024;
    zT_1029 = env->typereg;
    zT_1026 = zT_1029;
    zT_1027 = child_type;
    zT_1028 = is_const;
    zT_1030 = zF_8FC81A87_typeRegistryGetOrCr(zT_1026, zT_1027, zT_1028);
    sl_tid = zT_1030;
    sl_tid = zT_1030;
    sl_tid = zT_1030;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1032[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_e[_i] = zT_1032[_i];
        _i++;
    }
}
    zT_1034 = child_type;
    zT_1036 = (unsigned char*)sl_e;
    zT_1037 = 20;
    zT_1038 = 0;
    zT_1039 = zT_1036 + zT_1038;
    zT_1040 = zT_1037 - zT_1038;
    zT_1041.ptr = zT_1039;
    zT_1041.len = zT_1040;
    zT_1035 = zT_1041;
    zT_1042 = zF_A7504564_itoa(zT_1034, zT_1035);
    sl_el = zT_1042;
    sl_el = zT_1042;
    sl_el = zT_1042;
    zT_1044 = 19;
    zT_1045 = (unsigned int)sl_el;
    zT_1046 = zT_1044 - zT_1045;
    sl_es = zT_1046;
    sl_es = zT_1046;
    sl_es = zT_1046;
    zT_1048 = "SL:e";
    zT_1050 = 4;
    zT_1049.ptr = zT_1048;
    zT_1049.len = zT_1050;
    sm = zT_1049;
    sm = zT_1049;
    sm = zT_1049;
    zT_1051 = sm;
    zF_48AC7B3A_markerWrite(zT_1051);
    zT_1053 = (unsigned char*)sl_e;
    zT_1055 = 19;
    zT_1056 = zT_1053 + sl_es;
    zT_1057 = zT_1055 - sl_es;
    zT_1058.ptr = zT_1056;
    zT_1058.len = zT_1057;
    zT_1052 = zT_1058;
    zF_48AC7B3A_markerWrite(zT_1052);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1060[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_r[_i] = zT_1060[_i];
        _i++;
    }
}
    zT_1062 = sl_tid;
    zT_1064 = (unsigned char*)sl_r;
    zT_1065 = 20;
    zT_1066 = 0;
    zT_1067 = zT_1064 + zT_1066;
    zT_1068 = zT_1065 - zT_1066;
    zT_1069.ptr = zT_1067;
    zT_1069.len = zT_1068;
    zT_1063 = zT_1069;
    zT_1070 = zF_A7504564_itoa(zT_1062, zT_1063);
    sl_rl = zT_1070;
    sl_rl = zT_1070;
    sl_rl = zT_1070;
    zT_1072 = 19;
    zT_1073 = (unsigned int)sl_rl;
    zT_1074 = zT_1072 - zT_1073;
    sl_rs = zT_1074;
    sl_rs = zT_1074;
    sl_rs = zT_1074;
    zT_1076 = "s";
    zT_1078 = 1;
    zT_1077.ptr = zT_1076;
    zT_1077.len = zT_1078;
    s2 = zT_1077;
    s2 = zT_1077;
    s2 = zT_1077;
    zT_1079 = s2;
    zF_48AC7B3A_markerWrite(zT_1079);
    zT_1081 = (unsigned char*)sl_r;
    zT_1083 = 19;
    zT_1084 = zT_1081 + sl_rs;
    zT_1085 = zT_1083 - sl_rs;
    zT_1086.ptr = zT_1084;
    zT_1086.len = zT_1085;
    zT_1080 = zT_1086;
    zF_48AC7B3A_markerWrite(zT_1080);
    zT_1088 = "\n";
    zT_1090 = 1;
    zT_1089.ptr = zT_1088;
    zT_1089.len = zT_1090;
    s3 = zT_1089;
    s3 = zT_1089;
    s3 = zT_1089;
    zT_1091 = s3;
    zF_48AC7B3A_markerWrite(zT_1091);
    return sl_tid;
    z_bb_167:
    zT_1092 = node.kind;
    zT_1095 = zT_8143F551_AstKind_optional_type;
    zT_1096 = zT_1092 == zT_1095;
    if (zT_1096) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_1098 = "OPTVOID:opt";
    zT_1100 = 11;
    zT_1099.ptr = zT_1098;
    zT_1099.len = zT_1100;
    optvd_m = zT_1099;
    optvd_m = zT_1099;
    optvd_m = zT_1099;
    zT_1101 = optvd_m;
    zT_1102 = child_type;
    zF_C914CB83_markerWriteInt(zT_1101, zT_1102);
    zT_1106 = env->typereg;
    zT_1104 = zT_1106;
    zT_1105 = child_type;
    zT_1107 = zF_74A7234F_typeRegistryGetOrCr(zT_1104, zT_1105);
    optvd_tid = zT_1107;
    optvd_tid = zT_1107;
    optvd_tid = zT_1107;
    zT_1109 = "OPTVOID:optR";
    zT_1111 = 12;
    zT_1110.ptr = zT_1109;
    zT_1110.len = zT_1111;
    optvd_rm = zT_1110;
    optvd_rm = zT_1110;
    optvd_rm = zT_1110;
    zT_1112 = optvd_rm;
    zT_1113 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_1112, zT_1113);
    return optvd_tid;
    z_bb_169:
    zT_1114 = node.kind;
    zT_1117 = zT_8143F551_AstKind_array_type;
    zT_1118 = zT_1114 == zT_1117;
    if (zT_1118) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    zT_1120 = "T0";
    zT_1122 = 2;
    zT_1121.ptr = zT_1120;
    zT_1121.len = zT_1122;
    t0m = zT_1121;
    t0m = zT_1121;
    t0m = zT_1121;
    zT_1123 = t0m;
    zF_48AC7B3A_markerWrite(zT_1123);
    zT_1125 = "T1e";
    zT_1127 = 3;
    zT_1126.ptr = zT_1125;
    zT_1126.len = zT_1127;
    t1m = zT_1126;
    t1m = zT_1126;
    t1m = zT_1126;
    zT_1128 = t1m;
    zF_48AC7B3A_markerWrite(zT_1128);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1130[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t1b[_i] = zT_1130[_i];
        _i++;
    }
}
    zT_1132 = child_type;
    zT_1134 = (unsigned char*)t1b;
    zT_1135 = 20;
    zT_1136 = 0;
    zT_1137 = zT_1134 + zT_1136;
    zT_1138 = zT_1135 - zT_1136;
    zT_1139.ptr = zT_1137;
    zT_1139.len = zT_1138;
    zT_1133 = zT_1139;
    zT_1140 = zF_A7504564_itoa(zT_1132, zT_1133);
    t1l = zT_1140;
    t1l = zT_1140;
    t1l = zT_1140;
    zT_1142 = 19;
    zT_1143 = (unsigned int)t1l;
    zT_1144 = zT_1142 - zT_1143;
    t1s = zT_1144;
    t1s = zT_1144;
    t1s = zT_1144;
    zT_1146 = (unsigned char*)t1b;
    zT_1148 = 19;
    zT_1149 = zT_1146 + t1s;
    zT_1150 = zT_1148 - t1s;
    zT_1151.ptr = zT_1149;
    zT_1151.len = zT_1150;
    zT_1145 = zT_1151;
    zF_48AC7B3A_markerWrite(zT_1145);
    zT_1152 = node.child_1;
    zT_1153 = 0;
    zT_1154 = zT_1152 != (unsigned int)zT_1153;
    if (zT_1154) goto z_bb_172; else goto z_bb_173;
    z_bb_171:
    goto z_bb_155;
    z_bb_172:
    zT_1158 = env->store;
    zT_1156 = zT_1158;
    zT_1159 = node.child_1;
    zT_1157 = zT_1159;
    zT_1160 = zF_FCDD1D35_astStoreNodeAt(zT_1156, zT_1157);
    sz_node = zT_1160;
    sz_node = zT_1160;
    sz_node = zT_1160;
    zT_1162 = 0;
    arr_len = zT_1162;
    arr_len = zT_1162;
    arr_len = zT_1162;
    zT_1164 = 0;
    arr_resolved = zT_1164;
    arr_resolved = zT_1164;
    arr_resolved = zT_1164;
    zT_1165 = sz_node.kind;
    zT_1168 = zT_8143F551_AstKind_int_literal;
    zT_1169 = zT_1165 == zT_1168;
    if (zT_1169) goto z_bb_174; else goto z_bb_176;
    z_bb_173:
    zT_1347 = 18;
    return zT_1347;
    z_bb_174:
    zT_1172 = env->store;
    zT_1170 = zT_1172;
    zT_1173 = node.child_1;
    zT_1171 = zT_1173;
    zT_1174 = zF_678B9A72_astStoreIntValue(zT_1170, zT_1171);
    zT_1175 = __bootstrap_u32_from_u64(zT_1174);
    arr_len = zT_1175;
    arr_len = zT_1175;
    zT_1176 = 1;
    arr_resolved = zT_1176;
    arr_resolved = zT_1176;
    goto z_bb_175;
    z_bb_175:
    zT_1274 = "T2L";
    zT_1276 = 3;
    zT_1275.ptr = zT_1274;
    zT_1275.len = zT_1276;
    t2m = zT_1275;
    t2m = zT_1275;
    t2m = zT_1275;
    zT_1277 = t2m;
    zF_48AC7B3A_markerWrite(zT_1277);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1279[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t2b[_i] = zT_1279[_i];
        _i++;
    }
}
    zT_1281 = arr_len;
    zT_1283 = (unsigned char*)t2b;
    zT_1284 = 20;
    zT_1285 = 0;
    zT_1286 = zT_1283 + zT_1285;
    zT_1287 = zT_1284 - zT_1285;
    zT_1288.ptr = zT_1286;
    zT_1288.len = zT_1287;
    zT_1282 = zT_1288;
    zT_1289 = zF_A7504564_itoa(zT_1281, zT_1282);
    t2l = zT_1289;
    t2l = zT_1289;
    t2l = zT_1289;
    zT_1291 = 19;
    zT_1292 = (unsigned int)t2l;
    zT_1293 = zT_1291 - zT_1292;
    t2s = zT_1293;
    t2s = zT_1293;
    t2s = zT_1293;
    zT_1295 = (unsigned char*)t2b;
    zT_1297 = 19;
    zT_1298 = zT_1295 + t2s;
    zT_1299 = zT_1297 - t2s;
    zT_1300.ptr = zT_1298;
    zT_1300.len = zT_1299;
    zT_1294 = zT_1300;
    zF_48AC7B3A_markerWrite(zT_1294);
    if (arr_resolved) goto z_bb_218; else goto z_bb_219;
    z_bb_176:
    zT_1177 = sz_node.kind;
    zT_1180 = zT_8143F551_AstKind_add;
    zT_1181 = zT_1177 == zT_1180;
    if (zT_1181) goto z_bb_178; else goto z_bb_177;
    z_bb_177:
    zT_1183 = sz_node.kind;
    zT_1186 = zT_8143F551_AstKind_sub;
    zT_1187 = zT_1183 == zT_1186;
    zT_1182 = zT_1187;
    goto z_bb_179;
    z_bb_178:
    zT_1182 = 1;
    goto z_bb_179;
    z_bb_179:
    if (zT_1182) goto z_bb_180; else goto z_bb_182;
    z_bb_180:
    zT_1189 = env;
    zT_1191 = sz_node.child_0;
    zT_1190 = zT_1191;
    zT_1192 = zF_6D0DD27D_evalConstU32Full(zT_1189, zT_1190);
    lhs = zT_1192;
    lhs = zT_1192;
    lhs = zT_1192;
    zT_1194 = env;
    zT_1196 = sz_node.child_1;
    zT_1195 = zT_1196;
    zT_1197 = zF_6D0DD27D_evalConstU32Full(zT_1194, zT_1195);
    rhs = zT_1197;
    rhs = zT_1197;
    rhs = zT_1197;
    zT_1198 = 4294967295u;
    zT_1199 = lhs != zT_1198;
    if (zT_1199) goto z_bb_183; else goto z_bb_184;
    z_bb_181:
    goto z_bb_175;
    z_bb_182:
    zT_1211 = sz_node.kind;
    zT_1214 = zT_8143F551_AstKind_mul;
    zT_1215 = zT_1211 == zT_1214;
    if (zT_1215) goto z_bb_192; else goto z_bb_191;
    z_bb_183:
    zT_1201 = 4294967295u;
    zT_1202 = rhs != zT_1201;
    zT_1200 = zT_1202;
    goto z_bb_185;
    z_bb_184:
    zT_1200 = 0;
    goto z_bb_185;
    z_bb_185:
    if (zT_1200) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_1203 = 1;
    arr_resolved = zT_1203;
    arr_resolved = zT_1203;
    zT_1204 = sz_node.kind;
    zT_1207 = zT_8143F551_AstKind_add;
    zT_1208 = zT_1204 == zT_1207;
    if (zT_1208) goto z_bb_188; else goto z_bb_190;
    z_bb_187:
    goto z_bb_181;
    z_bb_188:
    zT_1209 = lhs + rhs;
    arr_len = zT_1209;
    arr_len = zT_1209;
    goto z_bb_189;
    z_bb_189:
    goto z_bb_187;
    z_bb_190:
    zT_1210 = lhs - rhs;
    arr_len = zT_1210;
    arr_len = zT_1210;
    goto z_bb_189;
    z_bb_191:
    zT_1217 = sz_node.kind;
    zT_1220 = zT_8143F551_AstKind_div;
    zT_1221 = zT_1217 == zT_1220;
    zT_1216 = zT_1221;
    goto z_bb_193;
    z_bb_192:
    zT_1216 = 1;
    goto z_bb_193;
    z_bb_193:
    if (zT_1216) goto z_bb_195; else goto z_bb_194;
    z_bb_194:
    zT_1223 = sz_node.kind;
    zT_1226 = zT_8143F551_AstKind_mod_op;
    zT_1227 = zT_1223 == zT_1226;
    zT_1222 = zT_1227;
    goto z_bb_196;
    z_bb_195:
    zT_1222 = 1;
    goto z_bb_196;
    z_bb_196:
    if (zT_1222) goto z_bb_197; else goto z_bb_199;
    z_bb_197:
    zT_1229 = env;
    zT_1231 = sz_node.child_0;
    zT_1230 = zT_1231;
    zT_1232 = zF_6D0DD27D_evalConstU32Full(zT_1229, zT_1230);
    lhs = zT_1232;
    lhs = zT_1232;
    lhs = zT_1232;
    zT_1234 = env;
    zT_1236 = sz_node.child_1;
    zT_1235 = zT_1236;
    zT_1237 = zF_6D0DD27D_evalConstU32Full(zT_1234, zT_1235);
    rhs = zT_1237;
    rhs = zT_1237;
    rhs = zT_1237;
    zT_1238 = 4294967295u;
    zT_1239 = lhs != zT_1238;
    if (zT_1239) goto z_bb_200; else goto z_bb_201;
    z_bb_198:
    goto z_bb_181;
    z_bb_199:
    zT_1260 = sz_node.kind;
    zT_1263 = zT_8143F551_AstKind_ident_expr;
    zT_1264 = zT_1260 == zT_1263;
    if (zT_1264) goto z_bb_214; else goto z_bb_215;
    z_bb_200:
    zT_1241 = 4294967295u;
    zT_1242 = rhs != zT_1241;
    zT_1240 = zT_1242;
    goto z_bb_202;
    z_bb_201:
    zT_1240 = 0;
    goto z_bb_202;
    z_bb_202:
    if (zT_1240) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    zT_1244 = 0;
    zT_1245 = rhs != zT_1244;
    zT_1243 = zT_1245;
    goto z_bb_205;
    z_bb_204:
    zT_1243 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_1243) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_1246 = 1;
    arr_resolved = zT_1246;
    arr_resolved = zT_1246;
    zT_1247 = sz_node.kind;
    zT_1250 = zT_8143F551_AstKind_mul;
    zT_1251 = zT_1247 == zT_1250;
    if (zT_1251) goto z_bb_208; else goto z_bb_210;
    z_bb_207:
    goto z_bb_198;
    z_bb_208:
    zT_1252 = lhs * rhs;
    arr_len = zT_1252;
    arr_len = zT_1252;
    goto z_bb_209;
    z_bb_209:
    goto z_bb_207;
    z_bb_210:
    zT_1253 = sz_node.kind;
    zT_1256 = zT_8143F551_AstKind_div;
    zT_1257 = zT_1253 == zT_1256;
    if (zT_1257) goto z_bb_211; else goto z_bb_213;
    z_bb_211:
    zT_1258 = lhs / rhs;
    arr_len = zT_1258;
    arr_len = zT_1258;
    goto z_bb_212;
    z_bb_212:
    goto z_bb_209;
    z_bb_213:
    zT_1259 = lhs % rhs;
    arr_len = zT_1259;
    arr_len = zT_1259;
    goto z_bb_212;
    z_bb_214:
    zT_1266 = env;
    zT_1268 = node.child_1;
    zT_1267 = zT_1268;
    zT_1269 = zF_6D0DD27D_evalConstU32Full(zT_1266, zT_1267);
    al = zT_1269;
    al = zT_1269;
    al = zT_1269;
    zT_1270 = 4294967295u;
    zT_1271 = al != zT_1270;
    if (zT_1271) goto z_bb_216; else goto z_bb_217;
    z_bb_215:
    goto z_bb_198;
    z_bb_216:
    arr_len = al;
    arr_len = al;
    zT_1272 = 1;
    arr_resolved = zT_1272;
    arr_resolved = zT_1272;
    goto z_bb_217;
    z_bb_217:
    goto z_bb_215;
    z_bb_218:
    zT_1305 = env->typereg;
    zT_1302 = zT_1305;
    zT_1303 = child_type;
    zT_1304 = arr_len;
    zT_1306 = zF_BA693C74_typeRegistryGetOrCr(zT_1302, zT_1303, zT_1304);
    at = zT_1306;
    at = zT_1306;
    at = zT_1306;
    zT_1308 = "T3a";
    zT_1310 = 3;
    zT_1309.ptr = zT_1308;
    zT_1309.len = zT_1310;
    t3m = zT_1309;
    t3m = zT_1309;
    t3m = zT_1309;
    zT_1311 = t3m;
    zF_48AC7B3A_markerWrite(zT_1311);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1313[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t3b[_i] = zT_1313[_i];
        _i++;
    }
}
    zT_1315 = at;
    zT_1317 = (unsigned char*)t3b;
    zT_1318 = 20;
    zT_1319 = 0;
    zT_1320 = zT_1317 + zT_1319;
    zT_1321 = zT_1318 - zT_1319;
    zT_1322.ptr = zT_1320;
    zT_1322.len = zT_1321;
    zT_1316 = zT_1322;
    zT_1323 = zF_A7504564_itoa(zT_1315, zT_1316);
    t3l = zT_1323;
    t3l = zT_1323;
    t3l = zT_1323;
    zT_1325 = 19;
    zT_1326 = (unsigned int)t3l;
    zT_1327 = zT_1325 - zT_1326;
    t3s = zT_1327;
    t3s = zT_1327;
    t3s = zT_1327;
    zT_1329 = (unsigned char*)t3b;
    zT_1331 = 19;
    zT_1332 = zT_1329 + t3s;
    zT_1333 = zT_1331 - t3s;
    zT_1334.ptr = zT_1332;
    zT_1334.len = zT_1333;
    zT_1328 = zT_1334;
    zF_48AC7B3A_markerWrite(zT_1328);
    zT_1335 = 18;
    zT_1336 = at != zT_1335;
    if (zT_1336) goto z_bb_220; else goto z_bb_222;
    z_bb_219:
    goto z_bb_173;
    z_bb_220:
    zT_1338 = "A";
    zT_1340 = 1;
    zT_1339.ptr = zT_1338;
    zT_1339.len = zT_1340;
    am = zT_1339;
    am = zT_1339;
    am = zT_1339;
    zT_1341 = am;
    zF_48AC7B3A_markerWrite(zT_1341);
    goto z_bb_221;
    z_bb_221:
    return at;
    z_bb_222:
    zT_1343 = "a";
    zT_1345 = 1;
    zT_1344.ptr = zT_1343;
    zT_1344.len = zT_1345;
    am = zT_1344;
    am = zT_1344;
    am = zT_1344;
    zT_1346 = am;
    zF_48AC7B3A_markerWrite(zT_1346);
    goto z_bb_221;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_338B7C76_TypeRegistry* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_79FAE712_u64 zT_18;
    zT_79FAE712_u64 zT_19;
    zT_79FAE712_u64 zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24 = 0;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_26;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_40 = {0};
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_48;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_406493CE_StructPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_406493CE_StructPayload zT_54;
    unsigned short zT_55;
    unsigned int zT_56;
    int zT_57;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    zT_8143F551_AstKind zT_68;
    int zT_69;
    int zT_70;
    unsigned int zT_71;
    int zT_72;
    int zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80 = 0;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned int zT_96 = 0;
    unsigned char* zT_97;
    unsigned int zT_98;
    int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_109;
    unsigned int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_4028D896_Arr_unsigned_char_2 zT_121;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_125;
    unsigned int zT_126;
    int zT_127;
    unsigned char* zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131 = 0;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned char* zT_137;
    unsigned int zT_139;
    unsigned char* zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143;
    int zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_2DF01B61_FieldEntry* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_2DF01B61_FieldEntry* zT_150;
    char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    int zT_167;
    unsigned int zT_168;
    zT_33EF6BFB_TypeKind zT_169;
    zT_33EF6BFB_TypeKind zT_172;
    int zT_173;
    zT_338B7C76_TypeRegistry* zT_175;
    zT_54FF90FA_TaggedUnionPayload* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_54FF90FA_TaggedUnionPayload zT_179;
    char* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    unsigned short zT_194;
    unsigned int zT_195;
    unsigned short zT_196;
    unsigned int zT_197;
    int zT_198;
    zT_6B0A7D14_AstStore* zT_200;
    unsigned int zT_201;
    zT_6B0A7D14_AstStore* zT_202;
    unsigned int* zT_203;
    unsigned int zT_204;
    zT_22A7C88B_AstNode zT_205 = {0};
    zT_8143F551_AstKind zT_206;
    zT_8143F551_AstKind zT_209;
    int zT_210;
    int zT_211;
    unsigned int zT_212;
    int zT_213;
    int zT_214;
    zT_ABC1EBBE_TypeResolveEnv* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221 = 0;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    char* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    zT_4028D896_Arr_unsigned_char_2 zT_241;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    zT_6B0A7D14_AstStore* zT_245;
    unsigned int zT_246;
    zT_6B0A7D14_AstStore* zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int zT_250 = 0;
    unsigned char* zT_251;
    unsigned int zT_252;
    int zT_253;
    unsigned char* zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257 = 0;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned char* zT_263;
    unsigned int zT_265;
    unsigned char* zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_4028D896_Arr_unsigned_char_2 zT_275;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned char* zT_279;
    unsigned int zT_280;
    int zT_281;
    unsigned char* zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285 = 0;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned char* zT_291;
    unsigned int zT_293;
    unsigned char* zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned int zT_302;
    int zT_303;
    zT_338B7C76_TypeRegistry* zT_304;
    zT_2DF01B61_FieldEntry* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    zT_2DF01B61_FieldEntry* zT_309;
    char* zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    int zT_331;
    unsigned int zT_332;
    zT_33EF6BFB_TypeKind zT_333;
    zT_33EF6BFB_TypeKind zT_336;
    int zT_337;
    zT_338B7C76_TypeRegistry* zT_339;
    zT_AF9231A2_UnionPayload* zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    zT_AF9231A2_UnionPayload zT_343;
    unsigned short zT_344;
    unsigned int zT_345;
    int zT_346;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    zT_6B0A7D14_AstStore* zT_350;
    unsigned int* zT_351;
    unsigned int zT_352;
    zT_22A7C88B_AstNode zT_353 = {0};
    zT_8143F551_AstKind zT_354;
    zT_8143F551_AstKind zT_357;
    int zT_358;
    int zT_359;
    unsigned int zT_360;
    int zT_361;
    int zT_362;
    zT_ABC1EBBE_TypeResolveEnv* zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_369 = 0;
    unsigned int zT_370;
    int zT_371;
    zT_338B7C76_TypeRegistry* zT_372;
    zT_2DF01B61_FieldEntry* zT_373;
    unsigned int zT_374;
    unsigned int zT_375;
    unsigned int zT_376;
    zT_2DF01B61_FieldEntry* zT_377;
    int zT_378;
    unsigned int zT_379;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    zT_3CB0179A_Slice_zT_05F374B1_u fchildren;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_4028D896_Arr_unsigned_char_2 b2_pb;
    unsigned int b2_pl;
    unsigned int b2_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_4028D896_Arr_unsigned_char_2 b2_tb;
    unsigned int b2_tl;
    unsigned int b2_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_6 = env->store;
    zT_4 = zT_6;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    decl = zT_7;
    decl = zT_7;
    zT_11 = env->store;
    zT_9 = zT_11;
    zT_12 = decl.child_1;
    zT_10 = zT_12;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    (void)zT_13;
    zT_17 = env->typereg;
    zT_15 = zT_17;
    zT_18 = (zT_79FAE712_u64)mod_id;
    zT_19 = 32;
    zT_20 = zT_18 << zT_19;
    zT_23 = env->store;
    zT_21 = zT_23;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_25 = (zT_79FAE712_u64)zT_24;
    zT_26 = zT_20 | zT_25;
    zT_16 = zT_26;
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, zT_16);
    spid = zT_27;
    spid = zT_27;
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    sty = zT_34;
    sty = zT_34;
    zT_38 = env->store;
    zT_36 = zT_38;
    zT_39 = decl.child_1;
    zT_37 = zT_39;
    zT_40 = zF_850FDF81_astStoreNodeExtraCh(zT_36, zT_37);
    fchildren = zT_40;
    fchildren = zT_40;
    fchildren = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    fi2 = zT_43;
    fi2 = zT_43;
    zT_44 = sty.kind;
    zT_47 = zT_33EF6BFB_TypeKind_struct_type;
    zT_48 = zT_44 == zT_47;
    if (zT_48) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_50 = env->typereg;
    zT_51 = zT_50->st_items;
    zT_52 = sty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    sp = zT_54;
    sp = zT_54;
    sp = zT_54;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_169 = sty.kind;
    zT_172 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_173 = zT_169 == zT_172;
    if (zT_173) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_55 = sp.fields_count;
    zT_56 = (unsigned int)zT_55;
    zT_57 = fi2 < zT_56;
    if (zT_57) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_61 = env->store;
    zT_59 = zT_61;
    zT_62 = fchildren.ptr;
    zT_63 = zT_62[fi2];
    zT_60 = zT_63;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    fd = zT_64;
    fd = zT_64;
    fd = zT_64;
    zT_65 = fd.kind;
    zT_68 = zT_8143F551_AstKind_field_decl;
    zT_69 = zT_65 == zT_68;
    if (zT_69) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_167 = 1;
    zT_168 = fi2 + zT_167;
    fi2 = zT_168;
    fi2 = zT_168;
    goto z_bb_6;
    z_bb_10:
    zT_71 = fd.child_0;
    zT_72 = 0;
    zT_73 = zT_71 != (unsigned int)zT_72;
    zT_70 = zT_73;
    goto z_bb_12;
    z_bb_11:
    zT_70 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_70) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_75 = env;
    zT_78 = fd.child_0;
    zT_76 = zT_78;
    zT_79 = 0;
    zT_77 = zT_79;
    zT_80 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, zT_77);
    ft = zT_80;
    ft = zT_80;
    ft = zT_80;
    zT_82 = "B2:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    b2_pn = zT_83;
    b2_pn = zT_83;
    b2_pn = zT_83;
    zT_85 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_93 = env->store;
    zT_91 = zT_93;
    zT_94 = fchildren.ptr;
    zT_95 = zT_94[fi2];
    zT_92 = zT_95;
    zT_96 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_96;
    zT_97 = (unsigned char*)b2_pb;
    zT_98 = 20;
    zT_99 = 0;
    zT_100 = zT_97 + zT_99;
    zT_101 = zT_98 - zT_99;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_90 = zT_102;
    zT_103 = zF_A7504564_itoa(zT_89, zT_90);
    b2_pl = zT_103;
    b2_pl = zT_103;
    b2_pl = zT_103;
    zT_105 = 19;
    zT_106 = (unsigned int)b2_pl;
    zT_107 = zT_105 - zT_106;
    b2_ps = zT_107;
    b2_ps = zT_107;
    b2_ps = zT_107;
    zT_109 = (unsigned char*)b2_pb;
    zT_111 = 19;
    zT_112 = zT_109 + b2_ps;
    zT_113 = zT_111 - b2_ps;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_116 = "t";
    zT_118 = 1;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    b2_tn = zT_117;
    b2_tn = zT_117;
    b2_tn = zT_117;
    zT_119 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_119);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_121[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_121[_i];
        _i++;
    }
}
    zT_123 = ft;
    zT_125 = (unsigned char*)b2_tb;
    zT_126 = 20;
    zT_127 = 0;
    zT_128 = zT_125 + zT_127;
    zT_129 = zT_126 - zT_127;
    zT_130.ptr = zT_128;
    zT_130.len = zT_129;
    zT_124 = zT_130;
    zT_131 = zF_A7504564_itoa(zT_123, zT_124);
    b2_tl = zT_131;
    b2_tl = zT_131;
    b2_tl = zT_131;
    zT_133 = 19;
    zT_134 = (unsigned int)b2_tl;
    zT_135 = zT_133 - zT_134;
    b2_ts = zT_135;
    b2_ts = zT_135;
    b2_ts = zT_135;
    zT_137 = (unsigned char*)b2_tb;
    zT_139 = 19;
    zT_140 = zT_137 + b2_ts;
    zT_141 = zT_139 - b2_ts;
    zT_142.ptr = zT_140;
    zT_142.len = zT_141;
    zT_136 = zT_142;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_143 = 18;
    zT_144 = ft != zT_143;
    if (zT_144) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_145 = env->typereg;
    zT_146 = zT_145->fe_items;
    zT_147 = sp.fields_start;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_148 + fi2;
    zT_150 = zT_146 + zT_149;
    zT_150->type_id = ft;
    zT_152 = "FSW:n";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    fsw_nm = zT_153;
    fsw_nm = zT_153;
    fsw_nm = zT_153;
    zT_155 = fsw_nm;
    zT_157 = sp.fields_start;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_158 + fi2;
    zT_160 = (unsigned int)zT_159;
    zT_156 = zT_160;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    zT_162 = "FSW:t";
    zT_164 = 5;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    fsw_tm = zT_163;
    fsw_tm = zT_163;
    fsw_tm = zT_163;
    zT_165 = fsw_tm;
    zT_166 = ft;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_175 = env->typereg;
    zT_176 = zT_175->tu_items;
    zT_177 = sty.payload_idx;
    zT_178 = (unsigned int)zT_177;
    zT_179 = zT_176[zT_178];
    tp = zT_179;
    tp = zT_179;
    tp = zT_179;
    zT_181 = "TUI:fs";
    zT_183 = 6;
    zT_182.ptr = zT_181;
    zT_182.len = zT_183;
    tui_fsm = zT_182;
    tui_fsm = zT_182;
    tui_fsm = zT_182;
    zT_184 = tui_fsm;
    zT_186 = tp.fields_start;
    zT_187 = (unsigned int)zT_186;
    zT_185 = zT_187;
    zF_C914CB83_markerWriteInt(zT_184, zT_185);
    zT_189 = "TUI:fc";
    zT_191 = 6;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    tui_fcm = zT_190;
    tui_fcm = zT_190;
    tui_fcm = zT_190;
    zT_192 = tui_fcm;
    zT_194 = tp.fields_count;
    zT_195 = (unsigned int)zT_194;
    zT_193 = zT_195;
    zF_C914CB83_markerWriteInt(zT_192, zT_193);
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_333 = sty.kind;
    zT_336 = zT_33EF6BFB_TypeKind_union_type;
    zT_337 = zT_333 == zT_336;
    if (zT_337) goto z_bb_32; else goto z_bb_33;
    z_bb_20:
    zT_196 = tp.fields_count;
    zT_197 = (unsigned int)zT_196;
    zT_198 = fi2 < zT_197;
    if (zT_198) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_202 = env->store;
    zT_200 = zT_202;
    zT_203 = fchildren.ptr;
    zT_204 = zT_203[fi2];
    zT_201 = zT_204;
    zT_205 = zF_FCDD1D35_astStoreNodeAt(zT_200, zT_201);
    fd = zT_205;
    fd = zT_205;
    fd = zT_205;
    zT_206 = fd.kind;
    zT_209 = zT_8143F551_AstKind_field_decl;
    zT_210 = zT_206 == zT_209;
    if (zT_210) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_331 = 1;
    zT_332 = fi2 + zT_331;
    fi2 = zT_332;
    fi2 = zT_332;
    goto z_bb_20;
    z_bb_24:
    zT_212 = fd.child_0;
    zT_213 = 0;
    zT_214 = zT_212 != (unsigned int)zT_213;
    zT_211 = zT_214;
    goto z_bb_26;
    z_bb_25:
    zT_211 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_211) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_216 = env;
    zT_219 = fd.child_0;
    zT_217 = zT_219;
    zT_220 = 0;
    zT_218 = zT_220;
    zT_221 = zF_F2107C15_resolveTypeExprFull(zT_216, zT_217, zT_218);
    ft = zT_221;
    ft = zT_221;
    ft = zT_221;
    zT_223 = "DFT:n";
    zT_225 = 5;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    dft_nm = zT_224;
    dft_nm = zT_224;
    dft_nm = zT_224;
    zT_226 = dft_nm;
    zT_228 = (unsigned int)fi2;
    zT_227 = zT_228;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    zT_230 = "DFT:t";
    zT_232 = 5;
    zT_231.ptr = zT_230;
    zT_231.len = zT_232;
    dft_tm = zT_231;
    dft_tm = zT_231;
    dft_tm = zT_231;
    zT_233 = dft_tm;
    zT_234 = ft;
    zF_C914CB83_markerWriteInt(zT_233, zT_234);
    zT_236 = "B2:p";
    zT_238 = 4;
    zT_237.ptr = zT_236;
    zT_237.len = zT_238;
    b2_pn = zT_237;
    b2_pn = zT_237;
    b2_pn = zT_237;
    zT_239 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_239);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_241[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_241[_i];
        _i++;
    }
}
    zT_247 = env->store;
    zT_245 = zT_247;
    zT_248 = fchildren.ptr;
    zT_249 = zT_248[fi2];
    zT_246 = zT_249;
    zT_250 = zF_8BA26B9E_astStoreNodePayload(zT_245, zT_246);
    zT_243 = zT_250;
    zT_251 = (unsigned char*)b2_pb;
    zT_252 = 20;
    zT_253 = 0;
    zT_254 = zT_251 + zT_253;
    zT_255 = zT_252 - zT_253;
    zT_256.ptr = zT_254;
    zT_256.len = zT_255;
    zT_244 = zT_256;
    zT_257 = zF_A7504564_itoa(zT_243, zT_244);
    b2_pl = zT_257;
    b2_pl = zT_257;
    b2_pl = zT_257;
    zT_259 = 19;
    zT_260 = (unsigned int)b2_pl;
    zT_261 = zT_259 - zT_260;
    b2_ps = zT_261;
    b2_ps = zT_261;
    b2_ps = zT_261;
    zT_263 = (unsigned char*)b2_pb;
    zT_265 = 19;
    zT_266 = zT_263 + b2_ps;
    zT_267 = zT_265 - b2_ps;
    zT_268.ptr = zT_266;
    zT_268.len = zT_267;
    zT_262 = zT_268;
    zF_48AC7B3A_markerWrite(zT_262);
    zT_270 = "t";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    b2_tn = zT_271;
    b2_tn = zT_271;
    b2_tn = zT_271;
    zT_273 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_273);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_275[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_275[_i];
        _i++;
    }
}
    zT_277 = ft;
    zT_279 = (unsigned char*)b2_tb;
    zT_280 = 20;
    zT_281 = 0;
    zT_282 = zT_279 + zT_281;
    zT_283 = zT_280 - zT_281;
    zT_284.ptr = zT_282;
    zT_284.len = zT_283;
    zT_278 = zT_284;
    zT_285 = zF_A7504564_itoa(zT_277, zT_278);
    b2_tl = zT_285;
    b2_tl = zT_285;
    b2_tl = zT_285;
    zT_287 = 19;
    zT_288 = (unsigned int)b2_tl;
    zT_289 = zT_287 - zT_288;
    b2_ts = zT_289;
    b2_ts = zT_289;
    b2_ts = zT_289;
    zT_291 = (unsigned char*)b2_tb;
    zT_293 = 19;
    zT_294 = zT_291 + b2_ts;
    zT_295 = zT_293 - b2_ts;
    zT_296.ptr = zT_294;
    zT_296.len = zT_295;
    zT_290 = zT_296;
    zF_48AC7B3A_markerWrite(zT_290);
    zT_298 = "DTWR\n";
    zT_300 = 5;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    dtwr_m = zT_299;
    dtwr_m = zT_299;
    dtwr_m = zT_299;
    zT_301 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_301);
    zT_302 = 18;
    zT_303 = ft != zT_302;
    if (zT_303) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_304 = env->typereg;
    zT_305 = zT_304->fe_items;
    zT_306 = tp.fields_start;
    zT_307 = (unsigned int)zT_306;
    zT_308 = zT_307 + fi2;
    zT_309 = zT_305 + zT_308;
    zT_309->type_id = ft;
    zT_311 = "FTW:n";
    zT_313 = 5;
    zT_312.ptr = zT_311;
    zT_312.len = zT_313;
    ftw_nm = zT_312;
    ftw_nm = zT_312;
    ftw_nm = zT_312;
    zT_314 = ftw_nm;
    zT_316 = tp.fields_start;
    zT_317 = (unsigned int)zT_316;
    zT_318 = zT_317 + fi2;
    zT_319 = (unsigned int)zT_318;
    zT_315 = zT_319;
    zF_C914CB83_markerWriteInt(zT_314, zT_315);
    zT_321 = "FTW:t";
    zT_323 = 5;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    ftw_tm = zT_322;
    ftw_tm = zT_322;
    ftw_tm = zT_322;
    zT_324 = ftw_tm;
    zT_325 = ft;
    zF_C914CB83_markerWriteInt(zT_324, zT_325);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_327 = "DTSK\n";
    zT_329 = 5;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    dtsk_m = zT_328;
    dtsk_m = zT_328;
    dtsk_m = zT_328;
    zT_330 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_330);
    goto z_bb_30;
    z_bb_32:
    zT_339 = env->typereg;
    zT_340 = zT_339->un_items;
    zT_341 = sty.payload_idx;
    zT_342 = (unsigned int)zT_341;
    zT_343 = zT_340[zT_342];
    up = zT_343;
    up = zT_343;
    up = zT_343;
    goto z_bb_34;
    z_bb_33:
    goto z_bb_18;
    z_bb_34:
    zT_344 = up.fields_count;
    zT_345 = (unsigned int)zT_344;
    zT_346 = fi2 < zT_345;
    if (zT_346) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_350 = env->store;
    zT_348 = zT_350;
    zT_351 = fchildren.ptr;
    zT_352 = zT_351[fi2];
    zT_349 = zT_352;
    zT_353 = zF_FCDD1D35_astStoreNodeAt(zT_348, zT_349);
    fd = zT_353;
    fd = zT_353;
    fd = zT_353;
    zT_354 = fd.kind;
    zT_357 = zT_8143F551_AstKind_field_decl;
    zT_358 = zT_354 == zT_357;
    if (zT_358) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_378 = 1;
    zT_379 = fi2 + zT_378;
    fi2 = zT_379;
    fi2 = zT_379;
    goto z_bb_34;
    z_bb_38:
    zT_360 = fd.child_0;
    zT_361 = 0;
    zT_362 = zT_360 != (unsigned int)zT_361;
    zT_359 = zT_362;
    goto z_bb_40;
    z_bb_39:
    zT_359 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_359) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_364 = env;
    zT_367 = fd.child_0;
    zT_365 = zT_367;
    zT_368 = 0;
    zT_366 = zT_368;
    zT_369 = zF_F2107C15_resolveTypeExprFull(zT_364, zT_365, zT_366);
    ft = zT_369;
    ft = zT_369;
    ft = zT_369;
    zT_370 = 18;
    zT_371 = ft != zT_370;
    if (zT_371) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_372 = env->typereg;
    zT_373 = zT_372->fe_items;
    zT_374 = up.fields_start;
    zT_375 = (unsigned int)zT_374;
    zT_376 = zT_375 + fi2;
    zT_377 = zT_373 + zT_376;
    zT_377->type_id = ft;
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
}

/* varDeclInitNeedsNameCache */
int zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    zT_8143F551_AstKind zT_3;
    int zT_4;
    int zT_5;
    zT_8143F551_AstKind zT_8;
    int zT_9;
    int zT_10;
    zT_8143F551_AstKind zT_13;
    int zT_14;
    int zT_15;
    zT_8143F551_AstKind zT_18;
    int zT_19;
    int zT_20;
    zT_8143F551_AstKind zT_23;
    int zT_24;
    int zT_25;
    zT_8143F551_AstKind zT_28;
    int zT_29;
    int zT_30;
    zT_8143F551_AstKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_8143F551_AstKind_struct_decl;
    zT_4 = init_kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_8 = zT_8143F551_AstKind_union_decl;
    zT_9 = init_kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    return zT_10;
    z_bb_4:
    zT_13 = zT_8143F551_AstKind_enum_decl;
    zT_14 = init_kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 0;
    return zT_15;
    z_bb_6:
    zT_18 = zT_8143F551_AstKind_error_set_decl;
    zT_19 = init_kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 0;
    return zT_20;
    z_bb_8:
    zT_23 = zT_8143F551_AstKind_ident_expr;
    zT_24 = init_kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 0;
    return zT_25;
    z_bb_10:
    zT_28 = zT_8143F551_AstKind_import_expr;
    zT_29 = init_kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 0;
    return zT_30;
    z_bb_12:
    zT_33 = zT_8143F551_AstKind_fn_decl;
    zT_34 = init_kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 0;
    return zT_35;
    z_bb_14:
    zT_36 = 1;
    return zT_36;
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_7;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_26 = {0};
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    int zT_32;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_39 = {0};
    zT_8143F551_AstKind zT_40;
    zT_8143F551_AstKind zT_43;
    int zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_8143F551_AstKind zT_56;
    int zT_57 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    unsigned int zT_65;
    int zT_66;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    unsigned int zT_70;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int* zT_77;
    unsigned int zT_78;
    unsigned int zT_79 = 0;
    zT_79FAE712_u64 zT_80;
    zT_79FAE712_u64 zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_79FAE712_u64 zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_85;
    int zT_86;
    unsigned int zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned int ci;
    unsigned int cr;
    zT_3CB0179A_Slice_zT_05F374B1_u cd;
    unsigned int cdi;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    ci = zT_4;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    zT_7 = ci < zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    cr = zT_11;
    cr = zT_11;
    zT_12 = 0;
    zT_13 = cr == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_88 = 1;
    zT_89 = ci + zT_88;
    ci = zT_89;
    ci = zT_89;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_20 = env->store;
    zT_18 = zT_20;
    zT_19 = cr;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    (void)zT_21;
    zT_25 = env->store;
    zT_23 = zT_25;
    zT_24 = cr;
    zT_26 = zF_850FDF81_astStoreNodeExtraCh(zT_23, zT_24);
    cd = zT_26;
    cd = zT_26;
    cd = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    cdi = zT_29;
    cdi = zT_29;
    cdi = zT_29;
    goto z_bb_7;
    z_bb_7:
    zT_31 = cd.len;
    zT_32 = cdi < zT_31;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_34 = zT_36;
    zT_37 = cd.ptr;
    zT_38 = zT_37[cdi];
    zT_35 = zT_38;
    zT_39 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    cdcl = zT_39;
    cdcl = zT_39;
    cdcl = zT_39;
    zT_40 = cdcl.kind;
    zT_43 = zT_8143F551_AstKind_var_decl;
    zT_44 = zT_40 == zT_43;
    if (zT_44) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_86 = 1;
    zT_87 = cdi + zT_86;
    cdi = zT_87;
    cdi = zT_87;
    goto z_bb_7;
    z_bb_11:
    zT_46 = cdcl.child_1;
    zT_47 = 0;
    zT_48 = zT_46 != zT_47;
    zT_45 = zT_48;
    goto z_bb_13;
    z_bb_12:
    zT_45 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_52 = env->store;
    zT_50 = zT_52;
    zT_53 = cdcl.child_1;
    zT_51 = zT_53;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    cdinit = zT_54;
    cdinit = zT_54;
    cdinit = zT_54;
    zT_56 = cdinit.kind;
    zT_55 = zT_56;
    zT_57 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_55);
    if (zT_57) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_59 = env;
    zT_62 = cdcl.child_1;
    zT_60 = zT_62;
    zT_63 = 0;
    zT_61 = zT_63;
    zT_64 = zF_F2107C15_resolveTypeExprFull(zT_59, zT_60, zT_61);
    cdtype = zT_64;
    cdtype = zT_64;
    cdtype = zT_64;
    zT_65 = 18;
    zT_66 = cdtype != zT_65;
    if (zT_66) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_68 = mods.ptr;
    zT_69 = zT_68[ci];
    zT_70 = zT_69.id;
    zT_71 = (zT_79FAE712_u64)zT_70;
    zT_72 = 4294967296ULL;
    zT_73 = zT_71 * zT_72;
    zT_76 = env->store;
    zT_74 = zT_76;
    zT_77 = cd.ptr;
    zT_78 = zT_77[cdi];
    zT_75 = zT_78;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_80 = (zT_79FAE712_u64)zT_79;
    zT_81 = zT_73 + zT_80;
    ck = zT_81;
    ck = zT_81;
    ck = zT_81;
    zT_85 = env->typereg;
    zT_82 = zT_85;
    zT_83 = ck;
    zT_84 = cdtype;
    zF_5E95558D_nameCachePut(zT_82, zT_83, zT_84);
    goto z_bb_19;
    z_bb_19:
    goto z_bb_17;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_E68301A1_Opt_804 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_8143F551_AstKind zT_30;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    zT_8143F551_AstKind zT_42;
    int zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_8143F551_AstKind zT_54;
    int zT_55;
    unsigned int zT_56;
    zT_072B53A6_ModuleRegistry* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_ABC1EBBE_TypeResolveEnv* zT_68;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_78 = 0;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_82;
    zT_E68301A1_Opt_804 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    zT_6 = 8;
    zT_7 = depth > zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 18;
    return zT_8;
    z_bb_2:
    zT_13 = env->symbol_reg;
    zT_10 = zT_13;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    fs = zT_14;
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    zT_18 = 0;
    zT_19 = zT_17 != zT_18;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_82 = 18;
    return zT_82;
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_24 = env->store;
    zT_22 = zT_24;
    zT_25 = fss->decl_node;
    zT_23 = zT_25;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    fd = zT_26;
    fd = zT_26;
    zT_27 = fd.kind;
    zT_30 = zT_8143F551_AstKind_var_decl;
    zT_31 = zT_27 != zT_30;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_32 = 18;
    return zT_32;
    z_bb_8:
    zT_36 = env->store;
    zT_34 = zT_36;
    zT_37 = fd.child_1;
    zT_35 = zT_37;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    fi = zT_38;
    fi = zT_38;
    fi = zT_38;
    zT_39 = fi.kind;
    zT_42 = zT_8143F551_AstKind_field_access;
    zT_43 = zT_39 != zT_42;
    if (zT_43) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_44 = 18;
    return zT_44;
    z_bb_10:
    zT_48 = env->store;
    zT_46 = zT_48;
    zT_49 = fi.child_0;
    zT_47 = zT_49;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_46, zT_47);
    fb = zT_50;
    fb = zT_50;
    fb = zT_50;
    zT_51 = fb.kind;
    zT_54 = zT_8143F551_AstKind_import_expr;
    zT_55 = zT_51 != zT_54;
    if (zT_55) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_56 = 18;
    return zT_56;
    z_bb_12:
    zT_58 = module_reg;
    zT_62 = env->store;
    zT_60 = zT_62;
    zT_63 = fi.child_0;
    zT_61 = zT_63;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_59 = zT_64;
    zT_65 = zF_A258E183_moduleRegistryPathT(zT_58, zT_59);
    t2 = zT_65;
    t2 = zT_65;
    t2 = zT_65;
    zT_66 = t2.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_68 = env;
    zT_69 = module_reg;
    zT_70 = importer_mod_id;
    zT_71 = m2;
    zT_76 = env->store;
    zT_74 = zT_76;
    zT_77 = fd.child_1;
    zT_75 = zT_77;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_72 = zT_78;
    zT_79 = 1;
    zT_80 = depth + zT_79;
    zT_73 = zT_80;
    env = zT_68;
    module_reg = zT_69;
    importer_mod_id = zT_70;
    target_mod_id = zT_71;
    field_name_id = zT_72;
    depth = zT_73;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_8;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    zT_22A7C88B_AstNode zT_19 = {0};
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_24 = {0};
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    int zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int* zT_35;
    unsigned int zT_36;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    zT_8143F551_AstKind zT_41;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    zT_8143F551_AstKind zT_55;
    int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_8143F551_AstKind zT_66;
    int zT_67;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_6B0A7D14_AstStore* zT_73;
    unsigned int zT_74;
    unsigned int zT_75 = 0;
    zT_BAEE192E_Opt_10 zT_76 = {0};
    unsigned char zT_77;
    zT_ABC1EBBE_TypeResolveEnv* zT_80;
    zT_072B53A6_ModuleRegistry* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6E8D187B_ModuleEntry* zT_86;
    zT_6E8D187B_ModuleEntry zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_93 = 0;
    unsigned int zT_94;
    unsigned int zT_95 = 0;
    unsigned int zT_96;
    int zT_97;
    zT_3D7259E2_SymbolRegistry* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_3D7259E2_SymbolRegistry* zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int* zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_E68301A1_Opt_804 zT_112 = {0};
    unsigned char zT_113;
    zT_6E8D187B_ModuleEntry* zT_116;
    zT_6E8D187B_ModuleEntry zT_117;
    unsigned int zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    zT_79FAE712_u64 zT_121;
    zT_6B0A7D14_AstStore* zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int* zT_125;
    unsigned int zT_126;
    unsigned int zT_127 = 0;
    zT_79FAE712_u64 zT_128;
    zT_79FAE712_u64 zT_129;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    zT_338B7C76_TypeRegistry* zT_133;
    int zT_134;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_E68301A1_Opt_804 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    mi = zT_5;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    zT_8 = mi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    root = zT_12;
    root = zT_12;
    zT_13 = 0;
    zT_14 = root == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_136 = 1;
    zT_137 = mi + zT_136;
    mi = zT_137;
    mi = zT_137;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = env->store;
    zT_16 = zT_18;
    zT_17 = root;
    zT_19 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    (void)zT_19;
    zT_23 = env->store;
    zT_21 = zT_23;
    zT_22 = root;
    zT_24 = zF_850FDF81_astStoreNodeExtraCh(zT_21, zT_22);
    decls = zT_24;
    decls = zT_24;
    decls = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    di = zT_27;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    zT_29 = decls.len;
    zT_30 = di < zT_29;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_34 = env->store;
    zT_32 = zT_34;
    zT_35 = decls.ptr;
    zT_36 = zT_35[di];
    zT_33 = zT_36;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    decl = zT_37;
    decl = zT_37;
    decl = zT_37;
    zT_38 = decl.kind;
    zT_41 = zT_8143F551_AstKind_var_decl;
    zT_42 = zT_38 != zT_41;
    if (zT_42) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_134 = 1;
    zT_135 = di + zT_134;
    di = zT_135;
    di = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_43 = decl.child_1;
    zT_44 = 0;
    zT_45 = zT_43 == zT_44;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_49 = env->store;
    zT_47 = zT_49;
    zT_50 = decl.child_1;
    zT_48 = zT_50;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    init = zT_51;
    init = zT_51;
    zT_52 = init.kind;
    zT_55 = zT_8143F551_AstKind_field_access;
    zT_56 = zT_52 != zT_55;
    if (zT_56) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_60 = env->store;
    zT_58 = zT_60;
    zT_61 = init.child_0;
    zT_59 = zT_61;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    base = zT_62;
    base = zT_62;
    base = zT_62;
    zT_63 = base.kind;
    zT_66 = zT_8143F551_AstKind_import_expr;
    zT_67 = zT_63 != zT_66;
    if (zT_67) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_69 = module_reg;
    zT_73 = env->store;
    zT_71 = zT_73;
    zT_74 = init.child_0;
    zT_72 = zT_74;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_70 = zT_75;
    zT_76 = zF_A258E183_moduleRegistryPathT(zT_69, zT_70);
    target = zT_76;
    target = zT_76;
    target = zT_76;
    zT_77 = target.has_value;
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_80 = env;
    zT_81 = module_reg;
    zT_86 = mods.ptr;
    zT_87 = zT_86[mi];
    zT_88 = zT_87.id;
    zT_82 = zT_88;
    zT_83 = mtid;
    zT_91 = env->store;
    zT_89 = zT_91;
    zT_92 = decl.child_1;
    zT_90 = zT_92;
    zT_93 = zF_8BA26B9E_astStoreNodePayload(zT_89, zT_90);
    zT_84 = zT_93;
    zT_94 = 0;
    zT_85 = zT_94;
    zT_95 = zF_E8C2AADA_resolveImportFieldA(zT_80, zT_81, zT_82, zT_83, zT_84, zT_85);
    resolved = zT_95;
    resolved = zT_95;
    resolved = zT_95;
    zT_96 = 18;
    zT_97 = resolved != zT_96;
    if (zT_97) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_102 = env->symbol_reg;
    zT_99 = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.id;
    zT_100 = zT_105;
    zT_108 = env->store;
    zT_106 = zT_108;
    zT_109 = decls.ptr;
    zT_110 = zT_109[di];
    zT_107 = zT_110;
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_106, zT_107);
    zT_101 = zT_111;
    zT_112 = zF_A398987E_symbolRegistryQuali(zT_99, zT_100, zT_101);
    sym = zT_112;
    sym = zT_112;
    sym = zT_112;
    zT_113 = sym.has_value;
    if (zT_113) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_116 = mods.ptr;
    zT_117 = zT_116[mi];
    zT_118 = zT_117.id;
    zT_119 = (zT_79FAE712_u64)zT_118;
    zT_120 = 4294967296ULL;
    zT_121 = zT_119 * zT_120;
    zT_124 = env->store;
    zT_122 = zT_124;
    zT_125 = decls.ptr;
    zT_126 = zT_125[di];
    zT_123 = zT_126;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_122, zT_123);
    zT_128 = (zT_79FAE712_u64)zT_127;
    zT_129 = zT_121 + zT_128;
    ck = zT_129;
    ck = zT_129;
    ck = zT_129;
    zT_133 = env->typereg;
    zT_130 = zT_133;
    zT_131 = ck;
    zT_132 = resolved;
    zF_5E95558D_nameCachePut(zT_130, zT_131, zT_132);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_7;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_22A7C88B_AstNode zT_18 = {0};
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_36 = {0};
    zT_8143F551_AstKind zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    zT_8143F551_AstKind zT_55;
    int zT_56;
    int zT_57;
    zT_8143F551_AstKind zT_58;
    zT_8143F551_AstKind zT_61;
    int zT_62;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_66;
    zT_6E8D187B_ModuleEntry zT_67;
    unsigned int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    mi = zT_4;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    zT_7 = mi < zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    root = zT_11;
    root = zT_11;
    zT_12 = 0;
    zT_13 = root == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_73 = 1;
    zT_74 = mi + zT_73;
    mi = zT_74;
    mi = zT_74;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_17 = env->store;
    zT_15 = zT_17;
    zT_16 = root;
    zT_18 = zF_FCDD1D35_astStoreNodeAt(zT_15, zT_16);
    (void)zT_18;
    zT_22 = env->store;
    zT_20 = zT_22;
    zT_21 = root;
    zT_23 = zF_850FDF81_astStoreNodeExtraCh(zT_20, zT_21);
    decls = zT_23;
    decls = zT_23;
    decls = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    di = zT_26;
    di = zT_26;
    di = zT_26;
    goto z_bb_7;
    z_bb_7:
    zT_28 = decls.len;
    zT_29 = di < zT_28;
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_31 = zT_33;
    zT_34 = decls.ptr;
    zT_35 = zT_34[di];
    zT_32 = zT_35;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    decl = zT_36;
    decl = zT_36;
    decl = zT_36;
    zT_37 = decl.kind;
    zT_40 = zT_8143F551_AstKind_var_decl;
    zT_41 = zT_37 == zT_40;
    if (zT_41) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_71 = 1;
    zT_72 = di + zT_71;
    di = zT_72;
    di = zT_72;
    goto z_bb_7;
    z_bb_11:
    zT_43 = decl.child_1;
    zT_44 = 0;
    zT_45 = zT_43 != (unsigned int)zT_44;
    zT_42 = zT_45;
    goto z_bb_13;
    z_bb_12:
    zT_42 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_42) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_49 = env->store;
    zT_47 = zT_49;
    zT_50 = decl.child_1;
    zT_48 = zT_50;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    init = zT_51;
    init = zT_51;
    zT_52 = init.kind;
    zT_55 = zT_8143F551_AstKind_struct_decl;
    zT_56 = zT_52 == zT_55;
    if (zT_56) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_58 = init.kind;
    zT_61 = zT_8143F551_AstKind_union_decl;
    zT_62 = zT_58 == zT_61;
    zT_57 = zT_62;
    goto z_bb_18;
    z_bb_17:
    zT_57 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_63 = env;
    zT_66 = mods.ptr;
    zT_67 = zT_66[mi];
    zT_68 = zT_67.id;
    zT_64 = zT_68;
    zT_69 = decls.ptr;
    zT_70 = zT_69[di];
    zT_65 = zT_70;
    zF_F5C3193B_resolveDeclAggregat(zT_63, zT_64, zT_65);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_8;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    zT_22A7C88B_AstNode zT_22 = {0};
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_33;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    zT_8143F551_AstKind zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    zT_111F44FD_anon_166682 zT_48;
    zT_243D6A41_FnProto* zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_56;
    zT_243D6A41_FnProto zT_57;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_6E8D187B_ModuleEntry* zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_E68301A1_Opt_804 zT_67 = {0};
    unsigned char zT_68;
    unsigned int zT_70;
    unsigned int zT_71;
    int zT_72;
    zT_939EE900_Arr_unsigned_int_1 zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    int zT_78;
    int zT_79;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_87;
    int zT_88;
    int zT_89;
    zT_8EED1867_ResolvedTypeTable* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char zT_97;
    unsigned char zT_98;
    unsigned char zT_99;
    int zT_100;
    unsigned char zT_101;
    unsigned char zT_103;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    int zT_108;
    unsigned char zT_109;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned short zT_114;
    unsigned short zT_115;
    int zT_116;
    unsigned int zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    zT_79FAE712_u64 zT_121;
    unsigned short zT_122;
    zT_79FAE712_u64 zT_123;
    zT_79FAE712_u64 zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    zT_79FAE712_u64 zT_127;
    zT_6B0A7D14_AstStore* zT_128;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_129 = {0};
    int zT_131;
    unsigned int zT_132;
    unsigned int zT_134;
    int zT_135;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int* zT_140;
    unsigned int zT_141;
    zT_22A7C88B_AstNode zT_142 = {0};
    unsigned int zT_143;
    int zT_144;
    int zT_145;
    zT_ABC1EBBE_TypeResolveEnv* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152 = 0;
    zT_338B7C76_TypeRegistry* zT_153;
    unsigned int zT_154;
    zT_338B7C76_TypeRegistry* zT_155;
    unsigned int zT_156;
    int zT_157;
    zT_8EED1867_ResolvedTypeTable* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    int zT_162;
    unsigned int zT_163;
    zT_338B7C76_TypeRegistry* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    unsigned int zT_170;
    unsigned short zT_171;
    unsigned int zT_172;
    zT_338B7C76_TypeRegistry* zT_173;
    unsigned int zT_174;
    zT_6E8D187B_ModuleEntry* zT_175;
    zT_6E8D187B_ModuleEntry zT_176;
    unsigned int zT_177;
    unsigned short zT_178;
    int zT_179;
    unsigned int zT_180;
    unsigned int zT_181 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int* zT_185;
    unsigned int zT_186;
    zT_3D7259E2_SymbolRegistry* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_3D7259E2_SymbolRegistry* zT_191;
    zT_6E8D187B_ModuleEntry* zT_192;
    zT_6E8D187B_ModuleEntry zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_E68301A1_Opt_804 zT_196 = {0};
    unsigned char zT_197;
    zT_8143F551_AstKind zT_199;
    zT_8143F551_AstKind zT_202;
    int zT_203;
    int zT_204;
    unsigned int zT_205;
    int zT_206;
    int zT_207;
    zT_ABC1EBBE_TypeResolveEnv* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214 = 0;
    unsigned int zT_215;
    int zT_216;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_8EED1867_ResolvedTypeTable* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int* zT_224;
    unsigned int zT_225;
    zT_3D7259E2_SymbolRegistry* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_3D7259E2_SymbolRegistry* zT_230;
    zT_6E8D187B_ModuleEntry* zT_231;
    zT_6E8D187B_ModuleEntry zT_232;
    unsigned int zT_233;
    zT_6B0A7D14_AstStore* zT_234;
    unsigned int zT_235;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int* zT_237;
    unsigned int zT_238;
    unsigned int zT_239 = 0;
    zT_E68301A1_Opt_804 zT_240 = {0};
    unsigned char zT_241;
    int zT_243;
    unsigned int zT_244;
    int zT_245;
    unsigned int zT_246;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_E68301A1_Opt_804 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    unsigned int fn_start;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    unsigned int tid;
    zT_E68301A1_Opt_804 sym;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    mi = zT_5;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    zT_8 = mi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    root = zT_12;
    root = zT_12;
    zT_13 = 0;
    zT_14 = root == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_245 = 1;
    zT_246 = mi + zT_245;
    mi = zT_246;
    mi = zT_246;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_21 = env->store;
    zT_19 = zT_21;
    zT_20 = root;
    zT_22 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    (void)zT_22;
    zT_26 = env->store;
    zT_24 = zT_26;
    zT_25 = root;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    decls = zT_27;
    decls = zT_27;
    decls = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    di = zT_30;
    di = zT_30;
    di = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = decls.len;
    zT_33 = di < zT_32;
    if (zT_33) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_35 = zT_37;
    zT_38 = decls.ptr;
    zT_39 = zT_38[di];
    zT_36 = zT_39;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    decl = zT_40;
    decl = zT_40;
    decl = zT_40;
    zT_41 = decl.kind;
    zT_44 = zT_8143F551_AstKind_fn_decl;
    zT_45 = zT_41 == zT_44;
    if (zT_45) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_243 = 1;
    zT_244 = di + zT_243;
    di = zT_244;
    di = zT_244;
    goto z_bb_7;
    z_bb_11:
    zT_47 = env->store;
    zT_48 = zT_47->fn_protos;
    zT_49 = zT_48.items;
    zT_52 = env->store;
    zT_50 = zT_52;
    zT_53 = decls.ptr;
    zT_54 = zT_53[di];
    zT_51 = zT_54;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_50, zT_51);
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_49[zT_56];
    proto = zT_57;
    proto = zT_57;
    proto = zT_57;
    zT_62 = env->symbol_reg;
    zT_59 = zT_62;
    zT_63 = mods.ptr;
    zT_64 = zT_63[mi];
    zT_65 = zT_64.id;
    zT_60 = zT_65;
    zT_66 = proto.name_id;
    zT_61 = zT_66;
    zT_67 = zF_A398987E_symbolRegistryQuali(zT_59, zT_60, zT_61);
    sym_check = zT_67;
    sym_check = zT_67;
    sym_check = zT_67;
    zT_68 = sym_check.has_value;
    if (zT_68) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_199 = decl.kind;
    zT_202 = zT_8143F551_AstKind_var_decl;
    zT_203 = zT_199 == zT_202;
    if (zT_203) goto z_bb_38; else goto z_bb_39;
    z_bb_14:
    sc = sym_check.value;
    zT_70 = sc->type_id;
    zT_71 = 0;
    zT_72 = zT_70 != zT_71;
    if (zT_72) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_75 = 1;
    zT_76 = 0;
    zT_74[zT_76] = zT_75;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_74[_i];
        _i++;
    }
}
    zT_77 = proto.return_type_node;
    zT_78 = 0;
    zT_79 = zT_77 != (unsigned int)zT_78;
    if (zT_79) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_81 = env;
    zT_84 = proto.return_type_node;
    zT_82 = zT_84;
    zT_85 = 0;
    zT_83 = zT_85;
    zT_86 = zF_F2107C15_resolveTypeExprFull(zT_81, zT_82, zT_83);
    rtype = zT_86;
    rtype = zT_86;
    rtype = zT_86;
    zT_87 = 18;
    zT_88 = rtype != zT_87;
    if (zT_88) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_95 = 0;
    is_ext = zT_95;
    is_ext = zT_95;
    is_ext = zT_95;
    zT_96 = decl.flags;
    zT_97 = 4;
    zT_98 = zT_96 & zT_97;
    zT_99 = 0;
    zT_100 = zT_98 != zT_99;
    if (zT_100) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_89 = 0;
    rt_box[zT_89] = rtype;
    zT_90 = resolved_types;
    zT_93 = proto.return_type_node;
    zT_91 = zT_93;
    zT_92 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_90, zT_91, zT_92);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_101 = 1;
    is_ext = zT_101;
    is_ext = zT_101;
    goto z_bb_23;
    z_bb_23:
    zT_103 = 0;
    is_variadic = zT_103;
    is_variadic = zT_103;
    is_variadic = zT_103;
    zT_104 = decl.flags;
    zT_105 = 1;
    zT_106 = zT_104 & zT_105;
    zT_107 = 0;
    zT_108 = zT_106 != zT_107;
    if (zT_108) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_109 = 1;
    is_variadic = zT_109;
    is_variadic = zT_109;
    goto z_bb_25;
    z_bb_25:
    zT_111 = env->typereg;
    zT_112 = zT_111->xt_len;
    zT_113 = (unsigned int)zT_112;
    fn_start = zT_113;
    fn_start = zT_113;
    fn_start = zT_113;
    zT_114 = proto.params_count;
    zT_115 = 0;
    zT_116 = zT_114 > zT_115;
    if (zT_116) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_118 = proto.params_start;
    zT_119 = (zT_79FAE712_u64)zT_118;
    zT_120 = 32;
    zT_121 = zT_119 << zT_120;
    zT_122 = proto.params_count;
    zT_123 = (zT_79FAE712_u64)zT_122;
    zT_124 = zT_121 | zT_123;
    p_payload = zT_124;
    p_payload = zT_124;
    p_payload = zT_124;
    zT_128 = env->store;
    zT_126 = zT_128;
    zT_127 = p_payload;
    zT_129 = zF_3EAD7B21_astStoreGetExtraChi(zT_126, zT_127);
    pnodes = zT_129;
    pnodes = zT_129;
    pnodes = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    pi = zT_132;
    pi = zT_132;
    pi = zT_132;
    goto z_bb_28;
    z_bb_27:
    zT_173 = env->typereg;
    zT_165 = zT_173;
    zT_174 = proto.name_id;
    zT_166 = zT_174;
    zT_175 = mods.ptr;
    zT_176 = zT_175[mi];
    zT_177 = zT_176.id;
    zT_167 = zT_177;
    zT_168 = is_ext;
    zT_169 = is_variadic;
    zT_170 = fn_start;
    zT_178 = proto.params_count;
    zT_171 = zT_178;
    zT_179 = 0;
    zT_180 = rt_box[zT_179];
    zT_172 = zT_180;
    zT_181 = zF_474336D7_typeRegistryGetOrCr(zT_165, zT_166, zT_167, zT_168, zT_169, zT_170, zT_171, zT_172);
    tid = zT_181;
    tid = zT_181;
    tid = zT_181;
    zT_182 = resolved_types;
    zT_185 = decls.ptr;
    zT_186 = zT_185[di];
    zT_183 = zT_186;
    zT_184 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_182, zT_183, zT_184);
    zT_191 = env->symbol_reg;
    zT_188 = zT_191;
    zT_192 = mods.ptr;
    zT_193 = zT_192[mi];
    zT_194 = zT_193.id;
    zT_189 = zT_194;
    zT_195 = proto.name_id;
    zT_190 = zT_195;
    zT_196 = zF_A398987E_symbolRegistryQuali(zT_188, zT_189, zT_190);
    sym = zT_196;
    sym = zT_196;
    sym = zT_196;
    zT_197 = sym.has_value;
    if (zT_197) goto z_bb_36; else goto z_bb_37;
    z_bb_28:
    zT_134 = pnodes.len;
    zT_135 = pi < zT_134;
    if (zT_135) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_139 = env->store;
    zT_137 = zT_139;
    zT_140 = pnodes.ptr;
    zT_141 = zT_140[pi];
    zT_138 = zT_141;
    zT_142 = zF_FCDD1D35_astStoreNodeAt(zT_137, zT_138);
    pnode = zT_142;
    pnode = zT_142;
    pnode = zT_142;
    zT_143 = pnode.child_0;
    zT_144 = 0;
    zT_145 = zT_143 != (unsigned int)zT_144;
    if (zT_145) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_162 = 1;
    zT_163 = pi + zT_162;
    pi = zT_163;
    pi = zT_163;
    goto z_bb_28;
    z_bb_32:
    zT_147 = env;
    zT_150 = pnode.child_0;
    zT_148 = zT_150;
    zT_151 = 0;
    zT_149 = zT_151;
    zT_152 = zF_F2107C15_resolveTypeExprFull(zT_147, zT_148, zT_149);
    ptype = zT_152;
    ptype = zT_152;
    ptype = zT_152;
    zT_155 = env->typereg;
    zT_153 = zT_155;
    zT_154 = ptype;
    zF_4C03AE3D_xtAppend(zT_153, zT_154);
    zT_156 = 18;
    zT_157 = ptype != zT_156;
    if (zT_157) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_158 = resolved_types;
    zT_161 = pnode.child_0;
    zT_159 = zT_161;
    zT_160 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_158, zT_159, zT_160);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_205 = decl.child_0;
    zT_206 = 0;
    zT_207 = zT_205 != (unsigned int)zT_206;
    zT_204 = zT_207;
    goto z_bb_40;
    z_bb_39:
    zT_204 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_204) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_209 = env;
    zT_212 = decl.child_0;
    zT_210 = zT_212;
    zT_213 = 0;
    zT_211 = zT_213;
    zT_214 = zF_F2107C15_resolveTypeExprFull(zT_209, zT_210, zT_211);
    vtype = zT_214;
    vtype = zT_214;
    vtype = zT_214;
    zT_215 = 18;
    zT_216 = vtype != zT_215;
    if (zT_216) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_12;
    z_bb_43:
    zT_217 = resolved_types;
    zT_220 = decl.child_0;
    zT_218 = zT_220;
    zT_219 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    zT_221 = resolved_types;
    zT_224 = decls.ptr;
    zT_225 = zT_224[di];
    zT_222 = zT_225;
    zT_223 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_221, zT_222, zT_223);
    zT_230 = env->symbol_reg;
    zT_227 = zT_230;
    zT_231 = mods.ptr;
    zT_232 = zT_231[mi];
    zT_233 = zT_232.id;
    zT_228 = zT_233;
    zT_236 = env->store;
    zT_234 = zT_236;
    zT_237 = decls.ptr;
    zT_238 = zT_237[di];
    zT_235 = zT_238;
    zT_239 = zF_8BA26B9E_astStoreNodePayload(zT_234, zT_235);
    zT_229 = zT_239;
    zT_240 = zF_A398987E_symbolRegistryQuali(zT_227, zT_228, zT_229);
    sym = zT_240;
    sym = zT_240;
    sym = zT_240;
    zT_241 = sym.has_value;
    if (zT_241) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_46;
    z_bb_46:
    goto z_bb_44;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_8;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_9 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_11;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_14;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17;
    zT_072B53A6_ModuleRegistry* zT_18;
    zT_ABC1EBBE_TypeResolveEnv* zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_20;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    zT_ABC1EBBE_TypeResolveEnv* zT_23;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_24;
    zT_8EED1867_ResolvedTypeTable* zT_25;
    zT_ABC1EBBE_TypeResolveEnv* zT_26;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_8 = module_reg;
    zT_9 = zF_3452C137_moduleRegistryGetMo(zT_8);
    mods = zT_9;
    mods = zT_9;
    mods = zT_9;
    zT_11.store = store;
    zT_11.typereg = typereg;
    zT_11.symbol_reg = symbol_reg;
    zT_11.interner = interner;
    zT_11.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    env = zT_11;
    env = zT_11;
    env = zT_11;
    (void)perm_alloc;
    zT_15 = &env;
    zT_13 = zT_15;
    zT_14 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_13, zT_14);
    zT_19 = &env;
    zT_16 = zT_19;
    zT_17 = mods;
    zT_18 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_16, zT_17, zT_18);
    zT_22 = &env;
    zT_20 = zT_22;
    zT_21 = mods;
    zF_E2882212_resolveAggregateFie(zT_20, zT_21);
    zT_26 = &env;
    zT_23 = zT_26;
    zT_24 = mods;
    zT_25 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_23, zT_24, zT_25);
    return;
}

/* __module_init */
void zF_780653D2___module_init_16(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    unsigned int zT_3;
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zT_3 = 4294967295u;
    zG_E6DB2ACE_MODULE_ID_NONE = zT_3;
    return;
}

/* EOF */
