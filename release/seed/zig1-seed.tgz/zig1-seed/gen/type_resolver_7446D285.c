#include "type_resolver_7446D285.h"
#include <stdio.h>
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* localTypeScopeInit */
zT_C8A278E4_LocalTypeScope zF_8A85AA66_localTypeScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_C8A278E4_LocalTypeScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.types = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* nameScopeGrowPair */
void zF_F638C869_nameScopeGrowPair(zT_3E40CD83_Sand* alloc, unsigned int** names, unsigned int** values, unsigned int count, unsigned int* cap, unsigned int min_cap) {
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    zT_3E40CD83_Sand* zT_14;
    zT_FF4D4E6C_EU_242 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    zT_3E40CD83_Sand* zT_25;
    zT_FF4D4E6C_EU_242 zT_31 = {0};
    unsigned char zT_32;
    unsigned char* zT_33;
    unsigned int* zT_36;
    unsigned int* zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int* zT_43;
    unsigned int zT_44;
    unsigned int* zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_v;
    unsigned int* nn;
    unsigned int* nv;
    unsigned int i;
    zT_7 = *cap;
    if ((unsigned char)(zT_7 < min_cap)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = min_cap;
    goto z_bb_3;
    z_bb_2:
    zT_10 = *cap;
    zT_11 = 2;
    zT_9 = zT_10 * zT_11;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_14 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_14, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_n = zT_22;
    zT_25 = alloc;
    zT_31 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_33 = zT_31.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_v = zT_33;
    zT_36 = (unsigned int*)raw_n;
    nn = zT_36;
    zT_38 = (unsigned int*)raw_v;
    nv = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    i = zT_41;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < count)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = *names;
    zT_44 = zT_43[i];
    nn[i] = zT_44;
    zT_45 = *values;
    zT_46 = zT_45[i];
    nv[i] = zT_46;
    goto z_bb_13;
    z_bb_12:
    *names = nn;
    *values = nv;
    *cap = nc;
    return;
    z_bb_13:
    zT_47 = 1;
    zT_49 = i + (unsigned int)((unsigned int)zT_47);
    i = zT_49;
    goto z_bb_10;
}

/* nameScopeLookup */
zT_BAEE192E_Opt_10 zF_1B08A8E4_nameScopeLookup(unsigned int* names, unsigned int* values, unsigned int count, unsigned int name_id) {
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned int i;
    i = count;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = i - (unsigned int)(1);
    i = zT_8;
    zT_9 = names[i];
    if ((unsigned char)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = values[i];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_6:
    goto z_bb_4;
}

/* localTypeScopePush */
void zF_A3A445A0_localTypeScopePush(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->types;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->types;
    zT_21 = scope->count;
    zT_20[zT_21] = type_id;
    zT_22 = scope->count;
    scope->count = (unsigned int)(zT_22 + (unsigned int)(1));
    return;
}

/* localTypeScopeLookup */
zT_BAEE192E_Opt_10 zF_C768898A_localTypeScopeLooku(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    zT_2 = scope->names;
    zT_3 = scope->types;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* localConstScopeInit */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_E2DF2801_LocalConstScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.nodes = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localConstScopePush */
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->nodes;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->nodes;
    zT_21 = scope->count;
    zT_20[zT_21] = decl_node;
    zT_22 = scope->count;
    scope->count = (unsigned int)(zT_22 + (unsigned int)(1));
    return;
}

/* localConstScopeLookup */
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    zT_2 = scope->names;
    zT_3 = scope->nodes;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* rawArrayEnsureCapacity */
void zF_BEFE4370_rawArrayEnsureCapac(zT_3E40CD83_Sand* alloc, unsigned char** items, unsigned int len, unsigned int* cap, unsigned int elem_size, unsigned int min_cap) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_15;
    int zT_16;
    zT_3E40CD83_Sand* zT_19;
    unsigned char* zT_20;
    unsigned int zT_25;
    zT_6E306FF1_Opt_242 zT_29 = {0};
    unsigned char zT_30;
    zT_3E40CD83_Sand* zT_32;
    zT_FF4D4E6C_EU_242 zT_37 = {0};
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_42;
    unsigned int zT_43;
    unsigned char* zT_46;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_50;
    unsigned int nc;
    zT_6E306FF1_Opt_242 grown;
    unsigned char* raw;
    unsigned int ei;
    zT_6 = *cap;
    if ((unsigned char)(len < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap;
    if ((unsigned char)(zT_9 < min_cap)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = min_cap;
    goto z_bb_5;
    z_bb_4:
    zT_12 = *cap;
    zT_13 = 2;
    zT_11 = zT_12 * zT_13;
    goto z_bb_5;
    z_bb_5:
    nc = zT_11;
    zT_15 = *cap;
    zT_16 = 0;
    if ((unsigned char)(zT_15 > (unsigned int)zT_16)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_19 = alloc;
    zT_20 = *items;
    zT_25 = *cap;
    zT_29 = zF_33A3D4F8_sandTryReallocInPla(zT_19, zT_20, (unsigned int)(zT_25 * elem_size), (unsigned int)(nc * elem_size), (unsigned int)(4));
    grown = zT_29;
    zT_30 = grown.has_value;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_32 = alloc;
    zT_37 = zF_1395EB68_sandAlloc(zT_32, (unsigned int)(nc * elem_size), (unsigned int)(4));
    zT_38 = zT_37.is_error;
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    *cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_39 = zT_37.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_39;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ei = zT_43;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(ei < (unsigned int)(len * elem_size))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_46 = *items;
    zT_47 = zT_46[ei];
    raw[ei] = zT_47;
    goto z_bb_16;
    z_bb_15:
    *items = raw;
    *cap = nc;
    return;
    z_bb_16:
    zT_48 = 1;
    zT_50 = ei + (unsigned int)((unsigned int)zT_48);
    ei = zT_50;
    goto z_bb_13;
}

/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    zT_52CDA6EF_DepEdge* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->depend_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = &p;
    zT_6 = self->depend_len;
    zT_7 = &self->depend_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(8), (unsigned int)(8));
    self->depend_items = (zT_52CDA6EF_DepEdge*)((zT_52CDA6EF_DepEdge*)p);
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    self->depend_len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->worklist_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = &p;
    zT_6 = self->worklist_len;
    zT_7 = &self->worklist_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(4), (unsigned int)(64));
    self->worklist_items = (unsigned int*)((unsigned int*)p);
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 + (unsigned int)((unsigned int)zT_6));
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_FF4D4E6C_EU_242 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((unsigned char)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((unsigned char)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_19 = zT_17.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* markerU32 */
void zF_C8A36147_markerU32(unsigned int value) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12 = 0;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5826BFC7_Arr_unsigned_char_1 b;
    unsigned int l;
    unsigned int s;
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = value;
    zT_8 = 0;
    zT_9 = (unsigned char*)((unsigned char*)b) + zT_8;
    zT_10 = (unsigned int)(12) - zT_8;
    zT_11.ptr = zT_9;
    zT_11.len = zT_10;
    zT_5 = zT_11;
    zT_12 = zF_A7504564_itoa(zT_4, zT_5);
    l = zT_12;
    zT_16 = (unsigned int)(11) - (unsigned int)((unsigned int)l);
    s = zT_16;
    zT_21 = (unsigned char*)((unsigned char*)b) + s;
    zT_22 = (unsigned int)(11) - s;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    zT_17 = zT_23;
    zF_48AC7B3A_markerWrite(zT_17);
    return;
}

/* layoutCompute */
void zF_0E9E97D8_layoutCompute(zT_338B7C76_TypeRegistry* registry, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_19;
    unsigned short zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_2DF01B61_FieldEntry* zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry zT_42;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    zT_2DF01B61_FieldEntry* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    unsigned int zT_58 = 0;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char zT_78 = 0;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    int zT_88;
    unsigned char zT_90 = 0;
    zT_D155D06D_Type* zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    zT_457ECFEE_EnumPayload* zT_97;
    unsigned short zT_98;
    unsigned int zT_99;
    zT_457ECFEE_EnumPayload zT_100;
    zT_D155D06D_Type* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_D155D06D_Type zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    unsigned char zT_112;
    unsigned char zT_114 = 0;
    zT_D155D06D_Type* zT_115;
    zT_33EF6BFB_TypeKind zT_116;
    zT_AF9231A2_UnionPayload* zT_121;
    unsigned short zT_122;
    unsigned int zT_123;
    zT_AF9231A2_UnionPayload zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned short zT_129;
    unsigned int zT_130;
    int zT_132;
    unsigned int zT_133;
    int zT_135;
    unsigned int zT_136;
    int zT_138;
    unsigned int zT_139;
    zT_2DF01B61_FieldEntry* zT_142;
    unsigned int zT_143;
    zT_2DF01B61_FieldEntry zT_144;
    zT_D155D06D_Type* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_D155D06D_Type zT_149;
    zT_33EF6BFB_TypeKind zT_150;
    unsigned int zT_154;
    unsigned int zT_156;
    unsigned char zT_157;
    unsigned char zT_159;
    unsigned int zT_160;
    int zT_161;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    unsigned char zT_172 = 0;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    int zT_182;
    unsigned char zT_184 = 0;
    zT_D155D06D_Type* zT_185;
    zT_33EF6BFB_TypeKind zT_186;
    zT_338B7C76_TypeRegistry* zT_190;
    unsigned int zT_191;
    zT_33EF6BFB_TypeKind zT_192;
    zT_54FF90FA_TaggedUnionPayload* zT_197;
    unsigned short zT_198;
    unsigned int zT_199;
    zT_54FF90FA_TaggedUnionPayload zT_200;
    zT_D155D06D_Type* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_D155D06D_Type zT_205;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned short zT_210;
    unsigned int zT_211;
    int zT_213;
    unsigned int zT_214;
    int zT_216;
    unsigned int zT_217;
    int zT_219;
    unsigned int zT_220;
    zT_2DF01B61_FieldEntry* zT_223;
    unsigned int zT_224;
    zT_2DF01B61_FieldEntry zT_225;
    unsigned char* zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    unsigned int zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239;
    zT_D155D06D_Type* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_D155D06D_Type zT_245;
    zT_33EF6BFB_TypeKind zT_246;
    unsigned int zT_250;
    unsigned int zT_252;
    unsigned char zT_253;
    unsigned char zT_255;
    unsigned int zT_256;
    int zT_257;
    unsigned int zT_259;
    unsigned char zT_261;
    unsigned int zT_264;
    unsigned char zT_265;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271 = 0;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274 = 0;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    unsigned char zT_284 = 0;
    zT_D155D06D_Type* zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    zT_0B10E8E9_OptionalPayload* zT_291;
    unsigned short zT_292;
    unsigned int zT_293;
    zT_0B10E8E9_OptionalPayload zT_294;
    zT_D155D06D_Type* zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_D155D06D_Type zT_299;
    unsigned char zT_301;
    unsigned int zT_305;
    unsigned char zT_306;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_315 = 0;
    unsigned int zT_318 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320;
    unsigned char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    unsigned char zT_324 = 0;
    zT_D155D06D_Type* zT_325;
    zT_33EF6BFB_TypeKind zT_326;
    zT_42C2D6BF_EUPayload* zT_331;
    unsigned short zT_332;
    unsigned int zT_333;
    zT_42C2D6BF_EUPayload zT_334;
    zT_D155D06D_Type* zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    zT_D155D06D_Type zT_339;
    unsigned int zT_341;
    unsigned int zT_344;
    unsigned char zT_348;
    unsigned int zT_352;
    unsigned char zT_353;
    unsigned int zT_357;
    unsigned int zT_358;
    unsigned int zT_359 = 0;
    unsigned int zT_360;
    unsigned int zT_363 = 0;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    unsigned int zT_370;
    unsigned char* zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned int zT_373;
    unsigned char zT_374 = 0;
    zT_D155D06D_Type* zT_375;
    zT_33EF6BFB_TypeKind zT_376;
    zT_E834303C_ArrayPayload* zT_381;
    unsigned short zT_382;
    unsigned int zT_383;
    zT_E834303C_ArrayPayload zT_384;
    zT_D155D06D_Type* zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    zT_D155D06D_Type zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned char* zT_395;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_396;
    unsigned int zT_397;
    unsigned char zT_398;
    unsigned char zT_400 = 0;
    zT_D155D06D_Type* zT_401;
    zT_33EF6BFB_TypeKind zT_402;
    zT_666DC2E1_TuplePayload* zT_407;
    unsigned short zT_408;
    unsigned int zT_409;
    zT_666DC2E1_TuplePayload zT_410;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned short zT_415;
    unsigned int zT_416;
    int zT_418;
    unsigned int zT_419;
    int zT_421;
    unsigned int zT_422;
    int zT_424;
    unsigned int zT_425;
    unsigned int* zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    zT_D155D06D_Type* zT_432;
    unsigned int zT_433;
    zT_D155D06D_Type zT_434;
    unsigned int zT_435;
    unsigned char zT_437;
    unsigned int zT_439 = 0;
    unsigned int zT_440;
    unsigned int zT_441;
    unsigned char zT_442;
    unsigned char zT_444;
    unsigned int zT_445;
    int zT_446;
    unsigned int zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    unsigned int zT_451 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    unsigned int zT_453;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    unsigned char zT_457 = 0;
    unsigned int zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_462;
    unsigned char* zT_464;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_465;
    unsigned int zT_466;
    int zT_467;
    unsigned char zT_469 = 0;
    zT_D155D06D_Type* zT_470;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = registry->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_11 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_11 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_92 = ty.kind;
    if ((unsigned char)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_16 = registry;
    zT_17 = tid;
    zF_331152CD_typeRegistryCompute(zT_16, zT_17);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_19 = registry->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_24 = sp.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = sp.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    offset = zT_31;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    max_align = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    fi = zT_37;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = registry->fe_items;
    zT_41 = fstart + fi;
    zT_42 = zT_40[zT_41];
    fe = zT_42;
    zT_44 = registry->types_items;
    zT_45 = fe.type_id;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zT_44[zT_46];
    ft = zT_47;
    zT_48 = ft.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_70 = offset;
    zT_71 = max_align;
    zT_72 = zF_D2BAC673_alignUp_1(zT_70, zT_71);
    ty.size = zT_72;
    zT_75 = "alignment";
    zT_77 = 9;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    zT_73 = zT_76;
    zT_74 = max_align;
    zT_78 = zF_BBDF00B7_typeNarrowU8(zT_73, zT_74);
    ty.alignment = zT_78;
    zT_79 = ty.size;
    if ((unsigned char)(zT_79 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_67 = 1;
    zT_69 = fi + (unsigned int)((unsigned int)zT_67);
    fi = zT_69;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_52 = registry->fe_items;
    zT_53 = fstart + fi;
    zT_52[zT_53] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_54 = offset;
    zT_56 = ft.alignment;
    zT_58 = zF_D2BAC673_alignUp_1(zT_54, (unsigned int)((unsigned int)zT_56));
    offset = zT_58;
    fe.offset = offset;
    zT_59 = registry->fe_items;
    zT_60 = fstart + fi;
    zT_59[zT_60] = fe;
    zT_61 = ft.size;
    zT_62 = offset + zT_61;
    offset = zT_62;
    zT_63 = ft.alignment;
    if ((unsigned char)(zT_63 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_65 = ft.alignment;
    zT_66 = (unsigned int)zT_65;
    max_align = zT_66;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    zT_85 = "alignment";
    zT_87 = 9;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    zT_83 = zT_86;
    zT_88 = 1;
    zT_90 = zF_BBDF00B7_typeNarrowU8(zT_83, (unsigned int)((unsigned int)zT_88));
    ty.alignment = zT_90;
    goto z_bb_17;
    z_bb_17:
    zT_91 = registry->types_items;
    zT_91[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_97 = registry->en_items;
    zT_98 = ty.payload_idx;
    zT_99 = (unsigned int)zT_98;
    zT_100 = zT_97[zT_99];
    ep = zT_100;
    zT_102 = registry->types_items;
    zT_103 = ep.backing_type;
    zT_104 = (unsigned int)zT_103;
    zT_105 = zT_102[zT_104];
    bt = zT_105;
    zT_106 = bt.size;
    ty.size = zT_106;
    zT_109 = "alignment";
    zT_111 = 9;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    zT_107 = zT_110;
    zT_112 = bt.alignment;
    zT_114 = zF_BBDF00B7_typeNarrowU8(zT_107, (unsigned int)((unsigned int)zT_112));
    ty.alignment = zT_114;
    zT_115 = registry->types_items;
    zT_115[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_116 = ty.kind;
    if ((unsigned char)(zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_121 = registry->un_items;
    zT_122 = ty.payload_idx;
    zT_123 = (unsigned int)zT_122;
    zT_124 = zT_121[zT_123];
    up = zT_124;
    zT_126 = up.fields_start;
    zT_127 = (unsigned int)zT_126;
    fstart = zT_127;
    zT_129 = up.fields_count;
    zT_130 = (unsigned int)zT_129;
    fcount = zT_130;
    zT_132 = 0;
    zT_133 = (unsigned int)zT_132;
    max_sz = zT_133;
    zT_135 = 1;
    zT_136 = (unsigned int)zT_135;
    max_align = zT_136;
    zT_138 = 0;
    zT_139 = (unsigned int)zT_138;
    fi = zT_139;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_186 = ty.kind;
    if ((unsigned char)(zT_186 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((unsigned char)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_142 = registry->fe_items;
    zT_143 = fstart + fi;
    zT_144 = zT_142[zT_143];
    fe = zT_144;
    zT_146 = registry->types_items;
    zT_147 = fe.type_id;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    ft = zT_149;
    zT_150 = ft.kind;
    if ((unsigned char)(zT_150 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_164 = max_sz;
    zT_165 = max_align;
    zT_166 = zF_D2BAC673_alignUp_1(zT_164, zT_165);
    ty.size = zT_166;
    zT_169 = "alignment";
    zT_171 = 9;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    zT_167 = zT_170;
    zT_168 = max_align;
    zT_172 = zF_BBDF00B7_typeNarrowU8(zT_167, zT_168);
    ty.alignment = zT_172;
    zT_173 = ty.size;
    if ((unsigned char)(zT_173 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_161 = 1;
    zT_163 = fi + (unsigned int)((unsigned int)zT_161);
    fi = zT_163;
    goto z_bb_24;
    z_bb_28:
    zT_154 = ft.size;
    if ((unsigned char)(zT_154 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_156 = ft.size;
    max_sz = zT_156;
    goto z_bb_31;
    z_bb_31:
    zT_157 = ft.alignment;
    if ((unsigned char)(zT_157 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_159 = ft.alignment;
    zT_160 = (unsigned int)zT_159;
    max_align = zT_160;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    zT_179 = "alignment";
    zT_181 = 9;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    zT_177 = zT_180;
    zT_182 = 1;
    zT_184 = zF_BBDF00B7_typeNarrowU8(zT_177, (unsigned int)((unsigned int)zT_182));
    ty.alignment = zT_184;
    goto z_bb_35;
    z_bb_35:
    zT_185 = registry->types_items;
    zT_185[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_190 = registry;
    zT_191 = tid;
    zF_62A8E268_typeRegistryCompute(zT_190, zT_191);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_192 = ty.kind;
    if ((unsigned char)(zT_192 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_197 = registry->tu_items;
    zT_198 = ty.payload_idx;
    zT_199 = (unsigned int)zT_198;
    zT_200 = zT_197[zT_199];
    tp = zT_200;
    zT_202 = registry->types_items;
    zT_203 = tp.tag_type;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zT_202[zT_204];
    tag_ty = zT_205;
    zT_207 = tp.fields_start;
    zT_208 = (unsigned int)zT_207;
    fstart = zT_208;
    zT_210 = tp.fields_count;
    zT_211 = (unsigned int)zT_210;
    fcount = zT_211;
    zT_213 = 0;
    zT_214 = (unsigned int)zT_213;
    max_ps = zT_214;
    zT_216 = 1;
    zT_217 = (unsigned int)zT_216;
    max_pa = zT_217;
    zT_219 = 0;
    zT_220 = (unsigned int)zT_219;
    fi = zT_220;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_286 = ty.kind;
    if ((unsigned char)(zT_286 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((unsigned char)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_223 = registry->fe_items;
    zT_224 = fstart + fi;
    zT_225 = zT_223[zT_224];
    fe = zT_225;
    zT_227 = "FER:n";
    zT_229 = 5;
    zT_228.ptr = zT_227;
    zT_228.len = zT_229;
    fer_nm = zT_228;
    zT_230 = fer_nm;
    zF_C914CB83_markerWriteInt(zT_230, (unsigned int)((unsigned int)(unsigned int)(fstart + fi)));
    zT_235 = "FER:t";
    zT_237 = 5;
    zT_236.ptr = zT_235;
    zT_236.len = zT_237;
    fer_tm = zT_236;
    zT_238 = fer_tm;
    zT_239 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_238, zT_239);
    zT_242 = registry->types_items;
    zT_243 = fe.type_id;
    zT_244 = (unsigned int)zT_243;
    zT_245 = zT_242[zT_244];
    ft = zT_245;
    zT_246 = ft.kind;
    if ((unsigned char)(zT_246 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_261 = tag_ty.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_261) > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_257 = 1;
    zT_259 = fi + (unsigned int)((unsigned int)zT_257);
    fi = zT_259;
    goto z_bb_42;
    z_bb_46:
    zT_250 = ft.size;
    if ((unsigned char)(zT_250 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_252 = ft.size;
    max_ps = zT_252;
    goto z_bb_49;
    z_bb_49:
    zT_253 = ft.alignment;
    if ((unsigned char)(zT_253 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_255 = ft.alignment;
    zT_256 = (unsigned int)zT_255;
    max_pa = zT_256;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_265 = tag_ty.alignment;
    zT_264 = (unsigned int)zT_265;
    goto z_bb_54;
    z_bb_53:
    zT_264 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_264;
    zT_268 = tag_ty.size;
    total = zT_268;
    zT_269 = total;
    zT_270 = max_pa;
    zT_271 = zF_D2BAC673_alignUp_1(zT_269, zT_270);
    total = zT_271;
    zT_272 = max_ps;
    zT_273 = max_pa;
    zT_274 = zF_D2BAC673_alignUp_1(zT_272, zT_273);
    zT_275 = total + zT_274;
    total = zT_275;
    zT_276 = total;
    zT_277 = overall_align;
    zT_278 = zF_D2BAC673_alignUp_1(zT_276, zT_277);
    ty.size = zT_278;
    zT_281 = "alignment";
    zT_283 = 9;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    zT_279 = zT_282;
    zT_280 = overall_align;
    zT_284 = zF_BBDF00B7_typeNarrowU8(zT_279, zT_280);
    ty.alignment = zT_284;
    zT_285 = registry->types_items;
    zT_285[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_291 = registry->opt_items;
    zT_292 = ty.payload_idx;
    zT_293 = (unsigned int)zT_292;
    zT_294 = zT_291[zT_293];
    op = zT_294;
    zT_296 = registry->types_items;
    zT_297 = op.payload;
    zT_298 = (unsigned int)zT_297;
    zT_299 = zT_296[zT_298];
    pt = zT_299;
    zT_301 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_301) > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_326 = ty.kind;
    if ((unsigned char)(zT_326 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_306 = pt.alignment;
    zT_305 = (unsigned int)zT_306;
    goto z_bb_60;
    z_bb_59:
    zT_305 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_305;
    zT_311 = pt.size;
    zT_315 = zF_D2BAC673_alignUp_1(zT_311, (unsigned int)(4));
    zT_310 = pay_align;
    zT_318 = zF_D2BAC673_alignUp_1((unsigned int)(zT_315 + (unsigned int)(4)), zT_310);
    ty.size = zT_318;
    zT_321 = "alignment";
    zT_323 = 9;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    zT_319 = zT_322;
    zT_320 = pay_align;
    zT_324 = zF_BBDF00B7_typeNarrowU8(zT_319, zT_320);
    ty.alignment = zT_324;
    zT_325 = registry->types_items;
    zT_325[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_331 = registry->eu_items;
    zT_332 = ty.payload_idx;
    zT_333 = (unsigned int)zT_332;
    zT_334 = zT_331[zT_333];
    ep_1 = zT_334;
    zT_336 = registry->types_items;
    zT_337 = ep_1.payload;
    zT_338 = (unsigned int)zT_337;
    zT_339 = zT_336[zT_338];
    pt = zT_339;
    zT_341 = pt.size;
    if ((unsigned char)(zT_341 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_376 = ty.kind;
    if ((unsigned char)(zT_376 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_344 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_344 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_344;
    zT_348 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_348) > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_353 = pt.alignment;
    zT_352 = (unsigned int)zT_353;
    goto z_bb_69;
    z_bb_68:
    zT_352 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_352;
    zT_357 = union_sz;
    zT_358 = union_align;
    zT_359 = zF_D2BAC673_alignUp_1(zT_357, zT_358);
    total = zT_359;
    zT_360 = total;
    zT_363 = zF_D2BAC673_alignUp_1(zT_360, (unsigned int)(4));
    zT_365 = zT_363 + (unsigned int)(4);
    total = zT_365;
    zT_366 = total;
    zT_367 = union_align;
    zT_368 = zF_D2BAC673_alignUp_1(zT_366, zT_367);
    ty.size = zT_368;
    zT_371 = "alignment";
    zT_373 = 9;
    zT_372.ptr = zT_371;
    zT_372.len = zT_373;
    zT_369 = zT_372;
    zT_370 = union_align;
    zT_374 = zF_BBDF00B7_typeNarrowU8(zT_369, zT_370);
    ty.alignment = zT_374;
    zT_375 = registry->types_items;
    zT_375[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_381 = registry->array_items;
    zT_382 = ty.payload_idx;
    zT_383 = (unsigned int)zT_382;
    zT_384 = zT_381[zT_383];
    ap = zT_384;
    zT_386 = registry->types_items;
    zT_387 = ap.elem;
    zT_388 = (unsigned int)zT_387;
    zT_389 = zT_386[zT_388];
    et = zT_389;
    zT_390 = et.size;
    zT_391 = ap.length;
    ty.size = (unsigned int)(zT_390 * zT_391);
    zT_395 = "alignment";
    zT_397 = 9;
    zT_396.ptr = zT_395;
    zT_396.len = zT_397;
    zT_393 = zT_396;
    zT_398 = et.alignment;
    zT_400 = zF_BBDF00B7_typeNarrowU8(zT_393, (unsigned int)((unsigned int)zT_398));
    ty.alignment = zT_400;
    zT_401 = registry->types_items;
    zT_401[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_402 = ty.kind;
    if ((unsigned char)(zT_402 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_407 = registry->tup_items;
    zT_408 = ty.payload_idx;
    zT_409 = (unsigned int)zT_408;
    zT_410 = zT_407[zT_409];
    tp_2 = zT_410;
    zT_412 = tp_2.elems_start;
    zT_413 = (unsigned int)zT_412;
    estr = zT_413;
    zT_415 = tp_2.elems_count;
    zT_416 = (unsigned int)zT_415;
    ecount = zT_416;
    zT_418 = 0;
    zT_419 = (unsigned int)zT_418;
    offset = zT_419;
    zT_421 = 1;
    zT_422 = (unsigned int)zT_421;
    max_align = zT_422;
    zT_424 = 0;
    zT_425 = (unsigned int)zT_424;
    ei = zT_425;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    if ((unsigned char)(ei < ecount)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_428 = registry->xt_items;
    zT_429 = estr + ei;
    zT_430 = zT_428[zT_429];
    elem_tid = zT_430;
    zT_432 = registry->types_items;
    zT_433 = (unsigned int)elem_tid;
    zT_434 = zT_432[zT_433];
    et = zT_434;
    zT_435 = offset;
    zT_437 = et.alignment;
    zT_439 = zF_D2BAC673_alignUp_1(zT_435, (unsigned int)((unsigned int)zT_437));
    offset = zT_439;
    zT_440 = et.size;
    zT_441 = offset + zT_440;
    offset = zT_441;
    zT_442 = et.alignment;
    if ((unsigned char)(zT_442 > max_align)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_449 = offset;
    zT_450 = max_align;
    zT_451 = zF_D2BAC673_alignUp_1(zT_449, zT_450);
    ty.size = zT_451;
    zT_454 = "alignment";
    zT_456 = 9;
    zT_455.ptr = zT_454;
    zT_455.len = zT_456;
    zT_452 = zT_455;
    zT_453 = max_align;
    zT_457 = zF_BBDF00B7_typeNarrowU8(zT_452, zT_453);
    ty.alignment = zT_457;
    zT_458 = ty.size;
    if ((unsigned char)(zT_458 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_446 = 1;
    zT_448 = ei + (unsigned int)((unsigned int)zT_446);
    ei = zT_448;
    goto z_bb_75;
    z_bb_79:
    zT_444 = et.alignment;
    zT_445 = (unsigned int)zT_444;
    max_align = zT_445;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    ty.size = (unsigned int)(1);
    zT_464 = "alignment";
    zT_466 = 9;
    zT_465.ptr = zT_464;
    zT_465.len = zT_466;
    zT_462 = zT_465;
    zT_467 = 1;
    zT_469 = zF_BBDF00B7_typeNarrowU8(zT_462, (unsigned int)((unsigned int)zT_467));
    ty.alignment = zT_469;
    goto z_bb_82;
    z_bb_82:
    zT_470 = registry->types_items;
    zT_470[idx] = ty;
    goto z_bb_74;
}

/* layoutDepOk */
unsigned char zF_BEEAF73E_layoutDepOk(zT_338B7C76_TypeRegistry* registry, unsigned int dep, unsigned int depth) {
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_15 = 0;
    if ((unsigned char)(dep == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(dep == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(dep == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_12 = registry;
    zT_13 = dep;
    zT_14 = depth;
    zT_15 = zF_3E55D0D5_layoutEnsure(zT_12, zT_13, zT_14);
    return zT_15;
}

/* layoutFieldDepsOk */
unsigned char zF_B32C0425_layoutFieldDepsOk(zT_338B7C76_TypeRegistry* registry, unsigned int fstart, unsigned short fcount, unsigned int depth) {
    int zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_2DF01B61_FieldEntry* zT_12;
    unsigned int zT_14;
    zT_2DF01B61_FieldEntry zT_15;
    unsigned char zT_17 = 0;
    int zT_20;
    unsigned int zT_22;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = registry;
    zT_12 = registry->fe_items;
    zT_14 = (unsigned int)((unsigned int)fstart) + fi;
    zT_15 = zT_12[zT_14];
    zT_10 = zT_15.type_id;
    zT_11 = depth;
    zT_17 = zF_BEEAF73E_layoutDepOk(zT_9, zT_10, zT_11);
    if ((unsigned char)(!zT_17)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_20 = 1;
    zT_22 = fi + (unsigned int)((unsigned int)zT_20);
    fi = zT_22;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
}

/* layoutEnsure */
unsigned char zF_3E55D0D5_layoutEnsure(zT_338B7C76_TypeRegistry* registry, unsigned int tid, unsigned int depth) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    unsigned char zT_14;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_406493CE_StructPayload* zT_30;
    unsigned short zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    unsigned short zT_36;
    unsigned char zT_42 = 0;
    zT_33EF6BFB_TypeKind zT_43;
    zT_457ECFEE_EnumPayload* zT_48;
    unsigned short zT_49;
    unsigned int zT_50;
    zT_457ECFEE_EnumPayload zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    unsigned char zT_58 = 0;
    zT_33EF6BFB_TypeKind zT_59;
    zT_AF9231A2_UnionPayload* zT_64;
    unsigned short zT_65;
    unsigned int zT_66;
    zT_AF9231A2_UnionPayload zT_67;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned short zT_70;
    unsigned char zT_76 = 0;
    zT_33EF6BFB_TypeKind zT_77;
    zT_AF9231A2_UnionPayload* zT_82;
    unsigned short zT_83;
    unsigned int zT_84;
    zT_AF9231A2_UnionPayload zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    unsigned short zT_88;
    unsigned char zT_94 = 0;
    zT_33EF6BFB_TypeKind zT_95;
    zT_54FF90FA_TaggedUnionPayload* zT_100;
    unsigned short zT_101;
    unsigned int zT_102;
    zT_54FF90FA_TaggedUnionPayload zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    unsigned char zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned short zT_113;
    unsigned char zT_119 = 0;
    zT_33EF6BFB_TypeKind zT_120;
    zT_E834303C_ArrayPayload* zT_125;
    unsigned short zT_126;
    unsigned int zT_127;
    zT_E834303C_ArrayPayload zT_128;
    zT_338B7C76_TypeRegistry* zT_129;
    unsigned int zT_130;
    unsigned char zT_135 = 0;
    zT_33EF6BFB_TypeKind zT_136;
    zT_666DC2E1_TuplePayload* zT_141;
    unsigned short zT_142;
    unsigned int zT_143;
    zT_666DC2E1_TuplePayload zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned short zT_148;
    zT_338B7C76_TypeRegistry* zT_151;
    unsigned int zT_152;
    unsigned int* zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned char zT_161 = 0;
    unsigned char zT_163;
    int zT_164;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    zT_0B10E8E9_OptionalPayload* zT_172;
    unsigned short zT_173;
    unsigned int zT_174;
    zT_0B10E8E9_OptionalPayload zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    unsigned int zT_177;
    unsigned char zT_182 = 0;
    zT_33EF6BFB_TypeKind zT_183;
    zT_42C2D6BF_EUPayload* zT_188;
    unsigned short zT_189;
    unsigned int zT_190;
    zT_42C2D6BF_EUPayload zT_191;
    zT_338B7C76_TypeRegistry* zT_192;
    unsigned int zT_193;
    unsigned char zT_198 = 0;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_204;
    unsigned int zT_205;
    zT_D155D06D_Type* zT_207;
    zT_D155D06D_Type* zT_209;
    zT_D155D06D_Type ty;
    unsigned char deps_ok;
    unsigned char handled;
    zT_406493CE_StructPayload sp;
    zT_457ECFEE_EnumPayload ep;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_E834303C_ArrayPayload ap;
    zT_666DC2E1_TuplePayload tup;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload op;
    zT_42C2D6BF_EUPayload eup;
    if ((unsigned char)(tid == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = registry->types_items;
    zT_12 = (unsigned int)tid;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.state;
    if ((unsigned char)(zT_14 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_22 = 1;
    deps_ok = zT_22;
    zT_24 = 1;
    handled = zT_24;
    zT_25 = ty.kind;
    if ((unsigned char)(zT_25 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_30 = registry->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = registry;
    zT_35 = sp.fields_start;
    zT_36 = sp.fields_count;
    zT_42 = zF_B32C0425_layoutFieldDepsOk(zT_34, zT_35, zT_36, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_42;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(!handled)) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_43 = ty.kind;
    if ((unsigned char)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_48 = registry->en_items;
    zT_49 = ty.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    ep = zT_51;
    zT_52 = registry;
    zT_53 = ep.backing_type;
    zT_58 = zF_BEEAF73E_layoutDepOk(zT_52, zT_53, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_58;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_59 = ty.kind;
    if ((unsigned char)(zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_64 = registry->un_items;
    zT_65 = ty.payload_idx;
    zT_66 = (unsigned int)zT_65;
    zT_67 = zT_64[zT_66];
    up = zT_67;
    zT_68 = registry;
    zT_69 = up.fields_start;
    zT_70 = up.fields_count;
    zT_76 = zF_B32C0425_layoutFieldDepsOk(zT_68, zT_69, zT_70, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_76;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_82 = registry->un_items;
    zT_83 = ty.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    pup = zT_85;
    zT_86 = registry;
    zT_87 = pup.fields_start;
    zT_88 = pup.fields_count;
    zT_94 = zF_B32C0425_layoutFieldDepsOk(zT_86, zT_87, zT_88, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_94;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_95 = ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_100 = registry->tu_items;
    zT_101 = ty.payload_idx;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    tp = zT_103;
    zT_104 = registry;
    zT_105 = tp.tag_type;
    zT_110 = zF_BEEAF73E_layoutDepOk(zT_104, zT_105, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_110;
    if (deps_ok) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_120 = ty.kind;
    if ((unsigned char)(zT_120 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_111 = registry;
    zT_112 = tp.fields_start;
    zT_113 = tp.fields_count;
    zT_119 = zF_B32C0425_layoutFieldDepsOk(zT_111, zT_112, zT_113, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_119;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_125 = registry->array_items;
    zT_126 = ty.payload_idx;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zT_125[zT_127];
    ap = zT_128;
    zT_129 = registry;
    zT_130 = ap.elem;
    zT_135 = zF_BEEAF73E_layoutDepOk(zT_129, zT_130, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_135;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    zT_136 = ty.kind;
    if ((unsigned char)(zT_136 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_141 = registry->tup_items;
    zT_142 = ty.payload_idx;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    tup = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    ei = zT_147;
    goto z_bb_32;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_167 = ty.kind;
    if ((unsigned char)(zT_167 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_40;
    z_bb_32:
    zT_148 = tup.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_148))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_151 = registry;
    zT_154 = registry->xt_items;
    zT_155 = tup.elems_start;
    zT_157 = (unsigned int)((unsigned int)zT_155) + ei;
    zT_152 = zT_154[zT_157];
    zT_161 = zF_BEEAF73E_layoutDepOk(zT_151, zT_152, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_161)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_164 = 1;
    zT_166 = ei + (unsigned int)((unsigned int)zT_164);
    ei = zT_166;
    goto z_bb_32;
    z_bb_36:
    zT_163 = 0;
    deps_ok = zT_163;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    zT_172 = registry->opt_items;
    zT_173 = ty.payload_idx;
    zT_174 = (unsigned int)zT_173;
    zT_175 = zT_172[zT_174];
    op = zT_175;
    zT_176 = registry;
    zT_177 = op.payload;
    zT_182 = zF_BEEAF73E_layoutDepOk(zT_176, zT_177, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_182;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_30;
    z_bb_40:
    zT_183 = ty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_188 = registry->eu_items;
    zT_189 = ty.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    eup = zT_191;
    zT_192 = registry;
    zT_193 = eup.payload;
    zT_198 = zF_BEEAF73E_layoutDepOk(zT_192, zT_193, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_198;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_199 = 0;
    handled = zT_199;
    goto z_bb_42;
    z_bb_44:
    return (unsigned char)(0);
    z_bb_45:
    if ((unsigned char)(!deps_ok)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return (unsigned char)(0);
    z_bb_47:
    zT_204 = registry;
    zT_205 = tid;
    zF_0E9E97D8_layoutCompute(zT_204, zT_205);
    zT_207 = registry->types_items;
    zT_209 = zT_207 + (unsigned int)((unsigned int)tid);
    zT_209->state = (unsigned char)(2);
    return (unsigned char)(1);
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned char zT_7 = 0;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    zT_2 = self->registry;
    zT_3 = tid;
    zT_7 = zF_3E55D0D5_layoutEnsure(zT_2, zT_3, (unsigned int)(0));
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->registry;
    zT_10 = tid;
    zF_0E9E97D8_layoutCompute(zT_9, zT_10);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    zT_FF4D4E6C_EU_242 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_18 = i + (unsigned int)((unsigned int)zT_16);
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_25 = self->alloc;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(type_count * (unsigned int)(4)), (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_34 = zT_32.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_45 = zi + (unsigned int)((unsigned int)zT_43);
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    if ((unsigned char)(ei < zT_49)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    if ((unsigned char)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_62 = zT_59 + (unsigned int)((unsigned int)zT_60);
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_67 = ei + (unsigned int)((unsigned int)zT_65);
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    unsigned char zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    int zT_119;
    unsigned char zT_121 = 0;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_D155D06D_Type* zT_124;
    int zT_125;
    unsigned int zT_127;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((unsigned char)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((unsigned char)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_19 = ti + (unsigned int)((unsigned int)zT_17);
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    if ((unsigned char)(zT_20 > (unsigned int)zT_21)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    self->sorted_len = (unsigned int)(zT_30 + (unsigned int)(1));
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_39 = zT_37 + (unsigned int)((unsigned int)tid);
    zT_39->state = (unsigned char)(2);
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    if ((unsigned char)(ei < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    if ((unsigned char)(zT_47 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    if ((unsigned char)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_74 = ei + (unsigned int)((unsigned int)zT_72);
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    if ((unsigned char)(zT_57 > (unsigned int)zT_58)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_64 = zT_61 - (unsigned int)((unsigned int)zT_62);
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    if ((unsigned char)(zT_67 == (unsigned int)zT_68)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((unsigned char)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    zT_83 = ty.state;
    if ((unsigned char)(zT_83 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_125 = 1;
    zT_127 = ci + (unsigned int)((unsigned int)zT_125);
    ci = zT_127;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_86 = zT_88 > (unsigned int)zT_89;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = self->diag;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_101);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    zT_116 = "alignment";
    zT_118 = 9;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    zT_114 = zT_117;
    zT_119 = 1;
    zT_121 = zF_BBDF00B7_typeNarrowU8(zT_114, (unsigned int)((unsigned int)zT_119));
    ty.alignment = zT_121;
    ty.state = (unsigned char)(2);
    zT_123 = self->registry;
    zT_124 = zT_123->types_items;
    zT_124[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* kindIsAggregateCore */
unsigned char zF_95CB1909_kindIsAggregateCore(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    return zT_20;
}

/* fieldEmbedsByValue */
unsigned char zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_7;
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* requiresFullDef */
unsigned char zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_7;
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* layoutFieldNeedsEdge */
unsigned char zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_7;
    unsigned char zT_11;
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_11 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_11 = 1;
    goto z_bb_9;
    z_bb_9:
    return zT_11;
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    unsigned char zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    if ((unsigned char)(field_type >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    zT_12 = ft.kind;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    int zT_18;
    unsigned int zT_20;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_15 = (unsigned int)((unsigned int)fstart) + fi;
    zT_16 = zT_13[zT_15];
    zT_10 = zT_16.type_id;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_20 = fi + (unsigned int)((unsigned int)zT_18);
    fi = zT_20;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_406493CE_StructPayload* zT_19;
    unsigned short zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    zT_C890C8CB_TypeResolver* zT_23;
    unsigned int zT_24;
    unsigned short zT_25;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_29;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_54FF90FA_TaggedUnionPayload* zT_35;
    unsigned short zT_36;
    unsigned int zT_37;
    zT_54FF90FA_TaggedUnionPayload zT_38;
    zT_C890C8CB_TypeResolver* zT_39;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_42;
    zT_33EF6BFB_TypeKind zT_45;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_AF9231A2_UnionPayload* zT_51;
    unsigned short zT_52;
    unsigned int zT_53;
    zT_AF9231A2_UnionPayload zT_54;
    zT_C890C8CB_TypeResolver* zT_55;
    unsigned int zT_56;
    unsigned short zT_57;
    unsigned int zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_AF9231A2_UnionPayload* zT_67;
    unsigned short zT_68;
    unsigned int zT_69;
    zT_AF9231A2_UnionPayload zT_70;
    zT_C890C8CB_TypeResolver* zT_71;
    unsigned int zT_72;
    unsigned short zT_73;
    unsigned int zT_74;
    zT_33EF6BFB_TypeKind zT_77;
    zT_C890C8CB_TypeResolver* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_E834303C_ArrayPayload* zT_85;
    unsigned short zT_86;
    unsigned int zT_87;
    zT_E834303C_ArrayPayload zT_88;
    zT_33EF6BFB_TypeKind zT_90;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_666DC2E1_TuplePayload* zT_96;
    unsigned short zT_97;
    unsigned int zT_98;
    zT_666DC2E1_TuplePayload zT_99;
    int zT_101;
    unsigned int zT_102;
    unsigned short zT_103;
    zT_C890C8CB_TypeResolver* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int* zT_110;
    unsigned int zT_111;
    unsigned int zT_113;
    int zT_115;
    unsigned int zT_117;
    zT_33EF6BFB_TypeKind zT_118;
    zT_C890C8CB_TypeResolver* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_338B7C76_TypeRegistry* zT_125;
    zT_0B10E8E9_OptionalPayload* zT_126;
    unsigned short zT_127;
    unsigned int zT_128;
    zT_0B10E8E9_OptionalPayload zT_129;
    zT_33EF6BFB_TypeKind zT_131;
    zT_C890C8CB_TypeResolver* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_42C2D6BF_EUPayload* zT_139;
    unsigned short zT_140;
    unsigned int zT_141;
    zT_42C2D6BF_EUPayload zT_142;
    int zT_144;
    unsigned int zT_146;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    zT_13 = ty.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_144 = 1;
    zT_146 = ti + (unsigned int)((unsigned int)zT_144);
    ti = zT_146;
    goto z_bb_1;
    z_bb_5:
    zT_18 = self->registry;
    zT_19 = zT_18->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_23 = self;
    zT_24 = sp.fields_start;
    zT_25 = sp.fields_count;
    zT_26 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_23, zT_24, zT_25, zT_26);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_29 = ty.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_34 = self->registry;
    zT_35 = zT_34->tu_items;
    zT_36 = ty.payload_idx;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zT_35[zT_37];
    tp = zT_38;
    zT_39 = self;
    zT_40 = tp.fields_start;
    zT_41 = tp.fields_count;
    zT_42 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_39, zT_40, zT_41, zT_42);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_45 = ty.kind;
    if ((unsigned char)(zT_45 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_50 = self->registry;
    zT_51 = zT_50->un_items;
    zT_52 = ty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    up = zT_54;
    zT_55 = self;
    zT_56 = up.fields_start;
    zT_57 = up.fields_count;
    zT_58 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_55, zT_56, zT_57, zT_58);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_61 = ty.kind;
    if ((unsigned char)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_66 = self->registry;
    zT_67 = zT_66->un_items;
    zT_68 = ty.payload_idx;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zT_67[zT_69];
    pup = zT_70;
    zT_71 = self;
    zT_72 = pup.fields_start;
    zT_73 = pup.fields_count;
    zT_74 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_71, zT_72, zT_73, zT_74);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_81 = self;
    zT_84 = self->registry;
    zT_85 = zT_84->array_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    zT_82 = zT_88.elem;
    zT_83 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_81, zT_82, zT_83);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_90 = ty.kind;
    if ((unsigned char)(zT_90 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_95 = self->registry;
    zT_96 = zT_95->tup_items;
    zT_97 = ty.payload_idx;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    tp_1 = zT_99;
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    ei = zT_102;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_118 = ty.kind;
    if ((unsigned char)(zT_118 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_27; else goto z_bb_29;
    z_bb_23:
    zT_103 = tp_1.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_103))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_106 = self;
    zT_109 = self->registry;
    zT_110 = zT_109->xt_items;
    zT_111 = tp_1.elems_start;
    zT_113 = (unsigned int)((unsigned int)zT_111) + ei;
    zT_107 = zT_110[zT_113];
    zT_108 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_106, zT_107, zT_108);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_21;
    z_bb_26:
    zT_115 = 1;
    zT_117 = ei + (unsigned int)((unsigned int)zT_115);
    ei = zT_117;
    goto z_bb_23;
    z_bb_27:
    zT_122 = self;
    zT_125 = self->registry;
    zT_126 = zT_125->opt_items;
    zT_127 = ty.payload_idx;
    zT_128 = (unsigned int)zT_127;
    zT_129 = zT_126[zT_128];
    zT_123 = zT_129.payload;
    zT_124 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_122, zT_123, zT_124);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_131 = ty.kind;
    if ((unsigned char)(zT_131 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_135 = self;
    zT_138 = self->registry;
    zT_139 = zT_138->eu_items;
    zT_140 = ty.payload_idx;
    zT_141 = (unsigned int)zT_140;
    zT_142 = zT_139[zT_141];
    zT_136 = zT_142.payload;
    zT_137 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_135, zT_136, zT_137);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_28;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    int zT_9;
    int zT_11;
    zT_FF4D4E6C_EU_242 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    int zT_26;
    int zT_28;
    zT_FF4D4E6C_EU_242 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    int zT_40;
    int zT_42;
    zT_FF4D4E6C_EU_242 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    int zT_54;
    int zT_56;
    zT_FF4D4E6C_EU_242 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_71;
    unsigned int zT_73;
    zT_3E40CD83_Sand* zT_75;
    int zT_78;
    int zT_80;
    zT_FF4D4E6C_EU_242 zT_82 = {0};
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int* zT_87;
    unsigned int zT_89;
    unsigned int zT_91;
    int zT_93;
    unsigned int zT_94;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type* zT_98;
    zT_D155D06D_Type zT_99;
    unsigned char zT_101;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_406493CE_StructPayload* zT_108;
    unsigned short zT_109;
    unsigned int zT_110;
    zT_406493CE_StructPayload zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned short zT_115;
    unsigned char zT_118;
    int zT_119;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_2DF01B61_FieldEntry* zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    zT_2DF01B61_FieldEntry zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    unsigned char zT_136 = 0;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_3E40CD83_Sand* zT_142;
    unsigned int** zT_143;
    unsigned int** zT_144;
    unsigned int* zT_145;
    unsigned int zT_146;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    zT_33EF6BFB_TypeKind zT_158;
    zT_3E40CD83_Sand* zT_162;
    unsigned int** zT_163;
    unsigned int** zT_164;
    unsigned int* zT_165;
    unsigned int zT_166;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_177;
    int zT_178;
    unsigned int zT_180;
    zT_33EF6BFB_TypeKind zT_181;
    zT_338B7C76_TypeRegistry* zT_186;
    zT_54FF90FA_TaggedUnionPayload* zT_187;
    unsigned short zT_188;
    unsigned int zT_189;
    zT_54FF90FA_TaggedUnionPayload zT_190;
    int zT_192;
    unsigned int zT_193;
    unsigned short zT_194;
    unsigned char zT_197;
    int zT_198;
    zT_338B7C76_TypeRegistry* zT_201;
    zT_2DF01B61_FieldEntry* zT_202;
    unsigned int zT_203;
    unsigned int zT_205;
    zT_2DF01B61_FieldEntry zT_206;
    unsigned int zT_207;
    zT_338B7C76_TypeRegistry* zT_209;
    zT_D155D06D_Type* zT_210;
    unsigned int zT_211;
    zT_D155D06D_Type zT_212;
    zT_33EF6BFB_TypeKind zT_213;
    unsigned char zT_215 = 0;
    unsigned char zT_216;
    zT_33EF6BFB_TypeKind zT_217;
    zT_3E40CD83_Sand* zT_221;
    unsigned int** zT_222;
    unsigned int** zT_223;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_236;
    zT_33EF6BFB_TypeKind zT_237;
    zT_3E40CD83_Sand* zT_241;
    unsigned int** zT_242;
    unsigned int** zT_243;
    unsigned int* zT_244;
    unsigned int zT_245;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    int zT_257;
    unsigned int zT_259;
    zT_33EF6BFB_TypeKind zT_260;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_AF9231A2_UnionPayload* zT_266;
    unsigned short zT_267;
    unsigned int zT_268;
    zT_AF9231A2_UnionPayload zT_269;
    int zT_271;
    unsigned int zT_272;
    unsigned short zT_273;
    unsigned char zT_276;
    int zT_277;
    zT_338B7C76_TypeRegistry* zT_280;
    zT_2DF01B61_FieldEntry* zT_281;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_2DF01B61_FieldEntry zT_285;
    unsigned int zT_286;
    zT_338B7C76_TypeRegistry* zT_288;
    zT_D155D06D_Type* zT_289;
    unsigned int zT_290;
    zT_D155D06D_Type zT_291;
    zT_33EF6BFB_TypeKind zT_292;
    unsigned char zT_294 = 0;
    unsigned char zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_3E40CD83_Sand* zT_300;
    unsigned int** zT_301;
    unsigned int** zT_302;
    unsigned int* zT_303;
    unsigned int zT_304;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    unsigned int zT_315;
    zT_33EF6BFB_TypeKind zT_316;
    zT_3E40CD83_Sand* zT_320;
    unsigned int** zT_321;
    unsigned int** zT_322;
    unsigned int* zT_323;
    unsigned int zT_324;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_335;
    int zT_336;
    unsigned int zT_338;
    zT_33EF6BFB_TypeKind zT_339;
    zT_338B7C76_TypeRegistry* zT_344;
    zT_AF9231A2_UnionPayload* zT_345;
    unsigned short zT_346;
    unsigned int zT_347;
    zT_AF9231A2_UnionPayload zT_348;
    int zT_350;
    unsigned int zT_351;
    unsigned short zT_352;
    unsigned char zT_355;
    int zT_356;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_2DF01B61_FieldEntry* zT_360;
    unsigned int zT_361;
    unsigned int zT_363;
    zT_2DF01B61_FieldEntry zT_364;
    unsigned int zT_365;
    zT_338B7C76_TypeRegistry* zT_367;
    zT_D155D06D_Type* zT_368;
    unsigned int zT_369;
    zT_D155D06D_Type zT_370;
    zT_33EF6BFB_TypeKind zT_371;
    unsigned char zT_373 = 0;
    unsigned char zT_374;
    zT_33EF6BFB_TypeKind zT_375;
    zT_3E40CD83_Sand* zT_379;
    unsigned int** zT_380;
    unsigned int** zT_381;
    unsigned int* zT_382;
    unsigned int zT_383;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    unsigned int zT_394;
    zT_33EF6BFB_TypeKind zT_395;
    zT_3E40CD83_Sand* zT_399;
    unsigned int** zT_400;
    unsigned int** zT_401;
    unsigned int* zT_402;
    unsigned int zT_403;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_414;
    int zT_415;
    unsigned int zT_417;
    zT_33EF6BFB_TypeKind zT_418;
    zT_338B7C76_TypeRegistry* zT_423;
    zT_E834303C_ArrayPayload* zT_424;
    unsigned short zT_425;
    unsigned int zT_426;
    zT_E834303C_ArrayPayload zT_427;
    unsigned int zT_428;
    zT_338B7C76_TypeRegistry* zT_430;
    zT_D155D06D_Type* zT_431;
    unsigned int zT_432;
    zT_D155D06D_Type zT_433;
    zT_33EF6BFB_TypeKind zT_434;
    unsigned char zT_436 = 0;
    unsigned char zT_437;
    zT_33EF6BFB_TypeKind zT_438;
    zT_3E40CD83_Sand* zT_442;
    unsigned int** zT_443;
    unsigned int** zT_444;
    unsigned int* zT_445;
    unsigned int zT_446;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    unsigned int zT_457;
    zT_33EF6BFB_TypeKind zT_458;
    zT_3E40CD83_Sand* zT_462;
    unsigned int** zT_463;
    unsigned int** zT_464;
    unsigned int* zT_465;
    unsigned int zT_466;
    unsigned int zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_477;
    zT_33EF6BFB_TypeKind zT_478;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_42C2D6BF_EUPayload* zT_484;
    unsigned short zT_485;
    unsigned int zT_486;
    zT_42C2D6BF_EUPayload zT_487;
    unsigned int zT_488;
    zT_338B7C76_TypeRegistry* zT_490;
    zT_D155D06D_Type* zT_491;
    unsigned int zT_492;
    zT_D155D06D_Type zT_493;
    zT_33EF6BFB_TypeKind zT_494;
    unsigned char zT_496 = 0;
    unsigned char zT_497;
    zT_33EF6BFB_TypeKind zT_498;
    zT_3E40CD83_Sand* zT_502;
    unsigned int** zT_503;
    unsigned int** zT_504;
    unsigned int* zT_505;
    unsigned int zT_506;
    unsigned int zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned int zT_517;
    zT_33EF6BFB_TypeKind zT_518;
    zT_3E40CD83_Sand* zT_522;
    unsigned int** zT_523;
    unsigned int** zT_524;
    unsigned int* zT_525;
    unsigned int zT_526;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    unsigned int zT_535;
    unsigned int zT_537;
    zT_33EF6BFB_TypeKind zT_538;
    zT_338B7C76_TypeRegistry* zT_543;
    zT_0B10E8E9_OptionalPayload* zT_544;
    unsigned short zT_545;
    unsigned int zT_546;
    zT_0B10E8E9_OptionalPayload zT_547;
    unsigned int zT_548;
    zT_338B7C76_TypeRegistry* zT_550;
    zT_D155D06D_Type* zT_551;
    unsigned int zT_552;
    zT_D155D06D_Type zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    unsigned char zT_556 = 0;
    unsigned char zT_557;
    zT_33EF6BFB_TypeKind zT_558;
    zT_3E40CD83_Sand* zT_562;
    unsigned int** zT_563;
    unsigned int** zT_564;
    unsigned int* zT_565;
    unsigned int zT_566;
    unsigned int zT_570;
    unsigned int zT_571;
    unsigned int zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_577;
    zT_33EF6BFB_TypeKind zT_578;
    zT_3E40CD83_Sand* zT_582;
    unsigned int** zT_583;
    unsigned int** zT_584;
    unsigned int* zT_585;
    unsigned int zT_586;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned int zT_597;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned int zT_603;
    int zT_604;
    unsigned int zT_606;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_612;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned char zT_622;
    unsigned char zT_625;
    unsigned int zT_626;
    unsigned int zT_627;
    unsigned int zT_629;
    unsigned int zT_630;
    unsigned int zT_631;
    zT_3E40CD83_Sand* zT_633;
    int zT_636;
    int zT_638;
    zT_FF4D4E6C_EU_242 zT_640 = {0};
    unsigned char zT_641;
    unsigned char* zT_642;
    unsigned int* zT_645;
    unsigned int zT_647;
    int zT_648;
    unsigned int zT_649;
    unsigned char zT_651;
    unsigned int zT_654;
    unsigned int zT_655;
    unsigned int zT_657;
    int zT_658;
    unsigned int zT_660;
    unsigned char* zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    unsigned int zT_664;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_665;
    unsigned int zT_666;
    unsigned char* zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_671;
    int zT_672;
    unsigned int zT_673;
    unsigned char zT_675;
    unsigned char* zT_679;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_680;
    unsigned int zT_681;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_682;
    unsigned char* zT_684;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_685;
    unsigned int zT_686;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_687;
    unsigned char* zT_691;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_692;
    unsigned int zT_693;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_694;
    zT_338B7C76_TypeRegistry* zT_696;
    zT_D155D06D_Type* zT_697;
    zT_D155D06D_Type zT_698;
    zT_33EF6BFB_TypeKind zT_699;
    unsigned char* zT_702;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_703;
    unsigned int zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    int zT_706;
    unsigned int zT_708;
    zT_010C8DF0_ClassificationResul zT_709;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_11 = 1;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(zT_9 * tl), (unsigned int)((unsigned int)zT_11));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_28 = 4;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)(zT_26 * wp_edge_cap), (unsigned int)((unsigned int)zT_28));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_42 = 4;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)(zT_40 * wp_edge_cap), (unsigned int)((unsigned int)zT_42));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_46 = zT_44.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_56 = 4;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, (unsigned int)(zT_54 * tl), (unsigned int)((unsigned int)zT_56));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_60 = zT_58.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_73 = 0;
    wp_count = zT_73;
    zT_75 = perm_alloc;
    zT_78 = 4;
    zT_80 = 4;
    zT_82 = zF_1395EB68_sandAlloc(zT_75, (unsigned int)(zT_78 * tl), (unsigned int)((unsigned int)zT_80));
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_71 = whi + (unsigned int)((unsigned int)zT_69);
    whi = zT_71;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_84 = zT_82.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_84;
    zT_87 = (unsigned int*)wl_raw;
    worklist = zT_87;
    zT_89 = 0;
    wl_head = zT_89;
    zT_91 = 0;
    wl_tail = zT_91;
    zT_93 = 0;
    zT_94 = (unsigned int)zT_93;
    ti = zT_94;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_97 = self->registry;
    zT_98 = zT_97->types_items;
    zT_99 = zT_98[ti];
    ty = zT_99;
    zT_101 = 1;
    is_po = zT_101;
    zT_102 = ty.kind;
    if ((unsigned char)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_604 = 1;
    zT_606 = ti + (unsigned int)((unsigned int)zT_604);
    ti = zT_606;
    goto z_bb_20;
    z_bb_24:
    zT_107 = self->registry;
    zT_108 = zT_107->st_items;
    zT_109 = ty.payload_idx;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zT_108[zT_110];
    sp = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fi = zT_114;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((unsigned char)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_181 = ty.kind;
    if ((unsigned char)(zT_181 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_115 = sp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_115))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_122 = self->registry;
    zT_123 = zT_122->fe_items;
    zT_124 = sp.fields_start;
    zT_126 = (unsigned int)((unsigned int)zT_124) + fi;
    zT_127 = zT_123[zT_126];
    zT_128 = zT_127.type_id;
    ft_id = zT_128;
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)ft_id;
    zT_133 = zT_131[zT_132];
    ft = zT_133;
    zT_134 = ft.kind;
    zT_136 = zF_A47239A9_fieldEmbedsByValue(zT_134);
    if (zT_136) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_178 = 1;
    zT_180 = fi + (unsigned int)((unsigned int)zT_178);
    fi = zT_180;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 0;
    zT_118 = is_po != zT_119;
    goto z_bb_33;
    z_bb_32:
    zT_118 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_118) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_137 = 0;
    is_po = zT_137;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_138 = ft.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_142 = perm_alloc;
    zT_143 = &wp_to;
    zT_144 = &wp_next;
    zT_145 = &wp_edge_cap;
    zT_146 = wp_count;
    zF_25C377BD_growWpEdges(zT_142, zT_143, zT_144, zT_145, zT_146);
    zT_150 = (unsigned int)ti;
    zT_151 = (unsigned int)wp_count;
    wp_to[zT_151] = zT_150;
    zT_152 = (unsigned int)ft_id;
    zT_153 = wp_head[zT_152];
    zT_154 = (unsigned int)wp_count;
    wp_next[zT_154] = zT_153;
    zT_155 = (unsigned int)ft_id;
    wp_head[zT_155] = wp_count;
    zT_157 = wp_count + (unsigned int)(1);
    wp_count = zT_157;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_158 = ft.kind;
    if ((unsigned char)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_162 = perm_alloc;
    zT_163 = &wp_to;
    zT_164 = &wp_next;
    zT_165 = &wp_edge_cap;
    zT_166 = wp_count;
    zF_25C377BD_growWpEdges(zT_162, zT_163, zT_164, zT_165, zT_166);
    zT_170 = (unsigned int)ti;
    zT_171 = (unsigned int)wp_count;
    wp_to[zT_171] = zT_170;
    zT_172 = (unsigned int)ft_id;
    zT_173 = wp_head[zT_172];
    zT_174 = (unsigned int)wp_count;
    wp_next[zT_174] = zT_173;
    zT_175 = (unsigned int)ft_id;
    wp_head[zT_175] = wp_count;
    zT_177 = wp_count + (unsigned int)(1);
    wp_count = zT_177;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_186 = self->registry;
    zT_187 = zT_186->tu_items;
    zT_188 = ty.payload_idx;
    zT_189 = (unsigned int)zT_188;
    zT_190 = zT_187[zT_189];
    tp = zT_190;
    zT_192 = 0;
    zT_193 = (unsigned int)zT_192;
    fi = zT_193;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_260 = ty.kind;
    if ((unsigned char)(zT_260 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_194 = tp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_194))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_201 = self->registry;
    zT_202 = zT_201->fe_items;
    zT_203 = tp.fields_start;
    zT_205 = (unsigned int)((unsigned int)zT_203) + fi;
    zT_206 = zT_202[zT_205];
    zT_207 = zT_206.type_id;
    ft_id = zT_207;
    zT_209 = self->registry;
    zT_210 = zT_209->types_items;
    zT_211 = (unsigned int)ft_id;
    zT_212 = zT_210[zT_211];
    ft = zT_212;
    zT_213 = ft.kind;
    zT_215 = zF_A47239A9_fieldEmbedsByValue(zT_213);
    if (zT_215) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_257 = 1;
    zT_259 = fi + (unsigned int)((unsigned int)zT_257);
    fi = zT_259;
    goto z_bb_45;
    z_bb_49:
    zT_198 = 0;
    zT_197 = is_po != zT_198;
    goto z_bb_51;
    z_bb_50:
    zT_197 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_197) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_216 = 0;
    is_po = zT_216;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_217 = ft.kind;
    if ((unsigned char)(zT_217 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_221 = perm_alloc;
    zT_222 = &wp_to;
    zT_223 = &wp_next;
    zT_224 = &wp_edge_cap;
    zT_225 = wp_count;
    zF_25C377BD_growWpEdges(zT_221, zT_222, zT_223, zT_224, zT_225);
    zT_229 = (unsigned int)ti;
    zT_230 = (unsigned int)wp_count;
    wp_to[zT_230] = zT_229;
    zT_231 = (unsigned int)ft_id;
    zT_232 = wp_head[zT_231];
    zT_233 = (unsigned int)wp_count;
    wp_next[zT_233] = zT_232;
    zT_234 = (unsigned int)ft_id;
    wp_head[zT_234] = wp_count;
    zT_236 = wp_count + (unsigned int)(1);
    wp_count = zT_236;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_237 = ft.kind;
    if ((unsigned char)(zT_237 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_241 = perm_alloc;
    zT_242 = &wp_to;
    zT_243 = &wp_next;
    zT_244 = &wp_edge_cap;
    zT_245 = wp_count;
    zF_25C377BD_growWpEdges(zT_241, zT_242, zT_243, zT_244, zT_245);
    zT_249 = (unsigned int)ti;
    zT_250 = (unsigned int)wp_count;
    wp_to[zT_250] = zT_249;
    zT_251 = (unsigned int)ft_id;
    zT_252 = wp_head[zT_251];
    zT_253 = (unsigned int)wp_count;
    wp_next[zT_253] = zT_252;
    zT_254 = (unsigned int)ft_id;
    wp_head[zT_254] = wp_count;
    zT_256 = wp_count + (unsigned int)(1);
    wp_count = zT_256;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_265 = self->registry;
    zT_266 = zT_265->un_items;
    zT_267 = ty.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    up = zT_269;
    zT_271 = 0;
    zT_272 = (unsigned int)zT_271;
    fi = zT_272;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_339 = ty.kind;
    if ((unsigned char)(zT_339 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_273 = up.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_273))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_280 = self->registry;
    zT_281 = zT_280->fe_items;
    zT_282 = up.fields_start;
    zT_284 = (unsigned int)((unsigned int)zT_282) + fi;
    zT_285 = zT_281[zT_284];
    zT_286 = zT_285.type_id;
    ft_id = zT_286;
    zT_288 = self->registry;
    zT_289 = zT_288->types_items;
    zT_290 = (unsigned int)ft_id;
    zT_291 = zT_289[zT_290];
    ft = zT_291;
    zT_292 = ft.kind;
    zT_294 = zF_A47239A9_fieldEmbedsByValue(zT_292);
    if (zT_294) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_336 = 1;
    zT_338 = fi + (unsigned int)((unsigned int)zT_336);
    fi = zT_338;
    goto z_bb_63;
    z_bb_67:
    zT_277 = 0;
    zT_276 = is_po != zT_277;
    goto z_bb_69;
    z_bb_68:
    zT_276 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_276) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_295 = 0;
    is_po = zT_295;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_296 = ft.kind;
    if ((unsigned char)(zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_300 = perm_alloc;
    zT_301 = &wp_to;
    zT_302 = &wp_next;
    zT_303 = &wp_edge_cap;
    zT_304 = wp_count;
    zF_25C377BD_growWpEdges(zT_300, zT_301, zT_302, zT_303, zT_304);
    zT_308 = (unsigned int)ti;
    zT_309 = (unsigned int)wp_count;
    wp_to[zT_309] = zT_308;
    zT_310 = (unsigned int)ft_id;
    zT_311 = wp_head[zT_310];
    zT_312 = (unsigned int)wp_count;
    wp_next[zT_312] = zT_311;
    zT_313 = (unsigned int)ft_id;
    wp_head[zT_313] = wp_count;
    zT_315 = wp_count + (unsigned int)(1);
    wp_count = zT_315;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_316 = ft.kind;
    if ((unsigned char)(zT_316 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_320 = perm_alloc;
    zT_321 = &wp_to;
    zT_322 = &wp_next;
    zT_323 = &wp_edge_cap;
    zT_324 = wp_count;
    zF_25C377BD_growWpEdges(zT_320, zT_321, zT_322, zT_323, zT_324);
    zT_328 = (unsigned int)ti;
    zT_329 = (unsigned int)wp_count;
    wp_to[zT_329] = zT_328;
    zT_330 = (unsigned int)ft_id;
    zT_331 = wp_head[zT_330];
    zT_332 = (unsigned int)wp_count;
    wp_next[zT_332] = zT_331;
    zT_333 = (unsigned int)ft_id;
    wp_head[zT_333] = wp_count;
    zT_335 = wp_count + (unsigned int)(1);
    wp_count = zT_335;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_344 = self->registry;
    zT_345 = zT_344->un_items;
    zT_346 = ty.payload_idx;
    zT_347 = (unsigned int)zT_346;
    zT_348 = zT_345[zT_347];
    p_up = zT_348;
    zT_350 = 0;
    zT_351 = (unsigned int)zT_350;
    pfi = zT_351;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_418 = ty.kind;
    if ((unsigned char)(zT_418 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_352 = p_up.fields_count;
    if ((unsigned char)(pfi < (unsigned int)((unsigned int)zT_352))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_359 = self->registry;
    zT_360 = zT_359->fe_items;
    zT_361 = p_up.fields_start;
    zT_363 = (unsigned int)((unsigned int)zT_361) + pfi;
    zT_364 = zT_360[zT_363];
    zT_365 = zT_364.type_id;
    ft_id = zT_365;
    zT_367 = self->registry;
    zT_368 = zT_367->types_items;
    zT_369 = (unsigned int)ft_id;
    zT_370 = zT_368[zT_369];
    ft = zT_370;
    zT_371 = ft.kind;
    zT_373 = zF_A47239A9_fieldEmbedsByValue(zT_371);
    if (zT_373) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_415 = 1;
    zT_417 = pfi + (unsigned int)((unsigned int)zT_415);
    pfi = zT_417;
    goto z_bb_81;
    z_bb_85:
    zT_356 = 0;
    zT_355 = is_po != zT_356;
    goto z_bb_87;
    z_bb_86:
    zT_355 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_355) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_374 = 0;
    is_po = zT_374;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_375 = ft.kind;
    if ((unsigned char)(zT_375 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_379 = perm_alloc;
    zT_380 = &wp_to;
    zT_381 = &wp_next;
    zT_382 = &wp_edge_cap;
    zT_383 = wp_count;
    zF_25C377BD_growWpEdges(zT_379, zT_380, zT_381, zT_382, zT_383);
    zT_387 = (unsigned int)ti;
    zT_388 = (unsigned int)wp_count;
    wp_to[zT_388] = zT_387;
    zT_389 = (unsigned int)ft_id;
    zT_390 = wp_head[zT_389];
    zT_391 = (unsigned int)wp_count;
    wp_next[zT_391] = zT_390;
    zT_392 = (unsigned int)ft_id;
    wp_head[zT_392] = wp_count;
    zT_394 = wp_count + (unsigned int)(1);
    wp_count = zT_394;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_395 = ft.kind;
    if ((unsigned char)(zT_395 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_399 = perm_alloc;
    zT_400 = &wp_to;
    zT_401 = &wp_next;
    zT_402 = &wp_edge_cap;
    zT_403 = wp_count;
    zF_25C377BD_growWpEdges(zT_399, zT_400, zT_401, zT_402, zT_403);
    zT_407 = (unsigned int)ti;
    zT_408 = (unsigned int)wp_count;
    wp_to[zT_408] = zT_407;
    zT_409 = (unsigned int)ft_id;
    zT_410 = wp_head[zT_409];
    zT_411 = (unsigned int)wp_count;
    wp_next[zT_411] = zT_410;
    zT_412 = (unsigned int)ft_id;
    wp_head[zT_412] = wp_count;
    zT_414 = wp_count + (unsigned int)(1);
    wp_count = zT_414;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_423 = self->registry;
    zT_424 = zT_423->array_items;
    zT_425 = ty.payload_idx;
    zT_426 = (unsigned int)zT_425;
    zT_427 = zT_424[zT_426];
    zT_428 = zT_427.elem;
    et = zT_428;
    zT_430 = self->registry;
    zT_431 = zT_430->types_items;
    zT_432 = (unsigned int)et;
    zT_433 = zT_431[zT_432];
    et_ty = zT_433;
    zT_434 = et_ty.kind;
    zT_436 = zF_A47239A9_fieldEmbedsByValue(zT_434);
    if (zT_436) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_478 = ty.kind;
    if ((unsigned char)(zT_478 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_437 = 0;
    is_po = zT_437;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_438 = et_ty.kind;
    if ((unsigned char)(zT_438 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_442 = perm_alloc;
    zT_443 = &wp_to;
    zT_444 = &wp_next;
    zT_445 = &wp_edge_cap;
    zT_446 = wp_count;
    zF_25C377BD_growWpEdges(zT_442, zT_443, zT_444, zT_445, zT_446);
    zT_450 = (unsigned int)ti;
    zT_451 = (unsigned int)wp_count;
    wp_to[zT_451] = zT_450;
    zT_452 = (unsigned int)et;
    zT_453 = wp_head[zT_452];
    zT_454 = (unsigned int)wp_count;
    wp_next[zT_454] = zT_453;
    zT_455 = (unsigned int)et;
    wp_head[zT_455] = wp_count;
    zT_457 = wp_count + (unsigned int)(1);
    wp_count = zT_457;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_458 = et_ty.kind;
    if ((unsigned char)(zT_458 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_462 = perm_alloc;
    zT_463 = &wp_to;
    zT_464 = &wp_next;
    zT_465 = &wp_edge_cap;
    zT_466 = wp_count;
    zF_25C377BD_growWpEdges(zT_462, zT_463, zT_464, zT_465, zT_466);
    zT_470 = (unsigned int)ti;
    zT_471 = (unsigned int)wp_count;
    wp_to[zT_471] = zT_470;
    zT_472 = (unsigned int)et;
    zT_473 = wp_head[zT_472];
    zT_474 = (unsigned int)wp_count;
    wp_next[zT_474] = zT_473;
    zT_475 = (unsigned int)et;
    wp_head[zT_475] = wp_count;
    zT_477 = wp_count + (unsigned int)(1);
    wp_count = zT_477;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_483 = self->registry;
    zT_484 = zT_483->eu_items;
    zT_485 = ty.payload_idx;
    zT_486 = (unsigned int)zT_485;
    zT_487 = zT_484[zT_486];
    zT_488 = zT_487.payload;
    eup = zT_488;
    zT_490 = self->registry;
    zT_491 = zT_490->types_items;
    zT_492 = (unsigned int)eup;
    zT_493 = zT_491[zT_492];
    eup_ty = zT_493;
    zT_494 = eup_ty.kind;
    zT_496 = zF_A47239A9_fieldEmbedsByValue(zT_494);
    if (zT_496) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_538 = ty.kind;
    if ((unsigned char)(zT_538 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_497 = 0;
    is_po = zT_497;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_498 = eup_ty.kind;
    if ((unsigned char)(zT_498 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_502 = perm_alloc;
    zT_503 = &wp_to;
    zT_504 = &wp_next;
    zT_505 = &wp_edge_cap;
    zT_506 = wp_count;
    zF_25C377BD_growWpEdges(zT_502, zT_503, zT_504, zT_505, zT_506);
    zT_510 = (unsigned int)ti;
    zT_511 = (unsigned int)wp_count;
    wp_to[zT_511] = zT_510;
    zT_512 = (unsigned int)eup;
    zT_513 = wp_head[zT_512];
    zT_514 = (unsigned int)wp_count;
    wp_next[zT_514] = zT_513;
    zT_515 = (unsigned int)eup;
    wp_head[zT_515] = wp_count;
    zT_517 = wp_count + (unsigned int)(1);
    wp_count = zT_517;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_518 = eup_ty.kind;
    if ((unsigned char)(zT_518 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_522 = perm_alloc;
    zT_523 = &wp_to;
    zT_524 = &wp_next;
    zT_525 = &wp_edge_cap;
    zT_526 = wp_count;
    zF_25C377BD_growWpEdges(zT_522, zT_523, zT_524, zT_525, zT_526);
    zT_530 = (unsigned int)ti;
    zT_531 = (unsigned int)wp_count;
    wp_to[zT_531] = zT_530;
    zT_532 = (unsigned int)eup;
    zT_533 = wp_head[zT_532];
    zT_534 = (unsigned int)wp_count;
    wp_next[zT_534] = zT_533;
    zT_535 = (unsigned int)eup;
    wp_head[zT_535] = wp_count;
    zT_537 = wp_count + (unsigned int)(1);
    wp_count = zT_537;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_543 = self->registry;
    zT_544 = zT_543->opt_items;
    zT_545 = ty.payload_idx;
    zT_546 = (unsigned int)zT_545;
    zT_547 = zT_544[zT_546];
    zT_548 = zT_547.payload;
    op_p = zT_548;
    zT_550 = self->registry;
    zT_551 = zT_550->types_items;
    zT_552 = (unsigned int)op_p;
    zT_553 = zT_551[zT_552];
    op_ty = zT_553;
    zT_554 = op_ty.kind;
    zT_556 = zF_EA3ED3F3_requiresFullDef(zT_554);
    if (zT_556) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_557 = 0;
    is_po = zT_557;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_558 = op_ty.kind;
    if ((unsigned char)(zT_558 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_562 = perm_alloc;
    zT_563 = &wp_to;
    zT_564 = &wp_next;
    zT_565 = &wp_edge_cap;
    zT_566 = wp_count;
    zF_25C377BD_growWpEdges(zT_562, zT_563, zT_564, zT_565, zT_566);
    zT_570 = (unsigned int)ti;
    zT_571 = (unsigned int)wp_count;
    wp_to[zT_571] = zT_570;
    zT_572 = (unsigned int)op_p;
    zT_573 = wp_head[zT_572];
    zT_574 = (unsigned int)wp_count;
    wp_next[zT_574] = zT_573;
    zT_575 = (unsigned int)op_p;
    wp_head[zT_575] = wp_count;
    zT_577 = wp_count + (unsigned int)(1);
    wp_count = zT_577;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_578 = op_ty.kind;
    if ((unsigned char)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_582 = perm_alloc;
    zT_583 = &wp_to;
    zT_584 = &wp_next;
    zT_585 = &wp_edge_cap;
    zT_586 = wp_count;
    zF_25C377BD_growWpEdges(zT_582, zT_583, zT_584, zT_585, zT_586);
    zT_590 = (unsigned int)ti;
    zT_591 = (unsigned int)wp_count;
    wp_to[zT_591] = zT_590;
    zT_592 = (unsigned int)op_p;
    zT_593 = wp_head[zT_592];
    zT_594 = (unsigned int)wp_count;
    wp_next[zT_594] = zT_593;
    zT_595 = (unsigned int)op_p;
    wp_head[zT_595] = wp_count;
    zT_597 = wp_count + (unsigned int)(1);
    wp_count = zT_597;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_600 = (unsigned int)ti;
    zT_601 = (unsigned int)wl_tail;
    worklist[zT_601] = zT_600;
    zT_603 = wl_tail + (unsigned int)(1);
    wl_tail = zT_603;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((unsigned char)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_609 = (unsigned int)wl_head;
    zT_610 = worklist[zT_609];
    cur = zT_610;
    zT_612 = wl_head + (unsigned int)(1);
    wl_head = zT_612;
    zT_614 = (unsigned int)cur;
    zT_615 = wp_head[zT_614];
    e = zT_615;
    goto z_bb_134;
    z_bb_132:
    zT_633 = perm_alloc;
    zT_636 = 4;
    zT_638 = 4;
    zT_640 = zF_1395EB68_sandAlloc(zT_633, (unsigned int)(zT_636 * tl), (unsigned int)((unsigned int)zT_638));
    zT_641 = zT_640.is_error;
    if (zT_641) goto z_bb_140; else goto z_bb_141;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((unsigned char)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_619 = (unsigned int)e;
    zT_620 = wp_to[zT_619];
    parent_tid = zT_620;
    zT_621 = (unsigned int)parent_tid;
    zT_622 = pointer_only[zT_621];
    if ((unsigned char)(zT_622 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_625 = 0;
    zT_626 = (unsigned int)parent_tid;
    pointer_only[zT_626] = zT_625;
    zT_627 = (unsigned int)wl_tail;
    worklist[zT_627] = parent_tid;
    zT_629 = wl_tail + (unsigned int)(1);
    wl_tail = zT_629;
    goto z_bb_139;
    z_bb_139:
    zT_630 = (unsigned int)e;
    zT_631 = wp_next[zT_630];
    e = zT_631;
    goto z_bb_137;
    z_bb_140:
    pal_trap();
    z_bb_141:
    zT_642 = zT_640.data.payload;
    goto z_bb_142;
    z_bb_142:
    ids_raw = zT_642;
    zT_645 = (unsigned int*)ids_raw;
    ids = zT_645;
    zT_647 = 0;
    plen = zT_647;
    zT_648 = 0;
    zT_649 = (unsigned int)zT_648;
    ti = zT_649;
    goto z_bb_143;
    z_bb_143:
    if ((unsigned char)(ti < tl)) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_651 = pointer_only[ti];
    if ((unsigned char)(zT_651 != (unsigned char)(0))) goto z_bb_147; else goto z_bb_148;
    z_bb_145:
    zT_662 = "CLS:c";
    zT_664 = 5;
    zT_663.ptr = zT_662;
    zT_663.len = zT_664;
    cls_m = zT_663;
    zT_665 = cls_m;
    zF_48AC7B3A_markerWrite(zT_665);
    zT_666 = plen;
    zF_C8A36147_markerU32(zT_666);
    zT_668 = "\n";
    zT_670 = 1;
    zT_669.ptr = zT_668;
    zT_669.len = zT_670;
    cls_nl = zT_669;
    zT_671 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_671);
    zT_672 = 0;
    zT_673 = (unsigned int)zT_672;
    ti = zT_673;
    goto z_bb_149;
    z_bb_146:
    zT_658 = 1;
    zT_660 = ti + (unsigned int)((unsigned int)zT_658);
    ti = zT_660;
    goto z_bb_143;
    z_bb_147:
    zT_654 = (unsigned int)ti;
    zT_655 = (unsigned int)plen;
    ids[zT_655] = zT_654;
    zT_657 = plen + (unsigned int)(1);
    plen = zT_657;
    goto z_bb_148;
    z_bb_148:
    goto z_bb_146;
    z_bb_149:
    if ((unsigned char)(ti < tl)) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_675 = pointer_only[ti];
    if ((unsigned char)(zT_675 != (unsigned char)(0))) goto z_bb_153; else goto z_bb_155;
    z_bb_151:
    zT_709.ids = ids;
    zT_709.len = plen;
    return zT_709;
    z_bb_152:
    zT_706 = 1;
    zT_708 = ti + (unsigned int)((unsigned int)zT_706);
    ti = zT_708;
    goto z_bb_149;
    z_bb_153:
    zT_679 = "CLS:p";
    zT_681 = 5;
    zT_680.ptr = zT_679;
    zT_680.len = zT_681;
    pfx = zT_680;
    zT_682 = pfx;
    zF_48AC7B3A_markerWrite(zT_682);
    goto z_bb_154;
    z_bb_154:
    zF_C8A36147_markerU32((unsigned int)((unsigned int)ti));
    zT_691 = "k";
    zT_693 = 1;
    zT_692.ptr = zT_691;
    zT_692.len = zT_693;
    ck = zT_692;
    zT_694 = ck;
    zF_48AC7B3A_markerWrite(zT_694);
    zT_696 = self->registry;
    zT_697 = zT_696->types_items;
    zT_698 = zT_697[ti];
    zT_699 = zT_698.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_699));
    zT_702 = "\n";
    zT_704 = 1;
    zT_703.ptr = zT_702;
    zT_703.len = zT_704;
    cnl = zT_703;
    zT_705 = cnl;
    zF_48AC7B3A_markerWrite(zT_705);
    goto z_bb_152;
    z_bb_155:
    zT_684 = "CLS:v";
    zT_686 = 5;
    zT_685.ptr = zT_684;
    zT_685.len = zT_686;
    pfx = zT_685;
    zT_687 = pfx;
    zF_48AC7B3A_markerWrite(zT_687);
    goto z_bb_154;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int** zT_9;
    unsigned int** zT_10;
    unsigned int* zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = perm_a;
    zT_9 = wp_to_ptr;
    zT_10 = wp_next_ptr;
    zT_12 = cap_ptr;
    zF_F638C869_nameScopeGrowPair(zT_8, zT_9, zT_10, (unsigned int)((unsigned int)count), zT_12, (unsigned int)(0));
    return;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstModuleOfExpr */
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    unsigned int zT_19;
    zT_3D7259E2_SymbolRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D0942820_Opt_894 zT_27 = {0};
    unsigned char zT_28;
    zT_3C598AEF_SymbolKind zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned char zT_54;
    int zT_57;
    unsigned int zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    zT_3D7259E2_SymbolRegistry* zT_64;
    unsigned int zT_66;
    zT_D0942820_Opt_894 zT_69 = {0};
    unsigned char zT_70;
    zT_3C598AEF_SymbolKind zT_72;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    unsigned char zT_96;
    int zT_98;
    unsigned int zT_100;
    zT_8143F551_AstKind zT_102;
    zT_ABC1EBBE_TypeResolveEnv* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int zT_118 = 0;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_D0942820_Opt_894 zT_123 = {0};
    unsigned char zT_124;
    zT_3C598AEF_SymbolKind zT_126;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_134;
    unsigned int zT_135;
    zT_338B7C76_TypeRegistry* zT_137;
    unsigned int zT_138;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_D155D06D_Type* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_D155D06D_Type zT_145;
    zT_33EF6BFB_TypeKind zT_146;
    unsigned char zT_150;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    zT_D0942820_Opt_894 sym;
    zT_3A105EF1_Symbol* s2;
    zT_D155D06D_Type sty2;
    unsigned int base_mod;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* msym;
    zT_D155D06D_Type mty;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_53458827_astStoreIdentifier(zT_15, zT_16);
    name_id = zT_18;
    zT_19 = env->module_id;
    if ((unsigned char)(zT_19 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_102 = node.kind;
    if ((unsigned char)(zT_102 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_22 = env->symbol_reg;
    zT_23 = env->module_id;
    zT_24 = name_id;
    zT_27 = zF_A398987E_symbolRegistryQuali(zT_22, zT_23, zT_24);
    zT_28 = zT_27.has_value;
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    si = zT_58;
    goto z_bb_18;
    z_bb_7:
    s = zT_27.value;
    zT_30 = s->kind;
    if ((unsigned char)(zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_34 = s->module_id;
    return zT_34;
    z_bb_10:
    zT_35 = s->type_id;
    if ((unsigned char)(zT_35 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = s->type_id;
    zT_41 = env->typereg;
    zT_42 = zT_41->types_len;
    zT_38 = (unsigned int)((unsigned int)zT_39) < zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = env->typereg;
    zT_46 = zT_45->types_items;
    zT_47 = s->type_id;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    sty = zT_49;
    zT_50 = sty.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_54 = sty.module_id;
    return (unsigned int)((unsigned int)zT_54);
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_59 = env->symbol_reg;
    zT_60 = zT_59->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_60))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_64 = env->symbol_reg;
    zT_66 = name_id;
    zT_69 = zF_A398987E_symbolRegistryQuali(zT_64, (unsigned int)((unsigned int)si), zT_66);
    sym = zT_69;
    zT_70 = sym.has_value;
    if (zT_70) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    zT_98 = 1;
    zT_100 = si + (unsigned int)((unsigned int)zT_98);
    si = zT_100;
    goto z_bb_18;
    z_bb_22:
    s2 = sym.value;
    zT_72 = s2->kind;
    if ((unsigned char)(zT_72 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_76 = s2->module_id;
    return zT_76;
    z_bb_25:
    zT_77 = s2->type_id;
    if ((unsigned char)(zT_77 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_81 = s2->type_id;
    zT_83 = env->typereg;
    zT_84 = zT_83->types_len;
    zT_80 = (unsigned int)((unsigned int)zT_81) < zT_84;
    goto z_bb_28;
    z_bb_27:
    zT_80 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_80) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_items;
    zT_89 = s2->type_id;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    sty2 = zT_91;
    zT_92 = sty2.kind;
    if ((unsigned char)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_23;
    z_bb_31:
    zT_96 = sty2.module_id;
    return (unsigned int)((unsigned int)zT_96);
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_107 = env;
    zT_108 = node.child_0;
    zT_110 = zF_0E4084E4_evalConstModuleOfEx(zT_107, zT_108);
    base_mod = zT_110;
    if ((unsigned char)(base_mod == (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    return (unsigned int)(0);
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_115 = env->store;
    zT_116 = node_idx;
    zT_118 = zF_8BA26B9E_astStoreNodePayload(zT_115, zT_116);
    field_name_id = zT_118;
    zT_119 = env->symbol_reg;
    zT_120 = base_mod;
    zT_121 = field_name_id;
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_119, zT_120, zT_121);
    zT_124 = zT_123.has_value;
    if (zT_124) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    msym = zT_123.value;
    zT_126 = msym->kind;
    if ((unsigned char)(zT_126 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    return (unsigned int)(0);
    z_bb_39:
    zT_130 = msym->module_id;
    return zT_130;
    z_bb_40:
    zT_131 = msym->type_id;
    if ((unsigned char)(zT_131 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_135 = msym->type_id;
    zT_137 = env->typereg;
    zT_138 = zT_137->types_len;
    zT_134 = (unsigned int)((unsigned int)zT_135) < zT_138;
    goto z_bb_43;
    z_bb_42:
    zT_134 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_134) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_141 = env->typereg;
    zT_142 = zT_141->types_items;
    zT_143 = msym->type_id;
    zT_144 = (unsigned int)zT_143;
    zT_145 = zT_142[zT_144];
    mty = zT_145;
    zT_146 = mty.kind;
    if ((unsigned char)(zT_146 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_38;
    z_bb_46:
    zT_150 = mty.module_id;
    return (unsigned int)((unsigned int)zT_150);
    z_bb_47:
    goto z_bb_45;
}

/* evalConstScalarKind */
unsigned char zF_6AE4DFFC_evalConstScalarKind(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    return (unsigned char)(1);
}

/* evalConstIntFull */
zT_E53A25A2_Opt_203 zF_382591DE_evalConstIntFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_E53A25A2_Opt_203 zT_5 = {0};
    zT_E53A25A2_Opt_203 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    zT_79FAE712_u64 zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_79FAE712_u64 zT_27 = 0;
    zT_0163D9A4_ComptimeInt zT_28 = {0};
    zT_E53A25A2_Opt_203 zT_29;
    zT_8143F551_AstKind zT_30;
    unsigned int zT_34;
    zT_ABC1EBBE_TypeResolveEnv* zT_38;
    unsigned int zT_39;
    zT_E53A25A2_Opt_203 zT_44 = {0};
    unsigned char zT_45;
    zT_0163D9A4_ComptimeInt zT_48 = {0};
    zT_0163D9A4_ComptimeInt zT_49;
    zT_0163D9A4_ComptimeInt* zT_50;
    unsigned char zT_52 = 0;
    zT_E53A25A2_Opt_203 zT_53;
    zT_E53A25A2_Opt_203 zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_62;
    unsigned int zT_64;
    zT_8143F551_AstKind zT_66;
    unsigned char zT_70;
    zT_8143F551_AstKind zT_71;
    unsigned char zT_75;
    zT_8143F551_AstKind zT_76;
    unsigned char zT_80;
    zT_8143F551_AstKind zT_81;
    unsigned char zT_85;
    zT_8143F551_AstKind zT_86;
    unsigned char zT_90;
    zT_8143F551_AstKind zT_91;
    unsigned char zT_95;
    zT_8143F551_AstKind zT_96;
    unsigned char zT_100;
    zT_8143F551_AstKind zT_101;
    unsigned char zT_105;
    zT_8143F551_AstKind zT_106;
    unsigned char zT_110;
    zT_8143F551_AstKind zT_111;
    zT_ABC1EBBE_TypeResolveEnv* zT_116;
    unsigned int zT_117;
    zT_E53A25A2_Opt_203 zT_122 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_124;
    unsigned int zT_125;
    zT_E53A25A2_Opt_203 zT_130 = {0};
    unsigned char zT_131;
    unsigned char zT_133;
    zT_0163D9A4_ComptimeInt zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_0163D9A4_ComptimeInt zT_141;
    zT_0163D9A4_ComptimeInt zT_142;
    zT_0163D9A4_ComptimeInt* zT_143;
    unsigned char zT_145 = 0;
    zT_E53A25A2_Opt_203 zT_147 = {0};
    zT_E53A25A2_Opt_203 zT_148;
    zT_8143F551_AstKind zT_149;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    zT_0163D9A4_ComptimeInt* zT_155;
    unsigned char zT_157 = 0;
    zT_E53A25A2_Opt_203 zT_159 = {0};
    zT_E53A25A2_Opt_203 zT_160;
    zT_8143F551_AstKind zT_161;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    zT_0163D9A4_ComptimeInt* zT_167;
    unsigned char zT_169 = 0;
    zT_E53A25A2_Opt_203 zT_171 = {0};
    zT_E53A25A2_Opt_203 zT_172;
    zT_8143F551_AstKind zT_173;
    zT_0163D9A4_ComptimeInt zT_178 = {0};
    zT_0163D9A4_ComptimeInt zT_179;
    zT_0163D9A4_ComptimeInt zT_180;
    zT_0163D9A4_ComptimeInt* zT_181;
    zT_0163D9A4_ComptimeInt* zT_182;
    unsigned char zT_185 = 0;
    zT_E53A25A2_Opt_203 zT_187 = {0};
    zT_E53A25A2_Opt_203 zT_188;
    zT_8143F551_AstKind zT_189;
    zT_0163D9A4_ComptimeInt zT_194 = {0};
    zT_0163D9A4_ComptimeInt zT_195;
    zT_0163D9A4_ComptimeInt zT_196;
    zT_0163D9A4_ComptimeInt* zT_197;
    zT_0163D9A4_ComptimeInt* zT_198;
    unsigned char zT_201 = 0;
    zT_E53A25A2_Opt_203 zT_203 = {0};
    zT_E53A25A2_Opt_203 zT_204;
    zT_8143F551_AstKind zT_205;
    zT_0163D9A4_ComptimeInt zT_209;
    zT_0163D9A4_ComptimeInt zT_210;
    zT_0163D9A4_ComptimeInt* zT_211;
    unsigned char zT_213 = 0;
    zT_E53A25A2_Opt_203 zT_215 = {0};
    zT_E53A25A2_Opt_203 zT_216;
    zT_8143F551_AstKind zT_217;
    zT_0163D9A4_ComptimeInt zT_221;
    zT_0163D9A4_ComptimeInt zT_222;
    zT_0163D9A4_ComptimeInt* zT_223;
    unsigned char zT_225 = 0;
    zT_E53A25A2_Opt_203 zT_227 = {0};
    zT_E53A25A2_Opt_203 zT_228;
    zT_8143F551_AstKind zT_229;
    zT_0163D9A4_ComptimeInt zT_233;
    zT_0163D9A4_ComptimeInt zT_234;
    zT_0163D9A4_ComptimeInt* zT_235;
    unsigned char zT_237 = 0;
    zT_E53A25A2_Opt_203 zT_239 = {0};
    zT_E53A25A2_Opt_203 zT_240;
    zT_8143F551_AstKind zT_241;
    zT_0163D9A4_ComptimeInt zT_245;
    zT_0163D9A4_ComptimeInt zT_246;
    zT_0163D9A4_ComptimeInt* zT_247;
    unsigned char zT_249 = 0;
    zT_E53A25A2_Opt_203 zT_251 = {0};
    zT_E53A25A2_Opt_203 zT_252;
    zT_0163D9A4_ComptimeInt zT_253;
    zT_0163D9A4_ComptimeInt zT_254;
    zT_0163D9A4_ComptimeInt* zT_255;
    unsigned char zT_257 = 0;
    zT_E53A25A2_Opt_203 zT_259 = {0};
    zT_E53A25A2_Opt_203 zT_260;
    zT_E53A25A2_Opt_203 zT_261 = {0};
    zT_8143F551_AstKind zT_262;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    unsigned int zT_270 = 0;
    zT_02CE50E0_Opt_403 zT_271;
    unsigned char zT_272;
    zT_E2DF2801_LocalConstScope* zT_274;
    unsigned int zT_275;
    zT_BAEE192E_Opt_10 zT_276 = {0};
    unsigned char zT_277;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    zT_22A7C88B_AstNode zT_283 = {0};
    unsigned int zT_284;
    zT_ABC1EBBE_TypeResolveEnv* zT_287;
    unsigned int zT_290;
    unsigned int zT_292;
    zT_ABC1EBBE_TypeResolveEnv* zT_295;
    unsigned int zT_296;
    zT_D0942820_Opt_894 zT_297 = {0};
    unsigned char zT_298;
    unsigned short zT_300;
    zT_6B0A7D14_AstStore* zT_306;
    unsigned int zT_307;
    zT_22A7C88B_AstNode zT_310 = {0};
    unsigned int zT_311;
    zT_ABC1EBBE_TypeResolveEnv* zT_314;
    unsigned int zT_317;
    unsigned int zT_319;
    zT_E53A25A2_Opt_203 zT_321 = {0};
    zT_8143F551_AstKind zT_322;
    zT_ABC1EBBE_TypeResolveEnv* zT_327;
    unsigned int zT_328;
    unsigned int zT_330 = 0;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_337 = 0;
    zT_3D7259E2_SymbolRegistry* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_D0942820_Opt_894 zT_342 = {0};
    unsigned char zT_343;
    zT_ABC1EBBE_TypeResolveEnv* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    zT_3A105EF1_Symbol* zT_348;
    unsigned char zT_349 = 0;
    zT_E53A25A2_Opt_203 zT_351 = {0};
    unsigned short zT_352;
    zT_6B0A7D14_AstStore* zT_358;
    unsigned int zT_359;
    zT_22A7C88B_AstNode zT_362 = {0};
    unsigned int zT_363;
    zT_ABC1EBBE_TypeResolveEnv* zT_366;
    unsigned int zT_369;
    unsigned int zT_371;
    zT_E53A25A2_Opt_203 zT_373 = {0};
    zT_8143F551_AstKind zT_374;
    unsigned char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned int zT_381;
    zT_D3EB6303_StringInterner* zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned int zT_386 = 0;
    unsigned char* zT_388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_389;
    unsigned int zT_390;
    zT_D3EB6303_StringInterner* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_395 = 0;
    unsigned char* zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    unsigned int zT_399;
    zT_D3EB6303_StringInterner* zT_401;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_402;
    unsigned int zT_404 = 0;
    unsigned char* zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_D3EB6303_StringInterner* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_413 = 0;
    unsigned char* zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    zT_D3EB6303_StringInterner* zT_419;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned int zT_422 = 0;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_D3EB6303_StringInterner* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_431 = 0;
    unsigned char* zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    zT_D3EB6303_StringInterner* zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_440 = 0;
    zT_6B0A7D14_AstStore* zT_442;
    unsigned int zT_443;
    unsigned int zT_445 = 0;
    unsigned int zT_446;
    unsigned char zT_448;
    unsigned int zT_449;
    zT_ABC1EBBE_TypeResolveEnv* zT_454;
    unsigned int zT_455;
    zT_6B0A7D14_AstStore* zT_457;
    unsigned int zT_458;
    unsigned int zT_462 = 0;
    unsigned int zT_465 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_469;
    unsigned int zT_470;
    zT_6B0A7D14_AstStore* zT_472;
    unsigned int zT_473;
    unsigned int zT_477 = 0;
    zT_E53A25A2_Opt_203 zT_480 = {0};
    unsigned char zT_481;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_0163D9A4_ComptimeInt zT_484;
    unsigned int zT_485;
    unsigned char zT_487 = 0;
    zT_E53A25A2_Opt_203 zT_488;
    zT_E53A25A2_Opt_203 zT_489 = {0};
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned int zT_493;
    unsigned char zT_495;
    unsigned int zT_496;
    zT_ABC1EBBE_TypeResolveEnv* zT_501;
    unsigned int zT_502;
    zT_6B0A7D14_AstStore* zT_504;
    unsigned int zT_505;
    unsigned int zT_509 = 0;
    unsigned int zT_512 = 0;
    zT_338B7C76_TypeRegistry* zT_516;
    zT_D155D06D_Type* zT_517;
    unsigned int zT_518;
    zT_D155D06D_Type zT_519;
    unsigned char zT_520;
    unsigned char zT_523;
    zT_33EF6BFB_TypeKind zT_524;
    zT_338B7C76_TypeRegistry* zT_528;
    unsigned int zT_529;
    unsigned char zT_533 = 0;
    zT_338B7C76_TypeRegistry* zT_534;
    zT_D155D06D_Type* zT_535;
    unsigned int zT_536;
    zT_D155D06D_Type zT_537;
    zT_33EF6BFB_TypeKind zT_539;
    unsigned char zT_541 = 0;
    zT_33EF6BFB_TypeKind zT_542;
    unsigned char zT_546;
    unsigned char zT_547;
    unsigned char zT_550;
    unsigned int zT_551;
    unsigned int zT_554;
    zT_0163D9A4_ComptimeInt zT_556 = {0};
    zT_E53A25A2_Opt_203 zT_557;
    unsigned int zT_558;
    unsigned char zT_561;
    zT_0163D9A4_ComptimeInt zT_563 = {0};
    zT_E53A25A2_Opt_203 zT_564;
    unsigned int zT_566;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_569;
    unsigned int zT_570;
    unsigned char zT_572 = 0;
    zT_338B7C76_TypeRegistry* zT_573;
    unsigned int zT_574;
    unsigned char zT_576 = 0;
    unsigned int zT_577;
    zT_33EF6BFB_TypeKind zT_578;
    zT_338B7C76_TypeRegistry* zT_582;
    unsigned int zT_583;
    zT_338B7C76_TypeRegistry* zT_585;
    unsigned int zT_586;
    unsigned int zT_588 = 0;
    unsigned char zT_589 = 0;
    unsigned int zT_590;
    zT_33EF6BFB_TypeKind zT_591;
    unsigned int zT_595;
    zT_33EF6BFB_TypeKind zT_596;
    unsigned char zT_600;
    unsigned char zT_601;
    zT_338B7C76_TypeRegistry* zT_606;
    unsigned int zT_607;
    unsigned int zT_609 = 0;
    unsigned int zT_610;
    zT_0163D9A4_ComptimeInt zT_613 = {0};
    zT_E53A25A2_Opt_203 zT_614;
    zT_E53A25A2_Opt_203 zT_615 = {0};
    unsigned int zT_616;
    unsigned char zT_618;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv* zT_624;
    unsigned int zT_625;
    zT_6B0A7D14_AstStore* zT_627;
    unsigned int zT_628;
    unsigned int zT_632 = 0;
    unsigned int zT_635 = 0;
    zT_338B7C76_TypeRegistry* zT_639;
    zT_D155D06D_Type* zT_640;
    unsigned int zT_641;
    zT_D155D06D_Type zT_642;
    unsigned char zT_643;
    unsigned char zT_646;
    zT_33EF6BFB_TypeKind zT_647;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_652 = {0};
    zT_338B7C76_TypeRegistry* zT_653;
    unsigned int zT_654;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_655;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_659 = {0};
    zT_338B7C76_TypeRegistry* zT_661;
    unsigned int zT_662;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_663;
    unsigned char zT_666 = 0;
    zT_6B0A7D14_AstStore* zT_668;
    unsigned int zT_669;
    zT_6B0A7D14_AstStore* zT_671;
    unsigned int zT_672;
    unsigned int zT_676 = 0;
    zT_22A7C88B_AstNode zT_677 = {0};
    zT_8143F551_AstKind zT_678;
    zT_6B0A7D14_AstStore* zT_683;
    unsigned int zT_684;
    zT_6B0A7D14_AstStore* zT_686;
    unsigned int zT_687;
    unsigned int zT_691 = 0;
    unsigned int zT_692 = 0;
    zT_6B0A7D14_AstStore* zT_694;
    zT_20CEC606_anon_259785 zT_695;
    unsigned int* zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    int zT_700;
    unsigned int zT_701;
    unsigned int zT_703;
    zT_2DF01B61_FieldEntry* zT_705;
    zT_2DF01B61_FieldEntry zT_706;
    unsigned int zT_707;
    zT_2DF01B61_FieldEntry* zT_710;
    zT_2DF01B61_FieldEntry zT_711;
    unsigned int zT_712;
    zT_79FAE712_u64 zT_713;
    zT_79FAE712_u64 zT_715;
    unsigned int zT_717;
    zT_E276DDD0_PackedBitField* zT_719;
    zT_E276DDD0_PackedBitField zT_720;
    unsigned int zT_721;
    zT_79FAE712_u64 zT_722;
    unsigned int zT_723;
    zT_79FAE712_u64 zT_726;
    unsigned int zT_727;
    zT_79FAE712_u64 zT_730;
    zT_79FAE712_u64 zT_731;
    zT_0163D9A4_ComptimeInt zT_732 = {0};
    zT_E53A25A2_Opt_203 zT_733;
    int zT_734;
    unsigned int zT_736;
    zT_E53A25A2_Opt_203 zT_737 = {0};
    zT_E53A25A2_Opt_203 zT_738 = {0};
    zT_E53A25A2_Opt_203 zT_739 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 inner;
    zT_0163D9A4_ComptimeInt iv;
    zT_0163D9A4_ComptimeInt nv;
    zT_E53A25A2_Opt_203 l_opt;
    zT_E53A25A2_Opt_203 r_opt;
    zT_0163D9A4_ComptimeInt lv;
    zT_0163D9A4_ComptimeInt rv;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    zT_D0942820_Opt_894 c_sym;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int fa_mod_id;
    unsigned int fa_field_id;
    zT_3A105EF1_Symbol* fa_sym;
    zT_22A7C88B_AstNode fa_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    unsigned int size_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    unsigned int bitsz_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    unsigned int off_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int bitoff_id;
    unsigned int bc_n;
    unsigned int ct_tid;
    zT_E53A25A2_Opt_203 cv_opt;
    zT_0163D9A4_ComptimeInt cv;
    unsigned int bt_tid;
    zT_D155D06D_Type bt_ty;
    unsigned char bt_foldable;
    unsigned int bt_bits;
    unsigned int ot_tid;
    zT_D155D06D_Type ot_ty;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_19 = node.kind;
    zT_18 = zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = env->store;
    zT_25 = node_idx;
    zT_27 = zF_678B9A72_astStoreIntValue(zT_24, zT_25);
    zT_23 = zT_27;
    zT_28 = zF_1EAA44E6_ciFromU64(zT_23);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_9:
    zT_30 = node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = node.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_55 = node.kind;
    if ((unsigned char)(zT_55 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    zT_38 = env;
    zT_39 = node.child_0;
    zT_44 = zF_382591DE_evalConstIntFull(zT_38, zT_39, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_44;
    zT_45 = inner.has_value;
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_54.has_value = 0;
    return zT_54;
    z_bb_14:
    iv = inner.value;
    zT_48 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_48;
    zT_49 = iv;
    zT_50 = &nv;
    zT_52 = zF_EECBFD7D_ciNeg(zT_49, zT_50);
    (void)zT_52;
    zT_53.has_value = 1;
    zT_53.value = nv;
    return zT_53;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_59 = env;
    zT_62 = node.child_0;
    zT_64 = depth + (unsigned int)(1);
    env = zT_59;
    node_idx = zT_62;
    depth = zT_64;
    goto z_bb_0;
    z_bb_17:
    zT_66 = node.kind;
    if ((unsigned char)(zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_71 = node.kind;
    zT_70 = zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_20;
    z_bb_19:
    zT_70 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_70) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_76 = node.kind;
    zT_75 = zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_23;
    z_bb_22:
    zT_75 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_75) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_81 = node.kind;
    zT_80 = zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_26;
    z_bb_25:
    zT_80 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_80) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_86 = node.kind;
    zT_85 = zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_29;
    z_bb_28:
    zT_85 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_85) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_91 = node.kind;
    zT_90 = zT_91 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_32;
    z_bb_31:
    zT_90 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_90) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_96 = node.kind;
    zT_95 = zT_96 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_35;
    z_bb_34:
    zT_95 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_95) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_101 = node.kind;
    zT_100 = zT_101 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_38;
    z_bb_37:
    zT_100 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_100) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_106 = node.kind;
    zT_105 = zT_106 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_41;
    z_bb_40:
    zT_105 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_105) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_111 = node.kind;
    zT_110 = zT_111 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_44;
    z_bb_43:
    zT_110 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_110) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_116 = env;
    zT_117 = node.child_0;
    zT_122 = zF_382591DE_evalConstIntFull(zT_116, zT_117, (unsigned int)(depth + (unsigned int)(1)));
    l_opt = zT_122;
    zT_124 = env;
    zT_125 = node.child_1;
    zT_130 = zF_382591DE_evalConstIntFull(zT_124, zT_125, (unsigned int)(depth + (unsigned int)(1)));
    r_opt = zT_130;
    zT_131 = l_opt.has_value;
    if (zT_131) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_262 = node.kind;
    if ((unsigned char)(zT_262 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_47:
    lv = l_opt.value;
    zT_133 = r_opt.has_value;
    if (zT_133) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_261.has_value = 0;
    return zT_261;
    z_bb_49:
    rv = r_opt.value;
    zT_136 = zF_DC9B7BC0_ciZeroInt();
    res = zT_136;
    zT_137 = node.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_141 = lv;
    zT_142 = rv;
    zT_143 = &res;
    zT_145 = zF_8A5DB878_ciAdd(zT_141, zT_142, zT_143);
    if ((unsigned char)(!zT_145)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_149 = node.kind;
    if ((unsigned char)(zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_147.has_value = 0;
    return zT_147;
    z_bb_54:
    zT_148.has_value = 1;
    zT_148.value = res;
    return zT_148;
    z_bb_55:
    zT_153 = lv;
    zT_154 = rv;
    zT_155 = &res;
    zT_157 = zF_539A2D81_ciSub(zT_153, zT_154, zT_155);
    if ((unsigned char)(!zT_157)) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_161 = node.kind;
    if ((unsigned char)(zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_159.has_value = 0;
    return zT_159;
    z_bb_58:
    zT_160.has_value = 1;
    zT_160.value = res;
    return zT_160;
    z_bb_59:
    zT_165 = lv;
    zT_166 = rv;
    zT_167 = &res;
    zT_169 = zF_A3E385DD_ciMul(zT_165, zT_166, zT_167);
    if ((unsigned char)(!zT_169)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_173 = node.kind;
    if ((unsigned char)(zT_173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_171.has_value = 0;
    return zT_171;
    z_bb_62:
    zT_172.has_value = 1;
    zT_172.value = res;
    return zT_172;
    z_bb_63:
    zT_178 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_178;
    zT_179 = lv;
    zT_180 = rv;
    zT_181 = &res;
    zT_182 = &rem;
    zT_185 = zF_25A0EEC0_ciDivMod(zT_179, zT_180, zT_181, zT_182);
    if ((unsigned char)(!zT_185)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_189 = node.kind;
    if ((unsigned char)(zT_189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_187.has_value = 0;
    return zT_187;
    z_bb_66:
    zT_188.has_value = 1;
    zT_188.value = res;
    return zT_188;
    z_bb_67:
    zT_194 = zF_DC9B7BC0_ciZeroInt();
    q = zT_194;
    zT_195 = lv;
    zT_196 = rv;
    zT_197 = &q;
    zT_198 = &res;
    zT_201 = zF_25A0EEC0_ciDivMod(zT_195, zT_196, zT_197, zT_198);
    if ((unsigned char)(!zT_201)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_205 = node.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    zT_203.has_value = 0;
    return zT_203;
    z_bb_70:
    zT_204.has_value = 1;
    zT_204.value = res;
    return zT_204;
    z_bb_71:
    zT_209 = lv;
    zT_210 = rv;
    zT_211 = &res;
    zT_213 = zF_E15DE14D_ciBitAnd(zT_209, zT_210, zT_211);
    if ((unsigned char)(!zT_213)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_217 = node.kind;
    if ((unsigned char)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    zT_215.has_value = 0;
    return zT_215;
    z_bb_74:
    zT_216.has_value = 1;
    zT_216.value = res;
    return zT_216;
    z_bb_75:
    zT_221 = lv;
    zT_222 = rv;
    zT_223 = &res;
    zT_225 = zF_93823331_ciBitOr(zT_221, zT_222, zT_223);
    if ((unsigned char)(!zT_225)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_229 = node.kind;
    if ((unsigned char)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_227.has_value = 0;
    return zT_227;
    z_bb_78:
    zT_228.has_value = 1;
    zT_228.value = res;
    return zT_228;
    z_bb_79:
    zT_233 = lv;
    zT_234 = rv;
    zT_235 = &res;
    zT_237 = zF_C592CA21_ciBitXor(zT_233, zT_234, zT_235);
    if ((unsigned char)(!zT_237)) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_241 = node.kind;
    if ((unsigned char)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    zT_239.has_value = 0;
    return zT_239;
    z_bb_82:
    zT_240.has_value = 1;
    zT_240.value = res;
    return zT_240;
    z_bb_83:
    zT_245 = lv;
    zT_246 = rv;
    zT_247 = &res;
    zT_249 = zF_4FDD0D22_ciShl(zT_245, zT_246, zT_247);
    if ((unsigned char)(!zT_249)) goto z_bb_85; else goto z_bb_86;
    z_bb_84:
    zT_253 = lv;
    zT_254 = rv;
    zT_255 = &res;
    zT_257 = zF_41DCF718_ciShr(zT_253, zT_254, zT_255);
    if ((unsigned char)(!zT_257)) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    zT_251.has_value = 0;
    return zT_251;
    z_bb_86:
    zT_252.has_value = 1;
    zT_252.value = res;
    return zT_252;
    z_bb_87:
    zT_259.has_value = 0;
    return zT_259;
    z_bb_88:
    zT_260.has_value = 1;
    zT_260.value = res;
    return zT_260;
    z_bb_89:
    zT_267 = env->store;
    zT_268 = node_idx;
    zT_270 = zF_53458827_astStoreIdentifier(zT_267, zT_268);
    name_id = zT_270;
    zT_271 = env->local_consts;
    zT_272 = zT_271.has_value;
    if (zT_272) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    zT_322 = node.kind;
    if ((unsigned char)(zT_322 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_103; else goto z_bb_104;
    z_bb_91:
    lcs = zT_271.value;
    zT_274 = lcs;
    zT_275 = name_id;
    zT_276 = zF_6532C387_localConstScopeLook(zT_274, zT_275);
    zT_277 = zT_276.has_value;
    if (zT_277) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_295 = env;
    zT_296 = name_id;
    zT_297 = zF_04FED007_symbolLookupAllModu(zT_295, zT_296);
    c_sym = zT_297;
    zT_298 = c_sym.has_value;
    if (zT_298) goto z_bb_97; else goto z_bb_98;
    z_bb_93:
    l_decl_node = zT_276.value;
    zT_280 = env->store;
    zT_281 = l_decl_node;
    zT_283 = zF_FCDD1D35_astStoreNodeAt(zT_280, zT_281);
    l_decl = zT_283;
    zT_284 = l_decl.child_1;
    if ((unsigned char)(zT_284 != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_287 = env;
    zT_290 = l_decl.child_1;
    zT_292 = depth + (unsigned int)(1);
    env = zT_287;
    node_idx = zT_290;
    depth = zT_292;
    goto z_bb_0;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    cs = c_sym.value;
    zT_300 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_300 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_321.has_value = 0;
    return zT_321;
    z_bb_99:
    zT_306 = env->store;
    zT_307 = cs->decl_node;
    zT_310 = zF_FCDD1D35_astStoreNodeAt(zT_306, zT_307);
    c_decl = zT_310;
    zT_311 = c_decl.child_1;
    if ((unsigned char)(zT_311 != (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_314 = env;
    zT_317 = c_decl.child_1;
    zT_319 = depth + (unsigned int)(1);
    env = zT_314;
    node_idx = zT_317;
    depth = zT_319;
    goto z_bb_0;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_327 = env;
    zT_328 = node.child_0;
    zT_330 = zF_0E4084E4_evalConstModuleOfEx(zT_327, zT_328);
    fa_mod_id = zT_330;
    if ((unsigned char)(fa_mod_id != (unsigned int)(0))) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_374 = node.kind;
    if ((unsigned char)(zT_374 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_115; else goto z_bb_116;
    z_bb_105:
    zT_334 = env->store;
    zT_335 = node_idx;
    zT_337 = zF_8BA26B9E_astStoreNodePayload(zT_334, zT_335);
    fa_field_id = zT_337;
    zT_338 = env->symbol_reg;
    zT_339 = fa_mod_id;
    zT_340 = fa_field_id;
    zT_342 = zF_A398987E_symbolRegistryQuali(zT_338, zT_339, zT_340);
    zT_343 = zT_342.has_value;
    if (zT_343) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_373.has_value = 0;
    return zT_373;
    z_bb_107:
    fa_sym = zT_342.value;
    zT_345 = env;
    zT_346 = node_idx;
    zT_347 = fa_field_id;
    zT_348 = fa_sym;
    zT_349 = zF_D43B245F_typeResolverCheckMe(zT_345, zT_346, zT_347, zT_348);
    if ((unsigned char)(!zT_349)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_351.has_value = 0;
    return zT_351;
    z_bb_110:
    zT_352 = fa_sym->flags;
    if ((unsigned char)((unsigned short)(zT_352 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_358 = env->store;
    zT_359 = fa_sym->decl_node;
    zT_362 = zF_FCDD1D35_astStoreNodeAt(zT_358, zT_359);
    fa_decl = zT_362;
    zT_363 = fa_decl.child_1;
    if ((unsigned char)(zT_363 != (unsigned int)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_108;
    z_bb_113:
    zT_366 = env;
    zT_369 = fa_decl.child_1;
    zT_371 = depth + (unsigned int)(1);
    env = zT_366;
    node_idx = zT_369;
    depth = zT_371;
    goto z_bb_0;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_379 = "@sizeOf";
    zT_381 = 7;
    zT_380.ptr = zT_379;
    zT_380.len = zT_381;
    s_size = zT_380;
    zT_383 = env->interner;
    zT_384 = s_size;
    zT_386 = zF_50C274AF_stringInternerInter(zT_383, zT_384);
    size_id = zT_386;
    zT_388 = "@alignOf";
    zT_390 = 8;
    zT_389.ptr = zT_388;
    zT_389.len = zT_390;
    s_align = zT_389;
    zT_392 = env->interner;
    zT_393 = s_align;
    zT_395 = zF_50C274AF_stringInternerInter(zT_392, zT_393);
    align_id = zT_395;
    zT_397 = "@bitSizeOf";
    zT_399 = 10;
    zT_398.ptr = zT_397;
    zT_398.len = zT_399;
    s_bitsz = zT_398;
    zT_401 = env->interner;
    zT_402 = s_bitsz;
    zT_404 = zF_50C274AF_stringInternerInter(zT_401, zT_402);
    bitsz_id = zT_404;
    zT_406 = "@intCast";
    zT_408 = 8;
    zT_407.ptr = zT_406;
    zT_407.len = zT_408;
    s_intc = zT_407;
    zT_410 = env->interner;
    zT_411 = s_intc;
    zT_413 = zF_50C274AF_stringInternerInter(zT_410, zT_411);
    intc_id = zT_413;
    zT_415 = "@as";
    zT_417 = 3;
    zT_416.ptr = zT_415;
    zT_416.len = zT_417;
    s_as = zT_416;
    zT_419 = env->interner;
    zT_420 = s_as;
    zT_422 = zF_50C274AF_stringInternerInter(zT_419, zT_420);
    as_id = zT_422;
    zT_424 = "@offsetOf";
    zT_426 = 9;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    s_off = zT_425;
    zT_428 = env->interner;
    zT_429 = s_off;
    zT_431 = zF_50C274AF_stringInternerInter(zT_428, zT_429);
    off_id = zT_431;
    zT_433 = "@bitOffsetOf";
    zT_435 = 12;
    zT_434.ptr = zT_433;
    zT_434.len = zT_435;
    s_bitoff = zT_434;
    zT_437 = env->interner;
    zT_438 = s_bitoff;
    zT_440 = zF_50C274AF_stringInternerInter(zT_437, zT_438);
    bitoff_id = zT_440;
    zT_442 = env->store;
    zT_443 = node_idx;
    zT_445 = zF_152E19CB_astStoreNodeExtraCh(zT_442, zT_443);
    bc_n = zT_445;
    zT_446 = node.child_0;
    if ((unsigned char)(zT_446 == intc_id)) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_739.has_value = 0;
    return zT_739;
    z_bb_117:
    zT_449 = node.child_0;
    zT_448 = zT_449 == as_id;
    goto z_bb_119;
    z_bb_118:
    zT_448 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_448) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_490 = node.child_0;
    if ((unsigned char)(zT_490 == size_id)) goto z_bb_131; else goto z_bb_130;
    z_bb_122:
    zT_454 = env;
    zT_457 = env->store;
    zT_458 = node_idx;
    zT_462 = zF_B10B1BC1_astStoreNodeExtraCh(zT_457, zT_458, (unsigned int)(0));
    zT_455 = zT_462;
    zT_465 = zF_F2107C15_resolveTypeExprFull(zT_454, zT_455, (unsigned int)(depth + (unsigned int)(1)));
    ct_tid = zT_465;
    if ((unsigned char)(ct_tid != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    zT_489.has_value = 0;
    return zT_489;
    z_bb_124:
    zT_469 = env;
    zT_472 = env->store;
    zT_473 = node_idx;
    zT_477 = zF_B10B1BC1_astStoreNodeExtraCh(zT_472, zT_473, (unsigned int)(1));
    zT_470 = zT_477;
    zT_480 = zF_382591DE_evalConstIntFull(zT_469, zT_470, (unsigned int)(depth + (unsigned int)(1)));
    cv_opt = zT_480;
    zT_481 = cv_opt.has_value;
    if (zT_481) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    goto z_bb_123;
    z_bb_126:
    cv = cv_opt.value;
    zT_483 = env->typereg;
    zT_484 = cv;
    zT_485 = ct_tid;
    zT_487 = zF_B28C4720_comptimeIntFitsType(zT_483, zT_484, zT_485);
    if (zT_487) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_488.has_value = 1;
    zT_488.value = cv;
    return zT_488;
    z_bb_129:
    goto z_bb_127;
    z_bb_130:
    zT_493 = node.child_0;
    zT_492 = zT_493 == align_id;
    goto z_bb_132;
    z_bb_131:
    zT_492 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_492) goto z_bb_134; else goto z_bb_133;
    z_bb_133:
    zT_496 = node.child_0;
    zT_495 = zT_496 == bitsz_id;
    goto z_bb_135;
    z_bb_134:
    zT_495 = 1;
    goto z_bb_135;
    z_bb_135:
    if (zT_495) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    if ((unsigned char)(bc_n >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_137:
    zT_616 = node.child_0;
    if ((unsigned char)(zT_616 == off_id)) goto z_bb_170; else goto z_bb_169;
    z_bb_138:
    zT_501 = env;
    zT_504 = env->store;
    zT_505 = node_idx;
    zT_509 = zF_B10B1BC1_astStoreNodeExtraCh(zT_504, zT_505, (unsigned int)(0));
    zT_502 = zT_509;
    zT_512 = zF_F2107C15_resolveTypeExprFull(zT_501, zT_502, (unsigned int)(depth + (unsigned int)(1)));
    bt_tid = zT_512;
    if ((unsigned char)(bt_tid != (unsigned int)(18))) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_615.has_value = 0;
    return zT_615;
    z_bb_140:
    zT_516 = env->typereg;
    zT_517 = zT_516->types_items;
    zT_518 = (unsigned int)bt_tid;
    zT_519 = zT_517[zT_518];
    bt_ty = zT_519;
    zT_520 = bt_ty.state;
    if ((unsigned char)(zT_520 != (unsigned char)(2))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_524 = bt_ty.kind;
    zT_523 = zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_144;
    z_bb_143:
    zT_523 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_523) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_528 = env->typereg;
    zT_529 = bt_tid;
    zT_533 = zF_3E55D0D5_layoutEnsure(zT_528, zT_529, (unsigned int)(0));
    (void)zT_533;
    zT_534 = env->typereg;
    zT_535 = zT_534->types_items;
    zT_536 = (unsigned int)bt_tid;
    zT_537 = zT_535[zT_536];
    bt_ty = zT_537;
    goto z_bb_146;
    z_bb_146:
    zT_539 = bt_ty.kind;
    zT_541 = zF_6AE4DFFC_evalConstScalarKind(zT_539);
    bt_foldable = zT_541;
    zT_542 = bt_ty.kind;
    if ((unsigned char)(zT_542 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_546 = 1;
    bt_foldable = zT_546;
    goto z_bb_148;
    z_bb_148:
    zT_547 = bt_ty.state;
    if ((unsigned char)(zT_547 == (unsigned char)(2))) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_550 = bt_foldable;
    goto z_bb_151;
    z_bb_150:
    zT_550 = 0;
    goto z_bb_151;
    z_bb_151:
    if (zT_550) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_551 = node.child_0;
    if ((unsigned char)(zT_551 == size_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_141;
    z_bb_154:
    zT_554 = bt_ty.size;
    zT_556 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_554));
    zT_557.has_value = 1;
    zT_557.value = zT_556;
    return zT_557;
    z_bb_155:
    zT_558 = node.child_0;
    if ((unsigned char)(zT_558 == align_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_561 = bt_ty.alignment;
    zT_563 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_561));
    zT_564.has_value = 1;
    zT_564.value = zT_563;
    return zT_564;
    z_bb_157:
    zT_566 = bt_ty.size;
    zT_568 = zT_566 * (unsigned int)(8);
    bt_bits = zT_568;
    zT_569 = env->typereg;
    zT_570 = bt_tid;
    zT_572 = zF_3290E9C4_typeRegistryIsInteg(zT_569, zT_570);
    if (zT_572) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_573 = env->typereg;
    zT_574 = bt_tid;
    zT_576 = zF_655972D5_typeRegistryIntWidt(zT_573, zT_574);
    zT_577 = (unsigned int)zT_576;
    bt_bits = zT_577;
    goto z_bb_159;
    z_bb_159:
    zT_578 = bt_ty.kind;
    if ((unsigned char)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_582 = env->typereg;
    zT_585 = env->typereg;
    zT_586 = bt_tid;
    zT_588 = zF_014D7530_typeRegistryEnumBac(zT_585, zT_586);
    zT_583 = zT_588;
    zT_589 = zF_655972D5_typeRegistryIntWidt(zT_582, zT_583);
    zT_590 = (unsigned int)zT_589;
    bt_bits = zT_590;
    goto z_bb_161;
    z_bb_161:
    zT_591 = bt_ty.kind;
    if ((unsigned char)(zT_591 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_595 = 1;
    bt_bits = zT_595;
    goto z_bb_163;
    z_bb_163:
    zT_596 = bt_ty.kind;
    if ((unsigned char)(zT_596 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_601 = bt_ty.flags;
    zT_600 = (unsigned char)(zT_601 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_166;
    z_bb_165:
    zT_600 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_600) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_606 = env->typereg;
    zT_607 = bt_tid;
    zT_609 = zF_CB27DBA4_typeRegistryGetPack(zT_606, zT_607);
    zT_610 = (unsigned int)zT_609;
    bt_bits = zT_610;
    goto z_bb_168;
    z_bb_168:
    zT_613 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)bt_bits));
    zT_614.has_value = 1;
    zT_614.value = zT_613;
    return zT_614;
    z_bb_169:
    zT_619 = node.child_0;
    zT_618 = zT_619 == bitoff_id;
    goto z_bb_171;
    z_bb_170:
    zT_618 = 1;
    goto z_bb_171;
    z_bb_171:
    if (zT_618) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_174; else goto z_bb_175;
    z_bb_173:
    zT_738.has_value = 0;
    return zT_738;
    z_bb_174:
    zT_624 = env;
    zT_627 = env->store;
    zT_628 = node_idx;
    zT_632 = zF_B10B1BC1_astStoreNodeExtraCh(zT_627, zT_628, (unsigned int)(0));
    zT_625 = zT_632;
    zT_635 = zF_F2107C15_resolveTypeExprFull(zT_624, zT_625, (unsigned int)(depth + (unsigned int)(1)));
    ot_tid = zT_635;
    if ((unsigned char)(ot_tid != (unsigned int)(18))) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    zT_737.has_value = 0;
    return zT_737;
    z_bb_176:
    zT_639 = env->typereg;
    zT_640 = zT_639->types_items;
    zT_641 = (unsigned int)ot_tid;
    zT_642 = zT_640[zT_641];
    ot_ty = zT_642;
    zT_643 = ot_ty.state;
    if ((unsigned char)(zT_643 == (unsigned char)(2))) goto z_bb_178; else goto z_bb_179;
    z_bb_177:
    goto z_bb_175;
    z_bb_178:
    zT_647 = ot_ty.kind;
    zT_646 = zT_647 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_180;
    z_bb_179:
    zT_646 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_646) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    fields = zT_652;
    zT_653 = env->typereg;
    zT_654 = ot_tid;
    zT_655 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_653, zT_654, zT_655);
    packed_fields = zT_659;
    zT_661 = env->typereg;
    zT_662 = ot_tid;
    zT_663 = &packed_fields;
    zT_666 = zF_7D87247C_typeRegistryGetPack(zT_661, zT_662, zT_663);
    has_pk = zT_666;
    zT_668 = env->store;
    zT_671 = env->store;
    zT_672 = node_idx;
    zT_676 = zF_B10B1BC1_astStoreNodeExtraCh(zT_671, zT_672, (unsigned int)(1));
    zT_669 = zT_676;
    zT_677 = zF_FCDD1D35_astStoreNodeAt(zT_668, zT_669);
    fname_node = zT_677;
    zT_678 = fname_node.kind;
    if ((unsigned char)(zT_678 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    goto z_bb_177;
    z_bb_183:
    zT_683 = env->store;
    zT_686 = env->store;
    zT_687 = node_idx;
    zT_691 = zF_B10B1BC1_astStoreNodeExtraCh(zT_686, zT_687, (unsigned int)(1));
    zT_684 = zT_691;
    zT_692 = zF_8BA26B9E_astStoreNodePayload(zT_683, zT_684);
    sv_idx = zT_692;
    zT_694 = env->store;
    zT_695 = zT_694->string_values;
    zT_696 = zT_695.items;
    zT_697 = (unsigned int)sv_idx;
    zT_698 = zT_696[zT_697];
    want_id = zT_698;
    zT_700 = 0;
    zT_701 = (unsigned int)zT_700;
    fi = zT_701;
    goto z_bb_185;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_703 = fields.len;
    if ((unsigned char)(fi < zT_703)) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_705 = fields.ptr;
    zT_706 = zT_705[fi];
    zT_707 = zT_706.name_id;
    if ((unsigned char)(zT_707 == want_id)) goto z_bb_189; else goto z_bb_190;
    z_bb_187:
    goto z_bb_184;
    z_bb_188:
    zT_734 = 1;
    zT_736 = fi + (unsigned int)((unsigned int)zT_734);
    fi = zT_736;
    goto z_bb_185;
    z_bb_189:
    zT_710 = fields.ptr;
    zT_711 = zT_710[fi];
    zT_712 = zT_711.offset;
    zT_713 = (zT_79FAE712_u64)zT_712;
    bo = zT_713;
    if (has_pk) goto z_bb_191; else goto z_bb_193;
    z_bb_190:
    goto z_bb_188;
    z_bb_191:
    zT_715 = 0;
    pk_bo = zT_715;
    zT_717 = packed_fields.len;
    if ((unsigned char)(fi < zT_717)) goto z_bb_194; else goto z_bb_195;
    z_bb_192:
    zT_731 = bo;
    zT_732 = zF_1EAA44E6_ciFromU64(zT_731);
    zT_733.has_value = 1;
    zT_733.value = zT_732;
    return zT_733;
    z_bb_193:
    zT_727 = node.child_0;
    if ((unsigned char)(zT_727 == bitoff_id)) goto z_bb_199; else goto z_bb_200;
    z_bb_194:
    zT_719 = packed_fields.ptr;
    zT_720 = zT_719[fi];
    zT_721 = zT_720.bit_offset;
    zT_722 = (zT_79FAE712_u64)zT_721;
    pk_bo = zT_722;
    goto z_bb_195;
    z_bb_195:
    zT_723 = node.child_0;
    if ((unsigned char)(zT_723 == bitoff_id)) goto z_bb_196; else goto z_bb_198;
    z_bb_196:
    bo = pk_bo;
    goto z_bb_197;
    z_bb_197:
    goto z_bb_192;
    z_bb_198:
    zT_726 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_726;
    goto z_bb_197;
    z_bb_199:
    zT_730 = bo * (zT_79FAE712_u64)(8);
    bo = zT_730;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_192;
}

/* evalConstIntToSize */
unsigned int zF_5C9D5CFF_evalConstIntToSize(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_6 = {0};
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt zT_8;
    int zT_9 = 0;
    int zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_79FAE712_u64 zT_14 = 0;
    zT_0163D9A4_ComptimeInt lim;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(4294967294u));
    lim = zT_6;
    zT_7 = v;
    zT_8 = lim;
    zT_9 = zF_6408F093_ciCmp(zT_7, zT_8);
    zT_10 = 0;
    if ((unsigned char)(zT_9 > zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_13 = v;
    zT_14 = zF_4F2C9C5D_ciToU64(zT_13);
    return (unsigned int)((unsigned int)zT_14);
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_45 = 0;
    unsigned int zT_48 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_58 = 0;
    zT_E53A25A2_Opt_203 zT_61 = {0};
    unsigned char zT_64;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0163D9A4_ComptimeInt zT_67;
    unsigned int zT_68;
    unsigned char zT_70 = 0;
    zT_7432B7FA_Opt_232 zT_72;
    unsigned char zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_75;
    unsigned int zT_76;
    unsigned char zT_77 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_F85C5DED_DiagnosticCollector* zT_82;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_97 = 0;
    zT_0163D9A4_ComptimeInt zT_99;
    unsigned int zT_100 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_E53A25A2_Opt_203 zT_106 = {0};
    unsigned char zT_107;
    zT_0163D9A4_ComptimeInt zT_108;
    zT_0163D9A4_ComptimeInt zT_110;
    zT_0163D9A4_ComptimeInt zT_111;
    unsigned int zT_112 = 0;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_0163D9A4_ComptimeInt v;
    unsigned int bc_n;
    unsigned int ic_tid;
    zT_E53A25A2_Opt_203 ic_v;
    zT_0163D9A4_ComptimeInt iv;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "@intCast";
    zT_21 = 8;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    s_intc = zT_20;
    zT_23 = env->interner;
    zT_24 = s_intc;
    zT_26 = zF_50C274AF_stringInternerInter(zT_23, zT_24);
    intc_id = zT_26;
    zT_27 = node.child_0;
    if ((unsigned char)(zT_27 == intc_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_103 = env;
    zT_104 = node_idx;
    zT_105 = depth;
    zT_106 = zF_382591DE_evalConstIntFull(zT_103, zT_104, zT_105);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_22; else goto z_bb_21;
    z_bb_7:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_152E19CB_astStoreNodeExtraCh(zT_30, zT_31);
    bc_n = zT_33;
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_37 = env;
    zT_40 = env->store;
    zT_41 = node_idx;
    zT_45 = zF_B10B1BC1_astStoreNodeExtraCh(zT_40, zT_41, (unsigned int)(0));
    zT_38 = zT_45;
    zT_48 = zF_F2107C15_resolveTypeExprFull(zT_37, zT_38, (unsigned int)(depth + (unsigned int)(1)));
    ic_tid = zT_48;
    zT_50 = env;
    zT_53 = env->store;
    zT_54 = node_idx;
    zT_58 = zF_B10B1BC1_astStoreNodeExtraCh(zT_53, zT_54, (unsigned int)(1));
    zT_51 = zT_58;
    zT_61 = zF_382591DE_evalConstIntFull(zT_50, zT_51, (unsigned int)(depth + (unsigned int)(1)));
    ic_v = zT_61;
    if ((unsigned char)(ic_tid != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_64 = ic_v.has_value;
    if (zT_64) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    iv = ic_v.value;
    zT_66 = env->typereg;
    zT_67 = iv;
    zT_68 = ic_tid;
    zT_70 = zF_B28C4720_comptimeIntFitsType(zT_66, zT_67, zT_68);
    if ((unsigned char)(!zT_70)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_72 = env->diag;
    zT_73 = zT_72.has_value;
    if (zT_73) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_99 = iv;
    zT_100 = zF_5C9D5CFF_evalConstIntToSize(zT_99);
    return zT_100;
    z_bb_17:
    dg = zT_72.value;
    zT_75 = dg;
    zT_76 = node_idx;
    zT_77 = zF_4DD9DB2D_diagnosticCollector(zT_75, zT_76);
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned int)(4294967295u);
    z_bb_19:
    zT_79 = "@intCast value does not fit the target type";
    zT_81 = 43;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    ic_msg = zT_80;
    zT_82 = dg;
    zT_85 = env->source_file_id;
    zT_86 = node.span_start;
    zT_93 = node.span_start;
    zT_94 = node.span_len;
    zT_88 = ic_msg;
    zT_97 = zF_C82559AC_diagnosticCollector(zT_82, (unsigned char)(0), (unsigned short)(3000), zT_85, zT_86, (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94)), zT_88);
    (void)zT_97;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    return (unsigned int)(4294967295u);
    z_bb_22:
    zT_110 = zT_106.value;
    zT_108 = zT_110;
    goto z_bb_23;
    z_bb_23:
    v = zT_108;
    zT_111 = v;
    zT_112 = zF_5C9D5CFF_evalConstIntToSize(zT_111);
    return zT_112;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_ABC1EBBE_TypeResolveEnv* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E53A25A2_Opt_203 zT_7 = {0};
    unsigned char zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_44E16D78_Opt_7 zT_10 = {0};
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt zT_12;
    unsigned char zT_13 = 0;
    zT_44E16D78_Opt_7 zT_15 = {0};
    zT_0163D9A4_ComptimeInt zT_16;
    zT_79FAE712_u64 zT_17 = 0;
    zT_C69B2266_i64 zT_18;
    zT_44E16D78_Opt_7 zT_19;
    zT_0163D9A4_ComptimeInt v;
    zT_4 = env;
    zT_5 = node_idx;
    zT_6 = depth;
    zT_7 = zF_382591DE_evalConstIntFull(zT_4, zT_5, zT_6);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_2:
    zT_11 = zT_7.value;
    zT_9 = zT_11;
    goto z_bb_3;
    z_bb_3:
    v = zT_9;
    zT_12 = v;
    zT_13 = zF_EF3A264A_comptimeIntFits64(zT_12);
    if ((unsigned char)(!zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_5:
    zT_16 = v;
    zT_17 = zF_4F2C9C5D_ciToU64(zT_16);
    zT_18 = (zT_C69B2266_i64)zT_17;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
}

/* symbolLookupAllModules */
zT_D0942820_Opt_894 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_D0942820_Opt_894 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_19;
    zT_D0942820_Opt_894 zT_20 = {0};
    unsigned int si;
    zT_D0942820_Opt_894 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* symbolTypeIdOfModule */
unsigned int zF_66C54985_symbolTypeIdOfModul(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int module_id, unsigned int name_id) {
    zT_3D7259E2_SymbolRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D0942820_Opt_894 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_10;
    unsigned int zT_13;
    zT_3A105EF1_Symbol* s;
    zT_3 = env->symbol_reg;
    zT_4 = module_id;
    zT_5 = name_id;
    zT_7 = zF_A398987E_symbolRegistryQuali(zT_3, zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = zT_7.value;
    zT_10 = s->type_id;
    if ((unsigned char)(zT_10 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return (unsigned int)(0);
    z_bb_3:
    zT_13 = s->type_id;
    return zT_13;
    z_bb_4:
    goto z_bb_2;
}

/* symbolLookupTypeAllModules */
unsigned int zF_DE1472AF_symbolLookupTypeAll(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_ABC1EBBE_TypeResolveEnv* zT_10;
    unsigned int zT_12;
    unsigned int zT_14 = 0;
    int zT_17;
    unsigned int zT_19;
    unsigned int si;
    unsigned int t;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env;
    zT_12 = name_id;
    zT_14 = zF_66C54985_symbolTypeIdOfModul(zT_10, (unsigned int)((unsigned int)si), zT_12);
    t = zT_14;
    if ((unsigned char)(t != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return t;
    z_bb_6:
    goto z_bb_4;
}

/* enumMembersResolve */
unsigned char zF_0FFDEDBD_enumMembersResolve(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node, unsigned char append, unsigned int mstart, unsigned char strict, unsigned char check_only, unsigned int* out_count, unsigned int* out_fail_node, unsigned int* out_fail_kind) {
    zT_29C26066_Arr_zT_C69B2266_i64 zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_C69B2266_i64 zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    zT_22A7C88B_AstNode zT_35 = {0};
    zT_8143F551_AstKind zT_36;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv* zT_45;
    unsigned int zT_46;
    zT_44E16D78_Opt_7 zT_50 = {0};
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned char zT_57;
    unsigned int zT_60;
    int zT_62;
    unsigned int zT_63;
    zT_C69B2266_i64 zT_66 = 0;
    unsigned int zT_67;
    zT_C69B2266_i64 zT_68;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_D96DCDF2_EnumMember* zT_70;
    unsigned int zT_73;
    zT_D96DCDF2_EnumMember zT_74;
    zT_C69B2266_i64 zT_75;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    unsigned int zT_82 = 0;
    int zT_85;
    unsigned int zT_87;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D96DCDF2_EnumMember zT_92;
    zT_D96DCDF2_EnumMember zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_103 = 0;
    unsigned int zT_104 = 0;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D96DCDF2_EnumMember* zT_106;
    zT_D96DCDF2_EnumMember* zT_110;
    int zT_111;
    unsigned int zT_113;
    zT_C69B2266_i64 zT_115;
    int zT_116;
    unsigned int zT_118;
    zT_29C26066_Arr_zT_C69B2266_i64 seen;
    unsigned int children_n;
    zT_C69B2266_i64 auto_val;
    unsigned int k;
    unsigned int i;
    zT_22A7C88B_AstNode mnode;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int dj_lim;
    unsigned int dj;
    zT_C69B2266_i64 prev;
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        seen[_i] = zT_10[_i];
        _i++;
    }
}
    zT_12 = env->store;
    zT_13 = enum_node;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    children_n = zT_15;
    zT_17 = 0;
    auto_val = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    k = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < children_n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_26 = env->store;
    zT_29 = env->store;
    zT_30 = enum_node;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_29, zT_30, (unsigned int)((unsigned int)i));
    zT_27 = zT_34;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    mnode = zT_35;
    zT_36 = mnode.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    *out_count = k;
    return (unsigned char)(1);
    z_bb_4:
    zT_116 = 1;
    zT_118 = i + (unsigned int)((unsigned int)zT_116);
    i = zT_118;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    mval = auto_val;
    zT_41 = mnode.child_1;
    if ((unsigned char)(zT_41 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_45 = env;
    zT_46 = mnode.child_1;
    zT_50 = zF_FFFAAD16_evalConstI64Full(zT_45, zT_46, (unsigned int)(0));
    ev_opt = zT_50;
    zT_51 = ev_opt.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    if (strict) goto z_bb_14; else goto z_bb_15;
    z_bb_9:
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    if (strict) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_53 = mnode.child_1;
    *out_fail_node = zT_53;
    *out_fail_kind = (unsigned int)(1);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    dj_lim = k;
    if (check_only) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if (check_only) goto z_bb_30; else goto z_bb_32;
    z_bb_16:
    zT_57 = dj_lim > (unsigned int)(256);
    goto z_bb_18;
    z_bb_17:
    zT_57 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_60 = 256;
    dj_lim = zT_60;
    goto z_bb_20;
    z_bb_20:
    zT_62 = 0;
    zT_63 = (unsigned int)zT_62;
    dj = zT_63;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(dj < dj_lim)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    prev = zT_66;
    if (check_only) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_15;
    z_bb_24:
    zT_85 = 1;
    zT_87 = dj + (unsigned int)((unsigned int)zT_85);
    dj = zT_87;
    goto z_bb_21;
    z_bb_25:
    zT_67 = (unsigned int)dj;
    zT_68 = seen[zT_67];
    prev = zT_68;
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(prev == mval)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_69 = env->typereg;
    zT_70 = zT_69->em_items;
    zT_73 = (unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)dj);
    zT_74 = zT_70[zT_73];
    zT_75 = zT_74.value;
    prev = zT_75;
    goto z_bb_26;
    z_bb_28:
    zT_77 = env->store;
    zT_78 = enum_node;
    zT_82 = zF_B10B1BC1_astStoreNodeExtraCh(zT_77, zT_78, (unsigned int)((unsigned int)i));
    *out_fail_node = zT_82;
    *out_fail_kind = (unsigned int)(2);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    if ((unsigned char)(k < (unsigned int)(256))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_111 = 1;
    zT_113 = k + (unsigned int)((unsigned int)zT_111);
    k = zT_113;
    zT_115 = mval + (zT_C69B2266_i64)(1);
    auto_val = zT_115;
    goto z_bb_4;
    z_bb_32:
    if (append) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    zT_90 = (unsigned int)k;
    seen[zT_90] = mval;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_91 = env->typereg;
    zT_95 = env->store;
    zT_98 = env->store;
    zT_99 = enum_node;
    zT_103 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)i));
    zT_96 = zT_103;
    zT_104 = zF_8BA26B9E_astStoreNodePayload(zT_95, zT_96);
    zT_94.name_id = zT_104;
    zT_94.value = mval;
    zT_92 = zT_94;
    zF_157DA7BF_emAppend(zT_91, zT_92);
    goto z_bb_36;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_105 = env->typereg;
    zT_106 = zT_105->em_items;
    zT_110 = zT_106 + (unsigned int)((unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)k));
    zT_110->value = mval;
    goto z_bb_36;
}

/* reportEnumWalkFailure */
void zF_52B56F5B_reportEnumWalkFailu(zT_F85C5DED_DiagnosticCollector* diag, zT_6B0A7D14_AstStore* store, unsigned int source_file_id, unsigned int fail_node, unsigned int fail_kind) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_6 = store;
    zT_7 = fail_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    fn_ = zT_8;
    zT_10 = fn_.span_start;
    sp = zT_10;
    zT_12 = fn_.span_len;
    zT_14 = sp + (unsigned int)((unsigned int)zT_12);
    ep = zT_14;
    zT_16 = "enum member value is not a comptime-known integer expression";
    zT_18 = 60;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    msg = zT_17;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = "duplicate enum tag value (tag values must be unique)";
    zT_23 = 52;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    msg = zT_22;
    goto z_bb_2;
    z_bb_2:
    zT_24 = diag;
    zT_27 = source_file_id;
    zT_28 = sp;
    zT_29 = ep;
    zT_30 = msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    return;
}

/* enumReevaluateAll */
void zF_153D24FD_enumReevaluateAll(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_8 = {0};
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    zT_6E8D187B_ModuleEntry zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_8143F551_AstKind zT_43;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_51;
    zT_8143F551_AstKind zT_52;
    unsigned char zT_56;
    unsigned int zT_57;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_72 = 0;
    zT_6E8D187B_ModuleEntry* zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_78;
    zT_79FAE712_u64 zT_83;
    zT_939EE900_Arr_unsigned_int_1 zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_79FAE712_u64 zT_89;
    zT_BAEE192E_Opt_10 zT_90 = {0};
    unsigned char zT_91;
    int zT_93;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_98;
    zT_D155D06D_Type* zT_101;
    unsigned int zT_102;
    zT_D155D06D_Type zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    zT_457ECFEE_EnumPayload* zT_109;
    unsigned short zT_110;
    unsigned int zT_111;
    zT_457ECFEE_EnumPayload zT_112;
    zT_ABC1EBBE_TypeResolveEnv zT_114;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    zT_6E8D187B_ModuleEntry zT_119;
    unsigned int zT_120;
    zT_7432B7FA_Opt_232 zT_121;
    zT_02CE50E0_Opt_403 zT_122 = {0};
    zT_08CE5A52_Opt_405 zT_123 = {0};
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_ABC1EBBE_TypeResolveEnv* zT_133;
    unsigned int zT_134;
    unsigned int zT_136;
    unsigned int* zT_139;
    unsigned int* zT_140;
    unsigned int* zT_141;
    unsigned char zT_150 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_152;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_6E8D187B_ModuleEntry* zT_157;
    zT_6E8D187B_ModuleEntry zT_158;
    int zT_160;
    unsigned int zT_162;
    int zT_163;
    unsigned int zT_165;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    zT_939EE900_Arr_unsigned_int_1 tid_box;
    unsigned int t;
    unsigned int tid;
    zT_D155D06D_Type ety;
    zT_457ECFEE_EnumPayload ep;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_7 = module_reg;
    zT_8 = zF_3452C137_moduleRegistryGetMo(zT_7);
    mods = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    mi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    if ((unsigned char)(mi < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = mods.ptr;
    zT_17 = zT_16[mi];
    zT_18 = zT_17.ast_root;
    ast_root = zT_18;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_163 = 1;
    zT_165 = mi + (unsigned int)((unsigned int)zT_163);
    mi = zT_165;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_22 = store;
    zT_23 = ast_root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_22, zT_23);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < decls_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = store;
    zT_31 = ast_root;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_30, zT_31, (unsigned int)((unsigned int)di));
    decl_idx = zT_34;
    zT_36 = store;
    zT_37 = decl_idx;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    dnode = zT_38;
    zT_40 = 0;
    enum_node = zT_40;
    zT_42 = 0;
    enum_name_id = zT_42;
    zT_43 = dnode.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_160 = 1;
    zT_162 = di + (unsigned int)((unsigned int)zT_160);
    di = zT_162;
    goto z_bb_7;
    z_bb_11:
    zT_48 = dnode.child_1;
    zT_47 = zT_48 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_47 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_47) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    enum_node = decl_idx;
    zT_51 = dnode.child_0;
    enum_name_id = zT_51;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_16:
    zT_52 = dnode.kind;
    if ((unsigned char)(zT_52 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_57 = dnode.child_1;
    zT_56 = zT_57 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_56 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_56) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = store;
    zT_62 = dnode.child_1;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_61, zT_62);
    inn = zT_64;
    zT_65 = inn.kind;
    if ((unsigned char)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_69 = dnode.child_1;
    enum_node = zT_69;
    zT_70 = store;
    zT_71 = decl_idx;
    zT_72 = zF_8BA26B9E_astStoreNodePayload(zT_70, zT_71);
    enum_name_id = zT_72;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    goto z_bb_10;
    z_bb_25:
    zT_76 = mods.ptr;
    zT_77 = zT_76[mi];
    zT_78 = zT_77.id;
    zT_83 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_78) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_83;
    zT_86 = 0;
    zT_87 = 0;
    zT_85[zT_87] = zT_86;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        tid_box[_i] = zT_85[_i];
        _i++;
    }
}
    zT_88 = typereg;
    zT_89 = key;
    zT_90 = zF_0EB68360_nameCacheGet(zT_88, zT_89);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = zT_90.value;
    zT_93 = 0;
    tid_box[zT_93] = t;
    goto z_bb_27;
    z_bb_27:
    zT_95 = 0;
    zT_96 = tid_box[zT_95];
    tid = zT_96;
    zT_98 = typereg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_98)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_101 = typereg->types_items;
    zT_102 = (unsigned int)tid;
    zT_103 = zT_101[zT_102];
    ety = zT_103;
    zT_104 = ety.kind;
    if ((unsigned char)(zT_104 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_10;
    z_bb_32:
    zT_109 = typereg->en_items;
    zT_110 = ety.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    ep = zT_112;
    zT_114.store = store;
    zT_114.typereg = typereg;
    zT_114.symbol_reg = symbol_reg;
    zT_114.interner = interner;
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_114.module_id = zT_117;
    zT_118 = mods.ptr;
    zT_119 = zT_118[mi];
    zT_120 = zT_119.source_file_id;
    zT_114.source_file_id = zT_120;
    zT_121.has_value = 1;
    zT_121.value = diag;
    zT_114.diag = zT_121;
    zT_122.has_value = 0;
    zT_114.local_consts = zT_122;
    zT_123.has_value = 0;
    zT_114.local_types = zT_123;
    env = zT_114;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    count = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    fail_node = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    fail_kind = zT_132;
    zT_133 = &env;
    zT_134 = enum_node;
    zT_136 = ep.members_start;
    zT_139 = &count;
    zT_140 = &fail_node;
    zT_141 = &fail_kind;
    zT_150 = zF_0FFDEDBD_enumMembersResolve(zT_133, zT_134, (unsigned char)(0), zT_136, (unsigned char)(1), (unsigned char)(0), zT_139, zT_140, zT_141);
    if ((unsigned char)(!zT_150)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_152 = diag;
    zT_153 = store;
    zT_157 = mods.ptr;
    zT_158 = zT_157[mi];
    zT_154 = zT_158.source_file_id;
    zT_155 = fail_node;
    zT_156 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_152, zT_153, zT_154, zT_155, zT_156);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_10;
}

/* containerAnonNameId */
unsigned int zF_27A59B24_containerAnonNameId(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_3;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    unsigned int zT_17;
    zT_4428DEE2_Arr_unsigned_char_2 zT_19;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_22;
    int zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_28;
    int zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int zT_45;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    zT_5826BFC7_Arr_unsigned_char_1 idb;
    unsigned int idl;
    unsigned int ids;
    zT_4428DEE2_Arr_unsigned_char_2 nm;
    unsigned int di;
    unsigned int namelen;
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        idb[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = node_idx;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)idb) + zT_9;
    zT_11 = (unsigned int)(12) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_6 = zT_12;
    zT_13 = zF_A7504564_itoa(zT_5, zT_6);
    idl = zT_13;
    zT_17 = (unsigned int)(11) - (unsigned int)((unsigned int)idl);
    ids = zT_17;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_19[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        nm[_i] = zT_19[_i];
        _i++;
    }
}
    zT_20 = 97;
    zT_21 = 0;
    nm[zT_21] = zT_20;
    zT_22 = 110;
    zT_23 = 1;
    nm[zT_23] = zT_22;
    zT_24 = 111;
    zT_25 = 2;
    nm[zT_25] = zT_24;
    zT_26 = 110;
    zT_27 = 3;
    nm[zT_27] = zT_26;
    zT_28 = 95;
    zT_29 = 4;
    nm[zT_29] = zT_28;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    di = zT_32;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(di < (unsigned int)((unsigned int)idl))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_35 = ids + di;
    zT_36 = idb[zT_35];
    zT_38 = (unsigned int)(5) + di;
    nm[zT_38] = zT_36;
    goto z_bb_4;
    z_bb_3:
    zT_45 = (unsigned int)(5) + (unsigned int)((unsigned int)idl);
    namelen = zT_45;
    zT_46 = env->interner;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)nm) + zT_51;
    zT_53 = namelen - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_47 = zT_54;
    zT_55 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    return zT_55;
    z_bb_4:
    zT_39 = 1;
    zT_41 = di + (unsigned int)((unsigned int)zT_39);
    di = zT_41;
    goto z_bb_1;
}

/* isContainerDeclKind */
unsigned char zF_82C2F046_isContainerDeclKind(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    return zT_12;
}

/* isCompoundTypeExprKind */
unsigned char zF_599C0D79_isCompoundTypeExprK(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    return zT_24;
}

/* containerFieldCount */
unsigned int zF_3B3163AB_containerFieldCount(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    unsigned int zT_9 = 0;
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_21 = 0;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    int zT_30;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_35;
    unsigned int count;
    unsigned int children_n;
    unsigned int i;
    unsigned int child;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    count = zT_4;
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_152E19CB_astStoreNodeExtraCh(zT_6, zT_7);
    children_n = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = env->store;
    zT_17 = node_idx;
    zT_21 = zF_B10B1BC1_astStoreNodeExtraCh(zT_16, zT_17, (unsigned int)((unsigned int)i));
    child = zT_21;
    zT_22 = env->store;
    zT_23 = child;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_26 = zT_25.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return count;
    z_bb_4:
    zT_33 = 1;
    zT_35 = i + (unsigned int)((unsigned int)zT_33);
    i = zT_35;
    goto z_bb_1;
    z_bb_5:
    zT_30 = 1;
    zT_32 = count + (unsigned int)((unsigned int)zT_30);
    count = zT_32;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* tupleElemArrayUnsupported */
unsigned char zF_E2A017C6_tupleElemArrayUnsup(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int elem_tid, unsigned int mark_node) {
    unsigned char zT_5;
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_7432B7FA_Opt_232 zT_23;
    unsigned char zT_24;
    zT_F85C5DED_DiagnosticCollector* zT_26;
    unsigned int zT_27;
    unsigned char zT_28 = 0;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_33 = {0};
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_53 = 0;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    if ((unsigned char)(elem_tid == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = elem_tid == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_10 = env->typereg;
    zT_11 = zT_10->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)elem_tid) >= zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_14 = env->typereg;
    zT_15 = zT_14->types_items;
    zT_16 = (unsigned int)elem_tid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_23 = env->diag;
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    diag = zT_23.value;
    zT_26 = diag;
    zT_27 = mark_node;
    zT_28 = zF_4DD9DB2D_diagnosticCollector(zT_26, zT_27);
    if (zT_28) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_30 = env->store;
    zT_31 = mark_node;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    node = zT_33;
    zT_35 = "tuple types with array elements are not supported";
    zT_37 = 49;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    msg = zT_36;
    zT_38 = diag;
    zT_41 = env->source_file_id;
    zT_42 = node.span_start;
    zT_49 = node.span_start;
    zT_50 = node.span_len;
    zT_44 = msg;
    zT_53 = zF_C82559AC_diagnosticCollector(zT_38, (unsigned char)(0), (unsigned short)(3000), zT_41, zT_42, (unsigned int)(zT_49 + (unsigned int)((unsigned int)zT_50)), zT_44);
    (void)zT_53;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* validateLocalEnum */
void zF_9084D8CB_validateLocalEnum(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node) {
    zT_7432B7FA_Opt_232 zT_5;
    unsigned char zT_6;
    zT_F85C5DED_DiagnosticCollector* zT_7;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_10;
    unsigned char zT_11 = 0;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    unsigned int zT_23;
    unsigned int* zT_28;
    unsigned int* zT_29;
    unsigned int* zT_30;
    unsigned char zT_38 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_F85C5DED_DiagnosticCollector* diag;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = env->diag;
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    return;
    z_bb_4:
    zT_7 = zT_5.value;
    goto z_bb_5;
    z_bb_5:
    diag = zT_7;
    zT_9 = diag;
    zT_10 = enum_node;
    zT_11 = zF_4DD9DB2D_diagnosticCollector(zT_9, zT_10);
    if ((unsigned char)(!zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    count = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fail_node = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    fail_kind = zT_21;
    zT_22 = env;
    zT_23 = enum_node;
    zT_28 = &count;
    zT_29 = &fail_node;
    zT_30 = &fail_kind;
    zT_38 = zF_0FFDEDBD_enumMembersResolve(zT_22, zT_23, (unsigned char)(0), (unsigned int)(0), (unsigned char)(1), (unsigned char)(1), zT_28, zT_29, zT_30);
    if ((unsigned char)(!zT_38)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = diag;
    zT_41 = env->store;
    zT_42 = env->source_file_id;
    zT_43 = fail_node;
    zT_44 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_40, zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    return;
}

/* registerContainerType */
unsigned int zF_FE81311F_registerContainerTy(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, zT_8143F551_AstKind kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_12;
    unsigned int zT_13;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_36 = 0;
    unsigned char zT_39;
    zT_ABC1EBBE_TypeResolveEnv* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_7432B7FA_Opt_232 zT_45;
    unsigned char zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    zT_33EF6BFB_TypeKind zT_70;
    unsigned char zT_71;
    int zT_75;
    zT_33EF6BFB_TypeKind zT_77;
    unsigned char zT_84;
    int zT_88;
    zT_33EF6BFB_TypeKind zT_90;
    unsigned char zT_93;
    int zT_95;
    int zT_97;
    zT_33EF6BFB_TypeKind zT_99;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_111;
    zT_33EF6BFB_TypeKind zT_112;
    unsigned int zT_115 = 0;
    unsigned char zT_119;
    unsigned char zT_123;
    unsigned char zT_124;
    zT_338B7C76_TypeRegistry* zT_130;
    unsigned int zT_131;
    unsigned char zT_136;
    unsigned char zT_137;
    int zT_141;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    zT_6B0A7D14_AstStore* zT_150;
    unsigned int zT_151;
    unsigned int zT_153 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_155;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_157;
    int zT_159;
    unsigned int zT_160;
    int zT_162;
    unsigned int zT_163;
    unsigned char zT_166;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_175 = 0;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_22A7C88B_AstNode zT_180 = {0};
    zT_8143F551_AstKind zT_181;
    zT_ABC1EBBE_TypeResolveEnv* zT_185;
    unsigned int zT_186;
    unsigned int zT_191 = 0;
    int zT_192;
    unsigned int zT_194;
    int zT_195;
    unsigned int zT_197;
    zT_338B7C76_TypeRegistry* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    int zT_205;
    unsigned int zT_206;
    zT_ABC1EBBE_TypeResolveEnv* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_213 = 0;
    zT_338B7C76_TypeRegistry* zT_214;
    unsigned int zT_215;
    int zT_218;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_666DC2E1_TuplePayload zT_222;
    zT_666DC2E1_TuplePayload zT_224;
    unsigned int zT_225;
    unsigned short zT_226;
    zT_338B7C76_TypeRegistry* zT_228;
    unsigned int zT_229;
    unsigned int zT_232;
    zT_338B7C76_TypeRegistry* zT_234;
    zT_D155D06D_Type* zT_235;
    unsigned int zT_236;
    zT_D155D06D_Type zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    unsigned short zT_243 = 0;
    zT_338B7C76_TypeRegistry* zT_244;
    zT_D155D06D_Type* zT_245;
    unsigned int zT_246;
    zT_6B0A7D14_AstStore* zT_250;
    unsigned int zT_251;
    unsigned int zT_253 = 0;
    zT_6B0A7D14_AstStore* zT_257;
    unsigned int zT_258;
    unsigned int zT_260 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_262;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_264;
    int zT_266;
    unsigned int zT_267;
    int zT_269;
    unsigned int zT_270;
    unsigned char zT_273;
    zT_6B0A7D14_AstStore* zT_277;
    unsigned int zT_278;
    unsigned int zT_282 = 0;
    zT_6B0A7D14_AstStore* zT_284;
    unsigned int zT_285;
    zT_22A7C88B_AstNode zT_287 = {0};
    zT_8143F551_AstKind zT_288;
    zT_ABC1EBBE_TypeResolveEnv* zT_292;
    unsigned int zT_293;
    unsigned int zT_298 = 0;
    zT_6B0A7D14_AstStore* zT_299;
    unsigned int zT_300;
    unsigned int zT_302 = 0;
    int zT_303;
    unsigned int zT_305;
    int zT_306;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    int zT_316;
    unsigned int zT_317;
    zT_338B7C76_TypeRegistry* zT_319;
    zT_2DF01B61_FieldEntry zT_320;
    zT_2DF01B61_FieldEntry zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    int zT_326;
    unsigned int zT_328;
    zT_338B7C76_TypeRegistry* zT_329;
    zT_406493CE_StructPayload zT_330;
    zT_406493CE_StructPayload zT_332;
    unsigned int zT_333;
    unsigned short zT_334;
    zT_338B7C76_TypeRegistry* zT_336;
    unsigned int zT_337;
    unsigned int zT_340;
    zT_338B7C76_TypeRegistry* zT_342;
    zT_D155D06D_Type* zT_343;
    unsigned int zT_344;
    zT_D155D06D_Type zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned int zT_347;
    unsigned char* zT_348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_349;
    unsigned int zT_350;
    unsigned short zT_351 = 0;
    zT_338B7C76_TypeRegistry* zT_352;
    zT_D155D06D_Type* zT_353;
    unsigned int zT_354;
    zT_6B0A7D14_AstStore* zT_358;
    unsigned int zT_359;
    unsigned int zT_361 = 0;
    zT_6B0A7D14_AstStore* zT_365;
    unsigned int zT_366;
    unsigned int zT_368 = 0;
    int zT_369;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_372;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_374;
    int zT_376;
    unsigned int zT_377;
    int zT_379;
    unsigned int zT_380;
    unsigned char zT_383;
    zT_6B0A7D14_AstStore* zT_387;
    unsigned int zT_388;
    unsigned int zT_392 = 0;
    zT_6B0A7D14_AstStore* zT_394;
    unsigned int zT_395;
    zT_22A7C88B_AstNode zT_397 = {0};
    zT_8143F551_AstKind zT_398;
    zT_ABC1EBBE_TypeResolveEnv* zT_402;
    unsigned int zT_403;
    unsigned int zT_408 = 0;
    zT_6B0A7D14_AstStore* zT_409;
    unsigned int zT_410;
    unsigned int zT_412 = 0;
    int zT_413;
    unsigned int zT_415;
    int zT_416;
    unsigned int zT_418;
    zT_338B7C76_TypeRegistry* zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    int zT_424;
    unsigned int zT_425;
    zT_338B7C76_TypeRegistry* zT_427;
    zT_2DF01B61_FieldEntry zT_428;
    zT_2DF01B61_FieldEntry zT_430;
    unsigned int zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    int zT_434;
    unsigned int zT_436;
    unsigned char zT_437;
    int zT_439;
    int zT_441;
    zT_338B7C76_TypeRegistry* zT_443;
    zT_54FF90FA_TaggedUnionPayload zT_444;
    zT_54FF90FA_TaggedUnionPayload zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    unsigned short zT_449;
    zT_338B7C76_TypeRegistry* zT_451;
    unsigned int zT_452;
    unsigned int zT_455;
    zT_338B7C76_TypeRegistry* zT_457;
    zT_D155D06D_Type* zT_458;
    unsigned int zT_459;
    zT_D155D06D_Type zT_460;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_461;
    unsigned int zT_462;
    unsigned char* zT_463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    unsigned int zT_465;
    unsigned short zT_466 = 0;
    zT_338B7C76_TypeRegistry* zT_467;
    zT_D155D06D_Type* zT_468;
    unsigned int zT_469;
    zT_338B7C76_TypeRegistry* zT_470;
    zT_AF9231A2_UnionPayload zT_471;
    zT_AF9231A2_UnionPayload zT_473;
    unsigned int zT_474;
    unsigned short zT_475;
    unsigned int zT_476;
    zT_338B7C76_TypeRegistry* zT_478;
    unsigned int zT_479;
    unsigned int zT_482;
    zT_338B7C76_TypeRegistry* zT_484;
    zT_D155D06D_Type* zT_485;
    unsigned int zT_486;
    zT_D155D06D_Type zT_487;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_488;
    unsigned int zT_489;
    unsigned char* zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned int zT_492;
    unsigned short zT_493 = 0;
    zT_338B7C76_TypeRegistry* zT_494;
    zT_D155D06D_Type* zT_495;
    unsigned int zT_496;
    zT_338B7C76_TypeRegistry* zT_497;
    zT_6B0A7D14_AstStore* zT_498;
    zT_8143F551_AstKind zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    zT_3D7259E2_SymbolRegistry* zT_502;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_BAEE192E_Opt_10 existing;
    unsigned int e;
    zT_33EF6BFB_TypeKind type_kind;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_msg;
    unsigned int tid;
    unsigned int tup_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_ety;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_enode;
    unsigned int tup_ec;
    unsigned int tup_i;
    unsigned int tup_child;
    zT_22A7C88B_AstNode tup_fd;
    unsigned int tup_estart;
    unsigned int tup_j;
    unsigned int tup_tidx;
    zT_D155D06D_Type tup_ty;
    unsigned int sd_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    unsigned int sd_child;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned int un_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fnm;
    unsigned int un_fc;
    unsigned int un_i;
    unsigned int un_child;
    zT_22A7C88B_AstNode un_fd;
    unsigned int un_fstart;
    unsigned int un_j;
    unsigned int un_tu_idx;
    zT_D155D06D_Type un_tu_ty;
    unsigned int un_un_idx;
    zT_D155D06D_Type un_un_ty;
    zT_5 = env->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = env;
    zT_13 = node_idx;
    zF_9084D8CB_validateLocalEnum(zT_12, zT_13);
    goto z_bb_2;
    z_bb_2:
    zT_15 = env;
    zT_16 = node_idx;
    zT_17 = zF_27A59B24_containerAnonNameId(zT_15, zT_16);
    name_id = zT_17;
    zT_19 = env->typereg;
    zT_23 = zF_0EB68360_nameCacheGet(zT_19, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    existing = zT_23;
    zT_24 = existing.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    e = existing.value;
    return e;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_29 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_7;
    z_bb_6:
    zT_29 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = node_idx;
    zT_36 = zF_8BA26B9E_astStoreNodePayload(zT_33, zT_34);
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
switch (kind) {
case 3: goto z_bb_17;
case 4: goto z_bb_18;
case 5: goto z_bb_19;
case 9: goto z_bb_20;
default: goto z_bb_21;
}
    z_bb_10:
    zT_40 = env;
    zT_41 = node_idx;
    zT_42 = zF_3B3163AB_containerFieldCount(zT_40, zT_41);
    zT_39 = zT_42 > (unsigned int)(32);
    goto z_bb_12;
    z_bb_11:
    zT_39 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_39) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = env->diag;
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    diag = zT_45.value;
    zT_49 = "aggregate type has more than 32 fields, which is not supported";
    zT_51 = 62;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    fc_msg = zT_50;
    zT_52 = diag;
    zT_55 = env->source_file_id;
    zT_56 = node.span_start;
    zT_63 = node.span_start;
    zT_64 = node.span_len;
    zT_58 = fc_msg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_52, (unsigned char)(0), (unsigned short)(3000), zT_55, zT_56, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_58);
    (void)zT_67;
    goto z_bb_16;
    z_bb_16:
    return (unsigned int)(18);
    z_bb_17:
    zT_71 = node.flags;
    zT_75 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_71) & (unsigned short)(32)) != zT_75)) goto z_bb_24; else goto z_bb_25;
    z_bb_18:
    zT_70 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_23;
    z_bb_19:
    zT_84 = node.flags;
    zT_88 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_84) & (unsigned short)(16)) != zT_88)) goto z_bb_27; else goto z_bb_28;
    z_bb_20:
    zT_70 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_23;
    z_bb_21:
    zT_70 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_23;
    z_bb_23:
    type_kind = zT_70;
    zT_109 = env->typereg;
    zT_111 = name_id;
    zT_112 = type_kind;
    zT_115 = zF_3A64E2E0_typeRegistryRegiste(zT_109, (unsigned int)(0), zT_111, zT_112);
    tid = zT_115;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_34; else goto z_bb_33;
    z_bb_24:
    zT_77 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_26;
    z_bb_25:
    zT_77 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_26;
    z_bb_26:
    zT_70 = zT_77;
    goto z_bb_23;
    z_bb_27:
    zT_90 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_29;
    z_bb_28:
    zT_93 = node.flags;
    zT_95 = 1;
    zT_97 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_93) & zT_95) != zT_97)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_70 = zT_90;
    goto z_bb_23;
    z_bb_30:
    zT_99 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_32;
    z_bb_31:
    zT_99 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_32;
    z_bb_32:
    zT_90 = zT_99;
    goto z_bb_29;
    z_bb_33:
    zT_119 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_35;
    z_bb_34:
    zT_119 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_119) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_124 = node.flags;
    zT_123 = (unsigned short)((unsigned short)((unsigned short)zT_124) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_38;
    z_bb_37:
    zT_123 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_123) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_130 = env->typereg;
    zT_131 = tid;
    zF_52816016_typeRegistrySetPack(zT_130, zT_131);
    goto z_bb_40;
    z_bb_40:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_137 = node.flags;
    zT_141 = 0;
    zT_136 = (unsigned short)((unsigned short)((unsigned short)zT_137) & (unsigned short)(32)) != zT_141;
    goto z_bb_43;
    z_bb_42:
    zT_136 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_136) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_143 = env->store;
    zT_144 = node_idx;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_143, zT_144);
    if ((unsigned char)(zT_146 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    return tid;
    z_bb_46:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_64; else goto z_bb_66;
    z_bb_47:
    zT_150 = env->store;
    zT_151 = node_idx;
    zT_153 = zF_152E19CB_astStoreNodeExtraCh(zT_150, zT_151);
    tup_children_n = zT_153;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_155[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_ety[_i] = zT_155[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_157[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_enode[_i] = zT_157[_i];
        _i++;
    }
}
    zT_159 = 0;
    zT_160 = (unsigned int)zT_159;
    tup_ec = zT_160;
    zT_162 = 0;
    zT_163 = (unsigned int)zT_162;
    tup_i = zT_163;
    goto z_bb_49;
    z_bb_48:
    goto z_bb_45;
    z_bb_49:
    if ((unsigned char)(tup_i < (unsigned int)((unsigned int)tup_children_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_170 = env->store;
    zT_171 = node_idx;
    zT_175 = zF_B10B1BC1_astStoreNodeExtraCh(zT_170, zT_171, (unsigned int)((unsigned int)tup_i));
    tup_child = zT_175;
    zT_177 = env->store;
    zT_178 = tup_child;
    zT_180 = zF_FCDD1D35_astStoreNodeAt(zT_177, zT_178);
    tup_fd = zT_180;
    zT_181 = tup_fd.kind;
    if ((unsigned char)(zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_56; else goto z_bb_57;
    z_bb_51:
    if ((unsigned char)(tup_ec > (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_52:
    zT_195 = 1;
    zT_197 = tup_i + (unsigned int)((unsigned int)zT_195);
    tup_i = zT_197;
    goto z_bb_49;
    z_bb_53:
    zT_166 = tup_ec < (unsigned int)(32);
    goto z_bb_55;
    z_bb_54:
    zT_166 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_166) goto z_bb_50; else goto z_bb_51;
    z_bb_56:
    zT_185 = env;
    zT_186 = tup_fd.child_0;
    zT_191 = zF_F2107C15_resolveTypeExprFull(zT_185, zT_186, (unsigned int)(depth + (unsigned int)(1)));
    tup_ety[tup_ec] = zT_191;
    tup_enode[tup_ec] = tup_child;
    zT_192 = 1;
    zT_194 = tup_ec + (unsigned int)((unsigned int)zT_192);
    tup_ec = zT_194;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
    z_bb_58:
    zT_201 = env->typereg;
    zT_202 = zT_201->xt_len;
    zT_203 = (unsigned int)zT_202;
    tup_estart = zT_203;
    zT_205 = 0;
    zT_206 = (unsigned int)zT_205;
    tup_j = zT_206;
    goto z_bb_60;
    z_bb_59:
    goto z_bb_48;
    z_bb_60:
    if ((unsigned char)(tup_j < tup_ec)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_208 = env;
    zT_209 = tup_ety[tup_j];
    zT_210 = tup_enode[tup_j];
    zT_213 = zF_E2A017C6_tupleElemArrayUnsup(zT_208, zT_209, zT_210);
    (void)zT_213;
    zT_214 = env->typereg;
    zT_215 = tup_ety[tup_j];
    zF_4C03AE3D_xtAppend(zT_214, zT_215);
    goto z_bb_63;
    z_bb_62:
    zT_221 = env->typereg;
    zT_225 = (unsigned int)tup_estart;
    zT_224.elems_start = zT_225;
    zT_226 = (unsigned short)tup_ec;
    zT_224.elems_count = zT_226;
    zT_222 = zT_224;
    zF_C94DF842_tupAppend(zT_221, zT_222);
    zT_228 = env->typereg;
    zT_229 = zT_228->tup_len;
    zT_232 = (unsigned int)(unsigned int)(zT_229 - (unsigned int)(1));
    tup_tidx = zT_232;
    zT_234 = env->typereg;
    zT_235 = zT_234->types_items;
    zT_236 = (unsigned int)tid;
    zT_237 = zT_235[zT_236];
    tup_ty = zT_237;
    zT_240 = "payload_idx";
    zT_242 = 11;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    zT_238 = zT_241;
    zT_239 = tup_tidx;
    zT_243 = zF_4EF81ACE_typeNarrowU16(zT_238, zT_239);
    tup_ty.payload_idx = zT_243;
    zT_244 = env->typereg;
    zT_245 = zT_244->types_items;
    zT_246 = (unsigned int)tid;
    zT_245[zT_246] = tup_ty;
    goto z_bb_59;
    z_bb_63:
    zT_218 = 1;
    zT_220 = tup_j + (unsigned int)((unsigned int)zT_218);
    tup_j = zT_220;
    goto z_bb_60;
    z_bb_64:
    zT_250 = env->store;
    zT_251 = node_idx;
    zT_253 = zF_8BA26B9E_astStoreNodePayload(zT_250, zT_251);
    if ((unsigned char)(zT_253 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    goto z_bb_45;
    z_bb_66:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_84; else goto z_bb_86;
    z_bb_67:
    zT_257 = env->store;
    zT_258 = node_idx;
    zT_260 = zF_152E19CB_astStoreNodeExtraCh(zT_257, zT_258);
    sd_children_n = zT_260;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_262[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_262[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_264[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_264[_i];
        _i++;
    }
}
    zT_266 = 0;
    zT_267 = (unsigned int)zT_266;
    sd_fc = zT_267;
    zT_269 = 0;
    zT_270 = (unsigned int)zT_269;
    sd_i = zT_270;
    goto z_bb_69;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    if ((unsigned char)(sd_i < (unsigned int)((unsigned int)sd_children_n))) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_277 = env->store;
    zT_278 = node_idx;
    zT_282 = zF_B10B1BC1_astStoreNodeExtraCh(zT_277, zT_278, (unsigned int)((unsigned int)sd_i));
    sd_child = zT_282;
    zT_284 = env->store;
    zT_285 = sd_child;
    zT_287 = zF_FCDD1D35_astStoreNodeAt(zT_284, zT_285);
    sd_fd = zT_287;
    zT_288 = sd_fd.kind;
    if ((unsigned char)(zT_288 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_76; else goto z_bb_77;
    z_bb_71:
    if ((unsigned char)(sd_fc > (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_72:
    zT_306 = 1;
    zT_308 = sd_i + (unsigned int)((unsigned int)zT_306);
    sd_i = zT_308;
    goto z_bb_69;
    z_bb_73:
    zT_273 = sd_fc < (unsigned int)(32);
    goto z_bb_75;
    z_bb_74:
    zT_273 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_273) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_292 = env;
    zT_293 = sd_fd.child_0;
    zT_298 = zF_F2107C15_resolveTypeExprFull(zT_292, zT_293, (unsigned int)(depth + (unsigned int)(1)));
    sd_fty[sd_fc] = zT_298;
    zT_299 = env->store;
    zT_300 = sd_child;
    zT_302 = zF_8BA26B9E_astStoreNodePayload(zT_299, zT_300);
    sd_fnm[sd_fc] = zT_302;
    zT_303 = 1;
    zT_305 = sd_fc + (unsigned int)((unsigned int)zT_303);
    sd_fc = zT_305;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_312 = env->typereg;
    zT_313 = zT_312->fe_len;
    zT_314 = (unsigned int)zT_313;
    sd_fstart = zT_314;
    zT_316 = 0;
    zT_317 = (unsigned int)zT_316;
    sd_j = zT_317;
    goto z_bb_80;
    z_bb_79:
    goto z_bb_68;
    z_bb_80:
    if ((unsigned char)(sd_j < sd_fc)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_319 = env->typereg;
    zT_323 = sd_fnm[sd_j];
    zT_322.name_id = zT_323;
    zT_324 = sd_fty[sd_j];
    zT_322.type_id = zT_324;
    zT_325 = 0;
    zT_322.offset = zT_325;
    zT_320 = zT_322;
    zF_701DF154_feAppend(zT_319, zT_320);
    goto z_bb_83;
    z_bb_82:
    zT_329 = env->typereg;
    zT_333 = (unsigned int)sd_fstart;
    zT_332.fields_start = zT_333;
    zT_334 = (unsigned short)sd_fc;
    zT_332.fields_count = zT_334;
    zT_330 = zT_332;
    zF_CF849366_stAppend(zT_329, zT_330);
    zT_336 = env->typereg;
    zT_337 = zT_336->st_len;
    zT_340 = (unsigned int)(unsigned int)(zT_337 - (unsigned int)(1));
    sd_st_idx = zT_340;
    zT_342 = env->typereg;
    zT_343 = zT_342->types_items;
    zT_344 = (unsigned int)tid;
    zT_345 = zT_343[zT_344];
    sd_ty = zT_345;
    zT_348 = "payload_idx";
    zT_350 = 11;
    zT_349.ptr = zT_348;
    zT_349.len = zT_350;
    zT_346 = zT_349;
    zT_347 = sd_st_idx;
    zT_351 = zF_4EF81ACE_typeNarrowU16(zT_346, zT_347);
    sd_ty.payload_idx = zT_351;
    zT_352 = env->typereg;
    zT_353 = zT_352->types_items;
    zT_354 = (unsigned int)tid;
    zT_353[zT_354] = sd_ty;
    goto z_bb_79;
    z_bb_83:
    zT_326 = 1;
    zT_328 = sd_j + (unsigned int)((unsigned int)zT_326);
    sd_j = zT_328;
    goto z_bb_80;
    z_bb_84:
    zT_358 = env->store;
    zT_359 = node_idx;
    zT_361 = zF_8BA26B9E_astStoreNodePayload(zT_358, zT_359);
    if ((unsigned char)(zT_361 != (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    goto z_bb_65;
    z_bb_86:
    zT_497 = env->typereg;
    zT_498 = env->store;
    zT_499 = kind;
    zT_500 = node_idx;
    zT_501 = tid;
    zT_502 = env->symbol_reg;
    zF_020995FB_populateTypePayload(zT_497, zT_498, zT_499, zT_500, zT_501, zT_502);
    goto z_bb_85;
    z_bb_87:
    zT_365 = env->store;
    zT_366 = node_idx;
    zT_368 = zF_152E19CB_astStoreNodeExtraCh(zT_365, zT_366);
    un_children_n = zT_368;
    zT_369 = 0;
    if ((unsigned char)(un_children_n != (unsigned int)zT_369)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_372[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fty[_i] = zT_372[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_374[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fnm[_i] = zT_374[_i];
        _i++;
    }
}
    zT_376 = 0;
    zT_377 = (unsigned int)zT_376;
    un_fc = zT_377;
    zT_379 = 0;
    zT_380 = (unsigned int)zT_379;
    un_i = zT_380;
    goto z_bb_91;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    if ((unsigned char)(un_i < (unsigned int)((unsigned int)un_children_n))) goto z_bb_95; else goto z_bb_96;
    z_bb_92:
    zT_387 = env->store;
    zT_388 = node_idx;
    zT_392 = zF_B10B1BC1_astStoreNodeExtraCh(zT_387, zT_388, (unsigned int)((unsigned int)un_i));
    un_child = zT_392;
    zT_394 = env->store;
    zT_395 = un_child;
    zT_397 = zF_FCDD1D35_astStoreNodeAt(zT_394, zT_395);
    un_fd = zT_397;
    zT_398 = un_fd.kind;
    if ((unsigned char)(zT_398 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_98; else goto z_bb_99;
    z_bb_93:
    zT_420 = env->typereg;
    zT_421 = zT_420->fe_len;
    zT_422 = (unsigned int)zT_421;
    un_fstart = zT_422;
    zT_424 = 0;
    zT_425 = (unsigned int)zT_424;
    un_j = zT_425;
    goto z_bb_100;
    z_bb_94:
    zT_416 = 1;
    zT_418 = un_i + (unsigned int)((unsigned int)zT_416);
    un_i = zT_418;
    goto z_bb_91;
    z_bb_95:
    zT_383 = un_fc < (unsigned int)(32);
    goto z_bb_97;
    z_bb_96:
    zT_383 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_383) goto z_bb_92; else goto z_bb_93;
    z_bb_98:
    zT_402 = env;
    zT_403 = un_fd.child_0;
    zT_408 = zF_F2107C15_resolveTypeExprFull(zT_402, zT_403, (unsigned int)(depth + (unsigned int)(1)));
    un_fty[un_fc] = zT_408;
    zT_409 = env->store;
    zT_410 = un_child;
    zT_412 = zF_8BA26B9E_astStoreNodePayload(zT_409, zT_410);
    un_fnm[un_fc] = zT_412;
    zT_413 = 1;
    zT_415 = un_fc + (unsigned int)((unsigned int)zT_413);
    un_fc = zT_415;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_94;
    z_bb_100:
    if ((unsigned char)(un_j < un_fc)) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_427 = env->typereg;
    zT_431 = un_fnm[un_j];
    zT_430.name_id = zT_431;
    zT_432 = un_fty[un_j];
    zT_430.type_id = zT_432;
    zT_433 = 0;
    zT_430.offset = zT_433;
    zT_428 = zT_430;
    zF_701DF154_feAppend(zT_427, zT_428);
    goto z_bb_103;
    z_bb_102:
    zT_437 = node.flags;
    zT_439 = 1;
    zT_441 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_437) & zT_439) != zT_441)) goto z_bb_104; else goto z_bb_106;
    z_bb_103:
    zT_434 = 1;
    zT_436 = un_j + (unsigned int)((unsigned int)zT_434);
    un_j = zT_436;
    goto z_bb_100;
    z_bb_104:
    zT_443 = env->typereg;
    zT_447 = 10;
    zT_446.tag_type = zT_447;
    zT_448 = (unsigned int)un_fstart;
    zT_446.fields_start = zT_448;
    zT_449 = (unsigned short)un_fc;
    zT_446.fields_count = zT_449;
    zT_444 = zT_446;
    zF_FB6B57C6_tuAppend(zT_443, zT_444);
    zT_451 = env->typereg;
    zT_452 = zT_451->tu_len;
    zT_455 = (unsigned int)(unsigned int)(zT_452 - (unsigned int)(1));
    un_tu_idx = zT_455;
    zT_457 = env->typereg;
    zT_458 = zT_457->types_items;
    zT_459 = (unsigned int)tid;
    zT_460 = zT_458[zT_459];
    un_tu_ty = zT_460;
    zT_463 = "payload_idx";
    zT_465 = 11;
    zT_464.ptr = zT_463;
    zT_464.len = zT_465;
    zT_461 = zT_464;
    zT_462 = un_tu_idx;
    zT_466 = zF_4EF81ACE_typeNarrowU16(zT_461, zT_462);
    un_tu_ty.payload_idx = zT_466;
    zT_467 = env->typereg;
    zT_468 = zT_467->types_items;
    zT_469 = (unsigned int)tid;
    zT_468[zT_469] = un_tu_ty;
    goto z_bb_105;
    z_bb_105:
    goto z_bb_90;
    z_bb_106:
    zT_470 = env->typereg;
    zT_474 = (unsigned int)un_fstart;
    zT_473.fields_start = zT_474;
    zT_475 = (unsigned short)un_fc;
    zT_473.fields_count = zT_475;
    zT_476 = 1;
    zT_473.tag_type = zT_476;
    zT_471 = zT_473;
    zF_1718422E_unAppend(zT_470, zT_471);
    zT_478 = env->typereg;
    zT_479 = zT_478->un_len;
    zT_482 = (unsigned int)(unsigned int)(zT_479 - (unsigned int)(1));
    un_un_idx = zT_482;
    zT_484 = env->typereg;
    zT_485 = zT_484->types_items;
    zT_486 = (unsigned int)tid;
    zT_487 = zT_485[zT_486];
    un_un_ty = zT_487;
    zT_490 = "payload_idx";
    zT_492 = 11;
    zT_491.ptr = zT_490;
    zT_491.len = zT_492;
    zT_488 = zT_491;
    zT_489 = un_un_idx;
    zT_493 = zF_4EF81ACE_typeNarrowU16(zT_488, zT_489);
    un_un_ty.payload_idx = zT_493;
    zT_494 = env->typereg;
    zT_495 = zT_494->types_items;
    zT_496 = (unsigned int)tid;
    zT_495[zT_496] = un_un_ty;
    goto z_bb_105;
}

/* typeResolverCheckMemberVisibility */
unsigned char zF_D43B245F_typeResolverCheckMe(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int name_id, zT_3A105EF1_Symbol* sym) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_8;
    unsigned char zT_9 = 0;
    zT_7432B7FA_Opt_232 zT_11;
    unsigned char zT_12;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_15;
    unsigned char zT_16 = 0;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29 = {0};
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_37;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43 = {0};
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode zT_76 = {0};
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_F85C5DED_DiagnosticCollector* dc;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv2;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvnm;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tvparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvmsg;
    zT_22A7C88B_AstNode tvnode;
    unsigned int tv_di;
    zT_22A7C88B_AstNode tv_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv_note;
    zT_4 = sym->module_id;
    zT_5 = env->module_id;
    if ((unsigned char)(zT_4 == zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = sym;
    zT_9 = zF_C08C479C_symbolIsPublic(zT_8);
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_11 = env->diag;
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    dc = zT_11.value;
    zT_14 = dc;
    zT_15 = node_idx;
    zT_16 = zF_4DD9DB2D_diagnosticCollector(zT_14, zT_15);
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = "'";
    zT_20 = 1;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    tv1 = zT_19;
    zT_22 = "' is not marked 'pub'";
    zT_24 = 21;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    tv2 = zT_23;
    zT_26 = env->interner;
    zT_27 = name_id;
    zT_29 = zF_9134020D_stringInternerGet(zT_26, zT_27);
    tvnm = zT_29;
    zT_32 = 0;
    zT_31[zT_32] = tv1;
    zT_33 = 1;
    zT_31[zT_33] = tvnm;
    zT_34 = 2;
    zT_31[zT_34] = tv2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tvparts[_i] = zT_31[_i];
        _i++;
    }
}
    zT_36 = env->interner;
    zT_40 = 0;
    zT_41 = tvparts + zT_40;
    zT_37 = zT_41;
    zT_43 = zF_8C4BFF7C_diagnosticBuilderMa(zT_36, zT_37, (unsigned int)(3));
    tvmsg = zT_43;
    zT_45 = env->store;
    zT_46 = node_idx;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_45, zT_46);
    tvnode = zT_48;
    zT_50 = dc;
    zT_53 = env->source_file_id;
    zT_54 = tvnode.span_start;
    zT_63 = tvnode.span_start;
    zT_64 = tvnode.span_len;
    zT_56 = tvmsg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_50, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3007_VISIBILITY_VIOLATION)), zT_53, zT_54, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_56);
    tv_di = zT_67;
    zT_68 = sym->decl_node;
    if ((unsigned char)(zT_68 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_72 = env->store;
    zT_73 = sym->decl_node;
    zT_76 = zF_FCDD1D35_astStoreNodeAt(zT_72, zT_73);
    tv_decl = zT_76;
    zT_78 = "declared here";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    tv_note = zT_79;
    zT_81 = dc;
    zT_82 = tv_di;
    zT_83 = sym->file_id;
    zT_84 = tv_decl.span_start;
    zT_89 = tv_decl.span_start;
    zT_90 = tv_decl.span_len;
    zT_86 = tv_note;
    zF_A9049B03_diagnosticCollector(zT_81, zT_82, zT_83, zT_84, (unsigned int)(zT_89 + (unsigned int)((unsigned int)zT_90)), zT_86);
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* typeResolverIsInferredLenArray */
unsigned char zF_54996FA4_typeResolverIsInfer(zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    unsigned int zT_39;
    unsigned char zT_42;
    unsigned char* zT_43;
    int zT_44;
    unsigned char zT_45;
    zT_22A7C88B_AstNode nd;
    zT_22A7C88B_AstNode sz;
    unsigned int nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tx;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = store;
    zT_8 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    nd = zT_9;
    zT_10 = nd.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = nd.child_1;
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = store;
    zT_21 = nd.child_1;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    sz = zT_23;
    zT_24 = sz.kind;
    if ((unsigned char)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_30 = store;
    zT_31 = nd.child_1;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    nm = zT_33;
    zT_35 = interner;
    zT_36 = nm;
    zT_37 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    tx = zT_37;
    zT_39 = tx.len;
    if ((unsigned char)(zT_39 == (unsigned int)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_43 = tx.ptr;
    zT_44 = 0;
    zT_45 = zT_43[zT_44];
    zT_42 = zT_45 == (unsigned char)(95);
    goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    goto z_bb_11;
    z_bb_11:
    return zT_42;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_08CE5A52_Opt_405 zT_40;
    unsigned char zT_41;
    zT_C8A278E4_LocalTypeScope* zT_43;
    unsigned int zT_44;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    unsigned char zT_46;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_D3EB6303_StringInterner* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_57 = 0;
    unsigned int zT_58;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_72 = {0};
    unsigned char zT_73;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_95;
    unsigned int zT_96;
    zT_3D7259E2_SymbolRegistry* zT_97;
    unsigned int zT_98;
    zT_79FAE712_u64 zT_106;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_79FAE712_u64 zT_109;
    zT_BAEE192E_Opt_10 zT_111 = {0};
    unsigned char zT_112;
    int zT_114;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_ABC1EBBE_TypeResolveEnv* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_130 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_134;
    unsigned int zT_135;
    unsigned int zT_136 = 0;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    unsigned char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    unsigned char zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned char* zT_155;
    unsigned int zT_157 = 0;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163 = 0;
    zT_8143F551_AstKind zT_165;
    unsigned char zT_169;
    zT_8143F551_AstKind zT_170;
    unsigned char zT_174;
    zT_8143F551_AstKind zT_175;
    zT_ABC1EBBE_TypeResolveEnv* zT_179;
    unsigned int zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned int zT_182;
    unsigned int zT_184 = 0;
    zT_8143F551_AstKind zT_185;
    unsigned char zT_190;
    zT_ABC1EBBE_TypeResolveEnv* zT_192;
    unsigned int zT_193;
    unsigned int zT_198 = 0;
    zT_6B0A7D14_AstStore* zT_202;
    unsigned int zT_203;
    zT_22A7C88B_AstNode zT_206 = {0};
    zT_8143F551_AstKind zT_207;
    zT_6B0A7D14_AstStore* zT_212;
    unsigned int zT_213;
    unsigned int zT_216 = 0;
    int zT_218;
    unsigned int zT_219;
    zT_3D7259E2_SymbolRegistry* zT_220;
    unsigned int zT_221;
    zT_3D7259E2_SymbolRegistry* zT_225;
    unsigned int zT_227;
    zT_D0942820_Opt_894 zT_230 = {0};
    unsigned char zT_231;
    zT_3C598AEF_SymbolKind zT_233;
    unsigned int zT_238;
    zT_3D7259E2_SymbolRegistry* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    unsigned int zT_247 = 0;
    zT_D0942820_Opt_894 zT_248 = {0};
    unsigned char zT_249;
    zT_ABC1EBBE_TypeResolveEnv* zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    zT_3A105EF1_Symbol* zT_254;
    zT_6B0A7D14_AstStore* zT_255;
    unsigned int zT_256;
    unsigned int zT_258 = 0;
    unsigned char zT_259 = 0;
    unsigned int zT_262;
    unsigned char zT_265;
    unsigned char* zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271;
    unsigned int zT_273;
    int zT_274;
    unsigned int zT_276;
    unsigned char* zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned int zT_282;
    zT_338B7C76_TypeRegistry* zT_286;
    zT_D155D06D_Type* zT_287;
    unsigned int zT_288;
    zT_D155D06D_Type zT_289;
    zT_33EF6BFB_TypeKind zT_290;
    unsigned char zT_295;
    zT_3D7259E2_SymbolRegistry* zT_297;
    unsigned int zT_299;
    zT_6B0A7D14_AstStore* zT_302;
    unsigned int zT_303;
    unsigned int zT_305 = 0;
    zT_D0942820_Opt_894 zT_306 = {0};
    unsigned char zT_307;
    zT_ABC1EBBE_TypeResolveEnv* zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    zT_3A105EF1_Symbol* zT_312;
    zT_6B0A7D14_AstStore* zT_313;
    unsigned int zT_314;
    unsigned int zT_316 = 0;
    unsigned char zT_317 = 0;
    unsigned int zT_320;
    unsigned char zT_323;
    unsigned char* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned int zT_331;
    unsigned char* zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8143F551_AstKind zT_340;
    zT_939EE900_Arr_unsigned_int_1 zT_345;
    zT_338B7C76_TypeRegistry* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    zT_EDD37787_Arr_unsigned_short_ zT_351;
    unsigned short zT_352;
    unsigned int zT_353;
    zT_6B0A7D14_AstStore* zT_354;
    unsigned int zT_355;
    unsigned int zT_357 = 0;
    zT_6B0A7D14_AstStore* zT_361;
    unsigned int zT_362;
    unsigned int zT_364 = 0;
    unsigned short zT_365;
    int zT_366;
    int zT_368;
    unsigned int zT_369;
    zT_338B7C76_TypeRegistry* zT_372;
    unsigned int zT_373;
    zT_6B0A7D14_AstStore* zT_375;
    unsigned int zT_376;
    unsigned int zT_380 = 0;
    int zT_381;
    unsigned int zT_383;
    zT_338B7C76_TypeRegistry* zT_384;
    unsigned int zT_385;
    unsigned short zT_386;
    int zT_388;
    int zT_390;
    unsigned int zT_392 = 0;
    zT_8143F551_AstKind zT_393;
    zT_ABC1EBBE_TypeResolveEnv* zT_398;
    unsigned int zT_399;
    unsigned int zT_404 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    int zT_413;
    zT_ABC1EBBE_TypeResolveEnv* zT_416;
    unsigned int zT_417;
    unsigned int zT_422 = 0;
    int zT_426;
    unsigned int zT_427;
    int zT_428;
    zT_338B7C76_TypeRegistry* zT_429;
    unsigned int zT_430;
    unsigned int zT_431;
    int zT_433;
    unsigned int zT_435 = 0;
    zT_8143F551_AstKind zT_436;
    zT_939EE900_Arr_unsigned_int_1 zT_441;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    int zT_445;
    unsigned int zT_446;
    int zT_447;
    zT_ABC1EBBE_TypeResolveEnv* zT_449;
    unsigned int zT_450;
    unsigned int zT_455 = 0;
    int zT_456;
    unsigned char* zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_460;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_461;
    unsigned int zT_462;
    int zT_463;
    int zT_465;
    unsigned int zT_466;
    zT_99292002_Arr_unsigned_int_16 zT_471;
    unsigned int zT_473;
    zT_6B0A7D14_AstStore* zT_474;
    unsigned int zT_475;
    unsigned int zT_477 = 0;
    zT_6B0A7D14_AstStore* zT_481;
    unsigned int zT_482;
    unsigned int zT_484 = 0;
    unsigned int zT_486;
    unsigned char zT_489;
    zT_ABC1EBBE_TypeResolveEnv* zT_493;
    unsigned int zT_494;
    zT_6B0A7D14_AstStore* zT_496;
    unsigned int zT_497;
    unsigned int zT_501 = 0;
    unsigned int zT_504 = 0;
    unsigned int zT_509;
    unsigned int zT_511;
    unsigned char zT_513;
    unsigned char zT_514;
    unsigned char zT_519;
    zT_443A2803_Arr_unsigned_char_9 zT_521;
    unsigned int zT_523;
    unsigned char* zT_525;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_526;
    unsigned int zT_527;
    unsigned char* zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_531;
    unsigned int zT_532;
    unsigned int zT_534;
    unsigned int zT_536;
    unsigned char zT_538;
    unsigned char* zT_541;
    unsigned char zT_542;
    unsigned int zT_544;
    unsigned int zT_546;
    zT_5826BFC7_Arr_unsigned_char_1 zT_548;
    unsigned int zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    int zT_552;
    int zT_556;
    unsigned char* zT_557;
    unsigned int zT_558;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_559;
    unsigned int zT_560 = 0;
    unsigned int zT_564;
    unsigned char zT_567;
    unsigned char zT_570;
    unsigned int zT_572;
    unsigned int zT_574;
    unsigned int zT_576;
    unsigned char zT_578;
    unsigned char zT_583;
    unsigned int zT_585;
    zT_5826BFC7_Arr_unsigned_char_1 zT_587;
    unsigned int zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    int zT_594;
    unsigned char* zT_595;
    unsigned int zT_596;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_597;
    unsigned int zT_598 = 0;
    unsigned int zT_602;
    unsigned char zT_605;
    unsigned char zT_608;
    unsigned int zT_610;
    unsigned int zT_612;
    unsigned int zT_614;
    zT_D3EB6303_StringInterner* zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    int zT_621;
    unsigned char* zT_622;
    unsigned int zT_623;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_624;
    unsigned int zT_625 = 0;
    zT_338B7C76_TypeRegistry* zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    unsigned int zT_631;
    zT_338B7C76_TypeRegistry* zT_633;
    unsigned int zT_634;
    unsigned int zT_638;
    zT_338B7C76_TypeRegistry* zT_640;
    unsigned int zT_641;
    unsigned int zT_647;
    unsigned char zT_648;
    int zT_655;
    unsigned int zT_657 = 0;
    unsigned char* zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_660;
    unsigned int zT_661;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_662;
    unsigned int zT_663;
    zT_338B7C76_TypeRegistry* zT_664;
    unsigned int zT_665;
    zT_338B7C76_TypeRegistry* zT_667;
    unsigned int zT_668;
    unsigned int zT_672 = 0;
    unsigned int zT_673;
    int zT_674;
    zT_8143F551_AstKind zT_676;
    unsigned char zT_680;
    zT_8143F551_AstKind zT_681;
    unsigned char zT_685;
    zT_8143F551_AstKind zT_686;
    unsigned char zT_690;
    zT_6B0A7D14_AstStore* zT_691;
    zT_D3EB6303_StringInterner* zT_692;
    unsigned int zT_693;
    unsigned char zT_697 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_700;
    unsigned int zT_701;
    unsigned int zT_706 = 0;
    zT_8143F551_AstKind zT_710;
    unsigned char zT_714;
    zT_8143F551_AstKind zT_715;
    unsigned char* zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    unsigned int zT_722;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_723;
    unsigned int zT_724;
    unsigned char* zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    zT_8143F551_AstKind zT_731;
    unsigned char* zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_737;
    unsigned int zT_738;
    unsigned char zT_740;
    unsigned char zT_744;
    unsigned char zT_746;
    unsigned char zT_750;
    zT_8143F551_AstKind zT_751;
    zT_338B7C76_TypeRegistry* zT_756;
    unsigned int zT_757;
    unsigned char zT_758;
    unsigned char zT_759;
    unsigned int zT_761 = 0;
    unsigned char* zT_763;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767;
    unsigned char* zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_770;
    unsigned int zT_771;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_772;
    zT_338B7C76_TypeRegistry* zT_774;
    unsigned int zT_775;
    unsigned char zT_776;
    unsigned char zT_777;
    unsigned int zT_779 = 0;
    unsigned char* zT_781;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_782;
    unsigned int zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    unsigned int zT_785;
    unsigned char* zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788;
    unsigned int zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    zT_8143F551_AstKind zT_791;
    unsigned char zT_796;
    unsigned char zT_800;
    zT_338B7C76_TypeRegistry* zT_802;
    unsigned int zT_803;
    unsigned char zT_804;
    unsigned int zT_806 = 0;
    unsigned char* zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_809;
    unsigned int zT_810;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811;
    unsigned int zT_812;
    unsigned char* zT_814;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_815;
    unsigned int zT_816;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_817;
    unsigned int zT_818;
    unsigned char* zT_820;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_821;
    unsigned int zT_822;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_823;
    zT_8143F551_AstKind zT_824;
    unsigned char* zT_829;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_830;
    unsigned int zT_831;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_832;
    unsigned int zT_833;
    zT_338B7C76_TypeRegistry* zT_835;
    unsigned int zT_836;
    unsigned int zT_838 = 0;
    unsigned char* zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    unsigned int zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_843;
    unsigned int zT_844;
    zT_8143F551_AstKind zT_845;
    unsigned char* zT_850;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_851;
    unsigned int zT_852;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_853;
    unsigned char* zT_855;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_856;
    unsigned int zT_857;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_858;
    unsigned int zT_859;
    unsigned int zT_860;
    int zT_861;
    zT_6B0A7D14_AstStore* zT_864;
    unsigned int zT_865;
    zT_22A7C88B_AstNode zT_868 = {0};
    unsigned int zT_870;
    unsigned char zT_872;
    zT_ABC1EBBE_TypeResolveEnv* zT_874;
    unsigned int zT_875;
    unsigned int zT_879 = 0;
    unsigned char zT_882;
    unsigned char* zT_884;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_885;
    unsigned int zT_886;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_887;
    unsigned int zT_888;
    zT_338B7C76_TypeRegistry* zT_890;
    unsigned int zT_891;
    unsigned int zT_892;
    unsigned int zT_894 = 0;
    unsigned char* zT_896;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_897;
    unsigned int zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    unsigned int zT_900;
    unsigned char* zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_905;
    unsigned int zT_906;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_907;
    unsigned char* zT_909;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_910;
    unsigned int zT_911;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_912;
    unsigned char zT_914;
    zT_8143F551_AstKind zT_915;
    zT_6B0A7D14_AstStore* zT_920;
    unsigned int zT_921;
    unsigned int zT_924 = 0;
    zT_D3EB6303_StringInterner* zT_926;
    unsigned int zT_927;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_929 = {0};
    unsigned int zT_931;
    unsigned char zT_934;
    unsigned char* zT_935;
    int zT_936;
    unsigned char zT_937;
    unsigned char zT_940;
    zT_7432B7FA_Opt_232 zT_941;
    unsigned char zT_942;
    zT_F85C5DED_DiagnosticCollector* zT_944;
    unsigned int zT_945;
    unsigned char zT_946 = 0;
    unsigned char* zT_948;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_949;
    unsigned int zT_950;
    zT_F85C5DED_DiagnosticCollector* zT_951;
    unsigned int zT_954;
    unsigned int zT_955;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_957;
    unsigned int zT_962;
    unsigned int zT_963;
    unsigned int zT_966 = 0;
    zT_7432B7FA_Opt_232 zT_967;
    unsigned char zT_968;
    zT_F85C5DED_DiagnosticCollector* zT_970;
    unsigned int zT_971;
    unsigned char zT_972 = 0;
    unsigned char* zT_974;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_975;
    unsigned int zT_976;
    zT_F85C5DED_DiagnosticCollector* zT_977;
    unsigned int zT_980;
    unsigned int zT_981;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_983;
    unsigned int zT_990;
    unsigned int zT_991;
    unsigned int zT_994 = 0;
    unsigned char* zT_997;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_998;
    unsigned int zT_999;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1000;
    unsigned int zT_1001;
    unsigned char* zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1005;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1006;
    zT_8143F551_AstKind zT_1008;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_C8A278E4_LocalTypeScope* lts;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    unsigned int lt;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    unsigned int sym_cur_tid;
    unsigned int all_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    unsigned char arbu;
    unsigned int arbw;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_D0942820_Opt_894 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_D0942820_Opt_894 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    unsigned char mod_id_1;
    zT_D0942820_Opt_894 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    unsigned int esd_children_n;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    unsigned int fnt_extra_n;
    unsigned int fnt_i;
    unsigned char fnt_conv;
    unsigned int fnt_pt;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    unsigned char is_const;
    unsigned char is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    unsigned char arr_resolved;
    unsigned int alf;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    unsigned char sz_is_inferred;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ail_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asn_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    name_id = zT_33;
    zT_35 = "OPTVOID:id";
    zT_37 = 10;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    opm4_m = zT_36;
    zT_38 = opm4_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_40 = env->local_types;
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_165 = node.kind;
    if ((unsigned char)(zT_165 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_30; else goto z_bb_29;
    z_bb_5:
    lts = zT_40.value;
    zT_43 = lts;
    zT_44 = name_id;
    zT_45 = zF_C768898A_localTypeScopeLooku(zT_43, zT_44);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_49 = env->interner;
    zT_50 = name_id;
    zT_52 = zF_9134020D_stringInternerGet(zT_49, zT_50);
    text = zT_52;
    zT_54 = env->interner;
    zT_55 = text;
    zT_57 = zF_50C274AF_stringInternerInter(zT_54, zT_55);
    canonical_id = zT_57;
    zT_58 = env->module_id;
    if ((unsigned char)(zT_58 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    lt = zT_45.value;
    return lt;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_62 = env->module_id;
    zT_67 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_62) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck_cur = zT_67;
    zT_69 = env->typereg;
    zT_70 = ck_cur;
    zT_72 = zF_0EB68360_nameCacheGet(zT_69, zT_70);
    tc_cur = zT_72;
    zT_73 = tc_cur.has_value;
    if (zT_73) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_76 = env->typereg;
    zT_80 = zF_0EB68360_nameCacheGet(zT_76, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_80;
    zT_82 = "OPTVOID:nc";
    zT_84 = 10;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    opnc_m = zT_83;
    zT_85 = opnc_m;
    zT_86 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_85, zT_86);
    zT_87 = tid.has_value;
    if (zT_87) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    t = tc_cur.value;
    return t;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    t = tid.value;
    return t;
    z_bb_14:
    zT_90 = "NF";
    zT_92 = 2;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    nf = zT_91;
    zT_93 = nf;
    zF_48AC7B3A_markerWrite(zT_93);
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    mi = zT_96;
    goto z_bb_15;
    z_bb_15:
    zT_97 = env->symbol_reg;
    zT_98 = zT_97->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_98))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_106 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck = zT_106;
    zT_108 = env->typereg;
    zT_109 = ck;
    zT_111 = zF_0EB68360_nameCacheGet(zT_108, zT_109);
    tc = zT_111;
    zT_112 = tc.has_value;
    if (zT_112) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    zT_118 = "N2";
    zT_120 = 2;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    n2 = zT_119;
    zT_121 = n2;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_122 = env->module_id;
    if ((unsigned char)(zT_122 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_21; else goto z_bb_22;
    z_bb_18:
    zT_114 = 1;
    zT_116 = mi + (unsigned int)((unsigned int)zT_114);
    mi = zT_116;
    goto z_bb_15;
    z_bb_19:
    t = tc.value;
    return t;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_126 = env;
    zT_127 = env->module_id;
    zT_128 = name_id;
    zT_130 = zF_66C54985_symbolTypeIdOfModul(zT_126, zT_127, zT_128);
    sym_cur_tid = zT_130;
    if ((unsigned char)(sym_cur_tid != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_134 = env;
    zT_135 = name_id;
    zT_136 = zF_DE1472AF_symbolLookupTypeAll(zT_134, zT_135);
    all_tid = zT_136;
    if ((unsigned char)(all_tid != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    return sym_cur_tid;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_140 = "OPTVOID:ids";
    zT_142 = 11;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    ops_m = zT_141;
    zT_143 = ops_m;
    zT_144 = all_tid;
    zF_C914CB83_markerWriteInt(zT_143, zT_144);
    return all_tid;
    z_bb_26:
    zT_146 = "OPTVOID:idF";
    zT_148 = 11;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    opm4f_m = zT_147;
    zT_149 = opm4f_m;
    zT_150 = name_id;
    zF_C914CB83_markerWriteInt(zT_149, zT_150);
    zT_152 = 0;
    arbu = zT_152;
    zT_154 = text;
    zT_155 = &arbu;
    zT_157 = zF_741B5264_parseArbIntWidth(zT_154, zT_155);
    arbw = zT_157;
    if ((unsigned char)(arbw != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_160 = env->typereg;
    zT_161 = text;
    zT_163 = zF_B8CF3697_typeRegistryGetOrCr(zT_160, zT_161);
    return zT_163;
    z_bb_28:
    return (unsigned int)(18);
    z_bb_29:
    zT_170 = node.kind;
    zT_169 = zT_170 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_31;
    z_bb_30:
    zT_169 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_169) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_175 = node.kind;
    zT_174 = zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_34;
    z_bb_33:
    zT_174 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_174) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_179 = env;
    zT_180 = node_idx;
    zT_181 = node.kind;
    zT_182 = depth;
    zT_184 = zF_FE81311F_registerContainerTy(zT_179, zT_180, zT_181, zT_182);
    return zT_184;
    z_bb_36:
    zT_185 = node.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_190 = 0;
    fah_matched = zT_190;
    zT_192 = env;
    zT_193 = node.child_0;
    zT_198 = zF_F2107C15_resolveTypeExprFull(zT_192, zT_193, (unsigned int)(depth + (unsigned int)(1)));
    base_type = zT_198;
    if ((unsigned char)(base_type == (unsigned int)(18))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_340 = node.kind;
    if ((unsigned char)(zT_340 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_67; else goto z_bb_68;
    z_bb_39:
    zT_202 = env->store;
    zT_203 = node.child_0;
    zT_206 = zF_FCDD1D35_astStoreNodeAt(zT_202, zT_203);
    base_node = zT_206;
    zT_207 = base_node.kind;
    if ((unsigned char)(zT_207 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_286 = env->typereg;
    zT_287 = zT_286->types_items;
    zT_288 = (unsigned int)base_type;
    zT_289 = zT_287[zT_288];
    base_ty = zT_289;
    zT_290 = base_ty.kind;
    if ((unsigned char)(zT_290 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_41:
    zT_212 = env->store;
    zT_213 = node.child_0;
    zT_216 = zF_53458827_astStoreIdentifier(zT_212, zT_213);
    base_name_id = zT_216;
    zT_218 = 0;
    zT_219 = (unsigned int)zT_218;
    smi = zT_219;
    goto z_bb_43;
    z_bb_42:
    zT_278 = "FAH:m";
    zT_280 = 5;
    zT_279.ptr = zT_278;
    zT_279.len = zT_280;
    fam_m = zT_279;
    zT_281 = fam_m;
    zT_282 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_281, zT_282);
    return (unsigned int)(18);
    z_bb_43:
    zT_220 = env->symbol_reg;
    zT_221 = zT_220->tables_len;
    if ((unsigned char)(smi < (unsigned int)((unsigned int)zT_221))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_225 = env->symbol_reg;
    zT_227 = base_name_id;
    zT_230 = zF_A398987E_symbolRegistryQuali(zT_225, (unsigned int)((unsigned int)smi), zT_227);
    base_sym = zT_230;
    zT_231 = base_sym.has_value;
    if (zT_231) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_274 = 1;
    zT_276 = smi + (unsigned int)((unsigned int)zT_274);
    smi = zT_276;
    goto z_bb_43;
    z_bb_47:
    bs = base_sym.value;
    zT_233 = bs->kind;
    if ((unsigned char)(zT_233 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    zT_238 = bs->module_id;
    mod_id = zT_238;
    zT_240 = env->symbol_reg;
    zT_241 = mod_id;
    zT_244 = env->store;
    zT_245 = node_idx;
    zT_247 = zF_8BA26B9E_astStoreNodePayload(zT_244, zT_245);
    zT_242 = zT_247;
    zT_248 = zF_A398987E_symbolRegistryQuali(zT_240, zT_241, zT_242);
    payload_sym = zT_248;
    zT_249 = payload_sym.has_value;
    if (zT_249) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    ps = payload_sym.value;
    zT_251 = env;
    zT_252 = node_idx;
    zT_255 = env->store;
    zT_256 = node_idx;
    zT_258 = zF_8BA26B9E_astStoreNodePayload(zT_255, zT_256);
    zT_253 = zT_258;
    zT_254 = ps;
    zT_259 = zF_D43B245F_typeResolverCheckMe(zT_251, zT_252, zT_253, zT_254);
    if ((unsigned char)(!zT_259)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    return (unsigned int)(18);
    z_bb_54:
    zT_262 = ps->type_id;
    if ((unsigned char)(zT_262 != (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_265 = 1;
    fah_matched = zT_265;
    zT_267 = "FAH:r";
    zT_269 = 5;
    zT_268.ptr = zT_267;
    zT_268.len = zT_269;
    fam = zT_268;
    zT_270 = fam;
    zT_271 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_270, zT_271);
    zT_273 = ps->type_id;
    return zT_273;
    z_bb_56:
    goto z_bb_52;
    z_bb_57:
    zT_295 = base_ty.module_id;
    mod_id_1 = zT_295;
    zT_297 = env->symbol_reg;
    zT_302 = env->store;
    zT_303 = node_idx;
    zT_305 = zF_8BA26B9E_astStoreNodePayload(zT_302, zT_303);
    zT_299 = zT_305;
    zT_306 = zF_A398987E_symbolRegistryQuali(zT_297, (unsigned int)((unsigned int)mod_id_1), zT_299);
    sym = zT_306;
    zT_307 = sym.has_value;
    if (zT_307) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    if ((unsigned char)(fah_matched == (unsigned char)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_59:
    s = sym.value;
    zT_309 = env;
    zT_310 = node_idx;
    zT_313 = env->store;
    zT_314 = node_idx;
    zT_316 = zF_8BA26B9E_astStoreNodePayload(zT_313, zT_314);
    zT_311 = zT_316;
    zT_312 = s;
    zT_317 = zF_D43B245F_typeResolverCheckMe(zT_309, zT_310, zT_311, zT_312);
    if ((unsigned char)(!zT_317)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    return (unsigned int)(18);
    z_bb_62:
    zT_320 = s->type_id;
    if ((unsigned char)(zT_320 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_323 = 1;
    fah_matched = zT_323;
    zT_325 = "FAH:r";
    zT_327 = 5;
    zT_326.ptr = zT_325;
    zT_326.len = zT_327;
    fam = zT_326;
    zT_328 = fam;
    zT_329 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_328, zT_329);
    zT_331 = s->type_id;
    return zT_331;
    z_bb_64:
    goto z_bb_60;
    z_bb_65:
    zT_335 = "FAH:N";
    zT_337 = 5;
    zT_336.ptr = zT_335;
    zT_336.len = zT_337;
    fnm = zT_336;
    zT_338 = fnm;
    zT_339 = node_idx;
    zF_C914CB83_markerWriteInt(zT_338, zT_339);
    goto z_bb_66;
    z_bb_66:
    goto z_bb_38;
    z_bb_67:
    zT_346 = env->typereg;
    zT_347 = zT_346->xn_len;
    zT_348 = (unsigned int)zT_347;
    zT_349 = 0;
    zT_345[zT_349] = zT_348;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_345[_i];
        _i++;
    }
}
    zT_352 = 0;
    zT_353 = 0;
    zT_351[zT_353] = zT_352;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_351[_i];
        _i++;
    }
}
    zT_354 = env->store;
    zT_355 = node_idx;
    zT_357 = zF_8BA26B9E_astStoreNodePayload(zT_354, zT_355);
    if ((unsigned char)(zT_357 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_393 = node.kind;
    if ((unsigned char)(zT_393 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_69:
    zT_361 = env->store;
    zT_362 = node_idx;
    zT_364 = zF_152E19CB_astStoreNodeExtraCh(zT_361, zT_362);
    esd_children_n = zT_364;
    zT_365 = (unsigned short)esd_children_n;
    zT_366 = 0;
    esd_count_box[zT_366] = zT_365;
    zT_368 = 0;
    zT_369 = (unsigned int)zT_368;
    esd_i = zT_369;
    goto z_bb_71;
    z_bb_70:
    zT_384 = env->typereg;
    zT_388 = 0;
    zT_385 = esd_start_box[zT_388];
    zT_390 = 0;
    zT_386 = esd_count_box[zT_390];
    zT_392 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_384, zT_385, zT_386);
    return zT_392;
    z_bb_71:
    if ((unsigned char)(esd_i < (unsigned int)((unsigned int)esd_children_n))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_372 = env->typereg;
    zT_375 = env->store;
    zT_376 = node_idx;
    zT_380 = zF_B10B1BC1_astStoreNodeExtraCh(zT_375, zT_376, (unsigned int)((unsigned int)esd_i));
    zT_373 = zT_380;
    zF_A648B1CB_xnAppend(zT_372, zT_373);
    goto z_bb_74;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_381 = 1;
    zT_383 = esd_i + (unsigned int)((unsigned int)zT_381);
    esd_i = zT_383;
    goto z_bb_71;
    z_bb_75:
    zT_398 = env;
    zT_399 = node.child_1;
    zT_404 = zF_F2107C15_resolveTypeExprFull(zT_398, zT_399, (unsigned int)(depth + (unsigned int)(1)));
    eu_payload_type = zT_404;
    if ((unsigned char)(eu_payload_type == (unsigned int)(18))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_436 = node.kind;
    if ((unsigned char)(zT_436 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_77:
    return (unsigned int)(18);
    z_bb_78:
    zT_410 = 0;
    zT_411 = 0;
    zT_409[zT_411] = zT_410;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_409[_i];
        _i++;
    }
}
    zT_412 = node.child_0;
    zT_413 = 0;
    if ((unsigned char)(zT_412 != (unsigned int)zT_413)) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    zT_416 = env;
    zT_417 = node.child_0;
    zT_422 = zF_F2107C15_resolveTypeExprFull(zT_416, zT_417, (unsigned int)(depth + (unsigned int)(1)));
    eu_resolved_es = zT_422;
    if ((unsigned char)(eu_resolved_es == (unsigned int)(18))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_429 = env->typereg;
    zT_430 = eu_payload_type;
    zT_433 = 0;
    zT_431 = eu_es_box[zT_433];
    zT_435 = zF_16D1A6EE_typeRegistryGetOrCr(zT_429, zT_430, zT_431);
    return zT_435;
    z_bb_81:
    zT_427 = 0;
    zT_428 = 0;
    eu_es_box[zT_428] = zT_427;
    goto z_bb_80;
    z_bb_82:
    return (unsigned int)(18);
    z_bb_83:
    zT_426 = 0;
    eu_es_box[zT_426] = eu_resolved_es;
    goto z_bb_80;
    z_bb_84:
    zT_442 = 0;
    zT_443 = 0;
    zT_441[zT_443] = zT_442;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_441[_i];
        _i++;
    }
}
    zT_444 = 1;
    zT_445 = 0;
    fnt_ret_box[zT_445] = zT_444;
    zT_446 = node.child_0;
    zT_447 = 0;
    if ((unsigned char)(zT_446 != (unsigned int)zT_447)) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_673 = node.child_0;
    zT_674 = 0;
    if ((unsigned char)(zT_673 != (unsigned int)zT_674)) goto z_bb_139; else goto z_bb_140;
    z_bb_86:
    zT_449 = env;
    zT_450 = node.child_0;
    zT_455 = zF_F2107C15_resolveTypeExprFull(zT_449, zT_450, (unsigned int)(depth + (unsigned int)(1)));
    zT_456 = 0;
    fnt_ret_box[zT_456] = zT_455;
    zT_458 = "OPTVOID:fntR";
    zT_460 = 12;
    zT_459.ptr = zT_458;
    zT_459.len = zT_460;
    opm2_m = zT_459;
    zT_461 = opm2_m;
    zT_463 = 0;
    zT_462 = fnt_ret_box[zT_463];
    zF_C914CB83_markerWriteInt(zT_461, zT_462);
    zT_465 = 0;
    zT_466 = fnt_ret_box[zT_465];
    if ((unsigned char)(zT_466 == (unsigned int)(18))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_471[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_471[_i];
        _i++;
    }
}
    zT_473 = 0;
    fnt_pc = zT_473;
    zT_474 = env->store;
    zT_475 = node_idx;
    zT_477 = zF_8BA26B9E_astStoreNodePayload(zT_474, zT_475);
    if ((unsigned char)(zT_477 != (unsigned int)(0))) goto z_bb_90; else goto z_bb_91;
    z_bb_88:
    return (unsigned int)(18);
    z_bb_89:
    goto z_bb_87;
    z_bb_90:
    zT_481 = env->store;
    zT_482 = node_idx;
    zT_484 = zF_152E19CB_astStoreNodeExtraCh(zT_481, zT_482);
    fnt_extra_n = zT_484;
    zT_486 = 0;
    fnt_i = zT_486;
    goto z_bb_92;
    z_bb_91:
    zT_513 = 0;
    fnt_conv = zT_513;
    zT_514 = node.flags;
    if ((unsigned char)((unsigned char)(zT_514 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_92:
    if ((unsigned char)(fnt_i < (unsigned int)((unsigned int)fnt_extra_n))) goto z_bb_96; else goto z_bb_97;
    z_bb_93:
    zT_493 = env;
    zT_496 = env->store;
    zT_497 = node_idx;
    zT_501 = zF_B10B1BC1_astStoreNodeExtraCh(zT_496, zT_497, (unsigned int)((unsigned int)fnt_i));
    zT_494 = zT_501;
    zT_504 = zF_F2107C15_resolveTypeExprFull(zT_493, zT_494, (unsigned int)(depth + (unsigned int)(1)));
    fnt_pt = zT_504;
    if ((unsigned char)(fnt_pt == (unsigned int)(18))) goto z_bb_99; else goto z_bb_100;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_511 = fnt_i + (unsigned int)(1);
    fnt_i = zT_511;
    goto z_bb_92;
    z_bb_96:
    zT_489 = fnt_pc < (unsigned int)(16);
    goto z_bb_98;
    z_bb_97:
    zT_489 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_489) goto z_bb_93; else goto z_bb_94;
    z_bb_99:
    return (unsigned int)(18);
    z_bb_100:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_509 = fnt_pc + (unsigned int)(1);
    fnt_pc = zT_509;
    goto z_bb_95;
    z_bb_101:
    zT_519 = 1;
    fnt_conv = zT_519;
    goto z_bb_102;
    z_bb_102:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_521[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_521[_i];
        _i++;
    }
}
    zT_523 = 0;
    fnt_np = zT_523;
    zT_525 = "fnt_";
    zT_527 = 4;
    zT_526.ptr = zT_525;
    zT_526.len = zT_527;
    fnt_pre = zT_526;
    if ((unsigned char)(fnt_conv == (unsigned char)(1))) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_530 = "fnts_";
    zT_532 = 5;
    zT_531.ptr = zT_530;
    zT_531.len = zT_532;
    fnt_pre = zT_531;
    goto z_bb_104;
    z_bb_104:
    zT_534 = 0;
    fnt_pri = zT_534;
    goto z_bb_105;
    z_bb_105:
    zT_536 = fnt_pre.len;
    if ((unsigned char)(fnt_pri < zT_536)) goto z_bb_109; else goto z_bb_110;
    z_bb_106:
    zT_541 = fnt_pre.ptr;
    zT_542 = zT_541[fnt_pri];
    fnt_nb[fnt_np] = zT_542;
    zT_544 = fnt_np + (unsigned int)(1);
    fnt_np = zT_544;
    goto z_bb_108;
    z_bb_107:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_548[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_548[_i];
        _i++;
    }
}
    zT_552 = 0;
    zT_550 = fnt_ret_box[zT_552];
    zT_556 = 0;
    zT_557 = (unsigned char*)((unsigned char*)fnt_rb) + zT_556;
    zT_558 = (unsigned int)(12) - zT_556;
    zT_559.ptr = zT_557;
    zT_559.len = zT_558;
    zT_551 = zT_559;
    zT_560 = zF_A7504564_itoa(zT_550, zT_551);
    fnt_rl = zT_560;
    zT_564 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_rl);
    fnt_rs = zT_564;
    goto z_bb_112;
    z_bb_108:
    zT_546 = fnt_pri + (unsigned int)(1);
    fnt_pri = zT_546;
    goto z_bb_105;
    z_bb_109:
    zT_538 = fnt_np < (unsigned int)(95);
    goto z_bb_111;
    z_bb_110:
    zT_538 = 0;
    goto z_bb_111;
    z_bb_111:
    if (zT_538) goto z_bb_106; else goto z_bb_107;
    z_bb_112:
    if ((unsigned char)(fnt_rs < (unsigned int)(11))) goto z_bb_116; else goto z_bb_117;
    z_bb_113:
    zT_570 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_570;
    zT_572 = fnt_np + (unsigned int)(1);
    fnt_np = zT_572;
    goto z_bb_115;
    z_bb_114:
    zT_576 = 0;
    fnt_k = zT_576;
    goto z_bb_119;
    z_bb_115:
    zT_574 = fnt_rs + (unsigned int)(1);
    fnt_rs = zT_574;
    goto z_bb_112;
    z_bb_116:
    zT_567 = fnt_np < (unsigned int)(95);
    goto z_bb_118;
    z_bb_117:
    zT_567 = 0;
    goto z_bb_118;
    z_bb_118:
    if (zT_567) goto z_bb_113; else goto z_bb_114;
    z_bb_119:
    if ((unsigned char)(fnt_k < fnt_pc)) goto z_bb_123; else goto z_bb_124;
    z_bb_120:
    if ((unsigned char)(fnt_np < (unsigned int)(95))) goto z_bb_126; else goto z_bb_127;
    z_bb_121:
    zT_616 = env->interner;
    zT_621 = 0;
    zT_622 = (unsigned char*)((unsigned char*)fnt_nb) + zT_621;
    zT_623 = fnt_np - zT_621;
    zT_624.ptr = zT_622;
    zT_624.len = zT_623;
    zT_617 = zT_624;
    zT_625 = zF_50C274AF_stringInternerInter(zT_616, zT_617);
    fnt_name_id = zT_625;
    zT_627 = env->typereg;
    zT_628 = zT_627->xt_len;
    zT_629 = (unsigned int)zT_628;
    fnt_pstart = zT_629;
    zT_631 = 0;
    fnt_a = zT_631;
    goto z_bb_135;
    z_bb_122:
    zT_614 = fnt_k + (unsigned int)(1);
    fnt_k = zT_614;
    goto z_bb_119;
    z_bb_123:
    zT_578 = fnt_np < (unsigned int)(95);
    goto z_bb_125;
    z_bb_124:
    zT_578 = 0;
    goto z_bb_125;
    z_bb_125:
    if (zT_578) goto z_bb_120; else goto z_bb_121;
    z_bb_126:
    zT_583 = 95;
    fnt_nb[fnt_np] = zT_583;
    zT_585 = fnt_np + (unsigned int)(1);
    fnt_np = zT_585;
    goto z_bb_127;
    z_bb_127:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_587[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_587[_i];
        _i++;
    }
}
    zT_589 = fnt_ptypes[fnt_k];
    zT_594 = 0;
    zT_595 = (unsigned char*)((unsigned char*)fnt_pb) + zT_594;
    zT_596 = (unsigned int)(12) - zT_594;
    zT_597.ptr = zT_595;
    zT_597.len = zT_596;
    zT_590 = zT_597;
    zT_598 = zF_A7504564_itoa(zT_589, zT_590);
    fnt_pl = zT_598;
    zT_602 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_pl);
    fnt_ps = zT_602;
    goto z_bb_128;
    z_bb_128:
    if ((unsigned char)(fnt_ps < (unsigned int)(11))) goto z_bb_132; else goto z_bb_133;
    z_bb_129:
    zT_608 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_608;
    zT_610 = fnt_np + (unsigned int)(1);
    fnt_np = zT_610;
    goto z_bb_131;
    z_bb_130:
    goto z_bb_122;
    z_bb_131:
    zT_612 = fnt_ps + (unsigned int)(1);
    fnt_ps = zT_612;
    goto z_bb_128;
    z_bb_132:
    zT_605 = fnt_np < (unsigned int)(95);
    goto z_bb_134;
    z_bb_133:
    zT_605 = 0;
    goto z_bb_134;
    z_bb_134:
    if (zT_605) goto z_bb_129; else goto z_bb_130;
    z_bb_135:
    if ((unsigned char)(fnt_a < fnt_pc)) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    zT_633 = env->typereg;
    zT_634 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_633, zT_634);
    goto z_bb_138;
    z_bb_137:
    zT_640 = env->typereg;
    zT_641 = fnt_name_id;
    zT_655 = 0;
    zT_647 = fnt_ret_box[zT_655];
    zT_648 = fnt_conv;
    zT_657 = zF_474336D7_typeRegistryGetOrCr(zT_640, zT_641, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), (unsigned short)((unsigned short)fnt_pc), zT_647, zT_648);
    fnt_tid = zT_657;
    zT_659 = "OPTVOID:fntT";
    zT_661 = 12;
    zT_660.ptr = zT_659;
    zT_660.len = zT_661;
    opm3_m = zT_660;
    zT_662 = opm3_m;
    zT_663 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_662, zT_663);
    zT_664 = env->typereg;
    zT_665 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_664, zT_665);
    zT_667 = env->typereg;
    zT_668 = fnt_tid;
    zT_672 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_667, zT_668, (unsigned char)(0));
    return zT_672;
    z_bb_138:
    zT_638 = fnt_a + (unsigned int)(1);
    fnt_a = zT_638;
    goto z_bb_135;
    z_bb_139:
    zT_676 = node.kind;
    if ((unsigned char)(zT_676 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_142; else goto z_bb_141;
    z_bb_140:
    zT_997 = "UND:n";
    zT_999 = 5;
    zT_998.ptr = zT_997;
    zT_998.len = zT_999;
    und_nm2 = zT_998;
    zT_1000 = und_nm2;
    zT_1001 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1000, zT_1001);
    zT_1003 = "UND:k";
    zT_1005 = 5;
    zT_1004.ptr = zT_1003;
    zT_1004.len = zT_1005;
    und_km = zT_1004;
    zT_1006 = und_km;
    zT_1008 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1006, (unsigned int)((unsigned int)zT_1008));
    return (unsigned int)(18);
    z_bb_141:
    zT_681 = node.kind;
    zT_680 = zT_681 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_143;
    z_bb_142:
    zT_680 = 1;
    goto z_bb_143;
    z_bb_143:
    if (zT_680) goto z_bb_145; else goto z_bb_144;
    z_bb_144:
    zT_686 = node.kind;
    zT_685 = zT_686 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_146;
    z_bb_145:
    zT_685 = 1;
    goto z_bb_146;
    z_bb_146:
    if (zT_685) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_691 = env->store;
    zT_692 = env->interner;
    zT_693 = node.child_0;
    zT_697 = zF_54996FA4_typeResolverIsInfer(zT_691, zT_692, zT_693);
    zT_690 = zT_697;
    goto z_bb_149;
    z_bb_148:
    zT_690 = 0;
    goto z_bb_149;
    z_bb_149:
    if (zT_690) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (unsigned int)(18);
    z_bb_151:
    zT_700 = env;
    zT_701 = node.child_0;
    zT_706 = zF_F2107C15_resolveTypeExprFull(zT_700, zT_701, (unsigned int)(depth + (unsigned int)(1)));
    child_type = zT_706;
    if ((unsigned char)(child_type == (unsigned int)(18))) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    return (unsigned int)(18);
    z_bb_153:
    zT_710 = node.kind;
    if ((unsigned char)(zT_710 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_155; else goto z_bb_154;
    z_bb_154:
    zT_715 = node.kind;
    zT_714 = zT_715 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_156;
    z_bb_155:
    zT_714 = 1;
    goto z_bb_156;
    z_bb_156:
    if (zT_714) goto z_bb_157; else goto z_bb_158;
    z_bb_157:
    zT_720 = "PTR:i";
    zT_722 = 5;
    zT_721.ptr = zT_720;
    zT_721.len = zT_722;
    ptm = zT_721;
    zT_723 = ptm;
    zF_48AC7B3A_markerWrite(zT_723);
    zT_724 = node_idx;
    zF_C8A36147_markerU32(zT_724);
    zT_726 = "k";
    zT_728 = 1;
    zT_727.ptr = zT_726;
    zT_727.len = zT_728;
    ptkm = zT_727;
    zT_729 = ptkm;
    zF_48AC7B3A_markerWrite(zT_729);
    zT_731 = node.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_731));
    zT_734 = "c";
    zT_736 = 1;
    zT_735.ptr = zT_734;
    zT_735.len = zT_736;
    ptcm = zT_735;
    zT_737 = ptcm;
    zF_48AC7B3A_markerWrite(zT_737);
    zT_738 = child_type;
    zF_C8A36147_markerU32(zT_738);
    zT_740 = node.flags;
    zT_744 = (unsigned char)(zT_740 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_744;
    zT_746 = node.flags;
    zT_750 = (unsigned char)(zT_746 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_750;
    zT_751 = node.kind;
    if ((unsigned char)(zT_751 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_159; else goto z_bb_161;
    z_bb_158:
    zT_791 = node.kind;
    if ((unsigned char)(zT_791 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_159:
    zT_756 = env->typereg;
    zT_757 = child_type;
    zT_758 = is_const;
    zT_759 = is_volatile;
    zT_761 = zF_0C0306D6_typeRegistryGetOrCr(zT_756, zT_757, zT_758, zT_759);
    ptr_tid = zT_761;
    zT_763 = "P";
    zT_765 = 1;
    zT_764.ptr = zT_763;
    zT_764.len = zT_765;
    ppm = zT_764;
    zT_766 = ppm;
    zF_48AC7B3A_markerWrite(zT_766);
    zT_767 = ptr_tid;
    zF_C8A36147_markerU32(zT_767);
    zT_769 = "\n";
    zT_771 = 1;
    zT_770.ptr = zT_769;
    zT_770.len = zT_771;
    pnl = zT_770;
    zT_772 = pnl;
    zF_48AC7B3A_markerWrite(zT_772);
    return ptr_tid;
    goto z_bb_158;
    z_bb_161:
    zT_774 = env->typereg;
    zT_775 = child_type;
    zT_776 = is_const;
    zT_777 = is_volatile;
    zT_779 = zF_827207A1_typeRegistryGetOrCr(zT_774, zT_775, zT_776, zT_777);
    ptr_tid2 = zT_779;
    zT_781 = "M";
    zT_783 = 1;
    zT_782.ptr = zT_781;
    zT_782.len = zT_783;
    ppm2 = zT_782;
    zT_784 = ppm2;
    zF_48AC7B3A_markerWrite(zT_784);
    zT_785 = ptr_tid2;
    zF_C8A36147_markerU32(zT_785);
    zT_787 = "\n";
    zT_789 = 1;
    zT_788.ptr = zT_787;
    zT_788.len = zT_789;
    pnl2 = zT_788;
    zT_790 = pnl2;
    zF_48AC7B3A_markerWrite(zT_790);
    return ptr_tid2;
    z_bb_162:
    zT_796 = node.flags;
    zT_800 = (unsigned char)(zT_796 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_800;
    zT_802 = env->typereg;
    zT_803 = child_type;
    zT_804 = is_const;
    zT_806 = zF_8FC81A87_typeRegistryGetOrCr(zT_802, zT_803, zT_804);
    sl_tid = zT_806;
    zT_808 = "SL:e";
    zT_810 = 4;
    zT_809.ptr = zT_808;
    zT_809.len = zT_810;
    sm = zT_809;
    zT_811 = sm;
    zF_48AC7B3A_markerWrite(zT_811);
    zT_812 = child_type;
    zF_C8A36147_markerU32(zT_812);
    zT_814 = "s";
    zT_816 = 1;
    zT_815.ptr = zT_814;
    zT_815.len = zT_816;
    s2 = zT_815;
    zT_817 = s2;
    zF_48AC7B3A_markerWrite(zT_817);
    zT_818 = sl_tid;
    zF_C8A36147_markerU32(zT_818);
    zT_820 = "\n";
    zT_822 = 1;
    zT_821.ptr = zT_820;
    zT_821.len = zT_822;
    s3 = zT_821;
    zT_823 = s3;
    zF_48AC7B3A_markerWrite(zT_823);
    return sl_tid;
    z_bb_163:
    zT_824 = node.kind;
    if ((unsigned char)(zT_824 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_829 = "OPTVOID:opt";
    zT_831 = 11;
    zT_830.ptr = zT_829;
    zT_830.len = zT_831;
    optvd_m = zT_830;
    zT_832 = optvd_m;
    zT_833 = child_type;
    zF_C914CB83_markerWriteInt(zT_832, zT_833);
    zT_835 = env->typereg;
    zT_836 = child_type;
    zT_838 = zF_74A7234F_typeRegistryGetOrCr(zT_835, zT_836);
    optvd_tid = zT_838;
    zT_840 = "OPTVOID:optR";
    zT_842 = 12;
    zT_841.ptr = zT_840;
    zT_841.len = zT_842;
    optvd_rm = zT_841;
    zT_843 = optvd_rm;
    zT_844 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_843, zT_844);
    return optvd_tid;
    z_bb_165:
    zT_845 = node.kind;
    if ((unsigned char)(zT_845 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    zT_850 = "T0";
    zT_852 = 2;
    zT_851.ptr = zT_850;
    zT_851.len = zT_852;
    t0m = zT_851;
    zT_853 = t0m;
    zF_48AC7B3A_markerWrite(zT_853);
    zT_855 = "T1e";
    zT_857 = 3;
    zT_856.ptr = zT_855;
    zT_856.len = zT_857;
    t1m = zT_856;
    zT_858 = t1m;
    zF_48AC7B3A_markerWrite(zT_858);
    zT_859 = child_type;
    zF_C8A36147_markerU32(zT_859);
    zT_860 = node.child_1;
    zT_861 = 0;
    if ((unsigned char)(zT_860 != (unsigned int)zT_861)) goto z_bb_168; else goto z_bb_169;
    z_bb_167:
    goto z_bb_140;
    z_bb_168:
    zT_864 = env->store;
    zT_865 = node.child_1;
    zT_868 = zF_FCDD1D35_astStoreNodeAt(zT_864, zT_865);
    sz_node = zT_868;
    zT_870 = 0;
    arr_len = zT_870;
    zT_872 = 0;
    arr_resolved = zT_872;
    zT_874 = env;
    zT_875 = node.child_1;
    zT_879 = zF_6D0DD27D_evalConstU32Full(zT_874, zT_875, (unsigned int)(0));
    alf = zT_879;
    if ((unsigned char)(alf != (unsigned int)(4294967295u))) goto z_bb_170; else goto z_bb_171;
    z_bb_169:
    return (unsigned int)(18);
    z_bb_170:
    arr_len = alf;
    zT_882 = 1;
    arr_resolved = zT_882;
    goto z_bb_171;
    z_bb_171:
    zT_884 = "T2L";
    zT_886 = 3;
    zT_885.ptr = zT_884;
    zT_885.len = zT_886;
    t2m = zT_885;
    zT_887 = t2m;
    zF_48AC7B3A_markerWrite(zT_887);
    zT_888 = arr_len;
    zF_C8A36147_markerU32(zT_888);
    if (arr_resolved) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    zT_890 = env->typereg;
    zT_891 = child_type;
    zT_892 = arr_len;
    zT_894 = zF_BA693C74_typeRegistryGetOrCr(zT_890, zT_891, zT_892);
    at = zT_894;
    zT_896 = "T3a";
    zT_898 = 3;
    zT_897.ptr = zT_896;
    zT_897.len = zT_898;
    t3m = zT_897;
    zT_899 = t3m;
    zF_48AC7B3A_markerWrite(zT_899);
    zT_900 = at;
    zF_C8A36147_markerU32(zT_900);
    if ((unsigned char)(at != (unsigned int)(18))) goto z_bb_174; else goto z_bb_176;
    z_bb_173:
    zT_914 = 0;
    sz_is_inferred = zT_914;
    zT_915 = sz_node.kind;
    if ((unsigned char)(zT_915 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_177; else goto z_bb_178;
    z_bb_174:
    zT_904 = "A";
    zT_906 = 1;
    zT_905.ptr = zT_904;
    zT_905.len = zT_906;
    am = zT_905;
    zT_907 = am;
    zF_48AC7B3A_markerWrite(zT_907);
    goto z_bb_175;
    z_bb_175:
    return at;
    z_bb_176:
    zT_909 = "a";
    zT_911 = 1;
    zT_910.ptr = zT_909;
    zT_910.len = zT_911;
    am = zT_910;
    zT_912 = am;
    zF_48AC7B3A_markerWrite(zT_912);
    goto z_bb_175;
    z_bb_177:
    zT_920 = env->store;
    zT_921 = node.child_1;
    zT_924 = zF_53458827_astStoreIdentifier(zT_920, zT_921);
    sz_name = zT_924;
    zT_926 = env->interner;
    zT_927 = sz_name;
    zT_929 = zF_9134020D_stringInternerGet(zT_926, zT_927);
    sz_text = zT_929;
    zT_931 = sz_text.len;
    if ((unsigned char)(zT_931 == (unsigned int)(1))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    if (sz_is_inferred) goto z_bb_184; else goto z_bb_186;
    z_bb_179:
    zT_935 = sz_text.ptr;
    zT_936 = 0;
    zT_937 = zT_935[zT_936];
    zT_934 = zT_937 == (unsigned char)(95);
    goto z_bb_181;
    z_bb_180:
    zT_934 = 0;
    goto z_bb_181;
    z_bb_181:
    if (zT_934) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_940 = 1;
    sz_is_inferred = zT_940;
    goto z_bb_183;
    z_bb_183:
    goto z_bb_178;
    z_bb_184:
    zT_941 = env->diag;
    zT_942 = zT_941.has_value;
    if (zT_942) goto z_bb_187; else goto z_bb_188;
    z_bb_185:
    goto z_bb_169;
    z_bb_186:
    zT_967 = env->diag;
    zT_968 = zT_967.has_value;
    if (zT_968) goto z_bb_191; else goto z_bb_192;
    z_bb_187:
    dg = zT_941.value;
    zT_944 = dg;
    zT_945 = node_idx;
    zT_946 = zF_4DD9DB2D_diagnosticCollector(zT_944, zT_945);
    if (zT_946) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    goto z_bb_185;
    z_bb_189:
    zT_948 = "unable to infer array size";
    zT_950 = 26;
    zT_949.ptr = zT_948;
    zT_949.len = zT_950;
    ail_msg = zT_949;
    zT_951 = dg;
    zT_954 = env->source_file_id;
    zT_955 = sz_node.span_start;
    zT_962 = sz_node.span_start;
    zT_963 = sz_node.span_len;
    zT_957 = ail_msg;
    zT_966 = zF_C82559AC_diagnosticCollector(zT_951, (unsigned char)(0), (unsigned short)(3000), zT_954, zT_955, (unsigned int)(zT_962 + (unsigned int)((unsigned int)zT_963)), zT_957);
    (void)zT_966;
    goto z_bb_190;
    z_bb_190:
    goto z_bb_188;
    z_bb_191:
    dg = zT_967.value;
    zT_970 = dg;
    zT_971 = node_idx;
    zT_972 = zF_4DD9DB2D_diagnosticCollector(zT_970, zT_971);
    if (zT_972) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    goto z_bb_185;
    z_bb_193:
    zT_974 = "array size is not a constant expression";
    zT_976 = 39;
    zT_975.ptr = zT_974;
    zT_975.len = zT_976;
    asn_msg = zT_975;
    zT_977 = dg;
    zT_980 = env->source_file_id;
    zT_981 = sz_node.span_start;
    zT_990 = sz_node.span_start;
    zT_991 = sz_node.span_len;
    zT_983 = asn_msg;
    zT_994 = zF_C82559AC_diagnosticCollector(zT_977, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3050_ARRAY_SIZE_NOT_CONSTANT)), zT_980, zT_981, (unsigned int)(zT_990 + (unsigned int)((unsigned int)zT_991)), zT_983);
    (void)zT_994;
    goto z_bb_194;
    z_bb_194:
    goto z_bb_192;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_406493CE_StructPayload* zT_50;
    unsigned short zT_51;
    unsigned int zT_52;
    zT_406493CE_StructPayload zT_53;
    unsigned short zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_64 = 0;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    unsigned char zT_74;
    unsigned int zT_75;
    int zT_76;
    zT_ABC1EBBE_TypeResolveEnv* zT_79;
    unsigned int zT_80;
    unsigned int zT_84 = 0;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_2DF01B61_FieldEntry* zT_104;
    unsigned int zT_105;
    zT_2DF01B61_FieldEntry* zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_115;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    int zT_125;
    unsigned int zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_666DC2E1_TuplePayload* zT_134;
    unsigned short zT_135;
    unsigned int zT_136;
    zT_666DC2E1_TuplePayload zT_137;
    unsigned short zT_138;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_148 = 0;
    zT_6B0A7D14_AstStore* zT_150;
    unsigned int zT_151;
    zT_22A7C88B_AstNode zT_153 = {0};
    zT_8143F551_AstKind zT_154;
    unsigned char zT_158;
    unsigned int zT_159;
    int zT_160;
    zT_ABC1EBBE_TypeResolveEnv* zT_163;
    unsigned int zT_164;
    unsigned int zT_168 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char zT_174 = 0;
    zT_338B7C76_TypeRegistry* zT_175;
    unsigned int* zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_182;
    zT_33EF6BFB_TypeKind zT_183;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_54FF90FA_TaggedUnionPayload* zT_189;
    unsigned short zT_190;
    unsigned int zT_191;
    zT_54FF90FA_TaggedUnionPayload zT_192;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned short zT_207;
    unsigned short zT_209;
    zT_6B0A7D14_AstStore* zT_213;
    unsigned int zT_214;
    zT_6B0A7D14_AstStore* zT_216;
    unsigned int zT_217;
    unsigned int zT_222 = 0;
    zT_22A7C88B_AstNode zT_223 = {0};
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    unsigned int zT_229;
    int zT_230;
    zT_ABC1EBBE_TypeResolveEnv* zT_233;
    unsigned int zT_234;
    unsigned int zT_238 = 0;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned char* zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    unsigned int zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    unsigned char* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    zT_6B0A7D14_AstStore* zT_261;
    unsigned int zT_262;
    unsigned int zT_267 = 0;
    unsigned int zT_268 = 0;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    unsigned char* zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    zT_338B7C76_TypeRegistry* zT_282;
    zT_2DF01B61_FieldEntry* zT_283;
    unsigned int zT_284;
    zT_2DF01B61_FieldEntry* zT_287;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_294;
    unsigned char* zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    unsigned char* zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    int zT_309;
    unsigned int zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    unsigned char zT_316;
    zT_33EF6BFB_TypeKind zT_317;
    zT_338B7C76_TypeRegistry* zT_322;
    zT_AF9231A2_UnionPayload* zT_323;
    unsigned short zT_324;
    unsigned int zT_325;
    zT_AF9231A2_UnionPayload zT_326;
    unsigned short zT_327;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_340 = 0;
    zT_22A7C88B_AstNode zT_341 = {0};
    zT_8143F551_AstKind zT_342;
    unsigned char zT_346;
    unsigned int zT_347;
    int zT_348;
    zT_ABC1EBBE_TypeResolveEnv* zT_351;
    unsigned int zT_352;
    unsigned int zT_356 = 0;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_2DF01B61_FieldEntry* zT_360;
    unsigned int zT_361;
    zT_2DF01B61_FieldEntry* zT_364;
    int zT_365;
    unsigned int zT_367;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    unsigned int fchild;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_666DC2E1_TuplePayload tp_t;
    unsigned int tfchild;
    zT_22A7C88B_AstNode tfd;
    unsigned int tft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_21 = env->store;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_24)));
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_36 = env->store;
    zT_37 = decl.child_1;
    (void)zF_152E19CB_astStoreNodeExtraCh(zT_36, zT_37);
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    zT_44 = sty.kind;
    if ((unsigned char)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_49 = env->typereg;
    zT_50 = zT_49->st_items;
    zT_51 = sty.payload_idx;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    sp = zT_53;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_128 = sty.kind;
    if ((unsigned char)(zT_128 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_54 = sp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_54))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_58 = env->store;
    zT_59 = decl.child_1;
    zT_64 = zF_B10B1BC1_astStoreNodeExtraCh(zT_58, zT_59, (unsigned int)((unsigned int)fi2));
    fchild = zT_64;
    zT_66 = env->store;
    zT_67 = fchild;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    fd = zT_69;
    zT_70 = fd.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_125 = 1;
    zT_127 = fi2 + (unsigned int)((unsigned int)zT_125);
    fi2 = zT_127;
    goto z_bb_6;
    z_bb_10:
    zT_75 = fd.child_0;
    zT_76 = 0;
    zT_74 = zT_75 != (unsigned int)zT_76;
    goto z_bb_12;
    z_bb_11:
    zT_74 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_74) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_79 = env;
    zT_80 = fd.child_0;
    zT_84 = zF_F2107C15_resolveTypeExprFull(zT_79, zT_80, (unsigned int)(0));
    ft = zT_84;
    zT_86 = "B2:p";
    zT_88 = 4;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    b2_pn = zT_87;
    zT_89 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_89);
    zT_91 = env->store;
    zT_92 = fchild;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_90 = zT_94;
    zF_C8A36147_markerU32(zT_90);
    zT_96 = "t";
    zT_98 = 1;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    b2_tn = zT_97;
    zT_99 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_99);
    zT_100 = ft;
    zF_C8A36147_markerU32(zT_100);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_103 = env->typereg;
    zT_104 = zT_103->fe_items;
    zT_105 = sp.fields_start;
    zT_108 = zT_104 + (unsigned int)((unsigned int)((unsigned int)zT_105) + fi2);
    zT_108->type_id = ft;
    zT_110 = "FSW:n";
    zT_112 = 5;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    fsw_nm = zT_111;
    zT_113 = fsw_nm;
    zT_115 = sp.fields_start;
    zF_C914CB83_markerWriteInt(zT_113, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_115) + fi2)));
    zT_120 = "FSW:t";
    zT_122 = 5;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    fsw_tm = zT_121;
    zT_123 = fsw_tm;
    zT_124 = ft;
    zF_C914CB83_markerWriteInt(zT_123, zT_124);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_133 = env->typereg;
    zT_134 = zT_133->tup_items;
    zT_135 = sty.payload_idx;
    zT_136 = (unsigned int)zT_135;
    zT_137 = zT_134[zT_136];
    tp_t = zT_137;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_183 = sty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_31; else goto z_bb_33;
    z_bb_20:
    zT_138 = tp_t.elems_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_138))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_142 = env->store;
    zT_143 = decl.child_1;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_142, zT_143, (unsigned int)((unsigned int)fi2));
    tfchild = zT_148;
    zT_150 = env->store;
    zT_151 = tfchild;
    zT_153 = zF_FCDD1D35_astStoreNodeAt(zT_150, zT_151);
    tfd = zT_153;
    zT_154 = tfd.kind;
    if ((unsigned char)(zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_180 = 1;
    zT_182 = fi2 + (unsigned int)((unsigned int)zT_180);
    fi2 = zT_182;
    goto z_bb_20;
    z_bb_24:
    zT_159 = tfd.child_0;
    zT_160 = 0;
    zT_158 = zT_159 != (unsigned int)zT_160;
    goto z_bb_26;
    z_bb_25:
    zT_158 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_158) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_163 = env;
    zT_164 = tfd.child_0;
    zT_168 = zF_F2107C15_resolveTypeExprFull(zT_163, zT_164, (unsigned int)(0));
    tft = zT_168;
    if ((unsigned char)(tft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_171 = env;
    zT_172 = tft;
    zT_173 = tfchild;
    zT_174 = zF_E2A017C6_tupleElemArrayUnsup(zT_171, zT_172, zT_173);
    (void)zT_174;
    zT_175 = env->typereg;
    zT_176 = zT_175->xt_items;
    zT_177 = tp_t.elems_start;
    zT_179 = (unsigned int)((unsigned int)zT_177) + fi2;
    zT_176[zT_179] = tft;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_188 = env->typereg;
    zT_189 = zT_188->tu_items;
    zT_190 = sty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tp = zT_192;
    zT_194 = "TUI:fs";
    zT_196 = 6;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    tui_fsm = zT_195;
    zT_197 = tui_fsm;
    zT_199 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_197, (unsigned int)((unsigned int)zT_199));
    zT_202 = "TUI:fc";
    zT_204 = 6;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    tui_fcm = zT_203;
    zT_205 = tui_fcm;
    zT_207 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_205, (unsigned int)((unsigned int)zT_207));
    goto z_bb_34;
    z_bb_32:
    goto z_bb_18;
    z_bb_33:
    zT_312 = sty.kind;
    if ((unsigned char)(zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_47; else goto z_bb_46;
    z_bb_34:
    zT_209 = tp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_209))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_213 = env->store;
    zT_216 = env->store;
    zT_217 = decl.child_1;
    zT_222 = zF_B10B1BC1_astStoreNodeExtraCh(zT_216, zT_217, (unsigned int)((unsigned int)fi2));
    zT_214 = zT_222;
    zT_223 = zF_FCDD1D35_astStoreNodeAt(zT_213, zT_214);
    fd = zT_223;
    zT_224 = fd.kind;
    if ((unsigned char)(zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_32;
    z_bb_37:
    zT_309 = 1;
    zT_311 = fi2 + (unsigned int)((unsigned int)zT_309);
    fi2 = zT_311;
    goto z_bb_34;
    z_bb_38:
    zT_229 = fd.child_0;
    zT_230 = 0;
    zT_228 = zT_229 != (unsigned int)zT_230;
    goto z_bb_40;
    z_bb_39:
    zT_228 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_228) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_233 = env;
    zT_234 = fd.child_0;
    zT_238 = zF_F2107C15_resolveTypeExprFull(zT_233, zT_234, (unsigned int)(0));
    ft = zT_238;
    zT_240 = "DFT:n";
    zT_242 = 5;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    dft_nm = zT_241;
    zT_243 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_243, (unsigned int)((unsigned int)fi2));
    zT_247 = "DFT:t";
    zT_249 = 5;
    zT_248.ptr = zT_247;
    zT_248.len = zT_249;
    dft_tm = zT_248;
    zT_250 = dft_tm;
    zT_251 = ft;
    zF_C914CB83_markerWriteInt(zT_250, zT_251);
    zT_253 = "B2:p";
    zT_255 = 4;
    zT_254.ptr = zT_253;
    zT_254.len = zT_255;
    b2_pn = zT_254;
    zT_256 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_256);
    zT_258 = env->store;
    zT_261 = env->store;
    zT_262 = decl.child_1;
    zT_267 = zF_B10B1BC1_astStoreNodeExtraCh(zT_261, zT_262, (unsigned int)((unsigned int)fi2));
    zT_259 = zT_267;
    zT_268 = zF_8BA26B9E_astStoreNodePayload(zT_258, zT_259);
    zT_257 = zT_268;
    zF_C8A36147_markerU32(zT_257);
    zT_270 = "t";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    b2_tn = zT_271;
    zT_273 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_273);
    zT_274 = ft;
    zF_C8A36147_markerU32(zT_274);
    zT_276 = "DTWR\n";
    zT_278 = 5;
    zT_277.ptr = zT_276;
    zT_277.len = zT_278;
    dtwr_m = zT_277;
    zT_279 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_279);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_43; else goto z_bb_45;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_282 = env->typereg;
    zT_283 = zT_282->fe_items;
    zT_284 = tp.fields_start;
    zT_287 = zT_283 + (unsigned int)((unsigned int)((unsigned int)zT_284) + fi2);
    zT_287->type_id = ft;
    zT_289 = "FTW:n";
    zT_291 = 5;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    ftw_nm = zT_290;
    zT_292 = ftw_nm;
    zT_294 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_292, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_294) + fi2)));
    zT_299 = "FTW:t";
    zT_301 = 5;
    zT_300.ptr = zT_299;
    zT_300.len = zT_301;
    ftw_tm = zT_300;
    zT_302 = ftw_tm;
    zT_303 = ft;
    zF_C914CB83_markerWriteInt(zT_302, zT_303);
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_305 = "DTSK\n";
    zT_307 = 5;
    zT_306.ptr = zT_305;
    zT_306.len = zT_307;
    dtsk_m = zT_306;
    zT_308 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_308);
    goto z_bb_44;
    z_bb_46:
    zT_317 = sty.kind;
    zT_316 = zT_317 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_48;
    z_bb_47:
    zT_316 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_316) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_322 = env->typereg;
    zT_323 = zT_322->un_items;
    zT_324 = sty.payload_idx;
    zT_325 = (unsigned int)zT_324;
    zT_326 = zT_323[zT_325];
    up = zT_326;
    goto z_bb_51;
    z_bb_50:
    goto z_bb_32;
    z_bb_51:
    zT_327 = up.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_327))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_331 = env->store;
    zT_334 = env->store;
    zT_335 = decl.child_1;
    zT_340 = zF_B10B1BC1_astStoreNodeExtraCh(zT_334, zT_335, (unsigned int)((unsigned int)fi2));
    zT_332 = zT_340;
    zT_341 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    fd = zT_341;
    zT_342 = fd.kind;
    if ((unsigned char)(zT_342 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    zT_365 = 1;
    zT_367 = fi2 + (unsigned int)((unsigned int)zT_365);
    fi2 = zT_367;
    goto z_bb_51;
    z_bb_55:
    zT_347 = fd.child_0;
    zT_348 = 0;
    zT_346 = zT_347 != (unsigned int)zT_348;
    goto z_bb_57;
    z_bb_56:
    zT_346 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_346) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_351 = env;
    zT_352 = fd.child_0;
    zT_356 = zF_F2107C15_resolveTypeExprFull(zT_351, zT_352, (unsigned int)(0));
    ft = zT_356;
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_54;
    z_bb_60:
    zT_359 = env->typereg;
    zT_360 = zT_359->fe_items;
    zT_361 = up.fields_start;
    zT_364 = zT_360 + (unsigned int)((unsigned int)((unsigned int)zT_361) + fi2);
    zT_364->type_id = ft;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_59;
}

/* varDeclInitNeedsNameCache */
unsigned char zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    return (unsigned char)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    zT_6E8D187B_ModuleEntry zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    unsigned char zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    unsigned char zT_63 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    zT_6E8D187B_ModuleEntry* zT_74;
    zT_6E8D187B_ModuleEntry zT_75;
    unsigned int zT_76;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_83 = 0;
    zT_79FAE712_u64 zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_79FAE712_u64 zT_87;
    unsigned int zT_88;
    zT_3D7259E2_SymbolRegistry* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_95;
    zT_6E8D187B_ModuleEntry zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_101 = 0;
    zT_D0942820_Opt_894 zT_102 = {0};
    unsigned char zT_103;
    int zT_105;
    unsigned int zT_107;
    int zT_108;
    unsigned int zT_110;
    unsigned int ci;
    unsigned int cr;
    unsigned int cd_n;
    unsigned int cdi;
    unsigned int cd_i;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_D0942820_Opt_894 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    if ((unsigned char)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_108 = 1;
    zT_110 = ci + (unsigned int)((unsigned int)zT_108);
    ci = zT_110;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_17 = mods.ptr;
    zT_18 = zT_17[ci];
    zT_19 = zT_18.source_file_id;
    env->source_file_id = zT_19;
    zT_21 = env->store;
    zT_22 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    zT_26 = env->store;
    zT_27 = cr;
    zT_29 = zF_152E19CB_astStoreNodeExtraCh(zT_26, zT_27);
    cd_n = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    cdi = zT_32;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cd_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_37 = cr;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)cdi));
    cd_i = zT_41;
    zT_43 = env->store;
    zT_44 = cd_i;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_43, zT_44);
    cdcl = zT_46;
    zT_47 = cdcl.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_105 = 1;
    zT_107 = cdi + (unsigned int)((unsigned int)zT_105);
    cdi = zT_107;
    goto z_bb_7;
    z_bb_11:
    zT_52 = cdcl.child_1;
    zT_51 = zT_52 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_51 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_51) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_56 = env->store;
    zT_57 = cdcl.child_1;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cdinit = zT_60;
    zT_61 = cdinit.kind;
    zT_63 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_61);
    if (zT_63) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_65 = env;
    zT_66 = cdcl.child_1;
    zT_70 = zF_F2107C15_resolveTypeExprFull(zT_65, zT_66, (unsigned int)(0));
    cdtype = zT_70;
    if ((unsigned char)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_74 = mods.ptr;
    zT_75 = zT_74[ci];
    zT_76 = zT_75.id;
    zT_80 = env->store;
    zT_81 = cd_i;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_80, zT_81);
    zT_85 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_76) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_83);
    ck = zT_85;
    zT_86 = env->typereg;
    zT_87 = ck;
    zT_88 = cdtype;
    zF_5E95558D_nameCachePut(zT_86, zT_87, zT_88);
    zT_91 = env->symbol_reg;
    zT_95 = mods.ptr;
    zT_96 = zT_95[ci];
    zT_92 = zT_96.id;
    zT_98 = env->store;
    zT_99 = cd_i;
    zT_101 = zF_8BA26B9E_astStoreNodePayload(zT_98, zT_99);
    zT_93 = zT_101;
    zT_102 = zF_A398987E_symbolRegistryQuali(zT_91, zT_92, zT_93);
    cdsym = zT_102;
    zT_103 = cdsym.has_value;
    if (zT_103) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_D0942820_Opt_894 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_8143F551_AstKind zT_49;
    zT_072B53A6_ModuleRegistry* zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_61 = 0;
    zT_BAEE192E_Opt_10 zT_62 = {0};
    unsigned char zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    unsigned int zT_77;
    zT_D0942820_Opt_894 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((unsigned char)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_33 = env->store;
    zT_34 = fd.child_1;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fi = zT_37;
    zT_38 = fi.kind;
    if ((unsigned char)(zT_38 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_44 = env->store;
    zT_45 = fi.child_0;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    fb = zT_48;
    zT_49 = fb.kind;
    if ((unsigned char)(zT_49 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_55 = module_reg;
    zT_57 = env->store;
    zT_58 = fi.child_0;
    zT_61 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    zT_56 = zT_61;
    zT_62 = zF_A258E183_moduleRegistryPathT(zT_55, zT_56);
    t2 = zT_62;
    zT_63 = t2.has_value;
    if (zT_63) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_65 = env;
    zT_66 = module_reg;
    zT_67 = importer_mod_id;
    zT_68 = m2;
    zT_71 = env->store;
    zT_72 = fd.child_1;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_69 = zT_75;
    zT_77 = depth + (unsigned int)(1);
    env = zT_65;
    module_reg = zT_66;
    importer_mod_id = zT_67;
    target_mod_id = zT_68;
    field_name_id = zT_69;
    depth = zT_77;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_36 = 0;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    zT_072B53A6_ModuleRegistry* zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    unsigned int zT_76 = 0;
    zT_BAEE192E_Opt_10 zT_77 = {0};
    unsigned char zT_78;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    zT_072B53A6_ModuleRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6E8D187B_ModuleEntry* zT_87;
    zT_6E8D187B_ModuleEntry zT_88;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    unsigned int zT_94 = 0;
    unsigned int zT_96 = 0;
    zT_3D7259E2_SymbolRegistry* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_6E8D187B_ModuleEntry* zT_104;
    zT_6E8D187B_ModuleEntry zT_105;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_D0942820_Opt_894 zT_111 = {0};
    unsigned char zT_112;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    zT_79FAE712_u64 zT_126;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_136;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_D0942820_Opt_894 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_134 = 1;
    zT_136 = mi + (unsigned int)((unsigned int)zT_134);
    mi = zT_136;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = env->store;
    zT_17 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    zT_21 = env->store;
    zT_22 = root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_21, zT_22);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = env->store;
    zT_32 = root;
    zT_36 = zF_B10B1BC1_astStoreNodeExtraCh(zT_31, zT_32, (unsigned int)((unsigned int)di));
    decl_idx = zT_36;
    zT_38 = env->store;
    zT_39 = decl_idx;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    decl = zT_41;
    zT_42 = decl.kind;
    if ((unsigned char)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_131 = 1;
    zT_133 = di + (unsigned int)((unsigned int)zT_131);
    di = zT_133;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_46 = decl.child_1;
    if ((unsigned char)(zT_46 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_50 = env->store;
    zT_51 = decl.child_1;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    init = zT_54;
    zT_55 = init.kind;
    if ((unsigned char)(zT_55 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_60 = env->store;
    zT_61 = init.child_0;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_60, zT_61);
    base = zT_64;
    zT_65 = base.kind;
    if ((unsigned char)(zT_65 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_70 = module_reg;
    zT_72 = env->store;
    zT_73 = init.child_0;
    zT_76 = zF_8BA26B9E_astStoreNodePayload(zT_72, zT_73);
    zT_71 = zT_76;
    zT_77 = zF_A258E183_moduleRegistryPathT(zT_70, zT_71);
    target = zT_77;
    zT_78 = target.has_value;
    if (zT_78) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_81 = env;
    zT_82 = module_reg;
    zT_87 = mods.ptr;
    zT_88 = zT_87[mi];
    zT_83 = zT_88.id;
    zT_84 = mtid;
    zT_90 = env->store;
    zT_91 = decl.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_90, zT_91);
    zT_85 = zT_94;
    zT_96 = zF_E8C2AADA_resolveImportFieldA(zT_81, zT_82, zT_83, zT_84, zT_85, (unsigned int)(0));
    resolved = zT_96;
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_100 = env->symbol_reg;
    zT_104 = mods.ptr;
    zT_105 = zT_104[mi];
    zT_101 = zT_105.id;
    zT_107 = env->store;
    zT_108 = decl_idx;
    zT_110 = zF_8BA26B9E_astStoreNodePayload(zT_107, zT_108);
    zT_102 = zT_110;
    zT_111 = zF_A398987E_symbolRegistryQuali(zT_100, zT_101, zT_102);
    sym = zT_111;
    zT_112 = sym.has_value;
    if (zT_112) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_121 = env->store;
    zT_122 = decl_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    zT_126 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_117) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_124);
    ck = zT_126;
    zT_127 = env->typereg;
    zT_128 = ck;
    zT_129 = resolved;
    zF_5E95558D_nameCachePut(zT_127, zT_128, zT_129);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned char zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_8143F551_AstKind zT_58;
    unsigned char zT_62;
    zT_8143F551_AstKind zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6E8D187B_ModuleEntry* zT_70;
    zT_6E8D187B_ModuleEntry zT_71;
    int zT_73;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_78;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_76 = 1;
    zT_78 = mi + (unsigned int)((unsigned int)zT_76);
    mi = zT_78;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[mi];
    zT_16 = zT_15.source_file_id;
    env->source_file_id = zT_16;
    zT_18 = env->store;
    zT_19 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = root;
    zT_38 = zF_B10B1BC1_astStoreNodeExtraCh(zT_33, zT_34, (unsigned int)((unsigned int)di));
    decl_idx = zT_38;
    zT_40 = env->store;
    zT_41 = decl_idx;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    decl = zT_43;
    zT_44 = decl.kind;
    if ((unsigned char)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_73 = 1;
    zT_75 = di + (unsigned int)((unsigned int)zT_73);
    di = zT_75;
    goto z_bb_7;
    z_bb_11:
    zT_49 = decl.child_1;
    zT_50 = 0;
    zT_48 = zT_49 != (unsigned int)zT_50;
    goto z_bb_13;
    z_bb_12:
    zT_48 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_48) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_53 = env->store;
    zT_54 = decl.child_1;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    init = zT_57;
    zT_58 = init.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_63 = init.kind;
    zT_62 = zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_62 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_62) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_67 = env;
    zT_70 = mods.ptr;
    zT_71 = zT_70[mi];
    zT_68 = zT_71.id;
    zT_69 = decl_idx;
    zF_F5C3193B_resolveDeclAggregat(zT_67, zT_68, zT_69);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* reportUndefinedSymbol */
void zF_76A5E245_reportUndefinedSymb(zT_F85C5DED_DiagnosticCollector* diag, zT_D3EB6303_StringInterner* interner, unsigned int source_file_id, unsigned int span_start, unsigned int span_len, unsigned int name_id) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17 = {0};
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_25;
    int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_31;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_43 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_8F083A69_Slice_zT_0B42B2F8_u uitext;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    zT_7 = "identifier '";
    zT_9 = 12;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    ui1 = zT_8;
    zT_11 = "' is not declared or imported in this module";
    zT_13 = 44;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    ui2 = zT_12;
    zT_15 = interner;
    zT_16 = name_id;
    zT_17 = zF_9134020D_stringInternerGet(zT_15, zT_16);
    uitext = zT_17;
    zT_20 = 0;
    zT_19[zT_20] = ui1;
    zT_21 = 1;
    zT_19[zT_21] = uitext;
    zT_22 = 2;
    zT_19[zT_22] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_19[_i];
        _i++;
    }
}
    zT_24 = interner;
    zT_27 = 0;
    zT_28 = uiparts + zT_27;
    zT_25 = zT_28;
    zT_30 = zF_8C4BFF7C_diagnosticBuilderMa(zT_24, zT_25, (unsigned int)(3));
    uimsg = zT_30;
    zT_31 = diag;
    zT_34 = source_file_id;
    zT_35 = span_start;
    zT_37 = uimsg;
    zT_43 = zF_C82559AC_diagnosticCollector(zT_31, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_34, zT_35, (unsigned int)(span_start + span_len), zT_37);
    (void)zT_43;
    return;
}

/* typeResolverDiagnoseSignatureType */
void zF_2501AC4F_typeResolverDiagnos(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_7432B7FA_Opt_232 zT_8;
    unsigned char zT_9;
    zT_F85C5DED_DiagnosticCollector* zT_10;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    unsigned int zT_22;
    unsigned int zT_25 = 0;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_41 = 0;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned int zT_54;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_66;
    zT_8143F551_AstKind zT_68;
    unsigned int zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_79 = 0;
    unsigned char zT_81;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D155D06D_Type* zT_92;
    unsigned int zT_93;
    zT_D155D06D_Type zT_94;
    zT_33EF6BFB_TypeKind zT_95;
    unsigned char zT_99;
    unsigned char zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    zT_22A7C88B_AstNode zT_106 = {0};
    zT_8143F551_AstKind zT_107;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned int zT_115 = 0;
    int zT_117;
    unsigned int zT_118;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    zT_3D7259E2_SymbolRegistry* zT_124;
    unsigned int zT_126;
    zT_D0942820_Opt_894 zT_129 = {0};
    unsigned char zT_130;
    zT_3C598AEF_SymbolKind zT_132;
    unsigned char zT_136;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    zT_3D7259E2_SymbolRegistry* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_D0942820_Opt_894 zT_151 = {0};
    unsigned char zT_152;
    zT_F85C5DED_DiagnosticCollector* zT_154;
    unsigned int zT_155;
    unsigned char zT_156 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_157;
    zT_D3EB6303_StringInterner* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_162;
    unsigned int zT_166;
    zT_ABC1EBBE_TypeResolveEnv* zT_170;
    unsigned int zT_171;
    zT_8143F551_AstKind zT_175;
    unsigned int zT_179;
    int zT_180;
    zT_ABC1EBBE_TypeResolveEnv* zT_182;
    unsigned int zT_183;
    unsigned int zT_188;
    int zT_189;
    zT_ABC1EBBE_TypeResolveEnv* zT_191;
    unsigned int zT_192;
    zT_8143F551_AstKind zT_197;
    unsigned int zT_201;
    int zT_202;
    zT_ABC1EBBE_TypeResolveEnv* zT_204;
    unsigned int zT_205;
    zT_6B0A7D14_AstStore* zT_210;
    unsigned int zT_211;
    unsigned int zT_213 = 0;
    zT_6B0A7D14_AstStore* zT_217;
    unsigned int zT_218;
    unsigned int zT_220 = 0;
    int zT_222;
    unsigned int zT_223;
    zT_6B0A7D14_AstStore* zT_227;
    unsigned int zT_228;
    unsigned int zT_232 = 0;
    int zT_233;
    zT_ABC1EBBE_TypeResolveEnv* zT_235;
    unsigned int zT_236;
    int zT_240;
    unsigned int zT_242;
    zT_8143F551_AstKind zT_243;
    unsigned char zT_247;
    zT_8143F551_AstKind zT_248;
    unsigned char zT_252;
    zT_8143F551_AstKind zT_253;
    unsigned char zT_257;
    zT_8143F551_AstKind zT_258;
    unsigned char zT_262;
    zT_8143F551_AstKind zT_263;
    unsigned int zT_267;
    int zT_268;
    zT_ABC1EBBE_TypeResolveEnv* zT_270;
    unsigned int zT_271;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u nr_text;
    unsigned int nr_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_text;
    unsigned int at_id;
    unsigned int fd_base;
    unsigned int fd_bt;
    unsigned char fd_is_mod;
    unsigned int fd_mod_id;
    zT_22A7C88B_AstNode fd_bn;
    zT_D155D06D_Type fd_ty;
    unsigned int fd_bname;
    unsigned int fd_mi;
    zT_D0942820_Opt_894 fd_bs;
    zT_3A105EF1_Symbol* fb;
    unsigned int fd_member;
    zT_D0942820_Opt_894 fd_ms;
    unsigned int ft_n;
    unsigned int ft_i;
    unsigned int ft_child;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_8 = env->diag;
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    return;
    z_bb_6:
    zT_10 = zT_8.value;
    goto z_bb_7;
    z_bb_7:
    diag = zT_10;
    zT_13 = env->store;
    zT_14 = node_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    node = zT_16;
    zT_17 = node.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = env;
    zT_22 = node_idx;
    zT_25 = zF_F2107C15_resolveTypeExprFull(zT_21, zT_22, (unsigned int)(0));
    if ((unsigned char)(zT_25 != (unsigned int)(18))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_68 = node.kind;
    if ((unsigned char)(zT_68 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_18; else goto z_bb_19;
    z_bb_10:
    return;
    z_bb_11:
    zT_29 = env->store;
    zT_30 = node_idx;
    zT_32 = zF_53458827_astStoreIdentifier(zT_29, zT_30);
    name_id = zT_32;
    zT_34 = "noreturn";
    zT_36 = 8;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    nr_text = zT_35;
    zT_38 = env->interner;
    zT_39 = nr_text;
    zT_41 = zF_50C274AF_stringInternerInter(zT_38, zT_39);
    nr_id = zT_41;
    if ((unsigned char)(name_id == nr_id)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    zT_44 = "anytype";
    zT_46 = 7;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    at_text = zT_45;
    zT_48 = env->interner;
    zT_49 = at_text;
    zT_51 = zF_50C274AF_stringInternerInter(zT_48, zT_49);
    at_id = zT_51;
    if ((unsigned char)(name_id == at_id)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return;
    z_bb_15:
    zT_53 = diag;
    zT_54 = node_idx;
    zT_55 = zF_4DD9DB2D_diagnosticCollector(zT_53, zT_54);
    if ((unsigned char)(!zT_55)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return;
    z_bb_17:
    zT_57 = diag;
    zT_58 = env->interner;
    zT_59 = env->source_file_id;
    zT_60 = node.span_start;
    zT_66 = node.span_len;
    zT_62 = name_id;
    zF_76A5E245_reportUndefinedSymb(zT_57, zT_58, zT_59, zT_60, (unsigned int)((unsigned int)zT_66), zT_62);
    return;
    z_bb_18:
    zT_73 = node.child_0;
    fd_base = zT_73;
    zT_75 = env;
    zT_76 = fd_base;
    zT_79 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, (unsigned int)(0));
    fd_bt = zT_79;
    zT_81 = 0;
    fd_is_mod = zT_81;
    zT_83 = 0;
    fd_mod_id = zT_83;
    if ((unsigned char)(fd_bt != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_175 = node.kind;
    if ((unsigned char)(zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_20:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)fd_bt) < zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    if (fd_is_mod) goto z_bb_37; else goto z_bb_38;
    z_bb_22:
    zT_103 = env->store;
    zT_104 = fd_base;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_103, zT_104);
    fd_bn = zT_106;
    zT_107 = fd_bn.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_27; else goto z_bb_28;
    z_bb_23:
    zT_91 = env->typereg;
    zT_92 = zT_91->types_items;
    zT_93 = (unsigned int)fd_bt;
    zT_94 = zT_92[zT_93];
    fd_ty = zT_94;
    zT_95 = fd_ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_99 = 1;
    fd_is_mod = zT_99;
    zT_100 = fd_ty.module_id;
    zT_101 = (unsigned int)zT_100;
    fd_mod_id = zT_101;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_112 = env->store;
    zT_113 = fd_base;
    zT_115 = zF_53458827_astStoreIdentifier(zT_112, zT_113);
    fd_bname = zT_115;
    zT_117 = 0;
    zT_118 = (unsigned int)zT_117;
    fd_mi = zT_118;
    goto z_bb_29;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_119 = env->symbol_reg;
    zT_120 = zT_119->tables_len;
    if ((unsigned char)(fd_mi < (unsigned int)((unsigned int)zT_120))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_124 = env->symbol_reg;
    zT_126 = fd_bname;
    zT_129 = zF_A398987E_symbolRegistryQuali(zT_124, (unsigned int)((unsigned int)fd_mi), zT_126);
    fd_bs = zT_129;
    zT_130 = fd_bs.has_value;
    if (zT_130) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_138 = 1;
    zT_140 = fd_mi + (unsigned int)((unsigned int)zT_138);
    fd_mi = zT_140;
    goto z_bb_29;
    z_bb_33:
    fb = fd_bs.value;
    zT_132 = fb->kind;
    if ((unsigned char)(zT_132 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_136 = 1;
    fd_is_mod = zT_136;
    zT_137 = fb->module_id;
    fd_mod_id = zT_137;
    goto z_bb_36;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_142 = env->store;
    zT_143 = node_idx;
    zT_145 = zF_8BA26B9E_astStoreNodePayload(zT_142, zT_143);
    fd_member = zT_145;
    zT_147 = env->symbol_reg;
    zT_148 = fd_mod_id;
    zT_149 = fd_member;
    zT_151 = zF_A398987E_symbolRegistryQuali(zT_147, zT_148, zT_149);
    fd_ms = zT_151;
    zT_152 = fd_ms.has_value;
    if ((unsigned char)(!zT_152)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    if ((unsigned char)(fd_bt == (unsigned int)(18))) goto z_bb_43; else goto z_bb_44;
    z_bb_39:
    zT_154 = diag;
    zT_155 = node_idx;
    zT_156 = zF_4DD9DB2D_diagnosticCollector(zT_154, zT_155);
    if (zT_156) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    return;
    z_bb_41:
    zT_157 = diag;
    zT_158 = env->interner;
    zT_159 = env->source_file_id;
    zT_160 = node.span_start;
    zT_166 = node.span_len;
    zT_162 = fd_member;
    zF_76A5E245_reportUndefinedSymb(zT_157, zT_158, zT_159, zT_160, (unsigned int)((unsigned int)zT_166), zT_162);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_170 = env;
    zT_171 = fd_base;
    zF_2501AC4F_typeResolverDiagnos(zT_170, zT_171, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_44;
    z_bb_44:
    return;
    z_bb_45:
    zT_179 = node.child_0;
    zT_180 = 0;
    if ((unsigned char)(zT_179 != (unsigned int)zT_180)) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_197 = node.kind;
    if ((unsigned char)(zT_197 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_47:
    zT_182 = env;
    zT_183 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_182, zT_183, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_48;
    z_bb_48:
    zT_188 = node.child_1;
    zT_189 = 0;
    if ((unsigned char)(zT_188 != (unsigned int)zT_189)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_191 = env;
    zT_192 = node.child_1;
    zF_2501AC4F_typeResolverDiagnos(zT_191, zT_192, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_50;
    z_bb_50:
    return;
    z_bb_51:
    zT_201 = node.child_0;
    zT_202 = 0;
    if ((unsigned char)(zT_201 != (unsigned int)zT_202)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_243 = node.kind;
    if ((unsigned char)(zT_243 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_64; else goto z_bb_63;
    z_bb_53:
    zT_204 = env;
    zT_205 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_204, zT_205, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_54;
    z_bb_54:
    zT_210 = env->store;
    zT_211 = node_idx;
    zT_213 = zF_8BA26B9E_astStoreNodePayload(zT_210, zT_211);
    if ((unsigned char)(zT_213 != (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_217 = env->store;
    zT_218 = node_idx;
    zT_220 = zF_152E19CB_astStoreNodeExtraCh(zT_217, zT_218);
    ft_n = zT_220;
    zT_222 = 0;
    zT_223 = (unsigned int)zT_222;
    ft_i = zT_223;
    goto z_bb_57;
    z_bb_56:
    return;
    z_bb_57:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_227 = env->store;
    zT_228 = node_idx;
    zT_232 = zF_B10B1BC1_astStoreNodeExtraCh(zT_227, zT_228, (unsigned int)((unsigned int)ft_i));
    ft_child = zT_232;
    zT_233 = 0;
    if ((unsigned char)(ft_child != (unsigned int)zT_233)) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_240 = 1;
    zT_242 = ft_i + (unsigned int)((unsigned int)zT_240);
    ft_i = zT_242;
    goto z_bb_57;
    z_bb_61:
    zT_235 = env;
    zT_236 = ft_child;
    zF_2501AC4F_typeResolverDiagnos(zT_235, zT_236, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_248 = node.kind;
    zT_247 = zT_248 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_65;
    z_bb_64:
    zT_247 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_247) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_253 = node.kind;
    zT_252 = zT_253 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_68;
    z_bb_67:
    zT_252 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_252) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_258 = node.kind;
    zT_257 = zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_71;
    z_bb_70:
    zT_257 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_257) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_263 = node.kind;
    zT_262 = zT_263 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_74;
    z_bb_73:
    zT_262 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_262) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_267 = node.child_0;
    zT_268 = 0;
    if ((unsigned char)(zT_267 != (unsigned int)zT_268)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return;
    z_bb_77:
    zT_270 = env;
    zT_271 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_270, zT_271, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_78;
    z_bb_78:
    return;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6E8D187B_ModuleEntry* zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_47 = {0};
    zT_8143F551_AstKind zT_48;
    zT_6B0A7D14_AstStore* zT_53;
    zT_1BCC7F90_anon_259794 zT_54;
    zT_243D6A41_FnProto* zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    unsigned int zT_60;
    zT_243D6A41_FnProto zT_61;
    zT_3D7259E2_SymbolRegistry* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_67;
    zT_6E8D187B_ModuleEntry zT_68;
    zT_D0942820_Opt_894 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_74;
    zT_939EE900_Arr_unsigned_int_1 zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    int zT_82;
    zT_ABC1EBBE_TypeResolveEnv* zT_85;
    unsigned int zT_86;
    unsigned int zT_90 = 0;
    int zT_93;
    zT_8EED1867_ResolvedTypeTable* zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_ABC1EBBE_TypeResolveEnv* zT_98;
    unsigned int zT_99;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_110;
    unsigned char zT_112;
    unsigned char zT_113;
    unsigned char zT_118;
    zT_993A6923_Arr_unsigned_int_64 zT_120;
    unsigned int zT_122;
    unsigned short zT_123;
    char* zT_127;
    unsigned int zT_128;
    char* zT_129;
    unsigned int zT_130;
    char* zT_131;
    unsigned int zT_132;
    unsigned short zT_134;
    unsigned int zT_138;
    unsigned short zT_142;
    zT_79FAE712_u64 zT_144;
    zT_6B0A7D14_AstStore* zT_146;
    zT_79FAE712_u64 zT_147;
    unsigned int zT_149 = 0;
    int zT_151;
    unsigned int zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    zT_79FAE712_u64 zT_160;
    unsigned int zT_164 = 0;
    zT_22A7C88B_AstNode zT_165 = {0};
    unsigned int zT_166;
    int zT_167;
    zT_ABC1EBBE_TypeResolveEnv* zT_170;
    unsigned int zT_171;
    unsigned int zT_175 = 0;
    char* zT_178;
    unsigned int zT_179;
    char* zT_180;
    unsigned int zT_181;
    char* zT_182;
    unsigned int zT_183;
    unsigned int zT_186;
    zT_8EED1867_ResolvedTypeTable* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_ABC1EBBE_TypeResolveEnv* zT_193;
    unsigned int zT_194;
    int zT_198;
    unsigned int zT_200;
    zT_338B7C76_TypeRegistry* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_206;
    zT_338B7C76_TypeRegistry* zT_208;
    unsigned int zT_209;
    int zT_212;
    unsigned int zT_214;
    zT_338B7C76_TypeRegistry* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned char zT_219;
    unsigned char zT_220;
    unsigned int zT_221;
    unsigned short zT_222;
    unsigned int zT_223;
    unsigned char zT_224;
    zT_6E8D187B_ModuleEntry* zT_227;
    zT_6E8D187B_ModuleEntry zT_228;
    int zT_231;
    unsigned int zT_234 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_3D7259E2_SymbolRegistry* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_6E8D187B_ModuleEntry* zT_243;
    zT_6E8D187B_ModuleEntry zT_244;
    zT_D0942820_Opt_894 zT_247 = {0};
    unsigned char zT_248;
    zT_8143F551_AstKind zT_250;
    unsigned char zT_254;
    unsigned int zT_255;
    int zT_256;
    zT_ABC1EBBE_TypeResolveEnv* zT_259;
    unsigned int zT_260;
    unsigned int zT_264 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    zT_8EED1867_ResolvedTypeTable* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    zT_3D7259E2_SymbolRegistry* zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_6E8D187B_ModuleEntry* zT_279;
    zT_6E8D187B_ModuleEntry zT_280;
    zT_6B0A7D14_AstStore* zT_282;
    unsigned int zT_283;
    unsigned int zT_285 = 0;
    zT_D0942820_Opt_894 zT_286 = {0};
    unsigned char zT_287;
    int zT_289;
    unsigned int zT_291;
    int zT_292;
    unsigned int zT_294;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_D0942820_Opt_894 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    zT_993A6923_Arr_unsigned_int_64 ptypes_buf;
    unsigned int ptypes_n;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int fn_start;
    unsigned int pf;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    unsigned int tid;
    zT_D0942820_Opt_894 sym;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_292 = 1;
    zT_294 = mi + (unsigned int)((unsigned int)zT_292);
    mi = zT_294;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_18 = mods.ptr;
    zT_19 = zT_18[mi];
    zT_20 = zT_19.source_file_id;
    env->source_file_id = zT_20;
    zT_22 = env->store;
    zT_23 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_27 = env->store;
    zT_28 = root;
    zT_30 = zF_152E19CB_astStoreNodeExtraCh(zT_27, zT_28);
    decls_n = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    di = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_38 = root;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)di));
    decl_idx = zT_42;
    zT_44 = env->store;
    zT_45 = decl_idx;
    zT_47 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    decl = zT_47;
    zT_48 = decl.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_289 = 1;
    zT_291 = di + (unsigned int)((unsigned int)zT_289);
    di = zT_291;
    goto z_bb_7;
    z_bb_11:
    zT_53 = env->store;
    zT_54 = zT_53->fn_protos;
    zT_55 = zT_54.items;
    zT_56 = env->store;
    zT_57 = decl_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    zT_60 = (unsigned int)zT_59;
    zT_61 = zT_55[zT_60];
    proto = zT_61;
    zT_63 = env->symbol_reg;
    zT_67 = mods.ptr;
    zT_68 = zT_67[mi];
    zT_64 = zT_68.id;
    zT_65 = proto.name_id;
    zT_71 = zF_A398987E_symbolRegistryQuali(zT_63, zT_64, zT_65);
    sym_check = zT_71;
    zT_72 = sym_check.has_value;
    if (zT_72) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_250 = decl.kind;
    if ((unsigned char)(zT_250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_48; else goto z_bb_49;
    z_bb_14:
    sc = sym_check.value;
    zT_74 = sc->type_id;
    if ((unsigned char)(zT_74 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_79 = 1;
    zT_80 = 0;
    zT_78[zT_80] = zT_79;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_78[_i];
        _i++;
    }
}
    zT_81 = proto.return_type_node;
    zT_82 = 0;
    if ((unsigned char)(zT_81 != (unsigned int)zT_82)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_85 = env;
    zT_86 = proto.return_type_node;
    zT_90 = zF_F2107C15_resolveTypeExprFull(zT_85, zT_86, (unsigned int)(0));
    rtype = zT_90;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_104 = 0;
    is_ext = zT_104;
    zT_105 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_105 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_93 = 0;
    rt_box[zT_93] = rtype;
    zT_94 = resolved_types;
    zT_95 = proto.return_type_node;
    zT_96 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_94, zT_95, zT_96);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_98 = env;
    zT_99 = proto.return_type_node;
    zF_2501AC4F_typeResolverDiagnos(zT_98, zT_99, (unsigned int)(0));
    goto z_bb_21;
    z_bb_23:
    zT_110 = 1;
    is_ext = zT_110;
    goto z_bb_24;
    z_bb_24:
    zT_112 = 0;
    is_variadic = zT_112;
    zT_113 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_113 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_118 = 1;
    is_variadic = zT_118;
    goto z_bb_26;
    z_bb_26:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_120[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        ptypes_buf[_i] = zT_120[_i];
        _i++;
    }
}
    zT_122 = 0;
    ptypes_n = zT_122;
    zT_123 = proto.params_count;
    if ((unsigned char)((unsigned int)((unsigned int)zT_123) > (unsigned int)(64))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_127 = "panic: ";
    zT_128 = 7;
    fwrite(zT_127, 1, zT_128, stderr);
    zT_129 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_130 = 72;
    fwrite(zT_129, 1, zT_130, stderr);
    zT_131 = "\n";
    zT_132 = 1;
    fwrite(zT_131, 1, zT_132, stderr);
    pal_trap();
    z_bb_28:
    zT_134 = proto.params_count;
    if ((unsigned char)(zT_134 > (unsigned short)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_138 = proto.params_start;
    zT_142 = proto.params_count;
    zT_144 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_138) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_142);
    p_payload = zT_144;
    zT_146 = env->store;
    zT_147 = p_payload;
    zT_149 = zF_03CE8CAB_astStoreGetExtraChi(zT_146, zT_147);
    pnodes_n = zT_149;
    zT_151 = 0;
    zT_152 = (unsigned int)zT_151;
    pi = zT_152;
    goto z_bb_31;
    z_bb_30:
    zT_202 = env->typereg;
    zT_203 = zT_202->xt_len;
    zT_204 = (unsigned int)zT_203;
    fn_start = zT_204;
    zT_206 = 0;
    pf = zT_206;
    goto z_bb_42;
    z_bb_31:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_156 = env->store;
    zT_159 = env->store;
    zT_160 = p_payload;
    zT_164 = zF_E5B10421_astStoreGetExtraChi(zT_159, zT_160, (unsigned int)((unsigned int)pi));
    zT_157 = zT_164;
    zT_165 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    pnode = zT_165;
    zT_166 = pnode.child_0;
    zT_167 = 0;
    if ((unsigned char)(zT_166 != (unsigned int)zT_167)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_198 = 1;
    zT_200 = pi + (unsigned int)((unsigned int)zT_198);
    pi = zT_200;
    goto z_bb_31;
    z_bb_35:
    zT_170 = env;
    zT_171 = pnode.child_0;
    zT_175 = zF_F2107C15_resolveTypeExprFull(zT_170, zT_171, (unsigned int)(0));
    ptype = zT_175;
    if ((unsigned char)(ptypes_n >= (unsigned int)(64))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_178 = "panic: ";
    zT_179 = 7;
    fwrite(zT_178, 1, zT_179, stderr);
    zT_180 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_181 = 72;
    fwrite(zT_180, 1, zT_181, stderr);
    zT_182 = "\n";
    zT_183 = 1;
    fwrite(zT_182, 1, zT_183, stderr);
    pal_trap();
    z_bb_38:
    ptypes_buf[ptypes_n] = ptype;
    zT_186 = ptypes_n + (unsigned int)(1);
    ptypes_n = zT_186;
    if ((unsigned char)(ptype != (unsigned int)(18))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_189 = resolved_types;
    zT_190 = pnode.child_0;
    zT_191 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_189, zT_190, zT_191);
    goto z_bb_40;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_193 = env;
    zT_194 = pnode.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_193, zT_194, (unsigned int)(0));
    goto z_bb_40;
    z_bb_42:
    if ((unsigned char)(pf < ptypes_n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_208 = env->typereg;
    zT_209 = ptypes_buf[pf];
    zF_4C03AE3D_xtAppend(zT_208, zT_209);
    goto z_bb_45;
    z_bb_44:
    zT_216 = env->typereg;
    zT_217 = proto.name_id;
    zT_227 = mods.ptr;
    zT_228 = zT_227[mi];
    zT_218 = zT_228.id;
    zT_219 = is_ext;
    zT_220 = is_variadic;
    zT_221 = fn_start;
    zT_222 = proto.params_count;
    zT_231 = 0;
    zT_223 = rt_box[zT_231];
    zT_224 = proto.call_conv;
    zT_234 = zF_474336D7_typeRegistryGetOrCr(zT_216, zT_217, zT_218, zT_219, zT_220, zT_221, zT_222, zT_223, zT_224);
    tid = zT_234;
    zT_235 = resolved_types;
    zT_236 = decl_idx;
    zT_237 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_235, zT_236, zT_237);
    zT_239 = env->symbol_reg;
    zT_243 = mods.ptr;
    zT_244 = zT_243[mi];
    zT_240 = zT_244.id;
    zT_241 = proto.name_id;
    zT_247 = zF_A398987E_symbolRegistryQuali(zT_239, zT_240, zT_241);
    sym = zT_247;
    zT_248 = sym.has_value;
    if (zT_248) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_212 = 1;
    zT_214 = pf + (unsigned int)((unsigned int)zT_212);
    pf = zT_214;
    goto z_bb_42;
    z_bb_46:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_255 = decl.child_0;
    zT_256 = 0;
    zT_254 = zT_255 != (unsigned int)zT_256;
    goto z_bb_50;
    z_bb_49:
    zT_254 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_254) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_259 = env;
    zT_260 = decl.child_0;
    zT_264 = zF_F2107C15_resolveTypeExprFull(zT_259, zT_260, (unsigned int)(0));
    vtype = zT_264;
    if ((unsigned char)(vtype != (unsigned int)(18))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_12;
    z_bb_53:
    zT_267 = resolved_types;
    zT_268 = decl.child_0;
    zT_269 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_267, zT_268, zT_269);
    zT_271 = resolved_types;
    zT_272 = decl_idx;
    zT_273 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_271, zT_272, zT_273);
    zT_275 = env->symbol_reg;
    zT_279 = mods.ptr;
    zT_280 = zT_279[mi];
    zT_276 = zT_280.id;
    zT_282 = env->store;
    zT_283 = decl_idx;
    zT_285 = zF_8BA26B9E_astStoreNodePayload(zT_282, zT_283);
    zT_277 = zT_285;
    zT_286 = zF_A398987E_symbolRegistryQuali(zT_275, zT_276, zT_277);
    sym = zT_286;
    zT_287 = sym.has_value;
    if (zT_287) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_54;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_9;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_10 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_12;
    unsigned int zT_14;
    zT_7432B7FA_Opt_232 zT_15;
    zT_02CE50E0_Opt_403 zT_16 = {0};
    zT_08CE5A52_Opt_405 zT_17 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_18;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_22;
    zT_072B53A6_ModuleRegistry* zT_23;
    zT_ABC1EBBE_TypeResolveEnv* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_9 = module_reg;
    zT_10 = zF_3452C137_moduleRegistryGetMo(zT_9);
    mods = zT_10;
    zT_12.store = store;
    zT_12.typereg = typereg;
    zT_12.symbol_reg = symbol_reg;
    zT_12.interner = interner;
    zT_12.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_14 = 0;
    zT_12.source_file_id = zT_14;
    zT_15.has_value = 1;
    zT_15.value = diag;
    zT_12.diag = zT_15;
    zT_16.has_value = 0;
    zT_12.local_consts = zT_16;
    zT_17.has_value = 0;
    zT_12.local_types = zT_17;
    env = zT_12;
    (void)perm_alloc;
    zT_18 = &env;
    zT_19 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_18, zT_19);
    zT_21 = &env;
    zT_22 = mods;
    zT_23 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_21, zT_22, zT_23);
    zT_25 = &env;
    zT_26 = mods;
    zF_E2882212_resolveAggregateFie(zT_25, zT_26);
    zT_28 = &env;
    zT_29 = mods;
    zT_30 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_28, zT_29, zT_30);
    return;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
    return;
}

/* EOF */
