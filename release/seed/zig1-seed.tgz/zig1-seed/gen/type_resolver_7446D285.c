#include "type_resolver_7446D285.h"
#include <stdio.h>
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* localTypeScopeInit */
zT_C8A278E4_LocalTypeScope zF_8A85AA66_localTypeScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_C8A278E4_LocalTypeScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.types = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localTypeScopePush */
void zF_A3A445A0_localTypeScopePush(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_12;
    int zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_019EE88E_EU_932 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_3E40CD83_Sand* zT_28;
    zT_019EE88E_EU_932 zT_35 = {0};
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int* zT_40;
    unsigned int* zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    unsigned int* zT_55;
    unsigned int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_t;
    unsigned int* nn;
    unsigned int* nt;
    unsigned int i;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = scope->cap;
    if ((unsigned char)(zT_7 < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_55 = scope->names;
    zT_56 = scope->count;
    zT_55[zT_56] = name_id;
    zT_57 = scope->types;
    zT_58 = scope->count;
    zT_57[zT_58] = type_id;
    zT_59 = scope->count;
    scope->count = (unsigned int)(zT_59 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_10 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_12 = scope->cap;
    zT_13 = 2;
    zT_10 = zT_12 * zT_13;
    goto z_bb_5;
    z_bb_5:
    nc = zT_10;
    zT_16 = scope->alloc;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_25 = zT_23.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_n = zT_25;
    zT_28 = scope->alloc;
    zT_35 = zF_1395EB68_sandAlloc(zT_28, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_37 = zT_35.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_t = zT_37;
    zT_40 = (unsigned int*)raw_n;
    nn = zT_40;
    zT_42 = (unsigned int*)raw_t;
    nt = zT_42;
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    i = zT_45;
    goto z_bb_12;
    z_bb_12:
    zT_46 = scope->count;
    if ((unsigned char)(i < zT_46)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_48 = scope->names;
    zT_49 = zT_48[i];
    nn[i] = zT_49;
    zT_50 = scope->types;
    zT_51 = zT_50[i];
    nt[i] = zT_51;
    goto z_bb_15;
    z_bb_14:
    scope->names = nn;
    scope->types = nt;
    scope->cap = nc;
    goto z_bb_2;
    z_bb_15:
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_12;
}

/* localTypeScopeLookup */
zT_BAEE192E_Opt_10 zF_C768898A_localTypeScopeLooku(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id) {
    unsigned int zT_3;
    unsigned int zT_7;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    unsigned int i;
    zT_3 = scope->count;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = i - (unsigned int)(1);
    i = zT_7;
    zT_8 = scope->names;
    zT_9 = zT_8[i];
    if ((unsigned char)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = scope->types;
    zT_12 = zT_11[i];
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    goto z_bb_4;
}

/* localConstScopeInit */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_E2DF2801_LocalConstScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.nodes = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localConstScopePush */
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_12;
    int zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_019EE88E_EU_932 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_3E40CD83_Sand* zT_28;
    zT_019EE88E_EU_932 zT_35 = {0};
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int* zT_40;
    unsigned int* zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    unsigned int* zT_55;
    unsigned int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_d;
    unsigned int* nn;
    unsigned int* nd;
    unsigned int i;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = scope->cap;
    if ((unsigned char)(zT_7 < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_55 = scope->names;
    zT_56 = scope->count;
    zT_55[zT_56] = name_id;
    zT_57 = scope->nodes;
    zT_58 = scope->count;
    zT_57[zT_58] = decl_node;
    zT_59 = scope->count;
    scope->count = (unsigned int)(zT_59 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_10 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_12 = scope->cap;
    zT_13 = 2;
    zT_10 = zT_12 * zT_13;
    goto z_bb_5;
    z_bb_5:
    nc = zT_10;
    zT_16 = scope->alloc;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_25 = zT_23.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_n = zT_25;
    zT_28 = scope->alloc;
    zT_35 = zF_1395EB68_sandAlloc(zT_28, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_37 = zT_35.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_d = zT_37;
    zT_40 = (unsigned int*)raw_n;
    nn = zT_40;
    zT_42 = (unsigned int*)raw_d;
    nd = zT_42;
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    i = zT_45;
    goto z_bb_12;
    z_bb_12:
    zT_46 = scope->count;
    if ((unsigned char)(i < zT_46)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_48 = scope->names;
    zT_49 = zT_48[i];
    nn[i] = zT_49;
    zT_50 = scope->nodes;
    zT_51 = zT_50[i];
    nd[i] = zT_51;
    goto z_bb_15;
    z_bb_14:
    scope->names = nn;
    scope->nodes = nd;
    scope->cap = nc;
    goto z_bb_2;
    z_bb_15:
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_12;
}

/* localConstScopeLookup */
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id) {
    unsigned int zT_3;
    unsigned int zT_7;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    unsigned int i;
    zT_3 = scope->count;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = i - (unsigned int)(1);
    i = zT_7;
    zT_8 = scope->names;
    zT_9 = zT_8[i];
    if ((unsigned char)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = scope->nodes;
    zT_12 = zT_11[i];
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    goto z_bb_4;
}

/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_6B32A9CF_Opt_239 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_019EE88E_EU_932 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6B32A9CF_Opt_239 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->depend_len;
    zT_2 = self->depend_cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->depend_cap;
    zT_6 = 8;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->depend_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->depend_cap;
    zT_14 = 0;
    if ((unsigned char)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->depend_items;
    zT_25 = self->depend_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->depend_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->depend_items;
    zT_48 = self->depend_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    goto z_bb_16;
    z_bb_15:
    self->depend_items = new_items;
    self->depend_cap = nc;
    return;
    z_bb_16:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    self->depend_len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    unsigned int* zT_23;
    unsigned int zT_25;
    zT_6B32A9CF_Opt_239 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_019EE88E_EU_932 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned int* zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6B32A9CF_Opt_239 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_1 = self->worklist_len;
    zT_2 = self->worklist_cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->worklist_cap;
    zT_6 = 64;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->worklist_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->worklist_cap;
    zT_14 = 0;
    if ((unsigned char)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->worklist_items;
    zT_25 = self->worklist_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(4)), (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->worklist_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (unsigned int*)raw;
    new_items = zT_46;
    zT_47 = self->worklist_items;
    zT_48 = self->worklist_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    goto z_bb_16;
    z_bb_15:
    self->worklist_items = new_items;
    self->worklist_cap = nc;
    return;
    z_bb_16:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 + (unsigned int)((unsigned int)zT_6));
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_019EE88E_EU_932 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((unsigned char)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((unsigned char)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_19 = zT_17.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* layoutCompute */
void zF_0E9E97D8_layoutCompute(zT_338B7C76_TypeRegistry* registry, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_2DF01B61_FieldEntry* zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry zT_42;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    zT_2DF01B61_FieldEntry* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_57 = 0;
    zT_2DF01B61_FieldEntry* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_71;
    zT_D155D06D_Type* zT_76;
    zT_33EF6BFB_TypeKind zT_77;
    zT_457ECFEE_EnumPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_457ECFEE_EnumPayload zT_85;
    zT_D155D06D_Type* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_D155D06D_Type* zT_93;
    zT_33EF6BFB_TypeKind zT_94;
    zT_AF9231A2_UnionPayload* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_AF9231A2_UnionPayload zT_102;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned short zT_107;
    unsigned int zT_108;
    int zT_110;
    unsigned int zT_111;
    int zT_113;
    unsigned int zT_114;
    int zT_116;
    unsigned int zT_117;
    zT_2DF01B61_FieldEntry* zT_120;
    unsigned int zT_121;
    zT_2DF01B61_FieldEntry zT_122;
    zT_D155D06D_Type* zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_D155D06D_Type zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    unsigned int zT_132;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143 = 0;
    unsigned int zT_144;
    zT_D155D06D_Type* zT_149;
    zT_33EF6BFB_TypeKind zT_150;
    zT_338B7C76_TypeRegistry* zT_154;
    unsigned int zT_155;
    zT_33EF6BFB_TypeKind zT_156;
    zT_54FF90FA_TaggedUnionPayload* zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_54FF90FA_TaggedUnionPayload zT_164;
    zT_D155D06D_Type* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    zT_D155D06D_Type zT_169;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned short zT_174;
    unsigned int zT_175;
    int zT_177;
    unsigned int zT_178;
    int zT_180;
    unsigned int zT_181;
    int zT_183;
    unsigned int zT_184;
    zT_2DF01B61_FieldEntry* zT_187;
    unsigned int zT_188;
    zT_2DF01B61_FieldEntry zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D155D06D_Type* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_D155D06D_Type zT_209;
    zT_33EF6BFB_TypeKind zT_210;
    unsigned int zT_214;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_219;
    int zT_220;
    unsigned int zT_222;
    unsigned int zT_224;
    unsigned int zT_226;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232 = 0;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235 = 0;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239 = 0;
    zT_D155D06D_Type* zT_240;
    zT_33EF6BFB_TypeKind zT_241;
    zT_0B10E8E9_OptionalPayload* zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    zT_0B10E8E9_OptionalPayload zT_249;
    zT_D155D06D_Type* zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    zT_D155D06D_Type zT_254;
    unsigned int zT_256;
    unsigned int zT_259;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_268 = 0;
    unsigned int zT_271 = 0;
    zT_D155D06D_Type* zT_272;
    zT_33EF6BFB_TypeKind zT_273;
    zT_42C2D6BF_EUPayload* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    zT_42C2D6BF_EUPayload zT_281;
    zT_D155D06D_Type* zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    zT_D155D06D_Type zT_286;
    unsigned int zT_288;
    unsigned int zT_291;
    unsigned int zT_295;
    unsigned int zT_298;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304 = 0;
    unsigned int zT_305;
    unsigned int zT_308 = 0;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_313 = 0;
    zT_D155D06D_Type* zT_314;
    zT_33EF6BFB_TypeKind zT_315;
    zT_E834303C_ArrayPayload* zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    zT_E834303C_ArrayPayload zT_323;
    zT_D155D06D_Type* zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_D155D06D_Type zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_332;
    zT_D155D06D_Type* zT_333;
    zT_33EF6BFB_TypeKind zT_334;
    zT_666DC2E1_TuplePayload* zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    zT_666DC2E1_TuplePayload zT_342;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned short zT_347;
    unsigned int zT_348;
    int zT_350;
    unsigned int zT_351;
    int zT_353;
    unsigned int zT_354;
    int zT_356;
    unsigned int zT_357;
    unsigned int* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    zT_D155D06D_Type* zT_364;
    unsigned int zT_365;
    zT_D155D06D_Type zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_370 = 0;
    unsigned int zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned int zT_375;
    int zT_376;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_381 = 0;
    unsigned int zT_382;
    zT_D155D06D_Type* zT_387;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = registry->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_11 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_11 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_16 = registry;
    zT_17 = tid;
    zF_331152CD_typeRegistryCompute(zT_16, zT_17);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_19 = registry->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_24 = sp.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = sp.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    offset = zT_31;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    max_align = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    fi = zT_37;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = registry->fe_items;
    zT_41 = fstart + fi;
    zT_42 = zT_40[zT_41];
    fe = zT_42;
    zT_44 = registry->types_items;
    zT_45 = fe.type_id;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zT_44[zT_46];
    ft = zT_47;
    zT_48 = ft.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_68 = offset;
    zT_69 = max_align;
    zT_70 = zF_D2BAC673_alignUp_1(zT_68, zT_69);
    ty.size = zT_70;
    ty.alignment = max_align;
    zT_71 = ty.size;
    if ((unsigned char)(zT_71 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_65 = 1;
    zT_67 = fi + (unsigned int)((unsigned int)zT_65);
    fi = zT_67;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_52 = registry->fe_items;
    zT_53 = fstart + fi;
    zT_52[zT_53] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_54 = offset;
    zT_55 = ft.alignment;
    zT_57 = zF_D2BAC673_alignUp_1(zT_54, zT_55);
    offset = zT_57;
    fe.offset = offset;
    zT_58 = registry->fe_items;
    zT_59 = fstart + fi;
    zT_58[zT_59] = fe;
    zT_60 = ft.size;
    zT_61 = offset + zT_60;
    offset = zT_61;
    zT_62 = ft.alignment;
    if ((unsigned char)(zT_62 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_64 = ft.alignment;
    max_align = zT_64;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_17;
    z_bb_17:
    zT_76 = registry->types_items;
    zT_76[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_82 = registry->en_items;
    zT_83 = ty.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    ep = zT_85;
    zT_87 = registry->types_items;
    zT_88 = ep.backing_type;
    zT_89 = (unsigned int)zT_88;
    zT_90 = zT_87[zT_89];
    bt = zT_90;
    zT_91 = bt.size;
    ty.size = zT_91;
    zT_92 = bt.alignment;
    ty.alignment = zT_92;
    zT_93 = registry->types_items;
    zT_93[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_94 = ty.kind;
    if ((unsigned char)(zT_94 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_99 = registry->un_items;
    zT_100 = ty.payload_idx;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zT_99[zT_101];
    up = zT_102;
    zT_104 = up.fields_start;
    zT_105 = (unsigned int)zT_104;
    fstart = zT_105;
    zT_107 = up.fields_count;
    zT_108 = (unsigned int)zT_107;
    fcount = zT_108;
    zT_110 = 0;
    zT_111 = (unsigned int)zT_110;
    max_sz = zT_111;
    zT_113 = 1;
    zT_114 = (unsigned int)zT_113;
    max_align = zT_114;
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    fi = zT_117;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_150 = ty.kind;
    if ((unsigned char)(zT_150 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((unsigned char)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_120 = registry->fe_items;
    zT_121 = fstart + fi;
    zT_122 = zT_120[zT_121];
    fe = zT_122;
    zT_124 = registry->types_items;
    zT_125 = fe.type_id;
    zT_126 = (unsigned int)zT_125;
    zT_127 = zT_124[zT_126];
    ft = zT_127;
    zT_128 = ft.kind;
    if ((unsigned char)(zT_128 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_141 = max_sz;
    zT_142 = max_align;
    zT_143 = zF_D2BAC673_alignUp_1(zT_141, zT_142);
    ty.size = zT_143;
    ty.alignment = max_align;
    zT_144 = ty.size;
    if ((unsigned char)(zT_144 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_138 = 1;
    zT_140 = fi + (unsigned int)((unsigned int)zT_138);
    fi = zT_140;
    goto z_bb_24;
    z_bb_28:
    zT_132 = ft.size;
    if ((unsigned char)(zT_132 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_134 = ft.size;
    max_sz = zT_134;
    goto z_bb_31;
    z_bb_31:
    zT_135 = ft.alignment;
    if ((unsigned char)(zT_135 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_137 = ft.alignment;
    max_align = zT_137;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_35;
    z_bb_35:
    zT_149 = registry->types_items;
    zT_149[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_154 = registry;
    zT_155 = tid;
    zF_62A8E268_typeRegistryCompute(zT_154, zT_155);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_156 = ty.kind;
    if ((unsigned char)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_161 = registry->tu_items;
    zT_162 = ty.payload_idx;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zT_161[zT_163];
    tp = zT_164;
    zT_166 = registry->types_items;
    zT_167 = tp.tag_type;
    zT_168 = (unsigned int)zT_167;
    zT_169 = zT_166[zT_168];
    tag_ty = zT_169;
    zT_171 = tp.fields_start;
    zT_172 = (unsigned int)zT_171;
    fstart = zT_172;
    zT_174 = tp.fields_count;
    zT_175 = (unsigned int)zT_174;
    fcount = zT_175;
    zT_177 = 0;
    zT_178 = (unsigned int)zT_177;
    max_ps = zT_178;
    zT_180 = 1;
    zT_181 = (unsigned int)zT_180;
    max_pa = zT_181;
    zT_183 = 0;
    zT_184 = (unsigned int)zT_183;
    fi = zT_184;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_241 = ty.kind;
    if ((unsigned char)(zT_241 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((unsigned char)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_187 = registry->fe_items;
    zT_188 = fstart + fi;
    zT_189 = zT_187[zT_188];
    fe = zT_189;
    zT_191 = "FER:n";
    zT_193 = 5;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    fer_nm = zT_192;
    zT_194 = fer_nm;
    zF_C914CB83_markerWriteInt(zT_194, (unsigned int)((unsigned int)(unsigned int)(fstart + fi)));
    zT_199 = "FER:t";
    zT_201 = 5;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    fer_tm = zT_200;
    zT_202 = fer_tm;
    zT_203 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_202, zT_203);
    zT_206 = registry->types_items;
    zT_207 = fe.type_id;
    zT_208 = (unsigned int)zT_207;
    zT_209 = zT_206[zT_208];
    ft = zT_209;
    zT_210 = ft.kind;
    if ((unsigned char)(zT_210 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_224 = tag_ty.alignment;
    if ((unsigned char)(zT_224 > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_220 = 1;
    zT_222 = fi + (unsigned int)((unsigned int)zT_220);
    fi = zT_222;
    goto z_bb_42;
    z_bb_46:
    zT_214 = ft.size;
    if ((unsigned char)(zT_214 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_216 = ft.size;
    max_ps = zT_216;
    goto z_bb_49;
    z_bb_49:
    zT_217 = ft.alignment;
    if ((unsigned char)(zT_217 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_219 = ft.alignment;
    max_pa = zT_219;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_226 = tag_ty.alignment;
    goto z_bb_54;
    z_bb_53:
    zT_226 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_226;
    zT_229 = tag_ty.size;
    total = zT_229;
    zT_230 = total;
    zT_231 = max_pa;
    zT_232 = zF_D2BAC673_alignUp_1(zT_230, zT_231);
    total = zT_232;
    zT_233 = max_ps;
    zT_234 = max_pa;
    zT_235 = zF_D2BAC673_alignUp_1(zT_233, zT_234);
    zT_236 = total + zT_235;
    total = zT_236;
    zT_237 = total;
    zT_238 = overall_align;
    zT_239 = zF_D2BAC673_alignUp_1(zT_237, zT_238);
    ty.size = zT_239;
    ty.alignment = overall_align;
    zT_240 = registry->types_items;
    zT_240[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_246 = registry->opt_items;
    zT_247 = ty.payload_idx;
    zT_248 = (unsigned int)zT_247;
    zT_249 = zT_246[zT_248];
    op = zT_249;
    zT_251 = registry->types_items;
    zT_252 = op.payload;
    zT_253 = (unsigned int)zT_252;
    zT_254 = zT_251[zT_253];
    pt = zT_254;
    zT_256 = pt.alignment;
    if ((unsigned char)(zT_256 > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_273 = ty.kind;
    if ((unsigned char)(zT_273 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_259 = pt.alignment;
    goto z_bb_60;
    z_bb_59:
    zT_259 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_259;
    zT_264 = pt.size;
    zT_268 = zF_D2BAC673_alignUp_1(zT_264, (unsigned int)(4));
    zT_263 = pay_align;
    zT_271 = zF_D2BAC673_alignUp_1((unsigned int)(zT_268 + (unsigned int)(4)), zT_263);
    ty.size = zT_271;
    ty.alignment = pay_align;
    zT_272 = registry->types_items;
    zT_272[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_278 = registry->eu_items;
    zT_279 = ty.payload_idx;
    zT_280 = (unsigned int)zT_279;
    zT_281 = zT_278[zT_280];
    ep_1 = zT_281;
    zT_283 = registry->types_items;
    zT_284 = ep_1.payload;
    zT_285 = (unsigned int)zT_284;
    zT_286 = zT_283[zT_285];
    pt = zT_286;
    zT_288 = pt.size;
    if ((unsigned char)(zT_288 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_315 = ty.kind;
    if ((unsigned char)(zT_315 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_291 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_291 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_291;
    zT_295 = pt.alignment;
    if ((unsigned char)(zT_295 > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_298 = pt.alignment;
    goto z_bb_69;
    z_bb_68:
    zT_298 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_298;
    zT_302 = union_sz;
    zT_303 = union_align;
    zT_304 = zF_D2BAC673_alignUp_1(zT_302, zT_303);
    total = zT_304;
    zT_305 = total;
    zT_308 = zF_D2BAC673_alignUp_1(zT_305, (unsigned int)(4));
    zT_310 = zT_308 + (unsigned int)(4);
    total = zT_310;
    zT_311 = total;
    zT_312 = union_align;
    zT_313 = zF_D2BAC673_alignUp_1(zT_311, zT_312);
    ty.size = zT_313;
    ty.alignment = union_align;
    zT_314 = registry->types_items;
    zT_314[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_320 = registry->array_items;
    zT_321 = ty.payload_idx;
    zT_322 = (unsigned int)zT_321;
    zT_323 = zT_320[zT_322];
    ap = zT_323;
    zT_325 = registry->types_items;
    zT_326 = ap.elem;
    zT_327 = (unsigned int)zT_326;
    zT_328 = zT_325[zT_327];
    et = zT_328;
    zT_329 = et.size;
    zT_330 = ap.length;
    ty.size = (unsigned int)(zT_329 * zT_330);
    zT_332 = et.alignment;
    ty.alignment = zT_332;
    zT_333 = registry->types_items;
    zT_333[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_334 = ty.kind;
    if ((unsigned char)(zT_334 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_339 = registry->tup_items;
    zT_340 = ty.payload_idx;
    zT_341 = (unsigned int)zT_340;
    zT_342 = zT_339[zT_341];
    tp_2 = zT_342;
    zT_344 = tp_2.elems_start;
    zT_345 = (unsigned int)zT_344;
    estr = zT_345;
    zT_347 = tp_2.elems_count;
    zT_348 = (unsigned int)zT_347;
    ecount = zT_348;
    zT_350 = 0;
    zT_351 = (unsigned int)zT_350;
    offset = zT_351;
    zT_353 = 1;
    zT_354 = (unsigned int)zT_353;
    max_align = zT_354;
    zT_356 = 0;
    zT_357 = (unsigned int)zT_356;
    ei = zT_357;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    if ((unsigned char)(ei < ecount)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_360 = registry->xt_items;
    zT_361 = estr + ei;
    zT_362 = zT_360[zT_361];
    elem_tid = zT_362;
    zT_364 = registry->types_items;
    zT_365 = (unsigned int)elem_tid;
    zT_366 = zT_364[zT_365];
    et = zT_366;
    zT_367 = offset;
    zT_368 = et.alignment;
    zT_370 = zF_D2BAC673_alignUp_1(zT_367, zT_368);
    offset = zT_370;
    zT_371 = et.size;
    zT_372 = offset + zT_371;
    offset = zT_372;
    zT_373 = et.alignment;
    if ((unsigned char)(zT_373 > max_align)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_379 = offset;
    zT_380 = max_align;
    zT_381 = zF_D2BAC673_alignUp_1(zT_379, zT_380);
    ty.size = zT_381;
    ty.alignment = max_align;
    zT_382 = ty.size;
    if ((unsigned char)(zT_382 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_376 = 1;
    zT_378 = ei + (unsigned int)((unsigned int)zT_376);
    ei = zT_378;
    goto z_bb_75;
    z_bb_79:
    zT_375 = et.alignment;
    max_align = zT_375;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_82;
    z_bb_82:
    zT_387 = registry->types_items;
    zT_387[idx] = ty;
    goto z_bb_74;
}

/* layoutDepOk */
unsigned char zF_BEEAF73E_layoutDepOk(zT_338B7C76_TypeRegistry* registry, unsigned int dep, unsigned int depth) {
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_15 = 0;
    if ((unsigned char)(dep == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(dep == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(dep == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_12 = registry;
    zT_13 = dep;
    zT_14 = depth;
    zT_15 = zF_3E55D0D5_layoutEnsure(zT_12, zT_13, zT_14);
    return zT_15;
}

/* layoutFieldDepsOk */
unsigned char zF_B32C0425_layoutFieldDepsOk(zT_338B7C76_TypeRegistry* registry, unsigned int fstart, unsigned short fcount, unsigned int depth) {
    int zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_2DF01B61_FieldEntry* zT_12;
    unsigned int zT_14;
    zT_2DF01B61_FieldEntry zT_15;
    unsigned char zT_17 = 0;
    int zT_20;
    unsigned int zT_22;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = registry;
    zT_12 = registry->fe_items;
    zT_14 = (unsigned int)((unsigned int)fstart) + fi;
    zT_15 = zT_12[zT_14];
    zT_10 = zT_15.type_id;
    zT_11 = depth;
    zT_17 = zF_BEEAF73E_layoutDepOk(zT_9, zT_10, zT_11);
    if ((unsigned char)(!zT_17)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_20 = 1;
    zT_22 = fi + (unsigned int)((unsigned int)zT_20);
    fi = zT_22;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
}

/* layoutEnsure */
unsigned char zF_3E55D0D5_layoutEnsure(zT_338B7C76_TypeRegistry* registry, unsigned int tid, unsigned int depth) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    unsigned char zT_14;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_406493CE_StructPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    unsigned short zT_36;
    unsigned char zT_42 = 0;
    zT_33EF6BFB_TypeKind zT_43;
    zT_457ECFEE_EnumPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_457ECFEE_EnumPayload zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    unsigned char zT_58 = 0;
    zT_33EF6BFB_TypeKind zT_59;
    zT_AF9231A2_UnionPayload* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_AF9231A2_UnionPayload zT_67;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned short zT_70;
    unsigned char zT_76 = 0;
    zT_33EF6BFB_TypeKind zT_77;
    zT_AF9231A2_UnionPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_AF9231A2_UnionPayload zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    unsigned short zT_88;
    unsigned char zT_94 = 0;
    zT_33EF6BFB_TypeKind zT_95;
    zT_54FF90FA_TaggedUnionPayload* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_54FF90FA_TaggedUnionPayload zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    unsigned char zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned short zT_113;
    unsigned char zT_119 = 0;
    zT_33EF6BFB_TypeKind zT_120;
    zT_E834303C_ArrayPayload* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_E834303C_ArrayPayload zT_128;
    zT_338B7C76_TypeRegistry* zT_129;
    unsigned int zT_130;
    unsigned char zT_135 = 0;
    zT_33EF6BFB_TypeKind zT_136;
    zT_666DC2E1_TuplePayload* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_666DC2E1_TuplePayload zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned short zT_148;
    zT_338B7C76_TypeRegistry* zT_151;
    unsigned int zT_152;
    unsigned int* zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned char zT_161 = 0;
    unsigned char zT_163;
    int zT_164;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    zT_0B10E8E9_OptionalPayload* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_0B10E8E9_OptionalPayload zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    unsigned int zT_177;
    unsigned char zT_182 = 0;
    zT_33EF6BFB_TypeKind zT_183;
    zT_42C2D6BF_EUPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_42C2D6BF_EUPayload zT_191;
    zT_338B7C76_TypeRegistry* zT_192;
    unsigned int zT_193;
    unsigned char zT_198 = 0;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_204;
    unsigned int zT_205;
    zT_D155D06D_Type* zT_207;
    zT_D155D06D_Type* zT_209;
    zT_D155D06D_Type ty;
    unsigned char deps_ok;
    unsigned char handled;
    zT_406493CE_StructPayload sp;
    zT_457ECFEE_EnumPayload ep;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_E834303C_ArrayPayload ap;
    zT_666DC2E1_TuplePayload tup;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload op;
    zT_42C2D6BF_EUPayload eup;
    if ((unsigned char)(tid == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = registry->types_items;
    zT_12 = (unsigned int)tid;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.state;
    if ((unsigned char)(zT_14 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_22 = 1;
    deps_ok = zT_22;
    zT_24 = 1;
    handled = zT_24;
    zT_25 = ty.kind;
    if ((unsigned char)(zT_25 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_30 = registry->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = registry;
    zT_35 = sp.fields_start;
    zT_36 = sp.fields_count;
    zT_42 = zF_B32C0425_layoutFieldDepsOk(zT_34, zT_35, zT_36, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_42;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(!handled)) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_43 = ty.kind;
    if ((unsigned char)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_48 = registry->en_items;
    zT_49 = ty.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    ep = zT_51;
    zT_52 = registry;
    zT_53 = ep.backing_type;
    zT_58 = zF_BEEAF73E_layoutDepOk(zT_52, zT_53, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_58;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_59 = ty.kind;
    if ((unsigned char)(zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_64 = registry->un_items;
    zT_65 = ty.payload_idx;
    zT_66 = (unsigned int)zT_65;
    zT_67 = zT_64[zT_66];
    up = zT_67;
    zT_68 = registry;
    zT_69 = up.fields_start;
    zT_70 = up.fields_count;
    zT_76 = zF_B32C0425_layoutFieldDepsOk(zT_68, zT_69, zT_70, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_76;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_82 = registry->un_items;
    zT_83 = ty.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    pup = zT_85;
    zT_86 = registry;
    zT_87 = pup.fields_start;
    zT_88 = pup.fields_count;
    zT_94 = zF_B32C0425_layoutFieldDepsOk(zT_86, zT_87, zT_88, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_94;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_95 = ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_100 = registry->tu_items;
    zT_101 = ty.payload_idx;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    tp = zT_103;
    zT_104 = registry;
    zT_105 = tp.tag_type;
    zT_110 = zF_BEEAF73E_layoutDepOk(zT_104, zT_105, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_110;
    if (deps_ok) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_120 = ty.kind;
    if ((unsigned char)(zT_120 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_111 = registry;
    zT_112 = tp.fields_start;
    zT_113 = tp.fields_count;
    zT_119 = zF_B32C0425_layoutFieldDepsOk(zT_111, zT_112, zT_113, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_119;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_125 = registry->array_items;
    zT_126 = ty.payload_idx;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zT_125[zT_127];
    ap = zT_128;
    zT_129 = registry;
    zT_130 = ap.elem;
    zT_135 = zF_BEEAF73E_layoutDepOk(zT_129, zT_130, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_135;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    zT_136 = ty.kind;
    if ((unsigned char)(zT_136 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_141 = registry->tup_items;
    zT_142 = ty.payload_idx;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    tup = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    ei = zT_147;
    goto z_bb_32;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_167 = ty.kind;
    if ((unsigned char)(zT_167 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_40;
    z_bb_32:
    zT_148 = tup.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_148))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_151 = registry;
    zT_154 = registry->xt_items;
    zT_155 = tup.elems_start;
    zT_157 = (unsigned int)((unsigned int)zT_155) + ei;
    zT_152 = zT_154[zT_157];
    zT_161 = zF_BEEAF73E_layoutDepOk(zT_151, zT_152, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_161)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_164 = 1;
    zT_166 = ei + (unsigned int)((unsigned int)zT_164);
    ei = zT_166;
    goto z_bb_32;
    z_bb_36:
    zT_163 = 0;
    deps_ok = zT_163;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    zT_172 = registry->opt_items;
    zT_173 = ty.payload_idx;
    zT_174 = (unsigned int)zT_173;
    zT_175 = zT_172[zT_174];
    op = zT_175;
    zT_176 = registry;
    zT_177 = op.payload;
    zT_182 = zF_BEEAF73E_layoutDepOk(zT_176, zT_177, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_182;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_30;
    z_bb_40:
    zT_183 = ty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_188 = registry->eu_items;
    zT_189 = ty.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    eup = zT_191;
    zT_192 = registry;
    zT_193 = eup.payload;
    zT_198 = zF_BEEAF73E_layoutDepOk(zT_192, zT_193, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_198;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_199 = 0;
    handled = zT_199;
    goto z_bb_42;
    z_bb_44:
    return (unsigned char)(0);
    z_bb_45:
    if ((unsigned char)(!deps_ok)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return (unsigned char)(0);
    z_bb_47:
    zT_204 = registry;
    zT_205 = tid;
    zF_0E9E97D8_layoutCompute(zT_204, zT_205);
    zT_207 = registry->types_items;
    zT_209 = zT_207 + (unsigned int)((unsigned int)tid);
    zT_209->state = (unsigned char)(2);
    return (unsigned char)(1);
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned char zT_7 = 0;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    zT_2 = self->registry;
    zT_3 = tid;
    zT_7 = zF_3E55D0D5_layoutEnsure(zT_2, zT_3, (unsigned int)(0));
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->registry;
    zT_10 = tid;
    zF_0E9E97D8_layoutCompute(zT_9, zT_10);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    zT_019EE88E_EU_932 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_18 = i + (unsigned int)((unsigned int)zT_16);
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_25 = self->alloc;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(type_count * (unsigned int)(4)), (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_34 = zT_32.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_45 = zi + (unsigned int)((unsigned int)zT_43);
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    if ((unsigned char)(ei < zT_49)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    if ((unsigned char)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_62 = zT_59 + (unsigned int)((unsigned int)zT_60);
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_67 = ei + (unsigned int)((unsigned int)zT_65);
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    unsigned char zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_D155D06D_Type* zT_117;
    int zT_118;
    unsigned int zT_120;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((unsigned char)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((unsigned char)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_19 = ti + (unsigned int)((unsigned int)zT_17);
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    if ((unsigned char)(zT_20 > (unsigned int)zT_21)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    self->sorted_len = (unsigned int)(zT_30 + (unsigned int)(1));
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_39 = zT_37 + (unsigned int)((unsigned int)tid);
    zT_39->state = (unsigned char)(2);
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    if ((unsigned char)(ei < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    if ((unsigned char)(zT_47 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    if ((unsigned char)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_74 = ei + (unsigned int)((unsigned int)zT_72);
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    if ((unsigned char)(zT_57 > (unsigned int)zT_58)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_64 = zT_61 - (unsigned int)((unsigned int)zT_62);
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    if ((unsigned char)(zT_67 == (unsigned int)zT_68)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((unsigned char)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    zT_83 = ty.state;
    if ((unsigned char)(zT_83 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_118 = 1;
    zT_120 = ci + (unsigned int)((unsigned int)zT_118);
    ci = zT_120;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_86 = zT_88 > (unsigned int)zT_89;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = self->diag;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_101);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    ty.alignment = (unsigned int)(1);
    ty.state = (unsigned char)(2);
    zT_116 = self->registry;
    zT_117 = zT_116->types_items;
    zT_117[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* fieldEmbedsByValue */
unsigned char zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(0);
}

/* requiresFullDef */
unsigned char zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(0);
}

/* layoutFieldNeedsEdge */
unsigned char zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    return (unsigned char)(0);
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    unsigned char zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    if ((unsigned char)(field_type >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    zT_12 = ft.kind;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    int zT_18;
    unsigned int zT_20;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_15 = (unsigned int)((unsigned int)fstart) + fi;
    zT_16 = zT_13[zT_15];
    zT_10 = zT_16.type_id;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_20 = fi + (unsigned int)((unsigned int)zT_18);
    fi = zT_20;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_406493CE_StructPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    zT_C890C8CB_TypeResolver* zT_23;
    unsigned int zT_24;
    unsigned short zT_25;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_29;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_54FF90FA_TaggedUnionPayload* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_54FF90FA_TaggedUnionPayload zT_38;
    zT_C890C8CB_TypeResolver* zT_39;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_42;
    zT_33EF6BFB_TypeKind zT_45;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_AF9231A2_UnionPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_AF9231A2_UnionPayload zT_54;
    zT_C890C8CB_TypeResolver* zT_55;
    unsigned int zT_56;
    unsigned short zT_57;
    unsigned int zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_AF9231A2_UnionPayload* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_AF9231A2_UnionPayload zT_70;
    zT_C890C8CB_TypeResolver* zT_71;
    unsigned int zT_72;
    unsigned short zT_73;
    unsigned int zT_74;
    zT_33EF6BFB_TypeKind zT_77;
    zT_C890C8CB_TypeResolver* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_E834303C_ArrayPayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_E834303C_ArrayPayload zT_88;
    zT_33EF6BFB_TypeKind zT_90;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_666DC2E1_TuplePayload* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_666DC2E1_TuplePayload zT_99;
    int zT_101;
    unsigned int zT_102;
    unsigned short zT_103;
    zT_C890C8CB_TypeResolver* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int* zT_110;
    unsigned int zT_111;
    unsigned int zT_113;
    int zT_115;
    unsigned int zT_117;
    zT_33EF6BFB_TypeKind zT_118;
    zT_C890C8CB_TypeResolver* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_338B7C76_TypeRegistry* zT_125;
    zT_0B10E8E9_OptionalPayload* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_0B10E8E9_OptionalPayload zT_129;
    zT_33EF6BFB_TypeKind zT_131;
    zT_C890C8CB_TypeResolver* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_42C2D6BF_EUPayload* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_42C2D6BF_EUPayload zT_142;
    int zT_144;
    unsigned int zT_146;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    zT_13 = ty.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_144 = 1;
    zT_146 = ti + (unsigned int)((unsigned int)zT_144);
    ti = zT_146;
    goto z_bb_1;
    z_bb_5:
    zT_18 = self->registry;
    zT_19 = zT_18->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_23 = self;
    zT_24 = sp.fields_start;
    zT_25 = sp.fields_count;
    zT_26 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_23, zT_24, zT_25, zT_26);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_29 = ty.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_34 = self->registry;
    zT_35 = zT_34->tu_items;
    zT_36 = ty.payload_idx;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zT_35[zT_37];
    tp = zT_38;
    zT_39 = self;
    zT_40 = tp.fields_start;
    zT_41 = tp.fields_count;
    zT_42 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_39, zT_40, zT_41, zT_42);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_45 = ty.kind;
    if ((unsigned char)(zT_45 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_50 = self->registry;
    zT_51 = zT_50->un_items;
    zT_52 = ty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    up = zT_54;
    zT_55 = self;
    zT_56 = up.fields_start;
    zT_57 = up.fields_count;
    zT_58 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_55, zT_56, zT_57, zT_58);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_61 = ty.kind;
    if ((unsigned char)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_66 = self->registry;
    zT_67 = zT_66->un_items;
    zT_68 = ty.payload_idx;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zT_67[zT_69];
    pup = zT_70;
    zT_71 = self;
    zT_72 = pup.fields_start;
    zT_73 = pup.fields_count;
    zT_74 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_71, zT_72, zT_73, zT_74);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_81 = self;
    zT_84 = self->registry;
    zT_85 = zT_84->array_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    zT_82 = zT_88.elem;
    zT_83 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_81, zT_82, zT_83);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_90 = ty.kind;
    if ((unsigned char)(zT_90 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_95 = self->registry;
    zT_96 = zT_95->tup_items;
    zT_97 = ty.payload_idx;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    tp_1 = zT_99;
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    ei = zT_102;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_118 = ty.kind;
    if ((unsigned char)(zT_118 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_27; else goto z_bb_29;
    z_bb_23:
    zT_103 = tp_1.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_103))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_106 = self;
    zT_109 = self->registry;
    zT_110 = zT_109->xt_items;
    zT_111 = tp_1.elems_start;
    zT_113 = (unsigned int)((unsigned int)zT_111) + ei;
    zT_107 = zT_110[zT_113];
    zT_108 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_106, zT_107, zT_108);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_21;
    z_bb_26:
    zT_115 = 1;
    zT_117 = ei + (unsigned int)((unsigned int)zT_115);
    ei = zT_117;
    goto z_bb_23;
    z_bb_27:
    zT_122 = self;
    zT_125 = self->registry;
    zT_126 = zT_125->opt_items;
    zT_127 = ty.payload_idx;
    zT_128 = (unsigned int)zT_127;
    zT_129 = zT_126[zT_128];
    zT_123 = zT_129.payload;
    zT_124 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_122, zT_123, zT_124);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_131 = ty.kind;
    if ((unsigned char)(zT_131 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_135 = self;
    zT_138 = self->registry;
    zT_139 = zT_138->eu_items;
    zT_140 = ty.payload_idx;
    zT_141 = (unsigned int)zT_140;
    zT_142 = zT_139[zT_141];
    zT_136 = zT_142.payload;
    zT_137 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_135, zT_136, zT_137);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_28;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    int zT_9;
    int zT_11;
    zT_019EE88E_EU_932 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    int zT_26;
    int zT_28;
    zT_019EE88E_EU_932 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    int zT_40;
    int zT_42;
    zT_019EE88E_EU_932 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    int zT_54;
    int zT_56;
    zT_019EE88E_EU_932 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_71;
    unsigned int zT_73;
    zT_3E40CD83_Sand* zT_75;
    int zT_78;
    int zT_80;
    zT_019EE88E_EU_932 zT_82 = {0};
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int* zT_87;
    unsigned int zT_89;
    unsigned int zT_91;
    int zT_93;
    unsigned int zT_94;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type* zT_98;
    zT_D155D06D_Type zT_99;
    unsigned char zT_101;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_406493CE_StructPayload* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_406493CE_StructPayload zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned short zT_115;
    unsigned char zT_118;
    int zT_119;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_2DF01B61_FieldEntry* zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    zT_2DF01B61_FieldEntry zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    unsigned char zT_136 = 0;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_3E40CD83_Sand* zT_142;
    unsigned int** zT_143;
    unsigned int** zT_144;
    unsigned int* zT_145;
    unsigned int zT_146;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    zT_33EF6BFB_TypeKind zT_158;
    zT_3E40CD83_Sand* zT_162;
    unsigned int** zT_163;
    unsigned int** zT_164;
    unsigned int* zT_165;
    unsigned int zT_166;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_177;
    int zT_178;
    unsigned int zT_180;
    zT_33EF6BFB_TypeKind zT_181;
    zT_338B7C76_TypeRegistry* zT_186;
    zT_54FF90FA_TaggedUnionPayload* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_54FF90FA_TaggedUnionPayload zT_190;
    int zT_192;
    unsigned int zT_193;
    unsigned short zT_194;
    unsigned char zT_197;
    int zT_198;
    zT_338B7C76_TypeRegistry* zT_201;
    zT_2DF01B61_FieldEntry* zT_202;
    unsigned int zT_203;
    unsigned int zT_205;
    zT_2DF01B61_FieldEntry zT_206;
    unsigned int zT_207;
    zT_338B7C76_TypeRegistry* zT_209;
    zT_D155D06D_Type* zT_210;
    unsigned int zT_211;
    zT_D155D06D_Type zT_212;
    zT_33EF6BFB_TypeKind zT_213;
    unsigned char zT_215 = 0;
    unsigned char zT_216;
    zT_33EF6BFB_TypeKind zT_217;
    zT_3E40CD83_Sand* zT_221;
    unsigned int** zT_222;
    unsigned int** zT_223;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_236;
    zT_33EF6BFB_TypeKind zT_237;
    zT_3E40CD83_Sand* zT_241;
    unsigned int** zT_242;
    unsigned int** zT_243;
    unsigned int* zT_244;
    unsigned int zT_245;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    int zT_257;
    unsigned int zT_259;
    zT_33EF6BFB_TypeKind zT_260;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_AF9231A2_UnionPayload* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_AF9231A2_UnionPayload zT_269;
    int zT_271;
    unsigned int zT_272;
    unsigned short zT_273;
    unsigned char zT_276;
    int zT_277;
    zT_338B7C76_TypeRegistry* zT_280;
    zT_2DF01B61_FieldEntry* zT_281;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_2DF01B61_FieldEntry zT_285;
    unsigned int zT_286;
    zT_338B7C76_TypeRegistry* zT_288;
    zT_D155D06D_Type* zT_289;
    unsigned int zT_290;
    zT_D155D06D_Type zT_291;
    zT_33EF6BFB_TypeKind zT_292;
    unsigned char zT_294 = 0;
    unsigned char zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_3E40CD83_Sand* zT_300;
    unsigned int** zT_301;
    unsigned int** zT_302;
    unsigned int* zT_303;
    unsigned int zT_304;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    unsigned int zT_315;
    zT_33EF6BFB_TypeKind zT_316;
    zT_3E40CD83_Sand* zT_320;
    unsigned int** zT_321;
    unsigned int** zT_322;
    unsigned int* zT_323;
    unsigned int zT_324;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_335;
    int zT_336;
    unsigned int zT_338;
    zT_33EF6BFB_TypeKind zT_339;
    zT_338B7C76_TypeRegistry* zT_344;
    zT_AF9231A2_UnionPayload* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    zT_AF9231A2_UnionPayload zT_348;
    int zT_350;
    unsigned int zT_351;
    unsigned short zT_352;
    unsigned char zT_355;
    int zT_356;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_2DF01B61_FieldEntry* zT_360;
    unsigned int zT_361;
    unsigned int zT_363;
    zT_2DF01B61_FieldEntry zT_364;
    unsigned int zT_365;
    zT_338B7C76_TypeRegistry* zT_367;
    zT_D155D06D_Type* zT_368;
    unsigned int zT_369;
    zT_D155D06D_Type zT_370;
    zT_33EF6BFB_TypeKind zT_371;
    unsigned char zT_373 = 0;
    unsigned char zT_374;
    zT_33EF6BFB_TypeKind zT_375;
    zT_3E40CD83_Sand* zT_379;
    unsigned int** zT_380;
    unsigned int** zT_381;
    unsigned int* zT_382;
    unsigned int zT_383;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    unsigned int zT_394;
    zT_33EF6BFB_TypeKind zT_395;
    zT_3E40CD83_Sand* zT_399;
    unsigned int** zT_400;
    unsigned int** zT_401;
    unsigned int* zT_402;
    unsigned int zT_403;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_414;
    int zT_415;
    unsigned int zT_417;
    zT_33EF6BFB_TypeKind zT_418;
    zT_338B7C76_TypeRegistry* zT_423;
    zT_E834303C_ArrayPayload* zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    zT_E834303C_ArrayPayload zT_427;
    unsigned int zT_428;
    zT_338B7C76_TypeRegistry* zT_430;
    zT_D155D06D_Type* zT_431;
    unsigned int zT_432;
    zT_D155D06D_Type zT_433;
    zT_33EF6BFB_TypeKind zT_434;
    unsigned char zT_436 = 0;
    unsigned char zT_437;
    zT_33EF6BFB_TypeKind zT_438;
    zT_3E40CD83_Sand* zT_442;
    unsigned int** zT_443;
    unsigned int** zT_444;
    unsigned int* zT_445;
    unsigned int zT_446;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    unsigned int zT_457;
    zT_33EF6BFB_TypeKind zT_458;
    zT_3E40CD83_Sand* zT_462;
    unsigned int** zT_463;
    unsigned int** zT_464;
    unsigned int* zT_465;
    unsigned int zT_466;
    unsigned int zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_477;
    zT_33EF6BFB_TypeKind zT_478;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_42C2D6BF_EUPayload* zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    zT_42C2D6BF_EUPayload zT_487;
    unsigned int zT_488;
    zT_338B7C76_TypeRegistry* zT_490;
    zT_D155D06D_Type* zT_491;
    unsigned int zT_492;
    zT_D155D06D_Type zT_493;
    zT_33EF6BFB_TypeKind zT_494;
    unsigned char zT_496 = 0;
    unsigned char zT_497;
    zT_33EF6BFB_TypeKind zT_498;
    zT_3E40CD83_Sand* zT_502;
    unsigned int** zT_503;
    unsigned int** zT_504;
    unsigned int* zT_505;
    unsigned int zT_506;
    unsigned int zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned int zT_517;
    zT_33EF6BFB_TypeKind zT_518;
    zT_3E40CD83_Sand* zT_522;
    unsigned int** zT_523;
    unsigned int** zT_524;
    unsigned int* zT_525;
    unsigned int zT_526;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    unsigned int zT_535;
    unsigned int zT_537;
    zT_33EF6BFB_TypeKind zT_538;
    zT_338B7C76_TypeRegistry* zT_543;
    zT_0B10E8E9_OptionalPayload* zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    zT_0B10E8E9_OptionalPayload zT_547;
    unsigned int zT_548;
    zT_338B7C76_TypeRegistry* zT_550;
    zT_D155D06D_Type* zT_551;
    unsigned int zT_552;
    zT_D155D06D_Type zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    unsigned char zT_556 = 0;
    unsigned char zT_557;
    zT_33EF6BFB_TypeKind zT_558;
    zT_3E40CD83_Sand* zT_562;
    unsigned int** zT_563;
    unsigned int** zT_564;
    unsigned int* zT_565;
    unsigned int zT_566;
    unsigned int zT_570;
    unsigned int zT_571;
    unsigned int zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_577;
    zT_33EF6BFB_TypeKind zT_578;
    zT_3E40CD83_Sand* zT_582;
    unsigned int** zT_583;
    unsigned int** zT_584;
    unsigned int* zT_585;
    unsigned int zT_586;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned int zT_597;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned int zT_603;
    int zT_604;
    unsigned int zT_606;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_612;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned char zT_622;
    unsigned char zT_625;
    unsigned int zT_626;
    unsigned int zT_627;
    unsigned int zT_629;
    unsigned int zT_630;
    unsigned int zT_631;
    zT_3E40CD83_Sand* zT_633;
    int zT_636;
    int zT_638;
    zT_019EE88E_EU_932 zT_640 = {0};
    unsigned char zT_641;
    unsigned char* zT_642;
    unsigned int* zT_645;
    unsigned int zT_647;
    int zT_648;
    unsigned int zT_649;
    unsigned char zT_651;
    unsigned int zT_654;
    unsigned int zT_655;
    unsigned int zT_657;
    int zT_658;
    unsigned int zT_660;
    unsigned char* zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    unsigned int zT_664;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_665;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_667;
    unsigned int zT_669;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_670;
    int zT_673;
    unsigned char* zT_674;
    unsigned int zT_675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_676;
    unsigned int zT_677 = 0;
    unsigned int zT_681;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_682;
    unsigned char* zT_686;
    unsigned int zT_687;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_688;
    unsigned char* zT_690;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_691;
    unsigned int zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_693;
    int zT_694;
    unsigned int zT_695;
    unsigned char zT_697;
    unsigned char* zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    unsigned int zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    unsigned char* zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    unsigned int zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_714;
    int zT_718;
    unsigned char* zT_719;
    unsigned int zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    unsigned int zT_722 = 0;
    unsigned int zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned char* zT_731;
    unsigned int zT_732;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_733;
    unsigned char* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_740;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_743;
    zT_338B7C76_TypeRegistry* zT_744;
    zT_D155D06D_Type* zT_745;
    zT_D155D06D_Type zT_746;
    zT_33EF6BFB_TypeKind zT_747;
    int zT_751;
    unsigned char* zT_752;
    unsigned int zT_753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_754;
    unsigned int zT_755 = 0;
    unsigned int zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_760;
    unsigned char* zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned char* zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned int zT_770;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_771;
    int zT_772;
    unsigned int zT_774;
    zT_010C8DF0_ClassificationResul zT_775;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_5A26C2ED_Arr_unsigned_char_1 cls_b;
    unsigned int cls_l;
    unsigned int cls_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_5A26C2ED_Arr_unsigned_char_1 ctb;
    unsigned int ctl;
    unsigned int cts;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_5A26C2ED_Arr_unsigned_char_1 ckb;
    unsigned int ckl;
    unsigned int cks;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_11 = 1;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(zT_9 * tl), (unsigned int)((unsigned int)zT_11));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_28 = 4;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)(zT_26 * wp_edge_cap), (unsigned int)((unsigned int)zT_28));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_42 = 4;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)(zT_40 * wp_edge_cap), (unsigned int)((unsigned int)zT_42));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_46 = zT_44.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_56 = 4;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, (unsigned int)(zT_54 * tl), (unsigned int)((unsigned int)zT_56));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_60 = zT_58.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_73 = 0;
    wp_count = zT_73;
    zT_75 = perm_alloc;
    zT_78 = 4;
    zT_80 = 4;
    zT_82 = zF_1395EB68_sandAlloc(zT_75, (unsigned int)(zT_78 * tl), (unsigned int)((unsigned int)zT_80));
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_71 = whi + (unsigned int)((unsigned int)zT_69);
    whi = zT_71;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_84 = zT_82.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_84;
    zT_87 = (unsigned int*)wl_raw;
    worklist = zT_87;
    zT_89 = 0;
    wl_head = zT_89;
    zT_91 = 0;
    wl_tail = zT_91;
    zT_93 = 0;
    zT_94 = (unsigned int)zT_93;
    ti = zT_94;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_97 = self->registry;
    zT_98 = zT_97->types_items;
    zT_99 = zT_98[ti];
    ty = zT_99;
    zT_101 = 1;
    is_po = zT_101;
    zT_102 = ty.kind;
    if ((unsigned char)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_604 = 1;
    zT_606 = ti + (unsigned int)((unsigned int)zT_604);
    ti = zT_606;
    goto z_bb_20;
    z_bb_24:
    zT_107 = self->registry;
    zT_108 = zT_107->st_items;
    zT_109 = ty.payload_idx;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zT_108[zT_110];
    sp = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fi = zT_114;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((unsigned char)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_181 = ty.kind;
    if ((unsigned char)(zT_181 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_115 = sp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_115))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_122 = self->registry;
    zT_123 = zT_122->fe_items;
    zT_124 = sp.fields_start;
    zT_126 = (unsigned int)((unsigned int)zT_124) + fi;
    zT_127 = zT_123[zT_126];
    zT_128 = zT_127.type_id;
    ft_id = zT_128;
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)ft_id;
    zT_133 = zT_131[zT_132];
    ft = zT_133;
    zT_134 = ft.kind;
    zT_136 = zF_A47239A9_fieldEmbedsByValue(zT_134);
    if (zT_136) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_178 = 1;
    zT_180 = fi + (unsigned int)((unsigned int)zT_178);
    fi = zT_180;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 0;
    zT_118 = is_po != zT_119;
    goto z_bb_33;
    z_bb_32:
    zT_118 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_118) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_137 = 0;
    is_po = zT_137;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_138 = ft.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_142 = perm_alloc;
    zT_143 = &wp_to;
    zT_144 = &wp_next;
    zT_145 = &wp_edge_cap;
    zT_146 = wp_count;
    zF_25C377BD_growWpEdges(zT_142, zT_143, zT_144, zT_145, zT_146);
    zT_150 = (unsigned int)ti;
    zT_151 = (unsigned int)wp_count;
    wp_to[zT_151] = zT_150;
    zT_152 = (unsigned int)ft_id;
    zT_153 = wp_head[zT_152];
    zT_154 = (unsigned int)wp_count;
    wp_next[zT_154] = zT_153;
    zT_155 = (unsigned int)ft_id;
    wp_head[zT_155] = wp_count;
    zT_157 = wp_count + (unsigned int)(1);
    wp_count = zT_157;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_158 = ft.kind;
    if ((unsigned char)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_162 = perm_alloc;
    zT_163 = &wp_to;
    zT_164 = &wp_next;
    zT_165 = &wp_edge_cap;
    zT_166 = wp_count;
    zF_25C377BD_growWpEdges(zT_162, zT_163, zT_164, zT_165, zT_166);
    zT_170 = (unsigned int)ti;
    zT_171 = (unsigned int)wp_count;
    wp_to[zT_171] = zT_170;
    zT_172 = (unsigned int)ft_id;
    zT_173 = wp_head[zT_172];
    zT_174 = (unsigned int)wp_count;
    wp_next[zT_174] = zT_173;
    zT_175 = (unsigned int)ft_id;
    wp_head[zT_175] = wp_count;
    zT_177 = wp_count + (unsigned int)(1);
    wp_count = zT_177;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_186 = self->registry;
    zT_187 = zT_186->tu_items;
    zT_188 = ty.payload_idx;
    zT_189 = (unsigned int)zT_188;
    zT_190 = zT_187[zT_189];
    tp = zT_190;
    zT_192 = 0;
    zT_193 = (unsigned int)zT_192;
    fi = zT_193;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_260 = ty.kind;
    if ((unsigned char)(zT_260 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_194 = tp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_194))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_201 = self->registry;
    zT_202 = zT_201->fe_items;
    zT_203 = tp.fields_start;
    zT_205 = (unsigned int)((unsigned int)zT_203) + fi;
    zT_206 = zT_202[zT_205];
    zT_207 = zT_206.type_id;
    ft_id = zT_207;
    zT_209 = self->registry;
    zT_210 = zT_209->types_items;
    zT_211 = (unsigned int)ft_id;
    zT_212 = zT_210[zT_211];
    ft = zT_212;
    zT_213 = ft.kind;
    zT_215 = zF_A47239A9_fieldEmbedsByValue(zT_213);
    if (zT_215) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_257 = 1;
    zT_259 = fi + (unsigned int)((unsigned int)zT_257);
    fi = zT_259;
    goto z_bb_45;
    z_bb_49:
    zT_198 = 0;
    zT_197 = is_po != zT_198;
    goto z_bb_51;
    z_bb_50:
    zT_197 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_197) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_216 = 0;
    is_po = zT_216;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_217 = ft.kind;
    if ((unsigned char)(zT_217 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_221 = perm_alloc;
    zT_222 = &wp_to;
    zT_223 = &wp_next;
    zT_224 = &wp_edge_cap;
    zT_225 = wp_count;
    zF_25C377BD_growWpEdges(zT_221, zT_222, zT_223, zT_224, zT_225);
    zT_229 = (unsigned int)ti;
    zT_230 = (unsigned int)wp_count;
    wp_to[zT_230] = zT_229;
    zT_231 = (unsigned int)ft_id;
    zT_232 = wp_head[zT_231];
    zT_233 = (unsigned int)wp_count;
    wp_next[zT_233] = zT_232;
    zT_234 = (unsigned int)ft_id;
    wp_head[zT_234] = wp_count;
    zT_236 = wp_count + (unsigned int)(1);
    wp_count = zT_236;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_237 = ft.kind;
    if ((unsigned char)(zT_237 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_241 = perm_alloc;
    zT_242 = &wp_to;
    zT_243 = &wp_next;
    zT_244 = &wp_edge_cap;
    zT_245 = wp_count;
    zF_25C377BD_growWpEdges(zT_241, zT_242, zT_243, zT_244, zT_245);
    zT_249 = (unsigned int)ti;
    zT_250 = (unsigned int)wp_count;
    wp_to[zT_250] = zT_249;
    zT_251 = (unsigned int)ft_id;
    zT_252 = wp_head[zT_251];
    zT_253 = (unsigned int)wp_count;
    wp_next[zT_253] = zT_252;
    zT_254 = (unsigned int)ft_id;
    wp_head[zT_254] = wp_count;
    zT_256 = wp_count + (unsigned int)(1);
    wp_count = zT_256;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_265 = self->registry;
    zT_266 = zT_265->un_items;
    zT_267 = ty.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    up = zT_269;
    zT_271 = 0;
    zT_272 = (unsigned int)zT_271;
    fi = zT_272;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_339 = ty.kind;
    if ((unsigned char)(zT_339 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_273 = up.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_273))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_280 = self->registry;
    zT_281 = zT_280->fe_items;
    zT_282 = up.fields_start;
    zT_284 = (unsigned int)((unsigned int)zT_282) + fi;
    zT_285 = zT_281[zT_284];
    zT_286 = zT_285.type_id;
    ft_id = zT_286;
    zT_288 = self->registry;
    zT_289 = zT_288->types_items;
    zT_290 = (unsigned int)ft_id;
    zT_291 = zT_289[zT_290];
    ft = zT_291;
    zT_292 = ft.kind;
    zT_294 = zF_A47239A9_fieldEmbedsByValue(zT_292);
    if (zT_294) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_336 = 1;
    zT_338 = fi + (unsigned int)((unsigned int)zT_336);
    fi = zT_338;
    goto z_bb_63;
    z_bb_67:
    zT_277 = 0;
    zT_276 = is_po != zT_277;
    goto z_bb_69;
    z_bb_68:
    zT_276 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_276) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_295 = 0;
    is_po = zT_295;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_296 = ft.kind;
    if ((unsigned char)(zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_300 = perm_alloc;
    zT_301 = &wp_to;
    zT_302 = &wp_next;
    zT_303 = &wp_edge_cap;
    zT_304 = wp_count;
    zF_25C377BD_growWpEdges(zT_300, zT_301, zT_302, zT_303, zT_304);
    zT_308 = (unsigned int)ti;
    zT_309 = (unsigned int)wp_count;
    wp_to[zT_309] = zT_308;
    zT_310 = (unsigned int)ft_id;
    zT_311 = wp_head[zT_310];
    zT_312 = (unsigned int)wp_count;
    wp_next[zT_312] = zT_311;
    zT_313 = (unsigned int)ft_id;
    wp_head[zT_313] = wp_count;
    zT_315 = wp_count + (unsigned int)(1);
    wp_count = zT_315;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_316 = ft.kind;
    if ((unsigned char)(zT_316 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_320 = perm_alloc;
    zT_321 = &wp_to;
    zT_322 = &wp_next;
    zT_323 = &wp_edge_cap;
    zT_324 = wp_count;
    zF_25C377BD_growWpEdges(zT_320, zT_321, zT_322, zT_323, zT_324);
    zT_328 = (unsigned int)ti;
    zT_329 = (unsigned int)wp_count;
    wp_to[zT_329] = zT_328;
    zT_330 = (unsigned int)ft_id;
    zT_331 = wp_head[zT_330];
    zT_332 = (unsigned int)wp_count;
    wp_next[zT_332] = zT_331;
    zT_333 = (unsigned int)ft_id;
    wp_head[zT_333] = wp_count;
    zT_335 = wp_count + (unsigned int)(1);
    wp_count = zT_335;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_344 = self->registry;
    zT_345 = zT_344->un_items;
    zT_346 = ty.payload_idx;
    zT_347 = (unsigned int)zT_346;
    zT_348 = zT_345[zT_347];
    p_up = zT_348;
    zT_350 = 0;
    zT_351 = (unsigned int)zT_350;
    pfi = zT_351;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_418 = ty.kind;
    if ((unsigned char)(zT_418 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_352 = p_up.fields_count;
    if ((unsigned char)(pfi < (unsigned int)((unsigned int)zT_352))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_359 = self->registry;
    zT_360 = zT_359->fe_items;
    zT_361 = p_up.fields_start;
    zT_363 = (unsigned int)((unsigned int)zT_361) + pfi;
    zT_364 = zT_360[zT_363];
    zT_365 = zT_364.type_id;
    ft_id = zT_365;
    zT_367 = self->registry;
    zT_368 = zT_367->types_items;
    zT_369 = (unsigned int)ft_id;
    zT_370 = zT_368[zT_369];
    ft = zT_370;
    zT_371 = ft.kind;
    zT_373 = zF_A47239A9_fieldEmbedsByValue(zT_371);
    if (zT_373) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_415 = 1;
    zT_417 = pfi + (unsigned int)((unsigned int)zT_415);
    pfi = zT_417;
    goto z_bb_81;
    z_bb_85:
    zT_356 = 0;
    zT_355 = is_po != zT_356;
    goto z_bb_87;
    z_bb_86:
    zT_355 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_355) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_374 = 0;
    is_po = zT_374;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_375 = ft.kind;
    if ((unsigned char)(zT_375 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_379 = perm_alloc;
    zT_380 = &wp_to;
    zT_381 = &wp_next;
    zT_382 = &wp_edge_cap;
    zT_383 = wp_count;
    zF_25C377BD_growWpEdges(zT_379, zT_380, zT_381, zT_382, zT_383);
    zT_387 = (unsigned int)ti;
    zT_388 = (unsigned int)wp_count;
    wp_to[zT_388] = zT_387;
    zT_389 = (unsigned int)ft_id;
    zT_390 = wp_head[zT_389];
    zT_391 = (unsigned int)wp_count;
    wp_next[zT_391] = zT_390;
    zT_392 = (unsigned int)ft_id;
    wp_head[zT_392] = wp_count;
    zT_394 = wp_count + (unsigned int)(1);
    wp_count = zT_394;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_395 = ft.kind;
    if ((unsigned char)(zT_395 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_399 = perm_alloc;
    zT_400 = &wp_to;
    zT_401 = &wp_next;
    zT_402 = &wp_edge_cap;
    zT_403 = wp_count;
    zF_25C377BD_growWpEdges(zT_399, zT_400, zT_401, zT_402, zT_403);
    zT_407 = (unsigned int)ti;
    zT_408 = (unsigned int)wp_count;
    wp_to[zT_408] = zT_407;
    zT_409 = (unsigned int)ft_id;
    zT_410 = wp_head[zT_409];
    zT_411 = (unsigned int)wp_count;
    wp_next[zT_411] = zT_410;
    zT_412 = (unsigned int)ft_id;
    wp_head[zT_412] = wp_count;
    zT_414 = wp_count + (unsigned int)(1);
    wp_count = zT_414;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_423 = self->registry;
    zT_424 = zT_423->array_items;
    zT_425 = ty.payload_idx;
    zT_426 = (unsigned int)zT_425;
    zT_427 = zT_424[zT_426];
    zT_428 = zT_427.elem;
    et = zT_428;
    zT_430 = self->registry;
    zT_431 = zT_430->types_items;
    zT_432 = (unsigned int)et;
    zT_433 = zT_431[zT_432];
    et_ty = zT_433;
    zT_434 = et_ty.kind;
    zT_436 = zF_A47239A9_fieldEmbedsByValue(zT_434);
    if (zT_436) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_478 = ty.kind;
    if ((unsigned char)(zT_478 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_437 = 0;
    is_po = zT_437;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_438 = et_ty.kind;
    if ((unsigned char)(zT_438 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_442 = perm_alloc;
    zT_443 = &wp_to;
    zT_444 = &wp_next;
    zT_445 = &wp_edge_cap;
    zT_446 = wp_count;
    zF_25C377BD_growWpEdges(zT_442, zT_443, zT_444, zT_445, zT_446);
    zT_450 = (unsigned int)ti;
    zT_451 = (unsigned int)wp_count;
    wp_to[zT_451] = zT_450;
    zT_452 = (unsigned int)et;
    zT_453 = wp_head[zT_452];
    zT_454 = (unsigned int)wp_count;
    wp_next[zT_454] = zT_453;
    zT_455 = (unsigned int)et;
    wp_head[zT_455] = wp_count;
    zT_457 = wp_count + (unsigned int)(1);
    wp_count = zT_457;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_458 = et_ty.kind;
    if ((unsigned char)(zT_458 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_462 = perm_alloc;
    zT_463 = &wp_to;
    zT_464 = &wp_next;
    zT_465 = &wp_edge_cap;
    zT_466 = wp_count;
    zF_25C377BD_growWpEdges(zT_462, zT_463, zT_464, zT_465, zT_466);
    zT_470 = (unsigned int)ti;
    zT_471 = (unsigned int)wp_count;
    wp_to[zT_471] = zT_470;
    zT_472 = (unsigned int)et;
    zT_473 = wp_head[zT_472];
    zT_474 = (unsigned int)wp_count;
    wp_next[zT_474] = zT_473;
    zT_475 = (unsigned int)et;
    wp_head[zT_475] = wp_count;
    zT_477 = wp_count + (unsigned int)(1);
    wp_count = zT_477;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_483 = self->registry;
    zT_484 = zT_483->eu_items;
    zT_485 = ty.payload_idx;
    zT_486 = (unsigned int)zT_485;
    zT_487 = zT_484[zT_486];
    zT_488 = zT_487.payload;
    eup = zT_488;
    zT_490 = self->registry;
    zT_491 = zT_490->types_items;
    zT_492 = (unsigned int)eup;
    zT_493 = zT_491[zT_492];
    eup_ty = zT_493;
    zT_494 = eup_ty.kind;
    zT_496 = zF_A47239A9_fieldEmbedsByValue(zT_494);
    if (zT_496) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_538 = ty.kind;
    if ((unsigned char)(zT_538 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_497 = 0;
    is_po = zT_497;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_498 = eup_ty.kind;
    if ((unsigned char)(zT_498 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_502 = perm_alloc;
    zT_503 = &wp_to;
    zT_504 = &wp_next;
    zT_505 = &wp_edge_cap;
    zT_506 = wp_count;
    zF_25C377BD_growWpEdges(zT_502, zT_503, zT_504, zT_505, zT_506);
    zT_510 = (unsigned int)ti;
    zT_511 = (unsigned int)wp_count;
    wp_to[zT_511] = zT_510;
    zT_512 = (unsigned int)eup;
    zT_513 = wp_head[zT_512];
    zT_514 = (unsigned int)wp_count;
    wp_next[zT_514] = zT_513;
    zT_515 = (unsigned int)eup;
    wp_head[zT_515] = wp_count;
    zT_517 = wp_count + (unsigned int)(1);
    wp_count = zT_517;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_518 = eup_ty.kind;
    if ((unsigned char)(zT_518 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_522 = perm_alloc;
    zT_523 = &wp_to;
    zT_524 = &wp_next;
    zT_525 = &wp_edge_cap;
    zT_526 = wp_count;
    zF_25C377BD_growWpEdges(zT_522, zT_523, zT_524, zT_525, zT_526);
    zT_530 = (unsigned int)ti;
    zT_531 = (unsigned int)wp_count;
    wp_to[zT_531] = zT_530;
    zT_532 = (unsigned int)eup;
    zT_533 = wp_head[zT_532];
    zT_534 = (unsigned int)wp_count;
    wp_next[zT_534] = zT_533;
    zT_535 = (unsigned int)eup;
    wp_head[zT_535] = wp_count;
    zT_537 = wp_count + (unsigned int)(1);
    wp_count = zT_537;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_543 = self->registry;
    zT_544 = zT_543->opt_items;
    zT_545 = ty.payload_idx;
    zT_546 = (unsigned int)zT_545;
    zT_547 = zT_544[zT_546];
    zT_548 = zT_547.payload;
    op_p = zT_548;
    zT_550 = self->registry;
    zT_551 = zT_550->types_items;
    zT_552 = (unsigned int)op_p;
    zT_553 = zT_551[zT_552];
    op_ty = zT_553;
    zT_554 = op_ty.kind;
    zT_556 = zF_EA3ED3F3_requiresFullDef(zT_554);
    if (zT_556) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_557 = 0;
    is_po = zT_557;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_558 = op_ty.kind;
    if ((unsigned char)(zT_558 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_562 = perm_alloc;
    zT_563 = &wp_to;
    zT_564 = &wp_next;
    zT_565 = &wp_edge_cap;
    zT_566 = wp_count;
    zF_25C377BD_growWpEdges(zT_562, zT_563, zT_564, zT_565, zT_566);
    zT_570 = (unsigned int)ti;
    zT_571 = (unsigned int)wp_count;
    wp_to[zT_571] = zT_570;
    zT_572 = (unsigned int)op_p;
    zT_573 = wp_head[zT_572];
    zT_574 = (unsigned int)wp_count;
    wp_next[zT_574] = zT_573;
    zT_575 = (unsigned int)op_p;
    wp_head[zT_575] = wp_count;
    zT_577 = wp_count + (unsigned int)(1);
    wp_count = zT_577;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_578 = op_ty.kind;
    if ((unsigned char)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_582 = perm_alloc;
    zT_583 = &wp_to;
    zT_584 = &wp_next;
    zT_585 = &wp_edge_cap;
    zT_586 = wp_count;
    zF_25C377BD_growWpEdges(zT_582, zT_583, zT_584, zT_585, zT_586);
    zT_590 = (unsigned int)ti;
    zT_591 = (unsigned int)wp_count;
    wp_to[zT_591] = zT_590;
    zT_592 = (unsigned int)op_p;
    zT_593 = wp_head[zT_592];
    zT_594 = (unsigned int)wp_count;
    wp_next[zT_594] = zT_593;
    zT_595 = (unsigned int)op_p;
    wp_head[zT_595] = wp_count;
    zT_597 = wp_count + (unsigned int)(1);
    wp_count = zT_597;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_600 = (unsigned int)ti;
    zT_601 = (unsigned int)wl_tail;
    worklist[zT_601] = zT_600;
    zT_603 = wl_tail + (unsigned int)(1);
    wl_tail = zT_603;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((unsigned char)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_609 = (unsigned int)wl_head;
    zT_610 = worklist[zT_609];
    cur = zT_610;
    zT_612 = wl_head + (unsigned int)(1);
    wl_head = zT_612;
    zT_614 = (unsigned int)cur;
    zT_615 = wp_head[zT_614];
    e = zT_615;
    goto z_bb_134;
    z_bb_132:
    zT_633 = perm_alloc;
    zT_636 = 4;
    zT_638 = 4;
    zT_640 = zF_1395EB68_sandAlloc(zT_633, (unsigned int)(zT_636 * tl), (unsigned int)((unsigned int)zT_638));
    zT_641 = zT_640.is_error;
    if (zT_641) goto z_bb_140; else goto z_bb_141;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((unsigned char)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_619 = (unsigned int)e;
    zT_620 = wp_to[zT_619];
    parent_tid = zT_620;
    zT_621 = (unsigned int)parent_tid;
    zT_622 = pointer_only[zT_621];
    if ((unsigned char)(zT_622 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_625 = 0;
    zT_626 = (unsigned int)parent_tid;
    pointer_only[zT_626] = zT_625;
    zT_627 = (unsigned int)wl_tail;
    worklist[zT_627] = parent_tid;
    zT_629 = wl_tail + (unsigned int)(1);
    wl_tail = zT_629;
    goto z_bb_139;
    z_bb_139:
    zT_630 = (unsigned int)e;
    zT_631 = wp_next[zT_630];
    e = zT_631;
    goto z_bb_137;
    z_bb_140:
    pal_trap();
    z_bb_141:
    zT_642 = zT_640.data.payload;
    goto z_bb_142;
    z_bb_142:
    ids_raw = zT_642;
    zT_645 = (unsigned int*)ids_raw;
    ids = zT_645;
    zT_647 = 0;
    plen = zT_647;
    zT_648 = 0;
    zT_649 = (unsigned int)zT_648;
    ti = zT_649;
    goto z_bb_143;
    z_bb_143:
    if ((unsigned char)(ti < tl)) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_651 = pointer_only[ti];
    if ((unsigned char)(zT_651 != (unsigned char)(0))) goto z_bb_147; else goto z_bb_148;
    z_bb_145:
    zT_662 = "CLS:c";
    zT_664 = 5;
    zT_663.ptr = zT_662;
    zT_663.len = zT_664;
    cls_m = zT_663;
    zT_665 = cls_m;
    zF_48AC7B3A_markerWrite(zT_665);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_667[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cls_b[_i] = zT_667[_i];
        _i++;
    }
}
    zT_669 = plen;
    zT_673 = 0;
    zT_674 = (unsigned char*)((unsigned char*)cls_b) + zT_673;
    zT_675 = (unsigned int)(10) - zT_673;
    zT_676.ptr = zT_674;
    zT_676.len = zT_675;
    zT_670 = zT_676;
    zT_677 = zF_A7504564_itoa(zT_669, zT_670);
    cls_l = zT_677;
    zT_681 = (unsigned int)(9) - (unsigned int)((unsigned int)cls_l);
    cls_s = zT_681;
    zT_686 = (unsigned char*)((unsigned char*)cls_b) + cls_s;
    zT_687 = (unsigned int)(9) - cls_s;
    zT_688.ptr = zT_686;
    zT_688.len = zT_687;
    zT_682 = zT_688;
    zF_48AC7B3A_markerWrite(zT_682);
    zT_690 = "\n";
    zT_692 = 1;
    zT_691.ptr = zT_690;
    zT_691.len = zT_692;
    cls_nl = zT_691;
    zT_693 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_693);
    zT_694 = 0;
    zT_695 = (unsigned int)zT_694;
    ti = zT_695;
    goto z_bb_149;
    z_bb_146:
    zT_658 = 1;
    zT_660 = ti + (unsigned int)((unsigned int)zT_658);
    ti = zT_660;
    goto z_bb_143;
    z_bb_147:
    zT_654 = (unsigned int)ti;
    zT_655 = (unsigned int)plen;
    ids[zT_655] = zT_654;
    zT_657 = plen + (unsigned int)(1);
    plen = zT_657;
    goto z_bb_148;
    z_bb_148:
    goto z_bb_146;
    z_bb_149:
    if ((unsigned char)(ti < tl)) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_697 = pointer_only[ti];
    if ((unsigned char)(zT_697 != (unsigned char)(0))) goto z_bb_153; else goto z_bb_155;
    z_bb_151:
    zT_775.ids = ids;
    zT_775.len = plen;
    return zT_775;
    z_bb_152:
    zT_772 = 1;
    zT_774 = ti + (unsigned int)((unsigned int)zT_772);
    ti = zT_774;
    goto z_bb_149;
    z_bb_153:
    zT_701 = "CLS:p";
    zT_703 = 5;
    zT_702.ptr = zT_701;
    zT_702.len = zT_703;
    pfx = zT_702;
    zT_704 = pfx;
    zF_48AC7B3A_markerWrite(zT_704);
    goto z_bb_154;
    z_bb_154:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_711[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ctb[_i] = zT_711[_i];
        _i++;
    }
}
    zT_718 = 0;
    zT_719 = (unsigned char*)((unsigned char*)ctb) + zT_718;
    zT_720 = (unsigned int)(10) - zT_718;
    zT_721.ptr = zT_719;
    zT_721.len = zT_720;
    zT_714 = zT_721;
    zT_722 = zF_A7504564_itoa((unsigned int)((unsigned int)ti), zT_714);
    ctl = zT_722;
    zT_726 = (unsigned int)(9) - (unsigned int)((unsigned int)ctl);
    cts = zT_726;
    zT_731 = (unsigned char*)((unsigned char*)ctb) + cts;
    zT_732 = (unsigned int)(9) - cts;
    zT_733.ptr = zT_731;
    zT_733.len = zT_732;
    zT_727 = zT_733;
    zF_48AC7B3A_markerWrite(zT_727);
    zT_735 = "k";
    zT_737 = 1;
    zT_736.ptr = zT_735;
    zT_736.len = zT_737;
    ck = zT_736;
    zT_738 = ck;
    zF_48AC7B3A_markerWrite(zT_738);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_740[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ckb[_i] = zT_740[_i];
        _i++;
    }
}
    zT_744 = self->registry;
    zT_745 = zT_744->types_items;
    zT_746 = zT_745[ti];
    zT_747 = zT_746.kind;
    zT_751 = 0;
    zT_752 = (unsigned char*)((unsigned char*)ckb) + zT_751;
    zT_753 = (unsigned int)(10) - zT_751;
    zT_754.ptr = zT_752;
    zT_754.len = zT_753;
    zT_743 = zT_754;
    zT_755 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_747), zT_743);
    ckl = zT_755;
    zT_759 = (unsigned int)(9) - (unsigned int)((unsigned int)ckl);
    cks = zT_759;
    zT_764 = (unsigned char*)((unsigned char*)ckb) + cks;
    zT_765 = (unsigned int)(9) - cks;
    zT_766.ptr = zT_764;
    zT_766.len = zT_765;
    zT_760 = zT_766;
    zF_48AC7B3A_markerWrite(zT_760);
    zT_768 = "\n";
    zT_770 = 1;
    zT_769.ptr = zT_768;
    zT_769.len = zT_770;
    cnl = zT_769;
    zT_771 = cnl;
    zF_48AC7B3A_markerWrite(zT_771);
    goto z_bb_152;
    z_bb_155:
    zT_706 = "CLS:v";
    zT_708 = 5;
    zT_707.ptr = zT_706;
    zT_707.len = zT_708;
    pfx = zT_707;
    zT_709 = pfx;
    zF_48AC7B3A_markerWrite(zT_709);
    goto z_bb_154;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_14;
    int zT_17;
    int zT_19;
    zT_019EE88E_EU_932 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_3E40CD83_Sand* zT_26;
    int zT_29;
    int zT_31;
    zT_019EE88E_EU_932 zT_33 = {0};
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned int* zT_38;
    unsigned int* zT_40;
    int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* new_to_raw;
    unsigned char* new_nx_raw;
    unsigned int* new_to;
    unsigned int* new_nx;
    unsigned int ci;
    zT_6 = *cap_ptr;
    if ((unsigned char)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap_ptr;
    old_cap = zT_9;
    zT_11 = 2;
    zT_12 = old_cap * zT_11;
    new_cap = zT_12;
    zT_14 = perm_a;
    zT_17 = 4;
    zT_19 = 4;
    zT_21 = zF_1395EB68_sandAlloc(zT_14, (unsigned int)(zT_17 * new_cap), (unsigned int)((unsigned int)zT_19));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_23 = zT_21.data.payload;
    goto z_bb_5;
    z_bb_5:
    new_to_raw = zT_23;
    zT_26 = perm_a;
    zT_29 = 4;
    zT_31 = 4;
    zT_33 = zF_1395EB68_sandAlloc(zT_26, (unsigned int)(zT_29 * new_cap), (unsigned int)((unsigned int)zT_31));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    new_nx_raw = zT_35;
    zT_38 = (unsigned int*)new_to_raw;
    new_to = zT_38;
    zT_40 = (unsigned int*)new_nx_raw;
    new_nx = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)count))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *wp_to_ptr;
    zT_47 = zT_46[ci];
    new_to[ci] = zT_47;
    zT_48 = *wp_next_ptr;
    zT_49 = zT_48[ci];
    new_nx[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *wp_to_ptr = new_to;
    *wp_next_ptr = new_nx;
    *cap_ptr = new_cap;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_52 = ci + (unsigned int)((unsigned int)zT_50);
    ci = zT_52;
    goto z_bb_9;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstModuleOfExpr */
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    unsigned int zT_19;
    zT_3D7259E2_SymbolRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_577B64BF_Opt_873 zT_27 = {0};
    unsigned char zT_28;
    zT_3C598AEF_SymbolKind zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned int zT_54;
    int zT_56;
    unsigned int zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    unsigned int zT_59;
    zT_3D7259E2_SymbolRegistry* zT_63;
    unsigned int zT_65;
    zT_577B64BF_Opt_873 zT_68 = {0};
    unsigned char zT_69;
    zT_3C598AEF_SymbolKind zT_71;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_79;
    unsigned int zT_80;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_D155D06D_Type* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type zT_90;
    zT_33EF6BFB_TypeKind zT_91;
    unsigned int zT_95;
    int zT_96;
    unsigned int zT_98;
    zT_8143F551_AstKind zT_100;
    zT_ABC1EBBE_TypeResolveEnv* zT_105;
    unsigned int zT_106;
    unsigned int zT_108 = 0;
    zT_6B0A7D14_AstStore* zT_113;
    unsigned int zT_114;
    unsigned int zT_116 = 0;
    zT_3D7259E2_SymbolRegistry* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_577B64BF_Opt_873 zT_121 = {0};
    unsigned char zT_122;
    zT_3C598AEF_SymbolKind zT_124;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned char zT_132;
    unsigned int zT_133;
    zT_338B7C76_TypeRegistry* zT_135;
    unsigned int zT_136;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_D155D06D_Type* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_D155D06D_Type zT_143;
    zT_33EF6BFB_TypeKind zT_144;
    unsigned int zT_148;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    zT_577B64BF_Opt_873 sym;
    zT_3A105EF1_Symbol* s2;
    zT_D155D06D_Type sty2;
    unsigned int base_mod;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* msym;
    zT_D155D06D_Type mty;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_53458827_astStoreIdentifier(zT_15, zT_16);
    name_id = zT_18;
    zT_19 = env->module_id;
    if ((unsigned char)(zT_19 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_100 = node.kind;
    if ((unsigned char)(zT_100 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_22 = env->symbol_reg;
    zT_23 = env->module_id;
    zT_24 = name_id;
    zT_27 = zF_A398987E_symbolRegistryQuali(zT_22, zT_23, zT_24);
    zT_28 = zT_27.has_value;
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    si = zT_57;
    goto z_bb_18;
    z_bb_7:
    s = zT_27.value;
    zT_30 = s->kind;
    if ((unsigned char)(zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_34 = s->module_id;
    return zT_34;
    z_bb_10:
    zT_35 = s->type_id;
    if ((unsigned char)(zT_35 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = s->type_id;
    zT_41 = env->typereg;
    zT_42 = zT_41->types_len;
    zT_38 = (unsigned int)((unsigned int)zT_39) < zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = env->typereg;
    zT_46 = zT_45->types_items;
    zT_47 = s->type_id;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    sty = zT_49;
    zT_50 = sty.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_54 = sty.module_id;
    return zT_54;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_58 = env->symbol_reg;
    zT_59 = zT_58->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_59))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_63 = env->symbol_reg;
    zT_65 = name_id;
    zT_68 = zF_A398987E_symbolRegistryQuali(zT_63, (unsigned int)((unsigned int)si), zT_65);
    sym = zT_68;
    zT_69 = sym.has_value;
    if (zT_69) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    zT_96 = 1;
    zT_98 = si + (unsigned int)((unsigned int)zT_96);
    si = zT_98;
    goto z_bb_18;
    z_bb_22:
    s2 = sym.value;
    zT_71 = s2->kind;
    if ((unsigned char)(zT_71 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_75 = s2->module_id;
    return zT_75;
    z_bb_25:
    zT_76 = s2->type_id;
    if ((unsigned char)(zT_76 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_80 = s2->type_id;
    zT_82 = env->typereg;
    zT_83 = zT_82->types_len;
    zT_79 = (unsigned int)((unsigned int)zT_80) < zT_83;
    goto z_bb_28;
    z_bb_27:
    zT_79 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_79) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_86 = env->typereg;
    zT_87 = zT_86->types_items;
    zT_88 = s2->type_id;
    zT_89 = (unsigned int)zT_88;
    zT_90 = zT_87[zT_89];
    sty2 = zT_90;
    zT_91 = sty2.kind;
    if ((unsigned char)(zT_91 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_23;
    z_bb_31:
    zT_95 = sty2.module_id;
    return zT_95;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_105 = env;
    zT_106 = node.child_0;
    zT_108 = zF_0E4084E4_evalConstModuleOfEx(zT_105, zT_106);
    base_mod = zT_108;
    if ((unsigned char)(base_mod == (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    return (unsigned int)(0);
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_113 = env->store;
    zT_114 = node_idx;
    zT_116 = zF_8BA26B9E_astStoreNodePayload(zT_113, zT_114);
    field_name_id = zT_116;
    zT_117 = env->symbol_reg;
    zT_118 = base_mod;
    zT_119 = field_name_id;
    zT_121 = zF_A398987E_symbolRegistryQuali(zT_117, zT_118, zT_119);
    zT_122 = zT_121.has_value;
    if (zT_122) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    msym = zT_121.value;
    zT_124 = msym->kind;
    if ((unsigned char)(zT_124 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    return (unsigned int)(0);
    z_bb_39:
    zT_128 = msym->module_id;
    return zT_128;
    z_bb_40:
    zT_129 = msym->type_id;
    if ((unsigned char)(zT_129 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_133 = msym->type_id;
    zT_135 = env->typereg;
    zT_136 = zT_135->types_len;
    zT_132 = (unsigned int)((unsigned int)zT_133) < zT_136;
    goto z_bb_43;
    z_bb_42:
    zT_132 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_132) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_139 = env->typereg;
    zT_140 = zT_139->types_items;
    zT_141 = msym->type_id;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    mty = zT_143;
    zT_144 = mty.kind;
    if ((unsigned char)(zT_144 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_38;
    z_bb_46:
    zT_148 = mty.module_id;
    return zT_148;
    z_bb_47:
    goto z_bb_45;
}

/* evalConstScalarKind */
unsigned char zF_6AE4DFFC_evalConstScalarKind(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    return (unsigned char)(1);
}

/* evalConstIntFull */
zT_E63A2735_Opt_202 zF_382591DE_evalConstIntFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_E63A2735_Opt_202 zT_5 = {0};
    zT_E63A2735_Opt_202 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    zT_79FAE712_u64 zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_79FAE712_u64 zT_27 = 0;
    zT_0163D9A4_ComptimeInt zT_28 = {0};
    zT_E63A2735_Opt_202 zT_29;
    zT_8143F551_AstKind zT_30;
    unsigned int zT_34;
    zT_ABC1EBBE_TypeResolveEnv* zT_38;
    unsigned int zT_39;
    zT_E63A2735_Opt_202 zT_44 = {0};
    unsigned char zT_45;
    zT_0163D9A4_ComptimeInt zT_48 = {0};
    zT_0163D9A4_ComptimeInt zT_49;
    zT_0163D9A4_ComptimeInt* zT_50;
    unsigned char zT_52 = 0;
    zT_E63A2735_Opt_202 zT_53;
    zT_E63A2735_Opt_202 zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_62;
    unsigned int zT_64;
    zT_8143F551_AstKind zT_66;
    unsigned char zT_70;
    zT_8143F551_AstKind zT_71;
    unsigned char zT_75;
    zT_8143F551_AstKind zT_76;
    unsigned char zT_80;
    zT_8143F551_AstKind zT_81;
    unsigned char zT_85;
    zT_8143F551_AstKind zT_86;
    unsigned char zT_90;
    zT_8143F551_AstKind zT_91;
    unsigned char zT_95;
    zT_8143F551_AstKind zT_96;
    unsigned char zT_100;
    zT_8143F551_AstKind zT_101;
    unsigned char zT_105;
    zT_8143F551_AstKind zT_106;
    unsigned char zT_110;
    zT_8143F551_AstKind zT_111;
    zT_ABC1EBBE_TypeResolveEnv* zT_116;
    unsigned int zT_117;
    zT_E63A2735_Opt_202 zT_122 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_124;
    unsigned int zT_125;
    zT_E63A2735_Opt_202 zT_130 = {0};
    unsigned char zT_131;
    unsigned char zT_133;
    zT_0163D9A4_ComptimeInt zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_0163D9A4_ComptimeInt zT_141;
    zT_0163D9A4_ComptimeInt zT_142;
    zT_0163D9A4_ComptimeInt* zT_143;
    unsigned char zT_145 = 0;
    zT_E63A2735_Opt_202 zT_147 = {0};
    zT_E63A2735_Opt_202 zT_148;
    zT_8143F551_AstKind zT_149;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    zT_0163D9A4_ComptimeInt* zT_155;
    unsigned char zT_157 = 0;
    zT_E63A2735_Opt_202 zT_159 = {0};
    zT_E63A2735_Opt_202 zT_160;
    zT_8143F551_AstKind zT_161;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    zT_0163D9A4_ComptimeInt* zT_167;
    unsigned char zT_169 = 0;
    zT_E63A2735_Opt_202 zT_171 = {0};
    zT_E63A2735_Opt_202 zT_172;
    zT_8143F551_AstKind zT_173;
    zT_0163D9A4_ComptimeInt zT_178 = {0};
    zT_0163D9A4_ComptimeInt zT_179;
    zT_0163D9A4_ComptimeInt zT_180;
    zT_0163D9A4_ComptimeInt* zT_181;
    zT_0163D9A4_ComptimeInt* zT_182;
    unsigned char zT_185 = 0;
    zT_E63A2735_Opt_202 zT_187 = {0};
    zT_E63A2735_Opt_202 zT_188;
    zT_8143F551_AstKind zT_189;
    zT_0163D9A4_ComptimeInt zT_194 = {0};
    zT_0163D9A4_ComptimeInt zT_195;
    zT_0163D9A4_ComptimeInt zT_196;
    zT_0163D9A4_ComptimeInt* zT_197;
    zT_0163D9A4_ComptimeInt* zT_198;
    unsigned char zT_201 = 0;
    zT_E63A2735_Opt_202 zT_203 = {0};
    zT_E63A2735_Opt_202 zT_204;
    zT_8143F551_AstKind zT_205;
    zT_0163D9A4_ComptimeInt zT_209;
    zT_0163D9A4_ComptimeInt zT_210;
    zT_0163D9A4_ComptimeInt* zT_211;
    unsigned char zT_213 = 0;
    zT_E63A2735_Opt_202 zT_215 = {0};
    zT_E63A2735_Opt_202 zT_216;
    zT_8143F551_AstKind zT_217;
    zT_0163D9A4_ComptimeInt zT_221;
    zT_0163D9A4_ComptimeInt zT_222;
    zT_0163D9A4_ComptimeInt* zT_223;
    unsigned char zT_225 = 0;
    zT_E63A2735_Opt_202 zT_227 = {0};
    zT_E63A2735_Opt_202 zT_228;
    zT_8143F551_AstKind zT_229;
    zT_0163D9A4_ComptimeInt zT_233;
    zT_0163D9A4_ComptimeInt zT_234;
    zT_0163D9A4_ComptimeInt* zT_235;
    unsigned char zT_237 = 0;
    zT_E63A2735_Opt_202 zT_239 = {0};
    zT_E63A2735_Opt_202 zT_240;
    zT_8143F551_AstKind zT_241;
    zT_0163D9A4_ComptimeInt zT_245;
    zT_0163D9A4_ComptimeInt zT_246;
    zT_0163D9A4_ComptimeInt* zT_247;
    unsigned char zT_249 = 0;
    zT_E63A2735_Opt_202 zT_251 = {0};
    zT_E63A2735_Opt_202 zT_252;
    zT_0163D9A4_ComptimeInt zT_253;
    zT_0163D9A4_ComptimeInt zT_254;
    zT_0163D9A4_ComptimeInt* zT_255;
    unsigned char zT_257 = 0;
    zT_E63A2735_Opt_202 zT_259 = {0};
    zT_E63A2735_Opt_202 zT_260;
    zT_E63A2735_Opt_202 zT_261 = {0};
    zT_8143F551_AstKind zT_262;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    unsigned int zT_270 = 0;
    zT_02B97B5A_Opt_399 zT_271;
    unsigned char zT_272;
    zT_E2DF2801_LocalConstScope* zT_274;
    unsigned int zT_275;
    zT_BAEE192E_Opt_10 zT_276 = {0};
    unsigned char zT_277;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    zT_22A7C88B_AstNode zT_283 = {0};
    unsigned int zT_284;
    zT_ABC1EBBE_TypeResolveEnv* zT_287;
    unsigned int zT_290;
    unsigned int zT_292;
    zT_ABC1EBBE_TypeResolveEnv* zT_295;
    unsigned int zT_296;
    zT_577B64BF_Opt_873 zT_297 = {0};
    unsigned char zT_298;
    unsigned short zT_300;
    zT_6B0A7D14_AstStore* zT_306;
    unsigned int zT_307;
    zT_22A7C88B_AstNode zT_310 = {0};
    unsigned int zT_311;
    zT_ABC1EBBE_TypeResolveEnv* zT_314;
    unsigned int zT_317;
    unsigned int zT_319;
    zT_E63A2735_Opt_202 zT_321 = {0};
    zT_8143F551_AstKind zT_322;
    zT_ABC1EBBE_TypeResolveEnv* zT_327;
    unsigned int zT_328;
    unsigned int zT_330 = 0;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_337 = 0;
    zT_3D7259E2_SymbolRegistry* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_577B64BF_Opt_873 zT_342 = {0};
    unsigned char zT_343;
    zT_ABC1EBBE_TypeResolveEnv* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    zT_3A105EF1_Symbol* zT_348;
    unsigned char zT_349 = 0;
    zT_E63A2735_Opt_202 zT_351 = {0};
    unsigned short zT_352;
    zT_6B0A7D14_AstStore* zT_358;
    unsigned int zT_359;
    zT_22A7C88B_AstNode zT_362 = {0};
    unsigned int zT_363;
    zT_ABC1EBBE_TypeResolveEnv* zT_366;
    unsigned int zT_369;
    unsigned int zT_371;
    zT_E63A2735_Opt_202 zT_373 = {0};
    zT_8143F551_AstKind zT_374;
    unsigned char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned int zT_381;
    zT_D3EB6303_StringInterner* zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned int zT_386 = 0;
    unsigned char* zT_388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_389;
    unsigned int zT_390;
    zT_D3EB6303_StringInterner* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_395 = 0;
    unsigned char* zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    unsigned int zT_399;
    zT_D3EB6303_StringInterner* zT_401;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_402;
    unsigned int zT_404 = 0;
    unsigned char* zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_D3EB6303_StringInterner* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_413 = 0;
    unsigned char* zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    zT_D3EB6303_StringInterner* zT_419;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned int zT_422 = 0;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_D3EB6303_StringInterner* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_431 = 0;
    unsigned char* zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    zT_D3EB6303_StringInterner* zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_440 = 0;
    zT_6B0A7D14_AstStore* zT_442;
    unsigned int zT_443;
    unsigned int zT_445 = 0;
    unsigned int zT_446;
    unsigned char zT_448;
    unsigned int zT_449;
    zT_ABC1EBBE_TypeResolveEnv* zT_454;
    unsigned int zT_455;
    zT_6B0A7D14_AstStore* zT_457;
    unsigned int zT_458;
    unsigned int zT_462 = 0;
    unsigned int zT_465 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_469;
    unsigned int zT_470;
    zT_6B0A7D14_AstStore* zT_472;
    unsigned int zT_473;
    unsigned int zT_477 = 0;
    zT_E63A2735_Opt_202 zT_480 = {0};
    unsigned char zT_481;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_0163D9A4_ComptimeInt zT_484;
    unsigned int zT_485;
    unsigned char zT_487 = 0;
    zT_E63A2735_Opt_202 zT_488;
    zT_E63A2735_Opt_202 zT_489 = {0};
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned int zT_493;
    unsigned char zT_495;
    unsigned int zT_496;
    zT_ABC1EBBE_TypeResolveEnv* zT_501;
    unsigned int zT_502;
    zT_6B0A7D14_AstStore* zT_504;
    unsigned int zT_505;
    unsigned int zT_509 = 0;
    unsigned int zT_512 = 0;
    zT_338B7C76_TypeRegistry* zT_516;
    zT_D155D06D_Type* zT_517;
    unsigned int zT_518;
    zT_D155D06D_Type zT_519;
    unsigned char zT_520;
    unsigned char zT_523;
    zT_33EF6BFB_TypeKind zT_524;
    zT_338B7C76_TypeRegistry* zT_528;
    unsigned int zT_529;
    unsigned char zT_533 = 0;
    zT_338B7C76_TypeRegistry* zT_534;
    zT_D155D06D_Type* zT_535;
    unsigned int zT_536;
    zT_D155D06D_Type zT_537;
    zT_33EF6BFB_TypeKind zT_539;
    unsigned char zT_541 = 0;
    zT_33EF6BFB_TypeKind zT_542;
    unsigned char zT_546;
    unsigned char zT_547;
    unsigned char zT_550;
    unsigned int zT_551;
    unsigned int zT_554;
    zT_0163D9A4_ComptimeInt zT_556 = {0};
    zT_E63A2735_Opt_202 zT_557;
    unsigned int zT_558;
    unsigned int zT_561;
    zT_0163D9A4_ComptimeInt zT_563 = {0};
    zT_E63A2735_Opt_202 zT_564;
    unsigned int zT_566;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_569;
    unsigned int zT_570;
    unsigned char zT_572 = 0;
    zT_338B7C76_TypeRegistry* zT_573;
    unsigned int zT_574;
    unsigned char zT_576 = 0;
    unsigned int zT_577;
    zT_33EF6BFB_TypeKind zT_578;
    zT_338B7C76_TypeRegistry* zT_582;
    unsigned int zT_583;
    zT_338B7C76_TypeRegistry* zT_585;
    unsigned int zT_586;
    unsigned int zT_588 = 0;
    unsigned char zT_589 = 0;
    unsigned int zT_590;
    zT_33EF6BFB_TypeKind zT_591;
    unsigned int zT_595;
    zT_33EF6BFB_TypeKind zT_596;
    unsigned char zT_600;
    unsigned char zT_601;
    zT_338B7C76_TypeRegistry* zT_606;
    unsigned int zT_607;
    unsigned int zT_609 = 0;
    unsigned int zT_610;
    zT_0163D9A4_ComptimeInt zT_613 = {0};
    zT_E63A2735_Opt_202 zT_614;
    zT_E63A2735_Opt_202 zT_615 = {0};
    unsigned int zT_616;
    unsigned char zT_618;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv* zT_624;
    unsigned int zT_625;
    zT_6B0A7D14_AstStore* zT_627;
    unsigned int zT_628;
    unsigned int zT_632 = 0;
    unsigned int zT_635 = 0;
    zT_338B7C76_TypeRegistry* zT_639;
    zT_D155D06D_Type* zT_640;
    unsigned int zT_641;
    zT_D155D06D_Type zT_642;
    unsigned char zT_643;
    unsigned char zT_646;
    zT_33EF6BFB_TypeKind zT_647;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_652 = {0};
    zT_338B7C76_TypeRegistry* zT_653;
    unsigned int zT_654;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_655;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_659 = {0};
    zT_338B7C76_TypeRegistry* zT_661;
    unsigned int zT_662;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_663;
    unsigned char zT_666 = 0;
    zT_6B0A7D14_AstStore* zT_668;
    unsigned int zT_669;
    zT_6B0A7D14_AstStore* zT_671;
    unsigned int zT_672;
    unsigned int zT_676 = 0;
    zT_22A7C88B_AstNode zT_677 = {0};
    zT_8143F551_AstKind zT_678;
    zT_6B0A7D14_AstStore* zT_683;
    unsigned int zT_684;
    zT_6B0A7D14_AstStore* zT_686;
    unsigned int zT_687;
    unsigned int zT_691 = 0;
    unsigned int zT_692 = 0;
    zT_6B0A7D14_AstStore* zT_694;
    zT_46CBCFBF_anon_258042 zT_695;
    unsigned int* zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    int zT_700;
    unsigned int zT_701;
    unsigned int zT_703;
    zT_2DF01B61_FieldEntry* zT_705;
    zT_2DF01B61_FieldEntry zT_706;
    unsigned int zT_707;
    zT_2DF01B61_FieldEntry* zT_710;
    zT_2DF01B61_FieldEntry zT_711;
    unsigned int zT_712;
    zT_79FAE712_u64 zT_713;
    zT_79FAE712_u64 zT_715;
    unsigned int zT_717;
    zT_E276DDD0_PackedBitField* zT_719;
    zT_E276DDD0_PackedBitField zT_720;
    unsigned int zT_721;
    zT_79FAE712_u64 zT_722;
    unsigned int zT_723;
    zT_79FAE712_u64 zT_726;
    unsigned int zT_727;
    zT_79FAE712_u64 zT_730;
    zT_79FAE712_u64 zT_731;
    zT_0163D9A4_ComptimeInt zT_732 = {0};
    zT_E63A2735_Opt_202 zT_733;
    int zT_734;
    unsigned int zT_736;
    unsigned char zT_737;
    unsigned char zT_740;
    zT_33EF6BFB_TypeKind zT_741;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_746 = {0};
    zT_338B7C76_TypeRegistry* zT_747;
    unsigned int zT_748;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_749;
    zT_6B0A7D14_AstStore* zT_753;
    unsigned int zT_754;
    zT_6B0A7D14_AstStore* zT_756;
    unsigned int zT_757;
    unsigned int zT_761 = 0;
    zT_22A7C88B_AstNode zT_762 = {0};
    zT_8143F551_AstKind zT_763;
    zT_6B0A7D14_AstStore* zT_768;
    unsigned int zT_769;
    zT_6B0A7D14_AstStore* zT_771;
    unsigned int zT_772;
    unsigned int zT_776 = 0;
    unsigned int zT_777 = 0;
    zT_6B0A7D14_AstStore* zT_779;
    zT_46CBCFBF_anon_258042 zT_780;
    unsigned int* zT_781;
    unsigned int zT_782;
    unsigned int zT_783;
    int zT_785;
    unsigned int zT_786;
    unsigned int zT_788;
    zT_2DF01B61_FieldEntry* zT_790;
    zT_2DF01B61_FieldEntry zT_791;
    unsigned int zT_792;
    zT_0163D9A4_ComptimeInt zT_794 = {0};
    zT_E63A2735_Opt_202 zT_795;
    int zT_796;
    unsigned int zT_798;
    zT_E63A2735_Opt_202 zT_799 = {0};
    zT_E63A2735_Opt_202 zT_800 = {0};
    zT_E63A2735_Opt_202 zT_801 = {0};
    zT_22A7C88B_AstNode node;
    zT_E63A2735_Opt_202 inner;
    zT_0163D9A4_ComptimeInt iv;
    zT_0163D9A4_ComptimeInt nv;
    zT_E63A2735_Opt_202 l_opt;
    zT_E63A2735_Opt_202 r_opt;
    zT_0163D9A4_ComptimeInt lv;
    zT_0163D9A4_ComptimeInt rv;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    zT_577B64BF_Opt_873 c_sym;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int fa_mod_id;
    unsigned int fa_field_id;
    zT_3A105EF1_Symbol* fa_sym;
    zT_22A7C88B_AstNode fa_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    unsigned int size_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    unsigned int bitsz_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    unsigned int off_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int bitoff_id;
    unsigned int bc_n;
    unsigned int ct_tid;
    zT_E63A2735_Opt_202 cv_opt;
    zT_0163D9A4_ComptimeInt cv;
    unsigned int bt_tid;
    zT_D155D06D_Type bt_ty;
    unsigned char bt_foldable;
    unsigned int bt_bits;
    unsigned int ot_tid;
    zT_D155D06D_Type ot_ty;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    zT_BF2E90D8_Slice_zT_2DF01B61_F u_fields;
    zT_22A7C88B_AstNode fname_node2;
    unsigned int sv_idx2;
    unsigned int want_id2;
    unsigned int fi2;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_19 = node.kind;
    zT_18 = zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = env->store;
    zT_25 = node_idx;
    zT_27 = zF_678B9A72_astStoreIntValue(zT_24, zT_25);
    zT_23 = zT_27;
    zT_28 = zF_1EAA44E6_ciFromU64(zT_23);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_9:
    zT_30 = node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = node.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_55 = node.kind;
    if ((unsigned char)(zT_55 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    zT_38 = env;
    zT_39 = node.child_0;
    zT_44 = zF_382591DE_evalConstIntFull(zT_38, zT_39, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_44;
    zT_45 = inner.has_value;
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_54.has_value = 0;
    return zT_54;
    z_bb_14:
    iv = inner.value;
    zT_48 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_48;
    zT_49 = iv;
    zT_50 = &nv;
    zT_52 = zF_EECBFD7D_ciNeg(zT_49, zT_50);
    (void)zT_52;
    zT_53.has_value = 1;
    zT_53.value = nv;
    return zT_53;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_59 = env;
    zT_62 = node.child_0;
    zT_64 = depth + (unsigned int)(1);
    env = zT_59;
    node_idx = zT_62;
    depth = zT_64;
    goto z_bb_0;
    z_bb_17:
    zT_66 = node.kind;
    if ((unsigned char)(zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_71 = node.kind;
    zT_70 = zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_20;
    z_bb_19:
    zT_70 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_70) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_76 = node.kind;
    zT_75 = zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_23;
    z_bb_22:
    zT_75 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_75) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_81 = node.kind;
    zT_80 = zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_26;
    z_bb_25:
    zT_80 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_80) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_86 = node.kind;
    zT_85 = zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_29;
    z_bb_28:
    zT_85 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_85) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_91 = node.kind;
    zT_90 = zT_91 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_32;
    z_bb_31:
    zT_90 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_90) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_96 = node.kind;
    zT_95 = zT_96 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_35;
    z_bb_34:
    zT_95 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_95) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_101 = node.kind;
    zT_100 = zT_101 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_38;
    z_bb_37:
    zT_100 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_100) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_106 = node.kind;
    zT_105 = zT_106 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_41;
    z_bb_40:
    zT_105 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_105) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_111 = node.kind;
    zT_110 = zT_111 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_44;
    z_bb_43:
    zT_110 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_110) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_116 = env;
    zT_117 = node.child_0;
    zT_122 = zF_382591DE_evalConstIntFull(zT_116, zT_117, (unsigned int)(depth + (unsigned int)(1)));
    l_opt = zT_122;
    zT_124 = env;
    zT_125 = node.child_1;
    zT_130 = zF_382591DE_evalConstIntFull(zT_124, zT_125, (unsigned int)(depth + (unsigned int)(1)));
    r_opt = zT_130;
    zT_131 = l_opt.has_value;
    if (zT_131) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_262 = node.kind;
    if ((unsigned char)(zT_262 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_47:
    lv = l_opt.value;
    zT_133 = r_opt.has_value;
    if (zT_133) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_261.has_value = 0;
    return zT_261;
    z_bb_49:
    rv = r_opt.value;
    zT_136 = zF_DC9B7BC0_ciZeroInt();
    res = zT_136;
    zT_137 = node.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_141 = lv;
    zT_142 = rv;
    zT_143 = &res;
    zT_145 = zF_8A5DB878_ciAdd(zT_141, zT_142, zT_143);
    if ((unsigned char)(!zT_145)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_149 = node.kind;
    if ((unsigned char)(zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_147.has_value = 0;
    return zT_147;
    z_bb_54:
    zT_148.has_value = 1;
    zT_148.value = res;
    return zT_148;
    z_bb_55:
    zT_153 = lv;
    zT_154 = rv;
    zT_155 = &res;
    zT_157 = zF_539A2D81_ciSub(zT_153, zT_154, zT_155);
    if ((unsigned char)(!zT_157)) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_161 = node.kind;
    if ((unsigned char)(zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_159.has_value = 0;
    return zT_159;
    z_bb_58:
    zT_160.has_value = 1;
    zT_160.value = res;
    return zT_160;
    z_bb_59:
    zT_165 = lv;
    zT_166 = rv;
    zT_167 = &res;
    zT_169 = zF_A3E385DD_ciMul(zT_165, zT_166, zT_167);
    if ((unsigned char)(!zT_169)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_173 = node.kind;
    if ((unsigned char)(zT_173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_171.has_value = 0;
    return zT_171;
    z_bb_62:
    zT_172.has_value = 1;
    zT_172.value = res;
    return zT_172;
    z_bb_63:
    zT_178 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_178;
    zT_179 = lv;
    zT_180 = rv;
    zT_181 = &res;
    zT_182 = &rem;
    zT_185 = zF_25A0EEC0_ciDivMod(zT_179, zT_180, zT_181, zT_182);
    if ((unsigned char)(!zT_185)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_189 = node.kind;
    if ((unsigned char)(zT_189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_187.has_value = 0;
    return zT_187;
    z_bb_66:
    zT_188.has_value = 1;
    zT_188.value = res;
    return zT_188;
    z_bb_67:
    zT_194 = zF_DC9B7BC0_ciZeroInt();
    q = zT_194;
    zT_195 = lv;
    zT_196 = rv;
    zT_197 = &q;
    zT_198 = &res;
    zT_201 = zF_25A0EEC0_ciDivMod(zT_195, zT_196, zT_197, zT_198);
    if ((unsigned char)(!zT_201)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_205 = node.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    zT_203.has_value = 0;
    return zT_203;
    z_bb_70:
    zT_204.has_value = 1;
    zT_204.value = res;
    return zT_204;
    z_bb_71:
    zT_209 = lv;
    zT_210 = rv;
    zT_211 = &res;
    zT_213 = zF_E15DE14D_ciBitAnd(zT_209, zT_210, zT_211);
    if ((unsigned char)(!zT_213)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_217 = node.kind;
    if ((unsigned char)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    zT_215.has_value = 0;
    return zT_215;
    z_bb_74:
    zT_216.has_value = 1;
    zT_216.value = res;
    return zT_216;
    z_bb_75:
    zT_221 = lv;
    zT_222 = rv;
    zT_223 = &res;
    zT_225 = zF_93823331_ciBitOr(zT_221, zT_222, zT_223);
    if ((unsigned char)(!zT_225)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_229 = node.kind;
    if ((unsigned char)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_227.has_value = 0;
    return zT_227;
    z_bb_78:
    zT_228.has_value = 1;
    zT_228.value = res;
    return zT_228;
    z_bb_79:
    zT_233 = lv;
    zT_234 = rv;
    zT_235 = &res;
    zT_237 = zF_C592CA21_ciBitXor(zT_233, zT_234, zT_235);
    if ((unsigned char)(!zT_237)) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_241 = node.kind;
    if ((unsigned char)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    zT_239.has_value = 0;
    return zT_239;
    z_bb_82:
    zT_240.has_value = 1;
    zT_240.value = res;
    return zT_240;
    z_bb_83:
    zT_245 = lv;
    zT_246 = rv;
    zT_247 = &res;
    zT_249 = zF_4FDD0D22_ciShl(zT_245, zT_246, zT_247);
    if ((unsigned char)(!zT_249)) goto z_bb_85; else goto z_bb_86;
    z_bb_84:
    zT_253 = lv;
    zT_254 = rv;
    zT_255 = &res;
    zT_257 = zF_41DCF718_ciShr(zT_253, zT_254, zT_255);
    if ((unsigned char)(!zT_257)) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    zT_251.has_value = 0;
    return zT_251;
    z_bb_86:
    zT_252.has_value = 1;
    zT_252.value = res;
    return zT_252;
    z_bb_87:
    zT_259.has_value = 0;
    return zT_259;
    z_bb_88:
    zT_260.has_value = 1;
    zT_260.value = res;
    return zT_260;
    z_bb_89:
    zT_267 = env->store;
    zT_268 = node_idx;
    zT_270 = zF_53458827_astStoreIdentifier(zT_267, zT_268);
    name_id = zT_270;
    zT_271 = env->local_consts;
    zT_272 = zT_271.has_value;
    if (zT_272) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    zT_322 = node.kind;
    if ((unsigned char)(zT_322 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_103; else goto z_bb_104;
    z_bb_91:
    lcs = zT_271.value;
    zT_274 = lcs;
    zT_275 = name_id;
    zT_276 = zF_6532C387_localConstScopeLook(zT_274, zT_275);
    zT_277 = zT_276.has_value;
    if (zT_277) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_295 = env;
    zT_296 = name_id;
    zT_297 = zF_04FED007_symbolLookupAllModu(zT_295, zT_296);
    c_sym = zT_297;
    zT_298 = c_sym.has_value;
    if (zT_298) goto z_bb_97; else goto z_bb_98;
    z_bb_93:
    l_decl_node = zT_276.value;
    zT_280 = env->store;
    zT_281 = l_decl_node;
    zT_283 = zF_FCDD1D35_astStoreNodeAt(zT_280, zT_281);
    l_decl = zT_283;
    zT_284 = l_decl.child_1;
    if ((unsigned char)(zT_284 != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_287 = env;
    zT_290 = l_decl.child_1;
    zT_292 = depth + (unsigned int)(1);
    env = zT_287;
    node_idx = zT_290;
    depth = zT_292;
    goto z_bb_0;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    cs = c_sym.value;
    zT_300 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_300 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_321.has_value = 0;
    return zT_321;
    z_bb_99:
    zT_306 = env->store;
    zT_307 = cs->decl_node;
    zT_310 = zF_FCDD1D35_astStoreNodeAt(zT_306, zT_307);
    c_decl = zT_310;
    zT_311 = c_decl.child_1;
    if ((unsigned char)(zT_311 != (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_314 = env;
    zT_317 = c_decl.child_1;
    zT_319 = depth + (unsigned int)(1);
    env = zT_314;
    node_idx = zT_317;
    depth = zT_319;
    goto z_bb_0;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_327 = env;
    zT_328 = node.child_0;
    zT_330 = zF_0E4084E4_evalConstModuleOfEx(zT_327, zT_328);
    fa_mod_id = zT_330;
    if ((unsigned char)(fa_mod_id != (unsigned int)(0))) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_374 = node.kind;
    if ((unsigned char)(zT_374 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_115; else goto z_bb_116;
    z_bb_105:
    zT_334 = env->store;
    zT_335 = node_idx;
    zT_337 = zF_8BA26B9E_astStoreNodePayload(zT_334, zT_335);
    fa_field_id = zT_337;
    zT_338 = env->symbol_reg;
    zT_339 = fa_mod_id;
    zT_340 = fa_field_id;
    zT_342 = zF_A398987E_symbolRegistryQuali(zT_338, zT_339, zT_340);
    zT_343 = zT_342.has_value;
    if (zT_343) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_373.has_value = 0;
    return zT_373;
    z_bb_107:
    fa_sym = zT_342.value;
    zT_345 = env;
    zT_346 = node_idx;
    zT_347 = fa_field_id;
    zT_348 = fa_sym;
    zT_349 = zF_D43B245F_typeResolverCheckMe(zT_345, zT_346, zT_347, zT_348);
    if ((unsigned char)(!zT_349)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_351.has_value = 0;
    return zT_351;
    z_bb_110:
    zT_352 = fa_sym->flags;
    if ((unsigned char)((unsigned short)(zT_352 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_358 = env->store;
    zT_359 = fa_sym->decl_node;
    zT_362 = zF_FCDD1D35_astStoreNodeAt(zT_358, zT_359);
    fa_decl = zT_362;
    zT_363 = fa_decl.child_1;
    if ((unsigned char)(zT_363 != (unsigned int)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_108;
    z_bb_113:
    zT_366 = env;
    zT_369 = fa_decl.child_1;
    zT_371 = depth + (unsigned int)(1);
    env = zT_366;
    node_idx = zT_369;
    depth = zT_371;
    goto z_bb_0;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_379 = "@sizeOf";
    zT_381 = 7;
    zT_380.ptr = zT_379;
    zT_380.len = zT_381;
    s_size = zT_380;
    zT_383 = env->interner;
    zT_384 = s_size;
    zT_386 = zF_50C274AF_stringInternerInter(zT_383, zT_384);
    size_id = zT_386;
    zT_388 = "@alignOf";
    zT_390 = 8;
    zT_389.ptr = zT_388;
    zT_389.len = zT_390;
    s_align = zT_389;
    zT_392 = env->interner;
    zT_393 = s_align;
    zT_395 = zF_50C274AF_stringInternerInter(zT_392, zT_393);
    align_id = zT_395;
    zT_397 = "@bitSizeOf";
    zT_399 = 10;
    zT_398.ptr = zT_397;
    zT_398.len = zT_399;
    s_bitsz = zT_398;
    zT_401 = env->interner;
    zT_402 = s_bitsz;
    zT_404 = zF_50C274AF_stringInternerInter(zT_401, zT_402);
    bitsz_id = zT_404;
    zT_406 = "@intCast";
    zT_408 = 8;
    zT_407.ptr = zT_406;
    zT_407.len = zT_408;
    s_intc = zT_407;
    zT_410 = env->interner;
    zT_411 = s_intc;
    zT_413 = zF_50C274AF_stringInternerInter(zT_410, zT_411);
    intc_id = zT_413;
    zT_415 = "@as";
    zT_417 = 3;
    zT_416.ptr = zT_415;
    zT_416.len = zT_417;
    s_as = zT_416;
    zT_419 = env->interner;
    zT_420 = s_as;
    zT_422 = zF_50C274AF_stringInternerInter(zT_419, zT_420);
    as_id = zT_422;
    zT_424 = "@offsetOf";
    zT_426 = 9;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    s_off = zT_425;
    zT_428 = env->interner;
    zT_429 = s_off;
    zT_431 = zF_50C274AF_stringInternerInter(zT_428, zT_429);
    off_id = zT_431;
    zT_433 = "@bitOffsetOf";
    zT_435 = 12;
    zT_434.ptr = zT_433;
    zT_434.len = zT_435;
    s_bitoff = zT_434;
    zT_437 = env->interner;
    zT_438 = s_bitoff;
    zT_440 = zF_50C274AF_stringInternerInter(zT_437, zT_438);
    bitoff_id = zT_440;
    zT_442 = env->store;
    zT_443 = node_idx;
    zT_445 = zF_152E19CB_astStoreNodeExtraCh(zT_442, zT_443);
    bc_n = zT_445;
    zT_446 = node.child_0;
    if ((unsigned char)(zT_446 == intc_id)) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_801.has_value = 0;
    return zT_801;
    z_bb_117:
    zT_449 = node.child_0;
    zT_448 = zT_449 == as_id;
    goto z_bb_119;
    z_bb_118:
    zT_448 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_448) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_490 = node.child_0;
    if ((unsigned char)(zT_490 == size_id)) goto z_bb_131; else goto z_bb_130;
    z_bb_122:
    zT_454 = env;
    zT_457 = env->store;
    zT_458 = node_idx;
    zT_462 = zF_B10B1BC1_astStoreNodeExtraCh(zT_457, zT_458, (unsigned int)(0));
    zT_455 = zT_462;
    zT_465 = zF_F2107C15_resolveTypeExprFull(zT_454, zT_455, (unsigned int)(depth + (unsigned int)(1)));
    ct_tid = zT_465;
    if ((unsigned char)(ct_tid != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    zT_489.has_value = 0;
    return zT_489;
    z_bb_124:
    zT_469 = env;
    zT_472 = env->store;
    zT_473 = node_idx;
    zT_477 = zF_B10B1BC1_astStoreNodeExtraCh(zT_472, zT_473, (unsigned int)(1));
    zT_470 = zT_477;
    zT_480 = zF_382591DE_evalConstIntFull(zT_469, zT_470, (unsigned int)(depth + (unsigned int)(1)));
    cv_opt = zT_480;
    zT_481 = cv_opt.has_value;
    if (zT_481) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    goto z_bb_123;
    z_bb_126:
    cv = cv_opt.value;
    zT_483 = env->typereg;
    zT_484 = cv;
    zT_485 = ct_tid;
    zT_487 = zF_B28C4720_comptimeIntFitsType(zT_483, zT_484, zT_485);
    if (zT_487) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_488.has_value = 1;
    zT_488.value = cv;
    return zT_488;
    z_bb_129:
    goto z_bb_127;
    z_bb_130:
    zT_493 = node.child_0;
    zT_492 = zT_493 == align_id;
    goto z_bb_132;
    z_bb_131:
    zT_492 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_492) goto z_bb_134; else goto z_bb_133;
    z_bb_133:
    zT_496 = node.child_0;
    zT_495 = zT_496 == bitsz_id;
    goto z_bb_135;
    z_bb_134:
    zT_495 = 1;
    goto z_bb_135;
    z_bb_135:
    if (zT_495) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    if ((unsigned char)(bc_n >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_137:
    zT_616 = node.child_0;
    if ((unsigned char)(zT_616 == off_id)) goto z_bb_170; else goto z_bb_169;
    z_bb_138:
    zT_501 = env;
    zT_504 = env->store;
    zT_505 = node_idx;
    zT_509 = zF_B10B1BC1_astStoreNodeExtraCh(zT_504, zT_505, (unsigned int)(0));
    zT_502 = zT_509;
    zT_512 = zF_F2107C15_resolveTypeExprFull(zT_501, zT_502, (unsigned int)(depth + (unsigned int)(1)));
    bt_tid = zT_512;
    if ((unsigned char)(bt_tid != (unsigned int)(18))) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_615.has_value = 0;
    return zT_615;
    z_bb_140:
    zT_516 = env->typereg;
    zT_517 = zT_516->types_items;
    zT_518 = (unsigned int)bt_tid;
    zT_519 = zT_517[zT_518];
    bt_ty = zT_519;
    zT_520 = bt_ty.state;
    if ((unsigned char)(zT_520 != (unsigned char)(2))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_524 = bt_ty.kind;
    zT_523 = zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_144;
    z_bb_143:
    zT_523 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_523) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_528 = env->typereg;
    zT_529 = bt_tid;
    zT_533 = zF_3E55D0D5_layoutEnsure(zT_528, zT_529, (unsigned int)(0));
    (void)zT_533;
    zT_534 = env->typereg;
    zT_535 = zT_534->types_items;
    zT_536 = (unsigned int)bt_tid;
    zT_537 = zT_535[zT_536];
    bt_ty = zT_537;
    goto z_bb_146;
    z_bb_146:
    zT_539 = bt_ty.kind;
    zT_541 = zF_6AE4DFFC_evalConstScalarKind(zT_539);
    bt_foldable = zT_541;
    zT_542 = bt_ty.kind;
    if ((unsigned char)(zT_542 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_546 = 1;
    bt_foldable = zT_546;
    goto z_bb_148;
    z_bb_148:
    zT_547 = bt_ty.state;
    if ((unsigned char)(zT_547 == (unsigned char)(2))) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_550 = bt_foldable;
    goto z_bb_151;
    z_bb_150:
    zT_550 = 0;
    goto z_bb_151;
    z_bb_151:
    if (zT_550) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_551 = node.child_0;
    if ((unsigned char)(zT_551 == size_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_141;
    z_bb_154:
    zT_554 = bt_ty.size;
    zT_556 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_554));
    zT_557.has_value = 1;
    zT_557.value = zT_556;
    return zT_557;
    z_bb_155:
    zT_558 = node.child_0;
    if ((unsigned char)(zT_558 == align_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_561 = bt_ty.alignment;
    zT_563 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_561));
    zT_564.has_value = 1;
    zT_564.value = zT_563;
    return zT_564;
    z_bb_157:
    zT_566 = bt_ty.size;
    zT_568 = zT_566 * (unsigned int)(8);
    bt_bits = zT_568;
    zT_569 = env->typereg;
    zT_570 = bt_tid;
    zT_572 = zF_3290E9C4_typeRegistryIsInteg(zT_569, zT_570);
    if (zT_572) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_573 = env->typereg;
    zT_574 = bt_tid;
    zT_576 = zF_655972D5_typeRegistryIntWidt(zT_573, zT_574);
    zT_577 = (unsigned int)zT_576;
    bt_bits = zT_577;
    goto z_bb_159;
    z_bb_159:
    zT_578 = bt_ty.kind;
    if ((unsigned char)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_582 = env->typereg;
    zT_585 = env->typereg;
    zT_586 = bt_tid;
    zT_588 = zF_014D7530_typeRegistryEnumBac(zT_585, zT_586);
    zT_583 = zT_588;
    zT_589 = zF_655972D5_typeRegistryIntWidt(zT_582, zT_583);
    zT_590 = (unsigned int)zT_589;
    bt_bits = zT_590;
    goto z_bb_161;
    z_bb_161:
    zT_591 = bt_ty.kind;
    if ((unsigned char)(zT_591 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_595 = 1;
    bt_bits = zT_595;
    goto z_bb_163;
    z_bb_163:
    zT_596 = bt_ty.kind;
    if ((unsigned char)(zT_596 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_601 = bt_ty.flags;
    zT_600 = (unsigned char)(zT_601 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_166;
    z_bb_165:
    zT_600 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_600) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_606 = env->typereg;
    zT_607 = bt_tid;
    zT_609 = zF_CB27DBA4_typeRegistryGetPack(zT_606, zT_607);
    zT_610 = (unsigned int)zT_609;
    bt_bits = zT_610;
    goto z_bb_168;
    z_bb_168:
    zT_613 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)bt_bits));
    zT_614.has_value = 1;
    zT_614.value = zT_613;
    return zT_614;
    z_bb_169:
    zT_619 = node.child_0;
    zT_618 = zT_619 == bitoff_id;
    goto z_bb_171;
    z_bb_170:
    zT_618 = 1;
    goto z_bb_171;
    z_bb_171:
    if (zT_618) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_174; else goto z_bb_175;
    z_bb_173:
    zT_800.has_value = 0;
    return zT_800;
    z_bb_174:
    zT_624 = env;
    zT_627 = env->store;
    zT_628 = node_idx;
    zT_632 = zF_B10B1BC1_astStoreNodeExtraCh(zT_627, zT_628, (unsigned int)(0));
    zT_625 = zT_632;
    zT_635 = zF_F2107C15_resolveTypeExprFull(zT_624, zT_625, (unsigned int)(depth + (unsigned int)(1)));
    ot_tid = zT_635;
    if ((unsigned char)(ot_tid != (unsigned int)(18))) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    zT_799.has_value = 0;
    return zT_799;
    z_bb_176:
    zT_639 = env->typereg;
    zT_640 = zT_639->types_items;
    zT_641 = (unsigned int)ot_tid;
    zT_642 = zT_640[zT_641];
    ot_ty = zT_642;
    zT_643 = ot_ty.state;
    if ((unsigned char)(zT_643 == (unsigned char)(2))) goto z_bb_178; else goto z_bb_179;
    z_bb_177:
    goto z_bb_175;
    z_bb_178:
    zT_647 = ot_ty.kind;
    zT_646 = zT_647 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_180;
    z_bb_179:
    zT_646 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_646) goto z_bb_181; else goto z_bb_183;
    z_bb_181:
    fields = zT_652;
    zT_653 = env->typereg;
    zT_654 = ot_tid;
    zT_655 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_653, zT_654, zT_655);
    packed_fields = zT_659;
    zT_661 = env->typereg;
    zT_662 = ot_tid;
    zT_663 = &packed_fields;
    zT_666 = zF_7D87247C_typeRegistryGetPack(zT_661, zT_662, zT_663);
    has_pk = zT_666;
    zT_668 = env->store;
    zT_671 = env->store;
    zT_672 = node_idx;
    zT_676 = zF_B10B1BC1_astStoreNodeExtraCh(zT_671, zT_672, (unsigned int)(1));
    zT_669 = zT_676;
    zT_677 = zF_FCDD1D35_astStoreNodeAt(zT_668, zT_669);
    fname_node = zT_677;
    zT_678 = fname_node.kind;
    if ((unsigned char)(zT_678 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_184; else goto z_bb_185;
    z_bb_182:
    goto z_bb_177;
    z_bb_183:
    zT_737 = ot_ty.state;
    if ((unsigned char)(zT_737 == (unsigned char)(2))) goto z_bb_202; else goto z_bb_203;
    z_bb_184:
    zT_683 = env->store;
    zT_686 = env->store;
    zT_687 = node_idx;
    zT_691 = zF_B10B1BC1_astStoreNodeExtraCh(zT_686, zT_687, (unsigned int)(1));
    zT_684 = zT_691;
    zT_692 = zF_8BA26B9E_astStoreNodePayload(zT_683, zT_684);
    sv_idx = zT_692;
    zT_694 = env->store;
    zT_695 = zT_694->string_values;
    zT_696 = zT_695.items;
    zT_697 = (unsigned int)sv_idx;
    zT_698 = zT_696[zT_697];
    want_id = zT_698;
    zT_700 = 0;
    zT_701 = (unsigned int)zT_700;
    fi = zT_701;
    goto z_bb_186;
    z_bb_185:
    goto z_bb_182;
    z_bb_186:
    zT_703 = fields.len;
    if ((unsigned char)(fi < zT_703)) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_705 = fields.ptr;
    zT_706 = zT_705[fi];
    zT_707 = zT_706.name_id;
    if ((unsigned char)(zT_707 == want_id)) goto z_bb_190; else goto z_bb_191;
    z_bb_188:
    goto z_bb_185;
    z_bb_189:
    zT_734 = 1;
    zT_736 = fi + (unsigned int)((unsigned int)zT_734);
    fi = zT_736;
    goto z_bb_186;
    z_bb_190:
    zT_710 = fields.ptr;
    zT_711 = zT_710[fi];
    zT_712 = zT_711.offset;
    zT_713 = (zT_79FAE712_u64)zT_712;
    bo = zT_713;
    if (has_pk) goto z_bb_192; else goto z_bb_194;
    z_bb_191:
    goto z_bb_189;
    z_bb_192:
    zT_715 = 0;
    pk_bo = zT_715;
    zT_717 = packed_fields.len;
    if ((unsigned char)(fi < zT_717)) goto z_bb_195; else goto z_bb_196;
    z_bb_193:
    zT_731 = bo;
    zT_732 = zF_1EAA44E6_ciFromU64(zT_731);
    zT_733.has_value = 1;
    zT_733.value = zT_732;
    return zT_733;
    z_bb_194:
    zT_727 = node.child_0;
    if ((unsigned char)(zT_727 == bitoff_id)) goto z_bb_200; else goto z_bb_201;
    z_bb_195:
    zT_719 = packed_fields.ptr;
    zT_720 = zT_719[fi];
    zT_721 = zT_720.bit_offset;
    zT_722 = (zT_79FAE712_u64)zT_721;
    pk_bo = zT_722;
    goto z_bb_196;
    z_bb_196:
    zT_723 = node.child_0;
    if ((unsigned char)(zT_723 == bitoff_id)) goto z_bb_197; else goto z_bb_199;
    z_bb_197:
    bo = pk_bo;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_193;
    z_bb_199:
    zT_726 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_726;
    goto z_bb_198;
    z_bb_200:
    zT_730 = bo * (zT_79FAE712_u64)(8);
    bo = zT_730;
    goto z_bb_201;
    z_bb_201:
    goto z_bb_193;
    z_bb_202:
    zT_741 = ot_ty.kind;
    zT_740 = zT_741 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_204;
    z_bb_203:
    zT_740 = 0;
    goto z_bb_204;
    z_bb_204:
    if (zT_740) goto z_bb_205; else goto z_bb_206;
    z_bb_205:
    u_fields = zT_746;
    zT_747 = env->typereg;
    zT_748 = ot_tid;
    zT_749 = &u_fields;
    zF_15BD2D98_typeRegistryGetUnio(zT_747, zT_748, zT_749);
    zT_753 = env->store;
    zT_756 = env->store;
    zT_757 = node_idx;
    zT_761 = zF_B10B1BC1_astStoreNodeExtraCh(zT_756, zT_757, (unsigned int)(1));
    zT_754 = zT_761;
    zT_762 = zF_FCDD1D35_astStoreNodeAt(zT_753, zT_754);
    fname_node2 = zT_762;
    zT_763 = fname_node2.kind;
    if ((unsigned char)(zT_763 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_207; else goto z_bb_208;
    z_bb_206:
    goto z_bb_182;
    z_bb_207:
    zT_768 = env->store;
    zT_771 = env->store;
    zT_772 = node_idx;
    zT_776 = zF_B10B1BC1_astStoreNodeExtraCh(zT_771, zT_772, (unsigned int)(1));
    zT_769 = zT_776;
    zT_777 = zF_8BA26B9E_astStoreNodePayload(zT_768, zT_769);
    sv_idx2 = zT_777;
    zT_779 = env->store;
    zT_780 = zT_779->string_values;
    zT_781 = zT_780.items;
    zT_782 = (unsigned int)sv_idx2;
    zT_783 = zT_781[zT_782];
    want_id2 = zT_783;
    zT_785 = 0;
    zT_786 = (unsigned int)zT_785;
    fi2 = zT_786;
    goto z_bb_209;
    z_bb_208:
    goto z_bb_206;
    z_bb_209:
    zT_788 = u_fields.len;
    if ((unsigned char)(fi2 < zT_788)) goto z_bb_210; else goto z_bb_211;
    z_bb_210:
    zT_790 = u_fields.ptr;
    zT_791 = zT_790[fi2];
    zT_792 = zT_791.name_id;
    if ((unsigned char)(zT_792 == want_id2)) goto z_bb_213; else goto z_bb_214;
    z_bb_211:
    goto z_bb_208;
    z_bb_212:
    zT_796 = 1;
    zT_798 = fi2 + (unsigned int)((unsigned int)zT_796);
    fi2 = zT_798;
    goto z_bb_209;
    z_bb_213:
    zT_794 = zF_DC9B7BC0_ciZeroInt();
    zT_795.has_value = 1;
    zT_795.value = zT_794;
    return zT_795;
    z_bb_214:
    goto z_bb_212;
}

/* evalConstIntToSize */
unsigned int zF_5C9D5CFF_evalConstIntToSize(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_6 = {0};
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt zT_8;
    int zT_9 = 0;
    int zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_79FAE712_u64 zT_14 = 0;
    zT_0163D9A4_ComptimeInt lim;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(4294967294u));
    lim = zT_6;
    zT_7 = v;
    zT_8 = lim;
    zT_9 = zF_6408F093_ciCmp(zT_7, zT_8);
    zT_10 = 0;
    if ((unsigned char)(zT_9 > zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_13 = v;
    zT_14 = zF_4F2C9C5D_ciToU64(zT_13);
    return (unsigned int)((unsigned int)zT_14);
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_45 = 0;
    unsigned int zT_48 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_58 = 0;
    zT_E63A2735_Opt_202 zT_61 = {0};
    unsigned char zT_64;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0163D9A4_ComptimeInt zT_67;
    unsigned int zT_68;
    unsigned char zT_70 = 0;
    zT_7034F045_Opt_228 zT_72;
    unsigned char zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_75;
    unsigned int zT_76;
    unsigned char zT_77 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_F85C5DED_DiagnosticCollector* zT_82;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_97 = 0;
    zT_0163D9A4_ComptimeInt zT_99;
    unsigned int zT_100 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_E63A2735_Opt_202 zT_106 = {0};
    unsigned char zT_107;
    zT_0163D9A4_ComptimeInt zT_108;
    zT_0163D9A4_ComptimeInt zT_110;
    zT_0163D9A4_ComptimeInt zT_111;
    unsigned int zT_112 = 0;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_0163D9A4_ComptimeInt v;
    unsigned int bc_n;
    unsigned int ic_tid;
    zT_E63A2735_Opt_202 ic_v;
    zT_0163D9A4_ComptimeInt iv;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "@intCast";
    zT_21 = 8;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    s_intc = zT_20;
    zT_23 = env->interner;
    zT_24 = s_intc;
    zT_26 = zF_50C274AF_stringInternerInter(zT_23, zT_24);
    intc_id = zT_26;
    zT_27 = node.child_0;
    if ((unsigned char)(zT_27 == intc_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_103 = env;
    zT_104 = node_idx;
    zT_105 = depth;
    zT_106 = zF_382591DE_evalConstIntFull(zT_103, zT_104, zT_105);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_22; else goto z_bb_21;
    z_bb_7:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_152E19CB_astStoreNodeExtraCh(zT_30, zT_31);
    bc_n = zT_33;
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_37 = env;
    zT_40 = env->store;
    zT_41 = node_idx;
    zT_45 = zF_B10B1BC1_astStoreNodeExtraCh(zT_40, zT_41, (unsigned int)(0));
    zT_38 = zT_45;
    zT_48 = zF_F2107C15_resolveTypeExprFull(zT_37, zT_38, (unsigned int)(depth + (unsigned int)(1)));
    ic_tid = zT_48;
    zT_50 = env;
    zT_53 = env->store;
    zT_54 = node_idx;
    zT_58 = zF_B10B1BC1_astStoreNodeExtraCh(zT_53, zT_54, (unsigned int)(1));
    zT_51 = zT_58;
    zT_61 = zF_382591DE_evalConstIntFull(zT_50, zT_51, (unsigned int)(depth + (unsigned int)(1)));
    ic_v = zT_61;
    if ((unsigned char)(ic_tid != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_64 = ic_v.has_value;
    if (zT_64) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    iv = ic_v.value;
    zT_66 = env->typereg;
    zT_67 = iv;
    zT_68 = ic_tid;
    zT_70 = zF_B28C4720_comptimeIntFitsType(zT_66, zT_67, zT_68);
    if ((unsigned char)(!zT_70)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_72 = env->diag;
    zT_73 = zT_72.has_value;
    if (zT_73) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_99 = iv;
    zT_100 = zF_5C9D5CFF_evalConstIntToSize(zT_99);
    return zT_100;
    z_bb_17:
    dg = zT_72.value;
    zT_75 = dg;
    zT_76 = node_idx;
    zT_77 = zF_4DD9DB2D_diagnosticCollector(zT_75, zT_76);
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned int)(4294967295u);
    z_bb_19:
    zT_79 = "@intCast value does not fit the target type";
    zT_81 = 43;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    ic_msg = zT_80;
    zT_82 = dg;
    zT_85 = env->source_file_id;
    zT_86 = node.span_start;
    zT_93 = node.span_start;
    zT_94 = node.span_len;
    zT_88 = ic_msg;
    zT_97 = zF_C82559AC_diagnosticCollector(zT_82, (unsigned char)(0), (unsigned short)(3000), zT_85, zT_86, (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94)), zT_88);
    (void)zT_97;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    return (unsigned int)(4294967295u);
    z_bb_22:
    zT_110 = zT_106.value;
    zT_108 = zT_110;
    goto z_bb_23;
    z_bb_23:
    v = zT_108;
    zT_111 = v;
    zT_112 = zF_5C9D5CFF_evalConstIntToSize(zT_111);
    return zT_112;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_ABC1EBBE_TypeResolveEnv* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E63A2735_Opt_202 zT_7 = {0};
    unsigned char zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_44E16D78_Opt_7 zT_10 = {0};
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt zT_12;
    unsigned char zT_13 = 0;
    zT_44E16D78_Opt_7 zT_15 = {0};
    zT_0163D9A4_ComptimeInt zT_16;
    zT_79FAE712_u64 zT_17 = 0;
    zT_C69B2266_i64 zT_18;
    zT_44E16D78_Opt_7 zT_19;
    zT_0163D9A4_ComptimeInt v;
    zT_4 = env;
    zT_5 = node_idx;
    zT_6 = depth;
    zT_7 = zF_382591DE_evalConstIntFull(zT_4, zT_5, zT_6);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_2:
    zT_11 = zT_7.value;
    zT_9 = zT_11;
    goto z_bb_3;
    z_bb_3:
    v = zT_9;
    zT_12 = v;
    zT_13 = zF_EF3A264A_comptimeIntFits64(zT_12);
    if ((unsigned char)(!zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_5:
    zT_16 = v;
    zT_17 = zF_4F2C9C5D_ciToU64(zT_16);
    zT_18 = (zT_C69B2266_i64)zT_17;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
}

/* symbolLookupAllModules */
zT_577B64BF_Opt_873 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_577B64BF_Opt_873 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_19;
    zT_577B64BF_Opt_873 zT_20 = {0};
    unsigned int si;
    zT_577B64BF_Opt_873 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* enumMembersResolve */
unsigned char zF_0FFDEDBD_enumMembersResolve(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node, unsigned char append, unsigned int mstart, unsigned char strict, unsigned char check_only, unsigned int* out_count, unsigned int* out_fail_node, unsigned int* out_fail_kind) {
    zT_29C26066_Arr_zT_C69B2266_i64 zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_C69B2266_i64 zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    zT_22A7C88B_AstNode zT_35 = {0};
    zT_8143F551_AstKind zT_36;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv* zT_45;
    unsigned int zT_46;
    zT_44E16D78_Opt_7 zT_50 = {0};
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned char zT_57;
    unsigned int zT_60;
    int zT_62;
    unsigned int zT_63;
    zT_C69B2266_i64 zT_66 = 0;
    unsigned int zT_67;
    zT_C69B2266_i64 zT_68;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_D96DCDF2_EnumMember* zT_70;
    unsigned int zT_73;
    zT_D96DCDF2_EnumMember zT_74;
    zT_C69B2266_i64 zT_75;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    unsigned int zT_82 = 0;
    int zT_85;
    unsigned int zT_87;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D96DCDF2_EnumMember zT_92;
    zT_D96DCDF2_EnumMember zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_103 = 0;
    unsigned int zT_104 = 0;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D96DCDF2_EnumMember* zT_106;
    zT_D96DCDF2_EnumMember* zT_110;
    int zT_111;
    unsigned int zT_113;
    zT_C69B2266_i64 zT_115;
    int zT_116;
    unsigned int zT_118;
    zT_29C26066_Arr_zT_C69B2266_i64 seen;
    unsigned int children_n;
    zT_C69B2266_i64 auto_val;
    unsigned int k;
    unsigned int i;
    zT_22A7C88B_AstNode mnode;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int dj_lim;
    unsigned int dj;
    zT_C69B2266_i64 prev;
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        seen[_i] = zT_10[_i];
        _i++;
    }
}
    zT_12 = env->store;
    zT_13 = enum_node;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    children_n = zT_15;
    zT_17 = 0;
    auto_val = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    k = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < children_n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_26 = env->store;
    zT_29 = env->store;
    zT_30 = enum_node;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_29, zT_30, (unsigned int)((unsigned int)i));
    zT_27 = zT_34;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    mnode = zT_35;
    zT_36 = mnode.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    *out_count = k;
    return (unsigned char)(1);
    z_bb_4:
    zT_116 = 1;
    zT_118 = i + (unsigned int)((unsigned int)zT_116);
    i = zT_118;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    mval = auto_val;
    zT_41 = mnode.child_1;
    if ((unsigned char)(zT_41 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_45 = env;
    zT_46 = mnode.child_1;
    zT_50 = zF_FFFAAD16_evalConstI64Full(zT_45, zT_46, (unsigned int)(0));
    ev_opt = zT_50;
    zT_51 = ev_opt.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    if (strict) goto z_bb_14; else goto z_bb_15;
    z_bb_9:
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    if (strict) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_53 = mnode.child_1;
    *out_fail_node = zT_53;
    *out_fail_kind = (unsigned int)(1);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    dj_lim = k;
    if (check_only) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if (check_only) goto z_bb_30; else goto z_bb_32;
    z_bb_16:
    zT_57 = dj_lim > (unsigned int)(256);
    goto z_bb_18;
    z_bb_17:
    zT_57 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_60 = 256;
    dj_lim = zT_60;
    goto z_bb_20;
    z_bb_20:
    zT_62 = 0;
    zT_63 = (unsigned int)zT_62;
    dj = zT_63;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(dj < dj_lim)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    prev = zT_66;
    if (check_only) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_15;
    z_bb_24:
    zT_85 = 1;
    zT_87 = dj + (unsigned int)((unsigned int)zT_85);
    dj = zT_87;
    goto z_bb_21;
    z_bb_25:
    zT_67 = (unsigned int)dj;
    zT_68 = seen[zT_67];
    prev = zT_68;
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(prev == mval)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_69 = env->typereg;
    zT_70 = zT_69->em_items;
    zT_73 = (unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)dj);
    zT_74 = zT_70[zT_73];
    zT_75 = zT_74.value;
    prev = zT_75;
    goto z_bb_26;
    z_bb_28:
    zT_77 = env->store;
    zT_78 = enum_node;
    zT_82 = zF_B10B1BC1_astStoreNodeExtraCh(zT_77, zT_78, (unsigned int)((unsigned int)i));
    *out_fail_node = zT_82;
    *out_fail_kind = (unsigned int)(2);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    if ((unsigned char)(k < (unsigned int)(256))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_111 = 1;
    zT_113 = k + (unsigned int)((unsigned int)zT_111);
    k = zT_113;
    zT_115 = mval + (zT_C69B2266_i64)(1);
    auto_val = zT_115;
    goto z_bb_4;
    z_bb_32:
    if (append) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    zT_90 = (unsigned int)k;
    seen[zT_90] = mval;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_91 = env->typereg;
    zT_95 = env->store;
    zT_98 = env->store;
    zT_99 = enum_node;
    zT_103 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)i));
    zT_96 = zT_103;
    zT_104 = zF_8BA26B9E_astStoreNodePayload(zT_95, zT_96);
    zT_94.name_id = zT_104;
    zT_94.value = mval;
    zT_92 = zT_94;
    zF_157DA7BF_emAppend(zT_91, zT_92);
    goto z_bb_36;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_105 = env->typereg;
    zT_106 = zT_105->em_items;
    zT_110 = zT_106 + (unsigned int)((unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)k));
    zT_110->value = mval;
    goto z_bb_36;
}

/* enumReevaluateAll */
void zF_153D24FD_enumReevaluateAll(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_8 = {0};
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    zT_6E8D187B_ModuleEntry zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_8143F551_AstKind zT_43;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_51;
    zT_8143F551_AstKind zT_52;
    unsigned char zT_56;
    unsigned int zT_57;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_72 = 0;
    zT_6E8D187B_ModuleEntry* zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_78;
    zT_79FAE712_u64 zT_83;
    zT_939EE900_Arr_unsigned_int_1 zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_79FAE712_u64 zT_89;
    zT_BAEE192E_Opt_10 zT_90 = {0};
    unsigned char zT_91;
    int zT_93;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_98;
    zT_D155D06D_Type* zT_101;
    unsigned int zT_102;
    zT_D155D06D_Type zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    zT_457ECFEE_EnumPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_457ECFEE_EnumPayload zT_112;
    zT_ABC1EBBE_TypeResolveEnv zT_114;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    zT_6E8D187B_ModuleEntry zT_119;
    unsigned int zT_120;
    zT_7034F045_Opt_228 zT_121;
    zT_02B97B5A_Opt_399 zT_122 = {0};
    zT_04CE5406_Opt_401 zT_123 = {0};
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_ABC1EBBE_TypeResolveEnv* zT_133;
    unsigned int zT_134;
    unsigned int zT_136;
    unsigned int* zT_139;
    unsigned int* zT_140;
    unsigned int* zT_141;
    unsigned char zT_150 = 0;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    zT_22A7C88B_AstNode zT_155 = {0};
    unsigned int zT_157;
    unsigned int zT_159;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_F85C5DED_DiagnosticCollector* zT_171;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zT_6E8D187B_ModuleEntry* zT_182;
    zT_6E8D187B_ModuleEntry zT_183;
    unsigned int zT_185 = 0;
    int zT_186;
    unsigned int zT_188;
    int zT_189;
    unsigned int zT_191;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    zT_939EE900_Arr_unsigned_int_1 tid_box;
    unsigned int t;
    unsigned int tid;
    zT_D155D06D_Type ety;
    zT_457ECFEE_EnumPayload ep;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep_;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_7 = module_reg;
    zT_8 = zF_3452C137_moduleRegistryGetMo(zT_7);
    mods = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    mi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    if ((unsigned char)(mi < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = mods.ptr;
    zT_17 = zT_16[mi];
    zT_18 = zT_17.ast_root;
    ast_root = zT_18;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_189 = 1;
    zT_191 = mi + (unsigned int)((unsigned int)zT_189);
    mi = zT_191;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_22 = store;
    zT_23 = ast_root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_22, zT_23);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < decls_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = store;
    zT_31 = ast_root;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_30, zT_31, (unsigned int)((unsigned int)di));
    decl_idx = zT_34;
    zT_36 = store;
    zT_37 = decl_idx;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    dnode = zT_38;
    zT_40 = 0;
    enum_node = zT_40;
    zT_42 = 0;
    enum_name_id = zT_42;
    zT_43 = dnode.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_186 = 1;
    zT_188 = di + (unsigned int)((unsigned int)zT_186);
    di = zT_188;
    goto z_bb_7;
    z_bb_11:
    zT_48 = dnode.child_1;
    zT_47 = zT_48 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_47 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_47) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    enum_node = decl_idx;
    zT_51 = dnode.child_0;
    enum_name_id = zT_51;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_16:
    zT_52 = dnode.kind;
    if ((unsigned char)(zT_52 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_57 = dnode.child_1;
    zT_56 = zT_57 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_56 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_56) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = store;
    zT_62 = dnode.child_1;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_61, zT_62);
    inn = zT_64;
    zT_65 = inn.kind;
    if ((unsigned char)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_69 = dnode.child_1;
    enum_node = zT_69;
    zT_70 = store;
    zT_71 = decl_idx;
    zT_72 = zF_8BA26B9E_astStoreNodePayload(zT_70, zT_71);
    enum_name_id = zT_72;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    goto z_bb_10;
    z_bb_25:
    zT_76 = mods.ptr;
    zT_77 = zT_76[mi];
    zT_78 = zT_77.id;
    zT_83 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_78) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_83;
    zT_86 = 0;
    zT_87 = 0;
    zT_85[zT_87] = zT_86;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        tid_box[_i] = zT_85[_i];
        _i++;
    }
}
    zT_88 = typereg;
    zT_89 = key;
    zT_90 = zF_0EB68360_nameCacheGet(zT_88, zT_89);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = zT_90.value;
    zT_93 = 0;
    tid_box[zT_93] = t;
    goto z_bb_27;
    z_bb_27:
    zT_95 = 0;
    zT_96 = tid_box[zT_95];
    tid = zT_96;
    zT_98 = typereg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_98)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_101 = typereg->types_items;
    zT_102 = (unsigned int)tid;
    zT_103 = zT_101[zT_102];
    ety = zT_103;
    zT_104 = ety.kind;
    if ((unsigned char)(zT_104 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_10;
    z_bb_32:
    zT_109 = typereg->en_items;
    zT_110 = ety.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    ep = zT_112;
    zT_114.store = store;
    zT_114.typereg = typereg;
    zT_114.symbol_reg = symbol_reg;
    zT_114.interner = interner;
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_114.module_id = zT_117;
    zT_118 = mods.ptr;
    zT_119 = zT_118[mi];
    zT_120 = zT_119.source_file_id;
    zT_114.source_file_id = zT_120;
    zT_121.has_value = 1;
    zT_121.value = diag;
    zT_114.diag = zT_121;
    zT_122.has_value = 0;
    zT_114.local_consts = zT_122;
    zT_123.has_value = 0;
    zT_114.local_types = zT_123;
    env = zT_114;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    count = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    fail_node = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    fail_kind = zT_132;
    zT_133 = &env;
    zT_134 = enum_node;
    zT_136 = ep.members_start;
    zT_139 = &count;
    zT_140 = &fail_node;
    zT_141 = &fail_kind;
    zT_150 = zF_0FFDEDBD_enumMembersResolve(zT_133, zT_134, (unsigned char)(0), zT_136, (unsigned char)(1), (unsigned char)(0), zT_139, zT_140, zT_141);
    if ((unsigned char)(!zT_150)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_153 = store;
    zT_154 = fail_node;
    zT_155 = zF_FCDD1D35_astStoreNodeAt(zT_153, zT_154);
    fn_ = zT_155;
    zT_157 = fn_.span_start;
    sp = zT_157;
    zT_159 = fn_.span_len;
    zT_161 = sp + (unsigned int)((unsigned int)zT_159);
    ep_ = zT_161;
    zT_163 = "enum member value is not a comptime-known integer expression";
    zT_165 = 60;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    msg = zT_164;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_10;
    z_bb_35:
    zT_168 = "duplicate enum tag value (tag values must be unique)";
    zT_170 = 52;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    msg = zT_169;
    goto z_bb_36;
    z_bb_36:
    zT_171 = diag;
    zT_182 = mods.ptr;
    zT_183 = zT_182[mi];
    zT_174 = zT_183.source_file_id;
    zT_175 = sp;
    zT_176 = ep_;
    zT_177 = msg;
    zT_185 = zF_C82559AC_diagnosticCollector(zT_171, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_174, zT_175, zT_176, zT_177);
    (void)zT_185;
    goto z_bb_34;
}

/* containerAnonNameId */
unsigned int zF_27A59B24_containerAnonNameId(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_3;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    unsigned int zT_17;
    zT_4428DEE2_Arr_unsigned_char_2 zT_19;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_22;
    int zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_28;
    int zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int zT_45;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    zT_5826BFC7_Arr_unsigned_char_1 idb;
    unsigned int idl;
    unsigned int ids;
    zT_4428DEE2_Arr_unsigned_char_2 nm;
    unsigned int di;
    unsigned int namelen;
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        idb[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = node_idx;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)idb) + zT_9;
    zT_11 = (unsigned int)(12) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_6 = zT_12;
    zT_13 = zF_A7504564_itoa(zT_5, zT_6);
    idl = zT_13;
    zT_17 = (unsigned int)(11) - (unsigned int)((unsigned int)idl);
    ids = zT_17;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_19[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        nm[_i] = zT_19[_i];
        _i++;
    }
}
    zT_20 = 97;
    zT_21 = 0;
    nm[zT_21] = zT_20;
    zT_22 = 110;
    zT_23 = 1;
    nm[zT_23] = zT_22;
    zT_24 = 111;
    zT_25 = 2;
    nm[zT_25] = zT_24;
    zT_26 = 110;
    zT_27 = 3;
    nm[zT_27] = zT_26;
    zT_28 = 95;
    zT_29 = 4;
    nm[zT_29] = zT_28;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    di = zT_32;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(di < (unsigned int)((unsigned int)idl))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_35 = ids + di;
    zT_36 = idb[zT_35];
    zT_38 = (unsigned int)(5) + di;
    nm[zT_38] = zT_36;
    goto z_bb_4;
    z_bb_3:
    zT_45 = (unsigned int)(5) + (unsigned int)((unsigned int)idl);
    namelen = zT_45;
    zT_46 = env->interner;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)nm) + zT_51;
    zT_53 = namelen - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_47 = zT_54;
    zT_55 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    return zT_55;
    z_bb_4:
    zT_39 = 1;
    zT_41 = di + (unsigned int)((unsigned int)zT_39);
    di = zT_41;
    goto z_bb_1;
}

/* isContainerDeclKind */
unsigned char zF_82C2F046_isContainerDeclKind(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    return zT_12;
}

/* isCompoundTypeExprKind */
unsigned char zF_599C0D79_isCompoundTypeExprK(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    return zT_24;
}

/* containerFieldCount */
unsigned int zF_3B3163AB_containerFieldCount(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    unsigned int zT_9 = 0;
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_21 = 0;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    int zT_30;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_35;
    unsigned int count;
    unsigned int children_n;
    unsigned int i;
    unsigned int child;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    count = zT_4;
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_152E19CB_astStoreNodeExtraCh(zT_6, zT_7);
    children_n = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = env->store;
    zT_17 = node_idx;
    zT_21 = zF_B10B1BC1_astStoreNodeExtraCh(zT_16, zT_17, (unsigned int)((unsigned int)i));
    child = zT_21;
    zT_22 = env->store;
    zT_23 = child;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_26 = zT_25.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return count;
    z_bb_4:
    zT_33 = 1;
    zT_35 = i + (unsigned int)((unsigned int)zT_33);
    i = zT_35;
    goto z_bb_1;
    z_bb_5:
    zT_30 = 1;
    zT_32 = count + (unsigned int)((unsigned int)zT_30);
    count = zT_32;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* validateLocalEnum */
void zF_9084D8CB_validateLocalEnum(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node) {
    zT_7034F045_Opt_228 zT_5;
    unsigned char zT_6;
    zT_F85C5DED_DiagnosticCollector* zT_7;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_10;
    unsigned char zT_11 = 0;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    unsigned int zT_23;
    unsigned int* zT_28;
    unsigned int* zT_29;
    unsigned int* zT_30;
    unsigned char zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_22A7C88B_AstNode zT_44 = {0};
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_F85C5DED_DiagnosticCollector* zT_60;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_72 = 0;
    zT_F85C5DED_DiagnosticCollector* diag;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = env->diag;
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    return;
    z_bb_4:
    zT_7 = zT_5.value;
    goto z_bb_5;
    z_bb_5:
    diag = zT_7;
    zT_9 = diag;
    zT_10 = enum_node;
    zT_11 = zF_4DD9DB2D_diagnosticCollector(zT_9, zT_10);
    if ((unsigned char)(!zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    count = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fail_node = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    fail_kind = zT_21;
    zT_22 = env;
    zT_23 = enum_node;
    zT_28 = &count;
    zT_29 = &fail_node;
    zT_30 = &fail_kind;
    zT_38 = zF_0FFDEDBD_enumMembersResolve(zT_22, zT_23, (unsigned char)(0), (unsigned int)(0), (unsigned char)(1), (unsigned char)(1), zT_28, zT_29, zT_30);
    if ((unsigned char)(!zT_38)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_41 = env->store;
    zT_42 = fail_node;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_41, zT_42);
    fn_ = zT_44;
    zT_46 = fn_.span_start;
    sp = zT_46;
    zT_48 = fn_.span_len;
    zT_50 = sp + (unsigned int)((unsigned int)zT_48);
    ep = zT_50;
    zT_52 = "enum member value is not a comptime-known integer expression";
    zT_54 = 60;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    msg = zT_53;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_57 = "duplicate enum tag value (tag values must be unique)";
    zT_59 = 52;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    msg = zT_58;
    goto z_bb_11;
    z_bb_11:
    zT_60 = diag;
    zT_63 = env->source_file_id;
    zT_64 = sp;
    zT_65 = ep;
    zT_66 = msg;
    zT_72 = zF_C82559AC_diagnosticCollector(zT_60, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_63, zT_64, zT_65, zT_66);
    (void)zT_72;
    goto z_bb_9;
}

/* registerContainerType */
unsigned int zF_FE81311F_registerContainerTy(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, zT_8143F551_AstKind kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_12;
    unsigned int zT_13;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_36 = 0;
    unsigned char zT_39;
    zT_ABC1EBBE_TypeResolveEnv* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_7034F045_Opt_228 zT_45;
    unsigned char zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    zT_33EF6BFB_TypeKind zT_70;
    unsigned char zT_75;
    int zT_79;
    zT_33EF6BFB_TypeKind zT_81;
    unsigned char zT_84;
    int zT_86;
    int zT_88;
    zT_33EF6BFB_TypeKind zT_90;
    zT_338B7C76_TypeRegistry* zT_100;
    unsigned int zT_102;
    zT_33EF6BFB_TypeKind zT_103;
    unsigned int zT_106 = 0;
    unsigned char zT_110;
    unsigned char zT_114;
    unsigned char zT_115;
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    unsigned int zT_130 = 0;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    unsigned int zT_137 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_139;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_141;
    int zT_143;
    unsigned int zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned char zT_150;
    zT_6B0A7D14_AstStore* zT_154;
    unsigned int zT_155;
    unsigned int zT_159 = 0;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    zT_22A7C88B_AstNode zT_164 = {0};
    zT_8143F551_AstKind zT_165;
    zT_ABC1EBBE_TypeResolveEnv* zT_169;
    unsigned int zT_170;
    unsigned int zT_175 = 0;
    zT_6B0A7D14_AstStore* zT_176;
    unsigned int zT_177;
    unsigned int zT_179 = 0;
    int zT_180;
    unsigned int zT_182;
    int zT_183;
    unsigned int zT_185;
    zT_338B7C76_TypeRegistry* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    int zT_193;
    unsigned int zT_194;
    zT_338B7C76_TypeRegistry* zT_196;
    zT_2DF01B61_FieldEntry zT_197;
    zT_2DF01B61_FieldEntry zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    int zT_203;
    unsigned int zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    zT_406493CE_StructPayload zT_207;
    zT_406493CE_StructPayload zT_209;
    unsigned int zT_210;
    unsigned short zT_211;
    zT_338B7C76_TypeRegistry* zT_213;
    unsigned int zT_214;
    unsigned int zT_217;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_D155D06D_Type* zT_220;
    unsigned int zT_221;
    zT_D155D06D_Type zT_222;
    zT_338B7C76_TypeRegistry* zT_223;
    zT_D155D06D_Type* zT_224;
    unsigned int zT_225;
    zT_6B0A7D14_AstStore* zT_229;
    unsigned int zT_230;
    unsigned int zT_232 = 0;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int zT_237;
    unsigned int zT_239 = 0;
    int zT_240;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_243;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_245;
    int zT_247;
    unsigned int zT_248;
    int zT_250;
    unsigned int zT_251;
    unsigned char zT_254;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_263 = 0;
    zT_6B0A7D14_AstStore* zT_265;
    unsigned int zT_266;
    zT_22A7C88B_AstNode zT_268 = {0};
    zT_8143F551_AstKind zT_269;
    zT_ABC1EBBE_TypeResolveEnv* zT_273;
    unsigned int zT_274;
    unsigned int zT_279 = 0;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    unsigned int zT_283 = 0;
    int zT_284;
    unsigned int zT_286;
    int zT_287;
    unsigned int zT_289;
    zT_338B7C76_TypeRegistry* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    int zT_295;
    unsigned int zT_296;
    zT_338B7C76_TypeRegistry* zT_298;
    zT_2DF01B61_FieldEntry zT_299;
    zT_2DF01B61_FieldEntry zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    int zT_305;
    unsigned int zT_307;
    unsigned char zT_308;
    int zT_310;
    int zT_312;
    zT_338B7C76_TypeRegistry* zT_314;
    zT_54FF90FA_TaggedUnionPayload zT_315;
    zT_54FF90FA_TaggedUnionPayload zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned short zT_320;
    zT_338B7C76_TypeRegistry* zT_322;
    unsigned int zT_323;
    unsigned int zT_326;
    zT_338B7C76_TypeRegistry* zT_328;
    zT_D155D06D_Type* zT_329;
    unsigned int zT_330;
    zT_D155D06D_Type zT_331;
    zT_338B7C76_TypeRegistry* zT_332;
    zT_D155D06D_Type* zT_333;
    unsigned int zT_334;
    zT_338B7C76_TypeRegistry* zT_335;
    zT_AF9231A2_UnionPayload zT_336;
    zT_AF9231A2_UnionPayload zT_338;
    unsigned int zT_339;
    unsigned short zT_340;
    unsigned int zT_341;
    zT_338B7C76_TypeRegistry* zT_343;
    unsigned int zT_344;
    unsigned int zT_347;
    zT_338B7C76_TypeRegistry* zT_349;
    zT_D155D06D_Type* zT_350;
    unsigned int zT_351;
    zT_D155D06D_Type zT_352;
    zT_338B7C76_TypeRegistry* zT_353;
    zT_D155D06D_Type* zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_356;
    zT_6B0A7D14_AstStore* zT_357;
    zT_8143F551_AstKind zT_358;
    unsigned int zT_359;
    zT_3D7259E2_SymbolRegistry* zT_360;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_BAEE192E_Opt_10 existing;
    unsigned int e;
    zT_33EF6BFB_TypeKind type_kind;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_msg;
    unsigned int tid;
    unsigned int sd_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    unsigned int sd_child;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned int un_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fnm;
    unsigned int un_fc;
    unsigned int un_i;
    unsigned int un_child;
    zT_22A7C88B_AstNode un_fd;
    unsigned int un_fstart;
    unsigned int un_j;
    unsigned int un_tu_idx;
    zT_D155D06D_Type un_tu_ty;
    unsigned int un_un_idx;
    zT_D155D06D_Type un_un_ty;
    zT_5 = env->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = env;
    zT_13 = node_idx;
    zF_9084D8CB_validateLocalEnum(zT_12, zT_13);
    goto z_bb_2;
    z_bb_2:
    zT_15 = env;
    zT_16 = node_idx;
    zT_17 = zF_27A59B24_containerAnonNameId(zT_15, zT_16);
    name_id = zT_17;
    zT_19 = env->typereg;
    zT_23 = zF_0EB68360_nameCacheGet(zT_19, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    existing = zT_23;
    zT_24 = existing.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    e = existing.value;
    return e;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_29 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_7;
    z_bb_6:
    zT_29 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = node_idx;
    zT_36 = zF_8BA26B9E_astStoreNodePayload(zT_33, zT_34);
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
switch (kind) {
case 3: goto z_bb_17;
case 4: goto z_bb_18;
case 5: goto z_bb_19;
case 9: goto z_bb_20;
default: goto z_bb_21;
}
    z_bb_10:
    zT_40 = env;
    zT_41 = node_idx;
    zT_42 = zF_3B3163AB_containerFieldCount(zT_40, zT_41);
    zT_39 = zT_42 > (unsigned int)(32);
    goto z_bb_12;
    z_bb_11:
    zT_39 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_39) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = env->diag;
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    diag = zT_45.value;
    zT_49 = "aggregate type has more than 32 fields, which is not supported";
    zT_51 = 62;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    fc_msg = zT_50;
    zT_52 = diag;
    zT_55 = env->source_file_id;
    zT_56 = node.span_start;
    zT_63 = node.span_start;
    zT_64 = node.span_len;
    zT_58 = fc_msg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_52, (unsigned char)(0), (unsigned short)(3000), zT_55, zT_56, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_58);
    (void)zT_67;
    goto z_bb_16;
    z_bb_16:
    return (unsigned int)(18);
    z_bb_17:
    zT_70 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_23;
    z_bb_18:
    zT_70 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_23;
    z_bb_19:
    zT_75 = node.flags;
    zT_79 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_75) & (unsigned short)(16)) != zT_79)) goto z_bb_24; else goto z_bb_25;
    z_bb_20:
    zT_70 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_23;
    z_bb_21:
    zT_70 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_23;
    z_bb_23:
    type_kind = zT_70;
    zT_100 = env->typereg;
    zT_102 = name_id;
    zT_103 = type_kind;
    zT_106 = zF_3A64E2E0_typeRegistryRegiste(zT_100, (unsigned int)(0), zT_102, zT_103);
    tid = zT_106;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_31; else goto z_bb_30;
    z_bb_24:
    zT_81 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_26;
    z_bb_25:
    zT_84 = node.flags;
    zT_86 = 1;
    zT_88 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_84) & zT_86) != zT_88)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_70 = zT_81;
    goto z_bb_23;
    z_bb_27:
    zT_90 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_29;
    z_bb_28:
    zT_90 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_29;
    z_bb_29:
    zT_81 = zT_90;
    goto z_bb_26;
    z_bb_30:
    zT_110 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_32;
    z_bb_31:
    zT_110 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_110) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_115 = node.flags;
    zT_114 = (unsigned short)((unsigned short)((unsigned short)zT_115) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_35;
    z_bb_34:
    zT_114 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_114) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_121 = env->typereg;
    zT_122 = tid;
    zF_52816016_typeRegistrySetPack(zT_121, zT_122);
    goto z_bb_37;
    z_bb_37:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_38; else goto z_bb_40;
    z_bb_38:
    zT_127 = env->store;
    zT_128 = node_idx;
    zT_130 = zF_8BA26B9E_astStoreNodePayload(zT_127, zT_128);
    if ((unsigned char)(zT_130 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    return tid;
    z_bb_40:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_58; else goto z_bb_60;
    z_bb_41:
    zT_134 = env->store;
    zT_135 = node_idx;
    zT_137 = zF_152E19CB_astStoreNodeExtraCh(zT_134, zT_135);
    sd_children_n = zT_137;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_139[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_139[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_141[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_141[_i];
        _i++;
    }
}
    zT_143 = 0;
    zT_144 = (unsigned int)zT_143;
    sd_fc = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    sd_i = zT_147;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    if ((unsigned char)(sd_i < (unsigned int)((unsigned int)sd_children_n))) goto z_bb_47; else goto z_bb_48;
    z_bb_44:
    zT_154 = env->store;
    zT_155 = node_idx;
    zT_159 = zF_B10B1BC1_astStoreNodeExtraCh(zT_154, zT_155, (unsigned int)((unsigned int)sd_i));
    sd_child = zT_159;
    zT_161 = env->store;
    zT_162 = sd_child;
    zT_164 = zF_FCDD1D35_astStoreNodeAt(zT_161, zT_162);
    sd_fd = zT_164;
    zT_165 = sd_fd.kind;
    if ((unsigned char)(zT_165 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_50; else goto z_bb_51;
    z_bb_45:
    if ((unsigned char)(sd_fc > (unsigned int)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_46:
    zT_183 = 1;
    zT_185 = sd_i + (unsigned int)((unsigned int)zT_183);
    sd_i = zT_185;
    goto z_bb_43;
    z_bb_47:
    zT_150 = sd_fc < (unsigned int)(32);
    goto z_bb_49;
    z_bb_48:
    zT_150 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_150) goto z_bb_44; else goto z_bb_45;
    z_bb_50:
    zT_169 = env;
    zT_170 = sd_fd.child_0;
    zT_175 = zF_F2107C15_resolveTypeExprFull(zT_169, zT_170, (unsigned int)(depth + (unsigned int)(1)));
    sd_fty[sd_fc] = zT_175;
    zT_176 = env->store;
    zT_177 = sd_child;
    zT_179 = zF_8BA26B9E_astStoreNodePayload(zT_176, zT_177);
    sd_fnm[sd_fc] = zT_179;
    zT_180 = 1;
    zT_182 = sd_fc + (unsigned int)((unsigned int)zT_180);
    sd_fc = zT_182;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_46;
    z_bb_52:
    zT_189 = env->typereg;
    zT_190 = zT_189->fe_len;
    zT_191 = (unsigned int)zT_190;
    sd_fstart = zT_191;
    zT_193 = 0;
    zT_194 = (unsigned int)zT_193;
    sd_j = zT_194;
    goto z_bb_54;
    z_bb_53:
    goto z_bb_42;
    z_bb_54:
    if ((unsigned char)(sd_j < sd_fc)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_196 = env->typereg;
    zT_200 = sd_fnm[sd_j];
    zT_199.name_id = zT_200;
    zT_201 = sd_fty[sd_j];
    zT_199.type_id = zT_201;
    zT_202 = 0;
    zT_199.offset = zT_202;
    zT_197 = zT_199;
    zF_701DF154_feAppend(zT_196, zT_197);
    goto z_bb_57;
    z_bb_56:
    zT_206 = env->typereg;
    zT_210 = (unsigned int)sd_fstart;
    zT_209.fields_start = zT_210;
    zT_211 = (unsigned short)sd_fc;
    zT_209.fields_count = zT_211;
    zT_207 = zT_209;
    zF_CF849366_stAppend(zT_206, zT_207);
    zT_213 = env->typereg;
    zT_214 = zT_213->st_len;
    zT_217 = (unsigned int)(unsigned int)(zT_214 - (unsigned int)(1));
    sd_st_idx = zT_217;
    zT_219 = env->typereg;
    zT_220 = zT_219->types_items;
    zT_221 = (unsigned int)tid;
    zT_222 = zT_220[zT_221];
    sd_ty = zT_222;
    sd_ty.payload_idx = sd_st_idx;
    zT_223 = env->typereg;
    zT_224 = zT_223->types_items;
    zT_225 = (unsigned int)tid;
    zT_224[zT_225] = sd_ty;
    goto z_bb_53;
    z_bb_57:
    zT_203 = 1;
    zT_205 = sd_j + (unsigned int)((unsigned int)zT_203);
    sd_j = zT_205;
    goto z_bb_54;
    z_bb_58:
    zT_229 = env->store;
    zT_230 = node_idx;
    zT_232 = zF_8BA26B9E_astStoreNodePayload(zT_229, zT_230);
    if ((unsigned char)(zT_232 != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_39;
    z_bb_60:
    zT_356 = env->typereg;
    zT_357 = env->store;
    zT_358 = kind;
    zT_359 = node_idx;
    zT_360 = env->symbol_reg;
    zF_020995FB_populateTypePayload(zT_356, zT_357, zT_358, zT_359, zT_360);
    goto z_bb_59;
    z_bb_61:
    zT_236 = env->store;
    zT_237 = node_idx;
    zT_239 = zF_152E19CB_astStoreNodeExtraCh(zT_236, zT_237);
    un_children_n = zT_239;
    zT_240 = 0;
    if ((unsigned char)(un_children_n != (unsigned int)zT_240)) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_243[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fty[_i] = zT_243[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_245[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fnm[_i] = zT_245[_i];
        _i++;
    }
}
    zT_247 = 0;
    zT_248 = (unsigned int)zT_247;
    un_fc = zT_248;
    zT_250 = 0;
    zT_251 = (unsigned int)zT_250;
    un_i = zT_251;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    if ((unsigned char)(un_i < (unsigned int)((unsigned int)un_children_n))) goto z_bb_69; else goto z_bb_70;
    z_bb_66:
    zT_258 = env->store;
    zT_259 = node_idx;
    zT_263 = zF_B10B1BC1_astStoreNodeExtraCh(zT_258, zT_259, (unsigned int)((unsigned int)un_i));
    un_child = zT_263;
    zT_265 = env->store;
    zT_266 = un_child;
    zT_268 = zF_FCDD1D35_astStoreNodeAt(zT_265, zT_266);
    un_fd = zT_268;
    zT_269 = un_fd.kind;
    if ((unsigned char)(zT_269 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_72; else goto z_bb_73;
    z_bb_67:
    zT_291 = env->typereg;
    zT_292 = zT_291->fe_len;
    zT_293 = (unsigned int)zT_292;
    un_fstart = zT_293;
    zT_295 = 0;
    zT_296 = (unsigned int)zT_295;
    un_j = zT_296;
    goto z_bb_74;
    z_bb_68:
    zT_287 = 1;
    zT_289 = un_i + (unsigned int)((unsigned int)zT_287);
    un_i = zT_289;
    goto z_bb_65;
    z_bb_69:
    zT_254 = un_fc < (unsigned int)(32);
    goto z_bb_71;
    z_bb_70:
    zT_254 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_254) goto z_bb_66; else goto z_bb_67;
    z_bb_72:
    zT_273 = env;
    zT_274 = un_fd.child_0;
    zT_279 = zF_F2107C15_resolveTypeExprFull(zT_273, zT_274, (unsigned int)(depth + (unsigned int)(1)));
    un_fty[un_fc] = zT_279;
    zT_280 = env->store;
    zT_281 = un_child;
    zT_283 = zF_8BA26B9E_astStoreNodePayload(zT_280, zT_281);
    un_fnm[un_fc] = zT_283;
    zT_284 = 1;
    zT_286 = un_fc + (unsigned int)((unsigned int)zT_284);
    un_fc = zT_286;
    goto z_bb_73;
    z_bb_73:
    goto z_bb_68;
    z_bb_74:
    if ((unsigned char)(un_j < un_fc)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_298 = env->typereg;
    zT_302 = un_fnm[un_j];
    zT_301.name_id = zT_302;
    zT_303 = un_fty[un_j];
    zT_301.type_id = zT_303;
    zT_304 = 0;
    zT_301.offset = zT_304;
    zT_299 = zT_301;
    zF_701DF154_feAppend(zT_298, zT_299);
    goto z_bb_77;
    z_bb_76:
    zT_308 = node.flags;
    zT_310 = 1;
    zT_312 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_308) & zT_310) != zT_312)) goto z_bb_78; else goto z_bb_80;
    z_bb_77:
    zT_305 = 1;
    zT_307 = un_j + (unsigned int)((unsigned int)zT_305);
    un_j = zT_307;
    goto z_bb_74;
    z_bb_78:
    zT_314 = env->typereg;
    zT_318 = 10;
    zT_317.tag_type = zT_318;
    zT_319 = (unsigned int)un_fstart;
    zT_317.fields_start = zT_319;
    zT_320 = (unsigned short)un_fc;
    zT_317.fields_count = zT_320;
    zT_315 = zT_317;
    zF_FB6B57C6_tuAppend(zT_314, zT_315);
    zT_322 = env->typereg;
    zT_323 = zT_322->tu_len;
    zT_326 = (unsigned int)(unsigned int)(zT_323 - (unsigned int)(1));
    un_tu_idx = zT_326;
    zT_328 = env->typereg;
    zT_329 = zT_328->types_items;
    zT_330 = (unsigned int)tid;
    zT_331 = zT_329[zT_330];
    un_tu_ty = zT_331;
    un_tu_ty.payload_idx = un_tu_idx;
    zT_332 = env->typereg;
    zT_333 = zT_332->types_items;
    zT_334 = (unsigned int)tid;
    zT_333[zT_334] = un_tu_ty;
    goto z_bb_79;
    z_bb_79:
    goto z_bb_64;
    z_bb_80:
    zT_335 = env->typereg;
    zT_339 = (unsigned int)un_fstart;
    zT_338.fields_start = zT_339;
    zT_340 = (unsigned short)un_fc;
    zT_338.fields_count = zT_340;
    zT_341 = 1;
    zT_338.tag_type = zT_341;
    zT_336 = zT_338;
    zF_1718422E_unAppend(zT_335, zT_336);
    zT_343 = env->typereg;
    zT_344 = zT_343->un_len;
    zT_347 = (unsigned int)(unsigned int)(zT_344 - (unsigned int)(1));
    un_un_idx = zT_347;
    zT_349 = env->typereg;
    zT_350 = zT_349->types_items;
    zT_351 = (unsigned int)tid;
    zT_352 = zT_350[zT_351];
    un_un_ty = zT_352;
    un_un_ty.payload_idx = un_un_idx;
    zT_353 = env->typereg;
    zT_354 = zT_353->types_items;
    zT_355 = (unsigned int)tid;
    zT_354[zT_355] = un_un_ty;
    goto z_bb_79;
}

/* typeResolverCheckMemberVisibility */
unsigned char zF_D43B245F_typeResolverCheckMe(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int name_id, zT_3A105EF1_Symbol* sym) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_8;
    unsigned char zT_9 = 0;
    zT_7034F045_Opt_228 zT_11;
    unsigned char zT_12;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_15;
    unsigned char zT_16 = 0;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29 = {0};
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_37;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43 = {0};
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode zT_76 = {0};
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_F85C5DED_DiagnosticCollector* dc;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv2;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvnm;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tvparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvmsg;
    zT_22A7C88B_AstNode tvnode;
    unsigned int tv_di;
    zT_22A7C88B_AstNode tv_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv_note;
    zT_4 = sym->module_id;
    zT_5 = env->module_id;
    if ((unsigned char)(zT_4 == zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = sym;
    zT_9 = zF_C08C479C_symbolIsPublic(zT_8);
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_11 = env->diag;
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    dc = zT_11.value;
    zT_14 = dc;
    zT_15 = node_idx;
    zT_16 = zF_4DD9DB2D_diagnosticCollector(zT_14, zT_15);
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = "'";
    zT_20 = 1;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    tv1 = zT_19;
    zT_22 = "' is not marked 'pub'";
    zT_24 = 21;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    tv2 = zT_23;
    zT_26 = env->interner;
    zT_27 = name_id;
    zT_29 = zF_9134020D_stringInternerGet(zT_26, zT_27);
    tvnm = zT_29;
    zT_32 = 0;
    zT_31[zT_32] = tv1;
    zT_33 = 1;
    zT_31[zT_33] = tvnm;
    zT_34 = 2;
    zT_31[zT_34] = tv2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tvparts[_i] = zT_31[_i];
        _i++;
    }
}
    zT_36 = env->interner;
    zT_40 = 0;
    zT_41 = tvparts + zT_40;
    zT_37 = zT_41;
    zT_43 = zF_8C4BFF7C_diagnosticBuilderMa(zT_36, zT_37, (unsigned int)(3));
    tvmsg = zT_43;
    zT_45 = env->store;
    zT_46 = node_idx;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_45, zT_46);
    tvnode = zT_48;
    zT_50 = dc;
    zT_53 = env->source_file_id;
    zT_54 = tvnode.span_start;
    zT_63 = tvnode.span_start;
    zT_64 = tvnode.span_len;
    zT_56 = tvmsg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_50, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3007_VISIBILITY_VIOLATION)), zT_53, zT_54, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_56);
    tv_di = zT_67;
    zT_68 = sym->decl_node;
    if ((unsigned char)(zT_68 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_72 = env->store;
    zT_73 = sym->decl_node;
    zT_76 = zF_FCDD1D35_astStoreNodeAt(zT_72, zT_73);
    tv_decl = zT_76;
    zT_78 = "declared here";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    tv_note = zT_79;
    zT_81 = dc;
    zT_82 = tv_di;
    zT_83 = sym->file_id;
    zT_84 = tv_decl.span_start;
    zT_89 = tv_decl.span_start;
    zT_90 = tv_decl.span_len;
    zT_86 = tv_note;
    zF_A9049B03_diagnosticCollector(zT_81, zT_82, zT_83, zT_84, (unsigned int)(zT_89 + (unsigned int)((unsigned int)zT_90)), zT_86);
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_04CE5406_Opt_401 zT_40;
    unsigned char zT_41;
    zT_C8A278E4_LocalTypeScope* zT_43;
    unsigned int zT_44;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    unsigned char zT_46;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_D3EB6303_StringInterner* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_57 = 0;
    unsigned int zT_58;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_72 = {0};
    unsigned char zT_73;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_95;
    unsigned int zT_96;
    zT_3D7259E2_SymbolRegistry* zT_97;
    unsigned int zT_98;
    zT_79FAE712_u64 zT_106;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_79FAE712_u64 zT_109;
    zT_BAEE192E_Opt_10 zT_111 = {0};
    unsigned char zT_112;
    int zT_114;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_3D7259E2_SymbolRegistry* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_577B64BF_Opt_873 zT_131 = {0};
    unsigned char zT_132;
    unsigned int zT_134;
    unsigned int zT_137;
    int zT_139;
    unsigned int zT_140;
    zT_3D7259E2_SymbolRegistry* zT_141;
    unsigned int zT_142;
    zT_3D7259E2_SymbolRegistry* zT_146;
    unsigned int zT_148;
    zT_577B64BF_Opt_873 zT_151 = {0};
    unsigned char zT_152;
    unsigned int zT_154;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    unsigned int zT_164;
    int zT_165;
    unsigned int zT_167;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    unsigned char zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_178;
    unsigned int zT_180 = 0;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_186 = 0;
    zT_8143F551_AstKind zT_188;
    unsigned char zT_192;
    zT_8143F551_AstKind zT_193;
    unsigned char zT_197;
    zT_8143F551_AstKind zT_198;
    zT_ABC1EBBE_TypeResolveEnv* zT_202;
    unsigned int zT_203;
    zT_8143F551_AstKind zT_204;
    unsigned int zT_205;
    unsigned int zT_207 = 0;
    zT_8143F551_AstKind zT_208;
    unsigned char zT_213;
    zT_ABC1EBBE_TypeResolveEnv* zT_215;
    unsigned int zT_216;
    unsigned int zT_221 = 0;
    zT_6B0A7D14_AstStore* zT_225;
    unsigned int zT_226;
    zT_22A7C88B_AstNode zT_229 = {0};
    zT_8143F551_AstKind zT_230;
    zT_6B0A7D14_AstStore* zT_235;
    unsigned int zT_236;
    unsigned int zT_239 = 0;
    int zT_241;
    unsigned int zT_242;
    zT_3D7259E2_SymbolRegistry* zT_243;
    unsigned int zT_244;
    zT_3D7259E2_SymbolRegistry* zT_248;
    unsigned int zT_250;
    zT_577B64BF_Opt_873 zT_253 = {0};
    unsigned char zT_254;
    zT_3C598AEF_SymbolKind zT_256;
    unsigned int zT_261;
    zT_3D7259E2_SymbolRegistry* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    unsigned int zT_270 = 0;
    zT_577B64BF_Opt_873 zT_271 = {0};
    unsigned char zT_272;
    zT_ABC1EBBE_TypeResolveEnv* zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    zT_3A105EF1_Symbol* zT_277;
    zT_6B0A7D14_AstStore* zT_278;
    unsigned int zT_279;
    unsigned int zT_281 = 0;
    unsigned char zT_282 = 0;
    unsigned int zT_285;
    unsigned char zT_288;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294;
    unsigned int zT_296;
    int zT_297;
    unsigned int zT_299;
    unsigned char* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_D155D06D_Type* zT_310;
    unsigned int zT_311;
    zT_D155D06D_Type zT_312;
    zT_33EF6BFB_TypeKind zT_313;
    unsigned int zT_318;
    zT_3D7259E2_SymbolRegistry* zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    zT_6B0A7D14_AstStore* zT_324;
    unsigned int zT_325;
    unsigned int zT_327 = 0;
    zT_577B64BF_Opt_873 zT_328 = {0};
    unsigned char zT_329;
    zT_ABC1EBBE_TypeResolveEnv* zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    zT_3A105EF1_Symbol* zT_334;
    zT_6B0A7D14_AstStore* zT_335;
    unsigned int zT_336;
    unsigned int zT_338 = 0;
    unsigned char zT_339 = 0;
    unsigned int zT_342;
    unsigned char zT_345;
    unsigned char* zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned int zT_351;
    unsigned int zT_353;
    unsigned char* zT_357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_358;
    unsigned int zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_8143F551_AstKind zT_362;
    zT_939EE900_Arr_unsigned_int_1 zT_367;
    zT_338B7C76_TypeRegistry* zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    zT_EDD37787_Arr_unsigned_short_ zT_373;
    unsigned short zT_374;
    unsigned int zT_375;
    zT_6B0A7D14_AstStore* zT_376;
    unsigned int zT_377;
    unsigned int zT_379 = 0;
    zT_6B0A7D14_AstStore* zT_383;
    unsigned int zT_384;
    unsigned int zT_386 = 0;
    unsigned short zT_387;
    int zT_388;
    int zT_390;
    unsigned int zT_391;
    zT_338B7C76_TypeRegistry* zT_394;
    unsigned int zT_395;
    zT_6B0A7D14_AstStore* zT_397;
    unsigned int zT_398;
    unsigned int zT_402 = 0;
    int zT_403;
    unsigned int zT_405;
    zT_338B7C76_TypeRegistry* zT_406;
    unsigned int zT_407;
    unsigned short zT_408;
    int zT_410;
    int zT_412;
    unsigned int zT_414 = 0;
    zT_8143F551_AstKind zT_415;
    zT_ABC1EBBE_TypeResolveEnv* zT_420;
    unsigned int zT_421;
    unsigned int zT_426 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    int zT_435;
    zT_ABC1EBBE_TypeResolveEnv* zT_438;
    unsigned int zT_439;
    unsigned int zT_444 = 0;
    int zT_448;
    unsigned int zT_449;
    int zT_450;
    zT_338B7C76_TypeRegistry* zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    int zT_455;
    unsigned int zT_457 = 0;
    zT_8143F551_AstKind zT_458;
    zT_939EE900_Arr_unsigned_int_1 zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    int zT_467;
    unsigned int zT_468;
    int zT_469;
    zT_ABC1EBBE_TypeResolveEnv* zT_471;
    unsigned int zT_472;
    unsigned int zT_477 = 0;
    int zT_478;
    unsigned char* zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    int zT_485;
    int zT_487;
    unsigned int zT_488;
    zT_99292002_Arr_unsigned_int_16 zT_493;
    unsigned int zT_495;
    zT_6B0A7D14_AstStore* zT_496;
    unsigned int zT_497;
    unsigned int zT_499 = 0;
    zT_6B0A7D14_AstStore* zT_503;
    unsigned int zT_504;
    unsigned int zT_506 = 0;
    unsigned int zT_508;
    unsigned char zT_511;
    zT_ABC1EBBE_TypeResolveEnv* zT_515;
    unsigned int zT_516;
    zT_6B0A7D14_AstStore* zT_518;
    unsigned int zT_519;
    unsigned int zT_523 = 0;
    unsigned int zT_526 = 0;
    unsigned int zT_531;
    unsigned int zT_533;
    unsigned char zT_535;
    unsigned char zT_536;
    unsigned char zT_541;
    zT_443A2803_Arr_unsigned_char_9 zT_543;
    unsigned int zT_545;
    unsigned char* zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    unsigned int zT_549;
    unsigned char* zT_552;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_553;
    unsigned int zT_554;
    unsigned int zT_556;
    unsigned int zT_558;
    unsigned char zT_560;
    unsigned char* zT_563;
    unsigned char zT_564;
    unsigned int zT_566;
    unsigned int zT_568;
    zT_5826BFC7_Arr_unsigned_char_1 zT_570;
    unsigned int zT_572;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_573;
    int zT_574;
    int zT_578;
    unsigned char* zT_579;
    unsigned int zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582 = 0;
    unsigned int zT_586;
    unsigned char zT_589;
    unsigned char zT_592;
    unsigned int zT_594;
    unsigned int zT_596;
    unsigned int zT_598;
    unsigned char zT_600;
    unsigned char zT_605;
    unsigned int zT_607;
    zT_5826BFC7_Arr_unsigned_char_1 zT_609;
    unsigned int zT_611;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_612;
    int zT_616;
    unsigned char* zT_617;
    unsigned int zT_618;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_619;
    unsigned int zT_620 = 0;
    unsigned int zT_624;
    unsigned char zT_627;
    unsigned char zT_630;
    unsigned int zT_632;
    unsigned int zT_634;
    unsigned int zT_636;
    zT_D3EB6303_StringInterner* zT_638;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_639;
    int zT_643;
    unsigned char* zT_644;
    unsigned int zT_645;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_646;
    unsigned int zT_647 = 0;
    zT_338B7C76_TypeRegistry* zT_649;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned int zT_653;
    zT_338B7C76_TypeRegistry* zT_655;
    unsigned int zT_656;
    unsigned int zT_660;
    zT_338B7C76_TypeRegistry* zT_662;
    unsigned int zT_663;
    unsigned int zT_669;
    unsigned char zT_670;
    int zT_677;
    unsigned int zT_679 = 0;
    unsigned char* zT_681;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_682;
    unsigned int zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_684;
    unsigned int zT_685;
    zT_338B7C76_TypeRegistry* zT_686;
    unsigned int zT_687;
    zT_338B7C76_TypeRegistry* zT_689;
    unsigned int zT_690;
    unsigned int zT_694 = 0;
    unsigned int zT_695;
    int zT_696;
    zT_ABC1EBBE_TypeResolveEnv* zT_699;
    unsigned int zT_700;
    unsigned int zT_705 = 0;
    zT_8143F551_AstKind zT_709;
    unsigned char zT_713;
    zT_8143F551_AstKind zT_714;
    unsigned char* zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    unsigned int zT_721;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_722;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_724;
    unsigned int zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    int zT_730;
    unsigned char* zT_731;
    unsigned int zT_732;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_733;
    unsigned int zT_734 = 0;
    unsigned int zT_738;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_739;
    unsigned char* zT_743;
    unsigned int zT_744;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_745;
    unsigned char* zT_747;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_748;
    unsigned int zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_752;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_755;
    zT_8143F551_AstKind zT_756;
    int zT_760;
    unsigned char* zT_761;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned int zT_764 = 0;
    unsigned int zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned char* zT_773;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    unsigned char* zT_777;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_782;
    unsigned int zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    int zT_788;
    unsigned char* zT_789;
    unsigned int zT_790;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    unsigned int zT_792 = 0;
    unsigned int zT_796;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_797;
    unsigned char* zT_801;
    unsigned int zT_802;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_803;
    unsigned char zT_805;
    unsigned char zT_809;
    unsigned char zT_811;
    unsigned char zT_815;
    zT_8143F551_AstKind zT_816;
    zT_338B7C76_TypeRegistry* zT_821;
    unsigned int zT_822;
    unsigned char zT_823;
    unsigned char zT_824;
    unsigned int zT_826 = 0;
    unsigned char* zT_828;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_829;
    unsigned int zT_830;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_831;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_833;
    unsigned int zT_835;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_836;
    int zT_839;
    unsigned char* zT_840;
    unsigned int zT_841;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_842;
    unsigned int zT_843 = 0;
    unsigned int zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned char* zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned char* zT_856;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_857;
    unsigned int zT_858;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_859;
    zT_338B7C76_TypeRegistry* zT_861;
    unsigned int zT_862;
    unsigned char zT_863;
    unsigned char zT_864;
    unsigned int zT_866 = 0;
    unsigned char* zT_868;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    unsigned int zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_873;
    unsigned int zT_875;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_876;
    int zT_879;
    unsigned char* zT_880;
    unsigned int zT_881;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_882;
    unsigned int zT_883 = 0;
    unsigned int zT_887;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_888;
    unsigned char* zT_892;
    unsigned int zT_893;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_894;
    unsigned char* zT_896;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_897;
    unsigned int zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    zT_8143F551_AstKind zT_900;
    unsigned char zT_905;
    unsigned char zT_909;
    zT_338B7C76_TypeRegistry* zT_911;
    unsigned int zT_912;
    unsigned char zT_913;
    unsigned int zT_915 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_917;
    unsigned int zT_919;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_920;
    int zT_923;
    unsigned char* zT_924;
    unsigned int zT_925;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_926;
    unsigned int zT_927 = 0;
    unsigned int zT_931;
    unsigned char* zT_933;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_934;
    unsigned int zT_935;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_936;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_937;
    unsigned char* zT_941;
    unsigned int zT_942;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_943;
    zT_4028D896_Arr_unsigned_char_2 zT_945;
    unsigned int zT_947;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_948;
    int zT_951;
    unsigned char* zT_952;
    unsigned int zT_953;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_954;
    unsigned int zT_955 = 0;
    unsigned int zT_959;
    unsigned char* zT_961;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_962;
    unsigned int zT_963;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_964;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_965;
    unsigned char* zT_969;
    unsigned int zT_970;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_971;
    unsigned char* zT_973;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_974;
    unsigned int zT_975;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_976;
    zT_8143F551_AstKind zT_977;
    unsigned char* zT_982;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_983;
    unsigned int zT_984;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_985;
    unsigned int zT_986;
    zT_338B7C76_TypeRegistry* zT_988;
    unsigned int zT_989;
    unsigned int zT_991 = 0;
    unsigned char* zT_993;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_994;
    unsigned int zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    unsigned int zT_997;
    zT_8143F551_AstKind zT_998;
    unsigned char* zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1005;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1006;
    unsigned char* zT_1008;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1009;
    unsigned int zT_1010;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1011;
    zT_4028D896_Arr_unsigned_char_2 zT_1013;
    unsigned int zT_1015;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1016;
    int zT_1019;
    unsigned char* zT_1020;
    unsigned int zT_1021;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1022;
    unsigned int zT_1023 = 0;
    unsigned int zT_1027;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1028;
    unsigned char* zT_1032;
    unsigned int zT_1033;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1034;
    unsigned int zT_1035;
    int zT_1036;
    zT_6B0A7D14_AstStore* zT_1039;
    unsigned int zT_1040;
    zT_22A7C88B_AstNode zT_1043 = {0};
    unsigned int zT_1045;
    unsigned char zT_1047;
    zT_ABC1EBBE_TypeResolveEnv* zT_1049;
    unsigned int zT_1050;
    unsigned int zT_1054 = 0;
    unsigned char zT_1057;
    unsigned char* zT_1059;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1060;
    unsigned int zT_1061;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1062;
    zT_4028D896_Arr_unsigned_char_2 zT_1064;
    unsigned int zT_1066;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1067;
    int zT_1070;
    unsigned char* zT_1071;
    unsigned int zT_1072;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1073;
    unsigned int zT_1074 = 0;
    unsigned int zT_1078;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1079;
    unsigned char* zT_1083;
    unsigned int zT_1084;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1085;
    zT_338B7C76_TypeRegistry* zT_1087;
    unsigned int zT_1088;
    unsigned int zT_1089;
    unsigned int zT_1091 = 0;
    unsigned char* zT_1093;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1094;
    unsigned int zT_1095;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1096;
    zT_4028D896_Arr_unsigned_char_2 zT_1098;
    unsigned int zT_1100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1101;
    int zT_1104;
    unsigned char* zT_1105;
    unsigned int zT_1106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1108 = 0;
    unsigned int zT_1112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1113;
    unsigned char* zT_1117;
    unsigned int zT_1118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1119;
    unsigned char* zT_1123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1124;
    unsigned int zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    unsigned char* zT_1128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1129;
    unsigned int zT_1130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1131;
    unsigned char zT_1133;
    zT_8143F551_AstKind zT_1134;
    zT_6B0A7D14_AstStore* zT_1139;
    unsigned int zT_1140;
    unsigned int zT_1143 = 0;
    zT_D3EB6303_StringInterner* zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1148 = {0};
    unsigned int zT_1150;
    unsigned char zT_1153;
    unsigned char* zT_1154;
    int zT_1155;
    unsigned char zT_1156;
    unsigned char zT_1159;
    zT_7034F045_Opt_228 zT_1161;
    unsigned char zT_1162;
    zT_F85C5DED_DiagnosticCollector* zT_1164;
    unsigned int zT_1165;
    unsigned char zT_1166 = 0;
    unsigned char* zT_1168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1169;
    unsigned int zT_1170;
    zT_F85C5DED_DiagnosticCollector* zT_1171;
    unsigned int zT_1174;
    unsigned int zT_1175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1177;
    unsigned int zT_1184;
    unsigned int zT_1185;
    unsigned int zT_1188 = 0;
    unsigned char* zT_1191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1192;
    unsigned int zT_1193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1194;
    unsigned int zT_1195;
    unsigned char* zT_1197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1198;
    unsigned int zT_1199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1200;
    zT_8143F551_AstKind zT_1202;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_C8A278E4_LocalTypeScope* lts;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    unsigned int lt;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    zT_577B64BF_Opt_873 sym_cur;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_577B64BF_Opt_873 sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    unsigned char arbu;
    unsigned int arbw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_577B64BF_Opt_873 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_577B64BF_Opt_873 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    unsigned int esd_children_n;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    unsigned int fnt_extra_n;
    unsigned int fnt_i;
    unsigned char fnt_conv;
    unsigned int fnt_pt;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptib;
    unsigned int ptil;
    unsigned int ptis;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptkb;
    unsigned int ptkl;
    unsigned int ptks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptcb;
    unsigned int ptcl;
    unsigned int ptcs;
    unsigned char is_const;
    unsigned char is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb;
    unsigned int ppl;
    unsigned int pps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb2;
    unsigned int ppl2;
    unsigned int pps2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_4028D896_Arr_unsigned_char_2 sl_e;
    unsigned int sl_el;
    unsigned int sl_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_4028D896_Arr_unsigned_char_2 sl_r;
    unsigned int sl_rl;
    unsigned int sl_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_4028D896_Arr_unsigned_char_2 t1b;
    unsigned int t1l;
    unsigned int t1s;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    unsigned char arr_resolved;
    unsigned int alf;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    zT_4028D896_Arr_unsigned_char_2 t2b;
    unsigned int t2l;
    unsigned int t2s;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    zT_4028D896_Arr_unsigned_char_2 t3b;
    unsigned int t3l;
    unsigned int t3s;
    unsigned char sz_is_inferred;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asn_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    name_id = zT_33;
    zT_35 = "OPTVOID:id";
    zT_37 = 10;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    opm4_m = zT_36;
    zT_38 = opm4_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_40 = env->local_types;
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_188 = node.kind;
    if ((unsigned char)(zT_188 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_38; else goto z_bb_37;
    z_bb_5:
    lts = zT_40.value;
    zT_43 = lts;
    zT_44 = name_id;
    zT_45 = zF_C768898A_localTypeScopeLooku(zT_43, zT_44);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_49 = env->interner;
    zT_50 = name_id;
    zT_52 = zF_9134020D_stringInternerGet(zT_49, zT_50);
    text = zT_52;
    zT_54 = env->interner;
    zT_55 = text;
    zT_57 = zF_50C274AF_stringInternerInter(zT_54, zT_55);
    canonical_id = zT_57;
    zT_58 = env->module_id;
    if ((unsigned char)(zT_58 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    lt = zT_45.value;
    return lt;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_62 = env->module_id;
    zT_67 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_62) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck_cur = zT_67;
    zT_69 = env->typereg;
    zT_70 = ck_cur;
    zT_72 = zF_0EB68360_nameCacheGet(zT_69, zT_70);
    tc_cur = zT_72;
    zT_73 = tc_cur.has_value;
    if (zT_73) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_76 = env->typereg;
    zT_80 = zF_0EB68360_nameCacheGet(zT_76, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_80;
    zT_82 = "OPTVOID:nc";
    zT_84 = 10;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    opnc_m = zT_83;
    zT_85 = opnc_m;
    zT_86 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_85, zT_86);
    zT_87 = tid.has_value;
    if (zT_87) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    t = tc_cur.value;
    return t;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    t = tid.value;
    return t;
    z_bb_14:
    zT_90 = "NF";
    zT_92 = 2;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    nf = zT_91;
    zT_93 = nf;
    zF_48AC7B3A_markerWrite(zT_93);
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    mi = zT_96;
    goto z_bb_15;
    z_bb_15:
    zT_97 = env->symbol_reg;
    zT_98 = zT_97->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_98))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_106 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck = zT_106;
    zT_108 = env->typereg;
    zT_109 = ck;
    zT_111 = zF_0EB68360_nameCacheGet(zT_108, zT_109);
    tc = zT_111;
    zT_112 = tc.has_value;
    if (zT_112) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    zT_118 = "N2";
    zT_120 = 2;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    n2 = zT_119;
    zT_121 = n2;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_122 = env->module_id;
    if ((unsigned char)(zT_122 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_21; else goto z_bb_22;
    z_bb_18:
    zT_114 = 1;
    zT_116 = mi + (unsigned int)((unsigned int)zT_114);
    mi = zT_116;
    goto z_bb_15;
    z_bb_19:
    t = tc.value;
    return t;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_126 = env->symbol_reg;
    zT_127 = env->module_id;
    zT_128 = name_id;
    zT_131 = zF_A398987E_symbolRegistryQuali(zT_126, zT_127, zT_128);
    sym_cur = zT_131;
    zT_132 = sym_cur.has_value;
    if (zT_132) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_139 = 0;
    zT_140 = (unsigned int)zT_139;
    si = zT_140;
    goto z_bb_27;
    z_bb_23:
    s = sym_cur.value;
    zT_134 = s->type_id;
    if ((unsigned char)(zT_134 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_137 = s->type_id;
    return zT_137;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_141 = env->symbol_reg;
    zT_142 = zT_141->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_142))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_146 = env->symbol_reg;
    zT_148 = name_id;
    zT_151 = zF_A398987E_symbolRegistryQuali(zT_146, (unsigned int)((unsigned int)si), zT_148);
    sym = zT_151;
    zT_152 = sym.has_value;
    if (zT_152) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_169 = "OPTVOID:idF";
    zT_171 = 11;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    opm4f_m = zT_170;
    zT_172 = opm4f_m;
    zT_173 = name_id;
    zF_C914CB83_markerWriteInt(zT_172, zT_173);
    zT_175 = 0;
    arbu = zT_175;
    zT_177 = text;
    zT_178 = &arbu;
    zT_180 = zF_741B5264_parseArbIntWidth(zT_177, zT_178);
    arbw = zT_180;
    if ((unsigned char)(arbw != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_30:
    zT_165 = 1;
    zT_167 = si + (unsigned int)((unsigned int)zT_165);
    si = zT_167;
    goto z_bb_27;
    z_bb_31:
    s = sym.value;
    zT_154 = s->type_id;
    if ((unsigned char)(zT_154 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_158 = "OPTVOID:ids";
    zT_160 = 11;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    ops_m = zT_159;
    zT_161 = ops_m;
    zT_162 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_164 = s->type_id;
    return zT_164;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_183 = env->typereg;
    zT_184 = text;
    zT_186 = zF_B8CF3697_typeRegistryGetOrCr(zT_183, zT_184);
    return zT_186;
    z_bb_36:
    return (unsigned int)(18);
    z_bb_37:
    zT_193 = node.kind;
    zT_192 = zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_39;
    z_bb_38:
    zT_192 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_192) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_198 = node.kind;
    zT_197 = zT_198 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_42;
    z_bb_41:
    zT_197 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_197) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_202 = env;
    zT_203 = node_idx;
    zT_204 = node.kind;
    zT_205 = depth;
    zT_207 = zF_FE81311F_registerContainerTy(zT_202, zT_203, zT_204, zT_205);
    return zT_207;
    z_bb_44:
    zT_208 = node.kind;
    if ((unsigned char)(zT_208 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_213 = 0;
    fah_matched = zT_213;
    zT_215 = env;
    zT_216 = node.child_0;
    zT_221 = zF_F2107C15_resolveTypeExprFull(zT_215, zT_216, (unsigned int)(depth + (unsigned int)(1)));
    base_type = zT_221;
    if ((unsigned char)(base_type == (unsigned int)(18))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_362 = node.kind;
    if ((unsigned char)(zT_362 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_75; else goto z_bb_76;
    z_bb_47:
    zT_225 = env->store;
    zT_226 = node.child_0;
    zT_229 = zF_FCDD1D35_astStoreNodeAt(zT_225, zT_226);
    base_node = zT_229;
    zT_230 = base_node.kind;
    if ((unsigned char)(zT_230 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_309 = env->typereg;
    zT_310 = zT_309->types_items;
    zT_311 = (unsigned int)base_type;
    zT_312 = zT_310[zT_311];
    base_ty = zT_312;
    zT_313 = base_ty.kind;
    if ((unsigned char)(zT_313 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_65; else goto z_bb_66;
    z_bb_49:
    zT_235 = env->store;
    zT_236 = node.child_0;
    zT_239 = zF_53458827_astStoreIdentifier(zT_235, zT_236);
    base_name_id = zT_239;
    zT_241 = 0;
    zT_242 = (unsigned int)zT_241;
    smi = zT_242;
    goto z_bb_51;
    z_bb_50:
    zT_301 = "FAH:m";
    zT_303 = 5;
    zT_302.ptr = zT_301;
    zT_302.len = zT_303;
    fam_m = zT_302;
    zT_304 = fam_m;
    zT_305 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_304, zT_305);
    return (unsigned int)(18);
    z_bb_51:
    zT_243 = env->symbol_reg;
    zT_244 = zT_243->tables_len;
    if ((unsigned char)(smi < (unsigned int)((unsigned int)zT_244))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_248 = env->symbol_reg;
    zT_250 = base_name_id;
    zT_253 = zF_A398987E_symbolRegistryQuali(zT_248, (unsigned int)((unsigned int)smi), zT_250);
    base_sym = zT_253;
    zT_254 = base_sym.has_value;
    if (zT_254) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    zT_297 = 1;
    zT_299 = smi + (unsigned int)((unsigned int)zT_297);
    smi = zT_299;
    goto z_bb_51;
    z_bb_55:
    bs = base_sym.value;
    zT_256 = bs->kind;
    if ((unsigned char)(zT_256 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    goto z_bb_54;
    z_bb_57:
    zT_261 = bs->module_id;
    mod_id = zT_261;
    zT_263 = env->symbol_reg;
    zT_264 = mod_id;
    zT_267 = env->store;
    zT_268 = node_idx;
    zT_270 = zF_8BA26B9E_astStoreNodePayload(zT_267, zT_268);
    zT_265 = zT_270;
    zT_271 = zF_A398987E_symbolRegistryQuali(zT_263, zT_264, zT_265);
    payload_sym = zT_271;
    zT_272 = payload_sym.has_value;
    if (zT_272) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    ps = payload_sym.value;
    zT_274 = env;
    zT_275 = node_idx;
    zT_278 = env->store;
    zT_279 = node_idx;
    zT_281 = zF_8BA26B9E_astStoreNodePayload(zT_278, zT_279);
    zT_276 = zT_281;
    zT_277 = ps;
    zT_282 = zF_D43B245F_typeResolverCheckMe(zT_274, zT_275, zT_276, zT_277);
    if ((unsigned char)(!zT_282)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    return (unsigned int)(18);
    z_bb_62:
    zT_285 = ps->type_id;
    if ((unsigned char)(zT_285 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_288 = 1;
    fah_matched = zT_288;
    zT_290 = "FAH:r";
    zT_292 = 5;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    fam = zT_291;
    zT_293 = fam;
    zT_294 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_293, zT_294);
    zT_296 = ps->type_id;
    return zT_296;
    z_bb_64:
    goto z_bb_60;
    z_bb_65:
    zT_318 = base_ty.module_id;
    mod_id = zT_318;
    zT_320 = env->symbol_reg;
    zT_321 = mod_id;
    zT_324 = env->store;
    zT_325 = node_idx;
    zT_327 = zF_8BA26B9E_astStoreNodePayload(zT_324, zT_325);
    zT_322 = zT_327;
    zT_328 = zF_A398987E_symbolRegistryQuali(zT_320, zT_321, zT_322);
    sym = zT_328;
    zT_329 = sym.has_value;
    if (zT_329) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    if ((unsigned char)(fah_matched == (unsigned char)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_67:
    s = sym.value;
    zT_331 = env;
    zT_332 = node_idx;
    zT_335 = env->store;
    zT_336 = node_idx;
    zT_338 = zF_8BA26B9E_astStoreNodePayload(zT_335, zT_336);
    zT_333 = zT_338;
    zT_334 = s;
    zT_339 = zF_D43B245F_typeResolverCheckMe(zT_331, zT_332, zT_333, zT_334);
    if ((unsigned char)(!zT_339)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_66;
    z_bb_69:
    return (unsigned int)(18);
    z_bb_70:
    zT_342 = s->type_id;
    if ((unsigned char)(zT_342 != (unsigned int)(0))) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_345 = 1;
    fah_matched = zT_345;
    zT_347 = "FAH:r";
    zT_349 = 5;
    zT_348.ptr = zT_347;
    zT_348.len = zT_349;
    fam = zT_348;
    zT_350 = fam;
    zT_351 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_350, zT_351);
    zT_353 = s->type_id;
    return zT_353;
    z_bb_72:
    goto z_bb_68;
    z_bb_73:
    zT_357 = "FAH:N";
    zT_359 = 5;
    zT_358.ptr = zT_357;
    zT_358.len = zT_359;
    fnm = zT_358;
    zT_360 = fnm;
    zT_361 = node_idx;
    zF_C914CB83_markerWriteInt(zT_360, zT_361);
    goto z_bb_74;
    z_bb_74:
    goto z_bb_46;
    z_bb_75:
    zT_368 = env->typereg;
    zT_369 = zT_368->xn_len;
    zT_370 = (unsigned int)zT_369;
    zT_371 = 0;
    zT_367[zT_371] = zT_370;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_367[_i];
        _i++;
    }
}
    zT_374 = 0;
    zT_375 = 0;
    zT_373[zT_375] = zT_374;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_373[_i];
        _i++;
    }
}
    zT_376 = env->store;
    zT_377 = node_idx;
    zT_379 = zF_8BA26B9E_astStoreNodePayload(zT_376, zT_377);
    if ((unsigned char)(zT_379 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_415 = node.kind;
    if ((unsigned char)(zT_415 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_83; else goto z_bb_84;
    z_bb_77:
    zT_383 = env->store;
    zT_384 = node_idx;
    zT_386 = zF_152E19CB_astStoreNodeExtraCh(zT_383, zT_384);
    esd_children_n = zT_386;
    zT_387 = (unsigned short)esd_children_n;
    zT_388 = 0;
    esd_count_box[zT_388] = zT_387;
    zT_390 = 0;
    zT_391 = (unsigned int)zT_390;
    esd_i = zT_391;
    goto z_bb_79;
    z_bb_78:
    zT_406 = env->typereg;
    zT_410 = 0;
    zT_407 = esd_start_box[zT_410];
    zT_412 = 0;
    zT_408 = esd_count_box[zT_412];
    zT_414 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_406, zT_407, zT_408);
    return zT_414;
    z_bb_79:
    if ((unsigned char)(esd_i < (unsigned int)((unsigned int)esd_children_n))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_394 = env->typereg;
    zT_397 = env->store;
    zT_398 = node_idx;
    zT_402 = zF_B10B1BC1_astStoreNodeExtraCh(zT_397, zT_398, (unsigned int)((unsigned int)esd_i));
    zT_395 = zT_402;
    zF_A648B1CB_xnAppend(zT_394, zT_395);
    goto z_bb_82;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    zT_403 = 1;
    zT_405 = esd_i + (unsigned int)((unsigned int)zT_403);
    esd_i = zT_405;
    goto z_bb_79;
    z_bb_83:
    zT_420 = env;
    zT_421 = node.child_1;
    zT_426 = zF_F2107C15_resolveTypeExprFull(zT_420, zT_421, (unsigned int)(depth + (unsigned int)(1)));
    eu_payload_type = zT_426;
    if ((unsigned char)(eu_payload_type == (unsigned int)(18))) goto z_bb_85; else goto z_bb_86;
    z_bb_84:
    zT_458 = node.kind;
    if ((unsigned char)(zT_458 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_92; else goto z_bb_93;
    z_bb_85:
    return (unsigned int)(18);
    z_bb_86:
    zT_432 = 0;
    zT_433 = 0;
    zT_431[zT_433] = zT_432;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_431[_i];
        _i++;
    }
}
    zT_434 = node.child_0;
    zT_435 = 0;
    if ((unsigned char)(zT_434 != (unsigned int)zT_435)) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    zT_438 = env;
    zT_439 = node.child_0;
    zT_444 = zF_F2107C15_resolveTypeExprFull(zT_438, zT_439, (unsigned int)(depth + (unsigned int)(1)));
    eu_resolved_es = zT_444;
    if ((unsigned char)(eu_resolved_es == (unsigned int)(18))) goto z_bb_90; else goto z_bb_91;
    z_bb_88:
    zT_451 = env->typereg;
    zT_452 = eu_payload_type;
    zT_455 = 0;
    zT_453 = eu_es_box[zT_455];
    zT_457 = zF_16D1A6EE_typeRegistryGetOrCr(zT_451, zT_452, zT_453);
    return zT_457;
    z_bb_89:
    zT_449 = 0;
    zT_450 = 0;
    eu_es_box[zT_450] = zT_449;
    goto z_bb_88;
    z_bb_90:
    return (unsigned int)(18);
    z_bb_91:
    zT_448 = 0;
    eu_es_box[zT_448] = eu_resolved_es;
    goto z_bb_88;
    z_bb_92:
    zT_464 = 0;
    zT_465 = 0;
    zT_463[zT_465] = zT_464;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_463[_i];
        _i++;
    }
}
    zT_466 = 1;
    zT_467 = 0;
    fnt_ret_box[zT_467] = zT_466;
    zT_468 = node.child_0;
    zT_469 = 0;
    if ((unsigned char)(zT_468 != (unsigned int)zT_469)) goto z_bb_94; else goto z_bb_95;
    z_bb_93:
    zT_695 = node.child_0;
    zT_696 = 0;
    if ((unsigned char)(zT_695 != (unsigned int)zT_696)) goto z_bb_147; else goto z_bb_148;
    z_bb_94:
    zT_471 = env;
    zT_472 = node.child_0;
    zT_477 = zF_F2107C15_resolveTypeExprFull(zT_471, zT_472, (unsigned int)(depth + (unsigned int)(1)));
    zT_478 = 0;
    fnt_ret_box[zT_478] = zT_477;
    zT_480 = "OPTVOID:fntR";
    zT_482 = 12;
    zT_481.ptr = zT_480;
    zT_481.len = zT_482;
    opm2_m = zT_481;
    zT_483 = opm2_m;
    zT_485 = 0;
    zT_484 = fnt_ret_box[zT_485];
    zF_C914CB83_markerWriteInt(zT_483, zT_484);
    zT_487 = 0;
    zT_488 = fnt_ret_box[zT_487];
    if ((unsigned char)(zT_488 == (unsigned int)(18))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_493[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_493[_i];
        _i++;
    }
}
    zT_495 = 0;
    fnt_pc = zT_495;
    zT_496 = env->store;
    zT_497 = node_idx;
    zT_499 = zF_8BA26B9E_astStoreNodePayload(zT_496, zT_497);
    if ((unsigned char)(zT_499 != (unsigned int)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_96:
    return (unsigned int)(18);
    z_bb_97:
    goto z_bb_95;
    z_bb_98:
    zT_503 = env->store;
    zT_504 = node_idx;
    zT_506 = zF_152E19CB_astStoreNodeExtraCh(zT_503, zT_504);
    fnt_extra_n = zT_506;
    zT_508 = 0;
    fnt_i = zT_508;
    goto z_bb_100;
    z_bb_99:
    zT_535 = 0;
    fnt_conv = zT_535;
    zT_536 = node.flags;
    if ((unsigned char)((unsigned char)(zT_536 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_100:
    if ((unsigned char)(fnt_i < (unsigned int)((unsigned int)fnt_extra_n))) goto z_bb_104; else goto z_bb_105;
    z_bb_101:
    zT_515 = env;
    zT_518 = env->store;
    zT_519 = node_idx;
    zT_523 = zF_B10B1BC1_astStoreNodeExtraCh(zT_518, zT_519, (unsigned int)((unsigned int)fnt_i));
    zT_516 = zT_523;
    zT_526 = zF_F2107C15_resolveTypeExprFull(zT_515, zT_516, (unsigned int)(depth + (unsigned int)(1)));
    fnt_pt = zT_526;
    if ((unsigned char)(fnt_pt == (unsigned int)(18))) goto z_bb_107; else goto z_bb_108;
    z_bb_102:
    goto z_bb_99;
    z_bb_103:
    zT_533 = fnt_i + (unsigned int)(1);
    fnt_i = zT_533;
    goto z_bb_100;
    z_bb_104:
    zT_511 = fnt_pc < (unsigned int)(16);
    goto z_bb_106;
    z_bb_105:
    zT_511 = 0;
    goto z_bb_106;
    z_bb_106:
    if (zT_511) goto z_bb_101; else goto z_bb_102;
    z_bb_107:
    return (unsigned int)(18);
    z_bb_108:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_531 = fnt_pc + (unsigned int)(1);
    fnt_pc = zT_531;
    goto z_bb_103;
    z_bb_109:
    zT_541 = 1;
    fnt_conv = zT_541;
    goto z_bb_110;
    z_bb_110:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_543[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_543[_i];
        _i++;
    }
}
    zT_545 = 0;
    fnt_np = zT_545;
    zT_547 = "fnt_";
    zT_549 = 4;
    zT_548.ptr = zT_547;
    zT_548.len = zT_549;
    fnt_pre = zT_548;
    if ((unsigned char)(fnt_conv == (unsigned char)(1))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_552 = "fnts_";
    zT_554 = 5;
    zT_553.ptr = zT_552;
    zT_553.len = zT_554;
    fnt_pre = zT_553;
    goto z_bb_112;
    z_bb_112:
    zT_556 = 0;
    fnt_pri = zT_556;
    goto z_bb_113;
    z_bb_113:
    zT_558 = fnt_pre.len;
    if ((unsigned char)(fnt_pri < zT_558)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_563 = fnt_pre.ptr;
    zT_564 = zT_563[fnt_pri];
    fnt_nb[fnt_np] = zT_564;
    zT_566 = fnt_np + (unsigned int)(1);
    fnt_np = zT_566;
    goto z_bb_116;
    z_bb_115:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_570[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_570[_i];
        _i++;
    }
}
    zT_574 = 0;
    zT_572 = fnt_ret_box[zT_574];
    zT_578 = 0;
    zT_579 = (unsigned char*)((unsigned char*)fnt_rb) + zT_578;
    zT_580 = (unsigned int)(12) - zT_578;
    zT_581.ptr = zT_579;
    zT_581.len = zT_580;
    zT_573 = zT_581;
    zT_582 = zF_A7504564_itoa(zT_572, zT_573);
    fnt_rl = zT_582;
    zT_586 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_rl);
    fnt_rs = zT_586;
    goto z_bb_120;
    z_bb_116:
    zT_568 = fnt_pri + (unsigned int)(1);
    fnt_pri = zT_568;
    goto z_bb_113;
    z_bb_117:
    zT_560 = fnt_np < (unsigned int)(95);
    goto z_bb_119;
    z_bb_118:
    zT_560 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_560) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    if ((unsigned char)(fnt_rs < (unsigned int)(11))) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_592 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_592;
    zT_594 = fnt_np + (unsigned int)(1);
    fnt_np = zT_594;
    goto z_bb_123;
    z_bb_122:
    zT_598 = 0;
    fnt_k = zT_598;
    goto z_bb_127;
    z_bb_123:
    zT_596 = fnt_rs + (unsigned int)(1);
    fnt_rs = zT_596;
    goto z_bb_120;
    z_bb_124:
    zT_589 = fnt_np < (unsigned int)(95);
    goto z_bb_126;
    z_bb_125:
    zT_589 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_589) goto z_bb_121; else goto z_bb_122;
    z_bb_127:
    if ((unsigned char)(fnt_k < fnt_pc)) goto z_bb_131; else goto z_bb_132;
    z_bb_128:
    if ((unsigned char)(fnt_np < (unsigned int)(95))) goto z_bb_134; else goto z_bb_135;
    z_bb_129:
    zT_638 = env->interner;
    zT_643 = 0;
    zT_644 = (unsigned char*)((unsigned char*)fnt_nb) + zT_643;
    zT_645 = fnt_np - zT_643;
    zT_646.ptr = zT_644;
    zT_646.len = zT_645;
    zT_639 = zT_646;
    zT_647 = zF_50C274AF_stringInternerInter(zT_638, zT_639);
    fnt_name_id = zT_647;
    zT_649 = env->typereg;
    zT_650 = zT_649->xt_len;
    zT_651 = (unsigned int)zT_650;
    fnt_pstart = zT_651;
    zT_653 = 0;
    fnt_a = zT_653;
    goto z_bb_143;
    z_bb_130:
    zT_636 = fnt_k + (unsigned int)(1);
    fnt_k = zT_636;
    goto z_bb_127;
    z_bb_131:
    zT_600 = fnt_np < (unsigned int)(95);
    goto z_bb_133;
    z_bb_132:
    zT_600 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_600) goto z_bb_128; else goto z_bb_129;
    z_bb_134:
    zT_605 = 95;
    fnt_nb[fnt_np] = zT_605;
    zT_607 = fnt_np + (unsigned int)(1);
    fnt_np = zT_607;
    goto z_bb_135;
    z_bb_135:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_609[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_609[_i];
        _i++;
    }
}
    zT_611 = fnt_ptypes[fnt_k];
    zT_616 = 0;
    zT_617 = (unsigned char*)((unsigned char*)fnt_pb) + zT_616;
    zT_618 = (unsigned int)(12) - zT_616;
    zT_619.ptr = zT_617;
    zT_619.len = zT_618;
    zT_612 = zT_619;
    zT_620 = zF_A7504564_itoa(zT_611, zT_612);
    fnt_pl = zT_620;
    zT_624 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_pl);
    fnt_ps = zT_624;
    goto z_bb_136;
    z_bb_136:
    if ((unsigned char)(fnt_ps < (unsigned int)(11))) goto z_bb_140; else goto z_bb_141;
    z_bb_137:
    zT_630 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_630;
    zT_632 = fnt_np + (unsigned int)(1);
    fnt_np = zT_632;
    goto z_bb_139;
    z_bb_138:
    goto z_bb_130;
    z_bb_139:
    zT_634 = fnt_ps + (unsigned int)(1);
    fnt_ps = zT_634;
    goto z_bb_136;
    z_bb_140:
    zT_627 = fnt_np < (unsigned int)(95);
    goto z_bb_142;
    z_bb_141:
    zT_627 = 0;
    goto z_bb_142;
    z_bb_142:
    if (zT_627) goto z_bb_137; else goto z_bb_138;
    z_bb_143:
    if ((unsigned char)(fnt_a < fnt_pc)) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_655 = env->typereg;
    zT_656 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_655, zT_656);
    goto z_bb_146;
    z_bb_145:
    zT_662 = env->typereg;
    zT_663 = fnt_name_id;
    zT_677 = 0;
    zT_669 = fnt_ret_box[zT_677];
    zT_670 = fnt_conv;
    zT_679 = zF_474336D7_typeRegistryGetOrCr(zT_662, zT_663, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), (unsigned short)((unsigned short)fnt_pc), zT_669, zT_670);
    fnt_tid = zT_679;
    zT_681 = "OPTVOID:fntT";
    zT_683 = 12;
    zT_682.ptr = zT_681;
    zT_682.len = zT_683;
    opm3_m = zT_682;
    zT_684 = opm3_m;
    zT_685 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_684, zT_685);
    zT_686 = env->typereg;
    zT_687 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_686, zT_687);
    zT_689 = env->typereg;
    zT_690 = fnt_tid;
    zT_694 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_689, zT_690, (unsigned char)(0));
    return zT_694;
    z_bb_146:
    zT_660 = fnt_a + (unsigned int)(1);
    fnt_a = zT_660;
    goto z_bb_143;
    z_bb_147:
    zT_699 = env;
    zT_700 = node.child_0;
    zT_705 = zF_F2107C15_resolveTypeExprFull(zT_699, zT_700, (unsigned int)(depth + (unsigned int)(1)));
    child_type = zT_705;
    if ((unsigned char)(child_type == (unsigned int)(18))) goto z_bb_149; else goto z_bb_150;
    z_bb_148:
    zT_1191 = "UND:n";
    zT_1193 = 5;
    zT_1192.ptr = zT_1191;
    zT_1192.len = zT_1193;
    und_nm2 = zT_1192;
    zT_1194 = und_nm2;
    zT_1195 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1194, zT_1195);
    zT_1197 = "UND:k";
    zT_1199 = 5;
    zT_1198.ptr = zT_1197;
    zT_1198.len = zT_1199;
    und_km = zT_1198;
    zT_1200 = und_km;
    zT_1202 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1200, (unsigned int)((unsigned int)zT_1202));
    return (unsigned int)(18);
    z_bb_149:
    return (unsigned int)(18);
    z_bb_150:
    zT_709 = node.kind;
    if ((unsigned char)(zT_709 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_152; else goto z_bb_151;
    z_bb_151:
    zT_714 = node.kind;
    zT_713 = zT_714 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_153;
    z_bb_152:
    zT_713 = 1;
    goto z_bb_153;
    z_bb_153:
    if (zT_713) goto z_bb_154; else goto z_bb_155;
    z_bb_154:
    zT_719 = "PTR:i";
    zT_721 = 5;
    zT_720.ptr = zT_719;
    zT_720.len = zT_721;
    ptm = zT_720;
    zT_722 = ptm;
    zF_48AC7B3A_markerWrite(zT_722);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_724[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptib[_i] = zT_724[_i];
        _i++;
    }
}
    zT_726 = node_idx;
    zT_730 = 0;
    zT_731 = (unsigned char*)((unsigned char*)ptib) + zT_730;
    zT_732 = (unsigned int)(10) - zT_730;
    zT_733.ptr = zT_731;
    zT_733.len = zT_732;
    zT_727 = zT_733;
    zT_734 = zF_A7504564_itoa(zT_726, zT_727);
    ptil = zT_734;
    zT_738 = (unsigned int)(9) - (unsigned int)((unsigned int)ptil);
    ptis = zT_738;
    zT_743 = (unsigned char*)((unsigned char*)ptib) + ptis;
    zT_744 = (unsigned int)(9) - ptis;
    zT_745.ptr = zT_743;
    zT_745.len = zT_744;
    zT_739 = zT_745;
    zF_48AC7B3A_markerWrite(zT_739);
    zT_747 = "k";
    zT_749 = 1;
    zT_748.ptr = zT_747;
    zT_748.len = zT_749;
    ptkm = zT_748;
    zT_750 = ptkm;
    zF_48AC7B3A_markerWrite(zT_750);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_752[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptkb[_i] = zT_752[_i];
        _i++;
    }
}
    zT_756 = node.kind;
    zT_760 = 0;
    zT_761 = (unsigned char*)((unsigned char*)ptkb) + zT_760;
    zT_762 = (unsigned int)(10) - zT_760;
    zT_763.ptr = zT_761;
    zT_763.len = zT_762;
    zT_755 = zT_763;
    zT_764 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_756), zT_755);
    ptkl = zT_764;
    zT_768 = (unsigned int)(9) - (unsigned int)((unsigned int)ptkl);
    ptks = zT_768;
    zT_773 = (unsigned char*)((unsigned char*)ptkb) + ptks;
    zT_774 = (unsigned int)(9) - ptks;
    zT_775.ptr = zT_773;
    zT_775.len = zT_774;
    zT_769 = zT_775;
    zF_48AC7B3A_markerWrite(zT_769);
    zT_777 = "c";
    zT_779 = 1;
    zT_778.ptr = zT_777;
    zT_778.len = zT_779;
    ptcm = zT_778;
    zT_780 = ptcm;
    zF_48AC7B3A_markerWrite(zT_780);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_782[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptcb[_i] = zT_782[_i];
        _i++;
    }
}
    zT_784 = child_type;
    zT_788 = 0;
    zT_789 = (unsigned char*)((unsigned char*)ptcb) + zT_788;
    zT_790 = (unsigned int)(10) - zT_788;
    zT_791.ptr = zT_789;
    zT_791.len = zT_790;
    zT_785 = zT_791;
    zT_792 = zF_A7504564_itoa(zT_784, zT_785);
    ptcl = zT_792;
    zT_796 = (unsigned int)(9) - (unsigned int)((unsigned int)ptcl);
    ptcs = zT_796;
    zT_801 = (unsigned char*)((unsigned char*)ptcb) + ptcs;
    zT_802 = (unsigned int)(9) - ptcs;
    zT_803.ptr = zT_801;
    zT_803.len = zT_802;
    zT_797 = zT_803;
    zF_48AC7B3A_markerWrite(zT_797);
    zT_805 = node.flags;
    zT_809 = (unsigned char)(zT_805 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_809;
    zT_811 = node.flags;
    zT_815 = (unsigned char)(zT_811 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_815;
    zT_816 = node.kind;
    if ((unsigned char)(zT_816 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_156; else goto z_bb_158;
    z_bb_155:
    zT_900 = node.kind;
    if ((unsigned char)(zT_900 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_159; else goto z_bb_160;
    z_bb_156:
    zT_821 = env->typereg;
    zT_822 = child_type;
    zT_823 = is_const;
    zT_824 = is_volatile;
    zT_826 = zF_0C0306D6_typeRegistryGetOrCr(zT_821, zT_822, zT_823, zT_824);
    ptr_tid = zT_826;
    zT_828 = "P";
    zT_830 = 1;
    zT_829.ptr = zT_828;
    zT_829.len = zT_830;
    ppm = zT_829;
    zT_831 = ppm;
    zF_48AC7B3A_markerWrite(zT_831);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_833[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb[_i] = zT_833[_i];
        _i++;
    }
}
    zT_835 = ptr_tid;
    zT_839 = 0;
    zT_840 = (unsigned char*)((unsigned char*)ppb) + zT_839;
    zT_841 = (unsigned int)(10) - zT_839;
    zT_842.ptr = zT_840;
    zT_842.len = zT_841;
    zT_836 = zT_842;
    zT_843 = zF_A7504564_itoa(zT_835, zT_836);
    ppl = zT_843;
    zT_847 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl);
    pps = zT_847;
    zT_852 = (unsigned char*)((unsigned char*)ppb) + pps;
    zT_853 = (unsigned int)(9) - pps;
    zT_854.ptr = zT_852;
    zT_854.len = zT_853;
    zT_848 = zT_854;
    zF_48AC7B3A_markerWrite(zT_848);
    zT_856 = "\n";
    zT_858 = 1;
    zT_857.ptr = zT_856;
    zT_857.len = zT_858;
    pnl = zT_857;
    zT_859 = pnl;
    zF_48AC7B3A_markerWrite(zT_859);
    return ptr_tid;
    goto z_bb_155;
    z_bb_158:
    zT_861 = env->typereg;
    zT_862 = child_type;
    zT_863 = is_const;
    zT_864 = is_volatile;
    zT_866 = zF_827207A1_typeRegistryGetOrCr(zT_861, zT_862, zT_863, zT_864);
    ptr_tid2 = zT_866;
    zT_868 = "M";
    zT_870 = 1;
    zT_869.ptr = zT_868;
    zT_869.len = zT_870;
    ppm2 = zT_869;
    zT_871 = ppm2;
    zF_48AC7B3A_markerWrite(zT_871);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_873[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb2[_i] = zT_873[_i];
        _i++;
    }
}
    zT_875 = ptr_tid2;
    zT_879 = 0;
    zT_880 = (unsigned char*)((unsigned char*)ppb2) + zT_879;
    zT_881 = (unsigned int)(10) - zT_879;
    zT_882.ptr = zT_880;
    zT_882.len = zT_881;
    zT_876 = zT_882;
    zT_883 = zF_A7504564_itoa(zT_875, zT_876);
    ppl2 = zT_883;
    zT_887 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl2);
    pps2 = zT_887;
    zT_892 = (unsigned char*)((unsigned char*)ppb2) + pps2;
    zT_893 = (unsigned int)(9) - pps2;
    zT_894.ptr = zT_892;
    zT_894.len = zT_893;
    zT_888 = zT_894;
    zF_48AC7B3A_markerWrite(zT_888);
    zT_896 = "\n";
    zT_898 = 1;
    zT_897.ptr = zT_896;
    zT_897.len = zT_898;
    pnl2 = zT_897;
    zT_899 = pnl2;
    zF_48AC7B3A_markerWrite(zT_899);
    return ptr_tid2;
    z_bb_159:
    zT_905 = node.flags;
    zT_909 = (unsigned char)(zT_905 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_909;
    zT_911 = env->typereg;
    zT_912 = child_type;
    zT_913 = is_const;
    zT_915 = zF_8FC81A87_typeRegistryGetOrCr(zT_911, zT_912, zT_913);
    sl_tid = zT_915;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_917[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_e[_i] = zT_917[_i];
        _i++;
    }
}
    zT_919 = child_type;
    zT_923 = 0;
    zT_924 = (unsigned char*)((unsigned char*)sl_e) + zT_923;
    zT_925 = (unsigned int)(20) - zT_923;
    zT_926.ptr = zT_924;
    zT_926.len = zT_925;
    zT_920 = zT_926;
    zT_927 = zF_A7504564_itoa(zT_919, zT_920);
    sl_el = zT_927;
    zT_931 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_el);
    sl_es = zT_931;
    zT_933 = "SL:e";
    zT_935 = 4;
    zT_934.ptr = zT_933;
    zT_934.len = zT_935;
    sm = zT_934;
    zT_936 = sm;
    zF_48AC7B3A_markerWrite(zT_936);
    zT_941 = (unsigned char*)((unsigned char*)sl_e) + sl_es;
    zT_942 = (unsigned int)(19) - sl_es;
    zT_943.ptr = zT_941;
    zT_943.len = zT_942;
    zT_937 = zT_943;
    zF_48AC7B3A_markerWrite(zT_937);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_945[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_r[_i] = zT_945[_i];
        _i++;
    }
}
    zT_947 = sl_tid;
    zT_951 = 0;
    zT_952 = (unsigned char*)((unsigned char*)sl_r) + zT_951;
    zT_953 = (unsigned int)(20) - zT_951;
    zT_954.ptr = zT_952;
    zT_954.len = zT_953;
    zT_948 = zT_954;
    zT_955 = zF_A7504564_itoa(zT_947, zT_948);
    sl_rl = zT_955;
    zT_959 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_rl);
    sl_rs = zT_959;
    zT_961 = "s";
    zT_963 = 1;
    zT_962.ptr = zT_961;
    zT_962.len = zT_963;
    s2 = zT_962;
    zT_964 = s2;
    zF_48AC7B3A_markerWrite(zT_964);
    zT_969 = (unsigned char*)((unsigned char*)sl_r) + sl_rs;
    zT_970 = (unsigned int)(19) - sl_rs;
    zT_971.ptr = zT_969;
    zT_971.len = zT_970;
    zT_965 = zT_971;
    zF_48AC7B3A_markerWrite(zT_965);
    zT_973 = "\n";
    zT_975 = 1;
    zT_974.ptr = zT_973;
    zT_974.len = zT_975;
    s3 = zT_974;
    zT_976 = s3;
    zF_48AC7B3A_markerWrite(zT_976);
    return sl_tid;
    z_bb_160:
    zT_977 = node.kind;
    if ((unsigned char)(zT_977 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_982 = "OPTVOID:opt";
    zT_984 = 11;
    zT_983.ptr = zT_982;
    zT_983.len = zT_984;
    optvd_m = zT_983;
    zT_985 = optvd_m;
    zT_986 = child_type;
    zF_C914CB83_markerWriteInt(zT_985, zT_986);
    zT_988 = env->typereg;
    zT_989 = child_type;
    zT_991 = zF_74A7234F_typeRegistryGetOrCr(zT_988, zT_989);
    optvd_tid = zT_991;
    zT_993 = "OPTVOID:optR";
    zT_995 = 12;
    zT_994.ptr = zT_993;
    zT_994.len = zT_995;
    optvd_rm = zT_994;
    zT_996 = optvd_rm;
    zT_997 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_996, zT_997);
    return optvd_tid;
    z_bb_162:
    zT_998 = node.kind;
    if ((unsigned char)(zT_998 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    zT_1003 = "T0";
    zT_1005 = 2;
    zT_1004.ptr = zT_1003;
    zT_1004.len = zT_1005;
    t0m = zT_1004;
    zT_1006 = t0m;
    zF_48AC7B3A_markerWrite(zT_1006);
    zT_1008 = "T1e";
    zT_1010 = 3;
    zT_1009.ptr = zT_1008;
    zT_1009.len = zT_1010;
    t1m = zT_1009;
    zT_1011 = t1m;
    zF_48AC7B3A_markerWrite(zT_1011);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1013[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t1b[_i] = zT_1013[_i];
        _i++;
    }
}
    zT_1015 = child_type;
    zT_1019 = 0;
    zT_1020 = (unsigned char*)((unsigned char*)t1b) + zT_1019;
    zT_1021 = (unsigned int)(20) - zT_1019;
    zT_1022.ptr = zT_1020;
    zT_1022.len = zT_1021;
    zT_1016 = zT_1022;
    zT_1023 = zF_A7504564_itoa(zT_1015, zT_1016);
    t1l = zT_1023;
    zT_1027 = (unsigned int)(19) - (unsigned int)((unsigned int)t1l);
    t1s = zT_1027;
    zT_1032 = (unsigned char*)((unsigned char*)t1b) + t1s;
    zT_1033 = (unsigned int)(19) - t1s;
    zT_1034.ptr = zT_1032;
    zT_1034.len = zT_1033;
    zT_1028 = zT_1034;
    zF_48AC7B3A_markerWrite(zT_1028);
    zT_1035 = node.child_1;
    zT_1036 = 0;
    if ((unsigned char)(zT_1035 != (unsigned int)zT_1036)) goto z_bb_165; else goto z_bb_166;
    z_bb_164:
    goto z_bb_148;
    z_bb_165:
    zT_1039 = env->store;
    zT_1040 = node.child_1;
    zT_1043 = zF_FCDD1D35_astStoreNodeAt(zT_1039, zT_1040);
    sz_node = zT_1043;
    zT_1045 = 0;
    arr_len = zT_1045;
    zT_1047 = 0;
    arr_resolved = zT_1047;
    zT_1049 = env;
    zT_1050 = node.child_1;
    zT_1054 = zF_6D0DD27D_evalConstU32Full(zT_1049, zT_1050, (unsigned int)(0));
    alf = zT_1054;
    if ((unsigned char)(alf != (unsigned int)(4294967295u))) goto z_bb_167; else goto z_bb_168;
    z_bb_166:
    return (unsigned int)(18);
    z_bb_167:
    arr_len = alf;
    zT_1057 = 1;
    arr_resolved = zT_1057;
    goto z_bb_168;
    z_bb_168:
    zT_1059 = "T2L";
    zT_1061 = 3;
    zT_1060.ptr = zT_1059;
    zT_1060.len = zT_1061;
    t2m = zT_1060;
    zT_1062 = t2m;
    zF_48AC7B3A_markerWrite(zT_1062);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1064[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t2b[_i] = zT_1064[_i];
        _i++;
    }
}
    zT_1066 = arr_len;
    zT_1070 = 0;
    zT_1071 = (unsigned char*)((unsigned char*)t2b) + zT_1070;
    zT_1072 = (unsigned int)(20) - zT_1070;
    zT_1073.ptr = zT_1071;
    zT_1073.len = zT_1072;
    zT_1067 = zT_1073;
    zT_1074 = zF_A7504564_itoa(zT_1066, zT_1067);
    t2l = zT_1074;
    zT_1078 = (unsigned int)(19) - (unsigned int)((unsigned int)t2l);
    t2s = zT_1078;
    zT_1083 = (unsigned char*)((unsigned char*)t2b) + t2s;
    zT_1084 = (unsigned int)(19) - t2s;
    zT_1085.ptr = zT_1083;
    zT_1085.len = zT_1084;
    zT_1079 = zT_1085;
    zF_48AC7B3A_markerWrite(zT_1079);
    if (arr_resolved) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_1087 = env->typereg;
    zT_1088 = child_type;
    zT_1089 = arr_len;
    zT_1091 = zF_BA693C74_typeRegistryGetOrCr(zT_1087, zT_1088, zT_1089);
    at = zT_1091;
    zT_1093 = "T3a";
    zT_1095 = 3;
    zT_1094.ptr = zT_1093;
    zT_1094.len = zT_1095;
    t3m = zT_1094;
    zT_1096 = t3m;
    zF_48AC7B3A_markerWrite(zT_1096);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1098[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t3b[_i] = zT_1098[_i];
        _i++;
    }
}
    zT_1100 = at;
    zT_1104 = 0;
    zT_1105 = (unsigned char*)((unsigned char*)t3b) + zT_1104;
    zT_1106 = (unsigned int)(20) - zT_1104;
    zT_1107.ptr = zT_1105;
    zT_1107.len = zT_1106;
    zT_1101 = zT_1107;
    zT_1108 = zF_A7504564_itoa(zT_1100, zT_1101);
    t3l = zT_1108;
    zT_1112 = (unsigned int)(19) - (unsigned int)((unsigned int)t3l);
    t3s = zT_1112;
    zT_1117 = (unsigned char*)((unsigned char*)t3b) + t3s;
    zT_1118 = (unsigned int)(19) - t3s;
    zT_1119.ptr = zT_1117;
    zT_1119.len = zT_1118;
    zT_1113 = zT_1119;
    zF_48AC7B3A_markerWrite(zT_1113);
    if ((unsigned char)(at != (unsigned int)(18))) goto z_bb_171; else goto z_bb_173;
    z_bb_170:
    zT_1133 = 0;
    sz_is_inferred = zT_1133;
    zT_1134 = sz_node.kind;
    if ((unsigned char)(zT_1134 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_174; else goto z_bb_175;
    z_bb_171:
    zT_1123 = "A";
    zT_1125 = 1;
    zT_1124.ptr = zT_1123;
    zT_1124.len = zT_1125;
    am = zT_1124;
    zT_1126 = am;
    zF_48AC7B3A_markerWrite(zT_1126);
    goto z_bb_172;
    z_bb_172:
    return at;
    z_bb_173:
    zT_1128 = "a";
    zT_1130 = 1;
    zT_1129.ptr = zT_1128;
    zT_1129.len = zT_1130;
    am = zT_1129;
    zT_1131 = am;
    zF_48AC7B3A_markerWrite(zT_1131);
    goto z_bb_172;
    z_bb_174:
    zT_1139 = env->store;
    zT_1140 = node.child_1;
    zT_1143 = zF_53458827_astStoreIdentifier(zT_1139, zT_1140);
    sz_name = zT_1143;
    zT_1145 = env->interner;
    zT_1146 = sz_name;
    zT_1148 = zF_9134020D_stringInternerGet(zT_1145, zT_1146);
    sz_text = zT_1148;
    zT_1150 = sz_text.len;
    if ((unsigned char)(zT_1150 == (unsigned int)(1))) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    if ((unsigned char)(!sz_is_inferred)) goto z_bb_181; else goto z_bb_182;
    z_bb_176:
    zT_1154 = sz_text.ptr;
    zT_1155 = 0;
    zT_1156 = zT_1154[zT_1155];
    zT_1153 = zT_1156 == (unsigned char)(95);
    goto z_bb_178;
    z_bb_177:
    zT_1153 = 0;
    goto z_bb_178;
    z_bb_178:
    if (zT_1153) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_1159 = 1;
    sz_is_inferred = zT_1159;
    goto z_bb_180;
    z_bb_180:
    goto z_bb_175;
    z_bb_181:
    zT_1161 = env->diag;
    zT_1162 = zT_1161.has_value;
    if (zT_1162) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    goto z_bb_166;
    z_bb_183:
    dg = zT_1161.value;
    zT_1164 = dg;
    zT_1165 = node_idx;
    zT_1166 = zF_4DD9DB2D_diagnosticCollector(zT_1164, zT_1165);
    if (zT_1166) goto z_bb_185; else goto z_bb_186;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_1168 = "array size is not a constant expression";
    zT_1170 = 39;
    zT_1169.ptr = zT_1168;
    zT_1169.len = zT_1170;
    asn_msg = zT_1169;
    zT_1171 = dg;
    zT_1174 = env->source_file_id;
    zT_1175 = sz_node.span_start;
    zT_1184 = sz_node.span_start;
    zT_1185 = sz_node.span_len;
    zT_1177 = asn_msg;
    zT_1188 = zF_C82559AC_diagnosticCollector(zT_1171, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3050_ARRAY_SIZE_NOT_CONSTANT)), zT_1174, zT_1175, (unsigned int)(zT_1184 + (unsigned int)((unsigned int)zT_1185)), zT_1177);
    (void)zT_1188;
    goto z_bb_186;
    z_bb_186:
    goto z_bb_184;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_406493CE_StructPayload* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_406493CE_StructPayload zT_53;
    unsigned short zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_64 = 0;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    unsigned char zT_74;
    unsigned int zT_75;
    int zT_76;
    zT_ABC1EBBE_TypeResolveEnv* zT_79;
    unsigned int zT_80;
    unsigned int zT_84 = 0;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_4028D896_Arr_unsigned_char_2 zT_91;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    unsigned int zT_98 = 0;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_4028D896_Arr_unsigned_char_2 zT_123;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    int zT_129;
    unsigned char* zT_130;
    unsigned int zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133 = 0;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned char* zT_142;
    unsigned int zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    zT_338B7C76_TypeRegistry* zT_147;
    zT_2DF01B61_FieldEntry* zT_148;
    unsigned int zT_149;
    zT_2DF01B61_FieldEntry* zT_152;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_159;
    unsigned char* zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    int zT_169;
    unsigned int zT_171;
    zT_33EF6BFB_TypeKind zT_172;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_54FF90FA_TaggedUnionPayload* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_54FF90FA_TaggedUnionPayload zT_181;
    unsigned char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_188;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned short zT_196;
    unsigned short zT_198;
    zT_6B0A7D14_AstStore* zT_202;
    unsigned int zT_203;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_206;
    unsigned int zT_211 = 0;
    zT_22A7C88B_AstNode zT_212 = {0};
    zT_8143F551_AstKind zT_213;
    unsigned char zT_217;
    unsigned int zT_218;
    int zT_219;
    zT_ABC1EBBE_TypeResolveEnv* zT_222;
    unsigned int zT_223;
    unsigned int zT_227 = 0;
    unsigned char* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    zT_4028D896_Arr_unsigned_char_2 zT_247;
    unsigned int zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    zT_6B0A7D14_AstStore* zT_251;
    unsigned int zT_252;
    zT_6B0A7D14_AstStore* zT_254;
    unsigned int zT_255;
    unsigned int zT_260 = 0;
    unsigned int zT_261 = 0;
    int zT_264;
    unsigned char* zT_265;
    unsigned int zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268 = 0;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned char* zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    zT_4028D896_Arr_unsigned_char_2 zT_286;
    unsigned int zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    int zT_292;
    unsigned char* zT_293;
    unsigned int zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296 = 0;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned char* zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned char* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned int zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zT_338B7C76_TypeRegistry* zT_315;
    zT_2DF01B61_FieldEntry* zT_316;
    unsigned int zT_317;
    zT_2DF01B61_FieldEntry* zT_320;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_327;
    unsigned char* zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336;
    unsigned char* zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    int zT_342;
    unsigned int zT_344;
    zT_33EF6BFB_TypeKind zT_345;
    unsigned char zT_349;
    zT_33EF6BFB_TypeKind zT_350;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_AF9231A2_UnionPayload* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    zT_AF9231A2_UnionPayload zT_359;
    unsigned short zT_360;
    zT_6B0A7D14_AstStore* zT_364;
    unsigned int zT_365;
    zT_6B0A7D14_AstStore* zT_367;
    unsigned int zT_368;
    unsigned int zT_373 = 0;
    zT_22A7C88B_AstNode zT_374 = {0};
    zT_8143F551_AstKind zT_375;
    unsigned char zT_379;
    unsigned int zT_380;
    int zT_381;
    zT_ABC1EBBE_TypeResolveEnv* zT_384;
    unsigned int zT_385;
    unsigned int zT_389 = 0;
    zT_338B7C76_TypeRegistry* zT_392;
    zT_2DF01B61_FieldEntry* zT_393;
    unsigned int zT_394;
    zT_2DF01B61_FieldEntry* zT_397;
    int zT_398;
    unsigned int zT_400;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    unsigned int fchild;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_4028D896_Arr_unsigned_char_2 b2_pb;
    unsigned int b2_pl;
    unsigned int b2_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_4028D896_Arr_unsigned_char_2 b2_tb;
    unsigned int b2_tl;
    unsigned int b2_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_21 = env->store;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_24)));
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_36 = env->store;
    zT_37 = decl.child_1;
    (void)zF_152E19CB_astStoreNodeExtraCh(zT_36, zT_37);
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    zT_44 = sty.kind;
    if ((unsigned char)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_49 = env->typereg;
    zT_50 = zT_49->st_items;
    zT_51 = sty.payload_idx;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    sp = zT_53;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_172 = sty.kind;
    if ((unsigned char)(zT_172 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_54 = sp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_54))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_58 = env->store;
    zT_59 = decl.child_1;
    zT_64 = zF_B10B1BC1_astStoreNodeExtraCh(zT_58, zT_59, (unsigned int)((unsigned int)fi2));
    fchild = zT_64;
    zT_66 = env->store;
    zT_67 = fchild;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    fd = zT_69;
    zT_70 = fd.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_169 = 1;
    zT_171 = fi2 + (unsigned int)((unsigned int)zT_169);
    fi2 = zT_171;
    goto z_bb_6;
    z_bb_10:
    zT_75 = fd.child_0;
    zT_76 = 0;
    zT_74 = zT_75 != (unsigned int)zT_76;
    goto z_bb_12;
    z_bb_11:
    zT_74 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_74) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_79 = env;
    zT_80 = fd.child_0;
    zT_84 = zF_F2107C15_resolveTypeExprFull(zT_79, zT_80, (unsigned int)(0));
    ft = zT_84;
    zT_86 = "B2:p";
    zT_88 = 4;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    b2_pn = zT_87;
    zT_89 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_89);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_91[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_91[_i];
        _i++;
    }
}
    zT_95 = env->store;
    zT_96 = fchild;
    zT_98 = zF_8BA26B9E_astStoreNodePayload(zT_95, zT_96);
    zT_93 = zT_98;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)b2_pb) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = zT_102;
    zT_104.len = zT_103;
    zT_94 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_93, zT_94);
    b2_pl = zT_105;
    zT_109 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_109;
    zT_114 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_115 = (unsigned int)(19) - b2_ps;
    zT_116.ptr = zT_114;
    zT_116.len = zT_115;
    zT_110 = zT_116;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_118 = "t";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    b2_tn = zT_119;
    zT_121 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_121);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_123[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_123[_i];
        _i++;
    }
}
    zT_125 = ft;
    zT_129 = 0;
    zT_130 = (unsigned char*)((unsigned char*)b2_tb) + zT_129;
    zT_131 = (unsigned int)(20) - zT_129;
    zT_132.ptr = zT_130;
    zT_132.len = zT_131;
    zT_126 = zT_132;
    zT_133 = zF_A7504564_itoa(zT_125, zT_126);
    b2_tl = zT_133;
    zT_137 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_137;
    zT_142 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_143 = (unsigned int)(19) - b2_ts;
    zT_144.ptr = zT_142;
    zT_144.len = zT_143;
    zT_138 = zT_144;
    zF_48AC7B3A_markerWrite(zT_138);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_147 = env->typereg;
    zT_148 = zT_147->fe_items;
    zT_149 = sp.fields_start;
    zT_152 = zT_148 + (unsigned int)((unsigned int)((unsigned int)zT_149) + fi2);
    zT_152->type_id = ft;
    zT_154 = "FSW:n";
    zT_156 = 5;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    fsw_nm = zT_155;
    zT_157 = fsw_nm;
    zT_159 = sp.fields_start;
    zF_C914CB83_markerWriteInt(zT_157, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_159) + fi2)));
    zT_164 = "FSW:t";
    zT_166 = 5;
    zT_165.ptr = zT_164;
    zT_165.len = zT_166;
    fsw_tm = zT_165;
    zT_167 = fsw_tm;
    zT_168 = ft;
    zF_C914CB83_markerWriteInt(zT_167, zT_168);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_177 = env->typereg;
    zT_178 = zT_177->tu_items;
    zT_179 = sty.payload_idx;
    zT_180 = (unsigned int)zT_179;
    zT_181 = zT_178[zT_180];
    tp = zT_181;
    zT_183 = "TUI:fs";
    zT_185 = 6;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    tui_fsm = zT_184;
    zT_186 = tui_fsm;
    zT_188 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_186, (unsigned int)((unsigned int)zT_188));
    zT_191 = "TUI:fc";
    zT_193 = 6;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    tui_fcm = zT_192;
    zT_194 = tui_fcm;
    zT_196 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_194, (unsigned int)((unsigned int)zT_196));
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_345 = sty.kind;
    if ((unsigned char)(zT_345 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_33; else goto z_bb_32;
    z_bb_20:
    zT_198 = tp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_198))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_202 = env->store;
    zT_205 = env->store;
    zT_206 = decl.child_1;
    zT_211 = zF_B10B1BC1_astStoreNodeExtraCh(zT_205, zT_206, (unsigned int)((unsigned int)fi2));
    zT_203 = zT_211;
    zT_212 = zF_FCDD1D35_astStoreNodeAt(zT_202, zT_203);
    fd = zT_212;
    zT_213 = fd.kind;
    if ((unsigned char)(zT_213 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_342 = 1;
    zT_344 = fi2 + (unsigned int)((unsigned int)zT_342);
    fi2 = zT_344;
    goto z_bb_20;
    z_bb_24:
    zT_218 = fd.child_0;
    zT_219 = 0;
    zT_217 = zT_218 != (unsigned int)zT_219;
    goto z_bb_26;
    z_bb_25:
    zT_217 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_217) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_222 = env;
    zT_223 = fd.child_0;
    zT_227 = zF_F2107C15_resolveTypeExprFull(zT_222, zT_223, (unsigned int)(0));
    ft = zT_227;
    zT_229 = "DFT:n";
    zT_231 = 5;
    zT_230.ptr = zT_229;
    zT_230.len = zT_231;
    dft_nm = zT_230;
    zT_232 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_232, (unsigned int)((unsigned int)fi2));
    zT_236 = "DFT:t";
    zT_238 = 5;
    zT_237.ptr = zT_236;
    zT_237.len = zT_238;
    dft_tm = zT_237;
    zT_239 = dft_tm;
    zT_240 = ft;
    zF_C914CB83_markerWriteInt(zT_239, zT_240);
    zT_242 = "B2:p";
    zT_244 = 4;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    b2_pn = zT_243;
    zT_245 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_245);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_247[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_247[_i];
        _i++;
    }
}
    zT_251 = env->store;
    zT_254 = env->store;
    zT_255 = decl.child_1;
    zT_260 = zF_B10B1BC1_astStoreNodeExtraCh(zT_254, zT_255, (unsigned int)((unsigned int)fi2));
    zT_252 = zT_260;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_251, zT_252);
    zT_249 = zT_261;
    zT_264 = 0;
    zT_265 = (unsigned char*)((unsigned char*)b2_pb) + zT_264;
    zT_266 = (unsigned int)(20) - zT_264;
    zT_267.ptr = zT_265;
    zT_267.len = zT_266;
    zT_250 = zT_267;
    zT_268 = zF_A7504564_itoa(zT_249, zT_250);
    b2_pl = zT_268;
    zT_272 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_272;
    zT_277 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_278 = (unsigned int)(19) - b2_ps;
    zT_279.ptr = zT_277;
    zT_279.len = zT_278;
    zT_273 = zT_279;
    zF_48AC7B3A_markerWrite(zT_273);
    zT_281 = "t";
    zT_283 = 1;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    b2_tn = zT_282;
    zT_284 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_284);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_286[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_286[_i];
        _i++;
    }
}
    zT_288 = ft;
    zT_292 = 0;
    zT_293 = (unsigned char*)((unsigned char*)b2_tb) + zT_292;
    zT_294 = (unsigned int)(20) - zT_292;
    zT_295.ptr = zT_293;
    zT_295.len = zT_294;
    zT_289 = zT_295;
    zT_296 = zF_A7504564_itoa(zT_288, zT_289);
    b2_tl = zT_296;
    zT_300 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_300;
    zT_305 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_306 = (unsigned int)(19) - b2_ts;
    zT_307.ptr = zT_305;
    zT_307.len = zT_306;
    zT_301 = zT_307;
    zF_48AC7B3A_markerWrite(zT_301);
    zT_309 = "DTWR\n";
    zT_311 = 5;
    zT_310.ptr = zT_309;
    zT_310.len = zT_311;
    dtwr_m = zT_310;
    zT_312 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_312);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_315 = env->typereg;
    zT_316 = zT_315->fe_items;
    zT_317 = tp.fields_start;
    zT_320 = zT_316 + (unsigned int)((unsigned int)((unsigned int)zT_317) + fi2);
    zT_320->type_id = ft;
    zT_322 = "FTW:n";
    zT_324 = 5;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    ftw_nm = zT_323;
    zT_325 = ftw_nm;
    zT_327 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_325, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_327) + fi2)));
    zT_332 = "FTW:t";
    zT_334 = 5;
    zT_333.ptr = zT_332;
    zT_333.len = zT_334;
    ftw_tm = zT_333;
    zT_335 = ftw_tm;
    zT_336 = ft;
    zF_C914CB83_markerWriteInt(zT_335, zT_336);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_338 = "DTSK\n";
    zT_340 = 5;
    zT_339.ptr = zT_338;
    zT_339.len = zT_340;
    dtsk_m = zT_339;
    zT_341 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_341);
    goto z_bb_30;
    z_bb_32:
    zT_350 = sty.kind;
    zT_349 = zT_350 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_34;
    z_bb_33:
    zT_349 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_349) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_355 = env->typereg;
    zT_356 = zT_355->un_items;
    zT_357 = sty.payload_idx;
    zT_358 = (unsigned int)zT_357;
    zT_359 = zT_356[zT_358];
    up = zT_359;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_18;
    z_bb_37:
    zT_360 = up.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_360))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_364 = env->store;
    zT_367 = env->store;
    zT_368 = decl.child_1;
    zT_373 = zF_B10B1BC1_astStoreNodeExtraCh(zT_367, zT_368, (unsigned int)((unsigned int)fi2));
    zT_365 = zT_373;
    zT_374 = zF_FCDD1D35_astStoreNodeAt(zT_364, zT_365);
    fd = zT_374;
    zT_375 = fd.kind;
    if ((unsigned char)(zT_375 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_398 = 1;
    zT_400 = fi2 + (unsigned int)((unsigned int)zT_398);
    fi2 = zT_400;
    goto z_bb_37;
    z_bb_41:
    zT_380 = fd.child_0;
    zT_381 = 0;
    zT_379 = zT_380 != (unsigned int)zT_381;
    goto z_bb_43;
    z_bb_42:
    zT_379 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_379) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_384 = env;
    zT_385 = fd.child_0;
    zT_389 = zF_F2107C15_resolveTypeExprFull(zT_384, zT_385, (unsigned int)(0));
    ft = zT_389;
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_40;
    z_bb_46:
    zT_392 = env->typereg;
    zT_393 = zT_392->fe_items;
    zT_394 = up.fields_start;
    zT_397 = zT_393 + (unsigned int)((unsigned int)((unsigned int)zT_394) + fi2);
    zT_397->type_id = ft;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_45;
}

/* varDeclInitNeedsNameCache */
unsigned char zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    return (unsigned char)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    zT_6E8D187B_ModuleEntry zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    unsigned char zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    unsigned char zT_63 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    zT_6E8D187B_ModuleEntry* zT_74;
    zT_6E8D187B_ModuleEntry zT_75;
    unsigned int zT_76;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_83 = 0;
    zT_79FAE712_u64 zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_79FAE712_u64 zT_87;
    unsigned int zT_88;
    zT_3D7259E2_SymbolRegistry* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_95;
    zT_6E8D187B_ModuleEntry zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_101 = 0;
    zT_577B64BF_Opt_873 zT_102 = {0};
    unsigned char zT_103;
    int zT_105;
    unsigned int zT_107;
    int zT_108;
    unsigned int zT_110;
    unsigned int ci;
    unsigned int cr;
    unsigned int cd_n;
    unsigned int cdi;
    unsigned int cd_i;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_577B64BF_Opt_873 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    if ((unsigned char)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_108 = 1;
    zT_110 = ci + (unsigned int)((unsigned int)zT_108);
    ci = zT_110;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_17 = mods.ptr;
    zT_18 = zT_17[ci];
    zT_19 = zT_18.source_file_id;
    env->source_file_id = zT_19;
    zT_21 = env->store;
    zT_22 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    zT_26 = env->store;
    zT_27 = cr;
    zT_29 = zF_152E19CB_astStoreNodeExtraCh(zT_26, zT_27);
    cd_n = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    cdi = zT_32;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cd_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_37 = cr;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)cdi));
    cd_i = zT_41;
    zT_43 = env->store;
    zT_44 = cd_i;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_43, zT_44);
    cdcl = zT_46;
    zT_47 = cdcl.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_105 = 1;
    zT_107 = cdi + (unsigned int)((unsigned int)zT_105);
    cdi = zT_107;
    goto z_bb_7;
    z_bb_11:
    zT_52 = cdcl.child_1;
    zT_51 = zT_52 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_51 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_51) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_56 = env->store;
    zT_57 = cdcl.child_1;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cdinit = zT_60;
    zT_61 = cdinit.kind;
    zT_63 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_61);
    if (zT_63) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_65 = env;
    zT_66 = cdcl.child_1;
    zT_70 = zF_F2107C15_resolveTypeExprFull(zT_65, zT_66, (unsigned int)(0));
    cdtype = zT_70;
    if ((unsigned char)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_74 = mods.ptr;
    zT_75 = zT_74[ci];
    zT_76 = zT_75.id;
    zT_80 = env->store;
    zT_81 = cd_i;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_80, zT_81);
    zT_85 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_76) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_83);
    ck = zT_85;
    zT_86 = env->typereg;
    zT_87 = ck;
    zT_88 = cdtype;
    zF_5E95558D_nameCachePut(zT_86, zT_87, zT_88);
    zT_91 = env->symbol_reg;
    zT_95 = mods.ptr;
    zT_96 = zT_95[ci];
    zT_92 = zT_96.id;
    zT_98 = env->store;
    zT_99 = cd_i;
    zT_101 = zF_8BA26B9E_astStoreNodePayload(zT_98, zT_99);
    zT_93 = zT_101;
    zT_102 = zF_A398987E_symbolRegistryQuali(zT_91, zT_92, zT_93);
    cdsym = zT_102;
    zT_103 = cdsym.has_value;
    if (zT_103) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_577B64BF_Opt_873 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_8143F551_AstKind zT_49;
    zT_072B53A6_ModuleRegistry* zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_61 = 0;
    zT_BAEE192E_Opt_10 zT_62 = {0};
    unsigned char zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    unsigned int zT_77;
    zT_577B64BF_Opt_873 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((unsigned char)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_33 = env->store;
    zT_34 = fd.child_1;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fi = zT_37;
    zT_38 = fi.kind;
    if ((unsigned char)(zT_38 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_44 = env->store;
    zT_45 = fi.child_0;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    fb = zT_48;
    zT_49 = fb.kind;
    if ((unsigned char)(zT_49 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_55 = module_reg;
    zT_57 = env->store;
    zT_58 = fi.child_0;
    zT_61 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    zT_56 = zT_61;
    zT_62 = zF_A258E183_moduleRegistryPathT(zT_55, zT_56);
    t2 = zT_62;
    zT_63 = t2.has_value;
    if (zT_63) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_65 = env;
    zT_66 = module_reg;
    zT_67 = importer_mod_id;
    zT_68 = m2;
    zT_71 = env->store;
    zT_72 = fd.child_1;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_69 = zT_75;
    zT_77 = depth + (unsigned int)(1);
    env = zT_65;
    module_reg = zT_66;
    importer_mod_id = zT_67;
    target_mod_id = zT_68;
    field_name_id = zT_69;
    depth = zT_77;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_36 = 0;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    zT_072B53A6_ModuleRegistry* zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    unsigned int zT_76 = 0;
    zT_BAEE192E_Opt_10 zT_77 = {0};
    unsigned char zT_78;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    zT_072B53A6_ModuleRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6E8D187B_ModuleEntry* zT_87;
    zT_6E8D187B_ModuleEntry zT_88;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    unsigned int zT_94 = 0;
    unsigned int zT_96 = 0;
    zT_3D7259E2_SymbolRegistry* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_6E8D187B_ModuleEntry* zT_104;
    zT_6E8D187B_ModuleEntry zT_105;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_577B64BF_Opt_873 zT_111 = {0};
    unsigned char zT_112;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    zT_79FAE712_u64 zT_126;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_136;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_577B64BF_Opt_873 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_134 = 1;
    zT_136 = mi + (unsigned int)((unsigned int)zT_134);
    mi = zT_136;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = env->store;
    zT_17 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    zT_21 = env->store;
    zT_22 = root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_21, zT_22);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = env->store;
    zT_32 = root;
    zT_36 = zF_B10B1BC1_astStoreNodeExtraCh(zT_31, zT_32, (unsigned int)((unsigned int)di));
    decl_idx = zT_36;
    zT_38 = env->store;
    zT_39 = decl_idx;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    decl = zT_41;
    zT_42 = decl.kind;
    if ((unsigned char)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_131 = 1;
    zT_133 = di + (unsigned int)((unsigned int)zT_131);
    di = zT_133;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_46 = decl.child_1;
    if ((unsigned char)(zT_46 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_50 = env->store;
    zT_51 = decl.child_1;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    init = zT_54;
    zT_55 = init.kind;
    if ((unsigned char)(zT_55 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_60 = env->store;
    zT_61 = init.child_0;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_60, zT_61);
    base = zT_64;
    zT_65 = base.kind;
    if ((unsigned char)(zT_65 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_70 = module_reg;
    zT_72 = env->store;
    zT_73 = init.child_0;
    zT_76 = zF_8BA26B9E_astStoreNodePayload(zT_72, zT_73);
    zT_71 = zT_76;
    zT_77 = zF_A258E183_moduleRegistryPathT(zT_70, zT_71);
    target = zT_77;
    zT_78 = target.has_value;
    if (zT_78) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_81 = env;
    zT_82 = module_reg;
    zT_87 = mods.ptr;
    zT_88 = zT_87[mi];
    zT_83 = zT_88.id;
    zT_84 = mtid;
    zT_90 = env->store;
    zT_91 = decl.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_90, zT_91);
    zT_85 = zT_94;
    zT_96 = zF_E8C2AADA_resolveImportFieldA(zT_81, zT_82, zT_83, zT_84, zT_85, (unsigned int)(0));
    resolved = zT_96;
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_100 = env->symbol_reg;
    zT_104 = mods.ptr;
    zT_105 = zT_104[mi];
    zT_101 = zT_105.id;
    zT_107 = env->store;
    zT_108 = decl_idx;
    zT_110 = zF_8BA26B9E_astStoreNodePayload(zT_107, zT_108);
    zT_102 = zT_110;
    zT_111 = zF_A398987E_symbolRegistryQuali(zT_100, zT_101, zT_102);
    sym = zT_111;
    zT_112 = sym.has_value;
    if (zT_112) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_121 = env->store;
    zT_122 = decl_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    zT_126 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_117) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_124);
    ck = zT_126;
    zT_127 = env->typereg;
    zT_128 = ck;
    zT_129 = resolved;
    zF_5E95558D_nameCachePut(zT_127, zT_128, zT_129);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned char zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_8143F551_AstKind zT_58;
    unsigned char zT_62;
    zT_8143F551_AstKind zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6E8D187B_ModuleEntry* zT_70;
    zT_6E8D187B_ModuleEntry zT_71;
    int zT_73;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_78;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_76 = 1;
    zT_78 = mi + (unsigned int)((unsigned int)zT_76);
    mi = zT_78;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[mi];
    zT_16 = zT_15.source_file_id;
    env->source_file_id = zT_16;
    zT_18 = env->store;
    zT_19 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = root;
    zT_38 = zF_B10B1BC1_astStoreNodeExtraCh(zT_33, zT_34, (unsigned int)((unsigned int)di));
    decl_idx = zT_38;
    zT_40 = env->store;
    zT_41 = decl_idx;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    decl = zT_43;
    zT_44 = decl.kind;
    if ((unsigned char)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_73 = 1;
    zT_75 = di + (unsigned int)((unsigned int)zT_73);
    di = zT_75;
    goto z_bb_7;
    z_bb_11:
    zT_49 = decl.child_1;
    zT_50 = 0;
    zT_48 = zT_49 != (unsigned int)zT_50;
    goto z_bb_13;
    z_bb_12:
    zT_48 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_48) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_53 = env->store;
    zT_54 = decl.child_1;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    init = zT_57;
    zT_58 = init.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_63 = init.kind;
    zT_62 = zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_62 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_62) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_67 = env;
    zT_70 = mods.ptr;
    zT_71 = zT_70[mi];
    zT_68 = zT_71.id;
    zT_69 = decl_idx;
    zF_F5C3193B_resolveDeclAggregat(zT_67, zT_68, zT_69);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6E8D187B_ModuleEntry* zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_47 = {0};
    zT_8143F551_AstKind zT_48;
    zT_6B0A7D14_AstStore* zT_53;
    zT_43C98C6F_anon_258051 zT_54;
    zT_243D6A41_FnProto* zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    unsigned int zT_60;
    zT_243D6A41_FnProto zT_61;
    zT_3D7259E2_SymbolRegistry* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_67;
    zT_6E8D187B_ModuleEntry zT_68;
    zT_577B64BF_Opt_873 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_74;
    zT_939EE900_Arr_unsigned_int_1 zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    int zT_82;
    zT_ABC1EBBE_TypeResolveEnv* zT_85;
    unsigned int zT_86;
    unsigned int zT_90 = 0;
    int zT_93;
    zT_8EED1867_ResolvedTypeTable* zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_99;
    unsigned char zT_100;
    unsigned char zT_105;
    unsigned char zT_107;
    unsigned char zT_108;
    unsigned char zT_113;
    zT_993A6923_Arr_unsigned_int_64 zT_115;
    unsigned int zT_117;
    unsigned short zT_118;
    char* zT_122;
    unsigned int zT_123;
    char* zT_124;
    unsigned int zT_125;
    char* zT_126;
    unsigned int zT_127;
    unsigned short zT_129;
    unsigned int zT_133;
    unsigned short zT_137;
    zT_79FAE712_u64 zT_139;
    zT_6B0A7D14_AstStore* zT_141;
    zT_79FAE712_u64 zT_142;
    unsigned int zT_144 = 0;
    int zT_146;
    unsigned int zT_147;
    zT_6B0A7D14_AstStore* zT_151;
    unsigned int zT_152;
    zT_6B0A7D14_AstStore* zT_154;
    zT_79FAE712_u64 zT_155;
    unsigned int zT_159 = 0;
    zT_22A7C88B_AstNode zT_160 = {0};
    unsigned int zT_161;
    int zT_162;
    zT_ABC1EBBE_TypeResolveEnv* zT_165;
    unsigned int zT_166;
    unsigned int zT_170 = 0;
    char* zT_173;
    unsigned int zT_174;
    char* zT_175;
    unsigned int zT_176;
    char* zT_177;
    unsigned int zT_178;
    unsigned int zT_181;
    zT_8EED1867_ResolvedTypeTable* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_190;
    zT_338B7C76_TypeRegistry* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_198;
    unsigned int zT_199;
    int zT_202;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned char zT_209;
    unsigned char zT_210;
    unsigned int zT_211;
    unsigned short zT_212;
    unsigned int zT_213;
    unsigned char zT_214;
    zT_6E8D187B_ModuleEntry* zT_217;
    zT_6E8D187B_ModuleEntry zT_218;
    int zT_221;
    unsigned int zT_224 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    zT_3D7259E2_SymbolRegistry* zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    zT_6E8D187B_ModuleEntry* zT_233;
    zT_6E8D187B_ModuleEntry zT_234;
    zT_577B64BF_Opt_873 zT_237 = {0};
    unsigned char zT_238;
    zT_8143F551_AstKind zT_240;
    unsigned char zT_244;
    unsigned int zT_245;
    int zT_246;
    zT_ABC1EBBE_TypeResolveEnv* zT_249;
    unsigned int zT_250;
    unsigned int zT_254 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    zT_8EED1867_ResolvedTypeTable* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_3D7259E2_SymbolRegistry* zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    zT_6E8D187B_ModuleEntry* zT_269;
    zT_6E8D187B_ModuleEntry zT_270;
    zT_6B0A7D14_AstStore* zT_272;
    unsigned int zT_273;
    unsigned int zT_275 = 0;
    zT_577B64BF_Opt_873 zT_276 = {0};
    unsigned char zT_277;
    int zT_279;
    unsigned int zT_281;
    int zT_282;
    unsigned int zT_284;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_577B64BF_Opt_873 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    zT_993A6923_Arr_unsigned_int_64 ptypes_buf;
    unsigned int ptypes_n;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int fn_start;
    unsigned int pf;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    unsigned int tid;
    zT_577B64BF_Opt_873 sym;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_282 = 1;
    zT_284 = mi + (unsigned int)((unsigned int)zT_282);
    mi = zT_284;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_18 = mods.ptr;
    zT_19 = zT_18[mi];
    zT_20 = zT_19.source_file_id;
    env->source_file_id = zT_20;
    zT_22 = env->store;
    zT_23 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_27 = env->store;
    zT_28 = root;
    zT_30 = zF_152E19CB_astStoreNodeExtraCh(zT_27, zT_28);
    decls_n = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    di = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_38 = root;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)di));
    decl_idx = zT_42;
    zT_44 = env->store;
    zT_45 = decl_idx;
    zT_47 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    decl = zT_47;
    zT_48 = decl.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_279 = 1;
    zT_281 = di + (unsigned int)((unsigned int)zT_279);
    di = zT_281;
    goto z_bb_7;
    z_bb_11:
    zT_53 = env->store;
    zT_54 = zT_53->fn_protos;
    zT_55 = zT_54.items;
    zT_56 = env->store;
    zT_57 = decl_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    zT_60 = (unsigned int)zT_59;
    zT_61 = zT_55[zT_60];
    proto = zT_61;
    zT_63 = env->symbol_reg;
    zT_67 = mods.ptr;
    zT_68 = zT_67[mi];
    zT_64 = zT_68.id;
    zT_65 = proto.name_id;
    zT_71 = zF_A398987E_symbolRegistryQuali(zT_63, zT_64, zT_65);
    sym_check = zT_71;
    zT_72 = sym_check.has_value;
    if (zT_72) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_240 = decl.kind;
    if ((unsigned char)(zT_240 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_14:
    sc = sym_check.value;
    zT_74 = sc->type_id;
    if ((unsigned char)(zT_74 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_79 = 1;
    zT_80 = 0;
    zT_78[zT_80] = zT_79;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_78[_i];
        _i++;
    }
}
    zT_81 = proto.return_type_node;
    zT_82 = 0;
    if ((unsigned char)(zT_81 != (unsigned int)zT_82)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_85 = env;
    zT_86 = proto.return_type_node;
    zT_90 = zF_F2107C15_resolveTypeExprFull(zT_85, zT_86, (unsigned int)(0));
    rtype = zT_90;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_99 = 0;
    is_ext = zT_99;
    zT_100 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_100 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_93 = 0;
    rt_box[zT_93] = rtype;
    zT_94 = resolved_types;
    zT_95 = proto.return_type_node;
    zT_96 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_94, zT_95, zT_96);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_105 = 1;
    is_ext = zT_105;
    goto z_bb_23;
    z_bb_23:
    zT_107 = 0;
    is_variadic = zT_107;
    zT_108 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_108 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_113 = 1;
    is_variadic = zT_113;
    goto z_bb_25;
    z_bb_25:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_115[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        ptypes_buf[_i] = zT_115[_i];
        _i++;
    }
}
    zT_117 = 0;
    ptypes_n = zT_117;
    zT_118 = proto.params_count;
    if ((unsigned char)((unsigned int)((unsigned int)zT_118) > (unsigned int)(64))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_122 = "panic: ";
    zT_123 = 7;
    fwrite(zT_122, 1, zT_123, stderr);
    zT_124 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_125 = 72;
    fwrite(zT_124, 1, zT_125, stderr);
    zT_126 = "\n";
    zT_127 = 1;
    fwrite(zT_126, 1, zT_127, stderr);
    pal_trap();
    z_bb_27:
    zT_129 = proto.params_count;
    if ((unsigned char)(zT_129 > (unsigned short)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_133 = proto.params_start;
    zT_137 = proto.params_count;
    zT_139 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_133) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_137);
    p_payload = zT_139;
    zT_141 = env->store;
    zT_142 = p_payload;
    zT_144 = zF_03CE8CAB_astStoreGetExtraChi(zT_141, zT_142);
    pnodes_n = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    pi = zT_147;
    goto z_bb_30;
    z_bb_29:
    zT_192 = env->typereg;
    zT_193 = zT_192->xt_len;
    zT_194 = (unsigned int)zT_193;
    fn_start = zT_194;
    zT_196 = 0;
    pf = zT_196;
    goto z_bb_40;
    z_bb_30:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_151 = env->store;
    zT_154 = env->store;
    zT_155 = p_payload;
    zT_159 = zF_E5B10421_astStoreGetExtraChi(zT_154, zT_155, (unsigned int)((unsigned int)pi));
    zT_152 = zT_159;
    zT_160 = zF_FCDD1D35_astStoreNodeAt(zT_151, zT_152);
    pnode = zT_160;
    zT_161 = pnode.child_0;
    zT_162 = 0;
    if ((unsigned char)(zT_161 != (unsigned int)zT_162)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_188 = 1;
    zT_190 = pi + (unsigned int)((unsigned int)zT_188);
    pi = zT_190;
    goto z_bb_30;
    z_bb_34:
    zT_165 = env;
    zT_166 = pnode.child_0;
    zT_170 = zF_F2107C15_resolveTypeExprFull(zT_165, zT_166, (unsigned int)(0));
    ptype = zT_170;
    if ((unsigned char)(ptypes_n >= (unsigned int)(64))) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    zT_173 = "panic: ";
    zT_174 = 7;
    fwrite(zT_173, 1, zT_174, stderr);
    zT_175 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_176 = 72;
    fwrite(zT_175, 1, zT_176, stderr);
    zT_177 = "\n";
    zT_178 = 1;
    fwrite(zT_177, 1, zT_178, stderr);
    pal_trap();
    z_bb_37:
    ptypes_buf[ptypes_n] = ptype;
    zT_181 = ptypes_n + (unsigned int)(1);
    ptypes_n = zT_181;
    if ((unsigned char)(ptype != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_184 = resolved_types;
    zT_185 = pnode.child_0;
    zT_186 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_184, zT_185, zT_186);
    goto z_bb_39;
    z_bb_39:
    goto z_bb_35;
    z_bb_40:
    if ((unsigned char)(pf < ptypes_n)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_198 = env->typereg;
    zT_199 = ptypes_buf[pf];
    zF_4C03AE3D_xtAppend(zT_198, zT_199);
    goto z_bb_43;
    z_bb_42:
    zT_206 = env->typereg;
    zT_207 = proto.name_id;
    zT_217 = mods.ptr;
    zT_218 = zT_217[mi];
    zT_208 = zT_218.id;
    zT_209 = is_ext;
    zT_210 = is_variadic;
    zT_211 = fn_start;
    zT_212 = proto.params_count;
    zT_221 = 0;
    zT_213 = rt_box[zT_221];
    zT_214 = proto.call_conv;
    zT_224 = zF_474336D7_typeRegistryGetOrCr(zT_206, zT_207, zT_208, zT_209, zT_210, zT_211, zT_212, zT_213, zT_214);
    tid = zT_224;
    zT_225 = resolved_types;
    zT_226 = decl_idx;
    zT_227 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_225, zT_226, zT_227);
    zT_229 = env->symbol_reg;
    zT_233 = mods.ptr;
    zT_234 = zT_233[mi];
    zT_230 = zT_234.id;
    zT_231 = proto.name_id;
    zT_237 = zF_A398987E_symbolRegistryQuali(zT_229, zT_230, zT_231);
    sym = zT_237;
    zT_238 = sym.has_value;
    if (zT_238) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_202 = 1;
    zT_204 = pf + (unsigned int)((unsigned int)zT_202);
    pf = zT_204;
    goto z_bb_40;
    z_bb_44:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_245 = decl.child_0;
    zT_246 = 0;
    zT_244 = zT_245 != (unsigned int)zT_246;
    goto z_bb_48;
    z_bb_47:
    zT_244 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_244) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_249 = env;
    zT_250 = decl.child_0;
    zT_254 = zF_F2107C15_resolveTypeExprFull(zT_249, zT_250, (unsigned int)(0));
    vtype = zT_254;
    if ((unsigned char)(vtype != (unsigned int)(18))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_12;
    z_bb_51:
    zT_257 = resolved_types;
    zT_258 = decl.child_0;
    zT_259 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_257, zT_258, zT_259);
    zT_261 = resolved_types;
    zT_262 = decl_idx;
    zT_263 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_261, zT_262, zT_263);
    zT_265 = env->symbol_reg;
    zT_269 = mods.ptr;
    zT_270 = zT_269[mi];
    zT_266 = zT_270.id;
    zT_272 = env->store;
    zT_273 = decl_idx;
    zT_275 = zF_8BA26B9E_astStoreNodePayload(zT_272, zT_273);
    zT_267 = zT_275;
    zT_276 = zF_A398987E_symbolRegistryQuali(zT_265, zT_266, zT_267);
    sym = zT_276;
    zT_277 = sym.has_value;
    if (zT_277) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_52;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_9;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_10 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_12;
    unsigned int zT_14;
    zT_7034F045_Opt_228 zT_15;
    zT_02B97B5A_Opt_399 zT_16 = {0};
    zT_04CE5406_Opt_401 zT_17 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_18;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_22;
    zT_072B53A6_ModuleRegistry* zT_23;
    zT_ABC1EBBE_TypeResolveEnv* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_9 = module_reg;
    zT_10 = zF_3452C137_moduleRegistryGetMo(zT_9);
    mods = zT_10;
    zT_12.store = store;
    zT_12.typereg = typereg;
    zT_12.symbol_reg = symbol_reg;
    zT_12.interner = interner;
    zT_12.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_14 = 0;
    zT_12.source_file_id = zT_14;
    zT_15.has_value = 1;
    zT_15.value = diag;
    zT_12.diag = zT_15;
    zT_16.has_value = 0;
    zT_12.local_consts = zT_16;
    zT_17.has_value = 0;
    zT_12.local_types = zT_17;
    env = zT_12;
    (void)perm_alloc;
    zT_18 = &env;
    zT_19 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_18, zT_19);
    zT_21 = &env;
    zT_22 = mods;
    zT_23 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_21, zT_22, zT_23);
    zT_25 = &env;
    zT_26 = mods;
    zF_E2882212_resolveAggregateFie(zT_25, zT_26);
    zT_28 = &env;
    zT_29 = mods;
    zT_30 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_28, zT_29, zT_30);
    return;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
    return;
}

/* EOF */
