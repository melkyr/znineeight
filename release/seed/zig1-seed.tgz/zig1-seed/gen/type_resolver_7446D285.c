#include "type_resolver_7446D285.h"
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_7534F824_Opt_223 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_65F39959_EU_322 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_7534F824_Opt_223 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->depend_len;
    zT_2 = self->depend_cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->depend_cap;
    zT_6 = 8;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->depend_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->depend_cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->depend_items;
    zT_25 = self->depend_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->depend_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->depend_items;
    zT_48 = self->depend_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->depend_items = new_items;
    self->depend_cap = nc;
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    self->depend_len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    unsigned int* zT_23;
    unsigned int zT_25;
    zT_7534F824_Opt_223 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_65F39959_EU_322 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned int* zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_7534F824_Opt_223 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_1 = self->worklist_len;
    zT_2 = self->worklist_cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->worklist_cap;
    zT_6 = 64;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->worklist_cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->worklist_cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->worklist_items;
    zT_25 = self->worklist_cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(4)), (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->worklist_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (unsigned int*)raw;
    new_items = zT_46;
    zT_47 = self->worklist_items;
    zT_48 = self->worklist_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->worklist_items = new_items;
    self->worklist_cap = nc;
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 + (unsigned int)((unsigned int)zT_6));
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((int)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_65F39959_EU_322 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((int)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((int)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_19 = zT_17.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_5;
    zT_D155D06D_Type* zT_6;
    zT_D155D06D_Type zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_406493CE_StructPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_406493CE_StructPayload zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned short zT_31;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    unsigned int zT_46;
    zT_2DF01B61_FieldEntry zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_D155D06D_Type* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_D155D06D_Type zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_2DF01B61_FieldEntry* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_2DF01B61_FieldEntry* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78 = 0;
    unsigned int zT_79;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_D155D06D_Type* zT_85;
    zT_33EF6BFB_TypeKind zT_86;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_457ECFEE_EnumPayload* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_457ECFEE_EnumPayload zT_96;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_D155D06D_Type* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_D155D06D_Type zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_AF9231A2_UnionPayload* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_AF9231A2_UnionPayload zT_117;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned short zT_122;
    unsigned int zT_123;
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_338B7C76_TypeRegistry* zT_135;
    zT_2DF01B61_FieldEntry* zT_136;
    unsigned int zT_137;
    zT_2DF01B61_FieldEntry zT_138;
    zT_338B7C76_TypeRegistry* zT_140;
    zT_D155D06D_Type* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_D155D06D_Type zT_144;
    zT_33EF6BFB_TypeKind zT_145;
    unsigned int zT_150;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_155;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160 = 0;
    unsigned int zT_161;
    zT_338B7C76_TypeRegistry* zT_166;
    zT_D155D06D_Type* zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_173;
    unsigned int zT_174;
    zT_33EF6BFB_TypeKind zT_176;
    zT_338B7C76_TypeRegistry* zT_182;
    zT_54FF90FA_TaggedUnionPayload* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_54FF90FA_TaggedUnionPayload zT_186;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_D155D06D_Type* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_D155D06D_Type zT_192;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned short zT_197;
    unsigned int zT_198;
    int zT_200;
    unsigned int zT_201;
    int zT_203;
    unsigned int zT_204;
    int zT_206;
    unsigned int zT_207;
    zT_338B7C76_TypeRegistry* zT_210;
    zT_2DF01B61_FieldEntry* zT_211;
    unsigned int zT_212;
    zT_2DF01B61_FieldEntry zT_213;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_338B7C76_TypeRegistry* zT_230;
    zT_D155D06D_Type* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    zT_D155D06D_Type zT_234;
    zT_33EF6BFB_TypeKind zT_235;
    unsigned int zT_240;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned int zT_245;
    int zT_246;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned int zT_251;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257 = 0;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260 = 0;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264 = 0;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_D155D06D_Type* zT_266;
    zT_33EF6BFB_TypeKind zT_267;
    zT_338B7C76_TypeRegistry* zT_273;
    zT_0B10E8E9_OptionalPayload* zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    zT_0B10E8E9_OptionalPayload zT_277;
    zT_338B7C76_TypeRegistry* zT_279;
    zT_D155D06D_Type* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    zT_D155D06D_Type zT_283;
    unsigned int zT_285;
    unsigned int zT_288;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_297 = 0;
    unsigned int zT_300 = 0;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_D155D06D_Type* zT_302;
    zT_33EF6BFB_TypeKind zT_303;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_42C2D6BF_EUPayload* zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    zT_42C2D6BF_EUPayload zT_313;
    zT_338B7C76_TypeRegistry* zT_315;
    zT_D155D06D_Type* zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    zT_D155D06D_Type zT_319;
    unsigned int zT_321;
    unsigned int zT_324;
    unsigned int zT_328;
    unsigned int zT_331;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337 = 0;
    unsigned int zT_338;
    unsigned int zT_341 = 0;
    unsigned int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned int zT_346 = 0;
    zT_338B7C76_TypeRegistry* zT_347;
    zT_D155D06D_Type* zT_348;
    zT_33EF6BFB_TypeKind zT_349;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_E834303C_ArrayPayload* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    zT_E834303C_ArrayPayload zT_359;
    zT_338B7C76_TypeRegistry* zT_361;
    zT_D155D06D_Type* zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_D155D06D_Type zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_369;
    zT_338B7C76_TypeRegistry* zT_370;
    zT_D155D06D_Type* zT_371;
    zT_33EF6BFB_TypeKind zT_372;
    zT_338B7C76_TypeRegistry* zT_378;
    zT_666DC2E1_TuplePayload* zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    zT_666DC2E1_TuplePayload zT_382;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned short zT_387;
    unsigned int zT_388;
    int zT_390;
    unsigned int zT_391;
    int zT_393;
    unsigned int zT_394;
    int zT_396;
    unsigned int zT_397;
    zT_338B7C76_TypeRegistry* zT_400;
    unsigned int* zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_338B7C76_TypeRegistry* zT_405;
    zT_D155D06D_Type* zT_406;
    unsigned int zT_407;
    zT_D155D06D_Type zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned int zT_412 = 0;
    unsigned int zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    unsigned int zT_417;
    int zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned int zT_422 = 0;
    unsigned int zT_423;
    zT_338B7C76_TypeRegistry* zT_428;
    zT_D155D06D_Type* zT_429;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->registry;
    zT_6 = zT_5->types_items;
    zT_7 = zT_6[idx];
    ty = zT_7;
    zT_8 = ty.kind;
    if ((int)(zT_8 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_13 = ty.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_86 = ty.kind;
    if ((int)(zT_86 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = tid;
    zF_331152CD_typeRegistryCompute(zT_18, zT_19);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_22 = self->registry;
    zT_23 = zT_22->st_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    sp = zT_26;
    zT_28 = sp.fields_start;
    zT_29 = (unsigned int)zT_28;
    fstart = zT_29;
    zT_31 = sp.fields_count;
    zT_32 = (unsigned int)zT_31;
    fcount = zT_32;
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    offset = zT_35;
    zT_37 = 1;
    zT_38 = (unsigned int)zT_37;
    max_align = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_7;
    z_bb_7:
    if ((int)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = fstart + fi;
    zT_47 = zT_45[zT_46];
    fe = zT_47;
    zT_49 = self->registry;
    zT_50 = zT_49->types_items;
    zT_51 = fe.type_id;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    ft = zT_53;
    zT_54 = ft.kind;
    if ((int)(zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_76 = offset;
    zT_77 = max_align;
    zT_78 = zF_D2BAC673_alignUp_1(zT_76, zT_77);
    ty.size = zT_78;
    ty.alignment = max_align;
    zT_79 = ty.size;
    if ((int)(zT_79 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_74 = 1;
    zT_75 = fi + zT_74;
    fi = zT_75;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_59 = self->registry;
    zT_60 = zT_59->fe_items;
    zT_61 = fstart + fi;
    zT_60[zT_61] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_62 = offset;
    zT_63 = ft.alignment;
    zT_65 = zF_D2BAC673_alignUp_1(zT_62, zT_63);
    offset = zT_65;
    fe.offset = offset;
    zT_66 = self->registry;
    zT_67 = zT_66->fe_items;
    zT_68 = fstart + fi;
    zT_67[zT_68] = fe;
    zT_69 = ft.size;
    zT_70 = offset + zT_69;
    offset = zT_70;
    zT_71 = ft.alignment;
    if ((int)(zT_71 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_73 = ft.alignment;
    max_align = zT_73;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_17;
    z_bb_17:
    zT_84 = self->registry;
    zT_85 = zT_84->types_items;
    zT_85[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_92 = self->registry;
    zT_93 = zT_92->en_items;
    zT_94 = ty.payload_idx;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_93[zT_95];
    ep = zT_96;
    zT_98 = self->registry;
    zT_99 = zT_98->types_items;
    zT_100 = ep.backing_type;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zT_99[zT_101];
    bt = zT_102;
    zT_103 = bt.size;
    ty.size = zT_103;
    zT_104 = bt.alignment;
    ty.alignment = zT_104;
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_106[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_107 = ty.kind;
    if ((int)(zT_107 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_113 = self->registry;
    zT_114 = zT_113->un_items;
    zT_115 = ty.payload_idx;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    up = zT_117;
    zT_119 = up.fields_start;
    zT_120 = (unsigned int)zT_119;
    fstart = zT_120;
    zT_122 = up.fields_count;
    zT_123 = (unsigned int)zT_122;
    fcount = zT_123;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    max_sz = zT_126;
    zT_128 = 1;
    zT_129 = (unsigned int)zT_128;
    max_align = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    fi = zT_132;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_168 = ty.kind;
    if ((int)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((int)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_135 = self->registry;
    zT_136 = zT_135->fe_items;
    zT_137 = fstart + fi;
    zT_138 = zT_136[zT_137];
    fe = zT_138;
    zT_140 = self->registry;
    zT_141 = zT_140->types_items;
    zT_142 = fe.type_id;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    ft = zT_144;
    zT_145 = ft.kind;
    if ((int)(zT_145 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_158 = max_sz;
    zT_159 = max_align;
    zT_160 = zF_D2BAC673_alignUp_1(zT_158, zT_159);
    ty.size = zT_160;
    ty.alignment = max_align;
    zT_161 = ty.size;
    if ((int)(zT_161 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_156 = 1;
    zT_157 = fi + zT_156;
    fi = zT_157;
    goto z_bb_24;
    z_bb_28:
    zT_150 = ft.size;
    if ((int)(zT_150 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_152 = ft.size;
    max_sz = zT_152;
    goto z_bb_31;
    z_bb_31:
    zT_153 = ft.alignment;
    if ((int)(zT_153 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_155 = ft.alignment;
    max_align = zT_155;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_35;
    z_bb_35:
    zT_166 = self->registry;
    zT_167 = zT_166->types_items;
    zT_167[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_173 = self->registry;
    zT_174 = tid;
    zF_62A8E268_typeRegistryCompute(zT_173, zT_174);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_176 = ty.kind;
    if ((int)(zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_182 = self->registry;
    zT_183 = zT_182->tu_items;
    zT_184 = ty.payload_idx;
    zT_185 = (unsigned int)zT_184;
    zT_186 = zT_183[zT_185];
    tp = zT_186;
    zT_188 = self->registry;
    zT_189 = zT_188->types_items;
    zT_190 = tp.tag_type;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tag_ty = zT_192;
    zT_194 = tp.fields_start;
    zT_195 = (unsigned int)zT_194;
    fstart = zT_195;
    zT_197 = tp.fields_count;
    zT_198 = (unsigned int)zT_197;
    fcount = zT_198;
    zT_200 = 0;
    zT_201 = (unsigned int)zT_200;
    max_ps = zT_201;
    zT_203 = 1;
    zT_204 = (unsigned int)zT_203;
    max_pa = zT_204;
    zT_206 = 0;
    zT_207 = (unsigned int)zT_206;
    fi = zT_207;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_267 = ty.kind;
    if ((int)(zT_267 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((int)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_210 = self->registry;
    zT_211 = zT_210->fe_items;
    zT_212 = fstart + fi;
    zT_213 = zT_211[zT_212];
    fe = zT_213;
    zT_215 = "FER:n";
    zT_217 = 5;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    fer_nm = zT_216;
    zT_218 = fer_nm;
    zF_C914CB83_markerWriteInt(zT_218, (unsigned int)((unsigned int)(unsigned int)(fstart + fi)));
    zT_223 = "FER:t";
    zT_225 = 5;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    fer_tm = zT_224;
    zT_226 = fer_tm;
    zT_227 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    zT_230 = self->registry;
    zT_231 = zT_230->types_items;
    zT_232 = fe.type_id;
    zT_233 = (unsigned int)zT_232;
    zT_234 = zT_231[zT_233];
    ft = zT_234;
    zT_235 = ft.kind;
    if ((int)(zT_235 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_249 = tag_ty.alignment;
    if ((int)(zT_249 > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_246 = 1;
    zT_247 = fi + zT_246;
    fi = zT_247;
    goto z_bb_42;
    z_bb_46:
    zT_240 = ft.size;
    if ((int)(zT_240 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_242 = ft.size;
    max_ps = zT_242;
    goto z_bb_49;
    z_bb_49:
    zT_243 = ft.alignment;
    if ((int)(zT_243 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_245 = ft.alignment;
    max_pa = zT_245;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_251 = tag_ty.alignment;
    goto z_bb_54;
    z_bb_53:
    zT_251 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_251;
    zT_254 = tag_ty.size;
    total = zT_254;
    zT_255 = total;
    zT_256 = max_pa;
    zT_257 = zF_D2BAC673_alignUp_1(zT_255, zT_256);
    total = zT_257;
    zT_258 = max_ps;
    zT_259 = max_pa;
    zT_260 = zF_D2BAC673_alignUp_1(zT_258, zT_259);
    zT_261 = total + zT_260;
    total = zT_261;
    zT_262 = total;
    zT_263 = overall_align;
    zT_264 = zF_D2BAC673_alignUp_1(zT_262, zT_263);
    ty.size = zT_264;
    ty.alignment = overall_align;
    zT_265 = self->registry;
    zT_266 = zT_265->types_items;
    zT_266[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_273 = self->registry;
    zT_274 = zT_273->opt_items;
    zT_275 = ty.payload_idx;
    zT_276 = (unsigned int)zT_275;
    zT_277 = zT_274[zT_276];
    op = zT_277;
    zT_279 = self->registry;
    zT_280 = zT_279->types_items;
    zT_281 = op.payload;
    zT_282 = (unsigned int)zT_281;
    zT_283 = zT_280[zT_282];
    pt = zT_283;
    zT_285 = pt.alignment;
    if ((int)(zT_285 > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_303 = ty.kind;
    if ((int)(zT_303 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_288 = pt.alignment;
    goto z_bb_60;
    z_bb_59:
    zT_288 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_288;
    zT_293 = pt.size;
    zT_297 = zF_D2BAC673_alignUp_1(zT_293, (unsigned int)(4));
    zT_292 = pay_align;
    zT_300 = zF_D2BAC673_alignUp_1((unsigned int)(zT_297 + (unsigned int)(4)), zT_292);
    ty.size = zT_300;
    ty.alignment = pay_align;
    zT_301 = self->registry;
    zT_302 = zT_301->types_items;
    zT_302[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_309 = self->registry;
    zT_310 = zT_309->eu_items;
    zT_311 = ty.payload_idx;
    zT_312 = (unsigned int)zT_311;
    zT_313 = zT_310[zT_312];
    ep_1 = zT_313;
    zT_315 = self->registry;
    zT_316 = zT_315->types_items;
    zT_317 = ep_1.payload;
    zT_318 = (unsigned int)zT_317;
    zT_319 = zT_316[zT_318];
    pt = zT_319;
    zT_321 = pt.size;
    if ((int)(zT_321 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_349 = ty.kind;
    if ((int)(zT_349 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_324 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_324 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_324;
    zT_328 = pt.alignment;
    if ((int)(zT_328 > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_331 = pt.alignment;
    goto z_bb_69;
    z_bb_68:
    zT_331 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_331;
    zT_335 = union_sz;
    zT_336 = union_align;
    zT_337 = zF_D2BAC673_alignUp_1(zT_335, zT_336);
    total = zT_337;
    zT_338 = total;
    zT_341 = zF_D2BAC673_alignUp_1(zT_338, (unsigned int)(4));
    zT_343 = zT_341 + (unsigned int)(4);
    total = zT_343;
    zT_344 = total;
    zT_345 = union_align;
    zT_346 = zF_D2BAC673_alignUp_1(zT_344, zT_345);
    ty.size = zT_346;
    ty.alignment = union_align;
    zT_347 = self->registry;
    zT_348 = zT_347->types_items;
    zT_348[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_355 = self->registry;
    zT_356 = zT_355->array_items;
    zT_357 = ty.payload_idx;
    zT_358 = (unsigned int)zT_357;
    zT_359 = zT_356[zT_358];
    ap = zT_359;
    zT_361 = self->registry;
    zT_362 = zT_361->types_items;
    zT_363 = ap.elem;
    zT_364 = (unsigned int)zT_363;
    zT_365 = zT_362[zT_364];
    et = zT_365;
    zT_366 = et.size;
    zT_367 = ap.length;
    ty.size = (unsigned int)(zT_366 * zT_367);
    zT_369 = et.alignment;
    ty.alignment = zT_369;
    zT_370 = self->registry;
    zT_371 = zT_370->types_items;
    zT_371[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_372 = ty.kind;
    if ((int)(zT_372 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_378 = self->registry;
    zT_379 = zT_378->tup_items;
    zT_380 = ty.payload_idx;
    zT_381 = (unsigned int)zT_380;
    zT_382 = zT_379[zT_381];
    tp_2 = zT_382;
    zT_384 = tp_2.elems_start;
    zT_385 = (unsigned int)zT_384;
    estr = zT_385;
    zT_387 = tp_2.elems_count;
    zT_388 = (unsigned int)zT_387;
    ecount = zT_388;
    zT_390 = 0;
    zT_391 = (unsigned int)zT_390;
    offset = zT_391;
    zT_393 = 1;
    zT_394 = (unsigned int)zT_393;
    max_align = zT_394;
    zT_396 = 0;
    zT_397 = (unsigned int)zT_396;
    ei = zT_397;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    if ((int)(ei < ecount)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_400 = self->registry;
    zT_401 = zT_400->xt_items;
    zT_402 = estr + ei;
    zT_403 = zT_401[zT_402];
    elem_tid = zT_403;
    zT_405 = self->registry;
    zT_406 = zT_405->types_items;
    zT_407 = (unsigned int)elem_tid;
    zT_408 = zT_406[zT_407];
    et = zT_408;
    zT_409 = offset;
    zT_410 = et.alignment;
    zT_412 = zF_D2BAC673_alignUp_1(zT_409, zT_410);
    offset = zT_412;
    zT_413 = et.size;
    zT_414 = offset + zT_413;
    offset = zT_414;
    zT_415 = et.alignment;
    if ((int)(zT_415 > max_align)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_420 = offset;
    zT_421 = max_align;
    zT_422 = zF_D2BAC673_alignUp_1(zT_420, zT_421);
    ty.size = zT_422;
    ty.alignment = max_align;
    zT_423 = ty.size;
    if ((int)(zT_423 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_418 = 1;
    zT_419 = ei + zT_418;
    ei = zT_419;
    goto z_bb_75;
    z_bb_79:
    zT_417 = et.alignment;
    max_align = zT_417;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned int)(1);
    goto z_bb_82;
    z_bb_82:
    zT_428 = self->registry;
    zT_429 = zT_428->types_items;
    zT_429[idx] = ty;
    goto z_bb_74;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    zT_65F39959_EU_322 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((int)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_18 = i + (unsigned int)((unsigned int)zT_16);
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_25 = self->alloc;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(type_count * (unsigned int)(4)), (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_34 = zT_32.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    if ((int)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_45 = zi + (unsigned int)((unsigned int)zT_43);
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    if ((int)(ei < zT_49)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    if ((int)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_62 = zT_59 + (unsigned int)((unsigned int)zT_60);
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_67 = ei + (unsigned int)((unsigned int)zT_65);
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    int zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_D155D06D_Type* zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((int)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((int)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((int)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_19 = ti + (unsigned int)((unsigned int)zT_17);
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    self->sorted_len = (unsigned int)(zT_30 + (unsigned int)(1));
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_39 = zT_37 + (unsigned int)((unsigned int)tid);
    zT_39->state = (unsigned char)(2);
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    if ((int)(ei < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    if ((int)(zT_47 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    if ((int)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_74 = ei + (unsigned int)((unsigned int)zT_72);
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    if ((int)(zT_57 > (unsigned int)zT_58)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_64 = zT_61 - (unsigned int)((unsigned int)zT_62);
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    if ((int)(zT_67 == (unsigned int)zT_68)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((int)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    zT_83 = ty.state;
    if ((int)(zT_83 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_120 = 1;
    zT_121 = ci + zT_120;
    ci = zT_121;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_86 = zT_88 > (unsigned int)zT_89;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = self->diag;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_101);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    ty.alignment = (unsigned int)(1);
    ty.state = (unsigned char)(2);
    zT_118 = self->registry;
    zT_119 = zT_118->types_items;
    zT_119[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* fieldEmbedsByValue */
int zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* requiresFullDef */
int zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* layoutFieldNeedsEdge */
int zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    return (int)(0);
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    if ((int)(field_type >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    zT_12 = ft.kind;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    int zT_18;
    unsigned int zT_19;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((int)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_15 = (unsigned int)((unsigned int)fstart) + fi;
    zT_16 = zT_13[zT_15];
    zT_10 = zT_16.type_id;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_19 = fi + zT_18;
    fi = zT_19;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_406493CE_StructPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_406493CE_StructPayload zT_23;
    zT_C890C8CB_TypeResolver* zT_24;
    unsigned int zT_25;
    unsigned short zT_26;
    unsigned int zT_27;
    zT_33EF6BFB_TypeKind zT_30;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_54FF90FA_TaggedUnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_54FF90FA_TaggedUnionPayload zT_40;
    zT_C890C8CB_TypeResolver* zT_41;
    unsigned int zT_42;
    unsigned short zT_43;
    unsigned int zT_44;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_AF9231A2_UnionPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_AF9231A2_UnionPayload zT_57;
    zT_C890C8CB_TypeResolver* zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    unsigned int zT_61;
    zT_33EF6BFB_TypeKind zT_64;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_AF9231A2_UnionPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_AF9231A2_UnionPayload zT_74;
    zT_C890C8CB_TypeResolver* zT_75;
    unsigned int zT_76;
    unsigned short zT_77;
    unsigned int zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    zT_C890C8CB_TypeResolver* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_E834303C_ArrayPayload* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_E834303C_ArrayPayload zT_93;
    zT_33EF6BFB_TypeKind zT_95;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_666DC2E1_TuplePayload* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_666DC2E1_TuplePayload zT_105;
    int zT_107;
    unsigned int zT_108;
    unsigned short zT_109;
    zT_C890C8CB_TypeResolver* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int* zT_116;
    unsigned int zT_117;
    unsigned int zT_119;
    int zT_121;
    unsigned int zT_122;
    zT_33EF6BFB_TypeKind zT_123;
    zT_C890C8CB_TypeResolver* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_0B10E8E9_OptionalPayload* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    zT_0B10E8E9_OptionalPayload zT_135;
    zT_33EF6BFB_TypeKind zT_137;
    zT_C890C8CB_TypeResolver* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_42C2D6BF_EUPayload* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_42C2D6BF_EUPayload zT_149;
    int zT_151;
    unsigned int zT_152;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((int)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    zT_13 = ty.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_151 = 1;
    zT_152 = ti + zT_151;
    ti = zT_152;
    goto z_bb_1;
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->st_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    sp = zT_23;
    zT_24 = self;
    zT_25 = sp.fields_start;
    zT_26 = sp.fields_count;
    zT_27 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_24, zT_25, zT_26, zT_27);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = ty.kind;
    if ((int)(zT_30 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_36 = self->registry;
    zT_37 = zT_36->tu_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    tp = zT_40;
    zT_41 = self;
    zT_42 = tp.fields_start;
    zT_43 = tp.fields_count;
    zT_44 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_47 = ty.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_53 = self->registry;
    zT_54 = zT_53->un_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    up = zT_57;
    zT_58 = self;
    zT_59 = up.fields_start;
    zT_60 = up.fields_count;
    zT_61 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_58, zT_59, zT_60, zT_61);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_64 = ty.kind;
    if ((int)(zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_70 = self->registry;
    zT_71 = zT_70->un_items;
    zT_72 = ty.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    pup = zT_74;
    zT_75 = self;
    zT_76 = pup.fields_start;
    zT_77 = pup.fields_count;
    zT_78 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_75, zT_76, zT_77, zT_78);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_81 = ty.kind;
    if ((int)(zT_81 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_86 = self;
    zT_89 = self->registry;
    zT_90 = zT_89->array_items;
    zT_91 = ty.payload_idx;
    zT_92 = (unsigned int)zT_91;
    zT_93 = zT_90[zT_92];
    zT_87 = zT_93.elem;
    zT_88 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_86, zT_87, zT_88);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_95 = ty.kind;
    if ((int)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_101 = self->registry;
    zT_102 = zT_101->tup_items;
    zT_103 = ty.payload_idx;
    zT_104 = (unsigned int)zT_103;
    zT_105 = zT_102[zT_104];
    tp_1 = zT_105;
    zT_107 = 0;
    zT_108 = (unsigned int)zT_107;
    ei = zT_108;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_123 = ty.kind;
    if ((int)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_27; else goto z_bb_29;
    z_bb_23:
    zT_109 = tp_1.elems_count;
    if ((int)(ei < (unsigned int)((unsigned int)zT_109))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_112 = self;
    zT_115 = self->registry;
    zT_116 = zT_115->xt_items;
    zT_117 = tp_1.elems_start;
    zT_119 = (unsigned int)((unsigned int)zT_117) + ei;
    zT_113 = zT_116[zT_119];
    zT_114 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_112, zT_113, zT_114);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_21;
    z_bb_26:
    zT_121 = 1;
    zT_122 = ei + zT_121;
    ei = zT_122;
    goto z_bb_23;
    z_bb_27:
    zT_128 = self;
    zT_131 = self->registry;
    zT_132 = zT_131->opt_items;
    zT_133 = ty.payload_idx;
    zT_134 = (unsigned int)zT_133;
    zT_135 = zT_132[zT_134];
    zT_129 = zT_135.payload;
    zT_130 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_128, zT_129, zT_130);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_137 = ty.kind;
    if ((int)(zT_137 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_142 = self;
    zT_145 = self->registry;
    zT_146 = zT_145->eu_items;
    zT_147 = ty.payload_idx;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    zT_143 = zT_149.payload;
    zT_144 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_142, zT_143, zT_144);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_28;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    int zT_9;
    int zT_11;
    zT_65F39959_EU_322 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    int zT_26;
    int zT_28;
    zT_65F39959_EU_322 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    int zT_40;
    int zT_42;
    zT_65F39959_EU_322 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    int zT_54;
    int zT_56;
    zT_65F39959_EU_322 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_72;
    zT_3E40CD83_Sand* zT_74;
    int zT_77;
    int zT_79;
    zT_65F39959_EU_322 zT_81 = {0};
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int* zT_86;
    unsigned int zT_88;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_D155D06D_Type* zT_97;
    zT_D155D06D_Type zT_98;
    unsigned char zT_100;
    zT_33EF6BFB_TypeKind zT_101;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_406493CE_StructPayload* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_406493CE_StructPayload zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned short zT_115;
    int zT_118;
    int zT_119;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_2DF01B61_FieldEntry* zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    zT_2DF01B61_FieldEntry zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    int zT_136 = 0;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_3E40CD83_Sand* zT_143;
    unsigned int** zT_144;
    unsigned int** zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    zT_3E40CD83_Sand* zT_164;
    unsigned int** zT_165;
    unsigned int** zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_54FF90FA_TaggedUnionPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_54FF90FA_TaggedUnionPayload zT_192;
    int zT_194;
    unsigned int zT_195;
    unsigned short zT_196;
    int zT_199;
    int zT_200;
    zT_338B7C76_TypeRegistry* zT_203;
    zT_2DF01B61_FieldEntry* zT_204;
    unsigned int zT_205;
    unsigned int zT_207;
    zT_2DF01B61_FieldEntry zT_208;
    unsigned int zT_209;
    zT_338B7C76_TypeRegistry* zT_211;
    zT_D155D06D_Type* zT_212;
    unsigned int zT_213;
    zT_D155D06D_Type zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_217 = 0;
    unsigned char zT_218;
    zT_33EF6BFB_TypeKind zT_219;
    zT_3E40CD83_Sand* zT_224;
    unsigned int** zT_225;
    unsigned int** zT_226;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_239;
    zT_33EF6BFB_TypeKind zT_240;
    zT_3E40CD83_Sand* zT_245;
    unsigned int** zT_246;
    unsigned int** zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_260;
    int zT_261;
    unsigned int zT_262;
    zT_33EF6BFB_TypeKind zT_263;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_AF9231A2_UnionPayload* zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_AF9231A2_UnionPayload zT_273;
    int zT_275;
    unsigned int zT_276;
    unsigned short zT_277;
    int zT_280;
    int zT_281;
    zT_338B7C76_TypeRegistry* zT_284;
    zT_2DF01B61_FieldEntry* zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    zT_2DF01B61_FieldEntry zT_289;
    unsigned int zT_290;
    zT_338B7C76_TypeRegistry* zT_292;
    zT_D155D06D_Type* zT_293;
    unsigned int zT_294;
    zT_D155D06D_Type zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    int zT_298 = 0;
    unsigned char zT_299;
    zT_33EF6BFB_TypeKind zT_300;
    zT_3E40CD83_Sand* zT_305;
    unsigned int** zT_306;
    unsigned int** zT_307;
    unsigned int* zT_308;
    unsigned int zT_309;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_320;
    zT_33EF6BFB_TypeKind zT_321;
    zT_3E40CD83_Sand* zT_326;
    unsigned int** zT_327;
    unsigned int** zT_328;
    unsigned int* zT_329;
    unsigned int zT_330;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_341;
    int zT_342;
    unsigned int zT_343;
    zT_33EF6BFB_TypeKind zT_344;
    zT_338B7C76_TypeRegistry* zT_350;
    zT_AF9231A2_UnionPayload* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_AF9231A2_UnionPayload zT_354;
    int zT_356;
    unsigned int zT_357;
    unsigned short zT_358;
    int zT_361;
    int zT_362;
    zT_338B7C76_TypeRegistry* zT_365;
    zT_2DF01B61_FieldEntry* zT_366;
    unsigned int zT_367;
    unsigned int zT_369;
    zT_2DF01B61_FieldEntry zT_370;
    unsigned int zT_371;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_D155D06D_Type* zT_374;
    unsigned int zT_375;
    zT_D155D06D_Type zT_376;
    zT_33EF6BFB_TypeKind zT_377;
    int zT_379 = 0;
    unsigned char zT_380;
    zT_33EF6BFB_TypeKind zT_381;
    zT_3E40CD83_Sand* zT_386;
    unsigned int** zT_387;
    unsigned int** zT_388;
    unsigned int* zT_389;
    unsigned int zT_390;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_401;
    zT_33EF6BFB_TypeKind zT_402;
    zT_3E40CD83_Sand* zT_407;
    unsigned int** zT_408;
    unsigned int** zT_409;
    unsigned int* zT_410;
    unsigned int zT_411;
    unsigned int zT_415;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_422;
    int zT_423;
    unsigned int zT_424;
    zT_33EF6BFB_TypeKind zT_425;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_E834303C_ArrayPayload* zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    zT_E834303C_ArrayPayload zT_435;
    unsigned int zT_436;
    zT_338B7C76_TypeRegistry* zT_438;
    zT_D155D06D_Type* zT_439;
    unsigned int zT_440;
    zT_D155D06D_Type zT_441;
    zT_33EF6BFB_TypeKind zT_442;
    int zT_444 = 0;
    unsigned char zT_445;
    zT_33EF6BFB_TypeKind zT_446;
    zT_3E40CD83_Sand* zT_451;
    unsigned int** zT_452;
    unsigned int** zT_453;
    unsigned int* zT_454;
    unsigned int zT_455;
    unsigned int zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_466;
    zT_33EF6BFB_TypeKind zT_467;
    zT_3E40CD83_Sand* zT_472;
    unsigned int** zT_473;
    unsigned int** zT_474;
    unsigned int* zT_475;
    unsigned int zT_476;
    unsigned int zT_480;
    unsigned int zT_481;
    unsigned int zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_487;
    zT_33EF6BFB_TypeKind zT_488;
    zT_338B7C76_TypeRegistry* zT_494;
    zT_42C2D6BF_EUPayload* zT_495;
    unsigned int zT_496;
    unsigned int zT_497;
    zT_42C2D6BF_EUPayload zT_498;
    unsigned int zT_499;
    zT_338B7C76_TypeRegistry* zT_501;
    zT_D155D06D_Type* zT_502;
    unsigned int zT_503;
    zT_D155D06D_Type zT_504;
    zT_33EF6BFB_TypeKind zT_505;
    int zT_507 = 0;
    unsigned char zT_508;
    zT_33EF6BFB_TypeKind zT_509;
    zT_3E40CD83_Sand* zT_514;
    unsigned int** zT_515;
    unsigned int** zT_516;
    unsigned int* zT_517;
    unsigned int zT_518;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_525;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_529;
    zT_33EF6BFB_TypeKind zT_530;
    zT_3E40CD83_Sand* zT_535;
    unsigned int** zT_536;
    unsigned int** zT_537;
    unsigned int* zT_538;
    unsigned int zT_539;
    unsigned int zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    unsigned int zT_550;
    zT_33EF6BFB_TypeKind zT_551;
    zT_338B7C76_TypeRegistry* zT_557;
    zT_0B10E8E9_OptionalPayload* zT_558;
    unsigned int zT_559;
    unsigned int zT_560;
    zT_0B10E8E9_OptionalPayload zT_561;
    unsigned int zT_562;
    zT_338B7C76_TypeRegistry* zT_564;
    zT_D155D06D_Type* zT_565;
    unsigned int zT_566;
    zT_D155D06D_Type zT_567;
    zT_33EF6BFB_TypeKind zT_568;
    int zT_570 = 0;
    unsigned char zT_571;
    zT_33EF6BFB_TypeKind zT_572;
    zT_3E40CD83_Sand* zT_577;
    unsigned int** zT_578;
    unsigned int** zT_579;
    unsigned int* zT_580;
    unsigned int zT_581;
    unsigned int zT_585;
    unsigned int zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_592;
    zT_33EF6BFB_TypeKind zT_593;
    zT_3E40CD83_Sand* zT_598;
    unsigned int** zT_599;
    unsigned int** zT_600;
    unsigned int* zT_601;
    unsigned int zT_602;
    unsigned int zT_606;
    unsigned int zT_607;
    unsigned int zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_613;
    unsigned int zT_616;
    unsigned int zT_617;
    unsigned int zT_619;
    int zT_620;
    unsigned int zT_621;
    unsigned int zT_624;
    unsigned int zT_625;
    unsigned int zT_627;
    unsigned int zT_629;
    unsigned int zT_630;
    unsigned int zT_634;
    unsigned int zT_635;
    unsigned int zT_636;
    unsigned char zT_637;
    unsigned char zT_640;
    unsigned int zT_641;
    unsigned int zT_642;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_646;
    zT_3E40CD83_Sand* zT_648;
    int zT_651;
    int zT_653;
    zT_65F39959_EU_322 zT_655 = {0};
    unsigned char zT_656;
    unsigned char* zT_657;
    unsigned int* zT_660;
    unsigned int zT_662;
    int zT_663;
    unsigned int zT_664;
    unsigned char zT_666;
    unsigned int zT_669;
    unsigned int zT_670;
    unsigned int zT_672;
    int zT_673;
    unsigned int zT_674;
    char* zT_676;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_677;
    unsigned int zT_678;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_679;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_681;
    unsigned int zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_684;
    int zT_687;
    unsigned char* zT_688;
    unsigned int zT_689;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_690;
    unsigned int zT_691 = 0;
    unsigned int zT_695;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_696;
    unsigned char* zT_700;
    unsigned int zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    char* zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    unsigned int zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    int zT_708;
    unsigned int zT_709;
    unsigned char zT_711;
    char* zT_715;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_716;
    unsigned int zT_717;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_718;
    char* zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    unsigned int zT_722;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_723;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_728;
    int zT_732;
    unsigned char* zT_733;
    unsigned int zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736 = 0;
    unsigned int zT_740;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_741;
    unsigned char* zT_745;
    unsigned int zT_746;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_747;
    char* zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    unsigned int zT_751;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_752;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_754;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    zT_338B7C76_TypeRegistry* zT_758;
    zT_D155D06D_Type* zT_759;
    zT_D155D06D_Type zT_760;
    zT_33EF6BFB_TypeKind zT_761;
    int zT_765;
    unsigned char* zT_766;
    unsigned int zT_767;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_768;
    unsigned int zT_769 = 0;
    unsigned int zT_773;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_774;
    unsigned char* zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    char* zT_782;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_783;
    unsigned int zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    int zT_786;
    unsigned int zT_787;
    zT_010C8DF0_ClassificationResul zT_788;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_5A26C2ED_Arr_unsigned_char_1 cls_b;
    unsigned int cls_l;
    unsigned int cls_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_5A26C2ED_Arr_unsigned_char_1 ctb;
    unsigned int ctl;
    unsigned int cts;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_5A26C2ED_Arr_unsigned_char_1 ckb;
    unsigned int ckl;
    unsigned int cks;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_11 = 1;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(zT_9 * tl), (unsigned int)((unsigned int)zT_11));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_28 = 4;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)(zT_26 * wp_edge_cap), (unsigned int)((unsigned int)zT_28));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_42 = 4;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)(zT_40 * wp_edge_cap), (unsigned int)((unsigned int)zT_42));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_46 = zT_44.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_56 = 4;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, (unsigned int)(zT_54 * tl), (unsigned int)((unsigned int)zT_56));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_60 = zT_58.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    if ((int)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_72 = 0;
    wp_count = zT_72;
    zT_74 = perm_alloc;
    zT_77 = 4;
    zT_79 = 4;
    zT_81 = zF_1395EB68_sandAlloc(zT_74, (unsigned int)(zT_77 * tl), (unsigned int)((unsigned int)zT_79));
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_70 = whi + zT_69;
    whi = zT_70;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_83 = zT_81.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_83;
    zT_86 = (unsigned int*)wl_raw;
    worklist = zT_86;
    zT_88 = 0;
    wl_head = zT_88;
    zT_90 = 0;
    wl_tail = zT_90;
    zT_92 = 0;
    zT_93 = (unsigned int)zT_92;
    ti = zT_93;
    goto z_bb_20;
    z_bb_20:
    if ((int)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_96 = self->registry;
    zT_97 = zT_96->types_items;
    zT_98 = zT_97[ti];
    ty = zT_98;
    zT_100 = 1;
    is_po = zT_100;
    zT_101 = ty.kind;
    if ((int)(zT_101 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_620 = 1;
    zT_621 = ti + zT_620;
    ti = zT_621;
    goto z_bb_20;
    z_bb_24:
    zT_107 = self->registry;
    zT_108 = zT_107->st_items;
    zT_109 = ty.payload_idx;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zT_108[zT_110];
    sp = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fi = zT_114;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((int)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_182 = ty.kind;
    if ((int)(zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_115 = sp.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_115))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_122 = self->registry;
    zT_123 = zT_122->fe_items;
    zT_124 = sp.fields_start;
    zT_126 = (unsigned int)((unsigned int)zT_124) + fi;
    zT_127 = zT_123[zT_126];
    zT_128 = zT_127.type_id;
    ft_id = zT_128;
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)ft_id;
    zT_133 = zT_131[zT_132];
    ft = zT_133;
    zT_134 = ft.kind;
    zT_136 = zF_A47239A9_fieldEmbedsByValue(zT_134);
    if (zT_136) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_180 = 1;
    zT_181 = fi + zT_180;
    fi = zT_181;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 0;
    zT_118 = is_po != zT_119;
    goto z_bb_33;
    z_bb_32:
    zT_118 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_118) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_137 = 0;
    is_po = zT_137;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_138 = ft.kind;
    if ((int)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_143 = perm_alloc;
    zT_144 = &wp_to;
    zT_145 = &wp_next;
    zT_146 = &wp_edge_cap;
    zT_147 = wp_count;
    zF_25C377BD_growWpEdges(zT_143, zT_144, zT_145, zT_146, zT_147);
    zT_151 = (unsigned int)ti;
    zT_152 = (unsigned int)wp_count;
    wp_to[zT_152] = zT_151;
    zT_153 = (unsigned int)ft_id;
    zT_154 = wp_head[zT_153];
    zT_155 = (unsigned int)wp_count;
    wp_next[zT_155] = zT_154;
    zT_156 = (unsigned int)ft_id;
    wp_head[zT_156] = wp_count;
    zT_158 = wp_count + (unsigned int)(1);
    wp_count = zT_158;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_159 = ft.kind;
    if ((int)(zT_159 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_164 = perm_alloc;
    zT_165 = &wp_to;
    zT_166 = &wp_next;
    zT_167 = &wp_edge_cap;
    zT_168 = wp_count;
    zF_25C377BD_growWpEdges(zT_164, zT_165, zT_166, zT_167, zT_168);
    zT_172 = (unsigned int)ti;
    zT_173 = (unsigned int)wp_count;
    wp_to[zT_173] = zT_172;
    zT_174 = (unsigned int)ft_id;
    zT_175 = wp_head[zT_174];
    zT_176 = (unsigned int)wp_count;
    wp_next[zT_176] = zT_175;
    zT_177 = (unsigned int)ft_id;
    wp_head[zT_177] = wp_count;
    zT_179 = wp_count + (unsigned int)(1);
    wp_count = zT_179;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_188 = self->registry;
    zT_189 = zT_188->tu_items;
    zT_190 = ty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tp = zT_192;
    zT_194 = 0;
    zT_195 = (unsigned int)zT_194;
    fi = zT_195;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_263 = ty.kind;
    if ((int)(zT_263 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_196 = tp.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_196))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_203 = self->registry;
    zT_204 = zT_203->fe_items;
    zT_205 = tp.fields_start;
    zT_207 = (unsigned int)((unsigned int)zT_205) + fi;
    zT_208 = zT_204[zT_207];
    zT_209 = zT_208.type_id;
    ft_id = zT_209;
    zT_211 = self->registry;
    zT_212 = zT_211->types_items;
    zT_213 = (unsigned int)ft_id;
    zT_214 = zT_212[zT_213];
    ft = zT_214;
    zT_215 = ft.kind;
    zT_217 = zF_A47239A9_fieldEmbedsByValue(zT_215);
    if (zT_217) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_261 = 1;
    zT_262 = fi + zT_261;
    fi = zT_262;
    goto z_bb_45;
    z_bb_49:
    zT_200 = 0;
    zT_199 = is_po != zT_200;
    goto z_bb_51;
    z_bb_50:
    zT_199 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_199) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_218 = 0;
    is_po = zT_218;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_219 = ft.kind;
    if ((int)(zT_219 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_224 = perm_alloc;
    zT_225 = &wp_to;
    zT_226 = &wp_next;
    zT_227 = &wp_edge_cap;
    zT_228 = wp_count;
    zF_25C377BD_growWpEdges(zT_224, zT_225, zT_226, zT_227, zT_228);
    zT_232 = (unsigned int)ti;
    zT_233 = (unsigned int)wp_count;
    wp_to[zT_233] = zT_232;
    zT_234 = (unsigned int)ft_id;
    zT_235 = wp_head[zT_234];
    zT_236 = (unsigned int)wp_count;
    wp_next[zT_236] = zT_235;
    zT_237 = (unsigned int)ft_id;
    wp_head[zT_237] = wp_count;
    zT_239 = wp_count + (unsigned int)(1);
    wp_count = zT_239;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_240 = ft.kind;
    if ((int)(zT_240 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_245 = perm_alloc;
    zT_246 = &wp_to;
    zT_247 = &wp_next;
    zT_248 = &wp_edge_cap;
    zT_249 = wp_count;
    zF_25C377BD_growWpEdges(zT_245, zT_246, zT_247, zT_248, zT_249);
    zT_253 = (unsigned int)ti;
    zT_254 = (unsigned int)wp_count;
    wp_to[zT_254] = zT_253;
    zT_255 = (unsigned int)ft_id;
    zT_256 = wp_head[zT_255];
    zT_257 = (unsigned int)wp_count;
    wp_next[zT_257] = zT_256;
    zT_258 = (unsigned int)ft_id;
    wp_head[zT_258] = wp_count;
    zT_260 = wp_count + (unsigned int)(1);
    wp_count = zT_260;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_269 = self->registry;
    zT_270 = zT_269->un_items;
    zT_271 = ty.payload_idx;
    zT_272 = (unsigned int)zT_271;
    zT_273 = zT_270[zT_272];
    up = zT_273;
    zT_275 = 0;
    zT_276 = (unsigned int)zT_275;
    fi = zT_276;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_344 = ty.kind;
    if ((int)(zT_344 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_277 = up.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_277))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_284 = self->registry;
    zT_285 = zT_284->fe_items;
    zT_286 = up.fields_start;
    zT_288 = (unsigned int)((unsigned int)zT_286) + fi;
    zT_289 = zT_285[zT_288];
    zT_290 = zT_289.type_id;
    ft_id = zT_290;
    zT_292 = self->registry;
    zT_293 = zT_292->types_items;
    zT_294 = (unsigned int)ft_id;
    zT_295 = zT_293[zT_294];
    ft = zT_295;
    zT_296 = ft.kind;
    zT_298 = zF_A47239A9_fieldEmbedsByValue(zT_296);
    if (zT_298) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_342 = 1;
    zT_343 = fi + zT_342;
    fi = zT_343;
    goto z_bb_63;
    z_bb_67:
    zT_281 = 0;
    zT_280 = is_po != zT_281;
    goto z_bb_69;
    z_bb_68:
    zT_280 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_280) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_299 = 0;
    is_po = zT_299;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_300 = ft.kind;
    if ((int)(zT_300 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_305 = perm_alloc;
    zT_306 = &wp_to;
    zT_307 = &wp_next;
    zT_308 = &wp_edge_cap;
    zT_309 = wp_count;
    zF_25C377BD_growWpEdges(zT_305, zT_306, zT_307, zT_308, zT_309);
    zT_313 = (unsigned int)ti;
    zT_314 = (unsigned int)wp_count;
    wp_to[zT_314] = zT_313;
    zT_315 = (unsigned int)ft_id;
    zT_316 = wp_head[zT_315];
    zT_317 = (unsigned int)wp_count;
    wp_next[zT_317] = zT_316;
    zT_318 = (unsigned int)ft_id;
    wp_head[zT_318] = wp_count;
    zT_320 = wp_count + (unsigned int)(1);
    wp_count = zT_320;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_321 = ft.kind;
    if ((int)(zT_321 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_326 = perm_alloc;
    zT_327 = &wp_to;
    zT_328 = &wp_next;
    zT_329 = &wp_edge_cap;
    zT_330 = wp_count;
    zF_25C377BD_growWpEdges(zT_326, zT_327, zT_328, zT_329, zT_330);
    zT_334 = (unsigned int)ti;
    zT_335 = (unsigned int)wp_count;
    wp_to[zT_335] = zT_334;
    zT_336 = (unsigned int)ft_id;
    zT_337 = wp_head[zT_336];
    zT_338 = (unsigned int)wp_count;
    wp_next[zT_338] = zT_337;
    zT_339 = (unsigned int)ft_id;
    wp_head[zT_339] = wp_count;
    zT_341 = wp_count + (unsigned int)(1);
    wp_count = zT_341;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_350 = self->registry;
    zT_351 = zT_350->un_items;
    zT_352 = ty.payload_idx;
    zT_353 = (unsigned int)zT_352;
    zT_354 = zT_351[zT_353];
    p_up = zT_354;
    zT_356 = 0;
    zT_357 = (unsigned int)zT_356;
    pfi = zT_357;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_425 = ty.kind;
    if ((int)(zT_425 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_358 = p_up.fields_count;
    if ((int)(pfi < (unsigned int)((unsigned int)zT_358))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_365 = self->registry;
    zT_366 = zT_365->fe_items;
    zT_367 = p_up.fields_start;
    zT_369 = (unsigned int)((unsigned int)zT_367) + pfi;
    zT_370 = zT_366[zT_369];
    zT_371 = zT_370.type_id;
    ft_id = zT_371;
    zT_373 = self->registry;
    zT_374 = zT_373->types_items;
    zT_375 = (unsigned int)ft_id;
    zT_376 = zT_374[zT_375];
    ft = zT_376;
    zT_377 = ft.kind;
    zT_379 = zF_A47239A9_fieldEmbedsByValue(zT_377);
    if (zT_379) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_423 = 1;
    zT_424 = pfi + zT_423;
    pfi = zT_424;
    goto z_bb_81;
    z_bb_85:
    zT_362 = 0;
    zT_361 = is_po != zT_362;
    goto z_bb_87;
    z_bb_86:
    zT_361 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_361) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_380 = 0;
    is_po = zT_380;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_381 = ft.kind;
    if ((int)(zT_381 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_386 = perm_alloc;
    zT_387 = &wp_to;
    zT_388 = &wp_next;
    zT_389 = &wp_edge_cap;
    zT_390 = wp_count;
    zF_25C377BD_growWpEdges(zT_386, zT_387, zT_388, zT_389, zT_390);
    zT_394 = (unsigned int)ti;
    zT_395 = (unsigned int)wp_count;
    wp_to[zT_395] = zT_394;
    zT_396 = (unsigned int)ft_id;
    zT_397 = wp_head[zT_396];
    zT_398 = (unsigned int)wp_count;
    wp_next[zT_398] = zT_397;
    zT_399 = (unsigned int)ft_id;
    wp_head[zT_399] = wp_count;
    zT_401 = wp_count + (unsigned int)(1);
    wp_count = zT_401;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_402 = ft.kind;
    if ((int)(zT_402 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_407 = perm_alloc;
    zT_408 = &wp_to;
    zT_409 = &wp_next;
    zT_410 = &wp_edge_cap;
    zT_411 = wp_count;
    zF_25C377BD_growWpEdges(zT_407, zT_408, zT_409, zT_410, zT_411);
    zT_415 = (unsigned int)ti;
    zT_416 = (unsigned int)wp_count;
    wp_to[zT_416] = zT_415;
    zT_417 = (unsigned int)ft_id;
    zT_418 = wp_head[zT_417];
    zT_419 = (unsigned int)wp_count;
    wp_next[zT_419] = zT_418;
    zT_420 = (unsigned int)ft_id;
    wp_head[zT_420] = wp_count;
    zT_422 = wp_count + (unsigned int)(1);
    wp_count = zT_422;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_431 = self->registry;
    zT_432 = zT_431->array_items;
    zT_433 = ty.payload_idx;
    zT_434 = (unsigned int)zT_433;
    zT_435 = zT_432[zT_434];
    zT_436 = zT_435.elem;
    et = zT_436;
    zT_438 = self->registry;
    zT_439 = zT_438->types_items;
    zT_440 = (unsigned int)et;
    zT_441 = zT_439[zT_440];
    et_ty = zT_441;
    zT_442 = et_ty.kind;
    zT_444 = zF_A47239A9_fieldEmbedsByValue(zT_442);
    if (zT_444) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_488 = ty.kind;
    if ((int)(zT_488 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_445 = 0;
    is_po = zT_445;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_446 = et_ty.kind;
    if ((int)(zT_446 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_451 = perm_alloc;
    zT_452 = &wp_to;
    zT_453 = &wp_next;
    zT_454 = &wp_edge_cap;
    zT_455 = wp_count;
    zF_25C377BD_growWpEdges(zT_451, zT_452, zT_453, zT_454, zT_455);
    zT_459 = (unsigned int)ti;
    zT_460 = (unsigned int)wp_count;
    wp_to[zT_460] = zT_459;
    zT_461 = (unsigned int)et;
    zT_462 = wp_head[zT_461];
    zT_463 = (unsigned int)wp_count;
    wp_next[zT_463] = zT_462;
    zT_464 = (unsigned int)et;
    wp_head[zT_464] = wp_count;
    zT_466 = wp_count + (unsigned int)(1);
    wp_count = zT_466;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_467 = et_ty.kind;
    if ((int)(zT_467 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_472 = perm_alloc;
    zT_473 = &wp_to;
    zT_474 = &wp_next;
    zT_475 = &wp_edge_cap;
    zT_476 = wp_count;
    zF_25C377BD_growWpEdges(zT_472, zT_473, zT_474, zT_475, zT_476);
    zT_480 = (unsigned int)ti;
    zT_481 = (unsigned int)wp_count;
    wp_to[zT_481] = zT_480;
    zT_482 = (unsigned int)et;
    zT_483 = wp_head[zT_482];
    zT_484 = (unsigned int)wp_count;
    wp_next[zT_484] = zT_483;
    zT_485 = (unsigned int)et;
    wp_head[zT_485] = wp_count;
    zT_487 = wp_count + (unsigned int)(1);
    wp_count = zT_487;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_494 = self->registry;
    zT_495 = zT_494->eu_items;
    zT_496 = ty.payload_idx;
    zT_497 = (unsigned int)zT_496;
    zT_498 = zT_495[zT_497];
    zT_499 = zT_498.payload;
    eup = zT_499;
    zT_501 = self->registry;
    zT_502 = zT_501->types_items;
    zT_503 = (unsigned int)eup;
    zT_504 = zT_502[zT_503];
    eup_ty = zT_504;
    zT_505 = eup_ty.kind;
    zT_507 = zF_A47239A9_fieldEmbedsByValue(zT_505);
    if (zT_507) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_551 = ty.kind;
    if ((int)(zT_551 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_508 = 0;
    is_po = zT_508;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_509 = eup_ty.kind;
    if ((int)(zT_509 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_514 = perm_alloc;
    zT_515 = &wp_to;
    zT_516 = &wp_next;
    zT_517 = &wp_edge_cap;
    zT_518 = wp_count;
    zF_25C377BD_growWpEdges(zT_514, zT_515, zT_516, zT_517, zT_518);
    zT_522 = (unsigned int)ti;
    zT_523 = (unsigned int)wp_count;
    wp_to[zT_523] = zT_522;
    zT_524 = (unsigned int)eup;
    zT_525 = wp_head[zT_524];
    zT_526 = (unsigned int)wp_count;
    wp_next[zT_526] = zT_525;
    zT_527 = (unsigned int)eup;
    wp_head[zT_527] = wp_count;
    zT_529 = wp_count + (unsigned int)(1);
    wp_count = zT_529;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_530 = eup_ty.kind;
    if ((int)(zT_530 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_535 = perm_alloc;
    zT_536 = &wp_to;
    zT_537 = &wp_next;
    zT_538 = &wp_edge_cap;
    zT_539 = wp_count;
    zF_25C377BD_growWpEdges(zT_535, zT_536, zT_537, zT_538, zT_539);
    zT_543 = (unsigned int)ti;
    zT_544 = (unsigned int)wp_count;
    wp_to[zT_544] = zT_543;
    zT_545 = (unsigned int)eup;
    zT_546 = wp_head[zT_545];
    zT_547 = (unsigned int)wp_count;
    wp_next[zT_547] = zT_546;
    zT_548 = (unsigned int)eup;
    wp_head[zT_548] = wp_count;
    zT_550 = wp_count + (unsigned int)(1);
    wp_count = zT_550;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_557 = self->registry;
    zT_558 = zT_557->opt_items;
    zT_559 = ty.payload_idx;
    zT_560 = (unsigned int)zT_559;
    zT_561 = zT_558[zT_560];
    zT_562 = zT_561.payload;
    op_p = zT_562;
    zT_564 = self->registry;
    zT_565 = zT_564->types_items;
    zT_566 = (unsigned int)op_p;
    zT_567 = zT_565[zT_566];
    op_ty = zT_567;
    zT_568 = op_ty.kind;
    zT_570 = zF_EA3ED3F3_requiresFullDef(zT_568);
    if (zT_570) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_571 = 0;
    is_po = zT_571;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_572 = op_ty.kind;
    if ((int)(zT_572 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_577 = perm_alloc;
    zT_578 = &wp_to;
    zT_579 = &wp_next;
    zT_580 = &wp_edge_cap;
    zT_581 = wp_count;
    zF_25C377BD_growWpEdges(zT_577, zT_578, zT_579, zT_580, zT_581);
    zT_585 = (unsigned int)ti;
    zT_586 = (unsigned int)wp_count;
    wp_to[zT_586] = zT_585;
    zT_587 = (unsigned int)op_p;
    zT_588 = wp_head[zT_587];
    zT_589 = (unsigned int)wp_count;
    wp_next[zT_589] = zT_588;
    zT_590 = (unsigned int)op_p;
    wp_head[zT_590] = wp_count;
    zT_592 = wp_count + (unsigned int)(1);
    wp_count = zT_592;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_593 = op_ty.kind;
    if ((int)(zT_593 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_598 = perm_alloc;
    zT_599 = &wp_to;
    zT_600 = &wp_next;
    zT_601 = &wp_edge_cap;
    zT_602 = wp_count;
    zF_25C377BD_growWpEdges(zT_598, zT_599, zT_600, zT_601, zT_602);
    zT_606 = (unsigned int)ti;
    zT_607 = (unsigned int)wp_count;
    wp_to[zT_607] = zT_606;
    zT_608 = (unsigned int)op_p;
    zT_609 = wp_head[zT_608];
    zT_610 = (unsigned int)wp_count;
    wp_next[zT_610] = zT_609;
    zT_611 = (unsigned int)op_p;
    wp_head[zT_611] = wp_count;
    zT_613 = wp_count + (unsigned int)(1);
    wp_count = zT_613;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_616 = (unsigned int)ti;
    zT_617 = (unsigned int)wl_tail;
    worklist[zT_617] = zT_616;
    zT_619 = wl_tail + (unsigned int)(1);
    wl_tail = zT_619;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((int)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_624 = (unsigned int)wl_head;
    zT_625 = worklist[zT_624];
    cur = zT_625;
    zT_627 = wl_head + (unsigned int)(1);
    wl_head = zT_627;
    zT_629 = (unsigned int)cur;
    zT_630 = wp_head[zT_629];
    e = zT_630;
    goto z_bb_134;
    z_bb_132:
    zT_648 = perm_alloc;
    zT_651 = 4;
    zT_653 = 4;
    zT_655 = zF_1395EB68_sandAlloc(zT_648, (unsigned int)(zT_651 * tl), (unsigned int)((unsigned int)zT_653));
    zT_656 = zT_655.is_error;
    if (zT_656) goto z_bb_140; else goto z_bb_141;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((int)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_634 = (unsigned int)e;
    zT_635 = wp_to[zT_634];
    parent_tid = zT_635;
    zT_636 = (unsigned int)parent_tid;
    zT_637 = pointer_only[zT_636];
    if ((int)(zT_637 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_640 = 0;
    zT_641 = (unsigned int)parent_tid;
    pointer_only[zT_641] = zT_640;
    zT_642 = (unsigned int)wl_tail;
    worklist[zT_642] = parent_tid;
    zT_644 = wl_tail + (unsigned int)(1);
    wl_tail = zT_644;
    goto z_bb_139;
    z_bb_139:
    zT_645 = (unsigned int)e;
    zT_646 = wp_next[zT_645];
    e = zT_646;
    goto z_bb_137;
    z_bb_140:
    pal_trap();
    z_bb_141:
    zT_657 = zT_655.data.payload;
    goto z_bb_142;
    z_bb_142:
    ids_raw = zT_657;
    zT_660 = (unsigned int*)ids_raw;
    ids = zT_660;
    zT_662 = 0;
    plen = zT_662;
    zT_663 = 0;
    zT_664 = (unsigned int)zT_663;
    ti = zT_664;
    goto z_bb_143;
    z_bb_143:
    if ((int)(ti < tl)) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_666 = pointer_only[ti];
    if ((int)(zT_666 != (unsigned char)(0))) goto z_bb_147; else goto z_bb_148;
    z_bb_145:
    zT_676 = "CLS:c";
    zT_678 = 5;
    zT_677.ptr = zT_676;
    zT_677.len = zT_678;
    cls_m = zT_677;
    zT_679 = cls_m;
    zF_48AC7B3A_markerWrite(zT_679);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_681[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cls_b[_i] = zT_681[_i];
        _i++;
    }
}
    zT_683 = plen;
    zT_687 = 0;
    zT_688 = (unsigned char*)((unsigned char*)cls_b) + zT_687;
    zT_689 = (unsigned int)(10) - zT_687;
    zT_690.ptr = zT_688;
    zT_690.len = zT_689;
    zT_684 = zT_690;
    zT_691 = zF_A7504564_itoa(zT_683, zT_684);
    cls_l = zT_691;
    zT_695 = (unsigned int)(9) - (unsigned int)((unsigned int)cls_l);
    cls_s = zT_695;
    zT_700 = (unsigned char*)((unsigned char*)cls_b) + cls_s;
    zT_701 = (unsigned int)(9) - cls_s;
    zT_702.ptr = zT_700;
    zT_702.len = zT_701;
    zT_696 = zT_702;
    zF_48AC7B3A_markerWrite(zT_696);
    zT_704 = "\n";
    zT_706 = 1;
    zT_705.ptr = zT_704;
    zT_705.len = zT_706;
    cls_nl = zT_705;
    zT_707 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_707);
    zT_708 = 0;
    zT_709 = (unsigned int)zT_708;
    ti = zT_709;
    goto z_bb_149;
    z_bb_146:
    zT_673 = 1;
    zT_674 = ti + zT_673;
    ti = zT_674;
    goto z_bb_143;
    z_bb_147:
    zT_669 = (unsigned int)ti;
    zT_670 = (unsigned int)plen;
    ids[zT_670] = zT_669;
    zT_672 = plen + (unsigned int)(1);
    plen = zT_672;
    goto z_bb_148;
    z_bb_148:
    goto z_bb_146;
    z_bb_149:
    if ((int)(ti < tl)) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_711 = pointer_only[ti];
    if ((int)(zT_711 != (unsigned char)(0))) goto z_bb_153; else goto z_bb_155;
    z_bb_151:
    zT_788.ids = ids;
    zT_788.len = plen;
    return zT_788;
    z_bb_152:
    zT_786 = 1;
    zT_787 = ti + zT_786;
    ti = zT_787;
    goto z_bb_149;
    z_bb_153:
    zT_715 = "CLS:p";
    zT_717 = 5;
    zT_716.ptr = zT_715;
    zT_716.len = zT_717;
    pfx = zT_716;
    zT_718 = pfx;
    zF_48AC7B3A_markerWrite(zT_718);
    goto z_bb_154;
    z_bb_154:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_725[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ctb[_i] = zT_725[_i];
        _i++;
    }
}
    zT_732 = 0;
    zT_733 = (unsigned char*)((unsigned char*)ctb) + zT_732;
    zT_734 = (unsigned int)(10) - zT_732;
    zT_735.ptr = zT_733;
    zT_735.len = zT_734;
    zT_728 = zT_735;
    zT_736 = zF_A7504564_itoa((unsigned int)((unsigned int)ti), zT_728);
    ctl = zT_736;
    zT_740 = (unsigned int)(9) - (unsigned int)((unsigned int)ctl);
    cts = zT_740;
    zT_745 = (unsigned char*)((unsigned char*)ctb) + cts;
    zT_746 = (unsigned int)(9) - cts;
    zT_747.ptr = zT_745;
    zT_747.len = zT_746;
    zT_741 = zT_747;
    zF_48AC7B3A_markerWrite(zT_741);
    zT_749 = "k";
    zT_751 = 1;
    zT_750.ptr = zT_749;
    zT_750.len = zT_751;
    ck = zT_750;
    zT_752 = ck;
    zF_48AC7B3A_markerWrite(zT_752);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_754[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ckb[_i] = zT_754[_i];
        _i++;
    }
}
    zT_758 = self->registry;
    zT_759 = zT_758->types_items;
    zT_760 = zT_759[ti];
    zT_761 = zT_760.kind;
    zT_765 = 0;
    zT_766 = (unsigned char*)((unsigned char*)ckb) + zT_765;
    zT_767 = (unsigned int)(10) - zT_765;
    zT_768.ptr = zT_766;
    zT_768.len = zT_767;
    zT_757 = zT_768;
    zT_769 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_761), zT_757);
    ckl = zT_769;
    zT_773 = (unsigned int)(9) - (unsigned int)((unsigned int)ckl);
    cks = zT_773;
    zT_778 = (unsigned char*)((unsigned char*)ckb) + cks;
    zT_779 = (unsigned int)(9) - cks;
    zT_780.ptr = zT_778;
    zT_780.len = zT_779;
    zT_774 = zT_780;
    zF_48AC7B3A_markerWrite(zT_774);
    zT_782 = "\n";
    zT_784 = 1;
    zT_783.ptr = zT_782;
    zT_783.len = zT_784;
    cnl = zT_783;
    zT_785 = cnl;
    zF_48AC7B3A_markerWrite(zT_785);
    goto z_bb_152;
    z_bb_155:
    zT_720 = "CLS:v";
    zT_722 = 5;
    zT_721.ptr = zT_720;
    zT_721.len = zT_722;
    pfx = zT_721;
    zT_723 = pfx;
    zF_48AC7B3A_markerWrite(zT_723);
    goto z_bb_154;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_14;
    int zT_17;
    int zT_19;
    zT_65F39959_EU_322 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_3E40CD83_Sand* zT_26;
    int zT_29;
    int zT_31;
    zT_65F39959_EU_322 zT_33 = {0};
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned int* zT_38;
    unsigned int* zT_40;
    int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* new_to_raw;
    unsigned char* new_nx_raw;
    unsigned int* new_to;
    unsigned int* new_nx;
    unsigned int ci;
    zT_6 = *cap_ptr;
    if ((int)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap_ptr;
    old_cap = zT_9;
    zT_11 = 2;
    zT_12 = old_cap * zT_11;
    new_cap = zT_12;
    zT_14 = perm_a;
    zT_17 = 4;
    zT_19 = 4;
    zT_21 = zF_1395EB68_sandAlloc(zT_14, (unsigned int)(zT_17 * new_cap), (unsigned int)((unsigned int)zT_19));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_23 = zT_21.data.payload;
    goto z_bb_5;
    z_bb_5:
    new_to_raw = zT_23;
    zT_26 = perm_a;
    zT_29 = 4;
    zT_31 = 4;
    zT_33 = zF_1395EB68_sandAlloc(zT_26, (unsigned int)(zT_29 * new_cap), (unsigned int)((unsigned int)zT_31));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    new_nx_raw = zT_35;
    zT_38 = (unsigned int*)new_to_raw;
    new_to = zT_38;
    zT_40 = (unsigned int*)new_nx_raw;
    new_nx = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_9;
    z_bb_9:
    if ((int)(ci < (unsigned int)((unsigned int)count))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *wp_to_ptr;
    zT_47 = zT_46[ci];
    new_to[ci] = zT_47;
    zT_48 = *wp_next_ptr;
    zT_49 = zT_48[ci];
    new_nx[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *wp_to_ptr = new_to;
    *wp_next_ptr = new_nx;
    *cap_ptr = new_cap;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    goto z_bb_9;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_18 = 0;
    zT_8143F551_AstKind zT_20;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_31;
    unsigned int zT_32;
    zT_D7876732_Opt_823 zT_33 = {0};
    unsigned char zT_34;
    unsigned short zT_36;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_22A7C88B_AstNode zT_46 = {0};
    unsigned int zT_47;
    int zT_48;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_52;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_D7876732_Opt_823 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_678B9A72_astStoreIntValue(zT_15, zT_16);
    return (unsigned int)((unsigned int)zT_18);
    z_bb_4:
    zT_20 = node.kind;
    if ((int)(zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = env->store;
    zT_27 = node_idx;
    zT_29 = zF_53458827_astStoreIdentifier(zT_26, zT_27);
    name_id = zT_29;
    zT_31 = env;
    zT_32 = name_id;
    zT_33 = zF_04FED007_symbolLookupAllModu(zT_31, zT_32);
    c_sym = zT_33;
    zT_34 = c_sym.has_value;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned int)(4294967295u);
    z_bb_7:
    cs = c_sym.value;
    zT_36 = cs->flags;
    if ((int)((unsigned short)(zT_36 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_42 = env->store;
    zT_43 = cs->decl_node;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    c_decl = zT_46;
    zT_47 = c_decl.child_1;
    zT_48 = 0;
    if ((int)(zT_47 != (unsigned int)zT_48)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_50 = env;
    zT_52 = c_decl.child_1;
    env = zT_50;
    node_idx = zT_52;
    goto z_bb_0;
    z_bb_12:
    goto z_bb_10;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_44E16D78_Opt_7 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_18 = 0;
    zT_C69B2266_i64 zT_19;
    zT_44E16D78_Opt_7 zT_20;
    zT_8143F551_AstKind zT_21;
    unsigned int zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_30;
    unsigned int zT_31;
    zT_44E16D78_Opt_7 zT_33 = {0};
    unsigned char zT_34;
    zT_79FAE712_u64 zT_37;
    zT_79FAE712_u64 zT_40;
    zT_C69B2266_i64 zT_41;
    zT_44E16D78_Opt_7 zT_42;
    zT_44E16D78_Opt_7 zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_55;
    unsigned int zT_56;
    zT_D7876732_Opt_823 zT_57 = {0};
    unsigned char zT_58;
    unsigned short zT_60;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_70 = {0};
    unsigned int zT_71;
    int zT_72;
    zT_ABC1EBBE_TypeResolveEnv* zT_74;
    unsigned int zT_76;
    zT_44E16D78_Opt_7 zT_78 = {0};
    zT_22A7C88B_AstNode node;
    zT_44E16D78_Opt_7 nv_opt;
    zT_C69B2266_i64 nv;
    zT_79FAE712_u64 as_u;
    zT_79FAE712_u64 neg_u;
    unsigned int name_id;
    zT_D7876732_Opt_823 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_678B9A72_astStoreIntValue(zT_15, zT_16);
    zT_19 = (zT_C69B2266_i64)zT_18;
    zT_20.has_value = 1;
    zT_20.value = zT_19;
    return zT_20;
    z_bb_4:
    zT_21 = node.kind;
    if ((int)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = node.child_0;
    if ((int)(zT_26 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_44 = node.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_7:
    zT_30 = env;
    zT_31 = node.child_0;
    zT_33 = zF_FFFAAD16_evalConstI64Full(zT_30, zT_31);
    nv_opt = zT_33;
    zT_34 = nv_opt.has_value;
    if (zT_34) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_43.has_value = 0;
    return zT_43;
    z_bb_9:
    nv = nv_opt.value;
    zT_37 = (zT_79FAE712_u64)nv;
    as_u = zT_37;
    zT_40 = (zT_79FAE712_u64)(0) - as_u;
    neg_u = zT_40;
    zT_41 = (zT_C69B2266_i64)neg_u;
    zT_42.has_value = 1;
    zT_42.value = zT_41;
    return zT_42;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_50 = env->store;
    zT_51 = node_idx;
    zT_53 = zF_53458827_astStoreIdentifier(zT_50, zT_51);
    name_id = zT_53;
    zT_55 = env;
    zT_56 = name_id;
    zT_57 = zF_04FED007_symbolLookupAllModu(zT_55, zT_56);
    c_sym = zT_57;
    zT_58 = c_sym.has_value;
    if (zT_58) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_78.has_value = 0;
    return zT_78;
    z_bb_13:
    cs = c_sym.value;
    zT_60 = cs->flags;
    if ((int)((unsigned short)(zT_60 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_66 = env->store;
    zT_67 = cs->decl_node;
    zT_70 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    c_decl = zT_70;
    zT_71 = c_decl.child_1;
    zT_72 = 0;
    if ((int)(zT_71 != (unsigned int)zT_72)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_74 = env;
    zT_76 = c_decl.child_1;
    env = zT_74;
    node_idx = zT_76;
    goto z_bb_0;
    z_bb_18:
    goto z_bb_16;
}

/* symbolLookupAllModules */
zT_D7876732_Opt_823 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_D7876732_Opt_823 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_D7876732_Opt_823 zT_19 = {0};
    unsigned int si;
    zT_D7876732_Opt_823 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((int)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_4:
    zT_17 = 1;
    zT_18 = si + zT_17;
    si = zT_18;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_79FAE712_u64 zT_63;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_BAEE192E_Opt_10 zT_73 = {0};
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_90;
    unsigned int zT_91;
    zT_79FAE712_u64 zT_99;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_79FAE712_u64 zT_102;
    zT_BAEE192E_Opt_10 zT_104 = {0};
    unsigned char zT_105;
    int zT_107;
    unsigned int zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_3D7259E2_SymbolRegistry* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_D7876732_Opt_823 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_126;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_3D7259E2_SymbolRegistry* zT_133;
    unsigned int zT_134;
    zT_3D7259E2_SymbolRegistry* zT_138;
    unsigned int zT_140;
    zT_D7876732_Opt_823 zT_143 = {0};
    unsigned char zT_144;
    unsigned int zT_146;
    char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    int* zT_169;
    unsigned int zT_171 = 0;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_177 = 0;
    zT_8143F551_AstKind zT_179;
    zT_5826BFC7_Arr_unsigned_char_1 zT_185;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    int zT_191;
    unsigned char* zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195 = 0;
    unsigned int zT_199;
    zT_4428DEE2_Arr_unsigned_char_2 zT_201;
    unsigned char zT_202;
    int zT_203;
    unsigned char zT_204;
    int zT_205;
    unsigned char zT_206;
    int zT_207;
    unsigned char zT_208;
    int zT_209;
    unsigned char zT_210;
    int zT_211;
    int zT_213;
    unsigned int zT_214;
    unsigned int zT_217;
    unsigned char zT_218;
    unsigned int zT_220;
    int zT_221;
    unsigned int zT_222;
    unsigned int zT_226;
    zT_D3EB6303_StringInterner* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    int zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237 = 0;
    zT_338B7C76_TypeRegistry* zT_239;
    zT_BAEE192E_Opt_10 zT_243 = {0};
    unsigned char zT_244;
    zT_338B7C76_TypeRegistry* zT_247;
    unsigned int zT_249;
    unsigned int zT_256 = 0;
    unsigned char zT_257;
    zT_338B7C76_TypeRegistry* zT_262;
    unsigned int zT_263;
    zT_6B0A7D14_AstStore* zT_265;
    unsigned int zT_266;
    unsigned int zT_268 = 0;
    zT_6B0A7D14_AstStore* zT_272;
    unsigned int zT_273;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_275 = {0};
    zT_9D2DA37C_Arr_unsigned_int_32 zT_277;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_279;
    int zT_281;
    unsigned int zT_282;
    int zT_284;
    unsigned int zT_285;
    unsigned int zT_287;
    int zT_289;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_294;
    unsigned int* zT_296;
    zT_22A7C88B_AstNode zT_298 = {0};
    zT_8143F551_AstKind zT_299;
    zT_ABC1EBBE_TypeResolveEnv* zT_305;
    unsigned int zT_306;
    unsigned int zT_311 = 0;
    zT_6B0A7D14_AstStore* zT_312;
    unsigned int zT_313;
    unsigned int* zT_315;
    unsigned int zT_317 = 0;
    int zT_318;
    unsigned int zT_320;
    int zT_321;
    unsigned int zT_322;
    zT_338B7C76_TypeRegistry* zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    int zT_330;
    unsigned int zT_331;
    zT_338B7C76_TypeRegistry* zT_333;
    zT_2DF01B61_FieldEntry zT_334;
    zT_2DF01B61_FieldEntry zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    int zT_340;
    unsigned int zT_341;
    zT_338B7C76_TypeRegistry* zT_342;
    zT_406493CE_StructPayload zT_343;
    zT_406493CE_StructPayload zT_345;
    unsigned int zT_346;
    unsigned short zT_347;
    zT_338B7C76_TypeRegistry* zT_349;
    unsigned int zT_350;
    unsigned int zT_353;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_D155D06D_Type* zT_356;
    unsigned int zT_357;
    zT_D155D06D_Type zT_358;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_D155D06D_Type* zT_360;
    unsigned int zT_361;
    zT_8143F551_AstKind zT_362;
    unsigned char zT_368;
    zT_ABC1EBBE_TypeResolveEnv* zT_370;
    unsigned int zT_371;
    unsigned int zT_376 = 0;
    zT_6B0A7D14_AstStore* zT_380;
    unsigned int zT_381;
    zT_22A7C88B_AstNode zT_384 = {0};
    zT_8143F551_AstKind zT_385;
    zT_6B0A7D14_AstStore* zT_391;
    unsigned int zT_392;
    unsigned int zT_395 = 0;
    int zT_397;
    unsigned int zT_398;
    zT_3D7259E2_SymbolRegistry* zT_399;
    unsigned int zT_400;
    zT_3D7259E2_SymbolRegistry* zT_404;
    unsigned int zT_406;
    zT_D7876732_Opt_823 zT_409 = {0};
    unsigned char zT_410;
    zT_3C598AEF_SymbolKind zT_412;
    unsigned int zT_418;
    zT_3D7259E2_SymbolRegistry* zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    zT_6B0A7D14_AstStore* zT_424;
    unsigned int zT_425;
    unsigned int zT_427 = 0;
    zT_D7876732_Opt_823 zT_428 = {0};
    unsigned char zT_429;
    unsigned int zT_431;
    unsigned char zT_434;
    char* zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    unsigned int zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440;
    unsigned int zT_442;
    int zT_443;
    unsigned int zT_444;
    char* zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_447;
    unsigned int zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned int zT_450;
    zT_338B7C76_TypeRegistry* zT_454;
    zT_D155D06D_Type* zT_455;
    unsigned int zT_456;
    zT_D155D06D_Type zT_457;
    zT_33EF6BFB_TypeKind zT_458;
    unsigned int zT_464;
    zT_3D7259E2_SymbolRegistry* zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    zT_6B0A7D14_AstStore* zT_470;
    unsigned int zT_471;
    unsigned int zT_473 = 0;
    zT_D7876732_Opt_823 zT_474 = {0};
    unsigned char zT_475;
    unsigned int zT_477;
    unsigned char zT_480;
    char* zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    unsigned int zT_488;
    char* zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned int zT_494;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    unsigned int zT_496;
    zT_8143F551_AstKind zT_497;
    zT_939EE900_Arr_unsigned_int_1 zT_503;
    zT_338B7C76_TypeRegistry* zT_504;
    unsigned int zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    zT_EDD37787_Arr_unsigned_short_ zT_509;
    unsigned short zT_510;
    unsigned int zT_511;
    zT_6B0A7D14_AstStore* zT_512;
    unsigned int zT_513;
    unsigned int zT_515 = 0;
    zT_6B0A7D14_AstStore* zT_519;
    unsigned int zT_520;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_522 = {0};
    unsigned int zT_524;
    unsigned short zT_525;
    int zT_526;
    int zT_528;
    unsigned int zT_529;
    unsigned int zT_531;
    zT_338B7C76_TypeRegistry* zT_533;
    unsigned int zT_534;
    unsigned int* zT_536;
    int zT_538;
    unsigned int zT_539;
    zT_338B7C76_TypeRegistry* zT_540;
    unsigned int zT_541;
    unsigned short zT_542;
    int zT_544;
    int zT_546;
    unsigned int zT_548 = 0;
    zT_8143F551_AstKind zT_549;
    zT_ABC1EBBE_TypeResolveEnv* zT_555;
    unsigned int zT_556;
    unsigned int zT_561 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_566;
    unsigned int zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    int zT_570;
    zT_ABC1EBBE_TypeResolveEnv* zT_573;
    unsigned int zT_574;
    unsigned int zT_579 = 0;
    int zT_583;
    unsigned int zT_584;
    int zT_585;
    zT_338B7C76_TypeRegistry* zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    int zT_590;
    unsigned int zT_592 = 0;
    zT_8143F551_AstKind zT_593;
    zT_939EE900_Arr_unsigned_int_1 zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned int zT_602;
    int zT_603;
    unsigned int zT_604;
    int zT_605;
    zT_ABC1EBBE_TypeResolveEnv* zT_607;
    unsigned int zT_608;
    unsigned int zT_613 = 0;
    int zT_614;
    char* zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    unsigned int zT_618;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_619;
    unsigned int zT_620;
    int zT_621;
    int zT_623;
    unsigned int zT_624;
    zT_99292002_Arr_unsigned_int_16 zT_629;
    unsigned int zT_631;
    zT_6B0A7D14_AstStore* zT_632;
    unsigned int zT_633;
    unsigned int zT_635 = 0;
    zT_6B0A7D14_AstStore* zT_639;
    unsigned int zT_640;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_642 = {0};
    unsigned int zT_644;
    unsigned int zT_646;
    int zT_648;
    zT_ABC1EBBE_TypeResolveEnv* zT_652;
    unsigned int zT_653;
    unsigned int* zT_655;
    unsigned int zT_659 = 0;
    unsigned int zT_664;
    unsigned int zT_666;
    zT_443A2803_Arr_unsigned_char_9 zT_668;
    unsigned int zT_670;
    char* zT_672;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_673;
    unsigned int zT_674;
    unsigned int zT_676;
    unsigned int zT_678;
    int zT_680;
    unsigned char* zT_683;
    unsigned char zT_684;
    unsigned int zT_686;
    unsigned int zT_688;
    zT_5826BFC7_Arr_unsigned_char_1 zT_690;
    unsigned int zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_693;
    int zT_694;
    int zT_698;
    unsigned char* zT_699;
    unsigned int zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_701;
    unsigned int zT_702 = 0;
    unsigned int zT_706;
    int zT_709;
    unsigned char zT_712;
    unsigned int zT_714;
    unsigned int zT_716;
    unsigned int zT_718;
    int zT_720;
    unsigned char zT_725;
    unsigned int zT_727;
    zT_5826BFC7_Arr_unsigned_char_1 zT_729;
    unsigned int zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    int zT_736;
    unsigned char* zT_737;
    unsigned int zT_738;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_739;
    unsigned int zT_740 = 0;
    unsigned int zT_744;
    int zT_747;
    unsigned char zT_750;
    unsigned int zT_752;
    unsigned int zT_754;
    unsigned int zT_756;
    zT_D3EB6303_StringInterner* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    int zT_763;
    unsigned char* zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767 = 0;
    zT_338B7C76_TypeRegistry* zT_769;
    unsigned int zT_770;
    unsigned int zT_771;
    unsigned int zT_773;
    zT_338B7C76_TypeRegistry* zT_775;
    unsigned int zT_776;
    unsigned int zT_780;
    zT_338B7C76_TypeRegistry* zT_782;
    unsigned int zT_783;
    unsigned int zT_789;
    int zT_796;
    unsigned int zT_798 = 0;
    char* zT_800;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_801;
    unsigned int zT_802;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_803;
    unsigned int zT_804;
    zT_338B7C76_TypeRegistry* zT_805;
    unsigned int zT_806;
    zT_338B7C76_TypeRegistry* zT_808;
    unsigned int zT_809;
    unsigned int zT_813 = 0;
    unsigned int zT_814;
    int zT_815;
    zT_ABC1EBBE_TypeResolveEnv* zT_818;
    unsigned int zT_819;
    unsigned int zT_824 = 0;
    zT_8143F551_AstKind zT_828;
    int zT_833;
    zT_8143F551_AstKind zT_834;
    char* zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    unsigned int zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_843;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_845;
    unsigned int zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    int zT_851;
    unsigned char* zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned int zT_855 = 0;
    unsigned int zT_859;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_860;
    unsigned char* zT_864;
    unsigned int zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_866;
    char* zT_868;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    unsigned int zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_873;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_876;
    zT_8143F551_AstKind zT_877;
    int zT_881;
    unsigned char* zT_882;
    unsigned int zT_883;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_884;
    unsigned int zT_885 = 0;
    unsigned int zT_889;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_890;
    unsigned char* zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    char* zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    unsigned int zT_900;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_901;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_903;
    unsigned int zT_905;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_906;
    int zT_909;
    unsigned char* zT_910;
    unsigned int zT_911;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_912;
    unsigned int zT_913 = 0;
    unsigned int zT_917;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_918;
    unsigned char* zT_922;
    unsigned int zT_923;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_924;
    unsigned char zT_926;
    int zT_930;
    unsigned char zT_932;
    int zT_936;
    zT_8143F551_AstKind zT_937;
    zT_338B7C76_TypeRegistry* zT_943;
    unsigned int zT_944;
    int zT_945;
    int zT_946;
    unsigned int zT_948 = 0;
    char* zT_950;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_951;
    unsigned int zT_952;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_953;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_955;
    unsigned int zT_957;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_958;
    int zT_961;
    unsigned char* zT_962;
    unsigned int zT_963;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_964;
    unsigned int zT_965 = 0;
    unsigned int zT_969;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_970;
    unsigned char* zT_974;
    unsigned int zT_975;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_976;
    char* zT_978;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_979;
    unsigned int zT_980;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_981;
    zT_338B7C76_TypeRegistry* zT_983;
    unsigned int zT_984;
    int zT_985;
    int zT_986;
    unsigned int zT_988 = 0;
    char* zT_990;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_991;
    unsigned int zT_992;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_993;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_995;
    unsigned int zT_997;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_998;
    int zT_1001;
    unsigned char* zT_1002;
    unsigned int zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1005 = 0;
    unsigned int zT_1009;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1010;
    unsigned char* zT_1014;
    unsigned int zT_1015;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1016;
    char* zT_1018;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1019;
    unsigned int zT_1020;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1021;
    zT_8143F551_AstKind zT_1022;
    unsigned char zT_1028;
    int zT_1032;
    zT_338B7C76_TypeRegistry* zT_1034;
    unsigned int zT_1035;
    int zT_1036;
    unsigned int zT_1038 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_1040;
    unsigned int zT_1042;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1043;
    int zT_1046;
    unsigned char* zT_1047;
    unsigned int zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1049;
    unsigned int zT_1050 = 0;
    unsigned int zT_1054;
    char* zT_1056;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1057;
    unsigned int zT_1058;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1059;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1060;
    unsigned char* zT_1064;
    unsigned int zT_1065;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1066;
    zT_4028D896_Arr_unsigned_char_2 zT_1068;
    unsigned int zT_1070;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1071;
    int zT_1074;
    unsigned char* zT_1075;
    unsigned int zT_1076;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1077;
    unsigned int zT_1078 = 0;
    unsigned int zT_1082;
    char* zT_1084;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1085;
    unsigned int zT_1086;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1087;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1088;
    unsigned char* zT_1092;
    unsigned int zT_1093;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1094;
    char* zT_1096;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1097;
    unsigned int zT_1098;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1099;
    zT_8143F551_AstKind zT_1100;
    char* zT_1106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1109;
    unsigned int zT_1110;
    zT_338B7C76_TypeRegistry* zT_1112;
    unsigned int zT_1113;
    unsigned int zT_1115 = 0;
    char* zT_1117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1118;
    unsigned int zT_1119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1120;
    unsigned int zT_1121;
    zT_8143F551_AstKind zT_1122;
    char* zT_1128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1129;
    unsigned int zT_1130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1131;
    char* zT_1133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1134;
    unsigned int zT_1135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1136;
    zT_4028D896_Arr_unsigned_char_2 zT_1138;
    unsigned int zT_1140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1141;
    int zT_1144;
    unsigned char* zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1147;
    unsigned int zT_1148 = 0;
    unsigned int zT_1152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1153;
    unsigned char* zT_1157;
    unsigned int zT_1158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1159;
    unsigned int zT_1160;
    int zT_1161;
    zT_6B0A7D14_AstStore* zT_1164;
    unsigned int zT_1165;
    zT_22A7C88B_AstNode zT_1168 = {0};
    unsigned int zT_1170;
    int zT_1172;
    zT_8143F551_AstKind zT_1173;
    zT_6B0A7D14_AstStore* zT_1178;
    unsigned int zT_1179;
    zT_79FAE712_u64 zT_1182 = 0;
    unsigned int zT_1183;
    int zT_1184;
    zT_8143F551_AstKind zT_1185;
    int zT_1190;
    zT_8143F551_AstKind zT_1191;
    zT_ABC1EBBE_TypeResolveEnv* zT_1197;
    unsigned int zT_1198;
    unsigned int zT_1200 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1202;
    unsigned int zT_1203;
    unsigned int zT_1205 = 0;
    int zT_1208;
    int zT_1211;
    zT_8143F551_AstKind zT_1212;
    unsigned int zT_1217;
    unsigned int zT_1218;
    zT_8143F551_AstKind zT_1219;
    int zT_1224;
    zT_8143F551_AstKind zT_1225;
    int zT_1230;
    zT_8143F551_AstKind zT_1231;
    zT_ABC1EBBE_TypeResolveEnv* zT_1237;
    unsigned int zT_1238;
    unsigned int zT_1240 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1242;
    unsigned int zT_1243;
    unsigned int zT_1245 = 0;
    int zT_1248;
    int zT_1251;
    int zT_1254;
    zT_8143F551_AstKind zT_1255;
    unsigned int zT_1260;
    zT_8143F551_AstKind zT_1261;
    unsigned int zT_1266;
    unsigned int zT_1267;
    zT_8143F551_AstKind zT_1268;
    zT_ABC1EBBE_TypeResolveEnv* zT_1274;
    unsigned int zT_1275;
    unsigned int zT_1277 = 0;
    int zT_1280;
    char* zT_1282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1283;
    unsigned int zT_1284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1285;
    zT_4028D896_Arr_unsigned_char_2 zT_1287;
    unsigned int zT_1289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1290;
    int zT_1293;
    unsigned char* zT_1294;
    unsigned int zT_1295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1296;
    unsigned int zT_1297 = 0;
    unsigned int zT_1301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1302;
    unsigned char* zT_1306;
    unsigned int zT_1307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1308;
    zT_338B7C76_TypeRegistry* zT_1310;
    unsigned int zT_1311;
    unsigned int zT_1312;
    unsigned int zT_1314 = 0;
    char* zT_1316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1317;
    unsigned int zT_1318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1319;
    zT_4028D896_Arr_unsigned_char_2 zT_1321;
    unsigned int zT_1323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1324;
    int zT_1327;
    unsigned char* zT_1328;
    unsigned int zT_1329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1330;
    unsigned int zT_1331 = 0;
    unsigned int zT_1335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1336;
    unsigned char* zT_1340;
    unsigned int zT_1341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1342;
    char* zT_1346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1347;
    unsigned int zT_1348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1349;
    char* zT_1351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1352;
    unsigned int zT_1353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1354;
    char* zT_1357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1358;
    unsigned int zT_1359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1360;
    unsigned int zT_1361;
    char* zT_1363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1364;
    unsigned int zT_1365;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1366;
    zT_8143F551_AstKind zT_1368;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    zT_D7876732_Opt_823 sym_cur;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D7876732_Opt_823 sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    int arbu;
    unsigned int arbw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_5826BFC7_Arr_unsigned_char_1 sd_id;
    unsigned int sd_idl;
    unsigned int sd_ids;
    zT_4428DEE2_Arr_unsigned_char_2 sd_nm;
    unsigned int sd_di;
    unsigned int sd_namelen;
    unsigned int sd_name_id;
    zT_BAEE192E_Opt_10 sd_existing;
    unsigned int se;
    unsigned int sd_tid;
    zT_3CB0179A_Slice_zT_05F374B1_u sd_children;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_ft;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_D7876732_Opt_823 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_D7876732_Opt_823 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    zT_3CB0179A_Slice_zT_05F374B1_u esd_children;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    zT_3CB0179A_Slice_zT_05F374B1_u fnt_extra;
    unsigned int fnt_i;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    unsigned int fnt_pt;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptib;
    unsigned int ptil;
    unsigned int ptis;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptkb;
    unsigned int ptkl;
    unsigned int ptks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptcb;
    unsigned int ptcl;
    unsigned int ptcs;
    int is_const;
    int is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb;
    unsigned int ppl;
    unsigned int pps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb2;
    unsigned int ppl2;
    unsigned int pps2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_4028D896_Arr_unsigned_char_2 sl_e;
    unsigned int sl_el;
    unsigned int sl_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_4028D896_Arr_unsigned_char_2 sl_r;
    unsigned int sl_rl;
    unsigned int sl_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_4028D896_Arr_unsigned_char_2 t1b;
    unsigned int t1l;
    unsigned int t1s;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    int arr_resolved;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    zT_4028D896_Arr_unsigned_char_2 t2b;
    unsigned int t2l;
    unsigned int t2s;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int al;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    zT_4028D896_Arr_unsigned_char_2 t3b;
    unsigned int t3l;
    unsigned int t3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    if ((int)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((int)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = env->store;
    zT_32 = node_idx;
    zT_34 = zF_53458827_astStoreIdentifier(zT_31, zT_32);
    name_id = zT_34;
    zT_36 = "OPTVOID:id";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    opm4_m = zT_37;
    zT_39 = opm4_m;
    zT_40 = name_id;
    zF_C914CB83_markerWriteInt(zT_39, zT_40);
    zT_42 = env->interner;
    zT_43 = name_id;
    zT_45 = zF_9134020D_stringInternerGet(zT_42, zT_43);
    text = zT_45;
    zT_47 = env->interner;
    zT_48 = text;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    canonical_id = zT_50;
    zT_51 = env->module_id;
    if ((int)(zT_51 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_179 = node.kind;
    if ((int)(zT_179 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_55 = env->module_id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_55) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck_cur = zT_60;
    zT_62 = env->typereg;
    zT_63 = ck_cur;
    zT_65 = zF_0EB68360_nameCacheGet(zT_62, zT_63);
    tc_cur = zT_65;
    zT_66 = tc_cur.has_value;
    if (zT_66) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_69 = env->typereg;
    zT_73 = zF_0EB68360_nameCacheGet(zT_69, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_73;
    zT_75 = "OPTVOID:nc";
    zT_77 = 10;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    opnc_m = zT_76;
    zT_78 = opnc_m;
    zT_79 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_78, zT_79);
    zT_80 = tid.has_value;
    if (zT_80) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    t = tc_cur.value;
    return t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    t = tid.value;
    return t;
    z_bb_10:
    zT_83 = "NF";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    nf = zT_84;
    zT_86 = nf;
    zF_48AC7B3A_markerWrite(zT_86);
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    mi = zT_89;
    goto z_bb_11;
    z_bb_11:
    zT_90 = env->symbol_reg;
    zT_91 = zT_90->tables_len;
    if ((int)(mi < (unsigned int)((unsigned int)zT_91))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_99 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck = zT_99;
    zT_101 = env->typereg;
    zT_102 = ck;
    zT_104 = zF_0EB68360_nameCacheGet(zT_101, zT_102);
    tc = zT_104;
    zT_105 = tc.has_value;
    if (zT_105) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_110 = "N2";
    zT_112 = 2;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    n2 = zT_111;
    zT_113 = n2;
    zF_48AC7B3A_markerWrite(zT_113);
    zT_114 = env->module_id;
    if ((int)(zT_114 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_107 = 1;
    zT_108 = mi + zT_107;
    mi = zT_108;
    goto z_bb_11;
    z_bb_15:
    t = tc.value;
    return t;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_118 = env->symbol_reg;
    zT_119 = env->module_id;
    zT_120 = name_id;
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_118, zT_119, zT_120);
    sym_cur = zT_123;
    zT_124 = sym_cur.has_value;
    if (zT_124) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    si = zT_132;
    goto z_bb_23;
    z_bb_19:
    s = sym_cur.value;
    zT_126 = s->type_id;
    if ((int)(zT_126 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_129 = s->type_id;
    return zT_129;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_133 = env->symbol_reg;
    zT_134 = zT_133->tables_len;
    if ((int)(si < (unsigned int)((unsigned int)zT_134))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_138 = env->symbol_reg;
    zT_140 = name_id;
    zT_143 = zF_A398987E_symbolRegistryQuali(zT_138, (unsigned int)((unsigned int)si), zT_140);
    sym = zT_143;
    zT_144 = sym.has_value;
    if (zT_144) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_160 = "OPTVOID:idF";
    zT_162 = 11;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    opm4f_m = zT_161;
    zT_163 = opm4f_m;
    zT_164 = name_id;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_166 = 0;
    arbu = zT_166;
    zT_168 = text;
    zT_169 = &arbu;
    zT_171 = zF_741B5264_parseArbIntWidth(zT_168, zT_169);
    arbw = zT_171;
    if ((int)(arbw != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    zT_157 = 1;
    zT_158 = si + zT_157;
    si = zT_158;
    goto z_bb_23;
    z_bb_27:
    s = sym.value;
    zT_146 = s->type_id;
    if ((int)(zT_146 != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_150 = "OPTVOID:ids";
    zT_152 = 11;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    ops_m = zT_151;
    zT_153 = ops_m;
    zT_154 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_153, zT_154);
    zT_156 = s->type_id;
    return zT_156;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_174 = env->typereg;
    zT_175 = text;
    zT_177 = zF_B8CF3697_typeRegistryGetOrCr(zT_174, zT_175);
    return zT_177;
    z_bb_32:
    return (unsigned int)(18);
    z_bb_33:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_185[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        sd_id[_i] = zT_185[_i];
        _i++;
    }
}
    zT_187 = node_idx;
    zT_191 = 0;
    zT_192 = (unsigned char*)((unsigned char*)sd_id) + zT_191;
    zT_193 = (unsigned int)(12) - zT_191;
    zT_194.ptr = zT_192;
    zT_194.len = zT_193;
    zT_188 = zT_194;
    zT_195 = zF_A7504564_itoa(zT_187, zT_188);
    sd_idl = zT_195;
    zT_199 = (unsigned int)(11) - (unsigned int)((unsigned int)sd_idl);
    sd_ids = zT_199;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_201[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        sd_nm[_i] = zT_201[_i];
        _i++;
    }
}
    zT_202 = 97;
    zT_203 = 0;
    sd_nm[zT_203] = zT_202;
    zT_204 = 110;
    zT_205 = 1;
    sd_nm[zT_205] = zT_204;
    zT_206 = 111;
    zT_207 = 2;
    sd_nm[zT_207] = zT_206;
    zT_208 = 110;
    zT_209 = 3;
    sd_nm[zT_209] = zT_208;
    zT_210 = 95;
    zT_211 = 4;
    sd_nm[zT_211] = zT_210;
    zT_213 = 0;
    zT_214 = (unsigned int)zT_213;
    sd_di = zT_214;
    goto z_bb_35;
    z_bb_34:
    zT_362 = node.kind;
    if ((int)(zT_362 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_60; else goto z_bb_61;
    z_bb_35:
    if ((int)(sd_di < (unsigned int)((unsigned int)sd_idl))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_217 = sd_ids + sd_di;
    zT_218 = sd_id[zT_217];
    zT_220 = (unsigned int)(5) + sd_di;
    sd_nm[zT_220] = zT_218;
    goto z_bb_38;
    z_bb_37:
    zT_226 = (unsigned int)(5) + (unsigned int)((unsigned int)sd_idl);
    sd_namelen = zT_226;
    zT_228 = env->interner;
    zT_233 = 0;
    zT_234 = (unsigned char*)((unsigned char*)sd_nm) + zT_233;
    zT_235 = sd_namelen - zT_233;
    zT_236.ptr = zT_234;
    zT_236.len = zT_235;
    zT_229 = zT_236;
    zT_237 = zF_50C274AF_stringInternerInter(zT_228, zT_229);
    sd_name_id = zT_237;
    zT_239 = env->typereg;
    zT_243 = zF_0EB68360_nameCacheGet(zT_239, (zT_79FAE712_u64)((zT_79FAE712_u64)sd_name_id));
    sd_existing = zT_243;
    zT_244 = sd_existing.has_value;
    if (zT_244) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_221 = 1;
    zT_222 = sd_di + zT_221;
    sd_di = zT_222;
    goto z_bb_35;
    z_bb_39:
    se = sd_existing.value;
    return se;
    z_bb_40:
    zT_247 = env->typereg;
    zT_249 = sd_name_id;
    zT_256 = zF_3A64E2E0_typeRegistryRegiste(zT_247, (unsigned int)(0), zT_249, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type));
    sd_tid = zT_256;
    zT_257 = node.flags;
    if ((int)((unsigned char)(zT_257 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_262 = env->typereg;
    zT_263 = sd_tid;
    zF_52816016_typeRegistrySetPack(zT_262, zT_263);
    goto z_bb_42;
    z_bb_42:
    zT_265 = env->store;
    zT_266 = node_idx;
    zT_268 = zF_8BA26B9E_astStoreNodePayload(zT_265, zT_266);
    if ((int)(zT_268 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_272 = env->store;
    zT_273 = node_idx;
    zT_275 = zF_850FDF81_astStoreNodeExtraCh(zT_272, zT_273);
    sd_children = zT_275;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_277[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_277[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_279[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_279[_i];
        _i++;
    }
}
    zT_281 = 0;
    zT_282 = (unsigned int)zT_281;
    sd_fc = zT_282;
    zT_284 = 0;
    zT_285 = (unsigned int)zT_284;
    sd_i = zT_285;
    goto z_bb_45;
    z_bb_44:
    return sd_tid;
    z_bb_45:
    zT_287 = sd_children.len;
    if ((int)(sd_i < zT_287)) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_293 = env->store;
    zT_296 = sd_children.ptr;
    zT_294 = zT_296[sd_i];
    zT_298 = zF_FCDD1D35_astStoreNodeAt(zT_293, zT_294);
    sd_fd = zT_298;
    zT_299 = sd_fd.kind;
    if ((int)(zT_299 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_52; else goto z_bb_53;
    z_bb_47:
    if ((int)(sd_fc > (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_48:
    zT_321 = 1;
    zT_322 = sd_i + zT_321;
    sd_i = zT_322;
    goto z_bb_45;
    z_bb_49:
    zT_289 = sd_fc < (unsigned int)(32);
    goto z_bb_51;
    z_bb_50:
    zT_289 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_289) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_305 = env;
    zT_306 = sd_fd.child_0;
    zT_311 = zF_F2107C15_resolveTypeExprFull(zT_305, zT_306, (unsigned int)(depth + (unsigned int)(1)));
    sd_ft = zT_311;
    sd_fty[sd_fc] = sd_ft;
    zT_312 = env->store;
    zT_315 = sd_children.ptr;
    zT_313 = zT_315[sd_i];
    zT_317 = zF_8BA26B9E_astStoreNodePayload(zT_312, zT_313);
    sd_fnm[sd_fc] = zT_317;
    zT_318 = 1;
    zT_320 = sd_fc + (unsigned int)((unsigned int)zT_318);
    sd_fc = zT_320;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_326 = env->typereg;
    zT_327 = zT_326->fe_len;
    zT_328 = (unsigned int)zT_327;
    sd_fstart = zT_328;
    zT_330 = 0;
    zT_331 = (unsigned int)zT_330;
    sd_j = zT_331;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_44;
    z_bb_56:
    if ((int)(sd_j < sd_fc)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_333 = env->typereg;
    zT_337 = sd_fnm[sd_j];
    zT_336.name_id = zT_337;
    zT_338 = sd_fty[sd_j];
    zT_336.type_id = zT_338;
    zT_339 = 0;
    zT_336.offset = zT_339;
    zT_334 = zT_336;
    zF_701DF154_feAppend(zT_333, zT_334);
    goto z_bb_59;
    z_bb_58:
    zT_342 = env->typereg;
    zT_346 = (unsigned int)sd_fstart;
    zT_345.fields_start = zT_346;
    zT_347 = (unsigned short)sd_fc;
    zT_345.fields_count = zT_347;
    zT_343 = zT_345;
    zF_CF849366_stAppend(zT_342, zT_343);
    zT_349 = env->typereg;
    zT_350 = zT_349->st_len;
    zT_353 = (unsigned int)(unsigned int)(zT_350 - (unsigned int)(1));
    sd_st_idx = zT_353;
    zT_355 = env->typereg;
    zT_356 = zT_355->types_items;
    zT_357 = (unsigned int)sd_tid;
    zT_358 = zT_356[zT_357];
    sd_ty = zT_358;
    sd_ty.payload_idx = sd_st_idx;
    zT_359 = env->typereg;
    zT_360 = zT_359->types_items;
    zT_361 = (unsigned int)sd_tid;
    zT_360[zT_361] = sd_ty;
    goto z_bb_55;
    z_bb_59:
    zT_340 = 1;
    zT_341 = sd_j + zT_340;
    sd_j = zT_341;
    goto z_bb_56;
    z_bb_60:
    zT_368 = 0;
    fah_matched = zT_368;
    zT_370 = env;
    zT_371 = node.child_0;
    zT_376 = zF_F2107C15_resolveTypeExprFull(zT_370, zT_371, (unsigned int)(depth + (unsigned int)(1)));
    base_type = zT_376;
    if ((int)(base_type == (unsigned int)(18))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_497 = node.kind;
    if ((int)(zT_497 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_86; else goto z_bb_87;
    z_bb_62:
    zT_380 = env->store;
    zT_381 = node.child_0;
    zT_384 = zF_FCDD1D35_astStoreNodeAt(zT_380, zT_381);
    base_node = zT_384;
    zT_385 = base_node.kind;
    if ((int)(zT_385 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    zT_454 = env->typereg;
    zT_455 = zT_454->types_items;
    zT_456 = (unsigned int)base_type;
    zT_457 = zT_455[zT_456];
    base_ty = zT_457;
    zT_458 = base_ty.kind;
    if ((int)(zT_458 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_64:
    zT_391 = env->store;
    zT_392 = node.child_0;
    zT_395 = zF_53458827_astStoreIdentifier(zT_391, zT_392);
    base_name_id = zT_395;
    zT_397 = 0;
    zT_398 = (unsigned int)zT_397;
    smi = zT_398;
    goto z_bb_66;
    z_bb_65:
    zT_446 = "FAH:m";
    zT_448 = 5;
    zT_447.ptr = zT_446;
    zT_447.len = zT_448;
    fam_m = zT_447;
    zT_449 = fam_m;
    zT_450 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_449, zT_450);
    return (unsigned int)(18);
    z_bb_66:
    zT_399 = env->symbol_reg;
    zT_400 = zT_399->tables_len;
    if ((int)(smi < (unsigned int)((unsigned int)zT_400))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_404 = env->symbol_reg;
    zT_406 = base_name_id;
    zT_409 = zF_A398987E_symbolRegistryQuali(zT_404, (unsigned int)((unsigned int)smi), zT_406);
    base_sym = zT_409;
    zT_410 = base_sym.has_value;
    if (zT_410) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_443 = 1;
    zT_444 = smi + zT_443;
    smi = zT_444;
    goto z_bb_66;
    z_bb_70:
    bs = base_sym.value;
    zT_412 = bs->kind;
    if ((int)(zT_412 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_69;
    z_bb_72:
    zT_418 = bs->module_id;
    mod_id = zT_418;
    zT_420 = env->symbol_reg;
    zT_421 = mod_id;
    zT_424 = env->store;
    zT_425 = node_idx;
    zT_427 = zF_8BA26B9E_astStoreNodePayload(zT_424, zT_425);
    zT_422 = zT_427;
    zT_428 = zF_A398987E_symbolRegistryQuali(zT_420, zT_421, zT_422);
    payload_sym = zT_428;
    zT_429 = payload_sym.has_value;
    if (zT_429) goto z_bb_74; else goto z_bb_75;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    ps = payload_sym.value;
    zT_431 = ps->type_id;
    if ((int)(zT_431 != (unsigned int)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    zT_434 = 1;
    fah_matched = zT_434;
    zT_436 = "FAH:r";
    zT_438 = 5;
    zT_437.ptr = zT_436;
    zT_437.len = zT_438;
    fam = zT_437;
    zT_439 = fam;
    zT_440 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_439, zT_440);
    zT_442 = ps->type_id;
    return zT_442;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_464 = base_ty.module_id;
    mod_id = zT_464;
    zT_466 = env->symbol_reg;
    zT_467 = mod_id;
    zT_470 = env->store;
    zT_471 = node_idx;
    zT_473 = zF_8BA26B9E_astStoreNodePayload(zT_470, zT_471);
    zT_468 = zT_473;
    zT_474 = zF_A398987E_symbolRegistryQuali(zT_466, zT_467, zT_468);
    sym = zT_474;
    zT_475 = sym.has_value;
    if (zT_475) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    if ((int)(fah_matched == (unsigned char)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_80:
    s = sym.value;
    zT_477 = s->type_id;
    if ((int)(zT_477 != (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_480 = 1;
    fah_matched = zT_480;
    zT_482 = "FAH:r";
    zT_484 = 5;
    zT_483.ptr = zT_482;
    zT_483.len = zT_484;
    fam = zT_483;
    zT_485 = fam;
    zT_486 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_485, zT_486);
    zT_488 = s->type_id;
    return zT_488;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_492 = "FAH:N";
    zT_494 = 5;
    zT_493.ptr = zT_492;
    zT_493.len = zT_494;
    fnm = zT_493;
    zT_495 = fnm;
    zT_496 = node_idx;
    zF_C914CB83_markerWriteInt(zT_495, zT_496);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_61;
    z_bb_86:
    zT_504 = env->typereg;
    zT_505 = zT_504->xn_len;
    zT_506 = (unsigned int)zT_505;
    zT_507 = 0;
    zT_503[zT_507] = zT_506;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_503[_i];
        _i++;
    }
}
    zT_510 = 0;
    zT_511 = 0;
    zT_509[zT_511] = zT_510;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_509[_i];
        _i++;
    }
}
    zT_512 = env->store;
    zT_513 = node_idx;
    zT_515 = zF_8BA26B9E_astStoreNodePayload(zT_512, zT_513);
    if ((int)(zT_515 != (unsigned int)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    zT_549 = node.kind;
    if ((int)(zT_549 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_88:
    zT_519 = env->store;
    zT_520 = node_idx;
    zT_522 = zF_850FDF81_astStoreNodeExtraCh(zT_519, zT_520);
    esd_children = zT_522;
    zT_524 = esd_children.len;
    zT_525 = (unsigned short)zT_524;
    zT_526 = 0;
    esd_count_box[zT_526] = zT_525;
    zT_528 = 0;
    zT_529 = (unsigned int)zT_528;
    esd_i = zT_529;
    goto z_bb_90;
    z_bb_89:
    zT_540 = env->typereg;
    zT_544 = 0;
    zT_541 = esd_start_box[zT_544];
    zT_546 = 0;
    zT_542 = esd_count_box[zT_546];
    zT_548 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_540, zT_541, zT_542);
    return zT_548;
    z_bb_90:
    zT_531 = esd_children.len;
    if ((int)(esd_i < zT_531)) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_533 = env->typereg;
    zT_536 = esd_children.ptr;
    zT_534 = zT_536[esd_i];
    zF_A648B1CB_xnAppend(zT_533, zT_534);
    goto z_bb_93;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_538 = 1;
    zT_539 = esd_i + zT_538;
    esd_i = zT_539;
    goto z_bb_90;
    z_bb_94:
    zT_555 = env;
    zT_556 = node.child_1;
    zT_561 = zF_F2107C15_resolveTypeExprFull(zT_555, zT_556, (unsigned int)(depth + (unsigned int)(1)));
    eu_payload_type = zT_561;
    if ((int)(eu_payload_type == (unsigned int)(18))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    zT_593 = node.kind;
    if ((int)(zT_593 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_103; else goto z_bb_104;
    z_bb_96:
    return (unsigned int)(18);
    z_bb_97:
    zT_567 = 0;
    zT_568 = 0;
    zT_566[zT_568] = zT_567;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_566[_i];
        _i++;
    }
}
    zT_569 = node.child_0;
    zT_570 = 0;
    if ((int)(zT_569 != (unsigned int)zT_570)) goto z_bb_98; else goto z_bb_100;
    z_bb_98:
    zT_573 = env;
    zT_574 = node.child_0;
    zT_579 = zF_F2107C15_resolveTypeExprFull(zT_573, zT_574, (unsigned int)(depth + (unsigned int)(1)));
    eu_resolved_es = zT_579;
    if ((int)(eu_resolved_es == (unsigned int)(18))) goto z_bb_101; else goto z_bb_102;
    z_bb_99:
    zT_586 = env->typereg;
    zT_587 = eu_payload_type;
    zT_590 = 0;
    zT_588 = eu_es_box[zT_590];
    zT_592 = zF_16D1A6EE_typeRegistryGetOrCr(zT_586, zT_587, zT_588);
    return zT_592;
    z_bb_100:
    zT_584 = 0;
    zT_585 = 0;
    eu_es_box[zT_585] = zT_584;
    goto z_bb_99;
    z_bb_101:
    return (unsigned int)(18);
    z_bb_102:
    zT_583 = 0;
    eu_es_box[zT_583] = eu_resolved_es;
    goto z_bb_99;
    z_bb_103:
    zT_600 = 0;
    zT_601 = 0;
    zT_599[zT_601] = zT_600;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_599[_i];
        _i++;
    }
}
    zT_602 = 1;
    zT_603 = 0;
    fnt_ret_box[zT_603] = zT_602;
    zT_604 = node.child_0;
    zT_605 = 0;
    if ((int)(zT_604 != (unsigned int)zT_605)) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_814 = node.child_0;
    zT_815 = 0;
    if ((int)(zT_814 != (unsigned int)zT_815)) goto z_bb_154; else goto z_bb_155;
    z_bb_105:
    zT_607 = env;
    zT_608 = node.child_0;
    zT_613 = zF_F2107C15_resolveTypeExprFull(zT_607, zT_608, (unsigned int)(depth + (unsigned int)(1)));
    zT_614 = 0;
    fnt_ret_box[zT_614] = zT_613;
    zT_616 = "OPTVOID:fntR";
    zT_618 = 12;
    zT_617.ptr = zT_616;
    zT_617.len = zT_618;
    opm2_m = zT_617;
    zT_619 = opm2_m;
    zT_621 = 0;
    zT_620 = fnt_ret_box[zT_621];
    zF_C914CB83_markerWriteInt(zT_619, zT_620);
    zT_623 = 0;
    zT_624 = fnt_ret_box[zT_623];
    if ((int)(zT_624 == (unsigned int)(18))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_629[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_629[_i];
        _i++;
    }
}
    zT_631 = 0;
    fnt_pc = zT_631;
    zT_632 = env->store;
    zT_633 = node_idx;
    zT_635 = zF_8BA26B9E_astStoreNodePayload(zT_632, zT_633);
    if ((int)(zT_635 != (unsigned int)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_107:
    return (unsigned int)(18);
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_639 = env->store;
    zT_640 = node_idx;
    zT_642 = zF_850FDF81_astStoreNodeExtraCh(zT_639, zT_640);
    fnt_extra = zT_642;
    zT_644 = 0;
    fnt_i = zT_644;
    goto z_bb_111;
    z_bb_110:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_668[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_668[_i];
        _i++;
    }
}
    zT_670 = 0;
    fnt_np = zT_670;
    zT_672 = "fnt_";
    zT_674 = 4;
    zT_673.ptr = zT_672;
    zT_673.len = zT_674;
    fnt_pre = zT_673;
    zT_676 = 0;
    fnt_pri = zT_676;
    goto z_bb_120;
    z_bb_111:
    zT_646 = fnt_extra.len;
    if ((int)(fnt_i < zT_646)) goto z_bb_115; else goto z_bb_116;
    z_bb_112:
    zT_652 = env;
    zT_655 = fnt_extra.ptr;
    zT_653 = zT_655[fnt_i];
    zT_659 = zF_F2107C15_resolveTypeExprFull(zT_652, zT_653, (unsigned int)(depth + (unsigned int)(1)));
    fnt_pt = zT_659;
    if ((int)(fnt_pt == (unsigned int)(18))) goto z_bb_118; else goto z_bb_119;
    z_bb_113:
    goto z_bb_110;
    z_bb_114:
    zT_666 = fnt_i + (unsigned int)(1);
    fnt_i = zT_666;
    goto z_bb_111;
    z_bb_115:
    zT_648 = fnt_pc < (unsigned int)(16);
    goto z_bb_117;
    z_bb_116:
    zT_648 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_648) goto z_bb_112; else goto z_bb_113;
    z_bb_118:
    return (unsigned int)(18);
    z_bb_119:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_664 = fnt_pc + (unsigned int)(1);
    fnt_pc = zT_664;
    goto z_bb_114;
    z_bb_120:
    zT_678 = fnt_pre.len;
    if ((int)(fnt_pri < zT_678)) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_683 = fnt_pre.ptr;
    zT_684 = zT_683[fnt_pri];
    fnt_nb[fnt_np] = zT_684;
    zT_686 = fnt_np + (unsigned int)(1);
    fnt_np = zT_686;
    goto z_bb_123;
    z_bb_122:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_690[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_690[_i];
        _i++;
    }
}
    zT_694 = 0;
    zT_692 = fnt_ret_box[zT_694];
    zT_698 = 0;
    zT_699 = (unsigned char*)((unsigned char*)fnt_rb) + zT_698;
    zT_700 = (unsigned int)(12) - zT_698;
    zT_701.ptr = zT_699;
    zT_701.len = zT_700;
    zT_693 = zT_701;
    zT_702 = zF_A7504564_itoa(zT_692, zT_693);
    fnt_rl = zT_702;
    zT_706 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_rl);
    fnt_rs = zT_706;
    goto z_bb_127;
    z_bb_123:
    zT_688 = fnt_pri + (unsigned int)(1);
    fnt_pri = zT_688;
    goto z_bb_120;
    z_bb_124:
    zT_680 = fnt_np < (unsigned int)(95);
    goto z_bb_126;
    z_bb_125:
    zT_680 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_680) goto z_bb_121; else goto z_bb_122;
    z_bb_127:
    if ((int)(fnt_rs < (unsigned int)(11))) goto z_bb_131; else goto z_bb_132;
    z_bb_128:
    zT_712 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_712;
    zT_714 = fnt_np + (unsigned int)(1);
    fnt_np = zT_714;
    goto z_bb_130;
    z_bb_129:
    zT_718 = 0;
    fnt_k = zT_718;
    goto z_bb_134;
    z_bb_130:
    zT_716 = fnt_rs + (unsigned int)(1);
    fnt_rs = zT_716;
    goto z_bb_127;
    z_bb_131:
    zT_709 = fnt_np < (unsigned int)(95);
    goto z_bb_133;
    z_bb_132:
    zT_709 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_709) goto z_bb_128; else goto z_bb_129;
    z_bb_134:
    if ((int)(fnt_k < fnt_pc)) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    if ((int)(fnt_np < (unsigned int)(95))) goto z_bb_141; else goto z_bb_142;
    z_bb_136:
    zT_758 = env->interner;
    zT_763 = 0;
    zT_764 = (unsigned char*)((unsigned char*)fnt_nb) + zT_763;
    zT_765 = fnt_np - zT_763;
    zT_766.ptr = zT_764;
    zT_766.len = zT_765;
    zT_759 = zT_766;
    zT_767 = zF_50C274AF_stringInternerInter(zT_758, zT_759);
    fnt_name_id = zT_767;
    zT_769 = env->typereg;
    zT_770 = zT_769->xt_len;
    zT_771 = (unsigned int)zT_770;
    fnt_pstart = zT_771;
    zT_773 = 0;
    fnt_a = zT_773;
    goto z_bb_150;
    z_bb_137:
    zT_756 = fnt_k + (unsigned int)(1);
    fnt_k = zT_756;
    goto z_bb_134;
    z_bb_138:
    zT_720 = fnt_np < (unsigned int)(95);
    goto z_bb_140;
    z_bb_139:
    zT_720 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_720) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    zT_725 = 95;
    fnt_nb[fnt_np] = zT_725;
    zT_727 = fnt_np + (unsigned int)(1);
    fnt_np = zT_727;
    goto z_bb_142;
    z_bb_142:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_729[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_729[_i];
        _i++;
    }
}
    zT_731 = fnt_ptypes[fnt_k];
    zT_736 = 0;
    zT_737 = (unsigned char*)((unsigned char*)fnt_pb) + zT_736;
    zT_738 = (unsigned int)(12) - zT_736;
    zT_739.ptr = zT_737;
    zT_739.len = zT_738;
    zT_732 = zT_739;
    zT_740 = zF_A7504564_itoa(zT_731, zT_732);
    fnt_pl = zT_740;
    zT_744 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_pl);
    fnt_ps = zT_744;
    goto z_bb_143;
    z_bb_143:
    if ((int)(fnt_ps < (unsigned int)(11))) goto z_bb_147; else goto z_bb_148;
    z_bb_144:
    zT_750 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_750;
    zT_752 = fnt_np + (unsigned int)(1);
    fnt_np = zT_752;
    goto z_bb_146;
    z_bb_145:
    goto z_bb_137;
    z_bb_146:
    zT_754 = fnt_ps + (unsigned int)(1);
    fnt_ps = zT_754;
    goto z_bb_143;
    z_bb_147:
    zT_747 = fnt_np < (unsigned int)(95);
    goto z_bb_149;
    z_bb_148:
    zT_747 = 0;
    goto z_bb_149;
    z_bb_149:
    if (zT_747) goto z_bb_144; else goto z_bb_145;
    z_bb_150:
    if ((int)(fnt_a < fnt_pc)) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_775 = env->typereg;
    zT_776 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_775, zT_776);
    goto z_bb_153;
    z_bb_152:
    zT_782 = env->typereg;
    zT_783 = fnt_name_id;
    zT_796 = 0;
    zT_789 = fnt_ret_box[zT_796];
    zT_798 = zF_474336D7_typeRegistryGetOrCr(zT_782, zT_783, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), (unsigned short)((unsigned short)fnt_pc), zT_789);
    fnt_tid = zT_798;
    zT_800 = "OPTVOID:fntT";
    zT_802 = 12;
    zT_801.ptr = zT_800;
    zT_801.len = zT_802;
    opm3_m = zT_801;
    zT_803 = opm3_m;
    zT_804 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_803, zT_804);
    zT_805 = env->typereg;
    zT_806 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_805, zT_806);
    zT_808 = env->typereg;
    zT_809 = fnt_tid;
    zT_813 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_808, zT_809, (int)(0));
    return zT_813;
    z_bb_153:
    zT_780 = fnt_a + (unsigned int)(1);
    fnt_a = zT_780;
    goto z_bb_150;
    z_bb_154:
    zT_818 = env;
    zT_819 = node.child_0;
    zT_824 = zF_F2107C15_resolveTypeExprFull(zT_818, zT_819, (unsigned int)(depth + (unsigned int)(1)));
    child_type = zT_824;
    if ((int)(child_type == (unsigned int)(18))) goto z_bb_156; else goto z_bb_157;
    z_bb_155:
    zT_1357 = "UND:n";
    zT_1359 = 5;
    zT_1358.ptr = zT_1357;
    zT_1358.len = zT_1359;
    und_nm2 = zT_1358;
    zT_1360 = und_nm2;
    zT_1361 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1360, zT_1361);
    zT_1363 = "UND:k";
    zT_1365 = 5;
    zT_1364.ptr = zT_1363;
    zT_1364.len = zT_1365;
    und_km = zT_1364;
    zT_1366 = und_km;
    zT_1368 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1366, (unsigned int)((unsigned int)zT_1368));
    return (unsigned int)(18);
    z_bb_156:
    return (unsigned int)(18);
    z_bb_157:
    zT_828 = node.kind;
    if ((int)(zT_828 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_159; else goto z_bb_158;
    z_bb_158:
    zT_834 = node.kind;
    zT_833 = zT_834 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_160;
    z_bb_159:
    zT_833 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_833) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_840 = "PTR:i";
    zT_842 = 5;
    zT_841.ptr = zT_840;
    zT_841.len = zT_842;
    ptm = zT_841;
    zT_843 = ptm;
    zF_48AC7B3A_markerWrite(zT_843);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_845[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptib[_i] = zT_845[_i];
        _i++;
    }
}
    zT_847 = node_idx;
    zT_851 = 0;
    zT_852 = (unsigned char*)((unsigned char*)ptib) + zT_851;
    zT_853 = (unsigned int)(10) - zT_851;
    zT_854.ptr = zT_852;
    zT_854.len = zT_853;
    zT_848 = zT_854;
    zT_855 = zF_A7504564_itoa(zT_847, zT_848);
    ptil = zT_855;
    zT_859 = (unsigned int)(9) - (unsigned int)((unsigned int)ptil);
    ptis = zT_859;
    zT_864 = (unsigned char*)((unsigned char*)ptib) + ptis;
    zT_865 = (unsigned int)(9) - ptis;
    zT_866.ptr = zT_864;
    zT_866.len = zT_865;
    zT_860 = zT_866;
    zF_48AC7B3A_markerWrite(zT_860);
    zT_868 = "k";
    zT_870 = 1;
    zT_869.ptr = zT_868;
    zT_869.len = zT_870;
    ptkm = zT_869;
    zT_871 = ptkm;
    zF_48AC7B3A_markerWrite(zT_871);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_873[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptkb[_i] = zT_873[_i];
        _i++;
    }
}
    zT_877 = node.kind;
    zT_881 = 0;
    zT_882 = (unsigned char*)((unsigned char*)ptkb) + zT_881;
    zT_883 = (unsigned int)(10) - zT_881;
    zT_884.ptr = zT_882;
    zT_884.len = zT_883;
    zT_876 = zT_884;
    zT_885 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_877), zT_876);
    ptkl = zT_885;
    zT_889 = (unsigned int)(9) - (unsigned int)((unsigned int)ptkl);
    ptks = zT_889;
    zT_894 = (unsigned char*)((unsigned char*)ptkb) + ptks;
    zT_895 = (unsigned int)(9) - ptks;
    zT_896.ptr = zT_894;
    zT_896.len = zT_895;
    zT_890 = zT_896;
    zF_48AC7B3A_markerWrite(zT_890);
    zT_898 = "c";
    zT_900 = 1;
    zT_899.ptr = zT_898;
    zT_899.len = zT_900;
    ptcm = zT_899;
    zT_901 = ptcm;
    zF_48AC7B3A_markerWrite(zT_901);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_903[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptcb[_i] = zT_903[_i];
        _i++;
    }
}
    zT_905 = child_type;
    zT_909 = 0;
    zT_910 = (unsigned char*)((unsigned char*)ptcb) + zT_909;
    zT_911 = (unsigned int)(10) - zT_909;
    zT_912.ptr = zT_910;
    zT_912.len = zT_911;
    zT_906 = zT_912;
    zT_913 = zF_A7504564_itoa(zT_905, zT_906);
    ptcl = zT_913;
    zT_917 = (unsigned int)(9) - (unsigned int)((unsigned int)ptcl);
    ptcs = zT_917;
    zT_922 = (unsigned char*)((unsigned char*)ptcb) + ptcs;
    zT_923 = (unsigned int)(9) - ptcs;
    zT_924.ptr = zT_922;
    zT_924.len = zT_923;
    zT_918 = zT_924;
    zF_48AC7B3A_markerWrite(zT_918);
    zT_926 = node.flags;
    zT_930 = (unsigned char)(zT_926 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_930;
    zT_932 = node.flags;
    zT_936 = (unsigned char)(zT_932 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_936;
    zT_937 = node.kind;
    if ((int)(zT_937 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_163; else goto z_bb_165;
    z_bb_162:
    zT_1022 = node.kind;
    if ((int)(zT_1022 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_166; else goto z_bb_167;
    z_bb_163:
    zT_943 = env->typereg;
    zT_944 = child_type;
    zT_945 = is_const;
    zT_946 = is_volatile;
    zT_948 = zF_0C0306D6_typeRegistryGetOrCr(zT_943, zT_944, zT_945, zT_946);
    ptr_tid = zT_948;
    zT_950 = "P";
    zT_952 = 1;
    zT_951.ptr = zT_950;
    zT_951.len = zT_952;
    ppm = zT_951;
    zT_953 = ppm;
    zF_48AC7B3A_markerWrite(zT_953);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_955[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb[_i] = zT_955[_i];
        _i++;
    }
}
    zT_957 = ptr_tid;
    zT_961 = 0;
    zT_962 = (unsigned char*)((unsigned char*)ppb) + zT_961;
    zT_963 = (unsigned int)(10) - zT_961;
    zT_964.ptr = zT_962;
    zT_964.len = zT_963;
    zT_958 = zT_964;
    zT_965 = zF_A7504564_itoa(zT_957, zT_958);
    ppl = zT_965;
    zT_969 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl);
    pps = zT_969;
    zT_974 = (unsigned char*)((unsigned char*)ppb) + pps;
    zT_975 = (unsigned int)(9) - pps;
    zT_976.ptr = zT_974;
    zT_976.len = zT_975;
    zT_970 = zT_976;
    zF_48AC7B3A_markerWrite(zT_970);
    zT_978 = "\n";
    zT_980 = 1;
    zT_979.ptr = zT_978;
    zT_979.len = zT_980;
    pnl = zT_979;
    zT_981 = pnl;
    zF_48AC7B3A_markerWrite(zT_981);
    return ptr_tid;
    goto z_bb_162;
    z_bb_165:
    zT_983 = env->typereg;
    zT_984 = child_type;
    zT_985 = is_const;
    zT_986 = is_volatile;
    zT_988 = zF_827207A1_typeRegistryGetOrCr(zT_983, zT_984, zT_985, zT_986);
    ptr_tid2 = zT_988;
    zT_990 = "M";
    zT_992 = 1;
    zT_991.ptr = zT_990;
    zT_991.len = zT_992;
    ppm2 = zT_991;
    zT_993 = ppm2;
    zF_48AC7B3A_markerWrite(zT_993);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_995[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb2[_i] = zT_995[_i];
        _i++;
    }
}
    zT_997 = ptr_tid2;
    zT_1001 = 0;
    zT_1002 = (unsigned char*)((unsigned char*)ppb2) + zT_1001;
    zT_1003 = (unsigned int)(10) - zT_1001;
    zT_1004.ptr = zT_1002;
    zT_1004.len = zT_1003;
    zT_998 = zT_1004;
    zT_1005 = zF_A7504564_itoa(zT_997, zT_998);
    ppl2 = zT_1005;
    zT_1009 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl2);
    pps2 = zT_1009;
    zT_1014 = (unsigned char*)((unsigned char*)ppb2) + pps2;
    zT_1015 = (unsigned int)(9) - pps2;
    zT_1016.ptr = zT_1014;
    zT_1016.len = zT_1015;
    zT_1010 = zT_1016;
    zF_48AC7B3A_markerWrite(zT_1010);
    zT_1018 = "\n";
    zT_1020 = 1;
    zT_1019.ptr = zT_1018;
    zT_1019.len = zT_1020;
    pnl2 = zT_1019;
    zT_1021 = pnl2;
    zF_48AC7B3A_markerWrite(zT_1021);
    return ptr_tid2;
    z_bb_166:
    zT_1028 = node.flags;
    zT_1032 = (unsigned char)(zT_1028 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_1032;
    zT_1034 = env->typereg;
    zT_1035 = child_type;
    zT_1036 = is_const;
    zT_1038 = zF_8FC81A87_typeRegistryGetOrCr(zT_1034, zT_1035, zT_1036);
    sl_tid = zT_1038;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1040[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_e[_i] = zT_1040[_i];
        _i++;
    }
}
    zT_1042 = child_type;
    zT_1046 = 0;
    zT_1047 = (unsigned char*)((unsigned char*)sl_e) + zT_1046;
    zT_1048 = (unsigned int)(20) - zT_1046;
    zT_1049.ptr = zT_1047;
    zT_1049.len = zT_1048;
    zT_1043 = zT_1049;
    zT_1050 = zF_A7504564_itoa(zT_1042, zT_1043);
    sl_el = zT_1050;
    zT_1054 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_el);
    sl_es = zT_1054;
    zT_1056 = "SL:e";
    zT_1058 = 4;
    zT_1057.ptr = zT_1056;
    zT_1057.len = zT_1058;
    sm = zT_1057;
    zT_1059 = sm;
    zF_48AC7B3A_markerWrite(zT_1059);
    zT_1064 = (unsigned char*)((unsigned char*)sl_e) + sl_es;
    zT_1065 = (unsigned int)(19) - sl_es;
    zT_1066.ptr = zT_1064;
    zT_1066.len = zT_1065;
    zT_1060 = zT_1066;
    zF_48AC7B3A_markerWrite(zT_1060);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1068[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_r[_i] = zT_1068[_i];
        _i++;
    }
}
    zT_1070 = sl_tid;
    zT_1074 = 0;
    zT_1075 = (unsigned char*)((unsigned char*)sl_r) + zT_1074;
    zT_1076 = (unsigned int)(20) - zT_1074;
    zT_1077.ptr = zT_1075;
    zT_1077.len = zT_1076;
    zT_1071 = zT_1077;
    zT_1078 = zF_A7504564_itoa(zT_1070, zT_1071);
    sl_rl = zT_1078;
    zT_1082 = (unsigned int)(19) - (unsigned int)((unsigned int)sl_rl);
    sl_rs = zT_1082;
    zT_1084 = "s";
    zT_1086 = 1;
    zT_1085.ptr = zT_1084;
    zT_1085.len = zT_1086;
    s2 = zT_1085;
    zT_1087 = s2;
    zF_48AC7B3A_markerWrite(zT_1087);
    zT_1092 = (unsigned char*)((unsigned char*)sl_r) + sl_rs;
    zT_1093 = (unsigned int)(19) - sl_rs;
    zT_1094.ptr = zT_1092;
    zT_1094.len = zT_1093;
    zT_1088 = zT_1094;
    zF_48AC7B3A_markerWrite(zT_1088);
    zT_1096 = "\n";
    zT_1098 = 1;
    zT_1097.ptr = zT_1096;
    zT_1097.len = zT_1098;
    s3 = zT_1097;
    zT_1099 = s3;
    zF_48AC7B3A_markerWrite(zT_1099);
    return sl_tid;
    z_bb_167:
    zT_1100 = node.kind;
    if ((int)(zT_1100 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_1106 = "OPTVOID:opt";
    zT_1108 = 11;
    zT_1107.ptr = zT_1106;
    zT_1107.len = zT_1108;
    optvd_m = zT_1107;
    zT_1109 = optvd_m;
    zT_1110 = child_type;
    zF_C914CB83_markerWriteInt(zT_1109, zT_1110);
    zT_1112 = env->typereg;
    zT_1113 = child_type;
    zT_1115 = zF_74A7234F_typeRegistryGetOrCr(zT_1112, zT_1113);
    optvd_tid = zT_1115;
    zT_1117 = "OPTVOID:optR";
    zT_1119 = 12;
    zT_1118.ptr = zT_1117;
    zT_1118.len = zT_1119;
    optvd_rm = zT_1118;
    zT_1120 = optvd_rm;
    zT_1121 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_1120, zT_1121);
    return optvd_tid;
    z_bb_169:
    zT_1122 = node.kind;
    if ((int)(zT_1122 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    zT_1128 = "T0";
    zT_1130 = 2;
    zT_1129.ptr = zT_1128;
    zT_1129.len = zT_1130;
    t0m = zT_1129;
    zT_1131 = t0m;
    zF_48AC7B3A_markerWrite(zT_1131);
    zT_1133 = "T1e";
    zT_1135 = 3;
    zT_1134.ptr = zT_1133;
    zT_1134.len = zT_1135;
    t1m = zT_1134;
    zT_1136 = t1m;
    zF_48AC7B3A_markerWrite(zT_1136);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1138[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t1b[_i] = zT_1138[_i];
        _i++;
    }
}
    zT_1140 = child_type;
    zT_1144 = 0;
    zT_1145 = (unsigned char*)((unsigned char*)t1b) + zT_1144;
    zT_1146 = (unsigned int)(20) - zT_1144;
    zT_1147.ptr = zT_1145;
    zT_1147.len = zT_1146;
    zT_1141 = zT_1147;
    zT_1148 = zF_A7504564_itoa(zT_1140, zT_1141);
    t1l = zT_1148;
    zT_1152 = (unsigned int)(19) - (unsigned int)((unsigned int)t1l);
    t1s = zT_1152;
    zT_1157 = (unsigned char*)((unsigned char*)t1b) + t1s;
    zT_1158 = (unsigned int)(19) - t1s;
    zT_1159.ptr = zT_1157;
    zT_1159.len = zT_1158;
    zT_1153 = zT_1159;
    zF_48AC7B3A_markerWrite(zT_1153);
    zT_1160 = node.child_1;
    zT_1161 = 0;
    if ((int)(zT_1160 != (unsigned int)zT_1161)) goto z_bb_172; else goto z_bb_173;
    z_bb_171:
    goto z_bb_155;
    z_bb_172:
    zT_1164 = env->store;
    zT_1165 = node.child_1;
    zT_1168 = zF_FCDD1D35_astStoreNodeAt(zT_1164, zT_1165);
    sz_node = zT_1168;
    zT_1170 = 0;
    arr_len = zT_1170;
    zT_1172 = 0;
    arr_resolved = zT_1172;
    zT_1173 = sz_node.kind;
    if ((int)(zT_1173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_174; else goto z_bb_176;
    z_bb_173:
    return (unsigned int)(18);
    z_bb_174:
    zT_1178 = env->store;
    zT_1179 = node.child_1;
    zT_1182 = zF_678B9A72_astStoreIntValue(zT_1178, zT_1179);
    zT_1183 = (unsigned int)zT_1182;
    arr_len = zT_1183;
    zT_1184 = 1;
    arr_resolved = zT_1184;
    goto z_bb_175;
    z_bb_175:
    zT_1282 = "T2L";
    zT_1284 = 3;
    zT_1283.ptr = zT_1282;
    zT_1283.len = zT_1284;
    t2m = zT_1283;
    zT_1285 = t2m;
    zF_48AC7B3A_markerWrite(zT_1285);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1287[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t2b[_i] = zT_1287[_i];
        _i++;
    }
}
    zT_1289 = arr_len;
    zT_1293 = 0;
    zT_1294 = (unsigned char*)((unsigned char*)t2b) + zT_1293;
    zT_1295 = (unsigned int)(20) - zT_1293;
    zT_1296.ptr = zT_1294;
    zT_1296.len = zT_1295;
    zT_1290 = zT_1296;
    zT_1297 = zF_A7504564_itoa(zT_1289, zT_1290);
    t2l = zT_1297;
    zT_1301 = (unsigned int)(19) - (unsigned int)((unsigned int)t2l);
    t2s = zT_1301;
    zT_1306 = (unsigned char*)((unsigned char*)t2b) + t2s;
    zT_1307 = (unsigned int)(19) - t2s;
    zT_1308.ptr = zT_1306;
    zT_1308.len = zT_1307;
    zT_1302 = zT_1308;
    zF_48AC7B3A_markerWrite(zT_1302);
    if (arr_resolved) goto z_bb_218; else goto z_bb_219;
    z_bb_176:
    zT_1185 = sz_node.kind;
    if ((int)(zT_1185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_178; else goto z_bb_177;
    z_bb_177:
    zT_1191 = sz_node.kind;
    zT_1190 = zT_1191 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_179;
    z_bb_178:
    zT_1190 = 1;
    goto z_bb_179;
    z_bb_179:
    if (zT_1190) goto z_bb_180; else goto z_bb_182;
    z_bb_180:
    zT_1197 = env;
    zT_1198 = sz_node.child_0;
    zT_1200 = zF_6D0DD27D_evalConstU32Full(zT_1197, zT_1198);
    lhs = zT_1200;
    zT_1202 = env;
    zT_1203 = sz_node.child_1;
    zT_1205 = zF_6D0DD27D_evalConstU32Full(zT_1202, zT_1203);
    rhs = zT_1205;
    if ((int)(lhs != (unsigned int)(4294967295u))) goto z_bb_183; else goto z_bb_184;
    z_bb_181:
    goto z_bb_175;
    z_bb_182:
    zT_1219 = sz_node.kind;
    if ((int)(zT_1219 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_192; else goto z_bb_191;
    z_bb_183:
    zT_1208 = rhs != (unsigned int)(4294967295u);
    goto z_bb_185;
    z_bb_184:
    zT_1208 = 0;
    goto z_bb_185;
    z_bb_185:
    if (zT_1208) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_1211 = 1;
    arr_resolved = zT_1211;
    zT_1212 = sz_node.kind;
    if ((int)(zT_1212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_188; else goto z_bb_190;
    z_bb_187:
    goto z_bb_181;
    z_bb_188:
    zT_1217 = lhs + rhs;
    arr_len = zT_1217;
    goto z_bb_189;
    z_bb_189:
    goto z_bb_187;
    z_bb_190:
    zT_1218 = lhs - rhs;
    arr_len = zT_1218;
    goto z_bb_189;
    z_bb_191:
    zT_1225 = sz_node.kind;
    zT_1224 = zT_1225 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_193;
    z_bb_192:
    zT_1224 = 1;
    goto z_bb_193;
    z_bb_193:
    if (zT_1224) goto z_bb_195; else goto z_bb_194;
    z_bb_194:
    zT_1231 = sz_node.kind;
    zT_1230 = zT_1231 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_196;
    z_bb_195:
    zT_1230 = 1;
    goto z_bb_196;
    z_bb_196:
    if (zT_1230) goto z_bb_197; else goto z_bb_199;
    z_bb_197:
    zT_1237 = env;
    zT_1238 = sz_node.child_0;
    zT_1240 = zF_6D0DD27D_evalConstU32Full(zT_1237, zT_1238);
    lhs = zT_1240;
    zT_1242 = env;
    zT_1243 = sz_node.child_1;
    zT_1245 = zF_6D0DD27D_evalConstU32Full(zT_1242, zT_1243);
    rhs = zT_1245;
    if ((int)(lhs != (unsigned int)(4294967295u))) goto z_bb_200; else goto z_bb_201;
    z_bb_198:
    goto z_bb_181;
    z_bb_199:
    zT_1268 = sz_node.kind;
    if ((int)(zT_1268 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_214; else goto z_bb_215;
    z_bb_200:
    zT_1248 = rhs != (unsigned int)(4294967295u);
    goto z_bb_202;
    z_bb_201:
    zT_1248 = 0;
    goto z_bb_202;
    z_bb_202:
    if (zT_1248) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    zT_1251 = rhs != (unsigned int)(0);
    goto z_bb_205;
    z_bb_204:
    zT_1251 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_1251) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_1254 = 1;
    arr_resolved = zT_1254;
    zT_1255 = sz_node.kind;
    if ((int)(zT_1255 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_208; else goto z_bb_210;
    z_bb_207:
    goto z_bb_198;
    z_bb_208:
    zT_1260 = lhs * rhs;
    arr_len = zT_1260;
    goto z_bb_209;
    z_bb_209:
    goto z_bb_207;
    z_bb_210:
    zT_1261 = sz_node.kind;
    if ((int)(zT_1261 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_211; else goto z_bb_213;
    z_bb_211:
    zT_1266 = lhs / rhs;
    arr_len = zT_1266;
    goto z_bb_212;
    z_bb_212:
    goto z_bb_209;
    z_bb_213:
    zT_1267 = lhs % rhs;
    arr_len = zT_1267;
    goto z_bb_212;
    z_bb_214:
    zT_1274 = env;
    zT_1275 = node.child_1;
    zT_1277 = zF_6D0DD27D_evalConstU32Full(zT_1274, zT_1275);
    al = zT_1277;
    if ((int)(al != (unsigned int)(4294967295u))) goto z_bb_216; else goto z_bb_217;
    z_bb_215:
    goto z_bb_198;
    z_bb_216:
    arr_len = al;
    zT_1280 = 1;
    arr_resolved = zT_1280;
    goto z_bb_217;
    z_bb_217:
    goto z_bb_215;
    z_bb_218:
    zT_1310 = env->typereg;
    zT_1311 = child_type;
    zT_1312 = arr_len;
    zT_1314 = zF_BA693C74_typeRegistryGetOrCr(zT_1310, zT_1311, zT_1312);
    at = zT_1314;
    zT_1316 = "T3a";
    zT_1318 = 3;
    zT_1317.ptr = zT_1316;
    zT_1317.len = zT_1318;
    t3m = zT_1317;
    zT_1319 = t3m;
    zF_48AC7B3A_markerWrite(zT_1319);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1321[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t3b[_i] = zT_1321[_i];
        _i++;
    }
}
    zT_1323 = at;
    zT_1327 = 0;
    zT_1328 = (unsigned char*)((unsigned char*)t3b) + zT_1327;
    zT_1329 = (unsigned int)(20) - zT_1327;
    zT_1330.ptr = zT_1328;
    zT_1330.len = zT_1329;
    zT_1324 = zT_1330;
    zT_1331 = zF_A7504564_itoa(zT_1323, zT_1324);
    t3l = zT_1331;
    zT_1335 = (unsigned int)(19) - (unsigned int)((unsigned int)t3l);
    t3s = zT_1335;
    zT_1340 = (unsigned char*)((unsigned char*)t3b) + t3s;
    zT_1341 = (unsigned int)(19) - t3s;
    zT_1342.ptr = zT_1340;
    zT_1342.len = zT_1341;
    zT_1336 = zT_1342;
    zF_48AC7B3A_markerWrite(zT_1336);
    if ((int)(at != (unsigned int)(18))) goto z_bb_220; else goto z_bb_222;
    z_bb_219:
    goto z_bb_173;
    z_bb_220:
    zT_1346 = "A";
    zT_1348 = 1;
    zT_1347.ptr = zT_1346;
    zT_1347.len = zT_1348;
    am = zT_1347;
    zT_1349 = am;
    zF_48AC7B3A_markerWrite(zT_1349);
    goto z_bb_221;
    z_bb_221:
    return at;
    z_bb_222:
    zT_1351 = "a";
    zT_1353 = 1;
    zT_1352.ptr = zT_1351;
    zT_1352.len = zT_1353;
    am = zT_1352;
    zT_1354 = am;
    zF_48AC7B3A_markerWrite(zT_1354);
    goto z_bb_221;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_40 = {0};
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_406493CE_StructPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_406493CE_StructPayload zT_54;
    unsigned short zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int* zT_62;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    int zT_70;
    unsigned int zT_71;
    int zT_72;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_80 = 0;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int* zT_94;
    unsigned int zT_96 = 0;
    int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_4028D896_Arr_unsigned_char_2 zT_121;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    int zT_127;
    unsigned char* zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131 = 0;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned char* zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_2DF01B61_FieldEntry* zT_146;
    unsigned int zT_147;
    zT_2DF01B61_FieldEntry* zT_150;
    char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_157;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    int zT_167;
    unsigned int zT_168;
    zT_33EF6BFB_TypeKind zT_169;
    zT_338B7C76_TypeRegistry* zT_175;
    zT_54FF90FA_TaggedUnionPayload* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_54FF90FA_TaggedUnionPayload zT_179;
    char* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_186;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned short zT_194;
    unsigned short zT_196;
    zT_6B0A7D14_AstStore* zT_200;
    unsigned int zT_201;
    unsigned int* zT_203;
    zT_22A7C88B_AstNode zT_205 = {0};
    zT_8143F551_AstKind zT_206;
    int zT_211;
    unsigned int zT_212;
    int zT_213;
    zT_ABC1EBBE_TypeResolveEnv* zT_216;
    unsigned int zT_217;
    unsigned int zT_221 = 0;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    char* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    zT_4028D896_Arr_unsigned_char_2 zT_241;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    zT_6B0A7D14_AstStore* zT_245;
    unsigned int zT_246;
    unsigned int* zT_248;
    unsigned int zT_250 = 0;
    int zT_253;
    unsigned char* zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257 = 0;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned char* zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_4028D896_Arr_unsigned_char_2 zT_275;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    int zT_281;
    unsigned char* zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285 = 0;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned char* zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_338B7C76_TypeRegistry* zT_304;
    zT_2DF01B61_FieldEntry* zT_305;
    unsigned int zT_306;
    zT_2DF01B61_FieldEntry* zT_309;
    char* zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_316;
    char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    int zT_331;
    unsigned int zT_332;
    zT_33EF6BFB_TypeKind zT_333;
    int zT_338;
    zT_33EF6BFB_TypeKind zT_339;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_AF9231A2_UnionPayload* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_AF9231A2_UnionPayload zT_349;
    unsigned short zT_350;
    zT_6B0A7D14_AstStore* zT_354;
    unsigned int zT_355;
    unsigned int* zT_357;
    zT_22A7C88B_AstNode zT_359 = {0};
    zT_8143F551_AstKind zT_360;
    int zT_365;
    unsigned int zT_366;
    int zT_367;
    zT_ABC1EBBE_TypeResolveEnv* zT_370;
    unsigned int zT_371;
    unsigned int zT_375 = 0;
    zT_338B7C76_TypeRegistry* zT_378;
    zT_2DF01B61_FieldEntry* zT_379;
    unsigned int zT_380;
    zT_2DF01B61_FieldEntry* zT_383;
    int zT_384;
    unsigned int zT_385;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    zT_3CB0179A_Slice_zT_05F374B1_u fchildren;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_4028D896_Arr_unsigned_char_2 b2_pb;
    unsigned int b2_pl;
    unsigned int b2_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_4028D896_Arr_unsigned_char_2 b2_tb;
    unsigned int b2_tl;
    unsigned int b2_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_21 = env->store;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_24)));
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_36 = env->store;
    zT_37 = decl.child_1;
    zT_40 = zF_850FDF81_astStoreNodeExtraCh(zT_36, zT_37);
    fchildren = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    zT_44 = sty.kind;
    if ((int)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_50 = env->typereg;
    zT_51 = zT_50->st_items;
    zT_52 = sty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    sp = zT_54;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_169 = sty.kind;
    if ((int)(zT_169 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_55 = sp.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_55))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_59 = env->store;
    zT_62 = fchildren.ptr;
    zT_60 = zT_62[fi2];
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    fd = zT_64;
    zT_65 = fd.kind;
    if ((int)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_167 = 1;
    zT_168 = fi2 + zT_167;
    fi2 = zT_168;
    goto z_bb_6;
    z_bb_10:
    zT_71 = fd.child_0;
    zT_72 = 0;
    zT_70 = zT_71 != (unsigned int)zT_72;
    goto z_bb_12;
    z_bb_11:
    zT_70 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_70) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_75 = env;
    zT_76 = fd.child_0;
    zT_80 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, (unsigned int)(0));
    ft = zT_80;
    zT_82 = "B2:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    b2_pn = zT_83;
    zT_85 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_91 = env->store;
    zT_94 = fchildren.ptr;
    zT_92 = zT_94[fi2];
    zT_96 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_96;
    zT_99 = 0;
    zT_100 = (unsigned char*)((unsigned char*)b2_pb) + zT_99;
    zT_101 = (unsigned int)(20) - zT_99;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_90 = zT_102;
    zT_103 = zF_A7504564_itoa(zT_89, zT_90);
    b2_pl = zT_103;
    zT_107 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_107;
    zT_112 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_113 = (unsigned int)(19) - b2_ps;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_116 = "t";
    zT_118 = 1;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    b2_tn = zT_117;
    zT_119 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_119);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_121[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_121[_i];
        _i++;
    }
}
    zT_123 = ft;
    zT_127 = 0;
    zT_128 = (unsigned char*)((unsigned char*)b2_tb) + zT_127;
    zT_129 = (unsigned int)(20) - zT_127;
    zT_130.ptr = zT_128;
    zT_130.len = zT_129;
    zT_124 = zT_130;
    zT_131 = zF_A7504564_itoa(zT_123, zT_124);
    b2_tl = zT_131;
    zT_135 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_135;
    zT_140 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_141 = (unsigned int)(19) - b2_ts;
    zT_142.ptr = zT_140;
    zT_142.len = zT_141;
    zT_136 = zT_142;
    zF_48AC7B3A_markerWrite(zT_136);
    if ((int)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_145 = env->typereg;
    zT_146 = zT_145->fe_items;
    zT_147 = sp.fields_start;
    zT_150 = zT_146 + (unsigned int)((unsigned int)((unsigned int)zT_147) + fi2);
    zT_150->type_id = ft;
    zT_152 = "FSW:n";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    fsw_nm = zT_153;
    zT_155 = fsw_nm;
    zT_157 = sp.fields_start;
    zF_C914CB83_markerWriteInt(zT_155, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_157) + fi2)));
    zT_162 = "FSW:t";
    zT_164 = 5;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    fsw_tm = zT_163;
    zT_165 = fsw_tm;
    zT_166 = ft;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_175 = env->typereg;
    zT_176 = zT_175->tu_items;
    zT_177 = sty.payload_idx;
    zT_178 = (unsigned int)zT_177;
    zT_179 = zT_176[zT_178];
    tp = zT_179;
    zT_181 = "TUI:fs";
    zT_183 = 6;
    zT_182.ptr = zT_181;
    zT_182.len = zT_183;
    tui_fsm = zT_182;
    zT_184 = tui_fsm;
    zT_186 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_184, (unsigned int)((unsigned int)zT_186));
    zT_189 = "TUI:fc";
    zT_191 = 6;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    tui_fcm = zT_190;
    zT_192 = tui_fcm;
    zT_194 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_192, (unsigned int)((unsigned int)zT_194));
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_333 = sty.kind;
    if ((int)(zT_333 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_33; else goto z_bb_32;
    z_bb_20:
    zT_196 = tp.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_196))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_200 = env->store;
    zT_203 = fchildren.ptr;
    zT_201 = zT_203[fi2];
    zT_205 = zF_FCDD1D35_astStoreNodeAt(zT_200, zT_201);
    fd = zT_205;
    zT_206 = fd.kind;
    if ((int)(zT_206 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_331 = 1;
    zT_332 = fi2 + zT_331;
    fi2 = zT_332;
    goto z_bb_20;
    z_bb_24:
    zT_212 = fd.child_0;
    zT_213 = 0;
    zT_211 = zT_212 != (unsigned int)zT_213;
    goto z_bb_26;
    z_bb_25:
    zT_211 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_211) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_216 = env;
    zT_217 = fd.child_0;
    zT_221 = zF_F2107C15_resolveTypeExprFull(zT_216, zT_217, (unsigned int)(0));
    ft = zT_221;
    zT_223 = "DFT:n";
    zT_225 = 5;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    dft_nm = zT_224;
    zT_226 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_226, (unsigned int)((unsigned int)fi2));
    zT_230 = "DFT:t";
    zT_232 = 5;
    zT_231.ptr = zT_230;
    zT_231.len = zT_232;
    dft_tm = zT_231;
    zT_233 = dft_tm;
    zT_234 = ft;
    zF_C914CB83_markerWriteInt(zT_233, zT_234);
    zT_236 = "B2:p";
    zT_238 = 4;
    zT_237.ptr = zT_236;
    zT_237.len = zT_238;
    b2_pn = zT_237;
    zT_239 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_239);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_241[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_241[_i];
        _i++;
    }
}
    zT_245 = env->store;
    zT_248 = fchildren.ptr;
    zT_246 = zT_248[fi2];
    zT_250 = zF_8BA26B9E_astStoreNodePayload(zT_245, zT_246);
    zT_243 = zT_250;
    zT_253 = 0;
    zT_254 = (unsigned char*)((unsigned char*)b2_pb) + zT_253;
    zT_255 = (unsigned int)(20) - zT_253;
    zT_256.ptr = zT_254;
    zT_256.len = zT_255;
    zT_244 = zT_256;
    zT_257 = zF_A7504564_itoa(zT_243, zT_244);
    b2_pl = zT_257;
    zT_261 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_pl);
    b2_ps = zT_261;
    zT_266 = (unsigned char*)((unsigned char*)b2_pb) + b2_ps;
    zT_267 = (unsigned int)(19) - b2_ps;
    zT_268.ptr = zT_266;
    zT_268.len = zT_267;
    zT_262 = zT_268;
    zF_48AC7B3A_markerWrite(zT_262);
    zT_270 = "t";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    b2_tn = zT_271;
    zT_273 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_273);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_275[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_275[_i];
        _i++;
    }
}
    zT_277 = ft;
    zT_281 = 0;
    zT_282 = (unsigned char*)((unsigned char*)b2_tb) + zT_281;
    zT_283 = (unsigned int)(20) - zT_281;
    zT_284.ptr = zT_282;
    zT_284.len = zT_283;
    zT_278 = zT_284;
    zT_285 = zF_A7504564_itoa(zT_277, zT_278);
    b2_tl = zT_285;
    zT_289 = (unsigned int)(19) - (unsigned int)((unsigned int)b2_tl);
    b2_ts = zT_289;
    zT_294 = (unsigned char*)((unsigned char*)b2_tb) + b2_ts;
    zT_295 = (unsigned int)(19) - b2_ts;
    zT_296.ptr = zT_294;
    zT_296.len = zT_295;
    zT_290 = zT_296;
    zF_48AC7B3A_markerWrite(zT_290);
    zT_298 = "DTWR\n";
    zT_300 = 5;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    dtwr_m = zT_299;
    zT_301 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_301);
    if ((int)(ft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_304 = env->typereg;
    zT_305 = zT_304->fe_items;
    zT_306 = tp.fields_start;
    zT_309 = zT_305 + (unsigned int)((unsigned int)((unsigned int)zT_306) + fi2);
    zT_309->type_id = ft;
    zT_311 = "FTW:n";
    zT_313 = 5;
    zT_312.ptr = zT_311;
    zT_312.len = zT_313;
    ftw_nm = zT_312;
    zT_314 = ftw_nm;
    zT_316 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_314, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_316) + fi2)));
    zT_321 = "FTW:t";
    zT_323 = 5;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    ftw_tm = zT_322;
    zT_324 = ftw_tm;
    zT_325 = ft;
    zF_C914CB83_markerWriteInt(zT_324, zT_325);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_327 = "DTSK\n";
    zT_329 = 5;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    dtsk_m = zT_328;
    zT_330 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_330);
    goto z_bb_30;
    z_bb_32:
    zT_339 = sty.kind;
    zT_338 = zT_339 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_34;
    z_bb_33:
    zT_338 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_338) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_345 = env->typereg;
    zT_346 = zT_345->un_items;
    zT_347 = sty.payload_idx;
    zT_348 = (unsigned int)zT_347;
    zT_349 = zT_346[zT_348];
    up = zT_349;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_18;
    z_bb_37:
    zT_350 = up.fields_count;
    if ((int)(fi2 < (unsigned int)((unsigned int)zT_350))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_354 = env->store;
    zT_357 = fchildren.ptr;
    zT_355 = zT_357[fi2];
    zT_359 = zF_FCDD1D35_astStoreNodeAt(zT_354, zT_355);
    fd = zT_359;
    zT_360 = fd.kind;
    if ((int)(zT_360 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_384 = 1;
    zT_385 = fi2 + zT_384;
    fi2 = zT_385;
    goto z_bb_37;
    z_bb_41:
    zT_366 = fd.child_0;
    zT_367 = 0;
    zT_365 = zT_366 != (unsigned int)zT_367;
    goto z_bb_43;
    z_bb_42:
    zT_365 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_365) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_370 = env;
    zT_371 = fd.child_0;
    zT_375 = zF_F2107C15_resolveTypeExprFull(zT_370, zT_371, (unsigned int)(0));
    ft = zT_375;
    if ((int)(ft != (unsigned int)(18))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_40;
    z_bb_46:
    zT_378 = env->typereg;
    zT_379 = zT_378->fe_items;
    zT_380 = up.fields_start;
    zT_383 = zT_379 + (unsigned int)((unsigned int)((unsigned int)zT_380) + fi2);
    zT_383->type_id = ft;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_45;
}

/* varDeclInitNeedsNameCache */
int zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    if ((int)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    return (int)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_26 = {0};
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int* zT_37;
    zT_22A7C88B_AstNode zT_39 = {0};
    zT_8143F551_AstKind zT_40;
    int zT_45;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    int zT_57 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_60;
    unsigned int zT_64 = 0;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int* zT_77;
    unsigned int zT_79 = 0;
    zT_79FAE712_u64 zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_79FAE712_u64 zT_83;
    unsigned int zT_84;
    zT_3D7259E2_SymbolRegistry* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_6E8D187B_ModuleEntry* zT_91;
    zT_6E8D187B_ModuleEntry zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    unsigned int* zT_97;
    unsigned int zT_99 = 0;
    zT_D7876732_Opt_823 zT_100 = {0};
    unsigned char zT_101;
    int zT_103;
    unsigned int zT_104;
    int zT_105;
    unsigned int zT_106;
    unsigned int ci;
    unsigned int cr;
    zT_3CB0179A_Slice_zT_05F374B1_u cd;
    unsigned int cdi;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_D7876732_Opt_823 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((int)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    if ((int)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_105 = 1;
    zT_106 = ci + zT_105;
    ci = zT_106;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_18 = env->store;
    zT_19 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = cr;
    zT_26 = zF_850FDF81_astStoreNodeExtraCh(zT_23, zT_24);
    cd = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    cdi = zT_29;
    goto z_bb_7;
    z_bb_7:
    zT_31 = cd.len;
    if ((int)(cdi < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_34 = env->store;
    zT_37 = cd.ptr;
    zT_35 = zT_37[cdi];
    zT_39 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    cdcl = zT_39;
    zT_40 = cdcl.kind;
    if ((int)(zT_40 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_103 = 1;
    zT_104 = cdi + zT_103;
    cdi = zT_104;
    goto z_bb_7;
    z_bb_11:
    zT_46 = cdcl.child_1;
    zT_45 = zT_46 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_45 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_50 = env->store;
    zT_51 = cdcl.child_1;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    cdinit = zT_54;
    zT_55 = cdinit.kind;
    zT_57 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_55);
    if (zT_57) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_59 = env;
    zT_60 = cdcl.child_1;
    zT_64 = zF_F2107C15_resolveTypeExprFull(zT_59, zT_60, (unsigned int)(0));
    cdtype = zT_64;
    if ((int)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_68 = mods.ptr;
    zT_69 = zT_68[ci];
    zT_70 = zT_69.id;
    zT_74 = env->store;
    zT_77 = cd.ptr;
    zT_75 = zT_77[cdi];
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_81 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_79);
    ck = zT_81;
    zT_82 = env->typereg;
    zT_83 = ck;
    zT_84 = cdtype;
    zF_5E95558D_nameCachePut(zT_82, zT_83, zT_84);
    zT_87 = env->symbol_reg;
    zT_91 = mods.ptr;
    zT_92 = zT_91[ci];
    zT_88 = zT_92.id;
    zT_94 = env->store;
    zT_97 = cd.ptr;
    zT_95 = zT_97[cdi];
    zT_99 = zF_8BA26B9E_astStoreNodePayload(zT_94, zT_95);
    zT_89 = zT_99;
    zT_100 = zF_A398987E_symbolRegistryQuali(zT_87, zT_88, zT_89);
    cdsym = zT_100;
    zT_101 = cdsym.has_value;
    if (zT_101) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_D7876732_Opt_823 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_072B53A6_ModuleRegistry* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_64 = 0;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_ABC1EBBE_TypeResolveEnv* zT_68;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_78 = 0;
    unsigned int zT_80;
    zT_D7876732_Opt_823 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((int)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((int)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_34 = env->store;
    zT_35 = fd.child_1;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    fi = zT_38;
    zT_39 = fi.kind;
    if ((int)(zT_39 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_46 = env->store;
    zT_47 = fi.child_0;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_46, zT_47);
    fb = zT_50;
    zT_51 = fb.kind;
    if ((int)(zT_51 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_58 = module_reg;
    zT_60 = env->store;
    zT_61 = fi.child_0;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_59 = zT_64;
    zT_65 = zF_A258E183_moduleRegistryPathT(zT_58, zT_59);
    t2 = zT_65;
    zT_66 = t2.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_68 = env;
    zT_69 = module_reg;
    zT_70 = importer_mod_id;
    zT_71 = m2;
    zT_74 = env->store;
    zT_75 = fd.child_1;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_72 = zT_78;
    zT_80 = depth + (unsigned int)(1);
    env = zT_68;
    module_reg = zT_69;
    importer_mod_id = zT_70;
    target_mod_id = zT_71;
    field_name_id = zT_72;
    depth = zT_80;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_24 = {0};
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned int* zT_35;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    zT_BAEE192E_Opt_10 zT_76 = {0};
    unsigned char zT_77;
    zT_ABC1EBBE_TypeResolveEnv* zT_80;
    zT_072B53A6_ModuleRegistry* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_6E8D187B_ModuleEntry* zT_86;
    zT_6E8D187B_ModuleEntry zT_87;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int zT_93 = 0;
    unsigned int zT_95 = 0;
    zT_3D7259E2_SymbolRegistry* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    unsigned int* zT_109;
    unsigned int zT_111 = 0;
    zT_D7876732_Opt_823 zT_112 = {0};
    unsigned char zT_113;
    zT_6E8D187B_ModuleEntry* zT_116;
    zT_6E8D187B_ModuleEntry zT_117;
    unsigned int zT_118;
    zT_6B0A7D14_AstStore* zT_122;
    unsigned int zT_123;
    unsigned int* zT_125;
    unsigned int zT_127 = 0;
    zT_79FAE712_u64 zT_129;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    int zT_134;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_D7876732_Opt_823 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((int)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_136 = 1;
    zT_137 = mi + zT_136;
    mi = zT_137;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = env->store;
    zT_17 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    zT_21 = env->store;
    zT_22 = root;
    zT_24 = zF_850FDF81_astStoreNodeExtraCh(zT_21, zT_22);
    decls = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    zT_29 = decls.len;
    if ((int)(di < zT_29)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = env->store;
    zT_35 = decls.ptr;
    zT_33 = zT_35[di];
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    decl = zT_37;
    zT_38 = decl.kind;
    if ((int)(zT_38 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_134 = 1;
    zT_135 = di + zT_134;
    di = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_43 = decl.child_1;
    if ((int)(zT_43 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_47 = env->store;
    zT_48 = decl.child_1;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    zT_52 = init.kind;
    if ((int)(zT_52 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_58 = env->store;
    zT_59 = init.child_0;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    base = zT_62;
    zT_63 = base.kind;
    if ((int)(zT_63 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_69 = module_reg;
    zT_71 = env->store;
    zT_72 = init.child_0;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_70 = zT_75;
    zT_76 = zF_A258E183_moduleRegistryPathT(zT_69, zT_70);
    target = zT_76;
    zT_77 = target.has_value;
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_80 = env;
    zT_81 = module_reg;
    zT_86 = mods.ptr;
    zT_87 = zT_86[mi];
    zT_82 = zT_87.id;
    zT_83 = mtid;
    zT_89 = env->store;
    zT_90 = decl.child_1;
    zT_93 = zF_8BA26B9E_astStoreNodePayload(zT_89, zT_90);
    zT_84 = zT_93;
    zT_95 = zF_E8C2AADA_resolveImportFieldA(zT_80, zT_81, zT_82, zT_83, zT_84, (unsigned int)(0));
    resolved = zT_95;
    if ((int)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_99 = env->symbol_reg;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_100 = zT_104.id;
    zT_106 = env->store;
    zT_109 = decls.ptr;
    zT_107 = zT_109[di];
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_106, zT_107);
    zT_101 = zT_111;
    zT_112 = zF_A398987E_symbolRegistryQuali(zT_99, zT_100, zT_101);
    sym = zT_112;
    zT_113 = sym.has_value;
    if (zT_113) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_116 = mods.ptr;
    zT_117 = zT_116[mi];
    zT_118 = zT_117.id;
    zT_122 = env->store;
    zT_125 = decls.ptr;
    zT_123 = zT_125[di];
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_122, zT_123);
    zT_129 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_118) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_127);
    ck = zT_129;
    zT_130 = env->typereg;
    zT_131 = ck;
    zT_132 = resolved;
    zF_5E95558D_nameCachePut(zT_130, zT_131, zT_132);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_22A7C88B_AstNode zT_36 = {0};
    zT_8143F551_AstKind zT_37;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    int zT_57;
    zT_8143F551_AstKind zT_58;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_66;
    zT_6E8D187B_ModuleEntry zT_67;
    unsigned int* zT_69;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((int)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_73 = 1;
    zT_74 = mi + zT_73;
    mi = zT_74;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = env->store;
    zT_16 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_15, zT_16);
    zT_20 = env->store;
    zT_21 = root;
    zT_23 = zF_850FDF81_astStoreNodeExtraCh(zT_20, zT_21);
    decls = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    di = zT_26;
    goto z_bb_7;
    z_bb_7:
    zT_28 = decls.len;
    if ((int)(di < zT_28)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = env->store;
    zT_34 = decls.ptr;
    zT_32 = zT_34[di];
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    decl = zT_36;
    zT_37 = decl.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_71 = 1;
    zT_72 = di + zT_71;
    di = zT_72;
    goto z_bb_7;
    z_bb_11:
    zT_43 = decl.child_1;
    zT_44 = 0;
    zT_42 = zT_43 != (unsigned int)zT_44;
    goto z_bb_13;
    z_bb_12:
    zT_42 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_42) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_47 = env->store;
    zT_48 = decl.child_1;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    zT_52 = init.kind;
    if ((int)(zT_52 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_58 = init.kind;
    zT_57 = zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_57 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_63 = env;
    zT_66 = mods.ptr;
    zT_67 = zT_66[mi];
    zT_64 = zT_67.id;
    zT_69 = decls.ptr;
    zT_65 = zT_69[di];
    zF_F5C3193B_resolveDeclAggregat(zT_63, zT_64, zT_65);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    zT_6B0A7D14_AstStore* zT_47;
    zT_C0653C9E_anon_199689 zT_48;
    zT_243D6A41_FnProto* zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    unsigned int* zT_53;
    unsigned int zT_55 = 0;
    unsigned int zT_56;
    zT_243D6A41_FnProto zT_57;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_6E8D187B_ModuleEntry* zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_D7876732_Opt_823 zT_67 = {0};
    unsigned char zT_68;
    unsigned int zT_70;
    zT_939EE900_Arr_unsigned_int_1 zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    int zT_89;
    zT_8EED1867_ResolvedTypeTable* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char zT_101;
    unsigned char zT_103;
    unsigned char zT_104;
    unsigned char zT_109;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned short zT_114;
    unsigned int zT_118;
    unsigned short zT_122;
    zT_79FAE712_u64 zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    zT_79FAE712_u64 zT_127;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_129 = {0};
    int zT_131;
    unsigned int zT_132;
    unsigned int zT_134;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_138;
    unsigned int* zT_140;
    zT_22A7C88B_AstNode zT_142 = {0};
    unsigned int zT_143;
    int zT_144;
    zT_ABC1EBBE_TypeResolveEnv* zT_147;
    unsigned int zT_148;
    unsigned int zT_152 = 0;
    zT_338B7C76_TypeRegistry* zT_153;
    unsigned int zT_154;
    zT_8EED1867_ResolvedTypeTable* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    int zT_162;
    unsigned int zT_163;
    zT_338B7C76_TypeRegistry* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    unsigned int zT_170;
    unsigned short zT_171;
    unsigned int zT_172;
    zT_6E8D187B_ModuleEntry* zT_175;
    zT_6E8D187B_ModuleEntry zT_176;
    int zT_179;
    unsigned int zT_181 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int* zT_185;
    zT_3D7259E2_SymbolRegistry* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_6E8D187B_ModuleEntry* zT_192;
    zT_6E8D187B_ModuleEntry zT_193;
    zT_D7876732_Opt_823 zT_196 = {0};
    unsigned char zT_197;
    zT_8143F551_AstKind zT_199;
    int zT_204;
    unsigned int zT_205;
    int zT_206;
    zT_ABC1EBBE_TypeResolveEnv* zT_209;
    unsigned int zT_210;
    unsigned int zT_214 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8EED1867_ResolvedTypeTable* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int* zT_224;
    zT_3D7259E2_SymbolRegistry* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_6E8D187B_ModuleEntry* zT_231;
    zT_6E8D187B_ModuleEntry zT_232;
    zT_6B0A7D14_AstStore* zT_234;
    unsigned int zT_235;
    unsigned int* zT_237;
    unsigned int zT_239 = 0;
    zT_D7876732_Opt_823 zT_240 = {0};
    unsigned char zT_241;
    int zT_243;
    unsigned int zT_244;
    int zT_245;
    unsigned int zT_246;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_D7876732_Opt_823 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    unsigned int fn_start;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    unsigned int tid;
    zT_D7876732_Opt_823 sym;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((int)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((int)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_245 = 1;
    zT_246 = mi + zT_245;
    mi = zT_246;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_19 = env->store;
    zT_20 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    zT_24 = env->store;
    zT_25 = root;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    decls = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    di = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = decls.len;
    if ((int)(di < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = env->store;
    zT_38 = decls.ptr;
    zT_36 = zT_38[di];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    decl = zT_40;
    zT_41 = decl.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_243 = 1;
    zT_244 = di + zT_243;
    di = zT_244;
    goto z_bb_7;
    z_bb_11:
    zT_47 = env->store;
    zT_48 = zT_47->fn_protos;
    zT_49 = zT_48.items;
    zT_50 = env->store;
    zT_53 = decls.ptr;
    zT_51 = zT_53[di];
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_50, zT_51);
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_49[zT_56];
    proto = zT_57;
    zT_59 = env->symbol_reg;
    zT_63 = mods.ptr;
    zT_64 = zT_63[mi];
    zT_60 = zT_64.id;
    zT_61 = proto.name_id;
    zT_67 = zF_A398987E_symbolRegistryQuali(zT_59, zT_60, zT_61);
    sym_check = zT_67;
    zT_68 = sym_check.has_value;
    if (zT_68) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_199 = decl.kind;
    if ((int)(zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_38; else goto z_bb_39;
    z_bb_14:
    sc = sym_check.value;
    zT_70 = sc->type_id;
    if ((int)(zT_70 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_75 = 1;
    zT_76 = 0;
    zT_74[zT_76] = zT_75;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_74[_i];
        _i++;
    }
}
    zT_77 = proto.return_type_node;
    zT_78 = 0;
    if ((int)(zT_77 != (unsigned int)zT_78)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_81 = env;
    zT_82 = proto.return_type_node;
    zT_86 = zF_F2107C15_resolveTypeExprFull(zT_81, zT_82, (unsigned int)(0));
    rtype = zT_86;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_95 = 0;
    is_ext = zT_95;
    zT_96 = decl.flags;
    if ((int)((unsigned char)(zT_96 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_89 = 0;
    rt_box[zT_89] = rtype;
    zT_90 = resolved_types;
    zT_91 = proto.return_type_node;
    zT_92 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_90, zT_91, zT_92);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_101 = 1;
    is_ext = zT_101;
    goto z_bb_23;
    z_bb_23:
    zT_103 = 0;
    is_variadic = zT_103;
    zT_104 = decl.flags;
    if ((int)((unsigned char)(zT_104 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_109 = 1;
    is_variadic = zT_109;
    goto z_bb_25;
    z_bb_25:
    zT_111 = env->typereg;
    zT_112 = zT_111->xt_len;
    zT_113 = (unsigned int)zT_112;
    fn_start = zT_113;
    zT_114 = proto.params_count;
    if ((int)(zT_114 > (unsigned short)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_118 = proto.params_start;
    zT_122 = proto.params_count;
    zT_124 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_118) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_122);
    p_payload = zT_124;
    zT_126 = env->store;
    zT_127 = p_payload;
    zT_129 = zF_3EAD7B21_astStoreGetExtraChi(zT_126, zT_127);
    pnodes = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    pi = zT_132;
    goto z_bb_28;
    z_bb_27:
    zT_165 = env->typereg;
    zT_166 = proto.name_id;
    zT_175 = mods.ptr;
    zT_176 = zT_175[mi];
    zT_167 = zT_176.id;
    zT_168 = is_ext;
    zT_169 = is_variadic;
    zT_170 = fn_start;
    zT_171 = proto.params_count;
    zT_179 = 0;
    zT_172 = rt_box[zT_179];
    zT_181 = zF_474336D7_typeRegistryGetOrCr(zT_165, zT_166, zT_167, zT_168, zT_169, zT_170, zT_171, zT_172);
    tid = zT_181;
    zT_182 = resolved_types;
    zT_185 = decls.ptr;
    zT_183 = zT_185[di];
    zT_184 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_182, zT_183, zT_184);
    zT_188 = env->symbol_reg;
    zT_192 = mods.ptr;
    zT_193 = zT_192[mi];
    zT_189 = zT_193.id;
    zT_190 = proto.name_id;
    zT_196 = zF_A398987E_symbolRegistryQuali(zT_188, zT_189, zT_190);
    sym = zT_196;
    zT_197 = sym.has_value;
    if (zT_197) goto z_bb_36; else goto z_bb_37;
    z_bb_28:
    zT_134 = pnodes.len;
    if ((int)(pi < zT_134)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_137 = env->store;
    zT_140 = pnodes.ptr;
    zT_138 = zT_140[pi];
    zT_142 = zF_FCDD1D35_astStoreNodeAt(zT_137, zT_138);
    pnode = zT_142;
    zT_143 = pnode.child_0;
    zT_144 = 0;
    if ((int)(zT_143 != (unsigned int)zT_144)) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_162 = 1;
    zT_163 = pi + zT_162;
    pi = zT_163;
    goto z_bb_28;
    z_bb_32:
    zT_147 = env;
    zT_148 = pnode.child_0;
    zT_152 = zF_F2107C15_resolveTypeExprFull(zT_147, zT_148, (unsigned int)(0));
    ptype = zT_152;
    zT_153 = env->typereg;
    zT_154 = ptype;
    zF_4C03AE3D_xtAppend(zT_153, zT_154);
    if ((int)(ptype != (unsigned int)(18))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_158 = resolved_types;
    zT_159 = pnode.child_0;
    zT_160 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_158, zT_159, zT_160);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_205 = decl.child_0;
    zT_206 = 0;
    zT_204 = zT_205 != (unsigned int)zT_206;
    goto z_bb_40;
    z_bb_39:
    zT_204 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_204) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_209 = env;
    zT_210 = decl.child_0;
    zT_214 = zF_F2107C15_resolveTypeExprFull(zT_209, zT_210, (unsigned int)(0));
    vtype = zT_214;
    if ((int)(vtype != (unsigned int)(18))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_12;
    z_bb_43:
    zT_217 = resolved_types;
    zT_218 = decl.child_0;
    zT_219 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    zT_221 = resolved_types;
    zT_224 = decls.ptr;
    zT_222 = zT_224[di];
    zT_223 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_221, zT_222, zT_223);
    zT_227 = env->symbol_reg;
    zT_231 = mods.ptr;
    zT_232 = zT_231[mi];
    zT_228 = zT_232.id;
    zT_234 = env->store;
    zT_237 = decls.ptr;
    zT_235 = zT_237[di];
    zT_239 = zF_8BA26B9E_astStoreNodePayload(zT_234, zT_235);
    zT_229 = zT_239;
    zT_240 = zF_A398987E_symbolRegistryQuali(zT_227, zT_228, zT_229);
    sym = zT_240;
    zT_241 = sym.has_value;
    if (zT_241) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_46;
    z_bb_46:
    goto z_bb_44;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_8;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_9 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_11;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_14;
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17;
    zT_072B53A6_ModuleRegistry* zT_18;
    zT_ABC1EBBE_TypeResolveEnv* zT_20;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_23;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_24;
    zT_8EED1867_ResolvedTypeTable* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_8 = module_reg;
    zT_9 = zF_3452C137_moduleRegistryGetMo(zT_8);
    mods = zT_9;
    zT_11.store = store;
    zT_11.typereg = typereg;
    zT_11.symbol_reg = symbol_reg;
    zT_11.interner = interner;
    zT_11.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    env = zT_11;
    (void)perm_alloc;
    zT_13 = &env;
    zT_14 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_13, zT_14);
    zT_16 = &env;
    zT_17 = mods;
    zT_18 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_16, zT_17, zT_18);
    zT_20 = &env;
    zT_21 = mods;
    zF_E2882212_resolveAggregateFie(zT_20, zT_21);
    zT_23 = &env;
    zT_24 = mods;
    zT_25 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_23, zT_24, zT_25);
    return;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
    return;
}

/* EOF */
