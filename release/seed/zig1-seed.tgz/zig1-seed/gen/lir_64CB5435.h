#ifndef ZIG_MODULE_LIR_64CB5435_H
#define ZIG_MODULE_LIR_64CB5435_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "hash_02AFCD13.h"

#ifndef ZIG_STRUCT_zT_4BD97095_SwitchCase
#define ZIG_STRUCT_zT_4BD97095_SwitchCase
struct zT_4BD97095_SwitchCase {
	zT_79FAE712_u64 value;
	unsigned int target_bb;
};
#endif /* ZIG_STRUCT_zT_4BD97095_SwitchCase */
#ifndef ZIG_STRUCT_zT_8779209D_LirParam
#define ZIG_STRUCT_zT_8779209D_LirParam
struct zT_8779209D_LirParam {
	unsigned int name_id;
	unsigned int type_id;
	unsigned int temp_id;
};
#endif /* ZIG_STRUCT_zT_8779209D_LirParam */
#ifndef ZIG_STRUCT_zT_1937645B_TempDecl
#define ZIG_STRUCT_zT_1937645B_TempDecl
struct zT_1937645B_TempDecl {
	unsigned int temp_id;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_1937645B_TempDecl */
#ifndef ZIG_STRUCT_zT_E7714190_LirSlot
#define ZIG_STRUCT_zT_E7714190_LirSlot
struct zT_E7714190_LirSlot {
	unsigned int module_id;
	unsigned int disk_offset;
	unsigned int byte_len;
};
#endif /* ZIG_STRUCT_zT_E7714190_LirSlot */
#ifndef ZIG_STRUCT_zT_54906056_ModuleGlobalDecl
#define ZIG_STRUCT_zT_54906056_ModuleGlobalDecl
struct zT_54906056_ModuleGlobalDecl {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int type_id;
	unsigned char has_runtime_init;
};
#endif /* ZIG_STRUCT_zT_54906056_ModuleGlobalDecl */

/* Forward declarations */
zT_AC00B5F6_LirSideEntryArrayLi zF_4231AD2C_lirSideEntryArrayLi(zT_3E40CD83_Sand*);
void zF_B5A8F8E4_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi*, unsigned int);
void zF_6E2511C2_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi*, zT_A8A5B231_LirSideEntry);
zT_99DE57BF_Slice_zT_A8A5B231_L zF_AC1429C8_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi*);
zT_DAE4631D_LirInstArrayList zF_C6E3B5BB_lirInstArrayListIni(zT_3E40CD83_Sand*);
void zF_178C876B_lirInstArrayListEns(zT_DAE4631D_LirInstArrayList*, unsigned int);
void zF_4BFD6009_lirInstArrayListApp(zT_DAE4631D_LirInstArrayList*, zT_6BA597BC_LirInst);
zT_804A8058_Slice_zT_6BA597BC_L zF_33BACEFF_lirInstArrayListGet(zT_DAE4631D_LirInstArrayList*);
zT_1CF28CA3_BasicBlockArrayList zF_2B78727D_basicBlockArrayList(zT_3E40CD83_Sand*);
void zF_DFD16D95_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList*, unsigned int);
void zF_09D85813_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList*, zT_88A68B1A_BasicBlock);
zT_A12E931C_Slice_zT_88A68B1A_B zF_EF689609_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList*);
zT_CFE23D0A_LirParamArrayList zF_0ED358C0_lirParamArrayListIn(zT_3E40CD83_Sand*);
void zF_D7BA6100_lirParamArrayListEn(zT_CFE23D0A_LirParamArrayList*, unsigned int);
void zF_5266C13E_lirParamArrayListAp(zT_CFE23D0A_LirParamArrayList*, zT_8779209D_LirParam);
zT_2F054080_Slice_zT_8779209D_L zF_DFC53FA4_lirParamArrayListGe(zT_CFE23D0A_LirParamArrayList*);
zT_5D72FBF8_TempDeclArrayList zF_DE63156A_tempDeclArrayListIn(zT_3E40CD83_Sand*);
void zF_2A1781A2_tempDeclArrayListEn(zT_5D72FBF8_TempDeclArrayList*, unsigned int);
void zF_70DD3460_tempDeclArrayListAp(zT_5D72FBF8_TempDeclArrayList*, zT_1937645B_TempDecl);
zT_732DFD13_Slice_zT_1937645B_T zF_5450447E_tempDeclArrayListGe(zT_5D72FBF8_TempDeclArrayList*);
zT_9F514E82_SwitchCaseArrayList zF_64707188_switchCaseArrayList(zT_3E40CD83_Sand*);
void zF_937B1D28_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList*, unsigned int);
void zF_AFFB7306_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList*, zT_4BD97095_SwitchCase);
zT_11D00852_Slice_zT_4BD97095_S zF_82C0CEBC_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList*);
zT_CA01C129_LirSlotArrayList zF_F91F6677_lirSlotArrayListIni(zT_3E40CD83_Sand*);
void zF_851221CF_lirSlotArrayListEns(zT_CA01C129_LirSlotArrayList*, unsigned int);
void zF_BD1C46FD_lirSlotArrayListApp(zT_CA01C129_LirSlotArrayList*, zT_E7714190_LirSlot);
zT_E44058BB_Slice_zT_E7714190_L zF_8E0BDF63_lirSlotArrayListGet(zT_CA01C129_LirSlotArrayList*);
unsigned int zF_F05FBDC6_lirSideAppendCallDi(zT_BBC23664_LirFunction*, zT_3BFB1E70_CallDirectData);
unsigned int zF_79C20A59_lirSideAppendTailCa(zT_BBC23664_LirFunction*, zT_0624AC1B_TailCallData);
zT_3BFB1E70_CallDirectData zF_75DE985C_lirSideGetCallDirec(zT_BBC23664_LirFunction*, unsigned int);
zT_0624AC1B_TailCallData zF_1AB3807F_lirSideGetTailCall(zT_BBC23664_LirFunction*, unsigned int);
zT_E1A783EF_GlobalDeclArrayList zF_EB0B1609_globalDeclArrayList(zT_3E40CD83_Sand*);
void zF_31512729_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList*, unsigned int);
void zF_F2C82CE7_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList*, zT_54906056_ModuleGlobalDecl);
zT_23133B1E_Slice_zT_54906056_M zF_6ACCE52D_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList*);
/* Storage globals (extern decls) */
extern zT_CA01C129_LirSlotArrayList zG_CA01C129_LirSlotArrayList;
extern zT_BBC23664_LirFunction zG_BBC23664_LirFunction;
extern zT_E7714190_LirSlot zG_E7714190_LirSlot;
extern zT_6BA597BC_LirInst zG_6BA597BC_LirInst;

#endif /* ZIG_MODULE_LIR_64CB5435_H */
