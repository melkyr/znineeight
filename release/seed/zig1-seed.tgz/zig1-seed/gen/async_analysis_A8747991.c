#include "async_analysis_A8747991.h"
/* asyncKey */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int module_id, unsigned int name_id) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
}

/* asyncIsSuspending */
int zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8 = 0;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 v;
    unsigned int val;
    zT_4 = map;
    zT_6 = module_id;
    zT_7 = name_id;
    zT_8 = zF_9D041EB6_asyncKey(zT_6, zT_7);
    zT_5 = zT_8;
    zT_9 = zF_A05A7BE1_u64ToU32MapGet(zT_4, zT_5);
    v = zT_9;
    zT_10 = v.has_value;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    val = v.value;
    return (int)(val != (unsigned int)(0));
    z_bb_2:
    return (int)(0);
}

/* asyncFrameSizeOf */
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    return zT_8;
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand* sand, unsigned int count) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int c;
    unsigned char* raw;
    c = count;
    if ((int)(c == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    c = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = sand;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)(4) * c), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    return (unsigned int*)((unsigned int*)raw);
}

/* resolveCalleeKey */
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int callee_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_3D7259E2_SymbolRegistry* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_5979294E_Opt_849 zT_20 = {0};
    unsigned char zT_21;
    zT_3C598AEF_SymbolKind zT_23;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    zT_BBEE1AC1_Opt_11 zT_33;
    zT_BBEE1AC1_Opt_11 zT_34 = {0};
    zT_8143F551_AstKind zT_35;
    zT_BBEE1AC1_Opt_11 zT_40 = {0};
    zT_99292002_Arr_unsigned_int_16 zT_42;
    int zT_44;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_58 = {0};
    zT_8143F551_AstKind zT_59;
    zT_BBEE1AC1_Opt_11 zT_66 = {0};
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_22A7C88B_AstNode zT_77 = {0};
    zT_8143F551_AstKind zT_78;
    zT_BBEE1AC1_Opt_11 zT_83 = {0};
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_87 = 0;
    zT_3D7259E2_SymbolRegistry* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_5979294E_Opt_849 zT_92 = {0};
    unsigned char zT_93;
    zT_3C598AEF_SymbolKind zT_95;
    zT_BBEE1AC1_Opt_11 zT_100 = {0};
    unsigned int zT_101;
    zT_BBEE1AC1_Opt_11 zT_102 = {0};
    int zT_106;
    unsigned int zT_108;
    zT_3D7259E2_SymbolRegistry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_5979294E_Opt_849 zT_114 = {0};
    unsigned char zT_115;
    zT_3C598AEF_SymbolKind zT_117;
    zT_BBEE1AC1_Opt_11 zT_122 = {0};
    unsigned int zT_123;
    zT_BBEE1AC1_Opt_11 zT_124 = {0};
    zT_3D7259E2_SymbolRegistry* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_128;
    zT_5979294E_Opt_849 zT_130 = {0};
    unsigned char zT_131;
    zT_3C598AEF_SymbolKind zT_133;
    unsigned int zT_138;
    unsigned int zT_139;
    zT_79FAE712_u64 zT_142 = 0;
    zT_BBEE1AC1_Opt_11 zT_143;
    zT_BBEE1AC1_Opt_11 zT_144 = {0};
    zT_22A7C88B_AstNode cn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_99292002_Arr_unsigned_int_16 names;
    unsigned int nlen;
    unsigned int cur;
    zT_22A7C88B_AstNode cw;
    unsigned int base_nid;
    unsigned int cur_mod;
    zT_3A105EF1_Symbol* bs;
    unsigned int i;
    zT_3A105EF1_Symbol* ms;
    zT_3A105EF1_Symbol* fs;
    zT_5 = store;
    zT_6 = callee_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    cn = zT_7;
    zT_8 = cn.kind;
    if ((int)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = store;
    zT_15 = callee_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_14, zT_15);
    nid = zT_16;
    zT_17 = sym_reg;
    zT_18 = module_id;
    zT_19 = nid;
    zT_20 = zF_A398987E_symbolRegistryQuali(zT_17, zT_18, zT_19);
    zT_21 = zT_20.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_35 = cn.kind;
    if ((int)(zT_35 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    s = zT_20.value;
    zT_23 = s->kind;
    if ((int)(zT_23 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_34.has_value = 0;
    return zT_34;
    z_bb_5:
    zT_28 = s->module_id;
    zT_29 = s->name_id;
    zT_32 = zF_9D041EB6_asyncKey(zT_28, zT_29);
    zT_33.has_value = 1;
    zT_33.value = zT_32;
    return zT_33;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_8:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_42[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        names[_i] = zT_42[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    nlen = zT_45;
    zT_46 = store;
    zT_47 = callee_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_46, zT_47);
    zT_49 = (unsigned int)nlen;
    names[zT_49] = zT_48;
    zT_50 = 1;
    zT_52 = nlen + (unsigned int)((unsigned int)zT_50);
    nlen = zT_52;
    zT_54 = cn.child_0;
    cur = zT_54;
    zT_56 = store;
    zT_57 = cur;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cw = zT_58;
    goto z_bb_9;
    z_bb_9:
    zT_59 = cw.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if ((int)(nlen >= (unsigned int)(16))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_78 = cw.kind;
    if ((int)(zT_78 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_14:
    zT_67 = store;
    zT_68 = cur;
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_67, zT_68);
    zT_70 = (unsigned int)nlen;
    names[zT_70] = zT_69;
    zT_71 = 1;
    zT_73 = nlen + (unsigned int)((unsigned int)zT_71);
    nlen = zT_73;
    zT_74 = cw.child_0;
    cur = zT_74;
    zT_75 = store;
    zT_76 = cur;
    zT_77 = zF_FCDD1D35_astStoreNodeAt(zT_75, zT_76);
    cw = zT_77;
    goto z_bb_12;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
    z_bb_16:
    zT_85 = store;
    zT_86 = cur;
    zT_87 = zF_53458827_astStoreIdentifier(zT_85, zT_86);
    base_nid = zT_87;
    cur_mod = module_id;
    zT_89 = sym_reg;
    zT_90 = module_id;
    zT_91 = base_nid;
    zT_92 = zF_A398987E_symbolRegistryQuali(zT_89, zT_90, zT_91);
    zT_93 = zT_92.has_value;
    if (zT_93) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    bs = zT_92.value;
    zT_95 = bs->kind;
    if ((int)(zT_95 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    i = nlen;
    goto z_bb_22;
    z_bb_19:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_20:
    zT_100.has_value = 0;
    return zT_100;
    z_bb_21:
    zT_101 = bs->module_id;
    cur_mod = zT_101;
    goto z_bb_18;
    z_bb_22:
    if ((int)(i > (unsigned int)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_106 = 1;
    zT_108 = i - (unsigned int)((unsigned int)zT_106);
    i = zT_108;
    zT_109 = sym_reg;
    zT_110 = cur_mod;
    zT_112 = (unsigned int)i;
    zT_111 = names[zT_112];
    zT_114 = zF_A398987E_symbolRegistryQuali(zT_109, zT_110, zT_111);
    zT_115 = zT_114.has_value;
    if (zT_115) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_125 = sym_reg;
    zT_126 = cur_mod;
    zT_128 = 0;
    zT_127 = names[zT_128];
    zT_130 = zF_A398987E_symbolRegistryQuali(zT_125, zT_126, zT_127);
    zT_131 = zT_130.has_value;
    if (zT_131) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    ms = zT_114.value;
    zT_117 = ms->kind;
    if ((int)(zT_117 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_124.has_value = 0;
    return zT_124;
    z_bb_29:
    zT_122.has_value = 0;
    return zT_122;
    z_bb_30:
    zT_123 = ms->module_id;
    cur_mod = zT_123;
    goto z_bb_27;
    z_bb_31:
    fs = zT_130.value;
    zT_133 = fs->kind;
    if ((int)(zT_133 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_144.has_value = 0;
    return zT_144;
    z_bb_33:
    zT_138 = fs->module_id;
    zT_139 = fs->name_id;
    zT_142 = zF_9D041EB6_asyncKey(zT_138, zT_139);
    zT_143.has_value = 1;
    zT_143.value = zT_142;
    return zT_143;
    z_bb_34:
    goto z_bb_32;
}

/* scanFunction */
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int caller_idx, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_B687BB96_U32ArrayList* edge_caller, zT_B687BB96_U32ArrayList* edge_callee, zT_47B162D1_U8ArrayList* direct, zT_A4CE86B7_U64ToU32Map* fn_index, unsigned int async_suspend_name_id) {
    zT_B687BB96_U32ArrayList* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_41;
    zT_3D7259E2_SymbolRegistry* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_BBEE1AC1_Opt_11 zT_46 = {0};
    unsigned char zT_47;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    zT_BAEE192E_Opt_10 zT_51 = {0};
    unsigned char zT_52;
    zT_B687BB96_U32ArrayList* zT_54;
    unsigned int zT_55;
    zT_B687BB96_U32ArrayList* zT_56;
    unsigned int zT_57;
    zT_B687BB96_U32ArrayList* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_64 = {0};
    unsigned int zT_66;
    unsigned int zT_68;
    zT_B687BB96_U32ArrayList* zT_70;
    unsigned int zT_71;
    unsigned int* zT_72;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_88 = {0};
    unsigned int zT_90;
    unsigned int zT_92;
    zT_B687BB96_U32ArrayList* zT_94;
    unsigned int zT_95;
    unsigned int* zT_96;
    int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    int zT_103;
    zT_8143F551_AstKind zT_104;
    int zT_107 = 0;
    zT_B687BB96_U32ArrayList* zT_108;
    unsigned int zT_109;
    unsigned int zT_111;
    int zT_114;
    zT_8143F551_AstKind zT_115;
    int zT_118 = 0;
    zT_B687BB96_U32ArrayList* zT_119;
    unsigned int zT_120;
    unsigned int zT_122;
    int zT_125;
    zT_8143F551_AstKind zT_126;
    int zT_129 = 0;
    zT_B687BB96_U32ArrayList* zT_130;
    unsigned int zT_131;
    zT_8143F551_AstKind zT_133;
    int zT_134 = 0;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_138 = {0};
    unsigned int zT_140;
    unsigned int zT_142;
    zT_B687BB96_U32ArrayList* zT_144;
    unsigned int zT_145;
    unsigned int* zT_146;
    int zT_148;
    unsigned int zT_149;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int gi;
    zT_3CB0179A_Slice_zT_05F374B1_u ec2;
    unsigned int ei2;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = stack;
    zT_15 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_14, zT_15);
    goto z_bb_3;
    z_bb_3:
    zT_16 = stack->len;
    if ((int)(zT_16 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = stack->items;
    zT_21 = stack->len;
    zT_22 = 1;
    zT_23 = zT_21 - zT_22;
    zT_24 = zT_20[zT_23];
    ni = zT_24;
    zT_25 = stack->len;
    stack->len = (unsigned int)(zT_25 - (unsigned int)(1));
    zT_29 = store;
    zT_30 = ni;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    n = zT_31;
    zT_33 = n.kind;
    k = zT_33;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_38 = n.child_0;
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_19; else goto z_bb_20;
    z_bb_9:
    zT_41 = store;
    zT_42 = sym_reg;
    zT_43 = module_id;
    zT_44 = n.child_0;
    zT_46 = zF_860C82EC_resolveCalleeKey(zT_41, zT_42, zT_43, zT_44);
    zT_47 = zT_46.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_62 = store;
    zT_63 = ni;
    zT_64 = zF_850FDF81_astStoreNodeExtraCh(zT_62, zT_63);
    ec = zT_64;
    zT_66 = 0;
    ei = zT_66;
    goto z_bb_15;
    z_bb_11:
    ck = zT_46.value;
    zT_49 = fn_index;
    zT_50 = ck;
    zT_51 = zF_A05A7BE1_u64ToU32MapGet(zT_49, zT_50);
    zT_52 = zT_51.has_value;
    if (zT_52) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_58 = stack;
    zT_59 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_58, zT_59);
    goto z_bb_10;
    z_bb_13:
    gi = zT_51.value;
    zT_54 = edge_caller;
    zT_55 = caller_idx;
    zF_62F717A2_u32ArrayListAppend(zT_54, zT_55);
    zT_56 = edge_callee;
    zT_57 = gi;
    zF_62F717A2_u32ArrayListAppend(zT_56, zT_57);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_68 = ec.len;
    if ((int)(ei < zT_68)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_70 = stack;
    zT_72 = ec.ptr;
    zT_71 = zT_72[ei];
    zF_62F717A2_u32ArrayListAppend(zT_70, zT_71);
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_74 = 1;
    zT_75 = ei + zT_74;
    ei = zT_75;
    goto z_bb_15;
    z_bb_19:
    zT_80 = n.child_0;
    if ((int)(zT_80 == async_suspend_name_id)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_100 = n.child_0;
    if ((int)(zT_100 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    zT_82 = 1;
    zT_83 = direct->items;
    zT_84 = (unsigned int)caller_idx;
    zT_83[zT_84] = zT_82;
    goto z_bb_22;
    z_bb_22:
    zT_86 = store;
    zT_87 = ni;
    zT_88 = zF_850FDF81_astStoreNodeExtraCh(zT_86, zT_87);
    ec2 = zT_88;
    zT_90 = 0;
    ei2 = zT_90;
    goto z_bb_23;
    z_bb_23:
    zT_92 = ec2.len;
    if ((int)(ei2 < zT_92)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = stack;
    zT_96 = ec2.ptr;
    zT_95 = zT_96[ei2];
    zF_62F717A2_u32ArrayListAppend(zT_94, zT_95);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_98 = 1;
    zT_99 = ei2 + zT_98;
    ei2 = zT_99;
    goto z_bb_23;
    z_bb_27:
    zT_104 = k;
    zT_107 = zF_C395F6FD_nodeChildIsNode(zT_104, (unsigned char)(0));
    zT_103 = zT_107;
    goto z_bb_29;
    z_bb_28:
    zT_103 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_103) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_108 = stack;
    zT_109 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_108, zT_109);
    goto z_bb_31;
    z_bb_31:
    zT_111 = n.child_1;
    if ((int)(zT_111 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_115 = k;
    zT_118 = zF_C395F6FD_nodeChildIsNode(zT_115, (unsigned char)(1));
    zT_114 = zT_118;
    goto z_bb_34;
    z_bb_33:
    zT_114 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_114) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_119 = stack;
    zT_120 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_119, zT_120);
    goto z_bb_36;
    z_bb_36:
    zT_122 = n.child_2;
    if ((int)(zT_122 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_126 = k;
    zT_129 = zF_C395F6FD_nodeChildIsNode(zT_126, (unsigned char)(2));
    zT_125 = zT_129;
    goto z_bb_39;
    z_bb_38:
    zT_125 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_125) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_130 = stack;
    zT_131 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_130, zT_131);
    goto z_bb_41;
    z_bb_41:
    zT_133 = k;
    zT_134 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_133);
    if (zT_134) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_136 = store;
    zT_137 = ni;
    zT_138 = zF_850FDF81_astStoreNodeExtraCh(zT_136, zT_137);
    ec3 = zT_138;
    zT_140 = 0;
    ei3 = zT_140;
    goto z_bb_44;
    z_bb_43:
    goto z_bb_6;
    z_bb_44:
    zT_142 = ec3.len;
    if ((int)(ei3 < zT_142)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_144 = stack;
    zT_146 = ec3.ptr;
    zT_145 = zT_146[ei3];
    zF_62F717A2_u32ArrayListAppend(zT_144, zT_145);
    goto z_bb_47;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_148 = 1;
    zT_149 = ei3 + zT_148;
    ei3 = zT_149;
    goto z_bb_44;
}

/* emitSuspMarker */
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64 key) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_5826BFC7_Arr_unsigned_char_1 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_5826BFC7_Arr_unsigned_char_1 zT_44;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54 = 0;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_4 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_4;
    zT_8 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_8;
    zT_10 = "SUSP:m";
    zT_12 = 6;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    m1 = zT_11;
    zT_13 = m1;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = module_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)b1) + zT_21;
    zT_23 = (unsigned int)(12) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    l1 = zT_25;
    zT_30 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_36 = (unsigned int)(11) - s1;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = ":n";
    zT_41 = 2;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    m2 = zT_40;
    zT_42 = m2;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = name_id;
    zT_50 = 0;
    zT_51 = (unsigned char*)((unsigned char*)b2) + zT_50;
    zT_52 = (unsigned int)(12) - zT_50;
    zT_53.ptr = zT_51;
    zT_53.len = zT_52;
    zT_47 = zT_53;
    zT_54 = zF_A7504564_itoa(zT_46, zT_47);
    l2 = zT_54;
    zT_59 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_59;
    zT_64 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_65 = (unsigned int)(11) - s2;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_60 = zT_66;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_68 = "\n";
    zT_70 = 1;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    m3 = zT_69;
    zT_71 = m3;
    zF_48AC7B3A_markerWrite(zT_71);
    return;
}

/* suspensionAnalysisRun */
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_072B53A6_ModuleRegistry* module_reg, zT_D3EB6303_StringInterner* interner, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_C4A0A7DB_U64ArrayList zT_26 = {0};
    zT_3E40CD83_Sand* zT_28;
    zT_47B162D1_U8ArrayList zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_B687BB96_U32ArrayList zT_32 = {0};
    zT_3E40CD83_Sand* zT_34;
    zT_B687BB96_U32ArrayList zT_35 = {0};
    zT_072B53A6_ModuleRegistry* zT_37;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_53 = {0};
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_62 = {0};
    unsigned int zT_64;
    unsigned int zT_66;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    unsigned int* zT_71;
    zT_22A7C88B_AstNode zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int* zT_82;
    unsigned int zT_84 = 0;
    zT_4878453E_anon_224415 zT_86;
    zT_243D6A41_FnProto* zT_87;
    unsigned int zT_88;
    zT_243D6A41_FnProto zT_89;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_6E8D187B_ModuleEntry* zT_93;
    zT_6E8D187B_ModuleEntry zT_94;
    zT_79FAE712_u64 zT_97 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_98;
    zT_79FAE712_u64 zT_99;
    zT_BAEE192E_Opt_10 zT_101 = {0};
    unsigned char zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_104;
    zT_79FAE712_u64 zT_105;
    unsigned int zT_108;
    zT_C4A0A7DB_U64ArrayList* zT_110;
    zT_79FAE712_u64 zT_111;
    zT_47B162D1_U8ArrayList* zT_113;
    int zT_117;
    unsigned int zT_118;
    int zT_119;
    unsigned int zT_120;
    zT_3E40CD83_Sand* zT_122;
    zT_B687BB96_U32ArrayList zT_123 = {0};
    unsigned int zT_124;
    unsigned int zT_126;
    zT_6E8D187B_ModuleEntry* zT_129;
    zT_6E8D187B_ModuleEntry zT_130;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_136;
    zT_22A7C88B_AstNode zT_137 = {0};
    zT_8143F551_AstKind zT_138;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_146 = {0};
    unsigned int zT_148;
    unsigned int zT_150;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    unsigned int* zT_155;
    zT_22A7C88B_AstNode zT_157 = {0};
    zT_8143F551_AstKind zT_158;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int* zT_166;
    unsigned int zT_168 = 0;
    zT_4878453E_anon_224415 zT_170;
    zT_243D6A41_FnProto* zT_171;
    unsigned int zT_172;
    zT_243D6A41_FnProto zT_173;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_6E8D187B_ModuleEntry* zT_177;
    zT_6E8D187B_ModuleEntry zT_178;
    zT_79FAE712_u64 zT_181 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_183;
    zT_79FAE712_u64 zT_184;
    zT_BAEE192E_Opt_10 zT_186 = {0};
    unsigned char zT_187;
    zT_6B0A7D14_AstStore* zT_189;
    zT_3D7259E2_SymbolRegistry* zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_B687BB96_U32ArrayList* zT_194;
    zT_B687BB96_U32ArrayList* zT_195;
    zT_B687BB96_U32ArrayList* zT_196;
    zT_47B162D1_U8ArrayList* zT_197;
    zT_A4CE86B7_U64ToU32Map* zT_198;
    unsigned int zT_199;
    zT_6E8D187B_ModuleEntry* zT_200;
    zT_6E8D187B_ModuleEntry zT_201;
    int zT_209;
    unsigned int zT_210;
    int zT_211;
    unsigned int zT_212;
    unsigned int zT_214;
    zT_3E40CD83_Sand* zT_218;
    unsigned int zT_219;
    unsigned int* zT_220 = 0;
    unsigned int zT_222;
    unsigned int zT_224;
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int* zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_237;
    unsigned int zT_238;
    int zT_239;
    unsigned int zT_240;
    zT_3E40CD83_Sand* zT_242;
    unsigned int* zT_246 = 0;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_251;
    unsigned int zT_252;
    int zT_253;
    unsigned int zT_254;
    zT_3E40CD83_Sand* zT_256;
    unsigned int zT_257;
    unsigned int* zT_258 = 0;
    unsigned int zT_259;
    unsigned int zT_261;
    int zT_262;
    unsigned int zT_263;
    zT_3E40CD83_Sand* zT_265;
    unsigned int zT_266;
    unsigned int* zT_268 = 0;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int* zT_273;
    unsigned int zT_274;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned int zT_282;
    unsigned int zT_283;
    int zT_284;
    unsigned int zT_285;
    zT_3E40CD83_Sand* zT_287;
    unsigned int zT_288;
    unsigned int* zT_289 = 0;
    unsigned int zT_291;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned char* zT_296;
    unsigned char zT_297;
    zT_A4CE86B7_U64ToU32Map* zT_300;
    zT_79FAE712_u64 zT_301;
    zT_79FAE712_u64* zT_303;
    unsigned int zT_306;
    unsigned int zT_308;
    int zT_309;
    unsigned int zT_310;
    unsigned int zT_313;
    unsigned int zT_315;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int zT_327;
    unsigned int zT_328;
    zT_79FAE712_u64* zT_330;
    unsigned int zT_331;
    zT_79FAE712_u64 zT_332;
    zT_A4CE86B7_U64ToU32Map* zT_333;
    zT_79FAE712_u64 zT_334;
    zT_BAEE192E_Opt_10 zT_335 = {0};
    unsigned char zT_336;
    zT_A4CE86B7_U64ToU32Map* zT_338;
    zT_79FAE712_u64 zT_339;
    unsigned int zT_343;
    unsigned int zT_345;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_79FAE712_u64* zT_351;
    zT_79FAE712_u64 zT_352;
    zT_A4CE86B7_U64ToU32Map* zT_354;
    zT_79FAE712_u64 zT_355;
    zT_BAEE192E_Opt_10 zT_356 = {0};
    unsigned char zT_357;
    zT_79FAE712_u64 zT_361;
    int zT_362;
    unsigned int zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_A4CE86B7_U64ToU32Map fn_index;
    zT_C4A0A7DB_U64ArrayList fn_keys;
    zT_47B162D1_U8ArrayList direct;
    zT_B687BB96_U32ArrayList edge_caller;
    zT_B687BB96_U32ArrayList edge_callee;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_B687BB96_U32ArrayList stack;
    zT_22A7C88B_AstNode root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned int ast_root2;
    unsigned int n;
    zT_22A7C88B_AstNode root2;
    zT_3CB0179A_Slice_zT_05F374B1_u decls2;
    unsigned int di2;
    zT_22A7C88B_AstNode decl2;
    unsigned int proto_idx2;
    zT_243D6A41_FnProto proto2;
    zT_79FAE712_u64 key2;
    zT_BAEE192E_Opt_10 cidx;
    unsigned int ci0;
    unsigned int* rev_count;
    unsigned int i;
    unsigned int m;
    unsigned int e;
    unsigned int g;
    unsigned int* rev_off;
    unsigned int acc;
    unsigned int* rev_pos;
    unsigned int* rev_to;
    unsigned int g2;
    unsigned int p;
    unsigned int* queue;
    unsigned int head;
    unsigned int tail;
    unsigned int g3;
    unsigned int k0;
    unsigned int k1;
    unsigned int kk;
    unsigned int c;
    zT_79FAE712_u64 ckey;
    zT_79FAE712_u64 kk2;
    zT_BAEE192E_Opt_10 vv;
    unsigned int val2;
    zT_7 = "YA\n";
    zT_9 = 3;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    p_msg = zT_8;
    zT_10 = p_msg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = "@asyncSuspend";
    zT_14 = 13;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    asu_text = zT_13;
    zT_16 = interner;
    zT_17 = asu_text;
    zT_18 = zF_50C274AF_stringInternerInter(zT_16, zT_17);
    async_suspend_name_id = zT_18;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    fn_index = zT_21;
    zT_23 = alloc;
    zT_26 = zF_477F0605_u64ArrayListInit(zT_23, (unsigned int)(256));
    fn_keys = zT_26;
    zT_28 = alloc;
    zT_29 = zF_E9FF0E66_byteArrayListInit(zT_28);
    direct = zT_29;
    zT_31 = alloc;
    zT_32 = zF_8E537D0C_u32ArrayListInit(zT_31);
    edge_caller = zT_32;
    zT_34 = alloc;
    zT_35 = zF_8E537D0C_u32ArrayListInit(zT_34);
    edge_callee = zT_35;
    zT_37 = module_reg;
    zT_38 = zF_3452C137_moduleRegistryGetMo(zT_37);
    mods = zT_38;
    zT_40 = 0;
    mi = zT_40;
    goto z_bb_1;
    z_bb_1:
    zT_42 = mods.len;
    if ((int)(mi < zT_42)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_45 = mods.ptr;
    zT_46 = zT_45[mi];
    zT_47 = zT_46.ast_root;
    ast_root = zT_47;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_122 = alloc;
    zT_123 = zF_8E537D0C_u32ArrayListInit(zT_122);
    stack = zT_123;
    zT_124 = 0;
    mi = zT_124;
    goto z_bb_17;
    z_bb_4:
    zT_119 = 1;
    zT_120 = mi + zT_119;
    mi = zT_120;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_51 = store;
    zT_52 = ast_root;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    root = zT_53;
    zT_54 = root.kind;
    if ((int)(zT_54 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_60 = store;
    zT_61 = ast_root;
    zT_62 = zF_850FDF81_astStoreNodeExtraCh(zT_60, zT_61);
    decls = zT_62;
    zT_64 = 0;
    di = zT_64;
    goto z_bb_9;
    z_bb_9:
    zT_66 = decls.len;
    if ((int)(di < zT_66)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_69 = store;
    zT_71 = decls.ptr;
    zT_70 = zT_71[di];
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    decl = zT_73;
    zT_74 = decl.kind;
    if ((int)(zT_74 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_117 = 1;
    zT_118 = di + zT_117;
    di = zT_118;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_80 = store;
    zT_82 = decls.ptr;
    zT_81 = zT_82[di];
    zT_84 = zF_8BA26B9E_astStoreNodePayload(zT_80, zT_81);
    proto_idx = zT_84;
    zT_86 = store->fn_protos;
    zT_87 = zT_86.items;
    zT_88 = (unsigned int)proto_idx;
    zT_89 = zT_87[zT_88];
    proto = zT_89;
    zT_93 = mods.ptr;
    zT_94 = zT_93[mi];
    zT_91 = zT_94.id;
    zT_92 = proto.name_id;
    zT_97 = zF_9D041EB6_asyncKey(zT_91, zT_92);
    key = zT_97;
    zT_98 = &fn_index;
    zT_99 = key;
    zT_101 = zF_A05A7BE1_u64ToU32MapGet(zT_98, zT_99);
    zT_102 = zT_101.has_value;
    if ((int)(!zT_102)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_104 = &fn_index;
    zT_105 = key;
    zT_108 = fn_keys.len;
    zF_B6EB812C_u64ToU32MapPut(zT_104, zT_105, (unsigned int)((unsigned int)zT_108));
    zT_110 = &fn_keys;
    zT_111 = key;
    zF_A553AD3B_u64ArrayListAppend(zT_110, zT_111);
    zT_113 = &direct;
    zF_463FE7A4_byteArrayListAppend(zT_113, (unsigned char)(0));
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    zT_126 = mods.len;
    if ((int)(mi < zT_126)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_129 = mods.ptr;
    zT_130 = zT_129[mi];
    zT_131 = zT_130.ast_root;
    ast_root2 = zT_131;
    if ((int)(ast_root2 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_214 = fn_keys.len;
    n = zT_214;
    if ((int)(n > (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_20:
    zT_211 = 1;
    zT_212 = mi + zT_211;
    mi = zT_212;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_135 = store;
    zT_136 = ast_root2;
    zT_137 = zF_FCDD1D35_astStoreNodeAt(zT_135, zT_136);
    root2 = zT_137;
    zT_138 = root2.kind;
    if ((int)(zT_138 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_144 = store;
    zT_145 = ast_root2;
    zT_146 = zF_850FDF81_astStoreNodeExtraCh(zT_144, zT_145);
    decls2 = zT_146;
    zT_148 = 0;
    di2 = zT_148;
    goto z_bb_25;
    z_bb_25:
    zT_150 = decls2.len;
    if ((int)(di2 < zT_150)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_153 = store;
    zT_155 = decls2.ptr;
    zT_154 = zT_155[di2];
    zT_157 = zF_FCDD1D35_astStoreNodeAt(zT_153, zT_154);
    decl2 = zT_157;
    zT_158 = decl2.kind;
    if ((int)(zT_158 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_209 = 1;
    zT_210 = di2 + zT_209;
    di2 = zT_210;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_164 = store;
    zT_166 = decls2.ptr;
    zT_165 = zT_166[di2];
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    proto_idx2 = zT_168;
    zT_170 = store->fn_protos;
    zT_171 = zT_170.items;
    zT_172 = (unsigned int)proto_idx2;
    zT_173 = zT_171[zT_172];
    proto2 = zT_173;
    zT_177 = mods.ptr;
    zT_178 = zT_177[mi];
    zT_175 = zT_178.id;
    zT_176 = proto2.name_id;
    zT_181 = zF_9D041EB6_asyncKey(zT_175, zT_176);
    key2 = zT_181;
    zT_183 = &fn_index;
    zT_184 = key2;
    zT_186 = zF_A05A7BE1_u64ToU32MapGet(zT_183, zT_184);
    cidx = zT_186;
    zT_187 = cidx.has_value;
    if (zT_187) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    ci0 = cidx.value;
    zT_189 = store;
    zT_190 = sym_reg;
    zT_200 = mods.ptr;
    zT_201 = zT_200[mi];
    zT_191 = zT_201.id;
    zT_192 = ci0;
    zT_193 = decl2.child_0;
    zT_194 = &stack;
    zT_195 = &edge_caller;
    zT_196 = &edge_callee;
    zT_197 = &direct;
    zT_198 = &fn_index;
    zT_199 = async_suspend_name_id;
    zF_32651930_scanFunction(zT_189, zT_190, zT_191, zT_192, zT_193, zT_194, zT_195, zT_196, zT_197, zT_198, zT_199);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_218 = alloc;
    zT_219 = n;
    zT_220 = zF_43BEEDA4_allocU32(zT_218, zT_219);
    rev_count = zT_220;
    zT_222 = 0;
    i = zT_222;
    goto z_bb_35;
    z_bb_34:
    zT_347 = 0;
    m = zT_347;
    goto z_bb_71;
    z_bb_35:
    if ((int)(i < n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_224 = 0;
    rev_count[i] = zT_224;
    goto z_bb_38;
    z_bb_37:
    zT_228 = 0;
    e = zT_228;
    goto z_bb_39;
    z_bb_38:
    zT_225 = 1;
    zT_226 = i + zT_225;
    i = zT_226;
    goto z_bb_35;
    z_bb_39:
    zT_229 = edge_callee.len;
    if ((int)(e < zT_229)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_232 = edge_callee.items;
    zT_233 = zT_232[e];
    g = zT_233;
    zT_234 = (unsigned int)g;
    zT_235 = rev_count[zT_234];
    zT_237 = zT_235 + (unsigned int)(1);
    zT_238 = (unsigned int)g;
    rev_count[zT_238] = zT_237;
    goto z_bb_42;
    z_bb_41:
    zT_242 = alloc;
    zT_246 = zF_43BEEDA4_allocU32(zT_242, (unsigned int)(n + (unsigned int)(1)));
    rev_off = zT_246;
    zT_248 = 0;
    acc = zT_248;
    zT_249 = 0;
    i = zT_249;
    goto z_bb_43;
    z_bb_42:
    zT_239 = 1;
    zT_240 = e + zT_239;
    e = zT_240;
    goto z_bb_39;
    z_bb_43:
    if ((int)(i < n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    rev_off[i] = acc;
    zT_251 = rev_count[i];
    zT_252 = acc + zT_251;
    acc = zT_252;
    goto z_bb_46;
    z_bb_45:
    rev_off[n] = acc;
    zT_256 = alloc;
    zT_257 = n;
    zT_258 = zF_43BEEDA4_allocU32(zT_256, zT_257);
    rev_pos = zT_258;
    zT_259 = 0;
    i = zT_259;
    goto z_bb_47;
    z_bb_46:
    zT_253 = 1;
    zT_254 = i + zT_253;
    i = zT_254;
    goto z_bb_43;
    z_bb_47:
    if ((int)(i < n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_261 = rev_off[i];
    rev_pos[i] = zT_261;
    goto z_bb_50;
    z_bb_49:
    zT_265 = alloc;
    zT_266 = edge_callee.len;
    zT_268 = zF_43BEEDA4_allocU32(zT_265, zT_266);
    rev_to = zT_268;
    zT_269 = 0;
    e = zT_269;
    goto z_bb_51;
    z_bb_50:
    zT_262 = 1;
    zT_263 = i + zT_262;
    i = zT_263;
    goto z_bb_47;
    z_bb_51:
    zT_270 = edge_callee.len;
    if ((int)(e < zT_270)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_273 = edge_callee.items;
    zT_274 = zT_273[e];
    g2 = zT_274;
    zT_276 = (unsigned int)g2;
    zT_277 = rev_pos[zT_276];
    p = zT_277;
    zT_278 = edge_caller.items;
    zT_279 = zT_278[e];
    zT_280 = (unsigned int)p;
    rev_to[zT_280] = zT_279;
    zT_282 = p + (unsigned int)(1);
    zT_283 = (unsigned int)g2;
    rev_pos[zT_283] = zT_282;
    goto z_bb_54;
    z_bb_53:
    zT_287 = alloc;
    zT_288 = n;
    zT_289 = zF_43BEEDA4_allocU32(zT_287, zT_288);
    queue = zT_289;
    zT_291 = 0;
    head = zT_291;
    zT_293 = 0;
    tail = zT_293;
    zT_294 = 0;
    i = zT_294;
    goto z_bb_55;
    z_bb_54:
    zT_284 = 1;
    zT_285 = e + zT_284;
    e = zT_285;
    goto z_bb_51;
    z_bb_55:
    if ((int)(i < n)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_296 = direct.items;
    zT_297 = zT_296[i];
    if ((int)(zT_297 != (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    goto z_bb_61;
    z_bb_58:
    zT_309 = 1;
    zT_310 = i + zT_309;
    i = zT_310;
    goto z_bb_55;
    z_bb_59:
    zT_300 = suspending_fns;
    zT_303 = fn_keys.items;
    zT_301 = zT_303[i];
    zF_B6EB812C_u64ToU32MapPut(zT_300, zT_301, (unsigned int)(1));
    zT_306 = (unsigned int)i;
    queue[tail] = zT_306;
    zT_308 = tail + (unsigned int)(1);
    tail = zT_308;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    if ((int)(head < tail)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_313 = queue[head];
    g3 = zT_313;
    zT_315 = head + (unsigned int)(1);
    head = zT_315;
    zT_317 = (unsigned int)g3;
    zT_318 = rev_off[zT_317];
    k0 = zT_318;
    zT_322 = (unsigned int)((unsigned int)g3) + (unsigned int)(1);
    zT_323 = rev_off[zT_322];
    k1 = zT_323;
    kk = k0;
    goto z_bb_65;
    z_bb_63:
    goto z_bb_34;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    if ((int)(kk < k1)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_327 = (unsigned int)kk;
    zT_328 = rev_to[zT_327];
    c = zT_328;
    zT_330 = fn_keys.items;
    zT_331 = (unsigned int)c;
    zT_332 = zT_330[zT_331];
    ckey = zT_332;
    zT_333 = suspending_fns;
    zT_334 = ckey;
    zT_335 = zF_A05A7BE1_u64ToU32MapGet(zT_333, zT_334);
    zT_336 = zT_335.has_value;
    if ((int)(!zT_336)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_345 = kk + (unsigned int)(1);
    kk = zT_345;
    goto z_bb_65;
    z_bb_69:
    zT_338 = suspending_fns;
    zT_339 = ckey;
    zF_B6EB812C_u64ToU32MapPut(zT_338, zT_339, (unsigned int)(1));
    queue[tail] = c;
    zT_343 = tail + (unsigned int)(1);
    tail = zT_343;
    goto z_bb_70;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_348 = fn_keys.len;
    if ((int)(m < zT_348)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_351 = fn_keys.items;
    zT_352 = zT_351[m];
    kk2 = zT_352;
    zT_354 = suspending_fns;
    zT_355 = kk2;
    zT_356 = zF_A05A7BE1_u64ToU32MapGet(zT_354, zT_355);
    vv = zT_356;
    zT_357 = vv.has_value;
    if (zT_357) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return;
    z_bb_74:
    zT_362 = 1;
    zT_363 = m + zT_362;
    m = zT_363;
    goto z_bb_71;
    z_bb_75:
    val2 = vv.value;
    if ((int)(val2 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_361 = kk2;
    zF_76D5E8D3_emitSuspMarker(zT_361);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* frameFieldSizeAlign */
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    zT_19 = t.alignment;
    if ((int)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_22 = t.alignment;
    al = zT_22;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* addFrameField */
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    unsigned int at;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_8 = reg;
    zT_9 = tid;
    zT_10 = &sz;
    zT_11 = &al;
    zF_816D1610_frameFieldSizeAlign(zT_8, zT_9, zT_10, zT_11);
    zT_14 = *offset;
    zT_15 = al;
    zT_17 = zF_978D7C93_alignUpU32(zT_14, zT_15);
    *offset = zT_17;
    zT_19 = *offset;
    at = zT_19;
    zT_20 = *offset;
    *offset = (unsigned int)(zT_20 + sz);
    zT_22 = *max_align;
    if ((int)(al > zT_22)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = al;
    goto z_bb_2;
    z_bb_2:
    return at;
}

/* typeIsPtrVoid */
int zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_112BF819_PtrPayload zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_17 = reg->ptr_items;
    zT_18 = t.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.base;
    base = zT_21;
    return (int)(base == (unsigned int)(1));
}

/* frameLocalTypeId */
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable* resolved_types, zT_22A7C88B_AstNode n) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned int t;
    zT_2 = n.child_0;
    if ((int)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_5 = resolved_types;
    zT_6 = n.child_0;
    zT_8 = zF_999DCF51_resolvedTypeTableGe(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    return (unsigned int)(18);
    z_bb_3:
    zT_11 = n.child_1;
    if ((int)(zT_11 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    t = zT_8.value;
    return t;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_14 = resolved_types;
    zT_15 = n.child_1;
    zT_17 = zF_999DCF51_resolvedTypeTableGe(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_2;
    z_bb_8:
    t = zT_17.value;
    return t;
    z_bb_9:
    goto z_bb_7;
}

/* scanFrameLocals */
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore* store, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_338B7C76_TypeRegistry* reg, zT_8EED1867_ResolvedTypeTable* resolved_types, unsigned int* offset, unsigned int* max_align) {
    zT_B687BB96_U32ArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_29;
    unsigned int zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_34 = {0};
    unsigned char zT_35;
    int zT_39;
    zT_8EED1867_ResolvedTypeTable* zT_44;
    zT_22A7C88B_AstNode zT_45;
    unsigned int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_47;
    unsigned int zT_48;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned int zT_51 = 0;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_59 = {0};
    unsigned int zT_62;
    unsigned int zT_66;
    zT_B687BB96_U32ArrayList* zT_67;
    unsigned int zT_68;
    unsigned int* zT_69;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_78 = {0};
    unsigned int zT_81;
    unsigned int zT_85;
    zT_B687BB96_U32ArrayList* zT_86;
    unsigned int zT_87;
    unsigned int* zT_88;
    unsigned int zT_90;
    zT_B687BB96_U32ArrayList* zT_93;
    unsigned int zT_94;
    zT_8143F551_AstKind zT_96;
    int zT_97 = 0;
    zT_6B0A7D14_AstStore* zT_99;
    unsigned int zT_100;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_101 = {0};
    unsigned int zT_104;
    unsigned int zT_108;
    zT_B687BB96_U32ArrayList* zT_109;
    unsigned int zT_110;
    unsigned int* zT_111;
    unsigned int zT_113;
    int zT_116;
    zT_8143F551_AstKind zT_117;
    int zT_120 = 0;
    zT_B687BB96_U32ArrayList* zT_121;
    unsigned int zT_122;
    unsigned int zT_124;
    int zT_127;
    zT_8143F551_AstKind zT_128;
    int zT_131 = 0;
    zT_B687BB96_U32ArrayList* zT_132;
    unsigned int zT_133;
    unsigned int zT_135;
    int zT_138;
    zT_8143F551_AstKind zT_139;
    int zT_142 = 0;
    zT_B687BB96_U32ArrayList* zT_143;
    unsigned int zT_144;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int lvt;
    unsigned int t;
    zT_3CB0179A_Slice_zT_05F374B1_u ecb;
    unsigned int bi;
    zT_3CB0179A_Slice_zT_05F374B1_u ecf;
    unsigned int fi;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = stack;
    zT_11 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_10, zT_11);
    goto z_bb_3;
    z_bb_3:
    zT_12 = stack->len;
    if ((int)(zT_12 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = stack->items;
    zT_17 = stack->len;
    zT_19 = zT_17 - (unsigned int)(1);
    zT_20 = zT_16[zT_19];
    ni = zT_20;
    zT_21 = stack->len;
    stack->len = (unsigned int)(zT_21 - (unsigned int)(1));
    zT_25 = store;
    zT_26 = ni;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    n = zT_27;
    zT_29 = n.kind;
    k = zT_29;
    zT_31 = 18;
    lvt = zT_31;
    zT_32 = resolved_types;
    zT_33 = ni;
    zT_34 = zF_999DCF51_resolvedTypeTableGe(zT_32, zT_33);
    zT_35 = zT_34.has_value;
    if (zT_35) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    t = zT_34.value;
    lvt = t;
    goto z_bb_8;
    z_bb_8:
    if ((int)(lvt == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_11;
    z_bb_10:
    zT_39 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_44 = resolved_types;
    zT_45 = n;
    zT_46 = zF_436F92E0_frameLocalTypeId(zT_44, zT_45);
    lvt = zT_46;
    goto z_bb_13;
    z_bb_13:
    zT_47 = reg;
    zT_48 = lvt;
    zT_49 = offset;
    zT_50 = max_align;
    zT_51 = zF_769CB99B_addFrameField(zT_47, zT_48, zT_49, zT_50);
    (void)zT_51;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = store;
    zT_58 = ni;
    zT_59 = zF_850FDF81_astStoreNodeExtraCh(zT_57, zT_58);
    ecb = zT_59;
    zT_62 = ecb.len;
    bi = zT_62;
    goto z_bb_16;
    z_bb_15:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_20; else goto z_bb_21;
    z_bb_16:
    if ((int)(bi > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_66 = bi - (unsigned int)(1);
    bi = zT_66;
    zT_67 = stack;
    zT_69 = ecb.ptr;
    zT_68 = zT_69[bi];
    zF_62F717A2_u32ArrayListAppend(zT_67, zT_68);
    goto z_bb_19;
    z_bb_18:
    goto z_bb_6;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_76 = store;
    zT_77 = ni;
    zT_78 = zF_850FDF81_astStoreNodeExtraCh(zT_76, zT_77);
    ecf = zT_78;
    zT_81 = ecf.len;
    fi = zT_81;
    goto z_bb_22;
    z_bb_21:
    zT_96 = k;
    zT_97 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_96);
    if (zT_97) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    if ((int)(fi > (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_85 = fi - (unsigned int)(1);
    fi = zT_85;
    zT_86 = stack;
    zT_88 = ecf.ptr;
    zT_87 = zT_88[fi];
    zF_62F717A2_u32ArrayListAppend(zT_86, zT_87);
    goto z_bb_25;
    z_bb_24:
    zT_90 = n.child_0;
    if ((int)(zT_90 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_93 = stack;
    zT_94 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_93, zT_94);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_99 = store;
    zT_100 = ni;
    zT_101 = zF_850FDF81_astStoreNodeExtraCh(zT_99, zT_100);
    ec3 = zT_101;
    zT_104 = ec3.len;
    ei3 = zT_104;
    goto z_bb_30;
    z_bb_29:
    zT_113 = n.child_2;
    if ((int)(zT_113 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((int)(ei3 > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_108 = ei3 - (unsigned int)(1);
    ei3 = zT_108;
    zT_109 = stack;
    zT_111 = ec3.ptr;
    zT_110 = zT_111[ei3];
    zF_62F717A2_u32ArrayListAppend(zT_109, zT_110);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_117 = k;
    zT_120 = zF_C395F6FD_nodeChildIsNode(zT_117, (unsigned char)(2));
    zT_116 = zT_120;
    goto z_bb_36;
    z_bb_35:
    zT_116 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_116) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_121 = stack;
    zT_122 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_121, zT_122);
    goto z_bb_38;
    z_bb_38:
    zT_124 = n.child_1;
    if ((int)(zT_124 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_128 = k;
    zT_131 = zF_C395F6FD_nodeChildIsNode(zT_128, (unsigned char)(1));
    zT_127 = zT_131;
    goto z_bb_41;
    z_bb_40:
    zT_127 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_127) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_132 = stack;
    zT_133 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_132, zT_133);
    goto z_bb_43;
    z_bb_43:
    zT_135 = n.child_0;
    if ((int)(zT_135 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_139 = k;
    zT_142 = zF_C395F6FD_nodeChildIsNode(zT_139, (unsigned char)(0));
    zT_138 = zT_142;
    goto z_bb_46;
    z_bb_45:
    zT_138 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_138) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_143 = stack;
    zT_144 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_143, zT_144);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_6;
}

/* scanImplicitAwaits */
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, zT_79FAE712_u64 caller_key, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* fn_ret_types, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* hidden_fns, zT_B687BB96_U32ArrayList* parent_type_list, zT_A4CE86B7_U64ToU32Map* parent_start, zT_A4CE86B7_U64ToU32Map* parent_count) {
    zT_B687BB96_U32ArrayList* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33 = {0};
    zT_8143F551_AstKind zT_35;
    unsigned int zT_40;
    zT_6B0A7D14_AstStore* zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_BBEE1AC1_Opt_11 zT_48 = {0};
    unsigned char zT_49;
    unsigned int zT_54;
    unsigned int zT_58;
    zT_A4CE86B7_U64ToU32Map* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_63;
    zT_79FAE712_u64 zT_64;
    unsigned int zT_68;
    zT_A4CE86B7_U64ToU32Map* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    zT_79FAE712_u64 zT_79;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    zT_79FAE712_u64 zT_90;
    zT_BAEE192E_Opt_10 zT_91 = {0};
    unsigned char zT_92;
    zT_A4CE86B7_U64ToU32Map* zT_96;
    zT_79FAE712_u64 zT_97;
    unsigned int zT_99;
    zT_B687BB96_U32ArrayList* zT_101;
    unsigned int zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_A4CE86B7_U64ToU32Map* zT_108;
    zT_79FAE712_u64 zT_109;
    unsigned int zT_110;
    zT_B687BB96_U32ArrayList* zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_117 = {0};
    unsigned int zT_119;
    unsigned int zT_121;
    zT_B687BB96_U32ArrayList* zT_123;
    unsigned int zT_124;
    unsigned int* zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_136 = {0};
    unsigned int zT_138;
    unsigned int zT_140;
    zT_B687BB96_U32ArrayList* zT_142;
    unsigned int zT_143;
    unsigned int* zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    int zT_151;
    zT_8143F551_AstKind zT_152;
    int zT_155 = 0;
    zT_B687BB96_U32ArrayList* zT_156;
    unsigned int zT_157;
    unsigned int zT_159;
    int zT_162;
    zT_8143F551_AstKind zT_163;
    int zT_166 = 0;
    zT_B687BB96_U32ArrayList* zT_167;
    unsigned int zT_168;
    unsigned int zT_170;
    int zT_173;
    zT_8143F551_AstKind zT_174;
    int zT_177 = 0;
    zT_B687BB96_U32ArrayList* zT_178;
    unsigned int zT_179;
    zT_8143F551_AstKind zT_181;
    int zT_182 = 0;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_186 = {0};
    unsigned int zT_188;
    unsigned int zT_190;
    zT_B687BB96_U32ArrayList* zT_192;
    unsigned int zT_193;
    unsigned int* zT_194;
    int zT_196;
    unsigned int zT_197;
    zT_A4CE86B7_U64ToU32Map* zT_198;
    zT_79FAE712_u64 zT_199;
    zT_BAEE192E_Opt_10 zT_200 = {0};
    unsigned char zT_201;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    zT_79FAE712_u64 zT_206;
    zT_BAEE192E_Opt_10 zT_207 = {0};
    unsigned char zT_208;
    unsigned int zT_211;
    unsigned int zT_213;
    unsigned int* zT_218;
    unsigned int zT_219;
    unsigned int* zT_220;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int* zT_224;
    unsigned int* zT_225;
    unsigned int zT_227;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int hf;
    unsigned int old;
    unsigned int rt;
    unsigned int r;
    unsigned int pc;
    unsigned int oldc;
    zT_3CB0179A_Slice_zT_05F374B1_u ec2;
    unsigned int ei2;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    unsigned int ei3;
    unsigned int ps;
    unsigned int lo;
    unsigned int hi;
    unsigned int tmp;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_16 = stack;
    zT_17 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_16, zT_17);
    goto z_bb_3;
    z_bb_3:
    zT_18 = stack->len;
    if ((int)(zT_18 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = stack->items;
    zT_23 = stack->len;
    zT_25 = zT_23 - (unsigned int)(1);
    zT_26 = zT_22[zT_25];
    ni = zT_26;
    zT_27 = stack->len;
    stack->len = (unsigned int)(zT_27 - (unsigned int)(1));
    zT_31 = store;
    zT_32 = ni;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    n = zT_33;
    zT_35 = n.kind;
    k = zT_35;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_198 = parent_count;
    zT_199 = caller_key;
    zT_200 = zF_A05A7BE1_u64ToU32MapGet(zT_198, zT_199);
    zT_201 = zT_200.has_value;
    if (zT_201) goto z_bb_56; else goto z_bb_57;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_40 = n.child_0;
    if ((int)(zT_40 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_9:
    zT_43 = store;
    zT_44 = sym_reg;
    zT_45 = module_id;
    zT_46 = n.child_0;
    zT_48 = zF_860C82EC_resolveCalleeKey(zT_43, zT_44, zT_45, zT_46);
    zT_49 = zT_48.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_115 = store;
    zT_116 = ni;
    zT_117 = zF_850FDF81_astStoreNodeExtraCh(zT_115, zT_116);
    ec = zT_117;
    zT_119 = 0;
    ei = zT_119;
    goto z_bb_25;
    z_bb_11:
    ck = zT_48.value;
    zT_54 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_54;
    zT_58 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_58;
    zT_59 = suspending_fns;
    zT_60 = cmid;
    zT_61 = cnid;
    zT_62 = zF_7C7E43BF_asyncIsSuspending(zT_59, zT_60, zT_61);
    if (zT_62) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_111 = stack;
    zT_112 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_111, zT_112);
    goto z_bb_10;
    z_bb_13:
    zT_63 = awaited_fns;
    zT_64 = ck;
    zF_B6EB812C_u64ToU32MapPut(zT_63, zT_64, (unsigned int)(1));
    (void)store;
    zT_68 = 1;
    hf = zT_68;
    zT_69 = hidden_fns;
    zT_70 = caller_key;
    zT_71 = zF_A05A7BE1_u64ToU32MapGet(zT_69, zT_70);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    old = zT_71.value;
    zT_75 = old | (unsigned int)(1);
    hf = zT_75;
    goto z_bb_16;
    z_bb_16:
    zT_77 = 1;
    rt = zT_77;
    zT_78 = fn_ret_types;
    zT_79 = ck;
    zT_80 = zF_A05A7BE1_u64ToU32MapGet(zT_78, zT_79);
    zT_81 = zT_80.has_value;
    if (zT_81) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    r = zT_80.value;
    rt = r;
    goto z_bb_18;
    z_bb_18:
    if ((int)(rt != (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_86 = hf | (unsigned int)(2);
    hf = zT_86;
    zT_88 = 0;
    pc = zT_88;
    zT_89 = parent_count;
    zT_90 = caller_key;
    zT_91 = zF_A05A7BE1_u64ToU32MapGet(zT_89, zT_90);
    zT_92 = zT_91.has_value;
    if (zT_92) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_108 = hidden_fns;
    zT_109 = caller_key;
    zT_110 = hf;
    zF_B6EB812C_u64ToU32MapPut(zT_108, zT_109, zT_110);
    (void)store;
    goto z_bb_14;
    z_bb_21:
    oldc = zT_91.value;
    pc = oldc;
    goto z_bb_22;
    z_bb_22:
    if ((int)(pc == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_96 = parent_start;
    zT_97 = caller_key;
    zT_99 = parent_type_list->len;
    zF_B6EB812C_u64ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)zT_99));
    (void)store;
    goto z_bb_24;
    z_bb_24:
    zT_101 = parent_type_list;
    zT_102 = rt;
    zF_62F717A2_u32ArrayListAppend(zT_101, zT_102);
    zT_103 = parent_count;
    zT_104 = caller_key;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, (unsigned int)(pc + (unsigned int)(1)));
    (void)store;
    goto z_bb_20;
    z_bb_25:
    zT_121 = ec.len;
    if ((int)(ei < zT_121)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_123 = stack;
    zT_125 = ec.ptr;
    zT_124 = zT_125[ei];
    zF_62F717A2_u32ArrayListAppend(zT_123, zT_124);
    goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_127 = 1;
    zT_128 = ei + zT_127;
    ei = zT_128;
    goto z_bb_25;
    z_bb_29:
    zT_134 = store;
    zT_135 = ni;
    zT_136 = zF_850FDF81_astStoreNodeExtraCh(zT_134, zT_135);
    ec2 = zT_136;
    zT_138 = 0;
    ei2 = zT_138;
    goto z_bb_31;
    z_bb_30:
    zT_148 = n.child_0;
    if ((int)(zT_148 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    zT_140 = ec2.len;
    if ((int)(ei2 < zT_140)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_142 = stack;
    zT_144 = ec2.ptr;
    zT_143 = zT_144[ei2];
    zF_62F717A2_u32ArrayListAppend(zT_142, zT_143);
    goto z_bb_34;
    z_bb_33:
    goto z_bb_6;
    z_bb_34:
    zT_146 = 1;
    zT_147 = ei2 + zT_146;
    ei2 = zT_147;
    goto z_bb_31;
    z_bb_35:
    zT_152 = k;
    zT_155 = zF_C395F6FD_nodeChildIsNode(zT_152, (unsigned char)(0));
    zT_151 = zT_155;
    goto z_bb_37;
    z_bb_36:
    zT_151 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_151) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_156 = stack;
    zT_157 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_156, zT_157);
    goto z_bb_39;
    z_bb_39:
    zT_159 = n.child_1;
    if ((int)(zT_159 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_163 = k;
    zT_166 = zF_C395F6FD_nodeChildIsNode(zT_163, (unsigned char)(1));
    zT_162 = zT_166;
    goto z_bb_42;
    z_bb_41:
    zT_162 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_162) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_167 = stack;
    zT_168 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_167, zT_168);
    goto z_bb_44;
    z_bb_44:
    zT_170 = n.child_2;
    if ((int)(zT_170 != (unsigned int)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_174 = k;
    zT_177 = zF_C395F6FD_nodeChildIsNode(zT_174, (unsigned char)(2));
    zT_173 = zT_177;
    goto z_bb_47;
    z_bb_46:
    zT_173 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_173) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_178 = stack;
    zT_179 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_178, zT_179);
    goto z_bb_49;
    z_bb_49:
    zT_181 = k;
    zT_182 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_181);
    if (zT_182) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_184 = store;
    zT_185 = ni;
    zT_186 = zF_850FDF81_astStoreNodeExtraCh(zT_184, zT_185);
    ec3 = zT_186;
    zT_188 = 0;
    ei3 = zT_188;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_6;
    z_bb_52:
    zT_190 = ec3.len;
    if ((int)(ei3 < zT_190)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_192 = stack;
    zT_194 = ec3.ptr;
    zT_193 = zT_194[ei3];
    zF_62F717A2_u32ArrayListAppend(zT_192, zT_193);
    goto z_bb_55;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_196 = 1;
    zT_197 = ei3 + zT_196;
    ei3 = zT_197;
    goto z_bb_52;
    z_bb_56:
    pc = zT_200.value;
    if ((int)(pc > (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return;
    z_bb_58:
    zT_205 = parent_start;
    zT_206 = caller_key;
    zT_207 = zF_A05A7BE1_u64ToU32MapGet(zT_205, zT_206);
    zT_208 = zT_207.has_value;
    if (zT_208) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    ps = zT_207.value;
    zT_211 = (unsigned int)ps;
    lo = zT_211;
    zT_213 = parent_type_list->len;
    hi = zT_213;
    goto z_bb_62;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    if ((int)((unsigned int)(lo + (unsigned int)(1)) < hi)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_218 = parent_type_list->items;
    zT_219 = zT_218[lo];
    tmp = zT_219;
    zT_220 = parent_type_list->items;
    zT_222 = hi - (unsigned int)(1);
    zT_223 = zT_220[zT_222];
    zT_224 = parent_type_list->items;
    zT_224[lo] = zT_223;
    zT_225 = parent_type_list->items;
    zT_227 = hi - (unsigned int)(1);
    zT_225[zT_227] = tmp;
    zT_229 = lo + (unsigned int)(1);
    lo = zT_229;
    zT_231 = hi - (unsigned int)(1);
    hi = zT_231;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    goto z_bb_62;
}

/* asyncStateTypeForCount */
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int count) {
    if ((int)(count <= (unsigned int)(255))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(8);
    z_bb_2:
    if ((int)(count <= (unsigned int)(65535))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(9);
    z_bb_4:
    return (unsigned int)(10);
}

/* scanSuspensionCount */
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, unsigned int async_suspend_name_id, unsigned int async_init_name_id) {
    unsigned int zT_9;
    zT_B687BB96_U32ArrayList* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    unsigned int zT_49;
    unsigned int zT_51;
    zT_B687BB96_U32ArrayList* zT_53;
    unsigned int zT_54;
    unsigned int* zT_55;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_66;
    zT_3D7259E2_SymbolRegistry* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_BBEE1AC1_Opt_11 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_77;
    unsigned int zT_81;
    zT_A4CE86B7_U64ToU32Map* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    int zT_85 = 0;
    unsigned int zT_87;
    zT_B687BB96_U32ArrayList* zT_88;
    unsigned int zT_89;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_94 = {0};
    unsigned int zT_96;
    unsigned int zT_98;
    zT_B687BB96_U32ArrayList* zT_100;
    unsigned int zT_101;
    unsigned int* zT_102;
    int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_109;
    zT_8143F551_AstKind zT_110;
    int zT_113 = 0;
    zT_B687BB96_U32ArrayList* zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    int zT_120;
    zT_8143F551_AstKind zT_121;
    int zT_124 = 0;
    zT_B687BB96_U32ArrayList* zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    int zT_131;
    zT_8143F551_AstKind zT_132;
    int zT_135 = 0;
    zT_B687BB96_U32ArrayList* zT_136;
    unsigned int zT_137;
    zT_8143F551_AstKind zT_139;
    int zT_140 = 0;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_144 = {0};
    unsigned int zT_146;
    unsigned int zT_148;
    zT_B687BB96_U32ArrayList* zT_150;
    unsigned int zT_151;
    unsigned int* zT_152;
    int zT_154;
    unsigned int zT_155;
    unsigned int count;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    zT_3CB0179A_Slice_zT_05F374B1_u ecb;
    unsigned int bi;
    zT_3CB0179A_Slice_zT_05F374B1_u ecf;
    unsigned int fi;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    unsigned int ei3;
    zT_9 = 0;
    count = zT_9;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return count;
    z_bb_2:
    zT_13 = stack;
    zT_14 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_13, zT_14);
    goto z_bb_3;
    z_bb_3:
    zT_15 = stack->len;
    if ((int)(zT_15 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = stack->items;
    zT_20 = stack->len;
    zT_22 = zT_20 - (unsigned int)(1);
    zT_23 = zT_19[zT_22];
    ni = zT_23;
    zT_24 = stack->len;
    stack->len = (unsigned int)(zT_24 - (unsigned int)(1));
    zT_28 = store;
    zT_29 = ni;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    n = zT_30;
    zT_32 = n.kind;
    k = zT_32;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return count;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_37 = n.child_0;
    if ((int)(zT_37 == async_suspend_name_id)) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    zT_40 = n.child_0;
    zT_39 = zT_40 == async_init_name_id;
    goto z_bb_11;
    z_bb_10:
    zT_39 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_43 = count + (unsigned int)(1);
    count = zT_43;
    goto z_bb_13;
    z_bb_13:
    zT_45 = store;
    zT_46 = ni;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_45, zT_46);
    ecb = zT_47;
    zT_49 = 0;
    bi = zT_49;
    goto z_bb_14;
    z_bb_14:
    zT_51 = ecb.len;
    if ((int)(bi < zT_51)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = stack;
    zT_55 = ecb.ptr;
    zT_54 = zT_55[bi];
    zF_62F717A2_u32ArrayListAppend(zT_53, zT_54);
    goto z_bb_17;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_57 = 1;
    zT_58 = bi + zT_57;
    bi = zT_58;
    goto z_bb_14;
    z_bb_18:
    zT_63 = n.child_0;
    if ((int)(zT_63 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_106 = n.child_0;
    if ((int)(zT_106 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_20:
    zT_66 = store;
    zT_67 = sym_reg;
    zT_68 = module_id;
    zT_69 = n.child_0;
    zT_71 = zF_860C82EC_resolveCalleeKey(zT_66, zT_67, zT_68, zT_69);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_92 = store;
    zT_93 = ni;
    zT_94 = zF_850FDF81_astStoreNodeExtraCh(zT_92, zT_93);
    ecf = zT_94;
    zT_96 = 0;
    fi = zT_96;
    goto z_bb_26;
    z_bb_22:
    ck = zT_71.value;
    zT_77 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_77;
    zT_81 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_81;
    zT_82 = suspending_fns;
    zT_83 = cmid;
    zT_84 = cnid;
    zT_85 = zF_7C7E43BF_asyncIsSuspending(zT_82, zT_83, zT_84);
    if (zT_85) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_88 = stack;
    zT_89 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_88, zT_89);
    goto z_bb_21;
    z_bb_24:
    zT_87 = count + (unsigned int)(1);
    count = zT_87;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_98 = ecf.len;
    if ((int)(fi < zT_98)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_100 = stack;
    zT_102 = ecf.ptr;
    zT_101 = zT_102[fi];
    zF_62F717A2_u32ArrayListAppend(zT_100, zT_101);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_6;
    z_bb_29:
    zT_104 = 1;
    zT_105 = fi + zT_104;
    fi = zT_105;
    goto z_bb_26;
    z_bb_30:
    zT_110 = k;
    zT_113 = zF_C395F6FD_nodeChildIsNode(zT_110, (unsigned char)(0));
    zT_109 = zT_113;
    goto z_bb_32;
    z_bb_31:
    zT_109 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_109) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_114 = stack;
    zT_115 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_114, zT_115);
    goto z_bb_34;
    z_bb_34:
    zT_117 = n.child_1;
    if ((int)(zT_117 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_121 = k;
    zT_124 = zF_C395F6FD_nodeChildIsNode(zT_121, (unsigned char)(1));
    zT_120 = zT_124;
    goto z_bb_37;
    z_bb_36:
    zT_120 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_120) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_125 = stack;
    zT_126 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_125, zT_126);
    goto z_bb_39;
    z_bb_39:
    zT_128 = n.child_2;
    if ((int)(zT_128 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_132 = k;
    zT_135 = zF_C395F6FD_nodeChildIsNode(zT_132, (unsigned char)(2));
    zT_131 = zT_135;
    goto z_bb_42;
    z_bb_41:
    zT_131 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_131) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_136 = stack;
    zT_137 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_136, zT_137);
    goto z_bb_44;
    z_bb_44:
    zT_139 = k;
    zT_140 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_139);
    if (zT_140) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_142 = store;
    zT_143 = ni;
    zT_144 = zF_850FDF81_astStoreNodeExtraCh(zT_142, zT_143);
    ec3 = zT_144;
    zT_146 = 0;
    ei3 = zT_146;
    goto z_bb_47;
    z_bb_46:
    goto z_bb_6;
    z_bb_47:
    zT_148 = ec3.len;
    if ((int)(ei3 < zT_148)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_150 = stack;
    zT_152 = ec3.ptr;
    zT_151 = zT_152[ei3];
    zF_62F717A2_u32ArrayListAppend(zT_150, zT_151);
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_154 = 1;
    zT_155 = ei3 + zT_154;
    ei3 = zT_155;
    goto z_bb_47;
}

/* asyncPtrVoid */
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_1;
    unsigned int zT_6 = 0;
    zT_1 = reg;
    zT_6 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1, (unsigned int)(1), (int)(0));
    return zT_6;
}

/* emitFrameMarker */
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64 key, unsigned int size) {
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_5826BFC7_Arr_unsigned_char_1 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_5826BFC7_Arr_unsigned_char_1 zT_45;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_5826BFC7_Arr_unsigned_char_1 zT_74;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84 = 0;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_5 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_5;
    zT_9 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_9;
    zT_11 = "FRAME:m";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    m1 = zT_12;
    zT_14 = m1;
    zF_48AC7B3A_markerWrite(zT_14);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_16[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = module_id;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)b1) + zT_22;
    zT_24 = (unsigned int)(12) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    l1 = zT_26;
    zT_31 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_31;
    zT_36 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_37 = (unsigned int)(11) - s1;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_32 = zT_38;
    zF_48AC7B3A_markerWrite(zT_32);
    zT_40 = ":n";
    zT_42 = 2;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    m2 = zT_41;
    zT_43 = m2;
    zF_48AC7B3A_markerWrite(zT_43);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_45[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_45[_i];
        _i++;
    }
}
    zT_47 = name_id;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)b2) + zT_51;
    zT_53 = (unsigned int)(12) - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_48 = zT_54;
    zT_55 = zF_A7504564_itoa(zT_47, zT_48);
    l2 = zT_55;
    zT_60 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_60;
    zT_65 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_66 = (unsigned int)(11) - s2;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_61 = zT_67;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_69 = ":s";
    zT_71 = 2;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    m3 = zT_70;
    zT_72 = m3;
    zF_48AC7B3A_markerWrite(zT_72);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_74[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_74[_i];
        _i++;
    }
}
    zT_76 = size;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)b3) + zT_80;
    zT_82 = (unsigned int)(12) - zT_80;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zT_84 = zF_A7504564_itoa(zT_76, zT_77);
    l3 = zT_84;
    zT_89 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_89;
    zT_94 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_95 = (unsigned int)(11) - s3;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90 = zT_96;
    zF_48AC7B3A_markerWrite(zT_90);
    zT_98 = "\n";
    zT_100 = 1;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    m4 = zT_99;
    zT_101 = m4;
    zF_48AC7B3A_markerWrite(zT_101);
    return;
}

/* asyncFrameSizeRun */
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* typereg, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_B687BB96_U32ArrayList zT_23 = {0};
    zT_072B53A6_ModuleRegistry* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26 = {0};
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    zT_3E40CD83_Sand* zT_44;
    zT_A4CE86B7_U64ToU32Map zT_45 = {0};
    unsigned int zT_47;
    unsigned int zT_49;
    zT_6E8D187B_ModuleEntry* zT_52;
    zT_6E8D187B_ModuleEntry zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_69 = {0};
    unsigned int zT_71;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int* zT_78;
    zT_22A7C88B_AstNode zT_80 = {0};
    zT_8143F551_AstKind zT_81;
    zT_4878453E_anon_224415 zT_87;
    zT_243D6A41_FnProto* zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int* zT_91;
    unsigned int zT_93 = 0;
    unsigned int zT_94;
    zT_243D6A41_FnProto zT_95;
    unsigned int zT_97;
    zT_8EED1867_ResolvedTypeTable* zT_98;
    unsigned int zT_99;
    zT_BAEE192E_Opt_10 zT_101 = {0};
    unsigned char zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_104;
    zT_79FAE712_u64 zT_105;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_6E8D187B_ModuleEntry* zT_110;
    zT_6E8D187B_ModuleEntry zT_111;
    zT_79FAE712_u64 zT_114 = 0;
    int zT_115;
    unsigned int zT_116;
    int zT_117;
    unsigned int zT_118;
    unsigned int zT_120;
    unsigned int zT_122;
    zT_6E8D187B_ModuleEntry* zT_125;
    zT_6E8D187B_ModuleEntry zT_126;
    unsigned int zT_127;
    zT_6B0A7D14_AstStore* zT_131;
    unsigned int zT_132;
    zT_22A7C88B_AstNode zT_133 = {0};
    zT_8143F551_AstKind zT_134;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_142 = {0};
    unsigned int zT_144;
    unsigned int zT_146;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int* zT_151;
    zT_22A7C88B_AstNode zT_153 = {0};
    zT_8143F551_AstKind zT_154;
    zT_4878453E_anon_224415 zT_160;
    zT_243D6A41_FnProto* zT_161;
    zT_6B0A7D14_AstStore* zT_162;
    unsigned int zT_163;
    unsigned int* zT_164;
    unsigned int zT_166 = 0;
    unsigned int zT_167;
    zT_243D6A41_FnProto zT_168;
    zT_A4CE86B7_U64ToU32Map* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_6E8D187B_ModuleEntry* zT_172;
    zT_6E8D187B_ModuleEntry zT_173;
    int zT_176 = 0;
    zT_6B0A7D14_AstStore* zT_178;
    zT_3D7259E2_SymbolRegistry* zT_179;
    unsigned int zT_180;
    zT_79FAE712_u64 zT_181;
    unsigned int zT_182;
    zT_B687BB96_U32ArrayList* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    zT_A4CE86B7_U64ToU32Map* zT_185;
    zT_A4CE86B7_U64ToU32Map* zT_186;
    zT_A4CE86B7_U64ToU32Map* zT_187;
    zT_B687BB96_U32ArrayList* zT_188;
    zT_A4CE86B7_U64ToU32Map* zT_189;
    zT_A4CE86B7_U64ToU32Map* zT_190;
    zT_6E8D187B_ModuleEntry* zT_191;
    zT_6E8D187B_ModuleEntry zT_192;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_6E8D187B_ModuleEntry* zT_196;
    zT_6E8D187B_ModuleEntry zT_197;
    zT_79FAE712_u64 zT_200 = 0;
    int zT_204;
    unsigned int zT_205;
    int zT_206;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned int zT_211;
    zT_6E8D187B_ModuleEntry* zT_214;
    zT_6E8D187B_ModuleEntry zT_215;
    unsigned int zT_216;
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_221;
    zT_22A7C88B_AstNode zT_222 = {0};
    zT_8143F551_AstKind zT_223;
    zT_6B0A7D14_AstStore* zT_229;
    unsigned int zT_230;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_231 = {0};
    unsigned int zT_233;
    unsigned int zT_235;
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int* zT_240;
    zT_22A7C88B_AstNode zT_242 = {0};
    zT_8143F551_AstKind zT_243;
    zT_6B0A7D14_AstStore* zT_249;
    unsigned int zT_250;
    unsigned int* zT_251;
    unsigned int zT_253 = 0;
    zT_4878453E_anon_224415 zT_255;
    zT_243D6A41_FnProto* zT_256;
    unsigned int zT_257;
    zT_243D6A41_FnProto zT_258;
    zT_A4CE86B7_U64ToU32Map* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_6E8D187B_ModuleEntry* zT_262;
    zT_6E8D187B_ModuleEntry zT_263;
    int zT_266 = 0;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_6E8D187B_ModuleEntry* zT_271;
    zT_6E8D187B_ModuleEntry zT_272;
    zT_79FAE712_u64 zT_275 = 0;
    int zT_277;
    unsigned char zT_278;
    int zT_284;
    zT_6E8D187B_ModuleEntry* zT_285;
    zT_6E8D187B_ModuleEntry zT_286;
    unsigned int zT_287;
    int zT_290;
    unsigned char zT_291;
    zT_D3EB6303_StringInterner* zT_298;
    unsigned int zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301 = {0};
    unsigned int zT_303;
    int zT_306;
    unsigned char* zT_307;
    int zT_308;
    unsigned char zT_309;
    int zT_312;
    unsigned char* zT_313;
    int zT_314;
    unsigned char zT_315;
    int zT_318;
    unsigned char* zT_319;
    int zT_320;
    unsigned char zT_321;
    int zT_324;
    unsigned char* zT_325;
    int zT_326;
    unsigned char zT_327;
    int zT_330;
    zT_A4CE86B7_U64ToU32Map* zT_331;
    zT_79FAE712_u64 zT_332;
    zT_6B0A7D14_AstStore* zT_336;
    zT_3D7259E2_SymbolRegistry* zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    zT_B687BB96_U32ArrayList* zT_340;
    zT_A4CE86B7_U64ToU32Map* zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    zT_6E8D187B_ModuleEntry* zT_344;
    zT_6E8D187B_ModuleEntry zT_345;
    unsigned int zT_349 = 0;
    unsigned int zT_351;
    unsigned int zT_352 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_353;
    zT_79FAE712_u64 zT_354;
    unsigned int zT_355;
    unsigned int zT_357;
    unsigned int zT_359;
    zT_338B7C76_TypeRegistry* zT_360;
    unsigned int* zT_362;
    unsigned int* zT_363;
    unsigned int zT_367 = 0;
    zT_338B7C76_TypeRegistry* zT_368;
    unsigned int* zT_370;
    unsigned int* zT_371;
    unsigned int zT_375 = 0;
    zT_338B7C76_TypeRegistry* zT_376;
    unsigned int zT_377;
    unsigned int* zT_378;
    unsigned int* zT_379;
    unsigned int zT_382 = 0;
    unsigned short zT_383;
    unsigned int zT_387;
    unsigned short zT_391;
    zT_79FAE712_u64 zT_393;
    zT_6B0A7D14_AstStore* zT_395;
    zT_79FAE712_u64 zT_396;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_397 = {0};
    unsigned int zT_399;
    unsigned int zT_401;
    zT_6B0A7D14_AstStore* zT_404;
    unsigned int zT_405;
    unsigned int* zT_406;
    zT_22A7C88B_AstNode zT_408 = {0};
    unsigned int zT_409;
    unsigned int zT_413;
    zT_8EED1867_ResolvedTypeTable* zT_414;
    unsigned int zT_415;
    zT_BAEE192E_Opt_10 zT_417 = {0};
    unsigned char zT_418;
    zT_338B7C76_TypeRegistry* zT_420;
    unsigned int zT_421;
    unsigned int* zT_422;
    unsigned int* zT_423;
    unsigned int zT_426 = 0;
    unsigned int zT_428;
    zT_6B0A7D14_AstStore* zT_429;
    unsigned int zT_430;
    zT_B687BB96_U32ArrayList* zT_431;
    zT_338B7C76_TypeRegistry* zT_432;
    zT_8EED1867_ResolvedTypeTable* zT_433;
    unsigned int* zT_434;
    unsigned int* zT_435;
    unsigned int zT_441;
    zT_A4CE86B7_U64ToU32Map* zT_442;
    zT_79FAE712_u64 zT_443;
    zT_BAEE192E_Opt_10 zT_444 = {0};
    unsigned char zT_445;
    zT_338B7C76_TypeRegistry* zT_451;
    unsigned int zT_452;
    unsigned int* zT_453;
    unsigned int* zT_454;
    zT_338B7C76_TypeRegistry* zT_455;
    unsigned int zT_456 = 0;
    unsigned int zT_459 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_460;
    zT_79FAE712_u64 zT_461;
    zT_BAEE192E_Opt_10 zT_462 = {0};
    unsigned char zT_463;
    int zT_464;
    zT_A4CE86B7_U64ToU32Map* zT_465;
    zT_79FAE712_u64 zT_466;
    zT_BAEE192E_Opt_10 zT_467 = {0};
    unsigned char zT_468;
    zT_338B7C76_TypeRegistry* zT_469;
    unsigned int zT_470;
    unsigned int* zT_471;
    unsigned int* zT_472;
    zT_338B7C76_TypeRegistry* zT_473;
    unsigned int zT_474 = 0;
    unsigned int zT_477 = 0;
    unsigned int zT_483;
    zT_A4CE86B7_U64ToU32Map* zT_484;
    zT_79FAE712_u64 zT_485;
    zT_BAEE192E_Opt_10 zT_486 = {0};
    unsigned char zT_487;
    unsigned int zT_490;
    zT_A4CE86B7_U64ToU32Map* zT_491;
    zT_79FAE712_u64 zT_492;
    zT_BAEE192E_Opt_10 zT_493 = {0};
    unsigned char zT_494;
    unsigned int zT_497;
    unsigned int* zT_500;
    unsigned int zT_502;
    unsigned int zT_503;
    zT_338B7C76_TypeRegistry* zT_504;
    unsigned int zT_505;
    unsigned int* zT_506;
    unsigned int* zT_507;
    unsigned int zT_510 = 0;
    unsigned int zT_512;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned int zT_516 = 0;
    unsigned int zT_519;
    unsigned int zT_520;
    unsigned int zT_523 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_524;
    zT_79FAE712_u64 zT_525;
    unsigned int zT_526;
    zT_79FAE712_u64 zT_527;
    unsigned int zT_528;
    int zT_529;
    unsigned int zT_530;
    int zT_531;
    unsigned int zT_532;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_B687BB96_U32ArrayList stack;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_text;
    unsigned int async_init_name_id;
    zT_A4CE86B7_U64ToU32Map fn_ret_types;
    unsigned int mi0;
    unsigned int ar0;
    unsigned int mi0b;
    zT_22A7C88B_AstNode r0;
    zT_3CB0179A_Slice_zT_05F374B1_u d0;
    unsigned int di0;
    zT_22A7C88B_AstNode dc0;
    zT_243D6A41_FnProto pr0;
    unsigned int rt0;
    unsigned int rr0;
    unsigned int ar0b;
    unsigned int mi;
    zT_22A7C88B_AstNode r0b;
    zT_3CB0179A_Slice_zT_05F374B1_u d0b;
    unsigned int di0b;
    zT_22A7C88B_AstNode dc0b;
    zT_243D6A41_FnProto pr0b;
    unsigned int ast_root;
    zT_22A7C88B_AstNode root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    int is_driver_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u dm;
    unsigned int susp_count;
    unsigned int state_type;
    unsigned int offset;
    unsigned int max_align;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    unsigned int hid;
    zT_22A7C88B_AstNode pnode;
    unsigned int pt;
    unsigned int rtp;
    unsigned int h;
    unsigned int pstart;
    unsigned int total;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_17 = "AFS\n";
    zT_19 = 4;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    p_msg = zT_18;
    zT_20 = p_msg;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_22 = alloc;
    zT_23 = zF_8E537D0C_u32ArrayListInit(zT_22);
    stack = zT_23;
    zT_25 = module_reg;
    zT_26 = zF_3452C137_moduleRegistryGetMo(zT_25);
    mods = zT_26;
    zT_28 = "@asyncSuspend";
    zT_30 = 13;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    asu_text = zT_29;
    zT_32 = interner;
    zT_33 = asu_text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    async_suspend_name_id = zT_34;
    zT_36 = "@asyncInit";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    ain_text = zT_37;
    zT_40 = interner;
    zT_41 = ain_text;
    zT_42 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    async_init_name_id = zT_42;
    zT_44 = alloc;
    zT_45 = zF_986226E1_u64ToU32MapInit(zT_44);
    fn_ret_types = zT_45;
    zT_47 = 0;
    mi0 = zT_47;
    goto z_bb_1;
    z_bb_1:
    zT_49 = mods.len;
    if ((int)(mi0 < zT_49)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_52 = mods.ptr;
    zT_53 = zT_52[mi0];
    zT_54 = zT_53.ast_root;
    ar0 = zT_54;
    if ((int)(ar0 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_120 = 0;
    mi0b = zT_120;
    goto z_bb_17;
    z_bb_4:
    zT_117 = 1;
    zT_118 = mi0 + zT_117;
    mi0 = zT_118;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_58 = store;
    zT_59 = ar0;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    r0 = zT_60;
    zT_61 = r0.kind;
    if ((int)(zT_61 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_67 = store;
    zT_68 = ar0;
    zT_69 = zF_850FDF81_astStoreNodeExtraCh(zT_67, zT_68);
    d0 = zT_69;
    zT_71 = 0;
    di0 = zT_71;
    goto z_bb_9;
    z_bb_9:
    zT_73 = d0.len;
    if ((int)(di0 < zT_73)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_76 = store;
    zT_78 = d0.ptr;
    zT_77 = zT_78[di0];
    zT_80 = zF_FCDD1D35_astStoreNodeAt(zT_76, zT_77);
    dc0 = zT_80;
    zT_81 = dc0.kind;
    if ((int)(zT_81 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_115 = 1;
    zT_116 = di0 + zT_115;
    di0 = zT_116;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_87 = store->fn_protos;
    zT_88 = zT_87.items;
    zT_89 = store;
    zT_91 = d0.ptr;
    zT_90 = zT_91[di0];
    zT_93 = zF_8BA26B9E_astStoreNodePayload(zT_89, zT_90);
    zT_94 = (unsigned int)zT_93;
    zT_95 = zT_88[zT_94];
    pr0 = zT_95;
    zT_97 = 1;
    rt0 = zT_97;
    zT_98 = resolved_types;
    zT_99 = pr0.return_type_node;
    zT_101 = zF_999DCF51_resolvedTypeTableGe(zT_98, zT_99);
    zT_102 = zT_101.has_value;
    if (zT_102) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    rr0 = zT_101.value;
    rt0 = rr0;
    goto z_bb_16;
    z_bb_16:
    zT_104 = &fn_ret_types;
    zT_110 = mods.ptr;
    zT_111 = zT_110[mi0];
    zT_108 = zT_111.id;
    zT_109 = pr0.name_id;
    zT_114 = zF_9D041EB6_asyncKey(zT_108, zT_109);
    zT_105 = zT_114;
    zT_106 = rt0;
    zF_B6EB812C_u64ToU32MapPut(zT_104, zT_105, zT_106);
    (void)alloc;
    goto z_bb_12;
    z_bb_17:
    zT_122 = mods.len;
    if ((int)(mi0b < zT_122)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_125 = mods.ptr;
    zT_126 = zT_125[mi0b];
    zT_127 = zT_126.ast_root;
    ar0b = zT_127;
    if ((int)(ar0b == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_209 = 0;
    mi = zT_209;
    goto z_bb_33;
    z_bb_20:
    zT_206 = 1;
    zT_207 = mi0b + zT_206;
    mi0b = zT_207;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_131 = store;
    zT_132 = ar0b;
    zT_133 = zF_FCDD1D35_astStoreNodeAt(zT_131, zT_132);
    r0b = zT_133;
    zT_134 = r0b.kind;
    if ((int)(zT_134 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_140 = store;
    zT_141 = ar0b;
    zT_142 = zF_850FDF81_astStoreNodeExtraCh(zT_140, zT_141);
    d0b = zT_142;
    zT_144 = 0;
    di0b = zT_144;
    goto z_bb_25;
    z_bb_25:
    zT_146 = d0b.len;
    if ((int)(di0b < zT_146)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_149 = store;
    zT_151 = d0b.ptr;
    zT_150 = zT_151[di0b];
    zT_153 = zF_FCDD1D35_astStoreNodeAt(zT_149, zT_150);
    dc0b = zT_153;
    zT_154 = dc0b.kind;
    if ((int)(zT_154 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_204 = 1;
    zT_205 = di0b + zT_204;
    di0b = zT_205;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_160 = store->fn_protos;
    zT_161 = zT_160.items;
    zT_162 = store;
    zT_164 = d0b.ptr;
    zT_163 = zT_164[di0b];
    zT_166 = zF_8BA26B9E_astStoreNodePayload(zT_162, zT_163);
    zT_167 = (unsigned int)zT_166;
    zT_168 = zT_161[zT_167];
    pr0b = zT_168;
    zT_169 = suspending_fns;
    zT_172 = mods.ptr;
    zT_173 = zT_172[mi0b];
    zT_170 = zT_173.id;
    zT_171 = pr0b.name_id;
    zT_176 = zF_7C7E43BF_asyncIsSuspending(zT_169, zT_170, zT_171);
    if ((int)(!zT_176)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_178 = store;
    zT_179 = sym_reg;
    zT_191 = mods.ptr;
    zT_192 = zT_191[mi0b];
    zT_180 = zT_192.id;
    zT_196 = mods.ptr;
    zT_197 = zT_196[mi0b];
    zT_194 = zT_197.id;
    zT_195 = pr0b.name_id;
    zT_200 = zF_9D041EB6_asyncKey(zT_194, zT_195);
    zT_181 = zT_200;
    zT_182 = dc0b.child_0;
    zT_183 = &stack;
    zT_184 = suspending_fns;
    zT_185 = &fn_ret_types;
    zT_186 = awaited_fns;
    zT_187 = async_hidden_fns;
    zT_188 = parent_result_type_list;
    zT_189 = parent_result_start;
    zT_190 = parent_result_count;
    zF_D62E4E4C_scanImplicitAwaits(zT_178, zT_179, zT_180, zT_181, zT_182, zT_183, zT_184, zT_185, zT_186, zT_187, zT_188, zT_189, zT_190);
    goto z_bb_28;
    z_bb_33:
    zT_211 = mods.len;
    if ((int)(mi < zT_211)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = mods.ptr;
    zT_215 = zT_214[mi];
    zT_216 = zT_215.ast_root;
    ast_root = zT_216;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return;
    z_bb_36:
    zT_531 = 1;
    zT_532 = mi + zT_531;
    mi = zT_532;
    goto z_bb_33;
    z_bb_37:
    goto z_bb_36;
    z_bb_38:
    zT_220 = store;
    zT_221 = ast_root;
    zT_222 = zF_FCDD1D35_astStoreNodeAt(zT_220, zT_221);
    root = zT_222;
    zT_223 = root.kind;
    if ((int)(zT_223 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_229 = store;
    zT_230 = ast_root;
    zT_231 = zF_850FDF81_astStoreNodeExtraCh(zT_229, zT_230);
    decls = zT_231;
    zT_233 = 0;
    di = zT_233;
    goto z_bb_41;
    z_bb_41:
    zT_235 = decls.len;
    if ((int)(di < zT_235)) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_238 = store;
    zT_240 = decls.ptr;
    zT_239 = zT_240[di];
    zT_242 = zF_FCDD1D35_astStoreNodeAt(zT_238, zT_239);
    decl = zT_242;
    zT_243 = decl.kind;
    if ((int)(zT_243 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_529 = 1;
    zT_530 = di + zT_529;
    di = zT_530;
    goto z_bb_41;
    z_bb_45:
    goto z_bb_44;
    z_bb_46:
    zT_249 = store;
    zT_251 = decls.ptr;
    zT_250 = zT_251[di];
    zT_253 = zF_8BA26B9E_astStoreNodePayload(zT_249, zT_250);
    proto_idx = zT_253;
    zT_255 = store->fn_protos;
    zT_256 = zT_255.items;
    zT_257 = (unsigned int)proto_idx;
    zT_258 = zT_256[zT_257];
    proto = zT_258;
    zT_259 = suspending_fns;
    zT_262 = mods.ptr;
    zT_263 = zT_262[mi];
    zT_260 = zT_263.id;
    zT_261 = proto.name_id;
    zT_266 = zF_7C7E43BF_asyncIsSuspending(zT_259, zT_260, zT_261);
    if ((int)(!zT_266)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_271 = mods.ptr;
    zT_272 = zT_271[mi];
    zT_269 = zT_272.id;
    zT_270 = proto.name_id;
    zT_275 = zF_9D041EB6_asyncKey(zT_269, zT_270);
    key = zT_275;
    zT_277 = 0;
    is_driver_target = zT_277;
    zT_278 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_278) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_284 = 1;
    is_driver_target = zT_284;
    goto z_bb_50;
    z_bb_50:
    zT_285 = mods.ptr;
    zT_286 = zT_285[mi];
    zT_287 = zT_286.id;
    if ((int)(zT_287 == (unsigned int)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_291 = decl.flags;
    zT_290 = (unsigned short)((unsigned short)((unsigned short)zT_291) & (unsigned short)(2)) != (unsigned short)(0);
    goto z_bb_53;
    z_bb_52:
    zT_290 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_290) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_298 = interner;
    zT_299 = proto.name_id;
    zT_301 = zF_9134020D_stringInternerGet(zT_298, zT_299);
    dm = zT_301;
    zT_303 = dm.len;
    if ((int)(zT_303 == (unsigned int)(4))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if (is_driver_target) goto z_bb_70; else goto z_bb_71;
    z_bb_56:
    zT_307 = dm.ptr;
    zT_308 = 0;
    zT_309 = zT_307[zT_308];
    zT_306 = zT_309 == (unsigned char)(109);
    goto z_bb_58;
    z_bb_57:
    zT_306 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_306) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_313 = dm.ptr;
    zT_314 = 1;
    zT_315 = zT_313[zT_314];
    zT_312 = zT_315 == (unsigned char)(97);
    goto z_bb_61;
    z_bb_60:
    zT_312 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_312) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_319 = dm.ptr;
    zT_320 = 2;
    zT_321 = zT_319[zT_320];
    zT_318 = zT_321 == (unsigned char)(105);
    goto z_bb_64;
    z_bb_63:
    zT_318 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_318) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_325 = dm.ptr;
    zT_326 = 3;
    zT_327 = zT_325[zT_326];
    zT_324 = zT_327 == (unsigned char)(110);
    goto z_bb_67;
    z_bb_66:
    zT_324 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_324) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_330 = 1;
    is_driver_target = zT_330;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_55;
    z_bb_70:
    zT_331 = driver_targets;
    zT_332 = key;
    zF_B6EB812C_u64ToU32MapPut(zT_331, zT_332, (unsigned int)(1));
    (void)alloc;
    goto z_bb_71;
    z_bb_71:
    zT_336 = store;
    zT_337 = sym_reg;
    zT_344 = mods.ptr;
    zT_345 = zT_344[mi];
    zT_338 = zT_345.id;
    zT_339 = decl.child_0;
    zT_340 = &stack;
    zT_341 = suspending_fns;
    zT_342 = async_suspend_name_id;
    zT_343 = async_init_name_id;
    zT_349 = zF_0782A438_scanSuspensionCount(zT_336, zT_337, zT_338, zT_339, zT_340, zT_341, zT_342, zT_343);
    susp_count = zT_349;
    zT_351 = susp_count;
    zT_352 = zF_74FC996E_asyncStateTypeForCo(zT_351);
    state_type = zT_352;
    zT_353 = state_widths;
    zT_354 = key;
    zT_355 = state_type;
    zF_B6EB812C_u64ToU32MapPut(zT_353, zT_354, zT_355);
    (void)alloc;
    zT_357 = 0;
    offset = zT_357;
    zT_359 = 1;
    max_align = zT_359;
    zT_360 = typereg;
    zT_362 = &offset;
    zT_363 = &max_align;
    zT_367 = zF_769CB99B_addFrameField(zT_360, (unsigned int)(13), zT_362, zT_363);
    (void)zT_367;
    zT_368 = typereg;
    zT_370 = &offset;
    zT_371 = &max_align;
    zT_375 = zF_769CB99B_addFrameField(zT_368, (unsigned int)(13), zT_370, zT_371);
    (void)zT_375;
    zT_376 = typereg;
    zT_377 = state_type;
    zT_378 = &offset;
    zT_379 = &max_align;
    zT_382 = zF_769CB99B_addFrameField(zT_376, zT_377, zT_378, zT_379);
    (void)zT_382;
    zT_383 = proto.params_count;
    if ((int)(zT_383 > (unsigned short)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_387 = proto.params_start;
    zT_391 = proto.params_count;
    zT_393 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_387) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_391);
    p_payload = zT_393;
    zT_395 = store;
    zT_396 = p_payload;
    zT_397 = zF_3EAD7B21_astStoreGetExtraChi(zT_395, zT_396);
    pnodes = zT_397;
    zT_399 = 0;
    pi = zT_399;
    goto z_bb_74;
    z_bb_73:
    zT_429 = store;
    zT_430 = decl.child_0;
    zT_431 = &stack;
    zT_432 = typereg;
    zT_433 = resolved_types;
    zT_434 = &offset;
    zT_435 = &max_align;
    zF_68BD38B1_scanFrameLocals(zT_429, zT_430, zT_431, zT_432, zT_433, zT_434, zT_435);
    zT_441 = 0;
    hid = zT_441;
    zT_442 = async_hidden_fns;
    zT_443 = key;
    zT_444 = zF_A05A7BE1_u64ToU32MapGet(zT_442, zT_443);
    zT_445 = zT_444.has_value;
    if (zT_445) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    zT_401 = pnodes.len;
    if ((int)(pi < zT_401)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_404 = store;
    zT_406 = pnodes.ptr;
    zT_405 = zT_406[pi];
    zT_408 = zF_FCDD1D35_astStoreNodeAt(zT_404, zT_405);
    pnode = zT_408;
    zT_409 = pnode.child_0;
    if ((int)(zT_409 == (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_428 = pi + (unsigned int)(1);
    pi = zT_428;
    goto z_bb_74;
    z_bb_78:
    goto z_bb_77;
    z_bb_79:
    zT_413 = 18;
    pt = zT_413;
    zT_414 = resolved_types;
    zT_415 = pnode.child_0;
    zT_417 = zF_999DCF51_resolvedTypeTableGe(zT_414, zT_415);
    zT_418 = zT_417.has_value;
    if (zT_418) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    rtp = zT_417.value;
    pt = rtp;
    goto z_bb_81;
    z_bb_81:
    zT_420 = typereg;
    zT_421 = pt;
    zT_422 = &offset;
    zT_423 = &max_align;
    zT_426 = zF_769CB99B_addFrameField(zT_420, zT_421, zT_422, zT_423);
    (void)zT_426;
    goto z_bb_77;
    z_bb_82:
    h = zT_444.value;
    hid = h;
    goto z_bb_83;
    z_bb_83:
    if ((int)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_451 = typereg;
    zT_455 = typereg;
    zT_456 = zF_FF3C4865_asyncPtrVoid(zT_455);
    zT_452 = zT_456;
    zT_453 = &offset;
    zT_454 = &max_align;
    zT_459 = zF_769CB99B_addFrameField(zT_451, zT_452, zT_453, zT_454);
    (void)zT_459;
    goto z_bb_85;
    z_bb_85:
    zT_460 = awaited_fns;
    zT_461 = key;
    zT_462 = zF_A05A7BE1_u64ToU32MapGet(zT_460, zT_461);
    zT_463 = zT_462.has_value;
    if (zT_463) goto z_bb_87; else goto z_bb_86;
    z_bb_86:
    zT_465 = driver_targets;
    zT_466 = key;
    zT_467 = zF_A05A7BE1_u64ToU32MapGet(zT_465, zT_466);
    zT_468 = zT_467.has_value;
    zT_464 = zT_468;
    goto z_bb_88;
    z_bb_87:
    zT_464 = 1;
    goto z_bb_88;
    z_bb_88:
    if (zT_464) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_469 = typereg;
    zT_473 = typereg;
    zT_474 = zF_FF3C4865_asyncPtrVoid(zT_473);
    zT_470 = zT_474;
    zT_471 = &offset;
    zT_472 = &max_align;
    zT_477 = zF_769CB99B_addFrameField(zT_469, zT_470, zT_471, zT_472);
    (void)zT_477;
    goto z_bb_90;
    z_bb_90:
    if ((int)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_483 = 0;
    pstart = zT_483;
    zT_484 = parent_result_start;
    zT_485 = key;
    zT_486 = zF_A05A7BE1_u64ToU32MapGet(zT_484, zT_485);
    zT_487 = zT_486.has_value;
    if (zT_487) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_514 = offset;
    zT_515 = max_align;
    zT_516 = zF_978D7C93_alignUpU32(zT_514, zT_515);
    total = zT_516;
    if ((int)(total == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_93:
    ps = zT_486.value;
    pstart = ps;
    goto z_bb_94;
    z_bb_94:
    zT_490 = 0;
    pcount = zT_490;
    zT_491 = parent_result_count;
    zT_492 = key;
    zT_493 = zF_A05A7BE1_u64ToU32MapGet(zT_491, zT_492);
    zT_494 = zT_493.has_value;
    if (zT_494) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    pc = zT_493.value;
    pcount = pc;
    goto z_bb_96;
    z_bb_96:
    zT_497 = 0;
    pk = zT_497;
    goto z_bb_97;
    z_bb_97:
    if ((int)(pk < pcount)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_500 = parent_result_type_list->items;
    zT_502 = (unsigned int)(unsigned int)(pstart + pk);
    zT_503 = zT_500[zT_502];
    prt = zT_503;
    zT_504 = typereg;
    zT_505 = prt;
    zT_506 = &offset;
    zT_507 = &max_align;
    zT_510 = zF_769CB99B_addFrameField(zT_504, zT_505, zT_506, zT_507);
    (void)zT_510;
    goto z_bb_100;
    z_bb_99:
    goto z_bb_92;
    z_bb_100:
    zT_512 = pk + (unsigned int)(1);
    pk = zT_512;
    goto z_bb_97;
    z_bb_101:
    zT_519 = 1;
    total = zT_519;
    goto z_bb_102;
    z_bb_102:
    zT_520 = total;
    zT_523 = zF_978D7C93_alignUpU32(zT_520, (unsigned int)(8));
    total = zT_523;
    zT_524 = frame_sizes;
    zT_525 = key;
    zT_526 = total;
    zF_B6EB812C_u64ToU32MapPut(zT_524, zT_525, zT_526);
    zT_527 = key;
    zT_528 = total;
    zF_7011AA79_emitFrameMarker(zT_527, zT_528);
    goto z_bb_44;
}

/* __module_init */
void zF_780653D2___module_init_21(void) {
    zT_8143F551_AstKind zT_0 = 0;
    zG_8143F551_AstKind = zT_0;
    return;
}

/* EOF */
