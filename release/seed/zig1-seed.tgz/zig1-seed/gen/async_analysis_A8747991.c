#include "async_analysis_A8747991.h"
/* asyncKey */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int module_id, unsigned int name_id) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
}

/* asyncIsSuspending */
int zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8 = 0;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 v;
    unsigned int val;
    zT_4 = map;
    zT_6 = module_id;
    zT_7 = name_id;
    zT_8 = zF_9D041EB6_asyncKey(zT_6, zT_7);
    zT_5 = zT_8;
    zT_9 = zF_A05A7BE1_u64ToU32MapGet(zT_4, zT_5);
    v = zT_9;
    zT_10 = v.has_value;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    val = v.value;
    return (int)(val != (unsigned int)(0));
    z_bb_2:
    return (int)(0);
}

/* asyncFrameSizeOf */
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    return zT_8;
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand* sand, unsigned int count) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int c;
    unsigned char* raw;
    c = count;
    if ((int)(c == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    c = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = sand;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)(4) * c), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    return (unsigned int*)((unsigned int*)raw);
}

/* resolveCalleeKey */
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int callee_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_3D7259E2_SymbolRegistry* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_D2761632_Opt_856 zT_20 = {0};
    unsigned char zT_21;
    zT_3C598AEF_SymbolKind zT_23;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    zT_BBEE1AC1_Opt_11 zT_33;
    zT_BBEE1AC1_Opt_11 zT_34 = {0};
    zT_8143F551_AstKind zT_35;
    zT_BBEE1AC1_Opt_11 zT_40 = {0};
    zT_99292002_Arr_unsigned_int_16 zT_42;
    int zT_44;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_58 = {0};
    zT_8143F551_AstKind zT_59;
    zT_BBEE1AC1_Opt_11 zT_66 = {0};
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_22A7C88B_AstNode zT_77 = {0};
    zT_8143F551_AstKind zT_78;
    zT_BBEE1AC1_Opt_11 zT_83 = {0};
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_87 = 0;
    zT_3D7259E2_SymbolRegistry* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_D2761632_Opt_856 zT_92 = {0};
    unsigned char zT_93;
    zT_3C598AEF_SymbolKind zT_95;
    zT_BBEE1AC1_Opt_11 zT_100 = {0};
    unsigned int zT_101;
    zT_BBEE1AC1_Opt_11 zT_102 = {0};
    int zT_106;
    unsigned int zT_108;
    zT_3D7259E2_SymbolRegistry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_D2761632_Opt_856 zT_114 = {0};
    unsigned char zT_115;
    zT_3C598AEF_SymbolKind zT_117;
    zT_BBEE1AC1_Opt_11 zT_122 = {0};
    unsigned int zT_123;
    zT_BBEE1AC1_Opt_11 zT_124 = {0};
    zT_3D7259E2_SymbolRegistry* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_128;
    zT_D2761632_Opt_856 zT_130 = {0};
    unsigned char zT_131;
    zT_3C598AEF_SymbolKind zT_133;
    unsigned int zT_138;
    unsigned int zT_139;
    zT_79FAE712_u64 zT_142 = 0;
    zT_BBEE1AC1_Opt_11 zT_143;
    zT_BBEE1AC1_Opt_11 zT_144 = {0};
    zT_22A7C88B_AstNode cn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_99292002_Arr_unsigned_int_16 names;
    unsigned int nlen;
    unsigned int cur;
    zT_22A7C88B_AstNode cw;
    unsigned int base_nid;
    unsigned int cur_mod;
    zT_3A105EF1_Symbol* bs;
    unsigned int i;
    zT_3A105EF1_Symbol* ms;
    zT_3A105EF1_Symbol* fs;
    zT_5 = store;
    zT_6 = callee_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    cn = zT_7;
    zT_8 = cn.kind;
    if ((int)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = store;
    zT_15 = callee_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_14, zT_15);
    nid = zT_16;
    zT_17 = sym_reg;
    zT_18 = module_id;
    zT_19 = nid;
    zT_20 = zF_A398987E_symbolRegistryQuali(zT_17, zT_18, zT_19);
    zT_21 = zT_20.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_35 = cn.kind;
    if ((int)(zT_35 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    s = zT_20.value;
    zT_23 = s->kind;
    if ((int)(zT_23 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_34.has_value = 0;
    return zT_34;
    z_bb_5:
    zT_28 = s->module_id;
    zT_29 = s->name_id;
    zT_32 = zF_9D041EB6_asyncKey(zT_28, zT_29);
    zT_33.has_value = 1;
    zT_33.value = zT_32;
    return zT_33;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_8:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_42[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        names[_i] = zT_42[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    nlen = zT_45;
    zT_46 = store;
    zT_47 = callee_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_46, zT_47);
    zT_49 = (unsigned int)nlen;
    names[zT_49] = zT_48;
    zT_50 = 1;
    zT_52 = nlen + (unsigned int)((unsigned int)zT_50);
    nlen = zT_52;
    zT_54 = cn.child_0;
    cur = zT_54;
    zT_56 = store;
    zT_57 = cur;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cw = zT_58;
    goto z_bb_9;
    z_bb_9:
    zT_59 = cw.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if ((int)(nlen >= (unsigned int)(16))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_78 = cw.kind;
    if ((int)(zT_78 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_14:
    zT_67 = store;
    zT_68 = cur;
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_67, zT_68);
    zT_70 = (unsigned int)nlen;
    names[zT_70] = zT_69;
    zT_71 = 1;
    zT_73 = nlen + (unsigned int)((unsigned int)zT_71);
    nlen = zT_73;
    zT_74 = cw.child_0;
    cur = zT_74;
    zT_75 = store;
    zT_76 = cur;
    zT_77 = zF_FCDD1D35_astStoreNodeAt(zT_75, zT_76);
    cw = zT_77;
    goto z_bb_12;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
    z_bb_16:
    zT_85 = store;
    zT_86 = cur;
    zT_87 = zF_53458827_astStoreIdentifier(zT_85, zT_86);
    base_nid = zT_87;
    cur_mod = module_id;
    zT_89 = sym_reg;
    zT_90 = module_id;
    zT_91 = base_nid;
    zT_92 = zF_A398987E_symbolRegistryQuali(zT_89, zT_90, zT_91);
    zT_93 = zT_92.has_value;
    if (zT_93) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    bs = zT_92.value;
    zT_95 = bs->kind;
    if ((int)(zT_95 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    i = nlen;
    goto z_bb_22;
    z_bb_19:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_20:
    zT_100.has_value = 0;
    return zT_100;
    z_bb_21:
    zT_101 = bs->module_id;
    cur_mod = zT_101;
    goto z_bb_18;
    z_bb_22:
    if ((int)(i > (unsigned int)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_106 = 1;
    zT_108 = i - (unsigned int)((unsigned int)zT_106);
    i = zT_108;
    zT_109 = sym_reg;
    zT_110 = cur_mod;
    zT_112 = (unsigned int)i;
    zT_111 = names[zT_112];
    zT_114 = zF_A398987E_symbolRegistryQuali(zT_109, zT_110, zT_111);
    zT_115 = zT_114.has_value;
    if (zT_115) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_125 = sym_reg;
    zT_126 = cur_mod;
    zT_128 = 0;
    zT_127 = names[zT_128];
    zT_130 = zF_A398987E_symbolRegistryQuali(zT_125, zT_126, zT_127);
    zT_131 = zT_130.has_value;
    if (zT_131) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    ms = zT_114.value;
    zT_117 = ms->kind;
    if ((int)(zT_117 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_124.has_value = 0;
    return zT_124;
    z_bb_29:
    zT_122.has_value = 0;
    return zT_122;
    z_bb_30:
    zT_123 = ms->module_id;
    cur_mod = zT_123;
    goto z_bb_27;
    z_bb_31:
    fs = zT_130.value;
    zT_133 = fs->kind;
    if ((int)(zT_133 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_144.has_value = 0;
    return zT_144;
    z_bb_33:
    zT_138 = fs->module_id;
    zT_139 = fs->name_id;
    zT_142 = zF_9D041EB6_asyncKey(zT_138, zT_139);
    zT_143.has_value = 1;
    zT_143.value = zT_142;
    return zT_143;
    z_bb_34:
    goto z_bb_32;
}

/* scanFunction */
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int caller_idx, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_B687BB96_U32ArrayList* edge_caller, zT_B687BB96_U32ArrayList* edge_callee, zT_47B162D1_U8ArrayList* direct, zT_A4CE86B7_U64ToU32Map* fn_index, unsigned int async_suspend_name_id) {
    zT_B687BB96_U32ArrayList* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_41;
    zT_3D7259E2_SymbolRegistry* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_BBEE1AC1_Opt_11 zT_46 = {0};
    unsigned char zT_47;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    zT_BAEE192E_Opt_10 zT_51 = {0};
    unsigned char zT_52;
    zT_B687BB96_U32ArrayList* zT_54;
    unsigned int zT_55;
    zT_B687BB96_U32ArrayList* zT_56;
    unsigned int zT_57;
    zT_B687BB96_U32ArrayList* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    unsigned int zT_66;
    zT_B687BB96_U32ArrayList* zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    int zT_76;
    unsigned int zT_77;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    zT_6B0A7D14_AstStore* zT_88;
    unsigned int zT_89;
    unsigned int zT_90 = 0;
    unsigned int zT_92;
    zT_B687BB96_U32ArrayList* zT_95;
    unsigned int zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_98;
    unsigned int zT_101 = 0;
    int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    int zT_107;
    zT_8143F551_AstKind zT_108;
    int zT_111 = 0;
    zT_B687BB96_U32ArrayList* zT_112;
    unsigned int zT_113;
    unsigned int zT_115;
    int zT_118;
    zT_8143F551_AstKind zT_119;
    int zT_122 = 0;
    zT_B687BB96_U32ArrayList* zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    int zT_129;
    zT_8143F551_AstKind zT_130;
    int zT_133 = 0;
    zT_B687BB96_U32ArrayList* zT_134;
    unsigned int zT_135;
    zT_8143F551_AstKind zT_137;
    int zT_138 = 0;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_144;
    zT_B687BB96_U32ArrayList* zT_147;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int zT_153 = 0;
    int zT_154;
    unsigned int zT_155;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int gi;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = stack;
    zT_15 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_14, zT_15);
    goto z_bb_3;
    z_bb_3:
    zT_16 = stack->len;
    if ((int)(zT_16 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = stack->items;
    zT_21 = stack->len;
    zT_22 = 1;
    zT_23 = zT_21 - zT_22;
    zT_24 = zT_20[zT_23];
    ni = zT_24;
    zT_25 = stack->len;
    stack->len = (unsigned int)(zT_25 - (unsigned int)(1));
    zT_29 = store;
    zT_30 = ni;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    n = zT_31;
    zT_33 = n.kind;
    k = zT_33;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_38 = n.child_0;
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_19; else goto z_bb_20;
    z_bb_9:
    zT_41 = store;
    zT_42 = sym_reg;
    zT_43 = module_id;
    zT_44 = n.child_0;
    zT_46 = zF_860C82EC_resolveCalleeKey(zT_41, zT_42, zT_43, zT_44);
    zT_47 = zT_46.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_62 = store;
    zT_63 = ni;
    zT_64 = zF_152E19CB_astStoreNodeExtraCh(zT_62, zT_63);
    ec_n = zT_64;
    zT_66 = 0;
    ei = zT_66;
    goto z_bb_15;
    z_bb_11:
    ck = zT_46.value;
    zT_49 = fn_index;
    zT_50 = ck;
    zT_51 = zF_A05A7BE1_u64ToU32MapGet(zT_49, zT_50);
    zT_52 = zT_51.has_value;
    if (zT_52) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_58 = stack;
    zT_59 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_58, zT_59);
    goto z_bb_10;
    z_bb_13:
    gi = zT_51.value;
    zT_54 = edge_caller;
    zT_55 = caller_idx;
    zF_62F717A2_u32ArrayListAppend(zT_54, zT_55);
    zT_56 = edge_callee;
    zT_57 = gi;
    zF_62F717A2_u32ArrayListAppend(zT_56, zT_57);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((int)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_69 = stack;
    zT_71 = store;
    zT_72 = ni;
    zT_75 = zF_B10B1BC1_astStoreNodeExtraCh(zT_71, zT_72, (unsigned int)((unsigned int)ei));
    zT_70 = zT_75;
    zF_62F717A2_u32ArrayListAppend(zT_69, zT_70);
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_76 = 1;
    zT_77 = ei + zT_76;
    ei = zT_77;
    goto z_bb_15;
    z_bb_19:
    zT_82 = n.child_0;
    if ((int)(zT_82 == async_suspend_name_id)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_104 = n.child_0;
    if ((int)(zT_104 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    zT_84 = 1;
    zT_85 = direct->items;
    zT_86 = (unsigned int)caller_idx;
    zT_85[zT_86] = zT_84;
    goto z_bb_22;
    z_bb_22:
    zT_88 = store;
    zT_89 = ni;
    zT_90 = zF_152E19CB_astStoreNodeExtraCh(zT_88, zT_89);
    ec2_n = zT_90;
    zT_92 = 0;
    ei2 = zT_92;
    goto z_bb_23;
    z_bb_23:
    if ((int)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_95 = stack;
    zT_97 = store;
    zT_98 = ni;
    zT_101 = zF_B10B1BC1_astStoreNodeExtraCh(zT_97, zT_98, (unsigned int)((unsigned int)ei2));
    zT_96 = zT_101;
    zF_62F717A2_u32ArrayListAppend(zT_95, zT_96);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_102 = 1;
    zT_103 = ei2 + zT_102;
    ei2 = zT_103;
    goto z_bb_23;
    z_bb_27:
    zT_108 = k;
    zT_111 = zF_C395F6FD_nodeChildIsNode(zT_108, (unsigned char)(0));
    zT_107 = zT_111;
    goto z_bb_29;
    z_bb_28:
    zT_107 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_107) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_112 = stack;
    zT_113 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_112, zT_113);
    goto z_bb_31;
    z_bb_31:
    zT_115 = n.child_1;
    if ((int)(zT_115 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_119 = k;
    zT_122 = zF_C395F6FD_nodeChildIsNode(zT_119, (unsigned char)(1));
    zT_118 = zT_122;
    goto z_bb_34;
    z_bb_33:
    zT_118 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_118) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_123 = stack;
    zT_124 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_123, zT_124);
    goto z_bb_36;
    z_bb_36:
    zT_126 = n.child_2;
    if ((int)(zT_126 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_130 = k;
    zT_133 = zF_C395F6FD_nodeChildIsNode(zT_130, (unsigned char)(2));
    zT_129 = zT_133;
    goto z_bb_39;
    z_bb_38:
    zT_129 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_129) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_134 = stack;
    zT_135 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_134, zT_135);
    goto z_bb_41;
    z_bb_41:
    zT_137 = k;
    zT_138 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_137);
    if (zT_138) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_140 = store;
    zT_141 = ni;
    zT_142 = zF_152E19CB_astStoreNodeExtraCh(zT_140, zT_141);
    ec3_n = zT_142;
    zT_144 = 0;
    ei3 = zT_144;
    goto z_bb_44;
    z_bb_43:
    goto z_bb_6;
    z_bb_44:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_147 = stack;
    zT_149 = store;
    zT_150 = ni;
    zT_153 = zF_B10B1BC1_astStoreNodeExtraCh(zT_149, zT_150, (unsigned int)((unsigned int)ei3));
    zT_148 = zT_153;
    zF_62F717A2_u32ArrayListAppend(zT_147, zT_148);
    goto z_bb_47;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_154 = 1;
    zT_155 = ei3 + zT_154;
    ei3 = zT_155;
    goto z_bb_44;
}

/* emitSuspMarker */
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64 key) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_5826BFC7_Arr_unsigned_char_1 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_5826BFC7_Arr_unsigned_char_1 zT_44;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54 = 0;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_4 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_4;
    zT_8 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_8;
    zT_10 = "SUSP:m";
    zT_12 = 6;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    m1 = zT_11;
    zT_13 = m1;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = module_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)b1) + zT_21;
    zT_23 = (unsigned int)(12) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    l1 = zT_25;
    zT_30 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_36 = (unsigned int)(11) - s1;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = ":n";
    zT_41 = 2;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    m2 = zT_40;
    zT_42 = m2;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = name_id;
    zT_50 = 0;
    zT_51 = (unsigned char*)((unsigned char*)b2) + zT_50;
    zT_52 = (unsigned int)(12) - zT_50;
    zT_53.ptr = zT_51;
    zT_53.len = zT_52;
    zT_47 = zT_53;
    zT_54 = zF_A7504564_itoa(zT_46, zT_47);
    l2 = zT_54;
    zT_59 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_59;
    zT_64 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_65 = (unsigned int)(11) - s2;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_60 = zT_66;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_68 = "\n";
    zT_70 = 1;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    m3 = zT_69;
    zT_71 = m3;
    zF_48AC7B3A_markerWrite(zT_71);
    return;
}

/* suspensionAnalysisRun */
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_072B53A6_ModuleRegistry* module_reg, zT_D3EB6303_StringInterner* interner, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_C4A0A7DB_U64ArrayList zT_26 = {0};
    zT_3E40CD83_Sand* zT_28;
    zT_47B162D1_U8ArrayList zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_B687BB96_U32ArrayList zT_32 = {0};
    zT_3E40CD83_Sand* zT_34;
    zT_B687BB96_U32ArrayList zT_35 = {0};
    zT_072B53A6_ModuleRegistry* zT_37;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_53 = {0};
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_64;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_22A7C88B_AstNode zT_76 = {0};
    zT_8143F551_AstKind zT_77;
    zT_6B0A7D14_AstStore* zT_83;
    unsigned int zT_84;
    unsigned int zT_85 = 0;
    zT_98B93138_anon_226730 zT_87;
    zT_243D6A41_FnProto* zT_88;
    unsigned int zT_89;
    zT_243D6A41_FnProto zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_94;
    zT_6E8D187B_ModuleEntry zT_95;
    zT_79FAE712_u64 zT_98 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_99;
    zT_79FAE712_u64 zT_100;
    zT_BAEE192E_Opt_10 zT_102 = {0};
    unsigned char zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_109;
    zT_C4A0A7DB_U64ArrayList* zT_111;
    zT_79FAE712_u64 zT_112;
    zT_47B162D1_U8ArrayList* zT_114;
    int zT_118;
    unsigned int zT_119;
    int zT_120;
    unsigned int zT_121;
    zT_3E40CD83_Sand* zT_123;
    zT_B687BB96_U32ArrayList zT_124 = {0};
    unsigned int zT_125;
    unsigned int zT_127;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_132;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    zT_22A7C88B_AstNode zT_138 = {0};
    zT_8143F551_AstKind zT_139;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int zT_147 = 0;
    unsigned int zT_149;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    unsigned int zT_157 = 0;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    zT_22A7C88B_AstNode zT_161 = {0};
    zT_8143F551_AstKind zT_162;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    unsigned int zT_170 = 0;
    zT_98B93138_anon_226730 zT_172;
    zT_243D6A41_FnProto* zT_173;
    unsigned int zT_174;
    zT_243D6A41_FnProto zT_175;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_6E8D187B_ModuleEntry* zT_179;
    zT_6E8D187B_ModuleEntry zT_180;
    zT_79FAE712_u64 zT_183 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_185;
    zT_79FAE712_u64 zT_186;
    zT_BAEE192E_Opt_10 zT_188 = {0};
    unsigned char zT_189;
    zT_6B0A7D14_AstStore* zT_191;
    zT_3D7259E2_SymbolRegistry* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_B687BB96_U32ArrayList* zT_196;
    zT_B687BB96_U32ArrayList* zT_197;
    zT_B687BB96_U32ArrayList* zT_198;
    zT_47B162D1_U8ArrayList* zT_199;
    zT_A4CE86B7_U64ToU32Map* zT_200;
    unsigned int zT_201;
    zT_6E8D187B_ModuleEntry* zT_202;
    zT_6E8D187B_ModuleEntry zT_203;
    int zT_211;
    unsigned int zT_212;
    int zT_213;
    unsigned int zT_214;
    unsigned int zT_216;
    zT_3E40CD83_Sand* zT_220;
    unsigned int zT_221;
    unsigned int* zT_222 = 0;
    unsigned int zT_224;
    unsigned int zT_226;
    int zT_227;
    unsigned int zT_228;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int* zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_239;
    unsigned int zT_240;
    int zT_241;
    unsigned int zT_242;
    zT_3E40CD83_Sand* zT_244;
    unsigned int* zT_248 = 0;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_253;
    unsigned int zT_254;
    int zT_255;
    unsigned int zT_256;
    zT_3E40CD83_Sand* zT_258;
    unsigned int zT_259;
    unsigned int* zT_260 = 0;
    unsigned int zT_261;
    unsigned int zT_263;
    int zT_264;
    unsigned int zT_265;
    zT_3E40CD83_Sand* zT_267;
    unsigned int zT_268;
    unsigned int* zT_270 = 0;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int* zT_275;
    unsigned int zT_276;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned int* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int zT_284;
    unsigned int zT_285;
    int zT_286;
    unsigned int zT_287;
    zT_3E40CD83_Sand* zT_289;
    unsigned int zT_290;
    unsigned int* zT_291 = 0;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned char* zT_298;
    unsigned char zT_299;
    zT_A4CE86B7_U64ToU32Map* zT_302;
    zT_79FAE712_u64 zT_303;
    zT_79FAE712_u64* zT_305;
    unsigned int zT_308;
    unsigned int zT_310;
    int zT_311;
    unsigned int zT_312;
    unsigned int zT_315;
    unsigned int zT_317;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned int zT_329;
    unsigned int zT_330;
    zT_79FAE712_u64* zT_332;
    unsigned int zT_333;
    zT_79FAE712_u64 zT_334;
    zT_A4CE86B7_U64ToU32Map* zT_335;
    zT_79FAE712_u64 zT_336;
    zT_BAEE192E_Opt_10 zT_337 = {0};
    unsigned char zT_338;
    zT_A4CE86B7_U64ToU32Map* zT_340;
    zT_79FAE712_u64 zT_341;
    unsigned int zT_345;
    unsigned int zT_347;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_79FAE712_u64* zT_353;
    zT_79FAE712_u64 zT_354;
    zT_A4CE86B7_U64ToU32Map* zT_356;
    zT_79FAE712_u64 zT_357;
    zT_BAEE192E_Opt_10 zT_358 = {0};
    unsigned char zT_359;
    zT_79FAE712_u64 zT_363;
    int zT_364;
    unsigned int zT_365;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_A4CE86B7_U64ToU32Map fn_index;
    zT_C4A0A7DB_U64ArrayList fn_keys;
    zT_47B162D1_U8ArrayList direct;
    zT_B687BB96_U32ArrayList edge_caller;
    zT_B687BB96_U32ArrayList edge_callee;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_B687BB96_U32ArrayList stack;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned int ast_root2;
    unsigned int n;
    zT_22A7C88B_AstNode root2;
    unsigned int decls2_n;
    unsigned int di2;
    unsigned int decl2_idx;
    zT_22A7C88B_AstNode decl2;
    unsigned int proto_idx2;
    zT_243D6A41_FnProto proto2;
    zT_79FAE712_u64 key2;
    zT_BAEE192E_Opt_10 cidx;
    unsigned int ci0;
    unsigned int* rev_count;
    unsigned int i;
    unsigned int m;
    unsigned int e;
    unsigned int g;
    unsigned int* rev_off;
    unsigned int acc;
    unsigned int* rev_pos;
    unsigned int* rev_to;
    unsigned int g2;
    unsigned int p;
    unsigned int* queue;
    unsigned int head;
    unsigned int tail;
    unsigned int g3;
    unsigned int k0;
    unsigned int k1;
    unsigned int kk;
    unsigned int c;
    zT_79FAE712_u64 ckey;
    zT_79FAE712_u64 kk2;
    zT_BAEE192E_Opt_10 vv;
    unsigned int val2;
    zT_7 = "YA\n";
    zT_9 = 3;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    p_msg = zT_8;
    zT_10 = p_msg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = "@asyncSuspend";
    zT_14 = 13;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    asu_text = zT_13;
    zT_16 = interner;
    zT_17 = asu_text;
    zT_18 = zF_50C274AF_stringInternerInter(zT_16, zT_17);
    async_suspend_name_id = zT_18;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    fn_index = zT_21;
    zT_23 = alloc;
    zT_26 = zF_477F0605_u64ArrayListInit(zT_23, (unsigned int)(256));
    fn_keys = zT_26;
    zT_28 = alloc;
    zT_29 = zF_E9FF0E66_byteArrayListInit(zT_28);
    direct = zT_29;
    zT_31 = alloc;
    zT_32 = zF_8E537D0C_u32ArrayListInit(zT_31);
    edge_caller = zT_32;
    zT_34 = alloc;
    zT_35 = zF_8E537D0C_u32ArrayListInit(zT_34);
    edge_callee = zT_35;
    zT_37 = module_reg;
    zT_38 = zF_3452C137_moduleRegistryGetMo(zT_37);
    mods = zT_38;
    zT_40 = 0;
    mi = zT_40;
    goto z_bb_1;
    z_bb_1:
    zT_42 = mods.len;
    if ((int)(mi < zT_42)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_45 = mods.ptr;
    zT_46 = zT_45[mi];
    zT_47 = zT_46.ast_root;
    ast_root = zT_47;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_123 = alloc;
    zT_124 = zF_8E537D0C_u32ArrayListInit(zT_123);
    stack = zT_124;
    zT_125 = 0;
    mi = zT_125;
    goto z_bb_17;
    z_bb_4:
    zT_120 = 1;
    zT_121 = mi + zT_120;
    mi = zT_121;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_51 = store;
    zT_52 = ast_root;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    root = zT_53;
    zT_54 = root.kind;
    if ((int)(zT_54 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_60 = store;
    zT_61 = ast_root;
    zT_62 = zF_152E19CB_astStoreNodeExtraCh(zT_60, zT_61);
    decls_n = zT_62;
    zT_64 = 0;
    di = zT_64;
    goto z_bb_9;
    z_bb_9:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_68 = store;
    zT_69 = ast_root;
    zT_72 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)di));
    decl_idx = zT_72;
    zT_74 = store;
    zT_75 = decl_idx;
    zT_76 = zF_FCDD1D35_astStoreNodeAt(zT_74, zT_75);
    decl = zT_76;
    zT_77 = decl.kind;
    if ((int)(zT_77 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_118 = 1;
    zT_119 = di + zT_118;
    di = zT_119;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_83 = store;
    zT_84 = decl_idx;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_83, zT_84);
    proto_idx = zT_85;
    zT_87 = store->fn_protos;
    zT_88 = zT_87.items;
    zT_89 = (unsigned int)proto_idx;
    zT_90 = zT_88[zT_89];
    proto = zT_90;
    zT_94 = mods.ptr;
    zT_95 = zT_94[mi];
    zT_92 = zT_95.id;
    zT_93 = proto.name_id;
    zT_98 = zF_9D041EB6_asyncKey(zT_92, zT_93);
    key = zT_98;
    zT_99 = &fn_index;
    zT_100 = key;
    zT_102 = zF_A05A7BE1_u64ToU32MapGet(zT_99, zT_100);
    zT_103 = zT_102.has_value;
    if ((int)(!zT_103)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_105 = &fn_index;
    zT_106 = key;
    zT_109 = fn_keys.len;
    zF_B6EB812C_u64ToU32MapPut(zT_105, zT_106, (unsigned int)((unsigned int)zT_109));
    zT_111 = &fn_keys;
    zT_112 = key;
    zF_A553AD3B_u64ArrayListAppend(zT_111, zT_112);
    zT_114 = &direct;
    zF_463FE7A4_byteArrayListAppend(zT_114, (unsigned char)(0));
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    zT_127 = mods.len;
    if ((int)(mi < zT_127)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_130 = mods.ptr;
    zT_131 = zT_130[mi];
    zT_132 = zT_131.ast_root;
    ast_root2 = zT_132;
    if ((int)(ast_root2 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_216 = fn_keys.len;
    n = zT_216;
    if ((int)(n > (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_20:
    zT_213 = 1;
    zT_214 = mi + zT_213;
    mi = zT_214;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_136 = store;
    zT_137 = ast_root2;
    zT_138 = zF_FCDD1D35_astStoreNodeAt(zT_136, zT_137);
    root2 = zT_138;
    zT_139 = root2.kind;
    if ((int)(zT_139 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_145 = store;
    zT_146 = ast_root2;
    zT_147 = zF_152E19CB_astStoreNodeExtraCh(zT_145, zT_146);
    decls2_n = zT_147;
    zT_149 = 0;
    di2 = zT_149;
    goto z_bb_25;
    z_bb_25:
    if ((int)(di2 < (unsigned int)((unsigned int)decls2_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_153 = store;
    zT_154 = ast_root2;
    zT_157 = zF_B10B1BC1_astStoreNodeExtraCh(zT_153, zT_154, (unsigned int)((unsigned int)di2));
    decl2_idx = zT_157;
    zT_159 = store;
    zT_160 = decl2_idx;
    zT_161 = zF_FCDD1D35_astStoreNodeAt(zT_159, zT_160);
    decl2 = zT_161;
    zT_162 = decl2.kind;
    if ((int)(zT_162 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_211 = 1;
    zT_212 = di2 + zT_211;
    di2 = zT_212;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_168 = store;
    zT_169 = decl2_idx;
    zT_170 = zF_8BA26B9E_astStoreNodePayload(zT_168, zT_169);
    proto_idx2 = zT_170;
    zT_172 = store->fn_protos;
    zT_173 = zT_172.items;
    zT_174 = (unsigned int)proto_idx2;
    zT_175 = zT_173[zT_174];
    proto2 = zT_175;
    zT_179 = mods.ptr;
    zT_180 = zT_179[mi];
    zT_177 = zT_180.id;
    zT_178 = proto2.name_id;
    zT_183 = zF_9D041EB6_asyncKey(zT_177, zT_178);
    key2 = zT_183;
    zT_185 = &fn_index;
    zT_186 = key2;
    zT_188 = zF_A05A7BE1_u64ToU32MapGet(zT_185, zT_186);
    cidx = zT_188;
    zT_189 = cidx.has_value;
    if (zT_189) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    ci0 = cidx.value;
    zT_191 = store;
    zT_192 = sym_reg;
    zT_202 = mods.ptr;
    zT_203 = zT_202[mi];
    zT_193 = zT_203.id;
    zT_194 = ci0;
    zT_195 = decl2.child_0;
    zT_196 = &stack;
    zT_197 = &edge_caller;
    zT_198 = &edge_callee;
    zT_199 = &direct;
    zT_200 = &fn_index;
    zT_201 = async_suspend_name_id;
    zF_32651930_scanFunction(zT_191, zT_192, zT_193, zT_194, zT_195, zT_196, zT_197, zT_198, zT_199, zT_200, zT_201);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_220 = alloc;
    zT_221 = n;
    zT_222 = zF_43BEEDA4_allocU32(zT_220, zT_221);
    rev_count = zT_222;
    zT_224 = 0;
    i = zT_224;
    goto z_bb_35;
    z_bb_34:
    zT_349 = 0;
    m = zT_349;
    goto z_bb_71;
    z_bb_35:
    if ((int)(i < n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_226 = 0;
    rev_count[i] = zT_226;
    goto z_bb_38;
    z_bb_37:
    zT_230 = 0;
    e = zT_230;
    goto z_bb_39;
    z_bb_38:
    zT_227 = 1;
    zT_228 = i + zT_227;
    i = zT_228;
    goto z_bb_35;
    z_bb_39:
    zT_231 = edge_callee.len;
    if ((int)(e < zT_231)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_234 = edge_callee.items;
    zT_235 = zT_234[e];
    g = zT_235;
    zT_236 = (unsigned int)g;
    zT_237 = rev_count[zT_236];
    zT_239 = zT_237 + (unsigned int)(1);
    zT_240 = (unsigned int)g;
    rev_count[zT_240] = zT_239;
    goto z_bb_42;
    z_bb_41:
    zT_244 = alloc;
    zT_248 = zF_43BEEDA4_allocU32(zT_244, (unsigned int)(n + (unsigned int)(1)));
    rev_off = zT_248;
    zT_250 = 0;
    acc = zT_250;
    zT_251 = 0;
    i = zT_251;
    goto z_bb_43;
    z_bb_42:
    zT_241 = 1;
    zT_242 = e + zT_241;
    e = zT_242;
    goto z_bb_39;
    z_bb_43:
    if ((int)(i < n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    rev_off[i] = acc;
    zT_253 = rev_count[i];
    zT_254 = acc + zT_253;
    acc = zT_254;
    goto z_bb_46;
    z_bb_45:
    rev_off[n] = acc;
    zT_258 = alloc;
    zT_259 = n;
    zT_260 = zF_43BEEDA4_allocU32(zT_258, zT_259);
    rev_pos = zT_260;
    zT_261 = 0;
    i = zT_261;
    goto z_bb_47;
    z_bb_46:
    zT_255 = 1;
    zT_256 = i + zT_255;
    i = zT_256;
    goto z_bb_43;
    z_bb_47:
    if ((int)(i < n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_263 = rev_off[i];
    rev_pos[i] = zT_263;
    goto z_bb_50;
    z_bb_49:
    zT_267 = alloc;
    zT_268 = edge_callee.len;
    zT_270 = zF_43BEEDA4_allocU32(zT_267, zT_268);
    rev_to = zT_270;
    zT_271 = 0;
    e = zT_271;
    goto z_bb_51;
    z_bb_50:
    zT_264 = 1;
    zT_265 = i + zT_264;
    i = zT_265;
    goto z_bb_47;
    z_bb_51:
    zT_272 = edge_callee.len;
    if ((int)(e < zT_272)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_275 = edge_callee.items;
    zT_276 = zT_275[e];
    g2 = zT_276;
    zT_278 = (unsigned int)g2;
    zT_279 = rev_pos[zT_278];
    p = zT_279;
    zT_280 = edge_caller.items;
    zT_281 = zT_280[e];
    zT_282 = (unsigned int)p;
    rev_to[zT_282] = zT_281;
    zT_284 = p + (unsigned int)(1);
    zT_285 = (unsigned int)g2;
    rev_pos[zT_285] = zT_284;
    goto z_bb_54;
    z_bb_53:
    zT_289 = alloc;
    zT_290 = n;
    zT_291 = zF_43BEEDA4_allocU32(zT_289, zT_290);
    queue = zT_291;
    zT_293 = 0;
    head = zT_293;
    zT_295 = 0;
    tail = zT_295;
    zT_296 = 0;
    i = zT_296;
    goto z_bb_55;
    z_bb_54:
    zT_286 = 1;
    zT_287 = e + zT_286;
    e = zT_287;
    goto z_bb_51;
    z_bb_55:
    if ((int)(i < n)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_298 = direct.items;
    zT_299 = zT_298[i];
    if ((int)(zT_299 != (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    goto z_bb_61;
    z_bb_58:
    zT_311 = 1;
    zT_312 = i + zT_311;
    i = zT_312;
    goto z_bb_55;
    z_bb_59:
    zT_302 = suspending_fns;
    zT_305 = fn_keys.items;
    zT_303 = zT_305[i];
    zF_B6EB812C_u64ToU32MapPut(zT_302, zT_303, (unsigned int)(1));
    zT_308 = (unsigned int)i;
    queue[tail] = zT_308;
    zT_310 = tail + (unsigned int)(1);
    tail = zT_310;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    if ((int)(head < tail)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_315 = queue[head];
    g3 = zT_315;
    zT_317 = head + (unsigned int)(1);
    head = zT_317;
    zT_319 = (unsigned int)g3;
    zT_320 = rev_off[zT_319];
    k0 = zT_320;
    zT_324 = (unsigned int)((unsigned int)g3) + (unsigned int)(1);
    zT_325 = rev_off[zT_324];
    k1 = zT_325;
    kk = k0;
    goto z_bb_65;
    z_bb_63:
    goto z_bb_34;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    if ((int)(kk < k1)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_329 = (unsigned int)kk;
    zT_330 = rev_to[zT_329];
    c = zT_330;
    zT_332 = fn_keys.items;
    zT_333 = (unsigned int)c;
    zT_334 = zT_332[zT_333];
    ckey = zT_334;
    zT_335 = suspending_fns;
    zT_336 = ckey;
    zT_337 = zF_A05A7BE1_u64ToU32MapGet(zT_335, zT_336);
    zT_338 = zT_337.has_value;
    if ((int)(!zT_338)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_347 = kk + (unsigned int)(1);
    kk = zT_347;
    goto z_bb_65;
    z_bb_69:
    zT_340 = suspending_fns;
    zT_341 = ckey;
    zF_B6EB812C_u64ToU32MapPut(zT_340, zT_341, (unsigned int)(1));
    queue[tail] = c;
    zT_345 = tail + (unsigned int)(1);
    tail = zT_345;
    goto z_bb_70;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_350 = fn_keys.len;
    if ((int)(m < zT_350)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_353 = fn_keys.items;
    zT_354 = zT_353[m];
    kk2 = zT_354;
    zT_356 = suspending_fns;
    zT_357 = kk2;
    zT_358 = zF_A05A7BE1_u64ToU32MapGet(zT_356, zT_357);
    vv = zT_358;
    zT_359 = vv.has_value;
    if (zT_359) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return;
    z_bb_74:
    zT_364 = 1;
    zT_365 = m + zT_364;
    m = zT_365;
    goto z_bb_71;
    z_bb_75:
    val2 = vv.value;
    if ((int)(val2 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_363 = kk2;
    zF_76D5E8D3_emitSuspMarker(zT_363);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* frameFieldSizeAlign */
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    zT_19 = t.alignment;
    if ((int)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_22 = t.alignment;
    al = zT_22;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* addFrameField */
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    unsigned int at;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_8 = reg;
    zT_9 = tid;
    zT_10 = &sz;
    zT_11 = &al;
    zF_816D1610_frameFieldSizeAlign(zT_8, zT_9, zT_10, zT_11);
    zT_14 = *offset;
    zT_15 = al;
    zT_17 = zF_978D7C93_alignUpU32(zT_14, zT_15);
    *offset = zT_17;
    zT_19 = *offset;
    at = zT_19;
    zT_20 = *offset;
    *offset = (unsigned int)(zT_20 + sz);
    zT_22 = *max_align;
    if ((int)(al > zT_22)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = al;
    goto z_bb_2;
    z_bb_2:
    return at;
}

/* typeIsPtrVoid */
int zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_112BF819_PtrPayload zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_17 = reg->ptr_items;
    zT_18 = t.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.base;
    base = zT_21;
    return (int)(base == (unsigned int)(1));
}

/* frameLocalTypeId */
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable* resolved_types, zT_22A7C88B_AstNode n) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned int t;
    zT_2 = n.child_0;
    if ((int)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_5 = resolved_types;
    zT_6 = n.child_0;
    zT_8 = zF_999DCF51_resolvedTypeTableGe(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    return (unsigned int)(18);
    z_bb_3:
    zT_11 = n.child_1;
    if ((int)(zT_11 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    t = zT_8.value;
    return t;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_14 = resolved_types;
    zT_15 = n.child_1;
    zT_17 = zF_999DCF51_resolvedTypeTableGe(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_2;
    z_bb_8:
    t = zT_17.value;
    return t;
    z_bb_9:
    goto z_bb_7;
}

/* scanFrameLocals */
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore* store, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_338B7C76_TypeRegistry* reg, zT_8EED1867_ResolvedTypeTable* resolved_types, unsigned int* offset, unsigned int* max_align) {
    zT_B687BB96_U32ArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_29;
    unsigned int zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_34 = {0};
    unsigned char zT_35;
    int zT_39;
    zT_8EED1867_ResolvedTypeTable* zT_44;
    zT_22A7C88B_AstNode zT_45;
    unsigned int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_47;
    unsigned int zT_48;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned int zT_51 = 0;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned int zT_61;
    unsigned int zT_65;
    zT_B687BB96_U32ArrayList* zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_80 = 0;
    unsigned int zT_82;
    unsigned int zT_86;
    zT_B687BB96_U32ArrayList* zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int zT_93 = 0;
    unsigned int zT_94;
    zT_B687BB96_U32ArrayList* zT_97;
    unsigned int zT_98;
    zT_8143F551_AstKind zT_100;
    int zT_101 = 0;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_107;
    unsigned int zT_111;
    zT_B687BB96_U32ArrayList* zT_112;
    unsigned int zT_113;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int zT_118 = 0;
    unsigned int zT_119;
    int zT_122;
    zT_8143F551_AstKind zT_123;
    int zT_126 = 0;
    zT_B687BB96_U32ArrayList* zT_127;
    unsigned int zT_128;
    unsigned int zT_130;
    int zT_133;
    zT_8143F551_AstKind zT_134;
    int zT_137 = 0;
    zT_B687BB96_U32ArrayList* zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    int zT_144;
    zT_8143F551_AstKind zT_145;
    int zT_148 = 0;
    zT_B687BB96_U32ArrayList* zT_149;
    unsigned int zT_150;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int lvt;
    unsigned int t;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = stack;
    zT_11 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_10, zT_11);
    goto z_bb_3;
    z_bb_3:
    zT_12 = stack->len;
    if ((int)(zT_12 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = stack->items;
    zT_17 = stack->len;
    zT_19 = zT_17 - (unsigned int)(1);
    zT_20 = zT_16[zT_19];
    ni = zT_20;
    zT_21 = stack->len;
    stack->len = (unsigned int)(zT_21 - (unsigned int)(1));
    zT_25 = store;
    zT_26 = ni;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    n = zT_27;
    zT_29 = n.kind;
    k = zT_29;
    zT_31 = 18;
    lvt = zT_31;
    zT_32 = resolved_types;
    zT_33 = ni;
    zT_34 = zF_999DCF51_resolvedTypeTableGe(zT_32, zT_33);
    zT_35 = zT_34.has_value;
    if (zT_35) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    t = zT_34.value;
    lvt = t;
    goto z_bb_8;
    z_bb_8:
    if ((int)(lvt == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_11;
    z_bb_10:
    zT_39 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_44 = resolved_types;
    zT_45 = n;
    zT_46 = zF_436F92E0_frameLocalTypeId(zT_44, zT_45);
    lvt = zT_46;
    goto z_bb_13;
    z_bb_13:
    zT_47 = reg;
    zT_48 = lvt;
    zT_49 = offset;
    zT_50 = max_align;
    zT_51 = zF_769CB99B_addFrameField(zT_47, zT_48, zT_49, zT_50);
    (void)zT_51;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = store;
    zT_58 = ni;
    zT_59 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    ecb_n = zT_59;
    zT_61 = (unsigned int)ecb_n;
    bi = zT_61;
    goto z_bb_16;
    z_bb_15:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_20; else goto z_bb_21;
    z_bb_16:
    if ((int)(bi > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_65 = bi - (unsigned int)(1);
    bi = zT_65;
    zT_66 = stack;
    zT_68 = store;
    zT_69 = ni;
    zT_72 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)bi));
    zT_67 = zT_72;
    zF_62F717A2_u32ArrayListAppend(zT_66, zT_67);
    goto z_bb_19;
    z_bb_18:
    goto z_bb_6;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_78 = store;
    zT_79 = ni;
    zT_80 = zF_152E19CB_astStoreNodeExtraCh(zT_78, zT_79);
    ecf_n = zT_80;
    zT_82 = (unsigned int)ecf_n;
    fi = zT_82;
    goto z_bb_22;
    z_bb_21:
    zT_100 = k;
    zT_101 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_100);
    if (zT_101) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    if ((int)(fi > (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_86 = fi - (unsigned int)(1);
    fi = zT_86;
    zT_87 = stack;
    zT_89 = store;
    zT_90 = ni;
    zT_93 = zF_B10B1BC1_astStoreNodeExtraCh(zT_89, zT_90, (unsigned int)((unsigned int)fi));
    zT_88 = zT_93;
    zF_62F717A2_u32ArrayListAppend(zT_87, zT_88);
    goto z_bb_25;
    z_bb_24:
    zT_94 = n.child_0;
    if ((int)(zT_94 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_97 = stack;
    zT_98 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_97, zT_98);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_103 = store;
    zT_104 = ni;
    zT_105 = zF_152E19CB_astStoreNodeExtraCh(zT_103, zT_104);
    ec3_n = zT_105;
    zT_107 = (unsigned int)ec3_n;
    ei3 = zT_107;
    goto z_bb_30;
    z_bb_29:
    zT_119 = n.child_2;
    if ((int)(zT_119 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((int)(ei3 > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_111 = ei3 - (unsigned int)(1);
    ei3 = zT_111;
    zT_112 = stack;
    zT_114 = store;
    zT_115 = ni;
    zT_118 = zF_B10B1BC1_astStoreNodeExtraCh(zT_114, zT_115, (unsigned int)((unsigned int)ei3));
    zT_113 = zT_118;
    zF_62F717A2_u32ArrayListAppend(zT_112, zT_113);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_123 = k;
    zT_126 = zF_C395F6FD_nodeChildIsNode(zT_123, (unsigned char)(2));
    zT_122 = zT_126;
    goto z_bb_36;
    z_bb_35:
    zT_122 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_122) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_127 = stack;
    zT_128 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_127, zT_128);
    goto z_bb_38;
    z_bb_38:
    zT_130 = n.child_1;
    if ((int)(zT_130 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_134 = k;
    zT_137 = zF_C395F6FD_nodeChildIsNode(zT_134, (unsigned char)(1));
    zT_133 = zT_137;
    goto z_bb_41;
    z_bb_40:
    zT_133 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_133) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_138 = stack;
    zT_139 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_138, zT_139);
    goto z_bb_43;
    z_bb_43:
    zT_141 = n.child_0;
    if ((int)(zT_141 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_145 = k;
    zT_148 = zF_C395F6FD_nodeChildIsNode(zT_145, (unsigned char)(0));
    zT_144 = zT_148;
    goto z_bb_46;
    z_bb_45:
    zT_144 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_144) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_149 = stack;
    zT_150 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_149, zT_150);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_6;
}

/* scanImplicitAwaits */
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, zT_79FAE712_u64 caller_key, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* fn_ret_types, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* hidden_fns, zT_B687BB96_U32ArrayList* parent_type_list, zT_A4CE86B7_U64ToU32Map* parent_start, zT_A4CE86B7_U64ToU32Map* parent_count) {
    zT_B687BB96_U32ArrayList* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33 = {0};
    zT_8143F551_AstKind zT_35;
    unsigned int zT_40;
    zT_6B0A7D14_AstStore* zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_BBEE1AC1_Opt_11 zT_48 = {0};
    unsigned char zT_49;
    unsigned int zT_54;
    unsigned int zT_58;
    zT_A4CE86B7_U64ToU32Map* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_63;
    zT_79FAE712_u64 zT_64;
    unsigned int zT_68;
    zT_A4CE86B7_U64ToU32Map* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    zT_79FAE712_u64 zT_79;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    zT_79FAE712_u64 zT_90;
    zT_BAEE192E_Opt_10 zT_91 = {0};
    unsigned char zT_92;
    zT_A4CE86B7_U64ToU32Map* zT_96;
    zT_79FAE712_u64 zT_97;
    unsigned int zT_99;
    zT_B687BB96_U32ArrayList* zT_101;
    unsigned int zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_A4CE86B7_U64ToU32Map* zT_108;
    zT_79FAE712_u64 zT_109;
    unsigned int zT_110;
    zT_B687BB96_U32ArrayList* zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int zT_117 = 0;
    unsigned int zT_119;
    zT_B687BB96_U32ArrayList* zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_128 = 0;
    int zT_129;
    unsigned int zT_130;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    unsigned int zT_138 = 0;
    unsigned int zT_140;
    zT_B687BB96_U32ArrayList* zT_143;
    unsigned int zT_144;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int zT_149 = 0;
    int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    int zT_155;
    zT_8143F551_AstKind zT_156;
    int zT_159 = 0;
    zT_B687BB96_U32ArrayList* zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    int zT_166;
    zT_8143F551_AstKind zT_167;
    int zT_170 = 0;
    zT_B687BB96_U32ArrayList* zT_171;
    unsigned int zT_172;
    unsigned int zT_174;
    int zT_177;
    zT_8143F551_AstKind zT_178;
    int zT_181 = 0;
    zT_B687BB96_U32ArrayList* zT_182;
    unsigned int zT_183;
    zT_8143F551_AstKind zT_185;
    int zT_186 = 0;
    zT_6B0A7D14_AstStore* zT_188;
    unsigned int zT_189;
    unsigned int zT_190 = 0;
    unsigned int zT_192;
    zT_B687BB96_U32ArrayList* zT_195;
    unsigned int zT_196;
    zT_6B0A7D14_AstStore* zT_197;
    unsigned int zT_198;
    unsigned int zT_201 = 0;
    int zT_202;
    unsigned int zT_203;
    zT_A4CE86B7_U64ToU32Map* zT_204;
    zT_79FAE712_u64 zT_205;
    zT_BAEE192E_Opt_10 zT_206 = {0};
    unsigned char zT_207;
    zT_A4CE86B7_U64ToU32Map* zT_211;
    zT_79FAE712_u64 zT_212;
    zT_BAEE192E_Opt_10 zT_213 = {0};
    unsigned char zT_214;
    unsigned int zT_217;
    unsigned int zT_219;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int* zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int* zT_230;
    unsigned int* zT_231;
    unsigned int zT_233;
    unsigned int zT_235;
    unsigned int zT_237;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int hf;
    unsigned int old;
    unsigned int rt;
    unsigned int r;
    unsigned int pc;
    unsigned int oldc;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    unsigned int ps;
    unsigned int lo;
    unsigned int hi;
    unsigned int tmp;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_16 = stack;
    zT_17 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_16, zT_17);
    goto z_bb_3;
    z_bb_3:
    zT_18 = stack->len;
    if ((int)(zT_18 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = stack->items;
    zT_23 = stack->len;
    zT_25 = zT_23 - (unsigned int)(1);
    zT_26 = zT_22[zT_25];
    ni = zT_26;
    zT_27 = stack->len;
    stack->len = (unsigned int)(zT_27 - (unsigned int)(1));
    zT_31 = store;
    zT_32 = ni;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    n = zT_33;
    zT_35 = n.kind;
    k = zT_35;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_204 = parent_count;
    zT_205 = caller_key;
    zT_206 = zF_A05A7BE1_u64ToU32MapGet(zT_204, zT_205);
    zT_207 = zT_206.has_value;
    if (zT_207) goto z_bb_56; else goto z_bb_57;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_40 = n.child_0;
    if ((int)(zT_40 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_9:
    zT_43 = store;
    zT_44 = sym_reg;
    zT_45 = module_id;
    zT_46 = n.child_0;
    zT_48 = zF_860C82EC_resolveCalleeKey(zT_43, zT_44, zT_45, zT_46);
    zT_49 = zT_48.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_115 = store;
    zT_116 = ni;
    zT_117 = zF_152E19CB_astStoreNodeExtraCh(zT_115, zT_116);
    ec_n = zT_117;
    zT_119 = 0;
    ei = zT_119;
    goto z_bb_25;
    z_bb_11:
    ck = zT_48.value;
    zT_54 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_54;
    zT_58 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_58;
    zT_59 = suspending_fns;
    zT_60 = cmid;
    zT_61 = cnid;
    zT_62 = zF_7C7E43BF_asyncIsSuspending(zT_59, zT_60, zT_61);
    if (zT_62) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_111 = stack;
    zT_112 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_111, zT_112);
    goto z_bb_10;
    z_bb_13:
    zT_63 = awaited_fns;
    zT_64 = ck;
    zF_B6EB812C_u64ToU32MapPut(zT_63, zT_64, (unsigned int)(1));
    (void)store;
    zT_68 = 1;
    hf = zT_68;
    zT_69 = hidden_fns;
    zT_70 = caller_key;
    zT_71 = zF_A05A7BE1_u64ToU32MapGet(zT_69, zT_70);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    old = zT_71.value;
    zT_75 = old | (unsigned int)(1);
    hf = zT_75;
    goto z_bb_16;
    z_bb_16:
    zT_77 = 1;
    rt = zT_77;
    zT_78 = fn_ret_types;
    zT_79 = ck;
    zT_80 = zF_A05A7BE1_u64ToU32MapGet(zT_78, zT_79);
    zT_81 = zT_80.has_value;
    if (zT_81) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    r = zT_80.value;
    rt = r;
    goto z_bb_18;
    z_bb_18:
    if ((int)(rt != (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_86 = hf | (unsigned int)(2);
    hf = zT_86;
    zT_88 = 0;
    pc = zT_88;
    zT_89 = parent_count;
    zT_90 = caller_key;
    zT_91 = zF_A05A7BE1_u64ToU32MapGet(zT_89, zT_90);
    zT_92 = zT_91.has_value;
    if (zT_92) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_108 = hidden_fns;
    zT_109 = caller_key;
    zT_110 = hf;
    zF_B6EB812C_u64ToU32MapPut(zT_108, zT_109, zT_110);
    (void)store;
    goto z_bb_14;
    z_bb_21:
    oldc = zT_91.value;
    pc = oldc;
    goto z_bb_22;
    z_bb_22:
    if ((int)(pc == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_96 = parent_start;
    zT_97 = caller_key;
    zT_99 = parent_type_list->len;
    zF_B6EB812C_u64ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)zT_99));
    (void)store;
    goto z_bb_24;
    z_bb_24:
    zT_101 = parent_type_list;
    zT_102 = rt;
    zF_62F717A2_u32ArrayListAppend(zT_101, zT_102);
    zT_103 = parent_count;
    zT_104 = caller_key;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, (unsigned int)(pc + (unsigned int)(1)));
    (void)store;
    goto z_bb_20;
    z_bb_25:
    if ((int)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_122 = stack;
    zT_124 = store;
    zT_125 = ni;
    zT_128 = zF_B10B1BC1_astStoreNodeExtraCh(zT_124, zT_125, (unsigned int)((unsigned int)ei));
    zT_123 = zT_128;
    zF_62F717A2_u32ArrayListAppend(zT_122, zT_123);
    goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_129 = 1;
    zT_130 = ei + zT_129;
    ei = zT_130;
    goto z_bb_25;
    z_bb_29:
    zT_136 = store;
    zT_137 = ni;
    zT_138 = zF_152E19CB_astStoreNodeExtraCh(zT_136, zT_137);
    ec2_n = zT_138;
    zT_140 = 0;
    ei2 = zT_140;
    goto z_bb_31;
    z_bb_30:
    zT_152 = n.child_0;
    if ((int)(zT_152 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    if ((int)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_143 = stack;
    zT_145 = store;
    zT_146 = ni;
    zT_149 = zF_B10B1BC1_astStoreNodeExtraCh(zT_145, zT_146, (unsigned int)((unsigned int)ei2));
    zT_144 = zT_149;
    zF_62F717A2_u32ArrayListAppend(zT_143, zT_144);
    goto z_bb_34;
    z_bb_33:
    goto z_bb_6;
    z_bb_34:
    zT_150 = 1;
    zT_151 = ei2 + zT_150;
    ei2 = zT_151;
    goto z_bb_31;
    z_bb_35:
    zT_156 = k;
    zT_159 = zF_C395F6FD_nodeChildIsNode(zT_156, (unsigned char)(0));
    zT_155 = zT_159;
    goto z_bb_37;
    z_bb_36:
    zT_155 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_155) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_160 = stack;
    zT_161 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_160, zT_161);
    goto z_bb_39;
    z_bb_39:
    zT_163 = n.child_1;
    if ((int)(zT_163 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_167 = k;
    zT_170 = zF_C395F6FD_nodeChildIsNode(zT_167, (unsigned char)(1));
    zT_166 = zT_170;
    goto z_bb_42;
    z_bb_41:
    zT_166 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_166) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_171 = stack;
    zT_172 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_171, zT_172);
    goto z_bb_44;
    z_bb_44:
    zT_174 = n.child_2;
    if ((int)(zT_174 != (unsigned int)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_178 = k;
    zT_181 = zF_C395F6FD_nodeChildIsNode(zT_178, (unsigned char)(2));
    zT_177 = zT_181;
    goto z_bb_47;
    z_bb_46:
    zT_177 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_177) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_182 = stack;
    zT_183 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_182, zT_183);
    goto z_bb_49;
    z_bb_49:
    zT_185 = k;
    zT_186 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_185);
    if (zT_186) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_188 = store;
    zT_189 = ni;
    zT_190 = zF_152E19CB_astStoreNodeExtraCh(zT_188, zT_189);
    ec3_n = zT_190;
    zT_192 = 0;
    ei3 = zT_192;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_6;
    z_bb_52:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_195 = stack;
    zT_197 = store;
    zT_198 = ni;
    zT_201 = zF_B10B1BC1_astStoreNodeExtraCh(zT_197, zT_198, (unsigned int)((unsigned int)ei3));
    zT_196 = zT_201;
    zF_62F717A2_u32ArrayListAppend(zT_195, zT_196);
    goto z_bb_55;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_202 = 1;
    zT_203 = ei3 + zT_202;
    ei3 = zT_203;
    goto z_bb_52;
    z_bb_56:
    pc = zT_206.value;
    if ((int)(pc > (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return;
    z_bb_58:
    zT_211 = parent_start;
    zT_212 = caller_key;
    zT_213 = zF_A05A7BE1_u64ToU32MapGet(zT_211, zT_212);
    zT_214 = zT_213.has_value;
    if (zT_214) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    ps = zT_213.value;
    zT_217 = (unsigned int)ps;
    lo = zT_217;
    zT_219 = parent_type_list->len;
    hi = zT_219;
    goto z_bb_62;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    if ((int)((unsigned int)(lo + (unsigned int)(1)) < hi)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_224 = parent_type_list->items;
    zT_225 = zT_224[lo];
    tmp = zT_225;
    zT_226 = parent_type_list->items;
    zT_228 = hi - (unsigned int)(1);
    zT_229 = zT_226[zT_228];
    zT_230 = parent_type_list->items;
    zT_230[lo] = zT_229;
    zT_231 = parent_type_list->items;
    zT_233 = hi - (unsigned int)(1);
    zT_231[zT_233] = tmp;
    zT_235 = lo + (unsigned int)(1);
    lo = zT_235;
    zT_237 = hi - (unsigned int)(1);
    hi = zT_237;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    goto z_bb_62;
}

/* asyncStateTypeForCount */
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int count) {
    if ((int)(count <= (unsigned int)(255))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(8);
    z_bb_2:
    if ((int)(count <= (unsigned int)(65535))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(9);
    z_bb_4:
    return (unsigned int)(10);
}

/* scanSuspensionCount */
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, unsigned int async_suspend_name_id, unsigned int async_init_name_id) {
    unsigned int zT_9;
    zT_B687BB96_U32ArrayList* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_49;
    zT_B687BB96_U32ArrayList* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    unsigned int zT_58 = 0;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_65;
    zT_6B0A7D14_AstStore* zT_68;
    zT_3D7259E2_SymbolRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_BBEE1AC1_Opt_11 zT_73 = {0};
    unsigned char zT_74;
    unsigned int zT_79;
    unsigned int zT_83;
    zT_A4CE86B7_U64ToU32Map* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    int zT_87 = 0;
    unsigned int zT_89;
    zT_B687BB96_U32ArrayList* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    unsigned int zT_96 = 0;
    unsigned int zT_98;
    zT_B687BB96_U32ArrayList* zT_101;
    unsigned int zT_102;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    unsigned int zT_107 = 0;
    int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    int zT_113;
    zT_8143F551_AstKind zT_114;
    int zT_117 = 0;
    zT_B687BB96_U32ArrayList* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    int zT_124;
    zT_8143F551_AstKind zT_125;
    int zT_128 = 0;
    zT_B687BB96_U32ArrayList* zT_129;
    unsigned int zT_130;
    unsigned int zT_132;
    int zT_135;
    zT_8143F551_AstKind zT_136;
    int zT_139 = 0;
    zT_B687BB96_U32ArrayList* zT_140;
    unsigned int zT_141;
    zT_8143F551_AstKind zT_143;
    int zT_144 = 0;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_150;
    zT_B687BB96_U32ArrayList* zT_153;
    unsigned int zT_154;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    unsigned int zT_159 = 0;
    int zT_160;
    unsigned int zT_161;
    unsigned int count;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int ec3_n;
    unsigned int ei3;
    zT_9 = 0;
    count = zT_9;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return count;
    z_bb_2:
    zT_13 = stack;
    zT_14 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_13, zT_14);
    goto z_bb_3;
    z_bb_3:
    zT_15 = stack->len;
    if ((int)(zT_15 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = stack->items;
    zT_20 = stack->len;
    zT_22 = zT_20 - (unsigned int)(1);
    zT_23 = zT_19[zT_22];
    ni = zT_23;
    zT_24 = stack->len;
    stack->len = (unsigned int)(zT_24 - (unsigned int)(1));
    zT_28 = store;
    zT_29 = ni;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    n = zT_30;
    zT_32 = n.kind;
    k = zT_32;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return count;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_37 = n.child_0;
    if ((int)(zT_37 == async_suspend_name_id)) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    zT_40 = n.child_0;
    zT_39 = zT_40 == async_init_name_id;
    goto z_bb_11;
    z_bb_10:
    zT_39 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_43 = count + (unsigned int)(1);
    count = zT_43;
    goto z_bb_13;
    z_bb_13:
    zT_45 = store;
    zT_46 = ni;
    zT_47 = zF_152E19CB_astStoreNodeExtraCh(zT_45, zT_46);
    ecb_n = zT_47;
    zT_49 = 0;
    bi = zT_49;
    goto z_bb_14;
    z_bb_14:
    if ((int)(bi < (unsigned int)((unsigned int)ecb_n))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_52 = stack;
    zT_54 = store;
    zT_55 = ni;
    zT_58 = zF_B10B1BC1_astStoreNodeExtraCh(zT_54, zT_55, (unsigned int)((unsigned int)bi));
    zT_53 = zT_58;
    zF_62F717A2_u32ArrayListAppend(zT_52, zT_53);
    goto z_bb_17;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_59 = 1;
    zT_60 = bi + zT_59;
    bi = zT_60;
    goto z_bb_14;
    z_bb_18:
    zT_65 = n.child_0;
    if ((int)(zT_65 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_110 = n.child_0;
    if ((int)(zT_110 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_20:
    zT_68 = store;
    zT_69 = sym_reg;
    zT_70 = module_id;
    zT_71 = n.child_0;
    zT_73 = zF_860C82EC_resolveCalleeKey(zT_68, zT_69, zT_70, zT_71);
    zT_74 = zT_73.has_value;
    if (zT_74) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_94 = store;
    zT_95 = ni;
    zT_96 = zF_152E19CB_astStoreNodeExtraCh(zT_94, zT_95);
    ecf_n = zT_96;
    zT_98 = 0;
    fi = zT_98;
    goto z_bb_26;
    z_bb_22:
    ck = zT_73.value;
    zT_79 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_79;
    zT_83 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_83;
    zT_84 = suspending_fns;
    zT_85 = cmid;
    zT_86 = cnid;
    zT_87 = zF_7C7E43BF_asyncIsSuspending(zT_84, zT_85, zT_86);
    if (zT_87) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_90 = stack;
    zT_91 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_90, zT_91);
    goto z_bb_21;
    z_bb_24:
    zT_89 = count + (unsigned int)(1);
    count = zT_89;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((int)(fi < (unsigned int)((unsigned int)ecf_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_101 = stack;
    zT_103 = store;
    zT_104 = ni;
    zT_107 = zF_B10B1BC1_astStoreNodeExtraCh(zT_103, zT_104, (unsigned int)((unsigned int)fi));
    zT_102 = zT_107;
    zF_62F717A2_u32ArrayListAppend(zT_101, zT_102);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_6;
    z_bb_29:
    zT_108 = 1;
    zT_109 = fi + zT_108;
    fi = zT_109;
    goto z_bb_26;
    z_bb_30:
    zT_114 = k;
    zT_117 = zF_C395F6FD_nodeChildIsNode(zT_114, (unsigned char)(0));
    zT_113 = zT_117;
    goto z_bb_32;
    z_bb_31:
    zT_113 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_113) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_118 = stack;
    zT_119 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_118, zT_119);
    goto z_bb_34;
    z_bb_34:
    zT_121 = n.child_1;
    if ((int)(zT_121 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_125 = k;
    zT_128 = zF_C395F6FD_nodeChildIsNode(zT_125, (unsigned char)(1));
    zT_124 = zT_128;
    goto z_bb_37;
    z_bb_36:
    zT_124 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_124) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_129 = stack;
    zT_130 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_129, zT_130);
    goto z_bb_39;
    z_bb_39:
    zT_132 = n.child_2;
    if ((int)(zT_132 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_136 = k;
    zT_139 = zF_C395F6FD_nodeChildIsNode(zT_136, (unsigned char)(2));
    zT_135 = zT_139;
    goto z_bb_42;
    z_bb_41:
    zT_135 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_135) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_140 = stack;
    zT_141 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_140, zT_141);
    goto z_bb_44;
    z_bb_44:
    zT_143 = k;
    zT_144 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_143);
    if (zT_144) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_146 = store;
    zT_147 = ni;
    zT_148 = zF_152E19CB_astStoreNodeExtraCh(zT_146, zT_147);
    ec3_n = zT_148;
    zT_150 = 0;
    ei3 = zT_150;
    goto z_bb_47;
    z_bb_46:
    goto z_bb_6;
    z_bb_47:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_153 = stack;
    zT_155 = store;
    zT_156 = ni;
    zT_159 = zF_B10B1BC1_astStoreNodeExtraCh(zT_155, zT_156, (unsigned int)((unsigned int)ei3));
    zT_154 = zT_159;
    zF_62F717A2_u32ArrayListAppend(zT_153, zT_154);
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_160 = 1;
    zT_161 = ei3 + zT_160;
    ei3 = zT_161;
    goto z_bb_47;
}

/* asyncPtrVoid */
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_1;
    unsigned int zT_6 = 0;
    zT_1 = reg;
    zT_6 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1, (unsigned int)(1), (int)(0));
    return zT_6;
}

/* emitFrameMarker */
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64 key, unsigned int size) {
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_5826BFC7_Arr_unsigned_char_1 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_5826BFC7_Arr_unsigned_char_1 zT_45;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_5826BFC7_Arr_unsigned_char_1 zT_74;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84 = 0;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_5 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_5;
    zT_9 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_9;
    zT_11 = "FRAME:m";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    m1 = zT_12;
    zT_14 = m1;
    zF_48AC7B3A_markerWrite(zT_14);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_16[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = module_id;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)b1) + zT_22;
    zT_24 = (unsigned int)(12) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    l1 = zT_26;
    zT_31 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_31;
    zT_36 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_37 = (unsigned int)(11) - s1;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_32 = zT_38;
    zF_48AC7B3A_markerWrite(zT_32);
    zT_40 = ":n";
    zT_42 = 2;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    m2 = zT_41;
    zT_43 = m2;
    zF_48AC7B3A_markerWrite(zT_43);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_45[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_45[_i];
        _i++;
    }
}
    zT_47 = name_id;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)b2) + zT_51;
    zT_53 = (unsigned int)(12) - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_48 = zT_54;
    zT_55 = zF_A7504564_itoa(zT_47, zT_48);
    l2 = zT_55;
    zT_60 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_60;
    zT_65 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_66 = (unsigned int)(11) - s2;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_61 = zT_67;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_69 = ":s";
    zT_71 = 2;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    m3 = zT_70;
    zT_72 = m3;
    zF_48AC7B3A_markerWrite(zT_72);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_74[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_74[_i];
        _i++;
    }
}
    zT_76 = size;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)b3) + zT_80;
    zT_82 = (unsigned int)(12) - zT_80;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zT_84 = zF_A7504564_itoa(zT_76, zT_77);
    l3 = zT_84;
    zT_89 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_89;
    zT_94 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_95 = (unsigned int)(11) - s3;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90 = zT_96;
    zF_48AC7B3A_markerWrite(zT_90);
    zT_98 = "\n";
    zT_100 = 1;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    m4 = zT_99;
    zT_101 = m4;
    zF_48AC7B3A_markerWrite(zT_101);
    return;
}

/* asyncFrameSizeRun */
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* typereg, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_B687BB96_U32ArrayList zT_23 = {0};
    zT_072B53A6_ModuleRegistry* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26 = {0};
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    zT_3E40CD83_Sand* zT_44;
    zT_A4CE86B7_U64ToU32Map zT_45 = {0};
    unsigned int zT_47;
    unsigned int zT_49;
    zT_6E8D187B_ModuleEntry* zT_52;
    zT_6E8D187B_ModuleEntry zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_79 = 0;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    zT_22A7C88B_AstNode zT_83 = {0};
    zT_8143F551_AstKind zT_84;
    zT_98B93138_anon_226730 zT_90;
    zT_243D6A41_FnProto* zT_91;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_94 = 0;
    unsigned int zT_95;
    zT_243D6A41_FnProto zT_96;
    unsigned int zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_99;
    unsigned int zT_100;
    zT_BAEE192E_Opt_10 zT_102 = {0};
    unsigned char zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_6E8D187B_ModuleEntry* zT_111;
    zT_6E8D187B_ModuleEntry zT_112;
    zT_79FAE712_u64 zT_115 = 0;
    int zT_116;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    zT_6E8D187B_ModuleEntry* zT_126;
    zT_6E8D187B_ModuleEntry zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    unsigned int zT_143 = 0;
    unsigned int zT_145;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int zT_153 = 0;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    zT_22A7C88B_AstNode zT_157 = {0};
    zT_8143F551_AstKind zT_158;
    zT_98B93138_anon_226730 zT_164;
    zT_243D6A41_FnProto* zT_165;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_168 = 0;
    unsigned int zT_169;
    zT_243D6A41_FnProto zT_170;
    zT_A4CE86B7_U64ToU32Map* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    zT_6E8D187B_ModuleEntry* zT_174;
    zT_6E8D187B_ModuleEntry zT_175;
    int zT_178 = 0;
    zT_6B0A7D14_AstStore* zT_180;
    zT_3D7259E2_SymbolRegistry* zT_181;
    unsigned int zT_182;
    zT_79FAE712_u64 zT_183;
    unsigned int zT_184;
    zT_B687BB96_U32ArrayList* zT_185;
    zT_A4CE86B7_U64ToU32Map* zT_186;
    zT_A4CE86B7_U64ToU32Map* zT_187;
    zT_A4CE86B7_U64ToU32Map* zT_188;
    zT_A4CE86B7_U64ToU32Map* zT_189;
    zT_B687BB96_U32ArrayList* zT_190;
    zT_A4CE86B7_U64ToU32Map* zT_191;
    zT_A4CE86B7_U64ToU32Map* zT_192;
    zT_6E8D187B_ModuleEntry* zT_193;
    zT_6E8D187B_ModuleEntry zT_194;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_6E8D187B_ModuleEntry* zT_198;
    zT_6E8D187B_ModuleEntry zT_199;
    zT_79FAE712_u64 zT_202 = 0;
    int zT_206;
    unsigned int zT_207;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_213;
    zT_6E8D187B_ModuleEntry* zT_216;
    zT_6E8D187B_ModuleEntry zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_222;
    unsigned int zT_223;
    zT_22A7C88B_AstNode zT_224 = {0};
    zT_8143F551_AstKind zT_225;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    unsigned int zT_233 = 0;
    unsigned int zT_235;
    zT_6B0A7D14_AstStore* zT_239;
    unsigned int zT_240;
    unsigned int zT_243 = 0;
    zT_6B0A7D14_AstStore* zT_245;
    unsigned int zT_246;
    zT_22A7C88B_AstNode zT_247 = {0};
    zT_8143F551_AstKind zT_248;
    zT_6B0A7D14_AstStore* zT_254;
    unsigned int zT_255;
    unsigned int zT_256 = 0;
    zT_98B93138_anon_226730 zT_258;
    zT_243D6A41_FnProto* zT_259;
    unsigned int zT_260;
    zT_243D6A41_FnProto zT_261;
    zT_A4CE86B7_U64ToU32Map* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    zT_6E8D187B_ModuleEntry* zT_265;
    zT_6E8D187B_ModuleEntry zT_266;
    int zT_269 = 0;
    unsigned int zT_272;
    unsigned int zT_273;
    zT_6E8D187B_ModuleEntry* zT_274;
    zT_6E8D187B_ModuleEntry zT_275;
    zT_79FAE712_u64 zT_278 = 0;
    int zT_280;
    unsigned char zT_281;
    int zT_287;
    zT_6E8D187B_ModuleEntry* zT_288;
    zT_6E8D187B_ModuleEntry zT_289;
    unsigned int zT_290;
    int zT_293;
    unsigned char zT_294;
    zT_D3EB6303_StringInterner* zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304 = {0};
    unsigned int zT_306;
    int zT_309;
    unsigned char* zT_310;
    int zT_311;
    unsigned char zT_312;
    int zT_315;
    unsigned char* zT_316;
    int zT_317;
    unsigned char zT_318;
    int zT_321;
    unsigned char* zT_322;
    int zT_323;
    unsigned char zT_324;
    int zT_327;
    unsigned char* zT_328;
    int zT_329;
    unsigned char zT_330;
    int zT_333;
    zT_A4CE86B7_U64ToU32Map* zT_334;
    zT_79FAE712_u64 zT_335;
    zT_6B0A7D14_AstStore* zT_339;
    zT_3D7259E2_SymbolRegistry* zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    zT_B687BB96_U32ArrayList* zT_343;
    zT_A4CE86B7_U64ToU32Map* zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_6E8D187B_ModuleEntry* zT_347;
    zT_6E8D187B_ModuleEntry zT_348;
    unsigned int zT_352 = 0;
    unsigned int zT_354;
    unsigned int zT_355 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_356;
    zT_79FAE712_u64 zT_357;
    unsigned int zT_358;
    unsigned int zT_360;
    unsigned int zT_362;
    zT_338B7C76_TypeRegistry* zT_363;
    unsigned int* zT_365;
    unsigned int* zT_366;
    unsigned int zT_370 = 0;
    zT_338B7C76_TypeRegistry* zT_371;
    unsigned int* zT_373;
    unsigned int* zT_374;
    unsigned int zT_378 = 0;
    zT_338B7C76_TypeRegistry* zT_379;
    unsigned int zT_380;
    unsigned int* zT_381;
    unsigned int* zT_382;
    unsigned int zT_385 = 0;
    unsigned short zT_386;
    unsigned int zT_390;
    unsigned short zT_394;
    zT_79FAE712_u64 zT_396;
    zT_6B0A7D14_AstStore* zT_398;
    zT_79FAE712_u64 zT_399;
    unsigned int zT_400 = 0;
    unsigned int zT_402;
    zT_6B0A7D14_AstStore* zT_406;
    unsigned int zT_407;
    zT_6B0A7D14_AstStore* zT_408;
    zT_79FAE712_u64 zT_409;
    unsigned int zT_412 = 0;
    zT_22A7C88B_AstNode zT_413 = {0};
    unsigned int zT_414;
    unsigned int zT_418;
    zT_8EED1867_ResolvedTypeTable* zT_419;
    unsigned int zT_420;
    zT_BAEE192E_Opt_10 zT_422 = {0};
    unsigned char zT_423;
    zT_338B7C76_TypeRegistry* zT_425;
    unsigned int zT_426;
    unsigned int* zT_427;
    unsigned int* zT_428;
    unsigned int zT_431 = 0;
    unsigned int zT_433;
    zT_6B0A7D14_AstStore* zT_434;
    unsigned int zT_435;
    zT_B687BB96_U32ArrayList* zT_436;
    zT_338B7C76_TypeRegistry* zT_437;
    zT_8EED1867_ResolvedTypeTable* zT_438;
    unsigned int* zT_439;
    unsigned int* zT_440;
    unsigned int zT_446;
    zT_A4CE86B7_U64ToU32Map* zT_447;
    zT_79FAE712_u64 zT_448;
    zT_BAEE192E_Opt_10 zT_449 = {0};
    unsigned char zT_450;
    zT_338B7C76_TypeRegistry* zT_456;
    unsigned int zT_457;
    unsigned int* zT_458;
    unsigned int* zT_459;
    zT_338B7C76_TypeRegistry* zT_460;
    unsigned int zT_461 = 0;
    unsigned int zT_464 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_465;
    zT_79FAE712_u64 zT_466;
    zT_BAEE192E_Opt_10 zT_467 = {0};
    unsigned char zT_468;
    int zT_469;
    zT_A4CE86B7_U64ToU32Map* zT_470;
    zT_79FAE712_u64 zT_471;
    zT_BAEE192E_Opt_10 zT_472 = {0};
    unsigned char zT_473;
    zT_338B7C76_TypeRegistry* zT_474;
    unsigned int zT_475;
    unsigned int* zT_476;
    unsigned int* zT_477;
    zT_338B7C76_TypeRegistry* zT_478;
    unsigned int zT_479 = 0;
    unsigned int zT_482 = 0;
    unsigned int zT_488;
    zT_A4CE86B7_U64ToU32Map* zT_489;
    zT_79FAE712_u64 zT_490;
    zT_BAEE192E_Opt_10 zT_491 = {0};
    unsigned char zT_492;
    unsigned int zT_495;
    zT_A4CE86B7_U64ToU32Map* zT_496;
    zT_79FAE712_u64 zT_497;
    zT_BAEE192E_Opt_10 zT_498 = {0};
    unsigned char zT_499;
    unsigned int zT_502;
    unsigned int* zT_505;
    unsigned int zT_507;
    unsigned int zT_508;
    zT_338B7C76_TypeRegistry* zT_509;
    unsigned int zT_510;
    unsigned int* zT_511;
    unsigned int* zT_512;
    unsigned int zT_515 = 0;
    unsigned int zT_517;
    unsigned int zT_519;
    unsigned int zT_520;
    unsigned int zT_521 = 0;
    unsigned int zT_524;
    unsigned int zT_525;
    unsigned int zT_528 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_529;
    zT_79FAE712_u64 zT_530;
    unsigned int zT_531;
    zT_79FAE712_u64 zT_532;
    unsigned int zT_533;
    int zT_534;
    unsigned int zT_535;
    int zT_536;
    unsigned int zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_B687BB96_U32ArrayList stack;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_text;
    unsigned int async_init_name_id;
    zT_A4CE86B7_U64ToU32Map fn_ret_types;
    unsigned int mi0;
    unsigned int ar0;
    unsigned int mi0b;
    zT_22A7C88B_AstNode r0;
    unsigned int d0_n;
    unsigned int di0;
    unsigned int d0_idx;
    zT_22A7C88B_AstNode dc0;
    zT_243D6A41_FnProto pr0;
    unsigned int rt0;
    unsigned int rr0;
    unsigned int ar0b;
    unsigned int mi;
    zT_22A7C88B_AstNode r0b;
    unsigned int d0b_n;
    unsigned int di0b;
    unsigned int d0b_idx;
    zT_22A7C88B_AstNode dc0b;
    zT_243D6A41_FnProto pr0b;
    unsigned int ast_root;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    int is_driver_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u dm;
    unsigned int susp_count;
    unsigned int state_type;
    unsigned int offset;
    unsigned int max_align;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int hid;
    zT_22A7C88B_AstNode pnode;
    unsigned int pt;
    unsigned int rtp;
    unsigned int h;
    unsigned int pstart;
    unsigned int total;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_17 = "AFS\n";
    zT_19 = 4;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    p_msg = zT_18;
    zT_20 = p_msg;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_22 = alloc;
    zT_23 = zF_8E537D0C_u32ArrayListInit(zT_22);
    stack = zT_23;
    zT_25 = module_reg;
    zT_26 = zF_3452C137_moduleRegistryGetMo(zT_25);
    mods = zT_26;
    zT_28 = "@asyncSuspend";
    zT_30 = 13;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    asu_text = zT_29;
    zT_32 = interner;
    zT_33 = asu_text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    async_suspend_name_id = zT_34;
    zT_36 = "@asyncInit";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    ain_text = zT_37;
    zT_40 = interner;
    zT_41 = ain_text;
    zT_42 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    async_init_name_id = zT_42;
    zT_44 = alloc;
    zT_45 = zF_986226E1_u64ToU32MapInit(zT_44);
    fn_ret_types = zT_45;
    zT_47 = 0;
    mi0 = zT_47;
    goto z_bb_1;
    z_bb_1:
    zT_49 = mods.len;
    if ((int)(mi0 < zT_49)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_52 = mods.ptr;
    zT_53 = zT_52[mi0];
    zT_54 = zT_53.ast_root;
    ar0 = zT_54;
    if ((int)(ar0 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_121 = 0;
    mi0b = zT_121;
    goto z_bb_17;
    z_bb_4:
    zT_118 = 1;
    zT_119 = mi0 + zT_118;
    mi0 = zT_119;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_58 = store;
    zT_59 = ar0;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    r0 = zT_60;
    zT_61 = r0.kind;
    if ((int)(zT_61 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_67 = store;
    zT_68 = ar0;
    zT_69 = zF_152E19CB_astStoreNodeExtraCh(zT_67, zT_68);
    d0_n = zT_69;
    zT_71 = 0;
    di0 = zT_71;
    goto z_bb_9;
    z_bb_9:
    if ((int)(di0 < (unsigned int)((unsigned int)d0_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_75 = store;
    zT_76 = ar0;
    zT_79 = zF_B10B1BC1_astStoreNodeExtraCh(zT_75, zT_76, (unsigned int)((unsigned int)di0));
    d0_idx = zT_79;
    zT_81 = store;
    zT_82 = d0_idx;
    zT_83 = zF_FCDD1D35_astStoreNodeAt(zT_81, zT_82);
    dc0 = zT_83;
    zT_84 = dc0.kind;
    if ((int)(zT_84 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_116 = 1;
    zT_117 = di0 + zT_116;
    di0 = zT_117;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_90 = store->fn_protos;
    zT_91 = zT_90.items;
    zT_92 = store;
    zT_93 = d0_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_92, zT_93);
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_91[zT_95];
    pr0 = zT_96;
    zT_98 = 1;
    rt0 = zT_98;
    zT_99 = resolved_types;
    zT_100 = pr0.return_type_node;
    zT_102 = zF_999DCF51_resolvedTypeTableGe(zT_99, zT_100);
    zT_103 = zT_102.has_value;
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    rr0 = zT_102.value;
    rt0 = rr0;
    goto z_bb_16;
    z_bb_16:
    zT_105 = &fn_ret_types;
    zT_111 = mods.ptr;
    zT_112 = zT_111[mi0];
    zT_109 = zT_112.id;
    zT_110 = pr0.name_id;
    zT_115 = zF_9D041EB6_asyncKey(zT_109, zT_110);
    zT_106 = zT_115;
    zT_107 = rt0;
    zF_B6EB812C_u64ToU32MapPut(zT_105, zT_106, zT_107);
    (void)alloc;
    goto z_bb_12;
    z_bb_17:
    zT_123 = mods.len;
    if ((int)(mi0b < zT_123)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_126 = mods.ptr;
    zT_127 = zT_126[mi0b];
    zT_128 = zT_127.ast_root;
    ar0b = zT_128;
    if ((int)(ar0b == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_211 = 0;
    mi = zT_211;
    goto z_bb_33;
    z_bb_20:
    zT_208 = 1;
    zT_209 = mi0b + zT_208;
    mi0b = zT_209;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_132 = store;
    zT_133 = ar0b;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_132, zT_133);
    r0b = zT_134;
    zT_135 = r0b.kind;
    if ((int)(zT_135 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_141 = store;
    zT_142 = ar0b;
    zT_143 = zF_152E19CB_astStoreNodeExtraCh(zT_141, zT_142);
    d0b_n = zT_143;
    zT_145 = 0;
    di0b = zT_145;
    goto z_bb_25;
    z_bb_25:
    if ((int)(di0b < (unsigned int)((unsigned int)d0b_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_149 = store;
    zT_150 = ar0b;
    zT_153 = zF_B10B1BC1_astStoreNodeExtraCh(zT_149, zT_150, (unsigned int)((unsigned int)di0b));
    d0b_idx = zT_153;
    zT_155 = store;
    zT_156 = d0b_idx;
    zT_157 = zF_FCDD1D35_astStoreNodeAt(zT_155, zT_156);
    dc0b = zT_157;
    zT_158 = dc0b.kind;
    if ((int)(zT_158 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_206 = 1;
    zT_207 = di0b + zT_206;
    di0b = zT_207;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_164 = store->fn_protos;
    zT_165 = zT_164.items;
    zT_166 = store;
    zT_167 = d0b_idx;
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_166, zT_167);
    zT_169 = (unsigned int)zT_168;
    zT_170 = zT_165[zT_169];
    pr0b = zT_170;
    zT_171 = suspending_fns;
    zT_174 = mods.ptr;
    zT_175 = zT_174[mi0b];
    zT_172 = zT_175.id;
    zT_173 = pr0b.name_id;
    zT_178 = zF_7C7E43BF_asyncIsSuspending(zT_171, zT_172, zT_173);
    if ((int)(!zT_178)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_180 = store;
    zT_181 = sym_reg;
    zT_193 = mods.ptr;
    zT_194 = zT_193[mi0b];
    zT_182 = zT_194.id;
    zT_198 = mods.ptr;
    zT_199 = zT_198[mi0b];
    zT_196 = zT_199.id;
    zT_197 = pr0b.name_id;
    zT_202 = zF_9D041EB6_asyncKey(zT_196, zT_197);
    zT_183 = zT_202;
    zT_184 = dc0b.child_0;
    zT_185 = &stack;
    zT_186 = suspending_fns;
    zT_187 = &fn_ret_types;
    zT_188 = awaited_fns;
    zT_189 = async_hidden_fns;
    zT_190 = parent_result_type_list;
    zT_191 = parent_result_start;
    zT_192 = parent_result_count;
    zF_D62E4E4C_scanImplicitAwaits(zT_180, zT_181, zT_182, zT_183, zT_184, zT_185, zT_186, zT_187, zT_188, zT_189, zT_190, zT_191, zT_192);
    goto z_bb_28;
    z_bb_33:
    zT_213 = mods.len;
    if ((int)(mi < zT_213)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_216 = mods.ptr;
    zT_217 = zT_216[mi];
    zT_218 = zT_217.ast_root;
    ast_root = zT_218;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return;
    z_bb_36:
    zT_536 = 1;
    zT_537 = mi + zT_536;
    mi = zT_537;
    goto z_bb_33;
    z_bb_37:
    goto z_bb_36;
    z_bb_38:
    zT_222 = store;
    zT_223 = ast_root;
    zT_224 = zF_FCDD1D35_astStoreNodeAt(zT_222, zT_223);
    root = zT_224;
    zT_225 = root.kind;
    if ((int)(zT_225 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_231 = store;
    zT_232 = ast_root;
    zT_233 = zF_152E19CB_astStoreNodeExtraCh(zT_231, zT_232);
    decls_n = zT_233;
    zT_235 = 0;
    di = zT_235;
    goto z_bb_41;
    z_bb_41:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_239 = store;
    zT_240 = ast_root;
    zT_243 = zF_B10B1BC1_astStoreNodeExtraCh(zT_239, zT_240, (unsigned int)((unsigned int)di));
    decl_idx = zT_243;
    zT_245 = store;
    zT_246 = decl_idx;
    zT_247 = zF_FCDD1D35_astStoreNodeAt(zT_245, zT_246);
    decl = zT_247;
    zT_248 = decl.kind;
    if ((int)(zT_248 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_534 = 1;
    zT_535 = di + zT_534;
    di = zT_535;
    goto z_bb_41;
    z_bb_45:
    goto z_bb_44;
    z_bb_46:
    zT_254 = store;
    zT_255 = decl_idx;
    zT_256 = zF_8BA26B9E_astStoreNodePayload(zT_254, zT_255);
    proto_idx = zT_256;
    zT_258 = store->fn_protos;
    zT_259 = zT_258.items;
    zT_260 = (unsigned int)proto_idx;
    zT_261 = zT_259[zT_260];
    proto = zT_261;
    zT_262 = suspending_fns;
    zT_265 = mods.ptr;
    zT_266 = zT_265[mi];
    zT_263 = zT_266.id;
    zT_264 = proto.name_id;
    zT_269 = zF_7C7E43BF_asyncIsSuspending(zT_262, zT_263, zT_264);
    if ((int)(!zT_269)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_274 = mods.ptr;
    zT_275 = zT_274[mi];
    zT_272 = zT_275.id;
    zT_273 = proto.name_id;
    zT_278 = zF_9D041EB6_asyncKey(zT_272, zT_273);
    key = zT_278;
    zT_280 = 0;
    is_driver_target = zT_280;
    zT_281 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_281) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_287 = 1;
    is_driver_target = zT_287;
    goto z_bb_50;
    z_bb_50:
    zT_288 = mods.ptr;
    zT_289 = zT_288[mi];
    zT_290 = zT_289.id;
    if ((int)(zT_290 == (unsigned int)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_294 = decl.flags;
    zT_293 = (unsigned short)((unsigned short)((unsigned short)zT_294) & (unsigned short)(2)) != (unsigned short)(0);
    goto z_bb_53;
    z_bb_52:
    zT_293 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_293) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_301 = interner;
    zT_302 = proto.name_id;
    zT_304 = zF_9134020D_stringInternerGet(zT_301, zT_302);
    dm = zT_304;
    zT_306 = dm.len;
    if ((int)(zT_306 == (unsigned int)(4))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if (is_driver_target) goto z_bb_70; else goto z_bb_71;
    z_bb_56:
    zT_310 = dm.ptr;
    zT_311 = 0;
    zT_312 = zT_310[zT_311];
    zT_309 = zT_312 == (unsigned char)(109);
    goto z_bb_58;
    z_bb_57:
    zT_309 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_309) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_316 = dm.ptr;
    zT_317 = 1;
    zT_318 = zT_316[zT_317];
    zT_315 = zT_318 == (unsigned char)(97);
    goto z_bb_61;
    z_bb_60:
    zT_315 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_315) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_322 = dm.ptr;
    zT_323 = 2;
    zT_324 = zT_322[zT_323];
    zT_321 = zT_324 == (unsigned char)(105);
    goto z_bb_64;
    z_bb_63:
    zT_321 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_321) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_328 = dm.ptr;
    zT_329 = 3;
    zT_330 = zT_328[zT_329];
    zT_327 = zT_330 == (unsigned char)(110);
    goto z_bb_67;
    z_bb_66:
    zT_327 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_327) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_333 = 1;
    is_driver_target = zT_333;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_55;
    z_bb_70:
    zT_334 = driver_targets;
    zT_335 = key;
    zF_B6EB812C_u64ToU32MapPut(zT_334, zT_335, (unsigned int)(1));
    (void)alloc;
    goto z_bb_71;
    z_bb_71:
    zT_339 = store;
    zT_340 = sym_reg;
    zT_347 = mods.ptr;
    zT_348 = zT_347[mi];
    zT_341 = zT_348.id;
    zT_342 = decl.child_0;
    zT_343 = &stack;
    zT_344 = suspending_fns;
    zT_345 = async_suspend_name_id;
    zT_346 = async_init_name_id;
    zT_352 = zF_0782A438_scanSuspensionCount(zT_339, zT_340, zT_341, zT_342, zT_343, zT_344, zT_345, zT_346);
    susp_count = zT_352;
    zT_354 = susp_count;
    zT_355 = zF_74FC996E_asyncStateTypeForCo(zT_354);
    state_type = zT_355;
    zT_356 = state_widths;
    zT_357 = key;
    zT_358 = state_type;
    zF_B6EB812C_u64ToU32MapPut(zT_356, zT_357, zT_358);
    (void)alloc;
    zT_360 = 0;
    offset = zT_360;
    zT_362 = 1;
    max_align = zT_362;
    zT_363 = typereg;
    zT_365 = &offset;
    zT_366 = &max_align;
    zT_370 = zF_769CB99B_addFrameField(zT_363, (unsigned int)(13), zT_365, zT_366);
    (void)zT_370;
    zT_371 = typereg;
    zT_373 = &offset;
    zT_374 = &max_align;
    zT_378 = zF_769CB99B_addFrameField(zT_371, (unsigned int)(13), zT_373, zT_374);
    (void)zT_378;
    zT_379 = typereg;
    zT_380 = state_type;
    zT_381 = &offset;
    zT_382 = &max_align;
    zT_385 = zF_769CB99B_addFrameField(zT_379, zT_380, zT_381, zT_382);
    (void)zT_385;
    zT_386 = proto.params_count;
    if ((int)(zT_386 > (unsigned short)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_390 = proto.params_start;
    zT_394 = proto.params_count;
    zT_396 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_390) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_394);
    p_payload = zT_396;
    zT_398 = store;
    zT_399 = p_payload;
    zT_400 = zF_03CE8CAB_astStoreGetExtraChi(zT_398, zT_399);
    pnodes_n = zT_400;
    zT_402 = 0;
    pi = zT_402;
    goto z_bb_74;
    z_bb_73:
    zT_434 = store;
    zT_435 = decl.child_0;
    zT_436 = &stack;
    zT_437 = typereg;
    zT_438 = resolved_types;
    zT_439 = &offset;
    zT_440 = &max_align;
    zF_68BD38B1_scanFrameLocals(zT_434, zT_435, zT_436, zT_437, zT_438, zT_439, zT_440);
    zT_446 = 0;
    hid = zT_446;
    zT_447 = async_hidden_fns;
    zT_448 = key;
    zT_449 = zF_A05A7BE1_u64ToU32MapGet(zT_447, zT_448);
    zT_450 = zT_449.has_value;
    if (zT_450) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    if ((int)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_406 = store;
    zT_408 = store;
    zT_409 = p_payload;
    zT_412 = zF_E5B10421_astStoreGetExtraChi(zT_408, zT_409, (unsigned int)((unsigned int)pi));
    zT_407 = zT_412;
    zT_413 = zF_FCDD1D35_astStoreNodeAt(zT_406, zT_407);
    pnode = zT_413;
    zT_414 = pnode.child_0;
    if ((int)(zT_414 == (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_433 = pi + (unsigned int)(1);
    pi = zT_433;
    goto z_bb_74;
    z_bb_78:
    goto z_bb_77;
    z_bb_79:
    zT_418 = 18;
    pt = zT_418;
    zT_419 = resolved_types;
    zT_420 = pnode.child_0;
    zT_422 = zF_999DCF51_resolvedTypeTableGe(zT_419, zT_420);
    zT_423 = zT_422.has_value;
    if (zT_423) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    rtp = zT_422.value;
    pt = rtp;
    goto z_bb_81;
    z_bb_81:
    zT_425 = typereg;
    zT_426 = pt;
    zT_427 = &offset;
    zT_428 = &max_align;
    zT_431 = zF_769CB99B_addFrameField(zT_425, zT_426, zT_427, zT_428);
    (void)zT_431;
    goto z_bb_77;
    z_bb_82:
    h = zT_449.value;
    hid = h;
    goto z_bb_83;
    z_bb_83:
    if ((int)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_456 = typereg;
    zT_460 = typereg;
    zT_461 = zF_FF3C4865_asyncPtrVoid(zT_460);
    zT_457 = zT_461;
    zT_458 = &offset;
    zT_459 = &max_align;
    zT_464 = zF_769CB99B_addFrameField(zT_456, zT_457, zT_458, zT_459);
    (void)zT_464;
    goto z_bb_85;
    z_bb_85:
    zT_465 = awaited_fns;
    zT_466 = key;
    zT_467 = zF_A05A7BE1_u64ToU32MapGet(zT_465, zT_466);
    zT_468 = zT_467.has_value;
    if (zT_468) goto z_bb_87; else goto z_bb_86;
    z_bb_86:
    zT_470 = driver_targets;
    zT_471 = key;
    zT_472 = zF_A05A7BE1_u64ToU32MapGet(zT_470, zT_471);
    zT_473 = zT_472.has_value;
    zT_469 = zT_473;
    goto z_bb_88;
    z_bb_87:
    zT_469 = 1;
    goto z_bb_88;
    z_bb_88:
    if (zT_469) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_474 = typereg;
    zT_478 = typereg;
    zT_479 = zF_FF3C4865_asyncPtrVoid(zT_478);
    zT_475 = zT_479;
    zT_476 = &offset;
    zT_477 = &max_align;
    zT_482 = zF_769CB99B_addFrameField(zT_474, zT_475, zT_476, zT_477);
    (void)zT_482;
    goto z_bb_90;
    z_bb_90:
    if ((int)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_488 = 0;
    pstart = zT_488;
    zT_489 = parent_result_start;
    zT_490 = key;
    zT_491 = zF_A05A7BE1_u64ToU32MapGet(zT_489, zT_490);
    zT_492 = zT_491.has_value;
    if (zT_492) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_519 = offset;
    zT_520 = max_align;
    zT_521 = zF_978D7C93_alignUpU32(zT_519, zT_520);
    total = zT_521;
    if ((int)(total == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_93:
    ps = zT_491.value;
    pstart = ps;
    goto z_bb_94;
    z_bb_94:
    zT_495 = 0;
    pcount = zT_495;
    zT_496 = parent_result_count;
    zT_497 = key;
    zT_498 = zF_A05A7BE1_u64ToU32MapGet(zT_496, zT_497);
    zT_499 = zT_498.has_value;
    if (zT_499) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    pc = zT_498.value;
    pcount = pc;
    goto z_bb_96;
    z_bb_96:
    zT_502 = 0;
    pk = zT_502;
    goto z_bb_97;
    z_bb_97:
    if ((int)(pk < pcount)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_505 = parent_result_type_list->items;
    zT_507 = (unsigned int)(unsigned int)(pstart + pk);
    zT_508 = zT_505[zT_507];
    prt = zT_508;
    zT_509 = typereg;
    zT_510 = prt;
    zT_511 = &offset;
    zT_512 = &max_align;
    zT_515 = zF_769CB99B_addFrameField(zT_509, zT_510, zT_511, zT_512);
    (void)zT_515;
    goto z_bb_100;
    z_bb_99:
    goto z_bb_92;
    z_bb_100:
    zT_517 = pk + (unsigned int)(1);
    pk = zT_517;
    goto z_bb_97;
    z_bb_101:
    zT_524 = 1;
    total = zT_524;
    goto z_bb_102;
    z_bb_102:
    zT_525 = total;
    zT_528 = zF_978D7C93_alignUpU32(zT_525, (unsigned int)(8));
    total = zT_528;
    zT_529 = frame_sizes;
    zT_530 = key;
    zT_531 = total;
    zF_B6EB812C_u64ToU32MapPut(zT_529, zT_530, zT_531);
    zT_532 = key;
    zT_533 = total;
    zF_7011AA79_emitFrameMarker(zT_532, zT_533);
    goto z_bb_44;
}

/* __module_init */
void zF_780653D2___module_init_21(void) {
    zT_8143F551_AstKind zT_0 = 0;
    zG_8143F551_AstKind = zT_0;
    return;
}

/* EOF */
