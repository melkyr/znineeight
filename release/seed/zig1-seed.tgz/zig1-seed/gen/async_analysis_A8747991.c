#include "async_analysis_A8747991.h"
/* asyncKey */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int module_id, unsigned int name_id) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
}

/* asyncIsSuspending */
unsigned char zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8 = 0;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 v;
    unsigned int val;
    zT_4 = map;
    zT_6 = module_id;
    zT_7 = name_id;
    zT_8 = zF_9D041EB6_asyncKey(zT_6, zT_7);
    zT_5 = zT_8;
    zT_9 = zF_A05A7BE1_u64ToU32MapGet(zT_4, zT_5);
    v = zT_9;
    zT_10 = v.has_value;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    val = v.value;
    return (unsigned char)(val != (unsigned int)(0));
    z_bb_2:
    return (unsigned char)(0);
}

/* asyncFrameSizeOf */
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    return zT_8;
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand* sand, unsigned int count) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_0715C9B9_EU_832 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int c;
    unsigned char* raw;
    c = count;
    if ((unsigned char)(c == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    c = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = sand;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)(4) * c), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    return (unsigned int*)((unsigned int*)raw);
}

/* resolveCalleeKey */
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int callee_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_15 = 0;
    zT_3D7259E2_SymbolRegistry* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_567DA1C3_Opt_868 zT_19 = {0};
    unsigned char zT_20;
    zT_3C598AEF_SymbolKind zT_22;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_79FAE712_u64 zT_30 = 0;
    zT_BBEE1AC1_Opt_11 zT_31;
    zT_BBEE1AC1_Opt_11 zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    zT_BBEE1AC1_Opt_11 zT_37 = {0};
    zT_99292002_Arr_unsigned_int_16 zT_39;
    int zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_45 = 0;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_49;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_55 = {0};
    zT_8143F551_AstKind zT_56;
    zT_BBEE1AC1_Opt_11 zT_62 = {0};
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_BBEE1AC1_Opt_11 zT_78 = {0};
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_82 = 0;
    zT_3D7259E2_SymbolRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_567DA1C3_Opt_868 zT_87 = {0};
    unsigned char zT_88;
    zT_3C598AEF_SymbolKind zT_90;
    zT_BBEE1AC1_Opt_11 zT_94 = {0};
    unsigned int zT_95;
    zT_BBEE1AC1_Opt_11 zT_96 = {0};
    int zT_100;
    unsigned int zT_102;
    zT_3D7259E2_SymbolRegistry* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_567DA1C3_Opt_868 zT_108 = {0};
    unsigned char zT_109;
    zT_3C598AEF_SymbolKind zT_111;
    zT_BBEE1AC1_Opt_11 zT_115 = {0};
    unsigned int zT_116;
    zT_BBEE1AC1_Opt_11 zT_117 = {0};
    zT_3D7259E2_SymbolRegistry* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    int zT_121;
    zT_567DA1C3_Opt_868 zT_123 = {0};
    unsigned char zT_124;
    zT_3C598AEF_SymbolKind zT_126;
    unsigned int zT_130;
    unsigned int zT_131;
    zT_79FAE712_u64 zT_134 = 0;
    zT_BBEE1AC1_Opt_11 zT_135;
    zT_BBEE1AC1_Opt_11 zT_136 = {0};
    zT_22A7C88B_AstNode cn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_99292002_Arr_unsigned_int_16 names;
    unsigned int nlen;
    unsigned int cur;
    zT_22A7C88B_AstNode cw;
    unsigned int base_nid;
    unsigned int cur_mod;
    zT_3A105EF1_Symbol* bs;
    unsigned int i;
    zT_3A105EF1_Symbol* ms;
    zT_3A105EF1_Symbol* fs;
    zT_5 = store;
    zT_6 = callee_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    cn = zT_7;
    zT_8 = cn.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = store;
    zT_14 = callee_idx;
    zT_15 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    nid = zT_15;
    zT_16 = sym_reg;
    zT_17 = module_id;
    zT_18 = nid;
    zT_19 = zF_A398987E_symbolRegistryQuali(zT_16, zT_17, zT_18);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_33 = cn.kind;
    if ((unsigned char)(zT_33 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    s = zT_19.value;
    zT_22 = s->kind;
    if ((unsigned char)(zT_22 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_5:
    zT_26 = s->module_id;
    zT_27 = s->name_id;
    zT_30 = zF_9D041EB6_asyncKey(zT_26, zT_27);
    zT_31.has_value = 1;
    zT_31.value = zT_30;
    return zT_31;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_8:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        names[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    nlen = zT_42;
    zT_43 = store;
    zT_44 = callee_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    zT_46 = (unsigned int)nlen;
    names[zT_46] = zT_45;
    zT_47 = 1;
    zT_49 = nlen + (unsigned int)((unsigned int)zT_47);
    nlen = zT_49;
    zT_51 = cn.child_0;
    cur = zT_51;
    zT_53 = store;
    zT_54 = cur;
    zT_55 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    cw = zT_55;
    goto z_bb_9;
    z_bb_9:
    zT_56 = cw.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if ((unsigned char)(nlen >= (unsigned int)(16))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_74 = cw.kind;
    if ((unsigned char)(zT_74 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_62.has_value = 0;
    return zT_62;
    z_bb_14:
    zT_63 = store;
    zT_64 = cur;
    zT_65 = zF_8BA26B9E_astStoreNodePayload(zT_63, zT_64);
    zT_66 = (unsigned int)nlen;
    names[zT_66] = zT_65;
    zT_67 = 1;
    zT_69 = nlen + (unsigned int)((unsigned int)zT_67);
    nlen = zT_69;
    zT_70 = cw.child_0;
    cur = zT_70;
    zT_71 = store;
    zT_72 = cur;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    cw = zT_73;
    goto z_bb_12;
    z_bb_15:
    zT_78.has_value = 0;
    return zT_78;
    z_bb_16:
    zT_80 = store;
    zT_81 = cur;
    zT_82 = zF_53458827_astStoreIdentifier(zT_80, zT_81);
    base_nid = zT_82;
    cur_mod = module_id;
    zT_84 = sym_reg;
    zT_85 = module_id;
    zT_86 = base_nid;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_84, zT_85, zT_86);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    bs = zT_87.value;
    zT_90 = bs->kind;
    if ((unsigned char)(zT_90 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    i = nlen;
    goto z_bb_22;
    z_bb_19:
    zT_96.has_value = 0;
    return zT_96;
    z_bb_20:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_21:
    zT_95 = bs->module_id;
    cur_mod = zT_95;
    goto z_bb_18;
    z_bb_22:
    if ((unsigned char)(i > (unsigned int)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_100 = 1;
    zT_102 = i - (unsigned int)((unsigned int)zT_100);
    i = zT_102;
    zT_103 = sym_reg;
    zT_104 = cur_mod;
    zT_106 = (unsigned int)i;
    zT_105 = names[zT_106];
    zT_108 = zF_A398987E_symbolRegistryQuali(zT_103, zT_104, zT_105);
    zT_109 = zT_108.has_value;
    if (zT_109) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_118 = sym_reg;
    zT_119 = cur_mod;
    zT_121 = 0;
    zT_120 = names[zT_121];
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_118, zT_119, zT_120);
    zT_124 = zT_123.has_value;
    if (zT_124) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    ms = zT_108.value;
    zT_111 = ms->kind;
    if ((unsigned char)(zT_111 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_117.has_value = 0;
    return zT_117;
    z_bb_29:
    zT_115.has_value = 0;
    return zT_115;
    z_bb_30:
    zT_116 = ms->module_id;
    cur_mod = zT_116;
    goto z_bb_27;
    z_bb_31:
    fs = zT_123.value;
    zT_126 = fs->kind;
    if ((unsigned char)(zT_126 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_33:
    zT_130 = fs->module_id;
    zT_131 = fs->name_id;
    zT_134 = zF_9D041EB6_asyncKey(zT_130, zT_131);
    zT_135.has_value = 1;
    zT_135.value = zT_134;
    return zT_135;
    z_bb_34:
    goto z_bb_32;
}

/* scanFunction */
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int caller_idx, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_B687BB96_U32ArrayList* edge_caller, zT_B687BB96_U32ArrayList* edge_callee, zT_47B162D1_U8ArrayList* direct, zT_A4CE86B7_U64ToU32Map* fn_index, unsigned int async_suspend_name_id) {
    zT_B687BB96_U32ArrayList* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_40;
    zT_3D7259E2_SymbolRegistry* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_BBEE1AC1_Opt_11 zT_45 = {0};
    unsigned char zT_46;
    zT_A4CE86B7_U64ToU32Map* zT_48;
    zT_79FAE712_u64 zT_49;
    zT_BAEE192E_Opt_10 zT_50 = {0};
    unsigned char zT_51;
    zT_B687BB96_U32ArrayList* zT_53;
    unsigned int zT_54;
    zT_B687BB96_U32ArrayList* zT_55;
    unsigned int zT_56;
    zT_B687BB96_U32ArrayList* zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    unsigned int zT_63 = 0;
    unsigned int zT_65;
    zT_B687BB96_U32ArrayList* zT_68;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_74 = 0;
    int zT_75;
    unsigned int zT_77;
    unsigned int zT_81;
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_6B0A7D14_AstStore* zT_87;
    unsigned int zT_88;
    unsigned int zT_89 = 0;
    unsigned int zT_91;
    zT_B687BB96_U32ArrayList* zT_94;
    unsigned int zT_95;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_100 = 0;
    int zT_101;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned char zT_107;
    zT_8143F551_AstKind zT_108;
    unsigned char zT_111 = 0;
    zT_B687BB96_U32ArrayList* zT_112;
    unsigned int zT_113;
    unsigned int zT_115;
    unsigned char zT_118;
    zT_8143F551_AstKind zT_119;
    unsigned char zT_122 = 0;
    zT_B687BB96_U32ArrayList* zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    unsigned char zT_129;
    zT_8143F551_AstKind zT_130;
    unsigned char zT_133 = 0;
    zT_B687BB96_U32ArrayList* zT_134;
    unsigned int zT_135;
    zT_8143F551_AstKind zT_137;
    unsigned char zT_138 = 0;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_144;
    zT_B687BB96_U32ArrayList* zT_147;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int zT_153 = 0;
    int zT_154;
    unsigned int zT_156;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int gi;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = stack;
    zT_15 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_14, zT_15);
    goto z_bb_3;
    z_bb_3:
    zT_16 = stack->len;
    if ((unsigned char)(zT_16 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = stack->items;
    zT_21 = stack->len;
    zT_22 = 1;
    zT_23 = zT_21 - zT_22;
    zT_24 = zT_20[zT_23];
    ni = zT_24;
    zT_25 = stack->len;
    stack->len = (unsigned int)(zT_25 - (unsigned int)(1));
    zT_29 = store;
    zT_30 = ni;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    n = zT_31;
    zT_33 = n.kind;
    k = zT_33;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_37 = n.child_0;
    if ((unsigned char)(zT_37 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_19; else goto z_bb_20;
    z_bb_9:
    zT_40 = store;
    zT_41 = sym_reg;
    zT_42 = module_id;
    zT_43 = n.child_0;
    zT_45 = zF_860C82EC_resolveCalleeKey(zT_40, zT_41, zT_42, zT_43);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_61 = store;
    zT_62 = ni;
    zT_63 = zF_152E19CB_astStoreNodeExtraCh(zT_61, zT_62);
    ec_n = zT_63;
    zT_65 = 0;
    ei = zT_65;
    goto z_bb_15;
    z_bb_11:
    ck = zT_45.value;
    zT_48 = fn_index;
    zT_49 = ck;
    zT_50 = zF_A05A7BE1_u64ToU32MapGet(zT_48, zT_49);
    zT_51 = zT_50.has_value;
    if (zT_51) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_57 = stack;
    zT_58 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_57, zT_58);
    goto z_bb_10;
    z_bb_13:
    gi = zT_50.value;
    zT_53 = edge_caller;
    zT_54 = caller_idx;
    zF_62F717A2_u32ArrayListAppend(zT_53, zT_54);
    zT_55 = edge_callee;
    zT_56 = gi;
    zF_62F717A2_u32ArrayListAppend(zT_55, zT_56);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((unsigned char)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_68 = stack;
    zT_70 = store;
    zT_71 = ni;
    zT_74 = zF_B10B1BC1_astStoreNodeExtraCh(zT_70, zT_71, (unsigned int)((unsigned int)ei));
    zT_69 = zT_74;
    zF_62F717A2_u32ArrayListAppend(zT_68, zT_69);
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_75 = 1;
    zT_77 = ei + (unsigned int)((unsigned int)zT_75);
    ei = zT_77;
    goto z_bb_15;
    z_bb_19:
    zT_81 = n.child_0;
    if ((unsigned char)(zT_81 == async_suspend_name_id)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_104 = n.child_0;
    if ((unsigned char)(zT_104 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    zT_83 = 1;
    zT_84 = direct->items;
    zT_85 = (unsigned int)caller_idx;
    zT_84[zT_85] = zT_83;
    goto z_bb_22;
    z_bb_22:
    zT_87 = store;
    zT_88 = ni;
    zT_89 = zF_152E19CB_astStoreNodeExtraCh(zT_87, zT_88);
    ec2_n = zT_89;
    zT_91 = 0;
    ei2 = zT_91;
    goto z_bb_23;
    z_bb_23:
    if ((unsigned char)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = stack;
    zT_96 = store;
    zT_97 = ni;
    zT_100 = zF_B10B1BC1_astStoreNodeExtraCh(zT_96, zT_97, (unsigned int)((unsigned int)ei2));
    zT_95 = zT_100;
    zF_62F717A2_u32ArrayListAppend(zT_94, zT_95);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_101 = 1;
    zT_103 = ei2 + (unsigned int)((unsigned int)zT_101);
    ei2 = zT_103;
    goto z_bb_23;
    z_bb_27:
    zT_108 = k;
    zT_111 = zF_C395F6FD_nodeChildIsNode(zT_108, (unsigned char)(0));
    zT_107 = zT_111;
    goto z_bb_29;
    z_bb_28:
    zT_107 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_107) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_112 = stack;
    zT_113 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_112, zT_113);
    goto z_bb_31;
    z_bb_31:
    zT_115 = n.child_1;
    if ((unsigned char)(zT_115 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_119 = k;
    zT_122 = zF_C395F6FD_nodeChildIsNode(zT_119, (unsigned char)(1));
    zT_118 = zT_122;
    goto z_bb_34;
    z_bb_33:
    zT_118 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_118) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_123 = stack;
    zT_124 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_123, zT_124);
    goto z_bb_36;
    z_bb_36:
    zT_126 = n.child_2;
    if ((unsigned char)(zT_126 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_130 = k;
    zT_133 = zF_C395F6FD_nodeChildIsNode(zT_130, (unsigned char)(2));
    zT_129 = zT_133;
    goto z_bb_39;
    z_bb_38:
    zT_129 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_129) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_134 = stack;
    zT_135 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_134, zT_135);
    goto z_bb_41;
    z_bb_41:
    zT_137 = k;
    zT_138 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_137);
    if (zT_138) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_140 = store;
    zT_141 = ni;
    zT_142 = zF_152E19CB_astStoreNodeExtraCh(zT_140, zT_141);
    ec3_n = zT_142;
    zT_144 = 0;
    ei3 = zT_144;
    goto z_bb_44;
    z_bb_43:
    goto z_bb_6;
    z_bb_44:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_147 = stack;
    zT_149 = store;
    zT_150 = ni;
    zT_153 = zF_B10B1BC1_astStoreNodeExtraCh(zT_149, zT_150, (unsigned int)((unsigned int)ei3));
    zT_148 = zT_153;
    zF_62F717A2_u32ArrayListAppend(zT_147, zT_148);
    goto z_bb_47;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_154 = 1;
    zT_156 = ei3 + (unsigned int)((unsigned int)zT_154);
    ei3 = zT_156;
    goto z_bb_44;
}

/* emitSuspMarker */
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64 key) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_5826BFC7_Arr_unsigned_char_1 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_5826BFC7_Arr_unsigned_char_1 zT_44;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54 = 0;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_4 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_4;
    zT_8 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_8;
    zT_10 = "SUSP:m";
    zT_12 = 6;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    m1 = zT_11;
    zT_13 = m1;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = module_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)b1) + zT_21;
    zT_23 = (unsigned int)(12) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    l1 = zT_25;
    zT_30 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_36 = (unsigned int)(11) - s1;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = ":n";
    zT_41 = 2;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    m2 = zT_40;
    zT_42 = m2;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = name_id;
    zT_50 = 0;
    zT_51 = (unsigned char*)((unsigned char*)b2) + zT_50;
    zT_52 = (unsigned int)(12) - zT_50;
    zT_53.ptr = zT_51;
    zT_53.len = zT_52;
    zT_47 = zT_53;
    zT_54 = zF_A7504564_itoa(zT_46, zT_47);
    l2 = zT_54;
    zT_59 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_59;
    zT_64 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_65 = (unsigned int)(11) - s2;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_60 = zT_66;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_68 = "\n";
    zT_70 = 1;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    m3 = zT_69;
    zT_71 = m3;
    zF_48AC7B3A_markerWrite(zT_71);
    return;
}

/* suspensionAnalysisRun */
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_072B53A6_ModuleRegistry* module_reg, zT_D3EB6303_StringInterner* interner, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_C4A0A7DB_U64ArrayList zT_26 = {0};
    zT_3E40CD83_Sand* zT_28;
    zT_47B162D1_U8ArrayList zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_B687BB96_U32ArrayList zT_32 = {0};
    zT_3E40CD83_Sand* zT_34;
    zT_B687BB96_U32ArrayList zT_35 = {0};
    zT_072B53A6_ModuleRegistry* zT_37;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_53 = {0};
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_61 = 0;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_71 = 0;
    zT_6B0A7D14_AstStore* zT_73;
    unsigned int zT_74;
    zT_22A7C88B_AstNode zT_75 = {0};
    zT_8143F551_AstKind zT_76;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_83 = 0;
    zT_9C1673CC_anon_238694 zT_85;
    zT_243D6A41_FnProto* zT_86;
    unsigned int zT_87;
    zT_243D6A41_FnProto zT_88;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    zT_79FAE712_u64 zT_96 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_97;
    zT_79FAE712_u64 zT_98;
    zT_BAEE192E_Opt_10 zT_100 = {0};
    unsigned char zT_101;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    unsigned int zT_107;
    zT_C4A0A7DB_U64ArrayList* zT_109;
    zT_79FAE712_u64 zT_110;
    zT_47B162D1_U8ArrayList* zT_112;
    int zT_116;
    unsigned int zT_118;
    int zT_119;
    unsigned int zT_121;
    zT_3E40CD83_Sand* zT_123;
    zT_B687BB96_U32ArrayList zT_124 = {0};
    unsigned int zT_125;
    unsigned int zT_127;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_132;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    zT_22A7C88B_AstNode zT_138 = {0};
    zT_8143F551_AstKind zT_139;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    unsigned int zT_146 = 0;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_152;
    unsigned int zT_153;
    unsigned int zT_156 = 0;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    zT_22A7C88B_AstNode zT_160 = {0};
    zT_8143F551_AstKind zT_161;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_168 = 0;
    zT_9C1673CC_anon_238694 zT_170;
    zT_243D6A41_FnProto* zT_171;
    unsigned int zT_172;
    zT_243D6A41_FnProto zT_173;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_6E8D187B_ModuleEntry* zT_177;
    zT_6E8D187B_ModuleEntry zT_178;
    zT_79FAE712_u64 zT_181 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_183;
    zT_79FAE712_u64 zT_184;
    zT_BAEE192E_Opt_10 zT_186 = {0};
    unsigned char zT_187;
    zT_6B0A7D14_AstStore* zT_189;
    zT_3D7259E2_SymbolRegistry* zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_B687BB96_U32ArrayList* zT_194;
    zT_B687BB96_U32ArrayList* zT_195;
    zT_B687BB96_U32ArrayList* zT_196;
    zT_47B162D1_U8ArrayList* zT_197;
    zT_A4CE86B7_U64ToU32Map* zT_198;
    unsigned int zT_199;
    zT_6E8D187B_ModuleEntry* zT_200;
    zT_6E8D187B_ModuleEntry zT_201;
    int zT_209;
    unsigned int zT_211;
    int zT_212;
    unsigned int zT_214;
    unsigned int zT_216;
    zT_3E40CD83_Sand* zT_220;
    unsigned int zT_221;
    unsigned int* zT_222 = 0;
    unsigned int zT_224;
    unsigned int zT_226;
    int zT_227;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned int zT_241;
    int zT_242;
    unsigned int zT_244;
    zT_3E40CD83_Sand* zT_246;
    unsigned int* zT_250 = 0;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_255;
    unsigned int zT_256;
    int zT_257;
    unsigned int zT_259;
    zT_3E40CD83_Sand* zT_261;
    unsigned int zT_262;
    unsigned int* zT_263 = 0;
    unsigned int zT_264;
    unsigned int zT_266;
    int zT_267;
    unsigned int zT_269;
    zT_3E40CD83_Sand* zT_271;
    unsigned int zT_272;
    unsigned int* zT_274 = 0;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int* zT_279;
    unsigned int zT_280;
    unsigned int zT_282;
    unsigned int zT_283;
    unsigned int* zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    unsigned int zT_289;
    int zT_290;
    unsigned int zT_292;
    zT_3E40CD83_Sand* zT_294;
    unsigned int zT_295;
    unsigned int* zT_296 = 0;
    unsigned int zT_298;
    unsigned int zT_300;
    unsigned int zT_301;
    unsigned char* zT_303;
    unsigned char zT_304;
    zT_A4CE86B7_U64ToU32Map* zT_307;
    zT_79FAE712_u64 zT_308;
    zT_79FAE712_u64* zT_310;
    unsigned int zT_313;
    unsigned int zT_315;
    int zT_316;
    unsigned int zT_318;
    unsigned int zT_321;
    unsigned int zT_323;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_335;
    unsigned int zT_336;
    zT_79FAE712_u64* zT_338;
    unsigned int zT_339;
    zT_79FAE712_u64 zT_340;
    zT_A4CE86B7_U64ToU32Map* zT_341;
    zT_79FAE712_u64 zT_342;
    zT_BAEE192E_Opt_10 zT_343 = {0};
    unsigned char zT_344;
    zT_A4CE86B7_U64ToU32Map* zT_346;
    zT_79FAE712_u64 zT_347;
    unsigned int zT_351;
    unsigned int zT_353;
    unsigned int zT_355;
    unsigned int zT_356;
    zT_79FAE712_u64* zT_359;
    zT_79FAE712_u64 zT_360;
    zT_A4CE86B7_U64ToU32Map* zT_362;
    zT_79FAE712_u64 zT_363;
    zT_BAEE192E_Opt_10 zT_364 = {0};
    unsigned char zT_365;
    zT_79FAE712_u64 zT_369;
    int zT_370;
    unsigned int zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_A4CE86B7_U64ToU32Map fn_index;
    zT_C4A0A7DB_U64ArrayList fn_keys;
    zT_47B162D1_U8ArrayList direct;
    zT_B687BB96_U32ArrayList edge_caller;
    zT_B687BB96_U32ArrayList edge_callee;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_B687BB96_U32ArrayList stack;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned int ast_root2;
    unsigned int n;
    zT_22A7C88B_AstNode root2;
    unsigned int decls2_n;
    unsigned int di2;
    unsigned int decl2_idx;
    zT_22A7C88B_AstNode decl2;
    unsigned int proto_idx2;
    zT_243D6A41_FnProto proto2;
    zT_79FAE712_u64 key2;
    zT_BAEE192E_Opt_10 cidx;
    unsigned int ci0;
    unsigned int* rev_count;
    unsigned int i;
    unsigned int m;
    unsigned int e;
    unsigned int g;
    unsigned int* rev_off;
    unsigned int acc;
    unsigned int* rev_pos;
    unsigned int* rev_to;
    unsigned int g2;
    unsigned int p;
    unsigned int* queue;
    unsigned int head;
    unsigned int tail;
    unsigned int g3;
    unsigned int k0;
    unsigned int k1;
    unsigned int kk;
    unsigned int c;
    zT_79FAE712_u64 ckey;
    zT_79FAE712_u64 kk2;
    zT_BAEE192E_Opt_10 vv;
    unsigned int val2;
    zT_7 = "YA\n";
    zT_9 = 3;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    p_msg = zT_8;
    zT_10 = p_msg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = "@asyncSuspend";
    zT_14 = 13;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    asu_text = zT_13;
    zT_16 = interner;
    zT_17 = asu_text;
    zT_18 = zF_50C274AF_stringInternerInter(zT_16, zT_17);
    async_suspend_name_id = zT_18;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    fn_index = zT_21;
    zT_23 = alloc;
    zT_26 = zF_477F0605_u64ArrayListInit(zT_23, (unsigned int)(256));
    fn_keys = zT_26;
    zT_28 = alloc;
    zT_29 = zF_E9FF0E66_byteArrayListInit(zT_28);
    direct = zT_29;
    zT_31 = alloc;
    zT_32 = zF_8E537D0C_u32ArrayListInit(zT_31);
    edge_caller = zT_32;
    zT_34 = alloc;
    zT_35 = zF_8E537D0C_u32ArrayListInit(zT_34);
    edge_callee = zT_35;
    zT_37 = module_reg;
    zT_38 = zF_3452C137_moduleRegistryGetMo(zT_37);
    mods = zT_38;
    zT_40 = 0;
    mi = zT_40;
    goto z_bb_1;
    z_bb_1:
    zT_42 = mods.len;
    if ((unsigned char)(mi < zT_42)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_45 = mods.ptr;
    zT_46 = zT_45[mi];
    zT_47 = zT_46.ast_root;
    ast_root = zT_47;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_123 = alloc;
    zT_124 = zF_8E537D0C_u32ArrayListInit(zT_123);
    stack = zT_124;
    zT_125 = 0;
    mi = zT_125;
    goto z_bb_17;
    z_bb_4:
    zT_119 = 1;
    zT_121 = mi + (unsigned int)((unsigned int)zT_119);
    mi = zT_121;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_51 = store;
    zT_52 = ast_root;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    root = zT_53;
    zT_54 = root.kind;
    if ((unsigned char)(zT_54 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_59 = store;
    zT_60 = ast_root;
    zT_61 = zF_152E19CB_astStoreNodeExtraCh(zT_59, zT_60);
    decls_n = zT_61;
    zT_63 = 0;
    di = zT_63;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_67 = store;
    zT_68 = ast_root;
    zT_71 = zF_B10B1BC1_astStoreNodeExtraCh(zT_67, zT_68, (unsigned int)((unsigned int)di));
    decl_idx = zT_71;
    zT_73 = store;
    zT_74 = decl_idx;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_73, zT_74);
    decl = zT_75;
    zT_76 = decl.kind;
    if ((unsigned char)(zT_76 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_116 = 1;
    zT_118 = di + (unsigned int)((unsigned int)zT_116);
    di = zT_118;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_81 = store;
    zT_82 = decl_idx;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_81, zT_82);
    proto_idx = zT_83;
    zT_85 = store->fn_protos;
    zT_86 = zT_85.items;
    zT_87 = (unsigned int)proto_idx;
    zT_88 = zT_86[zT_87];
    proto = zT_88;
    zT_92 = mods.ptr;
    zT_93 = zT_92[mi];
    zT_90 = zT_93.id;
    zT_91 = proto.name_id;
    zT_96 = zF_9D041EB6_asyncKey(zT_90, zT_91);
    key = zT_96;
    zT_97 = &fn_index;
    zT_98 = key;
    zT_100 = zF_A05A7BE1_u64ToU32MapGet(zT_97, zT_98);
    zT_101 = zT_100.has_value;
    if ((unsigned char)(!zT_101)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_103 = &fn_index;
    zT_104 = key;
    zT_107 = fn_keys.len;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, (unsigned int)((unsigned int)zT_107));
    zT_109 = &fn_keys;
    zT_110 = key;
    zF_A553AD3B_u64ArrayListAppend(zT_109, zT_110);
    zT_112 = &direct;
    zF_463FE7A4_byteArrayListAppend(zT_112, (unsigned char)(0));
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    zT_127 = mods.len;
    if ((unsigned char)(mi < zT_127)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_130 = mods.ptr;
    zT_131 = zT_130[mi];
    zT_132 = zT_131.ast_root;
    ast_root2 = zT_132;
    if ((unsigned char)(ast_root2 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_216 = fn_keys.len;
    n = zT_216;
    if ((unsigned char)(n > (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_20:
    zT_212 = 1;
    zT_214 = mi + (unsigned int)((unsigned int)zT_212);
    mi = zT_214;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_136 = store;
    zT_137 = ast_root2;
    zT_138 = zF_FCDD1D35_astStoreNodeAt(zT_136, zT_137);
    root2 = zT_138;
    zT_139 = root2.kind;
    if ((unsigned char)(zT_139 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_144 = store;
    zT_145 = ast_root2;
    zT_146 = zF_152E19CB_astStoreNodeExtraCh(zT_144, zT_145);
    decls2_n = zT_146;
    zT_148 = 0;
    di2 = zT_148;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(di2 < (unsigned int)((unsigned int)decls2_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_152 = store;
    zT_153 = ast_root2;
    zT_156 = zF_B10B1BC1_astStoreNodeExtraCh(zT_152, zT_153, (unsigned int)((unsigned int)di2));
    decl2_idx = zT_156;
    zT_158 = store;
    zT_159 = decl2_idx;
    zT_160 = zF_FCDD1D35_astStoreNodeAt(zT_158, zT_159);
    decl2 = zT_160;
    zT_161 = decl2.kind;
    if ((unsigned char)(zT_161 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_209 = 1;
    zT_211 = di2 + (unsigned int)((unsigned int)zT_209);
    di2 = zT_211;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_166 = store;
    zT_167 = decl2_idx;
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_166, zT_167);
    proto_idx2 = zT_168;
    zT_170 = store->fn_protos;
    zT_171 = zT_170.items;
    zT_172 = (unsigned int)proto_idx2;
    zT_173 = zT_171[zT_172];
    proto2 = zT_173;
    zT_177 = mods.ptr;
    zT_178 = zT_177[mi];
    zT_175 = zT_178.id;
    zT_176 = proto2.name_id;
    zT_181 = zF_9D041EB6_asyncKey(zT_175, zT_176);
    key2 = zT_181;
    zT_183 = &fn_index;
    zT_184 = key2;
    zT_186 = zF_A05A7BE1_u64ToU32MapGet(zT_183, zT_184);
    cidx = zT_186;
    zT_187 = cidx.has_value;
    if (zT_187) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    ci0 = cidx.value;
    zT_189 = store;
    zT_190 = sym_reg;
    zT_200 = mods.ptr;
    zT_201 = zT_200[mi];
    zT_191 = zT_201.id;
    zT_192 = ci0;
    zT_193 = decl2.child_0;
    zT_194 = &stack;
    zT_195 = &edge_caller;
    zT_196 = &edge_callee;
    zT_197 = &direct;
    zT_198 = &fn_index;
    zT_199 = async_suspend_name_id;
    zF_32651930_scanFunction(zT_189, zT_190, zT_191, zT_192, zT_193, zT_194, zT_195, zT_196, zT_197, zT_198, zT_199);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_220 = alloc;
    zT_221 = n;
    zT_222 = zF_43BEEDA4_allocU32(zT_220, zT_221);
    rev_count = zT_222;
    zT_224 = 0;
    i = zT_224;
    goto z_bb_35;
    z_bb_34:
    zT_355 = 0;
    m = zT_355;
    goto z_bb_71;
    z_bb_35:
    if ((unsigned char)(i < n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_226 = 0;
    rev_count[i] = zT_226;
    goto z_bb_38;
    z_bb_37:
    zT_231 = 0;
    e = zT_231;
    goto z_bb_39;
    z_bb_38:
    zT_227 = 1;
    zT_229 = i + (unsigned int)((unsigned int)zT_227);
    i = zT_229;
    goto z_bb_35;
    z_bb_39:
    zT_232 = edge_callee.len;
    if ((unsigned char)(e < zT_232)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_235 = edge_callee.items;
    zT_236 = zT_235[e];
    g = zT_236;
    zT_237 = (unsigned int)g;
    zT_238 = rev_count[zT_237];
    zT_240 = zT_238 + (unsigned int)(1);
    zT_241 = (unsigned int)g;
    rev_count[zT_241] = zT_240;
    goto z_bb_42;
    z_bb_41:
    zT_246 = alloc;
    zT_250 = zF_43BEEDA4_allocU32(zT_246, (unsigned int)(n + (unsigned int)(1)));
    rev_off = zT_250;
    zT_252 = 0;
    acc = zT_252;
    zT_253 = 0;
    i = zT_253;
    goto z_bb_43;
    z_bb_42:
    zT_242 = 1;
    zT_244 = e + (unsigned int)((unsigned int)zT_242);
    e = zT_244;
    goto z_bb_39;
    z_bb_43:
    if ((unsigned char)(i < n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    rev_off[i] = acc;
    zT_255 = rev_count[i];
    zT_256 = acc + zT_255;
    acc = zT_256;
    goto z_bb_46;
    z_bb_45:
    rev_off[n] = acc;
    zT_261 = alloc;
    zT_262 = n;
    zT_263 = zF_43BEEDA4_allocU32(zT_261, zT_262);
    rev_pos = zT_263;
    zT_264 = 0;
    i = zT_264;
    goto z_bb_47;
    z_bb_46:
    zT_257 = 1;
    zT_259 = i + (unsigned int)((unsigned int)zT_257);
    i = zT_259;
    goto z_bb_43;
    z_bb_47:
    if ((unsigned char)(i < n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_266 = rev_off[i];
    rev_pos[i] = zT_266;
    goto z_bb_50;
    z_bb_49:
    zT_271 = alloc;
    zT_272 = edge_callee.len;
    zT_274 = zF_43BEEDA4_allocU32(zT_271, zT_272);
    rev_to = zT_274;
    zT_275 = 0;
    e = zT_275;
    goto z_bb_51;
    z_bb_50:
    zT_267 = 1;
    zT_269 = i + (unsigned int)((unsigned int)zT_267);
    i = zT_269;
    goto z_bb_47;
    z_bb_51:
    zT_276 = edge_callee.len;
    if ((unsigned char)(e < zT_276)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_279 = edge_callee.items;
    zT_280 = zT_279[e];
    g2 = zT_280;
    zT_282 = (unsigned int)g2;
    zT_283 = rev_pos[zT_282];
    p = zT_283;
    zT_284 = edge_caller.items;
    zT_285 = zT_284[e];
    zT_286 = (unsigned int)p;
    rev_to[zT_286] = zT_285;
    zT_288 = p + (unsigned int)(1);
    zT_289 = (unsigned int)g2;
    rev_pos[zT_289] = zT_288;
    goto z_bb_54;
    z_bb_53:
    zT_294 = alloc;
    zT_295 = n;
    zT_296 = zF_43BEEDA4_allocU32(zT_294, zT_295);
    queue = zT_296;
    zT_298 = 0;
    head = zT_298;
    zT_300 = 0;
    tail = zT_300;
    zT_301 = 0;
    i = zT_301;
    goto z_bb_55;
    z_bb_54:
    zT_290 = 1;
    zT_292 = e + (unsigned int)((unsigned int)zT_290);
    e = zT_292;
    goto z_bb_51;
    z_bb_55:
    if ((unsigned char)(i < n)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_303 = direct.items;
    zT_304 = zT_303[i];
    if ((unsigned char)(zT_304 != (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    goto z_bb_61;
    z_bb_58:
    zT_316 = 1;
    zT_318 = i + (unsigned int)((unsigned int)zT_316);
    i = zT_318;
    goto z_bb_55;
    z_bb_59:
    zT_307 = suspending_fns;
    zT_310 = fn_keys.items;
    zT_308 = zT_310[i];
    zF_B6EB812C_u64ToU32MapPut(zT_307, zT_308, (unsigned int)(1));
    zT_313 = (unsigned int)i;
    queue[tail] = zT_313;
    zT_315 = tail + (unsigned int)(1);
    tail = zT_315;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    if ((unsigned char)(head < tail)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_321 = queue[head];
    g3 = zT_321;
    zT_323 = head + (unsigned int)(1);
    head = zT_323;
    zT_325 = (unsigned int)g3;
    zT_326 = rev_off[zT_325];
    k0 = zT_326;
    zT_330 = (unsigned int)((unsigned int)g3) + (unsigned int)(1);
    zT_331 = rev_off[zT_330];
    k1 = zT_331;
    kk = k0;
    goto z_bb_65;
    z_bb_63:
    goto z_bb_34;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    if ((unsigned char)(kk < k1)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_335 = (unsigned int)kk;
    zT_336 = rev_to[zT_335];
    c = zT_336;
    zT_338 = fn_keys.items;
    zT_339 = (unsigned int)c;
    zT_340 = zT_338[zT_339];
    ckey = zT_340;
    zT_341 = suspending_fns;
    zT_342 = ckey;
    zT_343 = zF_A05A7BE1_u64ToU32MapGet(zT_341, zT_342);
    zT_344 = zT_343.has_value;
    if ((unsigned char)(!zT_344)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_353 = kk + (unsigned int)(1);
    kk = zT_353;
    goto z_bb_65;
    z_bb_69:
    zT_346 = suspending_fns;
    zT_347 = ckey;
    zF_B6EB812C_u64ToU32MapPut(zT_346, zT_347, (unsigned int)(1));
    queue[tail] = c;
    zT_351 = tail + (unsigned int)(1);
    tail = zT_351;
    goto z_bb_70;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_356 = fn_keys.len;
    if ((unsigned char)(m < zT_356)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_359 = fn_keys.items;
    zT_360 = zT_359[m];
    kk2 = zT_360;
    zT_362 = suspending_fns;
    zT_363 = kk2;
    zT_364 = zF_A05A7BE1_u64ToU32MapGet(zT_362, zT_363);
    vv = zT_364;
    zT_365 = vv.has_value;
    if (zT_365) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return;
    z_bb_74:
    zT_370 = 1;
    zT_372 = m + (unsigned int)((unsigned int)zT_370);
    m = zT_372;
    goto z_bb_71;
    z_bb_75:
    val2 = vv.value;
    if ((unsigned char)(val2 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_369 = kk2;
    zF_76D5E8D3_emitSuspMarker(zT_369);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* frameFieldSizeAlign */
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    zT_19 = t.alignment;
    if ((unsigned char)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_22 = t.alignment;
    al = zT_22;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* addFrameField */
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    unsigned int at;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_8 = reg;
    zT_9 = tid;
    zT_10 = &sz;
    zT_11 = &al;
    zF_816D1610_frameFieldSizeAlign(zT_8, zT_9, zT_10, zT_11);
    zT_14 = *offset;
    zT_15 = al;
    zT_17 = zF_978D7C93_alignUpU32(zT_14, zT_15);
    *offset = zT_17;
    zT_19 = *offset;
    at = zT_19;
    zT_20 = *offset;
    *offset = (unsigned int)(zT_20 + sz);
    zT_22 = *max_align;
    if ((unsigned char)(al > zT_22)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = al;
    goto z_bb_2;
    z_bb_2:
    return at;
}

/* typeIsPtrVoid */
unsigned char zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_112BF819_PtrPayload zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_16 = reg->ptr_items;
    zT_17 = t.payload_idx;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zT_16[zT_18];
    zT_20 = zT_19.base;
    base = zT_20;
    return (unsigned char)(base == (unsigned int)(1));
}

/* frameLocalTypeId */
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable* resolved_types, zT_22A7C88B_AstNode n) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned int t;
    zT_2 = n.child_0;
    if ((unsigned char)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_5 = resolved_types;
    zT_6 = n.child_0;
    zT_8 = zF_999DCF51_resolvedTypeTableGe(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    return (unsigned int)(18);
    z_bb_3:
    zT_11 = n.child_1;
    if ((unsigned char)(zT_11 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    t = zT_8.value;
    return t;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_14 = resolved_types;
    zT_15 = n.child_1;
    zT_17 = zF_999DCF51_resolvedTypeTableGe(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_2;
    z_bb_8:
    t = zT_17.value;
    return t;
    z_bb_9:
    goto z_bb_7;
}

/* scanFrameLocals */
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore* store, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_338B7C76_TypeRegistry* reg, zT_8EED1867_ResolvedTypeTable* resolved_types, unsigned int* offset, unsigned int* max_align) {
    zT_B687BB96_U32ArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_29;
    unsigned int zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_34 = {0};
    unsigned char zT_35;
    unsigned char zT_39;
    zT_8EED1867_ResolvedTypeTable* zT_43;
    zT_22A7C88B_AstNode zT_44;
    unsigned int zT_45 = 0;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int* zT_49;
    unsigned int zT_50 = 0;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_57 = 0;
    unsigned int zT_59;
    unsigned int zT_63;
    zT_B687BB96_U32ArrayList* zT_64;
    unsigned int zT_65;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    unsigned int zT_70 = 0;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_77 = 0;
    unsigned int zT_79;
    unsigned int zT_83;
    zT_B687BB96_U32ArrayList* zT_84;
    unsigned int zT_85;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    unsigned int zT_90 = 0;
    unsigned int zT_91;
    zT_B687BB96_U32ArrayList* zT_94;
    unsigned int zT_95;
    zT_8143F551_AstKind zT_97;
    unsigned char zT_98 = 0;
    zT_6B0A7D14_AstStore* zT_100;
    unsigned int zT_101;
    unsigned int zT_102 = 0;
    unsigned int zT_104;
    unsigned int zT_108;
    zT_B687BB96_U32ArrayList* zT_109;
    unsigned int zT_110;
    zT_6B0A7D14_AstStore* zT_111;
    unsigned int zT_112;
    unsigned int zT_115 = 0;
    unsigned int zT_116;
    unsigned char zT_119;
    zT_8143F551_AstKind zT_120;
    unsigned char zT_123 = 0;
    zT_B687BB96_U32ArrayList* zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    unsigned char zT_134 = 0;
    zT_B687BB96_U32ArrayList* zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    unsigned char zT_141;
    zT_8143F551_AstKind zT_142;
    unsigned char zT_145 = 0;
    zT_B687BB96_U32ArrayList* zT_146;
    unsigned int zT_147;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int lvt;
    unsigned int t;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = stack;
    zT_11 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_10, zT_11);
    goto z_bb_3;
    z_bb_3:
    zT_12 = stack->len;
    if ((unsigned char)(zT_12 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = stack->items;
    zT_17 = stack->len;
    zT_19 = zT_17 - (unsigned int)(1);
    zT_20 = zT_16[zT_19];
    ni = zT_20;
    zT_21 = stack->len;
    stack->len = (unsigned int)(zT_21 - (unsigned int)(1));
    zT_25 = store;
    zT_26 = ni;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    n = zT_27;
    zT_29 = n.kind;
    k = zT_29;
    zT_31 = 18;
    lvt = zT_31;
    zT_32 = resolved_types;
    zT_33 = ni;
    zT_34 = zF_999DCF51_resolvedTypeTableGe(zT_32, zT_33);
    zT_35 = zT_34.has_value;
    if (zT_35) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    t = zT_34.value;
    lvt = t;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(lvt == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_11;
    z_bb_10:
    zT_39 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_43 = resolved_types;
    zT_44 = n;
    zT_45 = zF_436F92E0_frameLocalTypeId(zT_43, zT_44);
    lvt = zT_45;
    goto z_bb_13;
    z_bb_13:
    zT_46 = reg;
    zT_47 = lvt;
    zT_48 = offset;
    zT_49 = max_align;
    zT_50 = zF_769CB99B_addFrameField(zT_46, zT_47, zT_48, zT_49);
    (void)zT_50;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_55 = store;
    zT_56 = ni;
    zT_57 = zF_152E19CB_astStoreNodeExtraCh(zT_55, zT_56);
    ecb_n = zT_57;
    zT_59 = (unsigned int)ecb_n;
    bi = zT_59;
    goto z_bb_16;
    z_bb_15:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_20; else goto z_bb_21;
    z_bb_16:
    if ((unsigned char)(bi > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_63 = bi - (unsigned int)(1);
    bi = zT_63;
    zT_64 = stack;
    zT_66 = store;
    zT_67 = ni;
    zT_70 = zF_B10B1BC1_astStoreNodeExtraCh(zT_66, zT_67, (unsigned int)((unsigned int)bi));
    zT_65 = zT_70;
    zF_62F717A2_u32ArrayListAppend(zT_64, zT_65);
    goto z_bb_19;
    z_bb_18:
    goto z_bb_6;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_75 = store;
    zT_76 = ni;
    zT_77 = zF_152E19CB_astStoreNodeExtraCh(zT_75, zT_76);
    ecf_n = zT_77;
    zT_79 = (unsigned int)ecf_n;
    fi = zT_79;
    goto z_bb_22;
    z_bb_21:
    zT_97 = k;
    zT_98 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_97);
    if (zT_98) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    if ((unsigned char)(fi > (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_83 = fi - (unsigned int)(1);
    fi = zT_83;
    zT_84 = stack;
    zT_86 = store;
    zT_87 = ni;
    zT_90 = zF_B10B1BC1_astStoreNodeExtraCh(zT_86, zT_87, (unsigned int)((unsigned int)fi));
    zT_85 = zT_90;
    zF_62F717A2_u32ArrayListAppend(zT_84, zT_85);
    goto z_bb_25;
    z_bb_24:
    zT_91 = n.child_0;
    if ((unsigned char)(zT_91 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_94 = stack;
    zT_95 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_94, zT_95);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_100 = store;
    zT_101 = ni;
    zT_102 = zF_152E19CB_astStoreNodeExtraCh(zT_100, zT_101);
    ec3_n = zT_102;
    zT_104 = (unsigned int)ec3_n;
    ei3 = zT_104;
    goto z_bb_30;
    z_bb_29:
    zT_116 = n.child_2;
    if ((unsigned char)(zT_116 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((unsigned char)(ei3 > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_108 = ei3 - (unsigned int)(1);
    ei3 = zT_108;
    zT_109 = stack;
    zT_111 = store;
    zT_112 = ni;
    zT_115 = zF_B10B1BC1_astStoreNodeExtraCh(zT_111, zT_112, (unsigned int)((unsigned int)ei3));
    zT_110 = zT_115;
    zF_62F717A2_u32ArrayListAppend(zT_109, zT_110);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_120 = k;
    zT_123 = zF_C395F6FD_nodeChildIsNode(zT_120, (unsigned char)(2));
    zT_119 = zT_123;
    goto z_bb_36;
    z_bb_35:
    zT_119 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_119) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_124 = stack;
    zT_125 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_124, zT_125);
    goto z_bb_38;
    z_bb_38:
    zT_127 = n.child_1;
    if ((unsigned char)(zT_127 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_131 = k;
    zT_134 = zF_C395F6FD_nodeChildIsNode(zT_131, (unsigned char)(1));
    zT_130 = zT_134;
    goto z_bb_41;
    z_bb_40:
    zT_130 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_130) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_135 = stack;
    zT_136 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_135, zT_136);
    goto z_bb_43;
    z_bb_43:
    zT_138 = n.child_0;
    if ((unsigned char)(zT_138 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_142 = k;
    zT_145 = zF_C395F6FD_nodeChildIsNode(zT_142, (unsigned char)(0));
    zT_141 = zT_145;
    goto z_bb_46;
    z_bb_45:
    zT_141 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_141) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_146 = stack;
    zT_147 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_146, zT_147);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_6;
}

/* scanImplicitAwaits */
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, zT_79FAE712_u64 caller_key, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* fn_ret_types, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* hidden_fns, zT_B687BB96_U32ArrayList* parent_type_list, zT_A4CE86B7_U64ToU32Map* parent_start, zT_A4CE86B7_U64ToU32Map* parent_count) {
    zT_B687BB96_U32ArrayList* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33 = {0};
    zT_8143F551_AstKind zT_35;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_42;
    zT_3D7259E2_SymbolRegistry* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_BBEE1AC1_Opt_11 zT_47 = {0};
    unsigned char zT_48;
    unsigned int zT_53;
    unsigned int zT_57;
    zT_A4CE86B7_U64ToU32Map* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_61 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_62;
    zT_79FAE712_u64 zT_63;
    unsigned int zT_67;
    zT_A4CE86B7_U64ToU32Map* zT_68;
    zT_79FAE712_u64 zT_69;
    zT_BAEE192E_Opt_10 zT_70 = {0};
    unsigned char zT_71;
    unsigned int zT_74;
    unsigned int zT_76;
    zT_A4CE86B7_U64ToU32Map* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_79 = {0};
    unsigned char zT_80;
    unsigned int zT_85;
    unsigned int zT_87;
    zT_A4CE86B7_U64ToU32Map* zT_88;
    zT_79FAE712_u64 zT_89;
    zT_BAEE192E_Opt_10 zT_90 = {0};
    unsigned char zT_91;
    zT_A4CE86B7_U64ToU32Map* zT_95;
    zT_79FAE712_u64 zT_96;
    unsigned int zT_98;
    zT_B687BB96_U32ArrayList* zT_100;
    unsigned int zT_101;
    zT_A4CE86B7_U64ToU32Map* zT_102;
    zT_79FAE712_u64 zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_109;
    zT_B687BB96_U32ArrayList* zT_110;
    unsigned int zT_111;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int zT_116 = 0;
    unsigned int zT_118;
    zT_B687BB96_U32ArrayList* zT_121;
    unsigned int zT_122;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    unsigned int zT_127 = 0;
    int zT_128;
    unsigned int zT_130;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_136;
    unsigned int zT_137 = 0;
    unsigned int zT_139;
    zT_B687BB96_U32ArrayList* zT_142;
    unsigned int zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    unsigned int zT_148 = 0;
    int zT_149;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned char zT_155;
    zT_8143F551_AstKind zT_156;
    unsigned char zT_159 = 0;
    zT_B687BB96_U32ArrayList* zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    unsigned char zT_166;
    zT_8143F551_AstKind zT_167;
    unsigned char zT_170 = 0;
    zT_B687BB96_U32ArrayList* zT_171;
    unsigned int zT_172;
    unsigned int zT_174;
    unsigned char zT_177;
    zT_8143F551_AstKind zT_178;
    unsigned char zT_181 = 0;
    zT_B687BB96_U32ArrayList* zT_182;
    unsigned int zT_183;
    zT_8143F551_AstKind zT_185;
    unsigned char zT_186 = 0;
    zT_6B0A7D14_AstStore* zT_188;
    unsigned int zT_189;
    unsigned int zT_190 = 0;
    unsigned int zT_192;
    zT_B687BB96_U32ArrayList* zT_195;
    unsigned int zT_196;
    zT_6B0A7D14_AstStore* zT_197;
    unsigned int zT_198;
    unsigned int zT_201 = 0;
    int zT_202;
    unsigned int zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    zT_79FAE712_u64 zT_206;
    zT_BAEE192E_Opt_10 zT_207 = {0};
    unsigned char zT_208;
    zT_A4CE86B7_U64ToU32Map* zT_212;
    zT_79FAE712_u64 zT_213;
    zT_BAEE192E_Opt_10 zT_214 = {0};
    unsigned char zT_215;
    unsigned int zT_218;
    unsigned int zT_220;
    unsigned int* zT_225;
    unsigned int zT_226;
    unsigned int* zT_227;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int* zT_231;
    unsigned int* zT_232;
    unsigned int zT_234;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int hf;
    unsigned int old;
    unsigned int rt;
    unsigned int r;
    unsigned int pc;
    unsigned int oldc;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    unsigned int ps;
    unsigned int lo;
    unsigned int hi;
    unsigned int tmp;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_16 = stack;
    zT_17 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_16, zT_17);
    goto z_bb_3;
    z_bb_3:
    zT_18 = stack->len;
    if ((unsigned char)(zT_18 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = stack->items;
    zT_23 = stack->len;
    zT_25 = zT_23 - (unsigned int)(1);
    zT_26 = zT_22[zT_25];
    ni = zT_26;
    zT_27 = stack->len;
    stack->len = (unsigned int)(zT_27 - (unsigned int)(1));
    zT_31 = store;
    zT_32 = ni;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    n = zT_33;
    zT_35 = n.kind;
    k = zT_35;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_205 = parent_count;
    zT_206 = caller_key;
    zT_207 = zF_A05A7BE1_u64ToU32MapGet(zT_205, zT_206);
    zT_208 = zT_207.has_value;
    if (zT_208) goto z_bb_56; else goto z_bb_57;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_39 = n.child_0;
    if ((unsigned char)(zT_39 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_9:
    zT_42 = store;
    zT_43 = sym_reg;
    zT_44 = module_id;
    zT_45 = n.child_0;
    zT_47 = zF_860C82EC_resolveCalleeKey(zT_42, zT_43, zT_44, zT_45);
    zT_48 = zT_47.has_value;
    if (zT_48) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_114 = store;
    zT_115 = ni;
    zT_116 = zF_152E19CB_astStoreNodeExtraCh(zT_114, zT_115);
    ec_n = zT_116;
    zT_118 = 0;
    ei = zT_118;
    goto z_bb_25;
    z_bb_11:
    ck = zT_47.value;
    zT_53 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_53;
    zT_57 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_57;
    zT_58 = suspending_fns;
    zT_59 = cmid;
    zT_60 = cnid;
    zT_61 = zF_7C7E43BF_asyncIsSuspending(zT_58, zT_59, zT_60);
    if (zT_61) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_110 = stack;
    zT_111 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_110, zT_111);
    goto z_bb_10;
    z_bb_13:
    zT_62 = awaited_fns;
    zT_63 = ck;
    zF_B6EB812C_u64ToU32MapPut(zT_62, zT_63, (unsigned int)(1));
    (void)store;
    zT_67 = 1;
    hf = zT_67;
    zT_68 = hidden_fns;
    zT_69 = caller_key;
    zT_70 = zF_A05A7BE1_u64ToU32MapGet(zT_68, zT_69);
    zT_71 = zT_70.has_value;
    if (zT_71) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    old = zT_70.value;
    zT_74 = old | (unsigned int)(1);
    hf = zT_74;
    goto z_bb_16;
    z_bb_16:
    zT_76 = 1;
    rt = zT_76;
    zT_77 = fn_ret_types;
    zT_78 = ck;
    zT_79 = zF_A05A7BE1_u64ToU32MapGet(zT_77, zT_78);
    zT_80 = zT_79.has_value;
    if (zT_80) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    r = zT_79.value;
    rt = r;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(rt != (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_85 = hf | (unsigned int)(2);
    hf = zT_85;
    zT_87 = 0;
    pc = zT_87;
    zT_88 = parent_count;
    zT_89 = caller_key;
    zT_90 = zF_A05A7BE1_u64ToU32MapGet(zT_88, zT_89);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_107 = hidden_fns;
    zT_108 = caller_key;
    zT_109 = hf;
    zF_B6EB812C_u64ToU32MapPut(zT_107, zT_108, zT_109);
    (void)store;
    goto z_bb_14;
    z_bb_21:
    oldc = zT_90.value;
    pc = oldc;
    goto z_bb_22;
    z_bb_22:
    if ((unsigned char)(pc == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_95 = parent_start;
    zT_96 = caller_key;
    zT_98 = parent_type_list->len;
    zF_B6EB812C_u64ToU32MapPut(zT_95, zT_96, (unsigned int)((unsigned int)zT_98));
    (void)store;
    goto z_bb_24;
    z_bb_24:
    zT_100 = parent_type_list;
    zT_101 = rt;
    zF_62F717A2_u32ArrayListAppend(zT_100, zT_101);
    zT_102 = parent_count;
    zT_103 = caller_key;
    zF_B6EB812C_u64ToU32MapPut(zT_102, zT_103, (unsigned int)(pc + (unsigned int)(1)));
    (void)store;
    goto z_bb_20;
    z_bb_25:
    if ((unsigned char)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_121 = stack;
    zT_123 = store;
    zT_124 = ni;
    zT_127 = zF_B10B1BC1_astStoreNodeExtraCh(zT_123, zT_124, (unsigned int)((unsigned int)ei));
    zT_122 = zT_127;
    zF_62F717A2_u32ArrayListAppend(zT_121, zT_122);
    goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_128 = 1;
    zT_130 = ei + (unsigned int)((unsigned int)zT_128);
    ei = zT_130;
    goto z_bb_25;
    z_bb_29:
    zT_135 = store;
    zT_136 = ni;
    zT_137 = zF_152E19CB_astStoreNodeExtraCh(zT_135, zT_136);
    ec2_n = zT_137;
    zT_139 = 0;
    ei2 = zT_139;
    goto z_bb_31;
    z_bb_30:
    zT_152 = n.child_0;
    if ((unsigned char)(zT_152 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    if ((unsigned char)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_142 = stack;
    zT_144 = store;
    zT_145 = ni;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_144, zT_145, (unsigned int)((unsigned int)ei2));
    zT_143 = zT_148;
    zF_62F717A2_u32ArrayListAppend(zT_142, zT_143);
    goto z_bb_34;
    z_bb_33:
    goto z_bb_6;
    z_bb_34:
    zT_149 = 1;
    zT_151 = ei2 + (unsigned int)((unsigned int)zT_149);
    ei2 = zT_151;
    goto z_bb_31;
    z_bb_35:
    zT_156 = k;
    zT_159 = zF_C395F6FD_nodeChildIsNode(zT_156, (unsigned char)(0));
    zT_155 = zT_159;
    goto z_bb_37;
    z_bb_36:
    zT_155 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_155) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_160 = stack;
    zT_161 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_160, zT_161);
    goto z_bb_39;
    z_bb_39:
    zT_163 = n.child_1;
    if ((unsigned char)(zT_163 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_167 = k;
    zT_170 = zF_C395F6FD_nodeChildIsNode(zT_167, (unsigned char)(1));
    zT_166 = zT_170;
    goto z_bb_42;
    z_bb_41:
    zT_166 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_166) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_171 = stack;
    zT_172 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_171, zT_172);
    goto z_bb_44;
    z_bb_44:
    zT_174 = n.child_2;
    if ((unsigned char)(zT_174 != (unsigned int)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_178 = k;
    zT_181 = zF_C395F6FD_nodeChildIsNode(zT_178, (unsigned char)(2));
    zT_177 = zT_181;
    goto z_bb_47;
    z_bb_46:
    zT_177 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_177) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_182 = stack;
    zT_183 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_182, zT_183);
    goto z_bb_49;
    z_bb_49:
    zT_185 = k;
    zT_186 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_185);
    if (zT_186) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_188 = store;
    zT_189 = ni;
    zT_190 = zF_152E19CB_astStoreNodeExtraCh(zT_188, zT_189);
    ec3_n = zT_190;
    zT_192 = 0;
    ei3 = zT_192;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_6;
    z_bb_52:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_195 = stack;
    zT_197 = store;
    zT_198 = ni;
    zT_201 = zF_B10B1BC1_astStoreNodeExtraCh(zT_197, zT_198, (unsigned int)((unsigned int)ei3));
    zT_196 = zT_201;
    zF_62F717A2_u32ArrayListAppend(zT_195, zT_196);
    goto z_bb_55;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_202 = 1;
    zT_204 = ei3 + (unsigned int)((unsigned int)zT_202);
    ei3 = zT_204;
    goto z_bb_52;
    z_bb_56:
    pc = zT_207.value;
    if ((unsigned char)(pc > (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return;
    z_bb_58:
    zT_212 = parent_start;
    zT_213 = caller_key;
    zT_214 = zF_A05A7BE1_u64ToU32MapGet(zT_212, zT_213);
    zT_215 = zT_214.has_value;
    if (zT_215) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    ps = zT_214.value;
    zT_218 = (unsigned int)ps;
    lo = zT_218;
    zT_220 = parent_type_list->len;
    hi = zT_220;
    goto z_bb_62;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    if ((unsigned char)((unsigned int)(lo + (unsigned int)(1)) < hi)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_225 = parent_type_list->items;
    zT_226 = zT_225[lo];
    tmp = zT_226;
    zT_227 = parent_type_list->items;
    zT_229 = hi - (unsigned int)(1);
    zT_230 = zT_227[zT_229];
    zT_231 = parent_type_list->items;
    zT_231[lo] = zT_230;
    zT_232 = parent_type_list->items;
    zT_234 = hi - (unsigned int)(1);
    zT_232[zT_234] = tmp;
    zT_236 = lo + (unsigned int)(1);
    lo = zT_236;
    zT_238 = hi - (unsigned int)(1);
    hi = zT_238;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    goto z_bb_62;
}

/* asyncStateTypeForCount */
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int count) {
    if ((unsigned char)(count <= (unsigned int)(255))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(8);
    z_bb_2:
    if ((unsigned char)(count <= (unsigned int)(65535))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(9);
    z_bb_4:
    return (unsigned int)(10);
}

/* scanSuspensionCount */
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, unsigned int async_suspend_name_id, unsigned int async_init_name_id) {
    unsigned int zT_9;
    zT_B687BB96_U32ArrayList* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned int zT_36;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_46 = 0;
    unsigned int zT_48;
    zT_B687BB96_U32ArrayList* zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_57 = 0;
    int zT_58;
    unsigned int zT_60;
    unsigned int zT_64;
    zT_6B0A7D14_AstStore* zT_67;
    zT_3D7259E2_SymbolRegistry* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_BBEE1AC1_Opt_11 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_78;
    unsigned int zT_82;
    zT_A4CE86B7_U64ToU32Map* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_86 = 0;
    unsigned int zT_88;
    zT_B687BB96_U32ArrayList* zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_95 = 0;
    unsigned int zT_97;
    zT_B687BB96_U32ArrayList* zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_103;
    unsigned int zT_106 = 0;
    int zT_107;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_113;
    zT_8143F551_AstKind zT_114;
    unsigned char zT_117 = 0;
    zT_B687BB96_U32ArrayList* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned char zT_124;
    zT_8143F551_AstKind zT_125;
    unsigned char zT_128 = 0;
    zT_B687BB96_U32ArrayList* zT_129;
    unsigned int zT_130;
    unsigned int zT_132;
    unsigned char zT_135;
    zT_8143F551_AstKind zT_136;
    unsigned char zT_139 = 0;
    zT_B687BB96_U32ArrayList* zT_140;
    unsigned int zT_141;
    zT_8143F551_AstKind zT_143;
    unsigned char zT_144 = 0;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_150;
    zT_B687BB96_U32ArrayList* zT_153;
    unsigned int zT_154;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    unsigned int zT_159 = 0;
    int zT_160;
    unsigned int zT_162;
    unsigned int count;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int ec3_n;
    unsigned int ei3;
    zT_9 = 0;
    count = zT_9;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return count;
    z_bb_2:
    zT_13 = stack;
    zT_14 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_13, zT_14);
    goto z_bb_3;
    z_bb_3:
    zT_15 = stack->len;
    if ((unsigned char)(zT_15 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = stack->items;
    zT_20 = stack->len;
    zT_22 = zT_20 - (unsigned int)(1);
    zT_23 = zT_19[zT_22];
    ni = zT_23;
    zT_24 = stack->len;
    stack->len = (unsigned int)(zT_24 - (unsigned int)(1));
    zT_28 = store;
    zT_29 = ni;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    n = zT_30;
    zT_32 = n.kind;
    k = zT_32;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return count;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_36 = n.child_0;
    if ((unsigned char)(zT_36 == async_suspend_name_id)) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    zT_39 = n.child_0;
    zT_38 = zT_39 == async_init_name_id;
    goto z_bb_11;
    z_bb_10:
    zT_38 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_38) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_42 = count + (unsigned int)(1);
    count = zT_42;
    goto z_bb_13;
    z_bb_13:
    zT_44 = store;
    zT_45 = ni;
    zT_46 = zF_152E19CB_astStoreNodeExtraCh(zT_44, zT_45);
    ecb_n = zT_46;
    zT_48 = 0;
    bi = zT_48;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)ecb_n))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_51 = stack;
    zT_53 = store;
    zT_54 = ni;
    zT_57 = zF_B10B1BC1_astStoreNodeExtraCh(zT_53, zT_54, (unsigned int)((unsigned int)bi));
    zT_52 = zT_57;
    zF_62F717A2_u32ArrayListAppend(zT_51, zT_52);
    goto z_bb_17;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_58 = 1;
    zT_60 = bi + (unsigned int)((unsigned int)zT_58);
    bi = zT_60;
    goto z_bb_14;
    z_bb_18:
    zT_64 = n.child_0;
    if ((unsigned char)(zT_64 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_110 = n.child_0;
    if ((unsigned char)(zT_110 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_20:
    zT_67 = store;
    zT_68 = sym_reg;
    zT_69 = module_id;
    zT_70 = n.child_0;
    zT_72 = zF_860C82EC_resolveCalleeKey(zT_67, zT_68, zT_69, zT_70);
    zT_73 = zT_72.has_value;
    if (zT_73) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_93 = store;
    zT_94 = ni;
    zT_95 = zF_152E19CB_astStoreNodeExtraCh(zT_93, zT_94);
    ecf_n = zT_95;
    zT_97 = 0;
    fi = zT_97;
    goto z_bb_26;
    z_bb_22:
    ck = zT_72.value;
    zT_78 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_78;
    zT_82 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_82;
    zT_83 = suspending_fns;
    zT_84 = cmid;
    zT_85 = cnid;
    zT_86 = zF_7C7E43BF_asyncIsSuspending(zT_83, zT_84, zT_85);
    if (zT_86) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_89 = stack;
    zT_90 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_89, zT_90);
    goto z_bb_21;
    z_bb_24:
    zT_88 = count + (unsigned int)(1);
    count = zT_88;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)ecf_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_100 = stack;
    zT_102 = store;
    zT_103 = ni;
    zT_106 = zF_B10B1BC1_astStoreNodeExtraCh(zT_102, zT_103, (unsigned int)((unsigned int)fi));
    zT_101 = zT_106;
    zF_62F717A2_u32ArrayListAppend(zT_100, zT_101);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_6;
    z_bb_29:
    zT_107 = 1;
    zT_109 = fi + (unsigned int)((unsigned int)zT_107);
    fi = zT_109;
    goto z_bb_26;
    z_bb_30:
    zT_114 = k;
    zT_117 = zF_C395F6FD_nodeChildIsNode(zT_114, (unsigned char)(0));
    zT_113 = zT_117;
    goto z_bb_32;
    z_bb_31:
    zT_113 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_113) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_118 = stack;
    zT_119 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_118, zT_119);
    goto z_bb_34;
    z_bb_34:
    zT_121 = n.child_1;
    if ((unsigned char)(zT_121 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_125 = k;
    zT_128 = zF_C395F6FD_nodeChildIsNode(zT_125, (unsigned char)(1));
    zT_124 = zT_128;
    goto z_bb_37;
    z_bb_36:
    zT_124 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_124) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_129 = stack;
    zT_130 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_129, zT_130);
    goto z_bb_39;
    z_bb_39:
    zT_132 = n.child_2;
    if ((unsigned char)(zT_132 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_136 = k;
    zT_139 = zF_C395F6FD_nodeChildIsNode(zT_136, (unsigned char)(2));
    zT_135 = zT_139;
    goto z_bb_42;
    z_bb_41:
    zT_135 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_135) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_140 = stack;
    zT_141 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_140, zT_141);
    goto z_bb_44;
    z_bb_44:
    zT_143 = k;
    zT_144 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_143);
    if (zT_144) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_146 = store;
    zT_147 = ni;
    zT_148 = zF_152E19CB_astStoreNodeExtraCh(zT_146, zT_147);
    ec3_n = zT_148;
    zT_150 = 0;
    ei3 = zT_150;
    goto z_bb_47;
    z_bb_46:
    goto z_bb_6;
    z_bb_47:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_153 = stack;
    zT_155 = store;
    zT_156 = ni;
    zT_159 = zF_B10B1BC1_astStoreNodeExtraCh(zT_155, zT_156, (unsigned int)((unsigned int)ei3));
    zT_154 = zT_159;
    zF_62F717A2_u32ArrayListAppend(zT_153, zT_154);
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_160 = 1;
    zT_162 = ei3 + (unsigned int)((unsigned int)zT_160);
    ei3 = zT_162;
    goto z_bb_47;
}

/* asyncPtrVoid */
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_1;
    unsigned int zT_6 = 0;
    zT_1 = reg;
    zT_6 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1, (unsigned int)(1), (unsigned char)(0));
    return zT_6;
}

/* emitFrameMarker */
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64 key, unsigned int size) {
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_5826BFC7_Arr_unsigned_char_1 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_5826BFC7_Arr_unsigned_char_1 zT_45;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_5826BFC7_Arr_unsigned_char_1 zT_74;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84 = 0;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_5 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_5;
    zT_9 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_9;
    zT_11 = "FRAME:m";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    m1 = zT_12;
    zT_14 = m1;
    zF_48AC7B3A_markerWrite(zT_14);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_16[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = module_id;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)b1) + zT_22;
    zT_24 = (unsigned int)(12) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    l1 = zT_26;
    zT_31 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_31;
    zT_36 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_37 = (unsigned int)(11) - s1;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_32 = zT_38;
    zF_48AC7B3A_markerWrite(zT_32);
    zT_40 = ":n";
    zT_42 = 2;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    m2 = zT_41;
    zT_43 = m2;
    zF_48AC7B3A_markerWrite(zT_43);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_45[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_45[_i];
        _i++;
    }
}
    zT_47 = name_id;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)b2) + zT_51;
    zT_53 = (unsigned int)(12) - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_48 = zT_54;
    zT_55 = zF_A7504564_itoa(zT_47, zT_48);
    l2 = zT_55;
    zT_60 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_60;
    zT_65 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_66 = (unsigned int)(11) - s2;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_61 = zT_67;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_69 = ":s";
    zT_71 = 2;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    m3 = zT_70;
    zT_72 = m3;
    zF_48AC7B3A_markerWrite(zT_72);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_74[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_74[_i];
        _i++;
    }
}
    zT_76 = size;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)b3) + zT_80;
    zT_82 = (unsigned int)(12) - zT_80;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zT_84 = zF_A7504564_itoa(zT_76, zT_77);
    l3 = zT_84;
    zT_89 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_89;
    zT_94 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_95 = (unsigned int)(11) - s3;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90 = zT_96;
    zF_48AC7B3A_markerWrite(zT_90);
    zT_98 = "\n";
    zT_100 = 1;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    m4 = zT_99;
    zT_101 = m4;
    zF_48AC7B3A_markerWrite(zT_101);
    return;
}

/* asyncFrameSizeRun */
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* typereg, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_B687BB96_U32ArrayList zT_23 = {0};
    zT_072B53A6_ModuleRegistry* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26 = {0};
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    zT_3E40CD83_Sand* zT_44;
    zT_A4CE86B7_U64ToU32Map zT_45 = {0};
    unsigned int zT_47;
    unsigned int zT_49;
    zT_6E8D187B_ModuleEntry* zT_52;
    zT_6E8D187B_ModuleEntry zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    unsigned int zT_68 = 0;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_78 = 0;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    zT_22A7C88B_AstNode zT_82 = {0};
    zT_8143F551_AstKind zT_83;
    zT_9C1673CC_anon_238694 zT_88;
    zT_243D6A41_FnProto* zT_89;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    unsigned int zT_92 = 0;
    unsigned int zT_93;
    zT_243D6A41_FnProto zT_94;
    unsigned int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_97;
    unsigned int zT_98;
    zT_BAEE192E_Opt_10 zT_100 = {0};
    unsigned char zT_101;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_6E8D187B_ModuleEntry* zT_109;
    zT_6E8D187B_ModuleEntry zT_110;
    zT_79FAE712_u64 zT_113 = 0;
    int zT_114;
    unsigned int zT_116;
    int zT_117;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    zT_6E8D187B_ModuleEntry* zT_126;
    zT_6E8D187B_ModuleEntry zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_144;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int zT_152 = 0;
    zT_6B0A7D14_AstStore* zT_154;
    unsigned int zT_155;
    zT_22A7C88B_AstNode zT_156 = {0};
    zT_8143F551_AstKind zT_157;
    zT_9C1673CC_anon_238694 zT_162;
    zT_243D6A41_FnProto* zT_163;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_166 = 0;
    unsigned int zT_167;
    zT_243D6A41_FnProto zT_168;
    zT_A4CE86B7_U64ToU32Map* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_6E8D187B_ModuleEntry* zT_172;
    zT_6E8D187B_ModuleEntry zT_173;
    unsigned char zT_176 = 0;
    zT_6B0A7D14_AstStore* zT_178;
    zT_3D7259E2_SymbolRegistry* zT_179;
    unsigned int zT_180;
    zT_79FAE712_u64 zT_181;
    unsigned int zT_182;
    zT_B687BB96_U32ArrayList* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    zT_A4CE86B7_U64ToU32Map* zT_185;
    zT_A4CE86B7_U64ToU32Map* zT_186;
    zT_A4CE86B7_U64ToU32Map* zT_187;
    zT_B687BB96_U32ArrayList* zT_188;
    zT_A4CE86B7_U64ToU32Map* zT_189;
    zT_A4CE86B7_U64ToU32Map* zT_190;
    zT_6E8D187B_ModuleEntry* zT_191;
    zT_6E8D187B_ModuleEntry zT_192;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_6E8D187B_ModuleEntry* zT_196;
    zT_6E8D187B_ModuleEntry zT_197;
    zT_79FAE712_u64 zT_200 = 0;
    int zT_204;
    unsigned int zT_206;
    int zT_207;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_213;
    zT_6E8D187B_ModuleEntry* zT_216;
    zT_6E8D187B_ModuleEntry zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_222;
    unsigned int zT_223;
    zT_22A7C88B_AstNode zT_224 = {0};
    zT_8143F551_AstKind zT_225;
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    unsigned int zT_232 = 0;
    unsigned int zT_234;
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int zT_242 = 0;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    zT_22A7C88B_AstNode zT_246 = {0};
    zT_8143F551_AstKind zT_247;
    zT_6B0A7D14_AstStore* zT_252;
    unsigned int zT_253;
    unsigned int zT_254 = 0;
    zT_9C1673CC_anon_238694 zT_256;
    zT_243D6A41_FnProto* zT_257;
    unsigned int zT_258;
    zT_243D6A41_FnProto zT_259;
    zT_A4CE86B7_U64ToU32Map* zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    zT_6E8D187B_ModuleEntry* zT_263;
    zT_6E8D187B_ModuleEntry zT_264;
    unsigned char zT_267 = 0;
    unsigned int zT_270;
    unsigned int zT_271;
    zT_6E8D187B_ModuleEntry* zT_272;
    zT_6E8D187B_ModuleEntry zT_273;
    zT_79FAE712_u64 zT_276 = 0;
    unsigned char zT_278;
    unsigned char zT_279;
    unsigned char zT_285;
    zT_6E8D187B_ModuleEntry* zT_286;
    zT_6E8D187B_ModuleEntry zT_287;
    unsigned int zT_288;
    unsigned char zT_291;
    unsigned char zT_292;
    zT_D3EB6303_StringInterner* zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302 = {0};
    unsigned int zT_304;
    unsigned char zT_307;
    unsigned char* zT_308;
    int zT_309;
    unsigned char zT_310;
    unsigned char zT_313;
    unsigned char* zT_314;
    int zT_315;
    unsigned char zT_316;
    unsigned char zT_319;
    unsigned char* zT_320;
    int zT_321;
    unsigned char zT_322;
    unsigned char zT_325;
    unsigned char* zT_326;
    int zT_327;
    unsigned char zT_328;
    unsigned char zT_331;
    zT_A4CE86B7_U64ToU32Map* zT_332;
    zT_79FAE712_u64 zT_333;
    zT_6B0A7D14_AstStore* zT_337;
    zT_3D7259E2_SymbolRegistry* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_B687BB96_U32ArrayList* zT_341;
    zT_A4CE86B7_U64ToU32Map* zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    zT_6E8D187B_ModuleEntry* zT_345;
    zT_6E8D187B_ModuleEntry zT_346;
    unsigned int zT_350 = 0;
    unsigned int zT_352;
    unsigned int zT_353 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_354;
    zT_79FAE712_u64 zT_355;
    unsigned int zT_356;
    unsigned int zT_358;
    unsigned int zT_360;
    zT_338B7C76_TypeRegistry* zT_361;
    unsigned int* zT_363;
    unsigned int* zT_364;
    unsigned int zT_368 = 0;
    zT_338B7C76_TypeRegistry* zT_369;
    unsigned int* zT_371;
    unsigned int* zT_372;
    unsigned int zT_376 = 0;
    zT_338B7C76_TypeRegistry* zT_377;
    unsigned int zT_378;
    unsigned int* zT_379;
    unsigned int* zT_380;
    unsigned int zT_383 = 0;
    unsigned short zT_384;
    unsigned int zT_388;
    unsigned short zT_392;
    zT_79FAE712_u64 zT_394;
    zT_6B0A7D14_AstStore* zT_396;
    zT_79FAE712_u64 zT_397;
    unsigned int zT_398 = 0;
    unsigned int zT_400;
    zT_6B0A7D14_AstStore* zT_404;
    unsigned int zT_405;
    zT_6B0A7D14_AstStore* zT_406;
    zT_79FAE712_u64 zT_407;
    unsigned int zT_410 = 0;
    zT_22A7C88B_AstNode zT_411 = {0};
    unsigned int zT_412;
    unsigned int zT_416;
    zT_8EED1867_ResolvedTypeTable* zT_417;
    unsigned int zT_418;
    zT_BAEE192E_Opt_10 zT_420 = {0};
    unsigned char zT_421;
    zT_338B7C76_TypeRegistry* zT_423;
    unsigned int zT_424;
    unsigned int* zT_425;
    unsigned int* zT_426;
    unsigned int zT_429 = 0;
    unsigned int zT_431;
    zT_6B0A7D14_AstStore* zT_432;
    unsigned int zT_433;
    zT_B687BB96_U32ArrayList* zT_434;
    zT_338B7C76_TypeRegistry* zT_435;
    zT_8EED1867_ResolvedTypeTable* zT_436;
    unsigned int* zT_437;
    unsigned int* zT_438;
    unsigned int zT_444;
    zT_A4CE86B7_U64ToU32Map* zT_445;
    zT_79FAE712_u64 zT_446;
    zT_BAEE192E_Opt_10 zT_447 = {0};
    unsigned char zT_448;
    zT_338B7C76_TypeRegistry* zT_454;
    unsigned int zT_455;
    unsigned int* zT_456;
    unsigned int* zT_457;
    zT_338B7C76_TypeRegistry* zT_458;
    unsigned int zT_459 = 0;
    unsigned int zT_462 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_463;
    zT_79FAE712_u64 zT_464;
    zT_BAEE192E_Opt_10 zT_465 = {0};
    unsigned char zT_466;
    unsigned char zT_467;
    zT_A4CE86B7_U64ToU32Map* zT_468;
    zT_79FAE712_u64 zT_469;
    zT_BAEE192E_Opt_10 zT_470 = {0};
    unsigned char zT_471;
    zT_338B7C76_TypeRegistry* zT_472;
    unsigned int zT_473;
    unsigned int* zT_474;
    unsigned int* zT_475;
    zT_338B7C76_TypeRegistry* zT_476;
    unsigned int zT_477 = 0;
    unsigned int zT_480 = 0;
    unsigned int zT_486;
    zT_A4CE86B7_U64ToU32Map* zT_487;
    zT_79FAE712_u64 zT_488;
    zT_BAEE192E_Opt_10 zT_489 = {0};
    unsigned char zT_490;
    unsigned int zT_493;
    zT_A4CE86B7_U64ToU32Map* zT_494;
    zT_79FAE712_u64 zT_495;
    zT_BAEE192E_Opt_10 zT_496 = {0};
    unsigned char zT_497;
    unsigned int zT_500;
    unsigned int* zT_503;
    unsigned int zT_505;
    unsigned int zT_506;
    zT_338B7C76_TypeRegistry* zT_507;
    unsigned int zT_508;
    unsigned int* zT_509;
    unsigned int* zT_510;
    unsigned int zT_513 = 0;
    unsigned int zT_515;
    unsigned int zT_517;
    unsigned int zT_518;
    unsigned int zT_519 = 0;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_526 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_527;
    zT_79FAE712_u64 zT_528;
    unsigned int zT_529;
    zT_79FAE712_u64 zT_530;
    unsigned int zT_531;
    int zT_532;
    unsigned int zT_534;
    int zT_535;
    unsigned int zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_B687BB96_U32ArrayList stack;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_text;
    unsigned int async_init_name_id;
    zT_A4CE86B7_U64ToU32Map fn_ret_types;
    unsigned int mi0;
    unsigned int ar0;
    unsigned int mi0b;
    zT_22A7C88B_AstNode r0;
    unsigned int d0_n;
    unsigned int di0;
    unsigned int d0_idx;
    zT_22A7C88B_AstNode dc0;
    zT_243D6A41_FnProto pr0;
    unsigned int rt0;
    unsigned int rr0;
    unsigned int ar0b;
    unsigned int mi;
    zT_22A7C88B_AstNode r0b;
    unsigned int d0b_n;
    unsigned int di0b;
    unsigned int d0b_idx;
    zT_22A7C88B_AstNode dc0b;
    zT_243D6A41_FnProto pr0b;
    unsigned int ast_root;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned char is_driver_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u dm;
    unsigned int susp_count;
    unsigned int state_type;
    unsigned int offset;
    unsigned int max_align;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int hid;
    zT_22A7C88B_AstNode pnode;
    unsigned int pt;
    unsigned int rtp;
    unsigned int h;
    unsigned int pstart;
    unsigned int total;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_17 = "AFS\n";
    zT_19 = 4;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    p_msg = zT_18;
    zT_20 = p_msg;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_22 = alloc;
    zT_23 = zF_8E537D0C_u32ArrayListInit(zT_22);
    stack = zT_23;
    zT_25 = module_reg;
    zT_26 = zF_3452C137_moduleRegistryGetMo(zT_25);
    mods = zT_26;
    zT_28 = "@asyncSuspend";
    zT_30 = 13;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    asu_text = zT_29;
    zT_32 = interner;
    zT_33 = asu_text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    async_suspend_name_id = zT_34;
    zT_36 = "@asyncInit";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    ain_text = zT_37;
    zT_40 = interner;
    zT_41 = ain_text;
    zT_42 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    async_init_name_id = zT_42;
    zT_44 = alloc;
    zT_45 = zF_986226E1_u64ToU32MapInit(zT_44);
    fn_ret_types = zT_45;
    zT_47 = 0;
    mi0 = zT_47;
    goto z_bb_1;
    z_bb_1:
    zT_49 = mods.len;
    if ((unsigned char)(mi0 < zT_49)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_52 = mods.ptr;
    zT_53 = zT_52[mi0];
    zT_54 = zT_53.ast_root;
    ar0 = zT_54;
    if ((unsigned char)(ar0 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_121 = 0;
    mi0b = zT_121;
    goto z_bb_17;
    z_bb_4:
    zT_117 = 1;
    zT_119 = mi0 + (unsigned int)((unsigned int)zT_117);
    mi0 = zT_119;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_58 = store;
    zT_59 = ar0;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    r0 = zT_60;
    zT_61 = r0.kind;
    if ((unsigned char)(zT_61 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_66 = store;
    zT_67 = ar0;
    zT_68 = zF_152E19CB_astStoreNodeExtraCh(zT_66, zT_67);
    d0_n = zT_68;
    zT_70 = 0;
    di0 = zT_70;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(di0 < (unsigned int)((unsigned int)d0_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_74 = store;
    zT_75 = ar0;
    zT_78 = zF_B10B1BC1_astStoreNodeExtraCh(zT_74, zT_75, (unsigned int)((unsigned int)di0));
    d0_idx = zT_78;
    zT_80 = store;
    zT_81 = d0_idx;
    zT_82 = zF_FCDD1D35_astStoreNodeAt(zT_80, zT_81);
    dc0 = zT_82;
    zT_83 = dc0.kind;
    if ((unsigned char)(zT_83 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_114 = 1;
    zT_116 = di0 + (unsigned int)((unsigned int)zT_114);
    di0 = zT_116;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_88 = store->fn_protos;
    zT_89 = zT_88.items;
    zT_90 = store;
    zT_91 = d0_idx;
    zT_92 = zF_8BA26B9E_astStoreNodePayload(zT_90, zT_91);
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_89[zT_93];
    pr0 = zT_94;
    zT_96 = 1;
    rt0 = zT_96;
    zT_97 = resolved_types;
    zT_98 = pr0.return_type_node;
    zT_100 = zF_999DCF51_resolvedTypeTableGe(zT_97, zT_98);
    zT_101 = zT_100.has_value;
    if (zT_101) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    rr0 = zT_100.value;
    rt0 = rr0;
    goto z_bb_16;
    z_bb_16:
    zT_103 = &fn_ret_types;
    zT_109 = mods.ptr;
    zT_110 = zT_109[mi0];
    zT_107 = zT_110.id;
    zT_108 = pr0.name_id;
    zT_113 = zF_9D041EB6_asyncKey(zT_107, zT_108);
    zT_104 = zT_113;
    zT_105 = rt0;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, zT_105);
    (void)alloc;
    goto z_bb_12;
    z_bb_17:
    zT_123 = mods.len;
    if ((unsigned char)(mi0b < zT_123)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_126 = mods.ptr;
    zT_127 = zT_126[mi0b];
    zT_128 = zT_127.ast_root;
    ar0b = zT_128;
    if ((unsigned char)(ar0b == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_211 = 0;
    mi = zT_211;
    goto z_bb_33;
    z_bb_20:
    zT_207 = 1;
    zT_209 = mi0b + (unsigned int)((unsigned int)zT_207);
    mi0b = zT_209;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_132 = store;
    zT_133 = ar0b;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_132, zT_133);
    r0b = zT_134;
    zT_135 = r0b.kind;
    if ((unsigned char)(zT_135 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_140 = store;
    zT_141 = ar0b;
    zT_142 = zF_152E19CB_astStoreNodeExtraCh(zT_140, zT_141);
    d0b_n = zT_142;
    zT_144 = 0;
    di0b = zT_144;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(di0b < (unsigned int)((unsigned int)d0b_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_148 = store;
    zT_149 = ar0b;
    zT_152 = zF_B10B1BC1_astStoreNodeExtraCh(zT_148, zT_149, (unsigned int)((unsigned int)di0b));
    d0b_idx = zT_152;
    zT_154 = store;
    zT_155 = d0b_idx;
    zT_156 = zF_FCDD1D35_astStoreNodeAt(zT_154, zT_155);
    dc0b = zT_156;
    zT_157 = dc0b.kind;
    if ((unsigned char)(zT_157 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_204 = 1;
    zT_206 = di0b + (unsigned int)((unsigned int)zT_204);
    di0b = zT_206;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_162 = store->fn_protos;
    zT_163 = zT_162.items;
    zT_164 = store;
    zT_165 = d0b_idx;
    zT_166 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    zT_167 = (unsigned int)zT_166;
    zT_168 = zT_163[zT_167];
    pr0b = zT_168;
    zT_169 = suspending_fns;
    zT_172 = mods.ptr;
    zT_173 = zT_172[mi0b];
    zT_170 = zT_173.id;
    zT_171 = pr0b.name_id;
    zT_176 = zF_7C7E43BF_asyncIsSuspending(zT_169, zT_170, zT_171);
    if ((unsigned char)(!zT_176)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_178 = store;
    zT_179 = sym_reg;
    zT_191 = mods.ptr;
    zT_192 = zT_191[mi0b];
    zT_180 = zT_192.id;
    zT_196 = mods.ptr;
    zT_197 = zT_196[mi0b];
    zT_194 = zT_197.id;
    zT_195 = pr0b.name_id;
    zT_200 = zF_9D041EB6_asyncKey(zT_194, zT_195);
    zT_181 = zT_200;
    zT_182 = dc0b.child_0;
    zT_183 = &stack;
    zT_184 = suspending_fns;
    zT_185 = &fn_ret_types;
    zT_186 = awaited_fns;
    zT_187 = async_hidden_fns;
    zT_188 = parent_result_type_list;
    zT_189 = parent_result_start;
    zT_190 = parent_result_count;
    zF_D62E4E4C_scanImplicitAwaits(zT_178, zT_179, zT_180, zT_181, zT_182, zT_183, zT_184, zT_185, zT_186, zT_187, zT_188, zT_189, zT_190);
    goto z_bb_28;
    z_bb_33:
    zT_213 = mods.len;
    if ((unsigned char)(mi < zT_213)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_216 = mods.ptr;
    zT_217 = zT_216[mi];
    zT_218 = zT_217.ast_root;
    ast_root = zT_218;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return;
    z_bb_36:
    zT_535 = 1;
    zT_537 = mi + (unsigned int)((unsigned int)zT_535);
    mi = zT_537;
    goto z_bb_33;
    z_bb_37:
    goto z_bb_36;
    z_bb_38:
    zT_222 = store;
    zT_223 = ast_root;
    zT_224 = zF_FCDD1D35_astStoreNodeAt(zT_222, zT_223);
    root = zT_224;
    zT_225 = root.kind;
    if ((unsigned char)(zT_225 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_230 = store;
    zT_231 = ast_root;
    zT_232 = zF_152E19CB_astStoreNodeExtraCh(zT_230, zT_231);
    decls_n = zT_232;
    zT_234 = 0;
    di = zT_234;
    goto z_bb_41;
    z_bb_41:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_238 = store;
    zT_239 = ast_root;
    zT_242 = zF_B10B1BC1_astStoreNodeExtraCh(zT_238, zT_239, (unsigned int)((unsigned int)di));
    decl_idx = zT_242;
    zT_244 = store;
    zT_245 = decl_idx;
    zT_246 = zF_FCDD1D35_astStoreNodeAt(zT_244, zT_245);
    decl = zT_246;
    zT_247 = decl.kind;
    if ((unsigned char)(zT_247 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_532 = 1;
    zT_534 = di + (unsigned int)((unsigned int)zT_532);
    di = zT_534;
    goto z_bb_41;
    z_bb_45:
    goto z_bb_44;
    z_bb_46:
    zT_252 = store;
    zT_253 = decl_idx;
    zT_254 = zF_8BA26B9E_astStoreNodePayload(zT_252, zT_253);
    proto_idx = zT_254;
    zT_256 = store->fn_protos;
    zT_257 = zT_256.items;
    zT_258 = (unsigned int)proto_idx;
    zT_259 = zT_257[zT_258];
    proto = zT_259;
    zT_260 = suspending_fns;
    zT_263 = mods.ptr;
    zT_264 = zT_263[mi];
    zT_261 = zT_264.id;
    zT_262 = proto.name_id;
    zT_267 = zF_7C7E43BF_asyncIsSuspending(zT_260, zT_261, zT_262);
    if ((unsigned char)(!zT_267)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_272 = mods.ptr;
    zT_273 = zT_272[mi];
    zT_270 = zT_273.id;
    zT_271 = proto.name_id;
    zT_276 = zF_9D041EB6_asyncKey(zT_270, zT_271);
    key = zT_276;
    zT_278 = 0;
    is_driver_target = zT_278;
    zT_279 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_279) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_285 = 1;
    is_driver_target = zT_285;
    goto z_bb_50;
    z_bb_50:
    zT_286 = mods.ptr;
    zT_287 = zT_286[mi];
    zT_288 = zT_287.id;
    if ((unsigned char)(zT_288 == (unsigned int)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_292 = decl.flags;
    zT_291 = (unsigned short)((unsigned short)((unsigned short)zT_292) & (unsigned short)(2)) != (unsigned short)(0);
    goto z_bb_53;
    z_bb_52:
    zT_291 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_291) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_299 = interner;
    zT_300 = proto.name_id;
    zT_302 = zF_9134020D_stringInternerGet(zT_299, zT_300);
    dm = zT_302;
    zT_304 = dm.len;
    if ((unsigned char)(zT_304 == (unsigned int)(4))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if (is_driver_target) goto z_bb_70; else goto z_bb_71;
    z_bb_56:
    zT_308 = dm.ptr;
    zT_309 = 0;
    zT_310 = zT_308[zT_309];
    zT_307 = zT_310 == (unsigned char)(109);
    goto z_bb_58;
    z_bb_57:
    zT_307 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_307) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_314 = dm.ptr;
    zT_315 = 1;
    zT_316 = zT_314[zT_315];
    zT_313 = zT_316 == (unsigned char)(97);
    goto z_bb_61;
    z_bb_60:
    zT_313 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_313) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_320 = dm.ptr;
    zT_321 = 2;
    zT_322 = zT_320[zT_321];
    zT_319 = zT_322 == (unsigned char)(105);
    goto z_bb_64;
    z_bb_63:
    zT_319 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_319) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_326 = dm.ptr;
    zT_327 = 3;
    zT_328 = zT_326[zT_327];
    zT_325 = zT_328 == (unsigned char)(110);
    goto z_bb_67;
    z_bb_66:
    zT_325 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_325) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_331 = 1;
    is_driver_target = zT_331;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_55;
    z_bb_70:
    zT_332 = driver_targets;
    zT_333 = key;
    zF_B6EB812C_u64ToU32MapPut(zT_332, zT_333, (unsigned int)(1));
    (void)alloc;
    goto z_bb_71;
    z_bb_71:
    zT_337 = store;
    zT_338 = sym_reg;
    zT_345 = mods.ptr;
    zT_346 = zT_345[mi];
    zT_339 = zT_346.id;
    zT_340 = decl.child_0;
    zT_341 = &stack;
    zT_342 = suspending_fns;
    zT_343 = async_suspend_name_id;
    zT_344 = async_init_name_id;
    zT_350 = zF_0782A438_scanSuspensionCount(zT_337, zT_338, zT_339, zT_340, zT_341, zT_342, zT_343, zT_344);
    susp_count = zT_350;
    zT_352 = susp_count;
    zT_353 = zF_74FC996E_asyncStateTypeForCo(zT_352);
    state_type = zT_353;
    zT_354 = state_widths;
    zT_355 = key;
    zT_356 = state_type;
    zF_B6EB812C_u64ToU32MapPut(zT_354, zT_355, zT_356);
    (void)alloc;
    zT_358 = 0;
    offset = zT_358;
    zT_360 = 1;
    max_align = zT_360;
    zT_361 = typereg;
    zT_363 = &offset;
    zT_364 = &max_align;
    zT_368 = zF_769CB99B_addFrameField(zT_361, (unsigned int)(13), zT_363, zT_364);
    (void)zT_368;
    zT_369 = typereg;
    zT_371 = &offset;
    zT_372 = &max_align;
    zT_376 = zF_769CB99B_addFrameField(zT_369, (unsigned int)(13), zT_371, zT_372);
    (void)zT_376;
    zT_377 = typereg;
    zT_378 = state_type;
    zT_379 = &offset;
    zT_380 = &max_align;
    zT_383 = zF_769CB99B_addFrameField(zT_377, zT_378, zT_379, zT_380);
    (void)zT_383;
    zT_384 = proto.params_count;
    if ((unsigned char)(zT_384 > (unsigned short)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_388 = proto.params_start;
    zT_392 = proto.params_count;
    zT_394 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_388) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_392);
    p_payload = zT_394;
    zT_396 = store;
    zT_397 = p_payload;
    zT_398 = zF_03CE8CAB_astStoreGetExtraChi(zT_396, zT_397);
    pnodes_n = zT_398;
    zT_400 = 0;
    pi = zT_400;
    goto z_bb_74;
    z_bb_73:
    zT_432 = store;
    zT_433 = decl.child_0;
    zT_434 = &stack;
    zT_435 = typereg;
    zT_436 = resolved_types;
    zT_437 = &offset;
    zT_438 = &max_align;
    zF_68BD38B1_scanFrameLocals(zT_432, zT_433, zT_434, zT_435, zT_436, zT_437, zT_438);
    zT_444 = 0;
    hid = zT_444;
    zT_445 = async_hidden_fns;
    zT_446 = key;
    zT_447 = zF_A05A7BE1_u64ToU32MapGet(zT_445, zT_446);
    zT_448 = zT_447.has_value;
    if (zT_448) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_404 = store;
    zT_406 = store;
    zT_407 = p_payload;
    zT_410 = zF_E5B10421_astStoreGetExtraChi(zT_406, zT_407, (unsigned int)((unsigned int)pi));
    zT_405 = zT_410;
    zT_411 = zF_FCDD1D35_astStoreNodeAt(zT_404, zT_405);
    pnode = zT_411;
    zT_412 = pnode.child_0;
    if ((unsigned char)(zT_412 == (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_431 = pi + (unsigned int)(1);
    pi = zT_431;
    goto z_bb_74;
    z_bb_78:
    goto z_bb_77;
    z_bb_79:
    zT_416 = 18;
    pt = zT_416;
    zT_417 = resolved_types;
    zT_418 = pnode.child_0;
    zT_420 = zF_999DCF51_resolvedTypeTableGe(zT_417, zT_418);
    zT_421 = zT_420.has_value;
    if (zT_421) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    rtp = zT_420.value;
    pt = rtp;
    goto z_bb_81;
    z_bb_81:
    zT_423 = typereg;
    zT_424 = pt;
    zT_425 = &offset;
    zT_426 = &max_align;
    zT_429 = zF_769CB99B_addFrameField(zT_423, zT_424, zT_425, zT_426);
    (void)zT_429;
    goto z_bb_77;
    z_bb_82:
    h = zT_447.value;
    hid = h;
    goto z_bb_83;
    z_bb_83:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_454 = typereg;
    zT_458 = typereg;
    zT_459 = zF_FF3C4865_asyncPtrVoid(zT_458);
    zT_455 = zT_459;
    zT_456 = &offset;
    zT_457 = &max_align;
    zT_462 = zF_769CB99B_addFrameField(zT_454, zT_455, zT_456, zT_457);
    (void)zT_462;
    goto z_bb_85;
    z_bb_85:
    zT_463 = awaited_fns;
    zT_464 = key;
    zT_465 = zF_A05A7BE1_u64ToU32MapGet(zT_463, zT_464);
    zT_466 = zT_465.has_value;
    if (zT_466) goto z_bb_87; else goto z_bb_86;
    z_bb_86:
    zT_468 = driver_targets;
    zT_469 = key;
    zT_470 = zF_A05A7BE1_u64ToU32MapGet(zT_468, zT_469);
    zT_471 = zT_470.has_value;
    zT_467 = zT_471;
    goto z_bb_88;
    z_bb_87:
    zT_467 = 1;
    goto z_bb_88;
    z_bb_88:
    if (zT_467) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_472 = typereg;
    zT_476 = typereg;
    zT_477 = zF_FF3C4865_asyncPtrVoid(zT_476);
    zT_473 = zT_477;
    zT_474 = &offset;
    zT_475 = &max_align;
    zT_480 = zF_769CB99B_addFrameField(zT_472, zT_473, zT_474, zT_475);
    (void)zT_480;
    goto z_bb_90;
    z_bb_90:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_486 = 0;
    pstart = zT_486;
    zT_487 = parent_result_start;
    zT_488 = key;
    zT_489 = zF_A05A7BE1_u64ToU32MapGet(zT_487, zT_488);
    zT_490 = zT_489.has_value;
    if (zT_490) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_517 = offset;
    zT_518 = max_align;
    zT_519 = zF_978D7C93_alignUpU32(zT_517, zT_518);
    total = zT_519;
    if ((unsigned char)(total == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_93:
    ps = zT_489.value;
    pstart = ps;
    goto z_bb_94;
    z_bb_94:
    zT_493 = 0;
    pcount = zT_493;
    zT_494 = parent_result_count;
    zT_495 = key;
    zT_496 = zF_A05A7BE1_u64ToU32MapGet(zT_494, zT_495);
    zT_497 = zT_496.has_value;
    if (zT_497) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    pc = zT_496.value;
    pcount = pc;
    goto z_bb_96;
    z_bb_96:
    zT_500 = 0;
    pk = zT_500;
    goto z_bb_97;
    z_bb_97:
    if ((unsigned char)(pk < pcount)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_503 = parent_result_type_list->items;
    zT_505 = (unsigned int)(unsigned int)(pstart + pk);
    zT_506 = zT_503[zT_505];
    prt = zT_506;
    zT_507 = typereg;
    zT_508 = prt;
    zT_509 = &offset;
    zT_510 = &max_align;
    zT_513 = zF_769CB99B_addFrameField(zT_507, zT_508, zT_509, zT_510);
    (void)zT_513;
    goto z_bb_100;
    z_bb_99:
    goto z_bb_92;
    z_bb_100:
    zT_515 = pk + (unsigned int)(1);
    pk = zT_515;
    goto z_bb_97;
    z_bb_101:
    zT_522 = 1;
    total = zT_522;
    goto z_bb_102;
    z_bb_102:
    zT_523 = total;
    zT_526 = zF_978D7C93_alignUpU32(zT_523, (unsigned int)(8));
    total = zT_526;
    zT_527 = frame_sizes;
    zT_528 = key;
    zT_529 = total;
    zF_B6EB812C_u64ToU32MapPut(zT_527, zT_528, zT_529);
    zT_530 = key;
    zT_531 = total;
    zF_7011AA79_emitFrameMarker(zT_530, zT_531);
    goto z_bb_44;
}

/* __module_init */
void zF_780653D2___module_init_22(void) {
    zT_8143F551_AstKind zT_0 = 0;
    zG_8143F551_AstKind = zT_0;
    return;
}

/* EOF */
