#include "async_analysis_A8747991.h"
/* asyncKey */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int module_id, unsigned int name_id) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
}

/* asyncIsSuspending */
int zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8 = 0;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 v;
    unsigned int val;
    zT_4 = map;
    zT_6 = module_id;
    zT_7 = name_id;
    zT_8 = zF_9D041EB6_asyncKey(zT_6, zT_7);
    zT_5 = zT_8;
    zT_9 = zF_A05A7BE1_u64ToU32MapGet(zT_4, zT_5);
    v = zT_9;
    zT_10 = v.has_value;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    val = v.value;
    return (int)(val != (unsigned int)(0));
    z_bb_2:
    return (int)(0);
}

/* asyncFrameSizeOf */
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    return zT_8;
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand* sand, unsigned int count) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int c;
    unsigned char* raw;
    c = count;
    if ((int)(c == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    c = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = sand;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)(4) * c), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    return (unsigned int*)((unsigned int*)raw);
}

/* resolveCalleeKey */
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int callee_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_3D7259E2_SymbolRegistry* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_D4761958_Opt_858 zT_20 = {0};
    unsigned char zT_21;
    zT_3C598AEF_SymbolKind zT_23;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    zT_BBEE1AC1_Opt_11 zT_33;
    zT_BBEE1AC1_Opt_11 zT_34 = {0};
    zT_8143F551_AstKind zT_35;
    zT_BBEE1AC1_Opt_11 zT_40 = {0};
    zT_99292002_Arr_unsigned_int_16 zT_42;
    int zT_44;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_58 = {0};
    zT_8143F551_AstKind zT_59;
    zT_BBEE1AC1_Opt_11 zT_66 = {0};
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_22A7C88B_AstNode zT_77 = {0};
    zT_8143F551_AstKind zT_78;
    zT_BBEE1AC1_Opt_11 zT_83 = {0};
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_87 = 0;
    zT_3D7259E2_SymbolRegistry* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_D4761958_Opt_858 zT_92 = {0};
    unsigned char zT_93;
    zT_3C598AEF_SymbolKind zT_95;
    zT_BBEE1AC1_Opt_11 zT_100 = {0};
    unsigned int zT_101;
    zT_BBEE1AC1_Opt_11 zT_102 = {0};
    int zT_106;
    unsigned int zT_108;
    zT_3D7259E2_SymbolRegistry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_D4761958_Opt_858 zT_114 = {0};
    unsigned char zT_115;
    zT_3C598AEF_SymbolKind zT_117;
    zT_BBEE1AC1_Opt_11 zT_122 = {0};
    unsigned int zT_123;
    zT_BBEE1AC1_Opt_11 zT_124 = {0};
    zT_3D7259E2_SymbolRegistry* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_128;
    zT_D4761958_Opt_858 zT_130 = {0};
    unsigned char zT_131;
    zT_3C598AEF_SymbolKind zT_133;
    unsigned int zT_138;
    unsigned int zT_139;
    zT_79FAE712_u64 zT_142 = 0;
    zT_BBEE1AC1_Opt_11 zT_143;
    zT_BBEE1AC1_Opt_11 zT_144 = {0};
    zT_22A7C88B_AstNode cn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_99292002_Arr_unsigned_int_16 names;
    unsigned int nlen;
    unsigned int cur;
    zT_22A7C88B_AstNode cw;
    unsigned int base_nid;
    unsigned int cur_mod;
    zT_3A105EF1_Symbol* bs;
    unsigned int i;
    zT_3A105EF1_Symbol* ms;
    zT_3A105EF1_Symbol* fs;
    zT_5 = store;
    zT_6 = callee_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    cn = zT_7;
    zT_8 = cn.kind;
    if ((int)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = store;
    zT_15 = callee_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_14, zT_15);
    nid = zT_16;
    zT_17 = sym_reg;
    zT_18 = module_id;
    zT_19 = nid;
    zT_20 = zF_A398987E_symbolRegistryQuali(zT_17, zT_18, zT_19);
    zT_21 = zT_20.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_35 = cn.kind;
    if ((int)(zT_35 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    s = zT_20.value;
    zT_23 = s->kind;
    if ((int)(zT_23 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_34.has_value = 0;
    return zT_34;
    z_bb_5:
    zT_28 = s->module_id;
    zT_29 = s->name_id;
    zT_32 = zF_9D041EB6_asyncKey(zT_28, zT_29);
    zT_33.has_value = 1;
    zT_33.value = zT_32;
    return zT_33;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_8:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_42[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        names[_i] = zT_42[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    nlen = zT_45;
    zT_46 = store;
    zT_47 = callee_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_46, zT_47);
    zT_49 = (unsigned int)nlen;
    names[zT_49] = zT_48;
    zT_50 = 1;
    zT_52 = nlen + (unsigned int)((unsigned int)zT_50);
    nlen = zT_52;
    zT_54 = cn.child_0;
    cur = zT_54;
    zT_56 = store;
    zT_57 = cur;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cw = zT_58;
    goto z_bb_9;
    z_bb_9:
    zT_59 = cw.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if ((int)(nlen >= (unsigned int)(16))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_78 = cw.kind;
    if ((int)(zT_78 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_14:
    zT_67 = store;
    zT_68 = cur;
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_67, zT_68);
    zT_70 = (unsigned int)nlen;
    names[zT_70] = zT_69;
    zT_71 = 1;
    zT_73 = nlen + (unsigned int)((unsigned int)zT_71);
    nlen = zT_73;
    zT_74 = cw.child_0;
    cur = zT_74;
    zT_75 = store;
    zT_76 = cur;
    zT_77 = zF_FCDD1D35_astStoreNodeAt(zT_75, zT_76);
    cw = zT_77;
    goto z_bb_12;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
    z_bb_16:
    zT_85 = store;
    zT_86 = cur;
    zT_87 = zF_53458827_astStoreIdentifier(zT_85, zT_86);
    base_nid = zT_87;
    cur_mod = module_id;
    zT_89 = sym_reg;
    zT_90 = module_id;
    zT_91 = base_nid;
    zT_92 = zF_A398987E_symbolRegistryQuali(zT_89, zT_90, zT_91);
    zT_93 = zT_92.has_value;
    if (zT_93) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    bs = zT_92.value;
    zT_95 = bs->kind;
    if ((int)(zT_95 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    i = nlen;
    goto z_bb_22;
    z_bb_19:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_20:
    zT_100.has_value = 0;
    return zT_100;
    z_bb_21:
    zT_101 = bs->module_id;
    cur_mod = zT_101;
    goto z_bb_18;
    z_bb_22:
    if ((int)(i > (unsigned int)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_106 = 1;
    zT_108 = i - (unsigned int)((unsigned int)zT_106);
    i = zT_108;
    zT_109 = sym_reg;
    zT_110 = cur_mod;
    zT_112 = (unsigned int)i;
    zT_111 = names[zT_112];
    zT_114 = zF_A398987E_symbolRegistryQuali(zT_109, zT_110, zT_111);
    zT_115 = zT_114.has_value;
    if (zT_115) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_125 = sym_reg;
    zT_126 = cur_mod;
    zT_128 = 0;
    zT_127 = names[zT_128];
    zT_130 = zF_A398987E_symbolRegistryQuali(zT_125, zT_126, zT_127);
    zT_131 = zT_130.has_value;
    if (zT_131) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    ms = zT_114.value;
    zT_117 = ms->kind;
    if ((int)(zT_117 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_124.has_value = 0;
    return zT_124;
    z_bb_29:
    zT_122.has_value = 0;
    return zT_122;
    z_bb_30:
    zT_123 = ms->module_id;
    cur_mod = zT_123;
    goto z_bb_27;
    z_bb_31:
    fs = zT_130.value;
    zT_133 = fs->kind;
    if ((int)(zT_133 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_144.has_value = 0;
    return zT_144;
    z_bb_33:
    zT_138 = fs->module_id;
    zT_139 = fs->name_id;
    zT_142 = zF_9D041EB6_asyncKey(zT_138, zT_139);
    zT_143.has_value = 1;
    zT_143.value = zT_142;
    return zT_143;
    z_bb_34:
    goto z_bb_32;
}

/* scanFunction */
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int caller_idx, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_B687BB96_U32ArrayList* edge_caller, zT_B687BB96_U32ArrayList* edge_callee, zT_47B162D1_U8ArrayList* direct, zT_A4CE86B7_U64ToU32Map* fn_index, unsigned int async_suspend_name_id) {
    zT_B687BB96_U32ArrayList* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_41;
    zT_3D7259E2_SymbolRegistry* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_BBEE1AC1_Opt_11 zT_46 = {0};
    unsigned char zT_47;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    zT_BAEE192E_Opt_10 zT_51 = {0};
    unsigned char zT_52;
    zT_B687BB96_U32ArrayList* zT_54;
    unsigned int zT_55;
    zT_B687BB96_U32ArrayList* zT_56;
    unsigned int zT_57;
    zT_B687BB96_U32ArrayList* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    unsigned int zT_66;
    zT_B687BB96_U32ArrayList* zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    int zT_76;
    unsigned int zT_78;
    unsigned int zT_83;
    unsigned char zT_85;
    unsigned char* zT_86;
    unsigned int zT_87;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_93;
    zT_B687BB96_U32ArrayList* zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_102 = 0;
    int zT_103;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_109;
    zT_8143F551_AstKind zT_110;
    int zT_113 = 0;
    zT_B687BB96_U32ArrayList* zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    int zT_120;
    zT_8143F551_AstKind zT_121;
    int zT_124 = 0;
    zT_B687BB96_U32ArrayList* zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    int zT_131;
    zT_8143F551_AstKind zT_132;
    int zT_135 = 0;
    zT_B687BB96_U32ArrayList* zT_136;
    unsigned int zT_137;
    zT_8143F551_AstKind zT_139;
    int zT_140 = 0;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_144 = 0;
    unsigned int zT_146;
    zT_B687BB96_U32ArrayList* zT_149;
    unsigned int zT_150;
    zT_6B0A7D14_AstStore* zT_151;
    unsigned int zT_152;
    unsigned int zT_155 = 0;
    int zT_156;
    unsigned int zT_158;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int gi;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = stack;
    zT_15 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_14, zT_15);
    goto z_bb_3;
    z_bb_3:
    zT_16 = stack->len;
    if ((int)(zT_16 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = stack->items;
    zT_21 = stack->len;
    zT_22 = 1;
    zT_23 = zT_21 - zT_22;
    zT_24 = zT_20[zT_23];
    ni = zT_24;
    zT_25 = stack->len;
    stack->len = (unsigned int)(zT_25 - (unsigned int)(1));
    zT_29 = store;
    zT_30 = ni;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    n = zT_31;
    zT_33 = n.kind;
    k = zT_33;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_38 = n.child_0;
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_19; else goto z_bb_20;
    z_bb_9:
    zT_41 = store;
    zT_42 = sym_reg;
    zT_43 = module_id;
    zT_44 = n.child_0;
    zT_46 = zF_860C82EC_resolveCalleeKey(zT_41, zT_42, zT_43, zT_44);
    zT_47 = zT_46.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_62 = store;
    zT_63 = ni;
    zT_64 = zF_152E19CB_astStoreNodeExtraCh(zT_62, zT_63);
    ec_n = zT_64;
    zT_66 = 0;
    ei = zT_66;
    goto z_bb_15;
    z_bb_11:
    ck = zT_46.value;
    zT_49 = fn_index;
    zT_50 = ck;
    zT_51 = zF_A05A7BE1_u64ToU32MapGet(zT_49, zT_50);
    zT_52 = zT_51.has_value;
    if (zT_52) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_58 = stack;
    zT_59 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_58, zT_59);
    goto z_bb_10;
    z_bb_13:
    gi = zT_51.value;
    zT_54 = edge_caller;
    zT_55 = caller_idx;
    zF_62F717A2_u32ArrayListAppend(zT_54, zT_55);
    zT_56 = edge_callee;
    zT_57 = gi;
    zF_62F717A2_u32ArrayListAppend(zT_56, zT_57);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((int)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_69 = stack;
    zT_71 = store;
    zT_72 = ni;
    zT_75 = zF_B10B1BC1_astStoreNodeExtraCh(zT_71, zT_72, (unsigned int)((unsigned int)ei));
    zT_70 = zT_75;
    zF_62F717A2_u32ArrayListAppend(zT_69, zT_70);
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_76 = 1;
    zT_78 = ei + (unsigned int)((unsigned int)zT_76);
    ei = zT_78;
    goto z_bb_15;
    z_bb_19:
    zT_83 = n.child_0;
    if ((int)(zT_83 == async_suspend_name_id)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_106 = n.child_0;
    if ((int)(zT_106 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    zT_85 = 1;
    zT_86 = direct->items;
    zT_87 = (unsigned int)caller_idx;
    zT_86[zT_87] = zT_85;
    goto z_bb_22;
    z_bb_22:
    zT_89 = store;
    zT_90 = ni;
    zT_91 = zF_152E19CB_astStoreNodeExtraCh(zT_89, zT_90);
    ec2_n = zT_91;
    zT_93 = 0;
    ei2 = zT_93;
    goto z_bb_23;
    z_bb_23:
    if ((int)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_96 = stack;
    zT_98 = store;
    zT_99 = ni;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)ei2));
    zT_97 = zT_102;
    zF_62F717A2_u32ArrayListAppend(zT_96, zT_97);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_103 = 1;
    zT_105 = ei2 + (unsigned int)((unsigned int)zT_103);
    ei2 = zT_105;
    goto z_bb_23;
    z_bb_27:
    zT_110 = k;
    zT_113 = zF_C395F6FD_nodeChildIsNode(zT_110, (unsigned char)(0));
    zT_109 = zT_113;
    goto z_bb_29;
    z_bb_28:
    zT_109 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_109) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_114 = stack;
    zT_115 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_114, zT_115);
    goto z_bb_31;
    z_bb_31:
    zT_117 = n.child_1;
    if ((int)(zT_117 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_121 = k;
    zT_124 = zF_C395F6FD_nodeChildIsNode(zT_121, (unsigned char)(1));
    zT_120 = zT_124;
    goto z_bb_34;
    z_bb_33:
    zT_120 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_120) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_125 = stack;
    zT_126 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_125, zT_126);
    goto z_bb_36;
    z_bb_36:
    zT_128 = n.child_2;
    if ((int)(zT_128 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_132 = k;
    zT_135 = zF_C395F6FD_nodeChildIsNode(zT_132, (unsigned char)(2));
    zT_131 = zT_135;
    goto z_bb_39;
    z_bb_38:
    zT_131 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_131) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_136 = stack;
    zT_137 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_136, zT_137);
    goto z_bb_41;
    z_bb_41:
    zT_139 = k;
    zT_140 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_139);
    if (zT_140) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_142 = store;
    zT_143 = ni;
    zT_144 = zF_152E19CB_astStoreNodeExtraCh(zT_142, zT_143);
    ec3_n = zT_144;
    zT_146 = 0;
    ei3 = zT_146;
    goto z_bb_44;
    z_bb_43:
    goto z_bb_6;
    z_bb_44:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_149 = stack;
    zT_151 = store;
    zT_152 = ni;
    zT_155 = zF_B10B1BC1_astStoreNodeExtraCh(zT_151, zT_152, (unsigned int)((unsigned int)ei3));
    zT_150 = zT_155;
    zF_62F717A2_u32ArrayListAppend(zT_149, zT_150);
    goto z_bb_47;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_156 = 1;
    zT_158 = ei3 + (unsigned int)((unsigned int)zT_156);
    ei3 = zT_158;
    goto z_bb_44;
}

/* emitSuspMarker */
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64 key) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_5826BFC7_Arr_unsigned_char_1 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_5826BFC7_Arr_unsigned_char_1 zT_44;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54 = 0;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_4 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_4;
    zT_8 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_8;
    zT_10 = "SUSP:m";
    zT_12 = 6;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    m1 = zT_11;
    zT_13 = m1;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = module_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)b1) + zT_21;
    zT_23 = (unsigned int)(12) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    l1 = zT_25;
    zT_30 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_36 = (unsigned int)(11) - s1;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = ":n";
    zT_41 = 2;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    m2 = zT_40;
    zT_42 = m2;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = name_id;
    zT_50 = 0;
    zT_51 = (unsigned char*)((unsigned char*)b2) + zT_50;
    zT_52 = (unsigned int)(12) - zT_50;
    zT_53.ptr = zT_51;
    zT_53.len = zT_52;
    zT_47 = zT_53;
    zT_54 = zF_A7504564_itoa(zT_46, zT_47);
    l2 = zT_54;
    zT_59 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_59;
    zT_64 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_65 = (unsigned int)(11) - s2;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_60 = zT_66;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_68 = "\n";
    zT_70 = 1;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    m3 = zT_69;
    zT_71 = m3;
    zF_48AC7B3A_markerWrite(zT_71);
    return;
}

/* suspensionAnalysisRun */
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_072B53A6_ModuleRegistry* module_reg, zT_D3EB6303_StringInterner* interner, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_C4A0A7DB_U64ArrayList zT_26 = {0};
    zT_3E40CD83_Sand* zT_28;
    zT_47B162D1_U8ArrayList zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_B687BB96_U32ArrayList zT_32 = {0};
    zT_3E40CD83_Sand* zT_34;
    zT_B687BB96_U32ArrayList zT_35 = {0};
    zT_072B53A6_ModuleRegistry* zT_37;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_53 = {0};
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_64;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_22A7C88B_AstNode zT_76 = {0};
    zT_8143F551_AstKind zT_77;
    zT_6B0A7D14_AstStore* zT_83;
    unsigned int zT_84;
    unsigned int zT_85 = 0;
    zT_D7E9BA07_anon_229626 zT_87;
    zT_243D6A41_FnProto* zT_88;
    unsigned int zT_89;
    zT_243D6A41_FnProto zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_94;
    zT_6E8D187B_ModuleEntry zT_95;
    zT_79FAE712_u64 zT_98 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_99;
    zT_79FAE712_u64 zT_100;
    zT_BAEE192E_Opt_10 zT_102 = {0};
    unsigned char zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_109;
    zT_C4A0A7DB_U64ArrayList* zT_111;
    zT_79FAE712_u64 zT_112;
    zT_47B162D1_U8ArrayList* zT_114;
    int zT_118;
    unsigned int zT_120;
    int zT_121;
    unsigned int zT_123;
    zT_3E40CD83_Sand* zT_125;
    zT_B687BB96_U32ArrayList zT_126 = {0};
    unsigned int zT_127;
    unsigned int zT_129;
    zT_6E8D187B_ModuleEntry* zT_132;
    zT_6E8D187B_ModuleEntry zT_133;
    unsigned int zT_134;
    zT_6B0A7D14_AstStore* zT_138;
    unsigned int zT_139;
    zT_22A7C88B_AstNode zT_140 = {0};
    zT_8143F551_AstKind zT_141;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    unsigned int zT_149 = 0;
    unsigned int zT_151;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    unsigned int zT_159 = 0;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    zT_22A7C88B_AstNode zT_163 = {0};
    zT_8143F551_AstKind zT_164;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_172 = 0;
    zT_D7E9BA07_anon_229626 zT_174;
    zT_243D6A41_FnProto* zT_175;
    unsigned int zT_176;
    zT_243D6A41_FnProto zT_177;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_6E8D187B_ModuleEntry* zT_181;
    zT_6E8D187B_ModuleEntry zT_182;
    zT_79FAE712_u64 zT_185 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_187;
    zT_79FAE712_u64 zT_188;
    zT_BAEE192E_Opt_10 zT_190 = {0};
    unsigned char zT_191;
    zT_6B0A7D14_AstStore* zT_193;
    zT_3D7259E2_SymbolRegistry* zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_B687BB96_U32ArrayList* zT_198;
    zT_B687BB96_U32ArrayList* zT_199;
    zT_B687BB96_U32ArrayList* zT_200;
    zT_47B162D1_U8ArrayList* zT_201;
    zT_A4CE86B7_U64ToU32Map* zT_202;
    unsigned int zT_203;
    zT_6E8D187B_ModuleEntry* zT_204;
    zT_6E8D187B_ModuleEntry zT_205;
    int zT_213;
    unsigned int zT_215;
    int zT_216;
    unsigned int zT_218;
    unsigned int zT_220;
    zT_3E40CD83_Sand* zT_224;
    unsigned int zT_225;
    unsigned int* zT_226 = 0;
    unsigned int zT_228;
    unsigned int zT_230;
    int zT_231;
    unsigned int zT_233;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_244;
    unsigned int zT_245;
    int zT_246;
    unsigned int zT_248;
    zT_3E40CD83_Sand* zT_250;
    unsigned int* zT_254 = 0;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_259;
    unsigned int zT_260;
    int zT_261;
    unsigned int zT_263;
    zT_3E40CD83_Sand* zT_265;
    unsigned int zT_266;
    unsigned int* zT_267 = 0;
    unsigned int zT_268;
    unsigned int zT_270;
    int zT_271;
    unsigned int zT_273;
    zT_3E40CD83_Sand* zT_275;
    unsigned int zT_276;
    unsigned int* zT_278 = 0;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned int* zT_283;
    unsigned int zT_284;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int* zT_288;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_292;
    unsigned int zT_293;
    int zT_294;
    unsigned int zT_296;
    zT_3E40CD83_Sand* zT_298;
    unsigned int zT_299;
    unsigned int* zT_300 = 0;
    unsigned int zT_302;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char* zT_307;
    unsigned char zT_308;
    zT_A4CE86B7_U64ToU32Map* zT_311;
    zT_79FAE712_u64 zT_312;
    zT_79FAE712_u64* zT_314;
    unsigned int zT_317;
    unsigned int zT_319;
    int zT_320;
    unsigned int zT_322;
    unsigned int zT_325;
    unsigned int zT_327;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_79FAE712_u64* zT_342;
    unsigned int zT_343;
    zT_79FAE712_u64 zT_344;
    zT_A4CE86B7_U64ToU32Map* zT_345;
    zT_79FAE712_u64 zT_346;
    zT_BAEE192E_Opt_10 zT_347 = {0};
    unsigned char zT_348;
    zT_A4CE86B7_U64ToU32Map* zT_350;
    zT_79FAE712_u64 zT_351;
    unsigned int zT_355;
    unsigned int zT_357;
    unsigned int zT_359;
    unsigned int zT_360;
    zT_79FAE712_u64* zT_363;
    zT_79FAE712_u64 zT_364;
    zT_A4CE86B7_U64ToU32Map* zT_366;
    zT_79FAE712_u64 zT_367;
    zT_BAEE192E_Opt_10 zT_368 = {0};
    unsigned char zT_369;
    zT_79FAE712_u64 zT_373;
    int zT_374;
    unsigned int zT_376;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_A4CE86B7_U64ToU32Map fn_index;
    zT_C4A0A7DB_U64ArrayList fn_keys;
    zT_47B162D1_U8ArrayList direct;
    zT_B687BB96_U32ArrayList edge_caller;
    zT_B687BB96_U32ArrayList edge_callee;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_B687BB96_U32ArrayList stack;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned int ast_root2;
    unsigned int n;
    zT_22A7C88B_AstNode root2;
    unsigned int decls2_n;
    unsigned int di2;
    unsigned int decl2_idx;
    zT_22A7C88B_AstNode decl2;
    unsigned int proto_idx2;
    zT_243D6A41_FnProto proto2;
    zT_79FAE712_u64 key2;
    zT_BAEE192E_Opt_10 cidx;
    unsigned int ci0;
    unsigned int* rev_count;
    unsigned int i;
    unsigned int m;
    unsigned int e;
    unsigned int g;
    unsigned int* rev_off;
    unsigned int acc;
    unsigned int* rev_pos;
    unsigned int* rev_to;
    unsigned int g2;
    unsigned int p;
    unsigned int* queue;
    unsigned int head;
    unsigned int tail;
    unsigned int g3;
    unsigned int k0;
    unsigned int k1;
    unsigned int kk;
    unsigned int c;
    zT_79FAE712_u64 ckey;
    zT_79FAE712_u64 kk2;
    zT_BAEE192E_Opt_10 vv;
    unsigned int val2;
    zT_7 = "YA\n";
    zT_9 = 3;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    p_msg = zT_8;
    zT_10 = p_msg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = "@asyncSuspend";
    zT_14 = 13;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    asu_text = zT_13;
    zT_16 = interner;
    zT_17 = asu_text;
    zT_18 = zF_50C274AF_stringInternerInter(zT_16, zT_17);
    async_suspend_name_id = zT_18;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    fn_index = zT_21;
    zT_23 = alloc;
    zT_26 = zF_477F0605_u64ArrayListInit(zT_23, (unsigned int)(256));
    fn_keys = zT_26;
    zT_28 = alloc;
    zT_29 = zF_E9FF0E66_byteArrayListInit(zT_28);
    direct = zT_29;
    zT_31 = alloc;
    zT_32 = zF_8E537D0C_u32ArrayListInit(zT_31);
    edge_caller = zT_32;
    zT_34 = alloc;
    zT_35 = zF_8E537D0C_u32ArrayListInit(zT_34);
    edge_callee = zT_35;
    zT_37 = module_reg;
    zT_38 = zF_3452C137_moduleRegistryGetMo(zT_37);
    mods = zT_38;
    zT_40 = 0;
    mi = zT_40;
    goto z_bb_1;
    z_bb_1:
    zT_42 = mods.len;
    if ((int)(mi < zT_42)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_45 = mods.ptr;
    zT_46 = zT_45[mi];
    zT_47 = zT_46.ast_root;
    ast_root = zT_47;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_125 = alloc;
    zT_126 = zF_8E537D0C_u32ArrayListInit(zT_125);
    stack = zT_126;
    zT_127 = 0;
    mi = zT_127;
    goto z_bb_17;
    z_bb_4:
    zT_121 = 1;
    zT_123 = mi + (unsigned int)((unsigned int)zT_121);
    mi = zT_123;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_51 = store;
    zT_52 = ast_root;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    root = zT_53;
    zT_54 = root.kind;
    if ((int)(zT_54 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_60 = store;
    zT_61 = ast_root;
    zT_62 = zF_152E19CB_astStoreNodeExtraCh(zT_60, zT_61);
    decls_n = zT_62;
    zT_64 = 0;
    di = zT_64;
    goto z_bb_9;
    z_bb_9:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_68 = store;
    zT_69 = ast_root;
    zT_72 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)di));
    decl_idx = zT_72;
    zT_74 = store;
    zT_75 = decl_idx;
    zT_76 = zF_FCDD1D35_astStoreNodeAt(zT_74, zT_75);
    decl = zT_76;
    zT_77 = decl.kind;
    if ((int)(zT_77 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_118 = 1;
    zT_120 = di + (unsigned int)((unsigned int)zT_118);
    di = zT_120;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_83 = store;
    zT_84 = decl_idx;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_83, zT_84);
    proto_idx = zT_85;
    zT_87 = store->fn_protos;
    zT_88 = zT_87.items;
    zT_89 = (unsigned int)proto_idx;
    zT_90 = zT_88[zT_89];
    proto = zT_90;
    zT_94 = mods.ptr;
    zT_95 = zT_94[mi];
    zT_92 = zT_95.id;
    zT_93 = proto.name_id;
    zT_98 = zF_9D041EB6_asyncKey(zT_92, zT_93);
    key = zT_98;
    zT_99 = &fn_index;
    zT_100 = key;
    zT_102 = zF_A05A7BE1_u64ToU32MapGet(zT_99, zT_100);
    zT_103 = zT_102.has_value;
    if ((int)(!zT_103)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_105 = &fn_index;
    zT_106 = key;
    zT_109 = fn_keys.len;
    zF_B6EB812C_u64ToU32MapPut(zT_105, zT_106, (unsigned int)((unsigned int)zT_109));
    zT_111 = &fn_keys;
    zT_112 = key;
    zF_A553AD3B_u64ArrayListAppend(zT_111, zT_112);
    zT_114 = &direct;
    zF_463FE7A4_byteArrayListAppend(zT_114, (unsigned char)(0));
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    zT_129 = mods.len;
    if ((int)(mi < zT_129)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_132 = mods.ptr;
    zT_133 = zT_132[mi];
    zT_134 = zT_133.ast_root;
    ast_root2 = zT_134;
    if ((int)(ast_root2 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_220 = fn_keys.len;
    n = zT_220;
    if ((int)(n > (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_20:
    zT_216 = 1;
    zT_218 = mi + (unsigned int)((unsigned int)zT_216);
    mi = zT_218;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_138 = store;
    zT_139 = ast_root2;
    zT_140 = zF_FCDD1D35_astStoreNodeAt(zT_138, zT_139);
    root2 = zT_140;
    zT_141 = root2.kind;
    if ((int)(zT_141 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_147 = store;
    zT_148 = ast_root2;
    zT_149 = zF_152E19CB_astStoreNodeExtraCh(zT_147, zT_148);
    decls2_n = zT_149;
    zT_151 = 0;
    di2 = zT_151;
    goto z_bb_25;
    z_bb_25:
    if ((int)(di2 < (unsigned int)((unsigned int)decls2_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_155 = store;
    zT_156 = ast_root2;
    zT_159 = zF_B10B1BC1_astStoreNodeExtraCh(zT_155, zT_156, (unsigned int)((unsigned int)di2));
    decl2_idx = zT_159;
    zT_161 = store;
    zT_162 = decl2_idx;
    zT_163 = zF_FCDD1D35_astStoreNodeAt(zT_161, zT_162);
    decl2 = zT_163;
    zT_164 = decl2.kind;
    if ((int)(zT_164 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_213 = 1;
    zT_215 = di2 + (unsigned int)((unsigned int)zT_213);
    di2 = zT_215;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_170 = store;
    zT_171 = decl2_idx;
    zT_172 = zF_8BA26B9E_astStoreNodePayload(zT_170, zT_171);
    proto_idx2 = zT_172;
    zT_174 = store->fn_protos;
    zT_175 = zT_174.items;
    zT_176 = (unsigned int)proto_idx2;
    zT_177 = zT_175[zT_176];
    proto2 = zT_177;
    zT_181 = mods.ptr;
    zT_182 = zT_181[mi];
    zT_179 = zT_182.id;
    zT_180 = proto2.name_id;
    zT_185 = zF_9D041EB6_asyncKey(zT_179, zT_180);
    key2 = zT_185;
    zT_187 = &fn_index;
    zT_188 = key2;
    zT_190 = zF_A05A7BE1_u64ToU32MapGet(zT_187, zT_188);
    cidx = zT_190;
    zT_191 = cidx.has_value;
    if (zT_191) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    ci0 = cidx.value;
    zT_193 = store;
    zT_194 = sym_reg;
    zT_204 = mods.ptr;
    zT_205 = zT_204[mi];
    zT_195 = zT_205.id;
    zT_196 = ci0;
    zT_197 = decl2.child_0;
    zT_198 = &stack;
    zT_199 = &edge_caller;
    zT_200 = &edge_callee;
    zT_201 = &direct;
    zT_202 = &fn_index;
    zT_203 = async_suspend_name_id;
    zF_32651930_scanFunction(zT_193, zT_194, zT_195, zT_196, zT_197, zT_198, zT_199, zT_200, zT_201, zT_202, zT_203);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_224 = alloc;
    zT_225 = n;
    zT_226 = zF_43BEEDA4_allocU32(zT_224, zT_225);
    rev_count = zT_226;
    zT_228 = 0;
    i = zT_228;
    goto z_bb_35;
    z_bb_34:
    zT_359 = 0;
    m = zT_359;
    goto z_bb_71;
    z_bb_35:
    if ((int)(i < n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_230 = 0;
    rev_count[i] = zT_230;
    goto z_bb_38;
    z_bb_37:
    zT_235 = 0;
    e = zT_235;
    goto z_bb_39;
    z_bb_38:
    zT_231 = 1;
    zT_233 = i + (unsigned int)((unsigned int)zT_231);
    i = zT_233;
    goto z_bb_35;
    z_bb_39:
    zT_236 = edge_callee.len;
    if ((int)(e < zT_236)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_239 = edge_callee.items;
    zT_240 = zT_239[e];
    g = zT_240;
    zT_241 = (unsigned int)g;
    zT_242 = rev_count[zT_241];
    zT_244 = zT_242 + (unsigned int)(1);
    zT_245 = (unsigned int)g;
    rev_count[zT_245] = zT_244;
    goto z_bb_42;
    z_bb_41:
    zT_250 = alloc;
    zT_254 = zF_43BEEDA4_allocU32(zT_250, (unsigned int)(n + (unsigned int)(1)));
    rev_off = zT_254;
    zT_256 = 0;
    acc = zT_256;
    zT_257 = 0;
    i = zT_257;
    goto z_bb_43;
    z_bb_42:
    zT_246 = 1;
    zT_248 = e + (unsigned int)((unsigned int)zT_246);
    e = zT_248;
    goto z_bb_39;
    z_bb_43:
    if ((int)(i < n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    rev_off[i] = acc;
    zT_259 = rev_count[i];
    zT_260 = acc + zT_259;
    acc = zT_260;
    goto z_bb_46;
    z_bb_45:
    rev_off[n] = acc;
    zT_265 = alloc;
    zT_266 = n;
    zT_267 = zF_43BEEDA4_allocU32(zT_265, zT_266);
    rev_pos = zT_267;
    zT_268 = 0;
    i = zT_268;
    goto z_bb_47;
    z_bb_46:
    zT_261 = 1;
    zT_263 = i + (unsigned int)((unsigned int)zT_261);
    i = zT_263;
    goto z_bb_43;
    z_bb_47:
    if ((int)(i < n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_270 = rev_off[i];
    rev_pos[i] = zT_270;
    goto z_bb_50;
    z_bb_49:
    zT_275 = alloc;
    zT_276 = edge_callee.len;
    zT_278 = zF_43BEEDA4_allocU32(zT_275, zT_276);
    rev_to = zT_278;
    zT_279 = 0;
    e = zT_279;
    goto z_bb_51;
    z_bb_50:
    zT_271 = 1;
    zT_273 = i + (unsigned int)((unsigned int)zT_271);
    i = zT_273;
    goto z_bb_47;
    z_bb_51:
    zT_280 = edge_callee.len;
    if ((int)(e < zT_280)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_283 = edge_callee.items;
    zT_284 = zT_283[e];
    g2 = zT_284;
    zT_286 = (unsigned int)g2;
    zT_287 = rev_pos[zT_286];
    p = zT_287;
    zT_288 = edge_caller.items;
    zT_289 = zT_288[e];
    zT_290 = (unsigned int)p;
    rev_to[zT_290] = zT_289;
    zT_292 = p + (unsigned int)(1);
    zT_293 = (unsigned int)g2;
    rev_pos[zT_293] = zT_292;
    goto z_bb_54;
    z_bb_53:
    zT_298 = alloc;
    zT_299 = n;
    zT_300 = zF_43BEEDA4_allocU32(zT_298, zT_299);
    queue = zT_300;
    zT_302 = 0;
    head = zT_302;
    zT_304 = 0;
    tail = zT_304;
    zT_305 = 0;
    i = zT_305;
    goto z_bb_55;
    z_bb_54:
    zT_294 = 1;
    zT_296 = e + (unsigned int)((unsigned int)zT_294);
    e = zT_296;
    goto z_bb_51;
    z_bb_55:
    if ((int)(i < n)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_307 = direct.items;
    zT_308 = zT_307[i];
    if ((int)(zT_308 != (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    goto z_bb_61;
    z_bb_58:
    zT_320 = 1;
    zT_322 = i + (unsigned int)((unsigned int)zT_320);
    i = zT_322;
    goto z_bb_55;
    z_bb_59:
    zT_311 = suspending_fns;
    zT_314 = fn_keys.items;
    zT_312 = zT_314[i];
    zF_B6EB812C_u64ToU32MapPut(zT_311, zT_312, (unsigned int)(1));
    zT_317 = (unsigned int)i;
    queue[tail] = zT_317;
    zT_319 = tail + (unsigned int)(1);
    tail = zT_319;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    if ((int)(head < tail)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_325 = queue[head];
    g3 = zT_325;
    zT_327 = head + (unsigned int)(1);
    head = zT_327;
    zT_329 = (unsigned int)g3;
    zT_330 = rev_off[zT_329];
    k0 = zT_330;
    zT_334 = (unsigned int)((unsigned int)g3) + (unsigned int)(1);
    zT_335 = rev_off[zT_334];
    k1 = zT_335;
    kk = k0;
    goto z_bb_65;
    z_bb_63:
    goto z_bb_34;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    if ((int)(kk < k1)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_339 = (unsigned int)kk;
    zT_340 = rev_to[zT_339];
    c = zT_340;
    zT_342 = fn_keys.items;
    zT_343 = (unsigned int)c;
    zT_344 = zT_342[zT_343];
    ckey = zT_344;
    zT_345 = suspending_fns;
    zT_346 = ckey;
    zT_347 = zF_A05A7BE1_u64ToU32MapGet(zT_345, zT_346);
    zT_348 = zT_347.has_value;
    if ((int)(!zT_348)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_357 = kk + (unsigned int)(1);
    kk = zT_357;
    goto z_bb_65;
    z_bb_69:
    zT_350 = suspending_fns;
    zT_351 = ckey;
    zF_B6EB812C_u64ToU32MapPut(zT_350, zT_351, (unsigned int)(1));
    queue[tail] = c;
    zT_355 = tail + (unsigned int)(1);
    tail = zT_355;
    goto z_bb_70;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_360 = fn_keys.len;
    if ((int)(m < zT_360)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_363 = fn_keys.items;
    zT_364 = zT_363[m];
    kk2 = zT_364;
    zT_366 = suspending_fns;
    zT_367 = kk2;
    zT_368 = zF_A05A7BE1_u64ToU32MapGet(zT_366, zT_367);
    vv = zT_368;
    zT_369 = vv.has_value;
    if (zT_369) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return;
    z_bb_74:
    zT_374 = 1;
    zT_376 = m + (unsigned int)((unsigned int)zT_374);
    m = zT_376;
    goto z_bb_71;
    z_bb_75:
    val2 = vv.value;
    if ((int)(val2 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_373 = kk2;
    zF_76D5E8D3_emitSuspMarker(zT_373);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* frameFieldSizeAlign */
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    zT_19 = t.alignment;
    if ((int)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_22 = t.alignment;
    al = zT_22;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* addFrameField */
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    unsigned int at;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_8 = reg;
    zT_9 = tid;
    zT_10 = &sz;
    zT_11 = &al;
    zF_816D1610_frameFieldSizeAlign(zT_8, zT_9, zT_10, zT_11);
    zT_14 = *offset;
    zT_15 = al;
    zT_17 = zF_978D7C93_alignUpU32(zT_14, zT_15);
    *offset = zT_17;
    zT_19 = *offset;
    at = zT_19;
    zT_20 = *offset;
    *offset = (unsigned int)(zT_20 + sz);
    zT_22 = *max_align;
    if ((int)(al > zT_22)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = al;
    goto z_bb_2;
    z_bb_2:
    return at;
}

/* typeIsPtrVoid */
int zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_112BF819_PtrPayload zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_17 = reg->ptr_items;
    zT_18 = t.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.base;
    base = zT_21;
    return (int)(base == (unsigned int)(1));
}

/* frameLocalTypeId */
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable* resolved_types, zT_22A7C88B_AstNode n) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned int t;
    zT_2 = n.child_0;
    if ((int)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_5 = resolved_types;
    zT_6 = n.child_0;
    zT_8 = zF_999DCF51_resolvedTypeTableGe(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    return (unsigned int)(18);
    z_bb_3:
    zT_11 = n.child_1;
    if ((int)(zT_11 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    t = zT_8.value;
    return t;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_14 = resolved_types;
    zT_15 = n.child_1;
    zT_17 = zF_999DCF51_resolvedTypeTableGe(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_2;
    z_bb_8:
    t = zT_17.value;
    return t;
    z_bb_9:
    goto z_bb_7;
}

/* scanFrameLocals */
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore* store, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_338B7C76_TypeRegistry* reg, zT_8EED1867_ResolvedTypeTable* resolved_types, unsigned int* offset, unsigned int* max_align) {
    zT_B687BB96_U32ArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_29;
    unsigned int zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_34 = {0};
    unsigned char zT_35;
    int zT_39;
    zT_8EED1867_ResolvedTypeTable* zT_44;
    zT_22A7C88B_AstNode zT_45;
    unsigned int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_47;
    unsigned int zT_48;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned int zT_51 = 0;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned int zT_61;
    unsigned int zT_65;
    zT_B687BB96_U32ArrayList* zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_80 = 0;
    unsigned int zT_82;
    unsigned int zT_86;
    zT_B687BB96_U32ArrayList* zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int zT_93 = 0;
    unsigned int zT_94;
    zT_B687BB96_U32ArrayList* zT_97;
    unsigned int zT_98;
    zT_8143F551_AstKind zT_100;
    int zT_101 = 0;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_107;
    unsigned int zT_111;
    zT_B687BB96_U32ArrayList* zT_112;
    unsigned int zT_113;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int zT_118 = 0;
    unsigned int zT_119;
    int zT_122;
    zT_8143F551_AstKind zT_123;
    int zT_126 = 0;
    zT_B687BB96_U32ArrayList* zT_127;
    unsigned int zT_128;
    unsigned int zT_130;
    int zT_133;
    zT_8143F551_AstKind zT_134;
    int zT_137 = 0;
    zT_B687BB96_U32ArrayList* zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    int zT_144;
    zT_8143F551_AstKind zT_145;
    int zT_148 = 0;
    zT_B687BB96_U32ArrayList* zT_149;
    unsigned int zT_150;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int lvt;
    unsigned int t;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = stack;
    zT_11 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_10, zT_11);
    goto z_bb_3;
    z_bb_3:
    zT_12 = stack->len;
    if ((int)(zT_12 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = stack->items;
    zT_17 = stack->len;
    zT_19 = zT_17 - (unsigned int)(1);
    zT_20 = zT_16[zT_19];
    ni = zT_20;
    zT_21 = stack->len;
    stack->len = (unsigned int)(zT_21 - (unsigned int)(1));
    zT_25 = store;
    zT_26 = ni;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    n = zT_27;
    zT_29 = n.kind;
    k = zT_29;
    zT_31 = 18;
    lvt = zT_31;
    zT_32 = resolved_types;
    zT_33 = ni;
    zT_34 = zF_999DCF51_resolvedTypeTableGe(zT_32, zT_33);
    zT_35 = zT_34.has_value;
    if (zT_35) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    t = zT_34.value;
    lvt = t;
    goto z_bb_8;
    z_bb_8:
    if ((int)(lvt == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_11;
    z_bb_10:
    zT_39 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_44 = resolved_types;
    zT_45 = n;
    zT_46 = zF_436F92E0_frameLocalTypeId(zT_44, zT_45);
    lvt = zT_46;
    goto z_bb_13;
    z_bb_13:
    zT_47 = reg;
    zT_48 = lvt;
    zT_49 = offset;
    zT_50 = max_align;
    zT_51 = zF_769CB99B_addFrameField(zT_47, zT_48, zT_49, zT_50);
    (void)zT_51;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = store;
    zT_58 = ni;
    zT_59 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    ecb_n = zT_59;
    zT_61 = (unsigned int)ecb_n;
    bi = zT_61;
    goto z_bb_16;
    z_bb_15:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_20; else goto z_bb_21;
    z_bb_16:
    if ((int)(bi > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_65 = bi - (unsigned int)(1);
    bi = zT_65;
    zT_66 = stack;
    zT_68 = store;
    zT_69 = ni;
    zT_72 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)bi));
    zT_67 = zT_72;
    zF_62F717A2_u32ArrayListAppend(zT_66, zT_67);
    goto z_bb_19;
    z_bb_18:
    goto z_bb_6;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_78 = store;
    zT_79 = ni;
    zT_80 = zF_152E19CB_astStoreNodeExtraCh(zT_78, zT_79);
    ecf_n = zT_80;
    zT_82 = (unsigned int)ecf_n;
    fi = zT_82;
    goto z_bb_22;
    z_bb_21:
    zT_100 = k;
    zT_101 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_100);
    if (zT_101) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    if ((int)(fi > (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_86 = fi - (unsigned int)(1);
    fi = zT_86;
    zT_87 = stack;
    zT_89 = store;
    zT_90 = ni;
    zT_93 = zF_B10B1BC1_astStoreNodeExtraCh(zT_89, zT_90, (unsigned int)((unsigned int)fi));
    zT_88 = zT_93;
    zF_62F717A2_u32ArrayListAppend(zT_87, zT_88);
    goto z_bb_25;
    z_bb_24:
    zT_94 = n.child_0;
    if ((int)(zT_94 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_97 = stack;
    zT_98 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_97, zT_98);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_103 = store;
    zT_104 = ni;
    zT_105 = zF_152E19CB_astStoreNodeExtraCh(zT_103, zT_104);
    ec3_n = zT_105;
    zT_107 = (unsigned int)ec3_n;
    ei3 = zT_107;
    goto z_bb_30;
    z_bb_29:
    zT_119 = n.child_2;
    if ((int)(zT_119 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((int)(ei3 > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_111 = ei3 - (unsigned int)(1);
    ei3 = zT_111;
    zT_112 = stack;
    zT_114 = store;
    zT_115 = ni;
    zT_118 = zF_B10B1BC1_astStoreNodeExtraCh(zT_114, zT_115, (unsigned int)((unsigned int)ei3));
    zT_113 = zT_118;
    zF_62F717A2_u32ArrayListAppend(zT_112, zT_113);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_123 = k;
    zT_126 = zF_C395F6FD_nodeChildIsNode(zT_123, (unsigned char)(2));
    zT_122 = zT_126;
    goto z_bb_36;
    z_bb_35:
    zT_122 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_122) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_127 = stack;
    zT_128 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_127, zT_128);
    goto z_bb_38;
    z_bb_38:
    zT_130 = n.child_1;
    if ((int)(zT_130 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_134 = k;
    zT_137 = zF_C395F6FD_nodeChildIsNode(zT_134, (unsigned char)(1));
    zT_133 = zT_137;
    goto z_bb_41;
    z_bb_40:
    zT_133 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_133) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_138 = stack;
    zT_139 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_138, zT_139);
    goto z_bb_43;
    z_bb_43:
    zT_141 = n.child_0;
    if ((int)(zT_141 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_145 = k;
    zT_148 = zF_C395F6FD_nodeChildIsNode(zT_145, (unsigned char)(0));
    zT_144 = zT_148;
    goto z_bb_46;
    z_bb_45:
    zT_144 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_144) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_149 = stack;
    zT_150 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_149, zT_150);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_6;
}

/* scanImplicitAwaits */
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, zT_79FAE712_u64 caller_key, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* fn_ret_types, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* hidden_fns, zT_B687BB96_U32ArrayList* parent_type_list, zT_A4CE86B7_U64ToU32Map* parent_start, zT_A4CE86B7_U64ToU32Map* parent_count) {
    zT_B687BB96_U32ArrayList* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33 = {0};
    zT_8143F551_AstKind zT_35;
    unsigned int zT_40;
    zT_6B0A7D14_AstStore* zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_BBEE1AC1_Opt_11 zT_48 = {0};
    unsigned char zT_49;
    unsigned int zT_54;
    unsigned int zT_58;
    zT_A4CE86B7_U64ToU32Map* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_63;
    zT_79FAE712_u64 zT_64;
    unsigned int zT_68;
    zT_A4CE86B7_U64ToU32Map* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    zT_79FAE712_u64 zT_79;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    zT_79FAE712_u64 zT_90;
    zT_BAEE192E_Opt_10 zT_91 = {0};
    unsigned char zT_92;
    zT_A4CE86B7_U64ToU32Map* zT_96;
    zT_79FAE712_u64 zT_97;
    unsigned int zT_99;
    zT_B687BB96_U32ArrayList* zT_101;
    unsigned int zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_A4CE86B7_U64ToU32Map* zT_108;
    zT_79FAE712_u64 zT_109;
    unsigned int zT_110;
    zT_B687BB96_U32ArrayList* zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int zT_117 = 0;
    unsigned int zT_119;
    zT_B687BB96_U32ArrayList* zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_128 = 0;
    int zT_129;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_138;
    unsigned int zT_139 = 0;
    unsigned int zT_141;
    zT_B687BB96_U32ArrayList* zT_144;
    unsigned int zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    unsigned int zT_150 = 0;
    int zT_151;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_157;
    zT_8143F551_AstKind zT_158;
    int zT_161 = 0;
    zT_B687BB96_U32ArrayList* zT_162;
    unsigned int zT_163;
    unsigned int zT_165;
    int zT_168;
    zT_8143F551_AstKind zT_169;
    int zT_172 = 0;
    zT_B687BB96_U32ArrayList* zT_173;
    unsigned int zT_174;
    unsigned int zT_176;
    int zT_179;
    zT_8143F551_AstKind zT_180;
    int zT_183 = 0;
    zT_B687BB96_U32ArrayList* zT_184;
    unsigned int zT_185;
    zT_8143F551_AstKind zT_187;
    int zT_188 = 0;
    zT_6B0A7D14_AstStore* zT_190;
    unsigned int zT_191;
    unsigned int zT_192 = 0;
    unsigned int zT_194;
    zT_B687BB96_U32ArrayList* zT_197;
    unsigned int zT_198;
    zT_6B0A7D14_AstStore* zT_199;
    unsigned int zT_200;
    unsigned int zT_203 = 0;
    int zT_204;
    unsigned int zT_206;
    zT_A4CE86B7_U64ToU32Map* zT_207;
    zT_79FAE712_u64 zT_208;
    zT_BAEE192E_Opt_10 zT_209 = {0};
    unsigned char zT_210;
    zT_A4CE86B7_U64ToU32Map* zT_214;
    zT_79FAE712_u64 zT_215;
    zT_BAEE192E_Opt_10 zT_216 = {0};
    unsigned char zT_217;
    unsigned int zT_220;
    unsigned int zT_222;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int* zT_229;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int hf;
    unsigned int old;
    unsigned int rt;
    unsigned int r;
    unsigned int pc;
    unsigned int oldc;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    unsigned int ps;
    unsigned int lo;
    unsigned int hi;
    unsigned int tmp;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_16 = stack;
    zT_17 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_16, zT_17);
    goto z_bb_3;
    z_bb_3:
    zT_18 = stack->len;
    if ((int)(zT_18 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = stack->items;
    zT_23 = stack->len;
    zT_25 = zT_23 - (unsigned int)(1);
    zT_26 = zT_22[zT_25];
    ni = zT_26;
    zT_27 = stack->len;
    stack->len = (unsigned int)(zT_27 - (unsigned int)(1));
    zT_31 = store;
    zT_32 = ni;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    n = zT_33;
    zT_35 = n.kind;
    k = zT_35;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_207 = parent_count;
    zT_208 = caller_key;
    zT_209 = zF_A05A7BE1_u64ToU32MapGet(zT_207, zT_208);
    zT_210 = zT_209.has_value;
    if (zT_210) goto z_bb_56; else goto z_bb_57;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_40 = n.child_0;
    if ((int)(zT_40 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_9:
    zT_43 = store;
    zT_44 = sym_reg;
    zT_45 = module_id;
    zT_46 = n.child_0;
    zT_48 = zF_860C82EC_resolveCalleeKey(zT_43, zT_44, zT_45, zT_46);
    zT_49 = zT_48.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_115 = store;
    zT_116 = ni;
    zT_117 = zF_152E19CB_astStoreNodeExtraCh(zT_115, zT_116);
    ec_n = zT_117;
    zT_119 = 0;
    ei = zT_119;
    goto z_bb_25;
    z_bb_11:
    ck = zT_48.value;
    zT_54 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_54;
    zT_58 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_58;
    zT_59 = suspending_fns;
    zT_60 = cmid;
    zT_61 = cnid;
    zT_62 = zF_7C7E43BF_asyncIsSuspending(zT_59, zT_60, zT_61);
    if (zT_62) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_111 = stack;
    zT_112 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_111, zT_112);
    goto z_bb_10;
    z_bb_13:
    zT_63 = awaited_fns;
    zT_64 = ck;
    zF_B6EB812C_u64ToU32MapPut(zT_63, zT_64, (unsigned int)(1));
    (void)store;
    zT_68 = 1;
    hf = zT_68;
    zT_69 = hidden_fns;
    zT_70 = caller_key;
    zT_71 = zF_A05A7BE1_u64ToU32MapGet(zT_69, zT_70);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    old = zT_71.value;
    zT_75 = old | (unsigned int)(1);
    hf = zT_75;
    goto z_bb_16;
    z_bb_16:
    zT_77 = 1;
    rt = zT_77;
    zT_78 = fn_ret_types;
    zT_79 = ck;
    zT_80 = zF_A05A7BE1_u64ToU32MapGet(zT_78, zT_79);
    zT_81 = zT_80.has_value;
    if (zT_81) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    r = zT_80.value;
    rt = r;
    goto z_bb_18;
    z_bb_18:
    if ((int)(rt != (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_86 = hf | (unsigned int)(2);
    hf = zT_86;
    zT_88 = 0;
    pc = zT_88;
    zT_89 = parent_count;
    zT_90 = caller_key;
    zT_91 = zF_A05A7BE1_u64ToU32MapGet(zT_89, zT_90);
    zT_92 = zT_91.has_value;
    if (zT_92) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_108 = hidden_fns;
    zT_109 = caller_key;
    zT_110 = hf;
    zF_B6EB812C_u64ToU32MapPut(zT_108, zT_109, zT_110);
    (void)store;
    goto z_bb_14;
    z_bb_21:
    oldc = zT_91.value;
    pc = oldc;
    goto z_bb_22;
    z_bb_22:
    if ((int)(pc == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_96 = parent_start;
    zT_97 = caller_key;
    zT_99 = parent_type_list->len;
    zF_B6EB812C_u64ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)zT_99));
    (void)store;
    goto z_bb_24;
    z_bb_24:
    zT_101 = parent_type_list;
    zT_102 = rt;
    zF_62F717A2_u32ArrayListAppend(zT_101, zT_102);
    zT_103 = parent_count;
    zT_104 = caller_key;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, (unsigned int)(pc + (unsigned int)(1)));
    (void)store;
    goto z_bb_20;
    z_bb_25:
    if ((int)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_122 = stack;
    zT_124 = store;
    zT_125 = ni;
    zT_128 = zF_B10B1BC1_astStoreNodeExtraCh(zT_124, zT_125, (unsigned int)((unsigned int)ei));
    zT_123 = zT_128;
    zF_62F717A2_u32ArrayListAppend(zT_122, zT_123);
    goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_129 = 1;
    zT_131 = ei + (unsigned int)((unsigned int)zT_129);
    ei = zT_131;
    goto z_bb_25;
    z_bb_29:
    zT_137 = store;
    zT_138 = ni;
    zT_139 = zF_152E19CB_astStoreNodeExtraCh(zT_137, zT_138);
    ec2_n = zT_139;
    zT_141 = 0;
    ei2 = zT_141;
    goto z_bb_31;
    z_bb_30:
    zT_154 = n.child_0;
    if ((int)(zT_154 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    if ((int)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_144 = stack;
    zT_146 = store;
    zT_147 = ni;
    zT_150 = zF_B10B1BC1_astStoreNodeExtraCh(zT_146, zT_147, (unsigned int)((unsigned int)ei2));
    zT_145 = zT_150;
    zF_62F717A2_u32ArrayListAppend(zT_144, zT_145);
    goto z_bb_34;
    z_bb_33:
    goto z_bb_6;
    z_bb_34:
    zT_151 = 1;
    zT_153 = ei2 + (unsigned int)((unsigned int)zT_151);
    ei2 = zT_153;
    goto z_bb_31;
    z_bb_35:
    zT_158 = k;
    zT_161 = zF_C395F6FD_nodeChildIsNode(zT_158, (unsigned char)(0));
    zT_157 = zT_161;
    goto z_bb_37;
    z_bb_36:
    zT_157 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_157) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_162 = stack;
    zT_163 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_162, zT_163);
    goto z_bb_39;
    z_bb_39:
    zT_165 = n.child_1;
    if ((int)(zT_165 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_169 = k;
    zT_172 = zF_C395F6FD_nodeChildIsNode(zT_169, (unsigned char)(1));
    zT_168 = zT_172;
    goto z_bb_42;
    z_bb_41:
    zT_168 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_168) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_173 = stack;
    zT_174 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_173, zT_174);
    goto z_bb_44;
    z_bb_44:
    zT_176 = n.child_2;
    if ((int)(zT_176 != (unsigned int)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_180 = k;
    zT_183 = zF_C395F6FD_nodeChildIsNode(zT_180, (unsigned char)(2));
    zT_179 = zT_183;
    goto z_bb_47;
    z_bb_46:
    zT_179 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_179) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_184 = stack;
    zT_185 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_184, zT_185);
    goto z_bb_49;
    z_bb_49:
    zT_187 = k;
    zT_188 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_187);
    if (zT_188) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_190 = store;
    zT_191 = ni;
    zT_192 = zF_152E19CB_astStoreNodeExtraCh(zT_190, zT_191);
    ec3_n = zT_192;
    zT_194 = 0;
    ei3 = zT_194;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_6;
    z_bb_52:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_197 = stack;
    zT_199 = store;
    zT_200 = ni;
    zT_203 = zF_B10B1BC1_astStoreNodeExtraCh(zT_199, zT_200, (unsigned int)((unsigned int)ei3));
    zT_198 = zT_203;
    zF_62F717A2_u32ArrayListAppend(zT_197, zT_198);
    goto z_bb_55;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_204 = 1;
    zT_206 = ei3 + (unsigned int)((unsigned int)zT_204);
    ei3 = zT_206;
    goto z_bb_52;
    z_bb_56:
    pc = zT_209.value;
    if ((int)(pc > (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return;
    z_bb_58:
    zT_214 = parent_start;
    zT_215 = caller_key;
    zT_216 = zF_A05A7BE1_u64ToU32MapGet(zT_214, zT_215);
    zT_217 = zT_216.has_value;
    if (zT_217) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    ps = zT_216.value;
    zT_220 = (unsigned int)ps;
    lo = zT_220;
    zT_222 = parent_type_list->len;
    hi = zT_222;
    goto z_bb_62;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    if ((int)((unsigned int)(lo + (unsigned int)(1)) < hi)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_227 = parent_type_list->items;
    zT_228 = zT_227[lo];
    tmp = zT_228;
    zT_229 = parent_type_list->items;
    zT_231 = hi - (unsigned int)(1);
    zT_232 = zT_229[zT_231];
    zT_233 = parent_type_list->items;
    zT_233[lo] = zT_232;
    zT_234 = parent_type_list->items;
    zT_236 = hi - (unsigned int)(1);
    zT_234[zT_236] = tmp;
    zT_238 = lo + (unsigned int)(1);
    lo = zT_238;
    zT_240 = hi - (unsigned int)(1);
    hi = zT_240;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    goto z_bb_62;
}

/* asyncStateTypeForCount */
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int count) {
    if ((int)(count <= (unsigned int)(255))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(8);
    z_bb_2:
    if ((int)(count <= (unsigned int)(65535))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(9);
    z_bb_4:
    return (unsigned int)(10);
}

/* scanSuspensionCount */
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, unsigned int async_suspend_name_id, unsigned int async_init_name_id) {
    unsigned int zT_9;
    zT_B687BB96_U32ArrayList* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_49;
    zT_B687BB96_U32ArrayList* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    unsigned int zT_58 = 0;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_66;
    zT_6B0A7D14_AstStore* zT_69;
    zT_3D7259E2_SymbolRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_BBEE1AC1_Opt_11 zT_74 = {0};
    unsigned char zT_75;
    unsigned int zT_80;
    unsigned int zT_84;
    zT_A4CE86B7_U64ToU32Map* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    int zT_88 = 0;
    unsigned int zT_90;
    zT_B687BB96_U32ArrayList* zT_91;
    unsigned int zT_92;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    unsigned int zT_97 = 0;
    unsigned int zT_99;
    zT_B687BB96_U32ArrayList* zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    unsigned int zT_108 = 0;
    int zT_109;
    unsigned int zT_111;
    unsigned int zT_112;
    int zT_115;
    zT_8143F551_AstKind zT_116;
    int zT_119 = 0;
    zT_B687BB96_U32ArrayList* zT_120;
    unsigned int zT_121;
    unsigned int zT_123;
    int zT_126;
    zT_8143F551_AstKind zT_127;
    int zT_130 = 0;
    zT_B687BB96_U32ArrayList* zT_131;
    unsigned int zT_132;
    unsigned int zT_134;
    int zT_137;
    zT_8143F551_AstKind zT_138;
    int zT_141 = 0;
    zT_B687BB96_U32ArrayList* zT_142;
    unsigned int zT_143;
    zT_8143F551_AstKind zT_145;
    int zT_146 = 0;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int zT_150 = 0;
    unsigned int zT_152;
    zT_B687BB96_U32ArrayList* zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_157;
    unsigned int zT_158;
    unsigned int zT_161 = 0;
    int zT_162;
    unsigned int zT_164;
    unsigned int count;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int ec3_n;
    unsigned int ei3;
    zT_9 = 0;
    count = zT_9;
    stack->len = (unsigned int)(0);
    if ((int)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return count;
    z_bb_2:
    zT_13 = stack;
    zT_14 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_13, zT_14);
    goto z_bb_3;
    z_bb_3:
    zT_15 = stack->len;
    if ((int)(zT_15 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = stack->items;
    zT_20 = stack->len;
    zT_22 = zT_20 - (unsigned int)(1);
    zT_23 = zT_19[zT_22];
    ni = zT_23;
    zT_24 = stack->len;
    stack->len = (unsigned int)(zT_24 - (unsigned int)(1));
    zT_28 = store;
    zT_29 = ni;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    n = zT_30;
    zT_32 = n.kind;
    k = zT_32;
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return count;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_37 = n.child_0;
    if ((int)(zT_37 == async_suspend_name_id)) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    if ((int)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    zT_40 = n.child_0;
    zT_39 = zT_40 == async_init_name_id;
    goto z_bb_11;
    z_bb_10:
    zT_39 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_39) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_43 = count + (unsigned int)(1);
    count = zT_43;
    goto z_bb_13;
    z_bb_13:
    zT_45 = store;
    zT_46 = ni;
    zT_47 = zF_152E19CB_astStoreNodeExtraCh(zT_45, zT_46);
    ecb_n = zT_47;
    zT_49 = 0;
    bi = zT_49;
    goto z_bb_14;
    z_bb_14:
    if ((int)(bi < (unsigned int)((unsigned int)ecb_n))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_52 = stack;
    zT_54 = store;
    zT_55 = ni;
    zT_58 = zF_B10B1BC1_astStoreNodeExtraCh(zT_54, zT_55, (unsigned int)((unsigned int)bi));
    zT_53 = zT_58;
    zF_62F717A2_u32ArrayListAppend(zT_52, zT_53);
    goto z_bb_17;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_59 = 1;
    zT_61 = bi + (unsigned int)((unsigned int)zT_59);
    bi = zT_61;
    goto z_bb_14;
    z_bb_18:
    zT_66 = n.child_0;
    if ((int)(zT_66 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_112 = n.child_0;
    if ((int)(zT_112 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_20:
    zT_69 = store;
    zT_70 = sym_reg;
    zT_71 = module_id;
    zT_72 = n.child_0;
    zT_74 = zF_860C82EC_resolveCalleeKey(zT_69, zT_70, zT_71, zT_72);
    zT_75 = zT_74.has_value;
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_95 = store;
    zT_96 = ni;
    zT_97 = zF_152E19CB_astStoreNodeExtraCh(zT_95, zT_96);
    ecf_n = zT_97;
    zT_99 = 0;
    fi = zT_99;
    goto z_bb_26;
    z_bb_22:
    ck = zT_74.value;
    zT_80 = (unsigned int)(zT_79FAE712_u64)(ck >> (zT_79FAE712_u64)(32));
    cmid = zT_80;
    zT_84 = (unsigned int)(zT_79FAE712_u64)(ck & (zT_79FAE712_u64)(4294967295u));
    cnid = zT_84;
    zT_85 = suspending_fns;
    zT_86 = cmid;
    zT_87 = cnid;
    zT_88 = zF_7C7E43BF_asyncIsSuspending(zT_85, zT_86, zT_87);
    if (zT_88) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_91 = stack;
    zT_92 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_91, zT_92);
    goto z_bb_21;
    z_bb_24:
    zT_90 = count + (unsigned int)(1);
    count = zT_90;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((int)(fi < (unsigned int)((unsigned int)ecf_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_102 = stack;
    zT_104 = store;
    zT_105 = ni;
    zT_108 = zF_B10B1BC1_astStoreNodeExtraCh(zT_104, zT_105, (unsigned int)((unsigned int)fi));
    zT_103 = zT_108;
    zF_62F717A2_u32ArrayListAppend(zT_102, zT_103);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_6;
    z_bb_29:
    zT_109 = 1;
    zT_111 = fi + (unsigned int)((unsigned int)zT_109);
    fi = zT_111;
    goto z_bb_26;
    z_bb_30:
    zT_116 = k;
    zT_119 = zF_C395F6FD_nodeChildIsNode(zT_116, (unsigned char)(0));
    zT_115 = zT_119;
    goto z_bb_32;
    z_bb_31:
    zT_115 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_115) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_120 = stack;
    zT_121 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_120, zT_121);
    goto z_bb_34;
    z_bb_34:
    zT_123 = n.child_1;
    if ((int)(zT_123 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_127 = k;
    zT_130 = zF_C395F6FD_nodeChildIsNode(zT_127, (unsigned char)(1));
    zT_126 = zT_130;
    goto z_bb_37;
    z_bb_36:
    zT_126 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_126) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_131 = stack;
    zT_132 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_131, zT_132);
    goto z_bb_39;
    z_bb_39:
    zT_134 = n.child_2;
    if ((int)(zT_134 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_138 = k;
    zT_141 = zF_C395F6FD_nodeChildIsNode(zT_138, (unsigned char)(2));
    zT_137 = zT_141;
    goto z_bb_42;
    z_bb_41:
    zT_137 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_137) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_142 = stack;
    zT_143 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_142, zT_143);
    goto z_bb_44;
    z_bb_44:
    zT_145 = k;
    zT_146 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_145);
    if (zT_146) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_148 = store;
    zT_149 = ni;
    zT_150 = zF_152E19CB_astStoreNodeExtraCh(zT_148, zT_149);
    ec3_n = zT_150;
    zT_152 = 0;
    ei3 = zT_152;
    goto z_bb_47;
    z_bb_46:
    goto z_bb_6;
    z_bb_47:
    if ((int)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_155 = stack;
    zT_157 = store;
    zT_158 = ni;
    zT_161 = zF_B10B1BC1_astStoreNodeExtraCh(zT_157, zT_158, (unsigned int)((unsigned int)ei3));
    zT_156 = zT_161;
    zF_62F717A2_u32ArrayListAppend(zT_155, zT_156);
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_162 = 1;
    zT_164 = ei3 + (unsigned int)((unsigned int)zT_162);
    ei3 = zT_164;
    goto z_bb_47;
}

/* asyncPtrVoid */
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_1;
    unsigned int zT_6 = 0;
    zT_1 = reg;
    zT_6 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1, (unsigned int)(1), (int)(0));
    return zT_6;
}

/* emitFrameMarker */
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64 key, unsigned int size) {
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_5826BFC7_Arr_unsigned_char_1 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_5826BFC7_Arr_unsigned_char_1 zT_45;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_5826BFC7_Arr_unsigned_char_1 zT_74;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84 = 0;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_5 = (unsigned int)(zT_79FAE712_u64)(key >> (zT_79FAE712_u64)(32));
    module_id = zT_5;
    zT_9 = (unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_9;
    zT_11 = "FRAME:m";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    m1 = zT_12;
    zT_14 = m1;
    zF_48AC7B3A_markerWrite(zT_14);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_16[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = module_id;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)b1) + zT_22;
    zT_24 = (unsigned int)(12) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    l1 = zT_26;
    zT_31 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_31;
    zT_36 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_37 = (unsigned int)(11) - s1;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_32 = zT_38;
    zF_48AC7B3A_markerWrite(zT_32);
    zT_40 = ":n";
    zT_42 = 2;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    m2 = zT_41;
    zT_43 = m2;
    zF_48AC7B3A_markerWrite(zT_43);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_45[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_45[_i];
        _i++;
    }
}
    zT_47 = name_id;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)b2) + zT_51;
    zT_53 = (unsigned int)(12) - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_48 = zT_54;
    zT_55 = zF_A7504564_itoa(zT_47, zT_48);
    l2 = zT_55;
    zT_60 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_60;
    zT_65 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_66 = (unsigned int)(11) - s2;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_61 = zT_67;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_69 = ":s";
    zT_71 = 2;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    m3 = zT_70;
    zT_72 = m3;
    zF_48AC7B3A_markerWrite(zT_72);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_74[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_74[_i];
        _i++;
    }
}
    zT_76 = size;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)b3) + zT_80;
    zT_82 = (unsigned int)(12) - zT_80;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zT_84 = zF_A7504564_itoa(zT_76, zT_77);
    l3 = zT_84;
    zT_89 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_89;
    zT_94 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_95 = (unsigned int)(11) - s3;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90 = zT_96;
    zF_48AC7B3A_markerWrite(zT_90);
    zT_98 = "\n";
    zT_100 = 1;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    m4 = zT_99;
    zT_101 = m4;
    zF_48AC7B3A_markerWrite(zT_101);
    return;
}

/* asyncFrameSizeRun */
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* typereg, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_B687BB96_U32ArrayList zT_23 = {0};
    zT_072B53A6_ModuleRegistry* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26 = {0};
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    zT_3E40CD83_Sand* zT_44;
    zT_A4CE86B7_U64ToU32Map zT_45 = {0};
    unsigned int zT_47;
    unsigned int zT_49;
    zT_6E8D187B_ModuleEntry* zT_52;
    zT_6E8D187B_ModuleEntry zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_79 = 0;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    zT_22A7C88B_AstNode zT_83 = {0};
    zT_8143F551_AstKind zT_84;
    zT_D7E9BA07_anon_229626 zT_90;
    zT_243D6A41_FnProto* zT_91;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_94 = 0;
    unsigned int zT_95;
    zT_243D6A41_FnProto zT_96;
    unsigned int zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_99;
    unsigned int zT_100;
    zT_BAEE192E_Opt_10 zT_102 = {0};
    unsigned char zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_6E8D187B_ModuleEntry* zT_111;
    zT_6E8D187B_ModuleEntry zT_112;
    zT_79FAE712_u64 zT_115 = 0;
    int zT_116;
    unsigned int zT_118;
    int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    unsigned int zT_125;
    zT_6E8D187B_ModuleEntry* zT_128;
    zT_6E8D187B_ModuleEntry zT_129;
    unsigned int zT_130;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    zT_22A7C88B_AstNode zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_145 = 0;
    unsigned int zT_147;
    zT_6B0A7D14_AstStore* zT_151;
    unsigned int zT_152;
    unsigned int zT_155 = 0;
    zT_6B0A7D14_AstStore* zT_157;
    unsigned int zT_158;
    zT_22A7C88B_AstNode zT_159 = {0};
    zT_8143F551_AstKind zT_160;
    zT_D7E9BA07_anon_229626 zT_166;
    zT_243D6A41_FnProto* zT_167;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    unsigned int zT_170 = 0;
    unsigned int zT_171;
    zT_243D6A41_FnProto zT_172;
    zT_A4CE86B7_U64ToU32Map* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_6E8D187B_ModuleEntry* zT_176;
    zT_6E8D187B_ModuleEntry zT_177;
    int zT_180 = 0;
    zT_6B0A7D14_AstStore* zT_182;
    zT_3D7259E2_SymbolRegistry* zT_183;
    unsigned int zT_184;
    zT_79FAE712_u64 zT_185;
    unsigned int zT_186;
    zT_B687BB96_U32ArrayList* zT_187;
    zT_A4CE86B7_U64ToU32Map* zT_188;
    zT_A4CE86B7_U64ToU32Map* zT_189;
    zT_A4CE86B7_U64ToU32Map* zT_190;
    zT_A4CE86B7_U64ToU32Map* zT_191;
    zT_B687BB96_U32ArrayList* zT_192;
    zT_A4CE86B7_U64ToU32Map* zT_193;
    zT_A4CE86B7_U64ToU32Map* zT_194;
    zT_6E8D187B_ModuleEntry* zT_195;
    zT_6E8D187B_ModuleEntry zT_196;
    unsigned int zT_198;
    unsigned int zT_199;
    zT_6E8D187B_ModuleEntry* zT_200;
    zT_6E8D187B_ModuleEntry zT_201;
    zT_79FAE712_u64 zT_204 = 0;
    int zT_208;
    unsigned int zT_210;
    int zT_211;
    unsigned int zT_213;
    unsigned int zT_215;
    unsigned int zT_217;
    zT_6E8D187B_ModuleEntry* zT_220;
    zT_6E8D187B_ModuleEntry zT_221;
    unsigned int zT_222;
    zT_6B0A7D14_AstStore* zT_226;
    unsigned int zT_227;
    zT_22A7C88B_AstNode zT_228 = {0};
    zT_8143F551_AstKind zT_229;
    zT_6B0A7D14_AstStore* zT_235;
    unsigned int zT_236;
    unsigned int zT_237 = 0;
    unsigned int zT_239;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_244;
    unsigned int zT_247 = 0;
    zT_6B0A7D14_AstStore* zT_249;
    unsigned int zT_250;
    zT_22A7C88B_AstNode zT_251 = {0};
    zT_8143F551_AstKind zT_252;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_260 = 0;
    zT_D7E9BA07_anon_229626 zT_262;
    zT_243D6A41_FnProto* zT_263;
    unsigned int zT_264;
    zT_243D6A41_FnProto zT_265;
    zT_A4CE86B7_U64ToU32Map* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_6E8D187B_ModuleEntry* zT_269;
    zT_6E8D187B_ModuleEntry zT_270;
    int zT_273 = 0;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_6E8D187B_ModuleEntry* zT_278;
    zT_6E8D187B_ModuleEntry zT_279;
    zT_79FAE712_u64 zT_282 = 0;
    int zT_284;
    unsigned char zT_285;
    int zT_291;
    zT_6E8D187B_ModuleEntry* zT_292;
    zT_6E8D187B_ModuleEntry zT_293;
    unsigned int zT_294;
    int zT_297;
    unsigned char zT_298;
    zT_D3EB6303_StringInterner* zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308 = {0};
    unsigned int zT_310;
    int zT_313;
    unsigned char* zT_314;
    int zT_315;
    unsigned char zT_316;
    int zT_319;
    unsigned char* zT_320;
    int zT_321;
    unsigned char zT_322;
    int zT_325;
    unsigned char* zT_326;
    int zT_327;
    unsigned char zT_328;
    int zT_331;
    unsigned char* zT_332;
    int zT_333;
    unsigned char zT_334;
    int zT_337;
    zT_A4CE86B7_U64ToU32Map* zT_338;
    zT_79FAE712_u64 zT_339;
    zT_6B0A7D14_AstStore* zT_343;
    zT_3D7259E2_SymbolRegistry* zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_B687BB96_U32ArrayList* zT_347;
    zT_A4CE86B7_U64ToU32Map* zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_6E8D187B_ModuleEntry* zT_351;
    zT_6E8D187B_ModuleEntry zT_352;
    unsigned int zT_356 = 0;
    unsigned int zT_358;
    unsigned int zT_359 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_360;
    zT_79FAE712_u64 zT_361;
    unsigned int zT_362;
    unsigned int zT_364;
    unsigned int zT_366;
    zT_338B7C76_TypeRegistry* zT_367;
    unsigned int* zT_369;
    unsigned int* zT_370;
    unsigned int zT_374 = 0;
    zT_338B7C76_TypeRegistry* zT_375;
    unsigned int* zT_377;
    unsigned int* zT_378;
    unsigned int zT_382 = 0;
    zT_338B7C76_TypeRegistry* zT_383;
    unsigned int zT_384;
    unsigned int* zT_385;
    unsigned int* zT_386;
    unsigned int zT_389 = 0;
    unsigned short zT_390;
    unsigned int zT_394;
    unsigned short zT_398;
    zT_79FAE712_u64 zT_400;
    zT_6B0A7D14_AstStore* zT_402;
    zT_79FAE712_u64 zT_403;
    unsigned int zT_404 = 0;
    unsigned int zT_406;
    zT_6B0A7D14_AstStore* zT_410;
    unsigned int zT_411;
    zT_6B0A7D14_AstStore* zT_412;
    zT_79FAE712_u64 zT_413;
    unsigned int zT_416 = 0;
    zT_22A7C88B_AstNode zT_417 = {0};
    unsigned int zT_418;
    unsigned int zT_422;
    zT_8EED1867_ResolvedTypeTable* zT_423;
    unsigned int zT_424;
    zT_BAEE192E_Opt_10 zT_426 = {0};
    unsigned char zT_427;
    zT_338B7C76_TypeRegistry* zT_429;
    unsigned int zT_430;
    unsigned int* zT_431;
    unsigned int* zT_432;
    unsigned int zT_435 = 0;
    unsigned int zT_437;
    zT_6B0A7D14_AstStore* zT_438;
    unsigned int zT_439;
    zT_B687BB96_U32ArrayList* zT_440;
    zT_338B7C76_TypeRegistry* zT_441;
    zT_8EED1867_ResolvedTypeTable* zT_442;
    unsigned int* zT_443;
    unsigned int* zT_444;
    unsigned int zT_450;
    zT_A4CE86B7_U64ToU32Map* zT_451;
    zT_79FAE712_u64 zT_452;
    zT_BAEE192E_Opt_10 zT_453 = {0};
    unsigned char zT_454;
    zT_338B7C76_TypeRegistry* zT_460;
    unsigned int zT_461;
    unsigned int* zT_462;
    unsigned int* zT_463;
    zT_338B7C76_TypeRegistry* zT_464;
    unsigned int zT_465 = 0;
    unsigned int zT_468 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_469;
    zT_79FAE712_u64 zT_470;
    zT_BAEE192E_Opt_10 zT_471 = {0};
    unsigned char zT_472;
    int zT_473;
    zT_A4CE86B7_U64ToU32Map* zT_474;
    zT_79FAE712_u64 zT_475;
    zT_BAEE192E_Opt_10 zT_476 = {0};
    unsigned char zT_477;
    zT_338B7C76_TypeRegistry* zT_478;
    unsigned int zT_479;
    unsigned int* zT_480;
    unsigned int* zT_481;
    zT_338B7C76_TypeRegistry* zT_482;
    unsigned int zT_483 = 0;
    unsigned int zT_486 = 0;
    unsigned int zT_492;
    zT_A4CE86B7_U64ToU32Map* zT_493;
    zT_79FAE712_u64 zT_494;
    zT_BAEE192E_Opt_10 zT_495 = {0};
    unsigned char zT_496;
    unsigned int zT_499;
    zT_A4CE86B7_U64ToU32Map* zT_500;
    zT_79FAE712_u64 zT_501;
    zT_BAEE192E_Opt_10 zT_502 = {0};
    unsigned char zT_503;
    unsigned int zT_506;
    unsigned int* zT_509;
    unsigned int zT_511;
    unsigned int zT_512;
    zT_338B7C76_TypeRegistry* zT_513;
    unsigned int zT_514;
    unsigned int* zT_515;
    unsigned int* zT_516;
    unsigned int zT_519 = 0;
    unsigned int zT_521;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_525 = 0;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_532 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_533;
    zT_79FAE712_u64 zT_534;
    unsigned int zT_535;
    zT_79FAE712_u64 zT_536;
    unsigned int zT_537;
    int zT_538;
    unsigned int zT_540;
    int zT_541;
    unsigned int zT_543;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_B687BB96_U32ArrayList stack;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_text;
    unsigned int async_init_name_id;
    zT_A4CE86B7_U64ToU32Map fn_ret_types;
    unsigned int mi0;
    unsigned int ar0;
    unsigned int mi0b;
    zT_22A7C88B_AstNode r0;
    unsigned int d0_n;
    unsigned int di0;
    unsigned int d0_idx;
    zT_22A7C88B_AstNode dc0;
    zT_243D6A41_FnProto pr0;
    unsigned int rt0;
    unsigned int rr0;
    unsigned int ar0b;
    unsigned int mi;
    zT_22A7C88B_AstNode r0b;
    unsigned int d0b_n;
    unsigned int di0b;
    unsigned int d0b_idx;
    zT_22A7C88B_AstNode dc0b;
    zT_243D6A41_FnProto pr0b;
    unsigned int ast_root;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    int is_driver_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u dm;
    unsigned int susp_count;
    unsigned int state_type;
    unsigned int offset;
    unsigned int max_align;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int hid;
    zT_22A7C88B_AstNode pnode;
    unsigned int pt;
    unsigned int rtp;
    unsigned int h;
    unsigned int pstart;
    unsigned int total;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_17 = "AFS\n";
    zT_19 = 4;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    p_msg = zT_18;
    zT_20 = p_msg;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_22 = alloc;
    zT_23 = zF_8E537D0C_u32ArrayListInit(zT_22);
    stack = zT_23;
    zT_25 = module_reg;
    zT_26 = zF_3452C137_moduleRegistryGetMo(zT_25);
    mods = zT_26;
    zT_28 = "@asyncSuspend";
    zT_30 = 13;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    asu_text = zT_29;
    zT_32 = interner;
    zT_33 = asu_text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    async_suspend_name_id = zT_34;
    zT_36 = "@asyncInit";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    ain_text = zT_37;
    zT_40 = interner;
    zT_41 = ain_text;
    zT_42 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    async_init_name_id = zT_42;
    zT_44 = alloc;
    zT_45 = zF_986226E1_u64ToU32MapInit(zT_44);
    fn_ret_types = zT_45;
    zT_47 = 0;
    mi0 = zT_47;
    goto z_bb_1;
    z_bb_1:
    zT_49 = mods.len;
    if ((int)(mi0 < zT_49)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_52 = mods.ptr;
    zT_53 = zT_52[mi0];
    zT_54 = zT_53.ast_root;
    ar0 = zT_54;
    if ((int)(ar0 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_123 = 0;
    mi0b = zT_123;
    goto z_bb_17;
    z_bb_4:
    zT_119 = 1;
    zT_121 = mi0 + (unsigned int)((unsigned int)zT_119);
    mi0 = zT_121;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_58 = store;
    zT_59 = ar0;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    r0 = zT_60;
    zT_61 = r0.kind;
    if ((int)(zT_61 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_67 = store;
    zT_68 = ar0;
    zT_69 = zF_152E19CB_astStoreNodeExtraCh(zT_67, zT_68);
    d0_n = zT_69;
    zT_71 = 0;
    di0 = zT_71;
    goto z_bb_9;
    z_bb_9:
    if ((int)(di0 < (unsigned int)((unsigned int)d0_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_75 = store;
    zT_76 = ar0;
    zT_79 = zF_B10B1BC1_astStoreNodeExtraCh(zT_75, zT_76, (unsigned int)((unsigned int)di0));
    d0_idx = zT_79;
    zT_81 = store;
    zT_82 = d0_idx;
    zT_83 = zF_FCDD1D35_astStoreNodeAt(zT_81, zT_82);
    dc0 = zT_83;
    zT_84 = dc0.kind;
    if ((int)(zT_84 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_116 = 1;
    zT_118 = di0 + (unsigned int)((unsigned int)zT_116);
    di0 = zT_118;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_90 = store->fn_protos;
    zT_91 = zT_90.items;
    zT_92 = store;
    zT_93 = d0_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_92, zT_93);
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_91[zT_95];
    pr0 = zT_96;
    zT_98 = 1;
    rt0 = zT_98;
    zT_99 = resolved_types;
    zT_100 = pr0.return_type_node;
    zT_102 = zF_999DCF51_resolvedTypeTableGe(zT_99, zT_100);
    zT_103 = zT_102.has_value;
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    rr0 = zT_102.value;
    rt0 = rr0;
    goto z_bb_16;
    z_bb_16:
    zT_105 = &fn_ret_types;
    zT_111 = mods.ptr;
    zT_112 = zT_111[mi0];
    zT_109 = zT_112.id;
    zT_110 = pr0.name_id;
    zT_115 = zF_9D041EB6_asyncKey(zT_109, zT_110);
    zT_106 = zT_115;
    zT_107 = rt0;
    zF_B6EB812C_u64ToU32MapPut(zT_105, zT_106, zT_107);
    (void)alloc;
    goto z_bb_12;
    z_bb_17:
    zT_125 = mods.len;
    if ((int)(mi0b < zT_125)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_128 = mods.ptr;
    zT_129 = zT_128[mi0b];
    zT_130 = zT_129.ast_root;
    ar0b = zT_130;
    if ((int)(ar0b == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_215 = 0;
    mi = zT_215;
    goto z_bb_33;
    z_bb_20:
    zT_211 = 1;
    zT_213 = mi0b + (unsigned int)((unsigned int)zT_211);
    mi0b = zT_213;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_134 = store;
    zT_135 = ar0b;
    zT_136 = zF_FCDD1D35_astStoreNodeAt(zT_134, zT_135);
    r0b = zT_136;
    zT_137 = r0b.kind;
    if ((int)(zT_137 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_143 = store;
    zT_144 = ar0b;
    zT_145 = zF_152E19CB_astStoreNodeExtraCh(zT_143, zT_144);
    d0b_n = zT_145;
    zT_147 = 0;
    di0b = zT_147;
    goto z_bb_25;
    z_bb_25:
    if ((int)(di0b < (unsigned int)((unsigned int)d0b_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_151 = store;
    zT_152 = ar0b;
    zT_155 = zF_B10B1BC1_astStoreNodeExtraCh(zT_151, zT_152, (unsigned int)((unsigned int)di0b));
    d0b_idx = zT_155;
    zT_157 = store;
    zT_158 = d0b_idx;
    zT_159 = zF_FCDD1D35_astStoreNodeAt(zT_157, zT_158);
    dc0b = zT_159;
    zT_160 = dc0b.kind;
    if ((int)(zT_160 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_208 = 1;
    zT_210 = di0b + (unsigned int)((unsigned int)zT_208);
    di0b = zT_210;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_166 = store->fn_protos;
    zT_167 = zT_166.items;
    zT_168 = store;
    zT_169 = d0b_idx;
    zT_170 = zF_8BA26B9E_astStoreNodePayload(zT_168, zT_169);
    zT_171 = (unsigned int)zT_170;
    zT_172 = zT_167[zT_171];
    pr0b = zT_172;
    zT_173 = suspending_fns;
    zT_176 = mods.ptr;
    zT_177 = zT_176[mi0b];
    zT_174 = zT_177.id;
    zT_175 = pr0b.name_id;
    zT_180 = zF_7C7E43BF_asyncIsSuspending(zT_173, zT_174, zT_175);
    if ((int)(!zT_180)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_182 = store;
    zT_183 = sym_reg;
    zT_195 = mods.ptr;
    zT_196 = zT_195[mi0b];
    zT_184 = zT_196.id;
    zT_200 = mods.ptr;
    zT_201 = zT_200[mi0b];
    zT_198 = zT_201.id;
    zT_199 = pr0b.name_id;
    zT_204 = zF_9D041EB6_asyncKey(zT_198, zT_199);
    zT_185 = zT_204;
    zT_186 = dc0b.child_0;
    zT_187 = &stack;
    zT_188 = suspending_fns;
    zT_189 = &fn_ret_types;
    zT_190 = awaited_fns;
    zT_191 = async_hidden_fns;
    zT_192 = parent_result_type_list;
    zT_193 = parent_result_start;
    zT_194 = parent_result_count;
    zF_D62E4E4C_scanImplicitAwaits(zT_182, zT_183, zT_184, zT_185, zT_186, zT_187, zT_188, zT_189, zT_190, zT_191, zT_192, zT_193, zT_194);
    goto z_bb_28;
    z_bb_33:
    zT_217 = mods.len;
    if ((int)(mi < zT_217)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_220 = mods.ptr;
    zT_221 = zT_220[mi];
    zT_222 = zT_221.ast_root;
    ast_root = zT_222;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return;
    z_bb_36:
    zT_541 = 1;
    zT_543 = mi + (unsigned int)((unsigned int)zT_541);
    mi = zT_543;
    goto z_bb_33;
    z_bb_37:
    goto z_bb_36;
    z_bb_38:
    zT_226 = store;
    zT_227 = ast_root;
    zT_228 = zF_FCDD1D35_astStoreNodeAt(zT_226, zT_227);
    root = zT_228;
    zT_229 = root.kind;
    if ((int)(zT_229 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_235 = store;
    zT_236 = ast_root;
    zT_237 = zF_152E19CB_astStoreNodeExtraCh(zT_235, zT_236);
    decls_n = zT_237;
    zT_239 = 0;
    di = zT_239;
    goto z_bb_41;
    z_bb_41:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_243 = store;
    zT_244 = ast_root;
    zT_247 = zF_B10B1BC1_astStoreNodeExtraCh(zT_243, zT_244, (unsigned int)((unsigned int)di));
    decl_idx = zT_247;
    zT_249 = store;
    zT_250 = decl_idx;
    zT_251 = zF_FCDD1D35_astStoreNodeAt(zT_249, zT_250);
    decl = zT_251;
    zT_252 = decl.kind;
    if ((int)(zT_252 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_538 = 1;
    zT_540 = di + (unsigned int)((unsigned int)zT_538);
    di = zT_540;
    goto z_bb_41;
    z_bb_45:
    goto z_bb_44;
    z_bb_46:
    zT_258 = store;
    zT_259 = decl_idx;
    zT_260 = zF_8BA26B9E_astStoreNodePayload(zT_258, zT_259);
    proto_idx = zT_260;
    zT_262 = store->fn_protos;
    zT_263 = zT_262.items;
    zT_264 = (unsigned int)proto_idx;
    zT_265 = zT_263[zT_264];
    proto = zT_265;
    zT_266 = suspending_fns;
    zT_269 = mods.ptr;
    zT_270 = zT_269[mi];
    zT_267 = zT_270.id;
    zT_268 = proto.name_id;
    zT_273 = zF_7C7E43BF_asyncIsSuspending(zT_266, zT_267, zT_268);
    if ((int)(!zT_273)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_278 = mods.ptr;
    zT_279 = zT_278[mi];
    zT_276 = zT_279.id;
    zT_277 = proto.name_id;
    zT_282 = zF_9D041EB6_asyncKey(zT_276, zT_277);
    key = zT_282;
    zT_284 = 0;
    is_driver_target = zT_284;
    zT_285 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_285) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_291 = 1;
    is_driver_target = zT_291;
    goto z_bb_50;
    z_bb_50:
    zT_292 = mods.ptr;
    zT_293 = zT_292[mi];
    zT_294 = zT_293.id;
    if ((int)(zT_294 == (unsigned int)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_298 = decl.flags;
    zT_297 = (unsigned short)((unsigned short)((unsigned short)zT_298) & (unsigned short)(2)) != (unsigned short)(0);
    goto z_bb_53;
    z_bb_52:
    zT_297 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_297) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_305 = interner;
    zT_306 = proto.name_id;
    zT_308 = zF_9134020D_stringInternerGet(zT_305, zT_306);
    dm = zT_308;
    zT_310 = dm.len;
    if ((int)(zT_310 == (unsigned int)(4))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if (is_driver_target) goto z_bb_70; else goto z_bb_71;
    z_bb_56:
    zT_314 = dm.ptr;
    zT_315 = 0;
    zT_316 = zT_314[zT_315];
    zT_313 = zT_316 == (unsigned char)(109);
    goto z_bb_58;
    z_bb_57:
    zT_313 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_313) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_320 = dm.ptr;
    zT_321 = 1;
    zT_322 = zT_320[zT_321];
    zT_319 = zT_322 == (unsigned char)(97);
    goto z_bb_61;
    z_bb_60:
    zT_319 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_319) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_326 = dm.ptr;
    zT_327 = 2;
    zT_328 = zT_326[zT_327];
    zT_325 = zT_328 == (unsigned char)(105);
    goto z_bb_64;
    z_bb_63:
    zT_325 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_325) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_332 = dm.ptr;
    zT_333 = 3;
    zT_334 = zT_332[zT_333];
    zT_331 = zT_334 == (unsigned char)(110);
    goto z_bb_67;
    z_bb_66:
    zT_331 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_331) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_337 = 1;
    is_driver_target = zT_337;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_55;
    z_bb_70:
    zT_338 = driver_targets;
    zT_339 = key;
    zF_B6EB812C_u64ToU32MapPut(zT_338, zT_339, (unsigned int)(1));
    (void)alloc;
    goto z_bb_71;
    z_bb_71:
    zT_343 = store;
    zT_344 = sym_reg;
    zT_351 = mods.ptr;
    zT_352 = zT_351[mi];
    zT_345 = zT_352.id;
    zT_346 = decl.child_0;
    zT_347 = &stack;
    zT_348 = suspending_fns;
    zT_349 = async_suspend_name_id;
    zT_350 = async_init_name_id;
    zT_356 = zF_0782A438_scanSuspensionCount(zT_343, zT_344, zT_345, zT_346, zT_347, zT_348, zT_349, zT_350);
    susp_count = zT_356;
    zT_358 = susp_count;
    zT_359 = zF_74FC996E_asyncStateTypeForCo(zT_358);
    state_type = zT_359;
    zT_360 = state_widths;
    zT_361 = key;
    zT_362 = state_type;
    zF_B6EB812C_u64ToU32MapPut(zT_360, zT_361, zT_362);
    (void)alloc;
    zT_364 = 0;
    offset = zT_364;
    zT_366 = 1;
    max_align = zT_366;
    zT_367 = typereg;
    zT_369 = &offset;
    zT_370 = &max_align;
    zT_374 = zF_769CB99B_addFrameField(zT_367, (unsigned int)(13), zT_369, zT_370);
    (void)zT_374;
    zT_375 = typereg;
    zT_377 = &offset;
    zT_378 = &max_align;
    zT_382 = zF_769CB99B_addFrameField(zT_375, (unsigned int)(13), zT_377, zT_378);
    (void)zT_382;
    zT_383 = typereg;
    zT_384 = state_type;
    zT_385 = &offset;
    zT_386 = &max_align;
    zT_389 = zF_769CB99B_addFrameField(zT_383, zT_384, zT_385, zT_386);
    (void)zT_389;
    zT_390 = proto.params_count;
    if ((int)(zT_390 > (unsigned short)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_394 = proto.params_start;
    zT_398 = proto.params_count;
    zT_400 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_394) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_398);
    p_payload = zT_400;
    zT_402 = store;
    zT_403 = p_payload;
    zT_404 = zF_03CE8CAB_astStoreGetExtraChi(zT_402, zT_403);
    pnodes_n = zT_404;
    zT_406 = 0;
    pi = zT_406;
    goto z_bb_74;
    z_bb_73:
    zT_438 = store;
    zT_439 = decl.child_0;
    zT_440 = &stack;
    zT_441 = typereg;
    zT_442 = resolved_types;
    zT_443 = &offset;
    zT_444 = &max_align;
    zF_68BD38B1_scanFrameLocals(zT_438, zT_439, zT_440, zT_441, zT_442, zT_443, zT_444);
    zT_450 = 0;
    hid = zT_450;
    zT_451 = async_hidden_fns;
    zT_452 = key;
    zT_453 = zF_A05A7BE1_u64ToU32MapGet(zT_451, zT_452);
    zT_454 = zT_453.has_value;
    if (zT_454) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    if ((int)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_410 = store;
    zT_412 = store;
    zT_413 = p_payload;
    zT_416 = zF_E5B10421_astStoreGetExtraChi(zT_412, zT_413, (unsigned int)((unsigned int)pi));
    zT_411 = zT_416;
    zT_417 = zF_FCDD1D35_astStoreNodeAt(zT_410, zT_411);
    pnode = zT_417;
    zT_418 = pnode.child_0;
    if ((int)(zT_418 == (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_437 = pi + (unsigned int)(1);
    pi = zT_437;
    goto z_bb_74;
    z_bb_78:
    goto z_bb_77;
    z_bb_79:
    zT_422 = 18;
    pt = zT_422;
    zT_423 = resolved_types;
    zT_424 = pnode.child_0;
    zT_426 = zF_999DCF51_resolvedTypeTableGe(zT_423, zT_424);
    zT_427 = zT_426.has_value;
    if (zT_427) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    rtp = zT_426.value;
    pt = rtp;
    goto z_bb_81;
    z_bb_81:
    zT_429 = typereg;
    zT_430 = pt;
    zT_431 = &offset;
    zT_432 = &max_align;
    zT_435 = zF_769CB99B_addFrameField(zT_429, zT_430, zT_431, zT_432);
    (void)zT_435;
    goto z_bb_77;
    z_bb_82:
    h = zT_453.value;
    hid = h;
    goto z_bb_83;
    z_bb_83:
    if ((int)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_460 = typereg;
    zT_464 = typereg;
    zT_465 = zF_FF3C4865_asyncPtrVoid(zT_464);
    zT_461 = zT_465;
    zT_462 = &offset;
    zT_463 = &max_align;
    zT_468 = zF_769CB99B_addFrameField(zT_460, zT_461, zT_462, zT_463);
    (void)zT_468;
    goto z_bb_85;
    z_bb_85:
    zT_469 = awaited_fns;
    zT_470 = key;
    zT_471 = zF_A05A7BE1_u64ToU32MapGet(zT_469, zT_470);
    zT_472 = zT_471.has_value;
    if (zT_472) goto z_bb_87; else goto z_bb_86;
    z_bb_86:
    zT_474 = driver_targets;
    zT_475 = key;
    zT_476 = zF_A05A7BE1_u64ToU32MapGet(zT_474, zT_475);
    zT_477 = zT_476.has_value;
    zT_473 = zT_477;
    goto z_bb_88;
    z_bb_87:
    zT_473 = 1;
    goto z_bb_88;
    z_bb_88:
    if (zT_473) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_478 = typereg;
    zT_482 = typereg;
    zT_483 = zF_FF3C4865_asyncPtrVoid(zT_482);
    zT_479 = zT_483;
    zT_480 = &offset;
    zT_481 = &max_align;
    zT_486 = zF_769CB99B_addFrameField(zT_478, zT_479, zT_480, zT_481);
    (void)zT_486;
    goto z_bb_90;
    z_bb_90:
    if ((int)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_492 = 0;
    pstart = zT_492;
    zT_493 = parent_result_start;
    zT_494 = key;
    zT_495 = zF_A05A7BE1_u64ToU32MapGet(zT_493, zT_494);
    zT_496 = zT_495.has_value;
    if (zT_496) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_523 = offset;
    zT_524 = max_align;
    zT_525 = zF_978D7C93_alignUpU32(zT_523, zT_524);
    total = zT_525;
    if ((int)(total == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_93:
    ps = zT_495.value;
    pstart = ps;
    goto z_bb_94;
    z_bb_94:
    zT_499 = 0;
    pcount = zT_499;
    zT_500 = parent_result_count;
    zT_501 = key;
    zT_502 = zF_A05A7BE1_u64ToU32MapGet(zT_500, zT_501);
    zT_503 = zT_502.has_value;
    if (zT_503) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    pc = zT_502.value;
    pcount = pc;
    goto z_bb_96;
    z_bb_96:
    zT_506 = 0;
    pk = zT_506;
    goto z_bb_97;
    z_bb_97:
    if ((int)(pk < pcount)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_509 = parent_result_type_list->items;
    zT_511 = (unsigned int)(unsigned int)(pstart + pk);
    zT_512 = zT_509[zT_511];
    prt = zT_512;
    zT_513 = typereg;
    zT_514 = prt;
    zT_515 = &offset;
    zT_516 = &max_align;
    zT_519 = zF_769CB99B_addFrameField(zT_513, zT_514, zT_515, zT_516);
    (void)zT_519;
    goto z_bb_100;
    z_bb_99:
    goto z_bb_92;
    z_bb_100:
    zT_521 = pk + (unsigned int)(1);
    pk = zT_521;
    goto z_bb_97;
    z_bb_101:
    zT_528 = 1;
    total = zT_528;
    goto z_bb_102;
    z_bb_102:
    zT_529 = total;
    zT_532 = zF_978D7C93_alignUpU32(zT_529, (unsigned int)(8));
    total = zT_532;
    zT_533 = frame_sizes;
    zT_534 = key;
    zT_535 = total;
    zF_B6EB812C_u64ToU32MapPut(zT_533, zT_534, zT_535);
    zT_536 = key;
    zT_537 = total;
    zF_7011AA79_emitFrameMarker(zT_536, zT_537);
    goto z_bb_44;
}

/* __module_init */
void zF_780653D2___module_init_22(void) {
    zT_8143F551_AstKind zT_0 = 0;
    zG_8143F551_AstKind = zT_0;
    return;
}

/* EOF */
