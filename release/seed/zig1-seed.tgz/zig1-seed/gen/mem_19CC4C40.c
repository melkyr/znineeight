#include "mem_19CC4C40.h"
/* mem_eql */
int zF_B7662C9F_mem_eql(zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_6;
    int zT_7;
    unsigned char* zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned char* zT_13;
    unsigned char zT_14;
    int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned char c;
    unsigned int i;
    zT_3 = a.len;
    zT_5 = b.len;
    zT_6 = zT_3 != zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = 0;
    return zT_7;
    z_bb_2:
    zT_8 = a.ptr;
    zT_9 = a.len;
    i = 0;
    goto z_bb_3;
    z_bb_3:
    zT_11 = i < zT_9;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    c = zT_8[i];
    zT_13 = b.ptr;
    zT_14 = zT_13[i];
    zT_15 = c != zT_14;
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_19 = 1;
    return zT_19;
    z_bb_6:
    zT_16 = 0;
    return zT_16;
    z_bb_7:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    goto z_bb_3;
}

/* binary_search */
unsigned int zF_1457D8A5_binary_search(zT_3CB0179A_Slice_zT_05F374B1_u offsets, unsigned int target) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    int zT_19;
    unsigned int zT_20;
    int zT_21;
    int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int lo;
    unsigned int hi;
    unsigned int mid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    lo = zT_4;
    lo = zT_4;
    lo = zT_4;
    zT_7 = offsets.len;
    zT_8 = (unsigned int)zT_7;
    hi = zT_8;
    hi = zT_8;
    hi = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_9 = lo < hi;
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = hi - lo;
    zT_12 = 2;
    zT_13 = zT_11 / zT_12;
    zT_14 = lo + zT_13;
    mid = zT_14;
    mid = zT_14;
    mid = zT_14;
    zT_15 = offsets.ptr;
    zT_16 = (unsigned int)mid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17 <= target;
    if (zT_18) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_21 = 0;
    zT_22 = lo == (unsigned int)zT_21;
    if (zT_22) goto z_bb_8; else goto z_bb_10;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_19 = 1;
    zT_20 = mid + zT_19;
    lo = zT_20;
    lo = zT_20;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    hi = mid;
    hi = mid;
    goto z_bb_6;
    z_bb_8:
    zT_23 = 0;
    return zT_23;
    return 0;
    z_bb_10:
    zT_24 = 1;
    zT_25 = lo - zT_24;
    zT_26 = (unsigned int)zT_25;
    return zT_26;
}

/* EOF */
