#include "const_init_eval_283ED887.h"
unsigned char const zG_7572E8D7_CIE_ZERO = (unsigned char)(0);
unsigned char const zG_002ED8FA_CIE_INT = (unsigned char)(1);
unsigned char const zG_DE01BAF1_CIE_FLOAT = (unsigned char)(2);
unsigned char const zG_E69D9919_CIE_BOOL = (unsigned char)(3);
unsigned char const zG_DD770F31_CIE_CHAR = (unsigned char)(4);
unsigned char const zG_DC260CE4_CIE_STRING = (unsigned char)(5);
unsigned char const zG_8BCA4402_CIE_GLOBAL = (unsigned char)(6);
unsigned char const zG_AA7CCD69_CIE_FN = (unsigned char)(7);
unsigned char const zG_56522CBE_CIE_AGG = (unsigned char)(8);
unsigned int const zG_F7845E8F_CIE_NONE = (unsigned int)(4294967295u);
static unsigned int const zG_1C8CEEE7_kEvalDepthCap = (unsigned int)(256);
/* constInitTableInit */
zT_4065182A_ConstInitTable zF_046B7660_constInitTableInit(zT_3E40CD83_Sand* alloc) {
    zT_4065182A_ConstInitTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_8;
    zT_21D3708C_U32ToU32Map zT_9 = {0};
    zT_3E40CD83_Sand* zT_10;
    zT_21D3708C_U32ToU32Map zT_11 = {0};
    zT_2 = 0;
    zT_1.nodes = (zT_49DE1C22_ConstInitNode*)zT_2;
    zT_3 = 0;
    zT_1.nodes_len = zT_3;
    zT_4 = 0;
    zT_1.nodes_cap = zT_4;
    zT_5 = 0;
    zT_1.kids = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.kids_len = zT_6;
    zT_7 = 0;
    zT_1.kids_cap = zT_7;
    zT_8 = alloc;
    zT_9 = zF_58BDA2DE_u32ToU32MapInit(zT_8);
    zT_1.roots = zT_9;
    zT_10 = alloc;
    zT_11 = zF_58BDA2DE_u32ToU32MapInit(zT_10);
    zT_1.in_progress = zT_11;
    zT_1.alloc = alloc;
    return zT_1;
}

/* tableEnsureNodes */
void zF_7EB8906A_tableEnsureNodes(zT_4065182A_ConstInitTable* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_FDFD82FD_EU_362 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    zT_49DE1C22_ConstInitNode* zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_49DE1C22_ConstInitNode* zT_30;
    zT_49DE1C22_ConstInitNode zT_31;
    unsigned int zT_33;
    unsigned int new_cap;
    unsigned char* raw;
    zT_49DE1C22_ConstInitNode* new_nodes;
    unsigned int i;
    zT_2 = self->nodes_cap;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->nodes_cap;
    new_cap = zT_5;
    if ((unsigned char)(new_cap < (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 16;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_13 = self->alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(32) * new_cap), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_11 = new_cap * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_22 = zT_20.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_22;
    zT_25 = (zT_49DE1C22_ConstInitNode*)raw;
    new_nodes = zT_25;
    zT_27 = 0;
    i = zT_27;
    goto z_bb_12;
    z_bb_12:
    zT_28 = self->nodes_len;
    if ((unsigned char)(i < zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_30 = self->nodes;
    zT_31 = zT_30[i];
    new_nodes[i] = zT_31;
    goto z_bb_15;
    z_bb_14:
    self->nodes = new_nodes;
    self->nodes_cap = new_cap;
    return;
    z_bb_15:
    zT_33 = i + (unsigned int)(1);
    i = zT_33;
    goto z_bb_12;
}

/* tableEnsureKids */
void zF_0E390AEC_tableEnsureKids(zT_4065182A_ConstInitTable* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_FDFD82FD_EU_362 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int* zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int* zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* new_kids;
    unsigned int i;
    zT_2 = self->kids_cap;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->kids_cap;
    new_cap = zT_5;
    if ((unsigned char)(new_cap < (unsigned int)(32))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 32;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_13 = self->alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_11 = new_cap * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_22 = zT_20.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_22;
    zT_25 = (unsigned int*)raw;
    new_kids = zT_25;
    zT_27 = 0;
    i = zT_27;
    goto z_bb_12;
    z_bb_12:
    zT_28 = self->kids_len;
    if ((unsigned char)(i < zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_30 = self->kids;
    zT_31 = zT_30[i];
    new_kids[i] = zT_31;
    goto z_bb_15;
    z_bb_14:
    self->kids = new_kids;
    self->kids_cap = new_cap;
    return;
    z_bb_15:
    zT_33 = i + (unsigned int)(1);
    i = zT_33;
    goto z_bb_12;
}

/* tableAddNode */
unsigned int zF_094E0976_tableAddNode(zT_4065182A_ConstInitTable* self, unsigned char kind, zT_79FAE712_u64 a, unsigned int b, unsigned int c) {
    zT_4065182A_ConstInitTable* zT_5;
    unsigned int zT_7;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_49DE1C22_ConstInitNode zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_49DE1C22_ConstInitNode* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int idx;
    zT_5 = self;
    zT_7 = self->nodes_len;
    zF_7EB8906A_tableEnsureNodes(zT_5, (unsigned int)(zT_7 + (unsigned int)(1)));
    zT_11 = self->nodes_len;
    zT_12 = (unsigned int)zT_11;
    idx = zT_12;
    zT_13.kind = kind;
    zT_14 = 0;
    zT_13._pad0 = zT_14;
    zT_15 = 0;
    zT_13._pad1 = zT_15;
    zT_16 = 0;
    zT_13._pad2 = zT_16;
    zT_13.a = a;
    zT_13.b = b;
    zT_13.c = c;
    zT_17 = 0;
    zT_13.child_start = zT_17;
    zT_18 = 0;
    zT_13.child_count = zT_18;
    zT_19 = self->nodes;
    zT_20 = self->nodes_len;
    zT_19[zT_20] = zT_13;
    zT_21 = self->nodes_len;
    self->nodes_len = (unsigned int)(zT_21 + (unsigned int)(1));
    return idx;
}

/* tableFinishAgg */
void zF_D8E7F449_tableFinishAgg(zT_4065182A_ConstInitTable* self, unsigned int node_idx, unsigned int* scratch, unsigned int count) {
    zT_4065182A_ConstInitTable* zT_4;
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_23;
    zT_49DE1C22_ConstInitNode* zT_24;
    zT_49DE1C22_ConstInitNode* zT_26;
    zT_49DE1C22_ConstInitNode* zT_27;
    zT_49DE1C22_ConstInitNode* zT_29;
    unsigned int start;
    unsigned int i;
    zT_4 = self;
    zT_6 = self->kids_len;
    zF_0E390AEC_tableEnsureKids(zT_4, (unsigned int)(zT_6 + (unsigned int)((unsigned int)count)));
    zT_10 = self->kids_len;
    zT_11 = (unsigned int)zT_10;
    start = zT_11;
    zT_13 = 0;
    i = zT_13;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_15 = (unsigned int)i;
    zT_16 = scratch[zT_15];
    zT_17 = self->kids;
    zT_18 = self->kids_len;
    zT_17[zT_18] = zT_16;
    zT_19 = self->kids_len;
    self->kids_len = (unsigned int)(zT_19 + (unsigned int)(1));
    goto z_bb_4;
    z_bb_3:
    zT_24 = self->nodes;
    zT_26 = zT_24 + (unsigned int)((unsigned int)node_idx);
    zT_26->child_start = start;
    zT_27 = self->nodes;
    zT_29 = zT_27 + (unsigned int)((unsigned int)node_idx);
    zT_29->child_count = count;
    return;
    z_bb_4:
    zT_23 = i + (unsigned int)(1);
    i = zT_23;
    goto z_bb_1;
}

/* constInitNodeAt */
zT_49DE1C22_ConstInitNode zF_C30CDA77_constInitNodeAt(zT_4065182A_ConstInitTable* tbl, unsigned int idx) {
    zT_49DE1C22_ConstInitNode* zT_2;
    unsigned int zT_3;
    zT_49DE1C22_ConstInitNode zT_4;
    zT_2 = tbl->nodes;
    zT_3 = (unsigned int)idx;
    zT_4 = zT_2[zT_3];
    return zT_4;
}

/* constInitChildAt */
unsigned int zF_45C63E41_constInitChildAt(zT_4065182A_ConstInitTable* tbl, unsigned int node_idx, unsigned int i) {
    zT_49DE1C22_ConstInitNode* zT_4;
    unsigned int zT_5;
    zT_49DE1C22_ConstInitNode zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_49DE1C22_ConstInitNode nd;
    zT_4 = tbl->nodes;
    zT_5 = (unsigned int)node_idx;
    zT_6 = zT_4[zT_5];
    nd = zT_6;
    zT_7 = tbl->kids;
    zT_8 = nd.child_start;
    zT_10 = (unsigned int)(unsigned int)(zT_8 + i);
    zT_11 = zT_7[zT_10];
    return zT_11;
}

/* constInitEvaluate */
zT_BAEE192E_Opt_10 zF_2B750645_constInitEvaluate(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int decl_idx) {
    zT_4D150975_ConstInitEvalCtx* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_3 = ec;
    zT_4 = module_id;
    zT_5 = decl_idx;
    zT_8 = zF_4E698A93_evalDecl(zT_3, zT_4, zT_5, (unsigned int)(0));
    return zT_8;
}

/* evalDecl */
zT_BAEE192E_Opt_10 zF_4E698A93_evalDecl(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int decl_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_4065182A_ConstInitTable* zT_9;
    zT_BAEE192E_Opt_10 zT_11 = {0};
    unsigned char zT_12;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    zT_BAEE192E_Opt_10 zT_17;
    zT_BAEE192E_Opt_10 zT_20 = {0};
    zT_21D3708C_U32ToU32Map* zT_21;
    unsigned int zT_22;
    zT_4065182A_ConstInitTable* zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    zT_21D3708C_U32ToU32Map* zT_28;
    unsigned int zT_29;
    zT_4065182A_ConstInitTable* zT_31;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_40;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned int zT_50;
    zT_8EED1867_ResolvedTypeTable* zT_51;
    unsigned int zT_52;
    zT_BAEE192E_Opt_10 zT_54 = {0};
    unsigned char zT_55;
    zT_4D150975_ConstInitEvalCtx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_21D3708C_U32ToU32Map* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_4065182A_ConstInitTable* zT_71;
    zT_BAEE192E_Opt_10 zT_73;
    zT_21D3708C_U32ToU32Map* zT_74;
    unsigned int zT_75;
    zT_4065182A_ConstInitTable* zT_77;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned int memo;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 root;
    unsigned int dtype;
    unsigned int dt;
    unsigned int r;
    if ((unsigned char)(decl_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_9 = ec->tbl;
    zT_7 = &zT_9->roots;
    zT_8 = decl_idx;
    zT_11 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    memo = zT_11.value;
    if ((unsigned char)(memo == (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_16.has_value = 0;
    return zT_16;
    z_bb_6:
    zT_17.has_value = 1;
    zT_17.value = memo;
    return zT_17;
    z_bb_7:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_8:
    zT_23 = ec->tbl;
    zT_21 = &zT_23->in_progress;
    zT_22 = decl_idx;
    zT_25 = zF_F3EE5998_u32ToU32MapGet(zT_21, zT_22);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_27.has_value = 0;
    return zT_27;
    z_bb_10:
    zT_31 = ec->tbl;
    zT_28 = &zT_31->in_progress;
    zT_29 = decl_idx;
    zF_26476265_u32ToU32MapPut(zT_28, zT_29, (unsigned int)(1));
    zT_35 = ec->store;
    zT_36 = decl_idx;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    decl = zT_38;
    root.has_value = 0;
    zT_40 = decl.kind;
    if ((unsigned char)(zT_40 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_45 = decl.child_1;
    zT_44 = zT_45 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_44 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_44) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_50 = 18;
    dtype = zT_50;
    zT_51 = ec->resolved;
    zT_52 = decl_idx;
    zT_54 = zF_999DCF51_resolvedTypeTableGe(zT_51, zT_52);
    zT_55 = zT_54.has_value;
    if (zT_55) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_66 = root.has_value;
    if (zT_66) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    dt = zT_54.value;
    dtype = dt;
    goto z_bb_17;
    z_bb_17:
    zT_57 = ec;
    zT_58 = module_id;
    zT_59 = decl.child_1;
    zT_60 = dtype;
    zT_65 = zF_BF602E2F_classify(zT_57, zT_58, zT_59, zT_60, (unsigned int)(depth + (unsigned int)(1)));
    root = zT_65;
    goto z_bb_15;
    z_bb_18:
    r = root.value;
    zT_71 = ec->tbl;
    zT_68 = &zT_71->roots;
    zT_69 = decl_idx;
    zT_70 = r;
    zF_26476265_u32ToU32MapPut(zT_68, zT_69, zT_70);
    zT_73.has_value = 1;
    zT_73.value = r;
    return zT_73;
    z_bb_19:
    zT_77 = ec->tbl;
    zT_74 = &zT_77->roots;
    zT_75 = decl_idx;
    zF_26476265_u32ToU32MapPut(zT_74, zT_75, (unsigned int)(4294967295u));
    zT_80.has_value = 0;
    return zT_80;
}

/* typeKindOf */
unsigned int zF_4E56FBAE_typeKindOf(zT_4D150975_ConstInitEvalCtx* ec, unsigned int type_id) {
    unsigned char zT_4;
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_D155D06D_Type* zT_13;
    unsigned int zT_14;
    zT_D155D06D_Type zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    if ((unsigned char)(type_id == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = ec->registry;
    zT_7 = zT_6->types_len;
    zT_4 = (unsigned int)((unsigned int)type_id) >= zT_7;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel));
    z_bb_5:
    zT_12 = ec->registry;
    zT_13 = zT_12->types_items;
    zT_14 = (unsigned int)type_id;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.kind;
    return (unsigned int)((unsigned int)zT_16);
}

/* isU8ish */
unsigned char zF_092A96D8_isU8ish(zT_4D150975_ConstInitEvalCtx* ec, unsigned int elem) {
    unsigned char zT_4;
    zT_4D150975_ConstInitEvalCtx* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    if ((unsigned char)(elem == (unsigned int)(8))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = elem == (unsigned int)(14);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    zT_8 = ec;
    zT_9 = elem;
    zT_10 = zF_4E56FBAE_typeKindOf(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type)))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(0);
}

/* valNodeFromComptime */
zT_BAEE192E_Opt_10 zF_23832EEE_valNodeFromComptime(zT_4D150975_ConstInitEvalCtx* ec, zT_89B1DDDA_ComptimeVal cv, unsigned int type_id) {
    unsigned char zT_3;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    unsigned char zT_8 = 0;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    zT_4D150975_ConstInitEvalCtx* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    unsigned char zT_27;
    unsigned char zT_32;
    unsigned char zT_37;
    unsigned char zT_42;
    unsigned char zT_47;
    unsigned char zT_52;
    unsigned char zT_57;
    unsigned char zT_62;
    unsigned char zT_67;
    unsigned char zT_72;
    unsigned char zT_77;
    unsigned char zT_82;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_0163D9A4_ComptimeInt zT_88;
    unsigned int zT_89;
    zT_0163D9A4_ComptimeInt zT_91;
    unsigned char zT_92 = 0;
    zT_BAEE192E_Opt_10 zT_94 = {0};
    zT_0163D9A4_ComptimeInt zT_96;
    zT_0163D9A4_ComptimeInt zT_97;
    zT_79FAE712_u64 zT_98 = 0;
    unsigned int zT_100;
    zT_0163D9A4_ComptimeInt zT_101;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_4065182A_ConstInitTable* zT_104;
    unsigned char zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned int zT_110;
    unsigned int zT_112 = 0;
    zT_BAEE192E_Opt_10 zT_113;
    unsigned char zT_114;
    zT_79FAE712_u64 zT_118;
    zT_0163D9A4_ComptimeInt zT_119;
    zT_0163D9A4_ComptimeInt zT_120;
    unsigned char zT_121 = 0;
    zT_79FAE712_u64 zT_123;
    zT_4065182A_ConstInitTable* zT_124;
    unsigned char zT_125;
    zT_79FAE712_u64 zT_126;
    unsigned int zT_130;
    unsigned int zT_133 = 0;
    zT_BAEE192E_Opt_10 zT_134;
    unsigned char zT_135;
    zT_4065182A_ConstInitTable* zT_138;
    unsigned char zT_139;
    zT_79FAE712_u64 zT_140;
    unsigned int zT_144;
    unsigned int zT_148 = 0;
    zT_BAEE192E_Opt_10 zT_149;
    zT_BAEE192E_Opt_10 zT_150 = {0};
    unsigned int tk;
    unsigned char is_int_ty;
    zT_79FAE712_u64 pattern;
    unsigned int nflag;
    zT_79FAE712_u64 bv;
    zT_3 = cv.kind;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = cv.v;
    zT_6 = zT_7;
    zT_8 = zF_EF3A264A_comptimeIntFits64(zT_6);
    if ((unsigned char)(!zT_8)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_114 = cv.kind;
    if ((unsigned char)(zT_114 == (unsigned char)(1))) goto z_bb_52; else goto z_bb_53;
    z_bb_3:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_4:
    if ((unsigned char)(type_id != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = ec->registry;
    zT_16 = zT_15->types_len;
    zT_13 = (unsigned int)((unsigned int)type_id) < zT_16;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = ec;
    zT_20 = type_id;
    zT_21 = zF_4E56FBAE_typeKindOf(zT_19, zT_20);
    tk = zT_21;
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type)))) goto z_bb_11; else goto z_bb_10;
    z_bb_9:
    zT_97 = cv.v;
    zT_96 = zT_97;
    zT_98 = zF_4F2C9C5D_ciToU64(zT_96);
    pattern = zT_98;
    zT_100 = 0;
    nflag = zT_100;
    zT_101 = cv.v;
    zT_102 = zT_101.neg;
    if (zT_102) goto z_bb_50; else goto z_bb_51;
    z_bb_10:
    zT_27 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type));
    goto z_bb_12;
    z_bb_11:
    zT_27 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_27) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_32 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type));
    goto z_bb_15;
    z_bb_14:
    zT_32 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_37 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type));
    goto z_bb_18;
    z_bb_17:
    zT_37 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_37) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_42 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type));
    goto z_bb_21;
    z_bb_20:
    zT_42 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_42) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_47 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type));
    goto z_bb_24;
    z_bb_23:
    zT_47 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_47) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_52 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type));
    goto z_bb_27;
    z_bb_26:
    zT_52 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_52) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_57 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type));
    goto z_bb_30;
    z_bb_29:
    zT_57 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_57) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_62 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type));
    goto z_bb_33;
    z_bb_32:
    zT_62 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_62) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_67 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type));
    goto z_bb_36;
    z_bb_35:
    zT_67 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_67) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_72 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type));
    goto z_bb_39;
    z_bb_38:
    zT_72 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_72) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_77 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type));
    goto z_bb_42;
    z_bb_41:
    zT_77 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_77) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_82 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type));
    goto z_bb_45;
    z_bb_44:
    zT_82 = 1;
    goto z_bb_45;
    z_bb_45:
    is_int_ty = zT_82;
    if (is_int_ty) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_87 = ec->registry;
    zT_91 = cv.v;
    zT_88 = zT_91;
    zT_89 = type_id;
    zT_92 = zF_B28C4720_comptimeIntFitsType(zT_87, zT_88, zT_89);
    if ((unsigned char)(!zT_92)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_9;
    z_bb_48:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_103 = 1;
    nflag = zT_103;
    goto z_bb_51;
    z_bb_51:
    zT_104 = ec->tbl;
    zT_110 = 1;
    zT_105 = zT_110;
    zT_106 = pattern;
    zT_107 = nflag;
    zT_112 = zF_094E0976_tableAddNode(zT_104, zT_105, zT_106, zT_107, (unsigned int)(0));
    zT_113.has_value = 1;
    zT_113.value = zT_112;
    return zT_113;
    z_bb_52:
    zT_118 = 0;
    bv = zT_118;
    zT_120 = cv.v;
    zT_119 = zT_120;
    zT_121 = zF_0F5FA15F_ciIsZero(zT_119);
    if ((unsigned char)(!zT_121)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_135 = cv.kind;
    if ((unsigned char)(zT_135 == (unsigned char)(2))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_123 = 1;
    bv = zT_123;
    goto z_bb_55;
    z_bb_55:
    zT_124 = ec->tbl;
    zT_130 = 3;
    zT_125 = zT_130;
    zT_126 = bv;
    zT_133 = zF_094E0976_tableAddNode(zT_124, zT_125, zT_126, (unsigned int)(0), (unsigned int)(0));
    zT_134.has_value = 1;
    zT_134.value = zT_133;
    return zT_134;
    z_bb_56:
    zT_138 = ec->tbl;
    zT_144 = 2;
    zT_139 = zT_144;
    zT_140 = cv.float_bits;
    zT_148 = zF_094E0976_tableAddNode(zT_138, zT_139, zT_140, (unsigned int)(0), (unsigned int)(0));
    zT_149.has_value = 1;
    zT_149.value = zT_148;
    return zT_149;
    z_bb_57:
    zT_150.has_value = 0;
    return zT_150;
}

/* symbolIsConstGlobalSym */
unsigned char zF_145B7326_symbolIsConstGlobal(zT_3A105EF1_Symbol* s) {
    zT_3C598AEF_SymbolKind zT_1;
    unsigned short zT_6;
    zT_1 = s->kind;
    if ((unsigned char)(zT_1 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = s->flags;
    return (unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_6) & (unsigned short)(1)) == (unsigned short)(0));
}

/* resolveModuleBaseNode */
unsigned int zF_644AB5CE_resolveModuleBaseNo(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int base_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    zT_3D7259E2_SymbolRegistry* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_77F031D4_Opt_960 zT_24 = {0};
    unsigned char zT_25;
    zT_3C598AEF_SymbolKind zT_27;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_35;
    unsigned int zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    unsigned short zT_51;
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62 = 0;
    zT_072B53A6_ModuleRegistry* zT_63;
    unsigned int zT_64;
    zT_BAEE192E_Opt_10 zT_66 = {0};
    unsigned char zT_67;
    zT_22A7C88B_AstNode bn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    unsigned int path_id;
    unsigned int mtid;
    if ((unsigned char)(base_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = ec->store;
    zT_8 = base_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    bn = zT_10;
    zT_11 = bn.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ec->store;
    zT_17 = base_idx;
    zT_19 = zF_53458827_astStoreIdentifier(zT_16, zT_17);
    nid = zT_19;
    zT_20 = ec->symbol_reg;
    zT_21 = module_id;
    zT_22 = nid;
    zT_24 = zF_A398987E_symbolRegistryQuali(zT_20, zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_54 = bn.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_5:
    s = zT_24.value;
    zT_27 = s->kind;
    if ((unsigned char)(zT_27 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_31 = s->module_id;
    return zT_31;
    z_bb_8:
    zT_32 = s->type_id;
    if ((unsigned char)(zT_32 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_36 = s->type_id;
    zT_38 = ec->registry;
    zT_39 = zT_38->types_len;
    zT_35 = (unsigned int)((unsigned int)zT_36) < zT_39;
    goto z_bb_11;
    z_bb_10:
    zT_35 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_35) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_42 = ec->registry;
    zT_43 = zT_42->types_items;
    zT_44 = s->type_id;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    sty = zT_46;
    zT_47 = sty.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_6;
    z_bb_14:
    zT_51 = sty.module_id;
    return (unsigned int)((unsigned int)zT_51);
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_59 = ec->store;
    zT_60 = base_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    path_id = zT_62;
    zT_63 = ec->module_reg;
    zT_64 = path_id;
    zT_66 = zF_A258E183_moduleRegistryPathT(zT_63, zT_64);
    zT_67 = zT_66.has_value;
    if (zT_67) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return (unsigned int)(0);
    z_bb_18:
    mtid = zT_66.value;
    return mtid;
    z_bb_19:
    return (unsigned int)(0);
}

/* valueCopyDecl */
zT_BAEE192E_Opt_10 zF_07765C6B_valueCopyDecl(zT_4D150975_ConstInitEvalCtx* ec, unsigned int target_module, unsigned int decl_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_BAEE192E_Opt_10 zT_28 = {0};
    zT_22A7C88B_AstNode decl;
    if ((unsigned char)(decl_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_8 = ec->store;
    zT_9 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    decl = zT_11;
    zT_12 = decl.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16.has_value = 0;
    return zT_16;
    z_bb_4:
    zT_17 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_17) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_6:
    zT_24 = ec;
    zT_25 = target_module;
    zT_26 = decl_idx;
    zT_27 = depth;
    zT_28 = zF_4E698A93_evalDecl(zT_24, zT_25, zT_26, zT_27);
    return zT_28;
}

/* classifyScalar */
zT_BAEE192E_Opt_10 zF_83AC95E3_classifyScalar(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    zT_E494E487_anon_323991 zT_16;
    zT_00435AEB_f64* zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    unsigned int zT_22;
    zT_00435AEB_f64 zT_23;
    zT_00435AEB_f64* zT_25;
    zT_79FAE712_u64* zT_26;
    zT_4065182A_ConstInitTable* zT_27;
    unsigned char zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_33;
    unsigned int zT_37 = 0;
    zT_BAEE192E_Opt_10 zT_38;
    zT_8143F551_AstKind zT_39;
    zT_79FAE712_u64 zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_79FAE712_u64 zT_48 = 0;
    zT_0163D9A4_ComptimeInt zT_49 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_50;
    zT_89B1DDDA_ComptimeVal zT_51;
    unsigned int zT_52;
    zT_0163D9A4_ComptimeInt zT_53;
    zT_89B1DDDA_ComptimeVal zT_54 = {0};
    zT_BAEE192E_Opt_10 zT_55 = {0};
    zT_8143F551_AstKind zT_56;
    zT_79FAE712_u64 zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_79FAE712_u64 zT_65 = 0;
    zT_0163D9A4_ComptimeInt zT_66 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_68;
    zT_89B1DDDA_ComptimeVal zT_69;
    unsigned int zT_70;
    zT_0163D9A4_ComptimeInt zT_71;
    zT_89B1DDDA_ComptimeVal zT_72 = {0};
    zT_BAEE192E_Opt_10 zT_73 = {0};
    unsigned char zT_74;
    zT_4065182A_ConstInitTable* zT_77;
    zT_49DE1C22_ConstInitNode* zT_78;
    zT_49DE1C22_ConstInitNode* zT_80;
    zT_BAEE192E_Opt_10 zT_81;
    zT_BAEE192E_Opt_10 zT_82 = {0};
    zT_8143F551_AstKind zT_83;
    zT_79FAE712_u64 zT_88;
    unsigned char zT_89;
    zT_79FAE712_u64 zT_94;
    zT_4065182A_ConstInitTable* zT_95;
    unsigned char zT_96;
    zT_79FAE712_u64 zT_97;
    unsigned int zT_101;
    unsigned int zT_104 = 0;
    zT_BAEE192E_Opt_10 zT_105;
    zT_8143F551_AstKind zT_106;
    zT_21D3708C_U32ToU32Map* zT_110;
    unsigned int zT_111;
    zT_BAEE192E_Opt_10 zT_113 = {0};
    unsigned char zT_114;
    zT_0163D9A4_ComptimeInt zT_119 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_120;
    zT_89B1DDDA_ComptimeVal zT_121;
    unsigned int zT_122;
    zT_0163D9A4_ComptimeInt zT_123;
    zT_89B1DDDA_ComptimeVal zT_124 = {0};
    zT_BAEE192E_Opt_10 zT_125 = {0};
    zT_BAEE192E_Opt_10 zT_126 = {0};
    zT_8143F551_AstKind zT_127;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    unsigned int zT_135 = 0;
    zT_3D7259E2_SymbolRegistry* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    zT_77F031D4_Opt_960 zT_140 = {0};
    unsigned char zT_141;
    zT_3C598AEF_SymbolKind zT_143;
    zT_4065182A_ConstInitTable* zT_147;
    unsigned char zT_148;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_158 = 0;
    zT_BAEE192E_Opt_10 zT_159;
    zT_3A105EF1_Symbol* zT_160;
    unsigned char zT_161 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_BAEE192E_Opt_10 zT_168 = {0};
    zT_BAEE192E_Opt_10 zT_169 = {0};
    zT_8143F551_AstKind zT_170;
    zT_4D150975_ConstInitEvalCtx* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179 = 0;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    unsigned int zT_186 = 0;
    zT_3D7259E2_SymbolRegistry* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_77F031D4_Opt_960 zT_191 = {0};
    unsigned char zT_192;
    zT_3C598AEF_SymbolKind zT_194;
    zT_4065182A_ConstInitTable* zT_198;
    unsigned char zT_199;
    unsigned int zT_201;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_209 = 0;
    zT_BAEE192E_Opt_10 zT_210;
    zT_3A105EF1_Symbol* zT_211;
    unsigned char zT_212 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_BAEE192E_Opt_10 zT_219 = {0};
    zT_BAEE192E_Opt_10 zT_220 = {0};
    zT_8143F551_AstKind zT_221;
    zT_4D150975_ConstInitEvalCtx* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_BAEE192E_Opt_10 zT_231 = {0};
    zT_8143F551_AstKind zT_232;
    unsigned char zT_234 = 0;
    zT_DA663F79_ComptimeEval* zT_235;
    unsigned int zT_236;
    zT_7534F824_Opt_223 zT_238 = {0};
    unsigned char zT_239;
    zT_4D150975_ConstInitEvalCtx* zT_241;
    zT_89B1DDDA_ComptimeVal zT_242;
    unsigned int zT_243;
    zT_BAEE192E_Opt_10 zT_244 = {0};
    zT_BAEE192E_Opt_10 zT_245 = {0};
    zT_BAEE192E_Opt_10 zT_246 = {0};
    zT_22A7C88B_AstNode node;
    zT_00435AEB_f64 fb0;
    zT_79FAE712_u64* fbp0;
    zT_0163D9A4_ComptimeInt v;
    zT_0163D9A4_ComptimeInt v2;
    zT_BAEE192E_Opt_10 nid2;
    unsigned int n2;
    zT_79FAE712_u64 bv;
    unsigned int ev;
    zT_0163D9A4_ComptimeInt pv;
    unsigned int name_id;
    zT_3A105EF1_Symbol* s;
    unsigned int mid;
    unsigned int fname;
    zT_3A105EF1_Symbol* s2;
    zT_89B1DDDA_ComptimeVal cv;
    zT_6 = ec->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = ec->store;
    zT_16 = zT_15->float_values;
    zT_17 = zT_16.items;
    zT_18 = ec->store;
    zT_19 = node_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_18, zT_19);
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_17[zT_22];
    fb0 = zT_23;
    zT_25 = (zT_00435AEB_f64*)&fb0;
    zT_26 = (zT_79FAE712_u64*)zT_25;
    fbp0 = zT_26;
    zT_27 = ec->tbl;
    zT_33 = 2;
    zT_28 = zT_33;
    zT_29 = *fbp0;
    zT_37 = zF_094E0976_tableAddNode(zT_27, zT_28, zT_29, (unsigned int)(0), (unsigned int)(0));
    zT_38.has_value = 1;
    zT_38.value = zT_37;
    return zT_38;
    z_bb_2:
    zT_39 = node.kind;
    if ((unsigned char)(zT_39 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_45 = ec->store;
    zT_46 = node_idx;
    zT_48 = zF_678B9A72_astStoreIntValue(zT_45, zT_46);
    zT_44 = zT_48;
    zT_49 = zF_1EAA44E6_ciFromU64(zT_44);
    v = zT_49;
    zT_50 = ec;
    zT_53 = v;
    zT_54 = zF_237A4571_ciIntVal(zT_53);
    zT_51 = zT_54;
    zT_52 = type_id;
    zT_55 = zF_23832EEE_valNodeFromComptime(zT_50, zT_51, zT_52);
    return zT_55;
    z_bb_4:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_62 = ec->store;
    zT_63 = node_idx;
    zT_65 = zF_678B9A72_astStoreIntValue(zT_62, zT_63);
    zT_61 = zT_65;
    zT_66 = zF_1EAA44E6_ciFromU64(zT_61);
    v2 = zT_66;
    zT_68 = ec;
    zT_71 = v2;
    zT_72 = zF_237A4571_ciIntVal(zT_71);
    zT_69 = zT_72;
    zT_70 = type_id;
    zT_73 = zF_23832EEE_valNodeFromComptime(zT_68, zT_69, zT_70);
    nid2 = zT_73;
    zT_74 = nid2.has_value;
    if (zT_74) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_83 = node.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    n2 = nid2.value;
    zT_77 = ec->tbl;
    zT_78 = zT_77->nodes;
    zT_80 = zT_78 + (unsigned int)((unsigned int)n2);
    zT_80->kind = (unsigned int)(4);
    zT_81.has_value = 1;
    zT_81.value = n2;
    return zT_81;
    z_bb_8:
    zT_82.has_value = 0;
    return zT_82;
    z_bb_9:
    zT_88 = 0;
    bv = zT_88;
    zT_89 = node.flags;
    if ((unsigned char)((unsigned char)(zT_89 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_106 = node.kind;
    if ((unsigned char)(zT_106 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_94 = 1;
    bv = zT_94;
    goto z_bb_12;
    z_bb_12:
    zT_95 = ec->tbl;
    zT_101 = 3;
    zT_96 = zT_101;
    zT_97 = bv;
    zT_104 = zF_094E0976_tableAddNode(zT_95, zT_96, zT_97, (unsigned int)(0), (unsigned int)(0));
    zT_105.has_value = 1;
    zT_105.value = zT_104;
    return zT_105;
    z_bb_13:
    zT_110 = ec->enum_values;
    zT_111 = node_idx;
    zT_113 = zF_F3EE5998_u32ToU32MapGet(zT_110, zT_111);
    zT_114 = zT_113.has_value;
    if (zT_114) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_127 = node.kind;
    if ((unsigned char)(zT_127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    ev = zT_113.value;
    zT_119 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)ev));
    pv = zT_119;
    zT_120 = ec;
    zT_123 = pv;
    zT_124 = zF_237A4571_ciIntVal(zT_123);
    zT_121 = zT_124;
    zT_122 = type_id;
    zT_125 = zF_23832EEE_valNodeFromComptime(zT_120, zT_121, zT_122);
    return zT_125;
    z_bb_16:
    zT_126.has_value = 0;
    return zT_126;
    z_bb_17:
    zT_132 = ec->store;
    zT_133 = node_idx;
    zT_135 = zF_53458827_astStoreIdentifier(zT_132, zT_133);
    name_id = zT_135;
    zT_136 = ec->symbol_reg;
    zT_137 = module_id;
    zT_138 = name_id;
    zT_140 = zF_A398987E_symbolRegistryQuali(zT_136, zT_137, zT_138);
    zT_141 = zT_140.has_value;
    if (zT_141) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_170 = node.kind;
    if ((unsigned char)(zT_170 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_25; else goto z_bb_26;
    z_bb_19:
    s = zT_140.value;
    zT_143 = s->kind;
    if ((unsigned char)(zT_143 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_169.has_value = 0;
    return zT_169;
    z_bb_21:
    zT_147 = ec->tbl;
    zT_153 = 7;
    zT_148 = zT_153;
    zT_154 = s->name_id;
    zT_150 = s->module_id;
    zT_158 = zF_094E0976_tableAddNode(zT_147, zT_148, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_154), zT_150, (unsigned int)(0));
    zT_159.has_value = 1;
    zT_159.value = zT_158;
    return zT_159;
    z_bb_22:
    zT_160 = s;
    zT_161 = zF_145B7326_symbolIsConstGlobal(zT_160);
    if (zT_161) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_162 = ec;
    zT_163 = s->module_id;
    zT_164 = s->decl_node;
    zT_165 = depth;
    zT_168 = zF_07765C6B_valueCopyDecl(zT_162, zT_163, zT_164, zT_165);
    return zT_168;
    z_bb_24:
    goto z_bb_20;
    z_bb_25:
    zT_175 = ec;
    zT_176 = module_id;
    zT_177 = node.child_0;
    zT_179 = zF_644AB5CE_resolveModuleBaseNo(zT_175, zT_176, zT_177);
    mid = zT_179;
    if ((unsigned char)(mid != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_221 = node.kind;
    if ((unsigned char)(zT_221 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_35; else goto z_bb_36;
    z_bb_27:
    zT_183 = ec->store;
    zT_184 = node_idx;
    zT_186 = zF_8BA26B9E_astStoreNodePayload(zT_183, zT_184);
    fname = zT_186;
    zT_187 = ec->symbol_reg;
    zT_188 = mid;
    zT_189 = fname;
    zT_191 = zF_A398987E_symbolRegistryQuali(zT_187, zT_188, zT_189);
    zT_192 = zT_191.has_value;
    if (zT_192) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_220.has_value = 0;
    return zT_220;
    z_bb_29:
    s2 = zT_191.value;
    zT_194 = s2->kind;
    if ((unsigned char)(zT_194 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_198 = ec->tbl;
    zT_204 = 7;
    zT_199 = zT_204;
    zT_205 = s2->name_id;
    zT_201 = s2->module_id;
    zT_209 = zF_094E0976_tableAddNode(zT_198, zT_199, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_205), zT_201, (unsigned int)(0));
    zT_210.has_value = 1;
    zT_210.value = zT_209;
    return zT_210;
    z_bb_32:
    zT_211 = s2;
    zT_212 = zF_145B7326_symbolIsConstGlobal(zT_211);
    if (zT_212) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_213 = ec;
    zT_214 = s2->module_id;
    zT_215 = s2->decl_node;
    zT_216 = depth;
    zT_219 = zF_07765C6B_valueCopyDecl(zT_213, zT_214, zT_215, zT_216);
    return zT_219;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_225 = ec;
    zT_226 = module_id;
    zT_227 = node.child_0;
    zT_228 = type_id;
    zT_229 = depth;
    zT_231 = zF_BF602E2F_classify(zT_225, zT_226, zT_227, zT_228, zT_229);
    return zT_231;
    z_bb_36:
    zT_232 = node.kind;
    zT_234 = zF_CEDEFC06_comptimeShapeKind(zT_232);
    if (zT_234) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_235 = ec->ce;
    zT_236 = node_idx;
    zT_238 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_235, zT_236);
    zT_239 = zT_238.has_value;
    if (zT_239) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_246.has_value = 0;
    return zT_246;
    z_bb_39:
    cv = zT_238.value;
    zT_241 = ec;
    zT_242 = cv;
    zT_243 = type_id;
    zT_244 = zF_23832EEE_valNodeFromComptime(zT_241, zT_242, zT_243);
    return zT_244;
    z_bb_40:
    zT_245.has_value = 0;
    return zT_245;
}

/* comptimeShapeKind */
unsigned char zF_CEDEFC06_comptimeShapeKind(zT_8143F551_AstKind k) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    unsigned char zT_28;
    unsigned char zT_36;
    unsigned char zT_40;
    unsigned char zT_44;
    unsigned char zT_48;
    unsigned char zT_56;
    unsigned char zT_64;
    unsigned char zT_68;
    unsigned char zT_72;
    unsigned char zT_76;
    unsigned char zT_80;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_16 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_11;
    z_bb_10:
    zT_16 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_16) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_20 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_14;
    z_bb_13:
    zT_20 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_20) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_24 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_17;
    z_bb_16:
    zT_24 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_24) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_28 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_20;
    z_bb_19:
    zT_28 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_28) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_36 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_25;
    z_bb_24:
    zT_36 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_36) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_40 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_28;
    z_bb_27:
    zT_40 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_40) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_44 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_31;
    z_bb_30:
    zT_44 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_44) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_48 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_34;
    z_bb_33:
    zT_48 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_48) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_56 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_39;
    z_bb_38:
    zT_56 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_56) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)(1);
    z_bb_41:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_64 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_44;
    z_bb_43:
    zT_64 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_64) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_68 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_47;
    z_bb_46:
    zT_68 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_68) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_72 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_50;
    z_bb_49:
    zT_72 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_72) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_76 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_53;
    z_bb_52:
    zT_76 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_76) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_80 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_56;
    z_bb_55:
    zT_80 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_80) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned char)(1);
    z_bb_58:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(1);
    z_bb_60:
    return (unsigned char)(0);
}

/* classifyAddr */
zT_BAEE192E_Opt_10 zF_19E37948_classifyAddr(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int target_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    zT_3D7259E2_SymbolRegistry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_77F031D4_Opt_960 zT_22 = {0};
    unsigned char zT_23;
    zT_3C598AEF_SymbolKind zT_25;
    zT_4065182A_ConstInitTable* zT_29;
    unsigned char zT_30;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_40 = 0;
    zT_BAEE192E_Opt_10 zT_41;
    zT_3C598AEF_SymbolKind zT_42;
    unsigned int zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    unsigned int zT_49;
    zT_BAEE192E_Opt_10 zT_52 = {0};
    unsigned char zT_53;
    unsigned int zT_55;
    zT_4065182A_ConstInitTable* zT_56;
    unsigned char zT_57;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_66 = 0;
    zT_BAEE192E_Opt_10 zT_67;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    zT_4D150975_ConstInitEvalCtx* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_78 = 0;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    unsigned int zT_85 = 0;
    zT_3D7259E2_SymbolRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_77F031D4_Opt_960 zT_90 = {0};
    unsigned char zT_91;
    zT_3C598AEF_SymbolKind zT_93;
    zT_4065182A_ConstInitTable* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_108 = 0;
    zT_BAEE192E_Opt_10 zT_109;
    zT_3C598AEF_SymbolKind zT_110;
    unsigned int zT_115;
    zT_8EED1867_ResolvedTypeTable* zT_116;
    unsigned int zT_117;
    zT_BAEE192E_Opt_10 zT_120 = {0};
    unsigned char zT_121;
    zT_4065182A_ConstInitTable* zT_123;
    unsigned char zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_133 = 0;
    zT_BAEE192E_Opt_10 zT_134;
    zT_BAEE192E_Opt_10 zT_135 = {0};
    zT_BAEE192E_Opt_10 zT_136 = {0};
    zT_22A7C88B_AstNode t;
    unsigned int name_id;
    zT_3A105EF1_Symbol* s;
    unsigned int gtid;
    unsigned int gt;
    unsigned int mid;
    unsigned int fname;
    zT_3A105EF1_Symbol* s2;
    unsigned int gtid2;
    unsigned int gt2;
    (void)depth;
    zT_5 = ec->store;
    zT_6 = target_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    t = zT_8;
    zT_9 = t.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = ec->store;
    zT_15 = target_idx;
    zT_17 = zF_53458827_astStoreIdentifier(zT_14, zT_15);
    name_id = zT_17;
    zT_18 = ec->symbol_reg;
    zT_19 = module_id;
    zT_20 = name_id;
    zT_22 = zF_A398987E_symbolRegistryQuali(zT_18, zT_19, zT_20);
    zT_23 = zT_22.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_69 = t.kind;
    if ((unsigned char)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_12; else goto z_bb_13;
    z_bb_3:
    s = zT_22.value;
    zT_25 = s->kind;
    if ((unsigned char)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_68.has_value = 0;
    return zT_68;
    z_bb_5:
    zT_29 = ec->tbl;
    zT_35 = 7;
    zT_30 = zT_35;
    zT_36 = s->name_id;
    zT_32 = s->module_id;
    zT_40 = zF_094E0976_tableAddNode(zT_29, zT_30, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_36), zT_32, (unsigned int)(0));
    zT_41.has_value = 1;
    zT_41.value = zT_40;
    return zT_41;
    z_bb_6:
    zT_42 = s->kind;
    if ((unsigned char)(zT_42 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_47 = 0;
    gtid = zT_47;
    zT_48 = ec->resolved;
    zT_49 = s->decl_node;
    zT_52 = zF_999DCF51_resolvedTypeTableGe(zT_48, zT_49);
    zT_53 = zT_52.has_value;
    if (zT_53) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    gt = zT_52.value;
    gtid = gt;
    goto z_bb_10;
    z_bb_10:
    zT_56 = ec->tbl;
    zT_62 = 6;
    zT_57 = zT_62;
    zT_63 = s->name_id;
    zT_59 = s->module_id;
    zT_60 = gtid;
    zT_66 = zF_094E0976_tableAddNode(zT_56, zT_57, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_63), zT_59, zT_60);
    zT_67.has_value = 1;
    zT_67.value = zT_66;
    return zT_67;
    z_bb_11:
    zT_55 = s->type_id;
    gtid = zT_55;
    goto z_bb_10;
    z_bb_12:
    zT_74 = ec;
    zT_75 = module_id;
    zT_76 = t.child_0;
    zT_78 = zF_644AB5CE_resolveModuleBaseNo(zT_74, zT_75, zT_76);
    mid = zT_78;
    if ((unsigned char)(mid != (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_14:
    zT_82 = ec->store;
    zT_83 = target_idx;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_82, zT_83);
    fname = zT_85;
    zT_86 = ec->symbol_reg;
    zT_87 = mid;
    zT_88 = fname;
    zT_90 = zF_A398987E_symbolRegistryQuali(zT_86, zT_87, zT_88);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_135.has_value = 0;
    return zT_135;
    z_bb_16:
    s2 = zT_90.value;
    zT_93 = s2->kind;
    if ((unsigned char)(zT_93 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_97 = ec->tbl;
    zT_103 = 7;
    zT_98 = zT_103;
    zT_104 = s2->name_id;
    zT_100 = s2->module_id;
    zT_108 = zF_094E0976_tableAddNode(zT_97, zT_98, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_104), zT_100, (unsigned int)(0));
    zT_109.has_value = 1;
    zT_109.value = zT_108;
    return zT_109;
    z_bb_19:
    zT_110 = s2->kind;
    if ((unsigned char)(zT_110 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_115 = s2->type_id;
    gtid2 = zT_115;
    zT_116 = ec->resolved;
    zT_117 = s2->decl_node;
    zT_120 = zF_999DCF51_resolvedTypeTableGe(zT_116, zT_117);
    zT_121 = zT_120.has_value;
    if (zT_121) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_17;
    z_bb_22:
    gt2 = zT_120.value;
    gtid2 = gt2;
    goto z_bb_23;
    z_bb_23:
    zT_123 = ec->tbl;
    zT_129 = 6;
    zT_124 = zT_129;
    zT_130 = s2->name_id;
    zT_126 = s2->module_id;
    zT_127 = gtid2;
    zT_133 = zF_094E0976_tableAddNode(zT_123, zT_124, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_130), zT_126, zT_127);
    zT_134.has_value = 1;
    zT_134.value = zT_133;
    return zT_134;
}

/* classifyAgg */
zT_BAEE192E_Opt_10 zF_F7CF67F0_classifyAgg(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    zT_3D7259E2_SymbolRegistry* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_77F031D4_Opt_960 zT_30 = {0};
    unsigned char zT_31;
    zT_3A105EF1_Symbol* zT_33;
    unsigned char zT_34 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_BAEE192E_Opt_10 zT_41 = {0};
    zT_BAEE192E_Opt_10 zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    zT_4D150975_ConstInitEvalCtx* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_52 = 0;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    zT_3D7259E2_SymbolRegistry* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_77F031D4_Opt_960 zT_64 = {0};
    unsigned char zT_65;
    zT_3A105EF1_Symbol* zT_67;
    unsigned char zT_68 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_BAEE192E_Opt_10 zT_75 = {0};
    zT_BAEE192E_Opt_10 zT_76 = {0};
    zT_338B7C76_TypeRegistry* zT_82;
    zT_E834303C_ArrayPayload* zT_83;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_D155D06D_Type* zT_85;
    unsigned int zT_86;
    zT_D155D06D_Type zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_E834303C_ArrayPayload zT_90;
    unsigned int zT_92;
    zT_8143F551_AstKind zT_93;
    unsigned char zT_97;
    zT_8143F551_AstKind zT_98;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    unsigned int zT_106 = 0;
    zT_BAEE192E_Opt_10 zT_109 = {0};
    zT_4065182A_ConstInitTable* zT_111;
    unsigned char zT_112;
    unsigned int zT_117;
    unsigned int zT_121 = 0;
    zT_3E40CD83_Sand* zT_123;
    zT_4065182A_ConstInitTable* zT_126;
    int zT_129;
    zT_FDFD82FD_EU_362 zT_134 = {0};
    unsigned char zT_135;
    unsigned char* zT_136;
    unsigned int* zT_139;
    unsigned int zT_141;
    unsigned char zT_143;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_152 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_BAEE192E_Opt_10 zT_161 = {0};
    unsigned char zT_162;
    unsigned int zT_164;
    unsigned char zT_165;
    zT_4065182A_ConstInitTable* zT_166;
    unsigned char zT_167;
    unsigned int zT_172;
    unsigned int zT_176 = 0;
    unsigned int zT_177;
    unsigned int zT_179;
    zT_BAEE192E_Opt_10 zT_181 = {0};
    zT_4065182A_ConstInitTable* zT_182;
    unsigned int zT_183;
    unsigned int* zT_184;
    unsigned int zT_185;
    zT_BAEE192E_Opt_10 zT_187;
    zT_BAEE192E_Opt_10 zT_188 = {0};
    zT_8143F551_AstKind zT_193;
    zT_BAEE192E_Opt_10 zT_197 = {0};
    zT_338B7C76_TypeRegistry* zT_199;
    zT_666DC2E1_TuplePayload* zT_200;
    zT_338B7C76_TypeRegistry* zT_201;
    zT_D155D06D_Type* zT_202;
    unsigned int zT_203;
    zT_D155D06D_Type zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    zT_666DC2E1_TuplePayload zT_207;
    unsigned short zT_209;
    unsigned int zT_210;
    zT_6B0A7D14_AstStore* zT_212;
    unsigned int zT_213;
    unsigned int zT_215 = 0;
    zT_BAEE192E_Opt_10 zT_218 = {0};
    zT_4065182A_ConstInitTable* zT_220;
    unsigned char zT_221;
    unsigned int zT_226;
    unsigned int zT_230 = 0;
    zT_3E40CD83_Sand* zT_232;
    zT_4065182A_ConstInitTable* zT_235;
    int zT_238;
    zT_FDFD82FD_EU_362 zT_243 = {0};
    unsigned char zT_244;
    unsigned char* zT_245;
    unsigned int* zT_248;
    unsigned int zT_250;
    unsigned char zT_252;
    zT_338B7C76_TypeRegistry* zT_255;
    unsigned int* zT_256;
    unsigned int zT_257;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_6B0A7D14_AstStore* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_267 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    zT_BAEE192E_Opt_10 zT_275 = {0};
    unsigned char zT_276;
    unsigned int zT_278;
    unsigned char zT_279;
    unsigned int zT_281;
    zT_BAEE192E_Opt_10 zT_283 = {0};
    zT_4065182A_ConstInitTable* zT_284;
    unsigned int zT_285;
    unsigned int* zT_286;
    unsigned int zT_287;
    zT_BAEE192E_Opt_10 zT_289;
    zT_338B7C76_TypeRegistry* zT_295;
    zT_406493CE_StructPayload* zT_296;
    zT_338B7C76_TypeRegistry* zT_297;
    zT_D155D06D_Type* zT_298;
    unsigned int zT_299;
    zT_D155D06D_Type zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_406493CE_StructPayload zT_303;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned short zT_308;
    unsigned int zT_309;
    zT_3E40CD83_Sand* zT_311;
    zT_4065182A_ConstInitTable* zT_314;
    zT_FDFD82FD_EU_362 zT_321 = {0};
    unsigned char zT_322;
    unsigned char* zT_323;
    unsigned int* zT_326;
    unsigned int zT_328;
    unsigned int zT_330;
    zT_338B7C76_TypeRegistry* zT_332;
    zT_2DF01B61_FieldEntry* zT_333;
    unsigned int zT_334;
    zT_2DF01B61_FieldEntry zT_335;
    unsigned int zT_336;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_342;
    unsigned int zT_344;
    zT_8143F551_AstKind zT_345;
    zT_6B0A7D14_AstStore* zT_350;
    unsigned int zT_351;
    unsigned int zT_353 = 0;
    unsigned int zT_355;
    zT_6B0A7D14_AstStore* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_363 = 0;
    zT_6B0A7D14_AstStore* zT_365;
    unsigned int zT_366;
    unsigned int zT_368 = 0;
    unsigned char zT_370;
    unsigned int zT_372;
    zT_338B7C76_TypeRegistry* zT_374;
    zT_2DF01B61_FieldEntry* zT_375;
    unsigned int zT_376;
    zT_2DF01B61_FieldEntry zT_377;
    unsigned int zT_378;
    unsigned char zT_380;
    unsigned int zT_382;
    zT_BAEE192E_Opt_10 zT_384 = {0};
    unsigned int zT_386;
    zT_4065182A_ConstInitTable* zT_388;
    unsigned char zT_389;
    unsigned int zT_394;
    unsigned int zT_398 = 0;
    zT_3E40CD83_Sand* zT_400;
    zT_4065182A_ConstInitTable* zT_403;
    int zT_406;
    zT_FDFD82FD_EU_362 zT_411 = {0};
    unsigned char zT_412;
    unsigned char* zT_413;
    unsigned int* zT_416;
    unsigned int zT_418;
    unsigned char zT_420;
    zT_338B7C76_TypeRegistry* zT_423;
    zT_2DF01B61_FieldEntry* zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    unsigned int zT_428;
    zT_2DF01B61_FieldEntry zT_429;
    unsigned int zT_431;
    unsigned char zT_433;
    unsigned int zT_435;
    zT_6B0A7D14_AstStore* zT_439;
    unsigned int zT_440;
    unsigned int zT_441;
    unsigned int zT_443 = 0;
    zT_6B0A7D14_AstStore* zT_444;
    unsigned int zT_445;
    unsigned int zT_447 = 0;
    unsigned int zT_448;
    zT_4D150975_ConstInitEvalCtx* zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_6B0A7D14_AstStore* zT_455;
    unsigned int zT_456;
    zT_22A7C88B_AstNode zT_458 = {0};
    zT_BAEE192E_Opt_10 zT_463 = {0};
    unsigned char zT_464;
    unsigned char zT_466;
    unsigned char zT_467;
    unsigned int zT_469;
    zT_4065182A_ConstInitTable* zT_472;
    unsigned char zT_473;
    unsigned int zT_478;
    unsigned int zT_482 = 0;
    unsigned int zT_483;
    unsigned int zT_485;
    zT_BAEE192E_Opt_10 zT_487 = {0};
    zT_4065182A_ConstInitTable* zT_488;
    unsigned int zT_489;
    unsigned int* zT_490;
    unsigned int zT_491;
    zT_BAEE192E_Opt_10 zT_493;
    zT_8143F551_AstKind zT_494;
    zT_6B0A7D14_AstStore* zT_499;
    unsigned int zT_500;
    unsigned int zT_502 = 0;
    zT_BAEE192E_Opt_10 zT_505 = {0};
    zT_4065182A_ConstInitTable* zT_507;
    unsigned char zT_508;
    unsigned int zT_513;
    unsigned int zT_517 = 0;
    zT_3E40CD83_Sand* zT_519;
    zT_4065182A_ConstInitTable* zT_522;
    int zT_525;
    zT_FDFD82FD_EU_362 zT_530 = {0};
    unsigned char zT_531;
    unsigned char* zT_532;
    unsigned int* zT_535;
    unsigned int zT_537;
    unsigned char zT_539;
    zT_338B7C76_TypeRegistry* zT_542;
    zT_2DF01B61_FieldEntry* zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned int zT_547;
    zT_2DF01B61_FieldEntry zT_548;
    zT_6B0A7D14_AstStore* zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    unsigned int zT_554 = 0;
    zT_4D150975_ConstInitEvalCtx* zT_555;
    unsigned int zT_556;
    unsigned int zT_557;
    unsigned int zT_558;
    zT_BAEE192E_Opt_10 zT_563 = {0};
    unsigned char zT_564;
    unsigned int zT_566;
    unsigned char zT_567;
    unsigned int zT_569;
    zT_BAEE192E_Opt_10 zT_571 = {0};
    zT_4065182A_ConstInitTable* zT_572;
    unsigned int zT_573;
    unsigned int* zT_574;
    unsigned int zT_575;
    zT_BAEE192E_Opt_10 zT_577;
    zT_BAEE192E_Opt_10 zT_578 = {0};
    zT_8143F551_AstKind zT_583;
    zT_BAEE192E_Opt_10 zT_587 = {0};
    zT_338B7C76_TypeRegistry* zT_589;
    zT_AF9231A2_UnionPayload* zT_590;
    zT_338B7C76_TypeRegistry* zT_591;
    zT_D155D06D_Type* zT_592;
    unsigned int zT_593;
    zT_D155D06D_Type zT_594;
    unsigned int zT_595;
    unsigned int zT_596;
    zT_AF9231A2_UnionPayload zT_597;
    unsigned int zT_599;
    unsigned int zT_600;
    unsigned short zT_602;
    unsigned int zT_603;
    zT_6B0A7D14_AstStore* zT_605;
    unsigned int zT_606;
    unsigned int zT_608 = 0;
    zT_BAEE192E_Opt_10 zT_612 = {0};
    zT_6B0A7D14_AstStore* zT_614;
    unsigned int zT_615;
    unsigned int zT_619 = 0;
    zT_6B0A7D14_AstStore* zT_621;
    unsigned int zT_622;
    unsigned int zT_624 = 0;
    zT_C69B2266_i64 zT_626;
    unsigned int zT_628;
    zT_338B7C76_TypeRegistry* zT_630;
    zT_2DF01B61_FieldEntry* zT_631;
    unsigned int zT_632;
    zT_2DF01B61_FieldEntry zT_633;
    unsigned int zT_634;
    zT_C69B2266_i64 zT_636;
    unsigned int zT_638;
    zT_BAEE192E_Opt_10 zT_641 = {0};
    zT_C69B2266_i64 zT_643;
    unsigned int zT_645;
    zT_338B7C76_TypeRegistry* zT_647;
    zT_2DF01B61_FieldEntry* zT_648;
    unsigned int zT_649;
    zT_2DF01B61_FieldEntry zT_650;
    unsigned int zT_651;
    zT_C69B2266_i64 zT_654;
    unsigned int zT_656;
    zT_BAEE192E_Opt_10 zT_658 = {0};
    zT_338B7C76_TypeRegistry* zT_660;
    zT_2DF01B61_FieldEntry* zT_661;
    unsigned int zT_663;
    zT_2DF01B61_FieldEntry zT_664;
    zT_4D150975_ConstInitEvalCtx* zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    unsigned int zT_668;
    zT_6B0A7D14_AstStore* zT_670;
    unsigned int zT_671;
    zT_22A7C88B_AstNode zT_673 = {0};
    zT_BAEE192E_Opt_10 zT_678 = {0};
    unsigned char zT_679;
    zT_4065182A_ConstInitTable* zT_682;
    unsigned char zT_683;
    unsigned int zT_688;
    unsigned int zT_692 = 0;
    zT_3E40CD83_Sand* zT_694;
    zT_4065182A_ConstInitTable* zT_697;
    int zT_700;
    unsigned int zT_701;
    zT_FDFD82FD_EU_362 zT_704 = {0};
    unsigned char zT_705;
    unsigned char* zT_706;
    unsigned int* zT_709;
    int zT_710;
    zT_4065182A_ConstInitTable* zT_711;
    unsigned int zT_712;
    unsigned int* zT_713;
    zT_BAEE192E_Opt_10 zT_717;
    zT_BAEE192E_Opt_10 zT_718 = {0};
    zT_8143F551_AstKind zT_723;
    zT_BAEE192E_Opt_10 zT_727 = {0};
    zT_338B7C76_TypeRegistry* zT_729;
    zT_54FF90FA_TaggedUnionPayload* zT_730;
    zT_338B7C76_TypeRegistry* zT_731;
    zT_D155D06D_Type* zT_732;
    unsigned int zT_733;
    zT_D155D06D_Type zT_734;
    unsigned int zT_735;
    unsigned int zT_736;
    zT_54FF90FA_TaggedUnionPayload zT_737;
    unsigned int zT_739;
    unsigned int zT_740;
    unsigned short zT_742;
    unsigned int zT_743;
    zT_6B0A7D14_AstStore* zT_745;
    unsigned int zT_746;
    unsigned int zT_748 = 0;
    zT_BAEE192E_Opt_10 zT_752 = {0};
    zT_6B0A7D14_AstStore* zT_754;
    unsigned int zT_755;
    unsigned int zT_759 = 0;
    zT_6B0A7D14_AstStore* zT_761;
    unsigned int zT_762;
    unsigned int zT_764 = 0;
    zT_C69B2266_i64 zT_766;
    unsigned int zT_768;
    zT_338B7C76_TypeRegistry* zT_770;
    zT_2DF01B61_FieldEntry* zT_771;
    unsigned int zT_772;
    zT_2DF01B61_FieldEntry zT_773;
    unsigned int zT_774;
    zT_C69B2266_i64 zT_776;
    unsigned int zT_778;
    zT_BAEE192E_Opt_10 zT_781 = {0};
    zT_338B7C76_TypeRegistry* zT_783;
    zT_2DF01B61_FieldEntry* zT_784;
    unsigned int zT_786;
    zT_2DF01B61_FieldEntry zT_787;
    unsigned int zT_788;
    zT_BAEE192E_Opt_10 zT_791 = {0};
    zT_79FAE712_u64 zT_793;
    zT_338B7C76_TypeRegistry* zT_795;
    zT_D155D06D_Type* zT_796;
    unsigned int zT_797;
    unsigned int zT_798;
    zT_D155D06D_Type zT_799;
    zT_33EF6BFB_TypeKind zT_800;
    zT_338B7C76_TypeRegistry* zT_805;
    zT_457ECFEE_EnumPayload* zT_806;
    unsigned int zT_807;
    unsigned int zT_808;
    zT_457ECFEE_EnumPayload zT_809;
    unsigned char zT_811;
    unsigned short zT_813;
    unsigned short zT_814;
    zT_338B7C76_TypeRegistry* zT_817;
    zT_D96DCDF2_EnumMember* zT_818;
    unsigned int zT_819;
    unsigned int zT_822;
    zT_D96DCDF2_EnumMember zT_823;
    unsigned int zT_824;
    zT_C69B2266_i64 zT_826;
    zT_79FAE712_u64 zT_828;
    unsigned char zT_829;
    unsigned short zT_831;
    zT_BAEE192E_Opt_10 zT_833 = {0};
    zT_4065182A_ConstInitTable* zT_835;
    unsigned char zT_836;
    unsigned int zT_841;
    unsigned int zT_845 = 0;
    zT_3E40CD83_Sand* zT_847;
    zT_4065182A_ConstInitTable* zT_850;
    int zT_853;
    unsigned int zT_854;
    zT_FDFD82FD_EU_362 zT_857 = {0};
    unsigned char zT_858;
    unsigned char* zT_859;
    unsigned int* zT_862;
    zT_4065182A_ConstInitTable* zT_863;
    unsigned char zT_864;
    zT_79FAE712_u64 zT_865;
    unsigned int zT_869;
    unsigned int zT_872 = 0;
    int zT_873;
    zT_4065182A_ConstInitTable* zT_874;
    unsigned char zT_875;
    unsigned int zT_880;
    unsigned int zT_884 = 0;
    int zT_885;
    zT_4065182A_ConstInitTable* zT_886;
    unsigned int zT_887;
    unsigned int* zT_888;
    zT_BAEE192E_Opt_10 zT_892;
    zT_8143F551_AstKind zT_897;
    zT_4065182A_ConstInitTable* zT_901;
    unsigned char zT_902;
    unsigned int zT_907;
    unsigned int zT_911 = 0;
    zT_BAEE192E_Opt_10 zT_912;
    zT_338B7C76_TypeRegistry* zT_914;
    zT_0B10E8E9_OptionalPayload* zT_915;
    zT_338B7C76_TypeRegistry* zT_916;
    zT_D155D06D_Type* zT_917;
    unsigned int zT_918;
    zT_D155D06D_Type zT_919;
    unsigned int zT_920;
    unsigned int zT_921;
    zT_0B10E8E9_OptionalPayload zT_922;
    zT_4D150975_ConstInitEvalCtx* zT_923;
    unsigned int zT_924;
    unsigned int zT_925;
    unsigned int zT_926;
    zT_BAEE192E_Opt_10 zT_931 = {0};
    unsigned char zT_932;
    zT_4065182A_ConstInitTable* zT_935;
    unsigned char zT_936;
    unsigned int zT_941;
    unsigned int zT_945 = 0;
    zT_3E40CD83_Sand* zT_947;
    zT_4065182A_ConstInitTable* zT_950;
    int zT_953;
    unsigned int zT_954;
    zT_FDFD82FD_EU_362 zT_957 = {0};
    unsigned char zT_958;
    unsigned char* zT_959;
    unsigned int* zT_962;
    int zT_963;
    zT_4065182A_ConstInitTable* zT_964;
    unsigned char zT_965;
    unsigned int zT_970;
    unsigned int zT_974 = 0;
    int zT_975;
    zT_4065182A_ConstInitTable* zT_976;
    unsigned int zT_977;
    unsigned int* zT_978;
    zT_BAEE192E_Opt_10 zT_982;
    zT_BAEE192E_Opt_10 zT_983 = {0};
    zT_338B7C76_TypeRegistry* zT_989;
    zT_42C2D6BF_EUPayload* zT_990;
    zT_338B7C76_TypeRegistry* zT_991;
    zT_D155D06D_Type* zT_992;
    unsigned int zT_993;
    zT_D155D06D_Type zT_994;
    unsigned int zT_995;
    unsigned int zT_996;
    zT_42C2D6BF_EUPayload zT_997;
    unsigned int zT_999;
    unsigned char zT_1003;
    zT_4D150975_ConstInitEvalCtx* zT_1004;
    unsigned int zT_1005;
    unsigned int zT_1006 = 0;
    zT_8143F551_AstKind zT_1011;
    zT_BAEE192E_Opt_10 zT_1016 = {0};
    zT_21D3708C_U32ToU32Map* zT_1017;
    unsigned int zT_1018;
    zT_BAEE192E_Opt_10 zT_1020 = {0};
    unsigned char zT_1021;
    zT_4065182A_ConstInitTable* zT_1024;
    unsigned char zT_1025;
    unsigned int zT_1030;
    unsigned int zT_1034 = 0;
    zT_3E40CD83_Sand* zT_1036;
    zT_4065182A_ConstInitTable* zT_1039;
    int zT_1042;
    unsigned int zT_1043;
    zT_FDFD82FD_EU_362 zT_1046 = {0};
    unsigned char zT_1047;
    unsigned char* zT_1048;
    unsigned int* zT_1051;
    zT_4065182A_ConstInitTable* zT_1052;
    unsigned char zT_1053;
    unsigned int zT_1058;
    unsigned int zT_1062 = 0;
    int zT_1063;
    zT_4065182A_ConstInitTable* zT_1064;
    unsigned char zT_1065;
    unsigned int zT_1070;
    unsigned int zT_1074 = 0;
    int zT_1075;
    zT_4065182A_ConstInitTable* zT_1076;
    unsigned int zT_1077;
    unsigned int* zT_1078;
    zT_BAEE192E_Opt_10 zT_1082;
    zT_BAEE192E_Opt_10 zT_1083 = {0};
    zT_BAEE192E_Opt_10 zT_1084 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_1085;
    unsigned int zT_1086;
    unsigned int zT_1087;
    unsigned int zT_1088;
    zT_BAEE192E_Opt_10 zT_1092 = {0};
    unsigned char zT_1093;
    zT_4065182A_ConstInitTable* zT_1096;
    unsigned char zT_1097;
    unsigned int zT_1102;
    unsigned int zT_1106 = 0;
    zT_3E40CD83_Sand* zT_1108;
    zT_4065182A_ConstInitTable* zT_1111;
    int zT_1114;
    unsigned int zT_1115;
    zT_FDFD82FD_EU_362 zT_1118 = {0};
    unsigned char zT_1119;
    unsigned char* zT_1120;
    unsigned int* zT_1123;
    int zT_1124;
    zT_4065182A_ConstInitTable* zT_1125;
    unsigned char zT_1126;
    unsigned int zT_1131;
    unsigned int zT_1135 = 0;
    int zT_1136;
    zT_4065182A_ConstInitTable* zT_1137;
    unsigned int zT_1138;
    unsigned int* zT_1139;
    zT_BAEE192E_Opt_10 zT_1143;
    zT_BAEE192E_Opt_10 zT_1144 = {0};
    zT_BAEE192E_Opt_10 zT_1145 = {0};
    zT_22A7C88B_AstNode node;
    unsigned int tk;
    unsigned int cv_name;
    zT_3A105EF1_Symbol* cvs;
    unsigned int cv_mid;
    unsigned int cv_fn;
    zT_3A105EF1_Symbol* cvs2;
    zT_E834303C_ArrayPayload ap;
    unsigned int want;
    unsigned int n;
    unsigned int agg;
    unsigned char* scratch_raw;
    unsigned int* scratch;
    unsigned int i;
    unsigned char ok;
    unsigned int cei;
    unsigned int ch;
    zT_666DC2E1_TuplePayload tp;
    unsigned int tcount;
    unsigned int n2;
    unsigned int agg2;
    unsigned char* scratch_raw2;
    unsigned int* scratch2;
    unsigned int j;
    unsigned char ok2;
    unsigned int et;
    unsigned int cj;
    unsigned int ch2;
    zT_406493CE_StructPayload sp;
    unsigned int fs;
    unsigned int fc;
    unsigned char* vis_raw;
    unsigned int* vis;
    unsigned int vc;
    unsigned int fi;
    unsigned int n3;
    unsigned int ei3;
    unsigned int fi3;
    unsigned int fn3;
    unsigned char found3;
    unsigned int fj3;
    unsigned int agg3;
    unsigned char* scratch_raw3;
    unsigned int* scratch3;
    unsigned int vi;
    unsigned char ok3;
    zT_2DF01B61_FieldEntry fe3;
    unsigned int val_node;
    unsigned char have;
    unsigned int fj4;
    unsigned int fi4;
    unsigned int ch3;
    unsigned int n4;
    unsigned int agg4;
    unsigned char* scratch_raw4;
    unsigned int* scratch4;
    unsigned int vi4;
    unsigned char ok4;
    zT_2DF01B61_FieldEntry fe4;
    unsigned int cj4;
    unsigned int ch4;
    zT_AF9231A2_UnionPayload up;
    unsigned int ufs;
    unsigned int ufc;
    unsigned int n5;
    unsigned int fi5;
    unsigned int fn5;
    zT_C69B2266_i64 ai5;
    unsigned int uj;
    zT_C69B2266_i64 first_vis;
    unsigned int uj2;
    zT_2DF01B61_FieldEntry afe;
    unsigned int ch5;
    unsigned int agg5;
    unsigned char* scratch_raw5;
    unsigned int* scratch5;
    zT_54FF90FA_TaggedUnionPayload tpu;
    unsigned int tfs;
    unsigned int tfc;
    unsigned int n6;
    unsigned int fi6;
    unsigned int fn6;
    zT_C69B2266_i64 ai6;
    unsigned int tj;
    zT_2DF01B61_FieldEntry tfe;
    zT_79FAE712_u64 tag_val;
    zT_D155D06D_Type ttag;
    zT_457ECFEE_EnumPayload ep;
    unsigned char found_t;
    unsigned short em;
    unsigned int agg6;
    unsigned char* scratch_raw6;
    zT_D96DCDF2_EnumMember mem;
    unsigned int* scratch6;
    zT_0B10E8E9_OptionalPayload op;
    unsigned int pay;
    unsigned int agg7;
    unsigned char* scratch_raw7;
    unsigned int* scratch7;
    zT_42C2D6BF_EUPayload ep2;
    unsigned int pay_ty;
    unsigned char is_void_pay;
    unsigned int ev2;
    unsigned int agg8;
    unsigned char* scratch_raw8;
    unsigned int* scratch8;
    unsigned int pay2;
    unsigned int agg9;
    unsigned char* scratch_raw9;
    unsigned int* scratch9;
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = ec->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = ec;
    zT_15 = type_id;
    zT_16 = zF_4E56FBAE_typeKindOf(zT_14, zT_15);
    tk = zT_16;
    zT_17 = node.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = ec->store;
    zT_23 = node_idx;
    zT_25 = zF_53458827_astStoreIdentifier(zT_22, zT_23);
    cv_name = zT_25;
    zT_26 = ec->symbol_reg;
    zT_27 = module_id;
    zT_28 = cv_name;
    zT_30 = zF_A398987E_symbolRegistryQuali(zT_26, zT_27, zT_28);
    zT_31 = zT_30.has_value;
    if (zT_31) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_5:
    cvs = zT_30.value;
    zT_33 = cvs;
    zT_34 = zF_145B7326_symbolIsConstGlobal(zT_33);
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_42.has_value = 0;
    return zT_42;
    z_bb_7:
    zT_35 = ec;
    zT_36 = cvs->module_id;
    zT_37 = cvs->decl_node;
    zT_38 = depth;
    zT_41 = zF_07765C6B_valueCopyDecl(zT_35, zT_36, zT_37, zT_38);
    return zT_41;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_48 = ec;
    zT_49 = module_id;
    zT_50 = node.child_0;
    zT_52 = zF_644AB5CE_resolveModuleBaseNo(zT_48, zT_49, zT_50);
    cv_mid = zT_52;
    if ((unsigned char)(cv_mid != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_17; else goto z_bb_18;
    z_bb_11:
    zT_56 = ec->store;
    zT_57 = node_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    cv_fn = zT_59;
    zT_60 = ec->symbol_reg;
    zT_61 = cv_mid;
    zT_62 = cv_fn;
    zT_64 = zF_A398987E_symbolRegistryQuali(zT_60, zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_76.has_value = 0;
    return zT_76;
    z_bb_13:
    cvs2 = zT_64.value;
    zT_67 = cvs2;
    zT_68 = zF_145B7326_symbolIsConstGlobal(zT_67);
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_69 = ec;
    zT_70 = cvs2->module_id;
    zT_71 = cvs2->decl_node;
    zT_72 = depth;
    zT_75 = zF_07765C6B_valueCopyDecl(zT_69, zT_70, zT_71, zT_72);
    return zT_75;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_82 = ec->registry;
    zT_83 = zT_82->array_items;
    zT_84 = ec->registry;
    zT_85 = zT_84->types_items;
    zT_86 = (unsigned int)type_id;
    zT_87 = zT_85[zT_86];
    zT_88 = zT_87.payload_idx;
    zT_89 = (unsigned int)zT_88;
    zT_90 = zT_83[zT_89];
    ap = zT_90;
    zT_92 = ap.length;
    want = zT_92;
    zT_93 = node.kind;
    if ((unsigned char)(zT_93 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_20; else goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type)))) goto z_bb_41; else goto z_bb_42;
    z_bb_19:
    zT_98 = node.kind;
    zT_97 = zT_98 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_21;
    z_bb_20:
    zT_97 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_97) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_103 = ec->store;
    zT_104 = node_idx;
    zT_106 = zF_152E19CB_astStoreNodeExtraCh(zT_103, zT_104);
    n = zT_106;
    if ((unsigned char)((unsigned int)((unsigned int)n) > want)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_188.has_value = 0;
    return zT_188;
    z_bb_24:
    zT_109.has_value = 0;
    return zT_109;
    z_bb_25:
    zT_111 = ec->tbl;
    zT_117 = 8;
    zT_112 = zT_117;
    zT_121 = zF_094E0976_tableAddNode(zT_111, zT_112, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg = zT_121;
    zT_126 = ec->tbl;
    zT_123 = zT_126->alloc;
    zT_129 = 1;
    zT_134 = zF_1395EB68_sandAlloc(zT_123, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)(unsigned int)(want + zT_129))), (unsigned int)(4));
    zT_135 = zT_134.is_error;
    if (zT_135) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    pal_trap();
    z_bb_27:
    zT_136 = zT_134.data.payload;
    goto z_bb_28;
    z_bb_28:
    scratch_raw = zT_136;
    zT_139 = (unsigned int*)scratch_raw;
    scratch = zT_139;
    zT_141 = 0;
    i = zT_141;
    zT_143 = 1;
    ok = zT_143;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(i < want)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    if ((unsigned char)(i < (unsigned int)((unsigned int)n))) goto z_bb_33; else goto z_bb_35;
    z_bb_31:
    if ((unsigned char)(!ok)) goto z_bb_39; else goto z_bb_40;
    z_bb_32:
    zT_179 = i + (unsigned int)(1);
    i = zT_179;
    goto z_bb_29;
    z_bb_33:
    zT_148 = ec->store;
    zT_149 = node_idx;
    zT_150 = i;
    zT_152 = zF_B10B1BC1_astStoreNodeExtraCh(zT_148, zT_149, zT_150);
    cei = zT_152;
    zT_153 = ec;
    zT_154 = module_id;
    zT_155 = cei;
    zT_156 = ap.elem;
    zT_161 = zF_BF602E2F_classify(zT_153, zT_154, zT_155, zT_156, (unsigned int)(depth + (unsigned int)(1)));
    zT_162 = zT_161.has_value;
    if (zT_162) goto z_bb_36; else goto z_bb_38;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_166 = ec->tbl;
    zT_172 = 0;
    zT_167 = zT_172;
    zT_176 = zF_094E0976_tableAddNode(zT_166, zT_167, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_177 = (unsigned int)i;
    scratch[zT_177] = zT_176;
    goto z_bb_34;
    z_bb_36:
    ch = zT_161.value;
    zT_164 = (unsigned int)i;
    scratch[zT_164] = ch;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_165 = 0;
    ok = zT_165;
    goto z_bb_31;
    z_bb_39:
    zT_181.has_value = 0;
    return zT_181;
    z_bb_40:
    zT_182 = ec->tbl;
    zT_183 = agg;
    zT_184 = scratch;
    zT_185 = want;
    zF_D8E7F449_tableFinishAgg(zT_182, zT_183, zT_184, zT_185);
    zT_187.has_value = 1;
    zT_187.value = agg;
    return zT_187;
    z_bb_41:
    zT_193 = node.kind;
    if ((unsigned char)(zT_193 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type)))) goto z_bb_59; else goto z_bb_60;
    z_bb_43:
    zT_197.has_value = 0;
    return zT_197;
    z_bb_44:
    zT_199 = ec->registry;
    zT_200 = zT_199->tup_items;
    zT_201 = ec->registry;
    zT_202 = zT_201->types_items;
    zT_203 = (unsigned int)type_id;
    zT_204 = zT_202[zT_203];
    zT_205 = zT_204.payload_idx;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_200[zT_206];
    tp = zT_207;
    zT_209 = tp.elems_count;
    zT_210 = (unsigned int)zT_209;
    tcount = zT_210;
    zT_212 = ec->store;
    zT_213 = node_idx;
    zT_215 = zF_152E19CB_astStoreNodeExtraCh(zT_212, zT_213);
    n2 = zT_215;
    if ((unsigned char)((unsigned int)((unsigned int)n2) != tcount)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_218.has_value = 0;
    return zT_218;
    z_bb_46:
    zT_220 = ec->tbl;
    zT_226 = 8;
    zT_221 = zT_226;
    zT_230 = zF_094E0976_tableAddNode(zT_220, zT_221, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg2 = zT_230;
    zT_235 = ec->tbl;
    zT_232 = zT_235->alloc;
    zT_238 = 1;
    zT_243 = zF_1395EB68_sandAlloc(zT_232, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)(unsigned int)(tcount + zT_238))), (unsigned int)(4));
    zT_244 = zT_243.is_error;
    if (zT_244) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    pal_trap();
    z_bb_48:
    zT_245 = zT_243.data.payload;
    goto z_bb_49;
    z_bb_49:
    scratch_raw2 = zT_245;
    zT_248 = (unsigned int*)scratch_raw2;
    scratch2 = zT_248;
    zT_250 = 0;
    j = zT_250;
    zT_252 = 1;
    ok2 = zT_252;
    goto z_bb_50;
    z_bb_50:
    if ((unsigned char)(j < tcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_255 = ec->registry;
    zT_256 = zT_255->xt_items;
    zT_257 = tp.elems_start;
    zT_260 = (unsigned int)((unsigned int)zT_257) + (unsigned int)((unsigned int)j);
    zT_261 = zT_256[zT_260];
    et = zT_261;
    zT_263 = ec->store;
    zT_264 = node_idx;
    zT_265 = j;
    zT_267 = zF_B10B1BC1_astStoreNodeExtraCh(zT_263, zT_264, zT_265);
    cj = zT_267;
    zT_268 = ec;
    zT_269 = module_id;
    zT_270 = cj;
    zT_271 = et;
    zT_275 = zF_BF602E2F_classify(zT_268, zT_269, zT_270, zT_271, (unsigned int)(depth + (unsigned int)(1)));
    zT_276 = zT_275.has_value;
    if (zT_276) goto z_bb_54; else goto z_bb_56;
    z_bb_52:
    if ((unsigned char)(!ok2)) goto z_bb_57; else goto z_bb_58;
    z_bb_53:
    zT_281 = j + (unsigned int)(1);
    j = zT_281;
    goto z_bb_50;
    z_bb_54:
    ch2 = zT_275.value;
    zT_278 = (unsigned int)j;
    scratch2[zT_278] = ch2;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_279 = 0;
    ok2 = zT_279;
    goto z_bb_52;
    z_bb_57:
    zT_283.has_value = 0;
    return zT_283;
    z_bb_58:
    zT_284 = ec->tbl;
    zT_285 = agg2;
    zT_286 = scratch2;
    zT_287 = tcount;
    zF_D8E7F449_tableFinishAgg(zT_284, zT_285, zT_286, zT_287);
    zT_289.has_value = 1;
    zT_289.value = agg2;
    return zT_289;
    z_bb_59:
    zT_295 = ec->registry;
    zT_296 = zT_295->st_items;
    zT_297 = ec->registry;
    zT_298 = zT_297->types_items;
    zT_299 = (unsigned int)type_id;
    zT_300 = zT_298[zT_299];
    zT_301 = zT_300.payload_idx;
    zT_302 = (unsigned int)zT_301;
    zT_303 = zT_296[zT_302];
    sp = zT_303;
    zT_305 = sp.fields_start;
    zT_306 = (unsigned int)zT_305;
    fs = zT_306;
    zT_308 = sp.fields_count;
    zT_309 = (unsigned int)zT_308;
    fc = zT_309;
    zT_314 = ec->tbl;
    zT_311 = zT_314->alloc;
    zT_321 = zF_1395EB68_sandAlloc(zT_311, (unsigned int)((unsigned int)(4) * (unsigned int)(fc + (unsigned int)(1))), (unsigned int)(4));
    zT_322 = zT_321.is_error;
    if (zT_322) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type)))) goto z_bb_122; else goto z_bb_123;
    z_bb_61:
    pal_trap();
    z_bb_62:
    zT_323 = zT_321.data.payload;
    goto z_bb_63;
    z_bb_63:
    vis_raw = zT_323;
    zT_326 = (unsigned int*)vis_raw;
    vis = zT_326;
    zT_328 = 0;
    vc = zT_328;
    zT_330 = 0;
    fi = zT_330;
    goto z_bb_64;
    z_bb_64:
    if ((unsigned char)(fi < fc)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_332 = ec->registry;
    zT_333 = zT_332->fe_items;
    zT_334 = fs + fi;
    zT_335 = zT_333[zT_334];
    zT_336 = zT_335.type_id;
    if ((unsigned char)(zT_336 != (unsigned int)(1))) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    zT_345 = node.kind;
    if ((unsigned char)(zT_345 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    zT_344 = fi + (unsigned int)(1);
    fi = zT_344;
    goto z_bb_64;
    z_bb_68:
    zT_339 = (unsigned int)fi;
    zT_340 = (unsigned int)vc;
    vis[zT_340] = zT_339;
    zT_342 = vc + (unsigned int)(1);
    vc = zT_342;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_67;
    z_bb_70:
    zT_350 = ec->store;
    zT_351 = node_idx;
    zT_353 = zF_152E19CB_astStoreNodeExtraCh(zT_350, zT_351);
    n3 = zT_353;
    zT_355 = 0;
    ei3 = zT_355;
    goto z_bb_72;
    z_bb_71:
    zT_494 = node.kind;
    if ((unsigned char)(zT_494 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_106; else goto z_bb_107;
    z_bb_72:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)n3))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_359 = ec->store;
    zT_360 = node_idx;
    zT_361 = ei3;
    zT_363 = zF_B10B1BC1_astStoreNodeExtraCh(zT_359, zT_360, zT_361);
    fi3 = zT_363;
    zT_365 = ec->store;
    zT_366 = fi3;
    zT_368 = zF_8BA26B9E_astStoreNodePayload(zT_365, zT_366);
    fn3 = zT_368;
    zT_370 = 0;
    found3 = zT_370;
    zT_372 = 0;
    fj3 = zT_372;
    goto z_bb_76;
    z_bb_74:
    zT_388 = ec->tbl;
    zT_394 = 8;
    zT_389 = zT_394;
    zT_398 = zF_094E0976_tableAddNode(zT_388, zT_389, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg3 = zT_398;
    zT_403 = ec->tbl;
    zT_400 = zT_403->alloc;
    zT_406 = 1;
    zT_411 = zF_1395EB68_sandAlloc(zT_400, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)(unsigned int)(vc + zT_406))), (unsigned int)(4));
    zT_412 = zT_411.is_error;
    if (zT_412) goto z_bb_84; else goto z_bb_85;
    z_bb_75:
    zT_386 = ei3 + (unsigned int)(1);
    ei3 = zT_386;
    goto z_bb_72;
    z_bb_76:
    if ((unsigned char)(fj3 < fc)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_374 = ec->registry;
    zT_375 = zT_374->fe_items;
    zT_376 = fs + fj3;
    zT_377 = zT_375[zT_376];
    zT_378 = zT_377.name_id;
    if ((unsigned char)(zT_378 == fn3)) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    if ((unsigned char)(!found3)) goto z_bb_82; else goto z_bb_83;
    z_bb_79:
    zT_382 = fj3 + (unsigned int)(1);
    fj3 = zT_382;
    goto z_bb_76;
    z_bb_80:
    zT_380 = 1;
    found3 = zT_380;
    goto z_bb_78;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_384.has_value = 0;
    return zT_384;
    z_bb_83:
    goto z_bb_75;
    z_bb_84:
    pal_trap();
    z_bb_85:
    zT_413 = zT_411.data.payload;
    goto z_bb_86;
    z_bb_86:
    scratch_raw3 = zT_413;
    zT_416 = (unsigned int*)scratch_raw3;
    scratch3 = zT_416;
    zT_418 = 0;
    vi = zT_418;
    zT_420 = 1;
    ok3 = zT_420;
    goto z_bb_87;
    z_bb_87:
    if ((unsigned char)(vi < vc)) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_423 = ec->registry;
    zT_424 = zT_423->fe_items;
    zT_425 = (unsigned int)vi;
    zT_426 = vis[zT_425];
    zT_428 = fs + (unsigned int)((unsigned int)zT_426);
    zT_429 = zT_424[zT_428];
    fe3 = zT_429;
    zT_431 = 0;
    val_node = zT_431;
    zT_433 = 0;
    have = zT_433;
    zT_435 = 0;
    fj4 = zT_435;
    goto z_bb_91;
    z_bb_89:
    if ((unsigned char)(!ok3)) goto z_bb_104; else goto z_bb_105;
    z_bb_90:
    zT_485 = vi + (unsigned int)(1);
    vi = zT_485;
    goto z_bb_87;
    z_bb_91:
    if ((unsigned char)(fj4 < (unsigned int)((unsigned int)n3))) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_439 = ec->store;
    zT_440 = node_idx;
    zT_441 = fj4;
    zT_443 = zF_B10B1BC1_astStoreNodeExtraCh(zT_439, zT_440, zT_441);
    fi4 = zT_443;
    zT_444 = ec->store;
    zT_445 = fi4;
    zT_447 = zF_8BA26B9E_astStoreNodePayload(zT_444, zT_445);
    zT_448 = fe3.name_id;
    if ((unsigned char)(zT_447 == zT_448)) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    if ((unsigned char)(!ok3)) goto z_bb_100; else goto z_bb_101;
    z_bb_94:
    zT_469 = fj4 + (unsigned int)(1);
    fj4 = zT_469;
    goto z_bb_91;
    z_bb_95:
    zT_450 = ec;
    zT_451 = module_id;
    zT_455 = ec->store;
    zT_456 = fi4;
    zT_458 = zF_FCDD1D35_astStoreNodeAt(zT_455, zT_456);
    zT_452 = zT_458.child_0;
    zT_453 = fe3.type_id;
    zT_463 = zF_BF602E2F_classify(zT_450, zT_451, zT_452, zT_453, (unsigned int)(depth + (unsigned int)(1)));
    zT_464 = zT_463.has_value;
    if (zT_464) goto z_bb_97; else goto z_bb_99;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    ch3 = zT_463.value;
    val_node = ch3;
    zT_466 = 1;
    have = zT_466;
    goto z_bb_98;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_467 = 0;
    ok3 = zT_467;
    goto z_bb_98;
    z_bb_100:
    goto z_bb_89;
    z_bb_101:
    if ((unsigned char)(!have)) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_472 = ec->tbl;
    zT_478 = 0;
    zT_473 = zT_478;
    zT_482 = zF_094E0976_tableAddNode(zT_472, zT_473, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    val_node = zT_482;
    goto z_bb_103;
    z_bb_103:
    zT_483 = (unsigned int)vi;
    scratch3[zT_483] = val_node;
    goto z_bb_90;
    z_bb_104:
    zT_487.has_value = 0;
    return zT_487;
    z_bb_105:
    zT_488 = ec->tbl;
    zT_489 = agg3;
    zT_490 = scratch3;
    zT_491 = vc;
    zF_D8E7F449_tableFinishAgg(zT_488, zT_489, zT_490, zT_491);
    zT_493.has_value = 1;
    zT_493.value = agg3;
    return zT_493;
    z_bb_106:
    zT_499 = ec->store;
    zT_500 = node_idx;
    zT_502 = zF_152E19CB_astStoreNodeExtraCh(zT_499, zT_500);
    n4 = zT_502;
    if ((unsigned char)((unsigned int)((unsigned int)n4) != vc)) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    zT_578.has_value = 0;
    return zT_578;
    z_bb_108:
    zT_505.has_value = 0;
    return zT_505;
    z_bb_109:
    zT_507 = ec->tbl;
    zT_513 = 8;
    zT_508 = zT_513;
    zT_517 = zF_094E0976_tableAddNode(zT_507, zT_508, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg4 = zT_517;
    zT_522 = ec->tbl;
    zT_519 = zT_522->alloc;
    zT_525 = 1;
    zT_530 = zF_1395EB68_sandAlloc(zT_519, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)(unsigned int)(vc + zT_525))), (unsigned int)(4));
    zT_531 = zT_530.is_error;
    if (zT_531) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    pal_trap();
    z_bb_111:
    zT_532 = zT_530.data.payload;
    goto z_bb_112;
    z_bb_112:
    scratch_raw4 = zT_532;
    zT_535 = (unsigned int*)scratch_raw4;
    scratch4 = zT_535;
    zT_537 = 0;
    vi4 = zT_537;
    zT_539 = 1;
    ok4 = zT_539;
    goto z_bb_113;
    z_bb_113:
    if ((unsigned char)(vi4 < vc)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_542 = ec->registry;
    zT_543 = zT_542->fe_items;
    zT_544 = (unsigned int)vi4;
    zT_545 = vis[zT_544];
    zT_547 = fs + (unsigned int)((unsigned int)zT_545);
    zT_548 = zT_543[zT_547];
    fe4 = zT_548;
    zT_550 = ec->store;
    zT_551 = node_idx;
    zT_552 = vi4;
    zT_554 = zF_B10B1BC1_astStoreNodeExtraCh(zT_550, zT_551, zT_552);
    cj4 = zT_554;
    zT_555 = ec;
    zT_556 = module_id;
    zT_557 = cj4;
    zT_558 = fe4.type_id;
    zT_563 = zF_BF602E2F_classify(zT_555, zT_556, zT_557, zT_558, (unsigned int)(depth + (unsigned int)(1)));
    zT_564 = zT_563.has_value;
    if (zT_564) goto z_bb_117; else goto z_bb_119;
    z_bb_115:
    if ((unsigned char)(!ok4)) goto z_bb_120; else goto z_bb_121;
    z_bb_116:
    zT_569 = vi4 + (unsigned int)(1);
    vi4 = zT_569;
    goto z_bb_113;
    z_bb_117:
    ch4 = zT_563.value;
    zT_566 = (unsigned int)vi4;
    scratch4[zT_566] = ch4;
    goto z_bb_118;
    z_bb_118:
    goto z_bb_116;
    z_bb_119:
    zT_567 = 0;
    ok4 = zT_567;
    goto z_bb_115;
    z_bb_120:
    zT_571.has_value = 0;
    return zT_571;
    z_bb_121:
    zT_572 = ec->tbl;
    zT_573 = agg4;
    zT_574 = scratch4;
    zT_575 = vc;
    zF_D8E7F449_tableFinishAgg(zT_572, zT_573, zT_574, zT_575);
    zT_577.has_value = 1;
    zT_577.value = agg4;
    return zT_577;
    z_bb_122:
    zT_583 = node.kind;
    if ((unsigned char)(zT_583 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type)))) goto z_bb_149; else goto z_bb_150;
    z_bb_124:
    zT_587.has_value = 0;
    return zT_587;
    z_bb_125:
    zT_589 = ec->registry;
    zT_590 = zT_589->un_items;
    zT_591 = ec->registry;
    zT_592 = zT_591->types_items;
    zT_593 = (unsigned int)type_id;
    zT_594 = zT_592[zT_593];
    zT_595 = zT_594.payload_idx;
    zT_596 = (unsigned int)zT_595;
    zT_597 = zT_590[zT_596];
    up = zT_597;
    zT_599 = up.fields_start;
    zT_600 = (unsigned int)zT_599;
    ufs = zT_600;
    zT_602 = up.fields_count;
    zT_603 = (unsigned int)zT_602;
    ufc = zT_603;
    zT_605 = ec->store;
    zT_606 = node_idx;
    zT_608 = zF_152E19CB_astStoreNodeExtraCh(zT_605, zT_606);
    n5 = zT_608;
    if ((unsigned char)((unsigned int)((unsigned int)n5) != (unsigned int)(1))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_612.has_value = 0;
    return zT_612;
    z_bb_127:
    zT_614 = ec->store;
    zT_615 = node_idx;
    zT_619 = zF_B10B1BC1_astStoreNodeExtraCh(zT_614, zT_615, (unsigned int)(0));
    fi5 = zT_619;
    zT_621 = ec->store;
    zT_622 = fi5;
    zT_624 = zF_8BA26B9E_astStoreNodePayload(zT_621, zT_622);
    fn5 = zT_624;
    zT_626 = (zT_C69B2266_i64)-1;
    ai5 = zT_626;
    zT_628 = 0;
    uj = zT_628;
    goto z_bb_128;
    z_bb_128:
    if ((unsigned char)(uj < ufc)) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_630 = ec->registry;
    zT_631 = zT_630->fe_items;
    zT_632 = ufs + uj;
    zT_633 = zT_631[zT_632];
    zT_634 = zT_633.name_id;
    if ((unsigned char)(zT_634 == fn5)) goto z_bb_132; else goto z_bb_133;
    z_bb_130:
    if ((unsigned char)(ai5 < (zT_C69B2266_i64)(0))) goto z_bb_134; else goto z_bb_135;
    z_bb_131:
    zT_638 = uj + (unsigned int)(1);
    uj = zT_638;
    goto z_bb_128;
    z_bb_132:
    zT_636 = (zT_C69B2266_i64)uj;
    ai5 = zT_636;
    goto z_bb_130;
    z_bb_133:
    goto z_bb_131;
    z_bb_134:
    zT_641.has_value = 0;
    return zT_641;
    z_bb_135:
    zT_643 = (zT_C69B2266_i64)-1;
    first_vis = zT_643;
    zT_645 = 0;
    uj2 = zT_645;
    goto z_bb_136;
    z_bb_136:
    if ((unsigned char)(uj2 < ufc)) goto z_bb_137; else goto z_bb_138;
    z_bb_137:
    zT_647 = ec->registry;
    zT_648 = zT_647->fe_items;
    zT_649 = ufs + uj2;
    zT_650 = zT_648[zT_649];
    zT_651 = zT_650.type_id;
    if ((unsigned char)(zT_651 != (unsigned int)(1))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    if ((unsigned char)(ai5 != first_vis)) goto z_bb_142; else goto z_bb_143;
    z_bb_139:
    zT_656 = uj2 + (unsigned int)(1);
    uj2 = zT_656;
    goto z_bb_136;
    z_bb_140:
    zT_654 = (zT_C69B2266_i64)uj2;
    first_vis = zT_654;
    goto z_bb_138;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_658.has_value = 0;
    return zT_658;
    z_bb_143:
    zT_660 = ec->registry;
    zT_661 = zT_660->fe_items;
    zT_663 = ufs + (unsigned int)((unsigned int)ai5);
    zT_664 = zT_661[zT_663];
    afe = zT_664;
    zT_665 = ec;
    zT_666 = module_id;
    zT_670 = ec->store;
    zT_671 = fi5;
    zT_673 = zF_FCDD1D35_astStoreNodeAt(zT_670, zT_671);
    zT_667 = zT_673.child_0;
    zT_668 = afe.type_id;
    zT_678 = zF_BF602E2F_classify(zT_665, zT_666, zT_667, zT_668, (unsigned int)(depth + (unsigned int)(1)));
    zT_679 = zT_678.has_value;
    if (zT_679) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    ch5 = zT_678.value;
    zT_682 = ec->tbl;
    zT_688 = 8;
    zT_683 = zT_688;
    zT_692 = zF_094E0976_tableAddNode(zT_682, zT_683, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg5 = zT_692;
    zT_697 = ec->tbl;
    zT_694 = zT_697->alloc;
    zT_700 = 2;
    zT_701 = (unsigned int)(4) * zT_700;
    zT_704 = zF_1395EB68_sandAlloc(zT_694, (unsigned int)((unsigned int)zT_701), (unsigned int)(4));
    zT_705 = zT_704.is_error;
    if (zT_705) goto z_bb_146; else goto z_bb_147;
    z_bb_145:
    zT_718.has_value = 0;
    return zT_718;
    z_bb_146:
    pal_trap();
    z_bb_147:
    zT_706 = zT_704.data.payload;
    goto z_bb_148;
    z_bb_148:
    scratch_raw5 = zT_706;
    zT_709 = (unsigned int*)scratch_raw5;
    scratch5 = zT_709;
    zT_710 = 0;
    scratch5[zT_710] = ch5;
    zT_711 = ec->tbl;
    zT_712 = agg5;
    zT_713 = scratch5;
    zF_D8E7F449_tableFinishAgg(zT_711, zT_712, zT_713, (unsigned int)(1));
    zT_717.has_value = 1;
    zT_717.value = agg5;
    return zT_717;
    z_bb_149:
    zT_723 = node.kind;
    if ((unsigned char)(zT_723 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_151; else goto z_bb_152;
    z_bb_150:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type)))) goto z_bb_178; else goto z_bb_179;
    z_bb_151:
    zT_727.has_value = 0;
    return zT_727;
    z_bb_152:
    zT_729 = ec->registry;
    zT_730 = zT_729->tu_items;
    zT_731 = ec->registry;
    zT_732 = zT_731->types_items;
    zT_733 = (unsigned int)type_id;
    zT_734 = zT_732[zT_733];
    zT_735 = zT_734.payload_idx;
    zT_736 = (unsigned int)zT_735;
    zT_737 = zT_730[zT_736];
    tpu = zT_737;
    zT_739 = tpu.fields_start;
    zT_740 = (unsigned int)zT_739;
    tfs = zT_740;
    zT_742 = tpu.fields_count;
    zT_743 = (unsigned int)zT_742;
    tfc = zT_743;
    zT_745 = ec->store;
    zT_746 = node_idx;
    zT_748 = zF_152E19CB_astStoreNodeExtraCh(zT_745, zT_746);
    n6 = zT_748;
    if ((unsigned char)((unsigned int)((unsigned int)n6) != (unsigned int)(1))) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_752.has_value = 0;
    return zT_752;
    z_bb_154:
    zT_754 = ec->store;
    zT_755 = node_idx;
    zT_759 = zF_B10B1BC1_astStoreNodeExtraCh(zT_754, zT_755, (unsigned int)(0));
    fi6 = zT_759;
    zT_761 = ec->store;
    zT_762 = fi6;
    zT_764 = zF_8BA26B9E_astStoreNodePayload(zT_761, zT_762);
    fn6 = zT_764;
    zT_766 = (zT_C69B2266_i64)-1;
    ai6 = zT_766;
    zT_768 = 0;
    tj = zT_768;
    goto z_bb_155;
    z_bb_155:
    if ((unsigned char)(tj < tfc)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_770 = ec->registry;
    zT_771 = zT_770->fe_items;
    zT_772 = tfs + tj;
    zT_773 = zT_771[zT_772];
    zT_774 = zT_773.name_id;
    if ((unsigned char)(zT_774 == fn6)) goto z_bb_159; else goto z_bb_160;
    z_bb_157:
    if ((unsigned char)(ai6 < (zT_C69B2266_i64)(0))) goto z_bb_161; else goto z_bb_162;
    z_bb_158:
    zT_778 = tj + (unsigned int)(1);
    tj = zT_778;
    goto z_bb_155;
    z_bb_159:
    zT_776 = (zT_C69B2266_i64)tj;
    ai6 = zT_776;
    goto z_bb_157;
    z_bb_160:
    goto z_bb_158;
    z_bb_161:
    zT_781.has_value = 0;
    return zT_781;
    z_bb_162:
    zT_783 = ec->registry;
    zT_784 = zT_783->fe_items;
    zT_786 = tfs + (unsigned int)((unsigned int)ai6);
    zT_787 = zT_784[zT_786];
    tfe = zT_787;
    zT_788 = tfe.type_id;
    if ((unsigned char)(zT_788 != (unsigned int)(1))) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    zT_791.has_value = 0;
    return zT_791;
    z_bb_164:
    zT_793 = (zT_79FAE712_u64)ai6;
    tag_val = zT_793;
    zT_795 = ec->registry;
    zT_796 = zT_795->types_items;
    zT_797 = tpu.tag_type;
    zT_798 = (unsigned int)zT_797;
    zT_799 = zT_796[zT_798];
    ttag = zT_799;
    zT_800 = ttag.kind;
    if ((unsigned char)(zT_800 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_805 = ec->registry;
    zT_806 = zT_805->en_items;
    zT_807 = ttag.payload_idx;
    zT_808 = (unsigned int)zT_807;
    zT_809 = zT_806[zT_808];
    ep = zT_809;
    zT_811 = 0;
    found_t = zT_811;
    zT_813 = 0;
    em = zT_813;
    goto z_bb_167;
    z_bb_166:
    zT_835 = ec->tbl;
    zT_841 = 8;
    zT_836 = zT_841;
    zT_845 = zF_094E0976_tableAddNode(zT_835, zT_836, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg6 = zT_845;
    zT_850 = ec->tbl;
    zT_847 = zT_850->alloc;
    zT_853 = 3;
    zT_854 = (unsigned int)(4) * zT_853;
    zT_857 = zF_1395EB68_sandAlloc(zT_847, (unsigned int)((unsigned int)zT_854), (unsigned int)(4));
    zT_858 = zT_857.is_error;
    if (zT_858) goto z_bb_175; else goto z_bb_176;
    z_bb_167:
    zT_814 = ep.members_count;
    if ((unsigned char)(em < zT_814)) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_817 = ec->registry;
    zT_818 = zT_817->em_items;
    zT_819 = ep.members_start;
    zT_822 = (unsigned int)((unsigned int)zT_819) + (unsigned int)((unsigned int)em);
    zT_823 = zT_818[zT_822];
    mem = zT_823;
    zT_824 = mem.name_id;
    if ((unsigned char)(zT_824 == fn6)) goto z_bb_171; else goto z_bb_172;
    z_bb_169:
    if ((unsigned char)(!found_t)) goto z_bb_173; else goto z_bb_174;
    z_bb_170:
    zT_831 = em + (unsigned short)(1);
    em = zT_831;
    goto z_bb_167;
    z_bb_171:
    zT_826 = mem.value;
    zT_828 = (zT_79FAE712_u64)(zT_C69B2266_i64)((zT_C69B2266_i64)zT_826);
    tag_val = zT_828;
    zT_829 = 1;
    found_t = zT_829;
    goto z_bb_169;
    z_bb_172:
    goto z_bb_170;
    z_bb_173:
    zT_833.has_value = 0;
    return zT_833;
    z_bb_174:
    goto z_bb_166;
    z_bb_175:
    pal_trap();
    z_bb_176:
    zT_859 = zT_857.data.payload;
    goto z_bb_177;
    z_bb_177:
    scratch_raw6 = zT_859;
    zT_862 = (unsigned int*)scratch_raw6;
    scratch6 = zT_862;
    zT_863 = ec->tbl;
    zT_869 = 1;
    zT_864 = zT_869;
    zT_865 = tag_val;
    zT_872 = zF_094E0976_tableAddNode(zT_863, zT_864, zT_865, (unsigned int)(0), (unsigned int)(0));
    zT_873 = 0;
    scratch6[zT_873] = zT_872;
    zT_874 = ec->tbl;
    zT_880 = 0;
    zT_875 = zT_880;
    zT_884 = zF_094E0976_tableAddNode(zT_874, zT_875, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_885 = 1;
    scratch6[zT_885] = zT_884;
    zT_886 = ec->tbl;
    zT_887 = agg6;
    zT_888 = scratch6;
    zF_D8E7F449_tableFinishAgg(zT_886, zT_887, zT_888, (unsigned int)(2));
    zT_892.has_value = 1;
    zT_892.value = agg6;
    return zT_892;
    z_bb_178:
    zT_897 = node.kind;
    if ((unsigned char)(zT_897 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_180; else goto z_bb_181;
    z_bb_179:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type)))) goto z_bb_187; else goto z_bb_188;
    z_bb_180:
    zT_901 = ec->tbl;
    zT_907 = 0;
    zT_902 = zT_907;
    zT_911 = zF_094E0976_tableAddNode(zT_901, zT_902, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_912.has_value = 1;
    zT_912.value = zT_911;
    return zT_912;
    z_bb_181:
    zT_914 = ec->registry;
    zT_915 = zT_914->opt_items;
    zT_916 = ec->registry;
    zT_917 = zT_916->types_items;
    zT_918 = (unsigned int)type_id;
    zT_919 = zT_917[zT_918];
    zT_920 = zT_919.payload_idx;
    zT_921 = (unsigned int)zT_920;
    zT_922 = zT_915[zT_921];
    op = zT_922;
    zT_923 = ec;
    zT_924 = module_id;
    zT_925 = node_idx;
    zT_926 = op.payload;
    zT_931 = zF_BF602E2F_classify(zT_923, zT_924, zT_925, zT_926, (unsigned int)(depth + (unsigned int)(1)));
    zT_932 = zT_931.has_value;
    if (zT_932) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    pay = zT_931.value;
    zT_935 = ec->tbl;
    zT_941 = 8;
    zT_936 = zT_941;
    zT_945 = zF_094E0976_tableAddNode(zT_935, zT_936, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg7 = zT_945;
    zT_950 = ec->tbl;
    zT_947 = zT_950->alloc;
    zT_953 = 3;
    zT_954 = (unsigned int)(4) * zT_953;
    zT_957 = zF_1395EB68_sandAlloc(zT_947, (unsigned int)((unsigned int)zT_954), (unsigned int)(4));
    zT_958 = zT_957.is_error;
    if (zT_958) goto z_bb_184; else goto z_bb_185;
    z_bb_183:
    zT_983.has_value = 0;
    return zT_983;
    z_bb_184:
    pal_trap();
    z_bb_185:
    zT_959 = zT_957.data.payload;
    goto z_bb_186;
    z_bb_186:
    scratch_raw7 = zT_959;
    zT_962 = (unsigned int*)scratch_raw7;
    scratch7 = zT_962;
    zT_963 = 0;
    scratch7[zT_963] = pay;
    zT_964 = ec->tbl;
    zT_970 = 1;
    zT_965 = zT_970;
    zT_974 = zF_094E0976_tableAddNode(zT_964, zT_965, (zT_79FAE712_u64)(1), (unsigned int)(0), (unsigned int)(0));
    zT_975 = 1;
    scratch7[zT_975] = zT_974;
    zT_976 = ec->tbl;
    zT_977 = agg7;
    zT_978 = scratch7;
    zF_D8E7F449_tableFinishAgg(zT_976, zT_977, zT_978, (unsigned int)(2));
    zT_982.has_value = 1;
    zT_982.value = agg7;
    return zT_982;
    z_bb_187:
    zT_989 = ec->registry;
    zT_990 = zT_989->eu_items;
    zT_991 = ec->registry;
    zT_992 = zT_991->types_items;
    zT_993 = (unsigned int)type_id;
    zT_994 = zT_992[zT_993];
    zT_995 = zT_994.payload_idx;
    zT_996 = (unsigned int)zT_995;
    zT_997 = zT_990[zT_996];
    ep2 = zT_997;
    zT_999 = ep2.payload;
    pay_ty = zT_999;
    if ((unsigned char)(pay_ty == (unsigned int)(1))) goto z_bb_190; else goto z_bb_189;
    z_bb_188:
    zT_1145.has_value = 0;
    return zT_1145;
    z_bb_189:
    zT_1004 = ec;
    zT_1005 = pay_ty;
    zT_1006 = zF_4E56FBAE_typeKindOf(zT_1004, zT_1005);
    zT_1003 = zT_1006 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type));
    goto z_bb_191;
    z_bb_190:
    zT_1003 = 1;
    goto z_bb_191;
    z_bb_191:
    is_void_pay = zT_1003;
    zT_1011 = node.kind;
    if ((unsigned char)(zT_1011 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    if ((unsigned char)(!is_void_pay)) goto z_bb_194; else goto z_bb_195;
    z_bb_193:
    if (is_void_pay) goto z_bb_201; else goto z_bb_202;
    z_bb_194:
    zT_1016.has_value = 0;
    return zT_1016;
    z_bb_195:
    zT_1017 = ec->enum_values;
    zT_1018 = node_idx;
    zT_1020 = zF_F3EE5998_u32ToU32MapGet(zT_1017, zT_1018);
    zT_1021 = zT_1020.has_value;
    if (zT_1021) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    ev2 = zT_1020.value;
    zT_1024 = ec->tbl;
    zT_1030 = 8;
    zT_1025 = zT_1030;
    zT_1034 = zF_094E0976_tableAddNode(zT_1024, zT_1025, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg8 = zT_1034;
    zT_1039 = ec->tbl;
    zT_1036 = zT_1039->alloc;
    zT_1042 = 3;
    zT_1043 = (unsigned int)(4) * zT_1042;
    zT_1046 = zF_1395EB68_sandAlloc(zT_1036, (unsigned int)((unsigned int)zT_1043), (unsigned int)(4));
    zT_1047 = zT_1046.is_error;
    if (zT_1047) goto z_bb_198; else goto z_bb_199;
    z_bb_197:
    zT_1083.has_value = 0;
    return zT_1083;
    z_bb_198:
    pal_trap();
    z_bb_199:
    zT_1048 = zT_1046.data.payload;
    goto z_bb_200;
    z_bb_200:
    scratch_raw8 = zT_1048;
    zT_1051 = (unsigned int*)scratch_raw8;
    scratch8 = zT_1051;
    zT_1052 = ec->tbl;
    zT_1058 = 1;
    zT_1053 = zT_1058;
    zT_1062 = zF_094E0976_tableAddNode(zT_1052, zT_1053, (zT_79FAE712_u64)((zT_79FAE712_u64)ev2), (unsigned int)(0), (unsigned int)(0));
    zT_1063 = 0;
    scratch8[zT_1063] = zT_1062;
    zT_1064 = ec->tbl;
    zT_1070 = 1;
    zT_1065 = zT_1070;
    zT_1074 = zF_094E0976_tableAddNode(zT_1064, zT_1065, (zT_79FAE712_u64)(1), (unsigned int)(0), (unsigned int)(0));
    zT_1075 = 1;
    scratch8[zT_1075] = zT_1074;
    zT_1076 = ec->tbl;
    zT_1077 = agg8;
    zT_1078 = scratch8;
    zF_D8E7F449_tableFinishAgg(zT_1076, zT_1077, zT_1078, (unsigned int)(2));
    zT_1082.has_value = 1;
    zT_1082.value = agg8;
    return zT_1082;
    z_bb_201:
    zT_1084.has_value = 0;
    return zT_1084;
    z_bb_202:
    zT_1085 = ec;
    zT_1086 = module_id;
    zT_1087 = node_idx;
    zT_1088 = pay_ty;
    zT_1092 = zF_BF602E2F_classify(zT_1085, zT_1086, zT_1087, zT_1088, (unsigned int)(depth + (unsigned int)(1)));
    zT_1093 = zT_1092.has_value;
    if (zT_1093) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    pay2 = zT_1092.value;
    zT_1096 = ec->tbl;
    zT_1102 = 8;
    zT_1097 = zT_1102;
    zT_1106 = zF_094E0976_tableAddNode(zT_1096, zT_1097, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg9 = zT_1106;
    zT_1111 = ec->tbl;
    zT_1108 = zT_1111->alloc;
    zT_1114 = 3;
    zT_1115 = (unsigned int)(4) * zT_1114;
    zT_1118 = zF_1395EB68_sandAlloc(zT_1108, (unsigned int)((unsigned int)zT_1115), (unsigned int)(4));
    zT_1119 = zT_1118.is_error;
    if (zT_1119) goto z_bb_205; else goto z_bb_206;
    z_bb_204:
    zT_1144.has_value = 0;
    return zT_1144;
    z_bb_205:
    pal_trap();
    z_bb_206:
    zT_1120 = zT_1118.data.payload;
    goto z_bb_207;
    z_bb_207:
    scratch_raw9 = zT_1120;
    zT_1123 = (unsigned int*)scratch_raw9;
    scratch9 = zT_1123;
    zT_1124 = 0;
    scratch9[zT_1124] = pay2;
    zT_1125 = ec->tbl;
    zT_1131 = 1;
    zT_1126 = zT_1131;
    zT_1135 = zF_094E0976_tableAddNode(zT_1125, zT_1126, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_1136 = 1;
    scratch9[zT_1136] = zT_1135;
    zT_1137 = ec->tbl;
    zT_1138 = agg9;
    zT_1139 = scratch9;
    zF_D8E7F449_tableFinishAgg(zT_1137, zT_1138, zT_1139, (unsigned int)(2));
    zT_1143.has_value = 1;
    zT_1143.value = agg9;
    return zT_1143;
}

/* classify */
zT_BAEE192E_Opt_10 zF_BF602E2F_classify(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_7 = {0};
    zT_BAEE192E_Opt_10 zT_10 = {0};
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_17;
    unsigned int zT_18;
    unsigned int zT_19 = 0;
    zT_8143F551_AstKind zT_20;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_29;
    unsigned char zT_34;
    unsigned char zT_39;
    unsigned char zT_44;
    unsigned char zT_49;
    unsigned char zT_54;
    zT_8143F551_AstKind zT_59;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_E834303C_ArrayPayload* zT_70;
    zT_338B7C76_TypeRegistry* zT_71;
    zT_D155D06D_Type* zT_72;
    unsigned int zT_73;
    zT_D155D06D_Type zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_E834303C_ArrayPayload zT_77;
    zT_4D150975_ConstInitEvalCtx* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    zT_6B0A7D14_AstStore* zT_83;
    zT_5138F1F5_anon_324000 zT_84;
    unsigned int* zT_85;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_4065182A_ConstInitTable* zT_92;
    unsigned char zT_93;
    unsigned int zT_98;
    unsigned int zT_102 = 0;
    zT_BAEE192E_Opt_10 zT_103;
    zT_BAEE192E_Opt_10 zT_104 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_BAEE192E_Opt_10 zT_110 = {0};
    unsigned char zT_115;
    zT_8143F551_AstKind zT_120;
    zT_4065182A_ConstInitTable* zT_124;
    unsigned char zT_125;
    unsigned int zT_130;
    unsigned int zT_134 = 0;
    zT_BAEE192E_Opt_10 zT_135;
    zT_8143F551_AstKind zT_136;
    zT_6B0A7D14_AstStore* zT_141;
    zT_5138F1F5_anon_324000 zT_142;
    unsigned int* zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    unsigned int zT_147 = 0;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_4065182A_ConstInitTable* zT_150;
    unsigned char zT_151;
    unsigned int zT_156;
    unsigned int zT_160 = 0;
    zT_BAEE192E_Opt_10 zT_161;
    zT_8143F551_AstKind zT_162;
    zT_4D150975_ConstInitEvalCtx* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_BAEE192E_Opt_10 zT_171 = {0};
    zT_8143F551_AstKind zT_172;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    unsigned int zT_180 = 0;
    zT_3D7259E2_SymbolRegistry* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_77F031D4_Opt_960 zT_185 = {0};
    unsigned char zT_186;
    zT_3C598AEF_SymbolKind zT_188;
    zT_4065182A_ConstInitTable* zT_192;
    unsigned char zT_193;
    unsigned int zT_195;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_203 = 0;
    zT_BAEE192E_Opt_10 zT_204;
    zT_3C598AEF_SymbolKind zT_205;
    unsigned int zT_210;
    zT_8EED1867_ResolvedTypeTable* zT_211;
    unsigned int zT_212;
    zT_BAEE192E_Opt_10 zT_215 = {0};
    unsigned char zT_216;
    zT_4D150975_ConstInitEvalCtx* zT_218;
    unsigned int zT_219;
    unsigned int zT_220 = 0;
    zT_4065182A_ConstInitTable* zT_225;
    unsigned char zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_235 = 0;
    zT_BAEE192E_Opt_10 zT_236;
    zT_4D150975_ConstInitEvalCtx* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    zT_BAEE192E_Opt_10 zT_243 = {0};
    zT_BAEE192E_Opt_10 zT_244 = {0};
    zT_BAEE192E_Opt_10 zT_245 = {0};
    zT_8143F551_AstKind zT_250;
    zT_6B0A7D14_AstStore* zT_255;
    zT_5138F1F5_anon_324000 zT_256;
    unsigned int* zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_261 = 0;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_4065182A_ConstInitTable* zT_264;
    unsigned char zT_265;
    unsigned int zT_270;
    unsigned int zT_274 = 0;
    zT_BAEE192E_Opt_10 zT_275;
    zT_8143F551_AstKind zT_276;
    zT_6B0A7D14_AstStore* zT_281;
    unsigned int zT_282;
    unsigned int zT_284 = 0;
    zT_3D7259E2_SymbolRegistry* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    zT_77F031D4_Opt_960 zT_289 = {0};
    unsigned char zT_290;
    zT_3C598AEF_SymbolKind zT_292;
    unsigned int zT_297;
    zT_8EED1867_ResolvedTypeTable* zT_298;
    unsigned int zT_299;
    zT_BAEE192E_Opt_10 zT_302 = {0};
    unsigned char zT_303;
    zT_4D150975_ConstInitEvalCtx* zT_305;
    unsigned int zT_306;
    unsigned int zT_307 = 0;
    zT_4065182A_ConstInitTable* zT_312;
    unsigned char zT_313;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_322 = 0;
    zT_BAEE192E_Opt_10 zT_323;
    zT_4D150975_ConstInitEvalCtx* zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_BAEE192E_Opt_10 zT_330 = {0};
    zT_BAEE192E_Opt_10 zT_331 = {0};
    zT_8143F551_AstKind zT_332;
    zT_4D150975_ConstInitEvalCtx* zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    zT_BAEE192E_Opt_10 zT_341 = {0};
    zT_BAEE192E_Opt_10 zT_342 = {0};
    unsigned char zT_347;
    zT_8143F551_AstKind zT_352;
    zT_6B0A7D14_AstStore* zT_357;
    zT_E494E487_anon_323991 zT_358;
    zT_00435AEB_f64* zT_359;
    zT_6B0A7D14_AstStore* zT_360;
    unsigned int zT_361;
    unsigned int zT_363 = 0;
    unsigned int zT_364;
    zT_00435AEB_f64 zT_365;
    zT_00435AEB_f64* zT_367;
    zT_79FAE712_u64* zT_368;
    zT_4065182A_ConstInitTable* zT_369;
    unsigned char zT_370;
    zT_79FAE712_u64 zT_371;
    unsigned int zT_375;
    unsigned int zT_379 = 0;
    zT_BAEE192E_Opt_10 zT_380;
    zT_BAEE192E_Opt_10 zT_381 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_BAEE192E_Opt_10 zT_391 = {0};
    zT_4D150975_ConstInitEvalCtx* zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_BAEE192E_Opt_10 zT_397 = {0};
    zT_22A7C88B_AstNode node;
    unsigned int tk;
    zT_E834303C_ArrayPayload ap;
    unsigned int sid;
    unsigned int sid2;
    unsigned int name_id2;
    zT_3A105EF1_Symbol* s3;
    unsigned int gtid3;
    unsigned int gt3;
    unsigned int sid3;
    unsigned int name_id3;
    zT_3A105EF1_Symbol* s4;
    unsigned int gtid4;
    unsigned int gt4;
    zT_00435AEB_f64 fb;
    zT_79FAE712_u64* fbp;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_4:
    zT_12 = ec->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    node = zT_15;
    zT_17 = ec;
    zT_18 = type_id;
    zT_19 = zF_4E56FBAE_typeKindOf(zT_17, zT_18);
    tk = zT_19;
    zT_20 = node.kind;
    if ((unsigned char)(zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_24.has_value = 0;
    return zT_24;
    z_bb_6:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type)))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_29 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type));
    goto z_bb_9;
    z_bb_8:
    zT_29 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_29) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_34 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type));
    goto z_bb_12;
    z_bb_11:
    zT_34 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_34) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_39 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type));
    goto z_bb_15;
    z_bb_14:
    zT_39 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_39) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_44 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type));
    goto z_bb_18;
    z_bb_17:
    zT_44 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_44) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_49 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type));
    goto z_bb_21;
    z_bb_20:
    zT_49 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_49) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_54 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type));
    goto z_bb_24;
    z_bb_23:
    zT_54 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_54) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_59 = node.kind;
    if ((unsigned char)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type)))) goto z_bb_35; else goto z_bb_34;
    z_bb_27:
    zT_63 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type));
    goto z_bb_29;
    z_bb_28:
    zT_63 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_63) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_69 = ec->registry;
    zT_70 = zT_69->array_items;
    zT_71 = ec->registry;
    zT_72 = zT_71->types_items;
    zT_73 = (unsigned int)type_id;
    zT_74 = zT_72[zT_73];
    zT_75 = zT_74.payload_idx;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zT_70[zT_76];
    ap = zT_77;
    zT_78 = ec;
    zT_79 = ap.elem;
    zT_81 = zF_092A96D8_isU8ish(zT_78, zT_79);
    if (zT_81) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_105 = ec;
    zT_106 = module_id;
    zT_107 = node_idx;
    zT_108 = type_id;
    zT_109 = depth;
    zT_110 = zF_F7CF67F0_classifyAgg(zT_105, zT_106, zT_107, zT_108, zT_109);
    return zT_110;
    z_bb_32:
    zT_83 = ec->store;
    zT_84 = zT_83->string_values;
    zT_85 = zT_84.items;
    zT_86 = ec->store;
    zT_87 = node_idx;
    zT_89 = zF_8BA26B9E_astStoreNodePayload(zT_86, zT_87);
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_85[zT_90];
    sid = zT_91;
    zT_92 = ec->tbl;
    zT_98 = 5;
    zT_93 = zT_98;
    zT_102 = zF_094E0976_tableAddNode(zT_92, zT_93, (zT_79FAE712_u64)((zT_79FAE712_u64)sid), (unsigned int)(0), (unsigned int)(0));
    zT_103.has_value = 1;
    zT_103.value = zT_102;
    return zT_103;
    z_bb_33:
    zT_104.has_value = 0;
    return zT_104;
    z_bb_34:
    zT_115 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type));
    goto z_bb_36;
    z_bb_35:
    zT_115 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_115) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_120 = node.kind;
    if ((unsigned char)(zT_120 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type)))) goto z_bb_57; else goto z_bb_58;
    z_bb_39:
    zT_124 = ec->tbl;
    zT_130 = 0;
    zT_125 = zT_130;
    zT_134 = zF_094E0976_tableAddNode(zT_124, zT_125, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_135.has_value = 1;
    zT_135.value = zT_134;
    return zT_135;
    z_bb_40:
    zT_136 = node.kind;
    if ((unsigned char)(zT_136 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_141 = ec->store;
    zT_142 = zT_141->string_values;
    zT_143 = zT_142.items;
    zT_144 = ec->store;
    zT_145 = node_idx;
    zT_147 = zF_8BA26B9E_astStoreNodePayload(zT_144, zT_145);
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_143[zT_148];
    sid2 = zT_149;
    zT_150 = ec->tbl;
    zT_156 = 5;
    zT_151 = zT_156;
    zT_160 = zF_094E0976_tableAddNode(zT_150, zT_151, (zT_79FAE712_u64)((zT_79FAE712_u64)sid2), (unsigned int)(0), (unsigned int)(0));
    zT_161.has_value = 1;
    zT_161.value = zT_160;
    return zT_161;
    z_bb_42:
    zT_162 = node.kind;
    if ((unsigned char)(zT_162 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_166 = ec;
    zT_167 = module_id;
    zT_168 = node.child_0;
    zT_169 = depth;
    zT_171 = zF_19E37948_classifyAddr(zT_166, zT_167, zT_168, zT_169);
    return zT_171;
    z_bb_44:
    zT_172 = node.kind;
    if ((unsigned char)(zT_172 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_177 = ec->store;
    zT_178 = node_idx;
    zT_180 = zF_53458827_astStoreIdentifier(zT_177, zT_178);
    name_id2 = zT_180;
    zT_181 = ec->symbol_reg;
    zT_182 = module_id;
    zT_183 = name_id2;
    zT_185 = zF_A398987E_symbolRegistryQuali(zT_181, zT_182, zT_183);
    zT_186 = zT_185.has_value;
    if (zT_186) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_245.has_value = 0;
    return zT_245;
    z_bb_47:
    s3 = zT_185.value;
    zT_188 = s3->kind;
    if ((unsigned char)(zT_188 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_244.has_value = 0;
    return zT_244;
    z_bb_49:
    zT_192 = ec->tbl;
    zT_198 = 7;
    zT_193 = zT_198;
    zT_199 = s3->name_id;
    zT_195 = s3->module_id;
    zT_203 = zF_094E0976_tableAddNode(zT_192, zT_193, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_199), zT_195, (unsigned int)(0));
    zT_204.has_value = 1;
    zT_204.value = zT_203;
    return zT_204;
    z_bb_50:
    zT_205 = s3->kind;
    if ((unsigned char)(zT_205 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_210 = s3->type_id;
    gtid3 = zT_210;
    zT_211 = ec->resolved;
    zT_212 = s3->decl_node;
    zT_215 = zF_999DCF51_resolvedTypeTableGe(zT_211, zT_212);
    zT_216 = zT_215.has_value;
    if (zT_216) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_48;
    z_bb_53:
    gt3 = zT_215.value;
    gtid3 = gt3;
    goto z_bb_54;
    z_bb_54:
    zT_218 = ec;
    zT_219 = gtid3;
    zT_220 = zF_4E56FBAE_typeKindOf(zT_218, zT_219);
    if ((unsigned char)(zT_220 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_225 = ec->tbl;
    zT_231 = 6;
    zT_226 = zT_231;
    zT_232 = s3->name_id;
    zT_228 = s3->module_id;
    zT_229 = gtid3;
    zT_235 = zF_094E0976_tableAddNode(zT_225, zT_226, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_232), zT_228, zT_229);
    zT_236.has_value = 1;
    zT_236.value = zT_235;
    return zT_236;
    z_bb_56:
    zT_237 = ec;
    zT_238 = s3->module_id;
    zT_239 = s3->decl_node;
    zT_240 = depth;
    zT_243 = zF_07765C6B_valueCopyDecl(zT_237, zT_238, zT_239, zT_240);
    return zT_243;
    z_bb_57:
    zT_250 = node.kind;
    if ((unsigned char)(zT_250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type)))) goto z_bb_74; else goto z_bb_73;
    z_bb_59:
    zT_255 = ec->store;
    zT_256 = zT_255->string_values;
    zT_257 = zT_256.items;
    zT_258 = ec->store;
    zT_259 = node_idx;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_258, zT_259);
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_257[zT_262];
    sid3 = zT_263;
    zT_264 = ec->tbl;
    zT_270 = 5;
    zT_265 = zT_270;
    zT_274 = zF_094E0976_tableAddNode(zT_264, zT_265, (zT_79FAE712_u64)((zT_79FAE712_u64)sid3), (unsigned int)(0), (unsigned int)(0));
    zT_275.has_value = 1;
    zT_275.value = zT_274;
    return zT_275;
    z_bb_60:
    zT_276 = node.kind;
    if ((unsigned char)(zT_276 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_281 = ec->store;
    zT_282 = node_idx;
    zT_284 = zF_53458827_astStoreIdentifier(zT_281, zT_282);
    name_id3 = zT_284;
    zT_285 = ec->symbol_reg;
    zT_286 = module_id;
    zT_287 = name_id3;
    zT_289 = zF_A398987E_symbolRegistryQuali(zT_285, zT_286, zT_287);
    zT_290 = zT_289.has_value;
    if (zT_290) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_332 = node.kind;
    if ((unsigned char)(zT_332 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_71; else goto z_bb_72;
    z_bb_63:
    s4 = zT_289.value;
    zT_292 = s4->kind;
    if ((unsigned char)(zT_292 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_331.has_value = 0;
    return zT_331;
    z_bb_65:
    zT_297 = s4->type_id;
    gtid4 = zT_297;
    zT_298 = ec->resolved;
    zT_299 = s4->decl_node;
    zT_302 = zF_999DCF51_resolvedTypeTableGe(zT_298, zT_299);
    zT_303 = zT_302.has_value;
    if (zT_303) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    gt4 = zT_302.value;
    gtid4 = gt4;
    goto z_bb_68;
    z_bb_68:
    zT_305 = ec;
    zT_306 = gtid4;
    zT_307 = zF_4E56FBAE_typeKindOf(zT_305, zT_306);
    if ((unsigned char)(zT_307 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_312 = ec->tbl;
    zT_318 = 6;
    zT_313 = zT_318;
    zT_319 = s4->name_id;
    zT_315 = s4->module_id;
    zT_316 = gtid4;
    zT_322 = zF_094E0976_tableAddNode(zT_312, zT_313, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_319), zT_315, zT_316);
    zT_323.has_value = 1;
    zT_323.value = zT_322;
    return zT_323;
    z_bb_70:
    zT_324 = ec;
    zT_325 = s4->module_id;
    zT_326 = s4->decl_node;
    zT_327 = depth;
    zT_330 = zF_07765C6B_valueCopyDecl(zT_324, zT_325, zT_326, zT_327);
    return zT_330;
    z_bb_71:
    zT_336 = ec;
    zT_337 = module_id;
    zT_338 = node.child_0;
    zT_339 = depth;
    zT_341 = zF_19E37948_classifyAddr(zT_336, zT_337, zT_338, zT_339);
    return zT_341;
    z_bb_72:
    zT_342.has_value = 0;
    return zT_342;
    z_bb_73:
    zT_347 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type));
    goto z_bb_75;
    z_bb_74:
    zT_347 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_347) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_352 = node.kind;
    if ((unsigned char)(zT_352 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type)))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    zT_357 = ec->store;
    zT_358 = zT_357->float_values;
    zT_359 = zT_358.items;
    zT_360 = ec->store;
    zT_361 = node_idx;
    zT_363 = zF_8BA26B9E_astStoreNodePayload(zT_360, zT_361);
    zT_364 = (unsigned int)zT_363;
    zT_365 = zT_359[zT_364];
    fb = zT_365;
    zT_367 = (zT_00435AEB_f64*)&fb;
    zT_368 = (zT_79FAE712_u64*)zT_367;
    fbp = zT_368;
    zT_369 = ec->tbl;
    zT_375 = 2;
    zT_370 = zT_375;
    zT_371 = *fbp;
    zT_379 = zF_094E0976_tableAddNode(zT_369, zT_370, zT_371, (unsigned int)(0), (unsigned int)(0));
    zT_380.has_value = 1;
    zT_380.value = zT_379;
    return zT_380;
    z_bb_79:
    zT_381.has_value = 0;
    return zT_381;
    z_bb_80:
    zT_386 = ec;
    zT_387 = module_id;
    zT_388 = node_idx;
    zT_389 = type_id;
    zT_390 = depth;
    zT_391 = zF_83AC95E3_classifyScalar(zT_386, zT_387, zT_388, zT_389, zT_390);
    return zT_391;
    z_bb_81:
    zT_392 = ec;
    zT_393 = module_id;
    zT_394 = node_idx;
    zT_395 = type_id;
    zT_396 = depth;
    zT_397 = zF_83AC95E3_classifyScalar(zT_392, zT_393, zT_394, zT_395, zT_396);
    return zT_397;
}

/* EOF */
