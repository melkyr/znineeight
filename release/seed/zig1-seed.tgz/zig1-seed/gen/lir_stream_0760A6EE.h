#ifndef ZIG_MODULE_LIR_STREAM_0760A6EE_H
#define ZIG_MODULE_LIR_STREAM_0760A6EE_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "lir_64CB5435.h"
#include "allocator_E75B7A0B.h"
#include "hash_02AFCD13.h"
#include "panic_CE239B25.h"
#include "spill_store_AC8E76BA.h"


/* Forward declarations */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void);
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream*);
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream*, zT_3E40CD83_Sand*);
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream*);
void zF_FB050204_wU32(zT_7E7544E4_LirStream*, unsigned int);
void zF_56013A33_wU8(zT_7E7544E4_LirStream*, unsigned char);
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream*, unsigned char*, unsigned int);
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream*);
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream*);
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream*, unsigned char*, unsigned int);
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream*, zT_BBC23664_LirFunction);
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand*);
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream*, zT_E7714190_LirSlot, zT_3E40CD83_Sand*);
void zF_780653D2___module_init_14(void);
/* Storage globals (extern decls) */
extern unsigned char* zG_4417A8F5_READ_MODE;
extern unsigned char* zG_82B6E276_WRITE_MODE;

#endif /* ZIG_MODULE_LIR_STREAM_0760A6EE_H */
