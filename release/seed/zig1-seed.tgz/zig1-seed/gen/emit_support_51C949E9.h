#ifndef ZIG_MODULE_EMIT_SUPPORT_51C949E9_H
#define ZIG_MODULE_EMIT_SUPPORT_51C949E9_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "c89_emit_7CEF756E.h"


/* Forward declarations */
void zF_FFF31281_emitZigCompatHSuppo(zT_63BE4FF5_BufferedWriter*);
void zF_BF8BD489_emitNetPreludeHSupp(zT_63BE4FF5_BufferedWriter*);
void zF_3D335A79_emitStdOsPreludeHSu(zT_63BE4FF5_BufferedWriter*);
void zF_B6297F8C_emitStdTimePreludeH(zT_63BE4FF5_BufferedWriter*);
void zF_76601FCF_emitCExitCSupport(zT_63BE4FF5_BufferedWriter*);
void zF_2A56F787_emitZigRuntimeHSupp(zT_63BE4FF5_BufferedWriter*, unsigned char);
void zF_0620B2A4_emitZigRuntimeCSupp(zT_63BE4FF5_BufferedWriter*, unsigned char);
void zF_EAB0AAF5_emitZigPalCSupport(zT_63BE4FF5_BufferedWriter*);
void zF_780653D2___module_init_27(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_EMIT_SUPPORT_51C949E9_H */
