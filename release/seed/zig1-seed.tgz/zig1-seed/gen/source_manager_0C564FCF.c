#include "source_manager_0C564FCF.h"
zT_227EDE07_SourceManager zG_227EDE07_SourceManager;
/* sourceFileArrayListInit */
zT_6B45117F_SourceFileArrayList zF_EB529E39_sourceFileArrayList(zT_3E40CD83_Sand* allocator) {
    zT_6B45117F_SourceFileArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_ED18556E_SourceFile*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* sourceFileArrayListEnsureCapacity */
void zF_9E523C79_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_ED18556E_SourceFile* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_E637E89E_Opt_218 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_171165BB_EU_812 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_ED18556E_SourceFile* zT_49;
    zT_ED18556E_SourceFile* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_ED18556E_SourceFile* zT_53;
    unsigned int zT_54;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_55;
    zT_ED18556E_SourceFile* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_E637E89E_Opt_218 grown;
    unsigned char* raw;
    zT_ED18556E_SourceFile* new_items;
    zT_ED18556E_SourceFile item;
    unsigned int i;
    zT_2 = self->capacity;
    zT_3 = new_capacity <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    new_cap = new_capacity;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = new_cap < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = new_cap < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->allocator;
    zT_20 = zT_25;
    zT_26 = self->items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->capacity;
    zT_29 = 20;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 20;
    zT_32 = new_cap * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->allocator;
    zT_37 = zT_40;
    zT_41 = 20;
    zT_42 = zT_41 * new_cap;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_ED18556E_SourceFile*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* sourceFileArrayListAppend */
void zF_5368F9F7_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, zT_ED18556E_SourceFile value) {
    zT_6B45117F_SourceFileArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_ED18556E_SourceFile* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zT_4 + zT_5;
    zT_3 = zT_6;
    zF_9E523C79_sourceFileArrayList(zT_2, zT_3);
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9 + zT_11;
    self->len = zT_12;
    return;
}

/* sourceFileArrayListGetSlice */
zT_1D6CA09C_Slice_zT_ED18556E_S zF_276A1E3D_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self) {
    zT_ED18556E_SourceFile* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_ED18556E_SourceFile* zT_4;
    unsigned int zT_5;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* sourceManagerInit */
zT_227EDE07_SourceManager zF_01351F51_sourceManagerInit(zT_3E40CD83_Sand* allocator) {
    zT_3E40CD83_Sand* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_171165BB_EU_812 zT_7 = {0};
    unsigned char zT_8;
    unsigned char* zT_9;
    unsigned char* zT_10;
    zT_6B45117F_SourceFileArrayList* zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_6B45117F_SourceFileArrayList zT_14 = {0};
    zT_227EDE07_SourceManager zT_15;
    unsigned char* f_raw;
    zT_6B45117F_SourceFileArrayList* f_ptr;
    zT_2 = allocator;
    zT_5 = 16;
    zT_3 = zT_5;
    zT_6 = 4;
    zT_4 = zT_6;
    zT_7 = zF_1395EB68_sandAlloc(zT_2, zT_3, zT_4);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_10 = zT_7.data.payload;
    zT_9 = zT_10;
    goto z_bb_3;
    z_bb_3:
    f_raw = zT_9;
    f_raw = zT_9;
    f_raw = zT_9;
    zT_12 = (zT_6B45117F_SourceFileArrayList*)f_raw;
    f_ptr = zT_12;
    f_ptr = zT_12;
    f_ptr = zT_12;
    zT_13 = allocator;
    zT_14 = zF_EB529E39_sourceFileArrayList(zT_13);
    *f_ptr = zT_14;
    zT_15.files = f_ptr;
    zT_15.allocator = allocator;
    return zT_15;
}

/* sourceManagerAddFile */
unsigned int zF_3A49F0F4_sourceManagerAddFil(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u filename, zT_8F083A69_Slice_zT_0B42B2F8_u content) {
    zT_227EDE07_SourceManager* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6 = 0;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned char zT_21;
    int zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_29;
    unsigned int zT_30;
    int zT_31;
    int zT_32;
    int zT_33;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_3E40CD83_Sand* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_171165BB_EU_812 zT_42 = {0};
    unsigned char zT_43;
    unsigned char* zT_44;
    unsigned char* zT_45;
    zT_B687BB96_U32ArrayList* zT_47;
    zT_3E40CD83_Sand* zT_48;
    zT_3E40CD83_Sand* zT_49;
    zT_B687BB96_U32ArrayList zT_50 = {0};
    zT_B687BB96_U32ArrayList* zT_51;
    unsigned int zT_52;
    zT_B687BB96_U32ArrayList* zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    int zT_60;
    unsigned char zT_62;
    int zT_63;
    zT_B687BB96_U32ArrayList* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_6B45117F_SourceFileArrayList* zT_71;
    zT_ED18556E_SourceFile zT_72;
    zT_6B45117F_SourceFileArrayList* zT_73;
    zT_ED18556E_SourceFile zT_74;
    zT_6B45117F_SourceFileArrayList* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char* fname_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname_copy;
    unsigned int line_count;
    unsigned char c;
    unsigned int cap;
    unsigned char* lo_raw;
    zT_B687BB96_U32ArrayList* lo_ptr;
    unsigned char c_1;
    unsigned int i;
    zT_4 = self;
    zT_5 = filename;
    zT_6 = zF_B158E4F2_sourceManagerCopyTo(zT_4, zT_5);
    fname_raw = zT_6;
    fname_raw = zT_6;
    fname_raw = zT_6;
    zT_9 = filename.len;
    zT_10 = 0;
    zT_11 = fname_raw + zT_10;
    zT_12 = zT_9 - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    fname_copy = zT_13;
    fname_copy = zT_13;
    fname_copy = zT_13;
    zT_15 = 0;
    line_count = zT_15;
    line_count = zT_15;
    line_count = zT_15;
    zT_16 = content.ptr;
    zT_17 = content.len;
    zT_18 = 0;
    goto z_bb_1;
    z_bb_1:
    zT_19 = zT_18 < zT_17;
    if (zT_19) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    c = zT_16[zT_18];
    zT_21 = 10;
    zT_22 = c == zT_21;
    if (zT_22) goto z_bb_4; else goto z_bb_5;
    z_bb_3:
    zT_29 = 1;
    zT_30 = line_count + zT_29;
    cap = zT_30;
    cap = zT_30;
    cap = zT_30;
    zT_31 = 64;
    zT_32 = cap < (unsigned int)zT_31;
    if (zT_32) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    zT_23 = 1;
    zT_24 = (unsigned int)zT_23;
    zT_25 = line_count + zT_24;
    line_count = zT_25;
    line_count = zT_25;
    goto z_bb_5;
    z_bb_5:
    zT_26 = 1;
    zT_27 = zT_18 + zT_26;
    zT_18 = zT_27;
    goto z_bb_1;
    z_bb_6:
    zT_33 = 64;
    zT_34 = (unsigned int)zT_33;
    cap = zT_34;
    cap = zT_34;
    goto z_bb_7;
    z_bb_7:
    zT_39 = self->allocator;
    zT_36 = zT_39;
    zT_40 = 16;
    zT_37 = zT_40;
    zT_41 = 4;
    zT_38 = zT_41;
    zT_42 = zF_1395EB68_sandAlloc(zT_36, zT_37, zT_38);
    zT_43 = zT_42.is_error;
    if (zT_43) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    z_bb_9:
    zT_45 = zT_42.data.payload;
    zT_44 = zT_45;
    goto z_bb_10;
    z_bb_10:
    lo_raw = zT_44;
    lo_raw = zT_44;
    lo_raw = zT_44;
    zT_47 = (zT_B687BB96_U32ArrayList*)lo_raw;
    lo_ptr = zT_47;
    lo_ptr = zT_47;
    lo_ptr = zT_47;
    zT_49 = self->allocator;
    zT_48 = zT_49;
    zT_50 = zF_8E537D0C_u32ArrayListInit(zT_48);
    *lo_ptr = zT_50;
    zT_51 = lo_ptr;
    zT_52 = cap;
    zF_1580F084_u32ArrayListEnsureC(zT_51, zT_52);
    zT_53 = lo_ptr;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    zT_54 = zT_56;
    zF_62F717A2_u32ArrayListAppend(zT_53, zT_54);
    zT_57 = content.ptr;
    zT_58 = content.len;
    i = 0;
    goto z_bb_11;
    z_bb_11:
    zT_60 = i < zT_58;
    if (zT_60) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    c_1 = zT_57[i];
    zT_62 = 10;
    zT_63 = c_1 == zT_62;
    if (zT_63) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_73 = self->files;
    zT_71 = zT_73;
    zT_74.filename = fname_copy;
    zT_74.content = content;
    zT_74.line_offsets = lo_ptr;
    zT_72 = zT_74;
    zF_5368F9F7_sourceFileArrayList(zT_71, zT_72);
    zT_75 = self->files;
    zT_76 = zT_75->len;
    zT_77 = (unsigned int)zT_76;
    return zT_77;
    z_bb_14:
    zT_64 = lo_ptr;
    zT_66 = (unsigned int)i;
    zT_67 = 1;
    zT_68 = zT_66 + zT_67;
    zT_65 = zT_68;
    zF_62F717A2_u32ArrayListAppend(zT_64, zT_65);
    goto z_bb_15;
    z_bb_15:
    zT_69 = 1;
    zT_70 = i + zT_69;
    i = zT_70;
    goto z_bb_11;
}

/* sourceManagerGetFileName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7076474_sourceManagerGetFil(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned int zT_2;
    int zT_3;
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_6B45117F_SourceFileArrayList* zT_10;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11 = {0};
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    zT_ED18556E_SourceFile* zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_ED18556E_SourceFile zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_2 = 0;
    zT_3 = file_id == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    dummy = zT_6;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_10 = self->files;
    zT_9 = zT_10;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    files_slice = zT_11;
    files_slice = zT_11;
    zT_13 = files_slice.len;
    zT_14 = 0;
    zT_15 = zT_13 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    dummy = zT_18;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    fid = file_id;
    fid = file_id;
    zT_22 = files_slice.len;
    zT_23 = (unsigned int)zT_22;
    zT_24 = fid > zT_23;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = files_slice.ptr;
    zT_27 = 1;
    zT_28 = fid - zT_27;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_26[zT_29];
    zT_31 = zT_30.filename;
    return zT_31;
}

/* sourceManagerGetSourceContent */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_FFE72B39_sourceManagerGetSou(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned int zT_2;
    int zT_3;
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_6B45117F_SourceFileArrayList* zT_10;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11 = {0};
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    zT_ED18556E_SourceFile* zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_ED18556E_SourceFile zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_2 = 0;
    zT_3 = file_id == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    dummy = zT_6;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_10 = self->files;
    zT_9 = zT_10;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    files_slice = zT_11;
    files_slice = zT_11;
    zT_13 = files_slice.len;
    zT_14 = 0;
    zT_15 = zT_13 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    dummy = zT_18;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    fid = file_id;
    fid = file_id;
    zT_22 = files_slice.len;
    zT_23 = (unsigned int)zT_22;
    zT_24 = fid > zT_23;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = files_slice.ptr;
    zT_27 = 1;
    zT_28 = fid - zT_27;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_26[zT_29];
    zT_31 = zT_30.content;
    return zT_31;
}

/* sourceManagerGetLineOffsets */
zT_3CB0179A_Slice_zT_05F374B1_u zF_5041A561_sourceManagerGetLin(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned int zT_2;
    int zT_3;
    zT_949EEA93_Arr_unsigned_int_0 zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_11;
    zT_6B45117F_SourceFileArrayList* zT_13;
    zT_6B45117F_SourceFileArrayList* zT_14;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_15 = {0};
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    zT_949EEA93_Arr_unsigned_int_0 zT_21;
    unsigned int* zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int* zT_25;
    unsigned int zT_26;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27;
    unsigned int zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned int zT_33;
    zT_B687BB96_U32ArrayList* zT_34;
    zT_ED18556E_SourceFile* zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_ED18556E_SourceFile zT_39;
    zT_B687BB96_U32ArrayList* zT_40;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_41 = {0};
    zT_949EEA93_Arr_unsigned_int_0 dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_2 = 0;
    zT_3 = file_id == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    int _i = 0;
    while (_i < 0) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_5[_i];
        _i++;
    }
}
    zT_6 = (unsigned int*)dummy;
    zT_7 = 0;
    zT_8 = 0;
    zT_9 = zT_6 + zT_8;
    zT_10 = zT_7 - zT_8;
    zT_11.ptr = zT_9;
    zT_11.len = zT_10;
    return zT_11;
    z_bb_2:
    zT_14 = self->files;
    zT_13 = zT_14;
    zT_15 = zF_276A1E3D_sourceFileArrayList(zT_13);
    files_slice = zT_15;
    files_slice = zT_15;
    files_slice = zT_15;
    zT_17 = files_slice.len;
    zT_18 = 0;
    zT_19 = zT_17 == zT_18;
    if (zT_19) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    {
    int _i = 0;
    while (_i < 0) {
        zT_21[_i] = 0;
        _i++;
    }
}
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_21[_i];
        _i++;
    }
}
    zT_22 = (unsigned int*)dummy;
    zT_23 = 0;
    zT_24 = 0;
    zT_25 = zT_22 + zT_24;
    zT_26 = zT_23 - zT_24;
    zT_27.ptr = zT_25;
    zT_27.len = zT_26;
    return zT_27;
    z_bb_4:
    fid = file_id;
    fid = file_id;
    fid = file_id;
    zT_30 = files_slice.len;
    zT_31 = (unsigned int)zT_30;
    zT_32 = fid > zT_31;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_33 = 1;
    fid = zT_33;
    fid = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_35 = files_slice.ptr;
    zT_36 = 1;
    zT_37 = fid - zT_36;
    zT_38 = (unsigned int)zT_37;
    zT_39 = zT_35[zT_38];
    zT_40 = zT_39.line_offsets;
    zT_34 = zT_40;
    zT_41 = zF_281E4968_u32ArrayListGetSlic(zT_34);
    return zT_41;
}

/* sourceManagerGetLocation */
zT_5BC08DC6_Location zF_4966CE4A_sourceManagerGetLoc(zT_227EDE07_SourceManager* self, unsigned int file_id, unsigned int offset) {
    unsigned int zT_3;
    int zT_4;
    zT_5BC08DC6_Location zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_6B45117F_SourceFileArrayList* zT_10;
    zT_6B45117F_SourceFileArrayList* zT_11;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_12 = {0};
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_5BC08DC6_Location zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    zT_ED18556E_SourceFile* zT_28;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_ED18556E_SourceFile* zT_32;
    zT_B687BB96_U32ArrayList* zT_34;
    zT_B687BB96_U32ArrayList* zT_35;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_36 = {0};
    zT_3CB0179A_Slice_zT_05F374B1_u zT_38;
    unsigned int zT_39;
    unsigned int zT_40 = 0;
    unsigned int* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_5BC08DC6_Location zT_46;
    int zT_47;
    unsigned int zT_48;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_ED18556E_SourceFile* file;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    unsigned int col;
    zT_3 = 0;
    zT_4 = file_id == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    zT_5.file_id = zT_6;
    zT_7 = 0;
    zT_5.line = zT_7;
    zT_8 = 0;
    zT_5.col = zT_8;
    return zT_5;
    z_bb_2:
    zT_11 = self->files;
    zT_10 = zT_11;
    zT_12 = zF_276A1E3D_sourceFileArrayList(zT_10);
    files_slice = zT_12;
    files_slice = zT_12;
    files_slice = zT_12;
    fid = file_id;
    fid = file_id;
    fid = file_id;
    zT_15 = files_slice.len;
    zT_16 = 0;
    zT_17 = zT_15 == zT_16;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = 0;
    zT_18.file_id = zT_19;
    zT_20 = 0;
    zT_18.line = zT_20;
    zT_21 = 0;
    zT_18.col = zT_21;
    return zT_18;
    z_bb_4:
    zT_23 = files_slice.len;
    zT_24 = (unsigned int)zT_23;
    zT_25 = fid > zT_24;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = 1;
    fid = zT_26;
    fid = zT_26;
    goto z_bb_6;
    z_bb_6:
    zT_28 = files_slice.ptr;
    zT_29 = 1;
    zT_30 = fid - zT_29;
    zT_31 = (unsigned int)zT_30;
    zT_32 = zT_28 + zT_31;
    file = zT_32;
    file = zT_32;
    file = zT_32;
    zT_35 = file->line_offsets;
    zT_34 = zT_35;
    zT_36 = zF_281E4968_u32ArrayListGetSlic(zT_34);
    offsets = zT_36;
    offsets = zT_36;
    offsets = zT_36;
    zT_38 = offsets;
    zT_39 = offset;
    zT_40 = zF_1457D8A5_binary_search(zT_38, zT_39);
    line_idx = zT_40;
    line_idx = zT_40;
    line_idx = zT_40;
    zT_42 = offsets.ptr;
    zT_43 = (unsigned int)line_idx;
    zT_44 = zT_42[zT_43];
    zT_45 = offset - zT_44;
    col = zT_45;
    col = zT_45;
    col = zT_45;
    zT_46.file_id = file_id;
    zT_47 = 1;
    zT_48 = line_idx + zT_47;
    zT_46.line = zT_48;
    zT_46.col = col;
    return zT_46;
}

/* sourceManagerCopyToArena */
unsigned char* zF_B158E4F2_sourceManagerCopyTo(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    unsigned char* zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_171165BB_EU_812 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned char* zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_3 = text.len;
    zT_4 = 0;
    zT_5 = zT_3 == (unsigned int)zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    return zT_6;
    z_bb_2:
    zT_11 = self->allocator;
    zT_8 = zT_11;
    zT_13 = text.len;
    zT_9 = zT_13;
    zT_14 = 1;
    zT_10 = zT_14;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, zT_9, zT_10);
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    z_bb_4:
    zT_18 = zT_15.data.payload;
    zT_17 = zT_18;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    raw = zT_17;
    raw = zT_17;
    zT_19 = text.ptr;
    zT_20 = text.len;
    i = 0;
    goto z_bb_6;
    z_bb_6:
    zT_22 = i < zT_20;
    if (zT_22) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    c = zT_19[i];
    raw[i] = c;
    zT_24 = 1;
    zT_25 = i + zT_24;
    i = zT_25;
    goto z_bb_6;
    z_bb_8:
    return raw;
}

/* __module_init */
void zF_780653D2___module_init_2(void) {
    zT_B687BB96_U32ArrayList zT_0 = {0};
    zG_B687BB96_U32ArrayList = zT_0;
    return;
}

/* EOF */
