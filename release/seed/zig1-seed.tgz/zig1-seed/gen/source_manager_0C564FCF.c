#include "source_manager_0C564FCF.h"
zT_227EDE07_SourceManager zG_227EDE07_SourceManager;
/* sourceFileArrayListInit */
zT_6B45117F_SourceFileArrayList zF_EB529E39_sourceFileArrayList(zT_3E40CD83_Sand* allocator) {
    zT_6B45117F_SourceFileArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_ED18556E_SourceFile*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* sourceFileArrayListEnsureCapacity */
void zF_9E523C79_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_ED18556E_SourceFile* zT_26;
    unsigned int zT_28;
    zT_6F32B01B_Opt_235 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_ED18556E_SourceFile* zT_49;
    zT_ED18556E_SourceFile* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_ED18556E_SourceFile* zT_53;
    unsigned int zT_54;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_55;
    zT_ED18556E_SourceFile* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_ED18556E_SourceFile* new_items;
    zT_ED18556E_SourceFile item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->allocator;
    zT_26 = self->items;
    zT_28 = self->capacity;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(32)), (unsigned int)(new_cap * (unsigned int)(32)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->allocator;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(32) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_ED18556E_SourceFile*)raw;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* sourceFileArrayListAppend */
void zF_5368F9F7_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, zT_ED18556E_SourceFile value) {
    zT_6B45117F_SourceFileArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_ED18556E_SourceFile* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_9E523C79_sourceFileArrayList(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* sourceFileArrayListGetSlice */
zT_1D6CA09C_Slice_zT_ED18556E_S zF_276A1E3D_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self) {
    zT_ED18556E_SourceFile* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_ED18556E_SourceFile* zT_4;
    unsigned int zT_5;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* sourceManagerInit */
zT_227EDE07_SourceManager zF_01351F51_sourceManagerInit(zT_3E40CD83_Sand* allocator) {
    zT_3E40CD83_Sand* zT_2;
    zT_C6536882_EU_532 zT_7 = {0};
    unsigned char zT_8;
    unsigned char* zT_9;
    zT_6B45117F_SourceFileArrayList* zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_6B45117F_SourceFileArrayList zT_14 = {0};
    zT_3E40CD83_Sand* zT_16;
    zT_C6536882_EU_532 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_7D82FE60_GrowableSand* zT_26;
    zT_227EDE07_SourceManager zT_27;
    int zT_28;
    unsigned char* f_raw;
    zT_6B45117F_SourceFileArrayList* f_ptr;
    unsigned char* gs_raw;
    zT_7D82FE60_GrowableSand* gs_ptr;
    zT_2 = allocator;
    zT_7 = zF_1395EB68_sandAlloc(zT_2, (unsigned int)(16), (unsigned int)(4));
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    f_raw = zT_9;
    zT_12 = (zT_6B45117F_SourceFileArrayList*)f_raw;
    f_ptr = zT_12;
    zT_13 = allocator;
    zT_14 = zF_EB529E39_sourceFileArrayList(zT_13);
    *f_ptr = zT_14;
    zT_16 = allocator;
    zT_21 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(60), (unsigned int)(4));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_23 = zT_21.data.payload;
    goto z_bb_6;
    z_bb_6:
    gs_raw = zT_23;
    zT_26 = (zT_7D82FE60_GrowableSand*)gs_raw;
    gs_ptr = zT_26;
    zT_27.files = f_ptr;
    zT_27.allocator = allocator;
    zT_27.fault = gs_ptr;
    zT_28 = 0;
    zT_27.fault_ready = zT_28;
    return zT_27;
}

/* sourceManagerAddFile */
unsigned int zF_3A49F0F4_sourceManagerAddFil(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u filename, zT_8F083A69_Slice_zT_0B42B2F8_u content) {
    zT_227EDE07_SourceManager* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6 = 0;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_23;
    unsigned int zT_25;
    unsigned int zT_27;
    int zT_29;
    unsigned int zT_30;
    int zT_31;
    int zT_33;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_C6536882_EU_532 zT_42 = {0};
    unsigned char zT_43;
    unsigned char* zT_44;
    zT_B687BB96_U32ArrayList* zT_47;
    zT_3E40CD83_Sand* zT_48;
    zT_B687BB96_U32ArrayList zT_50 = {0};
    zT_B687BB96_U32ArrayList* zT_51;
    unsigned int zT_52;
    zT_B687BB96_U32ArrayList* zT_53;
    int zT_55;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_B687BB96_U32ArrayList* zT_64;
    int zT_67;
    unsigned int zT_70;
    zT_6B45117F_SourceFileArrayList* zT_71;
    zT_ED18556E_SourceFile zT_72;
    zT_ED18556E_SourceFile zT_74;
    unsigned int zT_76;
    int zT_77;
    int zT_78;
    zT_6B45117F_SourceFileArrayList* zT_79;
    unsigned int zT_80;
    unsigned char* fname_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname_copy;
    unsigned int line_count;
    unsigned char c;
    unsigned int cap;
    unsigned char* lo_raw;
    zT_B687BB96_U32ArrayList* lo_ptr;
    unsigned char c_1;
    unsigned int i;
    zT_4 = self;
    zT_5 = filename;
    zT_6 = zF_B158E4F2_sourceManagerCopyTo(zT_4, zT_5);
    fname_raw = zT_6;
    zT_9 = filename.len;
    zT_10 = 0;
    zT_11 = fname_raw + zT_10;
    zT_12 = zT_9 - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    fname_copy = zT_13;
    zT_15 = 0;
    line_count = zT_15;
    zT_16 = content.ptr;
    zT_17 = content.len;
    zT_18 = 0;
    goto z_bb_1;
    z_bb_1:
    if ((int)(zT_18 < zT_17)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    c = zT_16[zT_18];
    if ((int)(c == (unsigned char)(10))) goto z_bb_4; else goto z_bb_5;
    z_bb_3:
    zT_29 = 1;
    zT_30 = line_count + zT_29;
    cap = zT_30;
    zT_31 = 64;
    if ((int)(cap < (unsigned int)zT_31)) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    zT_23 = 1;
    zT_25 = line_count + (unsigned int)((unsigned int)zT_23);
    line_count = zT_25;
    goto z_bb_5;
    z_bb_5:
    zT_27 = zT_18 + (unsigned int)(1);
    zT_18 = zT_27;
    goto z_bb_1;
    z_bb_6:
    zT_33 = 64;
    zT_34 = (unsigned int)zT_33;
    cap = zT_34;
    goto z_bb_7;
    z_bb_7:
    zT_36 = self->allocator;
    zT_42 = zF_1395EB68_sandAlloc(zT_36, (unsigned int)(16), (unsigned int)(4));
    zT_43 = zT_42.is_error;
    if (zT_43) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    pal_trap();
    z_bb_9:
    zT_44 = zT_42.data.payload;
    goto z_bb_10;
    z_bb_10:
    lo_raw = zT_44;
    zT_47 = (zT_B687BB96_U32ArrayList*)lo_raw;
    lo_ptr = zT_47;
    zT_48 = self->allocator;
    zT_50 = zF_8E537D0C_u32ArrayListInit(zT_48);
    *lo_ptr = zT_50;
    zT_51 = lo_ptr;
    zT_52 = cap;
    zF_1580F084_u32ArrayListEnsureC(zT_51, zT_52);
    zT_53 = lo_ptr;
    zT_55 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_53, (unsigned int)((unsigned int)zT_55));
    zT_57 = content.ptr;
    zT_58 = content.len;
    i = 0;
    goto z_bb_11;
    z_bb_11:
    if ((int)(i < zT_58)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    c_1 = zT_57[i];
    if ((int)(c_1 == (unsigned char)(10))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_71 = self->files;
    zT_74.filename = fname_copy;
    zT_74.content = content;
    zT_74.line_offsets = lo_ptr;
    zT_76 = content.len;
    zT_74.len = zT_76;
    zT_77 = 1;
    zT_74.loaded = zT_77;
    zT_78 = 0;
    zT_74.transient = zT_78;
    zT_72 = zT_74;
    zF_5368F9F7_sourceFileArrayList(zT_71, zT_72);
    zT_79 = self->files;
    zT_80 = zT_79->len;
    return (unsigned int)((unsigned int)zT_80);
    z_bb_14:
    zT_64 = lo_ptr;
    zT_67 = 1;
    zF_62F717A2_u32ArrayListAppend(zT_64, (unsigned int)((unsigned int)((unsigned int)i) + zT_67));
    goto z_bb_15;
    z_bb_15:
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_11;
}

/* sourceManagerAddFileTransient */
unsigned int zF_55F5B402_sourceManagerAddFil(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u filename, zT_8F083A69_Slice_zT_0B42B2F8_u content) {
    zT_227EDE07_SourceManager* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6 = 0;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_3E40CD83_Sand* zT_15;
    zT_C6536882_EU_532 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_B687BB96_U32ArrayList* zT_26;
    zT_3E40CD83_Sand* zT_27;
    zT_B687BB96_U32ArrayList zT_29 = {0};
    zT_6B45117F_SourceFileArrayList* zT_30;
    zT_ED18556E_SourceFile zT_31;
    zT_ED18556E_SourceFile zT_33;
    unsigned int zT_35;
    int zT_36;
    int zT_37;
    zT_6B45117F_SourceFileArrayList* zT_38;
    unsigned int zT_39;
    unsigned char* fname_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname_copy;
    unsigned char* dummy_raw;
    zT_B687BB96_U32ArrayList* dummy_ptr;
    zT_4 = self;
    zT_5 = filename;
    zT_6 = zF_B158E4F2_sourceManagerCopyTo(zT_4, zT_5);
    fname_raw = zT_6;
    zT_9 = filename.len;
    zT_10 = 0;
    zT_11 = fname_raw + zT_10;
    zT_12 = zT_9 - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    fname_copy = zT_13;
    zT_15 = self->allocator;
    zT_21 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)(16), (unsigned int)(4));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_23 = zT_21.data.payload;
    goto z_bb_3;
    z_bb_3:
    dummy_raw = zT_23;
    zT_26 = (zT_B687BB96_U32ArrayList*)dummy_raw;
    dummy_ptr = zT_26;
    zT_27 = self->allocator;
    zT_29 = zF_8E537D0C_u32ArrayListInit(zT_27);
    *dummy_ptr = zT_29;
    zT_30 = self->files;
    zT_33.filename = fname_copy;
    zT_33.content = content;
    zT_33.line_offsets = dummy_ptr;
    zT_35 = content.len;
    zT_33.len = zT_35;
    zT_36 = 0;
    zT_33.loaded = zT_36;
    zT_37 = 1;
    zT_33.transient = zT_37;
    zT_31 = zT_33;
    zF_5368F9F7_sourceFileArrayList(zT_30, zT_31);
    zT_38 = self->files;
    zT_39 = zT_38->len;
    return (unsigned int)((unsigned int)zT_39);
}

/* sourceManagerFaultIn */
void zF_088D3002_sourceManagerFaultI(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    zT_6B45117F_SourceFileArrayList* zT_5;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_14;
    unsigned int zT_17;
    zT_ED18556E_SourceFile* zT_19;
    int zT_20;
    zT_ED18556E_SourceFile* zT_23;
    int zT_24;
    int zT_25;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_7D82FE60_GrowableSand* zT_31;
    zT_3E40CD83_Sand* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_3E40CD83_Sand* zT_36 = 0;
    int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    zT_3E40CD83_Sand* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_7D82FE60_GrowableSand* zT_44;
    zT_13D0AA3A_Opt_438 zT_46 = {0};
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_50;
    zT_7D82FE60_GrowableSand* zT_53;
    zT_C6536882_EU_532 zT_57 = {0};
    unsigned char zT_58;
    unsigned char* zT_59;
    zT_B687BB96_U32ArrayList* zT_62;
    zT_3E40CD83_Sand* zT_63;
    zT_7D82FE60_GrowableSand* zT_64;
    zT_B687BB96_U32ArrayList zT_66 = {0};
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    unsigned char* zT_79;
    unsigned char zT_80;
    int zT_83;
    unsigned int zT_85;
    int zT_86;
    unsigned int zT_88;
    int zT_90;
    unsigned int zT_91;
    zT_B687BB96_U32ArrayList* zT_92;
    unsigned int zT_93;
    zT_B687BB96_U32ArrayList* zT_94;
    int zT_96;
    unsigned char* zT_98;
    unsigned int zT_99;
    zT_B687BB96_U32ArrayList* zT_105;
    int zT_108;
    unsigned int zT_111;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_3E40CD83_Sand* zT_118;
    zT_7D82FE60_GrowableSand* zT_121;
    zT_C6536882_EU_532 zT_125 = {0};
    unsigned char zT_126;
    unsigned char* zT_127;
    zT_B687BB96_U32ArrayList* zT_130;
    zT_3E40CD83_Sand* zT_131;
    zT_7D82FE60_GrowableSand* zT_132;
    zT_B687BB96_U32ArrayList zT_134 = {0};
    zT_B687BB96_U32ArrayList* zT_135;
    int zT_137;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_ED18556E_SourceFile* file;
    zT_8F083A69_Slice_zT_0B42B2F8_u gs_name;
    zT_13D0AA3A_Opt_438 content_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned char* lo_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_content;
    unsigned char* lo_raw2;
    zT_B687BB96_U32ArrayList* lo_ptr;
    unsigned int scan_len;
    unsigned int line_count;
    unsigned int si;
    unsigned int cap;
    unsigned char c;
    unsigned int i;
    zT_B687BB96_U32ArrayList* lo_ptr2;
    if ((int)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->files;
    zT_7 = zF_276A1E3D_sourceFileArrayList(zT_5);
    files_slice = zT_7;
    zT_9 = files_slice.len;
    if ((int)(zT_9 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    fid = file_id;
    zT_14 = files_slice.len;
    if ((int)(fid > (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 1;
    fid = zT_17;
    goto z_bb_6;
    z_bb_6:
    zT_19 = files_slice.ptr;
    zT_20 = 1;
    zT_23 = zT_19 + (unsigned int)((unsigned int)(unsigned int)(fid - zT_20));
    file = zT_23;
    zT_24 = file->loaded;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_25 = self->fault_ready;
    if ((int)(!zT_25)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_28 = "diag_read";
    zT_30 = 9;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    gs_name = zT_29;
    zT_31 = self->fault;
    zT_36 = zF_8C23960F_poolPtr();
    zT_32 = zT_36;
    zT_37 = 4096;
    zT_34 = gs_name;
    zF_07B11742_growableSandInit(zT_31, zT_32, (unsigned int)((unsigned int)zT_37), zT_34);
    self->fault_ready = (int)(1);
    goto z_bb_10;
    z_bb_10:
    zT_43 = file->filename;
    zT_41 = zT_43;
    zT_44 = self->fault;
    zT_42 = &zT_44->view;
    zT_46 = zF_5B859C63_readFile(zT_41, zT_42);
    content_opt = zT_46;
    zT_47 = content_opt.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    content = content_opt.value;
    zT_53 = self->fault;
    zT_50 = &zT_53->view;
    zT_57 = zF_1395EB68_sandAlloc(zT_50, (unsigned int)(16), (unsigned int)(4));
    zT_58 = zT_57.is_error;
    if (zT_58) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    return;
    z_bb_13:
    zT_114 = "";
    zT_116 = 0;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    empty_content = zT_115;
    zT_121 = self->fault;
    zT_118 = &zT_121->view;
    zT_125 = zF_1395EB68_sandAlloc(zT_118, (unsigned int)(16), (unsigned int)(4));
    zT_126 = zT_125.is_error;
    if (zT_126) goto z_bb_30; else goto z_bb_31;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_59 = zT_57.data.payload;
    goto z_bb_16;
    z_bb_16:
    lo_raw = zT_59;
    zT_62 = (zT_B687BB96_U32ArrayList*)lo_raw;
    lo_ptr = zT_62;
    zT_64 = self->fault;
    zT_63 = &zT_64->view;
    zT_66 = zF_8E537D0C_u32ArrayListInit(zT_63);
    *lo_ptr = zT_66;
    zT_68 = file->len;
    scan_len = zT_68;
    zT_70 = content.len;
    if ((int)(scan_len > zT_70)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_73 = content.len;
    scan_len = zT_73;
    goto z_bb_18;
    z_bb_18:
    zT_75 = 0;
    line_count = zT_75;
    zT_77 = 0;
    si = zT_77;
    goto z_bb_19;
    z_bb_19:
    if ((int)(si < scan_len)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_79 = content.ptr;
    zT_80 = zT_79[si];
    if ((int)(zT_80 == (unsigned char)(10))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_90 = 1;
    zT_91 = line_count + zT_90;
    cap = zT_91;
    zT_92 = lo_ptr;
    zT_93 = cap;
    zF_1580F084_u32ArrayListEnsureC(zT_92, zT_93);
    zT_94 = lo_ptr;
    zT_96 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_94, (unsigned int)((unsigned int)zT_96));
    zT_98 = content.ptr;
    zT_99 = content.len;
    i = 0;
    goto z_bb_25;
    z_bb_22:
    zT_86 = 1;
    zT_88 = si + (unsigned int)((unsigned int)zT_86);
    si = zT_88;
    goto z_bb_19;
    z_bb_23:
    zT_83 = 1;
    zT_85 = line_count + (unsigned int)((unsigned int)zT_83);
    line_count = zT_85;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    if ((int)(i < zT_99)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    c = zT_98[i];
    if ((int)(c == (unsigned char)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    file->content = content;
    file->line_offsets = lo_ptr;
    file->loaded = (int)(1);
    goto z_bb_12;
    z_bb_28:
    zT_105 = lo_ptr;
    zT_108 = 1;
    zF_62F717A2_u32ArrayListAppend(zT_105, (unsigned int)((unsigned int)((unsigned int)i) + zT_108));
    goto z_bb_29;
    z_bb_29:
    zT_111 = i + (unsigned int)(1);
    i = zT_111;
    goto z_bb_25;
    z_bb_30:
    pal_trap();
    z_bb_31:
    zT_127 = zT_125.data.payload;
    goto z_bb_32;
    z_bb_32:
    lo_raw2 = zT_127;
    zT_130 = (zT_B687BB96_U32ArrayList*)lo_raw2;
    lo_ptr2 = zT_130;
    zT_132 = self->fault;
    zT_131 = &zT_132->view;
    zT_134 = zF_8E537D0C_u32ArrayListInit(zT_131);
    *lo_ptr2 = zT_134;
    zT_135 = lo_ptr2;
    zT_137 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_135, (unsigned int)((unsigned int)zT_137));
    file->content = empty_content;
    file->line_offsets = lo_ptr2;
    file->loaded = (int)(1);
    goto z_bb_12;
}

/* sourceManagerResetFaults */
void zF_196FDF3B_sourceManagerResetF(zT_227EDE07_SourceManager* self) {
    int zT_1;
    zT_3E40CD83_Sand* zT_3;
    zT_7D82FE60_GrowableSand* zT_4;
    zT_6B45117F_SourceFileArrayList* zT_7;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_9 = {0};
    unsigned int zT_11;
    unsigned int zT_13;
    zT_ED18556E_SourceFile* zT_15;
    zT_ED18556E_SourceFile zT_16;
    int zT_17;
    zT_ED18556E_SourceFile* zT_19;
    zT_ED18556E_SourceFile* zT_20;
    int zT_21;
    unsigned int zT_23;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int i;
    zT_1 = self->fault_ready;
    if ((int)(!zT_1)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->fault;
    zT_3 = &zT_4->view;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_7 = self->files;
    zT_9 = zF_276A1E3D_sourceFileArrayList(zT_7);
    files_slice = zT_9;
    zT_11 = 0;
    i = zT_11;
    goto z_bb_3;
    z_bb_3:
    zT_13 = files_slice.len;
    if ((int)(i < zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = files_slice.ptr;
    zT_16 = zT_15[i];
    zT_17 = zT_16.transient;
    if (zT_17) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = 1;
    zT_23 = i + (unsigned int)((unsigned int)zT_21);
    i = zT_23;
    goto z_bb_3;
    z_bb_7:
    zT_19 = files_slice.ptr;
    zT_20 = zT_19 + i;
    zT_20->loaded = (int)(0);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* sourceManagerGetFileName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7076474_sourceManagerGetFil(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11 = {0};
    unsigned int zT_13;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_ED18556E_SourceFile* zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_ED18556E_SourceFile zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((int)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_9 = self->files;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    zT_13 = files_slice.len;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    zT_22 = files_slice.len;
    if ((int)(fid > (unsigned int)((unsigned int)zT_22))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = files_slice.ptr;
    zT_27 = 1;
    zT_29 = (unsigned int)(unsigned int)(fid - zT_27);
    zT_30 = zT_26[zT_29];
    zT_31 = zT_30.filename;
    return zT_31;
}

/* sourceManagerGetSourceContent */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_FFE72B39_sourceManagerGetSou(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11 = {0};
    unsigned int zT_13;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_227EDE07_SourceManager* zT_26;
    unsigned int zT_27;
    zT_ED18556E_SourceFile* zT_28;
    int zT_29;
    unsigned int zT_31;
    zT_ED18556E_SourceFile zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((int)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_9 = self->files;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    zT_13 = files_slice.len;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    zT_22 = files_slice.len;
    if ((int)(fid > (unsigned int)((unsigned int)zT_22))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = self;
    zT_27 = fid;
    zF_088D3002_sourceManagerFaultI(zT_26, zT_27);
    zT_28 = files_slice.ptr;
    zT_29 = 1;
    zT_31 = (unsigned int)(unsigned int)(fid - zT_29);
    zT_32 = zT_28[zT_31];
    zT_33 = zT_32.content;
    return zT_33;
}

/* sourceManagerGetLineOffsets */
zT_3CB0179A_Slice_zT_05F374B1_u zF_5041A561_sourceManagerGetLin(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    zT_949EEA93_Arr_unsigned_int_0 zT_5;
    int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_11;
    zT_6B45117F_SourceFileArrayList* zT_13;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_15 = {0};
    unsigned int zT_17;
    zT_949EEA93_Arr_unsigned_int_0 zT_21;
    int zT_24;
    unsigned int* zT_25;
    unsigned int zT_26;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27;
    unsigned int zT_30;
    unsigned int zT_33;
    zT_227EDE07_SourceManager* zT_34;
    unsigned int zT_35;
    zT_B687BB96_U32ArrayList* zT_36;
    zT_ED18556E_SourceFile* zT_37;
    int zT_38;
    unsigned int zT_40;
    zT_ED18556E_SourceFile zT_41;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_43 = {0};
    zT_949EEA93_Arr_unsigned_int_0 dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((int)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    int _i = 0;
    while (_i < 0) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_5[_i];
        _i++;
    }
}
    zT_8 = 0;
    zT_9 = (unsigned int*)((unsigned int*)dummy) + zT_8;
    zT_10 = (unsigned int)(0) - zT_8;
    zT_11.ptr = zT_9;
    zT_11.len = zT_10;
    return zT_11;
    z_bb_2:
    zT_13 = self->files;
    zT_15 = zF_276A1E3D_sourceFileArrayList(zT_13);
    files_slice = zT_15;
    zT_17 = files_slice.len;
    if ((int)(zT_17 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    {
    int _i = 0;
    while (_i < 0) {
        zT_21[_i] = 0;
        _i++;
    }
}
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_21[_i];
        _i++;
    }
}
    zT_24 = 0;
    zT_25 = (unsigned int*)((unsigned int*)dummy) + zT_24;
    zT_26 = (unsigned int)(0) - zT_24;
    zT_27.ptr = zT_25;
    zT_27.len = zT_26;
    return zT_27;
    z_bb_4:
    fid = file_id;
    zT_30 = files_slice.len;
    if ((int)(fid > (unsigned int)((unsigned int)zT_30))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_33 = 1;
    fid = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_34 = self;
    zT_35 = fid;
    zF_088D3002_sourceManagerFaultI(zT_34, zT_35);
    zT_37 = files_slice.ptr;
    zT_38 = 1;
    zT_40 = (unsigned int)(unsigned int)(fid - zT_38);
    zT_41 = zT_37[zT_40];
    zT_36 = zT_41.line_offsets;
    zT_43 = zF_281E4968_u32ArrayListGetSlic(zT_36);
    return zT_43;
}

/* sourceManagerGetLocation */
zT_5BC08DC6_Location zF_4966CE4A_sourceManagerGetLoc(zT_227EDE07_SourceManager* self, unsigned int file_id, unsigned int offset) {
    zT_5BC08DC6_Location zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_6B45117F_SourceFileArrayList* zT_10;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_12 = {0};
    unsigned int zT_15;
    zT_5BC08DC6_Location zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_26;
    zT_227EDE07_SourceManager* zT_27;
    unsigned int zT_28;
    zT_ED18556E_SourceFile* zT_30;
    int zT_31;
    zT_ED18556E_SourceFile* zT_34;
    zT_B687BB96_U32ArrayList* zT_36;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_38 = {0};
    zT_3CB0179A_Slice_zT_05F374B1_u zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    unsigned int* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_5BC08DC6_Location zT_48;
    int zT_49;
    unsigned int zT_50;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_ED18556E_SourceFile* file;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    unsigned int col;
    if ((int)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    zT_5.file_id = zT_6;
    zT_7 = 0;
    zT_5.line = zT_7;
    zT_8 = 0;
    zT_5.col = zT_8;
    return zT_5;
    z_bb_2:
    zT_10 = self->files;
    zT_12 = zF_276A1E3D_sourceFileArrayList(zT_10);
    files_slice = zT_12;
    fid = file_id;
    zT_15 = files_slice.len;
    if ((int)(zT_15 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = 0;
    zT_18.file_id = zT_19;
    zT_20 = 0;
    zT_18.line = zT_20;
    zT_21 = 0;
    zT_18.col = zT_21;
    return zT_18;
    z_bb_4:
    zT_23 = files_slice.len;
    if ((int)(fid > (unsigned int)((unsigned int)zT_23))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = 1;
    fid = zT_26;
    goto z_bb_6;
    z_bb_6:
    zT_27 = self;
    zT_28 = fid;
    zF_088D3002_sourceManagerFaultI(zT_27, zT_28);
    zT_30 = files_slice.ptr;
    zT_31 = 1;
    zT_34 = zT_30 + (unsigned int)((unsigned int)(unsigned int)(fid - zT_31));
    file = zT_34;
    zT_36 = file->line_offsets;
    zT_38 = zF_281E4968_u32ArrayListGetSlic(zT_36);
    offsets = zT_38;
    zT_40 = offsets;
    zT_41 = offset;
    zT_42 = zF_1457D8A5_binary_search(zT_40, zT_41);
    line_idx = zT_42;
    zT_44 = offsets.ptr;
    zT_45 = (unsigned int)line_idx;
    zT_46 = zT_44[zT_45];
    zT_47 = offset - zT_46;
    col = zT_47;
    zT_48.file_id = file_id;
    zT_49 = 1;
    zT_50 = line_idx + zT_49;
    zT_48.line = zT_50;
    zT_48.col = col;
    return zT_48;
}

/* sourceManagerCopyToArena */
unsigned char* zF_B158E4F2_sourceManagerCopyTo(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    unsigned char* zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_C6536882_EU_532 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned int zT_25;
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_3 = text.len;
    zT_4 = 0;
    if ((int)(zT_3 == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    return zT_6;
    z_bb_2:
    zT_8 = self->allocator;
    zT_9 = text.len;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(1));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_19 = text.ptr;
    zT_20 = text.len;
    i = 0;
    goto z_bb_6;
    z_bb_6:
    if ((int)(i < zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    c = zT_19[i];
    raw[i] = c;
    zT_25 = i + (unsigned int)(1);
    i = zT_25;
    goto z_bb_6;
    z_bb_8:
    return raw;
}

/* __module_init */
void zF_780653D2___module_init_2(void) {
    zT_B687BB96_U32ArrayList zT_0 = {0};
    zG_B687BB96_U32ArrayList = zT_0;
    return;
}

/* EOF */
