#ifndef ZIG_MODULE_ASYNC_FRAME_LAYOUT_08B81337_H
#define ZIG_MODULE_ASYNC_FRAME_LAYOUT_08B81337_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "async_analysis_A8747991.h"
#include "growable_array_6014E5AF.h"
#include "hash_02AFCD13.h"
#include "itoa_4E677A6A.h"
#include "lir_64CB5435.h"
#include "pal_388A8A1B.h"
#include "type_registry_8EE489B8.h"

#ifndef ZIG_STRUCT_zT_902E38E8_AsyncFrameField
#define ZIG_STRUCT_zT_902E38E8_AsyncFrameField
struct zT_902E38E8_AsyncFrameField {
	unsigned char kind;
	unsigned int name_id;
	unsigned int temp_id;
	unsigned int type_id;
	unsigned int offset;
	unsigned int size;
	unsigned int alignment;
};
#endif /* ZIG_STRUCT_zT_902E38E8_AsyncFrameField */
#ifndef ZIG_STRUCT_zT_6D148508_Scan
#define ZIG_STRUCT_zT_6D148508_Scan
struct zT_6D148508_Scan {
	zT_BBC23664_LirFunction* lir_fn;
	zT_338B7C76_TypeRegistry* reg;
	unsigned int max_temp;
	unsigned int* ttype;
	zT_21D3708C_U32ToU32Map* locals;
	zT_3E40CD83_Sand* alloc;
	unsigned int nblocks;
	unsigned char* visited;
	unsigned int* work;
};
#endif /* ZIG_STRUCT_zT_6D148508_Scan */

/* Forward declarations */
zT_2CF63CE1_AsyncFrameFieldArra zF_1BFB52BE_fieldArrayListInit(zT_3E40CD83_Sand*, unsigned int);
void zF_FB5EC98E_fieldArrayListEnsur(zT_2CF63CE1_AsyncFrameFieldArra*, unsigned int);
void zF_92FA7DBC_fieldArrayListAppen(zT_2CF63CE1_AsyncFrameFieldArra*, zT_902E38E8_AsyncFrameField);
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand*, unsigned int, unsigned int);
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand*, unsigned int);
unsigned char* zF_9C85B07B_allocU8With(zT_3E40CD83_Sand*, unsigned int, unsigned char);
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction*);
unsigned int zF_CFED20F7_defResultTemp(zT_6D148508_Scan*, zT_6BA597BC_LirInst);
unsigned int zF_CD424A09_localStorage(zT_6D148508_Scan*, unsigned int);
int zF_1FF90D33_instDefsTemp(zT_6D148508_Scan*, zT_6BA597BC_LirInst, unsigned int);
int zF_E4C3429C_instReadsTemp(zT_6D148508_Scan*, zT_6BA597BC_LirInst, unsigned int);
int zF_1AAC25A7_instIsSuspendPoint(zT_6D148508_Scan*, zT_6BA597BC_LirInst, zT_A4CE86B7_U64ToU32Map*);
int zF_93E9604D_hasDefBefore(zT_6D148508_Scan*, unsigned int, unsigned int, unsigned int);
void zF_D7490A6E_cfgPushSuccessors(zT_6D148508_Scan*, unsigned int, unsigned int*);
int zF_4CED5DFF_hasReadAfter(zT_6D148508_Scan*, unsigned int, unsigned int, unsigned int);
void zF_F2801F08_addField(zT_2CF63CE1_AsyncFrameFieldArra*, zT_338B7C76_TypeRegistry*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned int*);
void zF_2B302EFE_emitLayoutMarker(unsigned int, unsigned int, unsigned int);
zT_3F3BF87A_AsyncFrameLayout zF_28031796_asyncLayoutFrame(zT_3E40CD83_Sand*, zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_B687BB96_U32ArrayList*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*);
void zF_17324878_asyncLayoutPublish(zT_3E40CD83_Sand*, zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int, zT_3F3BF87A_AsyncFrameLayout);
zT_03B97CED_Opt_398 zF_A1F56FFB_asyncLayoutLookup(zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int);
void zF_780653D2___module_init_22(void);
/* Storage globals (extern decls) */
extern zT_3F3BF87A_AsyncFrameLayout zG_3F3BF87A_AsyncFrameLayout;

#endif /* ZIG_MODULE_ASYNC_FRAME_LAYOUT_08B81337_H */
