#ifndef ZIG_MODULE_ALLOCATOR_E75B7A0B_H
#define ZIG_MODULE_ALLOCATOR_E75B7A0B_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "pal_388A8A1B.h"
#include "panic_CE239B25.h"
#include "itoa_4E677A6A.h"

#ifndef ZIG_STRUCT_zT_36103E01_TrackingAllocator
#define ZIG_STRUCT_zT_36103E01_TrackingAllocator
struct zT_36103E01_TrackingAllocator {
	zT_3E40CD83_Sand* arena;
	unsigned int total_allocated;
	unsigned int peak_allocated;
	unsigned int allocation_count;
};
#endif /* ZIG_STRUCT_zT_36103E01_TrackingAllocator */
#ifndef ZIG_STRUCT_zT_5FDE47EF_TrackingAllocatorRe
#define ZIG_STRUCT_zT_5FDE47EF_TrackingAllocatorRe
struct zT_5FDE47EF_TrackingAllocatorRe {
	unsigned int peak;
	unsigned int total;
	unsigned int count;
};
#endif /* ZIG_STRUCT_zT_5FDE47EF_TrackingAllocatorRe */

/* Forward declarations */
zT_3E40CD83_Sand zF_CE0A77DD_sandInit(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_0715C9B9_EU_832 zF_1395EB68_sandAlloc(zT_3E40CD83_Sand*, unsigned int, unsigned int);
void zF_F1B3F8C2_sandReset(zT_3E40CD83_Sand*);
void zF_07B11742_growableSandInit(zT_7D82FE60_GrowableSand*, zT_3E40CD83_Sand*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_130612FB_growableSandGrow(zT_7D82FE60_GrowableSand*, zT_3E40CD83_Sand*, unsigned int);
zT_6B306B38_Opt_241 zF_DFE38AD3_popFreeBestFit(unsigned int);
void zF_4C1017CD_arenaGrew(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int);
void zF_139949FD_writeUsizeExact(unsigned int);
void zF_CB5A85E9_sandResetPeak(zT_3E40CD83_Sand*);
zT_6A32A83C_Opt_238 zF_33A3D4F8_sandTryReallocInPla(zT_3E40CD83_Sand*, unsigned char*, unsigned int, unsigned int, unsigned int);
zT_6A32A83C_Opt_238 zF_B635FA63_sandReallocInPlace(zT_3E40CD83_Sand*, unsigned char*, unsigned int, unsigned int, unsigned int);
zT_3E40CD83_Sand* zF_8C23960F_poolPtr(void);
unsigned int zF_E5D0D49C_poolPeak(void);
zT_69057089_CompilerAlloc zF_90E832C7_initCompilerAlloc(void);
void zF_BA490D17_checkCombinedPeak(zT_69057089_CompilerAlloc*);
void zF_4ACF6BFE_printUsize(unsigned int);
zT_36103E01_TrackingAllocator zF_76B743BF_trackingAllocatorIn(zT_3E40CD83_Sand*);
zT_0715C9B9_EU_832 zF_A3D28661_trackingAlloc(zT_36103E01_TrackingAllocator*, unsigned int, unsigned int);
void zF_BABD990B_trackingReset(zT_36103E01_TrackingAllocator*);
unsigned int zF_6D8BD187_trackingPeak(zT_36103E01_TrackingAllocator*);
zT_5FDE47EF_TrackingAllocatorRe zF_6F4768CF_trackingAllocatorRe(zT_36103E01_TrackingAllocator*);
void zF_780653D2___module_init_1(void);
/* Storage globals (extern decls) */
extern zT_3E40CD83_Sand zG_3E40CD83_Sand;
extern zT_69057089_CompilerAlloc zG_69057089_CompilerAlloc;
extern zT_5B44B793_Arr_unsigned_char_2 zG_EEB4E6C3_memory_pool_buf;
extern zT_3E40CD83_Sand zG_91DD7983_pool;
extern zT_7D82FE60_GrowableSand zG_2D921856_perm_gs;
extern zT_7D82FE60_GrowableSand zG_D2119B4E_mod_gs;
extern zT_7D82FE60_GrowableSand zG_8901137E_scr_gs;
extern zT_7D82FE60_GrowableSand zG_74F406AB_lir_gs;
extern zT_7D82FE60_GrowableSand zG_DD5B2E91_emit_gs;
extern zT_6B306B38_Opt_241 zG_D5B16534_seg_free_head;
extern unsigned int zG_7135C933_DEV_MAX_MEM;
extern unsigned int zG_3B40C71D_RELEASE_MAX_MEM;
extern unsigned int zG_18AE3D2F_DEFAULT_MAX_MEM_KB;

#endif /* ZIG_MODULE_ALLOCATOR_E75B7A0B_H */
