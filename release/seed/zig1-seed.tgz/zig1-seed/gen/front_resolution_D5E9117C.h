#ifndef ZIG_MODULE_FRONT_RESOLUTION_D5E9117C_H
#define ZIG_MODULE_FRONT_RESOLUTION_D5E9117C_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "ast_2FA12982.h"
#include "module_registry_03A5D1FC.h"
#include "symbol_table_74081C75.h"
#include "type_registry_8EE489B8.h"
#include "resolved_type_table_5F22E794.h"
#include "coercion_F654E5FA.h"
#include "semantic_analyzer_4DBE89E5.h"
#include "type_resolver_7446D285.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "growable_array_6014E5AF.h"
#include "spill_store_AC8E76BA.h"

#ifndef ZIG_STRUCT_zT_6DCFC8DB_FrontResCtx
#define ZIG_STRUCT_zT_6DCFC8DB_FrontResCtx
struct zT_6DCFC8DB_FrontResCtx {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* typereg;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	zT_8EED1867_ResolvedTypeTable* resolved_types;
	zT_072B53A6_ModuleRegistry* module_reg;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_3E40CD83_Sand* scratch;
	zT_66E7D2EF_CoercionTable* coercion_table;
	zT_21D3708C_U32ToU32Map* enum_value_table;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	zT_21D3708C_U32ToU32Map* call_arg_types;
	zT_21D3708C_U32ToU32Map* call_param_map;
	zT_A4CE86B7_U64ToU32Map* suspending_fns;
};
#endif /* ZIG_STRUCT_zT_6DCFC8DB_FrontResCtx */

/* Forward declarations */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx*, unsigned int, unsigned int, zT_03B97CED_Opt_398, unsigned int);
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx*);
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx*);
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_B1CC762C_resolveStmtTypesRec(zT_6DCFC8DB_FrontResCtx*, unsigned int, unsigned int, unsigned int, unsigned int, zT_E2DF2801_LocalConstScope*);
void zF_780653D2___module_init_21(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_FRONT_RESOLUTION_D5E9117C_H */
