#include "analyzer_2FA863C8.h"
unsigned int zG_73BDFDC5_PER_FUNC_BUDGET;
/* identNameId */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_2 = store;
    zT_3 = node_idx;
    zT_4 = zF_53458827_astStoreIdentifier(zT_2, zT_3);
    return zT_4;
}

/* resolveOrigin */
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_BAEE192E_Opt_10 zT_19;
    zT_7E2F335A_AnalyzerContext* zT_23;
    unsigned int zT_25;
    zT_7E2F335A_AnalyzerContext* zT_30;
    unsigned int zT_32;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    zT_7E2F335A_AnalyzerContext* zT_41;
    unsigned int zT_43;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx->store;
    zT_16 = expr_idx;
    zT_18 = zF_2E24BD6B_identNameId(zT_15, zT_16);
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = ctx;
    zT_25 = node.child_0;
    ctx = zT_23;
    expr_idx = zT_25;
    goto z_bb_0;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = ctx;
    zT_32 = node.child_0;
    ctx = zT_30;
    expr_idx = zT_32;
    goto z_bb_0;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = ctx;
    zT_43 = node.child_0;
    ctx = zT_41;
    expr_idx = zT_43;
    goto z_bb_0;
    z_bb_12:
    zT_45.has_value = 0;
    return zT_45;
}

/* classifyProvenance */
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    zT_7E2F335A_AnalyzerContext* zT_18;
    unsigned int zT_19;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_060CD1EB_SymbolTable* zT_25;
    unsigned int zT_26;
    zT_567DA1C3_Opt_868 zT_28 = {0};
    unsigned char zT_29;
    zT_3C598AEF_SymbolKind zT_31;
    zT_3C598AEF_SymbolKind zT_37;
    zT_3C598AEF_SymbolKind zT_43;
    zT_7E2F335A_AnalyzerContext* zT_60;
    unsigned int zT_61;
    zT_BAEE192E_Opt_10 zT_63 = {0};
    unsigned char zT_64;
    zT_2C0927B0_StateMap* zT_67;
    unsigned int zT_68;
    zT_43E16BE5_Opt_8 zT_69 = {0};
    unsigned char zT_70;
    zT_7E2F335A_AnalyzerContext* zT_78;
    unsigned int zT_79;
    zT_BAEE192E_Opt_10 zT_81 = {0};
    unsigned char zT_82;
    zT_2C0927B0_StateMap* zT_85;
    unsigned int zT_86;
    zT_43E16BE5_Opt_8 zT_87 = {0};
    unsigned char zT_88;
    zT_2C0927B0_StateMap* zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_101 = 0;
    zT_43E16BE5_Opt_8 zT_102 = {0};
    unsigned char zT_103;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_BAEE192E_Opt_10 found_name_id;
    unsigned int name_id;
    zT_567DA1C3_Opt_868 sym;
    zT_3A105EF1_Symbol* s;
    zT_BAEE192E_Opt_10 base_id;
    unsigned int bid;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = expr_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = ctx;
    zT_19 = node.child_0;
    zT_21 = zF_92A5586D_resolveOrigin(zT_18, zT_19);
    found_name_id = zT_21;
    zT_22 = found_name_id.has_value;
    if (zT_22) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_15; else goto z_bb_16;
    z_bb_5:
    name_id = found_name_id.value;
    zT_25 = ctx->symbols;
    zT_26 = name_id;
    zT_28 = zF_893B79A5_symbolTableLookup(zT_25, zT_26);
    sym = zT_28;
    zT_29 = sym.has_value;
    if (zT_29) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_7:
    s = sym.value;
    zT_31 = s->kind;
    if ((unsigned char)(zT_31 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_local))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_10:
    zT_37 = s->kind;
    if ((unsigned char)(zT_37 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_param))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_12:
    zT_43 = s->kind;
    if ((unsigned char)(zT_43 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_60 = ctx;
    zT_61 = node.child_0;
    zT_63 = zF_92A5586D_resolveOrigin(zT_60, zT_61);
    base_id = zT_63;
    zT_64 = base_id.has_value;
    if (zT_64) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    bid = base_id.value;
    zT_67 = state;
    zT_68 = bid;
    zT_69 = zF_2EC17ECC_stateMapGet(zT_67, zT_68);
    result = zT_69;
    zT_70 = result.has_value;
    if (zT_70) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_21:
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_78 = ctx;
    zT_79 = node.child_0;
    zT_81 = zF_92A5586D_resolveOrigin(zT_78, zT_79);
    base_id = zT_81;
    zT_82 = base_id.has_value;
    if (zT_82) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    bid = base_id.value;
    zT_85 = state;
    zT_86 = bid;
    zT_87 = zF_2EC17ECC_stateMapGet(zT_85, zT_86);
    result = zT_87;
    zT_88 = result.has_value;
    if (zT_88) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_27:
    v = result.value;
    return v;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_96 = state;
    zT_98 = ctx->store;
    zT_99 = expr_idx;
    zT_101 = zF_2E24BD6B_identNameId(zT_98, zT_99);
    zT_97 = zT_101;
    zT_102 = zF_2EC17ECC_stateMapGet(zT_96, zT_97);
    result = zT_102;
    zT_103 = result.has_value;
    if (zT_103) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_31:
    v = result.value;
    return v;
    z_bb_32:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
}

/* checkReturnProvenance */
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx, unsigned int ret_node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_5;
    zT_2C0927B0_StateMap* zT_6;
    unsigned int zT_7;
    unsigned char zT_8 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    unsigned char zT_28;
    unsigned char zT_31;
    zT_8143F551_AstKind zT_33;
    zT_7E2F335A_AnalyzerContext* zT_38;
    unsigned int zT_39;
    zT_BAEE192E_Opt_10 zT_41 = {0};
    unsigned char zT_42;
    zT_D3EB6303_StringInterner* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48 = {0};
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_72;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_F85C5DED_DiagnosticCollector* zT_90;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_8143F551_AstKind zT_104;
    zT_7E2F335A_AnalyzerContext* zT_109;
    unsigned int zT_110;
    zT_BAEE192E_Opt_10 zT_112 = {0};
    unsigned char zT_113;
    zT_D3EB6303_StringInterner* zT_116;
    unsigned int zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119 = {0};
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    unsigned char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_D3EB6303_StringInterner* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_135;
    zT_F85C5DED_DiagnosticCollector* zT_137;
    int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_143;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_F85C5DED_DiagnosticCollector* zT_161;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    zT_7E2F335A_AnalyzerContext* zT_176;
    unsigned int zT_177;
    zT_BAEE192E_Opt_10 zT_178 = {0};
    unsigned char zT_179;
    zT_D3EB6303_StringInterner* zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185 = {0};
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_D3EB6303_StringInterner* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_201;
    zT_F85C5DED_DiagnosticCollector* zT_203;
    int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_209;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    zT_F85C5DED_DiagnosticCollector* zT_227;
    unsigned int zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_7E2F335A_AnalyzerContext* zT_243;
    unsigned int zT_244;
    zT_BAEE192E_Opt_10 zT_246 = {0};
    unsigned char zT_247;
    zT_D3EB6303_StringInterner* zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_253 = {0};
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_D3EB6303_StringInterner* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_269;
    zT_F85C5DED_DiagnosticCollector* zT_271;
    int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_277;
    unsigned int zT_281;
    unsigned int zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char* zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294;
    zT_F85C5DED_DiagnosticCollector* zT_295;
    unsigned int zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned char prov;
    zT_22A7C88B_AstNode rnode;
    unsigned int start;
    unsigned int end;
    zT_22A7C88B_AstNode expr_node;
    unsigned char pl;
    unsigned char ppa;
    zT_BAEE192E_Opt_10 name_opt;
    unsigned int nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli rparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_5 = ctx;
    zT_6 = state;
    zT_7 = expr_idx;
    zT_8 = zF_5542CD3C_classifyProvenance(zT_5, zT_6, zT_7);
    prov = zT_8;
    zT_10 = ctx->store;
    zT_11 = ret_node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    rnode = zT_13;
    zT_15 = rnode.span_start;
    start = zT_15;
    zT_17 = rnode.span_start;
    zT_18 = rnode.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = ctx->store;
    zT_23 = expr_idx;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    expr_node = zT_25;
    zT_28 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    pl = zT_28;
    zT_31 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr);
    ppa = zT_31;
    if ((unsigned char)(prov == pl)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_33 = expr_node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(prov == ppa)) goto z_bb_13; else goto z_bb_14;
    z_bb_3:
    zT_38 = ctx;
    zT_39 = expr_node.child_0;
    zT_41 = zF_92A5586D_resolveOrigin(zT_38, zT_39);
    name_opt = zT_41;
    zT_42 = name_opt.has_value;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_104 = expr_node.kind;
    if ((unsigned char)(zT_104 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    nid = name_opt.value;
    zT_45 = ctx->interner;
    zT_46 = nid;
    zT_48 = zF_9134020D_stringInternerGet(zT_45, zT_46);
    nm = zT_48;
    zT_50 = "returning address of local variable '";
    zT_52 = 37;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    rp1 = zT_51;
    zT_54 = "'";
    zT_56 = 1;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    rp2 = zT_55;
    zT_59 = 0;
    zT_58[zT_59] = rp1;
    zT_60 = 1;
    zT_58[zT_60] = nm;
    zT_61 = 2;
    zT_58[zT_61] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_58[_i];
        _i++;
    }
}
    zT_66 = ctx->diag;
    zT_63 = zT_66->interner;
    zT_68 = 0;
    zT_69 = rparts + zT_68;
    zT_64 = zT_69;
    zT_71 = zF_8C4BFF7C_diagnosticBuilderMa(zT_63, zT_64, (unsigned int)(3));
    msg = zT_71;
    zT_72 = ctx->diag;
    zT_76 = start;
    zT_77 = end;
    zT_78 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_72, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_76, zT_77, zT_78);
    return;
    z_bb_6:
    zT_87 = "returning address of local variable";
    zT_89 = 35;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    dmsg = zT_88;
    zT_90 = ctx->diag;
    zT_94 = start;
    zT_95 = end;
    zT_96 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_90, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_94, zT_95, zT_96);
    return;
    z_bb_7:
    zT_109 = ctx;
    zT_110 = expr_node.child_0;
    zT_112 = zF_92A5586D_resolveOrigin(zT_109, zT_110);
    name_opt = zT_112;
    zT_113 = name_opt.has_value;
    if (zT_113) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_176 = ctx;
    zT_177 = expr_idx;
    zT_178 = zF_92A5586D_resolveOrigin(zT_176, zT_177);
    name_opt = zT_178;
    zT_179 = name_opt.has_value;
    if (zT_179) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    nid = name_opt.value;
    zT_116 = ctx->interner;
    zT_117 = nid;
    zT_119 = zF_9134020D_stringInternerGet(zT_116, zT_117);
    nm = zT_119;
    zT_121 = "returning slice of local array '";
    zT_123 = 32;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    rp1 = zT_122;
    zT_125 = "'";
    zT_127 = 1;
    zT_126.ptr = zT_125;
    zT_126.len = zT_127;
    rp2 = zT_126;
    zT_130 = 0;
    zT_129[zT_130] = rp1;
    zT_131 = 1;
    zT_129[zT_131] = nm;
    zT_132 = 2;
    zT_129[zT_132] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_129[_i];
        _i++;
    }
}
    zT_137 = ctx->diag;
    zT_134 = zT_137->interner;
    zT_139 = 0;
    zT_140 = rparts + zT_139;
    zT_135 = zT_140;
    zT_142 = zF_8C4BFF7C_diagnosticBuilderMa(zT_134, zT_135, (unsigned int)(3));
    msg = zT_142;
    zT_143 = ctx->diag;
    zT_147 = start;
    zT_148 = end;
    zT_149 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_143, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_147, zT_148, zT_149);
    return;
    z_bb_10:
    zT_158 = "returning slice of local array";
    zT_160 = 30;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    dmsg = zT_159;
    zT_161 = ctx->diag;
    zT_165 = start;
    zT_166 = end;
    zT_167 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_161, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_165, zT_166, zT_167);
    return;
    z_bb_11:
    nid = name_opt.value;
    zT_182 = ctx->interner;
    zT_183 = nid;
    zT_185 = zF_9134020D_stringInternerGet(zT_182, zT_183);
    nm = zT_185;
    zT_187 = "returning pointer to local via variable '";
    zT_189 = 41;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    rp1 = zT_188;
    zT_191 = "'";
    zT_193 = 1;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    rp2 = zT_192;
    zT_196 = 0;
    zT_195[zT_196] = rp1;
    zT_197 = 1;
    zT_195[zT_197] = nm;
    zT_198 = 2;
    zT_195[zT_198] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_195[_i];
        _i++;
    }
}
    zT_203 = ctx->diag;
    zT_200 = zT_203->interner;
    zT_205 = 0;
    zT_206 = rparts + zT_205;
    zT_201 = zT_206;
    zT_208 = zF_8C4BFF7C_diagnosticBuilderMa(zT_200, zT_201, (unsigned int)(3));
    msg = zT_208;
    zT_209 = ctx->diag;
    zT_213 = start;
    zT_214 = end;
    zT_215 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_209, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_213, zT_214, zT_215);
    return;
    z_bb_12:
    zT_224 = "returning pointer to local via variable";
    zT_226 = 39;
    zT_225.ptr = zT_224;
    zT_225.len = zT_226;
    dmsg = zT_225;
    zT_227 = ctx->diag;
    zT_231 = start;
    zT_232 = end;
    zT_233 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_227, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_231, zT_232, zT_233);
    return;
    z_bb_13:
    zT_243 = ctx;
    zT_244 = expr_node.child_0;
    zT_246 = zF_92A5586D_resolveOrigin(zT_243, zT_244);
    name_opt = zT_246;
    zT_247 = name_opt.has_value;
    if (zT_247) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    return;
    z_bb_15:
    nid = name_opt.value;
    zT_250 = ctx->interner;
    zT_251 = nid;
    zT_253 = zF_9134020D_stringInternerGet(zT_250, zT_251);
    nm = zT_253;
    zT_255 = "returning address of parameter '";
    zT_257 = 32;
    zT_256.ptr = zT_255;
    zT_256.len = zT_257;
    rp1 = zT_256;
    zT_259 = "'";
    zT_261 = 1;
    zT_260.ptr = zT_259;
    zT_260.len = zT_261;
    rp2 = zT_260;
    zT_264 = 0;
    zT_263[zT_264] = rp1;
    zT_265 = 1;
    zT_263[zT_265] = nm;
    zT_266 = 2;
    zT_263[zT_266] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_263[_i];
        _i++;
    }
}
    zT_271 = ctx->diag;
    zT_268 = zT_271->interner;
    zT_273 = 0;
    zT_274 = rparts + zT_273;
    zT_269 = zT_274;
    zT_276 = zF_8C4BFF7C_diagnosticBuilderMa(zT_268, zT_269, (unsigned int)(3));
    msg = zT_276;
    zT_277 = ctx->diag;
    zT_281 = start;
    zT_282 = end;
    zT_283 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_277, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_281, zT_282, zT_283);
    return;
    z_bb_16:
    zT_292 = "returning address of function parameter";
    zT_294 = 39;
    zT_293.ptr = zT_292;
    zT_293.len = zT_294;
    dmsg = zT_293;
    zT_295 = ctx->diag;
    zT_299 = start;
    zT_300 = end;
    zT_301 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_295, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_299, zT_300, zT_301);
    return;
}

/* isAllocCall */
unsigned char zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_7E2F335A_AnalyzerContext* zT_14;
    unsigned int zT_16;
    zT_8143F551_AstKind zT_18;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    zT_8143F551_AstKind zT_29;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_48 = 0;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_D3EB6303_StringInterner* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sandAlloc;
    unsigned int sand_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_alloc;
    unsigned int sand2_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_alloc;
    unsigned int arena_nid;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = ctx;
    zT_16 = node.child_0;
    ctx = zT_14;
    expr_idx = zT_16;
    goto z_bb_0;
    z_bb_4:
    zT_18 = node.kind;
    if ((unsigned char)(zT_18 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_24 = ctx->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    callee = zT_28;
    zT_29 = callee.kind;
    if ((unsigned char)(zT_29 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_35 = ctx->store;
    zT_36 = node.child_0;
    zT_39 = zF_2E24BD6B_identNameId(zT_35, zT_36);
    name_id = zT_39;
    zT_41 = "sandAlloc";
    zT_43 = 9;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    s_sandAlloc = zT_42;
    zT_45 = ctx->interner;
    zT_46 = s_sandAlloc;
    zT_48 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    sand_nid = zT_48;
    if ((unsigned char)(name_id == sand_nid)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_52 = "sand_alloc";
    zT_54 = 10;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    s_sand_alloc = zT_53;
    zT_56 = ctx->interner;
    zT_57 = s_sand_alloc;
    zT_59 = zF_50C274AF_stringInternerInter(zT_56, zT_57);
    sand2_nid = zT_59;
    if ((unsigned char)(name_id == sand2_nid)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_63 = "arena_alloc";
    zT_65 = 11;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    s_arena_alloc = zT_64;
    zT_67 = ctx->interner;
    zT_68 = s_arena_alloc;
    zT_70 = zF_50C274AF_stringInternerInter(zT_67, zT_68);
    arena_nid = zT_70;
    if ((unsigned char)(name_id == arena_nid)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* isFreeCall */
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_31 = 0;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_40 = 0;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_49 = 0;
    unsigned char zT_51;
    zT_BAEE192E_Opt_10 zT_53 = {0};
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58 = 0;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    zT_22A7C88B_AstNode zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_81 = 0;
    zT_BAEE192E_Opt_10 zT_82;
    zT_BAEE192E_Opt_10 zT_83 = {0};
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_free;
    unsigned int arena_free_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_free;
    unsigned int sand_free_nid;
    unsigned int args_n;
    unsigned int args1;
    zT_22A7C88B_AstNode ptr_arg;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    zT_16 = ctx->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    callee = zT_20;
    zT_21 = callee.kind;
    if ((unsigned char)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_6:
    zT_27 = ctx->store;
    zT_28 = node.child_0;
    zT_31 = zF_2E24BD6B_identNameId(zT_27, zT_28);
    name_id = zT_31;
    zT_33 = "arena_free";
    zT_35 = 10;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s_arena_free = zT_34;
    zT_37 = ctx->interner;
    zT_38 = s_arena_free;
    zT_40 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    arena_free_nid = zT_40;
    zT_42 = "sandFree";
    zT_44 = 8;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    s_sand_free = zT_43;
    zT_46 = ctx->interner;
    zT_47 = s_sand_free;
    zT_49 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    sand_free_nid = zT_49;
    if ((unsigned char)(name_id != arena_free_nid)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_51 = name_id != sand_free_nid;
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_53.has_value = 0;
    return zT_53;
    z_bb_11:
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_152E19CB_astStoreNodeExtraCh(zT_55, zT_56);
    args_n = zT_58;
    if ((unsigned char)(args_n < (unsigned int)(2))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_61.has_value = 0;
    return zT_61;
    z_bb_13:
    zT_63 = ctx->store;
    zT_64 = expr_idx;
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_63, zT_64, (unsigned int)(1));
    args1 = zT_68;
    zT_70 = ctx->store;
    zT_71 = args1;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_70, zT_71);
    ptr_arg = zT_73;
    zT_74 = ptr_arg.kind;
    if ((unsigned char)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_78 = ctx->store;
    zT_79 = args1;
    zT_81 = zF_2E24BD6B_identNameId(zT_78, zT_79);
    zT_82.has_value = 1;
    zT_82.value = zT_81;
    return zT_82;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
}

/* compositeNameId */
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner* interner, unsigned int base_id, unsigned int field_id) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char* zT_47;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_59;
    unsigned char* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u base_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u field_str;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int pos;
    unsigned int i;
    zT_4 = interner;
    zT_5 = base_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    base_str = zT_6;
    zT_8 = interner;
    zT_9 = field_id;
    zT_10 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    field_str = zT_10;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    pos = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_1:
    zT_20 = base_str.len;
    if ((unsigned char)(i < zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_25 = base_str.ptr;
    zT_26 = zT_25[i];
    buf[pos] = zT_26;
    zT_27 = 1;
    zT_29 = pos + (unsigned int)((unsigned int)zT_27);
    pos = zT_29;
    zT_30 = 1;
    zT_32 = i + (unsigned int)((unsigned int)zT_30);
    i = zT_32;
    goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(pos < (unsigned int)(127))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_22 = pos < (unsigned int)(127);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_35 = 46;
    buf[pos] = zT_35;
    zT_36 = 1;
    zT_38 = pos + (unsigned int)((unsigned int)zT_36);
    pos = zT_38;
    goto z_bb_9;
    z_bb_9:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_10;
    z_bb_10:
    zT_42 = field_str.len;
    if ((unsigned char)(i < zT_42)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_47 = field_str.ptr;
    zT_48 = zT_47[i];
    buf[pos] = zT_48;
    zT_49 = 1;
    zT_51 = pos + (unsigned int)((unsigned int)zT_49);
    pos = zT_51;
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_13;
    z_bb_12:
    zT_55 = interner;
    zT_59 = 0;
    zT_60 = (unsigned char*)((unsigned char*)buf) + zT_59;
    zT_61 = pos - zT_59;
    zT_62.ptr = zT_60;
    zT_62.len = zT_61;
    zT_56 = zT_62;
    zT_63 = zF_50C274AF_stringInternerInter(zT_55, zT_56);
    return zT_63;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_44 = pos < (unsigned int)(127);
    goto z_bb_16;
    z_bb_15:
    zT_44 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_44) goto z_bb_11; else goto z_bb_12;
}

/* handleAllocCall */
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int init_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    unsigned char zT_6 = 0;
    zT_2C0927B0_StateMap* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_480593AB_AllocState zT_11;
    zT_4 = ctx;
    zT_5 = init_idx;
    zT_6 = zF_264B254A_isAllocCall(zT_4, zT_5);
    if ((unsigned char)(!zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = state;
    zT_9 = name_id;
    zT_11 = zT_480593AB_AllocState_allocated;
    zT_10 = zT_11;
    zF_ACCFA860_stateMapSet(zT_8, zT_9, zT_10);
    return;
}

/* handleFreeCall */
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_15 = {0};
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_22A7C88B_AstNode zT_20 = {0};
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_480593AB_AllocState zT_28;
    zT_D3EB6303_StringInterner* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35 = {0};
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D3EB6303_StringInterner* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_59;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_2C0927B0_StateMap* zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_480593AB_AllocState zT_81;
    zT_D3EB6303_StringInterner* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86 = {0};
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_102;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_110;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int name_id;
    zT_43E16BE5_Opt_8 current;
    zT_22A7C88B_AstNode node;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_8F083A69_Slice_zT_0B42B2F8_u up2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u umsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli dparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_4 = ctx;
    zT_5 = expr_idx;
    zT_6 = zF_E445D5FB_isFreeCall(zT_4, zT_5);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = zT_6.value;
    goto z_bb_3;
    z_bb_3:
    name_id = zT_8;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_13 = state;
    zT_14 = name_id;
    zT_15 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    current = zT_15;
    zT_17 = ctx->store;
    zT_18 = expr_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_17, zT_18);
    node = zT_20;
    zT_21 = current.has_value;
    if (zT_21) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_83 = ctx->interner;
    zT_84 = name_id;
    zT_86 = zF_9134020D_stringInternerGet(zT_83, zT_84);
    pn = zT_86;
    zT_88 = "freeing untracked pointer '";
    zT_90 = 27;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    up1 = zT_89;
    zT_92 = "'";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    up2 = zT_93;
    zT_97 = 0;
    zT_96[zT_97] = up1;
    zT_98 = 1;
    zT_96[zT_98] = pn;
    zT_99 = 2;
    zT_96[zT_99] = up2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_96[_i];
        _i++;
    }
}
    zT_104 = ctx->diag;
    zT_101 = zT_104->interner;
    zT_106 = 0;
    zT_107 = uparts + zT_106;
    zT_102 = zT_107;
    zT_109 = zF_8C4BFF7C_diagnosticBuilderMa(zT_101, zT_102, (unsigned int)(3));
    umsg = zT_109;
    zT_110 = ctx->diag;
    zT_114 = node.span_start;
    zT_124 = node.span_start;
    zT_125 = node.span_len;
    zT_116 = umsg;
    (void)zF_C82559AC_diagnosticCollector(zT_110, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6006_FREEING_UNTRACKED)), (unsigned int)(0), zT_114, (unsigned int)(zT_124 + (unsigned int)((unsigned int)zT_125)), zT_116);
    goto z_bb_7;
    z_bb_9:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_480593AB_AllocState_freed;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    return;
    z_bb_10:
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_freed))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ctx->interner;
    zT_33 = name_id;
    zT_35 = zF_9134020D_stringInternerGet(zT_32, zT_33);
    pn = zT_35;
    zT_37 = "double free of pointer '";
    zT_39 = 24;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    dp1 = zT_38;
    zT_41 = "'";
    zT_43 = 1;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    dp2 = zT_42;
    zT_46 = 0;
    zT_45[zT_46] = dp1;
    zT_47 = 1;
    zT_45[zT_47] = pn;
    zT_48 = 2;
    zT_45[zT_48] = dp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        dparts[_i] = zT_45[_i];
        _i++;
    }
}
    zT_53 = ctx->diag;
    zT_50 = zT_53->interner;
    zT_55 = 0;
    zT_56 = dparts + zT_55;
    zT_51 = zT_56;
    zT_58 = zF_8C4BFF7C_diagnosticBuilderMa(zT_50, zT_51, (unsigned int)(3));
    dmsg = zT_58;
    zT_59 = ctx->diag;
    zT_63 = node.span_start;
    zT_73 = node.span_start;
    zT_74 = node.span_len;
    zT_65 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_59, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2005_DOUBLE_FREE)), (unsigned int)(0), zT_63, (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74)), zT_65);
    return;
    z_bb_12:
    zT_78 = state;
    zT_79 = name_id;
    zT_81 = zT_480593AB_AllocState_freed;
    zT_80 = zT_81;
    zF_ACCFA860_stateMapSet(zT_78, zT_79, zT_80);
    goto z_bb_7;
}

/* checkLeaksOnScopeExit */
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state) {
    zT_2C0927B0_StateMap* zT_3;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_6B392E0E_StateEntry* zT_11;
    zT_6B392E0E_StateEntry zT_12;
    unsigned char zT_13;
    zT_D3EB6303_StringInterner* zT_17;
    unsigned int zT_18;
    zT_6B392E0E_StateEntry* zT_20;
    zT_6B392E0E_StateEntry zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_63;
    unsigned int zT_65;
    zT_92FBD55B_Slice_zT_6B392E0E_S entries;
    unsigned int ei;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli lparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_3 = state;
    zT_4 = zF_F0E7F434_stateMapGetEntries(zT_3);
    entries = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    ei = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = entries.len;
    if ((unsigned char)(ei < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = entries.ptr;
    zT_12 = zT_11[ei];
    zT_13 = zT_12.state;
    if ((unsigned char)(zT_13 == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_63 = 1;
    zT_65 = ei + (unsigned int)((unsigned int)zT_63);
    ei = zT_65;
    goto z_bb_1;
    z_bb_5:
    zT_17 = ctx->interner;
    zT_20 = entries.ptr;
    zT_21 = zT_20[ei];
    zT_18 = zT_21.name_id;
    zT_23 = zF_9134020D_stringInternerGet(zT_17, zT_18);
    pn = zT_23;
    zT_25 = "memory leak: pointer '";
    zT_27 = 22;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    lp1 = zT_26;
    zT_29 = "' not freed";
    zT_31 = 11;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    lp2 = zT_30;
    zT_34 = 0;
    zT_33[zT_34] = lp1;
    zT_35 = 1;
    zT_33[zT_35] = pn;
    zT_36 = 2;
    zT_33[zT_36] = lp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        lparts[_i] = zT_33[_i];
        _i++;
    }
}
    zT_41 = ctx->diag;
    zT_38 = zT_41->interner;
    zT_43 = 0;
    zT_44 = lparts + zT_43;
    zT_39 = zT_44;
    zT_46 = zF_8C4BFF7C_diagnosticBuilderMa(zT_38, zT_39, (unsigned int)(3));
    lmsg = zT_46;
    zT_47 = ctx->diag;
    zT_53 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_47, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_53);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* handleAllocAssign */
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    zT_2C0927B0_StateMap* zT_27;
    unsigned int zT_28;
    zT_43E16BE5_Opt_8 zT_29 = {0};
    unsigned char zT_30;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38 = {0};
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_54;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_62;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_7E2F335A_AnalyzerContext* zT_81;
    unsigned int zT_82;
    unsigned char zT_83 = 0;
    zT_2C0927B0_StateMap* zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    zT_480593AB_AllocState zT_87;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    zT_2C0927B0_StateMap* zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    zT_480593AB_AllocState zT_102;
    zT_2C0927B0_StateMap* zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    zT_480593AB_AllocState zT_106;
    zT_22A7C88B_AstNode node;
    unsigned int lhs_idx;
    unsigned int rhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int lhs_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u op1;
    zT_8F083A69_Slice_zT_0B42B2F8_u op2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli oparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_22A7C88B_AstNode rhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_0;
    lhs_idx = zT_9;
    zT_11 = node.child_1;
    rhs_idx = zT_11;
    zT_13 = ctx->store;
    zT_14 = lhs_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    lhs_node = zT_16;
    zT_17 = lhs_node.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_22 = ctx->store;
    zT_23 = lhs_idx;
    zT_25 = zF_2E24BD6B_identNameId(zT_22, zT_23);
    lhs_name_id = zT_25;
    zT_27 = state;
    zT_28 = lhs_name_id;
    zT_29 = zF_2EC17ECC_stateMapGet(zT_27, zT_28);
    current = zT_29;
    zT_30 = current.has_value;
    if (zT_30) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_81 = ctx;
    zT_82 = rhs_idx;
    zT_83 = zF_264B254A_isAllocCall(zT_81, zT_82);
    if (zT_83) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_35 = ctx->interner;
    zT_36 = lhs_name_id;
    zT_38 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    pn = zT_38;
    zT_40 = "memory leak: pointer '";
    zT_42 = 22;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    op1 = zT_41;
    zT_44 = "' overwritten before free";
    zT_46 = 25;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    op2 = zT_45;
    zT_49 = 0;
    zT_48[zT_49] = op1;
    zT_50 = 1;
    zT_48[zT_50] = pn;
    zT_51 = 2;
    zT_48[zT_51] = op2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        oparts[_i] = zT_48[_i];
        _i++;
    }
}
    zT_56 = ctx->diag;
    zT_53 = zT_56->interner;
    zT_58 = 0;
    zT_59 = oparts + zT_58;
    zT_54 = zT_59;
    zT_61 = zF_8C4BFF7C_diagnosticBuilderMa(zT_53, zT_54, (unsigned int)(3));
    lmsg = zT_61;
    zT_62 = ctx->diag;
    zT_66 = node.span_start;
    zT_76 = node.span_start;
    zT_77 = node.span_len;
    zT_68 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_62, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), zT_66, (unsigned int)(zT_76 + (unsigned int)((unsigned int)zT_77)), zT_68);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_84 = state;
    zT_85 = lhs_name_id;
    zT_87 = zT_480593AB_AllocState_allocated;
    zT_86 = zT_87;
    zF_ACCFA860_stateMapSet(zT_84, zT_85, zT_86);
    return;
    z_bb_8:
    if ((unsigned char)(rhs_idx != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_91 = ctx->store;
    zT_92 = rhs_idx;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    rhs_node = zT_94;
    zT_95 = rhs_node.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_103 = state;
    zT_104 = lhs_name_id;
    zT_106 = zT_480593AB_AllocState_unknown;
    zT_105 = zT_106;
    zF_ACCFA860_stateMapSet(zT_103, zT_104, zT_105);
    return;
    z_bb_11:
    zT_99 = state;
    zT_100 = lhs_name_id;
    zT_102 = zT_480593AB_AllocState_untracked;
    zT_101 = zT_102;
    zF_ACCFA860_stateMapSet(zT_99, zT_100, zT_101);
    return;
    z_bb_12:
    goto z_bb_10;
}

/* handleOwnershipReturn */
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int ret_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_2C0927B0_StateMap* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    unsigned int zT_20 = 0;
    zT_43E16BE5_Opt_8 zT_21 = {0};
    unsigned char zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_480593AB_AllocState zT_33;
    zT_22A7C88B_AstNode node;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    if ((unsigned char)(ret_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = ret_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = state;
    zT_17 = ctx->store;
    zT_18 = ret_expr_idx;
    zT_20 = zF_2E24BD6B_identNameId(zT_17, zT_18);
    zT_16 = zT_20;
    zT_21 = zF_2EC17ECC_stateMapGet(zT_15, zT_16);
    current = zT_21;
    zT_22 = current.has_value;
    if (zT_22) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = ret_expr_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_33 = zT_480593AB_AllocState_returned_val;
    zT_28 = zT_33;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* handleOwnershipPass */
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int fn_call_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_30 = 0;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35 = {0};
    zT_8143F551_AstKind zT_36;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_44 = 0;
    zT_2C0927B0_StateMap* zT_46;
    unsigned int zT_47;
    zT_43E16BE5_Opt_8 zT_48 = {0};
    unsigned char zT_49;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_480593AB_AllocState zT_56;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_D3EB6303_StringInterner* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84 = {0};
    unsigned char zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    zT_F85C5DED_DiagnosticCollector* zT_91;
    unsigned char zT_92;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_104;
    unsigned int zT_105;
    int zT_109;
    unsigned int zT_111;
    zT_22A7C88B_AstNode node;
    unsigned int args_n;
    unsigned int ai;
    unsigned int args_i;
    zT_22A7C88B_AstNode arg_node;
    unsigned int arg_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmsg;
    unsigned char warn_lvl;
    if ((unsigned char)(fn_call_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = fn_call_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ctx->store;
    zT_16 = fn_call_idx;
    zT_18 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    args_n = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    ai = zT_21;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = ctx->store;
    zT_26 = fn_call_idx;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_25, zT_26, (unsigned int)((unsigned int)ai));
    args_i = zT_30;
    zT_32 = ctx->store;
    zT_33 = args_i;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    arg_node = zT_35;
    zT_36 = arg_node.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_109 = 1;
    zT_111 = ai + (unsigned int)((unsigned int)zT_109);
    ai = zT_111;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_41 = ctx->store;
    zT_42 = args_i;
    zT_44 = zF_2E24BD6B_identNameId(zT_41, zT_42);
    arg_name_id = zT_44;
    zT_46 = state;
    zT_47 = arg_name_id;
    zT_48 = zF_2EC17ECC_stateMapGet(zT_46, zT_47);
    current = zT_48;
    zT_49 = current.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_8;
    z_bb_13:
    zT_53 = state;
    zT_54 = arg_name_id;
    zT_56 = zT_480593AB_AllocState_transferred;
    zT_55 = zT_56;
    zF_ACCFA860_stateMapSet(zT_53, zT_54, zT_55);
    zT_58 = ctx->interner;
    zT_59 = arg_name_id;
    zT_61 = zF_9134020D_stringInternerGet(zT_58, zT_59);
    pn = zT_61;
    zT_63 = "ownership of '";
    zT_65 = 14;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    tp1 = zT_64;
    zT_67 = "' transferred to function";
    zT_69 = 25;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    tp2 = zT_68;
    zT_72 = 0;
    zT_71[zT_72] = tp1;
    zT_73 = 1;
    zT_71[zT_73] = pn;
    zT_74 = 2;
    zT_71[zT_74] = tp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tparts[_i] = zT_71[_i];
        _i++;
    }
}
    zT_79 = ctx->diag;
    zT_76 = zT_79->interner;
    zT_81 = 0;
    zT_82 = tparts + zT_81;
    zT_77 = zT_82;
    zT_84 = zF_8C4BFF7C_diagnosticBuilderMa(zT_76, zT_77, (unsigned int)(3));
    tmsg = zT_84;
    zT_86 = 2;
    warn_lvl = zT_86;
    zT_87 = ctx->warn_all;
    if ((unsigned char)(zT_87 != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_90 = 1;
    warn_lvl = zT_90;
    goto z_bb_16;
    z_bb_16:
    zT_91 = ctx->diag;
    zT_92 = warn_lvl;
    zT_95 = node.span_start;
    zT_104 = node.span_start;
    zT_105 = node.span_len;
    zT_97 = tmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_91, zT_92, (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_INFO_7001_OWNERSHIP_TRANSFERRED)), (unsigned int)(0), zT_95, (unsigned int)(zT_104 + (unsigned int)((unsigned int)zT_105)), zT_97);
    goto z_bb_14;
}

/* deferQueueEnsureCapacity */
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext* ctx, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_0715C9B9_EU_832 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_7A19C4A5_DeferEntry* zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7A19C4A5_DeferEntry* zT_35;
    zT_7A19C4A5_DeferEntry zT_36;
    int zT_37;
    unsigned int zT_39;
    unsigned int nc;
    unsigned char* raw;
    zT_7A19C4A5_DeferEntry* new_items;
    unsigned int i;
    zT_2 = ctx->defer_queue_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = ctx->defer_queue_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = ctx->defer_queue_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = ctx->defer_queue_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_7A19C4A5_DeferEntry*)raw;
    new_items = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    i = zT_32;
    goto z_bb_10;
    z_bb_10:
    zT_33 = ctx->defer_queue_len;
    if ((unsigned char)(i < zT_33)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = ctx->defer_queue_items;
    zT_36 = zT_35[i];
    new_items[i] = zT_36;
    goto z_bb_13;
    z_bb_12:
    ctx->defer_queue_items = new_items;
    ctx->defer_queue_cap = nc;
    return;
    z_bb_13:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_10;
}

/* analyzeSignature */
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_17;
    zT_82915964_anon_238038 zT_18;
    zT_243D6A41_FnProto* zT_19;
    unsigned int zT_20;
    zT_243D6A41_FnProto zT_21;
    unsigned int zT_23;
    unsigned short zT_27;
    zT_79FAE712_u64 zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned int zT_34 = 0;
    int zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_49 = 0;
    zT_22A7C88B_AstNode zT_50 = {0};
    unsigned int zT_52;
    zT_7E2F335A_AnalyzerContext* zT_55;
    unsigned int zT_56;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_63;
    zT_7E2F335A_AnalyzerContext* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode node;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 param_payload;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned int type_expr;
    unsigned int ret_node;
    zT_3 = ctx->store;
    zT_4 = fn_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = fn_node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    proto_idx = zT_15;
    zT_17 = ctx->store;
    zT_18 = zT_17->fn_protos;
    zT_19 = zT_18.items;
    zT_20 = (unsigned int)proto_idx;
    zT_21 = zT_19[zT_20];
    proto = zT_21;
    zT_23 = proto.params_start;
    zT_27 = proto.params_count;
    zT_29 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_23) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_27);
    param_payload = zT_29;
    zT_31 = ctx->store;
    zT_32 = param_payload;
    zT_34 = zF_03CE8CAB_astStoreGetExtraChi(zT_31, zT_32);
    params_n = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    pi = zT_37;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_41 = ctx->store;
    zT_44 = ctx->store;
    zT_45 = param_payload;
    zT_49 = zF_E5B10421_astStoreGetExtraChi(zT_44, zT_45, (unsigned int)((unsigned int)pi));
    zT_42 = zT_49;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_41, zT_42);
    pnode = zT_50;
    zT_52 = pnode.child_0;
    type_expr = zT_52;
    if ((unsigned char)(type_expr != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = proto.return_type_node;
    ret_node = zT_63;
    if ((unsigned char)(ret_node != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_59 = 1;
    zT_61 = pi + (unsigned int)((unsigned int)zT_59);
    pi = zT_61;
    goto z_bb_3;
    z_bb_7:
    zT_55 = ctx;
    zT_56 = type_expr;
    zF_E153ECE7_validateSignatureTy(zT_55, zT_56, (unsigned int)(0));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_66 = ctx;
    zT_67 = ret_node;
    zF_E153ECE7_validateSignatureTy(zT_66, zT_67, (unsigned int)(1));
    goto z_bb_10;
    z_bb_10:
    return;
}

/* validateSignatureType */
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_79FAE712_u64 zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    zT_79FAE712_u64 zT_21;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    unsigned char zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    unsigned char zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_55;
    unsigned char zT_56;
    zT_D3EB6303_StringInterner* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63 = {0};
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_D3EB6303_StringInterner* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_79;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_87;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_33EF6BFB_TypeKind zT_106;
    unsigned char zT_110;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_F85C5DED_DiagnosticCollector* zT_117;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_138;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_F85C5DED_DiagnosticCollector* zT_145;
    unsigned int zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned char* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167;
    zT_D3EB6303_StringInterner* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_172 = 0;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_F85C5DED_DiagnosticCollector* zT_178;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_22A7C88B_AstNode tnode;
    unsigned int name_id;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 tid;
    unsigned int ttid;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u tname;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli iparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u wmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    zT_4 = ctx->store;
    zT_5 = type_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    tnode = zT_7;
    zT_8 = tnode.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = ctx->store;
    zT_14 = type_node_idx;
    zT_16 = zF_2E24BD6B_identNameId(zT_13, zT_14);
    name_id = zT_16;
    zT_18 = (zT_79FAE712_u64)name_id;
    key = zT_18;
    zT_20 = ctx->registry;
    zT_21 = key;
    zT_23 = zF_0EB68360_nameCacheGet(zT_20, zT_21);
    tid = zT_23;
    zT_24 = tid.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    ttid = tid.value;
    zT_27 = ctx->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)ttid;
    zT_30 = zT_28[zT_29];
    ty = zT_30;
    zT_31 = ty.kind;
    if ((unsigned char)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    zT_165 = "anytype";
    zT_167 = 7;
    zT_166.ptr = zT_165;
    zT_166.len = zT_167;
    s_anytype = zT_166;
    zT_169 = ctx->interner;
    zT_170 = s_anytype;
    zT_172 = zF_50C274AF_stringInternerInter(zT_169, zT_170);
    anytype_nid = zT_172;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_31; else goto z_bb_32;
    z_bb_5:
    zT_36 = ty.kind;
    if ((unsigned char)(zT_36 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_6:
    zT_35 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_35) goto z_bb_20; else goto z_bb_21;
    z_bb_8:
    zT_41 = ty.kind;
    zT_40 = zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_10;
    z_bb_9:
    zT_40 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_40) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_46 = ty.kind;
    zT_45 = zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_13;
    z_bb_12:
    zT_45 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_45) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_16;
    z_bb_15:
    zT_50 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_50) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_56 = ty.state;
    zT_55 = zT_56 != (unsigned char)(2);
    goto z_bb_19;
    z_bb_18:
    zT_55 = 0;
    goto z_bb_19;
    z_bb_19:
    zT_35 = zT_55;
    goto z_bb_7;
    z_bb_20:
    zT_60 = ctx->interner;
    zT_61 = name_id;
    zT_63 = zF_9134020D_stringInternerGet(zT_60, zT_61);
    tname = zT_63;
    zT_65 = "incomplete type '";
    zT_67 = 17;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    ip1 = zT_66;
    zT_69 = "' in function signature";
    zT_71 = 23;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    ip2 = zT_70;
    zT_74 = 0;
    zT_73[zT_74] = ip1;
    zT_75 = 1;
    zT_73[zT_75] = tname;
    zT_76 = 2;
    zT_73[zT_76] = ip2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        iparts[_i] = zT_73[_i];
        _i++;
    }
}
    zT_81 = ctx->diag;
    zT_78 = zT_81->interner;
    zT_83 = 0;
    zT_84 = iparts + zT_83;
    zT_79 = zT_84;
    zT_86 = zF_8C4BFF7C_diagnosticBuilderMa(zT_78, zT_79, (unsigned int)(3));
    imsg = zT_86;
    zT_87 = ctx->diag;
    zT_91 = tnode.span_start;
    zT_101 = tnode.span_start;
    zT_102 = tnode.span_len;
    zT_93 = imsg;
    (void)zF_C82559AC_diagnosticCollector(zT_87, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2011_INCOMPLETE_TYPE)), (unsigned int)(0), zT_91, (unsigned int)(zT_101 + (unsigned int)((unsigned int)zT_102)), zT_93);
    goto z_bb_21;
    z_bb_21:
    zT_106 = ty.kind;
    if ((unsigned char)(zT_106 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_110 = is_return == (unsigned int)(0);
    goto z_bb_24;
    z_bb_23:
    zT_110 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_110) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_114 = "void not allowed as parameter type";
    zT_116 = 34;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    vmsg = zT_115;
    zT_117 = ctx->diag;
    zT_121 = tnode.span_start;
    zT_131 = tnode.span_start;
    zT_132 = tnode.span_len;
    zT_123 = vmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_117, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2010_VOID_PARAMETER)), (unsigned int)(0), zT_121, (unsigned int)(zT_131 + (unsigned int)((unsigned int)zT_132)), zT_123);
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(is_return != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_138 = ty.size;
    if ((unsigned char)(zT_138 > (unsigned int)(64))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_4;
    z_bb_29:
    zT_142 = "return type exceeds 64 bytes; may cause issues on MSVC 6.0";
    zT_144 = 58;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    wmsg = zT_143;
    zT_145 = ctx->diag;
    zT_149 = tnode.span_start;
    zT_159 = tnode.span_start;
    zT_160 = tnode.span_len;
    zT_151 = wmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_145, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7010_LARGE_RETURN)), (unsigned int)(0), zT_149, (unsigned int)(zT_159 + (unsigned int)((unsigned int)zT_160)), zT_151);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_175 = "anytype not supported in Z98";
    zT_177 = 28;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    amsg = zT_176;
    zT_178 = ctx->diag;
    zT_182 = tnode.span_start;
    zT_192 = tnode.span_start;
    zT_193 = tnode.span_len;
    zT_184 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_178, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), (unsigned int)(0), zT_182, (unsigned int)(zT_192 + (unsigned int)((unsigned int)zT_193)), zT_184);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_2;
}

/* analyzeExpr */
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20 = 0;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_F85C5DED_DiagnosticCollector* zT_34;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_F85C5DED_DiagnosticCollector* zT_54;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_74;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    zT_7E2F335A_AnalyzerContext* zT_91;
    zT_2C0927B0_StateMap* zT_92;
    unsigned int zT_93;
    zT_7E2F335A_AnalyzerContext* zT_98;
    zT_2C0927B0_StateMap* zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    unsigned int zT_109 = 0;
    int zT_111;
    unsigned int zT_112;
    zT_7E2F335A_AnalyzerContext* zT_115;
    zT_2C0927B0_StateMap* zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_123 = 0;
    int zT_124;
    unsigned int zT_126;
    zT_6B0A7D14_AstStore* zT_131;
    unsigned int zT_132;
    unsigned int zT_134 = 0;
    int zT_136;
    unsigned int zT_137;
    zT_7E2F335A_AnalyzerContext* zT_140;
    zT_2C0927B0_StateMap* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_148 = 0;
    int zT_149;
    unsigned int zT_151;
    zT_7E2F335A_AnalyzerContext* zT_155;
    zT_2C0927B0_StateMap* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_160;
    unsigned int zT_161;
    zT_22A7C88B_AstNode zT_164 = {0};
    zT_8143F551_AstKind zT_165;
    zT_7E2F335A_AnalyzerContext* zT_170;
    zT_2C0927B0_StateMap* zT_171;
    unsigned int zT_172;
    unsigned char zT_174 = 0;
    zT_2C0927B0_StateMap* zT_175;
    unsigned int zT_176;
    unsigned char zT_177;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    unsigned int zT_182 = 0;
    unsigned int zT_183;
    unsigned char zT_186;
    zT_8143F551_AstKind zT_187;
    unsigned char zT_190 = 0;
    zT_7E2F335A_AnalyzerContext* zT_191;
    zT_2C0927B0_StateMap* zT_192;
    unsigned int zT_193;
    unsigned int zT_195;
    unsigned char zT_198;
    zT_8143F551_AstKind zT_199;
    unsigned char zT_202 = 0;
    zT_7E2F335A_AnalyzerContext* zT_203;
    zT_2C0927B0_StateMap* zT_204;
    unsigned int zT_205;
    unsigned int zT_207;
    unsigned char zT_210;
    zT_8143F551_AstKind zT_211;
    unsigned char zT_214 = 0;
    zT_7E2F335A_AnalyzerContext* zT_215;
    zT_2C0927B0_StateMap* zT_216;
    unsigned int zT_217;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char st;
    unsigned int start;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int args_n;
    unsigned int ai;
    unsigned int bargs_n;
    unsigned int bi;
    zT_22A7C88B_AstNode lhs_node;
    unsigned char new_st;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_0;
    zT_20 = zF_0619AC1C_classifyExpr(zT_16, zT_17, zT_18);
    st = zT_20;
    zT_22 = node.span_start;
    start = zT_22;
    zT_24 = node.span_start;
    zT_25 = node.span_len;
    zT_27 = zT_24 + (unsigned int)((unsigned int)zT_25);
    end = zT_27;
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_is_null))) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_31 = "definite null pointer dereference";
    zT_33 = 33;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    msg = zT_32;
    zT_34 = ctx->diag;
    zT_38 = start;
    zT_39 = end;
    zT_40 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_34, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2004_DEFINITE_NULL_DEREF)), (unsigned int)(0), zT_38, zT_39, zT_40);
    goto z_bb_6;
    z_bb_6:
    return;
    z_bb_7:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_uninit))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_51 = "dereference of uninitialized pointer";
    zT_53 = 36;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    msg = zT_52;
    zT_54 = ctx->diag;
    zT_58 = start;
    zT_59 = end;
    zT_60 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_54, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6001_UNINIT_DEREF)), (unsigned int)(0), zT_58, zT_59, zT_60);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_maybe))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_71 = "potential null pointer dereference";
    zT_73 = 34;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    msg = zT_72;
    zT_74 = ctx->diag;
    zT_78 = start;
    zT_79 = end;
    zT_80 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_74, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6002_POTENTIAL_NULL_DEREF)), (unsigned int)(0), zT_78, zT_79, zT_80);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_91 = ctx;
    zT_92 = state;
    zT_93 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_91, zT_92, zT_93);
    return;
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_98 = ctx;
    zT_99 = state;
    zT_100 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_98, zT_99, zT_100);
    return;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_106 = ctx->store;
    zT_107 = expr_idx;
    zT_109 = zF_152E19CB_astStoreNodeExtraCh(zT_106, zT_107);
    args_n = zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    ai = zT_112;
    goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_115 = ctx;
    zT_116 = state;
    zT_118 = ctx->store;
    zT_119 = expr_idx;
    zT_123 = zF_B10B1BC1_astStoreNodeExtraCh(zT_118, zT_119, (unsigned int)((unsigned int)ai));
    zT_117 = zT_123;
    zF_8D5B6C98_analyzeExpr(zT_115, zT_116, zT_117);
    goto z_bb_22;
    z_bb_21:
    return;
    z_bb_22:
    zT_124 = 1;
    zT_126 = ai + (unsigned int)((unsigned int)zT_124);
    ai = zT_126;
    goto z_bb_19;
    z_bb_23:
    zT_131 = ctx->store;
    zT_132 = expr_idx;
    zT_134 = zF_152E19CB_astStoreNodeExtraCh(zT_131, zT_132);
    bargs_n = zT_134;
    zT_136 = 0;
    zT_137 = (unsigned int)zT_136;
    bi = zT_137;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)bargs_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_140 = ctx;
    zT_141 = state;
    zT_143 = ctx->store;
    zT_144 = expr_idx;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_143, zT_144, (unsigned int)((unsigned int)bi));
    zT_142 = zT_148;
    zF_8D5B6C98_analyzeExpr(zT_140, zT_141, zT_142);
    goto z_bb_28;
    z_bb_27:
    return;
    z_bb_28:
    zT_149 = 1;
    zT_151 = bi + (unsigned int)((unsigned int)zT_149);
    bi = zT_151;
    goto z_bb_25;
    z_bb_29:
    zT_155 = ctx;
    zT_156 = state;
    zT_157 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_155, zT_156, zT_157);
    zT_160 = ctx->store;
    zT_161 = node.child_0;
    zT_164 = zF_FCDD1D35_astStoreNodeAt(zT_160, zT_161);
    lhs_node = zT_164;
    zT_165 = lhs_node.kind;
    if ((unsigned char)(zT_165 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_183 = node.child_0;
    if ((unsigned char)(zT_183 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_170 = ctx;
    zT_171 = state;
    zT_172 = node.child_1;
    zT_174 = zF_0619AC1C_classifyExpr(zT_170, zT_171, zT_172);
    new_st = zT_174;
    zT_175 = state;
    zT_178 = ctx->store;
    zT_179 = node.child_0;
    zT_182 = zF_2E24BD6B_identNameId(zT_178, zT_179);
    zT_176 = zT_182;
    zT_177 = new_st;
    zF_ACCFA860_stateMapSet(zT_175, zT_176, zT_177);
    goto z_bb_32;
    z_bb_32:
    return;
    z_bb_33:
    zT_187 = kind;
    zT_190 = zF_C395F6FD_nodeChildIsNode(zT_187, (unsigned char)(0));
    zT_186 = zT_190;
    goto z_bb_35;
    z_bb_34:
    zT_186 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_186) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_191 = ctx;
    zT_192 = state;
    zT_193 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_191, zT_192, zT_193);
    goto z_bb_37;
    z_bb_37:
    zT_195 = node.child_1;
    if ((unsigned char)(zT_195 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_199 = kind;
    zT_202 = zF_C395F6FD_nodeChildIsNode(zT_199, (unsigned char)(1));
    zT_198 = zT_202;
    goto z_bb_40;
    z_bb_39:
    zT_198 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_198) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_203 = ctx;
    zT_204 = state;
    zT_205 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_203, zT_204, zT_205);
    goto z_bb_42;
    z_bb_42:
    zT_207 = node.child_2;
    if ((unsigned char)(zT_207 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_211 = kind;
    zT_214 = zF_C395F6FD_nodeChildIsNode(zT_211, (unsigned char)(2));
    zT_210 = zT_214;
    goto z_bb_45;
    z_bb_44:
    zT_210 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_210) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_215 = ctx;
    zT_216 = state;
    zT_217 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_215, zT_216, zT_217);
    goto z_bb_47;
    z_bb_47:
    return;
}

/* classifyExpr */
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_12;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_79FAE712_u64 zT_44 = 0;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58 = 0;
    zT_43E16BE5_Opt_8 zT_59 = {0};
    unsigned char zT_60;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_79FAE712_u64 val;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(zT_E48CAD8A_PtrState_uninit);
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = expr_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = node.kind;
    kind = zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_41 = ctx->store;
    zT_42 = expr_idx;
    zT_44 = zF_678B9A72_astStoreIntValue(zT_41, zT_42);
    val = zT_44;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_18:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_19:
    zT_53 = state;
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_2E24BD6B_identNameId(zT_55, zT_56);
    zT_54 = zT_58;
    zT_59 = zF_2EC17ECC_stateMapGet(zT_53, zT_54);
    result = zT_59;
    zT_60 = result.has_value;
    if (zT_60) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_21:
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
}

/* isNullExpr */
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_21 = 0;
    zT_22A7C88B_AstNode node;
    zT_79FAE712_u64 val;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = store;
    zT_20 = idx;
    zT_21 = zF_678B9A72_astStoreIntValue(zT_19, zT_20);
    val = zT_21;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* isIdentExpr */
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_15 = 0;
    zT_BAEE192E_Opt_10 zT_16;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    zT_22A7C88B_AstNode node;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = store;
    zT_14 = idx;
    zT_15 = zF_2E24BD6B_identNameId(zT_13, zT_14);
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_4:
    zT_17.has_value = 0;
    return zT_17;
}

/* detectNullGuard */
zT_D0D475FB_Opt_118 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore* store, unsigned int cond_idx) {
    zT_D0D475FB_Opt_118 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned char zT_18 = 0;
    int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    zT_438E6589_NullGuard zT_28;
    unsigned char zT_29;
    zT_D0D475FB_Opt_118 zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    int zT_36;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_42 = {0};
    unsigned char zT_43;
    zT_438E6589_NullGuard zT_45;
    unsigned char zT_46;
    zT_D0D475FB_Opt_118 zT_47;
    zT_D0D475FB_Opt_118 zT_48 = {0};
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned char zT_56 = 0;
    int zT_57;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_BAEE192E_Opt_10 zT_63 = {0};
    unsigned char zT_64;
    zT_438E6589_NullGuard zT_66;
    unsigned char zT_67;
    zT_D0D475FB_Opt_118 zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned char zT_73 = 0;
    int zT_74;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    zT_438E6589_NullGuard zT_83;
    unsigned char zT_84;
    zT_D0D475FB_Opt_118 zT_85;
    zT_D0D475FB_Opt_118 zT_86 = {0};
    zT_438E6589_NullGuard zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_93 = 0;
    unsigned char zT_94;
    zT_D0D475FB_Opt_118 zT_95;
    zT_6B0A7D14_AstStore* zT_100;
    unsigned int zT_101;
    zT_D0D475FB_Opt_118 zT_103 = {0};
    unsigned char zT_104;
    zT_438E6589_NullGuard zT_106;
    unsigned int zT_107;
    int zT_108;
    unsigned char zT_109;
    unsigned char zT_111;
    zT_D0D475FB_Opt_118 zT_112;
    zT_D0D475FB_Opt_118 zT_113 = {0};
    zT_D0D475FB_Opt_118 zT_114 = {0};
    zT_22A7C88B_AstNode cond;
    zT_8143F551_AstKind ck;
    unsigned char n0;
    zT_BAEE192E_Opt_10 id1;
    unsigned char n1;
    unsigned int nid;
    zT_BAEE192E_Opt_10 id0;
    zT_D0D475FB_Opt_118 inner;
    zT_438E6589_NullGuard g;
    if ((unsigned char)(cond_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = cond_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    cond = zT_8;
    zT_10 = cond.kind;
    ck = zT_10;
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = store;
    zT_16 = cond.child_0;
    zT_18 = zF_F32BD543_isNullExpr(zT_15, zT_16);
    n0 = zT_18;
    zT_19 = 0;
    if ((unsigned char)(n0 != zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_22 = store;
    zT_23 = cond.child_1;
    zT_25 = zF_7B65B82E_isIdentExpr(zT_22, zT_23);
    id1 = zT_25;
    zT_26 = id1.has_value;
    if (zT_26) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_32 = store;
    zT_33 = cond.child_1;
    zT_35 = zF_F32BD543_isNullExpr(zT_32, zT_33);
    n1 = zT_35;
    zT_36 = 0;
    if ((unsigned char)(n1 != zT_36)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    nid = id1.value;
    zT_28.name_id = nid;
    zT_29 = 1;
    zT_28.is_not_null = zT_29;
    zT_30.has_value = 1;
    zT_30.value = zT_28;
    return zT_30;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_39 = store;
    zT_40 = cond.child_0;
    zT_42 = zF_7B65B82E_isIdentExpr(zT_39, zT_40);
    id0 = zT_42;
    zT_43 = id0.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_11:
    nid = id0.value;
    zT_45.name_id = nid;
    zT_46 = 1;
    zT_45.is_not_null = zT_46;
    zT_47.has_value = 1;
    zT_47.value = zT_45;
    return zT_47;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_53 = store;
    zT_54 = cond.child_0;
    zT_56 = zF_F32BD543_isNullExpr(zT_53, zT_54);
    n0 = zT_56;
    zT_57 = 0;
    if ((unsigned char)(n0 != zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    zT_60 = store;
    zT_61 = cond.child_1;
    zT_63 = zF_7B65B82E_isIdentExpr(zT_60, zT_61);
    id1 = zT_63;
    zT_64 = id1.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_70 = store;
    zT_71 = cond.child_1;
    zT_73 = zF_F32BD543_isNullExpr(zT_70, zT_71);
    n1 = zT_73;
    zT_74 = 0;
    if ((unsigned char)(n1 != zT_74)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    nid = id1.value;
    zT_66.name_id = nid;
    zT_67 = 0;
    zT_66.is_not_null = zT_67;
    zT_68.has_value = 1;
    zT_68.value = zT_66;
    return zT_68;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_77 = store;
    zT_78 = cond.child_0;
    zT_80 = zF_7B65B82E_isIdentExpr(zT_77, zT_78);
    id0 = zT_80;
    zT_81 = id0.has_value;
    if (zT_81) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_86.has_value = 0;
    return zT_86;
    z_bb_21:
    nid = id0.value;
    zT_83.name_id = nid;
    zT_84 = 0;
    zT_83.is_not_null = zT_84;
    zT_85.has_value = 1;
    zT_85.value = zT_83;
    return zT_85;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_91 = store;
    zT_92 = cond_idx;
    zT_93 = zF_2E24BD6B_identNameId(zT_91, zT_92);
    zT_90.name_id = zT_93;
    zT_94 = 1;
    zT_90.is_not_null = zT_94;
    zT_95.has_value = 1;
    zT_95.value = zT_90;
    return zT_95;
    z_bb_24:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_100 = store;
    zT_101 = cond.child_0;
    zT_103 = zF_8D299A60_detectNullGuard(zT_100, zT_101);
    inner = zT_103;
    zT_104 = inner.has_value;
    if (zT_104) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_27:
    g = inner.value;
    zT_107 = g.name_id;
    zT_106.name_id = zT_107;
    zT_108 = 1;
    zT_109 = g.is_not_null;
    zT_111 = (unsigned char)(unsigned char)(zT_108 - zT_109);
    zT_106.is_not_null = zT_111;
    zT_112.has_value = 1;
    zT_112.value = zT_106;
    return zT_112;
    z_bb_28:
    zT_113.has_value = 0;
    return zT_113;
}

/* applyNullGuardRefinement */
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore* store, unsigned int cond_idx, zT_2C0927B0_StateMap* then_state, zT_2C0927B0_StateMap* else_state) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_D0D475FB_Opt_118 zT_7 = {0};
    unsigned char zT_8;
    unsigned char zT_10;
    int zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zT_E48CAD8A_PtrState zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_E48CAD8A_PtrState zT_22;
    zT_2C0927B0_StateMap* zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    zT_E48CAD8A_PtrState zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    zT_E48CAD8A_PtrState zT_32;
    zT_D0D475FB_Opt_118 guard;
    zT_438E6589_NullGuard g;
    zT_5 = store;
    zT_6 = cond_idx;
    zT_7 = zF_8D299A60_detectNullGuard(zT_5, zT_6);
    guard = zT_7;
    zT_8 = guard.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    g = guard.value;
    zT_10 = g.is_not_null;
    zT_11 = 0;
    if ((unsigned char)(zT_10 != zT_11)) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_13 = then_state;
    zT_14 = g.name_id;
    zT_17 = zT_E48CAD8A_PtrState_safe;
    zT_15 = zT_17;
    zF_ACCFA860_stateMapSet(zT_13, zT_14, zT_15);
    zT_18 = else_state;
    zT_19 = g.name_id;
    zT_22 = zT_E48CAD8A_PtrState_is_null;
    zT_20 = zT_22;
    zF_ACCFA860_stateMapSet(zT_18, zT_19, zT_20);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = then_state;
    zT_24 = g.name_id;
    zT_27 = zT_E48CAD8A_PtrState_is_null;
    zT_25 = zT_27;
    zF_ACCFA860_stateMapSet(zT_23, zT_24, zT_25);
    zT_28 = else_state;
    zT_29 = g.name_id;
    zT_32 = zT_E48CAD8A_PtrState_safe;
    zT_30 = zT_32;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, zT_30);
    goto z_bb_4;
}

/* handleNullVarDecl */
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_14;
    zT_7E2F335A_AnalyzerContext* zT_18;
    zT_2C0927B0_StateMap* zT_19;
    unsigned int zT_20;
    unsigned char zT_21 = 0;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_E48CAD8A_PtrState zT_28;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int init_idx;
    unsigned char st;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = ctx->store;
    zT_10 = node_idx;
    zT_12 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    name_id = zT_12;
    zT_14 = node.child_1;
    init_idx = zT_14;
    if ((unsigned char)(init_idx != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_18 = ctx;
    zT_19 = state;
    zT_20 = init_idx;
    zT_21 = zF_0619AC1C_classifyExpr(zT_18, zT_19, zT_20);
    st = zT_21;
    zT_22 = state;
    zT_23 = name_id;
    zT_24 = st;
    zF_ACCFA860_stateMapSet(zT_22, zT_23, zT_24);
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_E48CAD8A_PtrState_uninit;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_2;
}

/* handleNullAssign */
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    zT_7E2F335A_AnalyzerContext* zT_11;
    zT_2C0927B0_StateMap* zT_12;
    unsigned int zT_13;
    unsigned char zT_14 = 0;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_8143F551_AstKind zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int rhs;
    unsigned char rhs_state;
    unsigned int lhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_1;
    rhs = zT_9;
    zT_11 = ctx;
    zT_12 = state;
    zT_13 = rhs;
    zT_14 = zF_0619AC1C_classifyExpr(zT_11, zT_12, zT_13);
    rhs_state = zT_14;
    zT_16 = node.child_0;
    lhs_idx = zT_16;
    zT_18 = ctx->store;
    zT_19 = lhs_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    lhs_node = zT_21;
    zT_22 = lhs_node.kind;
    if ((unsigned char)(zT_22 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = lhs_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_28 = rhs_state;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* executeDeferQueue */
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int target_depth, unsigned char is_error, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_12;
    zT_7A19C4A5_DeferEntry* zT_14;
    zT_7A19C4A5_DeferEntry zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_7E2F335A_AnalyzerContext* zT_21;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    zT_7E2F335A_AnalyzerContext* zT_31;
    zT_2C0927B0_StateMap* zT_32;
    unsigned int zT_33;
    unsigned int idx;
    zT_7A19C4A5_DeferEntry entry;
    ctx->in_defer_exec = (unsigned char)(1);
    goto z_bb_1;
    z_bb_1:
    zT_6 = ctx->defer_queue_len;
    if ((unsigned char)(zT_6 > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = ctx->defer_queue_len;
    zT_12 = zT_10 - (unsigned int)(1);
    idx = zT_12;
    zT_14 = ctx->defer_queue_items;
    zT_15 = zT_14[idx];
    entry = zT_15;
    zT_16 = entry.scope_depth;
    if ((unsigned char)(zT_16 < target_depth)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    ctx->in_defer_exec = (unsigned char)(0);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    ctx->defer_queue_len = idx;
    zT_18 = entry.kind;
    if ((unsigned char)(zT_18 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_21 = ctx;
    zT_22 = state;
    zT_23 = entry.stmt_idx;
    visit_fn(zT_21, zT_22, zT_23);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_25 = entry.kind;
    if ((unsigned char)(zT_25 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_28 = is_error != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_31 = ctx;
    zT_32 = state;
    zT_33 = entry.stmt_idx;
    visit_fn(zT_31, zT_32, zT_33);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
}

/* walkBlock */
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int block_idx, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_15;
    zT_2C0927B0_StateMap* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_28 = 0;
    int zT_30;
    unsigned int zT_31;
    zT_7E2F335A_AnalyzerContext* zT_34;
    zT_2C0927B0_StateMap* zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    zT_7E2F335A_AnalyzerContext* zT_46;
    zT_2C0927B0_StateMap* zT_47;
    unsigned int zT_48;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_50;
    unsigned char zT_52;
    zT_7E2F335A_AnalyzerContext* zT_55;
    zT_2C0927B0_StateMap* zT_56;
    zT_22A7C88B_AstNode node;
    unsigned int saved_depth;
    unsigned int children_n;
    unsigned int i;
    if ((unsigned char)(block_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = block_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_16 = state;
    zT_17 = block_idx;
    visit_fn(zT_15, zT_16, zT_17);
    return;
    z_bb_4:
    zT_19 = ctx->current_depth;
    saved_depth = zT_19;
    zT_20 = ctx->current_depth;
    zT_21 = 1;
    ctx->current_depth = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_25 = ctx->store;
    zT_26 = block_idx;
    zT_28 = zF_152E19CB_astStoreNodeExtraCh(zT_25, zT_26);
    children_n = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_34 = ctx;
    zT_35 = state;
    zT_37 = ctx->store;
    zT_38 = block_idx;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)i));
    zT_36 = zT_42;
    visit_fn(zT_34, zT_35, zT_36);
    goto z_bb_8;
    z_bb_7:
    zT_46 = ctx;
    zT_47 = state;
    zT_48 = saved_depth;
    zT_50 = visit_fn;
    zF_332F08BB_executeDeferQueue(zT_46, zT_47, zT_48, (unsigned char)(0), zT_50);
    zT_52 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_52 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_43 = 1;
    zT_45 = i + (unsigned int)((unsigned int)zT_43);
    i = zT_45;
    goto z_bb_5;
    z_bb_9:
    zT_55 = ctx;
    zT_56 = state;
    zF_628B7574_checkLeaksOnScopeEx(zT_55, zT_56);
    goto z_bb_10;
    z_bb_10:
    ctx->current_depth = saved_depth;
    return;
}

/* visitStatement */
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx, zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned char zT_17;
    zT_7E2F335A_AnalyzerContext* zT_21;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    zT_2C0927B0_StateMap* zT_26;
    zT_3E40CD83_Sand* zT_27;
    zT_2C0927B0_StateMap* zT_29 = 0;
    zT_2C0927B0_StateMap* zT_31;
    zT_3E40CD83_Sand* zT_32;
    zT_2C0927B0_StateMap* zT_34 = 0;
    unsigned char zT_35;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_2C0927B0_StateMap* zT_40;
    zT_2C0927B0_StateMap* zT_41;
    zT_2C0927B0_StateMap* zT_47;
    unsigned int zT_48;
    unsigned char zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    zT_E48CAD8A_PtrState zT_54;
    zT_7E2F335A_AnalyzerContext* zT_55;
    zT_2C0927B0_StateMap* zT_56;
    unsigned int zT_57;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_58;
    unsigned int zT_60;
    zT_7E2F335A_AnalyzerContext* zT_63;
    zT_2C0927B0_StateMap* zT_64;
    unsigned int zT_65;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_66;
    zT_2C0927B0_StateMap* zT_68;
    zT_2C0927B0_StateMap* zT_69;
    zT_2C0927B0_StateMap* zT_70;
    unsigned char zT_76;
    zT_7E2F335A_AnalyzerContext* zT_80;
    zT_2C0927B0_StateMap* zT_81;
    unsigned int zT_82;
    zT_2C0927B0_StateMap* zT_85;
    zT_3E40CD83_Sand* zT_86;
    zT_2C0927B0_StateMap* zT_88 = 0;
    unsigned char zT_89;
    unsigned char zT_92;
    zT_2C0927B0_StateMap* zT_96;
    unsigned int zT_97;
    unsigned char zT_98;
    zT_6B0A7D14_AstStore* zT_99;
    unsigned int zT_100;
    unsigned int zT_102 = 0;
    zT_E48CAD8A_PtrState zT_103;
    zT_7E2F335A_AnalyzerContext* zT_104;
    zT_2C0927B0_StateMap* zT_105;
    unsigned int zT_106;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_107;
    zT_2C0927B0_StateMap* zT_109;
    zT_2C0927B0_StateMap* zT_110;
    zT_2C0927B0_StateMap* zT_111;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_121 = 0;
    int zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_6B0A7D14_AstStore* zT_131;
    unsigned int zT_132;
    unsigned int zT_136 = 0;
    zT_22A7C88B_AstNode zT_137 = {0};
    zT_2C0927B0_StateMap* zT_139;
    zT_3E40CD83_Sand* zT_140;
    zT_2C0927B0_StateMap* zT_142 = 0;
    zT_7E2F335A_AnalyzerContext* zT_143;
    zT_2C0927B0_StateMap* zT_144;
    unsigned int zT_145;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_146;
    zT_2C0927B0_StateMap* zT_148;
    zT_2C0927B0_StateMap* zT_149;
    zT_2C0927B0_StateMap* zT_150;
    int zT_153;
    unsigned int zT_155;
    zT_2C0927B0_StateMap* zT_160;
    zT_3E40CD83_Sand* zT_161;
    zT_2C0927B0_StateMap* zT_163 = 0;
    zT_7E2F335A_AnalyzerContext* zT_164;
    zT_2C0927B0_StateMap* zT_165;
    unsigned int zT_166;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_167;
    zT_2C0927B0_StateMap* zT_169;
    zT_2C0927B0_StateMap* zT_170;
    zT_2C0927B0_StateMap* zT_171;
    unsigned int zT_177;
    unsigned char zT_180;
    zT_7E2F335A_AnalyzerContext* zT_183;
    zT_2C0927B0_StateMap* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned char zT_188;
    zT_7E2F335A_AnalyzerContext* zT_191;
    zT_2C0927B0_StateMap* zT_192;
    unsigned int zT_193;
    zT_7E2F335A_AnalyzerContext* zT_195;
    zT_2C0927B0_StateMap* zT_196;
    unsigned int zT_197;
    unsigned char zT_201;
    unsigned char zT_205;
    unsigned char zT_206;
    unsigned char zT_210;
    unsigned char zT_214;
    zT_7E2F335A_AnalyzerContext* zT_215;
    unsigned int zT_217;
    zT_7A19C4A5_DeferEntry zT_220;
    unsigned int zT_221;
    zT_7A19C4A5_DeferEntry* zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    int zT_225;
    unsigned char zT_228;
    unsigned char zT_231;
    zT_7E2F335A_AnalyzerContext* zT_235;
    zT_2C0927B0_StateMap* zT_236;
    unsigned int zT_237;
    zT_7E2F335A_AnalyzerContext* zT_238;
    zT_2C0927B0_StateMap* zT_239;
    unsigned int zT_240;
    unsigned char zT_241;
    unsigned char zT_244;
    zT_7E2F335A_AnalyzerContext* zT_248;
    zT_2C0927B0_StateMap* zT_249;
    unsigned int zT_250;
    zT_7E2F335A_AnalyzerContext* zT_251;
    zT_2C0927B0_StateMap* zT_252;
    unsigned int zT_253;
    zT_7E2F335A_AnalyzerContext* zT_257;
    zT_2C0927B0_StateMap* zT_258;
    unsigned int zT_259;
    zT_7E2F335A_AnalyzerContext* zT_261;
    zT_2C0927B0_StateMap* zT_262;
    unsigned int zT_263;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_2C0927B0_StateMap* then_state;
    zT_2C0927B0_StateMap* else_state;
    zT_2C0927B0_StateMap* body_state;
    unsigned int prongs_n;
    unsigned int si;
    zT_22A7C88B_AstNode prong;
    zT_2C0927B0_StateMap* ps;
    unsigned char dk;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_17 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture);
    goto z_bb_5;
    z_bb_4:
    zT_17 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_17) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_21 = ctx;
    zT_22 = state;
    zT_23 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_21, zT_22, zT_23);
    zT_26 = state;
    zT_27 = ctx->alloc;
    zT_29 = zF_77086C9C_stateMapFork(zT_26, zT_27);
    then_state = zT_29;
    zT_31 = state;
    zT_32 = ctx->alloc;
    zT_34 = zF_77086C9C_stateMapFork(zT_31, zT_32);
    else_state = zT_34;
    zT_35 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_35 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_16; else goto z_bb_15;
    z_bb_9:
    zT_38 = ctx->store;
    zT_39 = node.child_0;
    zT_40 = then_state;
    zT_41 = else_state;
    zF_76DBB626_applyNullGuardRefin(zT_38, zT_39, zT_40, zT_41);
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_55 = ctx;
    zT_56 = then_state;
    zT_57 = node.child_1;
    zT_58 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_55, zT_56, zT_57, zT_58);
    zT_60 = node.child_2;
    if ((unsigned char)(zT_60 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_47 = then_state;
    zT_50 = ctx->store;
    zT_51 = node_idx;
    zT_53 = zF_8BA26B9E_astStoreNodePayload(zT_50, zT_51);
    zT_48 = zT_53;
    zT_54 = zT_E48CAD8A_PtrState_safe;
    zT_49 = zT_54;
    zF_ACCFA860_stateMapSet(zT_47, zT_48, zT_49);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_63 = ctx;
    zT_64 = else_state;
    zT_65 = node.child_2;
    zT_66 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_63, zT_64, zT_65, zT_66);
    goto z_bb_14;
    z_bb_14:
    zT_68 = state;
    zT_69 = then_state;
    zT_70 = else_state;
    zF_143ACBA6_stateMapMergeStates(zT_68, zT_69, zT_70, (unsigned char)(99));
    goto z_bb_7;
    z_bb_15:
    zT_76 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_17;
    z_bb_16:
    zT_76 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_76) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_80 = ctx;
    zT_81 = state;
    zT_82 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_80, zT_81, zT_82);
    zT_85 = state;
    zT_86 = ctx->alloc;
    zT_88 = zF_77086C9C_stateMapFork(zT_85, zT_86);
    body_state = zT_88;
    zT_89 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_89 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    goto z_bb_7;
    z_bb_20:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_26; else goto z_bb_28;
    z_bb_21:
    zT_92 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_23;
    z_bb_22:
    zT_92 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_96 = body_state;
    zT_99 = ctx->store;
    zT_100 = node_idx;
    zT_102 = zF_8BA26B9E_astStoreNodePayload(zT_99, zT_100);
    zT_97 = zT_102;
    zT_103 = zT_E48CAD8A_PtrState_safe;
    zT_98 = zT_103;
    zF_ACCFA860_stateMapSet(zT_96, zT_97, zT_98);
    goto z_bb_25;
    z_bb_25:
    zT_104 = ctx;
    zT_105 = body_state;
    zT_106 = node.child_1;
    zT_107 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_104, zT_105, zT_106, zT_107);
    zT_109 = state;
    zT_110 = state;
    zT_111 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_109, zT_110, zT_111, (unsigned char)(99));
    goto z_bb_19;
    z_bb_26:
    zT_118 = ctx->store;
    zT_119 = node_idx;
    zT_121 = zF_152E19CB_astStoreNodeExtraCh(zT_118, zT_119);
    prongs_n = zT_121;
    zT_123 = 0;
    zT_124 = (unsigned int)zT_123;
    si = zT_124;
    goto z_bb_29;
    z_bb_27:
    goto z_bb_19;
    z_bb_28:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_33; else goto z_bb_35;
    z_bb_29:
    if ((unsigned char)(si < (unsigned int)((unsigned int)prongs_n))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_128 = ctx->store;
    zT_131 = ctx->store;
    zT_132 = node_idx;
    zT_136 = zF_B10B1BC1_astStoreNodeExtraCh(zT_131, zT_132, (unsigned int)((unsigned int)si));
    zT_129 = zT_136;
    zT_137 = zF_FCDD1D35_astStoreNodeAt(zT_128, zT_129);
    prong = zT_137;
    zT_139 = state;
    zT_140 = ctx->alloc;
    zT_142 = zF_77086C9C_stateMapFork(zT_139, zT_140);
    ps = zT_142;
    zT_143 = ctx;
    zT_144 = ps;
    zT_145 = prong.child_0;
    zT_146 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_143, zT_144, zT_145, zT_146);
    zT_148 = state;
    zT_149 = state;
    zT_150 = ps;
    zF_143ACBA6_stateMapMergeStates(zT_148, zT_149, zT_150, (unsigned char)(99));
    goto z_bb_32;
    z_bb_31:
    goto z_bb_27;
    z_bb_32:
    zT_153 = 1;
    zT_155 = si + (unsigned int)((unsigned int)zT_153);
    si = zT_155;
    goto z_bb_29;
    z_bb_33:
    zT_160 = state;
    zT_161 = ctx->alloc;
    zT_163 = zF_77086C9C_stateMapFork(zT_160, zT_161);
    body_state = zT_163;
    zT_164 = ctx;
    zT_165 = body_state;
    zT_166 = node.child_1;
    zT_167 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_164, zT_165, zT_166, zT_167);
    zT_169 = state;
    zT_170 = state;
    zT_171 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_169, zT_170, zT_171, (unsigned char)(99));
    goto z_bb_34;
    z_bb_34:
    goto z_bb_27;
    z_bb_35:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_36; else goto z_bb_38;
    z_bb_36:
    zT_177 = node.child_0;
    if ((unsigned char)(zT_177 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_46; else goto z_bb_45;
    z_bb_39:
    zT_180 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_180 != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_195 = ctx;
    zT_196 = state;
    zT_197 = node_idx;
    on_stmt(zT_195, zT_196, zT_197);
    goto z_bb_37;
    z_bb_41:
    zT_183 = ctx;
    zT_184 = state;
    zT_185 = node.child_0;
    zT_186 = node_idx;
    zF_8C7FC932_checkReturnProvenan(zT_183, zT_184, zT_185, zT_186);
    goto z_bb_42;
    z_bb_42:
    zT_188 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_188 != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_191 = ctx;
    zT_192 = state;
    zT_193 = node.child_0;
    zF_65CAFC02_handleOwnershipRetu(zT_191, zT_192, zT_193);
    goto z_bb_44;
    z_bb_44:
    goto z_bb_40;
    z_bb_45:
    zT_201 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_47;
    z_bb_46:
    zT_201 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_201) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_206 = ctx->in_defer_exec;
    zT_205 = zT_206 == (unsigned char)(0);
    goto z_bb_50;
    z_bb_49:
    zT_205 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_205) goto z_bb_51; else goto z_bb_53;
    z_bb_51:
    zT_210 = 0;
    dk = zT_210;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt))) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_37;
    z_bb_53:
    zT_228 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_228 != (unsigned char)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_214 = 1;
    dk = zT_214;
    goto z_bb_55;
    z_bb_55:
    zT_215 = ctx;
    zT_217 = ctx->defer_queue_len;
    zF_46BA7660_deferQueueEnsureCap(zT_215, (unsigned int)(zT_217 + (unsigned int)(1)));
    zT_220.kind = dk;
    zT_220.stmt_idx = node_idx;
    zT_221 = ctx->current_depth;
    zT_220.scope_depth = zT_221;
    zT_222 = ctx->defer_queue_items;
    zT_223 = ctx->defer_queue_len;
    zT_222[zT_223] = zT_220;
    zT_224 = ctx->defer_queue_len;
    zT_225 = 1;
    ctx->defer_queue_len = (unsigned int)(zT_224 + (unsigned int)((unsigned int)zT_225));
    goto z_bb_52;
    z_bb_56:
    zT_231 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_58;
    z_bb_57:
    zT_231 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_231) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_235 = ctx;
    zT_236 = state;
    zT_237 = node_idx;
    zF_B7AD2EEF_handleNullVarDecl(zT_235, zT_236, zT_237);
    zT_238 = ctx;
    zT_239 = state;
    zT_240 = node_idx;
    on_stmt(zT_238, zT_239, zT_240);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_52;
    z_bb_61:
    zT_241 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_241 != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_244 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign);
    goto z_bb_64;
    z_bb_63:
    zT_244 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_244) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_248 = ctx;
    zT_249 = state;
    zT_250 = node_idx;
    zF_847AD0EF_handleNullAssign(zT_248, zT_249, zT_250);
    zT_251 = ctx;
    zT_252 = state;
    zT_253 = node_idx;
    on_stmt(zT_251, zT_252, zT_253);
    goto z_bb_66;
    z_bb_66:
    goto z_bb_60;
    z_bb_67:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    zT_257 = ctx;
    zT_258 = state;
    zT_259 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_257, zT_258, zT_259);
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_261 = ctx;
    zT_262 = state;
    zT_263 = node_idx;
    on_stmt(zT_261, zT_262, zT_263);
    goto z_bb_69;
}

/* onNullStmt */
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    (void)ctx;
    (void)state;
    (void)node_idx;
    return;
}

/* onLifetimeStmt */
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned int zT_12;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20 = 0;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_27 = 0;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    zT_7E2F335A_AnalyzerContext* zT_52;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_56 = 0;
    zT_2C0927B0_StateMap* zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_64 = 0;
    zT_22A7C88B_AstNode node;
    unsigned char prov;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = node.child_1;
    if ((unsigned char)(zT_12 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_1;
    zT_20 = zF_5542CD3C_classifyProvenance(zT_16, zT_17, zT_18);
    prov = zT_20;
    zT_21 = state;
    zT_24 = ctx->store;
    zT_25 = node_idx;
    zT_27 = zF_8BA26B9E_astStoreNodePayload(zT_24, zT_25);
    zT_22 = zT_27;
    zT_23 = prov;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_28 = state;
    zT_31 = ctx->store;
    zT_32 = node_idx;
    zT_34 = zF_8BA26B9E_astStoreNodePayload(zT_31, zT_32);
    zT_29 = zT_34;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown)));
    goto z_bb_4;
    z_bb_6:
    zT_42 = ctx->store;
    zT_43 = node.child_0;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    lhs_node = zT_46;
    zT_47 = lhs_node.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    return;
    z_bb_8:
    zT_52 = ctx;
    zT_53 = state;
    zT_54 = node.child_1;
    zT_56 = zF_5542CD3C_classifyProvenance(zT_52, zT_53, zT_54);
    prov = zT_56;
    zT_57 = state;
    zT_60 = ctx->store;
    zT_61 = node.child_0;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_58 = zT_64;
    zT_59 = prov;
    zF_ACCFA860_stateMapSet(zT_57, zT_58, zT_59);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_7;
}

/* onDoubleFreeStmt */
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_7E2F335A_AnalyzerContext* zT_12;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    zT_8143F551_AstKind zT_21;
    zT_7E2F335A_AnalyzerContext* zT_25;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    zT_7E2F335A_AnalyzerContext* zT_32;
    zT_2C0927B0_StateMap* zT_33;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_35;
    zT_2C0927B0_StateMap* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = ctx;
    zT_13 = state;
    zT_16 = ctx->store;
    zT_17 = node_idx;
    zT_19 = zF_8BA26B9E_astStoreNodePayload(zT_16, zT_17);
    zT_14 = zT_19;
    zT_15 = node.child_1;
    zF_4330B9B8_handleAllocCall(zT_12, zT_13, zT_14, zT_15);
    goto z_bb_2;
    z_bb_2:
    zT_21 = node.kind;
    if ((unsigned char)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25 = ctx;
    zT_26 = state;
    zT_27 = node_idx;
    zF_67B7BB29_handleAllocAssign(zT_25, zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_32 = ctx;
    zT_33 = state;
    zT_34 = node_idx;
    zF_70D0501D_handleFreeCall(zT_32, zT_33, zT_34);
    zT_35 = ctx;
    zT_36 = state;
    zT_37 = node_idx;
    zF_9AFCA595_handleOwnershipPass(zT_35, zT_36, zT_37);
    goto z_bb_6;
    z_bb_6:
    return;
}

/* runSignatureAnalyzer */
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx) {
    zT_7E2F335A_AnalyzerContext* zT_2;
    unsigned int zT_3;
    zT_2 = ctx;
    zT_3 = fn_decl_idx;
    zF_2A06A757_analyzeSignature(zT_2, zT_3);
    return;
}

/* detectorVisit */
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_3;
    zT_2C0927B0_StateMap* zT_4;
    unsigned int zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_6;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_9;
    zT_3 = ctx;
    zT_4 = state;
    zT_5 = node_idx;
    zT_6 = ctx->on_stmt_cb;
    zT_9 = zF_59D99CE2_detectorVisit;
    zT_7 = zT_9;
    zF_468ECC89_visitStatement(zT_3, zT_4, zT_5, zT_6, zT_7);
    return;
}

/* runNullAnalyzer */
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->null_analysis_mode = (unsigned char)(1);
    zT_7 = zF_43C99FB3_onNullStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = &state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->null_analysis_mode = (unsigned char)(0);
    return;
}

/* runLifetimeAnalyzer */
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_4;
    zT_2C0927B0_StateMap zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    zT_82915964_anon_238038 zT_20;
    zT_243D6A41_FnProto* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned int zT_26;
    zT_243D6A41_FnProto zT_27;
    unsigned int zT_29;
    unsigned short zT_33;
    zT_79FAE712_u64 zT_35;
    zT_6B0A7D14_AstStore* zT_37;
    zT_79FAE712_u64 zT_38;
    unsigned int zT_40 = 0;
    int zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_55 = 0;
    zT_22A7C88B_AstNode zT_56 = {0};
    zT_8143F551_AstKind zT_57;
    zT_2C0927B0_StateMap* zT_61;
    unsigned int zT_62;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_6B0A7D14_AstStore* zT_68;
    zT_79FAE712_u64 zT_69;
    unsigned int zT_73 = 0;
    unsigned int zT_74 = 0;
    int zT_77;
    unsigned int zT_79;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_81;
    zT_7E2F335A_AnalyzerContext* zT_82;
    zT_2C0927B0_StateMap* zT_83;
    unsigned int zT_84;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_85;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_87;
    zT_2C0927B0_StateMap state;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 pp;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    zT_4 = ctx->alloc;
    zT_6 = zF_14665872_stateMapInit(zT_4);
    state = zT_6;
    zT_8 = ctx->store;
    zT_9 = fn_decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    zT_12 = ctx->store;
    zT_13 = fn_decl_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = ctx->store;
    zT_20 = zT_19->fn_protos;
    zT_21 = zT_20.items;
    zT_22 = ctx->store;
    zT_23 = fn_decl_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    proto = zT_27;
    zT_29 = proto.params_start;
    zT_33 = proto.params_count;
    zT_35 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_29) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_33);
    pp = zT_35;
    zT_37 = ctx->store;
    zT_38 = pp;
    zT_40 = zF_03CE8CAB_astStoreGetExtraChi(zT_37, zT_38);
    params_n = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    pi = zT_43;
    goto z_bb_3;
    z_bb_2:
    ctx->lifetime_analysis_mode = (unsigned char)(1);
    zT_81 = zF_3D2EF2C5_onLifetimeStmt;
    ctx->on_stmt_cb = zT_81;
    zT_82 = ctx;
    zT_83 = &state;
    zT_84 = fn_body_idx;
    zT_87 = zF_59D99CE2_detectorVisit;
    zT_85 = zT_87;
    zF_0F6AFE81_walkBlock(zT_82, zT_83, zT_84, zT_85);
    ctx->lifetime_analysis_mode = (unsigned char)(0);
    return;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_47 = ctx->store;
    zT_50 = ctx->store;
    zT_51 = pp;
    zT_55 = zF_E5B10421_astStoreGetExtraChi(zT_50, zT_51, (unsigned int)((unsigned int)pi));
    zT_48 = zT_55;
    zT_56 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    pnode = zT_56;
    zT_57 = pnode.kind;
    if ((unsigned char)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_77 = 1;
    zT_79 = pi + (unsigned int)((unsigned int)zT_77);
    pi = zT_79;
    goto z_bb_3;
    z_bb_7:
    zT_61 = &state;
    zT_65 = ctx->store;
    zT_68 = ctx->store;
    zT_69 = pp;
    zT_73 = zF_E5B10421_astStoreGetExtraChi(zT_68, zT_69, (unsigned int)((unsigned int)pi));
    zT_66 = zT_73;
    zT_74 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    zT_62 = zT_74;
    zF_ACCFA860_stateMapSet(zT_61, zT_62, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* runDoubleFreeAnalyzer */
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->doublefree_analysis_mode = (unsigned char)(1);
    zT_7 = zF_270EF995_onDoubleFreeStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = &state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->doublefree_analysis_mode = (unsigned char)(0);
    return;
}

/* runAllAnalyzers */
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext* ctx, unsigned int module_root_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_27 = 0;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_3E40CD83_Sand* zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    zT_82915964_anon_238038 zT_43;
    zT_243D6A41_FnProto* zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    unsigned int zT_49;
    zT_243D6A41_FnProto zT_50;
    unsigned int zT_51;
    zT_7E2F335A_AnalyzerContext* zT_52;
    unsigned int zT_53;
    zT_3E40CD83_Sand* zT_54;
    unsigned char zT_56;
    zT_7E2F335A_AnalyzerContext* zT_59;
    unsigned int zT_60;
    zT_3E40CD83_Sand* zT_62;
    unsigned char zT_64;
    zT_7E2F335A_AnalyzerContext* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_3E40CD83_Sand* zT_71;
    unsigned char zT_73;
    zT_7E2F335A_AnalyzerContext* zT_76;
    unsigned int zT_77;
    zT_3E40CD83_Sand* zT_79;
    zT_3E40CD83_Sand* zT_81;
    unsigned int zT_82;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_F85C5DED_DiagnosticCollector* zT_89;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_103;
    unsigned int zT_104;
    int zT_108;
    unsigned int zT_110;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u bmsg;
    zT_3 = ctx->store;
    zT_4 = module_root_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    root = zT_6;
    zT_7 = root.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = module_root_idx;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    decls_n = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    di = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = ctx->store;
    zT_23 = module_root_idx;
    zT_27 = zF_B10B1BC1_astStoreNodeExtraCh(zT_22, zT_23, (unsigned int)((unsigned int)di));
    decl_idx = zT_27;
    zT_29 = ctx->store;
    zT_30 = decl_idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    decl = zT_32;
    zT_33 = decl.kind;
    if ((unsigned char)(zT_33 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_108 = 1;
    zT_110 = di + (unsigned int)((unsigned int)zT_108);
    di = zT_110;
    goto z_bb_3;
    z_bb_7:
    goto z_bb_6;
    z_bb_8:
    zT_37 = decl.child_0;
    if ((unsigned char)(zT_37 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_40 = ctx->alloc;
    zF_CB5A85E9_sandResetPeak(zT_40);
    zT_42 = ctx->store;
    zT_43 = zT_42->fn_protos;
    zT_44 = zT_43.items;
    zT_45 = ctx->store;
    zT_46 = decl_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_45, zT_46);
    zT_49 = (unsigned int)zT_48;
    zT_50 = zT_44[zT_49];
    zT_51 = zT_50.name_id;
    ctx->current_fn_name = zT_51;
    zT_52 = ctx;
    zT_53 = decl_idx;
    zF_DDE69BF2_runSignatureAnalyze(zT_52, zT_53);
    zT_54 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_54);
    zT_56 = ctx->skip_null_check;
    if ((unsigned char)(zT_56 == (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_59 = ctx;
    zT_60 = decl.child_0;
    zF_29CABD65_runNullAnalyzer(zT_59, zT_60);
    zT_62 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_62);
    goto z_bb_12;
    z_bb_12:
    zT_64 = ctx->skip_lifetime_check;
    if ((unsigned char)(zT_64 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_67 = ctx;
    zT_68 = decl_idx;
    zT_69 = decl.child_0;
    zF_9B11D60F_runLifetimeAnalyzer(zT_67, zT_68, zT_69);
    zT_71 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_71);
    goto z_bb_14;
    z_bb_14:
    zT_73 = ctx->skip_doublefree_check;
    if ((unsigned char)(zT_73 == (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_76 = ctx;
    zT_77 = decl.child_0;
    zF_D5F41043_runDoubleFreeAnalyz(zT_76, zT_77);
    zT_79 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_79);
    goto z_bb_16;
    z_bb_16:
    zT_81 = ctx->alloc;
    zT_82 = zT_81->peak;
    if ((unsigned char)(zT_82 > zG_73BDFDC5_PER_FUNC_BUDGET)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_86 = "per-function analyzer budget exceeded";
    zT_88 = 37;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    bmsg = zT_87;
    zT_89 = ctx->diag;
    zT_93 = decl.span_start;
    zT_103 = decl.span_start;
    zT_104 = decl.span_len;
    zT_95 = bmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_89, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7002_ANALYZER_BUDGET_EXCEEDED)), (unsigned int)(0), zT_93, (unsigned int)(zT_103 + (unsigned int)((unsigned int)zT_104)), zT_95);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_6;
}

/* __module_init */
void zF_780653D2___module_init_10(void) {
    zG_73BDFDC5_PER_FUNC_BUDGET = (unsigned int)(524288);
    return;
}

/* EOF */
