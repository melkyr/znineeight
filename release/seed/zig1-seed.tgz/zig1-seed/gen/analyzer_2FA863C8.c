#include "analyzer_2FA863C8.h"
unsigned int const zG_73BDFDC5_PER_FUNC_BUDGET = (unsigned int)(524288);
/* identNameId */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_2 = store;
    zT_3 = node_idx;
    zT_4 = zF_53458827_astStoreIdentifier(zT_2, zT_3);
    return zT_4;
}

/* resolveOrigin */
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_BAEE192E_Opt_10 zT_19;
    zT_7E2F335A_AnalyzerContext* zT_23;
    unsigned int zT_25;
    zT_7E2F335A_AnalyzerContext* zT_30;
    unsigned int zT_32;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    zT_7E2F335A_AnalyzerContext* zT_41;
    unsigned int zT_43;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx->store;
    zT_16 = expr_idx;
    zT_18 = zF_2E24BD6B_identNameId(zT_15, zT_16);
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = ctx;
    zT_25 = node.child_0;
    ctx = zT_23;
    expr_idx = zT_25;
    goto z_bb_0;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = ctx;
    zT_32 = node.child_0;
    ctx = zT_30;
    expr_idx = zT_32;
    goto z_bb_0;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = ctx;
    zT_43 = node.child_0;
    ctx = zT_41;
    expr_idx = zT_43;
    goto z_bb_0;
    z_bb_12:
    zT_45.has_value = 0;
    return zT_45;
}

/* classifyProvenance */
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    zT_7E2F335A_AnalyzerContext* zT_34;
    unsigned int zT_35;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    unsigned char zT_38;
    unsigned char zT_41;
    zT_060CD1EB_SymbolTable* zT_43;
    unsigned int zT_44;
    zT_77F031D4_Opt_960 zT_46 = {0};
    unsigned char zT_47;
    zT_3C598AEF_SymbolKind zT_49;
    unsigned char zT_54;
    zT_3C598AEF_SymbolKind zT_55;
    unsigned char zT_60;
    zT_3C598AEF_SymbolKind zT_61;
    unsigned char zT_66;
    zT_2C0927B0_StateMap* zT_70;
    unsigned int zT_71;
    zT_43E16BE5_Opt_8 zT_72 = {0};
    unsigned char zT_73;
    unsigned char zT_76;
    unsigned char zT_87;
    unsigned char zT_91;
    zT_7E2F335A_AnalyzerContext* zT_132;
    unsigned int zT_133;
    zT_BAEE192E_Opt_10 zT_135 = {0};
    unsigned char zT_136;
    zT_2C0927B0_StateMap* zT_139;
    unsigned int zT_140;
    zT_43E16BE5_Opt_8 zT_141 = {0};
    unsigned char zT_142;
    zT_7E2F335A_AnalyzerContext* zT_150;
    unsigned int zT_151;
    zT_BAEE192E_Opt_10 zT_153 = {0};
    unsigned char zT_154;
    zT_2C0927B0_StateMap* zT_157;
    unsigned int zT_158;
    zT_43E16BE5_Opt_8 zT_159 = {0};
    unsigned char zT_160;
    zT_2C0927B0_StateMap* zT_168;
    unsigned int zT_169;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_173 = 0;
    zT_43E16BE5_Opt_8 zT_174 = {0};
    unsigned char zT_175;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char t5_is_interior;
    zT_22A7C88B_AstNode t5_onode;
    zT_BAEE192E_Opt_10 found_name_id;
    unsigned int name_id;
    unsigned char t5_base;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* s;
    zT_43E16BE5_Opt_8 pv;
    unsigned char v;
    zT_BAEE192E_Opt_10 base_id;
    unsigned int bid;
    zT_43E16BE5_Opt_8 result;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = expr_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = 0;
    t5_is_interior = zT_18;
    zT_19 = node.child_0;
    if ((unsigned char)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_46; else goto z_bb_47;
    z_bb_5:
    zT_23 = ctx->store;
    zT_24 = node.child_0;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_23, zT_24);
    t5_onode = zT_27;
    zT_28 = t5_onode.kind;
    if ((unsigned char)(zT_28 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_34 = ctx;
    zT_35 = node.child_0;
    zT_37 = zF_92A5586D_resolveOrigin(zT_34, zT_35);
    found_name_id = zT_37;
    zT_38 = found_name_id.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_32 = 1;
    t5_is_interior = zT_32;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    name_id = found_name_id.value;
    zT_41 = 255;
    t5_base = zT_41;
    zT_43 = ctx->symbols;
    zT_44 = name_id;
    zT_46 = zF_893B79A5_symbolTableLookup(zT_43, zT_44);
    sym = zT_46;
    zT_47 = sym.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_13;
    z_bb_10:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_11:
    s = sym.value;
    zT_49 = s->kind;
    if ((unsigned char)(zT_49 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_local))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    if ((unsigned char)(t5_is_interior == (unsigned char)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_13:
    zT_70 = state;
    zT_71 = name_id;
    zT_72 = zF_2EC17ECC_stateMapGet(zT_70, zT_71);
    pv = zT_72;
    zT_73 = pv.has_value;
    if (zT_73) goto z_bb_23; else goto z_bb_25;
    z_bb_14:
    zT_54 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    t5_base = zT_54;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_55 = s->kind;
    if ((unsigned char)(zT_55 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_param))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_60 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param);
    t5_base = zT_60;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_61 = s->kind;
    if ((unsigned char)(zT_61 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_66 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global);
    t5_base = zT_66;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_23:
    v = pv.value;
    t5_base = v;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_76 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    t5_base = zT_76;
    goto z_bb_24;
    z_bb_26:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global)))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external)))) goto z_bb_38; else goto z_bb_39;
    z_bb_28:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_29:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)))) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_87 = t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external));
    goto z_bb_32;
    z_bb_31:
    zT_87 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_87) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_91 = t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    goto z_bb_35;
    z_bb_34:
    zT_91 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_91) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_37:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_38:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external));
    z_bb_39:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global)))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_41:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap)))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_43:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_45:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_46:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_47:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_132 = ctx;
    zT_133 = node.child_0;
    zT_135 = zF_92A5586D_resolveOrigin(zT_132, zT_133);
    base_id = zT_135;
    zT_136 = base_id.has_value;
    if (zT_136) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_54; else goto z_bb_55;
    z_bb_50:
    bid = base_id.value;
    zT_139 = state;
    zT_140 = bid;
    zT_141 = zF_2EC17ECC_stateMapGet(zT_139, zT_140);
    result = zT_141;
    zT_142 = result.has_value;
    if (zT_142) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_52:
    v = result.value;
    return v;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_150 = ctx;
    zT_151 = node.child_0;
    zT_153 = zF_92A5586D_resolveOrigin(zT_150, zT_151);
    base_id = zT_153;
    zT_154 = base_id.has_value;
    if (zT_154) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    bid = base_id.value;
    zT_157 = state;
    zT_158 = bid;
    zT_159 = zF_2EC17ECC_stateMapGet(zT_157, zT_158);
    result = zT_159;
    zT_160 = result.has_value;
    if (zT_160) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_58:
    v = result.value;
    return v;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_168 = state;
    zT_170 = ctx->store;
    zT_171 = expr_idx;
    zT_173 = zF_2E24BD6B_identNameId(zT_170, zT_171);
    zT_169 = zT_173;
    zT_174 = zF_2EC17ECC_stateMapGet(zT_168, zT_169);
    result = zT_174;
    zT_175 = result.has_value;
    if (zT_175) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_62:
    v = result.value;
    return v;
    z_bb_63:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
}

/* checkReturnProvenance */
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx, unsigned int ret_node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_5;
    zT_2C0927B0_StateMap* zT_6;
    unsigned int zT_7;
    unsigned char zT_8 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    unsigned char zT_28;
    unsigned char zT_31;
    zT_8143F551_AstKind zT_33;
    zT_7E2F335A_AnalyzerContext* zT_38;
    unsigned int zT_39;
    zT_BAEE192E_Opt_10 zT_41 = {0};
    unsigned char zT_42;
    zT_D3EB6303_StringInterner* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48 = {0};
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_72;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_F85C5DED_DiagnosticCollector* zT_90;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_8143F551_AstKind zT_104;
    zT_7E2F335A_AnalyzerContext* zT_109;
    unsigned int zT_110;
    zT_BAEE192E_Opt_10 zT_112 = {0};
    unsigned char zT_113;
    zT_D3EB6303_StringInterner* zT_116;
    unsigned int zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119 = {0};
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    unsigned char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_D3EB6303_StringInterner* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_135;
    zT_F85C5DED_DiagnosticCollector* zT_137;
    int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_143;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_F85C5DED_DiagnosticCollector* zT_161;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    zT_7E2F335A_AnalyzerContext* zT_176;
    unsigned int zT_177;
    zT_BAEE192E_Opt_10 zT_178 = {0};
    unsigned char zT_179;
    zT_D3EB6303_StringInterner* zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185 = {0};
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_D3EB6303_StringInterner* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_201;
    zT_F85C5DED_DiagnosticCollector* zT_203;
    int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_209;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    zT_F85C5DED_DiagnosticCollector* zT_227;
    unsigned int zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_7E2F335A_AnalyzerContext* zT_243;
    unsigned int zT_244;
    zT_BAEE192E_Opt_10 zT_246 = {0};
    unsigned char zT_247;
    zT_D3EB6303_StringInterner* zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_253 = {0};
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_D3EB6303_StringInterner* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_269;
    zT_F85C5DED_DiagnosticCollector* zT_271;
    int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_277;
    unsigned int zT_281;
    unsigned int zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char* zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294;
    zT_F85C5DED_DiagnosticCollector* zT_295;
    unsigned int zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned char prov;
    zT_22A7C88B_AstNode rnode;
    unsigned int start;
    unsigned int end;
    zT_22A7C88B_AstNode expr_node;
    unsigned char pl;
    unsigned char ppa;
    zT_BAEE192E_Opt_10 name_opt;
    unsigned int nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli rparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_5 = ctx;
    zT_6 = state;
    zT_7 = expr_idx;
    zT_8 = zF_5542CD3C_classifyProvenance(zT_5, zT_6, zT_7);
    prov = zT_8;
    zT_10 = ctx->store;
    zT_11 = ret_node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    rnode = zT_13;
    zT_15 = rnode.span_start;
    start = zT_15;
    zT_17 = rnode.span_start;
    zT_18 = rnode.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = ctx->store;
    zT_23 = expr_idx;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    expr_node = zT_25;
    zT_28 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    pl = zT_28;
    zT_31 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr);
    ppa = zT_31;
    if ((unsigned char)(prov == pl)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_33 = expr_node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(prov == ppa)) goto z_bb_13; else goto z_bb_14;
    z_bb_3:
    zT_38 = ctx;
    zT_39 = expr_node.child_0;
    zT_41 = zF_92A5586D_resolveOrigin(zT_38, zT_39);
    name_opt = zT_41;
    zT_42 = name_opt.has_value;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_104 = expr_node.kind;
    if ((unsigned char)(zT_104 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    nid = name_opt.value;
    zT_45 = ctx->interner;
    zT_46 = nid;
    zT_48 = zF_9134020D_stringInternerGet(zT_45, zT_46);
    nm = zT_48;
    zT_50 = "returning address of local variable '";
    zT_52 = 37;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    rp1 = zT_51;
    zT_54 = "'";
    zT_56 = 1;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    rp2 = zT_55;
    zT_59 = 0;
    zT_58[zT_59] = rp1;
    zT_60 = 1;
    zT_58[zT_60] = nm;
    zT_61 = 2;
    zT_58[zT_61] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_58[_i];
        _i++;
    }
}
    zT_66 = ctx->diag;
    zT_63 = zT_66->interner;
    zT_68 = 0;
    zT_69 = rparts + zT_68;
    zT_64 = zT_69;
    zT_71 = zF_8C4BFF7C_diagnosticBuilderMa(zT_63, zT_64, (unsigned int)(3));
    msg = zT_71;
    zT_72 = ctx->diag;
    zT_76 = start;
    zT_77 = end;
    zT_78 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_72, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_76, zT_77, zT_78);
    return;
    z_bb_6:
    zT_87 = "returning address of local variable";
    zT_89 = 35;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    dmsg = zT_88;
    zT_90 = ctx->diag;
    zT_94 = start;
    zT_95 = end;
    zT_96 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_90, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_94, zT_95, zT_96);
    return;
    z_bb_7:
    zT_109 = ctx;
    zT_110 = expr_node.child_0;
    zT_112 = zF_92A5586D_resolveOrigin(zT_109, zT_110);
    name_opt = zT_112;
    zT_113 = name_opt.has_value;
    if (zT_113) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_176 = ctx;
    zT_177 = expr_idx;
    zT_178 = zF_92A5586D_resolveOrigin(zT_176, zT_177);
    name_opt = zT_178;
    zT_179 = name_opt.has_value;
    if (zT_179) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    nid = name_opt.value;
    zT_116 = ctx->interner;
    zT_117 = nid;
    zT_119 = zF_9134020D_stringInternerGet(zT_116, zT_117);
    nm = zT_119;
    zT_121 = "returning slice of local array '";
    zT_123 = 32;
    zT_122.ptr = (unsigned char*)zT_121;
    zT_122.len = zT_123;
    rp1 = zT_122;
    zT_125 = "'";
    zT_127 = 1;
    zT_126.ptr = (unsigned char*)zT_125;
    zT_126.len = zT_127;
    rp2 = zT_126;
    zT_130 = 0;
    zT_129[zT_130] = rp1;
    zT_131 = 1;
    zT_129[zT_131] = nm;
    zT_132 = 2;
    zT_129[zT_132] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_129[_i];
        _i++;
    }
}
    zT_137 = ctx->diag;
    zT_134 = zT_137->interner;
    zT_139 = 0;
    zT_140 = rparts + zT_139;
    zT_135 = zT_140;
    zT_142 = zF_8C4BFF7C_diagnosticBuilderMa(zT_134, zT_135, (unsigned int)(3));
    msg = zT_142;
    zT_143 = ctx->diag;
    zT_147 = start;
    zT_148 = end;
    zT_149 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_143, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_147, zT_148, zT_149);
    return;
    z_bb_10:
    zT_158 = "returning slice of local array";
    zT_160 = 30;
    zT_159.ptr = (unsigned char*)zT_158;
    zT_159.len = zT_160;
    dmsg = zT_159;
    zT_161 = ctx->diag;
    zT_165 = start;
    zT_166 = end;
    zT_167 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_161, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_165, zT_166, zT_167);
    return;
    z_bb_11:
    nid = name_opt.value;
    zT_182 = ctx->interner;
    zT_183 = nid;
    zT_185 = zF_9134020D_stringInternerGet(zT_182, zT_183);
    nm = zT_185;
    zT_187 = "returning pointer to local via variable '";
    zT_189 = 41;
    zT_188.ptr = (unsigned char*)zT_187;
    zT_188.len = zT_189;
    rp1 = zT_188;
    zT_191 = "'";
    zT_193 = 1;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    rp2 = zT_192;
    zT_196 = 0;
    zT_195[zT_196] = rp1;
    zT_197 = 1;
    zT_195[zT_197] = nm;
    zT_198 = 2;
    zT_195[zT_198] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_195[_i];
        _i++;
    }
}
    zT_203 = ctx->diag;
    zT_200 = zT_203->interner;
    zT_205 = 0;
    zT_206 = rparts + zT_205;
    zT_201 = zT_206;
    zT_208 = zF_8C4BFF7C_diagnosticBuilderMa(zT_200, zT_201, (unsigned int)(3));
    msg = zT_208;
    zT_209 = ctx->diag;
    zT_213 = start;
    zT_214 = end;
    zT_215 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_209, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_213, zT_214, zT_215);
    return;
    z_bb_12:
    zT_224 = "returning pointer to local via variable";
    zT_226 = 39;
    zT_225.ptr = (unsigned char*)zT_224;
    zT_225.len = zT_226;
    dmsg = zT_225;
    zT_227 = ctx->diag;
    zT_231 = start;
    zT_232 = end;
    zT_233 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_227, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_231, zT_232, zT_233);
    return;
    z_bb_13:
    zT_243 = ctx;
    zT_244 = expr_node.child_0;
    zT_246 = zF_92A5586D_resolveOrigin(zT_243, zT_244);
    name_opt = zT_246;
    zT_247 = name_opt.has_value;
    if (zT_247) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    return;
    z_bb_15:
    nid = name_opt.value;
    zT_250 = ctx->interner;
    zT_251 = nid;
    zT_253 = zF_9134020D_stringInternerGet(zT_250, zT_251);
    nm = zT_253;
    zT_255 = "returning address of parameter '";
    zT_257 = 32;
    zT_256.ptr = (unsigned char*)zT_255;
    zT_256.len = zT_257;
    rp1 = zT_256;
    zT_259 = "'";
    zT_261 = 1;
    zT_260.ptr = (unsigned char*)zT_259;
    zT_260.len = zT_261;
    rp2 = zT_260;
    zT_264 = 0;
    zT_263[zT_264] = rp1;
    zT_265 = 1;
    zT_263[zT_265] = nm;
    zT_266 = 2;
    zT_263[zT_266] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_263[_i];
        _i++;
    }
}
    zT_271 = ctx->diag;
    zT_268 = zT_271->interner;
    zT_273 = 0;
    zT_274 = rparts + zT_273;
    zT_269 = zT_274;
    zT_276 = zF_8C4BFF7C_diagnosticBuilderMa(zT_268, zT_269, (unsigned int)(3));
    msg = zT_276;
    zT_277 = ctx->diag;
    zT_281 = start;
    zT_282 = end;
    zT_283 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_277, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_281, zT_282, zT_283);
    return;
    z_bb_16:
    zT_292 = "returning address of function parameter";
    zT_294 = 39;
    zT_293.ptr = (unsigned char*)zT_292;
    zT_293.len = zT_294;
    dmsg = zT_293;
    zT_295 = ctx->diag;
    zT_299 = start;
    zT_300 = end;
    zT_301 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_295, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_299, zT_300, zT_301);
    return;
}

/* isAllocCall */
unsigned char zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_7E2F335A_AnalyzerContext* zT_14;
    unsigned int zT_16;
    zT_8143F551_AstKind zT_18;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    zT_8143F551_AstKind zT_29;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_48 = 0;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_D3EB6303_StringInterner* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sandAlloc;
    unsigned int sand_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_alloc;
    unsigned int sand2_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_alloc;
    unsigned int arena_nid;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = ctx;
    zT_16 = node.child_0;
    ctx = zT_14;
    expr_idx = zT_16;
    goto z_bb_0;
    z_bb_4:
    zT_18 = node.kind;
    if ((unsigned char)(zT_18 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_24 = ctx->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    callee = zT_28;
    zT_29 = callee.kind;
    if ((unsigned char)(zT_29 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_35 = ctx->store;
    zT_36 = node.child_0;
    zT_39 = zF_2E24BD6B_identNameId(zT_35, zT_36);
    name_id = zT_39;
    zT_41 = "sandAlloc";
    zT_43 = 9;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    s_sandAlloc = zT_42;
    zT_45 = ctx->interner;
    zT_46 = s_sandAlloc;
    zT_48 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    sand_nid = zT_48;
    if ((unsigned char)(name_id == sand_nid)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_52 = "sand_alloc";
    zT_54 = 10;
    zT_53.ptr = (unsigned char*)zT_52;
    zT_53.len = zT_54;
    s_sand_alloc = zT_53;
    zT_56 = ctx->interner;
    zT_57 = s_sand_alloc;
    zT_59 = zF_50C274AF_stringInternerInter(zT_56, zT_57);
    sand2_nid = zT_59;
    if ((unsigned char)(name_id == sand2_nid)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_63 = "arena_alloc";
    zT_65 = 11;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    s_arena_alloc = zT_64;
    zT_67 = ctx->interner;
    zT_68 = s_arena_alloc;
    zT_70 = zF_50C274AF_stringInternerInter(zT_67, zT_68);
    arena_nid = zT_70;
    if ((unsigned char)(name_id == arena_nid)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* isFreeCall */
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_31 = 0;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_40 = 0;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_49 = 0;
    unsigned char zT_51;
    zT_BAEE192E_Opt_10 zT_53 = {0};
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58 = 0;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    zT_22A7C88B_AstNode zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_81 = 0;
    zT_BAEE192E_Opt_10 zT_82;
    zT_BAEE192E_Opt_10 zT_83 = {0};
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_free;
    unsigned int arena_free_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_free;
    unsigned int sand_free_nid;
    unsigned int args_n;
    unsigned int args1;
    zT_22A7C88B_AstNode ptr_arg;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    zT_16 = ctx->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    callee = zT_20;
    zT_21 = callee.kind;
    if ((unsigned char)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_6:
    zT_27 = ctx->store;
    zT_28 = node.child_0;
    zT_31 = zF_2E24BD6B_identNameId(zT_27, zT_28);
    name_id = zT_31;
    zT_33 = "arena_free";
    zT_35 = 10;
    zT_34.ptr = (unsigned char*)zT_33;
    zT_34.len = zT_35;
    s_arena_free = zT_34;
    zT_37 = ctx->interner;
    zT_38 = s_arena_free;
    zT_40 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    arena_free_nid = zT_40;
    zT_42 = "sandFree";
    zT_44 = 8;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    s_sand_free = zT_43;
    zT_46 = ctx->interner;
    zT_47 = s_sand_free;
    zT_49 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    sand_free_nid = zT_49;
    if ((unsigned char)(name_id != arena_free_nid)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_51 = name_id != sand_free_nid;
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_53.has_value = 0;
    return zT_53;
    z_bb_11:
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_152E19CB_astStoreNodeExtraCh(zT_55, zT_56);
    args_n = zT_58;
    if ((unsigned char)(args_n < (unsigned int)(2))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_61.has_value = 0;
    return zT_61;
    z_bb_13:
    zT_63 = ctx->store;
    zT_64 = expr_idx;
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_63, zT_64, (unsigned int)(1));
    args1 = zT_68;
    zT_70 = ctx->store;
    zT_71 = args1;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_70, zT_71);
    ptr_arg = zT_73;
    zT_74 = ptr_arg.kind;
    if ((unsigned char)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_78 = ctx->store;
    zT_79 = args1;
    zT_81 = zF_2E24BD6B_identNameId(zT_78, zT_79);
    zT_82.has_value = 1;
    zT_82.value = zT_81;
    return zT_82;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
}

/* compositeNameId */
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner* interner, unsigned int base_id, unsigned int field_id) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char* zT_47;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_59;
    unsigned char* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u base_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u field_str;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int pos;
    unsigned int i;
    zT_4 = interner;
    zT_5 = base_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    base_str = zT_6;
    zT_8 = interner;
    zT_9 = field_id;
    zT_10 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    field_str = zT_10;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    pos = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_1:
    zT_20 = base_str.len;
    if ((unsigned char)(i < zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_25 = base_str.ptr;
    zT_26 = zT_25[i];
    buf[pos] = zT_26;
    zT_27 = 1;
    zT_29 = pos + (unsigned int)((unsigned int)zT_27);
    pos = zT_29;
    zT_30 = 1;
    zT_32 = i + (unsigned int)((unsigned int)zT_30);
    i = zT_32;
    goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(pos < (unsigned int)(127))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_22 = pos < (unsigned int)(127);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_35 = 46;
    buf[pos] = zT_35;
    zT_36 = 1;
    zT_38 = pos + (unsigned int)((unsigned int)zT_36);
    pos = zT_38;
    goto z_bb_9;
    z_bb_9:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_10;
    z_bb_10:
    zT_42 = field_str.len;
    if ((unsigned char)(i < zT_42)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_47 = field_str.ptr;
    zT_48 = zT_47[i];
    buf[pos] = zT_48;
    zT_49 = 1;
    zT_51 = pos + (unsigned int)((unsigned int)zT_49);
    pos = zT_51;
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_13;
    z_bb_12:
    zT_55 = interner;
    zT_59 = 0;
    zT_60 = (unsigned char*)((unsigned char*)buf) + zT_59;
    zT_61 = pos - zT_59;
    zT_62.ptr = (unsigned char*)zT_60;
    zT_62.len = zT_61;
    zT_56 = zT_62;
    zT_63 = zF_50C274AF_stringInternerInter(zT_55, zT_56);
    return zT_63;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_44 = pos < (unsigned int)(127);
    goto z_bb_16;
    z_bb_15:
    zT_44 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_44) goto z_bb_11; else goto z_bb_12;
}

/* handleAllocCall */
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int init_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    unsigned char zT_6 = 0;
    zT_2C0927B0_StateMap* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_480593AB_AllocState zT_11;
    zT_4 = ctx;
    zT_5 = init_idx;
    zT_6 = zF_264B254A_isAllocCall(zT_4, zT_5);
    if ((unsigned char)(!zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = state;
    zT_9 = name_id;
    zT_11 = zT_480593AB_AllocState_allocated;
    zT_10 = zT_11;
    zF_ACCFA860_stateMapSet(zT_8, zT_9, zT_10);
    return;
}

/* handleFreeCall */
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_15 = {0};
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_22A7C88B_AstNode zT_20 = {0};
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_480593AB_AllocState zT_28;
    zT_D3EB6303_StringInterner* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35 = {0};
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D3EB6303_StringInterner* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_59;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_2C0927B0_StateMap* zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_480593AB_AllocState zT_81;
    zT_D3EB6303_StringInterner* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86 = {0};
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_102;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_110;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int name_id;
    zT_43E16BE5_Opt_8 current;
    zT_22A7C88B_AstNode node;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_8F083A69_Slice_zT_0B42B2F8_u up2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u umsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli dparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_4 = ctx;
    zT_5 = expr_idx;
    zT_6 = zF_E445D5FB_isFreeCall(zT_4, zT_5);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = zT_6.value;
    goto z_bb_3;
    z_bb_3:
    name_id = zT_8;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_13 = state;
    zT_14 = name_id;
    zT_15 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    current = zT_15;
    zT_17 = ctx->store;
    zT_18 = expr_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_17, zT_18);
    node = zT_20;
    zT_21 = current.has_value;
    if (zT_21) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_83 = ctx->interner;
    zT_84 = name_id;
    zT_86 = zF_9134020D_stringInternerGet(zT_83, zT_84);
    pn = zT_86;
    zT_88 = "freeing untracked pointer '";
    zT_90 = 27;
    zT_89.ptr = (unsigned char*)zT_88;
    zT_89.len = zT_90;
    up1 = zT_89;
    zT_92 = "'";
    zT_94 = 1;
    zT_93.ptr = (unsigned char*)zT_92;
    zT_93.len = zT_94;
    up2 = zT_93;
    zT_97 = 0;
    zT_96[zT_97] = up1;
    zT_98 = 1;
    zT_96[zT_98] = pn;
    zT_99 = 2;
    zT_96[zT_99] = up2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_96[_i];
        _i++;
    }
}
    zT_104 = ctx->diag;
    zT_101 = zT_104->interner;
    zT_106 = 0;
    zT_107 = uparts + zT_106;
    zT_102 = zT_107;
    zT_109 = zF_8C4BFF7C_diagnosticBuilderMa(zT_101, zT_102, (unsigned int)(3));
    umsg = zT_109;
    zT_110 = ctx->diag;
    zT_114 = node.span_start;
    zT_124 = node.span_start;
    zT_125 = node.span_len;
    zT_116 = umsg;
    (void)zF_C82559AC_diagnosticCollector(zT_110, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6006_FREEING_UNTRACKED)), (unsigned int)(0), zT_114, (unsigned int)(zT_124 + (unsigned int)((unsigned int)zT_125)), zT_116);
    goto z_bb_7;
    z_bb_9:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_480593AB_AllocState_freed;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    return;
    z_bb_10:
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_freed))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ctx->interner;
    zT_33 = name_id;
    zT_35 = zF_9134020D_stringInternerGet(zT_32, zT_33);
    pn = zT_35;
    zT_37 = "double free of pointer '";
    zT_39 = 24;
    zT_38.ptr = (unsigned char*)zT_37;
    zT_38.len = zT_39;
    dp1 = zT_38;
    zT_41 = "'";
    zT_43 = 1;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    dp2 = zT_42;
    zT_46 = 0;
    zT_45[zT_46] = dp1;
    zT_47 = 1;
    zT_45[zT_47] = pn;
    zT_48 = 2;
    zT_45[zT_48] = dp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        dparts[_i] = zT_45[_i];
        _i++;
    }
}
    zT_53 = ctx->diag;
    zT_50 = zT_53->interner;
    zT_55 = 0;
    zT_56 = dparts + zT_55;
    zT_51 = zT_56;
    zT_58 = zF_8C4BFF7C_diagnosticBuilderMa(zT_50, zT_51, (unsigned int)(3));
    dmsg = zT_58;
    zT_59 = ctx->diag;
    zT_63 = node.span_start;
    zT_73 = node.span_start;
    zT_74 = node.span_len;
    zT_65 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_59, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2005_DOUBLE_FREE)), (unsigned int)(0), zT_63, (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74)), zT_65);
    return;
    z_bb_12:
    zT_78 = state;
    zT_79 = name_id;
    zT_81 = zT_480593AB_AllocState_freed;
    zT_80 = zT_81;
    zF_ACCFA860_stateMapSet(zT_78, zT_79, zT_80);
    goto z_bb_7;
}

/* checkLeaksOnScopeExit */
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state) {
    zT_2C0927B0_StateMap* zT_3;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_6B392E0E_StateEntry* zT_11;
    zT_6B392E0E_StateEntry zT_12;
    unsigned char zT_13;
    zT_D3EB6303_StringInterner* zT_17;
    unsigned int zT_18;
    zT_6B392E0E_StateEntry* zT_20;
    zT_6B392E0E_StateEntry zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_63;
    unsigned int zT_65;
    zT_92FBD55B_Slice_zT_6B392E0E_S entries;
    unsigned int ei;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli lparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_3 = state;
    zT_4 = zF_F0E7F434_stateMapGetEntries(zT_3);
    entries = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    ei = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = entries.len;
    if ((unsigned char)(ei < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = entries.ptr;
    zT_12 = zT_11[ei];
    zT_13 = zT_12.state;
    if ((unsigned char)(zT_13 == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_63 = 1;
    zT_65 = ei + (unsigned int)((unsigned int)zT_63);
    ei = zT_65;
    goto z_bb_1;
    z_bb_5:
    zT_17 = ctx->interner;
    zT_20 = entries.ptr;
    zT_21 = zT_20[ei];
    zT_18 = zT_21.name_id;
    zT_23 = zF_9134020D_stringInternerGet(zT_17, zT_18);
    pn = zT_23;
    zT_25 = "memory leak: pointer '";
    zT_27 = 22;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    lp1 = zT_26;
    zT_29 = "' not freed";
    zT_31 = 11;
    zT_30.ptr = (unsigned char*)zT_29;
    zT_30.len = zT_31;
    lp2 = zT_30;
    zT_34 = 0;
    zT_33[zT_34] = lp1;
    zT_35 = 1;
    zT_33[zT_35] = pn;
    zT_36 = 2;
    zT_33[zT_36] = lp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        lparts[_i] = zT_33[_i];
        _i++;
    }
}
    zT_41 = ctx->diag;
    zT_38 = zT_41->interner;
    zT_43 = 0;
    zT_44 = lparts + zT_43;
    zT_39 = zT_44;
    zT_46 = zF_8C4BFF7C_diagnosticBuilderMa(zT_38, zT_39, (unsigned int)(3));
    lmsg = zT_46;
    zT_47 = ctx->diag;
    zT_53 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_47, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_53);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* handleAllocAssign */
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    zT_2C0927B0_StateMap* zT_27;
    unsigned int zT_28;
    zT_43E16BE5_Opt_8 zT_29 = {0};
    unsigned char zT_30;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38 = {0};
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_54;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_62;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_7E2F335A_AnalyzerContext* zT_81;
    unsigned int zT_82;
    unsigned char zT_83 = 0;
    zT_2C0927B0_StateMap* zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    zT_480593AB_AllocState zT_87;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    zT_2C0927B0_StateMap* zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    zT_480593AB_AllocState zT_102;
    zT_2C0927B0_StateMap* zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    zT_480593AB_AllocState zT_106;
    zT_22A7C88B_AstNode node;
    unsigned int lhs_idx;
    unsigned int rhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int lhs_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u op1;
    zT_8F083A69_Slice_zT_0B42B2F8_u op2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli oparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_22A7C88B_AstNode rhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_0;
    lhs_idx = zT_9;
    zT_11 = node.child_1;
    rhs_idx = zT_11;
    zT_13 = ctx->store;
    zT_14 = lhs_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    lhs_node = zT_16;
    zT_17 = lhs_node.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_22 = ctx->store;
    zT_23 = lhs_idx;
    zT_25 = zF_2E24BD6B_identNameId(zT_22, zT_23);
    lhs_name_id = zT_25;
    zT_27 = state;
    zT_28 = lhs_name_id;
    zT_29 = zF_2EC17ECC_stateMapGet(zT_27, zT_28);
    current = zT_29;
    zT_30 = current.has_value;
    if (zT_30) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_81 = ctx;
    zT_82 = rhs_idx;
    zT_83 = zF_264B254A_isAllocCall(zT_81, zT_82);
    if (zT_83) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_35 = ctx->interner;
    zT_36 = lhs_name_id;
    zT_38 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    pn = zT_38;
    zT_40 = "memory leak: pointer '";
    zT_42 = 22;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    op1 = zT_41;
    zT_44 = "' overwritten before free";
    zT_46 = 25;
    zT_45.ptr = (unsigned char*)zT_44;
    zT_45.len = zT_46;
    op2 = zT_45;
    zT_49 = 0;
    zT_48[zT_49] = op1;
    zT_50 = 1;
    zT_48[zT_50] = pn;
    zT_51 = 2;
    zT_48[zT_51] = op2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        oparts[_i] = zT_48[_i];
        _i++;
    }
}
    zT_56 = ctx->diag;
    zT_53 = zT_56->interner;
    zT_58 = 0;
    zT_59 = oparts + zT_58;
    zT_54 = zT_59;
    zT_61 = zF_8C4BFF7C_diagnosticBuilderMa(zT_53, zT_54, (unsigned int)(3));
    lmsg = zT_61;
    zT_62 = ctx->diag;
    zT_66 = node.span_start;
    zT_76 = node.span_start;
    zT_77 = node.span_len;
    zT_68 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_62, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), zT_66, (unsigned int)(zT_76 + (unsigned int)((unsigned int)zT_77)), zT_68);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_84 = state;
    zT_85 = lhs_name_id;
    zT_87 = zT_480593AB_AllocState_allocated;
    zT_86 = zT_87;
    zF_ACCFA860_stateMapSet(zT_84, zT_85, zT_86);
    return;
    z_bb_8:
    if ((unsigned char)(rhs_idx != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_91 = ctx->store;
    zT_92 = rhs_idx;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    rhs_node = zT_94;
    zT_95 = rhs_node.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_103 = state;
    zT_104 = lhs_name_id;
    zT_106 = zT_480593AB_AllocState_unknown;
    zT_105 = zT_106;
    zF_ACCFA860_stateMapSet(zT_103, zT_104, zT_105);
    return;
    z_bb_11:
    zT_99 = state;
    zT_100 = lhs_name_id;
    zT_102 = zT_480593AB_AllocState_untracked;
    zT_101 = zT_102;
    zF_ACCFA860_stateMapSet(zT_99, zT_100, zT_101);
    return;
    z_bb_12:
    goto z_bb_10;
}

/* handleOwnershipReturn */
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int ret_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_2C0927B0_StateMap* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    unsigned int zT_20 = 0;
    zT_43E16BE5_Opt_8 zT_21 = {0};
    unsigned char zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_480593AB_AllocState zT_33;
    zT_22A7C88B_AstNode node;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    if ((unsigned char)(ret_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = ret_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = state;
    zT_17 = ctx->store;
    zT_18 = ret_expr_idx;
    zT_20 = zF_2E24BD6B_identNameId(zT_17, zT_18);
    zT_16 = zT_20;
    zT_21 = zF_2EC17ECC_stateMapGet(zT_15, zT_16);
    current = zT_21;
    zT_22 = current.has_value;
    if (zT_22) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = ret_expr_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_33 = zT_480593AB_AllocState_returned_val;
    zT_28 = zT_33;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* handleOwnershipPass */
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int fn_call_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_30 = 0;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35 = {0};
    zT_8143F551_AstKind zT_36;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_44 = 0;
    zT_2C0927B0_StateMap* zT_46;
    unsigned int zT_47;
    zT_43E16BE5_Opt_8 zT_48 = {0};
    unsigned char zT_49;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_480593AB_AllocState zT_56;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_D3EB6303_StringInterner* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84 = {0};
    unsigned char zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    zT_F85C5DED_DiagnosticCollector* zT_91;
    unsigned char zT_92;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_104;
    unsigned int zT_105;
    int zT_109;
    unsigned int zT_111;
    zT_22A7C88B_AstNode node;
    unsigned int args_n;
    unsigned int ai;
    unsigned int args_i;
    zT_22A7C88B_AstNode arg_node;
    unsigned int arg_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmsg;
    unsigned char warn_lvl;
    if ((unsigned char)(fn_call_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = fn_call_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ctx->store;
    zT_16 = fn_call_idx;
    zT_18 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    args_n = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    ai = zT_21;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = ctx->store;
    zT_26 = fn_call_idx;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_25, zT_26, (unsigned int)((unsigned int)ai));
    args_i = zT_30;
    zT_32 = ctx->store;
    zT_33 = args_i;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    arg_node = zT_35;
    zT_36 = arg_node.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_109 = 1;
    zT_111 = ai + (unsigned int)((unsigned int)zT_109);
    ai = zT_111;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_41 = ctx->store;
    zT_42 = args_i;
    zT_44 = zF_2E24BD6B_identNameId(zT_41, zT_42);
    arg_name_id = zT_44;
    zT_46 = state;
    zT_47 = arg_name_id;
    zT_48 = zF_2EC17ECC_stateMapGet(zT_46, zT_47);
    current = zT_48;
    zT_49 = current.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_8;
    z_bb_13:
    zT_53 = state;
    zT_54 = arg_name_id;
    zT_56 = zT_480593AB_AllocState_transferred;
    zT_55 = zT_56;
    zF_ACCFA860_stateMapSet(zT_53, zT_54, zT_55);
    zT_58 = ctx->interner;
    zT_59 = arg_name_id;
    zT_61 = zF_9134020D_stringInternerGet(zT_58, zT_59);
    pn = zT_61;
    zT_63 = "ownership of '";
    zT_65 = 14;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    tp1 = zT_64;
    zT_67 = "' transferred to function";
    zT_69 = 25;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    tp2 = zT_68;
    zT_72 = 0;
    zT_71[zT_72] = tp1;
    zT_73 = 1;
    zT_71[zT_73] = pn;
    zT_74 = 2;
    zT_71[zT_74] = tp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tparts[_i] = zT_71[_i];
        _i++;
    }
}
    zT_79 = ctx->diag;
    zT_76 = zT_79->interner;
    zT_81 = 0;
    zT_82 = tparts + zT_81;
    zT_77 = zT_82;
    zT_84 = zF_8C4BFF7C_diagnosticBuilderMa(zT_76, zT_77, (unsigned int)(3));
    tmsg = zT_84;
    zT_86 = 2;
    warn_lvl = zT_86;
    zT_87 = ctx->warn_all;
    if ((unsigned char)(zT_87 != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_90 = 1;
    warn_lvl = zT_90;
    goto z_bb_16;
    z_bb_16:
    zT_91 = ctx->diag;
    zT_92 = warn_lvl;
    zT_95 = node.span_start;
    zT_104 = node.span_start;
    zT_105 = node.span_len;
    zT_97 = tmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_91, zT_92, (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_INFO_7001_OWNERSHIP_TRANSFERRED)), (unsigned int)(0), zT_95, (unsigned int)(zT_104 + (unsigned int)((unsigned int)zT_105)), zT_97);
    goto z_bb_14;
}

/* deferQueueEnsureCapacity */
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext* ctx, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FDFD82FD_EU_362 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_7A19C4A5_DeferEntry* zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7A19C4A5_DeferEntry* zT_35;
    zT_7A19C4A5_DeferEntry zT_36;
    int zT_37;
    unsigned int zT_39;
    unsigned int nc;
    unsigned char* raw;
    zT_7A19C4A5_DeferEntry* new_items;
    unsigned int i;
    zT_2 = ctx->defer_queue_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = ctx->defer_queue_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = ctx->defer_queue_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = ctx->defer_queue_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_7A19C4A5_DeferEntry*)raw;
    new_items = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    i = zT_32;
    goto z_bb_10;
    z_bb_10:
    zT_33 = ctx->defer_queue_len;
    if ((unsigned char)(i < zT_33)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = ctx->defer_queue_items;
    zT_36 = zT_35[i];
    new_items[i] = zT_36;
    goto z_bb_13;
    z_bb_12:
    ctx->defer_queue_items = new_items;
    ctx->defer_queue_cap = nc;
    return;
    z_bb_13:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_10;
}

/* resetDeferQueue */
void zF_61F0EB83_resetDeferQueue(zT_7E2F335A_AnalyzerContext* ctx) {
    int zT_1;
    zT_1 = 0;
    ctx->defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_1;
    ctx->defer_queue_len = (unsigned int)(0);
    ctx->defer_queue_cap = (unsigned int)(0);
    return;
}

/* analyzeSignature */
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_17;
    zT_4EF476FD_anon_318191 zT_18;
    zT_243D6A41_FnProto* zT_19;
    unsigned int zT_20;
    zT_243D6A41_FnProto zT_21;
    unsigned int zT_23;
    unsigned short zT_27;
    zT_79FAE712_u64 zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned int zT_34 = 0;
    int zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_49 = 0;
    zT_22A7C88B_AstNode zT_50 = {0};
    unsigned int zT_52;
    zT_7E2F335A_AnalyzerContext* zT_55;
    unsigned int zT_56;
    zT_7E2F335A_AnalyzerContext* zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_63;
    unsigned int zT_65;
    zT_7E2F335A_AnalyzerContext* zT_68;
    unsigned int zT_69;
    zT_7E2F335A_AnalyzerContext* zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode node;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 param_payload;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned int type_expr;
    unsigned int ret_node;
    zT_3 = ctx->store;
    zT_4 = fn_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = fn_node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    proto_idx = zT_15;
    zT_17 = ctx->store;
    zT_18 = zT_17->fn_protos;
    zT_19 = zT_18.items;
    zT_20 = (unsigned int)proto_idx;
    zT_21 = zT_19[zT_20];
    proto = zT_21;
    zT_23 = proto.params_start;
    zT_27 = proto.params_count;
    zT_29 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_23) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_27);
    param_payload = zT_29;
    zT_31 = ctx->store;
    zT_32 = param_payload;
    zT_34 = zF_03CE8CAB_astStoreGetExtraChi(zT_31, zT_32);
    params_n = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    pi = zT_37;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_41 = ctx->store;
    zT_44 = ctx->store;
    zT_45 = param_payload;
    zT_49 = zF_E5B10421_astStoreGetExtraChi(zT_44, zT_45, (unsigned int)((unsigned int)pi));
    zT_42 = zT_49;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_41, zT_42);
    pnode = zT_50;
    zT_52 = pnode.child_0;
    type_expr = zT_52;
    if ((unsigned char)(type_expr != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_65 = proto.return_type_node;
    ret_node = zT_65;
    if ((unsigned char)(ret_node != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_61 = 1;
    zT_63 = pi + (unsigned int)((unsigned int)zT_61);
    pi = zT_63;
    goto z_bb_3;
    z_bb_7:
    zT_55 = ctx;
    zT_56 = type_expr;
    zF_E153ECE7_validateSignatureTy(zT_55, zT_56, (unsigned int)(0));
    goto z_bb_8;
    z_bb_8:
    zT_59 = ctx;
    zT_60 = type_expr;
    zF_11BB0278_rejectAnytypeType(zT_59, zT_60);
    goto z_bb_6;
    z_bb_9:
    zT_68 = ctx;
    zT_69 = ret_node;
    zF_E153ECE7_validateSignatureTy(zT_68, zT_69, (unsigned int)(1));
    goto z_bb_10;
    z_bb_10:
    zT_72 = ctx;
    zT_73 = ret_node;
    zF_11BB0278_rejectAnytypeType(zT_72, zT_73);
    return;
}

/* rejectAnytypeType */
void zF_11BB0278_rejectAnytypeType(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_27 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_29;
    unsigned int zT_30;
    unsigned char zT_32 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_60;
    unsigned char zT_64;
    unsigned char zT_68;
    unsigned char zT_72;
    zT_7E2F335A_AnalyzerContext* zT_76;
    unsigned int zT_77;
    zT_7E2F335A_AnalyzerContext* zT_82;
    unsigned int zT_83;
    zT_7E2F335A_AnalyzerContext* zT_85;
    unsigned int zT_86;
    zT_7E2F335A_AnalyzerContext* zT_91;
    unsigned int zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    unsigned int zT_97 = 0;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    unsigned int zT_104 = 0;
    int zT_106;
    unsigned int zT_107;
    zT_7E2F335A_AnalyzerContext* zT_110;
    unsigned int zT_111;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned int zT_117 = 0;
    int zT_118;
    unsigned int zT_120;
    zT_22A7C88B_AstNode tnode;
    zT_8143F551_AstKind kind;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    unsigned int ft_n;
    unsigned int ft_i;
    if ((unsigned char)(type_node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = ctx->store;
    zT_6 = type_node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    tnode = zT_8;
    zT_10 = tnode.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx->store;
    zT_16 = type_node_idx;
    zT_18 = zF_2E24BD6B_identNameId(zT_15, zT_16);
    name_id = zT_18;
    zT_20 = "anytype";
    zT_22 = 7;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    s_anytype = zT_21;
    zT_24 = ctx->interner;
    zT_25 = s_anytype;
    zT_27 = zF_50C274AF_stringInternerInter(zT_24, zT_25);
    anytype_nid = zT_27;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_5:
    zT_29 = ctx->diag;
    zT_30 = type_node_idx;
    zT_32 = zF_4DD9DB2D_diagnosticCollector(zT_29, zT_30);
    if ((unsigned char)(!zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    return;
    z_bb_8:
    zT_35 = "anytype not supported in Z98";
    zT_37 = 28;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    amsg = zT_36;
    zT_38 = ctx->diag;
    zT_41 = ctx->source_file_id;
    zT_42 = tnode.span_start;
    zT_52 = tnode.span_start;
    zT_53 = tnode.span_len;
    zT_44 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_38, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), zT_41, zT_42, (unsigned int)(zT_52 + (unsigned int)((unsigned int)zT_53)), zT_44);
    goto z_bb_6;
    z_bb_9:
    zT_60 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_11;
    z_bb_10:
    zT_60 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_60) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_64 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_14;
    z_bb_13:
    zT_64 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_64) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_68 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_17;
    z_bb_16:
    zT_68 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_68) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_72 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_20;
    z_bb_19:
    zT_72 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_72) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_76 = ctx;
    zT_77 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_76, zT_77);
    return;
    z_bb_22:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_82 = ctx;
    zT_83 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_82, zT_83);
    zT_85 = ctx;
    zT_86 = tnode.child_1;
    zF_11BB0278_rejectAnytypeType(zT_85, zT_86);
    return;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_91 = ctx;
    zT_92 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_91, zT_92);
    zT_94 = ctx->store;
    zT_95 = type_node_idx;
    zT_97 = zF_8BA26B9E_astStoreNodePayload(zT_94, zT_95);
    if ((unsigned char)(zT_97 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    return;
    z_bb_27:
    zT_101 = ctx->store;
    zT_102 = type_node_idx;
    zT_104 = zF_152E19CB_astStoreNodeExtraCh(zT_101, zT_102);
    ft_n = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    ft_i = zT_107;
    goto z_bb_29;
    z_bb_28:
    return;
    z_bb_29:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_110 = ctx;
    zT_112 = ctx->store;
    zT_113 = type_node_idx;
    zT_117 = zF_B10B1BC1_astStoreNodeExtraCh(zT_112, zT_113, (unsigned int)((unsigned int)ft_i));
    zT_111 = zT_117;
    zF_11BB0278_rejectAnytypeType(zT_110, zT_111);
    goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_118 = 1;
    zT_120 = ft_i + (unsigned int)((unsigned int)zT_118);
    ft_i = zT_120;
    goto z_bb_29;
}

/* validateSignatureNamed */
void zF_C745AF68_validateSignatureNa(zT_7E2F335A_AnalyzerContext* ctx, unsigned int name_id, unsigned int tnode_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_79FAE712_u64 zT_10;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    unsigned char zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_52;
    unsigned char zT_53;
    zT_D3EB6303_StringInterner* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60 = {0};
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_84;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_98;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_103;
    unsigned char zT_107;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_F85C5DED_DiagnosticCollector* zT_114;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_135;
    unsigned char* zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    zT_F85C5DED_DiagnosticCollector* zT_142;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_D3EB6303_StringInterner* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165 = {0};
    unsigned char zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned char* zT_170;
    unsigned int zT_172 = 0;
    unsigned char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    zT_D3EB6303_StringInterner* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_183 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_185;
    unsigned int zT_186;
    unsigned char zT_188 = 0;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_F85C5DED_DiagnosticCollector* zT_194;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_22A7C88B_AstNode tnode;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 tid;
    unsigned int ttid;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u t5_text;
    unsigned char t5_au;
    unsigned int t5_aw;
    zT_8F083A69_Slice_zT_0B42B2F8_u tname;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli iparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u wmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    zT_5 = ctx->store;
    zT_6 = tnode_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    tnode = zT_8;
    zT_10 = (zT_79FAE712_u64)name_id;
    key = zT_10;
    zT_12 = ctx->registry;
    zT_13 = key;
    zT_15 = zF_0EB68360_nameCacheGet(zT_12, zT_13);
    tid = zT_15;
    zT_16 = tid.has_value;
    if (zT_16) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    ttid = tid.value;
    zT_19 = ctx->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)ttid;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_5; else goto z_bb_4;
    z_bb_2:
    zT_176 = "anytype";
    zT_178 = 7;
    zT_177.ptr = (unsigned char*)zT_176;
    zT_177.len = zT_178;
    s_anytype = zT_177;
    zT_180 = ctx->interner;
    zT_181 = s_anytype;
    zT_183 = zF_50C274AF_stringInternerInter(zT_180, zT_181);
    anytype_nid = zT_183;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_35; else goto z_bb_36;
    z_bb_3:
    zT_162 = ctx->interner;
    zT_163 = name_id;
    zT_165 = zF_9134020D_stringInternerGet(zT_162, zT_163);
    t5_text = zT_165;
    zT_167 = 0;
    t5_au = zT_167;
    zT_169 = t5_text;
    zT_170 = (unsigned char*)&t5_au;
    zT_172 = zF_741B5264_parseArbIntWidth(zT_169, zT_170);
    t5_aw = zT_172;
    if ((unsigned char)(t5_aw != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_4:
    zT_28 = ty.kind;
    if ((unsigned char)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_8; else goto z_bb_7;
    z_bb_5:
    zT_27 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_27) goto z_bb_22; else goto z_bb_23;
    z_bb_7:
    zT_33 = ty.kind;
    zT_32 = zT_33 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_32 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_32) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_38 = ty.kind;
    zT_37 = zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_12;
    z_bb_11:
    zT_37 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_37) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_42 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_42) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_48 = ty.kind;
    zT_47 = zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_18;
    z_bb_17:
    zT_47 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_47) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_53 = ty.state;
    zT_52 = zT_53 != (unsigned char)(2);
    goto z_bb_21;
    z_bb_20:
    zT_52 = 0;
    goto z_bb_21;
    z_bb_21:
    zT_27 = zT_52;
    goto z_bb_6;
    z_bb_22:
    zT_57 = ctx->interner;
    zT_58 = name_id;
    zT_60 = zF_9134020D_stringInternerGet(zT_57, zT_58);
    tname = zT_60;
    zT_62 = "incomplete type '";
    zT_64 = 17;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    ip1 = zT_63;
    zT_66 = "' in function signature";
    zT_68 = 23;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    ip2 = zT_67;
    zT_71 = 0;
    zT_70[zT_71] = ip1;
    zT_72 = 1;
    zT_70[zT_72] = tname;
    zT_73 = 2;
    zT_70[zT_73] = ip2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        iparts[_i] = zT_70[_i];
        _i++;
    }
}
    zT_78 = ctx->diag;
    zT_75 = zT_78->interner;
    zT_80 = 0;
    zT_81 = iparts + zT_80;
    zT_76 = zT_81;
    zT_83 = zF_8C4BFF7C_diagnosticBuilderMa(zT_75, zT_76, (unsigned int)(3));
    imsg = zT_83;
    zT_84 = ctx->diag;
    zT_88 = tnode.span_start;
    zT_98 = tnode.span_start;
    zT_99 = tnode.span_len;
    zT_90 = imsg;
    (void)zF_C82559AC_diagnosticCollector(zT_84, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2011_INCOMPLETE_TYPE)), (unsigned int)(0), zT_88, (unsigned int)(zT_98 + (unsigned int)((unsigned int)zT_99)), zT_90);
    goto z_bb_23;
    z_bb_23:
    zT_103 = ty.kind;
    if ((unsigned char)(zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_107 = is_return == (unsigned int)(0);
    goto z_bb_26;
    z_bb_25:
    zT_107 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_107) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_111 = "void not allowed as parameter type";
    zT_113 = 34;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    vmsg = zT_112;
    zT_114 = ctx->diag;
    zT_118 = tnode.span_start;
    zT_128 = tnode.span_start;
    zT_129 = tnode.span_len;
    zT_120 = vmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_114, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2010_VOID_PARAMETER)), (unsigned int)(0), zT_118, (unsigned int)(zT_128 + (unsigned int)((unsigned int)zT_129)), zT_120);
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(is_return == (unsigned int)(1))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_135 = ty.size;
    if ((unsigned char)(zT_135 > (unsigned int)(64))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_2;
    z_bb_31:
    zT_139 = "return type exceeds 64 bytes; may cause issues on MSVC 6.0";
    zT_141 = 58;
    zT_140.ptr = (unsigned char*)zT_139;
    zT_140.len = zT_141;
    wmsg = zT_140;
    zT_142 = ctx->diag;
    zT_146 = tnode.span_start;
    zT_156 = tnode.span_start;
    zT_157 = tnode.span_len;
    zT_148 = wmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_142, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7010_LARGE_RETURN)), (unsigned int)(0), zT_146, (unsigned int)(zT_156 + (unsigned int)((unsigned int)zT_157)), zT_148);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    return;
    z_bb_34:
    goto z_bb_2;
    z_bb_35:
    zT_185 = ctx->diag;
    zT_186 = tnode_idx;
    zT_188 = zF_4DD9DB2D_diagnosticCollector(zT_185, zT_186);
    if ((unsigned char)(!zT_188)) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    return;
    z_bb_37:
    return;
    z_bb_38:
    zT_191 = "anytype not supported in Z98";
    zT_193 = 28;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    amsg = zT_192;
    zT_194 = ctx->diag;
    zT_197 = ctx->source_file_id;
    zT_198 = tnode.span_start;
    zT_208 = tnode.span_start;
    zT_209 = tnode.span_len;
    zT_200 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_194, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), zT_197, zT_198, (unsigned int)(zT_208 + (unsigned int)((unsigned int)zT_209)), zT_200);
    goto z_bb_36;
}

/* validateSignatureType */
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_7E2F335A_AnalyzerContext* zT_26;
    unsigned int zT_27;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_37;
    unsigned int zT_38;
    zT_7E2F335A_AnalyzerContext* zT_42;
    unsigned int zT_43;
    unsigned char zT_50;
    unsigned char zT_54;
    unsigned char zT_58;
    zT_7E2F335A_AnalyzerContext* zT_62;
    unsigned int zT_63;
    zT_7E2F335A_AnalyzerContext* zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_78 = 0;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    unsigned int zT_85 = 0;
    int zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_97 = 0;
    zT_7E2F335A_AnalyzerContext* zT_98;
    unsigned int zT_99;
    zT_7E2F335A_AnalyzerContext* zT_102;
    unsigned int zT_103;
    int zT_104;
    unsigned int zT_106;
    zT_6B0A7D14_AstStore* zT_111;
    unsigned int zT_112;
    unsigned int zT_114 = 0;
    zT_7E2F335A_AnalyzerContext* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_22A7C88B_AstNode tnode;
    zT_8143F551_AstKind kind;
    unsigned int ft_n;
    unsigned int ft_i;
    unsigned int ft_p;
    unsigned int t5_mname;
    if ((unsigned char)(type_node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = type_node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    tnode = zT_9;
    zT_11 = tnode.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_19 = ctx->store;
    zT_20 = type_node_idx;
    zT_22 = zF_2E24BD6B_identNameId(zT_19, zT_20);
    zT_16 = zT_22;
    zT_17 = type_node_idx;
    zT_18 = is_return;
    zF_C745AF68_validateSignatureNa(zT_15, zT_16, zT_17, zT_18);
    return;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = ctx;
    zT_27 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_26, zT_27, (unsigned int)(2));
    return;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = tnode.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_12; else goto z_bb_11;
    z_bb_9:
    zT_37 = ctx;
    zT_38 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_37, zT_38, (unsigned int)(2));
    goto z_bb_10;
    z_bb_10:
    zT_42 = ctx;
    zT_43 = tnode.child_1;
    zF_E153ECE7_validateSignatureTy(zT_42, zT_43, (unsigned int)(2));
    return;
    z_bb_11:
    zT_50 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_13;
    z_bb_12:
    zT_50 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_50) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_54 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_16;
    z_bb_15:
    zT_54 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_54) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_58 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_19;
    z_bb_18:
    zT_58 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_58) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = ctx;
    zT_63 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_62, zT_63, (unsigned int)(2));
    return;
    z_bb_21:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_70 = ctx;
    zT_71 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_70, zT_71, (unsigned int)(1));
    zT_75 = ctx->store;
    zT_76 = type_node_idx;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_75, zT_76);
    if ((unsigned char)(zT_78 != (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_30; else goto z_bb_31;
    z_bb_24:
    zT_82 = ctx->store;
    zT_83 = type_node_idx;
    zT_85 = zF_152E19CB_astStoreNodeExtraCh(zT_82, zT_83);
    ft_n = zT_85;
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    ft_i = zT_88;
    goto z_bb_26;
    z_bb_25:
    return;
    z_bb_26:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = ctx->store;
    zT_93 = type_node_idx;
    zT_97 = zF_B10B1BC1_astStoreNodeExtraCh(zT_92, zT_93, (unsigned int)((unsigned int)ft_i));
    ft_p = zT_97;
    zT_98 = ctx;
    zT_99 = ft_p;
    zF_E153ECE7_validateSignatureTy(zT_98, zT_99, (unsigned int)(2));
    zT_102 = ctx;
    zT_103 = ft_p;
    zF_11BB0278_rejectAnytypeType(zT_102, zT_103);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_104 = 1;
    zT_106 = ft_i + (unsigned int)((unsigned int)zT_104);
    ft_i = zT_106;
    goto z_bb_26;
    z_bb_30:
    zT_111 = ctx->store;
    zT_112 = type_node_idx;
    zT_114 = zF_8BA26B9E_astStoreNodePayload(zT_111, zT_112);
    t5_mname = zT_114;
    if ((unsigned char)(t5_mname != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    return;
    z_bb_32:
    zT_117 = ctx;
    zT_118 = t5_mname;
    zT_119 = type_node_idx;
    zT_120 = is_return;
    zF_C745AF68_validateSignatureNa(zT_117, zT_118, zT_119, zT_120);
    goto z_bb_33;
    z_bb_33:
    return;
}

/* analyzeExpr */
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20 = 0;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_F85C5DED_DiagnosticCollector* zT_34;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_F85C5DED_DiagnosticCollector* zT_54;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_74;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    zT_7E2F335A_AnalyzerContext* zT_91;
    zT_2C0927B0_StateMap* zT_92;
    unsigned int zT_93;
    zT_7E2F335A_AnalyzerContext* zT_98;
    zT_2C0927B0_StateMap* zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    unsigned int zT_109 = 0;
    int zT_111;
    unsigned int zT_112;
    zT_7E2F335A_AnalyzerContext* zT_115;
    zT_2C0927B0_StateMap* zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_123 = 0;
    int zT_124;
    unsigned int zT_126;
    zT_6B0A7D14_AstStore* zT_131;
    unsigned int zT_132;
    unsigned int zT_134 = 0;
    int zT_136;
    unsigned int zT_137;
    zT_7E2F335A_AnalyzerContext* zT_140;
    zT_2C0927B0_StateMap* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_148 = 0;
    int zT_149;
    unsigned int zT_151;
    zT_7E2F335A_AnalyzerContext* zT_156;
    unsigned int zT_157;
    int zT_160;
    zT_49E17557_Opt_2 zT_162 = {0};
    unsigned char zT_163;
    zT_6B0A7D14_AstStore* zT_165;
    unsigned int zT_166;
    unsigned int zT_168 = 0;
    zT_7E2F335A_AnalyzerContext* zT_171;
    zT_2C0927B0_StateMap* zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    zT_7E2F335A_AnalyzerContext* zT_178;
    zT_2C0927B0_StateMap* zT_179;
    unsigned int zT_180;
    zT_7E2F335A_AnalyzerContext* zT_182;
    zT_2C0927B0_StateMap* zT_183;
    unsigned int zT_184;
    zT_6B0A7D14_AstStore* zT_187;
    unsigned int zT_188;
    unsigned int zT_190 = 0;
    zT_2C0927B0_StateMap* zT_194;
    zT_3E40CD83_Sand* zT_195;
    zT_2C0927B0_StateMap* zT_197 = 0;
    zT_7E2F335A_AnalyzerContext* zT_198;
    zT_2C0927B0_StateMap* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_7E2F335A_AnalyzerContext* zT_203;
    zT_2C0927B0_StateMap* zT_204;
    unsigned int zT_205;
    zT_7E2F335A_AnalyzerContext* zT_207;
    zT_2C0927B0_StateMap* zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    zT_7E2F335A_AnalyzerContext* zT_214;
    zT_2C0927B0_StateMap* zT_215;
    unsigned int zT_216;
    zT_7E2F335A_AnalyzerContext* zT_221;
    zT_2C0927B0_StateMap* zT_222;
    unsigned int zT_223;
    unsigned int zT_226;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    zT_22A7C88B_AstNode zT_235 = {0};
    zT_8143F551_AstKind zT_236;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    unsigned int zT_244 = 0;
    zT_2C0927B0_StateMap* zT_248;
    zT_3E40CD83_Sand* zT_249;
    zT_2C0927B0_StateMap* zT_251 = 0;
    zT_7E2F335A_AnalyzerContext* zT_252;
    zT_2C0927B0_StateMap* zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    zT_7E2F335A_AnalyzerContext* zT_257;
    zT_2C0927B0_StateMap* zT_258;
    unsigned int zT_259;
    zT_7E2F335A_AnalyzerContext* zT_261;
    zT_2C0927B0_StateMap* zT_262;
    unsigned int zT_263;
    zT_7E2F335A_AnalyzerContext* zT_268;
    zT_2C0927B0_StateMap* zT_269;
    unsigned int zT_270;
    zT_6B0A7D14_AstStore* zT_273;
    unsigned int zT_274;
    zT_22A7C88B_AstNode zT_277 = {0};
    zT_8143F551_AstKind zT_278;
    zT_7E2F335A_AnalyzerContext* zT_283;
    zT_2C0927B0_StateMap* zT_284;
    unsigned int zT_285;
    unsigned char zT_287 = 0;
    zT_2C0927B0_StateMap* zT_288;
    unsigned int zT_289;
    unsigned char zT_290;
    zT_6B0A7D14_AstStore* zT_291;
    unsigned int zT_292;
    unsigned int zT_295 = 0;
    unsigned int zT_296;
    unsigned char zT_299;
    zT_8143F551_AstKind zT_300;
    unsigned char zT_303 = 0;
    zT_7E2F335A_AnalyzerContext* zT_304;
    zT_2C0927B0_StateMap* zT_305;
    unsigned int zT_306;
    unsigned int zT_308;
    unsigned char zT_311;
    zT_8143F551_AstKind zT_312;
    unsigned char zT_315 = 0;
    zT_7E2F335A_AnalyzerContext* zT_316;
    zT_2C0927B0_StateMap* zT_317;
    unsigned int zT_318;
    unsigned int zT_320;
    unsigned char zT_323;
    zT_8143F551_AstKind zT_324;
    unsigned char zT_327 = 0;
    zT_7E2F335A_AnalyzerContext* zT_328;
    zT_2C0927B0_StateMap* zT_329;
    unsigned int zT_330;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char st;
    unsigned int start;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int args_n;
    unsigned int ai;
    unsigned int bargs_n;
    unsigned int bi;
    zT_49E17557_Opt_2 t5_ief;
    unsigned char iev;
    unsigned int t5_iecap;
    zT_2C0927B0_StateMap* t5_ies;
    unsigned int t5_ecap;
    zT_22A7C88B_AstNode capn;
    zT_2C0927B0_StateMap* t5_ecs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned char new_st;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_0;
    zT_20 = zF_0619AC1C_classifyExpr(zT_16, zT_17, zT_18);
    st = zT_20;
    zT_22 = node.span_start;
    start = zT_22;
    zT_24 = node.span_start;
    zT_25 = node.span_len;
    zT_27 = zT_24 + (unsigned int)((unsigned int)zT_25);
    end = zT_27;
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_is_null))) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_31 = "definite null pointer dereference";
    zT_33 = 33;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    msg = zT_32;
    zT_34 = ctx->diag;
    zT_38 = start;
    zT_39 = end;
    zT_40 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_34, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2004_DEFINITE_NULL_DEREF)), (unsigned int)(0), zT_38, zT_39, zT_40);
    goto z_bb_6;
    z_bb_6:
    return;
    z_bb_7:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_uninit))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_51 = "dereference of uninitialized pointer";
    zT_53 = 36;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    msg = zT_52;
    zT_54 = ctx->diag;
    zT_58 = start;
    zT_59 = end;
    zT_60 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_54, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6001_UNINIT_DEREF)), (unsigned int)(0), zT_58, zT_59, zT_60);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_maybe))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_71 = "potential null pointer dereference";
    zT_73 = 34;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    msg = zT_72;
    zT_74 = ctx->diag;
    zT_78 = start;
    zT_79 = end;
    zT_80 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_74, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6002_POTENTIAL_NULL_DEREF)), (unsigned int)(0), zT_78, zT_79, zT_80);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_91 = ctx;
    zT_92 = state;
    zT_93 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_91, zT_92, zT_93);
    return;
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_98 = ctx;
    zT_99 = state;
    zT_100 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_98, zT_99, zT_100);
    return;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_106 = ctx->store;
    zT_107 = expr_idx;
    zT_109 = zF_152E19CB_astStoreNodeExtraCh(zT_106, zT_107);
    args_n = zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    ai = zT_112;
    goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_115 = ctx;
    zT_116 = state;
    zT_118 = ctx->store;
    zT_119 = expr_idx;
    zT_123 = zF_B10B1BC1_astStoreNodeExtraCh(zT_118, zT_119, (unsigned int)((unsigned int)ai));
    zT_117 = zT_123;
    zF_8D5B6C98_analyzeExpr(zT_115, zT_116, zT_117);
    goto z_bb_22;
    z_bb_21:
    return;
    z_bb_22:
    zT_124 = 1;
    zT_126 = ai + (unsigned int)((unsigned int)zT_124);
    ai = zT_126;
    goto z_bb_19;
    z_bb_23:
    zT_131 = ctx->store;
    zT_132 = expr_idx;
    zT_134 = zF_152E19CB_astStoreNodeExtraCh(zT_131, zT_132);
    bargs_n = zT_134;
    zT_136 = 0;
    zT_137 = (unsigned int)zT_136;
    bi = zT_137;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)bargs_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_140 = ctx;
    zT_141 = state;
    zT_143 = ctx->store;
    zT_144 = expr_idx;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_143, zT_144, (unsigned int)((unsigned int)bi));
    zT_142 = zT_148;
    zF_8D5B6C98_analyzeExpr(zT_140, zT_141, zT_142);
    goto z_bb_28;
    z_bb_27:
    return;
    z_bb_28:
    zT_149 = 1;
    zT_151 = bi + (unsigned int)((unsigned int)zT_149);
    bi = zT_151;
    goto z_bb_25;
    z_bb_29:
    zT_156 = ctx;
    zT_157 = node.child_0;
    zT_160 = 0;
    zT_162 = zF_A1341A8A_analyzerFoldComptim(zT_156, zT_157, (unsigned int)((unsigned int)zT_160));
    t5_ief = zT_162;
    zT_163 = t5_ief.has_value;
    if (zT_163) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_45; else goto z_bb_46;
    z_bb_31:
    iev = t5_ief.value;
    zT_165 = ctx->store;
    zT_166 = expr_idx;
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_165, zT_166);
    if ((unsigned char)(zT_168 == (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_182 = ctx;
    zT_183 = state;
    zT_184 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_182, zT_183, zT_184);
    zT_187 = ctx->store;
    zT_188 = expr_idx;
    zT_190 = zF_CE47A44A_captureNameIdOf(zT_187, zT_188);
    t5_iecap = zT_190;
    if ((unsigned char)(t5_iecap != (unsigned int)(0))) goto z_bb_40; else goto z_bb_42;
    z_bb_33:
    if (iev) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_171 = ctx;
    zT_172 = state;
    zT_173 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_171, zT_172, zT_173);
    goto z_bb_36;
    z_bb_36:
    return;
    z_bb_37:
    zT_175 = node.child_2;
    if ((unsigned char)(zT_175 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_178 = ctx;
    zT_179 = state;
    zT_180 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_178, zT_179, zT_180);
    goto z_bb_39;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_194 = state;
    zT_195 = ctx->alloc;
    zT_197 = zF_77086C9C_stateMapFork(zT_194, zT_195);
    t5_ies = zT_197;
    zT_198 = ctx;
    zT_199 = t5_ies;
    zT_200 = t5_iecap;
    zT_201 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_198, zT_199, zT_200, zT_201);
    zT_203 = ctx;
    zT_204 = t5_ies;
    zT_205 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_203, zT_204, zT_205);
    goto z_bb_41;
    z_bb_41:
    zT_211 = node.child_2;
    if ((unsigned char)(zT_211 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_207 = ctx;
    zT_208 = state;
    zT_209 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_207, zT_208, zT_209);
    goto z_bb_41;
    z_bb_43:
    zT_214 = ctx;
    zT_215 = state;
    zT_216 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_214, zT_215, zT_216);
    goto z_bb_44;
    z_bb_44:
    return;
    z_bb_45:
    zT_221 = ctx;
    zT_222 = state;
    zT_223 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_221, zT_222, zT_223);
    zT_226 = 0;
    t5_ecap = zT_226;
    zT_227 = node.child_2;
    if ((unsigned char)(zT_227 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_54; else goto z_bb_55;
    z_bb_47:
    zT_231 = ctx->store;
    zT_232 = node.child_2;
    zT_235 = zF_FCDD1D35_astStoreNodeAt(zT_231, zT_232);
    capn = zT_235;
    zT_236 = capn.kind;
    if ((unsigned char)(zT_236 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_payload_capture))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    if ((unsigned char)(t5_ecap != (unsigned int)(0))) goto z_bb_51; else goto z_bb_53;
    z_bb_49:
    zT_240 = ctx->store;
    zT_241 = node.child_2;
    zT_244 = zF_8BA26B9E_astStoreNodePayload(zT_240, zT_241);
    t5_ecap = zT_244;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_248 = state;
    zT_249 = ctx->alloc;
    zT_251 = zF_77086C9C_stateMapFork(zT_248, zT_249);
    t5_ecs = zT_251;
    zT_252 = ctx;
    zT_253 = t5_ecs;
    zT_254 = t5_ecap;
    zT_255 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_252, zT_253, zT_254, zT_255);
    zT_257 = ctx;
    zT_258 = t5_ecs;
    zT_259 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_257, zT_258, zT_259);
    goto z_bb_52;
    z_bb_52:
    return;
    z_bb_53:
    zT_261 = ctx;
    zT_262 = state;
    zT_263 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_261, zT_262, zT_263);
    goto z_bb_52;
    z_bb_54:
    zT_268 = ctx;
    zT_269 = state;
    zT_270 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_268, zT_269, zT_270);
    zT_273 = ctx->store;
    zT_274 = node.child_0;
    zT_277 = zF_FCDD1D35_astStoreNodeAt(zT_273, zT_274);
    lhs_node = zT_277;
    zT_278 = lhs_node.kind;
    if ((unsigned char)(zT_278 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_296 = node.child_0;
    if ((unsigned char)(zT_296 != (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    zT_283 = ctx;
    zT_284 = state;
    zT_285 = node.child_1;
    zT_287 = zF_0619AC1C_classifyExpr(zT_283, zT_284, zT_285);
    new_st = zT_287;
    zT_288 = state;
    zT_291 = ctx->store;
    zT_292 = node.child_0;
    zT_295 = zF_2E24BD6B_identNameId(zT_291, zT_292);
    zT_289 = zT_295;
    zT_290 = new_st;
    zF_ACCFA860_stateMapSet(zT_288, zT_289, zT_290);
    goto z_bb_57;
    z_bb_57:
    return;
    z_bb_58:
    zT_300 = kind;
    zT_303 = zF_C395F6FD_nodeChildIsNode(zT_300, (unsigned char)(0));
    zT_299 = zT_303;
    goto z_bb_60;
    z_bb_59:
    zT_299 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_299) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_304 = ctx;
    zT_305 = state;
    zT_306 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_304, zT_305, zT_306);
    goto z_bb_62;
    z_bb_62:
    zT_308 = node.child_1;
    if ((unsigned char)(zT_308 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_312 = kind;
    zT_315 = zF_C395F6FD_nodeChildIsNode(zT_312, (unsigned char)(1));
    zT_311 = zT_315;
    goto z_bb_65;
    z_bb_64:
    zT_311 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_311) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_316 = ctx;
    zT_317 = state;
    zT_318 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_316, zT_317, zT_318);
    goto z_bb_67;
    z_bb_67:
    zT_320 = node.child_2;
    if ((unsigned char)(zT_320 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_324 = kind;
    zT_327 = zF_C395F6FD_nodeChildIsNode(zT_324, (unsigned char)(2));
    zT_323 = zT_327;
    goto z_bb_70;
    z_bb_69:
    zT_323 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_323) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_328 = ctx;
    zT_329 = state;
    zT_330 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_328, zT_329, zT_330);
    goto z_bb_72;
    z_bb_72:
    return;
}

/* classifyExpr */
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_12;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_79FAE712_u64 zT_44 = 0;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58 = 0;
    zT_43E16BE5_Opt_8 zT_59 = {0};
    unsigned char zT_60;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_79FAE712_u64 val;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(zT_E48CAD8A_PtrState_uninit);
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = expr_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = node.kind;
    kind = zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_41 = ctx->store;
    zT_42 = expr_idx;
    zT_44 = zF_678B9A72_astStoreIntValue(zT_41, zT_42);
    val = zT_44;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_18:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_19:
    zT_53 = state;
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_2E24BD6B_identNameId(zT_55, zT_56);
    zT_54 = zT_58;
    zT_59 = zF_2EC17ECC_stateMapGet(zT_53, zT_54);
    result = zT_59;
    zT_60 = result.has_value;
    if (zT_60) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_21:
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
}

/* isNullExpr */
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_21 = 0;
    zT_22A7C88B_AstNode node;
    zT_79FAE712_u64 val;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = store;
    zT_20 = idx;
    zT_21 = zF_678B9A72_astStoreIntValue(zT_19, zT_20);
    val = zT_21;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* isIdentExpr */
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_15 = 0;
    zT_BAEE192E_Opt_10 zT_16;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    zT_22A7C88B_AstNode node;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = store;
    zT_14 = idx;
    zT_15 = zF_2E24BD6B_identNameId(zT_13, zT_14);
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_4:
    zT_17.has_value = 0;
    return zT_17;
}

/* detectNullGuard */
zT_57CCFBBB_Opt_121 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore* store, unsigned int cond_idx) {
    zT_57CCFBBB_Opt_121 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned char zT_18 = 0;
    int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    zT_438E6589_NullGuard zT_28;
    unsigned char zT_29;
    zT_57CCFBBB_Opt_121 zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    int zT_36;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_42 = {0};
    unsigned char zT_43;
    zT_438E6589_NullGuard zT_45;
    unsigned char zT_46;
    zT_57CCFBBB_Opt_121 zT_47;
    zT_57CCFBBB_Opt_121 zT_48 = {0};
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned char zT_56 = 0;
    int zT_57;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_BAEE192E_Opt_10 zT_63 = {0};
    unsigned char zT_64;
    zT_438E6589_NullGuard zT_66;
    unsigned char zT_67;
    zT_57CCFBBB_Opt_121 zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned char zT_73 = 0;
    int zT_74;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    zT_438E6589_NullGuard zT_83;
    unsigned char zT_84;
    zT_57CCFBBB_Opt_121 zT_85;
    zT_57CCFBBB_Opt_121 zT_86 = {0};
    zT_438E6589_NullGuard zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_93 = 0;
    unsigned char zT_94;
    zT_57CCFBBB_Opt_121 zT_95;
    zT_6B0A7D14_AstStore* zT_100;
    unsigned int zT_101;
    zT_57CCFBBB_Opt_121 zT_103 = {0};
    unsigned char zT_104;
    zT_438E6589_NullGuard zT_106;
    unsigned int zT_107;
    int zT_108;
    unsigned char zT_109;
    unsigned char zT_111;
    zT_57CCFBBB_Opt_121 zT_112;
    zT_57CCFBBB_Opt_121 zT_113 = {0};
    zT_57CCFBBB_Opt_121 zT_114 = {0};
    zT_22A7C88B_AstNode cond;
    zT_8143F551_AstKind ck;
    unsigned char n0;
    zT_BAEE192E_Opt_10 id1;
    unsigned char n1;
    unsigned int nid;
    zT_BAEE192E_Opt_10 id0;
    zT_57CCFBBB_Opt_121 inner;
    zT_438E6589_NullGuard g;
    if ((unsigned char)(cond_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = cond_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    cond = zT_8;
    zT_10 = cond.kind;
    ck = zT_10;
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = store;
    zT_16 = cond.child_0;
    zT_18 = zF_F32BD543_isNullExpr(zT_15, zT_16);
    n0 = zT_18;
    zT_19 = 0;
    if ((unsigned char)(n0 != zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_22 = store;
    zT_23 = cond.child_1;
    zT_25 = zF_7B65B82E_isIdentExpr(zT_22, zT_23);
    id1 = zT_25;
    zT_26 = id1.has_value;
    if (zT_26) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_32 = store;
    zT_33 = cond.child_1;
    zT_35 = zF_F32BD543_isNullExpr(zT_32, zT_33);
    n1 = zT_35;
    zT_36 = 0;
    if ((unsigned char)(n1 != zT_36)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    nid = id1.value;
    zT_28.name_id = nid;
    zT_29 = 1;
    zT_28.is_not_null = zT_29;
    zT_30.has_value = 1;
    zT_30.value = zT_28;
    return zT_30;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_39 = store;
    zT_40 = cond.child_0;
    zT_42 = zF_7B65B82E_isIdentExpr(zT_39, zT_40);
    id0 = zT_42;
    zT_43 = id0.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_11:
    nid = id0.value;
    zT_45.name_id = nid;
    zT_46 = 1;
    zT_45.is_not_null = zT_46;
    zT_47.has_value = 1;
    zT_47.value = zT_45;
    return zT_47;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_53 = store;
    zT_54 = cond.child_0;
    zT_56 = zF_F32BD543_isNullExpr(zT_53, zT_54);
    n0 = zT_56;
    zT_57 = 0;
    if ((unsigned char)(n0 != zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    zT_60 = store;
    zT_61 = cond.child_1;
    zT_63 = zF_7B65B82E_isIdentExpr(zT_60, zT_61);
    id1 = zT_63;
    zT_64 = id1.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_70 = store;
    zT_71 = cond.child_1;
    zT_73 = zF_F32BD543_isNullExpr(zT_70, zT_71);
    n1 = zT_73;
    zT_74 = 0;
    if ((unsigned char)(n1 != zT_74)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    nid = id1.value;
    zT_66.name_id = nid;
    zT_67 = 0;
    zT_66.is_not_null = zT_67;
    zT_68.has_value = 1;
    zT_68.value = zT_66;
    return zT_68;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_77 = store;
    zT_78 = cond.child_0;
    zT_80 = zF_7B65B82E_isIdentExpr(zT_77, zT_78);
    id0 = zT_80;
    zT_81 = id0.has_value;
    if (zT_81) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_86.has_value = 0;
    return zT_86;
    z_bb_21:
    nid = id0.value;
    zT_83.name_id = nid;
    zT_84 = 0;
    zT_83.is_not_null = zT_84;
    zT_85.has_value = 1;
    zT_85.value = zT_83;
    return zT_85;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_91 = store;
    zT_92 = cond_idx;
    zT_93 = zF_2E24BD6B_identNameId(zT_91, zT_92);
    zT_90.name_id = zT_93;
    zT_94 = 1;
    zT_90.is_not_null = zT_94;
    zT_95.has_value = 1;
    zT_95.value = zT_90;
    return zT_95;
    z_bb_24:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_100 = store;
    zT_101 = cond.child_0;
    zT_103 = zF_8D299A60_detectNullGuard(zT_100, zT_101);
    inner = zT_103;
    zT_104 = inner.has_value;
    if (zT_104) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_27:
    g = inner.value;
    zT_107 = g.name_id;
    zT_106.name_id = zT_107;
    zT_108 = 1;
    zT_109 = g.is_not_null;
    zT_111 = (unsigned char)(unsigned char)(zT_108 - zT_109);
    zT_106.is_not_null = zT_111;
    zT_112.has_value = 1;
    zT_112.value = zT_106;
    return zT_112;
    z_bb_28:
    zT_113.has_value = 0;
    return zT_113;
}

/* applyNullGuardRefinement */
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore* store, unsigned int cond_idx, zT_2C0927B0_StateMap* then_state, zT_2C0927B0_StateMap* else_state) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_57CCFBBB_Opt_121 zT_7 = {0};
    unsigned char zT_8;
    unsigned char zT_10;
    int zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zT_E48CAD8A_PtrState zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_E48CAD8A_PtrState zT_22;
    zT_2C0927B0_StateMap* zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    zT_E48CAD8A_PtrState zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    zT_E48CAD8A_PtrState zT_32;
    zT_57CCFBBB_Opt_121 guard;
    zT_438E6589_NullGuard g;
    zT_5 = store;
    zT_6 = cond_idx;
    zT_7 = zF_8D299A60_detectNullGuard(zT_5, zT_6);
    guard = zT_7;
    zT_8 = guard.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    g = guard.value;
    zT_10 = g.is_not_null;
    zT_11 = 0;
    if ((unsigned char)(zT_10 != zT_11)) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_13 = then_state;
    zT_14 = g.name_id;
    zT_17 = zT_E48CAD8A_PtrState_safe;
    zT_15 = zT_17;
    zF_ACCFA860_stateMapSet(zT_13, zT_14, zT_15);
    zT_18 = else_state;
    zT_19 = g.name_id;
    zT_22 = zT_E48CAD8A_PtrState_is_null;
    zT_20 = zT_22;
    zF_ACCFA860_stateMapSet(zT_18, zT_19, zT_20);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = then_state;
    zT_24 = g.name_id;
    zT_27 = zT_E48CAD8A_PtrState_is_null;
    zT_25 = zT_27;
    zF_ACCFA860_stateMapSet(zT_23, zT_24, zT_25);
    zT_28 = else_state;
    zT_29 = g.name_id;
    zT_32 = zT_E48CAD8A_PtrState_safe;
    zT_30 = zT_32;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, zT_30);
    goto z_bb_4;
}

/* handleNullVarDecl */
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_14;
    zT_7E2F335A_AnalyzerContext* zT_18;
    zT_2C0927B0_StateMap* zT_19;
    unsigned int zT_20;
    unsigned char zT_21 = 0;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_E48CAD8A_PtrState zT_28;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int init_idx;
    unsigned char st;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = ctx->store;
    zT_10 = node_idx;
    zT_12 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    name_id = zT_12;
    zT_14 = node.child_1;
    init_idx = zT_14;
    if ((unsigned char)(init_idx != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_18 = ctx;
    zT_19 = state;
    zT_20 = init_idx;
    zT_21 = zF_0619AC1C_classifyExpr(zT_18, zT_19, zT_20);
    st = zT_21;
    zT_22 = state;
    zT_23 = name_id;
    zT_24 = st;
    zF_ACCFA860_stateMapSet(zT_22, zT_23, zT_24);
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_E48CAD8A_PtrState_uninit;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_2;
}

/* handleNullAssign */
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    zT_7E2F335A_AnalyzerContext* zT_11;
    zT_2C0927B0_StateMap* zT_12;
    unsigned int zT_13;
    unsigned char zT_14 = 0;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_8143F551_AstKind zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int rhs;
    unsigned char rhs_state;
    unsigned int lhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_1;
    rhs = zT_9;
    zT_11 = ctx;
    zT_12 = state;
    zT_13 = rhs;
    zT_14 = zF_0619AC1C_classifyExpr(zT_11, zT_12, zT_13);
    rhs_state = zT_14;
    zT_16 = node.child_0;
    lhs_idx = zT_16;
    zT_18 = ctx->store;
    zT_19 = lhs_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    lhs_node = zT_21;
    zT_22 = lhs_node.kind;
    if ((unsigned char)(zT_22 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = lhs_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_28 = rhs_state;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* executeDeferQueue */
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int target_depth, unsigned char is_error, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_12;
    zT_7A19C4A5_DeferEntry* zT_14;
    zT_7A19C4A5_DeferEntry zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_7E2F335A_AnalyzerContext* zT_21;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    zT_7E2F335A_AnalyzerContext* zT_31;
    zT_2C0927B0_StateMap* zT_32;
    unsigned int zT_33;
    unsigned int idx;
    zT_7A19C4A5_DeferEntry entry;
    ctx->in_defer_exec = (unsigned char)(1);
    goto z_bb_1;
    z_bb_1:
    zT_6 = ctx->defer_queue_len;
    if ((unsigned char)(zT_6 > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = ctx->defer_queue_len;
    zT_12 = zT_10 - (unsigned int)(1);
    idx = zT_12;
    zT_14 = ctx->defer_queue_items;
    zT_15 = zT_14[idx];
    entry = zT_15;
    zT_16 = entry.scope_depth;
    if ((unsigned char)(zT_16 < target_depth)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    ctx->in_defer_exec = (unsigned char)(0);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    ctx->defer_queue_len = idx;
    zT_18 = entry.kind;
    if ((unsigned char)(zT_18 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_21 = ctx;
    zT_22 = state;
    zT_23 = entry.stmt_idx;
    visit_fn(zT_21, zT_22, zT_23);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_25 = entry.kind;
    if ((unsigned char)(zT_25 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_28 = is_error != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_31 = ctx;
    zT_32 = state;
    zT_33 = entry.stmt_idx;
    visit_fn(zT_31, zT_32, zT_33);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
}

/* walkBlock */
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int block_idx, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_15;
    zT_2C0927B0_StateMap* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_28 = 0;
    int zT_30;
    unsigned int zT_31;
    zT_7E2F335A_AnalyzerContext* zT_34;
    zT_2C0927B0_StateMap* zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    zT_7E2F335A_AnalyzerContext* zT_46;
    zT_2C0927B0_StateMap* zT_47;
    unsigned int zT_48;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_50;
    unsigned char zT_52;
    zT_7E2F335A_AnalyzerContext* zT_55;
    zT_2C0927B0_StateMap* zT_56;
    zT_22A7C88B_AstNode node;
    unsigned int saved_depth;
    unsigned int children_n;
    unsigned int i;
    if ((unsigned char)(block_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = block_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_16 = state;
    zT_17 = block_idx;
    visit_fn(zT_15, zT_16, zT_17);
    return;
    z_bb_4:
    zT_19 = ctx->current_depth;
    saved_depth = zT_19;
    zT_20 = ctx->current_depth;
    zT_21 = 1;
    ctx->current_depth = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_25 = ctx->store;
    zT_26 = block_idx;
    zT_28 = zF_152E19CB_astStoreNodeExtraCh(zT_25, zT_26);
    children_n = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_34 = ctx;
    zT_35 = state;
    zT_37 = ctx->store;
    zT_38 = block_idx;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)i));
    zT_36 = zT_42;
    visit_fn(zT_34, zT_35, zT_36);
    goto z_bb_8;
    z_bb_7:
    zT_46 = ctx;
    zT_47 = state;
    zT_48 = saved_depth;
    zT_50 = visit_fn;
    zF_332F08BB_executeDeferQueue(zT_46, zT_47, zT_48, (unsigned char)(0), zT_50);
    zT_52 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_52 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_43 = 1;
    zT_45 = i + (unsigned int)((unsigned int)zT_43);
    i = zT_45;
    goto z_bb_5;
    z_bb_9:
    zT_55 = ctx;
    zT_56 = state;
    zF_628B7574_checkLeaksOnScopeEx(zT_55, zT_56);
    goto z_bb_10;
    z_bb_10:
    ctx->current_depth = saved_depth;
    return;
}

/* captureNameIdOf */
unsigned int zF_CE47A44A_captureNameIdOf(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned char zT_14;
    unsigned char zT_18;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_25 = 0;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned char zT_37;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_44 = 0;
    unsigned char zT_49;
    unsigned char zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned int zT_63;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned int cap_idx;
    zT_22A7C88B_AstNode capn;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_10 = node.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_18 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_8;
    z_bb_7:
    zT_18 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_18) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = store;
    zT_24 = node_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_23, zT_24);
    cap_idx = zT_25;
    if ((unsigned char)(cap_idx == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_19; else goto z_bb_18;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    zT_30 = store;
    zT_31 = cap_idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    capn = zT_32;
    zT_33 = capn.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_38 = capn.kind;
    zT_37 = zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_15;
    z_bb_14:
    zT_37 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_37) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_42 = store;
    zT_43 = cap_idx;
    zT_44 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    return zT_44;
    z_bb_17:
    return (unsigned int)(0);
    z_bb_18:
    zT_49 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_20;
    z_bb_19:
    zT_49 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_49) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_53 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_23;
    z_bb_22:
    zT_53 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_53) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_57 = store;
    zT_58 = node_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    return zT_59;
    z_bb_25:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_prong))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_63 = node.child_1;
    return zT_63;
    z_bb_27:
    return (unsigned int)(0);
}

/* bindCaptureState */
void zF_C06E7771_bindCaptureState(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int src_expr) {
    unsigned char zT_6;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    zT_E48CAD8A_PtrState zT_12;
    unsigned char zT_13;
    zT_7E2F335A_AnalyzerContext* zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20 = 0;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_7E2F335A_AnalyzerContext* zT_28;
    unsigned int zT_29;
    zT_BAEE192E_Opt_10 zT_30 = {0};
    unsigned char zT_31;
    zT_2C0927B0_StateMap* zT_34;
    unsigned int zT_35;
    zT_43E16BE5_Opt_8 zT_36 = {0};
    unsigned char zT_37;
    zT_2C0927B0_StateMap* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_480593AB_AllocState zT_44;
    zT_2C0927B0_StateMap* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_480593AB_AllocState zT_48;
    zT_2C0927B0_StateMap* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    unsigned char prov;
    zT_BAEE192E_Opt_10 orig;
    unsigned int oid;
    zT_43E16BE5_Opt_8 cur;
    unsigned char c;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_6 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = state;
    zT_10 = name_id;
    zT_12 = zT_E48CAD8A_PtrState_safe;
    zT_11 = zT_12;
    zF_ACCFA860_stateMapSet(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_4:
    zT_13 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_13 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = ctx;
    zT_18 = state;
    zT_19 = src_expr;
    zT_20 = zF_5542CD3C_classifyProvenance(zT_17, zT_18, zT_19);
    prov = zT_20;
    zT_21 = state;
    zT_22 = name_id;
    zT_23 = prov;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_6;
    z_bb_6:
    zT_24 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_24 != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = ctx;
    zT_29 = src_expr;
    zT_30 = zF_92A5586D_resolveOrigin(zT_28, zT_29);
    orig = zT_30;
    zT_31 = orig.has_value;
    if (zT_31) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    return;
    z_bb_9:
    oid = orig.value;
    zT_34 = state;
    zT_35 = oid;
    zT_36 = zF_2EC17ECC_stateMapGet(zT_34, zT_35);
    cur = zT_36;
    zT_37 = cur.has_value;
    if (zT_37) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    c = cur.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_41 = state;
    zT_42 = name_id;
    zT_44 = zT_480593AB_AllocState_allocated;
    zT_43 = zT_44;
    zF_ACCFA860_stateMapSet(zT_41, zT_42, zT_43);
    zT_45 = state;
    zT_46 = oid;
    zT_48 = zT_480593AB_AllocState_transferred;
    zT_47 = zT_48;
    zF_ACCFA860_stateMapSet(zT_45, zT_46, zT_47);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_49 = state;
    zT_50 = name_id;
    zT_51 = c;
    zF_ACCFA860_stateMapSet(zT_49, zT_50, zT_51);
    goto z_bb_14;
}

/* analyzerFoldComptimeBool */
zT_49E17557_Opt_2 zF_A1341A8A_analyzerFoldComptim(zT_7E2F335A_AnalyzerContext* ctx, unsigned int node_idx, unsigned int depth) {
    zT_49E17557_Opt_2 zT_5 = {0};
    zT_49E17557_Opt_2 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    zT_49E17557_Opt_2 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_7E2F335A_AnalyzerContext* zT_28;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_8143F551_AstKind zT_35;
    zT_7E2F335A_AnalyzerContext* zT_39;
    unsigned int zT_40;
    zT_49E17557_Opt_2 zT_45 = {0};
    unsigned char zT_46;
    unsigned char zT_48;
    zT_49E17557_Opt_2 zT_49;
    zT_49E17557_Opt_2 zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_7E2F335A_AnalyzerContext* zT_55;
    unsigned int zT_56;
    zT_49E17557_Opt_2 zT_61 = {0};
    unsigned char zT_62;
    unsigned char zT_65;
    zT_49E17557_Opt_2 zT_66;
    zT_7E2F335A_AnalyzerContext* zT_67;
    unsigned int zT_70;
    unsigned int zT_72;
    zT_49E17557_Opt_2 zT_74 = {0};
    zT_8143F551_AstKind zT_75;
    zT_7E2F335A_AnalyzerContext* zT_79;
    unsigned int zT_80;
    zT_49E17557_Opt_2 zT_85 = {0};
    unsigned char zT_86;
    unsigned char zT_88;
    zT_49E17557_Opt_2 zT_89;
    zT_7E2F335A_AnalyzerContext* zT_90;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_49E17557_Opt_2 zT_97 = {0};
    zT_49E17557_Opt_2 zT_98 = {0};
    zT_22A7C88B_AstNode n;
    unsigned char v;
    unsigned char l;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = ctx->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    n = zT_13;
    zT_14 = n.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_18 = n.flags;
    zT_22 = (unsigned char)(zT_18 & (unsigned char)(1)) != (unsigned char)(0);
    zT_23.has_value = 1;
    zT_23.value = zT_22;
    return zT_23;
    z_bb_6:
    zT_24 = n.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = ctx;
    zT_31 = n.child_0;
    zT_33 = depth + (unsigned int)(1);
    ctx = zT_28;
    node_idx = zT_31;
    depth = zT_33;
    goto z_bb_0;
    z_bb_8:
    zT_35 = n.kind;
    if ((unsigned char)(zT_35 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = ctx;
    zT_40 = n.child_0;
    zT_45 = zF_A1341A8A_analyzerFoldComptim(zT_39, zT_40, (unsigned int)(depth + (unsigned int)(1)));
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_51 = n.kind;
    if ((unsigned char)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    v = zT_45.value;
    zT_48 = !v;
    zT_49.has_value = 1;
    zT_49.value = zT_48;
    return zT_49;
    z_bb_12:
    zT_50.has_value = 0;
    return zT_50;
    z_bb_13:
    zT_55 = ctx;
    zT_56 = n.child_0;
    zT_61 = zF_A1341A8A_analyzerFoldComptim(zT_55, zT_56, (unsigned int)(depth + (unsigned int)(1)));
    zT_62 = zT_61.has_value;
    if (zT_62) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_75 = n.kind;
    if ((unsigned char)(zT_75 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or))) goto z_bb_19; else goto z_bb_20;
    z_bb_15:
    l = zT_61.value;
    if ((unsigned char)(!l)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_74.has_value = 0;
    return zT_74;
    z_bb_17:
    zT_65 = 0;
    zT_66.has_value = 1;
    zT_66.value = zT_65;
    return zT_66;
    z_bb_18:
    zT_67 = ctx;
    zT_70 = n.child_1;
    zT_72 = depth + (unsigned int)(1);
    ctx = zT_67;
    node_idx = zT_70;
    depth = zT_72;
    goto z_bb_0;
    z_bb_19:
    zT_79 = ctx;
    zT_80 = n.child_0;
    zT_85 = zF_A1341A8A_analyzerFoldComptim(zT_79, zT_80, (unsigned int)(depth + (unsigned int)(1)));
    zT_86 = zT_85.has_value;
    if (zT_86) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_98.has_value = 0;
    return zT_98;
    z_bb_21:
    l = zT_85.value;
    if (l) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_97.has_value = 0;
    return zT_97;
    z_bb_23:
    zT_88 = 1;
    zT_89.has_value = 1;
    zT_89.value = zT_88;
    return zT_89;
    z_bb_24:
    zT_90 = ctx;
    zT_93 = n.child_1;
    zT_95 = depth + (unsigned int)(1);
    ctx = zT_90;
    node_idx = zT_93;
    depth = zT_95;
    goto z_bb_0;
}

/* paramTypeIsPointerLike */
unsigned char zF_42EA7E8C_paramTypeIsPointerL(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned char zT_14;
    zT_8143F551_AstKind zT_15;
    unsigned char zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned char zT_24;
    zT_8143F551_AstKind zT_25;
    zT_22A7C88B_AstNode tnode;
    if ((unsigned char)(type_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = type_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    tnode = zT_9;
    zT_10 = tnode.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_15 = tnode.kind;
    zT_14 = zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_20 = tnode.kind;
    zT_19 = zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_25 = tnode.kind;
    zT_24 = zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_11;
    z_bb_10:
    zT_24 = 1;
    goto z_bb_11;
    z_bb_11:
    return zT_24;
}

/* visitStatement */
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx, zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned char zT_17;
    zT_7E2F335A_AnalyzerContext* zT_22;
    unsigned int zT_23;
    int zT_26;
    zT_49E17557_Opt_2 zT_28 = {0};
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_7E2F335A_AnalyzerContext* zT_37;
    zT_2C0927B0_StateMap* zT_38;
    unsigned int zT_39;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_40;
    unsigned int zT_42;
    zT_7E2F335A_AnalyzerContext* zT_45;
    zT_2C0927B0_StateMap* zT_46;
    unsigned int zT_47;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_48;
    zT_7E2F335A_AnalyzerContext* zT_50;
    zT_2C0927B0_StateMap* zT_51;
    unsigned int zT_52;
    zT_2C0927B0_StateMap* zT_55;
    zT_3E40CD83_Sand* zT_56;
    zT_2C0927B0_StateMap* zT_58 = 0;
    zT_2C0927B0_StateMap* zT_60;
    zT_3E40CD83_Sand* zT_61;
    zT_2C0927B0_StateMap* zT_63 = 0;
    unsigned char zT_64;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_2C0927B0_StateMap* zT_69;
    zT_2C0927B0_StateMap* zT_70;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_77 = 0;
    zT_7E2F335A_AnalyzerContext* zT_78;
    zT_2C0927B0_StateMap* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_7E2F335A_AnalyzerContext* zT_83;
    zT_2C0927B0_StateMap* zT_84;
    unsigned int zT_85;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_86;
    unsigned int zT_88;
    zT_7E2F335A_AnalyzerContext* zT_91;
    zT_2C0927B0_StateMap* zT_92;
    unsigned int zT_93;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_94;
    zT_2C0927B0_StateMap* zT_96;
    zT_2C0927B0_StateMap* zT_97;
    zT_2C0927B0_StateMap* zT_98;
    unsigned char zT_104;
    zT_7E2F335A_AnalyzerContext* zT_108;
    zT_2C0927B0_StateMap* zT_109;
    unsigned int zT_110;
    zT_2C0927B0_StateMap* zT_113;
    zT_3E40CD83_Sand* zT_114;
    zT_2C0927B0_StateMap* zT_116 = 0;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_121 = 0;
    zT_7E2F335A_AnalyzerContext* zT_122;
    zT_2C0927B0_StateMap* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_7E2F335A_AnalyzerContext* zT_127;
    zT_2C0927B0_StateMap* zT_128;
    unsigned int zT_129;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_130;
    zT_2C0927B0_StateMap* zT_132;
    zT_2C0927B0_StateMap* zT_133;
    zT_2C0927B0_StateMap* zT_134;
    zT_7E2F335A_AnalyzerContext* zT_140;
    zT_2C0927B0_StateMap* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int zT_148 = 0;
    int zT_150;
    unsigned int zT_151;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_163 = 0;
    zT_22A7C88B_AstNode zT_164 = {0};
    zT_2C0927B0_StateMap* zT_166;
    zT_3E40CD83_Sand* zT_167;
    zT_2C0927B0_StateMap* zT_169 = 0;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_172;
    zT_6B0A7D14_AstStore* zT_174;
    unsigned int zT_175;
    unsigned int zT_179 = 0;
    unsigned int zT_180 = 0;
    zT_7E2F335A_AnalyzerContext* zT_181;
    zT_2C0927B0_StateMap* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_7E2F335A_AnalyzerContext* zT_186;
    zT_2C0927B0_StateMap* zT_187;
    unsigned int zT_188;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_189;
    zT_2C0927B0_StateMap* zT_191;
    zT_2C0927B0_StateMap* zT_192;
    zT_2C0927B0_StateMap* zT_193;
    unsigned char zT_196;
    zT_2C0927B0_StateMap* zT_199;
    zT_2C0927B0_StateMap* zT_200;
    int zT_204;
    unsigned int zT_206;
    zT_2C0927B0_StateMap* zT_211;
    zT_3E40CD83_Sand* zT_212;
    zT_2C0927B0_StateMap* zT_214 = 0;
    zT_6B0A7D14_AstStore* zT_216;
    unsigned int zT_217;
    unsigned int zT_219 = 0;
    zT_7E2F335A_AnalyzerContext* zT_220;
    zT_2C0927B0_StateMap* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_7E2F335A_AnalyzerContext* zT_225;
    zT_2C0927B0_StateMap* zT_226;
    unsigned int zT_227;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_228;
    zT_2C0927B0_StateMap* zT_230;
    zT_2C0927B0_StateMap* zT_231;
    zT_2C0927B0_StateMap* zT_232;
    unsigned int zT_238;
    unsigned char zT_241;
    zT_7E2F335A_AnalyzerContext* zT_244;
    zT_2C0927B0_StateMap* zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned char zT_249;
    zT_7E2F335A_AnalyzerContext* zT_252;
    zT_2C0927B0_StateMap* zT_253;
    unsigned int zT_254;
    zT_7E2F335A_AnalyzerContext* zT_256;
    zT_2C0927B0_StateMap* zT_257;
    unsigned int zT_258;
    unsigned char zT_262;
    unsigned char zT_266;
    unsigned char zT_267;
    unsigned char zT_271;
    unsigned char zT_275;
    zT_7E2F335A_AnalyzerContext* zT_276;
    unsigned int zT_278;
    zT_7A19C4A5_DeferEntry zT_281;
    unsigned int zT_282;
    zT_7A19C4A5_DeferEntry* zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    int zT_286;
    unsigned char zT_289;
    unsigned char zT_292;
    zT_7E2F335A_AnalyzerContext* zT_296;
    zT_2C0927B0_StateMap* zT_297;
    unsigned int zT_298;
    zT_7E2F335A_AnalyzerContext* zT_299;
    zT_2C0927B0_StateMap* zT_300;
    unsigned int zT_301;
    unsigned char zT_302;
    unsigned char zT_305;
    zT_7E2F335A_AnalyzerContext* zT_309;
    zT_2C0927B0_StateMap* zT_310;
    unsigned int zT_311;
    zT_7E2F335A_AnalyzerContext* zT_312;
    zT_2C0927B0_StateMap* zT_313;
    unsigned int zT_314;
    unsigned int zT_318;
    zT_6B0A7D14_AstStore* zT_322;
    unsigned int zT_323;
    zT_22A7C88B_AstNode zT_326 = {0};
    zT_8143F551_AstKind zT_327;
    zT_7E2F335A_AnalyzerContext* zT_331;
    zT_2C0927B0_StateMap* zT_332;
    unsigned int zT_333;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_334;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_335;
    zT_7E2F335A_AnalyzerContext* zT_337;
    zT_2C0927B0_StateMap* zT_338;
    unsigned int zT_339;
    zT_7E2F335A_AnalyzerContext* zT_344;
    zT_2C0927B0_StateMap* zT_345;
    unsigned int zT_346;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_347;
    zT_7E2F335A_AnalyzerContext* zT_351;
    zT_2C0927B0_StateMap* zT_352;
    unsigned int zT_353;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_354;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_355;
    zT_7E2F335A_AnalyzerContext* zT_357;
    zT_2C0927B0_StateMap* zT_358;
    unsigned int zT_359;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_49E17557_Opt_2 t5_fold;
    unsigned char tfv;
    zT_2C0927B0_StateMap* then_state;
    zT_2C0927B0_StateMap* else_state;
    unsigned int t5_cap;
    zT_2C0927B0_StateMap* body_state;
    unsigned int t5_wcap;
    unsigned int prongs_n;
    unsigned int si;
    zT_22A7C88B_AstNode prong;
    zT_2C0927B0_StateMap* ps;
    unsigned int t5_pcap;
    unsigned int t5_fcap;
    unsigned char dk;
    zT_22A7C88B_AstNode inner;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_17 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture);
    goto z_bb_5;
    z_bb_4:
    zT_17 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_17) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_22 = ctx;
    zT_23 = node.child_0;
    zT_26 = 0;
    zT_28 = zF_A1341A8A_analyzerFoldComptim(zT_22, zT_23, (unsigned int)((unsigned int)zT_26));
    t5_fold = zT_28;
    zT_29 = t5_fold.has_value;
    if (zT_29) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_23; else goto z_bb_22;
    z_bb_9:
    tfv = t5_fold.value;
    zT_31 = ctx->store;
    zT_32 = node_idx;
    zT_34 = zF_8BA26B9E_astStoreNodePayload(zT_31, zT_32);
    if ((unsigned char)(zT_34 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_50 = ctx;
    zT_51 = state;
    zT_52 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_50, zT_51, zT_52);
    zT_55 = state;
    zT_56 = ctx->alloc;
    zT_58 = zF_77086C9C_stateMapFork(zT_55, zT_56);
    then_state = zT_58;
    zT_60 = state;
    zT_61 = ctx->alloc;
    zT_63 = zF_77086C9C_stateMapFork(zT_60, zT_61);
    else_state = zT_63;
    zT_64 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_64 != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_11:
    if (tfv) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_37 = ctx;
    zT_38 = state;
    zT_39 = node.child_1;
    zT_40 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_37, zT_38, zT_39, zT_40);
    goto z_bb_14;
    z_bb_14:
    return;
    z_bb_15:
    zT_42 = node.child_2;
    if ((unsigned char)(zT_42 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = ctx;
    zT_46 = state;
    zT_47 = node.child_2;
    zT_48 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_45, zT_46, zT_47, zT_48);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_67 = ctx->store;
    zT_68 = node.child_0;
    zT_69 = then_state;
    zT_70 = else_state;
    zF_76DBB626_applyNullGuardRefin(zT_67, zT_68, zT_69, zT_70);
    goto z_bb_19;
    z_bb_19:
    zT_74 = ctx->store;
    zT_75 = node_idx;
    zT_77 = zF_CE47A44A_captureNameIdOf(zT_74, zT_75);
    t5_cap = zT_77;
    zT_78 = ctx;
    zT_79 = then_state;
    zT_80 = t5_cap;
    zT_81 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_78, zT_79, zT_80, zT_81);
    zT_83 = ctx;
    zT_84 = then_state;
    zT_85 = node.child_1;
    zT_86 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_83, zT_84, zT_85, zT_86);
    zT_88 = node.child_2;
    if ((unsigned char)(zT_88 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_91 = ctx;
    zT_92 = else_state;
    zT_93 = node.child_2;
    zT_94 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_91, zT_92, zT_93, zT_94);
    goto z_bb_21;
    z_bb_21:
    zT_96 = state;
    zT_97 = then_state;
    zT_98 = else_state;
    zF_143ACBA6_stateMapMergeStates(zT_96, zT_97, zT_98, (unsigned char)(99));
    goto z_bb_7;
    z_bb_22:
    zT_104 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_24;
    z_bb_23:
    zT_104 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_104) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_108 = ctx;
    zT_109 = state;
    zT_110 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_108, zT_109, zT_110);
    zT_113 = state;
    zT_114 = ctx->alloc;
    zT_116 = zF_77086C9C_stateMapFork(zT_113, zT_114);
    body_state = zT_116;
    zT_118 = ctx->store;
    zT_119 = node_idx;
    zT_121 = zF_CE47A44A_captureNameIdOf(zT_118, zT_119);
    t5_wcap = zT_121;
    zT_122 = ctx;
    zT_123 = body_state;
    zT_124 = t5_wcap;
    zT_125 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_122, zT_123, zT_124, zT_125);
    zT_127 = ctx;
    zT_128 = body_state;
    zT_129 = node.child_1;
    zT_130 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_127, zT_128, zT_129, zT_130);
    zT_132 = state;
    zT_133 = state;
    zT_134 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_132, zT_133, zT_134, (unsigned char)(99));
    goto z_bb_26;
    z_bb_26:
    goto z_bb_7;
    z_bb_27:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_140 = ctx;
    zT_141 = state;
    zT_142 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_140, zT_141, zT_142);
    zT_145 = ctx->store;
    zT_146 = node_idx;
    zT_148 = zF_152E19CB_astStoreNodeExtraCh(zT_145, zT_146);
    prongs_n = zT_148;
    zT_150 = 0;
    zT_151 = (unsigned int)zT_150;
    si = zT_151;
    goto z_bb_31;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_37; else goto z_bb_39;
    z_bb_31:
    if ((unsigned char)(si < (unsigned int)((unsigned int)prongs_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_155 = ctx->store;
    zT_158 = ctx->store;
    zT_159 = node_idx;
    zT_163 = zF_B10B1BC1_astStoreNodeExtraCh(zT_158, zT_159, (unsigned int)((unsigned int)si));
    zT_156 = zT_163;
    zT_164 = zF_FCDD1D35_astStoreNodeAt(zT_155, zT_156);
    prong = zT_164;
    zT_166 = state;
    zT_167 = ctx->alloc;
    zT_169 = zF_77086C9C_stateMapFork(zT_166, zT_167);
    ps = zT_169;
    zT_171 = ctx->store;
    zT_174 = ctx->store;
    zT_175 = node_idx;
    zT_179 = zF_B10B1BC1_astStoreNodeExtraCh(zT_174, zT_175, (unsigned int)((unsigned int)si));
    zT_172 = zT_179;
    zT_180 = zF_CE47A44A_captureNameIdOf(zT_171, zT_172);
    t5_pcap = zT_180;
    zT_181 = ctx;
    zT_182 = ps;
    zT_183 = t5_pcap;
    zT_184 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_181, zT_182, zT_183, zT_184);
    zT_186 = ctx;
    zT_187 = ps;
    zT_188 = prong.child_0;
    zT_189 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_186, zT_187, zT_188, zT_189);
    zT_191 = state;
    zT_192 = state;
    zT_193 = ps;
    zF_143ACBA6_stateMapMergeStates(zT_191, zT_192, zT_193, (unsigned char)(99));
    zT_196 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_196 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_204 = 1;
    zT_206 = si + (unsigned int)((unsigned int)zT_204);
    si = zT_206;
    goto z_bb_31;
    z_bb_35:
    zT_199 = state;
    zT_200 = ps;
    zF_619C0B6B_stateMapMergeInsert(zT_199, zT_200, (unsigned char)((unsigned char)(zT_480593AB_AllocState)(zT_480593AB_AllocState_unknown)));
    goto z_bb_36;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_211 = state;
    zT_212 = ctx->alloc;
    zT_214 = zF_77086C9C_stateMapFork(zT_211, zT_212);
    body_state = zT_214;
    zT_216 = ctx->store;
    zT_217 = node_idx;
    zT_219 = zF_CE47A44A_captureNameIdOf(zT_216, zT_217);
    t5_fcap = zT_219;
    zT_220 = ctx;
    zT_221 = body_state;
    zT_222 = t5_fcap;
    zT_223 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_220, zT_221, zT_222, zT_223);
    zT_225 = ctx;
    zT_226 = body_state;
    zT_227 = node.child_1;
    zT_228 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_225, zT_226, zT_227, zT_228);
    zT_230 = state;
    zT_231 = state;
    zT_232 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_230, zT_231, zT_232, (unsigned char)(99));
    goto z_bb_38;
    z_bb_38:
    goto z_bb_29;
    z_bb_39:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_238 = node.child_0;
    if ((unsigned char)(zT_238 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_50; else goto z_bb_49;
    z_bb_43:
    zT_241 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_241 != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_256 = ctx;
    zT_257 = state;
    zT_258 = node_idx;
    on_stmt(zT_256, zT_257, zT_258);
    goto z_bb_41;
    z_bb_45:
    zT_244 = ctx;
    zT_245 = state;
    zT_246 = node.child_0;
    zT_247 = node_idx;
    zF_8C7FC932_checkReturnProvenan(zT_244, zT_245, zT_246, zT_247);
    goto z_bb_46;
    z_bb_46:
    zT_249 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_249 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_252 = ctx;
    zT_253 = state;
    zT_254 = node.child_0;
    zF_65CAFC02_handleOwnershipRetu(zT_252, zT_253, zT_254);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_44;
    z_bb_49:
    zT_262 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_51;
    z_bb_50:
    zT_262 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_262) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_267 = ctx->in_defer_exec;
    zT_266 = zT_267 == (unsigned char)(0);
    goto z_bb_54;
    z_bb_53:
    zT_266 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_266) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_271 = 0;
    dk = zT_271;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_41;
    z_bb_57:
    zT_289 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_289 != (unsigned char)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    zT_275 = 1;
    dk = zT_275;
    goto z_bb_59;
    z_bb_59:
    zT_276 = ctx;
    zT_278 = ctx->defer_queue_len;
    zF_46BA7660_deferQueueEnsureCap(zT_276, (unsigned int)(zT_278 + (unsigned int)(1)));
    zT_281.kind = dk;
    zT_281.stmt_idx = node_idx;
    zT_282 = ctx->current_depth;
    zT_281.scope_depth = zT_282;
    zT_283 = ctx->defer_queue_items;
    zT_284 = ctx->defer_queue_len;
    zT_283[zT_284] = zT_281;
    zT_285 = ctx->defer_queue_len;
    zT_286 = 1;
    ctx->defer_queue_len = (unsigned int)(zT_285 + (unsigned int)((unsigned int)zT_286));
    goto z_bb_56;
    z_bb_60:
    zT_292 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_62;
    z_bb_61:
    zT_292 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_292) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_296 = ctx;
    zT_297 = state;
    zT_298 = node_idx;
    zF_B7AD2EEF_handleNullVarDecl(zT_296, zT_297, zT_298);
    zT_299 = ctx;
    zT_300 = state;
    zT_301 = node_idx;
    on_stmt(zT_299, zT_300, zT_301);
    goto z_bb_64;
    z_bb_64:
    goto z_bb_56;
    z_bb_65:
    zT_302 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_302 != (unsigned char)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_305 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign);
    goto z_bb_68;
    z_bb_67:
    zT_305 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_305) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_309 = ctx;
    zT_310 = state;
    zT_311 = node_idx;
    zF_847AD0EF_handleNullAssign(zT_309, zT_310, zT_311);
    zT_312 = ctx;
    zT_313 = state;
    zT_314 = node_idx;
    on_stmt(zT_312, zT_313, zT_314);
    goto z_bb_70;
    z_bb_70:
    goto z_bb_64;
    z_bb_71:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_72; else goto z_bb_74;
    z_bb_72:
    zT_318 = node.child_0;
    if ((unsigned char)(zT_318 != (unsigned int)(0))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_80; else goto z_bb_82;
    z_bb_75:
    zT_322 = ctx->store;
    zT_323 = node.child_0;
    zT_326 = zF_FCDD1D35_astStoreNodeAt(zT_322, zT_323);
    inner = zT_326;
    zT_327 = inner.kind;
    if ((unsigned char)(zT_327 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_77; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_331 = ctx;
    zT_332 = state;
    zT_333 = node.child_0;
    zT_334 = on_stmt;
    zT_335 = visit_fn;
    zF_468ECC89_visitStatement(zT_331, zT_332, zT_333, zT_334, zT_335);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    zT_337 = ctx;
    zT_338 = state;
    zT_339 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_337, zT_338, zT_339);
    goto z_bb_78;
    z_bb_80:
    zT_344 = ctx;
    zT_345 = state;
    zT_346 = node_idx;
    zT_347 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_344, zT_345, zT_346, zT_347);
    goto z_bb_81;
    z_bb_81:
    goto z_bb_73;
    z_bb_82:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_351 = ctx;
    zT_352 = state;
    zT_353 = node.child_0;
    zT_354 = on_stmt;
    zT_355 = visit_fn;
    zF_468ECC89_visitStatement(zT_351, zT_352, zT_353, zT_354, zT_355);
    goto z_bb_84;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    zT_357 = ctx;
    zT_358 = state;
    zT_359 = node_idx;
    on_stmt(zT_357, zT_358, zT_359);
    goto z_bb_84;
}

/* onNullStmt */
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    (void)ctx;
    (void)state;
    (void)node_idx;
    return;
}

/* onLifetimeStmt */
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned int zT_12;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20 = 0;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_27 = 0;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    zT_7E2F335A_AnalyzerContext* zT_52;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_56 = 0;
    zT_2C0927B0_StateMap* zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_64 = 0;
    zT_22A7C88B_AstNode node;
    unsigned char prov;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = node.child_1;
    if ((unsigned char)(zT_12 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_1;
    zT_20 = zF_5542CD3C_classifyProvenance(zT_16, zT_17, zT_18);
    prov = zT_20;
    zT_21 = state;
    zT_24 = ctx->store;
    zT_25 = node_idx;
    zT_27 = zF_8BA26B9E_astStoreNodePayload(zT_24, zT_25);
    zT_22 = zT_27;
    zT_23 = prov;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_28 = state;
    zT_31 = ctx->store;
    zT_32 = node_idx;
    zT_34 = zF_8BA26B9E_astStoreNodePayload(zT_31, zT_32);
    zT_29 = zT_34;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown)));
    goto z_bb_4;
    z_bb_6:
    zT_42 = ctx->store;
    zT_43 = node.child_0;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    lhs_node = zT_46;
    zT_47 = lhs_node.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    return;
    z_bb_8:
    zT_52 = ctx;
    zT_53 = state;
    zT_54 = node.child_1;
    zT_56 = zF_5542CD3C_classifyProvenance(zT_52, zT_53, zT_54);
    prov = zT_56;
    zT_57 = state;
    zT_60 = ctx->store;
    zT_61 = node.child_0;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_58 = zT_64;
    zT_59 = prov;
    zF_ACCFA860_stateMapSet(zT_57, zT_58, zT_59);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_7;
}

/* onDoubleFreeStmt */
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_7E2F335A_AnalyzerContext* zT_12;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    zT_8143F551_AstKind zT_21;
    zT_7E2F335A_AnalyzerContext* zT_25;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    zT_7E2F335A_AnalyzerContext* zT_32;
    zT_2C0927B0_StateMap* zT_33;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_35;
    zT_2C0927B0_StateMap* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = ctx;
    zT_13 = state;
    zT_16 = ctx->store;
    zT_17 = node_idx;
    zT_19 = zF_8BA26B9E_astStoreNodePayload(zT_16, zT_17);
    zT_14 = zT_19;
    zT_15 = node.child_1;
    zF_4330B9B8_handleAllocCall(zT_12, zT_13, zT_14, zT_15);
    goto z_bb_2;
    z_bb_2:
    zT_21 = node.kind;
    if ((unsigned char)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25 = ctx;
    zT_26 = state;
    zT_27 = node_idx;
    zF_67B7BB29_handleAllocAssign(zT_25, zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_32 = ctx;
    zT_33 = state;
    zT_34 = node_idx;
    zF_70D0501D_handleFreeCall(zT_32, zT_33, zT_34);
    zT_35 = ctx;
    zT_36 = state;
    zT_37 = node_idx;
    zF_9AFCA595_handleOwnershipPass(zT_35, zT_36, zT_37);
    goto z_bb_6;
    z_bb_6:
    return;
}

/* runSignatureAnalyzer */
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx) {
    zT_7E2F335A_AnalyzerContext* zT_2;
    unsigned int zT_3;
    zT_2 = ctx;
    zT_3 = fn_decl_idx;
    zF_2A06A757_analyzeSignature(zT_2, zT_3);
    return;
}

/* detectorVisit */
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_3;
    zT_2C0927B0_StateMap* zT_4;
    unsigned int zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_6;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_9;
    zT_3 = ctx;
    zT_4 = state;
    zT_5 = node_idx;
    zT_6 = ctx->on_stmt_cb;
    zT_9 = zF_59D99CE2_detectorVisit;
    zT_7 = zT_9;
    zF_468ECC89_visitStatement(zT_3, zT_4, zT_5, zT_6, zT_7);
    return;
}

/* runNullAnalyzer */
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->null_analysis_mode = (unsigned char)(1);
    zT_7 = zF_43C99FB3_onNullStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = (zT_2C0927B0_StateMap*)&state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->null_analysis_mode = (unsigned char)(0);
    return;
}

/* runLifetimeAnalyzer */
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_4;
    zT_2C0927B0_StateMap zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    zT_4EF476FD_anon_318191 zT_20;
    zT_243D6A41_FnProto* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned int zT_26;
    zT_243D6A41_FnProto zT_27;
    unsigned int zT_29;
    unsigned short zT_33;
    zT_79FAE712_u64 zT_35;
    zT_6B0A7D14_AstStore* zT_37;
    zT_79FAE712_u64 zT_38;
    unsigned int zT_40 = 0;
    int zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_55 = 0;
    zT_22A7C88B_AstNode zT_56 = {0};
    zT_8143F551_AstKind zT_57;
    unsigned char zT_63;
    zT_7E2F335A_AnalyzerContext* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    unsigned char zT_69;
    zT_2C0927B0_StateMap* zT_70;
    unsigned int zT_71;
    unsigned char zT_72;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_82 = 0;
    unsigned int zT_83 = 0;
    int zT_84;
    unsigned int zT_86;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_88;
    zT_7E2F335A_AnalyzerContext* zT_89;
    zT_2C0927B0_StateMap* zT_90;
    unsigned int zT_91;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_92;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_94;
    zT_2C0927B0_StateMap state;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 pp;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned char t5_pseed;
    zT_4 = ctx->alloc;
    zT_6 = zF_14665872_stateMapInit(zT_4);
    state = zT_6;
    zT_8 = ctx->store;
    zT_9 = fn_decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    zT_12 = ctx->store;
    zT_13 = fn_decl_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = ctx->store;
    zT_20 = zT_19->fn_protos;
    zT_21 = zT_20.items;
    zT_22 = ctx->store;
    zT_23 = fn_decl_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    proto = zT_27;
    zT_29 = proto.params_start;
    zT_33 = proto.params_count;
    zT_35 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_29) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_33);
    pp = zT_35;
    zT_37 = ctx->store;
    zT_38 = pp;
    zT_40 = zF_03CE8CAB_astStoreGetExtraChi(zT_37, zT_38);
    params_n = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    pi = zT_43;
    goto z_bb_3;
    z_bb_2:
    ctx->lifetime_analysis_mode = (unsigned char)(1);
    zT_88 = zF_3D2EF2C5_onLifetimeStmt;
    ctx->on_stmt_cb = zT_88;
    zT_89 = ctx;
    zT_90 = (zT_2C0927B0_StateMap*)&state;
    zT_91 = fn_body_idx;
    zT_94 = zF_59D99CE2_detectorVisit;
    zT_92 = zT_94;
    zF_0F6AFE81_walkBlock(zT_89, zT_90, zT_91, zT_92);
    ctx->lifetime_analysis_mode = (unsigned char)(0);
    return;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_47 = ctx->store;
    zT_50 = ctx->store;
    zT_51 = pp;
    zT_55 = zF_E5B10421_astStoreGetExtraChi(zT_50, zT_51, (unsigned int)((unsigned int)pi));
    zT_48 = zT_55;
    zT_56 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    pnode = zT_56;
    zT_57 = pnode.kind;
    if ((unsigned char)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_84 = 1;
    zT_86 = pi + (unsigned int)((unsigned int)zT_84);
    pi = zT_86;
    goto z_bb_3;
    z_bb_7:
    zT_63 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param);
    t5_pseed = zT_63;
    zT_64 = ctx;
    zT_65 = pnode.child_0;
    zT_67 = zF_42EA7E8C_paramTypeIsPointerL(zT_64, zT_65);
    if (zT_67) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_69 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external);
    t5_pseed = zT_69;
    goto z_bb_10;
    z_bb_10:
    zT_70 = (zT_2C0927B0_StateMap*)&state;
    zT_74 = ctx->store;
    zT_77 = ctx->store;
    zT_78 = pp;
    zT_82 = zF_E5B10421_astStoreGetExtraChi(zT_77, zT_78, (unsigned int)((unsigned int)pi));
    zT_75 = zT_82;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_71 = zT_83;
    zT_72 = t5_pseed;
    zF_ACCFA860_stateMapSet(zT_70, zT_71, zT_72);
    goto z_bb_8;
}

/* runDoubleFreeAnalyzer */
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->doublefree_analysis_mode = (unsigned char)(1);
    zT_7 = zF_270EF995_onDoubleFreeStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = (zT_2C0927B0_StateMap*)&state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->doublefree_analysis_mode = (unsigned char)(0);
    return;
}

/* runAllAnalyzers */
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext* ctx, unsigned int module_root_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_27 = 0;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_3E40CD83_Sand* zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    zT_4EF476FD_anon_318191 zT_43;
    zT_243D6A41_FnProto* zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    unsigned int zT_49;
    zT_243D6A41_FnProto zT_50;
    unsigned int zT_51;
    zT_7E2F335A_AnalyzerContext* zT_52;
    unsigned int zT_53;
    zT_3E40CD83_Sand* zT_54;
    zT_7E2F335A_AnalyzerContext* zT_56;
    unsigned char zT_57;
    zT_7E2F335A_AnalyzerContext* zT_60;
    unsigned int zT_61;
    zT_3E40CD83_Sand* zT_63;
    zT_7E2F335A_AnalyzerContext* zT_65;
    unsigned char zT_66;
    zT_7E2F335A_AnalyzerContext* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_3E40CD83_Sand* zT_73;
    zT_7E2F335A_AnalyzerContext* zT_75;
    unsigned char zT_76;
    zT_7E2F335A_AnalyzerContext* zT_79;
    unsigned int zT_80;
    zT_3E40CD83_Sand* zT_82;
    zT_7E2F335A_AnalyzerContext* zT_84;
    zT_3E40CD83_Sand* zT_85;
    unsigned int zT_86;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_107;
    unsigned int zT_108;
    int zT_112;
    unsigned int zT_114;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u bmsg;
    zT_3 = ctx->store;
    zT_4 = module_root_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    root = zT_6;
    zT_7 = root.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = module_root_idx;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    decls_n = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    di = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = ctx->store;
    zT_23 = module_root_idx;
    zT_27 = zF_B10B1BC1_astStoreNodeExtraCh(zT_22, zT_23, (unsigned int)((unsigned int)di));
    decl_idx = zT_27;
    zT_29 = ctx->store;
    zT_30 = decl_idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    decl = zT_32;
    zT_33 = decl.kind;
    if ((unsigned char)(zT_33 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_112 = 1;
    zT_114 = di + (unsigned int)((unsigned int)zT_112);
    di = zT_114;
    goto z_bb_3;
    z_bb_7:
    goto z_bb_6;
    z_bb_8:
    zT_37 = decl.child_0;
    if ((unsigned char)(zT_37 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_40 = ctx->alloc;
    zF_CB5A85E9_sandResetPeak(zT_40);
    zT_42 = ctx->store;
    zT_43 = zT_42->fn_protos;
    zT_44 = zT_43.items;
    zT_45 = ctx->store;
    zT_46 = decl_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_45, zT_46);
    zT_49 = (unsigned int)zT_48;
    zT_50 = zT_44[zT_49];
    zT_51 = zT_50.name_id;
    ctx->current_fn_name = zT_51;
    zT_52 = ctx;
    zT_53 = decl_idx;
    zF_DDE69BF2_runSignatureAnalyze(zT_52, zT_53);
    zT_54 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_54);
    zT_56 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_56);
    zT_57 = ctx->skip_null_check;
    if ((unsigned char)(zT_57 == (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_60 = ctx;
    zT_61 = decl.child_0;
    zF_29CABD65_runNullAnalyzer(zT_60, zT_61);
    zT_63 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_63);
    zT_65 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_65);
    goto z_bb_12;
    z_bb_12:
    zT_66 = ctx->skip_lifetime_check;
    if ((unsigned char)(zT_66 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_69 = ctx;
    zT_70 = decl_idx;
    zT_71 = decl.child_0;
    zF_9B11D60F_runLifetimeAnalyzer(zT_69, zT_70, zT_71);
    zT_73 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_73);
    zT_75 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_75);
    goto z_bb_14;
    z_bb_14:
    zT_76 = ctx->skip_doublefree_check;
    if ((unsigned char)(zT_76 == (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_79 = ctx;
    zT_80 = decl.child_0;
    zF_D5F41043_runDoubleFreeAnalyz(zT_79, zT_80);
    zT_82 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_82);
    zT_84 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_84);
    goto z_bb_16;
    z_bb_16:
    zT_85 = ctx->alloc;
    zT_86 = zT_85->peak;
    if ((unsigned char)(zT_86 > (unsigned int)(524288))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_90 = "per-function analyzer budget exceeded";
    zT_92 = 37;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    bmsg = zT_91;
    zT_93 = ctx->diag;
    zT_97 = decl.span_start;
    zT_107 = decl.span_start;
    zT_108 = decl.span_len;
    zT_99 = bmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_93, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7002_ANALYZER_BUDGET_EXCEEDED)), (unsigned int)(0), zT_97, (unsigned int)(zT_107 + (unsigned int)((unsigned int)zT_108)), zT_99);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_6;
}

/* EOF */
