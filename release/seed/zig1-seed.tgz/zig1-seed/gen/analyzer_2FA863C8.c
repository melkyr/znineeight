#include "analyzer_2FA863C8.h"
unsigned int zG_73BDFDC5_PER_FUNC_BUDGET;
/* identNameId */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_2 = store;
    zT_3 = node_idx;
    zT_4 = zF_53458827_astStoreIdentifier(zT_2, zT_3);
    return zT_4;
}

/* resolveOrigin */
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    zT_BAEE192E_Opt_10 zT_20;
    zT_7E2F335A_AnalyzerContext* zT_25;
    unsigned int zT_27;
    zT_7E2F335A_AnalyzerContext* zT_33;
    unsigned int zT_35;
    zT_BAEE192E_Opt_10 zT_41 = {0};
    zT_7E2F335A_AnalyzerContext* zT_46;
    unsigned int zT_48;
    zT_BAEE192E_Opt_10 zT_50 = {0};
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ctx->store;
    zT_17 = expr_idx;
    zT_19 = zF_2E24BD6B_identNameId(zT_16, zT_17);
    zT_20.has_value = 1;
    zT_20.value = zT_19;
    return zT_20;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = ctx;
    zT_27 = node.child_0;
    ctx = zT_25;
    expr_idx = zT_27;
    goto z_bb_0;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = ctx;
    zT_35 = node.child_0;
    ctx = zT_33;
    expr_idx = zT_35;
    goto z_bb_0;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41.has_value = 0;
    return zT_41;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_46 = ctx;
    zT_48 = node.child_0;
    ctx = zT_46;
    expr_idx = zT_48;
    goto z_bb_0;
    z_bb_12:
    zT_50.has_value = 0;
    return zT_50;
}

/* classifyProvenance */
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    zT_7E2F335A_AnalyzerContext* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_22 = {0};
    unsigned char zT_23;
    zT_060CD1EB_SymbolTable* zT_26;
    unsigned int zT_27;
    zT_D4761958_Opt_858 zT_29 = {0};
    unsigned char zT_30;
    zT_3C598AEF_SymbolKind zT_32;
    zT_3C598AEF_SymbolKind zT_39;
    zT_3C598AEF_SymbolKind zT_46;
    zT_7E2F335A_AnalyzerContext* zT_66;
    unsigned int zT_67;
    zT_BAEE192E_Opt_10 zT_69 = {0};
    unsigned char zT_70;
    zT_2C0927B0_StateMap* zT_73;
    unsigned int zT_74;
    zT_43E16BE5_Opt_8 zT_75 = {0};
    unsigned char zT_76;
    zT_7E2F335A_AnalyzerContext* zT_85;
    unsigned int zT_86;
    zT_BAEE192E_Opt_10 zT_88 = {0};
    unsigned char zT_89;
    zT_2C0927B0_StateMap* zT_92;
    unsigned int zT_93;
    zT_43E16BE5_Opt_8 zT_94 = {0};
    unsigned char zT_95;
    zT_2C0927B0_StateMap* zT_104;
    unsigned int zT_105;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    unsigned int zT_109 = 0;
    zT_43E16BE5_Opt_8 zT_110 = {0};
    unsigned char zT_111;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_BAEE192E_Opt_10 found_name_id;
    unsigned int name_id;
    zT_D4761958_Opt_858 sym;
    zT_3A105EF1_Symbol* s;
    zT_BAEE192E_Opt_10 base_id;
    unsigned int bid;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = expr_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = ctx;
    zT_20 = node.child_0;
    zT_22 = zF_92A5586D_resolveOrigin(zT_19, zT_20);
    found_name_id = zT_22;
    zT_23 = found_name_id.has_value;
    if (zT_23) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_15; else goto z_bb_16;
    z_bb_5:
    name_id = found_name_id.value;
    zT_26 = ctx->symbols;
    zT_27 = name_id;
    zT_29 = zF_893B79A5_symbolTableLookup(zT_26, zT_27);
    sym = zT_29;
    zT_30 = sym.has_value;
    if (zT_30) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_7:
    s = sym.value;
    zT_32 = s->kind;
    if ((unsigned char)(zT_32 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_local))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_10:
    zT_39 = s->kind;
    if ((unsigned char)(zT_39 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_param))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_12:
    zT_46 = s->kind;
    if ((unsigned char)(zT_46 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_66 = ctx;
    zT_67 = node.child_0;
    zT_69 = zF_92A5586D_resolveOrigin(zT_66, zT_67);
    base_id = zT_69;
    zT_70 = base_id.has_value;
    if (zT_70) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    bid = base_id.value;
    zT_73 = state;
    zT_74 = bid;
    zT_75 = zF_2EC17ECC_stateMapGet(zT_73, zT_74);
    result = zT_75;
    zT_76 = result.has_value;
    if (zT_76) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_21:
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_85 = ctx;
    zT_86 = node.child_0;
    zT_88 = zF_92A5586D_resolveOrigin(zT_85, zT_86);
    base_id = zT_88;
    zT_89 = base_id.has_value;
    if (zT_89) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    bid = base_id.value;
    zT_92 = state;
    zT_93 = bid;
    zT_94 = zF_2EC17ECC_stateMapGet(zT_92, zT_93);
    result = zT_94;
    zT_95 = result.has_value;
    if (zT_95) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_27:
    v = result.value;
    return v;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_104 = state;
    zT_106 = ctx->store;
    zT_107 = expr_idx;
    zT_109 = zF_2E24BD6B_identNameId(zT_106, zT_107);
    zT_105 = zT_109;
    zT_110 = zF_2EC17ECC_stateMapGet(zT_104, zT_105);
    result = zT_110;
    zT_111 = result.has_value;
    if (zT_111) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_31:
    v = result.value;
    return v;
    z_bb_32:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
}

/* checkReturnProvenance */
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx, unsigned int ret_node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_5;
    zT_2C0927B0_StateMap* zT_6;
    unsigned int zT_7;
    unsigned char zT_8 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    unsigned char zT_28;
    unsigned char zT_31;
    zT_8143F551_AstKind zT_33;
    zT_7E2F335A_AnalyzerContext* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_42 = {0};
    unsigned char zT_43;
    zT_D3EB6303_StringInterner* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49 = {0};
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_67;
    int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_73;
    unsigned int zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_8143F551_AstKind zT_107;
    zT_7E2F335A_AnalyzerContext* zT_113;
    unsigned int zT_114;
    zT_BAEE192E_Opt_10 zT_116 = {0};
    unsigned char zT_117;
    zT_D3EB6303_StringInterner* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123 = {0};
    unsigned char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    zT_D3EB6303_StringInterner* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_139;
    zT_F85C5DED_DiagnosticCollector* zT_141;
    int zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_147;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_F85C5DED_DiagnosticCollector* zT_166;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    zT_7E2F335A_AnalyzerContext* zT_182;
    unsigned int zT_183;
    zT_BAEE192E_Opt_10 zT_184 = {0};
    unsigned char zT_185;
    zT_D3EB6303_StringInterner* zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191 = {0};
    unsigned char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_D3EB6303_StringInterner* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_207;
    zT_F85C5DED_DiagnosticCollector* zT_209;
    int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_215;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned char* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    zT_F85C5DED_DiagnosticCollector* zT_234;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    zT_7E2F335A_AnalyzerContext* zT_251;
    unsigned int zT_252;
    zT_BAEE192E_Opt_10 zT_254 = {0};
    unsigned char zT_255;
    zT_D3EB6303_StringInterner* zT_258;
    unsigned int zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261 = {0};
    unsigned char* zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_265;
    unsigned char* zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    zT_D3EB6303_StringInterner* zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_277;
    zT_F85C5DED_DiagnosticCollector* zT_279;
    int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_285;
    unsigned int zT_289;
    unsigned int zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned char* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    zT_F85C5DED_DiagnosticCollector* zT_304;
    unsigned int zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned char prov;
    zT_22A7C88B_AstNode rnode;
    unsigned int start;
    unsigned int end;
    zT_22A7C88B_AstNode expr_node;
    unsigned char pl;
    unsigned char ppa;
    zT_BAEE192E_Opt_10 name_opt;
    unsigned int nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli rparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_5 = ctx;
    zT_6 = state;
    zT_7 = expr_idx;
    zT_8 = zF_5542CD3C_classifyProvenance(zT_5, zT_6, zT_7);
    prov = zT_8;
    zT_10 = ctx->store;
    zT_11 = ret_node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    rnode = zT_13;
    zT_15 = rnode.span_start;
    start = zT_15;
    zT_17 = rnode.span_start;
    zT_18 = rnode.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = ctx->store;
    zT_23 = expr_idx;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    expr_node = zT_25;
    zT_28 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    pl = zT_28;
    zT_31 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr);
    ppa = zT_31;
    if ((unsigned char)(prov == pl)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_33 = expr_node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(prov == ppa)) goto z_bb_13; else goto z_bb_14;
    z_bb_3:
    zT_39 = ctx;
    zT_40 = expr_node.child_0;
    zT_42 = zF_92A5586D_resolveOrigin(zT_39, zT_40);
    name_opt = zT_42;
    zT_43 = name_opt.has_value;
    if (zT_43) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_107 = expr_node.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    nid = name_opt.value;
    zT_46 = ctx->interner;
    zT_47 = nid;
    zT_49 = zF_9134020D_stringInternerGet(zT_46, zT_47);
    nm = zT_49;
    zT_51 = "returning address of local variable '";
    zT_53 = 37;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    rp1 = zT_52;
    zT_55 = "'";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    rp2 = zT_56;
    zT_60 = 0;
    zT_59[zT_60] = rp1;
    zT_61 = 1;
    zT_59[zT_61] = nm;
    zT_62 = 2;
    zT_59[zT_62] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_59[_i];
        _i++;
    }
}
    zT_67 = ctx->diag;
    zT_64 = zT_67->interner;
    zT_69 = 0;
    zT_70 = rparts + zT_69;
    zT_65 = zT_70;
    zT_72 = zF_8C4BFF7C_diagnosticBuilderMa(zT_64, zT_65, (unsigned int)(3));
    msg = zT_72;
    zT_73 = ctx->diag;
    zT_77 = start;
    zT_78 = end;
    zT_79 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_73, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_77, zT_78, zT_79);
    return;
    z_bb_6:
    zT_89 = "returning address of local variable";
    zT_91 = 35;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    dmsg = zT_90;
    zT_92 = ctx->diag;
    zT_96 = start;
    zT_97 = end;
    zT_98 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_92, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_96, zT_97, zT_98);
    return;
    z_bb_7:
    zT_113 = ctx;
    zT_114 = expr_node.child_0;
    zT_116 = zF_92A5586D_resolveOrigin(zT_113, zT_114);
    name_opt = zT_116;
    zT_117 = name_opt.has_value;
    if (zT_117) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_182 = ctx;
    zT_183 = expr_idx;
    zT_184 = zF_92A5586D_resolveOrigin(zT_182, zT_183);
    name_opt = zT_184;
    zT_185 = name_opt.has_value;
    if (zT_185) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    nid = name_opt.value;
    zT_120 = ctx->interner;
    zT_121 = nid;
    zT_123 = zF_9134020D_stringInternerGet(zT_120, zT_121);
    nm = zT_123;
    zT_125 = "returning slice of local array '";
    zT_127 = 32;
    zT_126.ptr = zT_125;
    zT_126.len = zT_127;
    rp1 = zT_126;
    zT_129 = "'";
    zT_131 = 1;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    rp2 = zT_130;
    zT_134 = 0;
    zT_133[zT_134] = rp1;
    zT_135 = 1;
    zT_133[zT_135] = nm;
    zT_136 = 2;
    zT_133[zT_136] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_133[_i];
        _i++;
    }
}
    zT_141 = ctx->diag;
    zT_138 = zT_141->interner;
    zT_143 = 0;
    zT_144 = rparts + zT_143;
    zT_139 = zT_144;
    zT_146 = zF_8C4BFF7C_diagnosticBuilderMa(zT_138, zT_139, (unsigned int)(3));
    msg = zT_146;
    zT_147 = ctx->diag;
    zT_151 = start;
    zT_152 = end;
    zT_153 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_147, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_151, zT_152, zT_153);
    return;
    z_bb_10:
    zT_163 = "returning slice of local array";
    zT_165 = 30;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    dmsg = zT_164;
    zT_166 = ctx->diag;
    zT_170 = start;
    zT_171 = end;
    zT_172 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_166, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_170, zT_171, zT_172);
    return;
    z_bb_11:
    nid = name_opt.value;
    zT_188 = ctx->interner;
    zT_189 = nid;
    zT_191 = zF_9134020D_stringInternerGet(zT_188, zT_189);
    nm = zT_191;
    zT_193 = "returning pointer to local via variable '";
    zT_195 = 41;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    rp1 = zT_194;
    zT_197 = "'";
    zT_199 = 1;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    rp2 = zT_198;
    zT_202 = 0;
    zT_201[zT_202] = rp1;
    zT_203 = 1;
    zT_201[zT_203] = nm;
    zT_204 = 2;
    zT_201[zT_204] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_201[_i];
        _i++;
    }
}
    zT_209 = ctx->diag;
    zT_206 = zT_209->interner;
    zT_211 = 0;
    zT_212 = rparts + zT_211;
    zT_207 = zT_212;
    zT_214 = zF_8C4BFF7C_diagnosticBuilderMa(zT_206, zT_207, (unsigned int)(3));
    msg = zT_214;
    zT_215 = ctx->diag;
    zT_219 = start;
    zT_220 = end;
    zT_221 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_215, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_219, zT_220, zT_221);
    return;
    z_bb_12:
    zT_231 = "returning pointer to local via variable";
    zT_233 = 39;
    zT_232.ptr = zT_231;
    zT_232.len = zT_233;
    dmsg = zT_232;
    zT_234 = ctx->diag;
    zT_238 = start;
    zT_239 = end;
    zT_240 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_234, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_238, zT_239, zT_240);
    return;
    z_bb_13:
    zT_251 = ctx;
    zT_252 = expr_node.child_0;
    zT_254 = zF_92A5586D_resolveOrigin(zT_251, zT_252);
    name_opt = zT_254;
    zT_255 = name_opt.has_value;
    if (zT_255) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    return;
    z_bb_15:
    nid = name_opt.value;
    zT_258 = ctx->interner;
    zT_259 = nid;
    zT_261 = zF_9134020D_stringInternerGet(zT_258, zT_259);
    nm = zT_261;
    zT_263 = "returning address of parameter '";
    zT_265 = 32;
    zT_264.ptr = zT_263;
    zT_264.len = zT_265;
    rp1 = zT_264;
    zT_267 = "'";
    zT_269 = 1;
    zT_268.ptr = zT_267;
    zT_268.len = zT_269;
    rp2 = zT_268;
    zT_272 = 0;
    zT_271[zT_272] = rp1;
    zT_273 = 1;
    zT_271[zT_273] = nm;
    zT_274 = 2;
    zT_271[zT_274] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_271[_i];
        _i++;
    }
}
    zT_279 = ctx->diag;
    zT_276 = zT_279->interner;
    zT_281 = 0;
    zT_282 = rparts + zT_281;
    zT_277 = zT_282;
    zT_284 = zF_8C4BFF7C_diagnosticBuilderMa(zT_276, zT_277, (unsigned int)(3));
    msg = zT_284;
    zT_285 = ctx->diag;
    zT_289 = start;
    zT_290 = end;
    zT_291 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_285, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_289, zT_290, zT_291);
    return;
    z_bb_16:
    zT_301 = "returning address of function parameter";
    zT_303 = 39;
    zT_302.ptr = zT_301;
    zT_302.len = zT_303;
    dmsg = zT_302;
    zT_304 = ctx->diag;
    zT_308 = start;
    zT_309 = end;
    zT_310 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_304, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_308, zT_309, zT_310);
    return;
}

/* isAllocCall */
unsigned char zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_7E2F335A_AnalyzerContext* zT_15;
    unsigned int zT_17;
    zT_8143F551_AstKind zT_19;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_31;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_42 = 0;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51 = 0;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_D3EB6303_StringInterner* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_62 = 0;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_D3EB6303_StringInterner* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_73 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sandAlloc;
    unsigned int sand_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_alloc;
    unsigned int sand2_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_alloc;
    unsigned int arena_nid;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_17 = node.child_0;
    ctx = zT_15;
    expr_idx = zT_17;
    goto z_bb_0;
    z_bb_4:
    zT_19 = node.kind;
    if ((unsigned char)(zT_19 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_26 = ctx->store;
    zT_27 = node.child_0;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    callee = zT_30;
    zT_31 = callee.kind;
    if ((unsigned char)(zT_31 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_38 = ctx->store;
    zT_39 = node.child_0;
    zT_42 = zF_2E24BD6B_identNameId(zT_38, zT_39);
    name_id = zT_42;
    zT_44 = "sandAlloc";
    zT_46 = 9;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    s_sandAlloc = zT_45;
    zT_48 = ctx->interner;
    zT_49 = s_sandAlloc;
    zT_51 = zF_50C274AF_stringInternerInter(zT_48, zT_49);
    sand_nid = zT_51;
    if ((unsigned char)(name_id == sand_nid)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_55 = "sand_alloc";
    zT_57 = 10;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    s_sand_alloc = zT_56;
    zT_59 = ctx->interner;
    zT_60 = s_sand_alloc;
    zT_62 = zF_50C274AF_stringInternerInter(zT_59, zT_60);
    sand2_nid = zT_62;
    if ((unsigned char)(name_id == sand2_nid)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_66 = "arena_alloc";
    zT_68 = 11;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_arena_alloc = zT_67;
    zT_70 = ctx->interner;
    zT_71 = s_arena_alloc;
    zT_73 = zF_50C274AF_stringInternerInter(zT_70, zT_71);
    arena_nid = zT_73;
    if ((unsigned char)(name_id == arena_nid)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* isFreeCall */
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_8143F551_AstKind zT_22;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_33 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_42 = 0;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51 = 0;
    unsigned char zT_53;
    zT_BAEE192E_Opt_10 zT_55 = {0};
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    zT_BAEE192E_Opt_10 zT_63 = {0};
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode zT_75 = {0};
    zT_8143F551_AstKind zT_76;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_84 = 0;
    zT_BAEE192E_Opt_10 zT_85;
    zT_BAEE192E_Opt_10 zT_86 = {0};
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_free;
    unsigned int arena_free_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_free;
    unsigned int sand_free_nid;
    unsigned int args_n;
    unsigned int args1;
    zT_22A7C88B_AstNode ptr_arg;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_4:
    zT_17 = ctx->store;
    zT_18 = node.child_0;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_17, zT_18);
    callee = zT_21;
    zT_22 = callee.kind;
    if ((unsigned char)(zT_22 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27.has_value = 0;
    return zT_27;
    z_bb_6:
    zT_29 = ctx->store;
    zT_30 = node.child_0;
    zT_33 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    name_id = zT_33;
    zT_35 = "arena_free";
    zT_37 = 10;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    s_arena_free = zT_36;
    zT_39 = ctx->interner;
    zT_40 = s_arena_free;
    zT_42 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    arena_free_nid = zT_42;
    zT_44 = "sandFree";
    zT_46 = 8;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    s_sand_free = zT_45;
    zT_48 = ctx->interner;
    zT_49 = s_sand_free;
    zT_51 = zF_50C274AF_stringInternerInter(zT_48, zT_49);
    sand_free_nid = zT_51;
    if ((unsigned char)(name_id != arena_free_nid)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_53 = name_id != sand_free_nid;
    goto z_bb_9;
    z_bb_8:
    zT_53 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_55.has_value = 0;
    return zT_55;
    z_bb_11:
    zT_57 = ctx->store;
    zT_58 = expr_idx;
    zT_60 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    args_n = zT_60;
    if ((unsigned char)(args_n < (unsigned int)(2))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63.has_value = 0;
    return zT_63;
    z_bb_13:
    zT_65 = ctx->store;
    zT_66 = expr_idx;
    zT_70 = zF_B10B1BC1_astStoreNodeExtraCh(zT_65, zT_66, (unsigned int)(1));
    args1 = zT_70;
    zT_72 = ctx->store;
    zT_73 = args1;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_72, zT_73);
    ptr_arg = zT_75;
    zT_76 = ptr_arg.kind;
    if ((unsigned char)(zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_81 = ctx->store;
    zT_82 = args1;
    zT_84 = zF_2E24BD6B_identNameId(zT_81, zT_82);
    zT_85.has_value = 1;
    zT_85.value = zT_84;
    return zT_85;
    z_bb_15:
    zT_86.has_value = 0;
    return zT_86;
}

/* compositeNameId */
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner* interner, unsigned int base_id, unsigned int field_id) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char* zT_47;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_59;
    unsigned char* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u base_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u field_str;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int pos;
    unsigned int i;
    zT_4 = interner;
    zT_5 = base_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    base_str = zT_6;
    zT_8 = interner;
    zT_9 = field_id;
    zT_10 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    field_str = zT_10;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    pos = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_1:
    zT_20 = base_str.len;
    if ((unsigned char)(i < zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_25 = base_str.ptr;
    zT_26 = zT_25[i];
    buf[pos] = zT_26;
    zT_27 = 1;
    zT_29 = pos + (unsigned int)((unsigned int)zT_27);
    pos = zT_29;
    zT_30 = 1;
    zT_32 = i + (unsigned int)((unsigned int)zT_30);
    i = zT_32;
    goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(pos < (unsigned int)(127))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_22 = pos < (unsigned int)(127);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_35 = 46;
    buf[pos] = zT_35;
    zT_36 = 1;
    zT_38 = pos + (unsigned int)((unsigned int)zT_36);
    pos = zT_38;
    goto z_bb_9;
    z_bb_9:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_10;
    z_bb_10:
    zT_42 = field_str.len;
    if ((unsigned char)(i < zT_42)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_47 = field_str.ptr;
    zT_48 = zT_47[i];
    buf[pos] = zT_48;
    zT_49 = 1;
    zT_51 = pos + (unsigned int)((unsigned int)zT_49);
    pos = zT_51;
    zT_52 = 1;
    zT_54 = i + (unsigned int)((unsigned int)zT_52);
    i = zT_54;
    goto z_bb_13;
    z_bb_12:
    zT_55 = interner;
    zT_59 = 0;
    zT_60 = (unsigned char*)((unsigned char*)buf) + zT_59;
    zT_61 = pos - zT_59;
    zT_62.ptr = zT_60;
    zT_62.len = zT_61;
    zT_56 = zT_62;
    zT_63 = zF_50C274AF_stringInternerInter(zT_55, zT_56);
    return zT_63;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_44 = pos < (unsigned int)(127);
    goto z_bb_16;
    z_bb_15:
    zT_44 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_44) goto z_bb_11; else goto z_bb_12;
}

/* handleAllocCall */
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int init_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    unsigned char zT_6 = 0;
    zT_2C0927B0_StateMap* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_480593AB_AllocState zT_11;
    zT_4 = ctx;
    zT_5 = init_idx;
    zT_6 = zF_264B254A_isAllocCall(zT_4, zT_5);
    if ((unsigned char)(!zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = state;
    zT_9 = name_id;
    zT_11 = zT_480593AB_AllocState_allocated;
    zT_10 = zT_11;
    zF_ACCFA860_stateMapSet(zT_8, zT_9, zT_10);
    return;
}

/* handleFreeCall */
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_15 = {0};
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_22A7C88B_AstNode zT_20 = {0};
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_480593AB_AllocState zT_28;
    zT_D3EB6303_StringInterner* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35 = {0};
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D3EB6303_StringInterner* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_59;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_2C0927B0_StateMap* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    zT_480593AB_AllocState zT_82;
    zT_D3EB6303_StringInterner* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87 = {0};
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_D3EB6303_StringInterner* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_103;
    zT_F85C5DED_DiagnosticCollector* zT_105;
    int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_111;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int name_id;
    zT_43E16BE5_Opt_8 current;
    zT_22A7C88B_AstNode node;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_8F083A69_Slice_zT_0B42B2F8_u up2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u umsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli dparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_4 = ctx;
    zT_5 = expr_idx;
    zT_6 = zF_E445D5FB_isFreeCall(zT_4, zT_5);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = zT_6.value;
    goto z_bb_3;
    z_bb_3:
    name_id = zT_8;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_13 = state;
    zT_14 = name_id;
    zT_15 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    current = zT_15;
    zT_17 = ctx->store;
    zT_18 = expr_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_17, zT_18);
    node = zT_20;
    zT_21 = current.has_value;
    if (zT_21) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_84 = ctx->interner;
    zT_85 = name_id;
    zT_87 = zF_9134020D_stringInternerGet(zT_84, zT_85);
    pn = zT_87;
    zT_89 = "freeing untracked pointer '";
    zT_91 = 27;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    up1 = zT_90;
    zT_93 = "'";
    zT_95 = 1;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    up2 = zT_94;
    zT_98 = 0;
    zT_97[zT_98] = up1;
    zT_99 = 1;
    zT_97[zT_99] = pn;
    zT_100 = 2;
    zT_97[zT_100] = up2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_97[_i];
        _i++;
    }
}
    zT_105 = ctx->diag;
    zT_102 = zT_105->interner;
    zT_107 = 0;
    zT_108 = uparts + zT_107;
    zT_103 = zT_108;
    zT_110 = zF_8C4BFF7C_diagnosticBuilderMa(zT_102, zT_103, (unsigned int)(3));
    umsg = zT_110;
    zT_111 = ctx->diag;
    zT_115 = node.span_start;
    zT_126 = node.span_start;
    zT_127 = node.span_len;
    zT_117 = umsg;
    (void)zF_C82559AC_diagnosticCollector(zT_111, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6006_FREEING_UNTRACKED)), (unsigned int)(0), zT_115, (unsigned int)(zT_126 + (unsigned int)((unsigned int)zT_127)), zT_117);
    goto z_bb_7;
    z_bb_9:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_480593AB_AllocState_freed;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    return;
    z_bb_10:
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_freed))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ctx->interner;
    zT_33 = name_id;
    zT_35 = zF_9134020D_stringInternerGet(zT_32, zT_33);
    pn = zT_35;
    zT_37 = "double free of pointer '";
    zT_39 = 24;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    dp1 = zT_38;
    zT_41 = "'";
    zT_43 = 1;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    dp2 = zT_42;
    zT_46 = 0;
    zT_45[zT_46] = dp1;
    zT_47 = 1;
    zT_45[zT_47] = pn;
    zT_48 = 2;
    zT_45[zT_48] = dp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        dparts[_i] = zT_45[_i];
        _i++;
    }
}
    zT_53 = ctx->diag;
    zT_50 = zT_53->interner;
    zT_55 = 0;
    zT_56 = dparts + zT_55;
    zT_51 = zT_56;
    zT_58 = zF_8C4BFF7C_diagnosticBuilderMa(zT_50, zT_51, (unsigned int)(3));
    dmsg = zT_58;
    zT_59 = ctx->diag;
    zT_63 = node.span_start;
    zT_74 = node.span_start;
    zT_75 = node.span_len;
    zT_65 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_59, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2005_DOUBLE_FREE)), (unsigned int)(0), zT_63, (unsigned int)(zT_74 + (unsigned int)((unsigned int)zT_75)), zT_65);
    return;
    z_bb_12:
    zT_79 = state;
    zT_80 = name_id;
    zT_82 = zT_480593AB_AllocState_freed;
    zT_81 = zT_82;
    zF_ACCFA860_stateMapSet(zT_79, zT_80, zT_81);
    goto z_bb_7;
}

/* checkLeaksOnScopeExit */
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state) {
    zT_2C0927B0_StateMap* zT_3;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_6B392E0E_StateEntry* zT_11;
    zT_6B392E0E_StateEntry zT_12;
    unsigned char zT_13;
    zT_D3EB6303_StringInterner* zT_17;
    unsigned int zT_18;
    zT_6B392E0E_StateEntry* zT_20;
    zT_6B392E0E_StateEntry zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_64;
    unsigned int zT_66;
    zT_92FBD55B_Slice_zT_6B392E0E_S entries;
    unsigned int ei;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli lparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_3 = state;
    zT_4 = zF_F0E7F434_stateMapGetEntries(zT_3);
    entries = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    ei = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = entries.len;
    if ((unsigned char)(ei < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = entries.ptr;
    zT_12 = zT_11[ei];
    zT_13 = zT_12.state;
    if ((unsigned char)(zT_13 == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_64 = 1;
    zT_66 = ei + (unsigned int)((unsigned int)zT_64);
    ei = zT_66;
    goto z_bb_1;
    z_bb_5:
    zT_17 = ctx->interner;
    zT_20 = entries.ptr;
    zT_21 = zT_20[ei];
    zT_18 = zT_21.name_id;
    zT_23 = zF_9134020D_stringInternerGet(zT_17, zT_18);
    pn = zT_23;
    zT_25 = "memory leak: pointer '";
    zT_27 = 22;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    lp1 = zT_26;
    zT_29 = "' not freed";
    zT_31 = 11;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    lp2 = zT_30;
    zT_34 = 0;
    zT_33[zT_34] = lp1;
    zT_35 = 1;
    zT_33[zT_35] = pn;
    zT_36 = 2;
    zT_33[zT_36] = lp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        lparts[_i] = zT_33[_i];
        _i++;
    }
}
    zT_41 = ctx->diag;
    zT_38 = zT_41->interner;
    zT_43 = 0;
    zT_44 = lparts + zT_43;
    zT_39 = zT_44;
    zT_46 = zF_8C4BFF7C_diagnosticBuilderMa(zT_38, zT_39, (unsigned int)(3));
    lmsg = zT_46;
    zT_47 = ctx->diag;
    zT_53 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_47, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_53);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* handleAllocAssign */
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    zT_43E16BE5_Opt_8 zT_30 = {0};
    unsigned char zT_31;
    zT_D3EB6303_StringInterner* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39 = {0};
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_D3EB6303_StringInterner* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_63;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_7E2F335A_AnalyzerContext* zT_83;
    unsigned int zT_84;
    unsigned char zT_85 = 0;
    zT_2C0927B0_StateMap* zT_86;
    unsigned int zT_87;
    unsigned char zT_88;
    zT_480593AB_AllocState zT_89;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_22A7C88B_AstNode zT_96 = {0};
    zT_8143F551_AstKind zT_97;
    zT_2C0927B0_StateMap* zT_102;
    unsigned int zT_103;
    unsigned char zT_104;
    zT_480593AB_AllocState zT_105;
    zT_2C0927B0_StateMap* zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    zT_480593AB_AllocState zT_109;
    zT_22A7C88B_AstNode node;
    unsigned int lhs_idx;
    unsigned int rhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int lhs_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u op1;
    zT_8F083A69_Slice_zT_0B42B2F8_u op2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli oparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_22A7C88B_AstNode rhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_0;
    lhs_idx = zT_9;
    zT_11 = node.child_1;
    rhs_idx = zT_11;
    zT_13 = ctx->store;
    zT_14 = lhs_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    lhs_node = zT_16;
    zT_17 = lhs_node.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_23 = ctx->store;
    zT_24 = lhs_idx;
    zT_26 = zF_2E24BD6B_identNameId(zT_23, zT_24);
    lhs_name_id = zT_26;
    zT_28 = state;
    zT_29 = lhs_name_id;
    zT_30 = zF_2EC17ECC_stateMapGet(zT_28, zT_29);
    current = zT_30;
    zT_31 = current.has_value;
    if (zT_31) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_83 = ctx;
    zT_84 = rhs_idx;
    zT_85 = zF_264B254A_isAllocCall(zT_83, zT_84);
    if (zT_85) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_36 = ctx->interner;
    zT_37 = lhs_name_id;
    zT_39 = zF_9134020D_stringInternerGet(zT_36, zT_37);
    pn = zT_39;
    zT_41 = "memory leak: pointer '";
    zT_43 = 22;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    op1 = zT_42;
    zT_45 = "' overwritten before free";
    zT_47 = 25;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    op2 = zT_46;
    zT_50 = 0;
    zT_49[zT_50] = op1;
    zT_51 = 1;
    zT_49[zT_51] = pn;
    zT_52 = 2;
    zT_49[zT_52] = op2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        oparts[_i] = zT_49[_i];
        _i++;
    }
}
    zT_57 = ctx->diag;
    zT_54 = zT_57->interner;
    zT_59 = 0;
    zT_60 = oparts + zT_59;
    zT_55 = zT_60;
    zT_62 = zF_8C4BFF7C_diagnosticBuilderMa(zT_54, zT_55, (unsigned int)(3));
    lmsg = zT_62;
    zT_63 = ctx->diag;
    zT_67 = node.span_start;
    zT_78 = node.span_start;
    zT_79 = node.span_len;
    zT_69 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_63, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), zT_67, (unsigned int)(zT_78 + (unsigned int)((unsigned int)zT_79)), zT_69);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_86 = state;
    zT_87 = lhs_name_id;
    zT_89 = zT_480593AB_AllocState_allocated;
    zT_88 = zT_89;
    zF_ACCFA860_stateMapSet(zT_86, zT_87, zT_88);
    return;
    z_bb_8:
    if ((unsigned char)(rhs_idx != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_93 = ctx->store;
    zT_94 = rhs_idx;
    zT_96 = zF_FCDD1D35_astStoreNodeAt(zT_93, zT_94);
    rhs_node = zT_96;
    zT_97 = rhs_node.kind;
    if ((unsigned char)(zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_106 = state;
    zT_107 = lhs_name_id;
    zT_109 = zT_480593AB_AllocState_unknown;
    zT_108 = zT_109;
    zF_ACCFA860_stateMapSet(zT_106, zT_107, zT_108);
    return;
    z_bb_11:
    zT_102 = state;
    zT_103 = lhs_name_id;
    zT_105 = zT_480593AB_AllocState_untracked;
    zT_104 = zT_105;
    zF_ACCFA860_stateMapSet(zT_102, zT_103, zT_104);
    return;
    z_bb_12:
    goto z_bb_10;
}

/* handleOwnershipReturn */
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int ret_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_2C0927B0_StateMap* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    zT_43E16BE5_Opt_8 zT_22 = {0};
    unsigned char zT_23;
    zT_2C0927B0_StateMap* zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_480593AB_AllocState zT_34;
    zT_22A7C88B_AstNode node;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    if ((unsigned char)(ret_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = ret_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_16 = state;
    zT_18 = ctx->store;
    zT_19 = ret_expr_idx;
    zT_21 = zF_2E24BD6B_identNameId(zT_18, zT_19);
    zT_17 = zT_21;
    zT_22 = zF_2EC17ECC_stateMapGet(zT_16, zT_17);
    current = zT_22;
    zT_23 = current.has_value;
    if (zT_23) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_27 = state;
    zT_30 = ctx->store;
    zT_31 = ret_expr_idx;
    zT_33 = zF_2E24BD6B_identNameId(zT_30, zT_31);
    zT_28 = zT_33;
    zT_34 = zT_480593AB_AllocState_returned_val;
    zT_29 = zT_34;
    zF_ACCFA860_stateMapSet(zT_27, zT_28, zT_29);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* handleOwnershipPass */
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int fn_call_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    int zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_31 = 0;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_36 = {0};
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_2C0927B0_StateMap* zT_48;
    unsigned int zT_49;
    zT_43E16BE5_Opt_8 zT_50 = {0};
    unsigned char zT_51;
    zT_2C0927B0_StateMap* zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    zT_480593AB_AllocState zT_58;
    zT_D3EB6303_StringInterner* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63 = {0};
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_D3EB6303_StringInterner* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_79;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86 = {0};
    unsigned char zT_88;
    unsigned char zT_89;
    unsigned char zT_92;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    unsigned char zT_94;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_107;
    unsigned int zT_108;
    int zT_112;
    unsigned int zT_114;
    zT_22A7C88B_AstNode node;
    unsigned int args_n;
    unsigned int ai;
    unsigned int args_i;
    zT_22A7C88B_AstNode arg_node;
    unsigned int arg_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmsg;
    unsigned char warn_lvl;
    if ((unsigned char)(fn_call_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = fn_call_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_16 = ctx->store;
    zT_17 = fn_call_idx;
    zT_19 = zF_152E19CB_astStoreNodeExtraCh(zT_16, zT_17);
    args_n = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    ai = zT_22;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = ctx->store;
    zT_27 = fn_call_idx;
    zT_31 = zF_B10B1BC1_astStoreNodeExtraCh(zT_26, zT_27, (unsigned int)((unsigned int)ai));
    args_i = zT_31;
    zT_33 = ctx->store;
    zT_34 = args_i;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    arg_node = zT_36;
    zT_37 = arg_node.kind;
    if ((unsigned char)(zT_37 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_112 = 1;
    zT_114 = ai + (unsigned int)((unsigned int)zT_112);
    ai = zT_114;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_43 = ctx->store;
    zT_44 = args_i;
    zT_46 = zF_2E24BD6B_identNameId(zT_43, zT_44);
    arg_name_id = zT_46;
    zT_48 = state;
    zT_49 = arg_name_id;
    zT_50 = zF_2EC17ECC_stateMapGet(zT_48, zT_49);
    current = zT_50;
    zT_51 = current.has_value;
    if (zT_51) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_8;
    z_bb_13:
    zT_55 = state;
    zT_56 = arg_name_id;
    zT_58 = zT_480593AB_AllocState_transferred;
    zT_57 = zT_58;
    zF_ACCFA860_stateMapSet(zT_55, zT_56, zT_57);
    zT_60 = ctx->interner;
    zT_61 = arg_name_id;
    zT_63 = zF_9134020D_stringInternerGet(zT_60, zT_61);
    pn = zT_63;
    zT_65 = "ownership of '";
    zT_67 = 14;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    tp1 = zT_66;
    zT_69 = "' transferred to function";
    zT_71 = 25;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    tp2 = zT_70;
    zT_74 = 0;
    zT_73[zT_74] = tp1;
    zT_75 = 1;
    zT_73[zT_75] = pn;
    zT_76 = 2;
    zT_73[zT_76] = tp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tparts[_i] = zT_73[_i];
        _i++;
    }
}
    zT_81 = ctx->diag;
    zT_78 = zT_81->interner;
    zT_83 = 0;
    zT_84 = tparts + zT_83;
    zT_79 = zT_84;
    zT_86 = zF_8C4BFF7C_diagnosticBuilderMa(zT_78, zT_79, (unsigned int)(3));
    tmsg = zT_86;
    zT_88 = 2;
    warn_lvl = zT_88;
    zT_89 = ctx->warn_all;
    if ((unsigned char)(zT_89 != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = 1;
    warn_lvl = zT_92;
    goto z_bb_16;
    z_bb_16:
    zT_93 = ctx->diag;
    zT_94 = warn_lvl;
    zT_97 = node.span_start;
    zT_107 = node.span_start;
    zT_108 = node.span_len;
    zT_99 = tmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_93, zT_94, (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_INFO_7001_OWNERSHIP_TRANSFERRED)), (unsigned int)(0), zT_97, (unsigned int)(zT_107 + (unsigned int)((unsigned int)zT_108)), zT_99);
    goto z_bb_14;
}

/* deferQueueEnsureCapacity */
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext* ctx, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_C6536882_EU_532 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_7A19C4A5_DeferEntry* zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7A19C4A5_DeferEntry* zT_35;
    zT_7A19C4A5_DeferEntry zT_36;
    int zT_37;
    unsigned int zT_39;
    unsigned int nc;
    unsigned char* raw;
    zT_7A19C4A5_DeferEntry* new_items;
    unsigned int i;
    zT_2 = ctx->defer_queue_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = ctx->defer_queue_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = ctx->defer_queue_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = ctx->defer_queue_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_7A19C4A5_DeferEntry*)raw;
    new_items = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    i = zT_32;
    goto z_bb_10;
    z_bb_10:
    zT_33 = ctx->defer_queue_len;
    if ((unsigned char)(i < zT_33)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = ctx->defer_queue_items;
    zT_36 = zT_35[i];
    new_items[i] = zT_36;
    goto z_bb_13;
    z_bb_12:
    ctx->defer_queue_items = new_items;
    ctx->defer_queue_cap = nc;
    return;
    z_bb_13:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_10;
}

/* analyzeSignature */
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_6B0A7D14_AstStore* zT_18;
    zT_D08E0C6B_anon_230871 zT_19;
    zT_243D6A41_FnProto* zT_20;
    unsigned int zT_21;
    zT_243D6A41_FnProto zT_22;
    unsigned int zT_24;
    unsigned short zT_28;
    zT_79FAE712_u64 zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    zT_79FAE712_u64 zT_33;
    unsigned int zT_35 = 0;
    int zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    zT_79FAE712_u64 zT_46;
    unsigned int zT_50 = 0;
    zT_22A7C88B_AstNode zT_51 = {0};
    unsigned int zT_53;
    zT_7E2F335A_AnalyzerContext* zT_56;
    unsigned int zT_57;
    int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    zT_7E2F335A_AnalyzerContext* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode node;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 param_payload;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned int type_expr;
    unsigned int ret_node;
    zT_3 = ctx->store;
    zT_4 = fn_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = ctx->store;
    zT_14 = fn_node_idx;
    zT_16 = zF_8BA26B9E_astStoreNodePayload(zT_13, zT_14);
    proto_idx = zT_16;
    zT_18 = ctx->store;
    zT_19 = zT_18->fn_protos;
    zT_20 = zT_19.items;
    zT_21 = (unsigned int)proto_idx;
    zT_22 = zT_20[zT_21];
    proto = zT_22;
    zT_24 = proto.params_start;
    zT_28 = proto.params_count;
    zT_30 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_24) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_28);
    param_payload = zT_30;
    zT_32 = ctx->store;
    zT_33 = param_payload;
    zT_35 = zF_03CE8CAB_astStoreGetExtraChi(zT_32, zT_33);
    params_n = zT_35;
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    pi = zT_38;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_42 = ctx->store;
    zT_45 = ctx->store;
    zT_46 = param_payload;
    zT_50 = zF_E5B10421_astStoreGetExtraChi(zT_45, zT_46, (unsigned int)((unsigned int)pi));
    zT_43 = zT_50;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    pnode = zT_51;
    zT_53 = pnode.child_0;
    type_expr = zT_53;
    if ((unsigned char)(type_expr != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_64 = proto.return_type_node;
    ret_node = zT_64;
    if ((unsigned char)(ret_node != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_60 = 1;
    zT_62 = pi + (unsigned int)((unsigned int)zT_60);
    pi = zT_62;
    goto z_bb_3;
    z_bb_7:
    zT_56 = ctx;
    zT_57 = type_expr;
    zF_E153ECE7_validateSignatureTy(zT_56, zT_57, (unsigned int)(0));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx;
    zT_68 = ret_node;
    zF_E153ECE7_validateSignatureTy(zT_67, zT_68, (unsigned int)(1));
    goto z_bb_10;
    z_bb_10:
    return;
}

/* validateSignatureType */
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    zT_79FAE712_u64 zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_79FAE712_u64 zT_22;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_33EF6BFB_TypeKind zT_32;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned char zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned char zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_61;
    unsigned char zT_62;
    zT_D3EB6303_StringInterner* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69 = {0};
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_D3EB6303_StringInterner* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_85;
    zT_F85C5DED_DiagnosticCollector* zT_87;
    int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_93;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_33EF6BFB_TypeKind zT_113;
    unsigned char zT_118;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    zT_F85C5DED_DiagnosticCollector* zT_125;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_147;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_F85C5DED_DiagnosticCollector* zT_154;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_D3EB6303_StringInterner* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_182 = 0;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_F85C5DED_DiagnosticCollector* zT_188;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_22A7C88B_AstNode tnode;
    unsigned int name_id;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 tid;
    unsigned int ttid;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u tname;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli iparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u wmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    zT_4 = ctx->store;
    zT_5 = type_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    tnode = zT_7;
    zT_8 = tnode.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = ctx->store;
    zT_15 = type_node_idx;
    zT_17 = zF_2E24BD6B_identNameId(zT_14, zT_15);
    name_id = zT_17;
    zT_19 = (zT_79FAE712_u64)name_id;
    key = zT_19;
    zT_21 = ctx->registry;
    zT_22 = key;
    zT_24 = zF_0EB68360_nameCacheGet(zT_21, zT_22);
    tid = zT_24;
    zT_25 = tid.has_value;
    if (zT_25) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    ttid = tid.value;
    zT_28 = ctx->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)ttid;
    zT_31 = zT_29[zT_30];
    ty = zT_31;
    zT_32 = ty.kind;
    if ((unsigned char)(zT_32 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    zT_175 = "anytype";
    zT_177 = 7;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    s_anytype = zT_176;
    zT_179 = ctx->interner;
    zT_180 = s_anytype;
    zT_182 = zF_50C274AF_stringInternerInter(zT_179, zT_180);
    anytype_nid = zT_182;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_31; else goto z_bb_32;
    z_bb_5:
    zT_38 = ty.kind;
    if ((unsigned char)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_6:
    zT_37 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_37) goto z_bb_20; else goto z_bb_21;
    z_bb_8:
    zT_44 = ty.kind;
    zT_43 = zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_10;
    z_bb_9:
    zT_43 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_43) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_50 = ty.kind;
    zT_49 = zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_13;
    z_bb_12:
    zT_49 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_56 = ty.kind;
    zT_55 = zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_16;
    z_bb_15:
    zT_55 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_55) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_62 = ty.state;
    zT_61 = zT_62 != (unsigned char)(2);
    goto z_bb_19;
    z_bb_18:
    zT_61 = 0;
    goto z_bb_19;
    z_bb_19:
    zT_37 = zT_61;
    goto z_bb_7;
    z_bb_20:
    zT_66 = ctx->interner;
    zT_67 = name_id;
    zT_69 = zF_9134020D_stringInternerGet(zT_66, zT_67);
    tname = zT_69;
    zT_71 = "incomplete type '";
    zT_73 = 17;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    ip1 = zT_72;
    zT_75 = "' in function signature";
    zT_77 = 23;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    ip2 = zT_76;
    zT_80 = 0;
    zT_79[zT_80] = ip1;
    zT_81 = 1;
    zT_79[zT_81] = tname;
    zT_82 = 2;
    zT_79[zT_82] = ip2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        iparts[_i] = zT_79[_i];
        _i++;
    }
}
    zT_87 = ctx->diag;
    zT_84 = zT_87->interner;
    zT_89 = 0;
    zT_90 = iparts + zT_89;
    zT_85 = zT_90;
    zT_92 = zF_8C4BFF7C_diagnosticBuilderMa(zT_84, zT_85, (unsigned int)(3));
    imsg = zT_92;
    zT_93 = ctx->diag;
    zT_97 = tnode.span_start;
    zT_108 = tnode.span_start;
    zT_109 = tnode.span_len;
    zT_99 = imsg;
    (void)zF_C82559AC_diagnosticCollector(zT_93, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2011_INCOMPLETE_TYPE)), (unsigned int)(0), zT_97, (unsigned int)(zT_108 + (unsigned int)((unsigned int)zT_109)), zT_99);
    goto z_bb_21;
    z_bb_21:
    zT_113 = ty.kind;
    if ((unsigned char)(zT_113 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_118 = is_return == (unsigned int)(0);
    goto z_bb_24;
    z_bb_23:
    zT_118 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_118) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_122 = "void not allowed as parameter type";
    zT_124 = 34;
    zT_123.ptr = zT_122;
    zT_123.len = zT_124;
    vmsg = zT_123;
    zT_125 = ctx->diag;
    zT_129 = tnode.span_start;
    zT_140 = tnode.span_start;
    zT_141 = tnode.span_len;
    zT_131 = vmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_125, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2010_VOID_PARAMETER)), (unsigned int)(0), zT_129, (unsigned int)(zT_140 + (unsigned int)((unsigned int)zT_141)), zT_131);
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(is_return != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_147 = ty.size;
    if ((unsigned char)(zT_147 > (unsigned int)(64))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_4;
    z_bb_29:
    zT_151 = "return type exceeds 64 bytes; may cause issues on MSVC 6.0";
    zT_153 = 58;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    wmsg = zT_152;
    zT_154 = ctx->diag;
    zT_158 = tnode.span_start;
    zT_169 = tnode.span_start;
    zT_170 = tnode.span_len;
    zT_160 = wmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_154, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7010_LARGE_RETURN)), (unsigned int)(0), zT_158, (unsigned int)(zT_169 + (unsigned int)((unsigned int)zT_170)), zT_160);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_185 = "anytype not supported in Z98";
    zT_187 = 28;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    amsg = zT_186;
    zT_188 = ctx->diag;
    zT_192 = tnode.span_start;
    zT_203 = tnode.span_start;
    zT_204 = tnode.span_len;
    zT_194 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_188, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), (unsigned int)(0), zT_192, (unsigned int)(zT_203 + (unsigned int)((unsigned int)zT_204)), zT_194);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_2;
}

/* analyzeExpr */
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_F85C5DED_DiagnosticCollector* zT_35;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    zT_7E2F335A_AnalyzerContext* zT_96;
    zT_2C0927B0_StateMap* zT_97;
    unsigned int zT_98;
    zT_7E2F335A_AnalyzerContext* zT_104;
    zT_2C0927B0_StateMap* zT_105;
    unsigned int zT_106;
    zT_6B0A7D14_AstStore* zT_113;
    unsigned int zT_114;
    unsigned int zT_116 = 0;
    int zT_118;
    unsigned int zT_119;
    zT_7E2F335A_AnalyzerContext* zT_122;
    zT_2C0927B0_StateMap* zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_130 = 0;
    int zT_131;
    unsigned int zT_133;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int zT_140;
    unsigned int zT_142 = 0;
    int zT_144;
    unsigned int zT_145;
    zT_7E2F335A_AnalyzerContext* zT_148;
    zT_2C0927B0_StateMap* zT_149;
    unsigned int zT_150;
    zT_6B0A7D14_AstStore* zT_151;
    unsigned int zT_152;
    unsigned int zT_156 = 0;
    int zT_157;
    unsigned int zT_159;
    zT_7E2F335A_AnalyzerContext* zT_164;
    zT_2C0927B0_StateMap* zT_165;
    unsigned int zT_166;
    zT_6B0A7D14_AstStore* zT_169;
    unsigned int zT_170;
    zT_22A7C88B_AstNode zT_173 = {0};
    zT_8143F551_AstKind zT_174;
    zT_7E2F335A_AnalyzerContext* zT_180;
    zT_2C0927B0_StateMap* zT_181;
    unsigned int zT_182;
    unsigned char zT_184 = 0;
    zT_2C0927B0_StateMap* zT_185;
    unsigned int zT_186;
    unsigned char zT_187;
    zT_6B0A7D14_AstStore* zT_188;
    unsigned int zT_189;
    unsigned int zT_192 = 0;
    unsigned int zT_193;
    unsigned char zT_196;
    zT_8143F551_AstKind zT_197;
    unsigned char zT_200 = 0;
    zT_7E2F335A_AnalyzerContext* zT_201;
    zT_2C0927B0_StateMap* zT_202;
    unsigned int zT_203;
    unsigned int zT_205;
    unsigned char zT_208;
    zT_8143F551_AstKind zT_209;
    unsigned char zT_212 = 0;
    zT_7E2F335A_AnalyzerContext* zT_213;
    zT_2C0927B0_StateMap* zT_214;
    unsigned int zT_215;
    unsigned int zT_217;
    unsigned char zT_220;
    zT_8143F551_AstKind zT_221;
    unsigned char zT_224 = 0;
    zT_7E2F335A_AnalyzerContext* zT_225;
    zT_2C0927B0_StateMap* zT_226;
    unsigned int zT_227;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char st;
    unsigned int start;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int args_n;
    unsigned int ai;
    unsigned int bargs_n;
    unsigned int bi;
    zT_22A7C88B_AstNode lhs_node;
    unsigned char new_st;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = ctx;
    zT_18 = state;
    zT_19 = node.child_0;
    zT_21 = zF_0619AC1C_classifyExpr(zT_17, zT_18, zT_19);
    st = zT_21;
    zT_23 = node.span_start;
    start = zT_23;
    zT_25 = node.span_start;
    zT_26 = node.span_len;
    zT_28 = zT_25 + (unsigned int)((unsigned int)zT_26);
    end = zT_28;
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_is_null))) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_32 = "definite null pointer dereference";
    zT_34 = 33;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    msg = zT_33;
    zT_35 = ctx->diag;
    zT_39 = start;
    zT_40 = end;
    zT_41 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_35, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2004_DEFINITE_NULL_DEREF)), (unsigned int)(0), zT_39, zT_40, zT_41);
    goto z_bb_6;
    z_bb_6:
    return;
    z_bb_7:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_uninit))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_53 = "dereference of uninitialized pointer";
    zT_55 = 36;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    msg = zT_54;
    zT_56 = ctx->diag;
    zT_60 = start;
    zT_61 = end;
    zT_62 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_56, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6001_UNINIT_DEREF)), (unsigned int)(0), zT_60, zT_61, zT_62);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_maybe))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_74 = "potential null pointer dereference";
    zT_76 = 34;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    msg = zT_75;
    zT_77 = ctx->diag;
    zT_81 = start;
    zT_82 = end;
    zT_83 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_77, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6002_POTENTIAL_NULL_DEREF)), (unsigned int)(0), zT_81, zT_82, zT_83);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_96 = ctx;
    zT_97 = state;
    zT_98 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_96, zT_97, zT_98);
    return;
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_104 = ctx;
    zT_105 = state;
    zT_106 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_104, zT_105, zT_106);
    return;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_113 = ctx->store;
    zT_114 = expr_idx;
    zT_116 = zF_152E19CB_astStoreNodeExtraCh(zT_113, zT_114);
    args_n = zT_116;
    zT_118 = 0;
    zT_119 = (unsigned int)zT_118;
    ai = zT_119;
    goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_122 = ctx;
    zT_123 = state;
    zT_125 = ctx->store;
    zT_126 = expr_idx;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_125, zT_126, (unsigned int)((unsigned int)ai));
    zT_124 = zT_130;
    zF_8D5B6C98_analyzeExpr(zT_122, zT_123, zT_124);
    goto z_bb_22;
    z_bb_21:
    return;
    z_bb_22:
    zT_131 = 1;
    zT_133 = ai + (unsigned int)((unsigned int)zT_131);
    ai = zT_133;
    goto z_bb_19;
    z_bb_23:
    zT_139 = ctx->store;
    zT_140 = expr_idx;
    zT_142 = zF_152E19CB_astStoreNodeExtraCh(zT_139, zT_140);
    bargs_n = zT_142;
    zT_144 = 0;
    zT_145 = (unsigned int)zT_144;
    bi = zT_145;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)bargs_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_148 = ctx;
    zT_149 = state;
    zT_151 = ctx->store;
    zT_152 = expr_idx;
    zT_156 = zF_B10B1BC1_astStoreNodeExtraCh(zT_151, zT_152, (unsigned int)((unsigned int)bi));
    zT_150 = zT_156;
    zF_8D5B6C98_analyzeExpr(zT_148, zT_149, zT_150);
    goto z_bb_28;
    z_bb_27:
    return;
    z_bb_28:
    zT_157 = 1;
    zT_159 = bi + (unsigned int)((unsigned int)zT_157);
    bi = zT_159;
    goto z_bb_25;
    z_bb_29:
    zT_164 = ctx;
    zT_165 = state;
    zT_166 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_164, zT_165, zT_166);
    zT_169 = ctx->store;
    zT_170 = node.child_0;
    zT_173 = zF_FCDD1D35_astStoreNodeAt(zT_169, zT_170);
    lhs_node = zT_173;
    zT_174 = lhs_node.kind;
    if ((unsigned char)(zT_174 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_193 = node.child_0;
    if ((unsigned char)(zT_193 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_180 = ctx;
    zT_181 = state;
    zT_182 = node.child_1;
    zT_184 = zF_0619AC1C_classifyExpr(zT_180, zT_181, zT_182);
    new_st = zT_184;
    zT_185 = state;
    zT_188 = ctx->store;
    zT_189 = node.child_0;
    zT_192 = zF_2E24BD6B_identNameId(zT_188, zT_189);
    zT_186 = zT_192;
    zT_187 = new_st;
    zF_ACCFA860_stateMapSet(zT_185, zT_186, zT_187);
    goto z_bb_32;
    z_bb_32:
    return;
    z_bb_33:
    zT_197 = kind;
    zT_200 = zF_C395F6FD_nodeChildIsNode(zT_197, (unsigned char)(0));
    zT_196 = zT_200;
    goto z_bb_35;
    z_bb_34:
    zT_196 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_196) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_201 = ctx;
    zT_202 = state;
    zT_203 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_201, zT_202, zT_203);
    goto z_bb_37;
    z_bb_37:
    zT_205 = node.child_1;
    if ((unsigned char)(zT_205 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_209 = kind;
    zT_212 = zF_C395F6FD_nodeChildIsNode(zT_209, (unsigned char)(1));
    zT_208 = zT_212;
    goto z_bb_40;
    z_bb_39:
    zT_208 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_208) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_213 = ctx;
    zT_214 = state;
    zT_215 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_213, zT_214, zT_215);
    goto z_bb_42;
    z_bb_42:
    zT_217 = node.child_2;
    if ((unsigned char)(zT_217 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_221 = kind;
    zT_224 = zF_C395F6FD_nodeChildIsNode(zT_221, (unsigned char)(2));
    zT_220 = zT_224;
    goto z_bb_45;
    z_bb_44:
    zT_220 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_220) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_225 = ctx;
    zT_226 = state;
    zT_227 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_225, zT_226, zT_227);
    goto z_bb_47;
    z_bb_47:
    return;
}

/* classifyExpr */
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_12;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    zT_79FAE712_u64 zT_51 = 0;
    zT_2C0927B0_StateMap* zT_61;
    unsigned int zT_62;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_66 = 0;
    zT_43E16BE5_Opt_8 zT_67 = {0};
    unsigned char zT_68;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_79FAE712_u64 val;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(zT_E48CAD8A_PtrState_uninit);
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = expr_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = node.kind;
    kind = zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_48 = ctx->store;
    zT_49 = expr_idx;
    zT_51 = zF_678B9A72_astStoreIntValue(zT_48, zT_49);
    val = zT_51;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_18:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_19:
    zT_61 = state;
    zT_63 = ctx->store;
    zT_64 = expr_idx;
    zT_66 = zF_2E24BD6B_identNameId(zT_63, zT_64);
    zT_62 = zT_66;
    zT_67 = zF_2EC17ECC_stateMapGet(zT_61, zT_62);
    result = zT_67;
    zT_68 = result.has_value;
    if (zT_68) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_21:
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
}

/* isNullExpr */
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_8143F551_AstKind zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_79FAE712_u64 zT_23 = 0;
    zT_22A7C88B_AstNode node;
    zT_79FAE712_u64 val;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_15 = node.kind;
    if ((unsigned char)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_21 = store;
    zT_22 = idx;
    zT_23 = zF_678B9A72_astStoreIntValue(zT_21, zT_22);
    val = zT_23;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* isIdentExpr */
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_BAEE192E_Opt_10 zT_17;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    zT_22A7C88B_AstNode node;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = store;
    zT_15 = idx;
    zT_16 = zF_2E24BD6B_identNameId(zT_14, zT_15);
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
    z_bb_4:
    zT_18.has_value = 0;
    return zT_18;
}

/* detectNullGuard */
zT_D0D475FB_Opt_118 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore* store, unsigned int cond_idx) {
    zT_D0D475FB_Opt_118 zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned char zT_19 = 0;
    int zT_20;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_BAEE192E_Opt_10 zT_26 = {0};
    unsigned char zT_27;
    zT_438E6589_NullGuard zT_29;
    unsigned char zT_30;
    zT_D0D475FB_Opt_118 zT_31;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned char zT_36 = 0;
    int zT_37;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_BAEE192E_Opt_10 zT_43 = {0};
    unsigned char zT_44;
    zT_438E6589_NullGuard zT_46;
    unsigned char zT_47;
    zT_D0D475FB_Opt_118 zT_48;
    zT_D0D475FB_Opt_118 zT_49 = {0};
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_438E6589_NullGuard zT_68;
    unsigned char zT_69;
    zT_D0D475FB_Opt_118 zT_70;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    unsigned char zT_75 = 0;
    int zT_76;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    zT_BAEE192E_Opt_10 zT_82 = {0};
    unsigned char zT_83;
    zT_438E6589_NullGuard zT_85;
    unsigned char zT_86;
    zT_D0D475FB_Opt_118 zT_87;
    zT_D0D475FB_Opt_118 zT_88 = {0};
    zT_438E6589_NullGuard zT_93;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    unsigned int zT_96 = 0;
    unsigned char zT_97;
    zT_D0D475FB_Opt_118 zT_98;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    zT_D0D475FB_Opt_118 zT_107 = {0};
    unsigned char zT_108;
    zT_438E6589_NullGuard zT_110;
    unsigned int zT_111;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_115;
    zT_D0D475FB_Opt_118 zT_116;
    zT_D0D475FB_Opt_118 zT_117 = {0};
    zT_D0D475FB_Opt_118 zT_118 = {0};
    zT_22A7C88B_AstNode cond;
    zT_8143F551_AstKind ck;
    unsigned char n0;
    zT_BAEE192E_Opt_10 id1;
    unsigned char n1;
    unsigned int nid;
    zT_BAEE192E_Opt_10 id0;
    zT_D0D475FB_Opt_118 inner;
    zT_438E6589_NullGuard g;
    if ((unsigned char)(cond_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = cond_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    cond = zT_8;
    zT_10 = cond.kind;
    ck = zT_10;
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = store;
    zT_17 = cond.child_0;
    zT_19 = zF_F32BD543_isNullExpr(zT_16, zT_17);
    n0 = zT_19;
    zT_20 = 0;
    if ((unsigned char)(n0 != zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_23 = store;
    zT_24 = cond.child_1;
    zT_26 = zF_7B65B82E_isIdentExpr(zT_23, zT_24);
    id1 = zT_26;
    zT_27 = id1.has_value;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_33 = store;
    zT_34 = cond.child_1;
    zT_36 = zF_F32BD543_isNullExpr(zT_33, zT_34);
    n1 = zT_36;
    zT_37 = 0;
    if ((unsigned char)(n1 != zT_37)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    nid = id1.value;
    zT_29.name_id = nid;
    zT_30 = 1;
    zT_29.is_not_null = zT_30;
    zT_31.has_value = 1;
    zT_31.value = zT_29;
    return zT_31;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_40 = store;
    zT_41 = cond.child_0;
    zT_43 = zF_7B65B82E_isIdentExpr(zT_40, zT_41);
    id0 = zT_43;
    zT_44 = id0.has_value;
    if (zT_44) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_49.has_value = 0;
    return zT_49;
    z_bb_11:
    nid = id0.value;
    zT_46.name_id = nid;
    zT_47 = 1;
    zT_46.is_not_null = zT_47;
    zT_48.has_value = 1;
    zT_48.value = zT_46;
    return zT_48;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_55 = store;
    zT_56 = cond.child_0;
    zT_58 = zF_F32BD543_isNullExpr(zT_55, zT_56);
    n0 = zT_58;
    zT_59 = 0;
    if ((unsigned char)(n0 != zT_59)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    zT_62 = store;
    zT_63 = cond.child_1;
    zT_65 = zF_7B65B82E_isIdentExpr(zT_62, zT_63);
    id1 = zT_65;
    zT_66 = id1.has_value;
    if (zT_66) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_72 = store;
    zT_73 = cond.child_1;
    zT_75 = zF_F32BD543_isNullExpr(zT_72, zT_73);
    n1 = zT_75;
    zT_76 = 0;
    if ((unsigned char)(n1 != zT_76)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    nid = id1.value;
    zT_68.name_id = nid;
    zT_69 = 0;
    zT_68.is_not_null = zT_69;
    zT_70.has_value = 1;
    zT_70.value = zT_68;
    return zT_70;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_79 = store;
    zT_80 = cond.child_0;
    zT_82 = zF_7B65B82E_isIdentExpr(zT_79, zT_80);
    id0 = zT_82;
    zT_83 = id0.has_value;
    if (zT_83) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_88.has_value = 0;
    return zT_88;
    z_bb_21:
    nid = id0.value;
    zT_85.name_id = nid;
    zT_86 = 0;
    zT_85.is_not_null = zT_86;
    zT_87.has_value = 1;
    zT_87.value = zT_85;
    return zT_87;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_94 = store;
    zT_95 = cond_idx;
    zT_96 = zF_2E24BD6B_identNameId(zT_94, zT_95);
    zT_93.name_id = zT_96;
    zT_97 = 1;
    zT_93.is_not_null = zT_97;
    zT_98.has_value = 1;
    zT_98.value = zT_93;
    return zT_98;
    z_bb_24:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_104 = store;
    zT_105 = cond.child_0;
    zT_107 = zF_8D299A60_detectNullGuard(zT_104, zT_105);
    inner = zT_107;
    zT_108 = inner.has_value;
    if (zT_108) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_118.has_value = 0;
    return zT_118;
    z_bb_27:
    g = inner.value;
    zT_111 = g.name_id;
    zT_110.name_id = zT_111;
    zT_112 = 1;
    zT_113 = g.is_not_null;
    zT_115 = (unsigned char)(unsigned char)(zT_112 - zT_113);
    zT_110.is_not_null = zT_115;
    zT_116.has_value = 1;
    zT_116.value = zT_110;
    return zT_116;
    z_bb_28:
    zT_117.has_value = 0;
    return zT_117;
}

/* applyNullGuardRefinement */
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore* store, unsigned int cond_idx, zT_2C0927B0_StateMap* then_state, zT_2C0927B0_StateMap* else_state) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_D0D475FB_Opt_118 zT_7 = {0};
    unsigned char zT_8;
    unsigned char zT_10;
    int zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zT_E48CAD8A_PtrState zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_E48CAD8A_PtrState zT_22;
    zT_2C0927B0_StateMap* zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    zT_E48CAD8A_PtrState zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    zT_E48CAD8A_PtrState zT_32;
    zT_D0D475FB_Opt_118 guard;
    zT_438E6589_NullGuard g;
    zT_5 = store;
    zT_6 = cond_idx;
    zT_7 = zF_8D299A60_detectNullGuard(zT_5, zT_6);
    guard = zT_7;
    zT_8 = guard.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    g = guard.value;
    zT_10 = g.is_not_null;
    zT_11 = 0;
    if ((unsigned char)(zT_10 != zT_11)) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_13 = then_state;
    zT_14 = g.name_id;
    zT_17 = zT_E48CAD8A_PtrState_safe;
    zT_15 = zT_17;
    zF_ACCFA860_stateMapSet(zT_13, zT_14, zT_15);
    zT_18 = else_state;
    zT_19 = g.name_id;
    zT_22 = zT_E48CAD8A_PtrState_is_null;
    zT_20 = zT_22;
    zF_ACCFA860_stateMapSet(zT_18, zT_19, zT_20);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = then_state;
    zT_24 = g.name_id;
    zT_27 = zT_E48CAD8A_PtrState_is_null;
    zT_25 = zT_27;
    zF_ACCFA860_stateMapSet(zT_23, zT_24, zT_25);
    zT_28 = else_state;
    zT_29 = g.name_id;
    zT_32 = zT_E48CAD8A_PtrState_safe;
    zT_30 = zT_32;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, zT_30);
    goto z_bb_4;
}

/* handleNullVarDecl */
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_14;
    zT_7E2F335A_AnalyzerContext* zT_18;
    zT_2C0927B0_StateMap* zT_19;
    unsigned int zT_20;
    unsigned char zT_21 = 0;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_E48CAD8A_PtrState zT_28;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int init_idx;
    unsigned char st;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = ctx->store;
    zT_10 = node_idx;
    zT_12 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    name_id = zT_12;
    zT_14 = node.child_1;
    init_idx = zT_14;
    if ((unsigned char)(init_idx != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_18 = ctx;
    zT_19 = state;
    zT_20 = init_idx;
    zT_21 = zF_0619AC1C_classifyExpr(zT_18, zT_19, zT_20);
    st = zT_21;
    zT_22 = state;
    zT_23 = name_id;
    zT_24 = st;
    zF_ACCFA860_stateMapSet(zT_22, zT_23, zT_24);
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_E48CAD8A_PtrState_uninit;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_2;
}

/* handleNullAssign */
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_9;
    zT_7E2F335A_AnalyzerContext* zT_11;
    zT_2C0927B0_StateMap* zT_12;
    unsigned int zT_13;
    unsigned char zT_14 = 0;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_8143F551_AstKind zT_22;
    zT_2C0927B0_StateMap* zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int rhs;
    unsigned char rhs_state;
    unsigned int lhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_1;
    rhs = zT_9;
    zT_11 = ctx;
    zT_12 = state;
    zT_13 = rhs;
    zT_14 = zF_0619AC1C_classifyExpr(zT_11, zT_12, zT_13);
    rhs_state = zT_14;
    zT_16 = node.child_0;
    lhs_idx = zT_16;
    zT_18 = ctx->store;
    zT_19 = lhs_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    lhs_node = zT_21;
    zT_22 = lhs_node.kind;
    if ((unsigned char)(zT_22 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_27 = state;
    zT_30 = ctx->store;
    zT_31 = lhs_idx;
    zT_33 = zF_2E24BD6B_identNameId(zT_30, zT_31);
    zT_28 = zT_33;
    zT_29 = rhs_state;
    zF_ACCFA860_stateMapSet(zT_27, zT_28, zT_29);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* executeDeferQueue */
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int target_depth, unsigned char is_error, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_12;
    zT_7A19C4A5_DeferEntry* zT_14;
    zT_7A19C4A5_DeferEntry zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_7E2F335A_AnalyzerContext* zT_21;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    zT_7E2F335A_AnalyzerContext* zT_31;
    zT_2C0927B0_StateMap* zT_32;
    unsigned int zT_33;
    unsigned int idx;
    zT_7A19C4A5_DeferEntry entry;
    ctx->in_defer_exec = (unsigned char)(1);
    goto z_bb_1;
    z_bb_1:
    zT_6 = ctx->defer_queue_len;
    if ((unsigned char)(zT_6 > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = ctx->defer_queue_len;
    zT_12 = zT_10 - (unsigned int)(1);
    idx = zT_12;
    zT_14 = ctx->defer_queue_items;
    zT_15 = zT_14[idx];
    entry = zT_15;
    zT_16 = entry.scope_depth;
    if ((unsigned char)(zT_16 < target_depth)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    ctx->in_defer_exec = (unsigned char)(0);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    ctx->defer_queue_len = idx;
    zT_18 = entry.kind;
    if ((unsigned char)(zT_18 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_21 = ctx;
    zT_22 = state;
    zT_23 = entry.stmt_idx;
    visit_fn(zT_21, zT_22, zT_23);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_25 = entry.kind;
    if ((unsigned char)(zT_25 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_28 = is_error != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_31 = ctx;
    zT_32 = state;
    zT_33 = entry.stmt_idx;
    visit_fn(zT_31, zT_32, zT_33);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
}

/* walkBlock */
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int block_idx, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    int zT_31;
    unsigned int zT_32;
    zT_7E2F335A_AnalyzerContext* zT_35;
    zT_2C0927B0_StateMap* zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_43 = 0;
    int zT_44;
    unsigned int zT_46;
    zT_7E2F335A_AnalyzerContext* zT_47;
    zT_2C0927B0_StateMap* zT_48;
    unsigned int zT_49;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_51;
    unsigned char zT_53;
    zT_7E2F335A_AnalyzerContext* zT_56;
    zT_2C0927B0_StateMap* zT_57;
    zT_22A7C88B_AstNode node;
    unsigned int saved_depth;
    unsigned int children_n;
    unsigned int i;
    if ((unsigned char)(block_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = block_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = block_idx;
    visit_fn(zT_16, zT_17, zT_18);
    return;
    z_bb_4:
    zT_20 = ctx->current_depth;
    saved_depth = zT_20;
    zT_21 = ctx->current_depth;
    zT_22 = 1;
    ctx->current_depth = (unsigned int)(zT_21 + (unsigned int)((unsigned int)zT_22));
    zT_26 = ctx->store;
    zT_27 = block_idx;
    zT_29 = zF_152E19CB_astStoreNodeExtraCh(zT_26, zT_27);
    children_n = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    i = zT_32;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = ctx;
    zT_36 = state;
    zT_38 = ctx->store;
    zT_39 = block_idx;
    zT_43 = zF_B10B1BC1_astStoreNodeExtraCh(zT_38, zT_39, (unsigned int)((unsigned int)i));
    zT_37 = zT_43;
    visit_fn(zT_35, zT_36, zT_37);
    goto z_bb_8;
    z_bb_7:
    zT_47 = ctx;
    zT_48 = state;
    zT_49 = saved_depth;
    zT_51 = visit_fn;
    zF_332F08BB_executeDeferQueue(zT_47, zT_48, zT_49, (unsigned char)(0), zT_51);
    zT_53 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_53 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_44 = 1;
    zT_46 = i + (unsigned int)((unsigned int)zT_44);
    i = zT_46;
    goto z_bb_5;
    z_bb_9:
    zT_56 = ctx;
    zT_57 = state;
    zF_628B7574_checkLeaksOnScopeEx(zT_56, zT_57);
    goto z_bb_10;
    z_bb_10:
    ctx->current_depth = saved_depth;
    return;
}

/* visitStatement */
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx, zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned char zT_18;
    zT_7E2F335A_AnalyzerContext* zT_23;
    zT_2C0927B0_StateMap* zT_24;
    unsigned int zT_25;
    zT_2C0927B0_StateMap* zT_28;
    zT_3E40CD83_Sand* zT_29;
    zT_2C0927B0_StateMap* zT_31 = 0;
    zT_2C0927B0_StateMap* zT_33;
    zT_3E40CD83_Sand* zT_34;
    zT_2C0927B0_StateMap* zT_36 = 0;
    unsigned char zT_37;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_2C0927B0_StateMap* zT_42;
    zT_2C0927B0_StateMap* zT_43;
    zT_2C0927B0_StateMap* zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_56 = 0;
    zT_E48CAD8A_PtrState zT_57;
    zT_7E2F335A_AnalyzerContext* zT_58;
    zT_2C0927B0_StateMap* zT_59;
    unsigned int zT_60;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_61;
    unsigned int zT_63;
    zT_7E2F335A_AnalyzerContext* zT_66;
    zT_2C0927B0_StateMap* zT_67;
    unsigned int zT_68;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_69;
    zT_2C0927B0_StateMap* zT_71;
    zT_2C0927B0_StateMap* zT_72;
    zT_2C0927B0_StateMap* zT_73;
    unsigned char zT_80;
    zT_7E2F335A_AnalyzerContext* zT_85;
    zT_2C0927B0_StateMap* zT_86;
    unsigned int zT_87;
    zT_2C0927B0_StateMap* zT_90;
    zT_3E40CD83_Sand* zT_91;
    zT_2C0927B0_StateMap* zT_93 = 0;
    unsigned char zT_94;
    unsigned char zT_97;
    zT_2C0927B0_StateMap* zT_102;
    unsigned int zT_103;
    unsigned char zT_104;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    unsigned int zT_108 = 0;
    zT_E48CAD8A_PtrState zT_109;
    zT_7E2F335A_AnalyzerContext* zT_110;
    zT_2C0927B0_StateMap* zT_111;
    unsigned int zT_112;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_113;
    zT_2C0927B0_StateMap* zT_115;
    zT_2C0927B0_StateMap* zT_116;
    zT_2C0927B0_StateMap* zT_117;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_128 = 0;
    int zT_130;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_136;
    zT_6B0A7D14_AstStore* zT_138;
    unsigned int zT_139;
    unsigned int zT_143 = 0;
    zT_22A7C88B_AstNode zT_144 = {0};
    zT_2C0927B0_StateMap* zT_146;
    zT_3E40CD83_Sand* zT_147;
    zT_2C0927B0_StateMap* zT_149 = 0;
    zT_7E2F335A_AnalyzerContext* zT_150;
    zT_2C0927B0_StateMap* zT_151;
    unsigned int zT_152;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_153;
    zT_2C0927B0_StateMap* zT_155;
    zT_2C0927B0_StateMap* zT_156;
    zT_2C0927B0_StateMap* zT_157;
    int zT_160;
    unsigned int zT_162;
    zT_2C0927B0_StateMap* zT_168;
    zT_3E40CD83_Sand* zT_169;
    zT_2C0927B0_StateMap* zT_171 = 0;
    zT_7E2F335A_AnalyzerContext* zT_172;
    zT_2C0927B0_StateMap* zT_173;
    unsigned int zT_174;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_175;
    zT_2C0927B0_StateMap* zT_177;
    zT_2C0927B0_StateMap* zT_178;
    zT_2C0927B0_StateMap* zT_179;
    unsigned int zT_186;
    unsigned char zT_189;
    zT_7E2F335A_AnalyzerContext* zT_192;
    zT_2C0927B0_StateMap* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned char zT_197;
    zT_7E2F335A_AnalyzerContext* zT_200;
    zT_2C0927B0_StateMap* zT_201;
    unsigned int zT_202;
    zT_7E2F335A_AnalyzerContext* zT_204;
    zT_2C0927B0_StateMap* zT_205;
    unsigned int zT_206;
    unsigned char zT_211;
    unsigned char zT_216;
    unsigned char zT_217;
    unsigned char zT_221;
    unsigned char zT_226;
    zT_7E2F335A_AnalyzerContext* zT_227;
    unsigned int zT_229;
    zT_7A19C4A5_DeferEntry zT_232;
    unsigned int zT_233;
    zT_7A19C4A5_DeferEntry* zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    int zT_237;
    unsigned char zT_240;
    unsigned char zT_243;
    zT_7E2F335A_AnalyzerContext* zT_248;
    zT_2C0927B0_StateMap* zT_249;
    unsigned int zT_250;
    zT_7E2F335A_AnalyzerContext* zT_251;
    zT_2C0927B0_StateMap* zT_252;
    unsigned int zT_253;
    unsigned char zT_254;
    unsigned char zT_257;
    zT_7E2F335A_AnalyzerContext* zT_262;
    zT_2C0927B0_StateMap* zT_263;
    unsigned int zT_264;
    zT_7E2F335A_AnalyzerContext* zT_265;
    zT_2C0927B0_StateMap* zT_266;
    unsigned int zT_267;
    zT_7E2F335A_AnalyzerContext* zT_272;
    zT_2C0927B0_StateMap* zT_273;
    unsigned int zT_274;
    zT_7E2F335A_AnalyzerContext* zT_276;
    zT_2C0927B0_StateMap* zT_277;
    unsigned int zT_278;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_2C0927B0_StateMap* then_state;
    zT_2C0927B0_StateMap* else_state;
    zT_2C0927B0_StateMap* body_state;
    unsigned int prongs_n;
    unsigned int si;
    zT_22A7C88B_AstNode prong;
    zT_2C0927B0_StateMap* ps;
    unsigned char dk;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_18 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture);
    goto z_bb_5;
    z_bb_4:
    zT_18 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_18) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_23 = ctx;
    zT_24 = state;
    zT_25 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_23, zT_24, zT_25);
    zT_28 = state;
    zT_29 = ctx->alloc;
    zT_31 = zF_77086C9C_stateMapFork(zT_28, zT_29);
    then_state = zT_31;
    zT_33 = state;
    zT_34 = ctx->alloc;
    zT_36 = zF_77086C9C_stateMapFork(zT_33, zT_34);
    else_state = zT_36;
    zT_37 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_37 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_16; else goto z_bb_15;
    z_bb_9:
    zT_40 = ctx->store;
    zT_41 = node.child_0;
    zT_42 = then_state;
    zT_43 = else_state;
    zF_76DBB626_applyNullGuardRefin(zT_40, zT_41, zT_42, zT_43);
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_58 = ctx;
    zT_59 = then_state;
    zT_60 = node.child_1;
    zT_61 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_58, zT_59, zT_60, zT_61);
    zT_63 = node.child_2;
    if ((unsigned char)(zT_63 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_50 = then_state;
    zT_53 = ctx->store;
    zT_54 = node_idx;
    zT_56 = zF_8BA26B9E_astStoreNodePayload(zT_53, zT_54);
    zT_51 = zT_56;
    zT_57 = zT_E48CAD8A_PtrState_safe;
    zT_52 = zT_57;
    zF_ACCFA860_stateMapSet(zT_50, zT_51, zT_52);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_66 = ctx;
    zT_67 = else_state;
    zT_68 = node.child_2;
    zT_69 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_66, zT_67, zT_68, zT_69);
    goto z_bb_14;
    z_bb_14:
    zT_71 = state;
    zT_72 = then_state;
    zT_73 = else_state;
    zF_143ACBA6_stateMapMergeStates(zT_71, zT_72, zT_73, (unsigned char)(99));
    goto z_bb_7;
    z_bb_15:
    zT_80 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_17;
    z_bb_16:
    zT_80 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_80) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_85 = ctx;
    zT_86 = state;
    zT_87 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_85, zT_86, zT_87);
    zT_90 = state;
    zT_91 = ctx->alloc;
    zT_93 = zF_77086C9C_stateMapFork(zT_90, zT_91);
    body_state = zT_93;
    zT_94 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_94 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    goto z_bb_7;
    z_bb_20:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_26; else goto z_bb_28;
    z_bb_21:
    zT_97 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_23;
    z_bb_22:
    zT_97 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_97) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_102 = body_state;
    zT_105 = ctx->store;
    zT_106 = node_idx;
    zT_108 = zF_8BA26B9E_astStoreNodePayload(zT_105, zT_106);
    zT_103 = zT_108;
    zT_109 = zT_E48CAD8A_PtrState_safe;
    zT_104 = zT_109;
    zF_ACCFA860_stateMapSet(zT_102, zT_103, zT_104);
    goto z_bb_25;
    z_bb_25:
    zT_110 = ctx;
    zT_111 = body_state;
    zT_112 = node.child_1;
    zT_113 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_110, zT_111, zT_112, zT_113);
    zT_115 = state;
    zT_116 = state;
    zT_117 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_115, zT_116, zT_117, (unsigned char)(99));
    goto z_bb_19;
    z_bb_26:
    zT_125 = ctx->store;
    zT_126 = node_idx;
    zT_128 = zF_152E19CB_astStoreNodeExtraCh(zT_125, zT_126);
    prongs_n = zT_128;
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    si = zT_131;
    goto z_bb_29;
    z_bb_27:
    goto z_bb_19;
    z_bb_28:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_33; else goto z_bb_35;
    z_bb_29:
    if ((unsigned char)(si < (unsigned int)((unsigned int)prongs_n))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_135 = ctx->store;
    zT_138 = ctx->store;
    zT_139 = node_idx;
    zT_143 = zF_B10B1BC1_astStoreNodeExtraCh(zT_138, zT_139, (unsigned int)((unsigned int)si));
    zT_136 = zT_143;
    zT_144 = zF_FCDD1D35_astStoreNodeAt(zT_135, zT_136);
    prong = zT_144;
    zT_146 = state;
    zT_147 = ctx->alloc;
    zT_149 = zF_77086C9C_stateMapFork(zT_146, zT_147);
    ps = zT_149;
    zT_150 = ctx;
    zT_151 = ps;
    zT_152 = prong.child_0;
    zT_153 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_150, zT_151, zT_152, zT_153);
    zT_155 = state;
    zT_156 = state;
    zT_157 = ps;
    zF_143ACBA6_stateMapMergeStates(zT_155, zT_156, zT_157, (unsigned char)(99));
    goto z_bb_32;
    z_bb_31:
    goto z_bb_27;
    z_bb_32:
    zT_160 = 1;
    zT_162 = si + (unsigned int)((unsigned int)zT_160);
    si = zT_162;
    goto z_bb_29;
    z_bb_33:
    zT_168 = state;
    zT_169 = ctx->alloc;
    zT_171 = zF_77086C9C_stateMapFork(zT_168, zT_169);
    body_state = zT_171;
    zT_172 = ctx;
    zT_173 = body_state;
    zT_174 = node.child_1;
    zT_175 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_172, zT_173, zT_174, zT_175);
    zT_177 = state;
    zT_178 = state;
    zT_179 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_177, zT_178, zT_179, (unsigned char)(99));
    goto z_bb_34;
    z_bb_34:
    goto z_bb_27;
    z_bb_35:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_36; else goto z_bb_38;
    z_bb_36:
    zT_186 = node.child_0;
    if ((unsigned char)(zT_186 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_46; else goto z_bb_45;
    z_bb_39:
    zT_189 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_189 != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_204 = ctx;
    zT_205 = state;
    zT_206 = node_idx;
    on_stmt(zT_204, zT_205, zT_206);
    goto z_bb_37;
    z_bb_41:
    zT_192 = ctx;
    zT_193 = state;
    zT_194 = node.child_0;
    zT_195 = node_idx;
    zF_8C7FC932_checkReturnProvenan(zT_192, zT_193, zT_194, zT_195);
    goto z_bb_42;
    z_bb_42:
    zT_197 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_197 != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_200 = ctx;
    zT_201 = state;
    zT_202 = node.child_0;
    zF_65CAFC02_handleOwnershipRetu(zT_200, zT_201, zT_202);
    goto z_bb_44;
    z_bb_44:
    goto z_bb_40;
    z_bb_45:
    zT_211 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_47;
    z_bb_46:
    zT_211 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_211) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_217 = ctx->in_defer_exec;
    zT_216 = zT_217 == (unsigned char)(0);
    goto z_bb_50;
    z_bb_49:
    zT_216 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_216) goto z_bb_51; else goto z_bb_53;
    z_bb_51:
    zT_221 = 0;
    dk = zT_221;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt))) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_37;
    z_bb_53:
    zT_240 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_240 != (unsigned char)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_226 = 1;
    dk = zT_226;
    goto z_bb_55;
    z_bb_55:
    zT_227 = ctx;
    zT_229 = ctx->defer_queue_len;
    zF_46BA7660_deferQueueEnsureCap(zT_227, (unsigned int)(zT_229 + (unsigned int)(1)));
    zT_232.kind = dk;
    zT_232.stmt_idx = node_idx;
    zT_233 = ctx->current_depth;
    zT_232.scope_depth = zT_233;
    zT_234 = ctx->defer_queue_items;
    zT_235 = ctx->defer_queue_len;
    zT_234[zT_235] = zT_232;
    zT_236 = ctx->defer_queue_len;
    zT_237 = 1;
    ctx->defer_queue_len = (unsigned int)(zT_236 + (unsigned int)((unsigned int)zT_237));
    goto z_bb_52;
    z_bb_56:
    zT_243 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_58;
    z_bb_57:
    zT_243 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_243) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_248 = ctx;
    zT_249 = state;
    zT_250 = node_idx;
    zF_B7AD2EEF_handleNullVarDecl(zT_248, zT_249, zT_250);
    zT_251 = ctx;
    zT_252 = state;
    zT_253 = node_idx;
    on_stmt(zT_251, zT_252, zT_253);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_52;
    z_bb_61:
    zT_254 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_254 != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_257 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign);
    goto z_bb_64;
    z_bb_63:
    zT_257 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_257) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_262 = ctx;
    zT_263 = state;
    zT_264 = node_idx;
    zF_847AD0EF_handleNullAssign(zT_262, zT_263, zT_264);
    zT_265 = ctx;
    zT_266 = state;
    zT_267 = node_idx;
    on_stmt(zT_265, zT_266, zT_267);
    goto z_bb_66;
    z_bb_66:
    goto z_bb_60;
    z_bb_67:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    zT_272 = ctx;
    zT_273 = state;
    zT_274 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_272, zT_273, zT_274);
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_276 = ctx;
    zT_277 = state;
    zT_278 = node_idx;
    on_stmt(zT_276, zT_277, zT_278);
    goto z_bb_69;
}

/* onNullStmt */
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    (void)ctx;
    (void)state;
    (void)node_idx;
    return;
}

/* onLifetimeStmt */
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned int zT_13;
    zT_7E2F335A_AnalyzerContext* zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_28 = 0;
    zT_2C0927B0_StateMap* zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned int zT_35 = 0;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_8143F551_AstKind zT_49;
    zT_7E2F335A_AnalyzerContext* zT_55;
    zT_2C0927B0_StateMap* zT_56;
    unsigned int zT_57;
    unsigned char zT_59 = 0;
    zT_2C0927B0_StateMap* zT_60;
    unsigned int zT_61;
    unsigned char zT_62;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    zT_22A7C88B_AstNode node;
    unsigned char prov;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = node.child_1;
    if ((unsigned char)(zT_13 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    zT_38 = node.kind;
    if ((unsigned char)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_17 = ctx;
    zT_18 = state;
    zT_19 = node.child_1;
    zT_21 = zF_5542CD3C_classifyProvenance(zT_17, zT_18, zT_19);
    prov = zT_21;
    zT_22 = state;
    zT_25 = ctx->store;
    zT_26 = node_idx;
    zT_28 = zF_8BA26B9E_astStoreNodePayload(zT_25, zT_26);
    zT_23 = zT_28;
    zT_24 = prov;
    zF_ACCFA860_stateMapSet(zT_22, zT_23, zT_24);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = state;
    zT_32 = ctx->store;
    zT_33 = node_idx;
    zT_35 = zF_8BA26B9E_astStoreNodePayload(zT_32, zT_33);
    zT_30 = zT_35;
    zF_ACCFA860_stateMapSet(zT_29, zT_30, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown)));
    goto z_bb_4;
    z_bb_6:
    zT_44 = ctx->store;
    zT_45 = node.child_0;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    lhs_node = zT_48;
    zT_49 = lhs_node.kind;
    if ((unsigned char)(zT_49 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    return;
    z_bb_8:
    zT_55 = ctx;
    zT_56 = state;
    zT_57 = node.child_1;
    zT_59 = zF_5542CD3C_classifyProvenance(zT_55, zT_56, zT_57);
    prov = zT_59;
    zT_60 = state;
    zT_63 = ctx->store;
    zT_64 = node.child_0;
    zT_67 = zF_8BA26B9E_astStoreNodePayload(zT_63, zT_64);
    zT_61 = zT_67;
    zT_62 = prov;
    zF_ACCFA860_stateMapSet(zT_60, zT_61, zT_62);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_7;
}

/* onDoubleFreeStmt */
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    zT_7E2F335A_AnalyzerContext* zT_13;
    zT_2C0927B0_StateMap* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    unsigned int zT_20 = 0;
    zT_8143F551_AstKind zT_22;
    zT_7E2F335A_AnalyzerContext* zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    zT_8143F551_AstKind zT_30;
    zT_7E2F335A_AnalyzerContext* zT_35;
    zT_2C0927B0_StateMap* zT_36;
    unsigned int zT_37;
    zT_7E2F335A_AnalyzerContext* zT_38;
    zT_2C0927B0_StateMap* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = ctx;
    zT_14 = state;
    zT_17 = ctx->store;
    zT_18 = node_idx;
    zT_20 = zF_8BA26B9E_astStoreNodePayload(zT_17, zT_18);
    zT_15 = zT_20;
    zT_16 = node.child_1;
    zF_4330B9B8_handleAllocCall(zT_13, zT_14, zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_22 = node.kind;
    if ((unsigned char)(zT_22 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_27 = ctx;
    zT_28 = state;
    zT_29 = node_idx;
    zF_67B7BB29_handleAllocAssign(zT_27, zT_28, zT_29);
    goto z_bb_4;
    z_bb_4:
    zT_30 = node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = ctx;
    zT_36 = state;
    zT_37 = node_idx;
    zF_70D0501D_handleFreeCall(zT_35, zT_36, zT_37);
    zT_38 = ctx;
    zT_39 = state;
    zT_40 = node_idx;
    zF_9AFCA595_handleOwnershipPass(zT_38, zT_39, zT_40);
    goto z_bb_6;
    z_bb_6:
    return;
}

/* runSignatureAnalyzer */
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx) {
    zT_7E2F335A_AnalyzerContext* zT_2;
    unsigned int zT_3;
    zT_2 = ctx;
    zT_3 = fn_decl_idx;
    zF_2A06A757_analyzeSignature(zT_2, zT_3);
    return;
}

/* detectorVisit */
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_3;
    zT_2C0927B0_StateMap* zT_4;
    unsigned int zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_6;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_9;
    zT_3 = ctx;
    zT_4 = state;
    zT_5 = node_idx;
    zT_6 = ctx->on_stmt_cb;
    zT_9 = zF_59D99CE2_detectorVisit;
    zT_7 = zT_9;
    zF_468ECC89_visitStatement(zT_3, zT_4, zT_5, zT_6, zT_7);
    return;
}

/* runNullAnalyzer */
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->null_analysis_mode = (unsigned char)(1);
    zT_7 = zF_43C99FB3_onNullStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = &state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->null_analysis_mode = (unsigned char)(0);
    return;
}

/* runLifetimeAnalyzer */
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_4;
    zT_2C0927B0_StateMap zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    zT_D08E0C6B_anon_230871 zT_20;
    zT_243D6A41_FnProto* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned int zT_26;
    zT_243D6A41_FnProto zT_27;
    unsigned int zT_29;
    unsigned short zT_33;
    zT_79FAE712_u64 zT_35;
    zT_6B0A7D14_AstStore* zT_37;
    zT_79FAE712_u64 zT_38;
    unsigned int zT_40 = 0;
    int zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_55 = 0;
    zT_22A7C88B_AstNode zT_56 = {0};
    zT_8143F551_AstKind zT_57;
    zT_2C0927B0_StateMap* zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_69;
    zT_79FAE712_u64 zT_70;
    unsigned int zT_74 = 0;
    unsigned int zT_75 = 0;
    int zT_78;
    unsigned int zT_80;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_82;
    zT_7E2F335A_AnalyzerContext* zT_83;
    zT_2C0927B0_StateMap* zT_84;
    unsigned int zT_85;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_86;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_88;
    zT_2C0927B0_StateMap state;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 pp;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    zT_4 = ctx->alloc;
    zT_6 = zF_14665872_stateMapInit(zT_4);
    state = zT_6;
    zT_8 = ctx->store;
    zT_9 = fn_decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    zT_12 = ctx->store;
    zT_13 = fn_decl_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = ctx->store;
    zT_20 = zT_19->fn_protos;
    zT_21 = zT_20.items;
    zT_22 = ctx->store;
    zT_23 = fn_decl_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    proto = zT_27;
    zT_29 = proto.params_start;
    zT_33 = proto.params_count;
    zT_35 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_29) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_33);
    pp = zT_35;
    zT_37 = ctx->store;
    zT_38 = pp;
    zT_40 = zF_03CE8CAB_astStoreGetExtraChi(zT_37, zT_38);
    params_n = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    pi = zT_43;
    goto z_bb_3;
    z_bb_2:
    ctx->lifetime_analysis_mode = (unsigned char)(1);
    zT_82 = zF_3D2EF2C5_onLifetimeStmt;
    ctx->on_stmt_cb = zT_82;
    zT_83 = ctx;
    zT_84 = &state;
    zT_85 = fn_body_idx;
    zT_88 = zF_59D99CE2_detectorVisit;
    zT_86 = zT_88;
    zF_0F6AFE81_walkBlock(zT_83, zT_84, zT_85, zT_86);
    ctx->lifetime_analysis_mode = (unsigned char)(0);
    return;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_47 = ctx->store;
    zT_50 = ctx->store;
    zT_51 = pp;
    zT_55 = zF_E5B10421_astStoreGetExtraChi(zT_50, zT_51, (unsigned int)((unsigned int)pi));
    zT_48 = zT_55;
    zT_56 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    pnode = zT_56;
    zT_57 = pnode.kind;
    if ((unsigned char)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_78 = 1;
    zT_80 = pi + (unsigned int)((unsigned int)zT_78);
    pi = zT_80;
    goto z_bb_3;
    z_bb_7:
    zT_62 = &state;
    zT_66 = ctx->store;
    zT_69 = ctx->store;
    zT_70 = pp;
    zT_74 = zF_E5B10421_astStoreGetExtraChi(zT_69, zT_70, (unsigned int)((unsigned int)pi));
    zT_67 = zT_74;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_66, zT_67);
    zT_63 = zT_75;
    zF_ACCFA860_stateMapSet(zT_62, zT_63, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* runDoubleFreeAnalyzer */
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5 = {0};
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->doublefree_analysis_mode = (unsigned char)(1);
    zT_7 = zF_270EF995_onDoubleFreeStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = &state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->doublefree_analysis_mode = (unsigned char)(0);
    return;
}

/* runAllAnalyzers */
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext* ctx, unsigned int module_root_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_28 = 0;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_33 = {0};
    zT_8143F551_AstKind zT_34;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    zT_D08E0C6B_anon_230871 zT_45;
    zT_243D6A41_FnProto* zT_46;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    zT_243D6A41_FnProto zT_52;
    unsigned int zT_53;
    zT_7E2F335A_AnalyzerContext* zT_54;
    unsigned int zT_55;
    zT_3E40CD83_Sand* zT_56;
    unsigned char zT_58;
    zT_7E2F335A_AnalyzerContext* zT_61;
    unsigned int zT_62;
    zT_3E40CD83_Sand* zT_64;
    unsigned char zT_66;
    zT_7E2F335A_AnalyzerContext* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_3E40CD83_Sand* zT_73;
    unsigned char zT_75;
    zT_7E2F335A_AnalyzerContext* zT_78;
    unsigned int zT_79;
    zT_3E40CD83_Sand* zT_81;
    zT_3E40CD83_Sand* zT_83;
    unsigned int zT_84;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_F85C5DED_DiagnosticCollector* zT_91;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_106;
    unsigned int zT_107;
    int zT_111;
    unsigned int zT_113;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u bmsg;
    zT_3 = ctx->store;
    zT_4 = module_root_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    root = zT_6;
    zT_7 = root.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = ctx->store;
    zT_14 = module_root_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_13, zT_14);
    decls_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    di = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_23 = ctx->store;
    zT_24 = module_root_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_23, zT_24, (unsigned int)((unsigned int)di));
    decl_idx = zT_28;
    zT_30 = ctx->store;
    zT_31 = decl_idx;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    decl = zT_33;
    zT_34 = decl.kind;
    if ((unsigned char)(zT_34 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_111 = 1;
    zT_113 = di + (unsigned int)((unsigned int)zT_111);
    di = zT_113;
    goto z_bb_3;
    z_bb_7:
    goto z_bb_6;
    z_bb_8:
    zT_39 = decl.child_0;
    if ((unsigned char)(zT_39 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_42 = ctx->alloc;
    zF_CB5A85E9_sandResetPeak(zT_42);
    zT_44 = ctx->store;
    zT_45 = zT_44->fn_protos;
    zT_46 = zT_45.items;
    zT_47 = ctx->store;
    zT_48 = decl_idx;
    zT_50 = zF_8BA26B9E_astStoreNodePayload(zT_47, zT_48);
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_46[zT_51];
    zT_53 = zT_52.name_id;
    ctx->current_fn_name = zT_53;
    zT_54 = ctx;
    zT_55 = decl_idx;
    zF_DDE69BF2_runSignatureAnalyze(zT_54, zT_55);
    zT_56 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_56);
    zT_58 = ctx->skip_null_check;
    if ((unsigned char)(zT_58 == (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_61 = ctx;
    zT_62 = decl.child_0;
    zF_29CABD65_runNullAnalyzer(zT_61, zT_62);
    zT_64 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_64);
    goto z_bb_12;
    z_bb_12:
    zT_66 = ctx->skip_lifetime_check;
    if ((unsigned char)(zT_66 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_69 = ctx;
    zT_70 = decl_idx;
    zT_71 = decl.child_0;
    zF_9B11D60F_runLifetimeAnalyzer(zT_69, zT_70, zT_71);
    zT_73 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_73);
    goto z_bb_14;
    z_bb_14:
    zT_75 = ctx->skip_doublefree_check;
    if ((unsigned char)(zT_75 == (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_78 = ctx;
    zT_79 = decl.child_0;
    zF_D5F41043_runDoubleFreeAnalyz(zT_78, zT_79);
    zT_81 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_81);
    goto z_bb_16;
    z_bb_16:
    zT_83 = ctx->alloc;
    zT_84 = zT_83->peak;
    if ((unsigned char)(zT_84 > zG_73BDFDC5_PER_FUNC_BUDGET)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_88 = "per-function analyzer budget exceeded";
    zT_90 = 37;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    bmsg = zT_89;
    zT_91 = ctx->diag;
    zT_95 = decl.span_start;
    zT_106 = decl.span_start;
    zT_107 = decl.span_len;
    zT_97 = bmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_91, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7002_ANALYZER_BUDGET_EXCEEDED)), (unsigned int)(0), zT_95, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), zT_97);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_6;
}

/* __module_init */
void zF_780653D2___module_init_10(void) {
    zG_73BDFDC5_PER_FUNC_BUDGET = (unsigned int)(524288);
    return;
}

/* EOF */
