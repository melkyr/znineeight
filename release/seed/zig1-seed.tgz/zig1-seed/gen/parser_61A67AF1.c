#include "parser_61A67AF1.h"
#include <stdio.h>
/* parserInitCommon */
zT_B559F9DA_Parser zF_EDAEEEE9_parserInitCommon(zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc, unsigned int builtin_import_id) {
    zT_3A355BD2_Token zT_7;
    zT_EAC3E484_TokenKind zT_10;
    unsigned int zT_11;
    unsigned short zT_12;
    zT_85CBA4DB_TokenValue zT_13 = {0};
    zT_B559F9DA_Parser zT_15;
    int zT_16;
    int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned char* zT_21;
    unsigned char* zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    int zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_7334F4FE_Opt_225 zT_38 = {0};
    zT_6A32A83C_Opt_238 zT_39 = {0};
    unsigned int zT_40;
    unsigned int zT_41;
    zT_3A355BD2_Token zero_tok;
    zT_10 = zT_EAC3E484_TokenKind_eof;
    zT_7.kind = zT_10;
    zT_11 = 0;
    zT_7.span_start = zT_11;
    zT_12 = 0;
    zT_7.span_len = zT_12;
    zT_7.value = zT_13;
    zero_tok = zT_7;
    zT_16 = 0;
    zT_15.use_lex = zT_16;
    zT_17 = 0;
    zT_15.lex = (zT_138FFB41_Lexer*)zT_17;
    zT_18 = 0;
    zT_15.tokens_ptr = (zT_3A355BD2_Token*)zT_18;
    zT_19 = 0;
    zT_15.tokens_len = zT_19;
    zT_21 = source.ptr;
    zT_22 = (unsigned char*)zT_21;
    zT_15.source_ptr = zT_22;
    zT_24 = source.len;
    zT_15.source_len = zT_24;
    zT_25 = 0;
    zT_15.pos = zT_25;
    zT_26 = 0;
    zT_15.la_len = zT_26;
    zT_27 = 0;
    zT_15.at_eof = zT_27;
    zT_15.eof_tok = zero_tok;
    zT_15.store = store;
    zT_15.interner = interner;
    zT_15.diag = diag;
    zT_15.allocator = alloc;
    zT_28 = 0;
    zT_15.child_buf_items = (unsigned int*)zT_28;
    zT_29 = 0;
    zT_15.child_buf_len = zT_29;
    zT_30 = 0;
    zT_15.child_buf_capacity = zT_30;
    zT_31 = 0;
    zT_15.last_end = zT_31;
    zT_15.last_tok = zero_tok;
    zT_32 = 0;
    zT_15.last_tok_valid = zT_32;
    zT_33 = 0;
    zT_15.decl_buf_items = (unsigned int*)zT_33;
    zT_34 = 0;
    zT_15.decl_buf_len = zT_34;
    zT_35 = 0;
    zT_15.decl_buf_capacity = zT_35;
    zT_36 = 0;
    zT_15.catch_capture = zT_36;
    zT_37 = 0;
    zT_15.expr_depth = zT_37;
    zT_15.builtin_import_id = builtin_import_id;
    zT_38.has_value = 0;
    zT_15.module_reg = zT_38;
    zT_39.has_value = 0;
    zT_15.import_scratch = zT_39;
    zT_40 = 0;
    zT_15.current_module_id = zT_40;
    zT_41 = 0;
    zT_15.file_id = zT_41;
    return zT_15;
}

/* parserInit */
zT_B559F9DA_Parser zF_74A05BF0_parserInit(zT_F020719E_Slice_zT_3A355BD2_T tokens, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3A355BD2_Token* zT_8;
    zT_3A355BD2_Token* zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    zT_D3EB6303_StringInterner* zT_21;
    zT_F85C5DED_DiagnosticCollector* zT_22;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    zT_B559F9DA_Parser zT_25 = {0};
    unsigned int zT_28;
    zT_3A355BD2_Token* t_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_8 = tokens.ptr;
    zT_9 = (zT_3A355BD2_Token*)zT_8;
    t_ptr = zT_9;
    zT_11 = "@import";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    import_s = zT_12;
    zT_15 = interner;
    zT_16 = import_s;
    zT_17 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    import_id = zT_17;
    zT_19 = source;
    zT_20 = store;
    zT_21 = interner;
    zT_22 = diag;
    zT_23 = alloc;
    zT_24 = import_id;
    zT_25 = zF_EDAEEEE9_parserInitCommon(zT_19, zT_20, zT_21, zT_22, zT_23, zT_24);
    p = zT_25;
    p.use_lex = (int)(0);
    p.tokens_ptr = t_ptr;
    zT_28 = tokens.len;
    p.tokens_len = zT_28;
    return p;
}

/* parserInitStreaming */
zT_B559F9DA_Parser zF_9E9ED878_parserInitStreaming(zT_138FFB41_Lexer* lex, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_D3EB6303_StringInterner* zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser zT_21 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_7 = "@import";
    zT_9 = 7;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    import_s = zT_8;
    zT_11 = interner;
    zT_12 = import_s;
    zT_13 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    import_id = zT_13;
    zT_15 = source;
    zT_16 = store;
    zT_17 = interner;
    zT_18 = diag;
    zT_19 = alloc;
    zT_20 = import_id;
    zT_21 = zF_EDAEEEE9_parserInitCommon(zT_15, zT_16, zT_17, zT_18, zT_19, zT_20);
    p = zT_21;
    p.use_lex = (int)(1);
    p.lex = lex;
    return p;
}

/* parserSetModuleContext */
void zF_15960D31_parserSetModuleCont(zT_B559F9DA_Parser* self, zT_072B53A6_ModuleRegistry* reg, unsigned int mod_id) {
    zT_7334F4FE_Opt_225 zT_3;
    zT_E41AEC18_ModuleEntryArrayLis zT_4;
    zT_6E8D187B_ModuleEntry* zT_5;
    zT_6E8D187B_ModuleEntry zT_6;
    unsigned int zT_7;
    zT_3.has_value = 1;
    zT_3.value = reg;
    self->module_reg = zT_3;
    self->current_module_id = mod_id;
    zT_4 = reg->modules;
    zT_5 = zT_4.items;
    zT_6 = zT_5[mod_id];
    zT_7 = zT_6.source_file_id;
    self->file_id = zT_7;
    return;
}

/* parserSetImportScratch */
void zF_C8F08D73_parserSetImportScra(zT_B559F9DA_Parser* self, zT_3E40CD83_Sand* scratch) {
    zT_6A32A83C_Opt_238 zT_2;
    zT_2.has_value = 1;
    zT_2.value = scratch;
    self->import_scratch = zT_2;
    return;
}

/* parserTokenText */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08D61E58_parserTokenText(zT_B559F9DA_Parser* self, zT_2B3424E9_ParseToken tok) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned short zT_6;
    unsigned int zT_8;
    unsigned char* zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int start;
    unsigned int end;
    zT_3 = tok.span_start;
    zT_4 = (unsigned int)zT_3;
    start = zT_4;
    zT_6 = tok.span_len;
    zT_8 = start + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->source_ptr;
    zT_10 = zT_9 + start;
    zT_11 = end - start;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    return zT_12;
}

/* parserPullOne */
void zF_7C3FD09B_parserPullOne(zT_B559F9DA_Parser* self) {
    int zT_1;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_4;
    zT_138FFB41_Lexer* zT_5;
    zT_3A355BD2_Token zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_3A355BD2_Token* zT_11;
    unsigned int zT_12;
    zT_3A355BD2_Token zT_13;
    unsigned int zT_14;
    int zT_15;
    zT_3A355BD2_Token* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    zT_3A355BD2_Token zT_22;
    zT_EAC3E484_TokenKind zT_23;
    zT_3A355BD2_Token* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_3A355BD2_Token tok;
    zT_1 = self->at_eof;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    tok = zT_3;
    zT_4 = self->use_lex;
    if (zT_4) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_5 = self->lex;
    zT_7 = zF_B976BEC9_lexerNextToken(zT_5);
    tok = zT_7;
    goto z_bb_4;
    z_bb_4:
    zT_23 = tok.kind;
    if ((int)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_9; else goto z_bb_10;
    z_bb_5:
    zT_8 = self->pos;
    zT_9 = self->tokens_len;
    if ((int)(zT_8 < zT_9)) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_11 = self->tokens_ptr;
    zT_12 = self->pos;
    zT_13 = zT_11[zT_12];
    tok = zT_13;
    zT_14 = self->pos;
    zT_15 = 1;
    self->pos = (unsigned int)(zT_14 + (unsigned int)((unsigned int)zT_15));
    goto z_bb_7;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = self->tokens_ptr;
    zT_19 = self->tokens_len;
    zT_20 = 1;
    zT_21 = zT_19 - zT_20;
    zT_22 = zT_18[zT_21];
    tok = zT_22;
    goto z_bb_7;
    z_bb_9:
    self->at_eof = (int)(1);
    self->eof_tok = tok;
    goto z_bb_10;
    z_bb_10:
    zT_29 = self->la;
    zT_30 = self->la_len;
    zT_29[zT_30] = tok;
    zT_31 = self->la_len;
    zT_32 = 1;
    self->la_len = (unsigned int)(zT_31 + (unsigned int)((unsigned int)zT_32));
    return;
}

/* parserConsumeCurrent */
void zF_2DCC9581_parserConsumeCurren(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    int zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3A355BD2_Token* zT_16;
    zT_3A355BD2_Token zT_17;
    zT_3A355BD2_Token* zT_18;
    int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    zT_B559F9DA_Parser* zT_27;
    unsigned int i;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((int)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    self->last_tok = zT_9;
    self->last_tok_valid = (int)(1);
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    i = zT_13;
    goto z_bb_5;
    z_bb_3:
    zT_5 = self->eof_tok;
    self->last_tok = zT_5;
    self->last_tok_valid = (int)(1);
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_14 = self->la_len;
    if ((int)(i < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_16 = self->la;
    zT_17 = zT_16[i];
    zT_18 = self->la;
    zT_19 = 1;
    zT_20 = i - zT_19;
    zT_18[zT_20] = zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_23 = self->la_len;
    zT_24 = 1;
    self->la_len = (unsigned int)(zT_23 - (unsigned int)((unsigned int)zT_24));
    zT_27 = self;
    zF_7C3FD09B_parserPullOne(zT_27);
    return;
    z_bb_8:
    zT_21 = 1;
    zT_22 = i + zT_21;
    i = zT_22;
    goto z_bb_5;
}

/* parserPeek */
zT_3A355BD2_Token zF_068A2DE5_parserPeek(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    int zT_4;
    zT_3A355BD2_Token zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((int)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    return zT_9;
    z_bb_3:
    zT_5 = self->eof_tok;
    return zT_5;
    z_bb_4:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_2;
}

/* parserPeekN */
zT_3A355BD2_Token zF_F685E431_parserPeekN(zT_B559F9DA_Parser* self, unsigned int n) {
    unsigned int zT_2;
    int zT_5;
    zT_B559F9DA_Parser* zT_6;
    unsigned int zT_7;
    zT_3A355BD2_Token* zT_10;
    zT_3A355BD2_Token zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_3A355BD2_Token* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_3A355BD2_Token zT_19;
    zT_3A355BD2_Token zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self->la_len;
    if ((int)(zT_2 <= (unsigned int)((unsigned int)n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self->at_eof;
    if (zT_5) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_7 = self->la_len;
    if ((int)(zT_7 > (unsigned int)((unsigned int)n))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_4;
    z_bb_7:
    zT_10 = self->la;
    zT_11 = zT_10[n];
    return zT_11;
    z_bb_8:
    zT_12 = self->la_len;
    zT_13 = 0;
    if ((int)(zT_12 > (unsigned int)zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = self->la;
    zT_16 = self->la_len;
    zT_17 = 1;
    zT_18 = zT_16 - zT_17;
    zT_19 = zT_15[zT_18];
    return zT_19;
    z_bb_10:
    zT_20 = self->eof_tok;
    return zT_20;
}

/* parserAdvance */
zT_3A355BD2_Token zF_C241B2C4_parserAdvance(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_4;
    unsigned short zT_5;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.span_start;
    zT_5 = tok.span_len;
    self->last_end = (unsigned int)(zT_4 + (unsigned int)((unsigned int)zT_5));
    zT_8 = self;
    zF_2DCC9581_parserConsumeCurren(zT_8);
    return tok;
}

/* tokenKindLabel */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_77B50062_tokenKindLabel(zT_EAC3E484_TokenKind kind) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = "';'";
    zT_8 = 3;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s = zT_7;
    return s;
    z_bb_2:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = "'('";
    zT_16 = 3;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s = zT_15;
    return s;
    z_bb_4:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = "')'";
    zT_24 = 3;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    s = zT_23;
    return s;
    z_bb_6:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = "'{'";
    zT_32 = 3;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    s = zT_31;
    return s;
    z_bb_8:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_38 = "'}'";
    zT_40 = 3;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    s = zT_39;
    return s;
    z_bb_10:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_46 = "'['";
    zT_48 = 3;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    s = zT_47;
    return s;
    z_bb_12:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_54 = "']'";
    zT_56 = 3;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s = zT_55;
    return s;
    z_bb_14:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_62 = "','";
    zT_64 = 3;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s = zT_63;
    return s;
    z_bb_16:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_70 = "'.'";
    zT_72 = 3;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s = zT_71;
    return s;
    z_bb_18:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_78 = "':'";
    zT_80 = 3;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s = zT_79;
    return s;
    z_bb_20:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = "'|'";
    zT_88 = 3;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s = zT_87;
    return s;
    z_bb_22:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_94 = "identifier";
    zT_96 = 10;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s = zT_95;
    return s;
    z_bb_24:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_102 = "string literal";
    zT_104 = 14;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s = zT_103;
    return s;
    z_bb_26:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_110 = "integer literal";
    zT_112 = 15;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s = zT_111;
    return s;
    z_bb_28:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_118 = "'fn'";
    zT_120 = 4;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    s = zT_119;
    return s;
    z_bb_30:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_126 = "'while'";
    zT_128 = 7;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    s = zT_127;
    return s;
    z_bb_32:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_134 = "'if'";
    zT_136 = 4;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    s = zT_135;
    return s;
    z_bb_34:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_142 = "'else'";
    zT_144 = 6;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    s = zT_143;
    return s;
    z_bb_36:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_150 = "'return'";
    zT_152 = 8;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    s = zT_151;
    return s;
    z_bb_38:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_158 = "'const'";
    zT_160 = 7;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    s = zT_159;
    return s;
    z_bb_40:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_166 = "'var'";
    zT_168 = 5;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    s = zT_167;
    return s;
    z_bb_42:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_174 = "'pub'";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    s = zT_175;
    return s;
    z_bb_44:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_182 = "'extern'";
    zT_184 = 8;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    s = zT_183;
    return s;
    z_bb_46:
    zT_186 = "token";
    zT_188 = 5;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    fallback = zT_187;
    return fallback;
}

/* parserExpect */
zT_CB78802F_EU_49 zF_5578C74F_parserExpect(zT_B559F9DA_Parser* self, zT_EAC3E484_TokenKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_EAC3E484_TokenKind zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13 = {0};
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_EAC3E484_TokenKind zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_4F2154A7_Arr_zT_8F083A69_Sli zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_30;
    zT_F85C5DED_DiagnosticCollector* zT_32;
    int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_DBF3575C_ParserError zT_41;
    zT_CB78802F_EU_49 zT_42;
    zT_B559F9DA_Parser* zT_43;
    zT_2B3424E9_ParseToken zT_44;
    zT_EAC3E484_TokenKind zT_45;
    unsigned int zT_46;
    unsigned short zT_47;
    zT_CB78802F_EU_49 zT_48;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_lab;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_lab;
    zT_4F2154A7_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    tok = zT_4;
    zT_5 = tok.kind;
    if ((int)(zT_5 != kind)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = "expected ";
    zT_10 = 9;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    exp_s = zT_9;
    zT_12 = kind;
    zT_13 = zF_77B50062_tokenKindLabel(zT_12);
    exp_lab = zT_13;
    zT_15 = " but found ";
    zT_17 = 11;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    fnd_s = zT_16;
    zT_19 = tok.kind;
    zT_21 = zF_77B50062_tokenKindLabel(zT_19);
    fnd_lab = zT_21;
    zT_24 = 0;
    zT_23[zT_24] = exp_s;
    zT_25 = 1;
    zT_23[zT_25] = exp_lab;
    zT_26 = 2;
    zT_23[zT_26] = fnd_s;
    zT_27 = 3;
    zT_23[zT_27] = fnd_lab;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        parts[_i] = zT_23[_i];
        _i++;
    }
}
    zT_32 = self->diag;
    zT_29 = zT_32->interner;
    zT_34 = 0;
    zT_35 = parts + zT_34;
    zT_30 = zT_35;
    zT_37 = zF_8C4BFF7C_diagnosticBuilderMa(zT_29, zT_30, (unsigned int)(4));
    msg = zT_37;
    zT_38 = self;
    zT_39 = tok;
    zT_40 = msg;
    zF_17DF2CA5_parserAddError(zT_38, zT_39, zT_40);
    zT_41 = 1;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_2:
    zT_43 = self;
    zF_2DCC9581_parserConsumeCurren(zT_43);
    zT_45 = tok.kind;
    zT_44.kind = zT_45;
    zT_46 = tok.span_start;
    zT_44.span_start = zT_46;
    zT_47 = tok.span_len;
    zT_44.span_len = zT_47;
    zT_48.data.payload = zT_44;
    zT_48.is_error = 0;
    return zT_48;
}

/* parserAddError */
void zF_17DF2CA5_parserAddError(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_3;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_3 = self->diag;
    zT_6 = self->file_id;
    zT_7 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_9 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_3, (unsigned char)(0), (unsigned short)(2000), zT_6, zT_7, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_9);
    return;
}

/* parserSynchronize */
void zF_4190C400_parserSynchronize(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    int zT_10;
    int zT_15;
    int zT_20;
    int zT_25;
    int zT_30;
    int zT_35;
    zT_B559F9DA_Parser* zT_40;
    zT_B559F9DA_Parser* zT_45;
    zT_EAC3E484_TokenKind k;
    goto z_bb_1;
    z_bb_1:
    if ((int)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    k = zT_5;
    if ((int)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_7;
    z_bb_6:
    zT_10 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_10) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_15 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn);
    goto z_bb_10;
    z_bb_9:
    zT_15 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_15) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_20 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const);
    goto z_bb_13;
    z_bb_12:
    zT_20 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_20) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_25 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var);
    goto z_bb_16;
    z_bb_15:
    zT_25 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_25) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_30 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub);
    goto z_bb_19;
    z_bb_18:
    zT_30 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_30) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_35 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test);
    goto z_bb_22;
    z_bb_21:
    zT_35 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_35) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_40 = self;
    zF_2DCC9581_parserConsumeCurren(zT_40);
    return;
    z_bb_24:
    if ((int)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return;
    z_bb_26:
    zT_45 = self;
    zF_2DCC9581_parserConsumeCurren(zT_45);
    goto z_bb_4;
}

/* parserParseExprPrec */
zT_3B6EA323_EU_01 zF_F07C1F04_parserParseExprPrec(zT_B559F9DA_Parser* self, zT_2B10107F_Prec min_prec) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_6;
    int zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_13;
    unsigned int zT_14;
    char* zT_15;
    unsigned int zT_16;
    char* zT_17;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_21;
    zT_3B6EA323_EU_01 zT_22 = {0};
    unsigned char zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_28;
    zT_B559F9DA_Parser* zT_29;
    unsigned int zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    unsigned char zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41 = {0};
    int zT_43;
    unsigned char zT_44;
    zT_F4EBEA72_OpInfo zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_ADDA7CFF_Opt_97 zT_49 = {0};
    unsigned char zT_50;
    int zT_52;
    unsigned char zT_53;
    int zT_54;
    zT_2B10107F_Prec zT_56;
    unsigned char zT_58 = 0;
    zT_2B10107F_Prec zT_59;
    unsigned char zT_60 = 0;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_2B10107F_Prec zT_65 = 0;
    int zT_66;
    zT_2B10107F_Prec zT_67;
    zT_2B10107F_Prec zT_69;
    unsigned char zT_71 = 0;
    int zT_72;
    zT_2B10107F_Prec zT_74 = 0;
    unsigned int zT_76 = 0;
    int zT_78;
    unsigned char zT_79;
    zT_EAC3E484_TokenKind zT_80;
    unsigned int zT_86;
    zT_B559F9DA_Parser* zT_87;
    zT_2B10107F_Prec zT_88;
    unsigned int* zT_89;
    zT_3B6EA323_EU_01 zT_91 = {0};
    unsigned char zT_92;
    unsigned int zT_93;
    int zT_94;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned short zT_100;
    unsigned int zT_102;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    int zT_116;
    int zT_119;
    unsigned int zT_121 = 0;
    int zT_122;
    unsigned char zT_123;
    zT_EAC3E484_TokenKind zT_124;
    zT_B559F9DA_Parser* zT_129;
    zT_2B10107F_Prec zT_130;
    zT_3B6EA323_EU_01 zT_131 = {0};
    unsigned char zT_132;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_137;
    zT_B559F9DA_Parser* zT_138;
    zT_2B10107F_Prec zT_139;
    zT_3B6EA323_EU_01 zT_140 = {0};
    unsigned char zT_141;
    unsigned int zT_142;
    int zT_143;
    unsigned int zT_146;
    int zT_147;
    zT_B559F9DA_Parser* zT_149;
    zT_3A355BD2_Token zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_3B6EA323_EU_01 zT_153 = {0};
    unsigned char zT_154;
    unsigned int zT_155;
    int zT_156;
    unsigned int zT_159;
    unsigned int zT_160;
    int zT_161;
    zT_3B6EA323_EU_01 zT_164;
    unsigned int zT_165;
    int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int lhs;
    zT_3A355BD2_Token tok;
    unsigned char has_info;
    zT_F4EBEA72_OpInfo info;
    zT_F4EBEA72_OpInfo val;
    zT_2B10107F_Prec next_min;
    unsigned int rhs;
    unsigned char catch_handled;
    unsigned int cap;
    unsigned int end;
    zT_2 = self->expr_depth;
    zT_3 = 1;
    self->expr_depth = (unsigned int)(zT_2 + (unsigned int)((unsigned int)zT_3));
    zT_6 = self->expr_depth;
    zT_7 = 12;
    if ((int)(zT_6 > (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = "max expression recursion depth exceeded";
    zT_12 = 39;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    msg = zT_11;
    zT_13 = "panic: ";
    zT_14 = 7;
    fwrite(zT_13, 1, zT_14, stderr);
    zT_15 = msg.ptr;
    zT_16 = msg.len;
    fwrite(zT_15, 1, zT_16, stderr);
    zT_17 = "\n";
    zT_18 = 1;
    fwrite(zT_17, 1, zT_18, stderr);
    pal_trap();
    z_bb_2:
    zT_21 = self;
    zT_22 = zF_565DCE21_parserParsePrimary(zT_21);
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = self->expr_depth;
    zT_25 = 1;
    self->expr_depth = (unsigned int)(zT_24 - (unsigned int)((unsigned int)zT_25));
    return zT_22;
    z_bb_4:
    zT_28 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    lhs = zT_28;
    zT_29 = self;
    zT_30 = lhs;
    zT_31 = zF_77AD89E7_parserParsePostfixC(zT_29, zT_30);
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_33 = self->expr_depth;
    zT_34 = 1;
    self->expr_depth = (unsigned int)(zT_33 - (unsigned int)((unsigned int)zT_34));
    return zT_31;
    z_bb_7:
    zT_37 = zT_31.data.payload;
    goto z_bb_8;
    z_bb_8:
    lhs = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((int)(1)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = zF_068A2DE5_parserPeek(zT_40);
    tok = zT_41;
    zT_43 = 0;
    zT_44 = (unsigned char)zT_43;
    has_info = zT_44;
    info = zT_46;
    zT_47 = tok.kind;
    zT_49 = zF_1E2936C3_getInfixInfo(zT_47);
    zT_50 = zT_49.has_value;
    if (zT_50) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_160 = self->expr_depth;
    zT_161 = 1;
    self->expr_depth = (unsigned int)(zT_160 - (unsigned int)((unsigned int)zT_161));
    zT_164.data.payload = lhs;
    zT_164.is_error = 0;
    return zT_164;
    zT_165 = self->expr_depth;
    zT_166 = 1;
    self->expr_depth = (unsigned int)(zT_165 - (unsigned int)((unsigned int)zT_166));
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    val = zT_49.value;
    info = val;
    zT_52 = 1;
    zT_53 = (unsigned char)zT_52;
    has_info = zT_53;
    goto z_bb_14;
    z_bb_14:
    zT_54 = 0;
    if ((int)(has_info == zT_54)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_56 = info.prec;
    zT_58 = zF_F312BDA3_precToInt(zT_56);
    zT_59 = min_prec;
    zT_60 = zF_F312BDA3_precToInt(zT_59);
    if ((int)(zT_58 < zT_60)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_11;
    z_bb_18:
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    next_min = zT_65;
    zT_66 = info.right_assoc;
    if (zT_66) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_67 = info.prec;
    next_min = zT_67;
    goto z_bb_20;
    z_bb_20:
    rhs = zT_76;
    zT_78 = 0;
    zT_79 = (unsigned char)zT_78;
    catch_handled = zT_79;
    zT_80 = tok.kind;
    if ((int)(zT_80 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_22; else goto z_bb_24;
    z_bb_21:
    zT_69 = info.prec;
    zT_71 = zF_F312BDA3_precToInt(zT_69);
    zT_72 = 1;
    zT_74 = zF_860100DC_precFromInt((unsigned char)(zT_71 + zT_72));
    next_min = zT_74;
    goto z_bb_20;
    z_bb_22:
    zT_86 = 0;
    cap = zT_86;
    zT_87 = self;
    zT_88 = next_min;
    zT_89 = &cap;
    zT_91 = zF_95DDA8C7_parserParseCatchRHS(zT_87, zT_88, zT_89);
    zT_92 = zT_91.is_error;
    if (zT_92) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_147 = 0;
    if ((int)(catch_handled == zT_147)) goto z_bb_37; else goto z_bb_38;
    z_bb_24:
    zT_124 = tok.kind;
    if ((int)(zT_124 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_28; else goto z_bb_30;
    z_bb_25:
    zT_93 = self->expr_depth;
    zT_94 = 1;
    self->expr_depth = (unsigned int)(zT_93 - (unsigned int)((unsigned int)zT_94));
    return zT_91;
    z_bb_26:
    zT_97 = zT_91.data.payload;
    goto z_bb_27;
    z_bb_27:
    rhs = zT_97;
    zT_99 = tok.span_start;
    zT_100 = tok.span_len;
    zT_102 = zT_99 + (unsigned int)((unsigned int)zT_100);
    end = zT_102;
    zT_103 = self->store;
    zT_116 = 0;
    zT_106 = tok.span_start;
    zT_107 = end;
    zT_108 = lhs;
    zT_109 = rhs;
    zT_110 = cap;
    zT_119 = 0;
    zT_121 = zF_6C9FF72F_astStoreAddNode(zT_103, (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr), (unsigned char)((unsigned char)zT_116), zT_106, zT_107, zT_108, zT_109, zT_110, (unsigned int)((unsigned int)zT_119));
    lhs = zT_121;
    zT_122 = 1;
    zT_123 = (unsigned char)zT_122;
    catch_handled = zT_123;
    goto z_bb_23;
    z_bb_28:
    zT_129 = self;
    zT_130 = next_min;
    zT_131 = zF_A059028C_parserParseOrelseRH(zT_129, zT_130);
    zT_132 = zT_131.is_error;
    if (zT_132) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_138 = self;
    zT_139 = next_min;
    zT_140 = zF_F07C1F04_parserParseExprPrec(zT_138, zT_139);
    zT_141 = zT_140.is_error;
    if (zT_141) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_133 = self->expr_depth;
    zT_134 = 1;
    self->expr_depth = (unsigned int)(zT_133 - (unsigned int)((unsigned int)zT_134));
    return zT_131;
    z_bb_32:
    zT_137 = zT_131.data.payload;
    goto z_bb_33;
    z_bb_33:
    rhs = zT_137;
    goto z_bb_29;
    z_bb_34:
    zT_142 = self->expr_depth;
    zT_143 = 1;
    self->expr_depth = (unsigned int)(zT_142 - (unsigned int)((unsigned int)zT_143));
    return zT_140;
    z_bb_35:
    zT_146 = zT_140.data.payload;
    goto z_bb_36;
    z_bb_36:
    rhs = zT_146;
    goto z_bb_29;
    z_bb_37:
    zT_149 = self;
    zT_150 = tok;
    zT_151 = lhs;
    zT_152 = rhs;
    zT_153 = zF_E702AE30_parserAddBinary(zT_149, zT_150, zT_151, zT_152);
    zT_154 = zT_153.is_error;
    if (zT_154) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_12;
    z_bb_39:
    zT_155 = self->expr_depth;
    zT_156 = 1;
    self->expr_depth = (unsigned int)(zT_155 - (unsigned int)((unsigned int)zT_156));
    return zT_153;
    z_bb_40:
    zT_159 = zT_153.data.payload;
    goto z_bb_41;
    z_bb_41:
    lhs = zT_159;
    goto z_bb_38;
}

/* parserAddBinary */
zT_3B6EA323_EU_01 zF_E702AE30_parserAddBinary(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned int lhs, unsigned int rhs) {
    zT_8143F551_AstKind zT_5 = 0;
    int zT_7;
    unsigned char zT_8;
    zT_EAC3E484_TokenKind zT_9;
    zT_8143F551_AstKind zT_12;
    int zT_13;
    unsigned char zT_14;
    zT_8143F551_AstKind zT_17;
    int zT_18;
    unsigned char zT_19;
    zT_8143F551_AstKind zT_22;
    int zT_23;
    unsigned char zT_24;
    zT_8143F551_AstKind zT_27;
    int zT_28;
    unsigned char zT_29;
    zT_8143F551_AstKind zT_32;
    int zT_33;
    unsigned char zT_34;
    zT_8143F551_AstKind zT_37;
    int zT_38;
    unsigned char zT_39;
    zT_8143F551_AstKind zT_42;
    int zT_43;
    unsigned char zT_44;
    zT_8143F551_AstKind zT_47;
    int zT_48;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_52;
    int zT_53;
    unsigned char zT_54;
    zT_8143F551_AstKind zT_57;
    int zT_58;
    unsigned char zT_59;
    zT_8143F551_AstKind zT_62;
    int zT_63;
    unsigned char zT_64;
    zT_8143F551_AstKind zT_67;
    int zT_68;
    unsigned char zT_69;
    zT_8143F551_AstKind zT_72;
    int zT_73;
    unsigned char zT_74;
    zT_8143F551_AstKind zT_77;
    int zT_78;
    unsigned char zT_79;
    zT_8143F551_AstKind zT_82;
    int zT_83;
    unsigned char zT_84;
    zT_8143F551_AstKind zT_87;
    int zT_88;
    unsigned char zT_89;
    zT_8143F551_AstKind zT_92;
    int zT_93;
    unsigned char zT_94;
    zT_8143F551_AstKind zT_97;
    int zT_98;
    unsigned char zT_99;
    zT_8143F551_AstKind zT_102;
    int zT_103;
    unsigned char zT_104;
    zT_8143F551_AstKind zT_107;
    int zT_108;
    unsigned char zT_109;
    zT_8143F551_AstKind zT_112;
    int zT_113;
    unsigned char zT_114;
    zT_8143F551_AstKind zT_117;
    int zT_118;
    unsigned char zT_119;
    zT_8143F551_AstKind zT_122;
    int zT_123;
    unsigned char zT_124;
    zT_8143F551_AstKind zT_127;
    int zT_128;
    unsigned char zT_129;
    zT_8143F551_AstKind zT_132;
    int zT_133;
    unsigned char zT_134;
    zT_8143F551_AstKind zT_137;
    int zT_138;
    unsigned char zT_139;
    zT_8143F551_AstKind zT_142;
    int zT_143;
    unsigned char zT_144;
    zT_8143F551_AstKind zT_147;
    int zT_148;
    unsigned char zT_149;
    zT_8143F551_AstKind zT_152;
    int zT_153;
    unsigned char zT_154;
    zT_8143F551_AstKind zT_157;
    int zT_158;
    unsigned char zT_159;
    zT_8143F551_AstKind zT_162;
    int zT_163;
    unsigned char zT_164;
    zT_8143F551_AstKind zT_167;
    int zT_168;
    unsigned char zT_169;
    zT_8143F551_AstKind zT_172;
    int zT_173;
    unsigned char zT_174;
    zT_8143F551_AstKind zT_177;
    int zT_178;
    unsigned char zT_179;
    zT_8143F551_AstKind zT_182;
    int zT_183;
    unsigned char zT_184;
    zT_8143F551_AstKind zT_187;
    int zT_188;
    unsigned char zT_189;
    zT_8143F551_AstKind zT_192;
    int zT_193;
    unsigned char zT_194;
    zT_8143F551_AstKind zT_197;
    int zT_198;
    unsigned char zT_199;
    zT_8143F551_AstKind zT_202;
    int zT_203;
    unsigned char zT_204;
    zT_8143F551_AstKind zT_207;
    int zT_208;
    unsigned char zT_209;
    zT_8143F551_AstKind zT_212;
    int zT_213;
    unsigned char zT_214;
    zT_8143F551_AstKind zT_217;
    int zT_218;
    unsigned char zT_219;
    zT_8143F551_AstKind zT_222;
    int zT_223;
    unsigned char zT_224;
    zT_8143F551_AstKind zT_227;
    int zT_228;
    unsigned char zT_229;
    zT_8143F551_AstKind zT_232;
    int zT_233;
    unsigned char zT_234;
    int zT_235;
    unsigned char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_B559F9DA_Parser* zT_241;
    zT_3A355BD2_Token zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    zT_DBF3575C_ParserError zT_244;
    zT_3B6EA323_EU_01 zT_245;
    unsigned int zT_247;
    unsigned short zT_248;
    unsigned int zT_250;
    zT_6B0A7D14_AstStore* zT_255;
    zT_8143F551_AstKind zT_256;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    int zT_265;
    int zT_269;
    unsigned int zT_271 = 0;
    zT_3B6EA323_EU_01 zT_272;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_EAC3E484_TokenKind zT_283;
    int zT_287;
    unsigned char* zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291 = 0;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    unsigned char* zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char* zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    int zT_316;
    unsigned char* zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320 = 0;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned char* zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned char* zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    unsigned int zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    zT_6B0A7D14_AstStore* zT_337;
    zT_8143F551_AstKind zT_338;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    int zT_347;
    int zT_350;
    int zT_352;
    unsigned int zT_354 = 0;
    zT_3B6EA323_EU_01 zT_355;
    zT_8143F551_AstKind kind;
    unsigned char found;
    zT_8F083A69_Slice_zT_0B42B2F8_u add_msg;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u bok;
    zT_5A26C2ED_Arr_unsigned_char_1 bokb;
    unsigned int bokl;
    unsigned int boks;
    zT_8F083A69_Slice_zT_0B42B2F8_u bokk;
    zT_5A26C2ED_Arr_unsigned_char_1 bokkb;
    unsigned int bokkl;
    unsigned int bokks;
    zT_8F083A69_Slice_zT_0B42B2F8_u boknl;
    kind = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    found = zT_8;
    zT_9 = tok.kind;
switch (zT_9) {
case 20: goto z_bb_1;
case 21: goto z_bb_2;
case 22: goto z_bb_3;
case 23: goto z_bb_4;
case 24: goto z_bb_5;
case 25: goto z_bb_6;
case 26: goto z_bb_7;
case 27: goto z_bb_8;
case 29: goto z_bb_9;
case 30: goto z_bb_10;
case 92: goto z_bb_11;
case 93: goto z_bb_12;
case 31: goto z_bb_13;
case 32: goto z_bb_14;
case 33: goto z_bb_15;
case 34: goto z_bb_16;
case 35: goto z_bb_17;
case 36: goto z_bb_18;
case 37: goto z_bb_19;
case 38: goto z_bb_20;
case 39: goto z_bb_21;
case 40: goto z_bb_22;
case 48: goto z_bb_23;
case 49: goto z_bb_24;
case 50: goto z_bb_25;
case 51: goto z_bb_26;
case 52: goto z_bb_27;
case 53: goto z_bb_28;
case 54: goto z_bb_29;
case 55: goto z_bb_30;
case 56: goto z_bb_31;
case 57: goto z_bb_32;
case 58: goto z_bb_33;
case 59: goto z_bb_34;
case 60: goto z_bb_35;
case 61: goto z_bb_36;
case 41: goto z_bb_37;
case 42: goto z_bb_38;
case 46: goto z_bb_39;
case 47: goto z_bb_40;
case 43: goto z_bb_41;
case 44: goto z_bb_42;
case 45: goto z_bb_43;
case 89: goto z_bb_44;
case 90: goto z_bb_45;
default: goto z_bb_46;
}
    z_bb_1:
    zT_12 = zT_8143F551_AstKind_add;
    kind = zT_12;
    zT_13 = 1;
    zT_14 = (unsigned char)zT_13;
    found = zT_14;
    goto z_bb_48;
    z_bb_2:
    zT_17 = zT_8143F551_AstKind_sub;
    kind = zT_17;
    zT_18 = 1;
    zT_19 = (unsigned char)zT_18;
    found = zT_19;
    goto z_bb_48;
    z_bb_3:
    zT_22 = zT_8143F551_AstKind_mul;
    kind = zT_22;
    zT_23 = 1;
    zT_24 = (unsigned char)zT_23;
    found = zT_24;
    goto z_bb_48;
    z_bb_4:
    zT_27 = zT_8143F551_AstKind_div;
    kind = zT_27;
    zT_28 = 1;
    zT_29 = (unsigned char)zT_28;
    found = zT_29;
    goto z_bb_48;
    z_bb_5:
    zT_32 = zT_8143F551_AstKind_mod_op;
    kind = zT_32;
    zT_33 = 1;
    zT_34 = (unsigned char)zT_33;
    found = zT_34;
    goto z_bb_48;
    z_bb_6:
    zT_37 = zT_8143F551_AstKind_bit_and;
    kind = zT_37;
    zT_38 = 1;
    zT_39 = (unsigned char)zT_38;
    found = zT_39;
    goto z_bb_48;
    z_bb_7:
    zT_42 = zT_8143F551_AstKind_bit_or;
    kind = zT_42;
    zT_43 = 1;
    zT_44 = (unsigned char)zT_43;
    found = zT_44;
    goto z_bb_48;
    z_bb_8:
    zT_47 = zT_8143F551_AstKind_bit_xor;
    kind = zT_47;
    zT_48 = 1;
    zT_49 = (unsigned char)zT_48;
    found = zT_49;
    goto z_bb_48;
    z_bb_9:
    zT_52 = zT_8143F551_AstKind_shl;
    kind = zT_52;
    zT_53 = 1;
    zT_54 = (unsigned char)zT_53;
    found = zT_54;
    goto z_bb_48;
    z_bb_10:
    zT_57 = zT_8143F551_AstKind_shr;
    kind = zT_57;
    zT_58 = 1;
    zT_59 = (unsigned char)zT_58;
    found = zT_59;
    goto z_bb_48;
    z_bb_11:
    zT_62 = zT_8143F551_AstKind_bool_and;
    kind = zT_62;
    zT_63 = 1;
    zT_64 = (unsigned char)zT_63;
    found = zT_64;
    goto z_bb_48;
    z_bb_12:
    zT_67 = zT_8143F551_AstKind_bool_or;
    kind = zT_67;
    zT_68 = 1;
    zT_69 = (unsigned char)zT_68;
    found = zT_69;
    goto z_bb_48;
    z_bb_13:
    zT_72 = zT_8143F551_AstKind_cmp_eq;
    kind = zT_72;
    zT_73 = 1;
    zT_74 = (unsigned char)zT_73;
    found = zT_74;
    goto z_bb_48;
    z_bb_14:
    zT_77 = zT_8143F551_AstKind_cmp_ne;
    kind = zT_77;
    zT_78 = 1;
    zT_79 = (unsigned char)zT_78;
    found = zT_79;
    goto z_bb_48;
    z_bb_15:
    zT_82 = zT_8143F551_AstKind_cmp_lt;
    kind = zT_82;
    zT_83 = 1;
    zT_84 = (unsigned char)zT_83;
    found = zT_84;
    goto z_bb_48;
    z_bb_16:
    zT_87 = zT_8143F551_AstKind_cmp_le;
    kind = zT_87;
    zT_88 = 1;
    zT_89 = (unsigned char)zT_88;
    found = zT_89;
    goto z_bb_48;
    z_bb_17:
    zT_92 = zT_8143F551_AstKind_cmp_gt;
    kind = zT_92;
    zT_93 = 1;
    zT_94 = (unsigned char)zT_93;
    found = zT_94;
    goto z_bb_48;
    z_bb_18:
    zT_97 = zT_8143F551_AstKind_cmp_ge;
    kind = zT_97;
    zT_98 = 1;
    zT_99 = (unsigned char)zT_98;
    found = zT_99;
    goto z_bb_48;
    z_bb_19:
    zT_102 = zT_8143F551_AstKind_plain_assign;
    kind = zT_102;
    zT_103 = 1;
    zT_104 = (unsigned char)zT_103;
    found = zT_104;
    goto z_bb_48;
    z_bb_20:
    zT_107 = zT_8143F551_AstKind_add_assign;
    kind = zT_107;
    zT_108 = 1;
    zT_109 = (unsigned char)zT_108;
    found = zT_109;
    goto z_bb_48;
    z_bb_21:
    zT_112 = zT_8143F551_AstKind_sub_assign;
    kind = zT_112;
    zT_113 = 1;
    zT_114 = (unsigned char)zT_113;
    found = zT_114;
    goto z_bb_48;
    z_bb_22:
    zT_117 = zT_8143F551_AstKind_mul_assign;
    kind = zT_117;
    zT_118 = 1;
    zT_119 = (unsigned char)zT_118;
    found = zT_119;
    goto z_bb_48;
    z_bb_23:
    zT_122 = zT_8143F551_AstKind_wrap_add;
    kind = zT_122;
    zT_123 = 1;
    zT_124 = (unsigned char)zT_123;
    found = zT_124;
    goto z_bb_48;
    z_bb_24:
    zT_127 = zT_8143F551_AstKind_wrap_sub;
    kind = zT_127;
    zT_128 = 1;
    zT_129 = (unsigned char)zT_128;
    found = zT_129;
    goto z_bb_48;
    z_bb_25:
    zT_132 = zT_8143F551_AstKind_wrap_mul;
    kind = zT_132;
    zT_133 = 1;
    zT_134 = (unsigned char)zT_133;
    found = zT_134;
    goto z_bb_48;
    z_bb_26:
    zT_137 = zT_8143F551_AstKind_wrap_add_assign;
    kind = zT_137;
    zT_138 = 1;
    zT_139 = (unsigned char)zT_138;
    found = zT_139;
    goto z_bb_48;
    z_bb_27:
    zT_142 = zT_8143F551_AstKind_wrap_sub_assign;
    kind = zT_142;
    zT_143 = 1;
    zT_144 = (unsigned char)zT_143;
    found = zT_144;
    goto z_bb_48;
    z_bb_28:
    zT_147 = zT_8143F551_AstKind_wrap_mul_assign;
    kind = zT_147;
    zT_148 = 1;
    zT_149 = (unsigned char)zT_148;
    found = zT_149;
    goto z_bb_48;
    z_bb_29:
    zT_152 = zT_8143F551_AstKind_sat_add;
    kind = zT_152;
    zT_153 = 1;
    zT_154 = (unsigned char)zT_153;
    found = zT_154;
    goto z_bb_48;
    z_bb_30:
    zT_157 = zT_8143F551_AstKind_sat_sub;
    kind = zT_157;
    zT_158 = 1;
    zT_159 = (unsigned char)zT_158;
    found = zT_159;
    goto z_bb_48;
    z_bb_31:
    zT_162 = zT_8143F551_AstKind_sat_mul;
    kind = zT_162;
    zT_163 = 1;
    zT_164 = (unsigned char)zT_163;
    found = zT_164;
    goto z_bb_48;
    z_bb_32:
    zT_167 = zT_8143F551_AstKind_sat_shl;
    kind = zT_167;
    zT_168 = 1;
    zT_169 = (unsigned char)zT_168;
    found = zT_169;
    goto z_bb_48;
    z_bb_33:
    zT_172 = zT_8143F551_AstKind_sat_add_assign;
    kind = zT_172;
    zT_173 = 1;
    zT_174 = (unsigned char)zT_173;
    found = zT_174;
    goto z_bb_48;
    z_bb_34:
    zT_177 = zT_8143F551_AstKind_sat_sub_assign;
    kind = zT_177;
    zT_178 = 1;
    zT_179 = (unsigned char)zT_178;
    found = zT_179;
    goto z_bb_48;
    z_bb_35:
    zT_182 = zT_8143F551_AstKind_sat_mul_assign;
    kind = zT_182;
    zT_183 = 1;
    zT_184 = (unsigned char)zT_183;
    found = zT_184;
    goto z_bb_48;
    z_bb_36:
    zT_187 = zT_8143F551_AstKind_sat_shl_assign;
    kind = zT_187;
    zT_188 = 1;
    zT_189 = (unsigned char)zT_188;
    found = zT_189;
    goto z_bb_48;
    z_bb_37:
    zT_192 = zT_8143F551_AstKind_div_assign;
    kind = zT_192;
    zT_193 = 1;
    zT_194 = (unsigned char)zT_193;
    found = zT_194;
    goto z_bb_48;
    z_bb_38:
    zT_197 = zT_8143F551_AstKind_mod_assign;
    kind = zT_197;
    zT_198 = 1;
    zT_199 = (unsigned char)zT_198;
    found = zT_199;
    goto z_bb_48;
    z_bb_39:
    zT_202 = zT_8143F551_AstKind_shl_assign;
    kind = zT_202;
    zT_203 = 1;
    zT_204 = (unsigned char)zT_203;
    found = zT_204;
    goto z_bb_48;
    z_bb_40:
    zT_207 = zT_8143F551_AstKind_shr_assign;
    kind = zT_207;
    zT_208 = 1;
    zT_209 = (unsigned char)zT_208;
    found = zT_209;
    goto z_bb_48;
    z_bb_41:
    zT_212 = zT_8143F551_AstKind_and_assign;
    kind = zT_212;
    zT_213 = 1;
    zT_214 = (unsigned char)zT_213;
    found = zT_214;
    goto z_bb_48;
    z_bb_42:
    zT_217 = zT_8143F551_AstKind_or_assign;
    kind = zT_217;
    zT_218 = 1;
    zT_219 = (unsigned char)zT_218;
    found = zT_219;
    goto z_bb_48;
    z_bb_43:
    zT_222 = zT_8143F551_AstKind_xor_assign;
    kind = zT_222;
    zT_223 = 1;
    zT_224 = (unsigned char)zT_223;
    found = zT_224;
    goto z_bb_48;
    z_bb_44:
    zT_227 = zT_8143F551_AstKind_catch_expr;
    kind = zT_227;
    zT_228 = 1;
    zT_229 = (unsigned char)zT_228;
    found = zT_229;
    goto z_bb_48;
    z_bb_45:
    zT_232 = zT_8143F551_AstKind_orelse_expr;
    kind = zT_232;
    zT_233 = 1;
    zT_234 = (unsigned char)zT_233;
    found = zT_234;
    goto z_bb_48;
    z_bb_46:
    goto z_bb_48;
    z_bb_48:
    zT_235 = 0;
    if ((int)(found == zT_235)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_238 = "invalid token in expression";
    zT_240 = 27;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    add_msg = zT_239;
    zT_241 = self;
    zT_242 = tok;
    zT_243 = add_msg;
    zF_17DF2CA5_parserAddError(zT_241, zT_242, zT_243);
    zT_244 = 1;
    zT_245.data.err = zT_244;
    zT_245.is_error = 1;
    return zT_245;
    z_bb_50:
    zT_247 = tok.span_start;
    zT_248 = tok.span_len;
    zT_250 = zT_247 + (unsigned int)((unsigned int)zT_248);
    end = zT_250;
    if ((int)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_255 = self->store;
    zT_256 = kind;
    zT_265 = 0;
    zT_258 = tok.span_start;
    zT_259 = end;
    zT_260 = lhs;
    zT_261 = rhs;
    zT_262 = self->catch_capture;
    zT_269 = 0;
    zT_271 = zF_6C9FF72F_astStoreAddNode(zT_255, zT_256, (unsigned char)((unsigned char)zT_265), zT_258, zT_259, zT_260, zT_261, zT_262, (unsigned int)((unsigned int)zT_269));
    zT_272.data.payload = zT_271;
    zT_272.is_error = 0;
    return zT_272;
    z_bb_52:
    zT_274 = "BOP:tk";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    bok = zT_275;
    zT_277 = bok;
    zF_48AC7B3A_markerWrite(zT_277);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_279[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        bokb[_i] = zT_279[_i];
        _i++;
    }
}
    zT_283 = tok.kind;
    zT_287 = 0;
    zT_288 = (unsigned char*)((unsigned char*)bokb) + zT_287;
    zT_289 = (unsigned int)(10) - zT_287;
    zT_290.ptr = zT_288;
    zT_290.len = zT_289;
    zT_282 = zT_290;
    zT_291 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_283), zT_282);
    bokl = zT_291;
    zT_295 = (unsigned int)(9) - (unsigned int)((unsigned int)bokl);
    boks = zT_295;
    zT_300 = (unsigned char*)((unsigned char*)bokb) + boks;
    zT_301 = (unsigned int)(9) - boks;
    zT_302.ptr = zT_300;
    zT_302.len = zT_301;
    zT_296 = zT_302;
    zF_48AC7B3A_markerWrite(zT_296);
    zT_304 = "ak";
    zT_306 = 2;
    zT_305.ptr = zT_304;
    zT_305.len = zT_306;
    bokk = zT_305;
    zT_307 = bokk;
    zF_48AC7B3A_markerWrite(zT_307);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_309[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        bokkb[_i] = zT_309[_i];
        _i++;
    }
}
    zT_316 = 0;
    zT_317 = (unsigned char*)((unsigned char*)bokkb) + zT_316;
    zT_318 = (unsigned int)(10) - zT_316;
    zT_319.ptr = zT_317;
    zT_319.len = zT_318;
    zT_312 = zT_319;
    zT_320 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_312);
    bokkl = zT_320;
    zT_324 = (unsigned int)(9) - (unsigned int)((unsigned int)bokkl);
    bokks = zT_324;
    zT_329 = (unsigned char*)((unsigned char*)bokkb) + bokks;
    zT_330 = (unsigned int)(9) - bokks;
    zT_331.ptr = zT_329;
    zT_331.len = zT_330;
    zT_325 = zT_331;
    zF_48AC7B3A_markerWrite(zT_325);
    zT_333 = " ";
    zT_335 = 1;
    zT_334.ptr = zT_333;
    zT_334.len = zT_335;
    boknl = zT_334;
    zT_336 = boknl;
    zF_48AC7B3A_markerWrite(zT_336);
    zT_337 = self->store;
    zT_338 = kind;
    zT_347 = 0;
    zT_340 = tok.span_start;
    zT_341 = end;
    zT_342 = lhs;
    zT_343 = rhs;
    zT_350 = 0;
    zT_352 = 0;
    zT_354 = zF_6C9FF72F_astStoreAddNode(zT_337, zT_338, (unsigned char)((unsigned char)zT_347), zT_340, zT_341, zT_342, zT_343, (unsigned int)((unsigned int)zT_350), (unsigned int)((unsigned int)zT_352));
    zT_355.data.payload = zT_354;
    zT_355.is_error = 0;
    return zT_355;
}

/* parserParsePrimary */
zT_3B6EA323_EU_01 zF_565DCE21_parserParsePrimary(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_9;
    zT_3B6EA323_EU_01 zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_B559F9DA_Parser* zT_16;
    zT_3B6EA323_EU_01 zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_23;
    zT_3B6EA323_EU_01 zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    zT_B559F9DA_Parser* zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    zT_EAC3E484_TokenKind zT_32;
    zT_B559F9DA_Parser* zT_37;
    zT_3B6EA323_EU_01 zT_38 = {0};
    zT_EAC3E484_TokenKind zT_39;
    zT_B559F9DA_Parser* zT_44;
    zT_3B6EA323_EU_01 zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    zT_B559F9DA_Parser* zT_51;
    zT_3B6EA323_EU_01 zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_62;
    zT_3B6EA323_EU_01 zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_73;
    zT_3B6EA323_EU_01 zT_78 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_B559F9DA_Parser* zT_84;
    zT_3B6EA323_EU_01 zT_85 = {0};
    zT_EAC3E484_TokenKind zT_86;
    zT_B559F9DA_Parser* zT_91;
    int zT_93;
    zT_3A355BD2_Token zT_95 = {0};
    zT_EAC3E484_TokenKind zT_96;
    int zT_101;
    zT_B559F9DA_Parser* zT_102;
    int zT_104;
    zT_3A355BD2_Token zT_106 = {0};
    zT_EAC3E484_TokenKind zT_107;
    zT_B559F9DA_Parser* zT_112;
    zT_3B6EA323_EU_01 zT_113 = {0};
    zT_B559F9DA_Parser* zT_114;
    int zT_116;
    zT_3A355BD2_Token zT_118 = {0};
    zT_EAC3E484_TokenKind zT_119;
    zT_B559F9DA_Parser* zT_125;
    zT_3B6EA323_EU_01 zT_126 = {0};
    unsigned char zT_127;
    unsigned int zT_128;
    zT_B559F9DA_Parser* zT_129;
    zT_3A355BD2_Token zT_130 = {0};
    zT_B559F9DA_Parser* zT_132;
    zT_3B6EA323_EU_01 zT_133 = {0};
    unsigned char zT_134;
    unsigned int zT_135;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_139;
    unsigned int zT_141;
    unsigned int zT_142;
    int zT_149;
    unsigned int zT_152;
    unsigned short zT_153;
    int zT_156;
    int zT_158;
    unsigned int zT_160 = 0;
    zT_3B6EA323_EU_01 zT_161;
    zT_B559F9DA_Parser* zT_162;
    zT_3B6EA323_EU_01 zT_163 = {0};
    zT_EAC3E484_TokenKind zT_164;
    zT_B559F9DA_Parser* zT_169;
    zT_3B6EA323_EU_01 zT_170 = {0};
    zT_EAC3E484_TokenKind zT_171;
    zT_B559F9DA_Parser* zT_176;
    zT_3B6EA323_EU_01 zT_177 = {0};
    zT_EAC3E484_TokenKind zT_178;
    zT_B559F9DA_Parser* zT_183;
    zT_3B6EA323_EU_01 zT_184 = {0};
    zT_EAC3E484_TokenKind zT_185;
    zT_B559F9DA_Parser* zT_190;
    zT_3B6EA323_EU_01 zT_191 = {0};
    zT_EAC3E484_TokenKind zT_192;
    zT_B559F9DA_Parser* zT_197;
    zT_3B6EA323_EU_01 zT_198 = {0};
    zT_EAC3E484_TokenKind zT_199;
    zT_B559F9DA_Parser* zT_204;
    zT_3B6EA323_EU_01 zT_205 = {0};
    zT_EAC3E484_TokenKind zT_206;
    zT_B559F9DA_Parser* zT_211;
    zT_3B6EA323_EU_01 zT_216 = {0};
    zT_EAC3E484_TokenKind zT_217;
    zT_B559F9DA_Parser* zT_222;
    zT_3B6EA323_EU_01 zT_227 = {0};
    zT_EAC3E484_TokenKind zT_228;
    zT_B559F9DA_Parser* zT_233;
    zT_3B6EA323_EU_01 zT_238 = {0};
    zT_EAC3E484_TokenKind zT_239;
    zT_B559F9DA_Parser* zT_244;
    zT_3B6EA323_EU_01 zT_249 = {0};
    zT_EAC3E484_TokenKind zT_250;
    zT_B559F9DA_Parser* zT_255;
    zT_3B6EA323_EU_01 zT_260 = {0};
    zT_EAC3E484_TokenKind zT_261;
    zT_B559F9DA_Parser* zT_266;
    zT_3B6EA323_EU_01 zT_267 = {0};
    zT_EAC3E484_TokenKind zT_268;
    zT_B559F9DA_Parser* zT_273;
    zT_3B6EA323_EU_01 zT_274 = {0};
    zT_EAC3E484_TokenKind zT_275;
    zT_B559F9DA_Parser* zT_280;
    zT_3B6EA323_EU_01 zT_281 = {0};
    zT_EAC3E484_TokenKind zT_282;
    zT_B559F9DA_Parser* zT_287;
    zT_3B6EA323_EU_01 zT_288 = {0};
    zT_EAC3E484_TokenKind zT_289;
    zT_B559F9DA_Parser* zT_294;
    zT_3B6EA323_EU_01 zT_295 = {0};
    zT_EAC3E484_TokenKind zT_296;
    zT_B559F9DA_Parser* zT_301;
    zT_3B6EA323_EU_01 zT_302 = {0};
    zT_EAC3E484_TokenKind zT_303;
    zT_B559F9DA_Parser* zT_308;
    zT_3B6EA323_EU_01 zT_309 = {0};
    zT_EAC3E484_TokenKind zT_310;
    zT_B559F9DA_Parser* zT_315;
    zT_3B6EA323_EU_01 zT_316 = {0};
    zT_EAC3E484_TokenKind zT_317;
    zT_B559F9DA_Parser* zT_322;
    zT_3B6EA323_EU_01 zT_323 = {0};
    zT_EAC3E484_TokenKind zT_324;
    zT_B559F9DA_Parser* zT_329;
    zT_3B6EA323_EU_01 zT_330 = {0};
    zT_EAC3E484_TokenKind zT_331;
    zT_B559F9DA_Parser* zT_336;
    unsigned char zT_337;
    unsigned int zT_338;
    zT_3B6EA323_EU_01 zT_339 = {0};
    zT_EAC3E484_TokenKind zT_340;
    zT_B559F9DA_Parser* zT_345;
    int zT_347;
    zT_3B6EA323_EU_01 zT_349 = {0};
    zT_EAC3E484_TokenKind zT_350;
    zT_B559F9DA_Parser* zT_355;
    zT_3B6EA323_EU_01 zT_356 = {0};
    zT_EAC3E484_TokenKind zT_357;
    zT_B559F9DA_Parser* zT_362;
    int zT_364;
    zT_3B6EA323_EU_01 zT_366 = {0};
    zT_EAC3E484_TokenKind zT_367;
    zT_B559F9DA_Parser* zT_372;
    zT_3A355BD2_Token zT_373 = {0};
    zT_B559F9DA_Parser* zT_375;
    zT_3A355BD2_Token zT_376 = {0};
    zT_EAC3E484_TokenKind zT_377;
    zT_B559F9DA_Parser* zT_382;
    int zT_384;
    zT_3B6EA323_EU_01 zT_386 = {0};
    zT_EAC3E484_TokenKind zT_387;
    zT_B559F9DA_Parser* zT_392;
    int zT_394;
    zT_3B6EA323_EU_01 zT_396 = {0};
    unsigned char* zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    unsigned int zT_400;
    zT_B559F9DA_Parser* zT_401;
    zT_3A355BD2_Token zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    zT_DBF3575C_ParserError zT_404;
    zT_3B6EA323_EU_01 zT_405;
    zT_EAC3E484_TokenKind zT_406;
    zT_B559F9DA_Parser* zT_411;
    zT_3B6EA323_EU_01 zT_412 = {0};
    zT_EAC3E484_TokenKind zT_413;
    zT_B559F9DA_Parser* zT_418;
    zT_3B6EA323_EU_01 zT_419 = {0};
    zT_EAC3E484_TokenKind zT_420;
    zT_B559F9DA_Parser* zT_425;
    zT_3B6EA323_EU_01 zT_426 = {0};
    zT_EAC3E484_TokenKind zT_427;
    zT_B559F9DA_Parser* zT_432;
    zT_3B6EA323_EU_01 zT_433 = {0};
    unsigned char* zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    unsigned int zT_437;
    zT_B559F9DA_Parser* zT_438;
    zT_3A355BD2_Token zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    zT_DBF3575C_ParserError zT_441;
    zT_3B6EA323_EU_01 zT_442;
    zT_3A355BD2_Token tok;
    unsigned int eu_base;
    unsigned int eu_payload;
    zT_3A355BD2_Token ntok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u primary_msg;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((int)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self;
    zT_10 = zF_4D06854D_parserParseIntLiter(zT_9);
    return zT_10;
    z_bb_2:
    zT_11 = tok.kind;
    if ((int)(zT_11 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = self;
    zT_17 = zF_FB72DD9C_parserParseFloatLit(zT_16);
    return zT_17;
    z_bb_4:
    zT_18 = tok.kind;
    if ((int)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = self;
    zT_24 = zF_397D4BBF_parserParseStringLi(zT_23);
    return zT_24;
    z_bb_6:
    zT_25 = tok.kind;
    if ((int)(zT_25 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = self;
    zT_31 = zF_F509A7F4_parserParseCharLite(zT_30);
    return zT_31;
    z_bb_8:
    zT_32 = tok.kind;
    if ((int)(zT_32 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37 = self;
    zT_38 = zF_0E221A14_parserParseBoolLite(zT_37);
    return zT_38;
    z_bb_10:
    zT_39 = tok.kind;
    if ((int)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_false))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_44 = self;
    zT_45 = zF_0E221A14_parserParseBoolLite(zT_44);
    return zT_45;
    z_bb_12:
    zT_46 = tok.kind;
    if ((int)(zT_46 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_null))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_51 = self;
    zT_56 = zF_A18ECFB6_parserParseSingleTo(zT_51, (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal));
    return zT_56;
    z_bb_14:
    zT_57 = tok.kind;
    if ((int)(zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_undefined))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_62 = self;
    zT_67 = zF_A18ECFB6_parserParseSingleTo(zT_62, (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal));
    return zT_67;
    z_bb_16:
    zT_68 = tok.kind;
    if ((int)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_unreachable))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_73 = self;
    zT_78 = zF_A18ECFB6_parserParseSingleTo(zT_73, (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr));
    return zT_78;
    z_bb_18:
    zT_79 = tok.kind;
    if ((int)(zT_79 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_84 = self;
    zT_85 = zF_F5EAD186_parserParseIdentExp(zT_84);
    return zT_85;
    z_bb_20:
    zT_86 = tok.kind;
    if ((int)(zT_86 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_91 = self;
    zT_93 = 1;
    zT_95 = zF_F685E431_parserPeekN(zT_91, (unsigned int)((unsigned int)zT_93));
    zT_96 = zT_95.kind;
    if ((int)(zT_96 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_164 = tok.kind;
    if ((int)(zT_164 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_bool))) goto z_bb_36; else goto z_bb_37;
    z_bb_23:
    zT_102 = self;
    zT_104 = 2;
    zT_106 = zF_F685E431_parserPeekN(zT_102, (unsigned int)((unsigned int)zT_104));
    zT_107 = zT_106.kind;
    zT_101 = zT_107 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_25;
    z_bb_24:
    zT_101 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_101) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_112 = self;
    zT_113 = zF_532B277E_parserParseLabeledB(zT_112);
    return zT_113;
    z_bb_27:
    zT_114 = self;
    zT_116 = 1;
    zT_118 = zF_F685E431_parserPeekN(zT_114, (unsigned int)((unsigned int)zT_116));
    zT_119 = zT_118.kind;
    if ((int)(zT_119 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_125 = self;
    zT_126 = zF_F5EAD186_parserParseIdentExp(zT_125);
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_162 = self;
    zT_163 = zF_F5EAD186_parserParseIdentExp(zT_162);
    return zT_163;
    z_bb_30:
    return zT_126;
    z_bb_31:
    zT_128 = zT_126.data.payload;
    goto z_bb_32;
    z_bb_32:
    eu_base = zT_128;
    zT_129 = self;
    zT_130 = zF_C241B2C4_parserAdvance(zT_129);
    (void)zT_130;
    zT_132 = self;
    zT_133 = zF_CBDBFE85_parserParseType(zT_132);
    zT_134 = zT_133.is_error;
    if (zT_134) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return zT_133;
    z_bb_34:
    zT_135 = zT_133.data.payload;
    goto z_bb_35;
    z_bb_35:
    eu_payload = zT_135;
    zT_136 = self->store;
    zT_149 = 0;
    zT_139 = tok.span_start;
    zT_152 = tok.span_start;
    zT_153 = tok.span_len;
    zT_141 = eu_base;
    zT_142 = eu_payload;
    zT_156 = 0;
    zT_158 = 0;
    zT_160 = zF_6C9FF72F_astStoreAddNode(zT_136, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_149), zT_139, (unsigned int)(zT_152 + (unsigned int)((unsigned int)zT_153)), zT_141, zT_142, (unsigned int)((unsigned int)zT_156), (unsigned int)((unsigned int)zT_158));
    zT_161.data.payload = zT_160;
    zT_161.is_error = 0;
    return zT_161;
    z_bb_36:
    zT_169 = self;
    zT_170 = zF_F5EAD186_parserParseIdentExp(zT_169);
    return zT_170;
    z_bb_37:
    zT_171 = tok.kind;
    if ((int)(zT_171 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_c_char))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_176 = self;
    zT_177 = zF_F5EAD186_parserParseIdentExp(zT_176);
    return zT_177;
    z_bb_39:
    zT_178 = tok.kind;
    if ((int)(zT_178 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_void))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_183 = self;
    zT_184 = zF_F5EAD186_parserParseIdentExp(zT_183);
    return zT_184;
    z_bb_41:
    zT_185 = tok.kind;
    if ((int)(zT_185 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_190 = self;
    zT_191 = zF_5D650338_parserParseBuiltinC(zT_190);
    return zT_191;
    z_bb_43:
    zT_192 = tok.kind;
    if ((int)(zT_192 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_197 = self;
    zT_198 = zF_C531682A_parserParseCInclude(zT_197);
    return zT_198;
    z_bb_45:
    zT_199 = tok.kind;
    if ((int)(zT_199 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_204 = self;
    zT_205 = zF_AC24A2A0_parserParseErrorLit(zT_204);
    return zT_205;
    z_bb_47:
    zT_206 = tok.kind;
    if ((int)(zT_206 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_211 = self;
    zT_216 = zF_BE192524_parserParsePrefixUn(zT_211, (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate));
    return zT_216;
    z_bb_49:
    zT_217 = tok.kind;
    if ((int)(zT_217 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_222 = self;
    zT_227 = zF_BE192524_parserParsePrefixUn(zT_222, (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate));
    return zT_227;
    z_bb_51:
    zT_228 = tok.kind;
    if ((int)(zT_228 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_233 = self;
    zT_238 = zF_BE192524_parserParsePrefixUn(zT_233, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not));
    return zT_238;
    z_bb_53:
    zT_239 = tok.kind;
    if ((int)(zT_239 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_244 = self;
    zT_249 = zF_BE192524_parserParsePrefixUn(zT_244, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not));
    return zT_249;
    z_bb_55:
    zT_250 = tok.kind;
    if ((int)(zT_250 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_255 = self;
    zT_260 = zF_BE192524_parserParsePrefixUn(zT_255, (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of));
    return zT_260;
    z_bb_57:
    zT_261 = tok.kind;
    if ((int)(zT_261 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_try))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_266 = self;
    zT_267 = zF_59C88921_parserParseTryExpr(zT_266);
    return zT_267;
    z_bb_59:
    zT_268 = tok.kind;
    if ((int)(zT_268 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_273 = self;
    zT_274 = zF_C5DF83EE_parserParseGroupedE(zT_273);
    return zT_274;
    z_bb_61:
    zT_275 = tok.kind;
    if ((int)(zT_275 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_280 = self;
    zT_281 = zF_9A508F9D_parserParseAnonymou(zT_280);
    return zT_281;
    z_bb_63:
    zT_282 = tok.kind;
    if ((int)(zT_282 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_287 = self;
    zT_288 = zF_BD525F87_parserParseEnumLite(zT_287);
    return zT_288;
    z_bb_65:
    zT_289 = tok.kind;
    if ((int)(zT_289 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_294 = self;
    zT_295 = zF_79089D39_parserParseIfExpr(zT_294);
    return zT_295;
    z_bb_67:
    zT_296 = tok.kind;
    if ((int)(zT_296 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_301 = self;
    zT_302 = zF_A9AC92CA_parserParseSwitchEx(zT_301);
    return zT_302;
    z_bb_69:
    zT_303 = tok.kind;
    if ((int)(zT_303 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_308 = self;
    zT_309 = zF_DE101A45_parserParseArrayLit(zT_308);
    return zT_309;
    z_bb_71:
    zT_310 = tok.kind;
    if ((int)(zT_310 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_315 = self;
    zT_316 = zF_08083D09_parserParsePtrType(zT_315);
    return zT_316;
    z_bb_73:
    zT_317 = tok.kind;
    if ((int)(zT_317 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_322 = self;
    zT_323 = zF_F9036399_parserParseOptional(zT_322);
    return zT_323;
    z_bb_75:
    zT_324 = tok.kind;
    if ((int)(zT_324 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_329 = self;
    zT_330 = zF_B83061B7_parserParseExternFn(zT_329);
    return zT_330;
    z_bb_77:
    zT_331 = tok.kind;
    if ((int)(zT_331 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_336 = self;
    zT_338 = 0;
    zT_337 = zT_338;
    zT_339 = zF_B5C9B665_parserParseFnType(zT_336, zT_337);
    return zT_339;
    z_bb_79:
    zT_340 = tok.kind;
    if ((int)(zT_340 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_345 = self;
    zT_347 = 0;
    zT_349 = zF_3530D6C0_parserParseStructTy(zT_345, (unsigned char)((unsigned char)zT_347));
    return zT_349;
    z_bb_81:
    zT_350 = tok.kind;
    if ((int)(zT_350 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_355 = self;
    zT_356 = zF_63EC2480_parserParseEnumType(zT_355);
    return zT_356;
    z_bb_83:
    zT_357 = tok.kind;
    if ((int)(zT_357 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_362 = self;
    zT_364 = 0;
    zT_366 = zF_0881F8E4_parserParseUnionTyp(zT_362, (unsigned char)((unsigned char)zT_364));
    return zT_366;
    z_bb_85:
    zT_367 = tok.kind;
    if ((int)(zT_367 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_packed))) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_372 = self;
    zT_373 = zF_C241B2C4_parserAdvance(zT_372);
    (void)zT_373;
    zT_375 = self;
    zT_376 = zF_068A2DE5_parserPeek(zT_375);
    ntok = zT_376;
    zT_377 = ntok.kind;
    if ((int)(zT_377 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    zT_406 = tok.kind;
    if ((int)(zT_406 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_92; else goto z_bb_93;
    z_bb_88:
    zT_382 = self;
    zT_384 = 1;
    zT_386 = zF_3530D6C0_parserParseStructTy(zT_382, (unsigned char)((unsigned char)zT_384));
    return zT_386;
    z_bb_89:
    zT_387 = ntok.kind;
    if ((int)(zT_387 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_392 = self;
    zT_394 = 1;
    zT_396 = zF_0881F8E4_parserParseUnionTyp(zT_392, (unsigned char)((unsigned char)zT_394));
    return zT_396;
    z_bb_91:
    zT_398 = "expected 'struct' or 'union' after 'packed'";
    zT_400 = 43;
    zT_399.ptr = zT_398;
    zT_399.len = zT_400;
    pmsg = zT_399;
    zT_401 = self;
    zT_402 = ntok;
    zT_403 = pmsg;
    zF_17DF2CA5_parserAddError(zT_401, zT_402, zT_403);
    zT_404 = 1;
    zT_405.data.err = zT_404;
    zT_405.is_error = 1;
    return zT_405;
    z_bb_92:
    zT_411 = self;
    zT_412 = zF_224C1394_parserParseReturnEx(zT_411);
    return zT_412;
    z_bb_93:
    zT_413 = tok.kind;
    if ((int)(zT_413 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_418 = self;
    zT_419 = zF_C69B6287_parserParseBreakExp(zT_418);
    return zT_419;
    z_bb_95:
    zT_420 = tok.kind;
    if ((int)(zT_420 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_425 = self;
    zT_426 = zF_73B42F4B_parserParseContinue(zT_425);
    return zT_426;
    z_bb_97:
    zT_427 = tok.kind;
    if ((int)(zT_427 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_432 = self;
    zT_433 = zF_365CA04A_parserParseBlock(zT_432);
    return zT_433;
    z_bb_99:
    zT_435 = "expected expression";
    zT_437 = 19;
    zT_436.ptr = zT_435;
    zT_436.len = zT_437;
    primary_msg = zT_436;
    zT_438 = self;
    zT_439 = tok;
    zT_440 = primary_msg;
    zF_17DF2CA5_parserAddError(zT_438, zT_439, zT_440);
    zT_441 = 1;
    zT_442.data.err = zT_441;
    zT_442.is_error = 1;
    return zT_442;
}

/* parserParsePostfixChain */
zT_3B6EA323_EU_01 zF_77AD89E7_parserParsePostfixC(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_17;
    unsigned int zT_19;
    int zT_27;
    unsigned int zT_30;
    unsigned short zT_31;
    int zT_34;
    int zT_36;
    int zT_38;
    unsigned int zT_40 = 0;
    zT_EAC3E484_TokenKind zT_41;
    zT_B559F9DA_Parser* zT_46;
    unsigned int zT_47;
    zT_3B6EA323_EU_01 zT_48 = {0};
    unsigned char zT_49;
    unsigned int zT_50;
    zT_EAC3E484_TokenKind zT_51;
    zT_B559F9DA_Parser* zT_56;
    unsigned int zT_57;
    zT_3B6EA323_EU_01 zT_58 = {0};
    unsigned char zT_59;
    unsigned int zT_60;
    zT_EAC3E484_TokenKind zT_61;
    zT_B559F9DA_Parser* zT_66;
    unsigned int zT_67;
    zT_3B6EA323_EU_01 zT_68 = {0};
    unsigned char zT_69;
    unsigned int zT_70;
    zT_EAC3E484_TokenKind zT_71;
    zT_B559F9DA_Parser* zT_76;
    unsigned int zT_77;
    zT_3B6EA323_EU_01 zT_78 = {0};
    unsigned char zT_79;
    unsigned int zT_80;
    zT_3B6EA323_EU_01 zT_81;
    unsigned int node;
    zT_3A355BD2_Token tok;
    node = base;
    goto z_bb_1;
    z_bb_1:
    if ((int)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_81.data.payload = node;
    zT_81.is_error = 0;
    return zT_81;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    (void)zT_13;
    zT_14 = self->store;
    zT_27 = 0;
    zT_17 = tok.span_start;
    zT_30 = tok.span_start;
    zT_31 = tok.span_len;
    zT_19 = node;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = zF_6C9FF72F_astStoreAddNode(zT_14, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_27), zT_17, (unsigned int)(zT_30 + (unsigned int)((unsigned int)zT_31)), zT_19, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38));
    node = zT_40;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_41 = tok.kind;
    if ((int)(zT_41 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_46 = self;
    zT_47 = node;
    zT_48 = zF_86B17ABA_parserParseDotAcces(zT_46, zT_47);
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_51 = tok.kind;
    if ((int)(zT_51 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_14; else goto z_bb_16;
    z_bb_11:
    return zT_48;
    z_bb_12:
    zT_50 = zT_48.data.payload;
    goto z_bb_13;
    z_bb_13:
    node = zT_50;
    goto z_bb_9;
    z_bb_14:
    zT_56 = self;
    zT_57 = node;
    zT_58 = zF_8B5A7E08_parserParseIndexOrS(zT_56, zT_57);
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_61 = tok.kind;
    if ((int)(zT_61 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_20; else goto z_bb_22;
    z_bb_17:
    return zT_58;
    z_bb_18:
    zT_60 = zT_58.data.payload;
    goto z_bb_19;
    z_bb_19:
    node = zT_60;
    goto z_bb_15;
    z_bb_20:
    zT_66 = self;
    zT_67 = node;
    zT_68 = zF_3FC58691_parserParseFnCall(zT_66, zT_67);
    zT_69 = zT_68.is_error;
    if (zT_69) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_71 = tok.kind;
    if ((int)(zT_71 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_28;
    z_bb_23:
    return zT_68;
    z_bb_24:
    zT_70 = zT_68.data.payload;
    goto z_bb_25;
    z_bb_25:
    node = zT_70;
    goto z_bb_21;
    z_bb_26:
    zT_76 = self;
    zT_77 = node;
    zT_78 = zF_EFD340BA_parserParseStructIn(zT_76, zT_77);
    zT_79 = zT_78.is_error;
    if (zT_79) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_21;
    z_bb_28:
    goto z_bb_3;
    z_bb_29:
    return zT_78;
    z_bb_30:
    zT_80 = zT_78.data.payload;
    goto z_bb_31;
    z_bb_31:
    node = zT_80;
    goto z_bb_27;
}

/* parserParseDotAccess */
zT_3B6EA323_EU_01 zF_86B17ABA_parserParseDotAcces(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    int zT_29;
    unsigned int zT_32;
    unsigned short zT_33;
    int zT_36;
    int zT_38;
    int zT_40;
    unsigned int zT_42 = 0;
    zT_3B6EA323_EU_01 zT_43;
    zT_85CBA4DB_TokenValue zT_45;
    unsigned int zT_46;
    zT_B559F9DA_Parser* zT_47;
    zT_3A355BD2_Token zT_48 = {0};
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_57;
    int zT_62;
    unsigned int zT_65;
    unsigned short zT_66;
    int zT_69;
    int zT_71;
    unsigned int zT_73 = 0;
    zT_3B6EA323_EU_01 zT_74;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((int)((unsigned int)((unsigned int)zT_7) == (unsigned int)((unsigned int)(zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    (void)zT_15;
    zT_16 = self->store;
    zT_29 = 0;
    zT_19 = tok.span_start;
    zT_32 = tok.span_start;
    zT_33 = tok.span_len;
    zT_21 = base;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = 0;
    zT_42 = zF_6C9FF72F_astStoreAddNode(zT_16, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_29), zT_19, (unsigned int)(zT_32 + (unsigned int)((unsigned int)zT_33)), zT_21, (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38), (unsigned int)((unsigned int)zT_40));
    zT_43.data.payload = zT_42;
    zT_43.is_error = 0;
    return zT_43;
    z_bb_2:
    zT_45 = tok.value;
    zT_46 = zT_45.string_id;
    name_id = zT_46;
    zT_47 = self;
    zT_48 = zF_C241B2C4_parserAdvance(zT_47);
    (void)zT_48;
    zT_49 = self->store;
    zT_62 = 0;
    zT_52 = tok.span_start;
    zT_65 = tok.span_start;
    zT_66 = tok.span_len;
    zT_54 = base;
    zT_69 = 0;
    zT_71 = 0;
    zT_57 = name_id;
    zT_73 = zF_6C9FF72F_astStoreAddNode(zT_49, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_62), zT_52, (unsigned int)(zT_65 + (unsigned int)((unsigned int)zT_66)), zT_54, (unsigned int)((unsigned int)zT_69), (unsigned int)((unsigned int)zT_71), zT_57);
    zT_74.data.payload = zT_73;
    zT_74.is_error = 0;
    return zT_74;
}

/* parserParseIndexOrSlice */
zT_3B6EA323_EU_01 zF_8B5A7E08_parserParseIndexOrS(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_EAC3E484_TokenKind zT_14;
    zT_B559F9DA_Parser* zT_19;
    zT_3A355BD2_Token zT_20 = {0};
    int zT_22;
    unsigned int zT_23;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_EAC3E484_TokenKind zT_26;
    zT_B559F9DA_Parser* zT_31;
    zT_3B6EA323_EU_01 zT_34 = {0};
    unsigned char zT_35;
    unsigned int zT_36;
    zT_B559F9DA_Parser* zT_37;
    zT_CB78802F_EU_49 zT_42 = {0};
    unsigned char zT_43;
    int zT_44;
    zT_3B6EA323_EU_01 zT_45;
    zT_2B3424E9_ParseToken zT_46;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_60;
    unsigned int zT_63;
    unsigned short zT_64;
    int zT_67;
    unsigned int zT_69 = 0;
    zT_3B6EA323_EU_01 zT_70;
    zT_B559F9DA_Parser* zT_71;
    zT_CB78802F_EU_49 zT_76 = {0};
    unsigned char zT_77;
    int zT_78;
    zT_3B6EA323_EU_01 zT_79;
    zT_2B3424E9_ParseToken zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_87;
    int zT_94;
    unsigned int zT_97;
    unsigned short zT_98;
    int zT_101;
    int zT_103;
    unsigned int zT_105 = 0;
    zT_3B6EA323_EU_01 zT_106;
    unsigned int first;
    zT_3A355BD2_Token tok;
    unsigned int last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    first = zT_10;
    zT_12 = self;
    zT_13 = zF_068A2DE5_parserPeek(zT_12);
    tok = zT_13;
    zT_14 = tok.kind;
    if ((int)(zT_14 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = self;
    zT_20 = zF_C241B2C4_parserAdvance(zT_19);
    (void)zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    last = zT_23;
    zT_24 = self;
    zT_25 = zF_068A2DE5_parserPeek(zT_24);
    zT_26 = zT_25.kind;
    if ((int)(zT_26 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_71 = self;
    zT_76 = zF_5578C74F_parserExpect(zT_71, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_77 = zT_76.is_error;
    if (zT_77) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_37 = self;
    zT_42 = zF_5578C74F_parserExpect(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_43 = zT_42.is_error;
    if (zT_43) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_31 = self;
    zT_34 = zF_F07C1F04_parserParseExprPrec(zT_31, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return zT_34;
    z_bb_10:
    zT_36 = zT_34.data.payload;
    goto z_bb_11;
    z_bb_11:
    last = zT_36;
    goto z_bb_7;
    z_bb_12:
    zT_44 = zT_42.data.err;
    zT_45.data.err = zT_44;
    zT_45.is_error = 1;
    return zT_45;
    z_bb_13:
    zT_46 = zT_42.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_46;
    zT_47 = self->store;
    zT_60 = 0;
    zT_50 = tok.span_start;
    zT_63 = tok.span_start;
    zT_64 = tok.span_len;
    zT_52 = base;
    zT_53 = first;
    zT_54 = last;
    zT_67 = 0;
    zT_69 = zF_6C9FF72F_astStoreAddNode(zT_47, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr), (unsigned char)((unsigned char)zT_60), zT_50, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_52, zT_53, zT_54, (unsigned int)((unsigned int)zT_67));
    zT_70.data.payload = zT_69;
    zT_70.is_error = 0;
    return zT_70;
    z_bb_15:
    zT_78 = zT_76.data.err;
    zT_79.data.err = zT_78;
    zT_79.is_error = 1;
    return zT_79;
    z_bb_16:
    zT_80 = zT_76.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_80;
    zT_81 = self->store;
    zT_94 = 0;
    zT_84 = tok.span_start;
    zT_97 = tok.span_start;
    zT_98 = tok.span_len;
    zT_86 = base;
    zT_87 = first;
    zT_101 = 0;
    zT_103 = 0;
    zT_105 = zF_6C9FF72F_astStoreAddNode(zT_81, (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access), (unsigned char)((unsigned char)zT_94), zT_84, (unsigned int)(zT_97 + (unsigned int)((unsigned int)zT_98)), zT_86, zT_87, (unsigned int)((unsigned int)zT_101), (unsigned int)((unsigned int)zT_103));
    zT_106.data.payload = zT_105;
    zT_106.is_error = 0;
    return zT_106;
}

/* parserParseFnCall */
zT_3B6EA323_EU_01 zF_3FC58691_parserParseFnCall(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    unsigned int zT_16;
    unsigned short zT_17;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_33;
    int zT_36;
    int zT_38;
    int zT_40;
    unsigned int zT_42 = 0;
    zT_3B6EA323_EU_01 zT_43;
    unsigned int zT_45;
    zT_B559F9DA_Parser* zT_48;
    zT_3B6EA323_EU_01 zT_51 = {0};
    unsigned char zT_52;
    unsigned int zT_53;
    unsigned int** zT_54;
    unsigned int* zT_55;
    unsigned int* zT_56;
    zT_3E40CD83_Sand* zT_57;
    unsigned int zT_58;
    zT_B559F9DA_Parser* zT_63;
    zT_3A355BD2_Token zT_64 = {0};
    zT_EAC3E484_TokenKind zT_65;
    zT_B559F9DA_Parser* zT_70;
    zT_CB78802F_EU_49 zT_75 = {0};
    unsigned char zT_76;
    int zT_77;
    zT_3B6EA323_EU_01 zT_78;
    zT_2B3424E9_ParseToken zT_79;
    zT_B559F9DA_Parser* zT_80;
    zT_3A355BD2_Token zT_81 = {0};
    zT_EAC3E484_TokenKind zT_82;
    zT_B559F9DA_Parser* zT_88;
    zT_CB78802F_EU_49 zT_93 = {0};
    unsigned char zT_94;
    int zT_95;
    zT_3B6EA323_EU_01 zT_96;
    zT_2B3424E9_ParseToken zT_97;
    unsigned int zT_99;
    unsigned short zT_100;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_6B0A7D14_AstStore* zT_108;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_109;
    unsigned int* zT_111;
    unsigned int zT_112;
    unsigned int* zT_113;
    unsigned int zT_114;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_115;
    unsigned int zT_116 = 0;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_125;
    int zT_130;
    int zT_133;
    int zT_135;
    unsigned int zT_137 = 0;
    zT_3B6EA323_EU_01 zT_138;
    zT_3A355BD2_Token lparen;
    zT_3A355BD2_Token rparen;
    unsigned int end;
    unsigned int saved_fncall;
    unsigned int arg;
    zT_2B3424E9_ParseToken rparen_1;
    unsigned int payload;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lparen = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    rparen = zT_14;
    zT_16 = rparen.span_start;
    zT_17 = rparen.span_len;
    zT_19 = zT_16 + (unsigned int)((unsigned int)zT_17);
    end = zT_19;
    zT_20 = self->store;
    zT_33 = 0;
    zT_23 = lparen.span_start;
    zT_24 = end;
    zT_25 = base;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = 0;
    zT_42 = zF_6C9FF72F_astStoreAddNode(zT_20, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_33), zT_23, zT_24, zT_25, (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38), (unsigned int)((unsigned int)zT_40));
    zT_43.data.payload = zT_42;
    zT_43.is_error = 0;
    return zT_43;
    z_bb_2:
    zT_45 = self->child_buf_len;
    saved_fncall = zT_45;
    goto z_bb_3;
    z_bb_3:
    if ((int)(1)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_48 = self;
    zT_51 = zF_F07C1F04_parserParseExprPrec(zT_48, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_52 = zT_51.is_error;
    if (zT_52) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_88 = self;
    zT_93 = zF_5578C74F_parserExpect(zT_88, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_94 = zT_93.is_error;
    if (zT_94) goto z_bb_17; else goto z_bb_18;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return zT_51;
    z_bb_8:
    zT_53 = zT_51.data.payload;
    goto z_bb_9;
    z_bb_9:
    arg = zT_53;
    zT_54 = &self->child_buf_items;
    zT_55 = &self->child_buf_len;
    zT_56 = &self->child_buf_capacity;
    zT_57 = self->allocator;
    zT_58 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_54, zT_55, zT_56, zT_57, zT_58);
    zT_63 = self;
    zT_64 = zF_068A2DE5_parserPeek(zT_63);
    zT_65 = zT_64.kind;
    if ((int)(zT_65 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    zT_70 = self;
    zT_75 = zF_5578C74F_parserExpect(zT_70, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_76 = zT_75.is_error;
    if (zT_76) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_77 = zT_75.data.err;
    zT_78.data.err = zT_77;
    zT_78.is_error = 1;
    return zT_78;
    z_bb_13:
    zT_79 = zT_75.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_79;
    zT_80 = self;
    zT_81 = zF_068A2DE5_parserPeek(zT_80);
    zT_82 = zT_81.kind;
    if ((int)(zT_82 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_5;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_95 = zT_93.data.err;
    zT_96.data.err = zT_95;
    zT_96.is_error = 1;
    return zT_96;
    z_bb_18:
    zT_97 = zT_93.data.payload;
    goto z_bb_19;
    z_bb_19:
    rparen_1 = zT_97;
    zT_99 = rparen_1.span_start;
    zT_100 = rparen_1.span_len;
    zT_102 = zT_99 + (unsigned int)((unsigned int)zT_100);
    end = zT_102;
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    payload = zT_105;
    zT_106 = self->child_buf_len;
    if ((int)(zT_106 > saved_fncall)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_108 = self->store;
    zT_111 = self->child_buf_items;
    zT_112 = self->child_buf_len;
    zT_113 = zT_111 + saved_fncall;
    zT_114 = zT_112 - saved_fncall;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_109 = zT_115;
    zT_116 = zF_583E993C_astStoreAddExtraChi(zT_108, zT_109);
    payload = zT_116;
    goto z_bb_21;
    z_bb_21:
    self->child_buf_len = saved_fncall;
    zT_117 = self->store;
    zT_130 = 0;
    zT_120 = lparen.span_start;
    zT_121 = end;
    zT_122 = base;
    zT_133 = 0;
    zT_135 = 0;
    zT_125 = payload;
    zT_137 = zF_6C9FF72F_astStoreAddNode(zT_117, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_130), zT_120, zT_121, zT_122, (unsigned int)((unsigned int)zT_133), (unsigned int)((unsigned int)zT_135), zT_125);
    zT_138.data.payload = zT_137;
    zT_138.is_error = 0;
    return zT_138;
}

/* parserParseCatchRHS */
zT_3B6EA323_EU_01 zF_95DDA8C7_parserParseCatchRHS(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min, unsigned int* capture_out) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    zT_B559F9DA_Parser* zT_17;
    zT_CB78802F_EU_49 zT_22 = {0};
    unsigned char zT_23;
    int zT_24;
    zT_3B6EA323_EU_01 zT_25;
    zT_2B3424E9_ParseToken zT_26;
    zT_B559F9DA_Parser* zT_27;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    zT_85CBA4DB_TokenValue zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_43;
    unsigned int zT_48;
    int zT_53;
    unsigned int zT_56;
    unsigned short zT_57;
    int zT_60;
    int zT_62;
    int zT_64;
    unsigned int zT_66 = 0;
    unsigned int zT_68 = 0;
    zT_B559F9DA_Parser* zT_69;
    zT_3A355BD2_Token zT_70 = {0};
    zT_EAC3E484_TokenKind zT_71;
    zT_B559F9DA_Parser* zT_76;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char zT_78;
    unsigned int zT_79;
    zT_B559F9DA_Parser* zT_80;
    zT_2B10107F_Prec zT_81;
    zT_3B6EA323_EU_01 zT_82 = {0};
    unsigned char zT_83;
    unsigned int zT_84;
    zT_3B6EA323_EU_01 zT_85;
    zT_3A355BD2_Token ptok;
    zT_3A355BD2_Token name_raw2;
    unsigned int result;
    unsigned int name_id;
    *capture_out = (unsigned int)(0);
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    ptok = zT_6;
    zT_7 = ptok.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    (void)zT_13;
    zT_15 = self;
    zT_16 = zF_068A2DE5_parserPeek(zT_15);
    name_raw2 = zT_16;
    zT_17 = self;
    zT_22 = zF_5578C74F_parserExpect(zT_17, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    result = zT_68;
    zT_69 = self;
    zT_70 = zF_068A2DE5_parserPeek(zT_69);
    zT_71 = zT_70.kind;
    if ((int)(zT_71 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_9; else goto z_bb_11;
    z_bb_3:
    zT_24 = zT_22.data.err;
    zT_25.data.err = zT_24;
    zT_25.is_error = 1;
    return zT_25;
    z_bb_4:
    zT_26 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_26;
    zT_27 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_27, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_7:
    zT_36 = zT_32.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_36;
    zT_38 = name_raw2.value;
    zT_39 = zT_38.string_id;
    name_id = zT_39;
    zT_40 = self->store;
    zT_53 = 0;
    zT_43 = name_raw2.span_start;
    zT_56 = name_raw2.span_start;
    zT_57 = name_raw2.span_len;
    zT_60 = 0;
    zT_62 = 0;
    zT_64 = 0;
    zT_48 = name_id;
    zT_66 = zF_6C9FF72F_astStoreAddNode(zT_40, (zT_8143F551_AstKind)(zT_8143F551_AstKind_payload_capture), (unsigned char)((unsigned char)zT_53), zT_43, (unsigned int)(zT_56 + (unsigned int)((unsigned int)zT_57)), (unsigned int)((unsigned int)zT_60), (unsigned int)((unsigned int)zT_62), (unsigned int)((unsigned int)zT_64), zT_48);
    *capture_out = zT_66;
    goto z_bb_2;
    z_bb_9:
    zT_76 = self;
    zT_77 = zF_365CA04A_parserParseBlock(zT_76);
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_85.data.payload = result;
    zT_85.is_error = 0;
    return zT_85;
    z_bb_11:
    zT_80 = self;
    zT_81 = next_min;
    zT_82 = zF_F07C1F04_parserParseExprPrec(zT_80, zT_81);
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_77;
    z_bb_13:
    zT_79 = zT_77.data.payload;
    goto z_bb_14;
    z_bb_14:
    result = zT_79;
    goto z_bb_10;
    z_bb_15:
    return zT_82;
    z_bb_16:
    zT_84 = zT_82.data.payload;
    goto z_bb_17;
    z_bb_17:
    result = zT_84;
    goto z_bb_10;
}

/* parserParseOrelseRHS */
zT_3B6EA323_EU_01 zF_A059028C_parserParseOrelseRH(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_9;
    zT_3B6EA323_EU_01 zT_10 = {0};
    zT_B559F9DA_Parser* zT_11;
    zT_2B10107F_Prec zT_12;
    zT_3B6EA323_EU_01 zT_13 = {0};
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((int)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self;
    zT_10 = zF_365CA04A_parserParseBlock(zT_9);
    return zT_10;
    z_bb_2:
    zT_11 = self;
    zT_12 = next_min;
    zT_13 = zF_F07C1F04_parserParseExprPrec(zT_11, zT_12);
    return zT_13;
}

/* parserParseFieldInitListNamed */
zT_3B6EA323_EU_01 zF_D1EA41E6_parserParseFieldIni(zT_B559F9DA_Parser* self) {
    unsigned int zT_2;
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11 = {0};
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_15;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_CB78802F_EU_49 zT_30 = {0};
    unsigned char zT_31;
    int zT_32;
    zT_3B6EA323_EU_01 zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_B559F9DA_Parser* zT_36;
    zT_3B6EA323_EU_01 zT_39 = {0};
    unsigned char zT_40;
    unsigned int zT_41;
    zT_85CBA4DB_TokenValue zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_49;
    unsigned int zT_51;
    unsigned int zT_54;
    int zT_59;
    unsigned int zT_62;
    unsigned short zT_63;
    int zT_66;
    int zT_68;
    unsigned int zT_70 = 0;
    unsigned int** zT_71;
    unsigned int* zT_72;
    unsigned int* zT_73;
    zT_3E40CD83_Sand* zT_74;
    unsigned int zT_75;
    zT_B559F9DA_Parser* zT_80;
    zT_3A355BD2_Token zT_81 = {0};
    zT_EAC3E484_TokenKind zT_82;
    zT_B559F9DA_Parser* zT_87;
    zT_3A355BD2_Token zT_88 = {0};
    zT_B559F9DA_Parser* zT_90;
    zT_CB78802F_EU_49 zT_95 = {0};
    unsigned char zT_96;
    int zT_97;
    zT_3B6EA323_EU_01 zT_98;
    int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_105;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_106;
    unsigned int* zT_108;
    unsigned int zT_109;
    unsigned int* zT_110;
    unsigned int zT_111;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_112;
    unsigned int zT_113 = 0;
    zT_3B6EA323_EU_01 zT_114;
    unsigned int saved_child_len;
    zT_3A355BD2_Token name_raw3;
    unsigned int val;
    unsigned int name_id;
    unsigned int field;
    unsigned int payload;
    zT_2 = self->child_buf_len;
    saved_child_len = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    if ((int)(zT_5 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self;
    zT_11 = zF_C241B2C4_parserAdvance(zT_10);
    (void)zT_11;
    zT_13 = self;
    zT_14 = zF_068A2DE5_parserPeek(zT_13);
    name_raw3 = zT_14;
    zT_15 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_15, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_90 = self;
    zT_95 = zF_5578C74F_parserExpect(zT_90, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_96 = zT_95.is_error;
    if (zT_96) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_6:
    zT_24 = zT_20.data.payload;
    goto z_bb_7;
    z_bb_7:
    (void)zT_24;
    zT_25 = self;
    zT_30 = zF_5578C74F_parserExpect(zT_25, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = zT_30.data.err;
    zT_33.data.err = zT_32;
    zT_33.is_error = 1;
    return zT_33;
    z_bb_9:
    zT_34 = zT_30.data.payload;
    goto z_bb_10;
    z_bb_10:
    (void)zT_34;
    zT_36 = self;
    zT_39 = zF_F07C1F04_parserParseExprPrec(zT_36, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return zT_39;
    z_bb_12:
    zT_41 = zT_39.data.payload;
    goto z_bb_13;
    z_bb_13:
    val = zT_41;
    zT_43 = name_raw3.value;
    zT_44 = zT_43.string_id;
    name_id = zT_44;
    zT_46 = self->store;
    zT_59 = 0;
    zT_49 = name_raw3.span_start;
    zT_62 = name_raw3.span_start;
    zT_63 = name_raw3.span_len;
    zT_51 = val;
    zT_66 = 0;
    zT_68 = 0;
    zT_54 = name_id;
    zT_70 = zF_6C9FF72F_astStoreAddNode(zT_46, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_init), (unsigned char)((unsigned char)zT_59), zT_49, (unsigned int)(zT_62 + (unsigned int)((unsigned int)zT_63)), zT_51, (unsigned int)((unsigned int)zT_66), (unsigned int)((unsigned int)zT_68), zT_54);
    field = zT_70;
    zT_71 = &self->child_buf_items;
    zT_72 = &self->child_buf_len;
    zT_73 = &self->child_buf_capacity;
    zT_74 = self->allocator;
    zT_75 = field;
    zF_8B163A32_u32ArrayListAppendI(zT_71, zT_72, zT_73, zT_74, zT_75);
    zT_80 = self;
    zT_81 = zF_068A2DE5_parserPeek(zT_80);
    zT_82 = zT_81.kind;
    if ((int)(zT_82 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_87 = self;
    zT_88 = zF_C241B2C4_parserAdvance(zT_87);
    (void)zT_88;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_4;
    z_bb_16:
    zT_97 = zT_95.data.err;
    zT_98.data.err = zT_97;
    zT_98.is_error = 1;
    return zT_98;
    z_bb_17:
    goto z_bb_18;
    z_bb_18:
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    payload = zT_102;
    zT_103 = self->child_buf_len;
    if ((int)(zT_103 > saved_child_len)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_105 = self->store;
    zT_108 = self->child_buf_items;
    zT_109 = self->child_buf_len;
    zT_110 = zT_108 + saved_child_len;
    zT_111 = zT_109 - saved_child_len;
    zT_112.ptr = zT_110;
    zT_112.len = zT_111;
    zT_106 = zT_112;
    zT_113 = zF_583E993C_astStoreAddExtraChi(zT_105, zT_106);
    payload = zT_113;
    goto z_bb_20;
    z_bb_20:
    self->child_buf_len = saved_child_len;
    zT_114.data.payload = payload;
    zT_114.is_error = 0;
    return zT_114;
}

/* parserParseStructInit */
zT_3B6EA323_EU_01 zF_EFD340BA_parserParseStructIn(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    int zT_25;
    int zT_28;
    int zT_30;
    unsigned int zT_32 = 0;
    zT_3B6EA323_EU_01 zT_33;
    zT_3A355BD2_Token lbrace;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lbrace = zT_4;
    zT_6 = self;
    zT_7 = zF_D1EA41E6_parserParseFieldIni(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_9;
    zT_11 = self->last_end;
    end_pos = zT_11;
    zT_12 = self->store;
    zT_25 = 0;
    zT_15 = lbrace.span_start;
    zT_16 = end_pos;
    zT_17 = base;
    zT_28 = 0;
    zT_30 = 0;
    zT_20 = payload;
    zT_32 = zF_6C9FF72F_astStoreAddNode(zT_12, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_25), zT_15, zT_16, zT_17, (unsigned int)((unsigned int)zT_28), (unsigned int)((unsigned int)zT_30), zT_20);
    zT_33.data.payload = zT_32;
    zT_33.is_error = 0;
    return zT_33;
}

/* u32ArrayListAppendInner */
void zF_8B163A32_u32ArrayListAppendI(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int* zT_29;
    unsigned int zT_31;
    zT_7532B98D_Opt_233 zT_37 = {0};
    unsigned char zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_FBF0B3E4_EU_332 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int* zT_61;
    unsigned int zT_62;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_63;
    unsigned int* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_7532B98D_Opt_233 grown;
    unsigned char* raw;
    unsigned int* new_items_p;
    unsigned int item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((int)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((int)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(4)), (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (unsigned int*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* parserPushU32 */
void zF_0F1462F8_parserPushU32(zT_B559F9DA_Parser* self, unsigned int** buf, unsigned int* len, unsigned int* cap, unsigned int v) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_5 = buf;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = self->allocator;
    zT_9 = v;
    zF_8B163A32_u32ArrayListAppendI(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* parserParseIntLiteral */
zT_3B6EA323_EU_01 zF_4D06854D_parserParseIntLiter(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_E45552BF_astStoreAddIntLiter(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseFloatLiteral */
zT_3B6EA323_EU_01 zF_FB72DD9C_parserParseFloatLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_C41F1B06_Arr_unsigned_char_6 zT_10;
    double zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_85CBA4DB_TokenValue zT_15;
    int zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25 = {0};
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    double zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_85CBA4DB_TokenValue zT_42;
    unsigned int zT_45 = 0;
    zT_3B6EA323_EU_01 zT_46;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_C41F1B06_Arr_unsigned_char_6 dbg_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        dbg_buf[_i] = zT_10[_i];
        _i++;
    }
}
    zT_15 = tok.value;
    zT_12 = zT_15.float_val;
    zT_19 = 0;
    zT_20 = (unsigned char*)((unsigned char*)dbg_buf) + zT_19;
    zT_21 = (unsigned int)(64) - zT_19;
    zT_22.ptr = zT_20;
    zT_22.len = zT_21;
    zT_13 = zT_22;
    zT_23 = 64;
    zT_25 = zF_4CAEBE7E_formatF64(zT_12, zT_13, (unsigned int)((unsigned int)zT_23));
    dbg = zT_25;
    zT_27 = "PF:";
    zT_29 = 3;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ps = zT_28;
    zT_30 = ps;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_31 = dbg;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_33 = "\n";
    zT_35 = 1;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pn = zT_34;
    zT_36 = pn;
    zF_48AC7B3A_markerWrite(zT_36);
    zT_37 = self->store;
    zT_42 = tok.value;
    zT_38 = zT_42.float_val;
    zT_39 = tok.span_start;
    zT_40 = end;
    zT_45 = zF_0CEAF68A_astStoreAddFloatLit(zT_37, zT_38, zT_39, zT_40);
    zT_46.data.payload = zT_45;
    zT_46.is_error = 0;
    return zT_46;
}

/* parserParseStringLiteral */
zT_3B6EA323_EU_01 zF_397D4BBF_parserParseStringLi(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.string_id;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_042235B9_astStoreAddStringLi(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseCharLiteral */
zT_3B6EA323_EU_01 zF_F509A7F4_parserParseCharLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_2CAC92AE_astStoreAddCharLite(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseBoolLiteral */
zT_3B6EA323_EU_01 zF_0E221A14_parserParseBoolLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned char zT_6;
    zT_EAC3E484_TokenKind zT_7;
    int zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_33;
    int zT_35;
    int zT_37;
    int zT_39;
    unsigned int zT_41 = 0;
    zT_3B6EA323_EU_01 zT_42;
    zT_3A355BD2_Token tok;
    unsigned char val;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    val = zT_6;
    zT_7 = tok.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 1;
    zT_13 = (unsigned char)zT_12;
    val = zT_13;
    goto z_bb_2;
    z_bb_2:
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end = zT_18;
    zT_19 = self->store;
    zT_21 = val;
    zT_22 = tok.span_start;
    zT_23 = end;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = 0;
    zT_39 = 0;
    zT_41 = zF_6C9FF72F_astStoreAddNode(zT_19, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal), zT_21, zT_22, zT_23, (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35), (unsigned int)((unsigned int)zT_37), (unsigned int)((unsigned int)zT_39));
    zT_42.data.payload = zT_41;
    zT_42.is_error = 0;
    return zT_42;
}

/* parserParseSingleToken */
zT_3B6EA323_EU_01 zF_A18ECFB6_parserParseSingleTo(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    unsigned int zT_6;
    unsigned short zT_7;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_10;
    zT_8143F551_AstKind zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_20;
    int zT_23;
    int zT_25;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = tok.span_start;
    zT_7 = tok.span_len;
    zT_9 = zT_6 + (unsigned int)((unsigned int)zT_7);
    end = zT_9;
    zT_10 = self->store;
    zT_11 = kind;
    zT_20 = 0;
    zT_13 = tok.span_start;
    zT_14 = end;
    zT_23 = 0;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_10, zT_11, (unsigned char)((unsigned char)zT_20), zT_13, zT_14, (unsigned int)((unsigned int)zT_23), (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29));
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* parserParseIdentExpr */
zT_3B6EA323_EU_01 zF_F5EAD186_parserParseIdentExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_2B3424E9_ParseToken zT_5;
    zT_EAC3E484_TokenKind zT_6;
    unsigned int zT_7;
    unsigned short zT_8;
    zT_D3EB6303_StringInterner* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_B559F9DA_Parser* zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15 = {0};
    unsigned int zT_16 = 0;
    unsigned int zT_18;
    unsigned short zT_19;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_32 = 0;
    zT_3B6EA323_EU_01 zT_33;
    zT_3A355BD2_Token tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_6 = tok.kind;
    zT_5.kind = zT_6;
    zT_7 = tok.span_start;
    zT_5.span_start = zT_7;
    zT_8 = tok.span_len;
    zT_5.span_len = zT_8;
    pt = zT_5;
    zT_10 = self->interner;
    zT_13 = self;
    zT_14 = pt;
    zT_15 = zF_08D61E58_parserTokenText(zT_13, zT_14);
    zT_11 = zT_15;
    zT_16 = zF_50C274AF_stringInternerInter(zT_10, zT_11);
    id = zT_16;
    zT_18 = tok.span_start;
    zT_19 = tok.span_len;
    zT_21 = zT_18 + (unsigned int)((unsigned int)zT_19);
    end = zT_21;
    zT_22 = self->store;
    zT_24 = id;
    zT_25 = tok.span_start;
    zT_26 = end;
    zT_32 = zF_1DF77BD4_astStoreAddIdentifi(zT_22, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_24, zT_25, zT_26);
    zT_33.data.payload = zT_32;
    zT_33.is_error = 0;
    return zT_33;
}

/* parserParsePrefixUnary */
zT_3B6EA323_EU_01 zF_BE192524_parserParsePrefixUn(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned short zT_14;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_8143F551_AstKind zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_27;
    int zT_30;
    int zT_32;
    int zT_34;
    unsigned int zT_36 = 0;
    zT_3B6EA323_EU_01 zT_37;
    zT_3A355BD2_Token tok;
    unsigned int operand;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = self;
    zT_9 = zF_F07C1F04_parserParseExprPrec(zT_6, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    operand = zT_11;
    zT_13 = tok.span_start;
    zT_14 = tok.span_len;
    zT_16 = zT_13 + (unsigned int)((unsigned int)zT_14);
    end = zT_16;
    zT_17 = self->store;
    zT_18 = kind;
    zT_27 = 0;
    zT_20 = tok.span_start;
    zT_21 = end;
    zT_22 = operand;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = zF_6C9FF72F_astStoreAddNode(zT_17, zT_18, (unsigned char)((unsigned char)zT_27), zT_20, zT_21, zT_22, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34));
    zT_37.data.payload = zT_36;
    zT_37.is_error = 0;
    return zT_37;
}

/* parserParseGroupedExpr */
zT_3B6EA323_EU_01 zF_C5DF83EE_parserParseGroupedE(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_17 = {0};
    unsigned char zT_18;
    int zT_19;
    zT_3B6EA323_EU_01 zT_20;
    zT_2B3424E9_ParseToken zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_25;
    unsigned int zT_27;
    int zT_35;
    unsigned int zT_38;
    unsigned short zT_39;
    int zT_42;
    int zT_44;
    int zT_46;
    unsigned int zT_48 = 0;
    zT_3B6EA323_EU_01 zT_49;
    zT_3A355BD2_Token lparen;
    unsigned int inner;
    zT_2B3424E9_ParseToken rparen;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    lparen = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = self;
    zT_17 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = zT_17.data.err;
    zT_20.data.err = zT_19;
    zT_20.is_error = 1;
    return zT_20;
    z_bb_5:
    zT_21 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    rparen = zT_21;
    zT_22 = self->store;
    zT_35 = 0;
    zT_25 = lparen.span_start;
    zT_38 = rparen.span_start;
    zT_39 = rparen.span_len;
    zT_27 = inner;
    zT_42 = 0;
    zT_44 = 0;
    zT_46 = 0;
    zT_48 = zF_6C9FF72F_astStoreAddNode(zT_22, (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr), (unsigned char)((unsigned char)zT_35), zT_25, (unsigned int)(zT_38 + (unsigned int)((unsigned int)zT_39)), zT_27, (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44), (unsigned int)((unsigned int)zT_46));
    zT_49.data.payload = zT_48;
    zT_49.is_error = 0;
    return zT_49;
}

/* parserParseBuiltinCall */
zT_3B6EA323_EU_01 zF_5D650338_parserParseBuiltinC(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_85CBA4DB_TokenValue zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_8;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11;
    zT_3B6EA323_EU_01 zT_12 = {0};
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned short zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_B559F9DA_Parser* zT_33;
    zT_3A355BD2_Token zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_DBF3575C_ParserError zT_36;
    zT_3B6EA323_EU_01 zT_37;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    unsigned int zT_41;
    zT_B559F9DA_Parser* zT_43;
    zT_3A355BD2_Token zT_44 = {0};
    zT_EAC3E484_TokenKind zT_45;
    zT_B559F9DA_Parser* zT_51;
    zT_3A355BD2_Token zT_52 = {0};
    unsigned char zT_54;
    zT_EAC3E484_TokenKind zT_55;
    unsigned char zT_60;
    zT_EAC3E484_TokenKind zT_61;
    unsigned char zT_66;
    zT_EAC3E484_TokenKind zT_67;
    unsigned char zT_72;
    zT_EAC3E484_TokenKind zT_73;
    unsigned char zT_78;
    zT_EAC3E484_TokenKind zT_79;
    unsigned char zT_84;
    zT_EAC3E484_TokenKind zT_85;
    unsigned char zT_90;
    zT_EAC3E484_TokenKind zT_91;
    unsigned char zT_96;
    zT_EAC3E484_TokenKind zT_97;
    unsigned char zT_102;
    zT_EAC3E484_TokenKind zT_103;
    unsigned char zT_108;
    zT_EAC3E484_TokenKind zT_109;
    unsigned char zT_114;
    zT_B559F9DA_Parser* zT_118;
    zT_3B6EA323_EU_01 zT_119 = {0};
    unsigned char zT_120;
    unsigned int zT_121;
    unsigned int** zT_122;
    unsigned int* zT_123;
    unsigned int* zT_124;
    zT_3E40CD83_Sand* zT_125;
    unsigned int zT_126;
    zT_B559F9DA_Parser* zT_132;
    zT_3B6EA323_EU_01 zT_135 = {0};
    unsigned char zT_136;
    unsigned int zT_137;
    unsigned int** zT_138;
    unsigned int* zT_139;
    unsigned int* zT_140;
    zT_3E40CD83_Sand* zT_141;
    unsigned int zT_142;
    zT_B559F9DA_Parser* zT_147;
    zT_3A355BD2_Token zT_148 = {0};
    zT_EAC3E484_TokenKind zT_149;
    zT_B559F9DA_Parser* zT_154;
    zT_CB78802F_EU_49 zT_159 = {0};
    unsigned char zT_160;
    int zT_161;
    zT_3B6EA323_EU_01 zT_162;
    zT_2B3424E9_ParseToken zT_163;
    zT_B559F9DA_Parser* zT_165;
    zT_3A355BD2_Token zT_166 = {0};
    unsigned int zT_167;
    unsigned short zT_168;
    unsigned int zT_170;
    int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_6B0A7D14_AstStore* zT_176;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_177;
    unsigned int* zT_179;
    unsigned int zT_180;
    unsigned int* zT_181;
    unsigned int zT_182;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_183;
    unsigned int zT_184 = 0;
    zT_6B0A7D14_AstStore* zT_185;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_193;
    int zT_198;
    int zT_201;
    int zT_203;
    unsigned int zT_205 = 0;
    zT_3B6EA323_EU_01 zT_206;
    zT_3A355BD2_Token tok;
    unsigned int id;
    unsigned int end;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    unsigned int saved_builtin;
    zT_3A355BD2_Token rparen;
    unsigned int payload;
    unsigned char is_type;
    unsigned int arg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = tok.value;
    zT_5 = zT_4.string_id;
    zT_6 = self->builtin_import_id;
    if ((int)(zT_5 == zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_8);
    zT_10 = self;
    zT_11 = tok;
    zT_12 = zF_D258E86B_parserParseImportEx(zT_10, zT_11);
    return zT_12;
    z_bb_2:
    zT_14 = tok.value;
    zT_15 = zT_14.string_id;
    id = zT_15;
    zT_17 = tok.span_start;
    zT_18 = tok.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    lparen = zT_23;
    zT_24 = lparen.kind;
    if ((int)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = "expected '(' after builtin name";
    zT_32 = 31;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    exp_s = zT_31;
    zT_33 = self;
    zT_34 = lparen;
    zT_35 = exp_s;
    zF_17DF2CA5_parserAddError(zT_33, zT_34, zT_35);
    zT_36 = 1;
    zT_37.data.err = zT_36;
    zT_37.is_error = 1;
    return zT_37;
    z_bb_4:
    zT_38 = self;
    zT_39 = zF_C241B2C4_parserAdvance(zT_38);
    (void)zT_39;
    zT_41 = self->child_buf_len;
    saved_builtin = zT_41;
    goto z_bb_5;
    z_bb_5:
    if ((int)(1)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_43 = self;
    zT_44 = zF_068A2DE5_parserPeek(zT_43);
    zT_45 = zT_44.kind;
    if ((int)(zT_45 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_165 = self;
    zT_166 = zF_C241B2C4_parserAdvance(zT_165);
    rparen = zT_166;
    zT_167 = rparen.span_start;
    zT_168 = rparen.span_len;
    zT_170 = zT_167 + (unsigned int)((unsigned int)zT_168);
    end = zT_170;
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    payload = zT_173;
    zT_174 = self->child_buf_len;
    if ((int)(zT_174 > saved_builtin)) goto z_bb_45; else goto z_bb_46;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    zT_51 = self;
    zT_52 = zF_068A2DE5_parserPeek(zT_51);
    tok = zT_52;
    zT_54 = 0;
    is_type = zT_54;
    zT_55 = tok.kind;
    if ((int)(zT_55 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_60 = 1;
    is_type = zT_60;
    goto z_bb_12;
    z_bb_12:
    zT_61 = tok.kind;
    if ((int)(zT_61 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_66 = 1;
    is_type = zT_66;
    goto z_bb_14;
    z_bb_14:
    zT_67 = tok.kind;
    if ((int)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_72 = 1;
    is_type = zT_72;
    goto z_bb_16;
    z_bb_16:
    zT_73 = tok.kind;
    if ((int)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_78 = 1;
    is_type = zT_78;
    goto z_bb_18;
    z_bb_18:
    zT_79 = tok.kind;
    if ((int)(zT_79 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_84 = 1;
    is_type = zT_84;
    goto z_bb_20;
    z_bb_20:
    zT_85 = tok.kind;
    if ((int)(zT_85 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_90 = 1;
    is_type = zT_90;
    goto z_bb_22;
    z_bb_22:
    zT_91 = tok.kind;
    if ((int)(zT_91 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_96 = 1;
    is_type = zT_96;
    goto z_bb_24;
    z_bb_24:
    zT_97 = tok.kind;
    if ((int)(zT_97 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_102 = 1;
    is_type = zT_102;
    goto z_bb_26;
    z_bb_26:
    zT_103 = tok.kind;
    if ((int)(zT_103 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_108 = 1;
    is_type = zT_108;
    goto z_bb_28;
    z_bb_28:
    zT_109 = tok.kind;
    if ((int)(zT_109 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_114 = 1;
    is_type = zT_114;
    goto z_bb_30;
    z_bb_30:
    if ((int)(is_type != (unsigned char)(0))) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_118 = self;
    zT_119 = zF_CBDBFE85_parserParseType(zT_118);
    zT_120 = zT_119.is_error;
    if (zT_120) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    zT_147 = self;
    zT_148 = zF_068A2DE5_parserPeek(zT_147);
    zT_149 = zT_148.kind;
    if ((int)(zT_149 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_40; else goto z_bb_41;
    z_bb_33:
    zT_132 = self;
    zT_135 = zF_F07C1F04_parserParseExprPrec(zT_132, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_136 = zT_135.is_error;
    if (zT_136) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    return zT_119;
    z_bb_35:
    zT_121 = zT_119.data.payload;
    goto z_bb_36;
    z_bb_36:
    arg = zT_121;
    zT_122 = &self->child_buf_items;
    zT_123 = &self->child_buf_len;
    zT_124 = &self->child_buf_capacity;
    zT_125 = self->allocator;
    zT_126 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_122, zT_123, zT_124, zT_125, zT_126);
    goto z_bb_32;
    z_bb_37:
    return zT_135;
    z_bb_38:
    zT_137 = zT_135.data.payload;
    goto z_bb_39;
    z_bb_39:
    arg = zT_137;
    zT_138 = &self->child_buf_items;
    zT_139 = &self->child_buf_len;
    zT_140 = &self->child_buf_capacity;
    zT_141 = self->allocator;
    zT_142 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_138, zT_139, zT_140, zT_141, zT_142);
    goto z_bb_32;
    z_bb_40:
    goto z_bb_7;
    z_bb_41:
    zT_154 = self;
    zT_159 = zF_5578C74F_parserExpect(zT_154, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_160 = zT_159.is_error;
    if (zT_160) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_161 = zT_159.data.err;
    zT_162.data.err = zT_161;
    zT_162.is_error = 1;
    return zT_162;
    z_bb_43:
    zT_163 = zT_159.data.payload;
    goto z_bb_44;
    z_bb_44:
    (void)zT_163;
    goto z_bb_8;
    z_bb_45:
    zT_176 = self->store;
    zT_179 = self->child_buf_items;
    zT_180 = self->child_buf_len;
    zT_181 = zT_179 + saved_builtin;
    zT_182 = zT_180 - saved_builtin;
    zT_183.ptr = zT_181;
    zT_183.len = zT_182;
    zT_177 = zT_183;
    zT_184 = zF_583E993C_astStoreAddExtraChi(zT_176, zT_177);
    payload = zT_184;
    goto z_bb_46;
    z_bb_46:
    self->child_buf_len = saved_builtin;
    zT_185 = self->store;
    zT_198 = 0;
    zT_188 = tok.span_start;
    zT_189 = end;
    zT_190 = id;
    zT_201 = 0;
    zT_203 = 0;
    zT_193 = payload;
    zT_205 = zF_6C9FF72F_astStoreAddNode(zT_185, (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call), (unsigned char)((unsigned char)zT_198), zT_188, zT_189, zT_190, (unsigned int)((unsigned int)zT_201), (unsigned int)((unsigned int)zT_203), zT_193);
    zT_206.data.payload = zT_205;
    zT_206.is_error = 0;
    return zT_206;
}

/* parserParseImportExpr */
zT_3B6EA323_EU_01 zF_D258E86B_parserParseImportEx(zT_B559F9DA_Parser* self, zT_3A355BD2_Token bi_tok) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_DBF3575C_ParserError zT_17;
    zT_3B6EA323_EU_01 zT_18;
    zT_B559F9DA_Parser* zT_19;
    zT_3A355BD2_Token zT_20 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_B559F9DA_Parser* zT_33;
    zT_3A355BD2_Token zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_DBF3575C_ParserError zT_36;
    zT_3B6EA323_EU_01 zT_37;
    zT_85CBA4DB_TokenValue zT_39;
    unsigned int zT_40;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_B559F9DA_Parser* zT_55;
    zT_3A355BD2_Token zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_DBF3575C_ParserError zT_58;
    zT_3B6EA323_EU_01 zT_59;
    unsigned int zT_61;
    unsigned short zT_62;
    unsigned int zT_64;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_7334F4FE_Opt_225 zT_67;
    unsigned char zT_68;
    zT_6A32A83C_Opt_238 zT_70;
    unsigned char zT_71;
    zT_3E40CD83_Sand* zT_73;
    zT_072B53A6_ModuleRegistry* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_3E40CD83_Sand* zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_89;
    int zT_94;
    int zT_97;
    int zT_99;
    int zT_101;
    unsigned int zT_103 = 0;
    zT_3B6EA323_EU_01 zT_104;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token path_tok;
    unsigned int path_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_072B53A6_ModuleRegistry* reg;
    zT_3E40CD83_Sand* is;
    zT_BAEE192E_Opt_10 resolved;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    lparen = zT_4;
    zT_5 = lparen.kind;
    if ((int)(zT_5 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = "expected '(' after @import";
    zT_13 = 26;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    exp_s = zT_12;
    zT_14 = self;
    zT_15 = lparen;
    zT_16 = exp_s;
    zF_17DF2CA5_parserAddError(zT_14, zT_15, zT_16);
    zT_17 = 1;
    zT_18.data.err = zT_17;
    zT_18.is_error = 1;
    return zT_18;
    z_bb_2:
    zT_19 = self;
    zT_20 = zF_C241B2C4_parserAdvance(zT_19);
    (void)zT_20;
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    path_tok = zT_23;
    zT_24 = path_tok.kind;
    if ((int)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = "expected string literal for @import path";
    zT_32 = 40;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    exp_s = zT_31;
    zT_33 = self;
    zT_34 = path_tok;
    zT_35 = exp_s;
    zF_17DF2CA5_parserAddError(zT_33, zT_34, zT_35);
    zT_36 = 1;
    zT_37.data.err = zT_36;
    zT_37.is_error = 1;
    return zT_37;
    z_bb_4:
    zT_39 = path_tok.value;
    zT_40 = zT_39.string_id;
    path_id = zT_40;
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    zT_44 = self;
    zT_45 = zF_068A2DE5_parserPeek(zT_44);
    rparen = zT_45;
    zT_46 = rparen.kind;
    if ((int)(zT_46 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_52 = "expected ')' after @import path";
    zT_54 = 31;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    exp_s = zT_53;
    zT_55 = self;
    zT_56 = rparen;
    zT_57 = exp_s;
    zF_17DF2CA5_parserAddError(zT_55, zT_56, zT_57);
    zT_58 = 1;
    zT_59.data.err = zT_58;
    zT_59.is_error = 1;
    return zT_59;
    z_bb_6:
    zT_61 = rparen.span_start;
    zT_62 = rparen.span_len;
    zT_64 = zT_61 + (unsigned int)((unsigned int)zT_62);
    end_pos = zT_64;
    zT_65 = self;
    zT_66 = zF_C241B2C4_parserAdvance(zT_65);
    (void)zT_66;
    zT_67 = self->module_reg;
    zT_68 = zT_67.has_value;
    if (zT_68) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    reg = zT_67.value;
    zT_70 = self->import_scratch;
    zT_71 = zT_70.has_value;
    if (zT_71) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_81 = self->store;
    zT_94 = 0;
    zT_84 = bi_tok.span_start;
    zT_85 = end_pos;
    zT_97 = 0;
    zT_99 = 0;
    zT_101 = 0;
    zT_89 = path_id;
    zT_103 = zF_6C9FF72F_astStoreAddNode(zT_81, (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr), (unsigned char)((unsigned char)zT_94), zT_84, zT_85, (unsigned int)((unsigned int)zT_97), (unsigned int)((unsigned int)zT_99), (unsigned int)((unsigned int)zT_101), zT_89);
    zT_104.data.payload = zT_103;
    zT_104.is_error = 0;
    return zT_104;
    z_bb_9:
    is = zT_70.value;
    zT_73 = is;
    zF_F1B3F8C2_sandReset(zT_73);
    zT_75 = reg;
    zT_76 = path_id;
    zT_77 = self->current_module_id;
    zT_78 = is;
    zT_80 = zF_620E3E3B_moduleRegistryResol(zT_75, zT_76, zT_77, zT_78);
    resolved = zT_80;
    (void)resolved;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* parserParseCInclude */
zT_3B6EA323_EU_01 zF_C531682A_parserParseCInclude(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_DBF3575C_ParserError zT_19;
    zT_3B6EA323_EU_01 zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_EAC3E484_TokenKind zT_26;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_DBF3575C_ParserError zT_38;
    zT_3B6EA323_EU_01 zT_39;
    zT_85CBA4DB_TokenValue zT_41;
    unsigned int zT_42;
    zT_B559F9DA_Parser* zT_43;
    zT_3A355BD2_Token zT_44 = {0};
    zT_B559F9DA_Parser* zT_46;
    zT_3A355BD2_Token zT_47 = {0};
    zT_EAC3E484_TokenKind zT_48;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_B559F9DA_Parser* zT_57;
    zT_3A355BD2_Token zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_DBF3575C_ParserError zT_60;
    zT_3B6EA323_EU_01 zT_61;
    unsigned int zT_63;
    unsigned short zT_64;
    unsigned int zT_66;
    zT_B559F9DA_Parser* zT_67;
    zT_3A355BD2_Token zT_68 = {0};
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_77;
    int zT_82;
    int zT_85;
    int zT_87;
    int zT_89;
    unsigned int zT_91 = 0;
    zT_3B6EA323_EU_01 zT_92;
    zT_3A355BD2_Token bi_tok;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token name_tok;
    unsigned int name_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    bi_tok = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    lparen = zT_6;
    zT_7 = lparen.kind;
    if ((int)(zT_7 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "expected '(' after @cInclude";
    zT_15 = 28;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    exp_s = zT_14;
    zT_16 = self;
    zT_17 = lparen;
    zT_18 = exp_s;
    zF_17DF2CA5_parserAddError(zT_16, zT_17, zT_18);
    zT_19 = 1;
    zT_20.data.err = zT_19;
    zT_20.is_error = 1;
    return zT_20;
    z_bb_2:
    zT_21 = self;
    zT_22 = zF_C241B2C4_parserAdvance(zT_21);
    (void)zT_22;
    zT_24 = self;
    zT_25 = zF_068A2DE5_parserPeek(zT_24);
    name_tok = zT_25;
    zT_26 = name_tok.kind;
    if ((int)(zT_26 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_32 = "expected string literal for @cInclude name";
    zT_34 = 42;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    exp_s = zT_33;
    zT_35 = self;
    zT_36 = name_tok;
    zT_37 = exp_s;
    zF_17DF2CA5_parserAddError(zT_35, zT_36, zT_37);
    zT_38 = 1;
    zT_39.data.err = zT_38;
    zT_39.is_error = 1;
    return zT_39;
    z_bb_4:
    zT_41 = name_tok.value;
    zT_42 = zT_41.string_id;
    name_id = zT_42;
    zT_43 = self;
    zT_44 = zF_C241B2C4_parserAdvance(zT_43);
    (void)zT_44;
    zT_46 = self;
    zT_47 = zF_068A2DE5_parserPeek(zT_46);
    rparen = zT_47;
    zT_48 = rparen.kind;
    if ((int)(zT_48 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_54 = "expected ')' after @cInclude name";
    zT_56 = 33;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    exp_s = zT_55;
    zT_57 = self;
    zT_58 = rparen;
    zT_59 = exp_s;
    zF_17DF2CA5_parserAddError(zT_57, zT_58, zT_59);
    zT_60 = 1;
    zT_61.data.err = zT_60;
    zT_61.is_error = 1;
    return zT_61;
    z_bb_6:
    zT_63 = rparen.span_start;
    zT_64 = rparen.span_len;
    zT_66 = zT_63 + (unsigned int)((unsigned int)zT_64);
    end_pos = zT_66;
    zT_67 = self;
    zT_68 = zF_C241B2C4_parserAdvance(zT_67);
    (void)zT_68;
    zT_69 = self->store;
    zT_82 = 0;
    zT_72 = bi_tok.span_start;
    zT_73 = end_pos;
    zT_85 = 0;
    zT_87 = 0;
    zT_89 = 0;
    zT_77 = name_id;
    zT_91 = zF_6C9FF72F_astStoreAddNode(zT_69, (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include), (unsigned char)((unsigned char)zT_82), zT_72, zT_73, (unsigned int)((unsigned int)zT_85), (unsigned int)((unsigned int)zT_87), (unsigned int)((unsigned int)zT_89), zT_77);
    zT_92.data.payload = zT_91;
    zT_92.is_error = 0;
    return zT_92;
}

/* parserParseErrorLiteral */
zT_3B6EA323_EU_01 zF_AC24A2A0_parserParseErrorLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13;
    zT_3B6EA323_EU_01 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_16;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_EAC3E484_TokenKind zT_19;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_B559F9DA_Parser* zT_27;
    zT_3B6EA323_EU_01 zT_28 = {0};
    unsigned char zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    int zT_44;
    unsigned int zT_47;
    unsigned short zT_48;
    int zT_51;
    int zT_53;
    unsigned int zT_55 = 0;
    zT_3B6EA323_EU_01 zT_56;
    zT_3B6EA323_EU_01 zT_57;
    zT_B559F9DA_Parser* zT_58;
    zT_CB78802F_EU_49 zT_63 = {0};
    unsigned char zT_64;
    int zT_65;
    zT_3B6EA323_EU_01 zT_66;
    zT_2B3424E9_ParseToken zT_67;
    zT_B559F9DA_Parser* zT_69;
    zT_CB78802F_EU_49 zT_74 = {0};
    unsigned char zT_75;
    int zT_76;
    zT_3B6EA323_EU_01 zT_77;
    zT_2B3424E9_ParseToken zT_78;
    zT_2B3424E9_ParseToken zT_80;
    zT_EAC3E484_TokenKind zT_81;
    unsigned int zT_82;
    unsigned short zT_83;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_B559F9DA_Parser* zT_88;
    zT_2B3424E9_ParseToken zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90 = {0};
    unsigned int zT_91 = 0;
    unsigned int zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_105;
    int zT_110;
    int zT_113;
    int zT_115;
    int zT_117;
    unsigned int zT_119 = 0;
    zT_3B6EA323_EU_01 zT_120;
    zT_3A355BD2_Token kw;
    unsigned int es;
    unsigned int eu_payload;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((int)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = kw;
    zT_14 = zF_2C55CABB_parserParseErrorSet(zT_12, zT_13);
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_58 = self;
    zT_63 = zF_5578C74F_parserExpect(zT_58, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot));
    zT_64 = zT_63.is_error;
    if (zT_64) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    return zT_14;
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    es = zT_16;
    zT_17 = self;
    zT_18 = zF_068A2DE5_parserPeek(zT_17);
    zT_19 = zT_18.kind;
    if ((int)(zT_19 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = self;
    zT_25 = zF_C241B2C4_parserAdvance(zT_24);
    (void)zT_25;
    zT_27 = self;
    zT_28 = zF_CBDBFE85_parserParseType(zT_27);
    zT_29 = zT_28.is_error;
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_57.data.payload = es;
    zT_57.is_error = 0;
    return zT_57;
    z_bb_8:
    return zT_28;
    z_bb_9:
    zT_30 = zT_28.data.payload;
    goto z_bb_10;
    z_bb_10:
    eu_payload = zT_30;
    zT_31 = self->store;
    zT_44 = 0;
    zT_34 = kw.span_start;
    zT_47 = kw.span_start;
    zT_48 = kw.span_len;
    zT_36 = es;
    zT_37 = eu_payload;
    zT_51 = 0;
    zT_53 = 0;
    zT_55 = zF_6C9FF72F_astStoreAddNode(zT_31, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_44), zT_34, (unsigned int)(zT_47 + (unsigned int)((unsigned int)zT_48)), zT_36, zT_37, (unsigned int)((unsigned int)zT_51), (unsigned int)((unsigned int)zT_53));
    zT_56.data.payload = zT_55;
    zT_56.is_error = 0;
    return zT_56;
    z_bb_11:
    zT_65 = zT_63.data.err;
    zT_66.data.err = zT_65;
    zT_66.is_error = 1;
    return zT_66;
    z_bb_12:
    zT_67 = zT_63.data.payload;
    goto z_bb_13;
    z_bb_13:
    (void)zT_67;
    zT_69 = self;
    zT_74 = zF_5578C74F_parserExpect(zT_69, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_76 = zT_74.data.err;
    zT_77.data.err = zT_76;
    zT_77.is_error = 1;
    return zT_77;
    z_bb_15:
    zT_78 = zT_74.data.payload;
    goto z_bb_16;
    z_bb_16:
    name_tok = zT_78;
    zT_81 = name_tok.kind;
    zT_80.kind = zT_81;
    zT_82 = name_tok.span_start;
    zT_80.span_start = zT_82;
    zT_83 = name_tok.span_len;
    zT_80.span_len = zT_83;
    pt = zT_80;
    zT_85 = self->interner;
    zT_88 = self;
    zT_89 = pt;
    zT_90 = zF_08D61E58_parserTokenText(zT_88, zT_89);
    zT_86 = zT_90;
    zT_91 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    name_id = zT_91;
    zT_93 = name_tok.span_start;
    zT_94 = name_tok.span_len;
    zT_96 = zT_93 + (unsigned int)((unsigned int)zT_94);
    end = zT_96;
    zT_97 = self->store;
    zT_110 = 0;
    zT_100 = kw.span_start;
    zT_101 = end;
    zT_113 = 0;
    zT_115 = 0;
    zT_117 = 0;
    zT_105 = name_id;
    zT_119 = zF_6C9FF72F_astStoreAddNode(zT_97, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal), (unsigned char)((unsigned char)zT_110), zT_100, zT_101, (unsigned int)((unsigned int)zT_113), (unsigned int)((unsigned int)zT_115), (unsigned int)((unsigned int)zT_117), zT_105);
    zT_120.data.payload = zT_119;
    zT_120.is_error = 0;
    return zT_120;
}

/* parserParseTryExpr */
zT_3B6EA323_EU_01 zF_59C88921_parserParseTryExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned short zT_13;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_3B6EA323_EU_01 zT_39;
    zT_3A355BD2_Token kw;
    unsigned int inner;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = kw.span_start;
    zT_13 = kw.span_len;
    zT_15 = zT_12 + (unsigned int)((unsigned int)zT_13);
    end_pos = zT_15;
    zT_16 = self->store;
    zT_29 = 0;
    zT_19 = kw.span_start;
    zT_20 = end_pos;
    zT_21 = inner;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_16, (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr), (unsigned char)((unsigned char)zT_29), zT_19, zT_20, zT_21, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    zT_39.data.payload = zT_38;
    zT_39.is_error = 0;
    return zT_39;
}

/* parserParseAnonymousLiteral */
zT_3B6EA323_EU_01 zF_9A508F9D_parserParseAnonymou(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    int zT_12;
    zT_EAC3E484_TokenKind zT_13;
    zT_B559F9DA_Parser* zT_19;
    zT_3B6EA323_EU_01 zT_20 = {0};
    unsigned char zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_31;
    int zT_36;
    int zT_40;
    int zT_42;
    int zT_44;
    unsigned int zT_46 = 0;
    zT_3B6EA323_EU_01 zT_47;
    unsigned int zT_49;
    zT_B559F9DA_Parser* zT_50;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_52;
    int zT_57;
    zT_B559F9DA_Parser* zT_58;
    zT_3A355BD2_Token zT_59 = {0};
    zT_EAC3E484_TokenKind zT_60;
    zT_B559F9DA_Parser* zT_66;
    zT_3B6EA323_EU_01 zT_69 = {0};
    unsigned char zT_70;
    unsigned int zT_71;
    unsigned int** zT_72;
    unsigned int* zT_73;
    unsigned int* zT_74;
    zT_3E40CD83_Sand* zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_81;
    zT_3A355BD2_Token zT_82 = {0};
    zT_EAC3E484_TokenKind zT_83;
    zT_B559F9DA_Parser* zT_88;
    zT_3A355BD2_Token zT_89 = {0};
    zT_B559F9DA_Parser* zT_91;
    zT_CB78802F_EU_49 zT_96 = {0};
    unsigned char zT_97;
    int zT_98;
    zT_3B6EA323_EU_01 zT_99;
    zT_2B3424E9_ParseToken zT_100;
    int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_106;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_107;
    unsigned int* zT_109;
    unsigned int zT_110;
    unsigned int* zT_111;
    unsigned int zT_112;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_113;
    unsigned int zT_114 = 0;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_118;
    unsigned int zT_123;
    int zT_128;
    unsigned int zT_131;
    unsigned short zT_132;
    int zT_135;
    int zT_137;
    int zT_139;
    unsigned int zT_141 = 0;
    zT_3B6EA323_EU_01 zT_142;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token peek;
    unsigned int payload;
    unsigned int saved_child_len;
    unsigned int val;
    zT_2B3424E9_ParseToken rbrace;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    peek = zT_6;
    zT_7 = peek.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_13 = peek.kind;
    zT_12 = zT_13 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_3;
    z_bb_2:
    zT_12 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = self;
    zT_20 = zF_D1EA41E6_parserParseFieldIni(zT_19);
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_49 = self->child_buf_len;
    saved_child_len = zT_49;
    goto z_bb_9;
    z_bb_6:
    return zT_20;
    z_bb_7:
    zT_22 = zT_20.data.payload;
    goto z_bb_8;
    z_bb_8:
    payload = zT_22;
    zT_23 = self->store;
    zT_36 = 0;
    zT_26 = dot.span_start;
    zT_27 = self->last_end;
    zT_40 = 0;
    zT_42 = 0;
    zT_44 = 0;
    zT_31 = payload;
    zT_46 = zF_6C9FF72F_astStoreAddNode(zT_23, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_36), zT_26, zT_27, (unsigned int)((unsigned int)zT_40), (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44), zT_31);
    zT_47.data.payload = zT_46;
    zT_47.is_error = 0;
    return zT_47;
    z_bb_9:
    zT_50 = self;
    zT_51 = zF_068A2DE5_parserPeek(zT_50);
    zT_52 = zT_51.kind;
    if ((int)(zT_52 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_66 = self;
    zT_69 = zF_F07C1F04_parserParseExprPrec(zT_66, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_70 = zT_69.is_error;
    if (zT_70) goto z_bb_16; else goto z_bb_17;
    z_bb_11:
    zT_91 = self;
    zT_96 = zF_5578C74F_parserExpect(zT_91, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_97 = zT_96.is_error;
    if (zT_97) goto z_bb_21; else goto z_bb_22;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_58 = self;
    zT_59 = zF_068A2DE5_parserPeek(zT_58);
    zT_60 = zT_59.kind;
    zT_57 = zT_60 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_15;
    z_bb_14:
    zT_57 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_57) goto z_bb_10; else goto z_bb_11;
    z_bb_16:
    return zT_69;
    z_bb_17:
    zT_71 = zT_69.data.payload;
    goto z_bb_18;
    z_bb_18:
    val = zT_71;
    zT_72 = &self->child_buf_items;
    zT_73 = &self->child_buf_len;
    zT_74 = &self->child_buf_capacity;
    zT_75 = self->allocator;
    zT_76 = val;
    zF_8B163A32_u32ArrayListAppendI(zT_72, zT_73, zT_74, zT_75, zT_76);
    zT_81 = self;
    zT_82 = zF_068A2DE5_parserPeek(zT_81);
    zT_83 = zT_82.kind;
    if ((int)(zT_83 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_88 = self;
    zT_89 = zF_C241B2C4_parserAdvance(zT_88);
    (void)zT_89;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_98 = zT_96.data.err;
    zT_99.data.err = zT_98;
    zT_99.is_error = 1;
    return zT_99;
    z_bb_22:
    zT_100 = zT_96.data.payload;
    goto z_bb_23;
    z_bb_23:
    rbrace = zT_100;
    zT_102 = 0;
    zT_103 = (unsigned int)zT_102;
    payload = zT_103;
    zT_104 = self->child_buf_len;
    if ((int)(zT_104 > saved_child_len)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_106 = self->store;
    zT_109 = self->child_buf_items;
    zT_110 = self->child_buf_len;
    zT_111 = zT_109 + saved_child_len;
    zT_112 = zT_110 - saved_child_len;
    zT_113.ptr = zT_111;
    zT_113.len = zT_112;
    zT_107 = zT_113;
    zT_114 = zF_583E993C_astStoreAddExtraChi(zT_106, zT_107);
    payload = zT_114;
    goto z_bb_25;
    z_bb_25:
    self->child_buf_len = saved_child_len;
    zT_115 = self->store;
    zT_128 = 0;
    zT_118 = dot.span_start;
    zT_131 = rbrace.span_start;
    zT_132 = rbrace.span_len;
    zT_135 = 0;
    zT_137 = 0;
    zT_139 = 0;
    zT_123 = payload;
    zT_141 = zF_6C9FF72F_astStoreAddNode(zT_115, (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal), (unsigned char)((unsigned char)zT_128), zT_118, (unsigned int)(zT_131 + (unsigned int)((unsigned int)zT_132)), (unsigned int)((unsigned int)zT_135), (unsigned int)((unsigned int)zT_137), (unsigned int)((unsigned int)zT_139), zT_123);
    zT_142.data.payload = zT_141;
    zT_142.is_error = 0;
    return zT_142;
}

/* parserParseEnumLiteral */
zT_3B6EA323_EU_01 zF_BD525F87_parserParseEnumLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_B559F9DA_Parser* zT_7;
    zT_CB78802F_EU_49 zT_12 = {0};
    unsigned char zT_13;
    int zT_14;
    zT_3B6EA323_EU_01 zT_15;
    zT_2B3424E9_ParseToken zT_16;
    unsigned int zT_18;
    unsigned short zT_19;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_85CBA4DB_TokenValue zT_31;
    unsigned int zT_34 = 0;
    zT_3B6EA323_EU_01 zT_35;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token name_tok;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    name_tok = zT_6;
    zT_7 = self;
    zT_12 = zF_5578C74F_parserExpect(zT_7, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_13 = zT_12.is_error;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = zT_12.data.err;
    zT_15.data.err = zT_14;
    zT_15.is_error = 1;
    return zT_15;
    z_bb_2:
    zT_16 = zT_12.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_16;
    zT_18 = name_tok.span_start;
    zT_19 = name_tok.span_len;
    zT_21 = zT_18 + (unsigned int)((unsigned int)zT_19);
    end_pos = zT_21;
    zT_22 = self->store;
    zT_31 = name_tok.value;
    zT_24 = zT_31.string_id;
    zT_25 = dot.span_start;
    zT_26 = end_pos;
    zT_34 = zF_1DF77BD4_astStoreAddIdentifi(zT_22, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal), zT_24, zT_25, zT_26);
    zT_35.data.payload = zT_34;
    zT_35.is_error = 0;
    return zT_35;
}

/* parserParseArrayLiteral */
zT_3B6EA323_EU_01 zF_DE101A45_parserParseArrayLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_3B6EA323_EU_01 zT_16;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    int zT_28;
    zT_B559F9DA_Parser* zT_29;
    zT_3A355BD2_Token zT_30 = {0};
    zT_EAC3E484_TokenKind zT_31;
    zT_B559F9DA_Parser* zT_37;
    zT_3B6EA323_EU_01 zT_40 = {0};
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned int** zT_43;
    unsigned int* zT_44;
    unsigned int* zT_45;
    zT_3E40CD83_Sand* zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53 = {0};
    zT_EAC3E484_TokenKind zT_54;
    zT_B559F9DA_Parser* zT_59;
    zT_3A355BD2_Token zT_60 = {0};
    zT_B559F9DA_Parser* zT_62;
    zT_CB78802F_EU_49 zT_67 = {0};
    unsigned char zT_68;
    int zT_69;
    zT_3B6EA323_EU_01 zT_70;
    zT_2B3424E9_ParseToken zT_71;
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_81;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_82;
    unsigned int* zT_84;
    unsigned int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_88;
    unsigned int zT_89 = 0;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_98;
    int zT_103;
    unsigned int zT_106;
    unsigned short zT_107;
    int zT_110;
    int zT_112;
    unsigned int zT_114 = 0;
    zT_3B6EA323_EU_01 zT_115;
    zT_3A355BD2_Token tok;
    unsigned int type_node;
    unsigned int saved_child_len;
    unsigned int val;
    zT_2B3424E9_ParseToken rbrace;
    zT_8F083A69_Slice_zT_0B42B2F8_u gap;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_2BC32683_parserParseBracketT(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    type_node = zT_8;
    zT_9 = self;
    zT_10 = zF_068A2DE5_parserPeek(zT_9);
    zT_11 = zT_10.kind;
    if ((int)(zT_11 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16.data.payload = type_node;
    zT_16.is_error = 0;
    return zT_16;
    z_bb_5:
    zT_17 = self;
    zT_18 = zF_C241B2C4_parserAdvance(zT_17);
    (void)zT_18;
    zT_20 = self->child_buf_len;
    saved_child_len = zT_20;
    goto z_bb_6;
    z_bb_6:
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    zT_23 = zT_22.kind;
    if ((int)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_10; else goto z_bb_11;
    z_bb_7:
    zT_37 = self;
    zT_40 = zF_F07C1F04_parserParseExprPrec(zT_37, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_13; else goto z_bb_14;
    z_bb_8:
    zT_62 = self;
    zT_67 = zF_5578C74F_parserExpect(zT_62, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_68 = zT_67.is_error;
    if (zT_68) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_29 = self;
    zT_30 = zF_068A2DE5_parserPeek(zT_29);
    zT_31 = zT_30.kind;
    zT_28 = zT_31 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_13:
    return zT_40;
    z_bb_14:
    zT_42 = zT_40.data.payload;
    goto z_bb_15;
    z_bb_15:
    val = zT_42;
    zT_43 = &self->child_buf_items;
    zT_44 = &self->child_buf_len;
    zT_45 = &self->child_buf_capacity;
    zT_46 = self->allocator;
    zT_47 = val;
    zF_8B163A32_u32ArrayListAppendI(zT_43, zT_44, zT_45, zT_46, zT_47);
    zT_52 = self;
    zT_53 = zF_068A2DE5_parserPeek(zT_52);
    zT_54 = zT_53.kind;
    if ((int)(zT_54 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_59 = self;
    zT_60 = zF_C241B2C4_parserAdvance(zT_59);
    (void)zT_60;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_9;
    z_bb_18:
    zT_69 = zT_67.data.err;
    zT_70.data.err = zT_69;
    zT_70.is_error = 1;
    return zT_70;
    z_bb_19:
    zT_71 = zT_67.data.payload;
    goto z_bb_20;
    z_bb_20:
    rbrace = zT_71;
    zT_73 = "";
    zT_75 = 0;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    gap = zT_74;
    (void)gap;
    zT_77 = 0;
    zT_78 = (unsigned int)zT_77;
    payload = zT_78;
    zT_79 = self->child_buf_len;
    if ((int)(zT_79 > saved_child_len)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_81 = self->store;
    zT_84 = self->child_buf_items;
    zT_85 = self->child_buf_len;
    zT_86 = zT_84 + saved_child_len;
    zT_87 = zT_85 - saved_child_len;
    zT_88.ptr = zT_86;
    zT_88.len = zT_87;
    zT_82 = zT_88;
    zT_89 = zF_583E993C_astStoreAddExtraChi(zT_81, zT_82);
    payload = zT_89;
    goto z_bb_22;
    z_bb_22:
    self->child_buf_len = saved_child_len;
    zT_90 = self->store;
    zT_103 = 0;
    zT_93 = tok.span_start;
    zT_106 = rbrace.span_start;
    zT_107 = rbrace.span_len;
    zT_95 = type_node;
    zT_110 = 0;
    zT_112 = 0;
    zT_98 = payload;
    zT_114 = zF_6C9FF72F_astStoreAddNode(zT_90, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init), (unsigned char)((unsigned char)zT_103), zT_93, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), zT_95, (unsigned int)((unsigned int)zT_110), (unsigned int)((unsigned int)zT_112), zT_98);
    zT_115.data.payload = zT_114;
    zT_115.is_error = 0;
    return zT_115;
}

/* parserParseIfExpr */
zT_3B6EA323_EU_01 zF_79089D39_parserParseIfExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_CB78802F_EU_49 zT_26 = {0};
    unsigned char zT_27;
    int zT_28;
    zT_3B6EA323_EU_01 zT_29;
    zT_2B3424E9_ParseToken zT_30;
    int zT_32;
    unsigned int zT_33;
    zT_B559F9DA_Parser* zT_34;
    zT_3A355BD2_Token zT_35 = {0};
    zT_EAC3E484_TokenKind zT_36;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_2B3424E9_ParseToken zT_44 = {0};
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_B559F9DA_Parser* zT_52;
    zT_CB78802F_EU_49 zT_57 = {0};
    unsigned char zT_58;
    int zT_59;
    zT_3B6EA323_EU_01 zT_60;
    zT_2B3424E9_ParseToken zT_61;
    zT_B559F9DA_Parser* zT_62;
    zT_CB78802F_EU_49 zT_67 = {0};
    unsigned char zT_68;
    int zT_69;
    zT_3B6EA323_EU_01 zT_70;
    zT_2B3424E9_ParseToken zT_71;
    zT_B559F9DA_Parser* zT_72;
    zT_CB78802F_EU_49 zT_77 = {0};
    unsigned char zT_78;
    int zT_79;
    zT_3B6EA323_EU_01 zT_80;
    zT_2B3424E9_ParseToken zT_81;
    zT_2B3424E9_ParseToken zT_83;
    zT_EAC3E484_TokenKind zT_84;
    unsigned int zT_85;
    unsigned short zT_86;
    zT_D3EB6303_StringInterner* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_B559F9DA_Parser* zT_91;
    zT_2B3424E9_ParseToken zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93 = {0};
    unsigned int zT_94 = 0;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_98;
    unsigned int zT_103;
    int zT_108;
    unsigned int zT_111;
    unsigned short zT_112;
    int zT_115;
    int zT_117;
    int zT_119;
    unsigned int zT_121 = 0;
    zT_B559F9DA_Parser* zT_123;
    zT_3B6EA323_EU_01 zT_126 = {0};
    unsigned char zT_127;
    unsigned int zT_128;
    int zT_130;
    unsigned int zT_131;
    zT_B559F9DA_Parser* zT_132;
    zT_3A355BD2_Token zT_133 = {0};
    zT_EAC3E484_TokenKind zT_134;
    zT_B559F9DA_Parser* zT_139;
    zT_3A355BD2_Token zT_140 = {0};
    zT_B559F9DA_Parser* zT_141;
    zT_3B6EA323_EU_01 zT_144 = {0};
    unsigned char zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    int zT_149;
    zT_3A355BD2_Token zT_151;
    unsigned int zT_152;
    unsigned short zT_153;
    unsigned int zT_155;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    int zT_169;
    unsigned int zT_172 = 0;
    zT_3B6EA323_EU_01 zT_173;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_node;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int then_body;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int else_body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_18;
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_20;
    zT_21 = self;
    zT_26 = zF_5578C74F_parserExpect(zT_21, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = zT_26.data.err;
    zT_29.data.err = zT_28;
    zT_29.is_error = 1;
    return zT_29;
    z_bb_8:
    zT_30 = zT_26.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    capture_node = zT_33;
    zT_34 = self;
    zT_35 = zF_068A2DE5_parserPeek(zT_34);
    zT_36 = zT_35.kind;
    if ((int)(zT_36 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    name_tok = zT_44;
    zT_45 = self;
    zT_46 = zF_068A2DE5_parserPeek(zT_45);
    zT_47 = zT_46.kind;
    if ((int)(zT_47 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_123 = self;
    zT_126 = zF_F07C1F04_parserParseExprPrec(zT_123, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_24; else goto z_bb_25;
    z_bb_12:
    zT_52 = self;
    zT_57 = zF_5578C74F_parserExpect(zT_52, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_58 = zT_57.is_error;
    if (zT_58) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_72 = self;
    zT_77 = zF_5578C74F_parserExpect(zT_72, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_62 = self;
    zT_67 = zF_5578C74F_parserExpect(zT_62, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_68 = zT_67.is_error;
    if (zT_68) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_59 = zT_57.data.err;
    zT_60.data.err = zT_59;
    zT_60.is_error = 1;
    return zT_60;
    z_bb_16:
    zT_61 = zT_57.data.payload;
    goto z_bb_17;
    z_bb_17:
    name_tok = zT_61;
    goto z_bb_13;
    z_bb_18:
    zT_69 = zT_67.data.err;
    zT_70.data.err = zT_69;
    zT_70.is_error = 1;
    return zT_70;
    z_bb_19:
    zT_71 = zT_67.data.payload;
    goto z_bb_20;
    z_bb_20:
    name_tok = zT_71;
    goto z_bb_13;
    z_bb_21:
    zT_79 = zT_77.data.err;
    zT_80.data.err = zT_79;
    zT_80.is_error = 1;
    return zT_80;
    z_bb_22:
    zT_81 = zT_77.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_81;
    zT_84 = name_tok.kind;
    zT_83.kind = zT_84;
    zT_85 = name_tok.span_start;
    zT_83.span_start = zT_85;
    zT_86 = name_tok.span_len;
    zT_83.span_len = zT_86;
    pt = zT_83;
    zT_88 = self->interner;
    zT_91 = self;
    zT_92 = pt;
    zT_93 = zF_08D61E58_parserTokenText(zT_91, zT_92);
    zT_89 = zT_93;
    zT_94 = zF_50C274AF_stringInternerInter(zT_88, zT_89);
    name_id = zT_94;
    zT_95 = self->store;
    zT_108 = 0;
    zT_98 = name_tok.span_start;
    zT_111 = name_tok.span_start;
    zT_112 = name_tok.span_len;
    zT_115 = 0;
    zT_117 = 0;
    zT_119 = 0;
    zT_103 = name_id;
    zT_121 = zF_6C9FF72F_astStoreAddNode(zT_95, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_108), zT_98, (unsigned int)(zT_111 + (unsigned int)((unsigned int)zT_112)), (unsigned int)((unsigned int)zT_115), (unsigned int)((unsigned int)zT_117), (unsigned int)((unsigned int)zT_119), zT_103);
    capture_node = zT_121;
    goto z_bb_11;
    z_bb_24:
    return zT_126;
    z_bb_25:
    zT_128 = zT_126.data.payload;
    goto z_bb_26;
    z_bb_26:
    then_body = zT_128;
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    else_body = zT_131;
    zT_132 = self;
    zT_133 = zF_068A2DE5_parserPeek(zT_132);
    zT_134 = zT_133.kind;
    if ((int)(zT_134 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_139 = self;
    zT_140 = zF_C241B2C4_parserAdvance(zT_139);
    (void)zT_140;
    zT_141 = self;
    zT_144 = zF_F07C1F04_parserParseExprPrec(zT_141, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_145 = zT_144.is_error;
    if (zT_145) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_148 = kw.span_start;
    end_pos = zT_148;
    zT_149 = self->last_tok_valid;
    if (zT_149) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    return zT_144;
    z_bb_30:
    zT_146 = zT_144.data.payload;
    goto z_bb_31;
    z_bb_31:
    else_body = zT_146;
    goto z_bb_28;
    z_bb_32:
    zT_151 = self->last_tok;
    last = zT_151;
    zT_152 = last.span_start;
    zT_153 = last.span_len;
    zT_155 = zT_152 + (unsigned int)((unsigned int)zT_153);
    end_pos = zT_155;
    goto z_bb_33;
    z_bb_33:
    zT_156 = self->store;
    zT_169 = 0;
    zT_159 = kw.span_start;
    zT_160 = end_pos;
    zT_161 = cond;
    zT_162 = then_body;
    zT_163 = else_body;
    zT_164 = capture_node;
    zT_172 = zF_6C9FF72F_astStoreAddNode(zT_156, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr), (unsigned char)((unsigned char)zT_169), zT_159, zT_160, zT_161, zT_162, zT_163, zT_164);
    zT_173.data.payload = zT_172;
    zT_173.is_error = 0;
    return zT_173;
}

/* parserParseSwitchExpr */
zT_3B6EA323_EU_01 zF_A9AC92CA_parserParseSwitchEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_CB78802F_EU_49 zT_26 = {0};
    unsigned char zT_27;
    int zT_28;
    zT_3B6EA323_EU_01 zT_29;
    zT_2B3424E9_ParseToken zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_CB78802F_EU_49 zT_36 = {0};
    unsigned char zT_37;
    int zT_38;
    zT_3B6EA323_EU_01 zT_39;
    zT_2B3424E9_ParseToken zT_40;
    unsigned int zT_42;
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_EAC3E484_TokenKind zT_52;
    zT_B559F9DA_Parser* zT_58;
    zT_3B6EA323_EU_01 zT_59 = {0};
    unsigned char zT_60;
    unsigned int zT_61;
    unsigned int** zT_62;
    unsigned int* zT_63;
    unsigned int* zT_64;
    zT_3E40CD83_Sand* zT_65;
    unsigned int zT_66;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    zT_EAC3E484_TokenKind zT_73;
    zT_B559F9DA_Parser* zT_78;
    zT_3A355BD2_Token zT_79 = {0};
    zT_B559F9DA_Parser* zT_80;
    zT_CB78802F_EU_49 zT_85 = {0};
    unsigned char zT_86;
    int zT_87;
    zT_3B6EA323_EU_01 zT_88;
    zT_2B3424E9_ParseToken zT_89;
    int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6B0A7D14_AstStore* zT_95;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_96;
    unsigned int* zT_98;
    unsigned int zT_99;
    unsigned int* zT_100;
    unsigned int zT_101;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_105;
    unsigned short zT_106;
    unsigned int zT_108;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_118;
    int zT_123;
    int zT_126;
    int zT_128;
    unsigned int zT_130 = 0;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_132;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    int zT_138;
    unsigned char* zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned char* zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_165;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    int zT_171;
    unsigned char* zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned char* zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned char* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    zT_3B6EA323_EU_01 zT_192;
    zT_3A355BD2_Token kw_tok;
    unsigned int cond;
    unsigned int saved_switch;
    zT_3A355BD2_Token tok;
    unsigned int prong;
    unsigned int payload;
    unsigned int end_pos;
    unsigned int pswe_node;
    zT_5A26C2ED_Arr_unsigned_char_1 pswe_b;
    unsigned int pswe_l;
    unsigned int pswe_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 pswe_pb;
    unsigned int pswe_pl;
    unsigned int pswe_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_nl;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw_tok = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_18;
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_20;
    zT_21 = self;
    zT_26 = zF_5578C74F_parserExpect(zT_21, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = zT_26.data.err;
    zT_29.data.err = zT_28;
    zT_29.is_error = 1;
    return zT_29;
    z_bb_8:
    zT_30 = zT_26.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_30;
    zT_31 = self;
    zT_36 = zF_5578C74F_parserExpect(zT_31, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_38 = zT_36.data.err;
    zT_39.data.err = zT_38;
    zT_39.is_error = 1;
    return zT_39;
    z_bb_11:
    zT_40 = zT_36.data.payload;
    goto z_bb_12;
    z_bb_12:
    (void)zT_40;
    zT_42 = self->child_buf_len;
    saved_switch = zT_42;
    goto z_bb_13;
    z_bb_13:
    if ((int)(1)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = self;
    zT_46 = zF_068A2DE5_parserPeek(zT_45);
    tok = zT_46;
    zT_47 = tok.kind;
    if ((int)(zT_47 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    zT_80 = self;
    zT_85 = zF_5578C74F_parserExpect(zT_80, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_86 = zT_85.is_error;
    if (zT_86) goto z_bb_26; else goto z_bb_27;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_52 = tok.kind;
    if ((int)(zT_52 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_58 = self;
    zT_59 = zF_CB4EC4E3_parserParseSwitchPr(zT_58);
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return zT_59;
    z_bb_22:
    zT_61 = zT_59.data.payload;
    goto z_bb_23;
    z_bb_23:
    prong = zT_61;
    zT_62 = &self->child_buf_items;
    zT_63 = &self->child_buf_len;
    zT_64 = &self->child_buf_capacity;
    zT_65 = self->allocator;
    zT_66 = prong;
    zF_8B163A32_u32ArrayListAppendI(zT_62, zT_63, zT_64, zT_65, zT_66);
    zT_71 = self;
    zT_72 = zF_068A2DE5_parserPeek(zT_71);
    zT_73 = zT_72.kind;
    if ((int)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_78 = self;
    zT_79 = zF_C241B2C4_parserAdvance(zT_78);
    (void)zT_79;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_16;
    z_bb_26:
    zT_87 = zT_85.data.err;
    zT_88.data.err = zT_87;
    zT_88.is_error = 1;
    return zT_88;
    z_bb_27:
    zT_89 = zT_85.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_89;
    zT_91 = 0;
    zT_92 = (unsigned int)zT_91;
    payload = zT_92;
    zT_93 = self->child_buf_len;
    if ((int)(zT_93 > saved_switch)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_95 = self->store;
    zT_98 = self->child_buf_items;
    zT_99 = self->child_buf_len;
    zT_100 = zT_98 + saved_switch;
    zT_101 = zT_99 - saved_switch;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zT_103 = zF_583E993C_astStoreAddExtraChi(zT_95, zT_96);
    payload = zT_103;
    goto z_bb_30;
    z_bb_30:
    self->child_buf_len = saved_switch;
    zT_105 = kw_tok.span_start;
    zT_106 = kw_tok.span_len;
    zT_108 = zT_105 + (unsigned int)((unsigned int)zT_106);
    end_pos = zT_108;
    zT_110 = self->store;
    zT_123 = 0;
    zT_113 = kw_tok.span_start;
    zT_114 = end_pos;
    zT_115 = cond;
    zT_126 = 0;
    zT_128 = 0;
    zT_118 = payload;
    zT_130 = zF_6C9FF72F_astStoreAddNode(zT_110, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex), (unsigned char)((unsigned char)zT_123), zT_113, zT_114, zT_115, (unsigned int)((unsigned int)zT_126), (unsigned int)((unsigned int)zT_128), zT_118);
    pswe_node = zT_130;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_132[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pswe_b[_i] = zT_132[_i];
        _i++;
    }
}
    zT_134 = pswe_node;
    zT_138 = 0;
    zT_139 = (unsigned char*)((unsigned char*)pswe_b) + zT_138;
    zT_140 = (unsigned int)(10) - zT_138;
    zT_141.ptr = zT_139;
    zT_141.len = zT_140;
    zT_135 = zT_141;
    zT_142 = zF_A7504564_itoa(zT_134, zT_135);
    pswe_l = zT_142;
    zT_146 = (unsigned int)(9) - (unsigned int)((unsigned int)pswe_l);
    pswe_s = zT_146;
    zT_148 = "PSWE:n";
    zT_150 = 6;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    pswe_m = zT_149;
    zT_151 = pswe_m;
    zF_48AC7B3A_markerWrite(zT_151);
    zT_156 = (unsigned char*)((unsigned char*)pswe_b) + pswe_s;
    zT_157 = (unsigned int)(9) - pswe_s;
    zT_158.ptr = zT_156;
    zT_158.len = zT_157;
    zT_152 = zT_158;
    zF_48AC7B3A_markerWrite(zT_152);
    zT_160 = "p";
    zT_162 = 1;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    pswe_pm = zT_161;
    zT_163 = pswe_pm;
    zF_48AC7B3A_markerWrite(zT_163);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_165[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pswe_pb[_i] = zT_165[_i];
        _i++;
    }
}
    zT_167 = payload;
    zT_171 = 0;
    zT_172 = (unsigned char*)((unsigned char*)pswe_pb) + zT_171;
    zT_173 = (unsigned int)(10) - zT_171;
    zT_174.ptr = zT_172;
    zT_174.len = zT_173;
    zT_168 = zT_174;
    zT_175 = zF_A7504564_itoa(zT_167, zT_168);
    pswe_pl = zT_175;
    zT_179 = (unsigned int)(9) - (unsigned int)((unsigned int)pswe_pl);
    pswe_ps = zT_179;
    zT_184 = (unsigned char*)((unsigned char*)pswe_pb) + pswe_ps;
    zT_185 = (unsigned int)(9) - pswe_ps;
    zT_186.ptr = zT_184;
    zT_186.len = zT_185;
    zT_180 = zT_186;
    zF_48AC7B3A_markerWrite(zT_180);
    zT_188 = "\n";
    zT_190 = 1;
    zT_189.ptr = zT_188;
    zT_189.len = zT_190;
    pswe_nl = zT_189;
    zT_191 = pswe_nl;
    zF_48AC7B3A_markerWrite(zT_191);
    zT_192.data.payload = pswe_node;
    zT_192.is_error = 0;
    return zT_192;
}

/* parserParseSwitchProng */
zT_3B6EA323_EU_01 zF_CB4EC4E3_parserParseSwitchPr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int* zT_5 = 0;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned char zT_14;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    zT_EAC3E484_TokenKind zT_17;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_B559F9DA_Parser* zT_28;
    zT_3A355BD2_Token zT_29 = {0};
    zT_EAC3E484_TokenKind zT_30;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    int zT_34;
    unsigned char zT_35;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_B559F9DA_Parser* zT_43;
    zT_3B6EA323_EU_01 zT_46 = {0};
    unsigned char zT_47;
    unsigned int zT_48;
    zT_8143F551_AstKind zT_52;
    int zT_54;
    unsigned int zT_55;
    zT_B559F9DA_Parser* zT_56;
    zT_3A355BD2_Token zT_57 = {0};
    zT_EAC3E484_TokenKind zT_58;
    zT_B559F9DA_Parser* zT_63;
    zT_3A355BD2_Token zT_64 = {0};
    zT_B559F9DA_Parser* zT_65;
    zT_3B6EA323_EU_01 zT_68 = {0};
    unsigned char zT_69;
    unsigned int zT_70;
    zT_8143F551_AstKind zT_73;
    zT_B559F9DA_Parser* zT_74;
    zT_3A355BD2_Token zT_75 = {0};
    zT_EAC3E484_TokenKind zT_76;
    zT_B559F9DA_Parser* zT_81;
    zT_3A355BD2_Token zT_82 = {0};
    zT_B559F9DA_Parser* zT_83;
    zT_3B6EA323_EU_01 zT_86 = {0};
    unsigned char zT_87;
    unsigned int zT_88;
    zT_8143F551_AstKind zT_91;
    zT_6B0A7D14_AstStore* zT_97;
    zT_8143F551_AstKind zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned int zT_103;
    int zT_107;
    unsigned int zT_110;
    unsigned short zT_111;
    int zT_114;
    int zT_116;
    unsigned int zT_118 = 0;
    unsigned int** zT_119;
    unsigned int* zT_120;
    unsigned int* zT_121;
    zT_3E40CD83_Sand* zT_122;
    unsigned int zT_123;
    unsigned int** zT_128;
    unsigned int* zT_129;
    unsigned int* zT_130;
    zT_3E40CD83_Sand* zT_131;
    unsigned int zT_132;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_B559F9DA_Parser* zT_144;
    zT_3A355BD2_Token zT_145 = {0};
    zT_EAC3E484_TokenKind zT_146;
    zT_B559F9DA_Parser* zT_151;
    int zT_153;
    zT_3A355BD2_Token zT_155 = {0};
    zT_EAC3E484_TokenKind zT_156;
    zT_B559F9DA_Parser* zT_161;
    zT_3A355BD2_Token zT_162 = {0};
    zT_B559F9DA_Parser* zT_163;
    zT_CB78802F_EU_49 zT_168 = {0};
    unsigned char zT_169;
    int zT_170;
    zT_3B6EA323_EU_01 zT_171;
    zT_2B3424E9_ParseToken zT_172;
    int zT_174;
    unsigned char zT_175;
    int zT_177;
    unsigned int zT_178;
    zT_B559F9DA_Parser* zT_179;
    zT_3A355BD2_Token zT_180 = {0};
    zT_EAC3E484_TokenKind zT_181;
    zT_B559F9DA_Parser* zT_186;
    zT_3A355BD2_Token zT_187 = {0};
    zT_2B3424E9_ParseToken zT_189 = {0};
    zT_B559F9DA_Parser* zT_190;
    zT_3A355BD2_Token zT_191 = {0};
    zT_EAC3E484_TokenKind zT_192;
    zT_B559F9DA_Parser* zT_197;
    zT_CB78802F_EU_49 zT_202 = {0};
    unsigned char zT_203;
    int zT_204;
    zT_3B6EA323_EU_01 zT_205;
    zT_2B3424E9_ParseToken zT_206;
    zT_B559F9DA_Parser* zT_207;
    zT_CB78802F_EU_49 zT_212 = {0};
    unsigned char zT_213;
    int zT_214;
    zT_3B6EA323_EU_01 zT_215;
    zT_2B3424E9_ParseToken zT_216;
    zT_B559F9DA_Parser* zT_217;
    zT_CB78802F_EU_49 zT_222 = {0};
    unsigned char zT_223;
    int zT_224;
    zT_3B6EA323_EU_01 zT_225;
    zT_2B3424E9_ParseToken zT_226;
    zT_2B3424E9_ParseToken zT_228;
    zT_EAC3E484_TokenKind zT_229;
    unsigned int zT_230;
    unsigned short zT_231;
    zT_D3EB6303_StringInterner* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_B559F9DA_Parser* zT_235;
    zT_2B3424E9_ParseToken zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237 = {0};
    unsigned int zT_238 = 0;
    int zT_239;
    unsigned char zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_247;
    unsigned int zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    int zT_253;
    unsigned char* zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257 = 0;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned char* zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    int zT_274;
    int zT_276;
    unsigned char zT_277;
    unsigned int zT_279 = 0;
    zT_B559F9DA_Parser* zT_280;
    zT_3A355BD2_Token zT_281 = {0};
    zT_EAC3E484_TokenKind zT_282;
    zT_B559F9DA_Parser* zT_287;
    zT_3B6EA323_EU_01 zT_288 = {0};
    unsigned char zT_289;
    unsigned int zT_290;
    zT_B559F9DA_Parser* zT_291;
    zT_3B6EA323_EU_01 zT_294 = {0};
    unsigned char zT_295;
    unsigned int zT_296;
    unsigned char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    int zT_310;
    unsigned char* zT_311;
    unsigned int zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned int zT_314 = 0;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char* zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    int zT_339;
    unsigned char* zT_340;
    unsigned int zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343 = 0;
    unsigned int zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned char* zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned char* zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned char* zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    unsigned int zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_6B0A7D14_AstStore* zT_368;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_369;
    int zT_371;
    unsigned int* zT_372;
    unsigned int zT_373;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_374;
    unsigned int zT_375 = 0;
    unsigned char* zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378;
    unsigned int zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_382;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    int zT_388;
    unsigned char* zT_389;
    unsigned int zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned int zT_392 = 0;
    unsigned int zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned char* zT_401;
    unsigned int zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned char* zT_405;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_406;
    unsigned int zT_407;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    unsigned int zT_410;
    unsigned short zT_411;
    unsigned int zT_413;
    zT_6B0A7D14_AstStore* zT_414;
    unsigned char zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_422;
    int zT_428;
    unsigned int zT_430 = 0;
    zT_3B6EA323_EU_01 zT_431;
    zT_3A355BD2_Token start_tok;
    unsigned int* case_items;
    unsigned int case_len;
    unsigned int case_cap;
    unsigned char is_else;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_em;
    unsigned int item;
    zT_8143F551_AstKind range_kind;
    unsigned int end_item;
    unsigned int range_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb2_m;
    unsigned char flags;
    unsigned int capture_name;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken pt;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpm;
    zT_5A26C2ED_Arr_unsigned_char_1 cpnb;
    unsigned int cpnl;
    unsigned int cpns;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpem;
    unsigned int body;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pcb_nb;
    unsigned int pcb_nl;
    unsigned int pcb_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 pcb_pb;
    unsigned int pcb_pl;
    unsigned int pcb_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_sm;
    unsigned int items_payload;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppl_m;
    zT_5A26C2ED_Arr_unsigned_char_1 ppl_pb;
    unsigned int ppl_pl;
    unsigned int ppl_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppl_n;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    start_tok = zT_3;
    case_items = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    case_len = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    case_cap = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned char)zT_13;
    is_else = zT_14;
    zT_15 = self;
    zT_16 = zF_068A2DE5_parserPeek(zT_15);
    zT_17 = zT_16.kind;
    if ((int)(zT_17 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_23 = "PCB:T";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    pcb_tm = zT_24;
    zT_26 = pcb_tm;
    zT_28 = self;
    zT_29 = zF_068A2DE5_parserPeek(zT_28);
    zT_30 = zT_29.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_30));
    zT_32 = self;
    zT_33 = zF_C241B2C4_parserAdvance(zT_32);
    (void)zT_33;
    zT_34 = 1;
    zT_35 = (unsigned char)zT_34;
    is_else = zT_35;
    goto z_bb_2;
    z_bb_2:
    zT_163 = self;
    zT_168 = zF_5578C74F_parserExpect(zT_163, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow));
    zT_169 = zT_168.is_error;
    if (zT_169) goto z_bb_29; else goto z_bb_30;
    z_bb_3:
    zT_37 = "PCB:E";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    pcb_em = zT_38;
    zT_40 = pcb_em;
    zF_48AC7B3A_markerWrite(zT_40);
    goto z_bb_4;
    z_bb_4:
    if ((int)(1)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_43 = self;
    zT_46 = zF_F07C1F04_parserParseExprPrec(zT_43, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_47 = zT_46.is_error;
    if (zT_47) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    return zT_46;
    z_bb_9:
    zT_48 = zT_46.data.payload;
    goto z_bb_10;
    z_bb_10:
    item = zT_48;
    zT_52 = zT_8143F551_AstKind_err;
    range_kind = zT_52;
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    end_item = zT_55;
    zT_56 = self;
    zT_57 = zF_068A2DE5_parserPeek(zT_56);
    zT_58 = zT_57.kind;
    if ((int)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_63 = self;
    zT_64 = zF_C241B2C4_parserAdvance(zT_63);
    (void)zT_64;
    zT_65 = self;
    zT_68 = zF_F07C1F04_parserParseExprPrec(zT_65, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_69 = zT_68.is_error;
    if (zT_69) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    if ((int)(range_kind != (zT_8143F551_AstKind)(zT_8143F551_AstKind_err))) goto z_bb_22; else goto z_bb_24;
    z_bb_13:
    zT_74 = self;
    zT_75 = zF_068A2DE5_parserPeek(zT_74);
    zT_76 = zT_75.kind;
    if ((int)(zT_76 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    return zT_68;
    z_bb_15:
    zT_70 = zT_68.data.payload;
    goto z_bb_16;
    z_bb_16:
    end_item = zT_70;
    zT_73 = zT_8143F551_AstKind_range_exclusive;
    range_kind = zT_73;
    goto z_bb_12;
    z_bb_17:
    zT_81 = self;
    zT_82 = zF_C241B2C4_parserAdvance(zT_81);
    (void)zT_82;
    zT_83 = self;
    zT_86 = zF_F07C1F04_parserParseExprPrec(zT_83, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_87 = zT_86.is_error;
    if (zT_87) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    return zT_86;
    z_bb_20:
    zT_88 = zT_86.data.payload;
    goto z_bb_21;
    z_bb_21:
    end_item = zT_88;
    zT_91 = zT_8143F551_AstKind_range_inclusive;
    range_kind = zT_91;
    goto z_bb_18;
    z_bb_22:
    zT_97 = self->store;
    zT_98 = range_kind;
    zT_107 = 0;
    zT_100 = start_tok.span_start;
    zT_110 = start_tok.span_start;
    zT_111 = start_tok.span_len;
    zT_102 = item;
    zT_103 = end_item;
    zT_114 = 0;
    zT_116 = 0;
    zT_118 = zF_6C9FF72F_astStoreAddNode(zT_97, zT_98, (unsigned char)((unsigned char)zT_107), zT_100, (unsigned int)(zT_110 + (unsigned int)((unsigned int)zT_111)), zT_102, zT_103, (unsigned int)((unsigned int)zT_114), (unsigned int)((unsigned int)zT_116));
    range_node = zT_118;
    zT_119 = &case_items;
    zT_120 = &case_len;
    zT_121 = &case_cap;
    zT_122 = self->allocator;
    zT_123 = range_node;
    zF_8B163A32_u32ArrayListAppendI(zT_119, zT_120, zT_121, zT_122, zT_123);
    goto z_bb_23;
    z_bb_23:
    zT_144 = self;
    zT_145 = zF_068A2DE5_parserPeek(zT_144);
    zT_146 = zT_145.kind;
    if ((int)(zT_146 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_128 = &case_items;
    zT_129 = &case_len;
    zT_130 = &case_cap;
    zT_131 = self->allocator;
    zT_132 = item;
    zF_8B163A32_u32ArrayListAppendI(zT_128, zT_129, zT_130, zT_131, zT_132);
    zT_138 = "PCB:B";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    pcb2_m = zT_139;
    zT_141 = pcb2_m;
    zF_C914CB83_markerWriteInt(zT_141, (unsigned int)((unsigned int)case_len));
    goto z_bb_23;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_151 = self;
    zT_153 = 1;
    zT_155 = zF_F685E431_parserPeekN(zT_151, (unsigned int)((unsigned int)zT_153));
    zT_156 = zT_155.kind;
    if ((int)(zT_156 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_161 = self;
    zT_162 = zF_C241B2C4_parserAdvance(zT_161);
    (void)zT_162;
    goto z_bb_7;
    z_bb_29:
    zT_170 = zT_168.data.err;
    zT_171.data.err = zT_170;
    zT_171.is_error = 1;
    return zT_171;
    z_bb_30:
    zT_172 = zT_168.data.payload;
    goto z_bb_31;
    z_bb_31:
    (void)zT_172;
    zT_174 = 0;
    zT_175 = (unsigned char)zT_174;
    flags = zT_175;
    zT_177 = 0;
    zT_178 = (unsigned int)zT_177;
    capture_name = zT_178;
    zT_179 = self;
    zT_180 = zF_068A2DE5_parserPeek(zT_179);
    zT_181 = zT_180.kind;
    if ((int)(zT_181 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_186 = self;
    zT_187 = zF_C241B2C4_parserAdvance(zT_186);
    (void)zT_187;
    name_tok = zT_189;
    zT_190 = self;
    zT_191 = zF_068A2DE5_parserPeek(zT_190);
    zT_192 = zT_191.kind;
    if ((int)(zT_192 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_274 = 0;
    if ((int)(is_else != zT_274)) goto z_bb_46; else goto z_bb_47;
    z_bb_34:
    zT_197 = self;
    zT_202 = zF_5578C74F_parserExpect(zT_197, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_203 = zT_202.is_error;
    if (zT_203) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_217 = self;
    zT_222 = zF_5578C74F_parserExpect(zT_217, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_223 = zT_222.is_error;
    if (zT_223) goto z_bb_43; else goto z_bb_44;
    z_bb_36:
    zT_207 = self;
    zT_212 = zF_5578C74F_parserExpect(zT_207, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_213 = zT_212.is_error;
    if (zT_213) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_204 = zT_202.data.err;
    zT_205.data.err = zT_204;
    zT_205.is_error = 1;
    return zT_205;
    z_bb_38:
    zT_206 = zT_202.data.payload;
    goto z_bb_39;
    z_bb_39:
    name_tok = zT_206;
    goto z_bb_35;
    z_bb_40:
    zT_214 = zT_212.data.err;
    zT_215.data.err = zT_214;
    zT_215.is_error = 1;
    return zT_215;
    z_bb_41:
    zT_216 = zT_212.data.payload;
    goto z_bb_42;
    z_bb_42:
    name_tok = zT_216;
    goto z_bb_35;
    z_bb_43:
    zT_224 = zT_222.data.err;
    zT_225.data.err = zT_224;
    zT_225.is_error = 1;
    return zT_225;
    z_bb_44:
    zT_226 = zT_222.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_226;
    zT_229 = name_tok.kind;
    zT_228.kind = zT_229;
    zT_230 = name_tok.span_start;
    zT_228.span_start = zT_230;
    zT_231 = name_tok.span_len;
    zT_228.span_len = zT_231;
    pt = zT_228;
    zT_232 = self->interner;
    zT_235 = self;
    zT_236 = pt;
    zT_237 = zF_08D61E58_parserTokenText(zT_235, zT_236);
    zT_233 = zT_237;
    zT_238 = zF_50C274AF_stringInternerInter(zT_232, zT_233);
    capture_name = zT_238;
    zT_239 = 16;
    zT_240 = (unsigned char)zT_239;
    flags = zT_240;
    zT_242 = "CPT:n";
    zT_244 = 5;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    cpm = zT_243;
    zT_245 = cpm;
    zF_48AC7B3A_markerWrite(zT_245);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_247[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpnb[_i] = zT_247[_i];
        _i++;
    }
}
    zT_249 = capture_name;
    zT_253 = 0;
    zT_254 = (unsigned char*)((unsigned char*)cpnb) + zT_253;
    zT_255 = (unsigned int)(10) - zT_253;
    zT_256.ptr = zT_254;
    zT_256.len = zT_255;
    zT_250 = zT_256;
    zT_257 = zF_A7504564_itoa(zT_249, zT_250);
    cpnl = zT_257;
    zT_261 = (unsigned int)(9) - (unsigned int)((unsigned int)cpnl);
    cpns = zT_261;
    zT_266 = (unsigned char*)((unsigned char*)cpnb) + cpns;
    zT_267 = (unsigned int)(9) - cpns;
    zT_268.ptr = zT_266;
    zT_268.len = zT_267;
    zT_262 = zT_268;
    zF_48AC7B3A_markerWrite(zT_262);
    zT_270 = "\n";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    cpem = zT_271;
    zT_273 = cpem;
    zF_48AC7B3A_markerWrite(zT_273);
    goto z_bb_33;
    z_bb_46:
    zT_276 = 1;
    zT_277 = flags | zT_276;
    flags = zT_277;
    goto z_bb_47;
    z_bb_47:
    body = zT_279;
    zT_280 = self;
    zT_281 = zF_068A2DE5_parserPeek(zT_280);
    zT_282 = zT_281.kind;
    if ((int)(zT_282 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_48; else goto z_bb_50;
    z_bb_48:
    zT_287 = self;
    zT_288 = zF_365CA04A_parserParseBlock(zT_287);
    zT_289 = zT_288.is_error;
    if (zT_289) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    zT_298 = "PCB:n";
    zT_300 = 5;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pcb_m = zT_299;
    zT_301 = pcb_m;
    zF_48AC7B3A_markerWrite(zT_301);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_303[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pcb_nb[_i] = zT_303[_i];
        _i++;
    }
}
    zT_310 = 0;
    zT_311 = (unsigned char*)((unsigned char*)pcb_nb) + zT_310;
    zT_312 = (unsigned int)(10) - zT_310;
    zT_313.ptr = zT_311;
    zT_313.len = zT_312;
    zT_306 = zT_313;
    zT_314 = zF_A7504564_itoa((unsigned int)((unsigned int)case_len), zT_306);
    pcb_nl = zT_314;
    zT_318 = (unsigned int)(9) - (unsigned int)((unsigned int)pcb_nl);
    pcb_ns = zT_318;
    zT_323 = (unsigned char*)((unsigned char*)pcb_nb) + pcb_ns;
    zT_324 = (unsigned int)(9) - pcb_ns;
    zT_325.ptr = zT_323;
    zT_325.len = zT_324;
    zT_319 = zT_325;
    zF_48AC7B3A_markerWrite(zT_319);
    zT_327 = "p=";
    zT_329 = 2;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    pcb_pm = zT_328;
    zT_330 = pcb_pm;
    zF_48AC7B3A_markerWrite(zT_330);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_332[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pcb_pb[_i] = zT_332[_i];
        _i++;
    }
}
    zT_339 = 0;
    zT_340 = (unsigned char*)((unsigned char*)pcb_pb) + zT_339;
    zT_341 = (unsigned int)(10) - zT_339;
    zT_342.ptr = zT_340;
    zT_342.len = zT_341;
    zT_335 = zT_342;
    zT_343 = zF_A7504564_itoa((unsigned int)((unsigned int)flags), zT_335);
    pcb_pl = zT_343;
    zT_347 = (unsigned int)(9) - (unsigned int)((unsigned int)pcb_pl);
    pcb_ps = zT_347;
    zT_352 = (unsigned char*)((unsigned char*)pcb_pb) + pcb_ps;
    zT_353 = (unsigned int)(9) - pcb_ps;
    zT_354.ptr = zT_352;
    zT_354.len = zT_353;
    zT_348 = zT_354;
    zF_48AC7B3A_markerWrite(zT_348);
    zT_356 = "\n";
    zT_358 = 1;
    zT_357.ptr = zT_356;
    zT_357.len = zT_358;
    pcb_n = zT_357;
    zT_359 = pcb_n;
    zF_48AC7B3A_markerWrite(zT_359);
    zT_361 = "PCB:S";
    zT_363 = 5;
    zT_362.ptr = zT_361;
    zT_362.len = zT_363;
    pcb_sm = zT_362;
    zT_364 = pcb_sm;
    zF_C914CB83_markerWriteInt(zT_364, (unsigned int)((unsigned int)case_len));
    zT_368 = self->store;
    zT_371 = 0;
    zT_372 = case_items + zT_371;
    zT_373 = case_len - zT_371;
    zT_374.ptr = zT_372;
    zT_374.len = zT_373;
    zT_369 = zT_374;
    zT_375 = zF_583E993C_astStoreAddExtraChi(zT_368, zT_369);
    items_payload = zT_375;
    zT_377 = "PPL:n";
    zT_379 = 5;
    zT_378.ptr = zT_377;
    zT_378.len = zT_379;
    ppl_m = zT_378;
    zT_380 = ppl_m;
    zF_48AC7B3A_markerWrite(zT_380);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_382[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppl_pb[_i] = zT_382[_i];
        _i++;
    }
}
    zT_384 = items_payload;
    zT_388 = 0;
    zT_389 = (unsigned char*)((unsigned char*)ppl_pb) + zT_388;
    zT_390 = (unsigned int)(10) - zT_388;
    zT_391.ptr = zT_389;
    zT_391.len = zT_390;
    zT_385 = zT_391;
    zT_392 = zF_A7504564_itoa(zT_384, zT_385);
    ppl_pl = zT_392;
    zT_396 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl_pl);
    ppl_ps = zT_396;
    zT_401 = (unsigned char*)((unsigned char*)ppl_pb) + ppl_ps;
    zT_402 = (unsigned int)(9) - ppl_ps;
    zT_403.ptr = zT_401;
    zT_403.len = zT_402;
    zT_397 = zT_403;
    zF_48AC7B3A_markerWrite(zT_397);
    zT_405 = "\n";
    zT_407 = 1;
    zT_406.ptr = zT_405;
    zT_406.len = zT_407;
    ppl_n = zT_406;
    zT_408 = ppl_n;
    zF_48AC7B3A_markerWrite(zT_408);
    zT_410 = start_tok.span_start;
    zT_411 = start_tok.span_len;
    zT_413 = zT_410 + (unsigned int)((unsigned int)zT_411);
    end_pos = zT_413;
    zT_414 = self->store;
    zT_416 = flags;
    zT_417 = start_tok.span_start;
    zT_418 = end_pos;
    zT_419 = body;
    zT_420 = capture_name;
    zT_428 = 0;
    zT_422 = items_payload;
    zT_430 = zF_6C9FF72F_astStoreAddNode(zT_414, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_prong), zT_416, zT_417, zT_418, zT_419, zT_420, (unsigned int)((unsigned int)zT_428), zT_422);
    zT_431.data.payload = zT_430;
    zT_431.is_error = 0;
    return zT_431;
    z_bb_50:
    zT_291 = self;
    zT_294 = zF_F07C1F04_parserParseExprPrec(zT_291, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_295 = zT_294.is_error;
    if (zT_295) goto z_bb_54; else goto z_bb_55;
    z_bb_51:
    return zT_288;
    z_bb_52:
    zT_290 = zT_288.data.payload;
    goto z_bb_53;
    z_bb_53:
    body = zT_290;
    goto z_bb_49;
    z_bb_54:
    return zT_294;
    z_bb_55:
    zT_296 = zT_294.data.payload;
    goto z_bb_56;
    z_bb_56:
    body = zT_296;
    goto z_bb_49;
}

/* parserParseType */
zT_3B6EA323_EU_01 zF_CBDBFE85_parserParseType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_9;
    zT_3B6EA323_EU_01 zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_B559F9DA_Parser* zT_16;
    zT_3B6EA323_EU_01 zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_23;
    zT_3B6EA323_EU_01 zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    zT_B559F9DA_Parser* zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    zT_EAC3E484_TokenKind zT_32;
    zT_B559F9DA_Parser* zT_37;
    zT_3B6EA323_EU_01 zT_38 = {0};
    zT_EAC3E484_TokenKind zT_39;
    zT_B559F9DA_Parser* zT_44;
    unsigned char zT_45;
    unsigned int zT_46;
    zT_3B6EA323_EU_01 zT_47 = {0};
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    unsigned char zT_56;
    unsigned int zT_57;
    zT_B559F9DA_Parser* zT_58;
    zT_3A355BD2_Token zT_59 = {0};
    zT_EAC3E484_TokenKind zT_60;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_B559F9DA_Parser* zT_68;
    zT_3B6EA323_EU_01 zT_69 = {0};
    unsigned char zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_75;
    unsigned int zT_77;
    unsigned int zT_78;
    int zT_85;
    unsigned int zT_88;
    unsigned short zT_89;
    int zT_92;
    int zT_94;
    unsigned int zT_96 = 0;
    zT_3B6EA323_EU_01 zT_97;
    zT_3B6EA323_EU_01 zT_98;
    zT_EAC3E484_TokenKind zT_99;
    zT_B559F9DA_Parser* zT_104;
    int zT_106;
    zT_3B6EA323_EU_01 zT_108 = {0};
    zT_EAC3E484_TokenKind zT_109;
    zT_B559F9DA_Parser* zT_114;
    zT_3B6EA323_EU_01 zT_115 = {0};
    zT_EAC3E484_TokenKind zT_116;
    zT_B559F9DA_Parser* zT_121;
    int zT_123;
    zT_3B6EA323_EU_01 zT_125 = {0};
    zT_EAC3E484_TokenKind zT_126;
    zT_B559F9DA_Parser* zT_131;
    zT_3A355BD2_Token zT_132 = {0};
    zT_B559F9DA_Parser* zT_134;
    zT_3A355BD2_Token zT_135 = {0};
    zT_EAC3E484_TokenKind zT_136;
    zT_B559F9DA_Parser* zT_141;
    int zT_143;
    zT_3B6EA323_EU_01 zT_145 = {0};
    zT_EAC3E484_TokenKind zT_146;
    zT_B559F9DA_Parser* zT_151;
    int zT_153;
    zT_3B6EA323_EU_01 zT_155 = {0};
    unsigned char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_B559F9DA_Parser* zT_160;
    zT_3A355BD2_Token zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    zT_DBF3575C_ParserError zT_163;
    zT_3B6EA323_EU_01 zT_164;
    zT_EAC3E484_TokenKind zT_165;
    zT_B559F9DA_Parser* zT_170;
    zT_3A355BD2_Token zT_171 = {0};
    unsigned int zT_173;
    zT_3B6EA323_EU_01 zT_174;
    zT_B559F9DA_Parser* zT_176;
    zT_3B6EA323_EU_01 zT_177 = {0};
    unsigned char zT_178;
    unsigned int zT_179;
    zT_B559F9DA_Parser* zT_180;
    zT_3A355BD2_Token zT_181 = {0};
    zT_EAC3E484_TokenKind zT_182;
    zT_B559F9DA_Parser* zT_187;
    zT_3A355BD2_Token zT_188 = {0};
    zT_B559F9DA_Parser* zT_190;
    zT_3B6EA323_EU_01 zT_191 = {0};
    unsigned char zT_192;
    unsigned int zT_193;
    zT_6B0A7D14_AstStore* zT_194;
    unsigned int zT_197;
    unsigned int zT_199;
    unsigned int zT_200;
    int zT_207;
    unsigned int zT_210;
    unsigned short zT_211;
    int zT_214;
    int zT_216;
    unsigned int zT_218 = 0;
    zT_3B6EA323_EU_01 zT_219;
    zT_3B6EA323_EU_01 zT_220;
    zT_3A355BD2_Token tok;
    unsigned int es;
    unsigned int payload;
    zT_3A355BD2_Token ntok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    unsigned int z;
    unsigned int base;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((int)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self;
    zT_10 = zF_08083D09_parserParsePtrType(zT_9);
    return zT_10;
    z_bb_2:
    zT_11 = tok.kind;
    if ((int)(zT_11 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = self;
    zT_17 = zF_2BC32683_parserParseBracketT(zT_16);
    return zT_17;
    z_bb_4:
    zT_18 = tok.kind;
    if ((int)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = self;
    zT_24 = zF_F9036399_parserParseOptional(zT_23);
    return zT_24;
    z_bb_6:
    zT_25 = tok.kind;
    if ((int)(zT_25 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = self;
    zT_31 = zF_33E5ECC8_parserParseErrorUni(zT_30);
    return zT_31;
    z_bb_8:
    zT_32 = tok.kind;
    if ((int)(zT_32 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37 = self;
    zT_38 = zF_B83061B7_parserParseExternFn(zT_37);
    return zT_38;
    z_bb_10:
    zT_39 = tok.kind;
    if ((int)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_44 = self;
    zT_46 = 0;
    zT_45 = zT_46;
    zT_47 = zF_B5C9B665_parserParseFnType(zT_44, zT_45);
    return zT_47;
    z_bb_12:
    zT_48 = tok.kind;
    if ((int)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_54 = self;
    zT_55 = zF_BFAD1973_parserParseErrorSet(zT_54);
    zT_56 = zT_55.is_error;
    if (zT_56) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_99 = tok.kind;
    if ((int)(zT_99 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    return zT_55;
    z_bb_16:
    zT_57 = zT_55.data.payload;
    goto z_bb_17;
    z_bb_17:
    es = zT_57;
    zT_58 = self;
    zT_59 = zF_068A2DE5_parserPeek(zT_58);
    zT_60 = zT_59.kind;
    if ((int)(zT_60 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_65 = self;
    zT_66 = zF_C241B2C4_parserAdvance(zT_65);
    (void)zT_66;
    zT_68 = self;
    zT_69 = zF_CBDBFE85_parserParseType(zT_68);
    zT_70 = zT_69.is_error;
    if (zT_70) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_98.data.payload = es;
    zT_98.is_error = 0;
    return zT_98;
    z_bb_20:
    return zT_69;
    z_bb_21:
    zT_71 = zT_69.data.payload;
    goto z_bb_22;
    z_bb_22:
    payload = zT_71;
    zT_72 = self->store;
    zT_85 = 0;
    zT_75 = tok.span_start;
    zT_88 = tok.span_start;
    zT_89 = tok.span_len;
    zT_77 = es;
    zT_78 = payload;
    zT_92 = 0;
    zT_94 = 0;
    zT_96 = zF_6C9FF72F_astStoreAddNode(zT_72, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_85), zT_75, (unsigned int)(zT_88 + (unsigned int)((unsigned int)zT_89)), zT_77, zT_78, (unsigned int)((unsigned int)zT_92), (unsigned int)((unsigned int)zT_94));
    zT_97.data.payload = zT_96;
    zT_97.is_error = 0;
    return zT_97;
    z_bb_23:
    zT_104 = self;
    zT_106 = 0;
    zT_108 = zF_3530D6C0_parserParseStructTy(zT_104, (unsigned char)((unsigned char)zT_106));
    return zT_108;
    z_bb_24:
    zT_109 = tok.kind;
    if ((int)(zT_109 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_114 = self;
    zT_115 = zF_63EC2480_parserParseEnumType(zT_114);
    return zT_115;
    z_bb_26:
    zT_116 = tok.kind;
    if ((int)(zT_116 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_121 = self;
    zT_123 = 0;
    zT_125 = zF_0881F8E4_parserParseUnionTyp(zT_121, (unsigned char)((unsigned char)zT_123));
    return zT_125;
    z_bb_28:
    zT_126 = tok.kind;
    if ((int)(zT_126 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_packed))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_131 = self;
    zT_132 = zF_C241B2C4_parserAdvance(zT_131);
    (void)zT_132;
    zT_134 = self;
    zT_135 = zF_068A2DE5_parserPeek(zT_134);
    ntok = zT_135;
    zT_136 = ntok.kind;
    if ((int)(zT_136 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_165 = tok.kind;
    if ((int)(zT_165 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    zT_141 = self;
    zT_143 = 1;
    zT_145 = zF_3530D6C0_parserParseStructTy(zT_141, (unsigned char)((unsigned char)zT_143));
    return zT_145;
    z_bb_32:
    zT_146 = ntok.kind;
    if ((int)(zT_146 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_151 = self;
    zT_153 = 1;
    zT_155 = zF_0881F8E4_parserParseUnionTyp(zT_151, (unsigned char)((unsigned char)zT_153));
    return zT_155;
    z_bb_34:
    zT_157 = "expected 'struct' or 'union' after 'packed'";
    zT_159 = 43;
    zT_158.ptr = zT_157;
    zT_158.len = zT_159;
    pmsg = zT_158;
    zT_160 = self;
    zT_161 = ntok;
    zT_162 = pmsg;
    zF_17DF2CA5_parserAddError(zT_160, zT_161, zT_162);
    zT_163 = 1;
    zT_164.data.err = zT_163;
    zT_164.is_error = 1;
    return zT_164;
    z_bb_35:
    zT_170 = self;
    zT_171 = zF_C241B2C4_parserAdvance(zT_170);
    (void)zT_171;
    zT_173 = 0;
    z = zT_173;
    zT_174.data.payload = z;
    zT_174.is_error = 0;
    return zT_174;
    z_bb_36:
    zT_176 = self;
    zT_177 = zF_C8A1E2C6_parserParseTypeName(zT_176);
    zT_178 = zT_177.is_error;
    if (zT_178) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return zT_177;
    z_bb_38:
    zT_179 = zT_177.data.payload;
    goto z_bb_39;
    z_bb_39:
    base = zT_179;
    zT_180 = self;
    zT_181 = zF_068A2DE5_parserPeek(zT_180);
    zT_182 = zT_181.kind;
    if ((int)(zT_182 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_187 = self;
    zT_188 = zF_C241B2C4_parserAdvance(zT_187);
    (void)zT_188;
    zT_190 = self;
    zT_191 = zF_CBDBFE85_parserParseType(zT_190);
    zT_192 = zT_191.is_error;
    if (zT_192) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_220.data.payload = base;
    zT_220.is_error = 0;
    return zT_220;
    z_bb_42:
    return zT_191;
    z_bb_43:
    zT_193 = zT_191.data.payload;
    goto z_bb_44;
    z_bb_44:
    payload = zT_193;
    zT_194 = self->store;
    zT_207 = 0;
    zT_197 = tok.span_start;
    zT_210 = tok.span_start;
    zT_211 = tok.span_len;
    zT_199 = base;
    zT_200 = payload;
    zT_214 = 0;
    zT_216 = 0;
    zT_218 = zF_6C9FF72F_astStoreAddNode(zT_194, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_207), zT_197, (unsigned int)(zT_210 + (unsigned int)((unsigned int)zT_211)), zT_199, zT_200, (unsigned int)((unsigned int)zT_214), (unsigned int)((unsigned int)zT_216));
    zT_219.data.payload = zT_218;
    zT_219.is_error = 0;
    return zT_219;
}

/* parserParsePtrQualifiers */
unsigned char zF_0FA83230_parserParsePtrQuali(zT_B559F9DA_Parser* self) {
    int zT_2;
    unsigned char zT_3;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    int zT_14;
    unsigned char zT_16;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_EAC3E484_TokenKind zT_19;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    int zT_26;
    unsigned char zT_28;
    unsigned char flags;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    flags = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((int)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return flags;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    (void)zT_13;
    zT_14 = 1;
    zT_16 = flags | (unsigned char)((unsigned char)zT_14);
    flags = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self;
    zT_18 = zF_068A2DE5_parserPeek(zT_17);
    zT_19 = zT_18.kind;
    if ((int)(zT_19 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_volatile))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_24 = self;
    zT_25 = zF_C241B2C4_parserAdvance(zT_24);
    (void)zT_25;
    zT_26 = 2;
    zT_28 = flags | (unsigned char)((unsigned char)zT_26);
    flags = zT_28;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    goto z_bb_3;
}

/* parserParsePtrType */
zT_3B6EA323_EU_01 zF_08083D09_parserParsePtrType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    unsigned char zT_6 = 0;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_27;
    unsigned short zT_28;
    int zT_31;
    int zT_33;
    int zT_35;
    unsigned int zT_37 = 0;
    zT_3B6EA323_EU_01 zT_38;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_0FA83230_parserParsePtrQuali(zT_5);
    flags = zT_6;
    zT_8 = self;
    zT_9 = zF_CBDBFE85_parserParseType(zT_8);
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    base = zT_11;
    end_pos = base;
    (void)end_pos;
    zT_13 = self->store;
    zT_15 = flags;
    zT_16 = tok.span_start;
    zT_27 = tok.span_start;
    zT_28 = tok.span_len;
    zT_18 = base;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = zF_6C9FF72F_astStoreAddNode(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type), zT_15, zT_16, (unsigned int)(zT_27 + (unsigned int)((unsigned int)zT_28)), zT_18, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35));
    zT_38.data.payload = zT_37;
    zT_38.is_error = 0;
    return zT_38;
}

/* parserParseBracketType */
zT_3B6EA323_EU_01 zF_2BC32683_parserParseBracketT(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_13;
    zT_CB78802F_EU_49 zT_18 = {0};
    unsigned char zT_19;
    int zT_20;
    zT_3B6EA323_EU_01 zT_21;
    zT_2B3424E9_ParseToken zT_22;
    zT_B559F9DA_Parser* zT_24;
    unsigned char zT_25 = 0;
    zT_B559F9DA_Parser* zT_27;
    zT_3B6EA323_EU_01 zT_28 = {0};
    unsigned char zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_45;
    unsigned short zT_46;
    int zT_49;
    int zT_51;
    int zT_53;
    unsigned int zT_55 = 0;
    zT_3B6EA323_EU_01 zT_56;
    zT_B559F9DA_Parser* zT_57;
    zT_3A355BD2_Token zT_58 = {0};
    zT_EAC3E484_TokenKind zT_59;
    zT_B559F9DA_Parser* zT_64;
    zT_3A355BD2_Token zT_65 = {0};
    int zT_67;
    unsigned char zT_68;
    zT_B559F9DA_Parser* zT_69;
    zT_3A355BD2_Token zT_70 = {0};
    zT_EAC3E484_TokenKind zT_71;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    int zT_78;
    unsigned char zT_79;
    zT_B559F9DA_Parser* zT_81;
    zT_3B6EA323_EU_01 zT_82 = {0};
    unsigned char zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned char zT_87;
    unsigned int zT_88;
    unsigned int zT_90;
    unsigned int zT_99;
    unsigned short zT_100;
    int zT_103;
    int zT_105;
    int zT_107;
    unsigned int zT_109 = 0;
    zT_3B6EA323_EU_01 zT_110;
    zT_B559F9DA_Parser* zT_112;
    zT_3B6EA323_EU_01 zT_115 = {0};
    unsigned char zT_116;
    unsigned int zT_117;
    zT_B559F9DA_Parser* zT_118;
    zT_CB78802F_EU_49 zT_123 = {0};
    unsigned char zT_124;
    int zT_125;
    zT_3B6EA323_EU_01 zT_126;
    zT_2B3424E9_ParseToken zT_127;
    zT_B559F9DA_Parser* zT_129;
    zT_3B6EA323_EU_01 zT_130 = {0};
    unsigned char zT_131;
    unsigned int zT_132;
    zT_6B0A7D14_AstStore* zT_133;
    unsigned int zT_136;
    unsigned int zT_138;
    unsigned int zT_139;
    int zT_146;
    unsigned int zT_149;
    unsigned short zT_150;
    int zT_153;
    int zT_155;
    unsigned int zT_157 = 0;
    zT_3B6EA323_EU_01 zT_158;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int size_expr;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((int)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_13 = self;
    zT_18 = zF_5578C74F_parserExpect(zT_13, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_57 = self;
    zT_58 = zF_068A2DE5_parserPeek(zT_57);
    zT_59 = zT_58.kind;
    if ((int)(zT_59 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_20 = zT_18.data.err;
    zT_21.data.err = zT_20;
    zT_21.is_error = 1;
    return zT_21;
    z_bb_4:
    zT_22 = zT_18.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_22;
    zT_24 = self;
    zT_25 = zF_0FA83230_parserParsePtrQuali(zT_24);
    flags = zT_25;
    zT_27 = self;
    zT_28 = zF_CBDBFE85_parserParseType(zT_27);
    zT_29 = zT_28.is_error;
    if (zT_29) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return zT_28;
    z_bb_7:
    zT_30 = zT_28.data.payload;
    goto z_bb_8;
    z_bb_8:
    base = zT_30;
    zT_31 = self->store;
    zT_33 = flags;
    zT_34 = tok.span_start;
    zT_45 = tok.span_start;
    zT_46 = tok.span_len;
    zT_36 = base;
    zT_49 = 0;
    zT_51 = 0;
    zT_53 = 0;
    zT_55 = zF_6C9FF72F_astStoreAddNode(zT_31, (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type), zT_33, zT_34, (unsigned int)(zT_45 + (unsigned int)((unsigned int)zT_46)), zT_36, (unsigned int)((unsigned int)zT_49), (unsigned int)((unsigned int)zT_51), (unsigned int)((unsigned int)zT_53));
    zT_56.data.payload = zT_55;
    zT_56.is_error = 0;
    return zT_56;
    z_bb_9:
    zT_64 = self;
    zT_65 = zF_C241B2C4_parserAdvance(zT_64);
    (void)zT_65;
    zT_67 = 0;
    zT_68 = (unsigned char)zT_67;
    flags = zT_68;
    zT_69 = self;
    zT_70 = zF_068A2DE5_parserPeek(zT_69);
    zT_71 = zT_70.kind;
    if ((int)(zT_71 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_112 = self;
    zT_115 = zF_F07C1F04_parserParseExprPrec(zT_112, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_116 = zT_115.is_error;
    if (zT_116) goto z_bb_16; else goto z_bb_17;
    z_bb_11:
    zT_76 = self;
    zT_77 = zF_C241B2C4_parserAdvance(zT_76);
    (void)zT_77;
    zT_78 = 1;
    zT_79 = (unsigned char)zT_78;
    flags = zT_79;
    goto z_bb_12;
    z_bb_12:
    zT_81 = self;
    zT_82 = zF_CBDBFE85_parserParseType(zT_81);
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return zT_82;
    z_bb_14:
    zT_84 = zT_82.data.payload;
    goto z_bb_15;
    z_bb_15:
    base = zT_84;
    zT_85 = self->store;
    zT_87 = flags;
    zT_88 = tok.span_start;
    zT_99 = tok.span_start;
    zT_100 = tok.span_len;
    zT_90 = base;
    zT_103 = 0;
    zT_105 = 0;
    zT_107 = 0;
    zT_109 = zF_6C9FF72F_astStoreAddNode(zT_85, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type), zT_87, zT_88, (unsigned int)(zT_99 + (unsigned int)((unsigned int)zT_100)), zT_90, (unsigned int)((unsigned int)zT_103), (unsigned int)((unsigned int)zT_105), (unsigned int)((unsigned int)zT_107));
    zT_110.data.payload = zT_109;
    zT_110.is_error = 0;
    return zT_110;
    z_bb_16:
    return zT_115;
    z_bb_17:
    zT_117 = zT_115.data.payload;
    goto z_bb_18;
    z_bb_18:
    size_expr = zT_117;
    zT_118 = self;
    zT_123 = zF_5578C74F_parserExpect(zT_118, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_125 = zT_123.data.err;
    zT_126.data.err = zT_125;
    zT_126.is_error = 1;
    return zT_126;
    z_bb_20:
    zT_127 = zT_123.data.payload;
    goto z_bb_21;
    z_bb_21:
    (void)zT_127;
    zT_129 = self;
    zT_130 = zF_CBDBFE85_parserParseType(zT_129);
    zT_131 = zT_130.is_error;
    if (zT_131) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return zT_130;
    z_bb_23:
    zT_132 = zT_130.data.payload;
    goto z_bb_24;
    z_bb_24:
    base = zT_132;
    zT_133 = self->store;
    zT_146 = 0;
    zT_136 = tok.span_start;
    zT_149 = tok.span_start;
    zT_150 = tok.span_len;
    zT_138 = base;
    zT_139 = size_expr;
    zT_153 = 0;
    zT_155 = 0;
    zT_157 = zF_6C9FF72F_astStoreAddNode(zT_133, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type), (unsigned char)((unsigned char)zT_146), zT_136, (unsigned int)(zT_149 + (unsigned int)((unsigned int)zT_150)), zT_138, zT_139, (unsigned int)((unsigned int)zT_153), (unsigned int)((unsigned int)zT_155));
    zT_158.data.payload = zT_157;
    zT_158.is_error = 0;
    return zT_158;
}

/* parserParseOptionalType */
zT_3B6EA323_EU_01 zF_F9036399_parserParseOptional(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_14;
    int zT_22;
    unsigned int zT_25;
    unsigned short zT_26;
    int zT_29;
    int zT_31;
    int zT_33;
    unsigned int zT_35 = 0;
    zT_3B6EA323_EU_01 zT_36;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_22 = 0;
    zT_12 = tok.span_start;
    zT_25 = tok.span_start;
    zT_26 = tok.span_len;
    zT_14 = payload;
    zT_29 = 0;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type), (unsigned char)((unsigned char)zT_22), zT_12, (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26)), zT_14, (unsigned int)((unsigned int)zT_29), (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33));
    zT_36.data.payload = zT_35;
    zT_36.is_error = 0;
    return zT_36;
}

/* parserParseErrorUnionType */
zT_3B6EA323_EU_01 zF_33E5ECC8_parserParseErrorUni(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_15;
    int zT_22;
    unsigned int zT_25;
    unsigned short zT_26;
    int zT_29;
    int zT_31;
    int zT_33;
    unsigned int zT_35 = 0;
    zT_3B6EA323_EU_01 zT_36;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_22 = 0;
    zT_12 = tok.span_start;
    zT_25 = tok.span_start;
    zT_26 = tok.span_len;
    zT_29 = 0;
    zT_15 = payload;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_22), zT_12, (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26)), (unsigned int)((unsigned int)zT_29), zT_15, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33));
    zT_36.data.payload = zT_35;
    zT_36.is_error = 0;
    return zT_36;
}

/* parserParseExternFnType */
zT_3B6EA323_EU_01 zF_B83061B7_parserParseExternFn(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    unsigned int zT_4;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_D3EB6303_StringInterner* zT_16;
    unsigned int zT_17;
    zT_85CBA4DB_TokenValue zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char zT_24 = 0;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_35;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_39;
    zT_3A355BD2_Token zT_40 = {0};
    zT_EAC3E484_TokenKind zT_41;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_B559F9DA_Parser* zT_50;
    zT_3A355BD2_Token zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_DBF3575C_ParserError zT_53;
    zT_3B6EA323_EU_01 zT_54;
    zT_B559F9DA_Parser* zT_55;
    unsigned char zT_56;
    zT_3B6EA323_EU_01 zT_57 = {0};
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u efm;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = 0;
    call_conv = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    str_tok = zT_14;
    zT_16 = self->interner;
    zT_19 = str_tok.value;
    zT_17 = zT_19.string_id;
    zT_21 = zF_9134020D_stringInternerGet(zT_16, zT_17);
    text = zT_21;
    zT_22 = self;
    zT_23 = text;
    zT_24 = zF_A095D9EA_parserClassifyCallC(zT_22, zT_23);
    call_conv = zT_24;
    if ((int)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_39 = self;
    zT_40 = zF_068A2DE5_parserPeek(zT_39);
    nt = zT_40;
    zT_41 = nt.kind;
    if ((int)(zT_41 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_28 = "unknown calling convention in `extern`";
    zT_30 = 38;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ucv = zT_29;
    zT_31 = self;
    zT_32 = str_tok;
    zT_35 = 3045;
    zT_34 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_31, zT_32, (unsigned short)((unsigned short)zT_35), zT_34);
    zT_37 = 0;
    call_conv = zT_37;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_47 = "expected 'fn' after extern calling convention";
    zT_49 = 45;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    efm = zT_48;
    zT_50 = self;
    zT_51 = nt;
    zT_52 = efm;
    zF_17DF2CA5_parserAddError(zT_50, zT_51, zT_52);
    zT_53 = 1;
    zT_54.data.err = zT_53;
    zT_54.is_error = 1;
    return zT_54;
    z_bb_6:
    zT_55 = self;
    zT_56 = call_conv;
    zT_57 = zF_B5C9B665_parserParseFnType(zT_55, zT_56);
    return zT_57;
}

/* parserParseFnType */
zT_3B6EA323_EU_01 zF_B5C9B665_parserParseFnType(zT_B559F9DA_Parser* self, unsigned char call_conv) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    unsigned int* zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    zT_B559F9DA_Parser* zT_29;
    zT_3A355BD2_Token zT_30 = {0};
    zT_EAC3E484_TokenKind zT_31;
    zT_B559F9DA_Parser* zT_37;
    zT_3A355BD2_Token zT_38 = {0};
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_B559F9DA_Parser* zT_43;
    zT_3A355BD2_Token zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_DBF3575C_ParserError zT_46;
    zT_3B6EA323_EU_01 zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    int zT_55;
    zT_B559F9DA_Parser* zT_56;
    int zT_58;
    zT_3A355BD2_Token zT_60 = {0};
    zT_EAC3E484_TokenKind zT_61;
    zT_B559F9DA_Parser* zT_66;
    zT_3A355BD2_Token zT_67 = {0};
    zT_B559F9DA_Parser* zT_68;
    zT_CB78802F_EU_49 zT_73 = {0};
    unsigned char zT_74;
    int zT_75;
    zT_3B6EA323_EU_01 zT_76;
    zT_2B3424E9_ParseToken zT_77;
    zT_B559F9DA_Parser* zT_79;
    zT_3B6EA323_EU_01 zT_80 = {0};
    unsigned char zT_81;
    unsigned int zT_82;
    zT_B559F9DA_Parser* zT_83;
    unsigned int** zT_84;
    unsigned int* zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    zT_B559F9DA_Parser* zT_91;
    zT_3A355BD2_Token zT_92 = {0};
    zT_EAC3E484_TokenKind zT_93;
    zT_B559F9DA_Parser* zT_98;
    zT_3A355BD2_Token zT_99 = {0};
    zT_B559F9DA_Parser* zT_100;
    zT_CB78802F_EU_49 zT_105 = {0};
    unsigned char zT_106;
    int zT_107;
    zT_3B6EA323_EU_01 zT_108;
    zT_2B3424E9_ParseToken zT_109;
    int zT_111;
    unsigned int zT_112;
    zT_B559F9DA_Parser* zT_113;
    zT_3A355BD2_Token zT_114 = {0};
    zT_EAC3E484_TokenKind zT_115;
    int zT_120;
    zT_B559F9DA_Parser* zT_121;
    zT_3A355BD2_Token zT_122 = {0};
    zT_EAC3E484_TokenKind zT_123;
    int zT_128;
    zT_B559F9DA_Parser* zT_129;
    zT_3A355BD2_Token zT_130 = {0};
    zT_EAC3E484_TokenKind zT_131;
    int zT_136;
    zT_B559F9DA_Parser* zT_137;
    zT_3A355BD2_Token zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    int zT_144;
    zT_B559F9DA_Parser* zT_145;
    zT_3A355BD2_Token zT_146 = {0};
    zT_EAC3E484_TokenKind zT_147;
    int zT_152;
    zT_B559F9DA_Parser* zT_153;
    zT_3A355BD2_Token zT_154 = {0};
    zT_EAC3E484_TokenKind zT_155;
    zT_B559F9DA_Parser* zT_160;
    zT_3B6EA323_EU_01 zT_161 = {0};
    unsigned char zT_162;
    unsigned int zT_163;
    int zT_165;
    unsigned int zT_166;
    int zT_167;
    zT_6B0A7D14_AstStore* zT_169;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_170;
    int zT_172;
    unsigned int* zT_173;
    unsigned int zT_174;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_175;
    unsigned int zT_176 = 0;
    int zT_178;
    unsigned char zT_179;
    unsigned char zT_183;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned char zT_186;
    unsigned int zT_187;
    unsigned int zT_189;
    unsigned int zT_192;
    unsigned int zT_198;
    unsigned short zT_199;
    int zT_202;
    int zT_204;
    unsigned int zT_206 = 0;
    zT_3B6EA323_EU_01 zT_207;
    zT_3A355BD2_Token tok;
    unsigned int* param_buf;
    unsigned int param_count;
    unsigned int param_cap;
    zT_3A355BD2_Token vtok;
    zT_8F083A69_Slice_zT_0B42B2F8_u v_msg;
    unsigned int p;
    unsigned int ret_type;
    unsigned int payload;
    unsigned char fn_flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_2:
    zT_14 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_14;
    param_buf = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    param_count = zT_19;
    zT_21 = 0;
    param_cap = zT_21;
    goto z_bb_4;
    z_bb_4:
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    zT_24 = zT_23.kind;
    if ((int)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_29 = self;
    zT_30 = zF_068A2DE5_parserPeek(zT_29);
    zT_31 = zT_30.kind;
    if ((int)(zT_31 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_100 = self;
    zT_105 = zF_5578C74F_parserExpect(zT_100, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_106 = zT_105.is_error;
    if (zT_106) goto z_bb_23; else goto z_bb_24;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = self;
    zT_38 = zF_C241B2C4_parserAdvance(zT_37);
    vtok = zT_38;
    zT_40 = "varargs not allowed in function pointer types";
    zT_42 = 45;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    v_msg = zT_41;
    zT_43 = self;
    zT_44 = vtok;
    zT_45 = v_msg;
    zF_17DF2CA5_parserAddError(zT_43, zT_44, zT_45);
    zT_46 = 1;
    zT_47.data.err = zT_46;
    zT_47.is_error = 1;
    return zT_47;
    z_bb_9:
    zT_48 = self;
    zT_49 = zF_068A2DE5_parserPeek(zT_48);
    zT_50 = zT_49.kind;
    if ((int)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_56 = self;
    zT_58 = 1;
    zT_60 = zF_F685E431_parserPeekN(zT_56, (unsigned int)((unsigned int)zT_58));
    zT_61 = zT_60.kind;
    zT_55 = zT_61 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon);
    goto z_bb_12;
    z_bb_11:
    zT_55 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_55) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_66 = self;
    zT_67 = zF_C241B2C4_parserAdvance(zT_66);
    (void)zT_67;
    zT_68 = self;
    zT_73 = zF_5578C74F_parserExpect(zT_68, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_74 = zT_73.is_error;
    if (zT_74) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_80 = zF_CBDBFE85_parserParseType(zT_79);
    zT_81 = zT_80.is_error;
    if (zT_81) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_75 = zT_73.data.err;
    zT_76.data.err = zT_75;
    zT_76.is_error = 1;
    return zT_76;
    z_bb_16:
    zT_77 = zT_73.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_77;
    goto z_bb_14;
    z_bb_18:
    return zT_80;
    z_bb_19:
    zT_82 = zT_80.data.payload;
    goto z_bb_20;
    z_bb_20:
    p = zT_82;
    zT_83 = self;
    zT_84 = &param_buf;
    zT_85 = &param_count;
    zT_86 = &param_cap;
    zT_87 = p;
    zF_0F1462F8_parserPushU32(zT_83, zT_84, zT_85, zT_86, zT_87);
    zT_91 = self;
    zT_92 = zF_068A2DE5_parserPeek(zT_91);
    zT_93 = zT_92.kind;
    if ((int)(zT_93 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_98 = self;
    zT_99 = zF_C241B2C4_parserAdvance(zT_98);
    (void)zT_99;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_7;
    z_bb_23:
    zT_107 = zT_105.data.err;
    zT_108.data.err = zT_107;
    zT_108.is_error = 1;
    return zT_108;
    z_bb_24:
    zT_109 = zT_105.data.payload;
    goto z_bb_25;
    z_bb_25:
    (void)zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    ret_type = zT_112;
    zT_113 = self;
    zT_114 = zF_068A2DE5_parserPeek(zT_113);
    zT_115 = zT_114.kind;
    if ((int)(zT_115 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_121 = self;
    zT_122 = zF_068A2DE5_parserPeek(zT_121);
    zT_123 = zT_122.kind;
    zT_120 = zT_123 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon);
    goto z_bb_28;
    z_bb_27:
    zT_120 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_120) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_129 = self;
    zT_130 = zF_068A2DE5_parserPeek(zT_129);
    zT_131 = zT_130.kind;
    zT_128 = zT_131 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_31;
    z_bb_30:
    zT_128 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_128) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_137 = self;
    zT_138 = zF_068A2DE5_parserPeek(zT_137);
    zT_139 = zT_138.kind;
    zT_136 = zT_139 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen);
    goto z_bb_34;
    z_bb_33:
    zT_136 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_136) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_145 = self;
    zT_146 = zF_068A2DE5_parserPeek(zT_145);
    zT_147 = zT_146.kind;
    zT_144 = zT_147 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket);
    goto z_bb_37;
    z_bb_36:
    zT_144 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_144) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_153 = self;
    zT_154 = zF_068A2DE5_parserPeek(zT_153);
    zT_155 = zT_154.kind;
    zT_152 = zT_155 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_40;
    z_bb_39:
    zT_152 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_152) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_160 = self;
    zT_161 = zF_CBDBFE85_parserParseType(zT_160);
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_165 = 0;
    zT_166 = (unsigned int)zT_165;
    payload = zT_166;
    zT_167 = 0;
    if ((int)(param_count > (unsigned int)zT_167)) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_161;
    z_bb_44:
    zT_163 = zT_161.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type = zT_163;
    goto z_bb_42;
    z_bb_46:
    zT_169 = self->store;
    zT_172 = 0;
    zT_173 = param_buf + zT_172;
    zT_174 = param_count - zT_172;
    zT_175.ptr = zT_173;
    zT_175.len = zT_174;
    zT_170 = zT_175;
    zT_176 = zF_583E993C_astStoreAddExtraChi(zT_169, zT_170);
    payload = zT_176;
    goto z_bb_47;
    z_bb_47:
    zT_178 = 0;
    zT_179 = (unsigned char)zT_178;
    fn_flags = zT_179;
    if ((int)(call_conv == (unsigned int)(1))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_183 = fn_flags | (unsigned char)(1);
    fn_flags = zT_183;
    goto z_bb_49;
    z_bb_49:
    zT_184 = self->store;
    zT_186 = fn_flags;
    zT_187 = tok.span_start;
    zT_198 = tok.span_start;
    zT_199 = tok.span_len;
    zT_189 = ret_type;
    zT_202 = 0;
    zT_204 = 0;
    zT_192 = payload;
    zT_206 = zF_6C9FF72F_astStoreAddNode(zT_184, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type), zT_186, zT_187, (unsigned int)(zT_198 + (unsigned int)((unsigned int)zT_199)), zT_189, (unsigned int)((unsigned int)zT_202), (unsigned int)((unsigned int)zT_204), zT_192);
    zT_207.data.payload = zT_206;
    zT_207.is_error = 0;
    return zT_207;
}

/* parserParseErrorSetDecl */
zT_3B6EA323_EU_01 zF_BFAD1973_parserParseErrorSet(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = tok;
    zT_6 = zF_2C55CABB_parserParseErrorSet(zT_4, zT_5);
    return zT_6;
}

/* parserParseErrorSetDeclBody */
zT_3B6EA323_EU_01 zF_2C55CABB_parserParseErrorSet(zT_B559F9DA_Parser* self, zT_3A355BD2_Token kw) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_7 = {0};
    unsigned char zT_8;
    int zT_9;
    zT_3B6EA323_EU_01 zT_10;
    zT_2B3424E9_ParseToken zT_11;
    int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_19;
    zT_3A355BD2_Token zT_20 = {0};
    zT_EAC3E484_TokenKind zT_21;
    zT_B559F9DA_Parser* zT_27;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    zT_2B3424E9_ParseToken zT_38;
    zT_EAC3E484_TokenKind zT_39;
    unsigned int zT_40;
    unsigned short zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_B559F9DA_Parser* zT_46;
    zT_2B3424E9_ParseToken zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48 = {0};
    unsigned int zT_49 = 0;
    zT_B559F9DA_Parser* zT_50;
    unsigned int** zT_51;
    unsigned int* zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    zT_B559F9DA_Parser* zT_58;
    zT_3A355BD2_Token zT_59 = {0};
    zT_EAC3E484_TokenKind zT_60;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_B559F9DA_Parser* zT_67;
    zT_CB78802F_EU_49 zT_72 = {0};
    unsigned char zT_73;
    int zT_74;
    zT_3B6EA323_EU_01 zT_75;
    zT_2B3424E9_ParseToken zT_76;
    int zT_78;
    unsigned int zT_79;
    int zT_80;
    zT_6B0A7D14_AstStore* zT_82;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83;
    int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_88;
    unsigned int zT_89 = 0;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_93;
    unsigned int zT_98;
    int zT_103;
    unsigned int zT_106;
    unsigned short zT_107;
    int zT_110;
    int zT_112;
    int zT_114;
    unsigned int zT_116 = 0;
    zT_3B6EA323_EU_01 zT_117;
    unsigned int* member_buf;
    unsigned int member_count;
    unsigned int member_cap;
    zT_2B3424E9_ParseToken tag_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int tag_id;
    unsigned int payload;
    zT_2 = self;
    zT_7 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = zT_7.data.err;
    zT_10.data.err = zT_9;
    zT_10.is_error = 1;
    return zT_10;
    z_bb_2:
    zT_11 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_11;
    zT_13 = 0;
    member_buf = (unsigned int*)zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    member_count = zT_16;
    zT_18 = 0;
    member_cap = zT_18;
    goto z_bb_4;
    z_bb_4:
    zT_19 = self;
    zT_20 = zF_068A2DE5_parserPeek(zT_19);
    zT_21 = zT_20.kind;
    if ((int)(zT_21 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_27, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_67 = self;
    zT_72 = zF_5578C74F_parserExpect(zT_67, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_73 = zT_72.is_error;
    if (zT_73) goto z_bb_13; else goto z_bb_14;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_9:
    zT_36 = zT_32.data.payload;
    goto z_bb_10;
    z_bb_10:
    tag_tok = zT_36;
    zT_39 = tag_tok.kind;
    zT_38.kind = zT_39;
    zT_40 = tag_tok.span_start;
    zT_38.span_start = zT_40;
    zT_41 = tag_tok.span_len;
    zT_38.span_len = zT_41;
    pt = zT_38;
    zT_43 = self->interner;
    zT_46 = self;
    zT_47 = pt;
    zT_48 = zF_08D61E58_parserTokenText(zT_46, zT_47);
    zT_44 = zT_48;
    zT_49 = zF_50C274AF_stringInternerInter(zT_43, zT_44);
    tag_id = zT_49;
    zT_50 = self;
    zT_51 = &member_buf;
    zT_52 = &member_count;
    zT_53 = &member_cap;
    zT_54 = tag_id;
    zF_0F1462F8_parserPushU32(zT_50, zT_51, zT_52, zT_53, zT_54);
    zT_58 = self;
    zT_59 = zF_068A2DE5_parserPeek(zT_58);
    zT_60 = zT_59.kind;
    if ((int)(zT_60 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_65 = self;
    zT_66 = zF_C241B2C4_parserAdvance(zT_65);
    (void)zT_66;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_74 = zT_72.data.err;
    zT_75.data.err = zT_74;
    zT_75.is_error = 1;
    return zT_75;
    z_bb_14:
    zT_76 = zT_72.data.payload;
    goto z_bb_15;
    z_bb_15:
    (void)zT_76;
    zT_78 = 0;
    zT_79 = (unsigned int)zT_78;
    payload = zT_79;
    zT_80 = 0;
    if ((int)(member_count > (unsigned int)zT_80)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_82 = self->store;
    zT_85 = 0;
    zT_86 = member_buf + zT_85;
    zT_87 = member_count - zT_85;
    zT_88.ptr = zT_86;
    zT_88.len = zT_87;
    zT_83 = zT_88;
    zT_89 = zF_583E993C_astStoreAddExtraChi(zT_82, zT_83);
    payload = zT_89;
    goto z_bb_17;
    z_bb_17:
    zT_90 = self->store;
    zT_103 = 0;
    zT_93 = kw.span_start;
    zT_106 = kw.span_start;
    zT_107 = kw.span_len;
    zT_110 = 0;
    zT_112 = 0;
    zT_114 = 0;
    zT_98 = payload;
    zT_116 = zF_6C9FF72F_astStoreAddNode(zT_90, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl), (unsigned char)((unsigned char)zT_103), zT_93, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), (unsigned int)((unsigned int)zT_110), (unsigned int)((unsigned int)zT_112), (unsigned int)((unsigned int)zT_114), zT_98);
    zT_117.data.payload = zT_116;
    zT_117.is_error = 0;
    return zT_117;
}

/* parserParseStructType */
zT_3B6EA323_EU_01 zF_3530D6C0_parserParseStructTy(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    unsigned int* zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    zT_B559F9DA_Parser* zT_30;
    zT_CB78802F_EU_49 zT_35 = {0};
    unsigned char zT_36;
    int zT_37;
    zT_3B6EA323_EU_01 zT_38;
    zT_2B3424E9_ParseToken zT_39;
    zT_B559F9DA_Parser* zT_40;
    zT_CB78802F_EU_49 zT_45 = {0};
    unsigned char zT_46;
    int zT_47;
    zT_3B6EA323_EU_01 zT_48;
    zT_2B3424E9_ParseToken zT_49;
    zT_2B3424E9_ParseToken zT_51;
    zT_EAC3E484_TokenKind zT_52;
    unsigned int zT_53;
    unsigned short zT_54;
    zT_D3EB6303_StringInterner* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_B559F9DA_Parser* zT_59;
    zT_2B3424E9_ParseToken zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    unsigned int zT_62 = 0;
    zT_B559F9DA_Parser* zT_64;
    zT_3B6EA323_EU_01 zT_65 = {0};
    unsigned char zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_77;
    int zT_82;
    unsigned int zT_85;
    unsigned short zT_86;
    int zT_89;
    int zT_91;
    unsigned int zT_93 = 0;
    zT_B559F9DA_Parser* zT_94;
    unsigned int** zT_95;
    unsigned int* zT_96;
    unsigned int* zT_97;
    unsigned int zT_98;
    zT_B559F9DA_Parser* zT_102;
    zT_3A355BD2_Token zT_103 = {0};
    zT_EAC3E484_TokenKind zT_104;
    zT_B559F9DA_Parser* zT_109;
    zT_3A355BD2_Token zT_110 = {0};
    zT_B559F9DA_Parser* zT_111;
    zT_CB78802F_EU_49 zT_116 = {0};
    unsigned char zT_117;
    int zT_118;
    zT_3B6EA323_EU_01 zT_119;
    zT_2B3424E9_ParseToken zT_120;
    int zT_122;
    unsigned int zT_123;
    int zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_127;
    int zT_129;
    unsigned int* zT_130;
    unsigned int zT_131;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_132;
    unsigned int zT_133 = 0;
    int zT_135;
    unsigned char zT_136;
    unsigned char zT_140;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned char zT_143;
    unsigned int zT_144;
    unsigned int zT_149;
    unsigned int zT_155;
    unsigned short zT_156;
    int zT_159;
    int zT_161;
    int zT_163;
    unsigned int zT_165 = 0;
    zT_3B6EA323_EU_01 zT_166;
    zT_3A355BD2_Token tok;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken npt;
    unsigned int name_id;
    unsigned int field_type;
    unsigned int field_node;
    unsigned int payload;
    unsigned char flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_2:
    zT_14 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_14;
    fields_buf = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    fields_count = zT_19;
    zT_21 = 0;
    fields_cap = zT_21;
    goto z_bb_4;
    z_bb_4:
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    zT_24 = zT_23.kind;
    if ((int)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = self;
    zT_35 = zF_5578C74F_parserExpect(zT_30, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_111 = self;
    zT_116 = zF_5578C74F_parserExpect(zT_111, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_19; else goto z_bb_20;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = zT_35.data.err;
    zT_38.data.err = zT_37;
    zT_38.is_error = 1;
    return zT_38;
    z_bb_9:
    zT_39 = zT_35.data.payload;
    goto z_bb_10;
    z_bb_10:
    name_tok = zT_39;
    zT_40 = self;
    zT_45 = zF_5578C74F_parserExpect(zT_40, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_47 = zT_45.data.err;
    zT_48.data.err = zT_47;
    zT_48.is_error = 1;
    return zT_48;
    z_bb_12:
    zT_49 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    (void)zT_49;
    zT_52 = name_tok.kind;
    zT_51.kind = zT_52;
    zT_53 = name_tok.span_start;
    zT_51.span_start = zT_53;
    zT_54 = name_tok.span_len;
    zT_51.span_len = zT_54;
    npt = zT_51;
    zT_56 = self->interner;
    zT_59 = self;
    zT_60 = npt;
    zT_61 = zF_08D61E58_parserTokenText(zT_59, zT_60);
    zT_57 = zT_61;
    zT_62 = zF_50C274AF_stringInternerInter(zT_56, zT_57);
    name_id = zT_62;
    zT_64 = self;
    zT_65 = zF_CBDBFE85_parserParseType(zT_64);
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return zT_65;
    z_bb_15:
    zT_67 = zT_65.data.payload;
    goto z_bb_16;
    z_bb_16:
    field_type = zT_67;
    zT_69 = self->store;
    zT_82 = 0;
    zT_72 = name_tok.span_start;
    zT_85 = name_tok.span_start;
    zT_86 = name_tok.span_len;
    zT_74 = field_type;
    zT_89 = 0;
    zT_91 = 0;
    zT_77 = name_id;
    zT_93 = zF_6C9FF72F_astStoreAddNode(zT_69, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_82), zT_72, (unsigned int)(zT_85 + (unsigned int)((unsigned int)zT_86)), zT_74, (unsigned int)((unsigned int)zT_89), (unsigned int)((unsigned int)zT_91), zT_77);
    field_node = zT_93;
    zT_94 = self;
    zT_95 = &fields_buf;
    zT_96 = &fields_count;
    zT_97 = &fields_cap;
    zT_98 = field_node;
    zF_0F1462F8_parserPushU32(zT_94, zT_95, zT_96, zT_97, zT_98);
    zT_102 = self;
    zT_103 = zF_068A2DE5_parserPeek(zT_102);
    zT_104 = zT_103.kind;
    if ((int)(zT_104 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_109 = self;
    zT_110 = zF_C241B2C4_parserAdvance(zT_109);
    (void)zT_110;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_7;
    z_bb_19:
    zT_118 = zT_116.data.err;
    zT_119.data.err = zT_118;
    zT_119.is_error = 1;
    return zT_119;
    z_bb_20:
    zT_120 = zT_116.data.payload;
    goto z_bb_21;
    z_bb_21:
    (void)zT_120;
    zT_122 = 0;
    zT_123 = (unsigned int)zT_122;
    payload = zT_123;
    zT_124 = 0;
    if ((int)(fields_count > (unsigned int)zT_124)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_126 = self->store;
    zT_129 = 0;
    zT_130 = fields_buf + zT_129;
    zT_131 = fields_count - zT_129;
    zT_132.ptr = zT_130;
    zT_132.len = zT_131;
    zT_127 = zT_132;
    zT_133 = zF_583E993C_astStoreAddExtraChi(zT_126, zT_127);
    payload = zT_133;
    goto z_bb_23;
    z_bb_23:
    zT_135 = 0;
    zT_136 = (unsigned char)zT_135;
    flags = zT_136;
    if ((int)(is_packed != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_140 = flags | (unsigned char)(16);
    flags = zT_140;
    goto z_bb_25;
    z_bb_25:
    zT_141 = self->store;
    zT_143 = flags;
    zT_144 = tok.span_start;
    zT_155 = tok.span_start;
    zT_156 = tok.span_len;
    zT_159 = 0;
    zT_161 = 0;
    zT_163 = 0;
    zT_149 = payload;
    zT_165 = zF_6C9FF72F_astStoreAddNode(zT_141, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl), zT_143, zT_144, (unsigned int)(zT_155 + (unsigned int)((unsigned int)zT_156)), (unsigned int)((unsigned int)zT_159), (unsigned int)((unsigned int)zT_161), (unsigned int)((unsigned int)zT_163), zT_149);
    zT_166.data.payload = zT_165;
    zT_166.is_error = 0;
    return zT_166;
}

/* parserParseEnumType */
zT_3B6EA323_EU_01 zF_63EC2480_parserParseEnumType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_25 = {0};
    unsigned char zT_26;
    int zT_27;
    zT_3B6EA323_EU_01 zT_28;
    zT_2B3424E9_ParseToken zT_29;
    zT_B559F9DA_Parser* zT_30;
    zT_CB78802F_EU_49 zT_35 = {0};
    unsigned char zT_36;
    int zT_37;
    zT_3B6EA323_EU_01 zT_38;
    zT_2B3424E9_ParseToken zT_39;
    unsigned int* zT_41 = 0;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    zT_B559F9DA_Parser* zT_47;
    zT_3A355BD2_Token zT_48 = {0};
    zT_EAC3E484_TokenKind zT_49;
    zT_B559F9DA_Parser* zT_55;
    zT_CB78802F_EU_49 zT_60 = {0};
    unsigned char zT_61;
    int zT_62;
    zT_3B6EA323_EU_01 zT_63;
    zT_2B3424E9_ParseToken zT_64;
    zT_2B3424E9_ParseToken zT_66;
    zT_EAC3E484_TokenKind zT_67;
    unsigned int zT_68;
    unsigned short zT_69;
    zT_D3EB6303_StringInterner* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_B559F9DA_Parser* zT_74;
    zT_2B3424E9_ParseToken zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76 = {0};
    unsigned int zT_77 = 0;
    int zT_79;
    unsigned int zT_80;
    zT_B559F9DA_Parser* zT_81;
    zT_3A355BD2_Token zT_82 = {0};
    zT_EAC3E484_TokenKind zT_83;
    zT_B559F9DA_Parser* zT_88;
    zT_3A355BD2_Token zT_89 = {0};
    zT_B559F9DA_Parser* zT_90;
    zT_3B6EA323_EU_01 zT_93 = {0};
    unsigned char zT_94;
    unsigned int zT_95;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_100;
    unsigned int zT_103;
    unsigned int zT_105;
    int zT_110;
    unsigned int zT_113;
    unsigned short zT_114;
    int zT_117;
    int zT_119;
    unsigned int zT_121 = 0;
    zT_B559F9DA_Parser* zT_122;
    unsigned int** zT_123;
    unsigned int* zT_124;
    unsigned int* zT_125;
    unsigned int zT_126;
    zT_B559F9DA_Parser* zT_130;
    zT_3A355BD2_Token zT_131 = {0};
    zT_EAC3E484_TokenKind zT_132;
    zT_B559F9DA_Parser* zT_137;
    zT_3A355BD2_Token zT_138 = {0};
    zT_B559F9DA_Parser* zT_139;
    zT_CB78802F_EU_49 zT_144 = {0};
    unsigned char zT_145;
    int zT_146;
    zT_3B6EA323_EU_01 zT_147;
    zT_2B3424E9_ParseToken zT_148;
    int zT_150;
    unsigned int zT_151;
    int zT_152;
    zT_6B0A7D14_AstStore* zT_154;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_155;
    int zT_157;
    unsigned int* zT_158;
    unsigned int zT_159;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_160;
    unsigned int zT_161 = 0;
    zT_6B0A7D14_AstStore* zT_162;
    unsigned int zT_165;
    unsigned int zT_167;
    unsigned int zT_170;
    int zT_175;
    unsigned int zT_178;
    unsigned short zT_179;
    int zT_182;
    int zT_184;
    unsigned int zT_186 = 0;
    zT_3B6EA323_EU_01 zT_187;
    zT_3A355BD2_Token tok;
    unsigned int backing_type2;
    unsigned int* members_buf;
    unsigned int members_count;
    unsigned int members_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken mpt;
    unsigned int name_id;
    unsigned int value_expr;
    unsigned int mnode;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    backing_type2 = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((int)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    (void)zT_15;
    zT_16 = self;
    zT_17 = zF_CBDBFE85_parserParseType(zT_16);
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_30 = self;
    zT_35 = zF_5578C74F_parserExpect(zT_30, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    return zT_17;
    z_bb_4:
    zT_19 = zT_17.data.payload;
    goto z_bb_5;
    z_bb_5:
    backing_type2 = zT_19;
    zT_20 = self;
    zT_25 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = zT_25.data.err;
    zT_28.data.err = zT_27;
    zT_28.is_error = 1;
    return zT_28;
    z_bb_7:
    zT_29 = zT_25.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_29;
    goto z_bb_2;
    z_bb_9:
    zT_37 = zT_35.data.err;
    zT_38.data.err = zT_37;
    zT_38.is_error = 1;
    return zT_38;
    z_bb_10:
    zT_39 = zT_35.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_39;
    members_buf = zT_41;
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    members_count = zT_44;
    zT_46 = 0;
    members_cap = zT_46;
    goto z_bb_12;
    z_bb_12:
    zT_47 = self;
    zT_48 = zF_068A2DE5_parserPeek(zT_47);
    zT_49 = zT_48.kind;
    if ((int)(zT_49 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_55 = self;
    zT_60 = zF_5578C74F_parserExpect(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_139 = self;
    zT_144 = zF_5578C74F_parserExpect(zT_139, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_145 = zT_144.is_error;
    if (zT_145) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_62 = zT_60.data.err;
    zT_63.data.err = zT_62;
    zT_63.is_error = 1;
    return zT_63;
    z_bb_17:
    zT_64 = zT_60.data.payload;
    goto z_bb_18;
    z_bb_18:
    name_tok = zT_64;
    zT_67 = name_tok.kind;
    zT_66.kind = zT_67;
    zT_68 = name_tok.span_start;
    zT_66.span_start = zT_68;
    zT_69 = name_tok.span_len;
    zT_66.span_len = zT_69;
    mpt = zT_66;
    zT_71 = self->interner;
    zT_74 = self;
    zT_75 = mpt;
    zT_76 = zF_08D61E58_parserTokenText(zT_74, zT_75);
    zT_72 = zT_76;
    zT_77 = zF_50C274AF_stringInternerInter(zT_71, zT_72);
    name_id = zT_77;
    zT_79 = 0;
    zT_80 = (unsigned int)zT_79;
    value_expr = zT_80;
    zT_81 = self;
    zT_82 = zF_068A2DE5_parserPeek(zT_81);
    zT_83 = zT_82.kind;
    if ((int)(zT_83 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_88 = self;
    zT_89 = zF_C241B2C4_parserAdvance(zT_88);
    (void)zT_89;
    zT_90 = self;
    zT_93 = zF_F07C1F04_parserParseExprPrec(zT_90, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_94 = zT_93.is_error;
    if (zT_94) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_97 = self->store;
    zT_110 = 0;
    zT_100 = name_tok.span_start;
    zT_113 = name_tok.span_start;
    zT_114 = name_tok.span_len;
    zT_117 = 0;
    zT_103 = value_expr;
    zT_119 = 0;
    zT_105 = name_id;
    zT_121 = zF_6C9FF72F_astStoreAddNode(zT_97, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_110), zT_100, (unsigned int)(zT_113 + (unsigned int)((unsigned int)zT_114)), (unsigned int)((unsigned int)zT_117), zT_103, (unsigned int)((unsigned int)zT_119), zT_105);
    mnode = zT_121;
    zT_122 = self;
    zT_123 = &members_buf;
    zT_124 = &members_count;
    zT_125 = &members_cap;
    zT_126 = mnode;
    zF_0F1462F8_parserPushU32(zT_122, zT_123, zT_124, zT_125, zT_126);
    zT_130 = self;
    zT_131 = zF_068A2DE5_parserPeek(zT_130);
    zT_132 = zT_131.kind;
    if ((int)(zT_132 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    return zT_93;
    z_bb_22:
    zT_95 = zT_93.data.payload;
    goto z_bb_23;
    z_bb_23:
    value_expr = zT_95;
    goto z_bb_20;
    z_bb_24:
    zT_137 = self;
    zT_138 = zF_C241B2C4_parserAdvance(zT_137);
    (void)zT_138;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_15;
    z_bb_26:
    zT_146 = zT_144.data.err;
    zT_147.data.err = zT_146;
    zT_147.is_error = 1;
    return zT_147;
    z_bb_27:
    zT_148 = zT_144.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_148;
    zT_150 = 0;
    zT_151 = (unsigned int)zT_150;
    payload = zT_151;
    zT_152 = 0;
    if ((int)(members_count > (unsigned int)zT_152)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_154 = self->store;
    zT_157 = 0;
    zT_158 = members_buf + zT_157;
    zT_159 = members_count - zT_157;
    zT_160.ptr = zT_158;
    zT_160.len = zT_159;
    zT_155 = zT_160;
    zT_161 = zF_583E993C_astStoreAddExtraChi(zT_154, zT_155);
    payload = zT_161;
    goto z_bb_30;
    z_bb_30:
    zT_162 = self->store;
    zT_175 = 0;
    zT_165 = tok.span_start;
    zT_178 = tok.span_start;
    zT_179 = tok.span_len;
    zT_167 = backing_type2;
    zT_182 = 0;
    zT_184 = 0;
    zT_170 = payload;
    zT_186 = zF_6C9FF72F_astStoreAddNode(zT_162, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl), (unsigned char)((unsigned char)zT_175), zT_165, (unsigned int)(zT_178 + (unsigned int)((unsigned int)zT_179)), zT_167, (unsigned int)((unsigned int)zT_182), (unsigned int)((unsigned int)zT_184), zT_170);
    zT_187.data.payload = zT_186;
    zT_187.is_error = 0;
    return zT_187;
}

/* parserParseUnionType */
zT_3B6EA323_EU_01 zF_0881F8E4_parserParseUnionTyp(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned char zT_7;
    int zT_9;
    unsigned char zT_10;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_EAC3E484_TokenKind zT_13;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_25 = {0};
    unsigned char zT_26;
    int zT_27;
    zT_3B6EA323_EU_01 zT_28;
    zT_2B3424E9_ParseToken zT_29;
    zT_B559F9DA_Parser* zT_30;
    zT_CB78802F_EU_49 zT_35 = {0};
    unsigned char zT_36;
    int zT_37;
    zT_3B6EA323_EU_01 zT_38;
    zT_2B3424E9_ParseToken zT_39;
    int zT_40;
    unsigned char zT_41;
    int zT_44;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_B559F9DA_Parser* zT_51;
    zT_3A355BD2_Token zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_DBF3575C_ParserError zT_54;
    zT_3B6EA323_EU_01 zT_55;
    unsigned char zT_59;
    unsigned char zT_63;
    zT_B559F9DA_Parser* zT_64;
    zT_CB78802F_EU_49 zT_69 = {0};
    unsigned char zT_70;
    int zT_71;
    zT_3B6EA323_EU_01 zT_72;
    zT_2B3424E9_ParseToken zT_73;
    unsigned int* zT_75 = 0;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_80;
    zT_B559F9DA_Parser* zT_81;
    zT_3A355BD2_Token zT_82 = {0};
    zT_EAC3E484_TokenKind zT_83;
    zT_B559F9DA_Parser* zT_89;
    zT_CB78802F_EU_49 zT_94 = {0};
    unsigned char zT_95;
    int zT_96;
    zT_3B6EA323_EU_01 zT_97;
    zT_2B3424E9_ParseToken zT_98;
    zT_2B3424E9_ParseToken zT_100;
    zT_EAC3E484_TokenKind zT_101;
    unsigned int zT_102;
    unsigned short zT_103;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    zT_B559F9DA_Parser* zT_108;
    zT_2B3424E9_ParseToken zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110 = {0};
    unsigned int zT_111 = 0;
    int zT_113;
    unsigned int zT_114;
    zT_B559F9DA_Parser* zT_115;
    zT_3A355BD2_Token zT_116 = {0};
    zT_EAC3E484_TokenKind zT_117;
    zT_B559F9DA_Parser* zT_122;
    zT_3A355BD2_Token zT_123 = {0};
    zT_B559F9DA_Parser* zT_125;
    zT_3B6EA323_EU_01 zT_126 = {0};
    unsigned char zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_129;
    unsigned int zT_132;
    unsigned int zT_134;
    unsigned int zT_137;
    int zT_142;
    unsigned int zT_145;
    unsigned short zT_146;
    int zT_149;
    int zT_151;
    unsigned int zT_153 = 0;
    zT_6B0A7D14_AstStore* zT_154;
    unsigned int zT_157;
    unsigned int zT_162;
    int zT_167;
    unsigned int zT_170;
    unsigned short zT_171;
    int zT_174;
    int zT_176;
    int zT_178;
    unsigned int zT_180 = 0;
    zT_B559F9DA_Parser* zT_181;
    unsigned int** zT_182;
    unsigned int* zT_183;
    unsigned int* zT_184;
    unsigned int zT_185;
    zT_B559F9DA_Parser* zT_189;
    zT_3A355BD2_Token zT_190 = {0};
    zT_EAC3E484_TokenKind zT_191;
    zT_B559F9DA_Parser* zT_196;
    zT_3A355BD2_Token zT_197 = {0};
    zT_B559F9DA_Parser* zT_198;
    zT_CB78802F_EU_49 zT_203 = {0};
    unsigned char zT_204;
    int zT_205;
    zT_3B6EA323_EU_01 zT_206;
    zT_2B3424E9_ParseToken zT_207;
    int zT_209;
    unsigned int zT_210;
    int zT_211;
    zT_6B0A7D14_AstStore* zT_213;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_214;
    int zT_216;
    unsigned int* zT_217;
    unsigned int zT_218;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_219;
    unsigned int zT_220 = 0;
    zT_8143F551_AstKind zT_224;
    int zT_225;
    zT_6B0A7D14_AstStore* zT_227;
    zT_8143F551_AstKind zT_228;
    unsigned char zT_229;
    unsigned int zT_230;
    unsigned int zT_235;
    unsigned int zT_238;
    unsigned short zT_239;
    int zT_242;
    int zT_244;
    int zT_246;
    unsigned int zT_248 = 0;
    zT_3B6EA323_EU_01 zT_249;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned char is_tagged;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_msg;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken upt;
    unsigned int name_id;
    unsigned int field_node;
    unsigned int field_type;
    unsigned int payload;
    zT_8143F551_AstKind kind;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned char)zT_6;
    flags = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_11 = self;
    zT_12 = zF_068A2DE5_parserPeek(zT_11);
    zT_13 = zT_12.kind;
    if ((int)(zT_13 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = self;
    zT_19 = zF_C241B2C4_parserAdvance(zT_18);
    (void)zT_19;
    zT_20 = self;
    zT_25 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((int)(is_tagged != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_27 = zT_25.data.err;
    zT_28.data.err = zT_27;
    zT_28.is_error = 1;
    return zT_28;
    z_bb_4:
    zT_29 = zT_25.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_29;
    zT_30 = self;
    zT_35 = zF_5578C74F_parserExpect(zT_30, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_37 = zT_35.data.err;
    zT_38.data.err = zT_37;
    zT_38.is_error = 1;
    return zT_38;
    z_bb_7:
    zT_39 = zT_35.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_39;
    zT_40 = 1;
    zT_41 = (unsigned char)zT_40;
    is_tagged = zT_41;
    goto z_bb_2;
    z_bb_9:
    zT_44 = is_packed != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_44 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_44) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_48 = "packed unions cannot be tagged (union(enum)); packed union is an untagged container";
    zT_50 = 83;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    tag_msg = zT_49;
    zT_51 = self;
    zT_52 = tok;
    zT_53 = tag_msg;
    zF_17DF2CA5_parserAddError(zT_51, zT_52, zT_53);
    zT_54 = 1;
    zT_55.data.err = zT_54;
    zT_55.is_error = 1;
    return zT_55;
    z_bb_13:
    if ((int)(is_tagged != (unsigned char)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_59 = flags | (unsigned char)(1);
    flags = zT_59;
    goto z_bb_15;
    z_bb_15:
    if ((int)(is_packed != (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_63 = flags | (unsigned char)(16);
    flags = zT_63;
    goto z_bb_17;
    z_bb_17:
    zT_64 = self;
    zT_69 = zF_5578C74F_parserExpect(zT_64, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_70 = zT_69.is_error;
    if (zT_70) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_71 = zT_69.data.err;
    zT_72.data.err = zT_71;
    zT_72.is_error = 1;
    return zT_72;
    z_bb_19:
    zT_73 = zT_69.data.payload;
    goto z_bb_20;
    z_bb_20:
    (void)zT_73;
    fields_buf = zT_75;
    zT_77 = 0;
    zT_78 = (unsigned int)zT_77;
    fields_count = zT_78;
    zT_80 = 0;
    fields_cap = zT_80;
    goto z_bb_21;
    z_bb_21:
    zT_81 = self;
    zT_82 = zF_068A2DE5_parserPeek(zT_81);
    zT_83 = zT_82.kind;
    if ((int)(zT_83 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_89 = self;
    zT_94 = zF_5578C74F_parserExpect(zT_89, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_95 = zT_94.is_error;
    if (zT_95) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_198 = self;
    zT_203 = zF_5578C74F_parserExpect(zT_198, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_204 = zT_203.is_error;
    if (zT_204) goto z_bb_36; else goto z_bb_37;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_96 = zT_94.data.err;
    zT_97.data.err = zT_96;
    zT_97.is_error = 1;
    return zT_97;
    z_bb_26:
    zT_98 = zT_94.data.payload;
    goto z_bb_27;
    z_bb_27:
    name_tok = zT_98;
    zT_101 = name_tok.kind;
    zT_100.kind = zT_101;
    zT_102 = name_tok.span_start;
    zT_100.span_start = zT_102;
    zT_103 = name_tok.span_len;
    zT_100.span_len = zT_103;
    upt = zT_100;
    zT_105 = self->interner;
    zT_108 = self;
    zT_109 = upt;
    zT_110 = zF_08D61E58_parserTokenText(zT_108, zT_109);
    zT_106 = zT_110;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    name_id = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    field_node = zT_114;
    zT_115 = self;
    zT_116 = zF_068A2DE5_parserPeek(zT_115);
    zT_117 = zT_116.kind;
    if ((int)(zT_117 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_122 = self;
    zT_123 = zF_C241B2C4_parserAdvance(zT_122);
    (void)zT_123;
    zT_125 = self;
    zT_126 = zF_CBDBFE85_parserParseType(zT_125);
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_181 = self;
    zT_182 = &fields_buf;
    zT_183 = &fields_count;
    zT_184 = &fields_cap;
    zT_185 = field_node;
    zF_0F1462F8_parserPushU32(zT_181, zT_182, zT_183, zT_184, zT_185);
    zT_189 = self;
    zT_190 = zF_068A2DE5_parserPeek(zT_189);
    zT_191 = zT_190.kind;
    if ((int)(zT_191 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    zT_154 = self->store;
    zT_167 = 0;
    zT_157 = name_tok.span_start;
    zT_170 = name_tok.span_start;
    zT_171 = name_tok.span_len;
    zT_174 = 0;
    zT_176 = 0;
    zT_178 = 0;
    zT_162 = name_id;
    zT_180 = zF_6C9FF72F_astStoreAddNode(zT_154, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_167), zT_157, (unsigned int)(zT_170 + (unsigned int)((unsigned int)zT_171)), (unsigned int)((unsigned int)zT_174), (unsigned int)((unsigned int)zT_176), (unsigned int)((unsigned int)zT_178), zT_162);
    field_node = zT_180;
    goto z_bb_29;
    z_bb_31:
    return zT_126;
    z_bb_32:
    zT_128 = zT_126.data.payload;
    goto z_bb_33;
    z_bb_33:
    field_type = zT_128;
    zT_129 = self->store;
    zT_142 = 0;
    zT_132 = name_tok.span_start;
    zT_145 = name_tok.span_start;
    zT_146 = name_tok.span_len;
    zT_134 = field_type;
    zT_149 = 0;
    zT_151 = 0;
    zT_137 = name_id;
    zT_153 = zF_6C9FF72F_astStoreAddNode(zT_129, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_142), zT_132, (unsigned int)(zT_145 + (unsigned int)((unsigned int)zT_146)), zT_134, (unsigned int)((unsigned int)zT_149), (unsigned int)((unsigned int)zT_151), zT_137);
    field_node = zT_153;
    goto z_bb_29;
    z_bb_34:
    zT_196 = self;
    zT_197 = zF_C241B2C4_parserAdvance(zT_196);
    (void)zT_197;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_24;
    z_bb_36:
    zT_205 = zT_203.data.err;
    zT_206.data.err = zT_205;
    zT_206.is_error = 1;
    return zT_206;
    z_bb_37:
    zT_207 = zT_203.data.payload;
    goto z_bb_38;
    z_bb_38:
    (void)zT_207;
    zT_209 = 0;
    zT_210 = (unsigned int)zT_209;
    payload = zT_210;
    zT_211 = 0;
    if ((int)(fields_count > (unsigned int)zT_211)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_213 = self->store;
    zT_216 = 0;
    zT_217 = fields_buf + zT_216;
    zT_218 = fields_count - zT_216;
    zT_219.ptr = zT_217;
    zT_219.len = zT_218;
    zT_214 = zT_219;
    zT_220 = zF_583E993C_astStoreAddExtraChi(zT_213, zT_214);
    payload = zT_220;
    goto z_bb_40;
    z_bb_40:
    zT_224 = zT_8143F551_AstKind_union_decl;
    kind = zT_224;
    zT_225 = 0;
    if ((int)(is_tagged != zT_225)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_42;
    z_bb_42:
    zT_227 = self->store;
    zT_228 = kind;
    zT_229 = flags;
    zT_230 = tok.span_start;
    zT_238 = tok.span_start;
    zT_239 = tok.span_len;
    zT_242 = 0;
    zT_244 = 0;
    zT_246 = 0;
    zT_235 = payload;
    zT_248 = zF_6C9FF72F_astStoreAddNode(zT_227, zT_228, zT_229, zT_230, (unsigned int)(zT_238 + (unsigned int)((unsigned int)zT_239)), (unsigned int)((unsigned int)zT_242), (unsigned int)((unsigned int)zT_244), (unsigned int)((unsigned int)zT_246), zT_235);
    zT_249.data.payload = zT_248;
    zT_249.is_error = 0;
    return zT_249;
}

/* parserParseTypeName */
zT_3B6EA323_EU_01 zF_C8A1E2C6_parserParseTypeName(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_2B3424E9_ParseToken zT_5;
    zT_EAC3E484_TokenKind zT_6;
    unsigned int zT_7;
    unsigned short zT_8;
    zT_D3EB6303_StringInterner* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_B559F9DA_Parser* zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15 = {0};
    unsigned int zT_16 = 0;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_28;
    unsigned short zT_29;
    unsigned int zT_32 = 0;
    zT_B559F9DA_Parser* zT_33;
    zT_3A355BD2_Token zT_34 = {0};
    zT_EAC3E484_TokenKind zT_35;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41 = {0};
    zT_B559F9DA_Parser* zT_43;
    zT_CB78802F_EU_49 zT_48 = {0};
    unsigned char zT_49;
    int zT_50;
    zT_3B6EA323_EU_01 zT_51;
    zT_2B3424E9_ParseToken zT_52;
    zT_2B3424E9_ParseToken zT_54;
    zT_EAC3E484_TokenKind zT_55;
    unsigned int zT_56;
    unsigned short zT_57;
    zT_D3EB6303_StringInterner* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_B559F9DA_Parser* zT_62;
    zT_2B3424E9_ParseToken zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64 = {0};
    unsigned int zT_65 = 0;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_69;
    unsigned int zT_71;
    unsigned int zT_74;
    int zT_79;
    unsigned int zT_82;
    unsigned short zT_83;
    int zT_86;
    int zT_88;
    unsigned int zT_90 = 0;
    zT_3B6EA323_EU_01 zT_91;
    zT_3A355BD2_Token tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int node;
    zT_2B3424E9_ParseToken field_tok;
    zT_2B3424E9_ParseToken fpt;
    unsigned int field_id;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_6 = tok.kind;
    zT_5.kind = zT_6;
    zT_7 = tok.span_start;
    zT_5.span_start = zT_7;
    zT_8 = tok.span_len;
    zT_5.span_len = zT_8;
    pt = zT_5;
    zT_10 = self->interner;
    zT_13 = self;
    zT_14 = pt;
    zT_15 = zF_08D61E58_parserTokenText(zT_13, zT_14);
    zT_11 = zT_15;
    zT_16 = zF_50C274AF_stringInternerInter(zT_10, zT_11);
    name_id = zT_16;
    zT_18 = self->store;
    zT_20 = name_id;
    zT_21 = tok.span_start;
    zT_28 = tok.span_start;
    zT_29 = tok.span_len;
    zT_32 = zF_1DF77BD4_astStoreAddIdentifi(zT_18, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_20, zT_21, (unsigned int)(zT_28 + (unsigned int)((unsigned int)zT_29)));
    node = zT_32;
    goto z_bb_1;
    z_bb_1:
    zT_33 = self;
    zT_34 = zF_068A2DE5_parserPeek(zT_33);
    zT_35 = zT_34.kind;
    if ((int)(zT_35 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_40 = self;
    zT_41 = zF_C241B2C4_parserAdvance(zT_40);
    (void)zT_41;
    zT_43 = self;
    zT_48 = zF_5578C74F_parserExpect(zT_43, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_91.data.payload = node;
    zT_91.is_error = 0;
    return zT_91;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_50 = zT_48.data.err;
    zT_51.data.err = zT_50;
    zT_51.is_error = 1;
    return zT_51;
    z_bb_6:
    zT_52 = zT_48.data.payload;
    goto z_bb_7;
    z_bb_7:
    field_tok = zT_52;
    zT_55 = field_tok.kind;
    zT_54.kind = zT_55;
    zT_56 = field_tok.span_start;
    zT_54.span_start = zT_56;
    zT_57 = field_tok.span_len;
    zT_54.span_len = zT_57;
    fpt = zT_54;
    zT_59 = self->interner;
    zT_62 = self;
    zT_63 = fpt;
    zT_64 = zF_08D61E58_parserTokenText(zT_62, zT_63);
    zT_60 = zT_64;
    zT_65 = zF_50C274AF_stringInternerInter(zT_59, zT_60);
    field_id = zT_65;
    zT_66 = self->store;
    zT_79 = 0;
    zT_69 = tok.span_start;
    zT_82 = field_tok.span_start;
    zT_83 = field_tok.span_len;
    zT_71 = node;
    zT_86 = 0;
    zT_88 = 0;
    zT_74 = field_id;
    zT_90 = zF_6C9FF72F_astStoreAddNode(zT_66, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_79), zT_69, (unsigned int)(zT_82 + (unsigned int)((unsigned int)zT_83)), zT_71, (unsigned int)((unsigned int)zT_86), (unsigned int)((unsigned int)zT_88), zT_74);
    node = zT_90;
    goto z_bb_4;
}

/* parserParseStatement */
zT_3B6EA323_EU_01 zF_462FC60E_parserParseStatemen(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_EAC3E484_TokenKind zT_14;
    int zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22 = 0;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_EAC3E484_TokenKind zT_39;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_B559F9DA_Parser* zT_49;
    zT_3B6EA323_EU_01 zT_58 = {0};
    zT_EAC3E484_TokenKind zT_59;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    zT_B559F9DA_Parser* zT_69;
    zT_3B6EA323_EU_01 zT_78 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_B559F9DA_Parser* zT_84;
    zT_3B6EA323_EU_01 zT_85 = {0};
    zT_EAC3E484_TokenKind zT_86;
    zT_B559F9DA_Parser* zT_91;
    zT_3B6EA323_EU_01 zT_94 = {0};
    zT_EAC3E484_TokenKind zT_95;
    zT_B559F9DA_Parser* zT_100;
    zT_3B6EA323_EU_01 zT_103 = {0};
    zT_EAC3E484_TokenKind zT_104;
    zT_B559F9DA_Parser* zT_109;
    unsigned char zT_114;
    unsigned int zT_119;
    zT_3B6EA323_EU_01 zT_120 = {0};
    zT_EAC3E484_TokenKind zT_121;
    zT_B559F9DA_Parser* zT_126;
    zT_3B6EA323_EU_01 zT_127 = {0};
    zT_EAC3E484_TokenKind zT_128;
    zT_B559F9DA_Parser* zT_133;
    zT_3B6EA323_EU_01 zT_134 = {0};
    zT_EAC3E484_TokenKind zT_135;
    zT_B559F9DA_Parser* zT_140;
    zT_3B6EA323_EU_01 zT_141 = {0};
    zT_EAC3E484_TokenKind zT_142;
    zT_B559F9DA_Parser* zT_147;
    zT_3B6EA323_EU_01 zT_148 = {0};
    zT_EAC3E484_TokenKind zT_149;
    zT_B559F9DA_Parser* zT_154;
    zT_3B6EA323_EU_01 zT_155 = {0};
    zT_EAC3E484_TokenKind zT_156;
    zT_B559F9DA_Parser* zT_161;
    zT_3B6EA323_EU_01 zT_162 = {0};
    zT_EAC3E484_TokenKind zT_163;
    zT_B559F9DA_Parser* zT_168;
    zT_3B6EA323_EU_01 zT_169 = {0};
    zT_EAC3E484_TokenKind zT_170;
    zT_B559F9DA_Parser* zT_175;
    zT_3B6EA323_EU_01 zT_180 = {0};
    zT_EAC3E484_TokenKind zT_181;
    zT_B559F9DA_Parser* zT_186;
    zT_3B6EA323_EU_01 zT_187 = {0};
    zT_EAC3E484_TokenKind zT_188;
    zT_B559F9DA_Parser* zT_193;
    zT_3B6EA323_EU_01 zT_194 = {0};
    zT_EAC3E484_TokenKind zT_195;
    zT_B559F9DA_Parser* zT_200;
    zT_3B6EA323_EU_01 zT_205 = {0};
    zT_EAC3E484_TokenKind zT_206;
    zT_B559F9DA_Parser* zT_211;
    zT_3B6EA323_EU_01 zT_216 = {0};
    zT_EAC3E484_TokenKind zT_217;
    zT_B559F9DA_Parser* zT_222;
    zT_3B6EA323_EU_01 zT_227 = {0};
    zT_EAC3E484_TokenKind zT_228;
    zT_B559F9DA_Parser* zT_233;
    zT_3B6EA323_EU_01 zT_234 = {0};
    zT_EAC3E484_TokenKind zT_235;
    zT_B559F9DA_Parser* zT_240;
    zT_3A355BD2_Token zT_241 = {0};
    zT_B559F9DA_Parser* zT_242;
    zT_EAC3E484_TokenKind zT_244;
    zT_B559F9DA_Parser* zT_249;
    int zT_251;
    zT_3A355BD2_Token zT_253 = {0};
    zT_EAC3E484_TokenKind zT_254;
    zT_B559F9DA_Parser* zT_259;
    zT_3B6EA323_EU_01 zT_260 = {0};
    zT_B559F9DA_Parser* zT_261;
    zT_3B6EA323_EU_01 zT_262 = {0};
    zT_B559F9DA_Parser* zT_263;
    zT_3B6EA323_EU_01 zT_264 = {0};
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pstk_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pstk_b;
    unsigned int pstk_l;
    unsigned int pstk_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pstk_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u varc_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u varv_s;
    z_bb_0:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = "PSTK:k";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    pstk_m = zT_6;
    zT_8 = pstk_m;
    zF_48AC7B3A_markerWrite(zT_8);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pstk_b[_i] = zT_10[_i];
        _i++;
    }
}
    zT_14 = tok.kind;
    zT_18 = 0;
    zT_19 = (unsigned char*)((unsigned char*)pstk_b) + zT_18;
    zT_20 = (unsigned int)(10) - zT_18;
    zT_21.ptr = zT_19;
    zT_21.len = zT_20;
    zT_13 = zT_21;
    zT_22 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_14), zT_13);
    pstk_l = zT_22;
    zT_26 = (unsigned int)(9) - (unsigned int)((unsigned int)pstk_l);
    pstk_s = zT_26;
    zT_31 = (unsigned char*)((unsigned char*)pstk_b) + pstk_s;
    zT_32 = (unsigned int)(9) - pstk_s;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zF_48AC7B3A_markerWrite(zT_27);
    zT_35 = "\n";
    zT_37 = 1;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    pstk_nl = zT_36;
    zT_38 = pstk_nl;
    zF_48AC7B3A_markerWrite(zT_38);
    zT_39 = tok.kind;
    if ((int)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_45 = "VARC";
    zT_47 = 4;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    varc_s = zT_46;
    zT_48 = varc_s;
    zF_48AC7B3A_markerWrite(zT_48);
    zT_49 = self;
    zT_58 = zF_7D11B416_parserParseVarDecl(zT_49, (int)(0), (int)(0), (int)(0), (int)(0));
    return zT_58;
    z_bb_2:
    zT_59 = tok.kind;
    if ((int)(zT_59 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_65 = "VARV";
    zT_67 = 4;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    varv_s = zT_66;
    zT_68 = varv_s;
    zF_48AC7B3A_markerWrite(zT_68);
    zT_69 = self;
    zT_78 = zF_7D11B416_parserParseVarDecl(zT_69, (int)(1), (int)(0), (int)(0), (int)(0));
    return zT_78;
    z_bb_4:
    zT_79 = tok.kind;
    if ((int)(zT_79 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_84 = self;
    zT_85 = zF_A8314C30_parserParsePubDecl(zT_84);
    return zT_85;
    z_bb_6:
    zT_86 = tok.kind;
    if ((int)(zT_86 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_91 = self;
    zT_94 = zF_A0D31A63_parserParseExternDe(zT_91, (int)(0));
    return zT_94;
    z_bb_8:
    zT_95 = tok.kind;
    if ((int)(zT_95 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_100 = self;
    zT_103 = zF_C3CD8237_parserParseExportDe(zT_100, (int)(0));
    return zT_103;
    z_bb_10:
    zT_104 = tok.kind;
    if ((int)(zT_104 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_109 = self;
    zT_119 = 0;
    zT_114 = zT_119;
    zT_120 = zF_3D879A25_parserParseFnDecl(zT_109, (int)(0), (int)(0), (int)(0), (int)(0), zT_114);
    return zT_120;
    z_bb_12:
    zT_121 = tok.kind;
    if ((int)(zT_121 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_126 = self;
    zT_127 = zF_DB819578_parserParseIfStmt(zT_126);
    return zT_127;
    z_bb_14:
    zT_128 = tok.kind;
    if ((int)(zT_128 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_133 = self;
    zT_134 = zF_4E7AD820_parserParseWhileStm(zT_133);
    return zT_134;
    z_bb_16:
    zT_135 = tok.kind;
    if ((int)(zT_135 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_for))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_140 = self;
    zT_141 = zF_54BCF0C6_parserParseForStmt(zT_140);
    return zT_141;
    z_bb_18:
    zT_142 = tok.kind;
    if ((int)(zT_142 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_147 = self;
    zT_148 = zF_3A6F34C7_parserParseSwitchSt(zT_147);
    return zT_148;
    z_bb_20:
    zT_149 = tok.kind;
    if ((int)(zT_149 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_154 = self;
    zT_155 = zF_76F5B9F1_parserParseReturnSt(zT_154);
    return zT_155;
    z_bb_22:
    zT_156 = tok.kind;
    if ((int)(zT_156 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_161 = self;
    zT_162 = zF_6DA396FE_parserParseBreakStm(zT_161);
    return zT_162;
    z_bb_24:
    zT_163 = tok.kind;
    if ((int)(zT_163 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_168 = self;
    zT_169 = zF_E13A9822_parserParseContinue(zT_168);
    return zT_169;
    z_bb_26:
    zT_170 = tok.kind;
    if ((int)(zT_170 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_defer))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_175 = self;
    zT_180 = zF_3B25AFD5_parserParseDeferStm(zT_175, (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt));
    return zT_180;
    z_bb_28:
    zT_181 = tok.kind;
    if ((int)(zT_181 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_errdefer))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_186 = self;
    zT_187 = zF_6C2E50E6_parserParseErrdefer(zT_186);
    return zT_187;
    z_bb_30:
    zT_188 = tok.kind;
    if ((int)(zT_188 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_193 = self;
    zT_194 = zF_15A196A5_parserParseTestDecl(zT_193);
    return zT_194;
    z_bb_32:
    zT_195 = tok.kind;
    if ((int)(zT_195 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_200 = self;
    zT_205 = zF_0A0E9C6C_parserParseContaine(zT_200, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl));
    return zT_205;
    z_bb_34:
    zT_206 = tok.kind;
    if ((int)(zT_206 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_211 = self;
    zT_216 = zF_0A0E9C6C_parserParseContaine(zT_211, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl));
    return zT_216;
    z_bb_36:
    zT_217 = tok.kind;
    if ((int)(zT_217 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_222 = self;
    zT_227 = zF_0A0E9C6C_parserParseContaine(zT_222, (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl));
    return zT_227;
    z_bb_38:
    zT_228 = tok.kind;
    if ((int)(zT_228 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_233 = self;
    zT_234 = zF_365CA04A_parserParseBlock(zT_233);
    return zT_234;
    z_bb_40:
    zT_235 = tok.kind;
    if ((int)(zT_235 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_240 = self;
    zT_241 = zF_C241B2C4_parserAdvance(zT_240);
    (void)zT_241;
    zT_242 = self;
    self = zT_242;
    goto z_bb_0;
    z_bb_42:
    zT_244 = tok.kind;
    if ((int)(zT_244 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_249 = self;
    zT_251 = 1;
    zT_253 = zF_F685E431_parserPeekN(zT_249, (unsigned int)((unsigned int)zT_251));
    zT_254 = zT_253.kind;
    if ((int)(zT_254 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_263 = self;
    zT_264 = zF_907B11F0_parserParseExprStmt(zT_263);
    return zT_264;
    z_bb_45:
    zT_259 = self;
    zT_260 = zF_BF6ABAB2_parserParseLabeledS(zT_259);
    return zT_260;
    z_bb_46:
    zT_261 = self;
    zT_262 = zF_907B11F0_parserParseExprStmt(zT_261);
    return zT_262;
}

/* parserEmitErrorNode */
unsigned int zF_8A97D8C1_parserEmitErrorNode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_9;
    int zT_19;
    unsigned int zT_22;
    unsigned short zT_23;
    int zT_26;
    int zT_28;
    int zT_30;
    int zT_32;
    unsigned int zT_34 = 0;
    zT_3 = self;
    zT_4 = tok;
    zT_5 = msg;
    zF_17DF2CA5_parserAddError(zT_3, zT_4, zT_5);
    zT_6 = self->store;
    zT_19 = 0;
    zT_9 = tok.span_start;
    zT_22 = tok.span_start;
    zT_23 = tok.span_len;
    zT_26 = 0;
    zT_28 = 0;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_err), (unsigned char)((unsigned char)zT_19), zT_9, (unsigned int)(zT_22 + (unsigned int)((unsigned int)zT_23)), (unsigned int)((unsigned int)zT_26), (unsigned int)((unsigned int)zT_28), (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32));
    return zT_34;
}

/* parserParseModuleRoot */
zT_3B6EA323_EU_01 zF_224ED3B5_parserParseModuleRo(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_10;
    zT_3B6EA323_EU_01 zT_11 = {0};
    unsigned char zT_12;
    unsigned int zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    zT_B559F9DA_Parser* zT_26;
    unsigned int** zT_27;
    unsigned int* zT_28;
    unsigned int* zT_29;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_36;
    zT_3A355BD2_Token zT_37 = {0};
    zT_EAC3E484_TokenKind zT_38;
    zT_B559F9DA_Parser* zT_43;
    zT_3A355BD2_Token zT_44 = {0};
    unsigned int** zT_46;
    unsigned int* zT_47;
    unsigned int* zT_48;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_61;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_62;
    unsigned int* zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned int* zT_67;
    unsigned int zT_68;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_69;
    unsigned int zT_70 = 0;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_79;
    int zT_84;
    int zT_86;
    int zT_88;
    int zT_90;
    int zT_92;
    int zT_94;
    unsigned int zT_96 = 0;
    zT_3B6EA323_EU_01 zT_97;
    unsigned int decl;
    unsigned int payload;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    unsigned int err;
    self->decl_buf_len = (unsigned int)(0);
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((int)(zT_4 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self;
    zT_11 = zF_462FC60E_parserParseStatemen(zT_10);
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    payload = zT_57;
    zT_58 = self->decl_buf_len;
    if ((int)(zT_58 > (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_15 = self;
    zT_16 = zF_068A2DE5_parserPeek(zT_15);
    tok = zT_16;
    zT_18 = "unexpected token";
    zT_20 = 16;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    err_msg = zT_19;
    zT_22 = self;
    zT_23 = tok;
    zT_24 = err_msg;
    zT_25 = zF_8A97D8C1_parserEmitErrorNode(zT_22, zT_23, zT_24);
    err = zT_25;
    zT_26 = self;
    zF_4190C400_parserSynchronize(zT_26);
    zT_27 = &self->decl_buf_items;
    zT_28 = &self->decl_buf_len;
    zT_29 = &self->decl_buf_capacity;
    zT_30 = self->allocator;
    zT_31 = err;
    zF_8B163A32_u32ArrayListAppendI(zT_27, zT_28, zT_29, zT_30, zT_31);
    goto z_bb_8;
    z_bb_6:
    zT_13 = zT_11.data.payload;
    goto z_bb_7;
    z_bb_7:
    decl = zT_13;
    zT_46 = &self->decl_buf_items;
    zT_47 = &self->decl_buf_len;
    zT_48 = &self->decl_buf_capacity;
    zT_49 = self->allocator;
    zT_50 = decl;
    zF_8B163A32_u32ArrayListAppendI(zT_46, zT_47, zT_48, zT_49, zT_50);
    goto z_bb_4;
    z_bb_8:
    zT_36 = self;
    zT_37 = zF_068A2DE5_parserPeek(zT_36);
    zT_38 = zT_37.kind;
    if ((int)(zT_38 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_43 = self;
    zT_44 = zF_C241B2C4_parserAdvance(zT_43);
    (void)zT_44;
    goto z_bb_11;
    z_bb_10:
    goto z_bb_4;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_61 = self->store;
    zT_64 = self->decl_buf_items;
    zT_65 = self->decl_buf_len;
    zT_66 = 0;
    zT_67 = zT_64 + zT_66;
    zT_68 = zT_65 - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_62 = zT_69;
    zT_70 = zF_583E993C_astStoreAddExtraChi(zT_61, zT_62);
    payload = zT_70;
    goto z_bb_13;
    z_bb_13:
    zT_71 = self->store;
    zT_84 = 0;
    zT_86 = 0;
    zT_88 = 0;
    zT_90 = 0;
    zT_92 = 0;
    zT_94 = 0;
    zT_79 = payload;
    zT_96 = zF_6C9FF72F_astStoreAddNode(zT_71, (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root), (unsigned char)((unsigned char)zT_84), (unsigned int)((unsigned int)zT_86), (unsigned int)((unsigned int)zT_88), (unsigned int)((unsigned int)zT_90), (unsigned int)((unsigned int)zT_92), (unsigned int)((unsigned int)zT_94), zT_79);
    zT_97.data.payload = zT_96;
    zT_97.is_error = 0;
    return zT_97;
}

/* parserParseExprStmt */
zT_3B6EA323_EU_01 zF_907B11F0_parserParseExprStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_7;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_15;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_3B6EA323_EU_01 zT_25;
    unsigned int result;
    zT_2 = self;
    zT_5 = zF_F07C1F04_parserParseExprPrec(zT_2, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_6 = zT_5.is_error;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_5;
    z_bb_2:
    zT_7 = zT_5.data.payload;
    goto z_bb_3;
    z_bb_3:
    result = zT_7;
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    if ((int)(zT_10 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_15, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_25.data.payload = result;
    zT_25.is_error = 0;
    return zT_25;
    z_bb_6:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_7:
    zT_24 = zT_20.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_24;
    goto z_bb_5;
}

/* parserParseLabeledStmt */
zT_3B6EA323_EU_01 zF_BF6ABAB2_parserParseLabeledS(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_16 = {0};
    unsigned char zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_28;
    int zT_33;
    unsigned int zT_36;
    unsigned short zT_37;
    int zT_40;
    int zT_42;
    zT_85CBA4DB_TokenValue zT_44;
    unsigned int zT_46 = 0;
    zT_3B6EA323_EU_01 zT_47;
    zT_3A355BD2_Token label_tok;
    unsigned int inner;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_16 = zF_462FC60E_parserParseStatemen(zT_15);
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_16;
    z_bb_5:
    zT_18 = zT_16.data.payload;
    goto z_bb_6;
    z_bb_6:
    inner = zT_18;
    end = inner;
    (void)end;
    zT_20 = self->store;
    zT_33 = 0;
    zT_23 = label_tok.span_start;
    zT_36 = label_tok.span_start;
    zT_37 = label_tok.span_len;
    zT_25 = inner;
    zT_40 = 0;
    zT_42 = 0;
    zT_44 = label_tok.value;
    zT_28 = zT_44.string_id;
    zT_46 = zF_6C9FF72F_astStoreAddNode(zT_20, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_33), zT_23, (unsigned int)(zT_36 + (unsigned int)((unsigned int)zT_37)), zT_25, (unsigned int)((unsigned int)zT_40), (unsigned int)((unsigned int)zT_42), zT_28);
    zT_47.data.payload = zT_46;
    zT_47.is_error = 0;
    return zT_47;
}

/* parserParseLabeledBlockExpr */
zT_3B6EA323_EU_01 zF_532B277E_parserParseLabeledB(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_16 = {0};
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    int zT_21;
    zT_3A355BD2_Token zT_23;
    unsigned int zT_24;
    unsigned short zT_25;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_36;
    int zT_41;
    int zT_44;
    int zT_46;
    zT_85CBA4DB_TokenValue zT_48;
    unsigned int zT_50 = 0;
    zT_3B6EA323_EU_01 zT_51;
    zT_3A355BD2_Token label_tok;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_16 = zF_365CA04A_parserParseBlock(zT_15);
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_16;
    z_bb_5:
    zT_18 = zT_16.data.payload;
    goto z_bb_6;
    z_bb_6:
    body = zT_18;
    zT_20 = label_tok.span_start;
    end_pos = zT_20;
    zT_21 = self->last_tok_valid;
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = self->last_tok;
    last = zT_23;
    zT_24 = last.span_start;
    zT_25 = last.span_len;
    zT_27 = zT_24 + (unsigned int)((unsigned int)zT_25);
    end_pos = zT_27;
    goto z_bb_8;
    z_bb_8:
    zT_28 = self->store;
    zT_41 = 0;
    zT_31 = label_tok.span_start;
    zT_32 = end_pos;
    zT_33 = body;
    zT_44 = 0;
    zT_46 = 0;
    zT_48 = label_tok.value;
    zT_36 = zT_48.string_id;
    zT_50 = zF_6C9FF72F_astStoreAddNode(zT_28, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_41), zT_31, zT_32, zT_33, (unsigned int)((unsigned int)zT_44), (unsigned int)((unsigned int)zT_46), zT_36);
    zT_51.data.payload = zT_50;
    zT_51.is_error = 0;
    return zT_51;
}

/* parserParseVarDecl */
zT_3B6EA323_EU_01 zF_7D11B416_parserParseVarDecl(zT_B559F9DA_Parser* self, int is_mutable, int is_pub, int is_extern, int is_export) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_B559F9DA_Parser* zT_23;
    zT_CB78802F_EU_49 zT_28 = {0};
    unsigned char zT_29;
    int zT_30;
    zT_3B6EA323_EU_01 zT_31;
    zT_2B3424E9_ParseToken zT_32;
    zT_85CBA4DB_TokenValue zT_34;
    unsigned int zT_35;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_40;
    unsigned char zT_42;
    unsigned char zT_44;
    unsigned char zT_46;
    int zT_48;
    unsigned int zT_49;
    zT_B559F9DA_Parser* zT_50;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_52;
    zT_B559F9DA_Parser* zT_57;
    zT_3A355BD2_Token zT_58 = {0};
    zT_B559F9DA_Parser* zT_59;
    zT_3B6EA323_EU_01 zT_60 = {0};
    unsigned char zT_61;
    unsigned int zT_62;
    int zT_64;
    unsigned int zT_65;
    zT_B559F9DA_Parser* zT_66;
    zT_3A355BD2_Token zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_73;
    zT_3A355BD2_Token zT_74 = {0};
    zT_B559F9DA_Parser* zT_75;
    zT_3B6EA323_EU_01 zT_78 = {0};
    unsigned char zT_79;
    unsigned int zT_80;
    zT_B559F9DA_Parser* zT_82;
    zT_CB78802F_EU_49 zT_87 = {0};
    unsigned char zT_88;
    int zT_89;
    zT_3B6EA323_EU_01 zT_90;
    zT_2B3424E9_ParseToken zT_91;
    unsigned int zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    zT_8143F551_AstKind zT_114;
    zT_3B6EA323_EU_01 zT_119;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned char zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    int zT_134;
    unsigned int zT_136 = 0;
    zT_3B6EA323_EU_01 zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_3A355BD2_Token kw;
    zT_3A355BD2_Token name_raw;
    unsigned int name_id;
    unsigned char flags;
    unsigned int type_node;
    unsigned int init_node;
    zT_2B3424E9_ParseToken semi;
    unsigned int end_pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u vok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pdv_s;
    zT_22A7C88B_AstNode init_check;
    zT_6 = "V";
    zT_8 = 1;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    vmsg = zT_7;
    zT_9 = vmsg;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    kw = zT_12;
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    name_raw = zT_15;
    zT_16 = name_raw.kind;
    if ((int)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_21 = self;
    zT_22 = zF_C241B2C4_parserAdvance(zT_21);
    (void)zT_22;
    goto z_bb_2;
    z_bb_2:
    zT_34 = name_raw.value;
    zT_35 = zT_34.string_id;
    name_id = zT_35;
    zT_37 = 0;
    zT_38 = (unsigned char)zT_37;
    flags = zT_38;
    if (is_mutable) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_23 = self;
    zT_28 = zF_5578C74F_parserExpect(zT_23, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_29 = zT_28.is_error;
    if (zT_29) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_30 = zT_28.data.err;
    zT_31.data.err = zT_30;
    zT_31.is_error = 1;
    return zT_31;
    z_bb_5:
    zT_32 = zT_28.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_32;
    goto z_bb_2;
    z_bb_7:
    zT_40 = flags | (unsigned char)(1);
    flags = zT_40;
    goto z_bb_8;
    z_bb_8:
    if (is_pub) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_42 = flags | (unsigned char)(2);
    flags = zT_42;
    goto z_bb_10;
    z_bb_10:
    if (is_extern) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_44 = flags | (unsigned char)(4);
    flags = zT_44;
    goto z_bb_12;
    z_bb_12:
    if (is_export) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = flags | (unsigned char)(8);
    flags = zT_46;
    goto z_bb_14;
    z_bb_14:
    zT_48 = 0;
    zT_49 = (unsigned int)zT_48;
    type_node = zT_49;
    zT_50 = self;
    zT_51 = zF_068A2DE5_parserPeek(zT_50);
    zT_52 = zT_51.kind;
    if ((int)(zT_52 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_57 = self;
    zT_58 = zF_C241B2C4_parserAdvance(zT_57);
    (void)zT_58;
    zT_59 = self;
    zT_60 = zF_CBDBFE85_parserParseType(zT_59);
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_64 = 0;
    zT_65 = (unsigned int)zT_64;
    init_node = zT_65;
    zT_66 = self;
    zT_67 = zF_068A2DE5_parserPeek(zT_66);
    zT_68 = zT_67.kind;
    if ((int)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_20; else goto z_bb_21;
    z_bb_17:
    return zT_60;
    z_bb_18:
    zT_62 = zT_60.data.payload;
    goto z_bb_19;
    z_bb_19:
    type_node = zT_62;
    goto z_bb_16;
    z_bb_20:
    zT_73 = self;
    zT_74 = zF_C241B2C4_parserAdvance(zT_73);
    (void)zT_74;
    zT_75 = self;
    zT_78 = zF_F07C1F04_parserParseExprPrec(zT_75, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_79 = zT_78.is_error;
    if (zT_79) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_82 = self;
    zT_87 = zF_5578C74F_parserExpect(zT_82, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_88 = zT_87.is_error;
    if (zT_88) goto z_bb_25; else goto z_bb_26;
    z_bb_22:
    return zT_78;
    z_bb_23:
    zT_80 = zT_78.data.payload;
    goto z_bb_24;
    z_bb_24:
    init_node = zT_80;
    goto z_bb_21;
    z_bb_25:
    zT_89 = zT_87.data.err;
    zT_90.data.err = zT_89;
    zT_90.is_error = 1;
    return zT_90;
    z_bb_26:
    zT_91 = zT_87.data.payload;
    goto z_bb_27;
    z_bb_27:
    semi = zT_91;
    zT_93 = semi.span_start;
    zT_94 = semi.span_len;
    zT_96 = zT_93 + (unsigned int)((unsigned int)zT_94);
    end_pos = zT_96;
    zT_98 = "v";
    zT_100 = 1;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    vok = zT_99;
    zT_101 = vok;
    zF_48AC7B3A_markerWrite(zT_101);
    zT_103 = "PDVx";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    pdv_s = zT_104;
    zT_106 = pdv_s;
    zF_48AC7B3A_markerWrite(zT_106);
    if ((int)(init_node != (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_110 = self->store;
    zT_111 = init_node;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    init_check = zT_113;
    zT_114 = init_check.kind;
    if ((int)(zT_114 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_120 = self->store;
    zT_122 = flags;
    zT_123 = kw.span_start;
    zT_124 = end_pos;
    zT_125 = type_node;
    zT_126 = init_node;
    zT_134 = 0;
    zT_128 = name_id;
    zT_136 = zF_6C9FF72F_astStoreAddNode(zT_120, (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl), zT_122, zT_123, zT_124, zT_125, zT_126, (unsigned int)((unsigned int)zT_134), zT_128);
    zT_137.data.payload = zT_136;
    zT_137.is_error = 0;
    return zT_137;
    z_bb_30:
    zT_119.data.payload = init_node;
    zT_119.is_error = 0;
    return zT_119;
    z_bb_31:
    goto z_bb_29;
}

/* parserParsePubDecl */
zT_3B6EA323_EU_01 zF_A8314C30_parserParsePubDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_11;
    unsigned char zT_16;
    unsigned int zT_21;
    zT_3B6EA323_EU_01 zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_28;
    zT_3B6EA323_EU_01 zT_37 = {0};
    zT_EAC3E484_TokenKind zT_38;
    zT_B559F9DA_Parser* zT_43;
    zT_3B6EA323_EU_01 zT_52 = {0};
    zT_EAC3E484_TokenKind zT_53;
    zT_B559F9DA_Parser* zT_58;
    zT_3B6EA323_EU_01 zT_59 = {0};
    zT_EAC3E484_TokenKind zT_60;
    zT_B559F9DA_Parser* zT_65;
    zT_3B6EA323_EU_01 zT_68 = {0};
    zT_EAC3E484_TokenKind zT_69;
    zT_B559F9DA_Parser* zT_74;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_DBF3575C_ParserError zT_85;
    zT_3B6EA323_EU_01 zT_86;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    tok = zT_5;
    zT_6 = tok.kind;
    if ((int)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_21 = 0;
    zT_16 = zT_21;
    zT_22 = zF_3D879A25_parserParseFnDecl(zT_11, (int)(1), (int)(0), (int)(0), (int)(0), zT_16);
    return zT_22;
    z_bb_2:
    zT_23 = tok.kind;
    if ((int)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_28 = self;
    zT_37 = zF_7D11B416_parserParseVarDecl(zT_28, (int)(0), (int)(1), (int)(0), (int)(0));
    return zT_37;
    z_bb_4:
    zT_38 = tok.kind;
    if ((int)(zT_38 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_43 = self;
    zT_52 = zF_7D11B416_parserParseVarDecl(zT_43, (int)(1), (int)(1), (int)(0), (int)(0));
    return zT_52;
    z_bb_6:
    zT_53 = tok.kind;
    if ((int)(zT_53 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_58 = self;
    zT_59 = zF_15A196A5_parserParseTestDecl(zT_58);
    return zT_59;
    z_bb_8:
    zT_60 = tok.kind;
    if ((int)(zT_60 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_65 = self;
    zT_68 = zF_A0D31A63_parserParseExternDe(zT_65, (int)(1));
    return zT_68;
    z_bb_10:
    zT_69 = tok.kind;
    if ((int)(zT_69 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_74 = self;
    zT_77 = zF_C3CD8237_parserParseExportDe(zT_74, (int)(1));
    return zT_77;
    z_bb_12:
    zT_79 = "expected fn/const/var after pub";
    zT_81 = 31;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    p_msg = zT_80;
    zT_82 = self;
    zT_83 = tok;
    zT_84 = p_msg;
    zF_17DF2CA5_parserAddError(zT_82, zT_83, zT_84);
    zT_85 = 1;
    zT_86.data.err = zT_85;
    zT_86.is_error = 1;
    return zT_86;
}

/* parserClassifyCallConv */
unsigned char zF_A095D9EA_parserClassifyCallC(zT_B559F9DA_Parser* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    int zT_6;
    unsigned char* zT_7;
    int zT_8;
    unsigned char zT_9;
    unsigned int zT_14;
    int zT_15;
    int zT_17;
    unsigned char* zT_18;
    int zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned char* zT_24;
    int zT_25;
    unsigned char zT_26;
    int zT_29;
    unsigned char* zT_30;
    int zT_31;
    unsigned char zT_32;
    int zT_35;
    unsigned char* zT_36;
    int zT_37;
    unsigned char zT_38;
    int zT_41;
    unsigned char* zT_42;
    int zT_43;
    unsigned char zT_44;
    unsigned int zT_49;
    int zT_50;
    int zT_52;
    unsigned char* zT_53;
    int zT_54;
    unsigned char zT_55;
    int zT_58;
    unsigned char* zT_59;
    int zT_60;
    unsigned char zT_61;
    int zT_64;
    unsigned char* zT_65;
    int zT_66;
    unsigned char zT_67;
    int zT_70;
    unsigned char* zT_71;
    int zT_72;
    unsigned char zT_73;
    int zT_76;
    unsigned char* zT_77;
    int zT_78;
    unsigned char zT_79;
    int zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned char zT_85;
    int zT_88;
    unsigned char* zT_89;
    int zT_90;
    unsigned char zT_91;
    (void)self;
    zT_3 = text.len;
    zT_4 = 1;
    if ((int)(zT_3 == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = text.ptr;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    zT_6 = zT_9 == (unsigned char)(99);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_14 = text.len;
    zT_15 = 5;
    if ((int)(zT_14 == (unsigned int)zT_15)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = text.ptr;
    zT_19 = 0;
    zT_20 = zT_18[zT_19];
    zT_17 = zT_20 == (unsigned char)(99);
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_24 = text.ptr;
    zT_25 = 1;
    zT_26 = zT_24[zT_25];
    zT_23 = zT_26 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_23 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_23) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = text.ptr;
    zT_31 = 2;
    zT_32 = zT_30[zT_31];
    zT_29 = zT_32 == (unsigned char)(101);
    goto z_bb_14;
    z_bb_13:
    zT_29 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_29) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_36 = text.ptr;
    zT_37 = 3;
    zT_38 = zT_36[zT_37];
    zT_35 = zT_38 == (unsigned char)(99);
    goto z_bb_17;
    z_bb_16:
    zT_35 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_35) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_42 = text.ptr;
    zT_43 = 4;
    zT_44 = zT_42[zT_43];
    zT_41 = zT_44 == (unsigned char)(108);
    goto z_bb_20;
    z_bb_19:
    zT_41 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_41) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_49 = text.len;
    zT_50 = 7;
    if ((int)(zT_49 == (unsigned int)zT_50)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_53 = text.ptr;
    zT_54 = 0;
    zT_55 = zT_53[zT_54];
    zT_52 = zT_55 == (unsigned char)(115);
    goto z_bb_25;
    z_bb_24:
    zT_52 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_52) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_59 = text.ptr;
    zT_60 = 1;
    zT_61 = zT_59[zT_60];
    zT_58 = zT_61 == (unsigned char)(116);
    goto z_bb_28;
    z_bb_27:
    zT_58 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_58) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_65 = text.ptr;
    zT_66 = 2;
    zT_67 = zT_65[zT_66];
    zT_64 = zT_67 == (unsigned char)(100);
    goto z_bb_31;
    z_bb_30:
    zT_64 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_64) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_71 = text.ptr;
    zT_72 = 3;
    zT_73 = zT_71[zT_72];
    zT_70 = zT_73 == (unsigned char)(99);
    goto z_bb_34;
    z_bb_33:
    zT_70 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_70) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_77 = text.ptr;
    zT_78 = 4;
    zT_79 = zT_77[zT_78];
    zT_76 = zT_79 == (unsigned char)(97);
    goto z_bb_37;
    z_bb_36:
    zT_76 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_76) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_83 = text.ptr;
    zT_84 = 5;
    zT_85 = zT_83[zT_84];
    zT_82 = zT_85 == (unsigned char)(108);
    goto z_bb_40;
    z_bb_39:
    zT_82 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_82) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_89 = text.ptr;
    zT_90 = 6;
    zT_91 = zT_89[zT_90];
    zT_88 = zT_91 == (unsigned char)(108);
    goto z_bb_43;
    z_bb_42:
    zT_88 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_88) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    return (unsigned char)(1);
    z_bb_45:
    return (unsigned char)(2);
}

/* parserAddErrorCode */
void zF_6E7AEAB4_parserAddErrorCode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned short code, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_4;
    unsigned short zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_4 = self->diag;
    zT_6 = code;
    zT_7 = self->file_id;
    zT_8 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_10 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_4, (unsigned char)(0), zT_6, zT_7, zT_8, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_10);
    return;
}

/* parserParseExternDecl */
zT_3B6EA323_EU_01 zF_A0D31A63_parserParseExternDe(zT_B559F9DA_Parser* self, int is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token zT_7 = {0};
    zT_EAC3E484_TokenKind zT_8;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_D3EB6303_StringInterner* zT_17;
    unsigned int zT_18;
    zT_85CBA4DB_TokenValue zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22 = {0};
    zT_B559F9DA_Parser* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char zT_25 = 0;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_36;
    unsigned int zT_38;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41 = {0};
    zT_EAC3E484_TokenKind zT_42;
    zT_B559F9DA_Parser* zT_47;
    int zT_48;
    unsigned char zT_52;
    zT_3B6EA323_EU_01 zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_62;
    int zT_64;
    zT_3B6EA323_EU_01 zT_70 = {0};
    zT_EAC3E484_TokenKind zT_71;
    zT_B559F9DA_Parser* zT_76;
    int zT_78;
    zT_3B6EA323_EU_01 zT_84 = {0};
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_B559F9DA_Parser* zT_89;
    zT_3A355BD2_Token zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_DBF3575C_ParserError zT_92;
    zT_3B6EA323_EU_01 zT_93;
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u e_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = 0;
    call_conv = zT_5;
    zT_6 = self;
    zT_7 = zF_068A2DE5_parserPeek(zT_6);
    zT_8 = zT_7.kind;
    if ((int)(zT_8 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    str_tok = zT_15;
    zT_17 = self->interner;
    zT_20 = str_tok.value;
    zT_18 = zT_20.string_id;
    zT_22 = zF_9134020D_stringInternerGet(zT_17, zT_18);
    text = zT_22;
    zT_23 = self;
    zT_24 = text;
    zT_25 = zF_A095D9EA_parserClassifyCallC(zT_23, zT_24);
    call_conv = zT_25;
    if ((int)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_40 = self;
    zT_41 = zF_068A2DE5_parserPeek(zT_40);
    tok = zT_41;
    zT_42 = tok.kind;
    if ((int)(zT_42 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_29 = "unknown calling convention in `extern`";
    zT_31 = 38;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    ucv = zT_30;
    zT_32 = self;
    zT_33 = str_tok;
    zT_36 = 3045;
    zT_35 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_32, zT_33, (unsigned short)((unsigned short)zT_36), zT_35);
    zT_38 = 0;
    call_conv = zT_38;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_47 = self;
    zT_48 = is_pub;
    zT_52 = call_conv;
    zT_56 = zF_3D879A25_parserParseFnDecl(zT_47, zT_48, (int)(1), (int)(0), (int)(0), zT_52);
    return zT_56;
    z_bb_6:
    zT_57 = tok.kind;
    if ((int)(zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_62 = self;
    zT_64 = is_pub;
    zT_70 = zF_7D11B416_parserParseVarDecl(zT_62, (int)(0), zT_64, (int)(1), (int)(0));
    return zT_70;
    z_bb_8:
    zT_71 = tok.kind;
    if ((int)(zT_71 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_76 = self;
    zT_78 = is_pub;
    zT_84 = zF_7D11B416_parserParseVarDecl(zT_76, (int)(1), zT_78, (int)(1), (int)(0));
    return zT_84;
    z_bb_10:
    zT_86 = "expected fn/const/var after extern";
    zT_88 = 34;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    e_msg = zT_87;
    zT_89 = self;
    zT_90 = tok;
    zT_91 = e_msg;
    zF_17DF2CA5_parserAddError(zT_89, zT_90, zT_91);
    zT_92 = 1;
    zT_93.data.err = zT_92;
    zT_93.is_error = 1;
    return zT_93;
}

/* parserParseExportDecl */
zT_3B6EA323_EU_01 zF_C3CD8237_parserParseExportDe(zT_B559F9DA_Parser* self, int is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    int zT_13;
    unsigned char zT_17;
    unsigned int zT_21;
    zT_3B6EA323_EU_01 zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_28;
    int zT_30;
    zT_3B6EA323_EU_01 zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_42;
    int zT_44;
    zT_3B6EA323_EU_01 zT_50 = {0};
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_B559F9DA_Parser* zT_55;
    zT_3A355BD2_Token zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_DBF3575C_ParserError zT_58;
    zT_3B6EA323_EU_01 zT_59;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u x_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((int)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = is_pub;
    zT_21 = 0;
    zT_17 = zT_21;
    zT_22 = zF_3D879A25_parserParseFnDecl(zT_12, zT_13, (int)(0), (int)(0), (int)(1), zT_17);
    return zT_22;
    z_bb_2:
    zT_23 = tok.kind;
    if ((int)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_28 = self;
    zT_30 = is_pub;
    zT_36 = zF_7D11B416_parserParseVarDecl(zT_28, (int)(0), zT_30, (int)(0), (int)(1));
    return zT_36;
    z_bb_4:
    zT_37 = tok.kind;
    if ((int)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_42 = self;
    zT_44 = is_pub;
    zT_50 = zF_7D11B416_parserParseVarDecl(zT_42, (int)(1), zT_44, (int)(0), (int)(1));
    return zT_50;
    z_bb_6:
    zT_52 = "expected fn/const/var after export";
    zT_54 = 34;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    x_msg = zT_53;
    zT_55 = self;
    zT_56 = tok;
    zT_57 = x_msg;
    zF_17DF2CA5_parserAddError(zT_55, zT_56, zT_57);
    zT_58 = 1;
    zT_59.data.err = zT_58;
    zT_59.is_error = 1;
    return zT_59;
}

/* parserParseFnDecl */
zT_3B6EA323_EU_01 zF_3D879A25_parserParseFnDecl(zT_B559F9DA_Parser* self, int is_pub, int is_extern, int is_test, int is_export, unsigned char call_conv) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    int zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    unsigned char zT_20;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_B559F9DA_Parser* zT_26;
    zT_CB78802F_EU_49 zT_31 = {0};
    unsigned char zT_32;
    int zT_33;
    zT_3B6EA323_EU_01 zT_34;
    zT_2B3424E9_ParseToken zT_35;
    zT_B559F9DA_Parser* zT_36;
    zT_CB78802F_EU_49 zT_41 = {0};
    unsigned char zT_42;
    int zT_43;
    zT_3B6EA323_EU_01 zT_44;
    zT_2B3424E9_ParseToken zT_45;
    int zT_46;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    int zT_55;
    zT_B559F9DA_Parser* zT_56;
    zT_3A355BD2_Token zT_57 = {0};
    zT_EAC3E484_TokenKind zT_58;
    zT_B559F9DA_Parser* zT_63;
    zT_3A355BD2_Token zT_64 = {0};
    zT_EAC3E484_TokenKind zT_65;
    zT_B559F9DA_Parser* zT_70;
    zT_3A355BD2_Token zT_71 = {0};
    unsigned char zT_73;
    zT_B559F9DA_Parser* zT_75;
    zT_CB78802F_EU_49 zT_80 = {0};
    unsigned char zT_81;
    int zT_82;
    zT_3B6EA323_EU_01 zT_83;
    zT_2B3424E9_ParseToken zT_84;
    zT_B559F9DA_Parser* zT_85;
    zT_CB78802F_EU_49 zT_90 = {0};
    unsigned char zT_91;
    int zT_92;
    zT_3B6EA323_EU_01 zT_93;
    zT_2B3424E9_ParseToken zT_94;
    zT_B559F9DA_Parser* zT_96;
    zT_3B6EA323_EU_01 zT_97 = {0};
    unsigned char zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_B559F9DA_Parser* zT_104;
    zT_2B3424E9_ParseToken zT_105;
    zT_2B3424E9_ParseToken zT_106;
    zT_EAC3E484_TokenKind zT_107;
    unsigned int zT_108;
    unsigned short zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110 = {0};
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_113;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    int zT_126;
    int zT_130;
    int zT_132;
    unsigned int zT_134 = 0;
    unsigned int** zT_135;
    unsigned int* zT_136;
    unsigned int* zT_137;
    zT_3E40CD83_Sand* zT_138;
    unsigned int zT_139;
    zT_B559F9DA_Parser* zT_144;
    zT_3A355BD2_Token zT_145 = {0};
    zT_EAC3E484_TokenKind zT_146;
    zT_B559F9DA_Parser* zT_151;
    zT_3A355BD2_Token zT_152 = {0};
    zT_B559F9DA_Parser* zT_153;
    zT_CB78802F_EU_49 zT_158 = {0};
    unsigned char zT_159;
    int zT_160;
    zT_3B6EA323_EU_01 zT_161;
    zT_2B3424E9_ParseToken zT_162;
    int zT_164;
    unsigned int zT_165;
    unsigned short zT_167;
    unsigned int zT_168;
    zT_6B0A7D14_AstStore* zT_172;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_173;
    unsigned int* zT_175;
    unsigned int zT_176;
    int zT_177;
    unsigned int* zT_178;
    unsigned int zT_179;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_180;
    unsigned int zT_181 = 0;
    zT_6B0A7D14_AstStore* zT_182;
    zT_08EB936D_anon_223558 zT_183;
    zT_79FAE712_u64* zT_184;
    unsigned int zT_185;
    zT_79FAE712_u64 zT_186;
    int zT_187;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned short zT_191;
    int zT_192;
    int zT_195;
    unsigned int zT_196;
    zT_B559F9DA_Parser* zT_197;
    zT_3A355BD2_Token zT_198 = {0};
    zT_EAC3E484_TokenKind zT_199;
    zT_B559F9DA_Parser* zT_204;
    zT_3A355BD2_Token zT_205 = {0};
    zT_B559F9DA_Parser* zT_206;
    zT_3B6EA323_EU_01 zT_207 = {0};
    unsigned char zT_208;
    unsigned int zT_209;
    zT_B559F9DA_Parser* zT_210;
    zT_3A355BD2_Token zT_211 = {0};
    zT_EAC3E484_TokenKind zT_212;
    int zT_217;
    zT_B559F9DA_Parser* zT_218;
    zT_3A355BD2_Token zT_219 = {0};
    zT_EAC3E484_TokenKind zT_220;
    zT_B559F9DA_Parser* zT_225;
    zT_3B6EA323_EU_01 zT_226 = {0};
    unsigned char zT_227;
    unsigned int zT_228;
    int zT_230;
    unsigned int zT_231;
    unsigned int zT_233 = 0;
    zT_B559F9DA_Parser* zT_234;
    zT_3A355BD2_Token zT_235 = {0};
    zT_EAC3E484_TokenKind zT_236;
    zT_B559F9DA_Parser* zT_242;
    zT_3A355BD2_Token zT_243 = {0};
    unsigned int zT_244;
    unsigned short zT_245;
    unsigned int zT_247;
    zT_B559F9DA_Parser* zT_248;
    zT_3B6EA323_EU_01 zT_249 = {0};
    unsigned char zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    zT_D3EB6303_StringInterner* zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    zT_B559F9DA_Parser* zT_265;
    zT_2B3424E9_ParseToken zT_266;
    zT_2B3424E9_ParseToken zT_267;
    zT_EAC3E484_TokenKind zT_268;
    unsigned int zT_269;
    unsigned short zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271 = {0};
    unsigned int zT_272 = 0;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    zT_4028D896_Arr_unsigned_char_2 zT_279;
    unsigned int zT_281;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    int zT_287;
    unsigned char* zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291 = 0;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    unsigned char* zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char* zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    zT_243D6A41_FnProto zT_309;
    zT_6B0A7D14_AstStore* zT_311;
    zT_243D6A41_FnProto zT_312;
    unsigned int zT_314 = 0;
    int zT_315;
    unsigned char* zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_321;
    zT_6B0A7D14_AstStore* zT_322;
    unsigned char zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_330;
    int zT_336;
    int zT_338;
    unsigned int zT_340 = 0;
    zT_3B6EA323_EU_01 zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmsg;
    zT_3A355BD2_Token kw;
    unsigned char flags;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken param_tok;
    unsigned int param_type;
    unsigned int param_name_id;
    unsigned int param_node;
    unsigned int param_start;
    unsigned short param_count;
    unsigned int pp;
    unsigned int ret_type_node;
    unsigned int body_node;
    unsigned int end_pos;
    zT_3A355BD2_Token semi;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_4028D896_Arr_unsigned_char_2 pa_buf;
    unsigned int pa_val;
    unsigned int pa_len;
    unsigned int pa_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    zT_243D6A41_FnProto proto;
    unsigned int proto_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u fok;
    zT_7 = "Fv";
    zT_9 = 2;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    fmsg = zT_8;
    zT_10 = fmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    kw = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned char)zT_15;
    flags = zT_16;
    if (is_pub) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = flags | (unsigned char)(2);
    flags = zT_18;
    goto z_bb_2;
    z_bb_2:
    if (is_extern) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = flags | (unsigned char)(4);
    flags = zT_20;
    goto z_bb_4;
    z_bb_4:
    if (is_test) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = flags | (unsigned char)(32);
    flags = zT_22;
    goto z_bb_6;
    z_bb_6:
    if (is_export) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = flags | (unsigned char)(8);
    flags = zT_24;
    goto z_bb_8;
    z_bb_8:
    zT_26 = self;
    zT_31 = zF_5578C74F_parserExpect(zT_26, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = zT_31.data.err;
    zT_34.data.err = zT_33;
    zT_34.is_error = 1;
    return zT_34;
    z_bb_10:
    zT_35 = zT_31.data.payload;
    goto z_bb_11;
    z_bb_11:
    name_tok = zT_35;
    zT_36 = self;
    zT_41 = zF_5578C74F_parserExpect(zT_36, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_43 = zT_41.data.err;
    zT_44.data.err = zT_43;
    zT_44.is_error = 1;
    return zT_44;
    z_bb_13:
    zT_45 = zT_41.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_45;
    zT_46 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_46);
    goto z_bb_15;
    z_bb_15:
    zT_48 = self;
    zT_49 = zF_068A2DE5_parserPeek(zT_48);
    zT_50 = zT_49.kind;
    if ((int)(zT_50 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_63 = self;
    zT_64 = zF_068A2DE5_parserPeek(zT_63);
    zT_65 = zT_64.kind;
    if ((int)(zT_65 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_22; else goto z_bb_23;
    z_bb_17:
    zT_153 = self;
    zT_158 = zF_5578C74F_parserExpect(zT_153, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_159 = zT_158.is_error;
    if (zT_159) goto z_bb_35; else goto z_bb_36;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_56 = self;
    zT_57 = zF_068A2DE5_parserPeek(zT_56);
    zT_58 = zT_57.kind;
    zT_55 = zT_58 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_21;
    z_bb_20:
    zT_55 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_55) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_70 = self;
    zT_71 = zF_C241B2C4_parserAdvance(zT_70);
    (void)zT_71;
    zT_73 = flags | (unsigned char)(1);
    flags = zT_73;
    goto z_bb_17;
    z_bb_23:
    zT_75 = self;
    zT_80 = zF_5578C74F_parserExpect(zT_75, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_81 = zT_80.is_error;
    if (zT_81) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_82 = zT_80.data.err;
    zT_83.data.err = zT_82;
    zT_83.is_error = 1;
    return zT_83;
    z_bb_25:
    zT_84 = zT_80.data.payload;
    goto z_bb_26;
    z_bb_26:
    param_tok = zT_84;
    zT_85 = self;
    zT_90 = zF_5578C74F_parserExpect(zT_85, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = zT_90.data.err;
    zT_93.data.err = zT_92;
    zT_93.is_error = 1;
    return zT_93;
    z_bb_28:
    zT_94 = zT_90.data.payload;
    goto z_bb_29;
    z_bb_29:
    (void)zT_94;
    zT_96 = self;
    zT_97 = zF_CBDBFE85_parserParseType(zT_96);
    zT_98 = zT_97.is_error;
    if (zT_98) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    return zT_97;
    z_bb_31:
    zT_99 = zT_97.data.payload;
    goto z_bb_32;
    z_bb_32:
    param_type = zT_99;
    zT_101 = self->interner;
    zT_104 = self;
    zT_107 = param_tok.kind;
    zT_106.kind = zT_107;
    zT_108 = param_tok.span_start;
    zT_106.span_start = zT_108;
    zT_109 = param_tok.span_len;
    zT_106.span_len = zT_109;
    zT_105 = zT_106;
    zT_110 = zF_08D61E58_parserTokenText(zT_104, zT_105);
    zT_102 = zT_110;
    zT_111 = zF_50C274AF_stringInternerInter(zT_101, zT_102);
    param_name_id = zT_111;
    zT_113 = self->store;
    zT_126 = 0;
    zT_116 = param_tok.span_start;
    zT_117 = self->last_end;
    zT_118 = param_type;
    zT_130 = 0;
    zT_132 = 0;
    zT_121 = param_name_id;
    zT_134 = zF_6C9FF72F_astStoreAddNode(zT_113, (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl), (unsigned char)((unsigned char)zT_126), zT_116, zT_117, zT_118, (unsigned int)((unsigned int)zT_130), (unsigned int)((unsigned int)zT_132), zT_121);
    param_node = zT_134;
    zT_135 = &self->child_buf_items;
    zT_136 = &self->child_buf_len;
    zT_137 = &self->child_buf_capacity;
    zT_138 = self->allocator;
    zT_139 = param_node;
    zF_8B163A32_u32ArrayListAppendI(zT_135, zT_136, zT_137, zT_138, zT_139);
    zT_144 = self;
    zT_145 = zF_068A2DE5_parserPeek(zT_144);
    zT_146 = zT_145.kind;
    if ((int)(zT_146 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_151 = self;
    zT_152 = zF_C241B2C4_parserAdvance(zT_151);
    (void)zT_152;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_18;
    z_bb_35:
    zT_160 = zT_158.data.err;
    zT_161.data.err = zT_160;
    zT_161.is_error = 1;
    return zT_161;
    z_bb_36:
    zT_162 = zT_158.data.payload;
    goto z_bb_37;
    z_bb_37:
    (void)zT_162;
    zT_164 = 0;
    zT_165 = (unsigned int)zT_164;
    param_start = zT_165;
    zT_167 = 0;
    param_count = zT_167;
    zT_168 = self->child_buf_len;
    if ((int)(zT_168 > (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_172 = self->store;
    zT_175 = self->child_buf_items;
    zT_176 = self->child_buf_len;
    zT_177 = 0;
    zT_178 = zT_175 + zT_177;
    zT_179 = zT_176 - zT_177;
    zT_180.ptr = zT_178;
    zT_180.len = zT_179;
    zT_173 = zT_180;
    zT_181 = zF_583E993C_astStoreAddExtraChi(zT_172, zT_173);
    pp = zT_181;
    zT_182 = self->store;
    zT_183 = zT_182->extra_ranges;
    zT_184 = zT_183.items;
    zT_185 = (unsigned int)pp;
    zT_186 = zT_184[zT_185];
    zT_187 = 32;
    zT_189 = (unsigned int)(zT_79FAE712_u64)(zT_186 >> zT_187);
    param_start = zT_189;
    zT_190 = self->child_buf_len;
    zT_191 = (unsigned short)zT_190;
    param_count = zT_191;
    zT_192 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_192);
    goto z_bb_39;
    z_bb_39:
    zT_195 = 0;
    zT_196 = (unsigned int)zT_195;
    ret_type_node = zT_196;
    zT_197 = self;
    zT_198 = zF_068A2DE5_parserPeek(zT_197);
    zT_199 = zT_198.kind;
    if ((int)(zT_199 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_204 = self;
    zT_205 = zF_C241B2C4_parserAdvance(zT_204);
    (void)zT_205;
    zT_206 = self;
    zT_207 = zF_CBDBFE85_parserParseType(zT_206);
    zT_208 = zT_207.is_error;
    if (zT_208) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_230 = 0;
    zT_231 = (unsigned int)zT_230;
    body_node = zT_231;
    end_pos = zT_233;
    zT_234 = self;
    zT_235 = zF_068A2DE5_parserPeek(zT_234);
    zT_236 = zT_235.kind;
    if ((int)(zT_236 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_54; else goto z_bb_56;
    z_bb_42:
    zT_210 = self;
    zT_211 = zF_068A2DE5_parserPeek(zT_210);
    zT_212 = zT_211.kind;
    if ((int)(zT_212 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_207;
    z_bb_44:
    zT_209 = zT_207.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type_node = zT_209;
    goto z_bb_41;
    z_bb_46:
    zT_218 = self;
    zT_219 = zF_068A2DE5_parserPeek(zT_218);
    zT_220 = zT_219.kind;
    zT_217 = zT_220 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_48;
    z_bb_47:
    zT_217 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_217) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_225 = self;
    zT_226 = zF_CBDBFE85_parserParseType(zT_225);
    zT_227 = zT_226.is_error;
    if (zT_227) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_41;
    z_bb_51:
    return zT_226;
    z_bb_52:
    zT_228 = zT_226.data.payload;
    goto z_bb_53;
    z_bb_53:
    ret_type_node = zT_228;
    goto z_bb_50;
    z_bb_54:
    zT_242 = self;
    zT_243 = zF_C241B2C4_parserAdvance(zT_242);
    semi = zT_243;
    zT_244 = semi.span_start;
    zT_245 = semi.span_len;
    zT_247 = zT_244 + (unsigned int)((unsigned int)zT_245);
    end_pos = zT_247;
    goto z_bb_55;
    z_bb_55:
    zT_253 = self->child_buf_len;
    if ((int)(zT_253 > (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    zT_248 = self;
    zT_249 = zF_365CA04A_parserParseBlock(zT_248);
    zT_250 = zT_249.is_error;
    if (zT_250) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return zT_249;
    z_bb_58:
    zT_251 = zT_249.data.payload;
    goto z_bb_59;
    z_bb_59:
    body_node = zT_251;
    zT_252 = self->last_end;
    end_pos = zT_252;
    goto z_bb_55;
    z_bb_60:
    zT_257 = "DP:child_buf_stale\n";
    zT_259 = 19;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    dmsg = zT_258;
    zT_260 = dmsg;
    zF_48AC7B3A_markerWrite(zT_260);
    goto z_bb_61;
    z_bb_61:
    zT_262 = self->interner;
    zT_265 = self;
    zT_268 = name_tok.kind;
    zT_267.kind = zT_268;
    zT_269 = name_tok.span_start;
    zT_267.span_start = zT_269;
    zT_270 = name_tok.span_len;
    zT_267.span_len = zT_270;
    zT_266 = zT_267;
    zT_271 = zF_08D61E58_parserTokenText(zT_265, zT_266);
    zT_263 = zT_271;
    zT_272 = zF_50C274AF_stringInternerInter(zT_262, zT_263);
    name_id = zT_272;
    zT_274 = "P:";
    zT_276 = 2;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pmsg = zT_275;
    zT_277 = pmsg;
    zF_48AC7B3A_markerWrite(zT_277);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_279[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pa_buf[_i] = zT_279[_i];
        _i++;
    }
}
    zT_281 = (unsigned int)param_count;
    pa_val = zT_281;
    zT_283 = pa_val;
    zT_287 = 0;
    zT_288 = (unsigned char*)((unsigned char*)pa_buf) + zT_287;
    zT_289 = (unsigned int)(20) - zT_287;
    zT_290.ptr = zT_288;
    zT_290.len = zT_289;
    zT_284 = zT_290;
    zT_291 = zF_A7504564_itoa(zT_283, zT_284);
    pa_len = zT_291;
    zT_295 = (unsigned int)(19) - (unsigned int)((unsigned int)pa_len);
    pa_start = zT_295;
    zT_300 = (unsigned char*)((unsigned char*)pa_buf) + pa_start;
    zT_301 = (unsigned int)(19) - pa_start;
    zT_302.ptr = zT_300;
    zT_302.len = zT_301;
    zT_296 = zT_302;
    zF_48AC7B3A_markerWrite(zT_296);
    zT_304 = "\n";
    zT_306 = 1;
    zT_305.ptr = zT_304;
    zT_305.len = zT_306;
    pnl = zT_305;
    zT_307 = pnl;
    zF_48AC7B3A_markerWrite(zT_307);
    zT_309.name_id = name_id;
    zT_309.params_start = param_start;
    zT_309.params_count = param_count;
    zT_309.call_conv = call_conv;
    zT_309.return_type_node = ret_type_node;
    proto = zT_309;
    zT_311 = self->store;
    zT_312 = proto;
    zT_314 = zF_F1F8D02B_astStoreAddFnProto(zT_311, zT_312);
    proto_idx = zT_314;
    zT_315 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_315);
    zT_318 = "Fk";
    zT_320 = 2;
    zT_319.ptr = zT_318;
    zT_319.len = zT_320;
    fok = zT_319;
    zT_321 = fok;
    zF_48AC7B3A_markerWrite(zT_321);
    zT_322 = self->store;
    zT_324 = flags;
    zT_325 = kw.span_start;
    zT_326 = end_pos;
    zT_327 = body_node;
    zT_336 = 0;
    zT_338 = 0;
    zT_330 = proto_idx;
    zT_340 = zF_6C9FF72F_astStoreAddNode(zT_322, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl), zT_324, zT_325, zT_326, zT_327, (unsigned int)((unsigned int)zT_336), (unsigned int)((unsigned int)zT_338), zT_330);
    zT_341.data.payload = zT_340;
    zT_341.is_error = 0;
    return zT_341;
}

/* parserParseIfStmt */
zT_3B6EA323_EU_01 zF_DB819578_parserParseIfStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37 = 0;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_58 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8143F551_AstKind zT_64;
    int zT_68;
    unsigned char* zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72 = 0;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_90;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101 = 0;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_119;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    int zT_126;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130 = 0;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned char* zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned char* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    zT_22A7C88B_AstNode zT_152 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    zT_8143F551_AstKind zT_158;
    int zT_162;
    unsigned char* zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166 = 0;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    zT_22A7C88B_AstNode zT_188 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    zT_8143F551_AstKind zT_194;
    int zT_198;
    unsigned char* zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202 = 0;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned char* zT_211;
    unsigned int zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    unsigned char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_B559F9DA_Parser* zT_219;
    zT_CB78802F_EU_49 zT_224 = {0};
    unsigned char zT_225;
    int zT_226;
    zT_3B6EA323_EU_01 zT_227;
    zT_2B3424E9_ParseToken zT_228;
    int zT_230;
    unsigned int zT_231;
    zT_B559F9DA_Parser* zT_232;
    zT_3A355BD2_Token zT_233 = {0};
    zT_EAC3E484_TokenKind zT_234;
    zT_B559F9DA_Parser* zT_239;
    zT_3A355BD2_Token zT_240 = {0};
    zT_2B3424E9_ParseToken zT_242 = {0};
    zT_B559F9DA_Parser* zT_243;
    zT_3A355BD2_Token zT_244 = {0};
    zT_EAC3E484_TokenKind zT_245;
    zT_B559F9DA_Parser* zT_250;
    zT_CB78802F_EU_49 zT_255 = {0};
    unsigned char zT_256;
    int zT_257;
    zT_3B6EA323_EU_01 zT_258;
    zT_2B3424E9_ParseToken zT_259;
    zT_B559F9DA_Parser* zT_260;
    zT_CB78802F_EU_49 zT_265 = {0};
    unsigned char zT_266;
    int zT_267;
    zT_3B6EA323_EU_01 zT_268;
    zT_2B3424E9_ParseToken zT_269;
    zT_B559F9DA_Parser* zT_270;
    zT_CB78802F_EU_49 zT_275 = {0};
    unsigned char zT_276;
    int zT_277;
    zT_3B6EA323_EU_01 zT_278;
    zT_2B3424E9_ParseToken zT_279;
    zT_2B3424E9_ParseToken zT_281;
    zT_EAC3E484_TokenKind zT_282;
    unsigned int zT_283;
    unsigned short zT_284;
    zT_D3EB6303_StringInterner* zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    zT_B559F9DA_Parser* zT_289;
    zT_2B3424E9_ParseToken zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291 = {0};
    unsigned int zT_292 = 0;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_296;
    unsigned int zT_301;
    int zT_306;
    unsigned int zT_309;
    unsigned short zT_310;
    int zT_313;
    int zT_315;
    int zT_317;
    unsigned int zT_319 = 0;
    unsigned int zT_321 = 0;
    zT_B559F9DA_Parser* zT_322;
    zT_3A355BD2_Token zT_323 = {0};
    zT_EAC3E484_TokenKind zT_324;
    zT_B559F9DA_Parser* zT_329;
    zT_3B6EA323_EU_01 zT_330 = {0};
    unsigned char zT_331;
    unsigned int zT_332;
    zT_B559F9DA_Parser* zT_333;
    zT_3B6EA323_EU_01 zT_336 = {0};
    unsigned char zT_337;
    unsigned int zT_338;
    unsigned char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_345;
    unsigned int zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    int zT_351;
    unsigned char* zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_355 = 0;
    unsigned int zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned char* zT_364;
    unsigned int zT_365;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_366;
    unsigned char* zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    unsigned int zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    zT_6B0A7D14_AstStore* zT_377;
    unsigned int zT_378;
    zT_22A7C88B_AstNode zT_380 = {0};
    zT_8143F551_AstKind zT_381;
    int zT_385;
    unsigned char* zT_386;
    unsigned int zT_387;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_388;
    unsigned int zT_389 = 0;
    unsigned int zT_393;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_394;
    unsigned char* zT_398;
    unsigned int zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    unsigned char* zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned int zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    int zT_407;
    unsigned int zT_408;
    zT_B559F9DA_Parser* zT_409;
    zT_3A355BD2_Token zT_410 = {0};
    zT_EAC3E484_TokenKind zT_411;
    zT_B559F9DA_Parser* zT_416;
    zT_3A355BD2_Token zT_417 = {0};
    zT_B559F9DA_Parser* zT_418;
    zT_3A355BD2_Token zT_419 = {0};
    zT_EAC3E484_TokenKind zT_420;
    zT_B559F9DA_Parser* zT_425;
    zT_3B6EA323_EU_01 zT_426 = {0};
    unsigned char zT_427;
    unsigned int zT_428;
    zT_B559F9DA_Parser* zT_429;
    zT_3A355BD2_Token zT_430 = {0};
    zT_EAC3E484_TokenKind zT_431;
    zT_B559F9DA_Parser* zT_436;
    zT_3B6EA323_EU_01 zT_437 = {0};
    unsigned char zT_438;
    unsigned int zT_439;
    zT_B559F9DA_Parser* zT_440;
    zT_3B6EA323_EU_01 zT_443 = {0};
    unsigned char zT_444;
    unsigned int zT_445;
    zT_B559F9DA_Parser* zT_446;
    zT_3A355BD2_Token zT_447 = {0};
    zT_EAC3E484_TokenKind zT_448;
    zT_B559F9DA_Parser* zT_453;
    zT_3A355BD2_Token zT_454 = {0};
    zT_B559F9DA_Parser* zT_455;
    zT_3A355BD2_Token zT_456 = {0};
    zT_EAC3E484_TokenKind zT_457;
    zT_B559F9DA_Parser* zT_463;
    zT_3A355BD2_Token zT_464 = {0};
    unsigned char* zT_466;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_467;
    unsigned int zT_468;
    zT_B559F9DA_Parser* zT_469;
    zT_3A355BD2_Token zT_470;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_471;
    zT_DBF3575C_ParserError zT_472;
    zT_3B6EA323_EU_01 zT_473;
    unsigned int zT_475;
    int zT_476;
    zT_3A355BD2_Token zT_478;
    unsigned int zT_479;
    unsigned short zT_480;
    unsigned int zT_482;
    zT_6B0A7D14_AstStore* zT_483;
    unsigned int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned int zT_491;
    int zT_496;
    unsigned int zT_499 = 0;
    zT_3B6EA323_EU_01 zT_500;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc0;
    zT_5A26C2ED_Arr_unsigned_char_1 pc0b;
    unsigned int pc0l;
    unsigned int pc0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck;
    zT_22A7C88B_AstNode cond_n;
    zT_5A26C2ED_Arr_unsigned_char_1 pckb;
    unsigned int pckl;
    unsigned int pcks;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc1;
    zT_5A26C2ED_Arr_unsigned_char_1 pc1b;
    unsigned int pc1l;
    unsigned int pc1s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2;
    zT_5A26C2ED_Arr_unsigned_char_1 pc2b;
    unsigned int pc2l;
    unsigned int pc2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck1;
    zT_22A7C88B_AstNode cn1;
    zT_5A26C2ED_Arr_unsigned_char_1 pck1b;
    unsigned int pck1l;
    unsigned int pck1s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck2;
    zT_22A7C88B_AstNode cn2;
    zT_5A26C2ED_Arr_unsigned_char_1 pck2b;
    unsigned int pck2l;
    unsigned int pck2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pknl;
    unsigned int capture_node;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int then_body;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pif_b;
    unsigned int pif_l;
    unsigned int pif_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_km;
    zT_5A26C2ED_Arr_unsigned_char_1 pif_kb;
    unsigned int pif_kl;
    unsigned int pif_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_nl;
    unsigned int else_node;
    unsigned int end_pos;
    zT_3A355BD2_Token else_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u else_msg;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_18;
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_20;
    zT_22 = "PIF:c=";
    zT_24 = 6;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    pc0 = zT_23;
    zT_25 = pc0;
    zF_48AC7B3A_markerWrite(zT_25);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc0b[_i] = zT_27[_i];
        _i++;
    }
}
    zT_29 = cond;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)pc0b) + zT_33;
    zT_35 = (unsigned int)(10) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_30 = zT_36;
    zT_37 = zF_A7504564_itoa(zT_29, zT_30);
    pc0l = zT_37;
    zT_41 = (unsigned int)(9) - (unsigned int)((unsigned int)pc0l);
    pc0s = zT_41;
    zT_46 = (unsigned char*)((unsigned char*)pc0b) + pc0s;
    zT_47 = (unsigned int)(9) - pc0s;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zF_48AC7B3A_markerWrite(zT_42);
    zT_50 = "k";
    zT_52 = 1;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    pck = zT_51;
    zT_53 = pck;
    zF_48AC7B3A_markerWrite(zT_53);
    zT_55 = self->store;
    zT_56 = cond;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    cond_n = zT_58;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pckb[_i] = zT_60[_i];
        _i++;
    }
}
    zT_64 = cond_n.kind;
    zT_68 = 0;
    zT_69 = (unsigned char*)((unsigned char*)pckb) + zT_68;
    zT_70 = (unsigned int)(10) - zT_68;
    zT_71.ptr = zT_69;
    zT_71.len = zT_70;
    zT_63 = zT_71;
    zT_72 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_64), zT_63);
    pckl = zT_72;
    zT_76 = (unsigned int)(9) - (unsigned int)((unsigned int)pckl);
    pcks = zT_76;
    zT_81 = (unsigned char*)((unsigned char*)pckb) + pcks;
    zT_82 = (unsigned int)(9) - pcks;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zF_48AC7B3A_markerWrite(zT_77);
    zT_85 = "c1";
    zT_87 = 2;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    pc1 = zT_86;
    zT_88 = pc1;
    zF_48AC7B3A_markerWrite(zT_88);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_90[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc1b[_i] = zT_90[_i];
        _i++;
    }
}
    zT_92 = cond_n.child_0;
    zT_97 = 0;
    zT_98 = (unsigned char*)((unsigned char*)pc1b) + zT_97;
    zT_99 = (unsigned int)(10) - zT_97;
    zT_100.ptr = zT_98;
    zT_100.len = zT_99;
    zT_93 = zT_100;
    zT_101 = zF_A7504564_itoa(zT_92, zT_93);
    pc1l = zT_101;
    zT_105 = (unsigned int)(9) - (unsigned int)((unsigned int)pc1l);
    pc1s = zT_105;
    zT_110 = (unsigned char*)((unsigned char*)pc1b) + pc1s;
    zT_111 = (unsigned int)(9) - pc1s;
    zT_112.ptr = zT_110;
    zT_112.len = zT_111;
    zT_106 = zT_112;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_114 = "c2";
    zT_116 = 2;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    pc2 = zT_115;
    zT_117 = pc2;
    zF_48AC7B3A_markerWrite(zT_117);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_119[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc2b[_i] = zT_119[_i];
        _i++;
    }
}
    zT_121 = cond_n.child_1;
    zT_126 = 0;
    zT_127 = (unsigned char*)((unsigned char*)pc2b) + zT_126;
    zT_128 = (unsigned int)(10) - zT_126;
    zT_129.ptr = zT_127;
    zT_129.len = zT_128;
    zT_122 = zT_129;
    zT_130 = zF_A7504564_itoa(zT_121, zT_122);
    pc2l = zT_130;
    zT_134 = (unsigned int)(9) - (unsigned int)((unsigned int)pc2l);
    pc2s = zT_134;
    zT_139 = (unsigned char*)((unsigned char*)pc2b) + pc2s;
    zT_140 = (unsigned int)(9) - pc2s;
    zT_141.ptr = zT_139;
    zT_141.len = zT_140;
    zT_135 = zT_141;
    zF_48AC7B3A_markerWrite(zT_135);
    zT_143 = "k1";
    zT_145 = 2;
    zT_144.ptr = zT_143;
    zT_144.len = zT_145;
    pck1 = zT_144;
    zT_146 = pck1;
    zF_48AC7B3A_markerWrite(zT_146);
    zT_148 = self->store;
    zT_149 = cond_n.child_0;
    zT_152 = zF_FCDD1D35_astStoreNodeAt(zT_148, zT_149);
    cn1 = zT_152;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pck1b[_i] = zT_154[_i];
        _i++;
    }
}
    zT_158 = cn1.kind;
    zT_162 = 0;
    zT_163 = (unsigned char*)((unsigned char*)pck1b) + zT_162;
    zT_164 = (unsigned int)(10) - zT_162;
    zT_165.ptr = zT_163;
    zT_165.len = zT_164;
    zT_157 = zT_165;
    zT_166 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_158), zT_157);
    pck1l = zT_166;
    zT_170 = (unsigned int)(9) - (unsigned int)((unsigned int)pck1l);
    pck1s = zT_170;
    zT_175 = (unsigned char*)((unsigned char*)pck1b) + pck1s;
    zT_176 = (unsigned int)(9) - pck1s;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_179 = "k2";
    zT_181 = 2;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    pck2 = zT_180;
    zT_182 = pck2;
    zF_48AC7B3A_markerWrite(zT_182);
    zT_184 = self->store;
    zT_185 = cond_n.child_1;
    zT_188 = zF_FCDD1D35_astStoreNodeAt(zT_184, zT_185);
    cn2 = zT_188;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_190[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pck2b[_i] = zT_190[_i];
        _i++;
    }
}
    zT_194 = cn2.kind;
    zT_198 = 0;
    zT_199 = (unsigned char*)((unsigned char*)pck2b) + zT_198;
    zT_200 = (unsigned int)(10) - zT_198;
    zT_201.ptr = zT_199;
    zT_201.len = zT_200;
    zT_193 = zT_201;
    zT_202 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_194), zT_193);
    pck2l = zT_202;
    zT_206 = (unsigned int)(9) - (unsigned int)((unsigned int)pck2l);
    pck2s = zT_206;
    zT_211 = (unsigned char*)((unsigned char*)pck2b) + pck2s;
    zT_212 = (unsigned int)(9) - pck2s;
    zT_213.ptr = zT_211;
    zT_213.len = zT_212;
    zT_207 = zT_213;
    zF_48AC7B3A_markerWrite(zT_207);
    zT_215 = "\n";
    zT_217 = 1;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    pknl = zT_216;
    zT_218 = pknl;
    zF_48AC7B3A_markerWrite(zT_218);
    zT_219 = self;
    zT_224 = zF_5578C74F_parserExpect(zT_219, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_225 = zT_224.is_error;
    if (zT_225) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_226 = zT_224.data.err;
    zT_227.data.err = zT_226;
    zT_227.is_error = 1;
    return zT_227;
    z_bb_8:
    zT_228 = zT_224.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_228;
    zT_230 = 0;
    zT_231 = (unsigned int)zT_230;
    capture_node = zT_231;
    zT_232 = self;
    zT_233 = zF_068A2DE5_parserPeek(zT_232);
    zT_234 = zT_233.kind;
    if ((int)(zT_234 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_239 = self;
    zT_240 = zF_C241B2C4_parserAdvance(zT_239);
    (void)zT_240;
    name_tok = zT_242;
    zT_243 = self;
    zT_244 = zF_068A2DE5_parserPeek(zT_243);
    zT_245 = zT_244.kind;
    if ((int)(zT_245 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    then_body = zT_321;
    zT_322 = self;
    zT_323 = zF_068A2DE5_parserPeek(zT_322);
    zT_324 = zT_323.kind;
    if ((int)(zT_324 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_24; else goto z_bb_26;
    z_bb_12:
    zT_250 = self;
    zT_255 = zF_5578C74F_parserExpect(zT_250, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_256 = zT_255.is_error;
    if (zT_256) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_270 = self;
    zT_275 = zF_5578C74F_parserExpect(zT_270, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_276 = zT_275.is_error;
    if (zT_276) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_260 = self;
    zT_265 = zF_5578C74F_parserExpect(zT_260, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_266 = zT_265.is_error;
    if (zT_266) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_257 = zT_255.data.err;
    zT_258.data.err = zT_257;
    zT_258.is_error = 1;
    return zT_258;
    z_bb_16:
    zT_259 = zT_255.data.payload;
    goto z_bb_17;
    z_bb_17:
    name_tok = zT_259;
    goto z_bb_13;
    z_bb_18:
    zT_267 = zT_265.data.err;
    zT_268.data.err = zT_267;
    zT_268.is_error = 1;
    return zT_268;
    z_bb_19:
    zT_269 = zT_265.data.payload;
    goto z_bb_20;
    z_bb_20:
    name_tok = zT_269;
    goto z_bb_13;
    z_bb_21:
    zT_277 = zT_275.data.err;
    zT_278.data.err = zT_277;
    zT_278.is_error = 1;
    return zT_278;
    z_bb_22:
    zT_279 = zT_275.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_279;
    zT_282 = name_tok.kind;
    zT_281.kind = zT_282;
    zT_283 = name_tok.span_start;
    zT_281.span_start = zT_283;
    zT_284 = name_tok.span_len;
    zT_281.span_len = zT_284;
    pt = zT_281;
    zT_286 = self->interner;
    zT_289 = self;
    zT_290 = pt;
    zT_291 = zF_08D61E58_parserTokenText(zT_289, zT_290);
    zT_287 = zT_291;
    zT_292 = zF_50C274AF_stringInternerInter(zT_286, zT_287);
    name_id = zT_292;
    zT_293 = self->store;
    zT_306 = 0;
    zT_296 = name_tok.span_start;
    zT_309 = name_tok.span_start;
    zT_310 = name_tok.span_len;
    zT_313 = 0;
    zT_315 = 0;
    zT_317 = 0;
    zT_301 = name_id;
    zT_319 = zF_6C9FF72F_astStoreAddNode(zT_293, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_306), zT_296, (unsigned int)(zT_309 + (unsigned int)((unsigned int)zT_310)), (unsigned int)((unsigned int)zT_313), (unsigned int)((unsigned int)zT_315), (unsigned int)((unsigned int)zT_317), zT_301);
    capture_node = zT_319;
    goto z_bb_11;
    z_bb_24:
    zT_329 = self;
    zT_330 = zF_365CA04A_parserParseBlock(zT_329);
    zT_331 = zT_330.is_error;
    if (zT_331) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_340 = "PIF:b";
    zT_342 = 5;
    zT_341.ptr = zT_340;
    zT_341.len = zT_342;
    pif_m = zT_341;
    zT_343 = pif_m;
    zF_48AC7B3A_markerWrite(zT_343);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_345[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pif_b[_i] = zT_345[_i];
        _i++;
    }
}
    zT_347 = then_body;
    zT_351 = 0;
    zT_352 = (unsigned char*)((unsigned char*)pif_b) + zT_351;
    zT_353 = (unsigned int)(10) - zT_351;
    zT_354.ptr = zT_352;
    zT_354.len = zT_353;
    zT_348 = zT_354;
    zT_355 = zF_A7504564_itoa(zT_347, zT_348);
    pif_l = zT_355;
    zT_359 = (unsigned int)(9) - (unsigned int)((unsigned int)pif_l);
    pif_s = zT_359;
    zT_364 = (unsigned char*)((unsigned char*)pif_b) + pif_s;
    zT_365 = (unsigned int)(9) - pif_s;
    zT_366.ptr = zT_364;
    zT_366.len = zT_365;
    zT_360 = zT_366;
    zF_48AC7B3A_markerWrite(zT_360);
    zT_368 = "k";
    zT_370 = 1;
    zT_369.ptr = zT_368;
    zT_369.len = zT_370;
    pif_km = zT_369;
    zT_371 = pif_km;
    zF_48AC7B3A_markerWrite(zT_371);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_373[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pif_kb[_i] = zT_373[_i];
        _i++;
    }
}
    zT_377 = self->store;
    zT_378 = then_body;
    zT_380 = zF_FCDD1D35_astStoreNodeAt(zT_377, zT_378);
    zT_381 = zT_380.kind;
    zT_385 = 0;
    zT_386 = (unsigned char*)((unsigned char*)pif_kb) + zT_385;
    zT_387 = (unsigned int)(10) - zT_385;
    zT_388.ptr = zT_386;
    zT_388.len = zT_387;
    zT_376 = zT_388;
    zT_389 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_381), zT_376);
    pif_kl = zT_389;
    zT_393 = (unsigned int)(9) - (unsigned int)((unsigned int)pif_kl);
    pif_ks = zT_393;
    zT_398 = (unsigned char*)((unsigned char*)pif_kb) + pif_ks;
    zT_399 = (unsigned int)(9) - pif_ks;
    zT_400.ptr = zT_398;
    zT_400.len = zT_399;
    zT_394 = zT_400;
    zF_48AC7B3A_markerWrite(zT_394);
    zT_402 = "\n";
    zT_404 = 1;
    zT_403.ptr = zT_402;
    zT_403.len = zT_404;
    pif_nl = zT_403;
    zT_405 = pif_nl;
    zF_48AC7B3A_markerWrite(zT_405);
    zT_407 = 0;
    zT_408 = (unsigned int)zT_407;
    else_node = zT_408;
    zT_409 = self;
    zT_410 = zF_068A2DE5_parserPeek(zT_409);
    zT_411 = zT_410.kind;
    if ((int)(zT_411 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_33; else goto z_bb_34;
    z_bb_26:
    zT_333 = self;
    zT_336 = zF_F07C1F04_parserParseExprPrec(zT_333, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_337 = zT_336.is_error;
    if (zT_337) goto z_bb_30; else goto z_bb_31;
    z_bb_27:
    return zT_330;
    z_bb_28:
    zT_332 = zT_330.data.payload;
    goto z_bb_29;
    z_bb_29:
    then_body = zT_332;
    goto z_bb_25;
    z_bb_30:
    return zT_336;
    z_bb_31:
    zT_338 = zT_336.data.payload;
    goto z_bb_32;
    z_bb_32:
    then_body = zT_338;
    goto z_bb_25;
    z_bb_33:
    zT_416 = self;
    zT_417 = zF_C241B2C4_parserAdvance(zT_416);
    (void)zT_417;
    zT_418 = self;
    zT_419 = zF_068A2DE5_parserPeek(zT_418);
    zT_420 = zT_419.kind;
    if ((int)(zT_420 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    zT_446 = self;
    zT_447 = zF_068A2DE5_parserPeek(zT_446);
    zT_448 = zT_447.kind;
    if ((int)(zT_448 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_50; else goto z_bb_51;
    z_bb_35:
    zT_425 = self;
    zT_426 = zF_DB819578_parserParseIfStmt(zT_425);
    zT_427 = zT_426.is_error;
    if (zT_427) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_429 = self;
    zT_430 = zF_068A2DE5_parserPeek(zT_429);
    zT_431 = zT_430.kind;
    if ((int)(zT_431 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_41; else goto z_bb_43;
    z_bb_38:
    return zT_426;
    z_bb_39:
    zT_428 = zT_426.data.payload;
    goto z_bb_40;
    z_bb_40:
    else_node = zT_428;
    goto z_bb_36;
    z_bb_41:
    zT_436 = self;
    zT_437 = zF_365CA04A_parserParseBlock(zT_436);
    zT_438 = zT_437.is_error;
    if (zT_438) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_440 = self;
    zT_443 = zF_F07C1F04_parserParseExprPrec(zT_440, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_444 = zT_443.is_error;
    if (zT_444) goto z_bb_47; else goto z_bb_48;
    z_bb_44:
    return zT_437;
    z_bb_45:
    zT_439 = zT_437.data.payload;
    goto z_bb_46;
    z_bb_46:
    else_node = zT_439;
    goto z_bb_42;
    z_bb_47:
    return zT_443;
    z_bb_48:
    zT_445 = zT_443.data.payload;
    goto z_bb_49;
    z_bb_49:
    else_node = zT_445;
    goto z_bb_42;
    z_bb_50:
    zT_453 = self;
    zT_454 = zF_C241B2C4_parserAdvance(zT_453);
    (void)zT_454;
    zT_455 = self;
    zT_456 = zF_068A2DE5_parserPeek(zT_455);
    zT_457 = zT_456.kind;
    if ((int)(zT_457 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_475 = kw.span_start;
    end_pos = zT_475;
    zT_476 = self->last_tok_valid;
    if (zT_476) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_463 = self;
    zT_464 = zF_068A2DE5_parserPeek(zT_463);
    else_tok = zT_464;
    zT_466 = "';' not allowed before 'else' - use braces: if (cond) { ... } else { ... }";
    zT_468 = 74;
    zT_467.ptr = zT_466;
    zT_467.len = zT_468;
    else_msg = zT_467;
    zT_469 = self;
    zT_470 = else_tok;
    zT_471 = else_msg;
    zF_17DF2CA5_parserAddError(zT_469, zT_470, zT_471);
    zT_472 = 1;
    zT_473.data.err = zT_472;
    zT_473.is_error = 1;
    return zT_473;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_478 = self->last_tok;
    last = zT_478;
    zT_479 = last.span_start;
    zT_480 = last.span_len;
    zT_482 = zT_479 + (unsigned int)((unsigned int)zT_480);
    end_pos = zT_482;
    goto z_bb_55;
    z_bb_55:
    zT_483 = self->store;
    zT_496 = 0;
    zT_486 = kw.span_start;
    zT_487 = end_pos;
    zT_488 = cond;
    zT_489 = then_body;
    zT_490 = else_node;
    zT_491 = capture_node;
    zT_499 = zF_6C9FF72F_astStoreAddNode(zT_483, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt), (unsigned char)((unsigned char)zT_496), zT_486, zT_487, zT_488, zT_489, zT_490, zT_491);
    zT_500.data.payload = zT_499;
    zT_500.is_error = 0;
    return zT_500;
}

/* parserParseWhileStmt */
zT_3B6EA323_EU_01 zF_4E7AD820_parserParseWhileStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_CB78802F_EU_49 zT_26 = {0};
    unsigned char zT_27;
    int zT_28;
    zT_3B6EA323_EU_01 zT_29;
    zT_2B3424E9_ParseToken zT_30;
    int zT_32;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_B559F9DA_Parser* zT_37;
    zT_3A355BD2_Token zT_38 = {0};
    zT_EAC3E484_TokenKind zT_39;
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_2B3424E9_ParseToken zT_47 = {0};
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_55;
    zT_CB78802F_EU_49 zT_60 = {0};
    unsigned char zT_61;
    int zT_62;
    zT_3B6EA323_EU_01 zT_63;
    zT_2B3424E9_ParseToken zT_64;
    zT_B559F9DA_Parser* zT_65;
    zT_CB78802F_EU_49 zT_70 = {0};
    unsigned char zT_71;
    int zT_72;
    zT_3B6EA323_EU_01 zT_73;
    zT_2B3424E9_ParseToken zT_74;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_B559F9DA_Parser* zT_78;
    zT_2B3424E9_ParseToken zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80 = {0};
    unsigned int zT_81 = 0;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_85;
    unsigned int zT_90;
    int zT_95;
    unsigned int zT_98;
    unsigned short zT_99;
    int zT_102;
    int zT_104;
    int zT_106;
    unsigned int zT_108 = 0;
    zT_B559F9DA_Parser* zT_109;
    zT_CB78802F_EU_49 zT_114 = {0};
    unsigned char zT_115;
    int zT_116;
    zT_3B6EA323_EU_01 zT_117;
    zT_2B3424E9_ParseToken zT_118;
    int zT_120;
    unsigned int zT_121;
    zT_B559F9DA_Parser* zT_122;
    zT_3A355BD2_Token zT_123 = {0};
    zT_EAC3E484_TokenKind zT_124;
    zT_B559F9DA_Parser* zT_129;
    zT_3A355BD2_Token zT_130 = {0};
    zT_B559F9DA_Parser* zT_131;
    zT_CB78802F_EU_49 zT_136 = {0};
    unsigned char zT_137;
    int zT_138;
    zT_3B6EA323_EU_01 zT_139;
    zT_2B3424E9_ParseToken zT_140;
    zT_B559F9DA_Parser* zT_141;
    zT_3B6EA323_EU_01 zT_144 = {0};
    unsigned char zT_145;
    unsigned int zT_146;
    zT_B559F9DA_Parser* zT_147;
    zT_CB78802F_EU_49 zT_152 = {0};
    unsigned char zT_153;
    int zT_154;
    zT_3B6EA323_EU_01 zT_155;
    zT_2B3424E9_ParseToken zT_156;
    unsigned int zT_158 = 0;
    zT_B559F9DA_Parser* zT_159;
    zT_3A355BD2_Token zT_160 = {0};
    zT_EAC3E484_TokenKind zT_161;
    zT_B559F9DA_Parser* zT_166;
    zT_3B6EA323_EU_01 zT_167 = {0};
    unsigned char zT_168;
    unsigned int zT_169;
    zT_B559F9DA_Parser* zT_170;
    zT_3B6EA323_EU_01 zT_173 = {0};
    unsigned char zT_174;
    unsigned int zT_175;
    zT_B559F9DA_Parser* zT_176;
    zT_3A355BD2_Token zT_177 = {0};
    zT_EAC3E484_TokenKind zT_178;
    zT_B559F9DA_Parser* zT_183;
    zT_3A355BD2_Token zT_184 = {0};
    unsigned int zT_186 = 0;
    int zT_187;
    zT_3A355BD2_Token zT_189;
    unsigned int zT_190;
    unsigned short zT_191;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_198;
    unsigned char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    int zT_209;
    unsigned char* zT_210;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213 = 0;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned char* zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    int zT_244;
    unsigned int zT_247 = 0;
    zT_3B6EA323_EU_01 zT_248;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_name;
    unsigned int cap_node;
    zT_2B3424E9_ParseToken cap_tok;
    unsigned int continue_expr;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_5A26C2ED_Arr_unsigned_char_1 zzz_buf_c2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zzz_c2e_m;
    unsigned int zzz_c2e_l;
    unsigned int zzz_c2e_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u zzz_c2e_nl;
    unsigned int zzz_c2;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_18;
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_20;
    zT_21 = self;
    zT_26 = zF_5578C74F_parserExpect(zT_21, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = zT_26.data.err;
    zT_29.data.err = zT_28;
    zT_29.is_error = 1;
    return zT_29;
    z_bb_8:
    zT_30 = zT_26.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    capture_name = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    cap_node = zT_36;
    zT_37 = self;
    zT_38 = zF_068A2DE5_parserPeek(zT_37);
    zT_39 = zT_38.kind;
    if ((int)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self;
    zT_45 = zF_C241B2C4_parserAdvance(zT_44);
    (void)zT_45;
    cap_tok = zT_47;
    zT_48 = self;
    zT_49 = zF_068A2DE5_parserPeek(zT_48);
    zT_50 = zT_49.kind;
    if ((int)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_120 = 0;
    zT_121 = (unsigned int)zT_120;
    continue_expr = zT_121;
    zT_122 = self;
    zT_123 = zF_068A2DE5_parserPeek(zT_122);
    zT_124 = zT_123.kind;
    if ((int)(zT_124 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_24; else goto z_bb_25;
    z_bb_12:
    zT_55 = self;
    zT_60 = zF_5578C74F_parserExpect(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_75 = self->interner;
    zT_78 = self;
    zT_79 = cap_tok;
    zT_80 = zF_08D61E58_parserTokenText(zT_78, zT_79);
    zT_76 = zT_80;
    zT_81 = zF_50C274AF_stringInternerInter(zT_75, zT_76);
    capture_name = zT_81;
    zT_82 = self->store;
    zT_95 = 0;
    zT_85 = cap_tok.span_start;
    zT_98 = cap_tok.span_start;
    zT_99 = cap_tok.span_len;
    zT_102 = 0;
    zT_104 = 0;
    zT_106 = 0;
    zT_90 = capture_name;
    zT_108 = zF_6C9FF72F_astStoreAddNode(zT_82, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture), (unsigned char)((unsigned char)zT_95), zT_85, (unsigned int)(zT_98 + (unsigned int)((unsigned int)zT_99)), (unsigned int)((unsigned int)zT_102), (unsigned int)((unsigned int)zT_104), (unsigned int)((unsigned int)zT_106), zT_90);
    cap_node = zT_108;
    zT_109 = self;
    zT_114 = zF_5578C74F_parserExpect(zT_109, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_115 = zT_114.is_error;
    if (zT_115) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_65 = self;
    zT_70 = zF_5578C74F_parserExpect(zT_65, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_62 = zT_60.data.err;
    zT_63.data.err = zT_62;
    zT_63.is_error = 1;
    return zT_63;
    z_bb_16:
    zT_64 = zT_60.data.payload;
    goto z_bb_17;
    z_bb_17:
    cap_tok = zT_64;
    goto z_bb_13;
    z_bb_18:
    zT_72 = zT_70.data.err;
    zT_73.data.err = zT_72;
    zT_73.is_error = 1;
    return zT_73;
    z_bb_19:
    zT_74 = zT_70.data.payload;
    goto z_bb_20;
    z_bb_20:
    cap_tok = zT_74;
    goto z_bb_13;
    z_bb_21:
    zT_116 = zT_114.data.err;
    zT_117.data.err = zT_116;
    zT_117.is_error = 1;
    return zT_117;
    z_bb_22:
    zT_118 = zT_114.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_118;
    goto z_bb_11;
    z_bb_24:
    zT_129 = self;
    zT_130 = zF_C241B2C4_parserAdvance(zT_129);
    (void)zT_130;
    zT_131 = self;
    zT_136 = zF_5578C74F_parserExpect(zT_131, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_137 = zT_136.is_error;
    if (zT_137) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    body = zT_158;
    zT_159 = self;
    zT_160 = zF_068A2DE5_parserPeek(zT_159);
    zT_161 = zT_160.kind;
    if ((int)(zT_161 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_35; else goto z_bb_37;
    z_bb_26:
    zT_138 = zT_136.data.err;
    zT_139.data.err = zT_138;
    zT_139.is_error = 1;
    return zT_139;
    z_bb_27:
    zT_140 = zT_136.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_140;
    zT_141 = self;
    zT_144 = zF_F07C1F04_parserParseExprPrec(zT_141, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_145 = zT_144.is_error;
    if (zT_145) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return zT_144;
    z_bb_30:
    zT_146 = zT_144.data.payload;
    goto z_bb_31;
    z_bb_31:
    continue_expr = zT_146;
    zT_147 = self;
    zT_152 = zF_5578C74F_parserExpect(zT_147, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_153 = zT_152.is_error;
    if (zT_153) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_154 = zT_152.data.err;
    zT_155.data.err = zT_154;
    zT_155.is_error = 1;
    return zT_155;
    z_bb_33:
    zT_156 = zT_152.data.payload;
    goto z_bb_34;
    z_bb_34:
    (void)zT_156;
    goto z_bb_25;
    z_bb_35:
    zT_166 = self;
    zT_167 = zF_365CA04A_parserParseBlock(zT_166);
    zT_168 = zT_167.is_error;
    if (zT_168) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    zT_176 = self;
    zT_177 = zF_068A2DE5_parserPeek(zT_176);
    zT_178 = zT_177.kind;
    if ((int)(zT_178 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_44; else goto z_bb_45;
    z_bb_37:
    zT_170 = self;
    zT_173 = zF_F07C1F04_parserParseExprPrec(zT_170, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_174 = zT_173.is_error;
    if (zT_174) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    return zT_167;
    z_bb_39:
    zT_169 = zT_167.data.payload;
    goto z_bb_40;
    z_bb_40:
    body = zT_169;
    goto z_bb_36;
    z_bb_41:
    return zT_173;
    z_bb_42:
    zT_175 = zT_173.data.payload;
    goto z_bb_43;
    z_bb_43:
    body = zT_175;
    goto z_bb_36;
    z_bb_44:
    zT_183 = self;
    zT_184 = zF_C241B2C4_parserAdvance(zT_183);
    (void)zT_184;
    goto z_bb_45;
    z_bb_45:
    end_pos = zT_186;
    zT_187 = self->last_tok_valid;
    if (zT_187) goto z_bb_46; else goto z_bb_48;
    z_bb_46:
    zT_189 = self->last_tok;
    last = zT_189;
    zT_190 = last.span_start;
    zT_191 = last.span_len;
    zT_193 = zT_190 + (unsigned int)((unsigned int)zT_191);
    end_pos = zT_193;
    goto z_bb_47;
    z_bb_47:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_198[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zzz_buf_c2[_i] = zT_198[_i];
        _i++;
    }
}
    zT_200 = "PTC2:e";
    zT_202 = 6;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    zzz_c2e_m = zT_201;
    zT_203 = zzz_c2e_m;
    zF_48AC7B3A_markerWrite(zT_203);
    zT_205 = continue_expr;
    zT_209 = 0;
    zT_210 = (unsigned char*)((unsigned char*)zzz_buf_c2) + zT_209;
    zT_211 = (unsigned int)(10) - zT_209;
    zT_212.ptr = zT_210;
    zT_212.len = zT_211;
    zT_206 = zT_212;
    zT_213 = zF_A7504564_itoa(zT_205, zT_206);
    zzz_c2e_l = zT_213;
    zT_217 = (unsigned int)(9) - (unsigned int)((unsigned int)zzz_c2e_l);
    zzz_c2e_s = zT_217;
    zT_222 = (unsigned char*)((unsigned char*)zzz_buf_c2) + zzz_c2e_s;
    zT_223 = (unsigned int)(9) - zzz_c2e_s;
    zT_224.ptr = zT_222;
    zT_224.len = zT_223;
    zT_218 = zT_224;
    zF_48AC7B3A_markerWrite(zT_218);
    zT_226 = "\n";
    zT_228 = 1;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    zzz_c2e_nl = zT_227;
    zT_229 = zzz_c2e_nl;
    zF_48AC7B3A_markerWrite(zT_229);
    zzz_c2 = continue_expr;
    zT_231 = self->store;
    zT_244 = 0;
    zT_234 = kw.span_start;
    zT_235 = end_pos;
    zT_236 = cond;
    zT_237 = body;
    zT_238 = zzz_c2;
    zT_239 = cap_node;
    zT_247 = zF_6C9FF72F_astStoreAddNode(zT_231, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt), (unsigned char)((unsigned char)zT_244), zT_234, zT_235, zT_236, zT_237, zT_238, zT_239);
    zT_248.data.payload = zT_247;
    zT_248.is_error = 0;
    return zT_248;
    z_bb_48:
    zT_194 = kw.span_start;
    end_pos = zT_194;
    goto z_bb_47;
}

/* parserParseForStmt */
zT_3B6EA323_EU_01 zF_54BCF0C6_parserParseForStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_28;
    zT_3A355BD2_Token zT_29 = {0};
    zT_B559F9DA_Parser* zT_31;
    zT_3B6EA323_EU_01 zT_34 = {0};
    unsigned char zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_42;
    unsigned int zT_43;
    int zT_50;
    int zT_52;
    int zT_54;
    int zT_56;
    int zT_58;
    unsigned int zT_60 = 0;
    zT_B559F9DA_Parser* zT_61;
    zT_CB78802F_EU_49 zT_66 = {0};
    unsigned char zT_67;
    int zT_68;
    zT_3B6EA323_EU_01 zT_69;
    zT_2B3424E9_ParseToken zT_70;
    int zT_72;
    unsigned int zT_73;
    int zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_77;
    zT_3A355BD2_Token zT_78 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_B559F9DA_Parser* zT_84;
    zT_3A355BD2_Token zT_85 = {0};
    zT_2B3424E9_ParseToken zT_87 = {0};
    zT_B559F9DA_Parser* zT_88;
    zT_3A355BD2_Token zT_89 = {0};
    zT_EAC3E484_TokenKind zT_90;
    zT_B559F9DA_Parser* zT_95;
    zT_CB78802F_EU_49 zT_100 = {0};
    unsigned char zT_101;
    int zT_102;
    zT_3B6EA323_EU_01 zT_103;
    zT_2B3424E9_ParseToken zT_104;
    zT_B559F9DA_Parser* zT_105;
    zT_CB78802F_EU_49 zT_110 = {0};
    unsigned char zT_111;
    int zT_112;
    zT_3B6EA323_EU_01 zT_113;
    zT_2B3424E9_ParseToken zT_114;
    zT_D3EB6303_StringInterner* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_B559F9DA_Parser* zT_118;
    zT_2B3424E9_ParseToken zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120 = {0};
    unsigned int zT_121 = 0;
    zT_B559F9DA_Parser* zT_122;
    zT_3A355BD2_Token zT_123 = {0};
    zT_EAC3E484_TokenKind zT_124;
    zT_B559F9DA_Parser* zT_129;
    zT_3A355BD2_Token zT_130 = {0};
    zT_B559F9DA_Parser* zT_132;
    zT_CB78802F_EU_49 zT_137 = {0};
    unsigned char zT_138;
    int zT_139;
    zT_3B6EA323_EU_01 zT_140;
    zT_2B3424E9_ParseToken zT_141;
    zT_D3EB6303_StringInterner* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    zT_B559F9DA_Parser* zT_145;
    zT_2B3424E9_ParseToken zT_146;
    zT_2B3424E9_ParseToken zT_147;
    zT_EAC3E484_TokenKind zT_148;
    unsigned int zT_149;
    unsigned short zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151 = {0};
    unsigned int zT_152 = 0;
    zT_B559F9DA_Parser* zT_153;
    zT_CB78802F_EU_49 zT_158 = {0};
    unsigned char zT_159;
    int zT_160;
    zT_3B6EA323_EU_01 zT_161;
    zT_2B3424E9_ParseToken zT_162;
    unsigned int zT_164 = 0;
    zT_B559F9DA_Parser* zT_165;
    zT_3A355BD2_Token zT_166 = {0};
    zT_EAC3E484_TokenKind zT_167;
    zT_B559F9DA_Parser* zT_172;
    zT_3B6EA323_EU_01 zT_173 = {0};
    unsigned char zT_174;
    unsigned int zT_175;
    zT_B559F9DA_Parser* zT_176;
    zT_3B6EA323_EU_01 zT_179 = {0};
    unsigned char zT_180;
    unsigned int zT_181;
    zT_B559F9DA_Parser* zT_182;
    zT_3A355BD2_Token zT_183 = {0};
    zT_EAC3E484_TokenKind zT_184;
    zT_B559F9DA_Parser* zT_189;
    zT_3A355BD2_Token zT_190 = {0};
    unsigned int zT_192 = 0;
    int zT_193;
    zT_3A355BD2_Token zT_195;
    unsigned int zT_196;
    unsigned short zT_197;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    int zT_214;
    unsigned int zT_217 = 0;
    zT_3B6EA323_EU_01 zT_218;
    zT_3A355BD2_Token kw;
    unsigned int pattern;
    unsigned int end_node;
    unsigned int capture_name;
    unsigned int index_name;
    zT_2B3424E9_ParseToken cap_tok;
    unsigned int body;
    zT_2B3424E9_ParseToken idx_tok;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_18;
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    pattern = zT_20;
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    zT_23 = zT_22.kind;
    if ((int)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = self;
    zT_29 = zF_C241B2C4_parserAdvance(zT_28);
    (void)zT_29;
    zT_31 = self;
    zT_34 = zF_F07C1F04_parserParseExprPrec(zT_31, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_61 = self;
    zT_66 = zF_5578C74F_parserExpect(zT_61, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_67 = zT_66.is_error;
    if (zT_67) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    return zT_34;
    z_bb_10:
    zT_36 = zT_34.data.payload;
    goto z_bb_11;
    z_bb_11:
    end_node = zT_36;
    zT_37 = self->store;
    zT_50 = 0;
    zT_52 = 0;
    zT_54 = 0;
    zT_42 = pattern;
    zT_43 = end_node;
    zT_56 = 0;
    zT_58 = 0;
    zT_60 = zF_6C9FF72F_astStoreAddNode(zT_37, (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive), (unsigned char)((unsigned char)zT_50), (unsigned int)((unsigned int)zT_52), (unsigned int)((unsigned int)zT_54), zT_42, zT_43, (unsigned int)((unsigned int)zT_56), (unsigned int)((unsigned int)zT_58));
    pattern = zT_60;
    goto z_bb_8;
    z_bb_12:
    zT_68 = zT_66.data.err;
    zT_69.data.err = zT_68;
    zT_69.is_error = 1;
    return zT_69;
    z_bb_13:
    zT_70 = zT_66.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_70;
    zT_72 = 0;
    zT_73 = (unsigned int)zT_72;
    capture_name = zT_73;
    zT_75 = 0;
    zT_76 = (unsigned int)zT_75;
    index_name = zT_76;
    zT_77 = self;
    zT_78 = zF_068A2DE5_parserPeek(zT_77);
    zT_79 = zT_78.kind;
    if ((int)(zT_79 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_84 = self;
    zT_85 = zF_C241B2C4_parserAdvance(zT_84);
    (void)zT_85;
    cap_tok = zT_87;
    zT_88 = self;
    zT_89 = zF_068A2DE5_parserPeek(zT_88);
    zT_90 = zT_89.kind;
    if ((int)(zT_90 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_17; else goto z_bb_19;
    z_bb_16:
    body = zT_164;
    zT_165 = self;
    zT_166 = zF_068A2DE5_parserPeek(zT_165);
    zT_167 = zT_166.kind;
    if ((int)(zT_167 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_34; else goto z_bb_36;
    z_bb_17:
    zT_95 = self;
    zT_100 = zF_5578C74F_parserExpect(zT_95, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_101 = zT_100.is_error;
    if (zT_101) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_115 = self->interner;
    zT_118 = self;
    zT_119 = cap_tok;
    zT_120 = zF_08D61E58_parserTokenText(zT_118, zT_119);
    zT_116 = zT_120;
    zT_121 = zF_50C274AF_stringInternerInter(zT_115, zT_116);
    capture_name = zT_121;
    zT_122 = self;
    zT_123 = zF_068A2DE5_parserPeek(zT_122);
    zT_124 = zT_123.kind;
    if ((int)(zT_124 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_26; else goto z_bb_27;
    z_bb_19:
    zT_105 = self;
    zT_110 = zF_5578C74F_parserExpect(zT_105, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_111 = zT_110.is_error;
    if (zT_111) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_102 = zT_100.data.err;
    zT_103.data.err = zT_102;
    zT_103.is_error = 1;
    return zT_103;
    z_bb_21:
    zT_104 = zT_100.data.payload;
    goto z_bb_22;
    z_bb_22:
    cap_tok = zT_104;
    goto z_bb_18;
    z_bb_23:
    zT_112 = zT_110.data.err;
    zT_113.data.err = zT_112;
    zT_113.is_error = 1;
    return zT_113;
    z_bb_24:
    zT_114 = zT_110.data.payload;
    goto z_bb_25;
    z_bb_25:
    cap_tok = zT_114;
    goto z_bb_18;
    z_bb_26:
    zT_129 = self;
    zT_130 = zF_C241B2C4_parserAdvance(zT_129);
    (void)zT_130;
    zT_132 = self;
    zT_137 = zF_5578C74F_parserExpect(zT_132, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_138 = zT_137.is_error;
    if (zT_138) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_153 = self;
    zT_158 = zF_5578C74F_parserExpect(zT_153, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_159 = zT_158.is_error;
    if (zT_159) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_139 = zT_137.data.err;
    zT_140.data.err = zT_139;
    zT_140.is_error = 1;
    return zT_140;
    z_bb_29:
    zT_141 = zT_137.data.payload;
    goto z_bb_30;
    z_bb_30:
    idx_tok = zT_141;
    zT_142 = self->interner;
    zT_145 = self;
    zT_148 = idx_tok.kind;
    zT_147.kind = zT_148;
    zT_149 = idx_tok.span_start;
    zT_147.span_start = zT_149;
    zT_150 = idx_tok.span_len;
    zT_147.span_len = zT_150;
    zT_146 = zT_147;
    zT_151 = zF_08D61E58_parserTokenText(zT_145, zT_146);
    zT_143 = zT_151;
    zT_152 = zF_50C274AF_stringInternerInter(zT_142, zT_143);
    index_name = zT_152;
    goto z_bb_27;
    z_bb_31:
    zT_160 = zT_158.data.err;
    zT_161.data.err = zT_160;
    zT_161.is_error = 1;
    return zT_161;
    z_bb_32:
    zT_162 = zT_158.data.payload;
    goto z_bb_33;
    z_bb_33:
    (void)zT_162;
    goto z_bb_16;
    z_bb_34:
    zT_172 = self;
    zT_173 = zF_365CA04A_parserParseBlock(zT_172);
    zT_174 = zT_173.is_error;
    if (zT_174) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_182 = self;
    zT_183 = zF_068A2DE5_parserPeek(zT_182);
    zT_184 = zT_183.kind;
    if ((int)(zT_184 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_43; else goto z_bb_44;
    z_bb_36:
    zT_176 = self;
    zT_179 = zF_F07C1F04_parserParseExprPrec(zT_176, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_180 = zT_179.is_error;
    if (zT_180) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    return zT_173;
    z_bb_38:
    zT_175 = zT_173.data.payload;
    goto z_bb_39;
    z_bb_39:
    body = zT_175;
    goto z_bb_35;
    z_bb_40:
    return zT_179;
    z_bb_41:
    zT_181 = zT_179.data.payload;
    goto z_bb_42;
    z_bb_42:
    body = zT_181;
    goto z_bb_35;
    z_bb_43:
    zT_189 = self;
    zT_190 = zF_C241B2C4_parserAdvance(zT_189);
    (void)zT_190;
    goto z_bb_44;
    z_bb_44:
    end_pos = zT_192;
    zT_193 = self->last_tok_valid;
    if (zT_193) goto z_bb_45; else goto z_bb_47;
    z_bb_45:
    zT_195 = self->last_tok;
    last = zT_195;
    zT_196 = last.span_start;
    zT_197 = last.span_len;
    zT_199 = zT_196 + (unsigned int)((unsigned int)zT_197);
    end_pos = zT_199;
    goto z_bb_46;
    z_bb_46:
    zT_201 = self->store;
    zT_214 = 0;
    zT_204 = kw.span_start;
    zT_205 = end_pos;
    zT_206 = pattern;
    zT_207 = body;
    zT_208 = index_name;
    zT_209 = capture_name;
    zT_217 = zF_6C9FF72F_astStoreAddNode(zT_201, (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt), (unsigned char)((unsigned char)zT_214), zT_204, zT_205, zT_206, zT_207, zT_208, zT_209);
    zT_218.data.payload = zT_217;
    zT_218.is_error = 0;
    return zT_218;
    z_bb_47:
    zT_200 = kw.span_start;
    end_pos = zT_200;
    goto z_bb_46;
}

/* parserParseSwitchStmt */
zT_3B6EA323_EU_01 zF_3A6F34C7_parserParseSwitchSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_11;
    int zT_19;
    int zT_21;
    int zT_23;
    int zT_25;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    unsigned int inner;
    zT_2 = self;
    zT_3 = zF_A9AC92CA_parserParseSwitchEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_5;
    zT_6 = self->store;
    zT_19 = 0;
    zT_21 = 0;
    zT_23 = 0;
    zT_11 = inner;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt), (unsigned char)((unsigned char)zT_19), (unsigned int)((unsigned int)zT_21), (unsigned int)((unsigned int)zT_23), zT_11, (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29));
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* parserParseReturnExpr */
zT_3B6EA323_EU_01 zF_224C1394_parserParseReturnEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    int zT_15;
    int zT_20;
    int zT_25;
    zT_B559F9DA_Parser* zT_30;
    zT_3B6EA323_EU_01 zT_33 = {0};
    unsigned char zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned short zT_38;
    unsigned int zT_40;
    int zT_41;
    zT_3A355BD2_Token zT_43;
    unsigned int zT_44;
    unsigned short zT_45;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_61;
    int zT_64;
    int zT_66;
    int zT_68;
    unsigned int zT_70 = 0;
    zT_3B6EA323_EU_01 zT_71;
    zT_3A355BD2_Token kw;
    unsigned int expr;
    zT_EAC3E484_TokenKind nt;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    expr = zT_6;
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    nt = zT_10;
    if ((int)(nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_3;
    z_bb_2:
    zT_15 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_15) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_6;
    z_bb_5:
    zT_20 = 0;
    goto z_bb_6;
    z_bb_6:
    if (zT_20) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_9;
    z_bb_8:
    zT_25 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_25) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_30 = self;
    zT_33 = zF_F07C1F04_parserParseExprPrec(zT_30, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = kw.span_start;
    zT_38 = kw.span_len;
    zT_40 = zT_37 + (unsigned int)((unsigned int)zT_38);
    end_pos = zT_40;
    zT_41 = self->last_tok_valid;
    if (zT_41) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_33;
    z_bb_13:
    zT_35 = zT_33.data.payload;
    goto z_bb_14;
    z_bb_14:
    expr = zT_35;
    goto z_bb_11;
    z_bb_15:
    zT_43 = self->last_tok;
    last = zT_43;
    zT_44 = last.span_start;
    zT_45 = last.span_len;
    zT_47 = zT_44 + (unsigned int)((unsigned int)zT_45);
    end_pos = zT_47;
    goto z_bb_16;
    z_bb_16:
    zT_48 = self->store;
    zT_61 = 0;
    zT_51 = kw.span_start;
    zT_52 = end_pos;
    zT_53 = expr;
    zT_64 = 0;
    zT_66 = 0;
    zT_68 = 0;
    zT_70 = zF_6C9FF72F_astStoreAddNode(zT_48, (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt), (unsigned char)((unsigned char)zT_61), zT_51, zT_52, zT_53, (unsigned int)((unsigned int)zT_64), (unsigned int)((unsigned int)zT_66), (unsigned int)((unsigned int)zT_68));
    zT_71.data.payload = zT_70;
    zT_71.is_error = 0;
    return zT_71;
}

/* parserParseBreakExpr */
zT_3B6EA323_EU_01 zF_C69B6287_parserParseBreakExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_17;
    zT_CB78802F_EU_49 zT_22 = {0};
    unsigned char zT_23;
    int zT_24;
    zT_3B6EA323_EU_01 zT_25;
    zT_2B3424E9_ParseToken zT_26;
    zT_2B3424E9_ParseToken zT_28;
    zT_EAC3E484_TokenKind zT_29;
    unsigned int zT_30;
    unsigned short zT_31;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_B559F9DA_Parser* zT_35;
    zT_2B3424E9_ParseToken zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    unsigned int zT_38 = 0;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_43;
    int zT_44;
    zT_3A355BD2_Token zT_46;
    unsigned int zT_47;
    unsigned short zT_48;
    unsigned int zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_59;
    int zT_64;
    int zT_67;
    int zT_69;
    int zT_71;
    unsigned int zT_73 = 0;
    zT_3B6EA323_EU_01 zT_74;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_2B3424E9_ParseToken pt;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((int)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    (void)zT_15;
    zT_17 = self;
    zT_22 = zF_5578C74F_parserExpect(zT_17, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_40 = kw.span_start;
    zT_41 = kw.span_len;
    zT_43 = zT_40 + (unsigned int)((unsigned int)zT_41);
    end_pos = zT_43;
    zT_44 = self->last_tok_valid;
    if (zT_44) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_24 = zT_22.data.err;
    zT_25.data.err = zT_24;
    zT_25.is_error = 1;
    return zT_25;
    z_bb_4:
    zT_26 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_26;
    zT_29 = label_tok.kind;
    zT_28.kind = zT_29;
    zT_30 = label_tok.span_start;
    zT_28.span_start = zT_30;
    zT_31 = label_tok.span_len;
    zT_28.span_len = zT_31;
    pt = zT_28;
    zT_32 = self->interner;
    zT_35 = self;
    zT_36 = pt;
    zT_37 = zF_08D61E58_parserTokenText(zT_35, zT_36);
    zT_33 = zT_37;
    zT_38 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    label_id = zT_38;
    goto z_bb_2;
    z_bb_6:
    zT_46 = self->last_tok;
    last = zT_46;
    zT_47 = last.span_start;
    zT_48 = last.span_len;
    zT_50 = zT_47 + (unsigned int)((unsigned int)zT_48);
    end_pos = zT_50;
    goto z_bb_7;
    z_bb_7:
    zT_51 = self->store;
    zT_64 = 0;
    zT_54 = kw.span_start;
    zT_55 = end_pos;
    zT_67 = 0;
    zT_69 = 0;
    zT_71 = 0;
    zT_59 = label_id;
    zT_73 = zF_6C9FF72F_astStoreAddNode(zT_51, (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt), (unsigned char)((unsigned char)zT_64), zT_54, zT_55, (unsigned int)((unsigned int)zT_67), (unsigned int)((unsigned int)zT_69), (unsigned int)((unsigned int)zT_71), zT_59);
    zT_74.data.payload = zT_73;
    zT_74.is_error = 0;
    return zT_74;
}

/* parserParseContinueExpr */
zT_3B6EA323_EU_01 zF_73B42F4B_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_17;
    zT_CB78802F_EU_49 zT_22 = {0};
    unsigned char zT_23;
    int zT_24;
    zT_3B6EA323_EU_01 zT_25;
    zT_2B3424E9_ParseToken zT_26;
    zT_2B3424E9_ParseToken zT_28;
    zT_EAC3E484_TokenKind zT_29;
    unsigned int zT_30;
    unsigned short zT_31;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_B559F9DA_Parser* zT_35;
    zT_2B3424E9_ParseToken zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    unsigned int zT_38 = 0;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_43;
    int zT_44;
    zT_3A355BD2_Token zT_46;
    unsigned int zT_47;
    unsigned short zT_48;
    unsigned int zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_59;
    int zT_64;
    int zT_67;
    int zT_69;
    int zT_71;
    unsigned int zT_73 = 0;
    zT_3B6EA323_EU_01 zT_74;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_2B3424E9_ParseToken pt;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((int)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    (void)zT_15;
    zT_17 = self;
    zT_22 = zF_5578C74F_parserExpect(zT_17, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_40 = kw.span_start;
    zT_41 = kw.span_len;
    zT_43 = zT_40 + (unsigned int)((unsigned int)zT_41);
    end_pos = zT_43;
    zT_44 = self->last_tok_valid;
    if (zT_44) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_24 = zT_22.data.err;
    zT_25.data.err = zT_24;
    zT_25.is_error = 1;
    return zT_25;
    z_bb_4:
    zT_26 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_26;
    zT_29 = label_tok.kind;
    zT_28.kind = zT_29;
    zT_30 = label_tok.span_start;
    zT_28.span_start = zT_30;
    zT_31 = label_tok.span_len;
    zT_28.span_len = zT_31;
    pt = zT_28;
    zT_32 = self->interner;
    zT_35 = self;
    zT_36 = pt;
    zT_37 = zF_08D61E58_parserTokenText(zT_35, zT_36);
    zT_33 = zT_37;
    zT_38 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    label_id = zT_38;
    goto z_bb_2;
    z_bb_6:
    zT_46 = self->last_tok;
    last = zT_46;
    zT_47 = last.span_start;
    zT_48 = last.span_len;
    zT_50 = zT_47 + (unsigned int)((unsigned int)zT_48);
    end_pos = zT_50;
    goto z_bb_7;
    z_bb_7:
    zT_51 = self->store;
    zT_64 = 0;
    zT_54 = kw.span_start;
    zT_55 = end_pos;
    zT_67 = 0;
    zT_69 = 0;
    zT_71 = 0;
    zT_59 = label_id;
    zT_73 = zF_6C9FF72F_astStoreAddNode(zT_51, (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt), (unsigned char)((unsigned char)zT_64), zT_54, zT_55, (unsigned int)((unsigned int)zT_67), (unsigned int)((unsigned int)zT_69), (unsigned int)((unsigned int)zT_71), zT_59);
    zT_74.data.payload = zT_73;
    zT_74.is_error = 0;
    return zT_74;
}

/* parserParseReturnStmt */
zT_3B6EA323_EU_01 zF_76F5B9F1_parserParseReturnSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_11 = {0};
    unsigned char zT_12;
    int zT_13;
    zT_3B6EA323_EU_01 zT_14;
    zT_2B3424E9_ParseToken zT_15;
    zT_3B6EA323_EU_01 zT_16;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_224C1394_parserParseReturnEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_11 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_13 = zT_11.data.err;
    zT_14.data.err = zT_13;
    zT_14.is_error = 1;
    return zT_14;
    z_bb_5:
    zT_15 = zT_11.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_15;
    zT_16.data.payload = node;
    zT_16.is_error = 0;
    return zT_16;
}

/* parserParseBreakStmt */
zT_3B6EA323_EU_01 zF_6DA396FE_parserParseBreakStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_11 = {0};
    unsigned char zT_12;
    int zT_13;
    zT_3B6EA323_EU_01 zT_14;
    zT_2B3424E9_ParseToken zT_15;
    zT_3B6EA323_EU_01 zT_16;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_C69B6287_parserParseBreakExp(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_11 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_13 = zT_11.data.err;
    zT_14.data.err = zT_13;
    zT_14.is_error = 1;
    return zT_14;
    z_bb_5:
    zT_15 = zT_11.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_15;
    zT_16.data.payload = node;
    zT_16.is_error = 0;
    return zT_16;
}

/* parserParseContinueStmt */
zT_3B6EA323_EU_01 zF_E13A9822_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_11 = {0};
    unsigned char zT_12;
    int zT_13;
    zT_3B6EA323_EU_01 zT_14;
    zT_2B3424E9_ParseToken zT_15;
    zT_3B6EA323_EU_01 zT_16;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_73B42F4B_parserParseContinue(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_11 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_13 = zT_11.data.err;
    zT_14.data.err = zT_13;
    zT_14.is_error = 1;
    return zT_14;
    z_bb_5:
    zT_15 = zT_11.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_15;
    zT_16.data.payload = node;
    zT_16.is_error = 0;
    return zT_16;
}

/* parserParseDeferStmt */
zT_3B6EA323_EU_01 zF_3B25AFD5_parserParseDeferStm(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_12;
    zT_3A355BD2_Token zT_14;
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_3B6EA323_EU_01 zT_39;
    zT_3A355BD2_Token kw;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    kw = zT_4;
    zT_6 = self;
    zT_7 = zF_462FC60E_parserParseStatemen(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    body = zT_9;
    zT_11 = kw.span_start;
    end_pos = zT_11;
    zT_12 = self->last_tok_valid;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = self->last_tok;
    last = zT_14;
    zT_15 = last.span_start;
    zT_16 = last.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end_pos = zT_18;
    goto z_bb_5;
    z_bb_5:
    zT_19 = self->store;
    zT_20 = kind;
    zT_29 = 0;
    zT_22 = kw.span_start;
    zT_23 = end_pos;
    zT_24 = body;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_19, zT_20, (unsigned char)((unsigned char)zT_29), zT_22, zT_23, zT_24, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    zT_39.data.payload = zT_38;
    zT_39.is_error = 0;
    return zT_39;
}

/* parserParseErrdeferStmt */
zT_3B6EA323_EU_01 zF_6C2E50E6_parserParseErrdefer(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3B6EA323_EU_01 zT_6 = {0};
    zT_1 = self;
    zT_6 = zF_3B25AFD5_parserParseDeferStm(zT_1, (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt));
    return zT_6;
}

/* parserParseTestDecl */
zT_3B6EA323_EU_01 zF_15A196A5_parserParseTestDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    zT_2B3424E9_ParseToken zT_18;
    zT_EAC3E484_TokenKind zT_19;
    unsigned int zT_20;
    unsigned short zT_21;
    zT_D3EB6303_StringInterner* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_B559F9DA_Parser* zT_25;
    zT_2B3424E9_ParseToken zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27 = {0};
    unsigned int zT_28 = 0;
    zT_B559F9DA_Parser* zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_35 = 0;
    int zT_36;
    zT_3A355BD2_Token zT_38;
    unsigned int zT_39;
    unsigned short zT_40;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_52;
    int zT_57;
    int zT_60;
    int zT_62;
    unsigned int zT_64 = 0;
    zT_3B6EA323_EU_01 zT_65;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_3A355BD2_Token name_tok;
    zT_2B3424E9_ParseToken npt;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    name_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((int)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = self;
    zT_16 = zF_C241B2C4_parserAdvance(zT_15);
    name_tok = zT_16;
    zT_19 = name_tok.kind;
    zT_18.kind = zT_19;
    zT_20 = name_tok.span_start;
    zT_18.span_start = zT_20;
    zT_21 = name_tok.span_len;
    zT_18.span_len = zT_21;
    npt = zT_18;
    zT_22 = self->interner;
    zT_25 = self;
    zT_26 = npt;
    zT_27 = zF_08D61E58_parserTokenText(zT_25, zT_26);
    zT_23 = zT_27;
    zT_28 = zF_50C274AF_stringInternerInter(zT_22, zT_23);
    name_id = zT_28;
    goto z_bb_2;
    z_bb_2:
    zT_30 = self;
    zT_31 = zF_365CA04A_parserParseBlock(zT_30);
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return zT_31;
    z_bb_4:
    zT_33 = zT_31.data.payload;
    goto z_bb_5;
    z_bb_5:
    body = zT_33;
    end_pos = zT_35;
    zT_36 = self->last_tok_valid;
    if (zT_36) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_38 = self->last_tok;
    last = zT_38;
    zT_39 = last.span_start;
    zT_40 = last.span_len;
    zT_42 = zT_39 + (unsigned int)((unsigned int)zT_40);
    end_pos = zT_42;
    goto z_bb_7;
    z_bb_7:
    zT_44 = self->store;
    zT_57 = 0;
    zT_47 = tok.span_start;
    zT_48 = end_pos;
    zT_49 = body;
    zT_60 = 0;
    zT_62 = 0;
    zT_52 = name_id;
    zT_64 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_test_decl), (unsigned char)((unsigned char)zT_57), zT_47, zT_48, zT_49, (unsigned int)((unsigned int)zT_60), (unsigned int)((unsigned int)zT_62), zT_52);
    zT_65.data.payload = zT_64;
    zT_65.is_error = 0;
    return zT_65;
    z_bb_8:
    zT_43 = tok.span_start;
    end_pos = zT_43;
    goto z_bb_7;
}

/* parserParseContainerDecl */
zT_3B6EA323_EU_01 zF_0A0E9C6C_parserParseContaine(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_18;
    zT_B559F9DA_Parser* zT_19;
    zT_3A355BD2_Token zT_20 = {0};
    zT_EAC3E484_TokenKind zT_21;
    zT_B559F9DA_Parser* zT_26;
    zT_3A355BD2_Token zT_27 = {0};
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_33 = {0};
    unsigned char zT_34;
    int zT_35;
    zT_3B6EA323_EU_01 zT_36;
    zT_2B3424E9_ParseToken zT_37;
    zT_B559F9DA_Parser* zT_38;
    zT_CB78802F_EU_49 zT_43 = {0};
    unsigned char zT_44;
    int zT_45;
    zT_3B6EA323_EU_01 zT_46;
    zT_2B3424E9_ParseToken zT_47;
    int zT_48;
    unsigned char zT_49;
    int zT_54;
    zT_B559F9DA_Parser* zT_55;
    zT_3A355BD2_Token zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_B559F9DA_Parser* zT_64;
    zT_3B6EA323_EU_01 zT_65 = {0};
    unsigned char zT_66;
    unsigned int zT_67;
    zT_B559F9DA_Parser* zT_68;
    zT_CB78802F_EU_49 zT_73 = {0};
    unsigned char zT_74;
    int zT_75;
    zT_3B6EA323_EU_01 zT_76;
    zT_2B3424E9_ParseToken zT_77;
    zT_B559F9DA_Parser* zT_78;
    zT_3A355BD2_Token zT_79 = {0};
    zT_EAC3E484_TokenKind zT_80;
    zT_B559F9DA_Parser* zT_86;
    zT_3A355BD2_Token zT_87 = {0};
    zT_2B3424E9_ParseToken zT_89;
    zT_EAC3E484_TokenKind zT_90;
    unsigned int zT_91;
    unsigned short zT_92;
    zT_D3EB6303_StringInterner* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_B559F9DA_Parser* zT_96;
    zT_2B3424E9_ParseToken zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98 = {0};
    unsigned int zT_99 = 0;
    zT_B559F9DA_Parser* zT_100;
    zT_CB78802F_EU_49 zT_105 = {0};
    unsigned char zT_106;
    int zT_107;
    zT_3B6EA323_EU_01 zT_108;
    zT_2B3424E9_ParseToken zT_109;
    unsigned int* zT_111 = 0;
    int zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    zT_B559F9DA_Parser* zT_117;
    zT_3A355BD2_Token zT_118 = {0};
    zT_EAC3E484_TokenKind zT_119;
    zT_B559F9DA_Parser* zT_125;
    zT_CB78802F_EU_49 zT_130 = {0};
    unsigned char zT_131;
    int zT_132;
    zT_3B6EA323_EU_01 zT_133;
    zT_2B3424E9_ParseToken zT_134;
    zT_2B3424E9_ParseToken zT_136;
    zT_EAC3E484_TokenKind zT_137;
    unsigned int zT_138;
    unsigned short zT_139;
    zT_D3EB6303_StringInterner* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    zT_B559F9DA_Parser* zT_144;
    zT_2B3424E9_ParseToken zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146 = {0};
    unsigned int zT_147 = 0;
    int zT_153;
    unsigned int zT_154;
    zT_B559F9DA_Parser* zT_155;
    zT_3A355BD2_Token zT_156 = {0};
    zT_EAC3E484_TokenKind zT_157;
    zT_B559F9DA_Parser* zT_162;
    zT_3A355BD2_Token zT_163 = {0};
    zT_B559F9DA_Parser* zT_164;
    zT_3B6EA323_EU_01 zT_167 = {0};
    unsigned char zT_168;
    unsigned int zT_169;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_174;
    unsigned int zT_177;
    unsigned int zT_179;
    int zT_184;
    unsigned int zT_187;
    unsigned short zT_188;
    int zT_191;
    int zT_193;
    unsigned int zT_195 = 0;
    zT_B559F9DA_Parser* zT_196;
    unsigned int** zT_197;
    unsigned int* zT_198;
    unsigned int* zT_199;
    unsigned int zT_200;
    zT_B559F9DA_Parser* zT_204;
    zT_CB78802F_EU_49 zT_209 = {0};
    unsigned char zT_210;
    int zT_211;
    zT_3B6EA323_EU_01 zT_212;
    zT_2B3424E9_ParseToken zT_213;
    zT_B559F9DA_Parser* zT_215;
    zT_3B6EA323_EU_01 zT_216 = {0};
    unsigned char zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_223;
    unsigned int zT_225;
    unsigned int zT_228;
    int zT_233;
    unsigned int zT_236;
    unsigned short zT_237;
    int zT_240;
    int zT_242;
    unsigned int zT_244 = 0;
    zT_B559F9DA_Parser* zT_245;
    unsigned int** zT_246;
    unsigned int* zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    zT_B559F9DA_Parser* zT_253;
    zT_3A355BD2_Token zT_254 = {0};
    zT_EAC3E484_TokenKind zT_255;
    zT_B559F9DA_Parser* zT_260;
    zT_3A355BD2_Token zT_261 = {0};
    zT_B559F9DA_Parser* zT_263;
    zT_CB78802F_EU_49 zT_268 = {0};
    unsigned char zT_269;
    int zT_270;
    zT_3B6EA323_EU_01 zT_271;
    zT_2B3424E9_ParseToken zT_272;
    int zT_274;
    unsigned int zT_275;
    int zT_276;
    zT_6B0A7D14_AstStore* zT_278;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_279;
    int zT_281;
    unsigned int* zT_282;
    unsigned int zT_283;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_284;
    unsigned int zT_285 = 0;
    unsigned int zT_287;
    unsigned short zT_288;
    unsigned int zT_290;
    zT_6B0A7D14_AstStore* zT_291;
    zT_8143F551_AstKind zT_292;
    unsigned char zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    unsigned int zT_299;
    int zT_302;
    unsigned int zT_304 = 0;
    zT_3B6EA323_EU_01 zT_305;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    unsigned char is_tagged;
    unsigned int backing_type;
    zT_3A355BD2_Token name_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken ftok;
    zT_2B3424E9_ParseToken rbrace;
    zT_2B3424E9_ParseToken fpt;
    unsigned int fid;
    unsigned int ev;
    unsigned int enode;
    unsigned int ftype;
    unsigned int fnode;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    name_id = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    backing_type = zT_13;
    if ((int)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self;
    zT_20 = zF_068A2DE5_parserPeek(zT_19);
    zT_21 = zT_20.kind;
    zT_18 = zT_21 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_3;
    z_bb_2:
    zT_18 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_26 = self;
    zT_27 = zF_C241B2C4_parserAdvance(zT_26);
    (void)zT_27;
    zT_28 = self;
    zT_33 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    if ((int)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_12; else goto z_bb_13;
    z_bb_6:
    zT_35 = zT_33.data.err;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_7:
    zT_37 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_37;
    zT_38 = self;
    zT_43 = zF_5578C74F_parserExpect(zT_38, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_44 = zT_43.is_error;
    if (zT_44) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_45 = zT_43.data.err;
    zT_46.data.err = zT_45;
    zT_46.is_error = 1;
    return zT_46;
    z_bb_10:
    zT_47 = zT_43.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_47;
    zT_48 = 1;
    zT_49 = (unsigned char)zT_48;
    is_tagged = zT_49;
    goto z_bb_5;
    z_bb_12:
    zT_55 = self;
    zT_56 = zF_068A2DE5_parserPeek(zT_55);
    zT_57 = zT_56.kind;
    zT_54 = zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_14;
    z_bb_13:
    zT_54 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_54) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    zT_64 = self;
    zT_65 = zF_CBDBFE85_parserParseType(zT_64);
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_78 = self;
    zT_79 = zF_068A2DE5_parserPeek(zT_78);
    zT_80 = zT_79.kind;
    if ((int)(zT_80 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_17:
    return zT_65;
    z_bb_18:
    zT_67 = zT_65.data.payload;
    goto z_bb_19;
    z_bb_19:
    backing_type = zT_67;
    zT_68 = self;
    zT_73 = zF_5578C74F_parserExpect(zT_68, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_74 = zT_73.is_error;
    if (zT_74) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_75 = zT_73.data.err;
    zT_76.data.err = zT_75;
    zT_76.is_error = 1;
    return zT_76;
    z_bb_21:
    zT_77 = zT_73.data.payload;
    goto z_bb_22;
    z_bb_22:
    (void)zT_77;
    goto z_bb_16;
    z_bb_23:
    zT_86 = self;
    zT_87 = zF_C241B2C4_parserAdvance(zT_86);
    name_tok = zT_87;
    zT_90 = name_tok.kind;
    zT_89.kind = zT_90;
    zT_91 = name_tok.span_start;
    zT_89.span_start = zT_91;
    zT_92 = name_tok.span_len;
    zT_89.span_len = zT_92;
    pt = zT_89;
    zT_93 = self->interner;
    zT_96 = self;
    zT_97 = pt;
    zT_98 = zF_08D61E58_parserTokenText(zT_96, zT_97);
    zT_94 = zT_98;
    zT_99 = zF_50C274AF_stringInternerInter(zT_93, zT_94);
    name_id = zT_99;
    goto z_bb_24;
    z_bb_24:
    zT_100 = self;
    zT_105 = zF_5578C74F_parserExpect(zT_100, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_106 = zT_105.is_error;
    if (zT_106) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_107 = zT_105.data.err;
    zT_108.data.err = zT_107;
    zT_108.is_error = 1;
    return zT_108;
    z_bb_26:
    zT_109 = zT_105.data.payload;
    goto z_bb_27;
    z_bb_27:
    (void)zT_109;
    fields_buf = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fields_count = zT_114;
    zT_116 = 0;
    fields_cap = zT_116;
    goto z_bb_28;
    z_bb_28:
    zT_117 = self;
    zT_118 = zF_068A2DE5_parserPeek(zT_117);
    zT_119 = zT_118.kind;
    if ((int)(zT_119 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_125 = self;
    zT_130 = zF_5578C74F_parserExpect(zT_125, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_131 = zT_130.is_error;
    if (zT_131) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    zT_263 = self;
    zT_268 = zF_5578C74F_parserExpect(zT_263, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_269 = zT_268.is_error;
    if (zT_269) goto z_bb_51; else goto z_bb_52;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_132 = zT_130.data.err;
    zT_133.data.err = zT_132;
    zT_133.is_error = 1;
    return zT_133;
    z_bb_33:
    zT_134 = zT_130.data.payload;
    goto z_bb_34;
    z_bb_34:
    ftok = zT_134;
    zT_137 = ftok.kind;
    zT_136.kind = zT_137;
    zT_138 = ftok.span_start;
    zT_136.span_start = zT_138;
    zT_139 = ftok.span_len;
    zT_136.span_len = zT_139;
    fpt = zT_136;
    zT_141 = self->interner;
    zT_144 = self;
    zT_145 = fpt;
    zT_146 = zF_08D61E58_parserTokenText(zT_144, zT_145);
    zT_142 = zT_146;
    zT_147 = zF_50C274AF_stringInternerInter(zT_141, zT_142);
    fid = zT_147;
    if ((int)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_153 = 0;
    zT_154 = (unsigned int)zT_153;
    ev = zT_154;
    zT_155 = self;
    zT_156 = zF_068A2DE5_parserPeek(zT_155);
    zT_157 = zT_156.kind;
    if ((int)(zT_157 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    zT_253 = self;
    zT_254 = zF_068A2DE5_parserPeek(zT_253);
    zT_255 = zT_254.kind;
    if ((int)(zT_255 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_49; else goto z_bb_50;
    z_bb_37:
    zT_204 = self;
    zT_209 = zF_5578C74F_parserExpect(zT_204, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_210 = zT_209.is_error;
    if (zT_210) goto z_bb_43; else goto z_bb_44;
    z_bb_38:
    zT_162 = self;
    zT_163 = zF_C241B2C4_parserAdvance(zT_162);
    (void)zT_163;
    zT_164 = self;
    zT_167 = zF_F07C1F04_parserParseExprPrec(zT_164, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_168 = zT_167.is_error;
    if (zT_168) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_171 = self->store;
    zT_184 = 0;
    zT_174 = ftok.span_start;
    zT_187 = ftok.span_start;
    zT_188 = ftok.span_len;
    zT_191 = 0;
    zT_177 = ev;
    zT_193 = 0;
    zT_179 = fid;
    zT_195 = zF_6C9FF72F_astStoreAddNode(zT_171, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_184), zT_174, (unsigned int)(zT_187 + (unsigned int)((unsigned int)zT_188)), (unsigned int)((unsigned int)zT_191), zT_177, (unsigned int)((unsigned int)zT_193), zT_179);
    enode = zT_195;
    zT_196 = self;
    zT_197 = &fields_buf;
    zT_198 = &fields_count;
    zT_199 = &fields_cap;
    zT_200 = enode;
    zF_0F1462F8_parserPushU32(zT_196, zT_197, zT_198, zT_199, zT_200);
    goto z_bb_36;
    z_bb_40:
    return zT_167;
    z_bb_41:
    zT_169 = zT_167.data.payload;
    goto z_bb_42;
    z_bb_42:
    ev = zT_169;
    goto z_bb_39;
    z_bb_43:
    zT_211 = zT_209.data.err;
    zT_212.data.err = zT_211;
    zT_212.is_error = 1;
    return zT_212;
    z_bb_44:
    zT_213 = zT_209.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_213;
    zT_215 = self;
    zT_216 = zF_CBDBFE85_parserParseType(zT_215);
    zT_217 = zT_216.is_error;
    if (zT_217) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return zT_216;
    z_bb_47:
    zT_218 = zT_216.data.payload;
    goto z_bb_48;
    z_bb_48:
    ftype = zT_218;
    zT_220 = self->store;
    zT_233 = 0;
    zT_223 = ftok.span_start;
    zT_236 = ftok.span_start;
    zT_237 = ftok.span_len;
    zT_225 = ftype;
    zT_240 = 0;
    zT_242 = 0;
    zT_228 = fid;
    zT_244 = zF_6C9FF72F_astStoreAddNode(zT_220, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_233), zT_223, (unsigned int)(zT_236 + (unsigned int)((unsigned int)zT_237)), zT_225, (unsigned int)((unsigned int)zT_240), (unsigned int)((unsigned int)zT_242), zT_228);
    fnode = zT_244;
    zT_245 = self;
    zT_246 = &fields_buf;
    zT_247 = &fields_count;
    zT_248 = &fields_cap;
    zT_249 = fnode;
    zF_0F1462F8_parserPushU32(zT_245, zT_246, zT_247, zT_248, zT_249);
    goto z_bb_36;
    z_bb_49:
    zT_260 = self;
    zT_261 = zF_C241B2C4_parserAdvance(zT_260);
    (void)zT_261;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_31;
    z_bb_51:
    zT_270 = zT_268.data.err;
    zT_271.data.err = zT_270;
    zT_271.is_error = 1;
    return zT_271;
    z_bb_52:
    zT_272 = zT_268.data.payload;
    goto z_bb_53;
    z_bb_53:
    rbrace = zT_272;
    zT_274 = 0;
    zT_275 = (unsigned int)zT_274;
    payload = zT_275;
    zT_276 = 0;
    if ((int)(fields_count > (unsigned int)zT_276)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_278 = self->store;
    zT_281 = 0;
    zT_282 = fields_buf + zT_281;
    zT_283 = fields_count - zT_281;
    zT_284.ptr = zT_282;
    zT_284.len = zT_283;
    zT_279 = zT_284;
    zT_285 = zF_583E993C_astStoreAddExtraChi(zT_278, zT_279);
    payload = zT_285;
    goto z_bb_55;
    z_bb_55:
    zT_287 = rbrace.span_start;
    zT_288 = rbrace.span_len;
    zT_290 = zT_287 + (unsigned int)((unsigned int)zT_288);
    end_pos = zT_290;
    zT_291 = self->store;
    zT_292 = kind;
    zT_293 = is_tagged;
    zT_294 = tok.span_start;
    zT_295 = end_pos;
    zT_296 = name_id;
    zT_297 = backing_type;
    zT_302 = 0;
    zT_299 = payload;
    zT_304 = zF_6C9FF72F_astStoreAddNode(zT_291, zT_292, zT_293, zT_294, zT_295, zT_296, zT_297, (unsigned int)((unsigned int)zT_302), zT_299);
    zT_305.data.payload = zT_304;
    zT_305.is_error = 0;
    return zT_305;
}

/* parserParseBlock */
zT_3B6EA323_EU_01 zF_365CA04A_parserParseBlock(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_7 = {0};
    unsigned char zT_8;
    int zT_9;
    zT_3B6EA323_EU_01 zT_10;
    zT_2B3424E9_ParseToken zT_11;
    unsigned int zT_13;
    zT_993A6923_Arr_unsigned_int_64 zT_15;
    unsigned int zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    int zT_25;
    zT_B559F9DA_Parser* zT_26;
    zT_3A355BD2_Token zT_27 = {0};
    zT_EAC3E484_TokenKind zT_28;
    zT_B559F9DA_Parser* zT_34;
    zT_3B6EA323_EU_01 zT_35 = {0};
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned int zT_40;
    unsigned int zT_44;
    unsigned int** zT_47;
    unsigned int* zT_48;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_50;
    unsigned int zT_51;
    unsigned int zT_58;
    unsigned int** zT_59;
    unsigned int* zT_60;
    unsigned int* zT_61;
    zT_3E40CD83_Sand* zT_62;
    unsigned int zT_63;
    unsigned int zT_69;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_EAC3E484_TokenKind zT_86;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_97 = {0};
    zT_8143F551_AstKind zT_98;
    zT_EAC3E484_TokenKind zT_100;
    int zT_105;
    zT_EAC3E484_TokenKind zT_106;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_B559F9DA_Parser* zT_133;
    zT_CB78802F_EU_49 zT_138 = {0};
    unsigned char zT_139;
    int zT_140;
    zT_3B6EA323_EU_01 zT_141;
    zT_2B3424E9_ParseToken zT_142;
    int zT_144;
    unsigned int zT_145;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_149 = {0};
    int zT_154;
    unsigned int* zT_155;
    unsigned int zT_156;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_157;
    unsigned int* zT_158;
    unsigned int* zT_160;
    unsigned int zT_161;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_162;
    zT_6B0A7D14_AstStore* zT_163;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_164;
    unsigned int zT_166 = 0;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184 = 0;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_202;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212 = 0;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned char* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    zT_6B0A7D14_AstStore* zT_229;
    unsigned int zT_232;
    unsigned int zT_237;
    int zT_242;
    unsigned int zT_245;
    unsigned short zT_246;
    int zT_249;
    int zT_251;
    int zT_253;
    unsigned int zT_255 = 0;
    zT_3B6EA323_EU_01 zT_256;
    zT_2B3424E9_ParseToken lbrace;
    unsigned int saved_len;
    zT_993A6923_Arr_unsigned_int_64 local_buf;
    unsigned int local_len;
    unsigned int stmt;
    zT_2B3424E9_ParseToken rbrace;
    zT_3A355BD2_Token pk;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_km;
    unsigned int fi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_lm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_pm;
    unsigned int payload;
    zT_3CB0179A_Slice_zT_05F374B1_u slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_m;
    zT_5A26C2ED_Arr_unsigned_char_1 plen_lb;
    unsigned int plen_ll;
    unsigned int plen_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 plen_pb;
    unsigned int plen_pl;
    unsigned int plen_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_nl;
    zT_2 = self;
    zT_7 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = zT_7.data.err;
    zT_10.data.err = zT_9;
    zT_10.is_error = 1;
    return zT_10;
    z_bb_2:
    zT_11 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    lbrace = zT_11;
    zT_13 = self->child_buf_len;
    saved_len = zT_13;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        local_buf[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = 0;
    local_len = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_18 = self;
    zT_19 = zF_068A2DE5_parserPeek(zT_18);
    zT_20 = zT_19.kind;
    if ((int)(zT_20 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_34 = self;
    zT_35 = zF_462FC60E_parserParseStatemen(zT_34);
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_133 = self;
    zT_138 = zF_5578C74F_parserExpect(zT_133, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_139 = zT_138.is_error;
    if (zT_139) goto z_bb_28; else goto z_bb_29;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_26 = self;
    zT_27 = zF_068A2DE5_parserPeek(zT_26);
    zT_28 = zT_27.kind;
    zT_25 = zT_28 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_10;
    z_bb_9:
    zT_25 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    return zT_35;
    z_bb_12:
    zT_37 = zT_35.data.payload;
    goto z_bb_13;
    z_bb_13:
    stmt = zT_37;
    if ((int)(local_len < (unsigned int)(64))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_40 = (unsigned int)local_len;
    local_buf[zT_40] = stmt;
    goto z_bb_15;
    z_bb_15:
    zT_69 = local_len + (unsigned int)(1);
    local_len = zT_69;
    zT_71 = self;
    zT_72 = zF_068A2DE5_parserPeek(zT_71);
    pk = zT_72;
    zT_74 = "PBX:S";
    zT_76 = 5;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    pbx_sm = zT_75;
    zT_77 = pbx_sm;
    zF_C914CB83_markerWriteInt(zT_77, (unsigned int)((unsigned int)local_len));
    zT_81 = "PBX:T";
    zT_83 = 5;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    pbx_tm = zT_82;
    zT_84 = pbx_tm;
    zT_86 = pk.kind;
    zF_C914CB83_markerWriteInt(zT_84, (unsigned int)((unsigned int)zT_86));
    zT_89 = "PBX:K";
    zT_91 = 5;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    pbx_km = zT_90;
    zT_92 = pbx_km;
    zT_94 = self->store;
    zT_95 = stmt;
    zT_97 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    zT_98 = zT_97.kind;
    zF_C914CB83_markerWriteInt(zT_92, (unsigned int)((unsigned int)zT_98));
    zT_100 = pk.kind;
    if ((int)(zT_100 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_24; else goto z_bb_23;
    z_bb_16:
    if ((int)(local_len == (unsigned int)(64))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_44 = 0;
    fi = zT_44;
    goto z_bb_19;
    z_bb_18:
    zT_59 = &self->child_buf_items;
    zT_60 = &self->child_buf_len;
    zT_61 = &self->child_buf_capacity;
    zT_62 = self->allocator;
    zT_63 = stmt;
    zF_8B163A32_u32ArrayListAppendI(zT_59, zT_60, zT_61, zT_62, zT_63);
    goto z_bb_15;
    z_bb_19:
    if ((int)(fi < (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_47 = &self->child_buf_items;
    zT_48 = &self->child_buf_len;
    zT_49 = &self->child_buf_capacity;
    zT_50 = self->allocator;
    zT_51 = local_buf[fi];
    zF_8B163A32_u32ArrayListAppendI(zT_47, zT_48, zT_49, zT_50, zT_51);
    goto z_bb_22;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_58 = fi + (unsigned int)(1);
    fi = zT_58;
    goto z_bb_19;
    z_bb_23:
    zT_106 = pk.kind;
    zT_105 = zT_106 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_25;
    z_bb_24:
    zT_105 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_105) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_112 = "PBX:L";
    zT_114 = 5;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    pbx_lm = zT_113;
    zT_115 = pbx_lm;
    zF_C914CB83_markerWriteInt(zT_115, (unsigned int)((unsigned int)local_len));
    zT_119 = "PBX:B";
    zT_121 = 5;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    pbx_bm = zT_120;
    zT_122 = pbx_bm;
    zF_C914CB83_markerWriteInt(zT_122, (unsigned int)((unsigned int)saved_len));
    zT_126 = "PBX:P";
    zT_128 = 5;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    pbx_pm = zT_127;
    zT_129 = pbx_pm;
    zT_130 = lbrace.span_start;
    zF_C914CB83_markerWriteInt(zT_129, zT_130);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_7;
    z_bb_28:
    zT_140 = zT_138.data.err;
    zT_141.data.err = zT_140;
    zT_141.is_error = 1;
    return zT_141;
    z_bb_29:
    zT_142 = zT_138.data.payload;
    goto z_bb_30;
    z_bb_30:
    rbrace = zT_142;
    zT_144 = 0;
    zT_145 = (unsigned int)zT_144;
    payload = zT_145;
    if ((int)(local_len > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    slice = zT_149;
    if ((int)(local_len <= (unsigned int)(64))) goto z_bb_33; else goto z_bb_35;
    z_bb_32:
    self->child_buf_len = saved_len;
    zT_168 = "PLEN:l";
    zT_170 = 6;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    plen_m = zT_169;
    zT_171 = plen_m;
    zF_48AC7B3A_markerWrite(zT_171);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_173[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        plen_lb[_i] = zT_173[_i];
        _i++;
    }
}
    zT_180 = 0;
    zT_181 = (unsigned char*)((unsigned char*)plen_lb) + zT_180;
    zT_182 = (unsigned int)(10) - zT_180;
    zT_183.ptr = zT_181;
    zT_183.len = zT_182;
    zT_176 = zT_183;
    zT_184 = zF_A7504564_itoa((unsigned int)((unsigned int)local_len), zT_176);
    plen_ll = zT_184;
    zT_188 = (unsigned int)(9) - (unsigned int)((unsigned int)plen_ll);
    plen_ls = zT_188;
    zT_193 = (unsigned char*)((unsigned char*)plen_lb) + plen_ls;
    zT_194 = (unsigned int)(9) - plen_ls;
    zT_195.ptr = zT_193;
    zT_195.len = zT_194;
    zT_189 = zT_195;
    zF_48AC7B3A_markerWrite(zT_189);
    zT_197 = "p";
    zT_199 = 1;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    plen_pm = zT_198;
    zT_200 = plen_pm;
    zF_48AC7B3A_markerWrite(zT_200);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_202[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        plen_pb[_i] = zT_202[_i];
        _i++;
    }
}
    zT_204 = payload;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)plen_pb) + zT_208;
    zT_210 = (unsigned int)(10) - zT_208;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_205 = zT_211;
    zT_212 = zF_A7504564_itoa(zT_204, zT_205);
    plen_pl = zT_212;
    zT_216 = (unsigned int)(9) - (unsigned int)((unsigned int)plen_pl);
    plen_ps = zT_216;
    zT_221 = (unsigned char*)((unsigned char*)plen_pb) + plen_ps;
    zT_222 = (unsigned int)(9) - plen_ps;
    zT_223.ptr = zT_221;
    zT_223.len = zT_222;
    zT_217 = zT_223;
    zF_48AC7B3A_markerWrite(zT_217);
    zT_225 = "\n";
    zT_227 = 1;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    plen_nl = zT_226;
    zT_228 = plen_nl;
    zF_48AC7B3A_markerWrite(zT_228);
    zT_229 = self->store;
    zT_242 = 0;
    zT_232 = lbrace.span_start;
    zT_245 = rbrace.span_start;
    zT_246 = rbrace.span_len;
    zT_249 = 0;
    zT_251 = 0;
    zT_253 = 0;
    zT_237 = payload;
    zT_255 = zF_6C9FF72F_astStoreAddNode(zT_229, (zT_8143F551_AstKind)(zT_8143F551_AstKind_block), (unsigned char)((unsigned char)zT_242), zT_232, (unsigned int)(zT_245 + (unsigned int)((unsigned int)zT_246)), (unsigned int)((unsigned int)zT_249), (unsigned int)((unsigned int)zT_251), (unsigned int)((unsigned int)zT_253), zT_237);
    zT_256.data.payload = zT_255;
    zT_256.is_error = 0;
    return zT_256;
    z_bb_33:
    zT_154 = 0;
    zT_155 = (unsigned int*)((unsigned int*)local_buf) + zT_154;
    zT_156 = local_len - zT_154;
    zT_157.ptr = zT_155;
    zT_157.len = zT_156;
    slice = zT_157;
    goto z_bb_34;
    z_bb_34:
    zT_163 = self->store;
    zT_164 = slice;
    zT_166 = zF_583E993C_astStoreAddExtraChi(zT_163, zT_164);
    payload = zT_166;
    goto z_bb_32;
    z_bb_35:
    zT_158 = self->child_buf_items;
    zT_160 = zT_158 + saved_len;
    zT_161 = (unsigned int)(saved_len + local_len) - saved_len;
    zT_162.ptr = zT_160;
    zT_162.len = zT_161;
    slice = zT_162;
    goto z_bb_34;
}

/* precToInt */
unsigned char zF_F312BDA3_precToInt(zT_2B10107F_Prec p) {
    return (unsigned char)((unsigned char)p);
}

/* precFromInt */
zT_2B10107F_Prec zF_860100DC_precFromInt(unsigned char v) {
    return (zT_2B10107F_Prec)((zT_2B10107F_Prec)v);
}

/* getInfixInfo */
zT_ADDA7CFF_Opt_97 zF_1E2936C3_getInfixInfo(zT_EAC3E484_TokenKind kind) {
    int zT_5;
    int zT_10;
    int zT_15;
    int zT_20;
    int zT_25;
    int zT_30;
    int zT_35;
    int zT_40;
    int zT_45;
    int zT_50;
    int zT_55;
    int zT_60;
    int zT_65;
    int zT_70;
    int zT_75;
    int zT_80;
    int zT_85;
    zT_F4EBEA72_OpInfo zT_90;
    zT_2B10107F_Prec zT_91;
    int zT_92;
    zT_ADDA7CFF_Opt_97 zT_93;
    zT_F4EBEA72_OpInfo zT_98;
    zT_2B10107F_Prec zT_99;
    int zT_100;
    zT_ADDA7CFF_Opt_97 zT_101;
    zT_F4EBEA72_OpInfo zT_106;
    zT_2B10107F_Prec zT_107;
    int zT_108;
    zT_ADDA7CFF_Opt_97 zT_109;
    zT_F4EBEA72_OpInfo zT_114;
    zT_2B10107F_Prec zT_115;
    int zT_116;
    zT_ADDA7CFF_Opt_97 zT_117;
    zT_F4EBEA72_OpInfo zT_122;
    zT_2B10107F_Prec zT_123;
    int zT_124;
    zT_ADDA7CFF_Opt_97 zT_125;
    int zT_130;
    int zT_135;
    int zT_140;
    int zT_145;
    int zT_150;
    zT_F4EBEA72_OpInfo zT_155;
    zT_2B10107F_Prec zT_156;
    int zT_157;
    zT_ADDA7CFF_Opt_97 zT_158;
    zT_F4EBEA72_OpInfo zT_163;
    zT_2B10107F_Prec zT_164;
    int zT_165;
    zT_ADDA7CFF_Opt_97 zT_166;
    zT_F4EBEA72_OpInfo zT_171;
    zT_2B10107F_Prec zT_172;
    int zT_173;
    zT_ADDA7CFF_Opt_97 zT_174;
    zT_F4EBEA72_OpInfo zT_179;
    zT_2B10107F_Prec zT_180;
    int zT_181;
    zT_ADDA7CFF_Opt_97 zT_182;
    int zT_187;
    int zT_192;
    zT_F4EBEA72_OpInfo zT_197;
    zT_2B10107F_Prec zT_198;
    int zT_199;
    zT_ADDA7CFF_Opt_97 zT_200;
    int zT_205;
    int zT_210;
    int zT_215;
    int zT_220;
    int zT_225;
    zT_F4EBEA72_OpInfo zT_230;
    zT_2B10107F_Prec zT_231;
    int zT_232;
    zT_ADDA7CFF_Opt_97 zT_233;
    int zT_238;
    int zT_243;
    int zT_248;
    int zT_253;
    zT_F4EBEA72_OpInfo zT_258;
    zT_2B10107F_Prec zT_259;
    int zT_260;
    zT_ADDA7CFF_Opt_97 zT_261;
    zT_ADDA7CFF_Opt_97 zT_262 = {0};
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_10 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq);
    goto z_bb_6;
    z_bb_5:
    zT_10 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_10) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_15 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq);
    goto z_bb_9;
    z_bb_8:
    zT_15 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_15) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_20 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq);
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_25 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq);
    goto z_bb_15;
    z_bb_14:
    zT_25 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_25) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_30 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq);
    goto z_bb_18;
    z_bb_17:
    zT_30 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_30) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_35 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq);
    goto z_bb_21;
    z_bb_20:
    zT_35 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_35) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_40 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq);
    goto z_bb_24;
    z_bb_23:
    zT_40 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_40) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_45 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq);
    goto z_bb_27;
    z_bb_26:
    zT_45 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_45) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_50 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq);
    goto z_bb_30;
    z_bb_29:
    zT_50 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_50) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_55 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq);
    goto z_bb_33;
    z_bb_32:
    zT_55 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_55) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_60 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq);
    goto z_bb_36;
    z_bb_35:
    zT_60 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_60) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_65 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq);
    goto z_bb_39;
    z_bb_38:
    zT_65 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_65) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_70 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq);
    goto z_bb_42;
    z_bb_41:
    zT_70 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_70) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_75 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq);
    goto z_bb_45;
    z_bb_44:
    zT_75 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_75) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_80 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq);
    goto z_bb_48;
    z_bb_47:
    zT_80 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_80) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_85 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq);
    goto z_bb_51;
    z_bb_50:
    zT_85 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_85) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_91 = zT_2B10107F_Prec_assignment;
    zT_90.prec = zT_91;
    zT_92 = 1;
    zT_90.right_assoc = zT_92;
    zT_93.has_value = 1;
    zT_93.value = zT_90;
    return zT_93;
    z_bb_53:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_99 = zT_2B10107F_Prec_prec_orelse;
    zT_98.prec = zT_99;
    zT_100 = 1;
    zT_98.right_assoc = zT_100;
    zT_101.has_value = 1;
    zT_101.value = zT_98;
    return zT_101;
    z_bb_55:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_107 = zT_2B10107F_Prec_prec_catch;
    zT_106.prec = zT_107;
    zT_108 = 1;
    zT_106.right_assoc = zT_108;
    zT_109.has_value = 1;
    zT_109.value = zT_106;
    return zT_109;
    z_bb_57:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_or))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_115 = zT_2B10107F_Prec_bool_or;
    zT_114.prec = zT_115;
    zT_116 = 0;
    zT_114.right_assoc = zT_116;
    zT_117.has_value = 1;
    zT_117.value = zT_114;
    return zT_117;
    z_bb_59:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_and))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_123 = zT_2B10107F_Prec_bool_and;
    zT_122.prec = zT_123;
    zT_124 = 0;
    zT_122.right_assoc = zT_124;
    zT_125.has_value = 1;
    zT_125.value = zT_122;
    return zT_125;
    z_bb_61:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq))) goto z_bb_63; else goto z_bb_62;
    z_bb_62:
    zT_130 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq);
    goto z_bb_64;
    z_bb_63:
    zT_130 = 1;
    goto z_bb_64;
    z_bb_64:
    if (zT_130) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_135 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less);
    goto z_bb_67;
    z_bb_66:
    zT_135 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_135) goto z_bb_69; else goto z_bb_68;
    z_bb_68:
    zT_140 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq);
    goto z_bb_70;
    z_bb_69:
    zT_140 = 1;
    goto z_bb_70;
    z_bb_70:
    if (zT_140) goto z_bb_72; else goto z_bb_71;
    z_bb_71:
    zT_145 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater);
    goto z_bb_73;
    z_bb_72:
    zT_145 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_145) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_150 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq);
    goto z_bb_76;
    z_bb_75:
    zT_150 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_150) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_156 = zT_2B10107F_Prec_comparison;
    zT_155.prec = zT_156;
    zT_157 = 0;
    zT_155.right_assoc = zT_157;
    zT_158.has_value = 1;
    zT_158.value = zT_155;
    return zT_158;
    z_bb_78:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_164 = zT_2B10107F_Prec_bit_or;
    zT_163.prec = zT_164;
    zT_165 = 0;
    zT_163.right_assoc = zT_165;
    zT_166.has_value = 1;
    zT_166.value = zT_163;
    return zT_166;
    z_bb_80:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_172 = zT_2B10107F_Prec_bit_xor;
    zT_171.prec = zT_172;
    zT_173 = 0;
    zT_171.right_assoc = zT_173;
    zT_174.has_value = 1;
    zT_174.value = zT_171;
    return zT_174;
    z_bb_82:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_180 = zT_2B10107F_Prec_bit_and;
    zT_179.prec = zT_180;
    zT_181 = 0;
    zT_179.right_assoc = zT_181;
    zT_182.has_value = 1;
    zT_182.value = zT_179;
    return zT_182;
    z_bb_84:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_187 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr);
    goto z_bb_87;
    z_bb_86:
    zT_187 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_187) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_192 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe);
    goto z_bb_90;
    z_bb_89:
    zT_192 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_192) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_198 = zT_2B10107F_Prec_shift;
    zT_197.prec = zT_198;
    zT_199 = 0;
    zT_197.right_assoc = zT_199;
    zT_200.has_value = 1;
    zT_200.value = zT_197;
    return zT_200;
    z_bb_92:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus))) goto z_bb_94; else goto z_bb_93;
    z_bb_93:
    zT_205 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus);
    goto z_bb_95;
    z_bb_94:
    zT_205 = 1;
    goto z_bb_95;
    z_bb_95:
    if (zT_205) goto z_bb_97; else goto z_bb_96;
    z_bb_96:
    zT_210 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct);
    goto z_bb_98;
    z_bb_97:
    zT_210 = 1;
    goto z_bb_98;
    z_bb_98:
    if (zT_210) goto z_bb_100; else goto z_bb_99;
    z_bb_99:
    zT_215 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct);
    goto z_bb_101;
    z_bb_100:
    zT_215 = 1;
    goto z_bb_101;
    z_bb_101:
    if (zT_215) goto z_bb_103; else goto z_bb_102;
    z_bb_102:
    zT_220 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe);
    goto z_bb_104;
    z_bb_103:
    zT_220 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_220) goto z_bb_106; else goto z_bb_105;
    z_bb_105:
    zT_225 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe);
    goto z_bb_107;
    z_bb_106:
    zT_225 = 1;
    goto z_bb_107;
    z_bb_107:
    if (zT_225) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_231 = zT_2B10107F_Prec_additive;
    zT_230.prec = zT_231;
    zT_232 = 0;
    zT_230.right_assoc = zT_232;
    zT_233.has_value = 1;
    zT_233.value = zT_230;
    return zT_233;
    z_bb_109:
    if ((int)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_111; else goto z_bb_110;
    z_bb_110:
    zT_238 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash);
    goto z_bb_112;
    z_bb_111:
    zT_238 = 1;
    goto z_bb_112;
    z_bb_112:
    if (zT_238) goto z_bb_114; else goto z_bb_113;
    z_bb_113:
    zT_243 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent);
    goto z_bb_115;
    z_bb_114:
    zT_243 = 1;
    goto z_bb_115;
    z_bb_115:
    if (zT_243) goto z_bb_117; else goto z_bb_116;
    z_bb_116:
    zT_248 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct);
    goto z_bb_118;
    z_bb_117:
    zT_248 = 1;
    goto z_bb_118;
    z_bb_118:
    if (zT_248) goto z_bb_120; else goto z_bb_119;
    z_bb_119:
    zT_253 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe);
    goto z_bb_121;
    z_bb_120:
    zT_253 = 1;
    goto z_bb_121;
    z_bb_121:
    if (zT_253) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_259 = zT_2B10107F_Prec_multiply;
    zT_258.prec = zT_259;
    zT_260 = 0;
    zT_258.right_assoc = zT_260;
    zT_261.has_value = 1;
    zT_261.value = zT_258;
    return zT_261;
    z_bb_123:
    zT_262.has_value = 0;
    return zT_262;
}

/* __module_init */
void zF_780653D2___module_init_7(void) {
    zT_F85C5DED_DiagnosticCollector zT_0 = {0};
    zT_072B53A6_ModuleRegistry zT_1 = {0};
    zG_F85C5DED_DiagnosticCollector = zT_0;
    zG_072B53A6_ModuleRegistry = zT_1;
    return;
}

/* EOF */
