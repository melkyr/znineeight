#include "parser_61A67AF1.h"
#include <stdio.h>
/* parserInitCommon */
zT_B559F9DA_Parser zF_EDAEEEE9_parserInitCommon(zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc, unsigned int builtin_import_id) {
    zT_3A355BD2_Token zT_7;
    zT_EAC3E484_TokenKind zT_9;
    unsigned int zT_10;
    unsigned short zT_11;
    zT_85CBA4DB_TokenValue zT_12 = {0};
    zT_B559F9DA_Parser zT_14;
    unsigned char zT_15;
    int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char* zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_31;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_6F32B01B_Opt_235 zT_37 = {0};
    zT_713074AA_Opt_247 zT_38 = {0};
    unsigned int zT_39;
    unsigned int zT_40;
    zT_3A355BD2_Token zero_tok;
    zT_9 = zT_EAC3E484_TokenKind_eof;
    zT_7.kind = zT_9;
    zT_10 = 0;
    zT_7.span_start = zT_10;
    zT_11 = 0;
    zT_7.span_len = zT_11;
    zT_7.value = zT_12;
    zero_tok = zT_7;
    zT_15 = 0;
    zT_14.use_lex = zT_15;
    zT_16 = 0;
    zT_14.lex = (zT_138FFB41_Lexer*)zT_16;
    zT_17 = 0;
    zT_14.tokens_ptr = (zT_3A355BD2_Token*)zT_17;
    zT_18 = 0;
    zT_14.tokens_len = zT_18;
    zT_20 = source.ptr;
    zT_21 = (unsigned char*)zT_20;
    zT_14.source_ptr = zT_21;
    zT_23 = source.len;
    zT_14.source_len = zT_23;
    zT_24 = 0;
    zT_14.pos = zT_24;
    zT_25 = 0;
    zT_14.la_len = zT_25;
    zT_26 = 0;
    zT_14.at_eof = zT_26;
    zT_14.eof_tok = zero_tok;
    zT_14.store = store;
    zT_14.interner = interner;
    zT_14.diag = diag;
    zT_14.allocator = alloc;
    zT_27 = 0;
    zT_14.child_buf_items = (unsigned int*)zT_27;
    zT_28 = 0;
    zT_14.child_buf_len = zT_28;
    zT_29 = 0;
    zT_14.child_buf_capacity = zT_29;
    zT_30 = 0;
    zT_14.last_end = zT_30;
    zT_14.last_tok = zero_tok;
    zT_31 = 0;
    zT_14.last_tok_valid = zT_31;
    zT_32 = 0;
    zT_14.decl_buf_items = (unsigned int*)zT_32;
    zT_33 = 0;
    zT_14.decl_buf_len = zT_33;
    zT_34 = 0;
    zT_14.decl_buf_capacity = zT_34;
    zT_35 = 0;
    zT_14.catch_capture = zT_35;
    zT_36 = 0;
    zT_14.expr_depth = zT_36;
    zT_14.builtin_import_id = builtin_import_id;
    zT_37.has_value = 0;
    zT_14.module_reg = zT_37;
    zT_38.has_value = 0;
    zT_14.import_scratch = zT_38;
    zT_39 = 0;
    zT_14.current_module_id = zT_39;
    zT_40 = 0;
    zT_14.file_id = zT_40;
    return zT_14;
}

/* parserInit */
zT_B559F9DA_Parser zF_74A05BF0_parserInit(zT_F020719E_Slice_zT_3A355BD2_T tokens, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3A355BD2_Token* zT_8;
    zT_3A355BD2_Token* zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    zT_D3EB6303_StringInterner* zT_21;
    zT_F85C5DED_DiagnosticCollector* zT_22;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    zT_B559F9DA_Parser zT_25 = {0};
    unsigned int zT_28;
    zT_3A355BD2_Token* t_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_8 = tokens.ptr;
    zT_9 = (zT_3A355BD2_Token*)zT_8;
    t_ptr = zT_9;
    zT_11 = "@import";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    import_s = zT_12;
    zT_15 = interner;
    zT_16 = import_s;
    zT_17 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    import_id = zT_17;
    zT_19 = source;
    zT_20 = store;
    zT_21 = interner;
    zT_22 = diag;
    zT_23 = alloc;
    zT_24 = import_id;
    zT_25 = zF_EDAEEEE9_parserInitCommon(zT_19, zT_20, zT_21, zT_22, zT_23, zT_24);
    p = zT_25;
    p.use_lex = (unsigned char)(0);
    p.tokens_ptr = t_ptr;
    zT_28 = tokens.len;
    p.tokens_len = zT_28;
    return p;
}

/* parserInitStreaming */
zT_B559F9DA_Parser zF_9E9ED878_parserInitStreaming(zT_138FFB41_Lexer* lex, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_D3EB6303_StringInterner* zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser zT_21 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_7 = "@import";
    zT_9 = 7;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    import_s = zT_8;
    zT_11 = interner;
    zT_12 = import_s;
    zT_13 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    import_id = zT_13;
    zT_15 = source;
    zT_16 = store;
    zT_17 = interner;
    zT_18 = diag;
    zT_19 = alloc;
    zT_20 = import_id;
    zT_21 = zF_EDAEEEE9_parserInitCommon(zT_15, zT_16, zT_17, zT_18, zT_19, zT_20);
    p = zT_21;
    p.use_lex = (unsigned char)(1);
    p.lex = lex;
    return p;
}

/* parserSetModuleContext */
void zF_15960D31_parserSetModuleCont(zT_B559F9DA_Parser* self, zT_072B53A6_ModuleRegistry* reg, unsigned int mod_id) {
    zT_6F32B01B_Opt_235 zT_3;
    zT_E41AEC18_ModuleEntryArrayLis zT_4;
    zT_6E8D187B_ModuleEntry* zT_5;
    zT_6E8D187B_ModuleEntry zT_6;
    unsigned int zT_7;
    zT_3.has_value = 1;
    zT_3.value = reg;
    self->module_reg = zT_3;
    self->current_module_id = mod_id;
    zT_4 = reg->modules;
    zT_5 = zT_4.items;
    zT_6 = zT_5[mod_id];
    zT_7 = zT_6.source_file_id;
    self->file_id = zT_7;
    return;
}

/* parserSetImportScratch */
void zF_C8F08D73_parserSetImportScra(zT_B559F9DA_Parser* self, zT_3E40CD83_Sand* scratch) {
    zT_713074AA_Opt_247 zT_2;
    zT_2.has_value = 1;
    zT_2.value = scratch;
    self->import_scratch = zT_2;
    return;
}

/* parserTokenText */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08D61E58_parserTokenText(zT_B559F9DA_Parser* self, zT_2B3424E9_ParseToken tok) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned short zT_6;
    unsigned int zT_8;
    unsigned char* zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int start;
    unsigned int end;
    zT_3 = tok.span_start;
    zT_4 = (unsigned int)zT_3;
    start = zT_4;
    zT_6 = tok.span_len;
    zT_8 = start + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->source_ptr;
    zT_10 = zT_9 + start;
    zT_11 = end - start;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    return zT_12;
}

/* parserInternParseToken */
unsigned int zF_ED2167CA_parserInternParseTo(zT_B559F9DA_Parser* self, zT_2B3424E9_ParseToken pt) {
    zT_D3EB6303_StringInterner* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    zT_B559F9DA_Parser* zT_5;
    zT_2B3424E9_ParseToken zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_8 = 0;
    zT_2 = self->interner;
    zT_5 = self;
    zT_6 = pt;
    zT_7 = zF_08D61E58_parserTokenText(zT_5, zT_6);
    zT_3 = zT_7;
    zT_8 = zF_50C274AF_stringInternerInter(zT_2, zT_3);
    return zT_8;
}

/* parserInternTokenText */
unsigned int zF_9DDDA188_parserInternTokenTe(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok) {
    zT_2B3424E9_ParseToken zT_3;
    zT_EAC3E484_TokenKind zT_4;
    unsigned int zT_5;
    unsigned short zT_6;
    zT_D3EB6303_StringInterner* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_B559F9DA_Parser* zT_10;
    zT_2B3424E9_ParseToken zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12 = {0};
    unsigned int zT_13 = 0;
    zT_2B3424E9_ParseToken pt;
    zT_4 = tok.kind;
    zT_3.kind = zT_4;
    zT_5 = tok.span_start;
    zT_3.span_start = zT_5;
    zT_6 = tok.span_len;
    zT_3.span_len = zT_6;
    pt = zT_3;
    zT_7 = self->interner;
    zT_10 = self;
    zT_11 = pt;
    zT_12 = zF_08D61E58_parserTokenText(zT_10, zT_11);
    zT_8 = zT_12;
    zT_13 = zF_50C274AF_stringInternerInter(zT_7, zT_8);
    return zT_13;
}

/* parserPullOne */
void zF_7C3FD09B_parserPullOne(zT_B559F9DA_Parser* self) {
    unsigned char zT_1;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned char zT_4;
    zT_138FFB41_Lexer* zT_5;
    zT_3A355BD2_Token zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_3A355BD2_Token* zT_11;
    unsigned int zT_12;
    zT_3A355BD2_Token zT_13;
    unsigned int zT_14;
    int zT_15;
    zT_3A355BD2_Token* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    zT_3A355BD2_Token zT_22;
    zT_EAC3E484_TokenKind zT_23;
    zT_3A355BD2_Token* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_3A355BD2_Token tok;
    zT_1 = self->at_eof;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    tok = zT_3;
    zT_4 = self->use_lex;
    if (zT_4) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_5 = self->lex;
    zT_7 = zF_B976BEC9_lexerNextToken(zT_5);
    tok = zT_7;
    goto z_bb_4;
    z_bb_4:
    zT_23 = tok.kind;
    if ((unsigned char)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_9; else goto z_bb_10;
    z_bb_5:
    zT_8 = self->pos;
    zT_9 = self->tokens_len;
    if ((unsigned char)(zT_8 < zT_9)) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_11 = self->tokens_ptr;
    zT_12 = self->pos;
    zT_13 = zT_11[zT_12];
    tok = zT_13;
    zT_14 = self->pos;
    zT_15 = 1;
    self->pos = (unsigned int)(zT_14 + (unsigned int)((unsigned int)zT_15));
    goto z_bb_7;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = self->tokens_ptr;
    zT_19 = self->tokens_len;
    zT_20 = 1;
    zT_21 = zT_19 - zT_20;
    zT_22 = zT_18[zT_21];
    tok = zT_22;
    goto z_bb_7;
    z_bb_9:
    self->at_eof = (unsigned char)(1);
    self->eof_tok = tok;
    goto z_bb_10;
    z_bb_10:
    zT_28 = self->la;
    zT_29 = self->la_len;
    zT_28[zT_29] = tok;
    zT_30 = self->la_len;
    zT_31 = 1;
    self->la_len = (unsigned int)(zT_30 + (unsigned int)((unsigned int)zT_31));
    return;
}

/* parserConsumeCurrent */
void zF_2DCC9581_parserConsumeCurren(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    unsigned char zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3A355BD2_Token* zT_16;
    zT_3A355BD2_Token zT_17;
    zT_3A355BD2_Token* zT_18;
    int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    zT_B559F9DA_Parser* zT_28;
    unsigned int i;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    self->last_tok = zT_9;
    self->last_tok_valid = (unsigned char)(1);
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    i = zT_13;
    goto z_bb_5;
    z_bb_3:
    zT_5 = self->eof_tok;
    self->last_tok = zT_5;
    self->last_tok_valid = (unsigned char)(1);
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_14 = self->la_len;
    if ((unsigned char)(i < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_16 = self->la;
    zT_17 = zT_16[i];
    zT_18 = self->la;
    zT_19 = 1;
    zT_20 = i - zT_19;
    zT_18[zT_20] = zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_24 = self->la_len;
    zT_25 = 1;
    self->la_len = (unsigned int)(zT_24 - (unsigned int)((unsigned int)zT_25));
    zT_28 = self;
    zF_7C3FD09B_parserPullOne(zT_28);
    return;
    z_bb_8:
    zT_21 = 1;
    zT_23 = i + (unsigned int)((unsigned int)zT_21);
    i = zT_23;
    goto z_bb_5;
}

/* parserPeek */
zT_3A355BD2_Token zF_068A2DE5_parserPeek(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    unsigned char zT_4;
    zT_3A355BD2_Token zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    return zT_9;
    z_bb_3:
    zT_5 = self->eof_tok;
    return zT_5;
    z_bb_4:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_2;
}

/* parserPeekN */
zT_3A355BD2_Token zF_F685E431_parserPeekN(zT_B559F9DA_Parser* self, unsigned int n) {
    unsigned int zT_2;
    unsigned char zT_5;
    zT_B559F9DA_Parser* zT_6;
    unsigned int zT_7;
    zT_3A355BD2_Token* zT_10;
    zT_3A355BD2_Token zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_3A355BD2_Token* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_3A355BD2_Token zT_19;
    zT_3A355BD2_Token zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self->la_len;
    if ((unsigned char)(zT_2 <= (unsigned int)((unsigned int)n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self->at_eof;
    if (zT_5) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_7 = self->la_len;
    if ((unsigned char)(zT_7 > (unsigned int)((unsigned int)n))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_4;
    z_bb_7:
    zT_10 = self->la;
    zT_11 = zT_10[n];
    return zT_11;
    z_bb_8:
    zT_12 = self->la_len;
    zT_13 = 0;
    if ((unsigned char)(zT_12 > (unsigned int)zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = self->la;
    zT_16 = self->la_len;
    zT_17 = 1;
    zT_18 = zT_16 - zT_17;
    zT_19 = zT_15[zT_18];
    return zT_19;
    z_bb_10:
    zT_20 = self->eof_tok;
    return zT_20;
}

/* parserAdvance */
zT_3A355BD2_Token zF_C241B2C4_parserAdvance(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_4;
    unsigned short zT_5;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.span_start;
    zT_5 = tok.span_len;
    self->last_end = (unsigned int)(zT_4 + (unsigned int)((unsigned int)zT_5));
    zT_8 = self;
    zF_2DCC9581_parserConsumeCurren(zT_8);
    return tok;
}

/* tokenKindLabel */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_77B50062_tokenKindLabel(zT_EAC3E484_TokenKind kind) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    unsigned char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "';'";
    zT_7 = 3;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s = zT_6;
    return s;
    z_bb_2:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = "'('";
    zT_14 = 3;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    s = zT_13;
    return s;
    z_bb_4:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "')'";
    zT_21 = 3;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    s = zT_20;
    return s;
    z_bb_6:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = "'{'";
    zT_28 = 3;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s = zT_27;
    return s;
    z_bb_8:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = "'}'";
    zT_35 = 3;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s = zT_34;
    return s;
    z_bb_10:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_40 = "'['";
    zT_42 = 3;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    s = zT_41;
    return s;
    z_bb_12:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_47 = "']'";
    zT_49 = 3;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    s = zT_48;
    return s;
    z_bb_14:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = "','";
    zT_56 = 3;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s = zT_55;
    return s;
    z_bb_16:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_61 = "'.'";
    zT_63 = 3;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s = zT_62;
    return s;
    z_bb_18:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_68 = "':'";
    zT_70 = 3;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    s = zT_69;
    return s;
    z_bb_20:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_75 = "'|'";
    zT_77 = 3;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    s = zT_76;
    return s;
    z_bb_22:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_82 = "identifier";
    zT_84 = 10;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s = zT_83;
    return s;
    z_bb_24:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_89 = "string literal";
    zT_91 = 14;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    s = zT_90;
    return s;
    z_bb_26:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_96 = "integer literal";
    zT_98 = 15;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    s = zT_97;
    return s;
    z_bb_28:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_103 = "'fn'";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    s = zT_104;
    return s;
    z_bb_30:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_110 = "'while'";
    zT_112 = 7;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s = zT_111;
    return s;
    z_bb_32:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_117 = "'if'";
    zT_119 = 4;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    s = zT_118;
    return s;
    z_bb_34:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_124 = "'else'";
    zT_126 = 6;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    s = zT_125;
    return s;
    z_bb_36:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_131 = "'return'";
    zT_133 = 8;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    s = zT_132;
    return s;
    z_bb_38:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_138 = "'const'";
    zT_140 = 7;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    s = zT_139;
    return s;
    z_bb_40:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_145 = "'var'";
    zT_147 = 5;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    s = zT_146;
    return s;
    z_bb_42:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_152 = "'pub'";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    s = zT_153;
    return s;
    z_bb_44:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_159 = "'extern'";
    zT_161 = 8;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    s = zT_160;
    return s;
    z_bb_46:
    zT_163 = "token";
    zT_165 = 5;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    fallback = zT_164;
    return fallback;
}

/* parserExpect */
zT_CB78802F_EU_49 zF_5578C74F_parserExpect(zT_B559F9DA_Parser* self, zT_EAC3E484_TokenKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_EAC3E484_TokenKind zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13 = {0};
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_EAC3E484_TokenKind zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_4F2154A7_Arr_zT_8F083A69_Sli zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_30;
    zT_F85C5DED_DiagnosticCollector* zT_32;
    int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_DBF3575C_ParserError zT_41;
    zT_CB78802F_EU_49 zT_42;
    zT_B559F9DA_Parser* zT_43;
    zT_2B3424E9_ParseToken zT_44;
    zT_EAC3E484_TokenKind zT_45;
    unsigned int zT_46;
    unsigned short zT_47;
    zT_CB78802F_EU_49 zT_48;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_lab;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_lab;
    zT_4F2154A7_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    tok = zT_4;
    zT_5 = tok.kind;
    if ((unsigned char)(zT_5 != kind)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = "expected ";
    zT_10 = 9;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    exp_s = zT_9;
    zT_12 = kind;
    zT_13 = zF_77B50062_tokenKindLabel(zT_12);
    exp_lab = zT_13;
    zT_15 = " but found ";
    zT_17 = 11;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    fnd_s = zT_16;
    zT_19 = tok.kind;
    zT_21 = zF_77B50062_tokenKindLabel(zT_19);
    fnd_lab = zT_21;
    zT_24 = 0;
    zT_23[zT_24] = exp_s;
    zT_25 = 1;
    zT_23[zT_25] = exp_lab;
    zT_26 = 2;
    zT_23[zT_26] = fnd_s;
    zT_27 = 3;
    zT_23[zT_27] = fnd_lab;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        parts[_i] = zT_23[_i];
        _i++;
    }
}
    zT_32 = self->diag;
    zT_29 = zT_32->interner;
    zT_34 = 0;
    zT_35 = parts + zT_34;
    zT_30 = zT_35;
    zT_37 = zF_8C4BFF7C_diagnosticBuilderMa(zT_29, zT_30, (unsigned int)(4));
    msg = zT_37;
    zT_38 = self;
    zT_39 = tok;
    zT_40 = msg;
    zF_17DF2CA5_parserAddError(zT_38, zT_39, zT_40);
    zT_41 = 1;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_2:
    zT_43 = self;
    zF_2DCC9581_parserConsumeCurren(zT_43);
    zT_45 = tok.kind;
    zT_44.kind = zT_45;
    zT_46 = tok.span_start;
    zT_44.span_start = zT_46;
    zT_47 = tok.span_len;
    zT_44.span_len = zT_47;
    zT_48.data.payload = zT_44;
    zT_48.is_error = 0;
    return zT_48;
}

/* parserAddError */
void zF_17DF2CA5_parserAddError(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_3;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_3 = self->diag;
    zT_6 = self->file_id;
    zT_7 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_9 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_3, (unsigned char)(0), (unsigned short)(2000), zT_6, zT_7, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_9);
    return;
}

/* parserSynchronize */
void zF_4190C400_parserSynchronize(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned char zT_17;
    unsigned char zT_21;
    unsigned char zT_25;
    unsigned char zT_29;
    zT_B559F9DA_Parser* zT_33;
    zT_B559F9DA_Parser* zT_37;
    zT_EAC3E484_TokenKind k;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    k = zT_5;
    if ((unsigned char)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_9 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_7;
    z_bb_6:
    zT_9 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_13 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_13) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_17 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const);
    goto z_bb_13;
    z_bb_12:
    zT_17 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_17) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_21 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var);
    goto z_bb_16;
    z_bb_15:
    zT_21 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_21) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_25 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub);
    goto z_bb_19;
    z_bb_18:
    zT_25 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_25) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_29 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test);
    goto z_bb_22;
    z_bb_21:
    zT_29 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_29) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_33 = self;
    zF_2DCC9581_parserConsumeCurren(zT_33);
    return;
    z_bb_24:
    if ((unsigned char)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return;
    z_bb_26:
    zT_37 = self;
    zF_2DCC9581_parserConsumeCurren(zT_37);
    goto z_bb_4;
}

/* parserParseExprPrec */
zT_3B6EA323_EU_01 zF_F07C1F04_parserParseExprPrec(zT_B559F9DA_Parser* self, zT_2B10107F_Prec min_prec) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_6;
    int zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_13;
    unsigned int zT_14;
    char* zT_15;
    unsigned int zT_16;
    char* zT_17;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_21;
    zT_3B6EA323_EU_01 zT_22 = {0};
    unsigned char zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_28;
    zT_B559F9DA_Parser* zT_29;
    unsigned int zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    unsigned char zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41 = {0};
    int zT_43;
    unsigned char zT_44;
    zT_F4EBEA72_OpInfo zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_B2DA84DE_Opt_98 zT_49 = {0};
    unsigned char zT_50;
    int zT_52;
    unsigned char zT_53;
    int zT_54;
    zT_2B10107F_Prec zT_56;
    unsigned char zT_58 = 0;
    zT_2B10107F_Prec zT_59;
    unsigned char zT_60 = 0;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_2B10107F_Prec zT_65 = 0;
    unsigned char zT_66;
    zT_2B10107F_Prec zT_67;
    zT_2B10107F_Prec zT_69;
    unsigned char zT_71 = 0;
    int zT_72;
    zT_2B10107F_Prec zT_74 = 0;
    unsigned int zT_76 = 0;
    int zT_78;
    unsigned char zT_79;
    zT_EAC3E484_TokenKind zT_80;
    unsigned int zT_85;
    zT_B559F9DA_Parser* zT_86;
    zT_2B10107F_Prec zT_87;
    unsigned int* zT_88;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_96;
    unsigned int zT_98;
    unsigned short zT_99;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    int zT_114;
    int zT_117;
    unsigned int zT_119 = 0;
    int zT_120;
    unsigned char zT_121;
    zT_EAC3E484_TokenKind zT_122;
    zT_B559F9DA_Parser* zT_126;
    zT_2B10107F_Prec zT_127;
    zT_3B6EA323_EU_01 zT_128 = {0};
    unsigned char zT_129;
    unsigned int zT_130;
    int zT_131;
    unsigned int zT_134;
    zT_B559F9DA_Parser* zT_135;
    zT_2B10107F_Prec zT_136;
    zT_3B6EA323_EU_01 zT_137 = {0};
    unsigned char zT_138;
    unsigned int zT_139;
    int zT_140;
    unsigned int zT_143;
    int zT_144;
    zT_B559F9DA_Parser* zT_146;
    zT_3A355BD2_Token zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_3B6EA323_EU_01 zT_150 = {0};
    unsigned char zT_151;
    unsigned int zT_152;
    int zT_153;
    unsigned int zT_156;
    unsigned int zT_157;
    int zT_158;
    zT_3B6EA323_EU_01 zT_161;
    unsigned int zT_162;
    int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int lhs;
    zT_3A355BD2_Token tok;
    unsigned char has_info;
    zT_F4EBEA72_OpInfo info;
    zT_F4EBEA72_OpInfo val;
    zT_2B10107F_Prec next_min;
    unsigned int rhs;
    unsigned char catch_handled;
    unsigned int cap;
    unsigned int end;
    zT_2 = self->expr_depth;
    zT_3 = 1;
    self->expr_depth = (unsigned int)(zT_2 + (unsigned int)((unsigned int)zT_3));
    zT_6 = self->expr_depth;
    zT_7 = 12;
    if ((unsigned char)(zT_6 > (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = "max expression recursion depth exceeded";
    zT_12 = 39;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    msg = zT_11;
    zT_13 = "panic: ";
    zT_14 = 7;
    fwrite(zT_13, 1, zT_14, stderr);
    zT_15 = msg.ptr;
    zT_16 = msg.len;
    fwrite(zT_15, 1, zT_16, stderr);
    zT_17 = "\n";
    zT_18 = 1;
    fwrite(zT_17, 1, zT_18, stderr);
    pal_trap();
    z_bb_2:
    zT_21 = self;
    zT_22 = zF_565DCE21_parserParsePrimary(zT_21);
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = self->expr_depth;
    zT_25 = 1;
    self->expr_depth = (unsigned int)(zT_24 - (unsigned int)((unsigned int)zT_25));
    return zT_22;
    z_bb_4:
    zT_28 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    lhs = zT_28;
    zT_29 = self;
    zT_30 = lhs;
    zT_31 = zF_77AD89E7_parserParsePostfixC(zT_29, zT_30);
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_33 = self->expr_depth;
    zT_34 = 1;
    self->expr_depth = (unsigned int)(zT_33 - (unsigned int)((unsigned int)zT_34));
    return zT_31;
    z_bb_7:
    zT_37 = zT_31.data.payload;
    goto z_bb_8;
    z_bb_8:
    lhs = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(1)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = zF_068A2DE5_parserPeek(zT_40);
    tok = zT_41;
    zT_43 = 0;
    zT_44 = (unsigned char)zT_43;
    has_info = zT_44;
    info = zT_46;
    zT_47 = tok.kind;
    zT_49 = zF_1E2936C3_getInfixInfo(zT_47);
    zT_50 = zT_49.has_value;
    if (zT_50) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_157 = self->expr_depth;
    zT_158 = 1;
    self->expr_depth = (unsigned int)(zT_157 - (unsigned int)((unsigned int)zT_158));
    zT_161.data.payload = lhs;
    zT_161.is_error = 0;
    return zT_161;
    zT_162 = self->expr_depth;
    zT_163 = 1;
    self->expr_depth = (unsigned int)(zT_162 - (unsigned int)((unsigned int)zT_163));
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    val = zT_49.value;
    info = val;
    zT_52 = 1;
    zT_53 = (unsigned char)zT_52;
    has_info = zT_53;
    goto z_bb_14;
    z_bb_14:
    zT_54 = 0;
    if ((unsigned char)(has_info == zT_54)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_56 = info.prec;
    zT_58 = zF_F312BDA3_precToInt(zT_56);
    zT_59 = min_prec;
    zT_60 = zF_F312BDA3_precToInt(zT_59);
    if ((unsigned char)(zT_58 < zT_60)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_11;
    z_bb_18:
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    next_min = zT_65;
    zT_66 = info.right_assoc;
    if (zT_66) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_67 = info.prec;
    next_min = zT_67;
    goto z_bb_20;
    z_bb_20:
    rhs = zT_76;
    zT_78 = 0;
    zT_79 = (unsigned char)zT_78;
    catch_handled = zT_79;
    zT_80 = tok.kind;
    if ((unsigned char)(zT_80 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_22; else goto z_bb_24;
    z_bb_21:
    zT_69 = info.prec;
    zT_71 = zF_F312BDA3_precToInt(zT_69);
    zT_72 = 1;
    zT_74 = zF_860100DC_precFromInt((unsigned char)(zT_71 + zT_72));
    next_min = zT_74;
    goto z_bb_20;
    z_bb_22:
    zT_85 = 0;
    cap = zT_85;
    zT_86 = self;
    zT_87 = next_min;
    zT_88 = &cap;
    zT_90 = zF_95DDA8C7_parserParseCatchRHS(zT_86, zT_87, zT_88);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_144 = 0;
    if ((unsigned char)(catch_handled == zT_144)) goto z_bb_37; else goto z_bb_38;
    z_bb_24:
    zT_122 = tok.kind;
    if ((unsigned char)(zT_122 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_28; else goto z_bb_30;
    z_bb_25:
    zT_92 = self->expr_depth;
    zT_93 = 1;
    self->expr_depth = (unsigned int)(zT_92 - (unsigned int)((unsigned int)zT_93));
    return zT_90;
    z_bb_26:
    zT_96 = zT_90.data.payload;
    goto z_bb_27;
    z_bb_27:
    rhs = zT_96;
    zT_98 = tok.span_start;
    zT_99 = tok.span_len;
    zT_101 = zT_98 + (unsigned int)((unsigned int)zT_99);
    end = zT_101;
    zT_102 = self->store;
    zT_114 = 0;
    zT_105 = tok.span_start;
    zT_106 = end;
    zT_107 = lhs;
    zT_108 = rhs;
    zT_109 = cap;
    zT_117 = 0;
    zT_119 = zF_6C9FF72F_astStoreAddNode(zT_102, (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr), (unsigned char)((unsigned char)zT_114), zT_105, zT_106, zT_107, zT_108, zT_109, (unsigned int)((unsigned int)zT_117));
    lhs = zT_119;
    zT_120 = 1;
    zT_121 = (unsigned char)zT_120;
    catch_handled = zT_121;
    goto z_bb_23;
    z_bb_28:
    zT_126 = self;
    zT_127 = next_min;
    zT_128 = zF_A059028C_parserParseOrelseRH(zT_126, zT_127);
    zT_129 = zT_128.is_error;
    if (zT_129) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_135 = self;
    zT_136 = next_min;
    zT_137 = zF_F07C1F04_parserParseExprPrec(zT_135, zT_136);
    zT_138 = zT_137.is_error;
    if (zT_138) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_130 = self->expr_depth;
    zT_131 = 1;
    self->expr_depth = (unsigned int)(zT_130 - (unsigned int)((unsigned int)zT_131));
    return zT_128;
    z_bb_32:
    zT_134 = zT_128.data.payload;
    goto z_bb_33;
    z_bb_33:
    rhs = zT_134;
    goto z_bb_29;
    z_bb_34:
    zT_139 = self->expr_depth;
    zT_140 = 1;
    self->expr_depth = (unsigned int)(zT_139 - (unsigned int)((unsigned int)zT_140));
    return zT_137;
    z_bb_35:
    zT_143 = zT_137.data.payload;
    goto z_bb_36;
    z_bb_36:
    rhs = zT_143;
    goto z_bb_29;
    z_bb_37:
    zT_146 = self;
    zT_147 = tok;
    zT_148 = lhs;
    zT_149 = rhs;
    zT_150 = zF_E702AE30_parserAddBinary(zT_146, zT_147, zT_148, zT_149);
    zT_151 = zT_150.is_error;
    if (zT_151) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_12;
    z_bb_39:
    zT_152 = self->expr_depth;
    zT_153 = 1;
    self->expr_depth = (unsigned int)(zT_152 - (unsigned int)((unsigned int)zT_153));
    return zT_150;
    z_bb_40:
    zT_156 = zT_150.data.payload;
    goto z_bb_41;
    z_bb_41:
    lhs = zT_156;
    goto z_bb_38;
}

/* parserAddBinary */
zT_3B6EA323_EU_01 zF_E702AE30_parserAddBinary(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned int lhs, unsigned int rhs) {
    zT_8143F551_AstKind zT_6;
    int zT_8;
    unsigned char zT_9;
    zT_EAC3E484_TokenKind zT_10;
    zT_B2DA84DE_Opt_98 zT_12 = {0};
    unsigned char zT_13;
    zT_8143F551_AstKind zT_15;
    int zT_16;
    unsigned char zT_17;
    int zT_18;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_DBF3575C_ParserError zT_27;
    zT_3B6EA323_EU_01 zT_28;
    unsigned int zT_30;
    unsigned short zT_31;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    int zT_47;
    int zT_51;
    unsigned int zT_53 = 0;
    zT_3B6EA323_EU_01 zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_EAC3E484_TokenKind zT_61;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_6B0A7D14_AstStore* zT_70;
    zT_8143F551_AstKind zT_71;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    int zT_80;
    int zT_83;
    int zT_85;
    unsigned int zT_87 = 0;
    zT_3B6EA323_EU_01 zT_88;
    zT_8143F551_AstKind kind;
    unsigned char found;
    zT_F4EBEA72_OpInfo op;
    zT_8F083A69_Slice_zT_0B42B2F8_u add_msg;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u bok;
    zT_8F083A69_Slice_zT_0B42B2F8_u bokk;
    zT_6 = zT_8143F551_AstKind_err;
    kind = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned char)zT_8;
    found = zT_9;
    zT_10 = tok.kind;
    zT_12 = zF_1E2936C3_getInfixInfo(zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    op = zT_12.value;
    zT_15 = op.ast_kind;
    kind = zT_15;
    zT_16 = 1;
    zT_17 = (unsigned char)zT_16;
    found = zT_17;
    goto z_bb_2;
    z_bb_2:
    zT_18 = 0;
    if ((unsigned char)(found == zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = "invalid token in expression";
    zT_23 = 27;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    add_msg = zT_22;
    zT_24 = self;
    zT_25 = tok;
    zT_26 = add_msg;
    zF_17DF2CA5_parserAddError(zT_24, zT_25, zT_26);
    zT_27 = 1;
    zT_28.data.err = zT_27;
    zT_28.is_error = 1;
    return zT_28;
    z_bb_4:
    zT_30 = tok.span_start;
    zT_31 = tok.span_len;
    zT_33 = zT_30 + (unsigned int)((unsigned int)zT_31);
    end = zT_33;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_37 = self->store;
    zT_38 = kind;
    zT_47 = 0;
    zT_40 = tok.span_start;
    zT_41 = end;
    zT_42 = lhs;
    zT_43 = rhs;
    zT_44 = self->catch_capture;
    zT_51 = 0;
    zT_53 = zF_6C9FF72F_astStoreAddNode(zT_37, zT_38, (unsigned char)((unsigned char)zT_47), zT_40, zT_41, zT_42, zT_43, zT_44, (unsigned int)((unsigned int)zT_51));
    zT_54.data.payload = zT_53;
    zT_54.is_error = 0;
    return zT_54;
    z_bb_6:
    zT_56 = "BOP:tk";
    zT_58 = 6;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    bok = zT_57;
    zT_59 = bok;
    zT_61 = tok.kind;
    zF_C914CB83_markerWriteInt(zT_59, (unsigned int)((unsigned int)zT_61));
    zT_64 = "ak";
    zT_66 = 2;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    bokk = zT_65;
    zT_67 = bokk;
    zF_C914CB83_markerWriteInt(zT_67, (unsigned int)((unsigned int)kind));
    zT_70 = self->store;
    zT_71 = kind;
    zT_80 = 0;
    zT_73 = tok.span_start;
    zT_74 = end;
    zT_75 = lhs;
    zT_76 = rhs;
    zT_83 = 0;
    zT_85 = 0;
    zT_87 = zF_6C9FF72F_astStoreAddNode(zT_70, zT_71, (unsigned char)((unsigned char)zT_80), zT_73, zT_74, zT_75, zT_76, (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85));
    zT_88.data.payload = zT_87;
    zT_88.is_error = 0;
    return zT_88;
}

/* parserParsePrimary */
zT_3B6EA323_EU_01 zF_565DCE21_parserParsePrimary(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_27 = {0};
    zT_EAC3E484_TokenKind zT_28;
    zT_B559F9DA_Parser* zT_32;
    zT_3B6EA323_EU_01 zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    zT_3B6EA323_EU_01 zT_39 = {0};
    zT_EAC3E484_TokenKind zT_40;
    zT_B559F9DA_Parser* zT_44;
    zT_3B6EA323_EU_01 zT_48 = {0};
    zT_EAC3E484_TokenKind zT_49;
    zT_B559F9DA_Parser* zT_53;
    zT_3B6EA323_EU_01 zT_57 = {0};
    zT_EAC3E484_TokenKind zT_58;
    zT_B559F9DA_Parser* zT_62;
    zT_3B6EA323_EU_01 zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    zT_EAC3E484_TokenKind zT_73;
    zT_B559F9DA_Parser* zT_77;
    int zT_79;
    zT_3A355BD2_Token zT_81 = {0};
    zT_EAC3E484_TokenKind zT_82;
    unsigned char zT_86;
    zT_B559F9DA_Parser* zT_87;
    int zT_89;
    zT_3A355BD2_Token zT_91 = {0};
    zT_EAC3E484_TokenKind zT_92;
    zT_B559F9DA_Parser* zT_96;
    zT_3B6EA323_EU_01 zT_97 = {0};
    zT_B559F9DA_Parser* zT_98;
    int zT_100;
    zT_3A355BD2_Token zT_102 = {0};
    zT_EAC3E484_TokenKind zT_103;
    zT_B559F9DA_Parser* zT_108;
    zT_3B6EA323_EU_01 zT_109 = {0};
    unsigned char zT_110;
    unsigned int zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_3A355BD2_Token zT_113 = {0};
    zT_B559F9DA_Parser* zT_115;
    zT_3B6EA323_EU_01 zT_116 = {0};
    unsigned char zT_117;
    unsigned int zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    int zT_131;
    unsigned int zT_134;
    unsigned short zT_135;
    int zT_138;
    int zT_140;
    unsigned int zT_142 = 0;
    zT_3B6EA323_EU_01 zT_143;
    zT_B559F9DA_Parser* zT_144;
    zT_3B6EA323_EU_01 zT_145 = {0};
    zT_EAC3E484_TokenKind zT_146;
    zT_B559F9DA_Parser* zT_150;
    zT_3B6EA323_EU_01 zT_151 = {0};
    zT_EAC3E484_TokenKind zT_152;
    zT_B559F9DA_Parser* zT_156;
    zT_3B6EA323_EU_01 zT_157 = {0};
    zT_EAC3E484_TokenKind zT_158;
    zT_B559F9DA_Parser* zT_162;
    zT_3B6EA323_EU_01 zT_163 = {0};
    zT_EAC3E484_TokenKind zT_164;
    zT_B559F9DA_Parser* zT_168;
    zT_3B6EA323_EU_01 zT_169 = {0};
    zT_EAC3E484_TokenKind zT_170;
    zT_B559F9DA_Parser* zT_174;
    zT_3B6EA323_EU_01 zT_175 = {0};
    zT_EAC3E484_TokenKind zT_176;
    zT_B559F9DA_Parser* zT_180;
    zT_3B6EA323_EU_01 zT_181 = {0};
    zT_EAC3E484_TokenKind zT_182;
    zT_B559F9DA_Parser* zT_186;
    zT_3B6EA323_EU_01 zT_190 = {0};
    zT_EAC3E484_TokenKind zT_191;
    zT_B559F9DA_Parser* zT_195;
    zT_3B6EA323_EU_01 zT_199 = {0};
    zT_EAC3E484_TokenKind zT_200;
    zT_B559F9DA_Parser* zT_204;
    zT_3B6EA323_EU_01 zT_208 = {0};
    zT_EAC3E484_TokenKind zT_209;
    zT_B559F9DA_Parser* zT_213;
    zT_3B6EA323_EU_01 zT_217 = {0};
    zT_EAC3E484_TokenKind zT_218;
    zT_B559F9DA_Parser* zT_222;
    zT_3B6EA323_EU_01 zT_226 = {0};
    zT_EAC3E484_TokenKind zT_227;
    zT_B559F9DA_Parser* zT_231;
    zT_3B6EA323_EU_01 zT_232 = {0};
    zT_EAC3E484_TokenKind zT_233;
    zT_B559F9DA_Parser* zT_237;
    zT_3B6EA323_EU_01 zT_238 = {0};
    zT_EAC3E484_TokenKind zT_239;
    zT_B559F9DA_Parser* zT_243;
    zT_3B6EA323_EU_01 zT_244 = {0};
    zT_EAC3E484_TokenKind zT_245;
    zT_B559F9DA_Parser* zT_249;
    zT_3B6EA323_EU_01 zT_250 = {0};
    zT_EAC3E484_TokenKind zT_251;
    zT_B559F9DA_Parser* zT_255;
    zT_3B6EA323_EU_01 zT_256 = {0};
    zT_EAC3E484_TokenKind zT_257;
    zT_B559F9DA_Parser* zT_261;
    zT_3B6EA323_EU_01 zT_262 = {0};
    zT_EAC3E484_TokenKind zT_263;
    zT_B559F9DA_Parser* zT_267;
    zT_3B6EA323_EU_01 zT_268 = {0};
    zT_B559F9DA_Parser* zT_270;
    zT_1ED12478_EU_196 zT_271 = {0};
    unsigned char zT_272;
    int zT_273;
    zT_3B6EA323_EU_01 zT_274;
    zT_BAEE192E_Opt_10 zT_275;
    unsigned char zT_276;
    zT_3B6EA323_EU_01 zT_278;
    zT_EAC3E484_TokenKind zT_279;
    zT_B559F9DA_Parser* zT_283;
    zT_3B6EA323_EU_01 zT_284 = {0};
    zT_EAC3E484_TokenKind zT_285;
    zT_B559F9DA_Parser* zT_289;
    zT_3B6EA323_EU_01 zT_290 = {0};
    zT_EAC3E484_TokenKind zT_291;
    zT_B559F9DA_Parser* zT_295;
    zT_3B6EA323_EU_01 zT_296 = {0};
    zT_EAC3E484_TokenKind zT_297;
    zT_B559F9DA_Parser* zT_301;
    zT_3B6EA323_EU_01 zT_302 = {0};
    unsigned char* zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned int zT_306;
    zT_B559F9DA_Parser* zT_307;
    zT_3A355BD2_Token zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    zT_DBF3575C_ParserError zT_310;
    zT_3B6EA323_EU_01 zT_311;
    zT_3A355BD2_Token tok;
    unsigned int eu_base;
    unsigned int eu_payload;
    zT_BAEE192E_Opt_10 leading;
    unsigned int n;
    zT_8F083A69_Slice_zT_0B42B2F8_u primary_msg;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_4D06854D_parserParseIntLiter(zT_8);
    return zT_9;
    z_bb_2:
    zT_10 = tok.kind;
    if ((unsigned char)(zT_10 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zT_15 = zF_FB72DD9C_parserParseFloatLit(zT_14);
    return zT_15;
    z_bb_4:
    zT_16 = tok.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = self;
    zT_21 = zF_397D4BBF_parserParseStringLi(zT_20);
    return zT_21;
    z_bb_6:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self;
    zT_27 = zF_F509A7F4_parserParseCharLite(zT_26);
    return zT_27;
    z_bb_8:
    zT_28 = tok.kind;
    if ((unsigned char)(zT_28 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self;
    zT_33 = zF_0E221A14_parserParseBoolLite(zT_32);
    return zT_33;
    z_bb_10:
    zT_34 = tok.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_false))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = self;
    zT_39 = zF_0E221A14_parserParseBoolLite(zT_38);
    return zT_39;
    z_bb_12:
    zT_40 = tok.kind;
    if ((unsigned char)(zT_40 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_null))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_44 = self;
    zT_48 = zF_A18ECFB6_parserParseSingleTo(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal));
    return zT_48;
    z_bb_14:
    zT_49 = tok.kind;
    if ((unsigned char)(zT_49 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_undefined))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = self;
    zT_57 = zF_A18ECFB6_parserParseSingleTo(zT_53, (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal));
    return zT_57;
    z_bb_16:
    zT_58 = tok.kind;
    if ((unsigned char)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_unreachable))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_62 = self;
    zT_66 = zF_A18ECFB6_parserParseSingleTo(zT_62, (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr));
    return zT_66;
    z_bb_18:
    zT_67 = tok.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_71 = self;
    zT_72 = zF_F5EAD186_parserParseIdentExp(zT_71);
    return zT_72;
    z_bb_20:
    zT_73 = tok.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_77 = self;
    zT_79 = 1;
    zT_81 = zF_F685E431_parserPeekN(zT_77, (unsigned int)((unsigned int)zT_79));
    zT_82 = zT_81.kind;
    if ((unsigned char)(zT_82 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_146 = tok.kind;
    if ((unsigned char)(zT_146 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_bool))) goto z_bb_36; else goto z_bb_37;
    z_bb_23:
    zT_87 = self;
    zT_89 = 2;
    zT_91 = zF_F685E431_parserPeekN(zT_87, (unsigned int)((unsigned int)zT_89));
    zT_92 = zT_91.kind;
    zT_86 = zT_92 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_25;
    z_bb_24:
    zT_86 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_86) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_96 = self;
    zT_97 = zF_532B277E_parserParseLabeledB(zT_96);
    return zT_97;
    z_bb_27:
    zT_98 = self;
    zT_100 = 1;
    zT_102 = zF_F685E431_parserPeekN(zT_98, (unsigned int)((unsigned int)zT_100));
    zT_103 = zT_102.kind;
    if ((unsigned char)(zT_103 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_108 = self;
    zT_109 = zF_F5EAD186_parserParseIdentExp(zT_108);
    zT_110 = zT_109.is_error;
    if (zT_110) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_144 = self;
    zT_145 = zF_F5EAD186_parserParseIdentExp(zT_144);
    return zT_145;
    z_bb_30:
    return zT_109;
    z_bb_31:
    zT_111 = zT_109.data.payload;
    goto z_bb_32;
    z_bb_32:
    eu_base = zT_111;
    zT_112 = self;
    zT_113 = zF_C241B2C4_parserAdvance(zT_112);
    (void)zT_113;
    zT_115 = self;
    zT_116 = zF_CBDBFE85_parserParseType(zT_115);
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return zT_116;
    z_bb_34:
    zT_118 = zT_116.data.payload;
    goto z_bb_35;
    z_bb_35:
    eu_payload = zT_118;
    zT_119 = self->store;
    zT_131 = 0;
    zT_122 = tok.span_start;
    zT_134 = tok.span_start;
    zT_135 = tok.span_len;
    zT_124 = eu_base;
    zT_125 = eu_payload;
    zT_138 = 0;
    zT_140 = 0;
    zT_142 = zF_6C9FF72F_astStoreAddNode(zT_119, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_131), zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124, zT_125, (unsigned int)((unsigned int)zT_138), (unsigned int)((unsigned int)zT_140));
    zT_143.data.payload = zT_142;
    zT_143.is_error = 0;
    return zT_143;
    z_bb_36:
    zT_150 = self;
    zT_151 = zF_F5EAD186_parserParseIdentExp(zT_150);
    return zT_151;
    z_bb_37:
    zT_152 = tok.kind;
    if ((unsigned char)(zT_152 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_c_char))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_156 = self;
    zT_157 = zF_F5EAD186_parserParseIdentExp(zT_156);
    return zT_157;
    z_bb_39:
    zT_158 = tok.kind;
    if ((unsigned char)(zT_158 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_void))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_162 = self;
    zT_163 = zF_F5EAD186_parserParseIdentExp(zT_162);
    return zT_163;
    z_bb_41:
    zT_164 = tok.kind;
    if ((unsigned char)(zT_164 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_168 = self;
    zT_169 = zF_5D650338_parserParseBuiltinC(zT_168);
    return zT_169;
    z_bb_43:
    zT_170 = tok.kind;
    if ((unsigned char)(zT_170 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_174 = self;
    zT_175 = zF_C531682A_parserParseCInclude(zT_174);
    return zT_175;
    z_bb_45:
    zT_176 = tok.kind;
    if ((unsigned char)(zT_176 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_180 = self;
    zT_181 = zF_AC24A2A0_parserParseErrorLit(zT_180);
    return zT_181;
    z_bb_47:
    zT_182 = tok.kind;
    if ((unsigned char)(zT_182 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_186 = self;
    zT_190 = zF_BE192524_parserParsePrefixUn(zT_186, (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate));
    return zT_190;
    z_bb_49:
    zT_191 = tok.kind;
    if ((unsigned char)(zT_191 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_195 = self;
    zT_199 = zF_BE192524_parserParsePrefixUn(zT_195, (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate));
    return zT_199;
    z_bb_51:
    zT_200 = tok.kind;
    if ((unsigned char)(zT_200 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_204 = self;
    zT_208 = zF_BE192524_parserParsePrefixUn(zT_204, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not));
    return zT_208;
    z_bb_53:
    zT_209 = tok.kind;
    if ((unsigned char)(zT_209 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_213 = self;
    zT_217 = zF_BE192524_parserParsePrefixUn(zT_213, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not));
    return zT_217;
    z_bb_55:
    zT_218 = tok.kind;
    if ((unsigned char)(zT_218 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_222 = self;
    zT_226 = zF_BE192524_parserParsePrefixUn(zT_222, (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of));
    return zT_226;
    z_bb_57:
    zT_227 = tok.kind;
    if ((unsigned char)(zT_227 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_try))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_231 = self;
    zT_232 = zF_59C88921_parserParseTryExpr(zT_231);
    return zT_232;
    z_bb_59:
    zT_233 = tok.kind;
    if ((unsigned char)(zT_233 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_237 = self;
    zT_238 = zF_C5DF83EE_parserParseGroupedE(zT_237);
    return zT_238;
    z_bb_61:
    zT_239 = tok.kind;
    if ((unsigned char)(zT_239 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_243 = self;
    zT_244 = zF_9A508F9D_parserParseAnonymou(zT_243);
    return zT_244;
    z_bb_63:
    zT_245 = tok.kind;
    if ((unsigned char)(zT_245 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_249 = self;
    zT_250 = zF_BD525F87_parserParseEnumLite(zT_249);
    return zT_250;
    z_bb_65:
    zT_251 = tok.kind;
    if ((unsigned char)(zT_251 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_255 = self;
    zT_256 = zF_79089D39_parserParseIfExpr(zT_255);
    return zT_256;
    z_bb_67:
    zT_257 = tok.kind;
    if ((unsigned char)(zT_257 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_261 = self;
    zT_262 = zF_A9AC92CA_parserParseSwitchEx(zT_261);
    return zT_262;
    z_bb_69:
    zT_263 = tok.kind;
    if ((unsigned char)(zT_263 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_267 = self;
    zT_268 = zF_DE101A45_parserParseArrayLit(zT_267);
    return zT_268;
    z_bb_71:
    zT_270 = self;
    zT_271 = zF_E3AE4B29_parserParseTypeLead(zT_270);
    zT_272 = zT_271.is_error;
    if (zT_272) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_273 = zT_271.data.err;
    zT_274.data.err = zT_273;
    zT_274.is_error = 1;
    return zT_274;
    z_bb_73:
    zT_275 = zT_271.data.payload;
    goto z_bb_74;
    z_bb_74:
    leading = zT_275;
    zT_276 = leading.has_value;
    if (zT_276) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    n = leading.value;
    zT_278.data.payload = n;
    zT_278.is_error = 0;
    return zT_278;
    z_bb_76:
    zT_279 = tok.kind;
    if ((unsigned char)(zT_279 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_283 = self;
    zT_284 = zF_224C1394_parserParseReturnEx(zT_283);
    return zT_284;
    z_bb_78:
    zT_285 = tok.kind;
    if ((unsigned char)(zT_285 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_289 = self;
    zT_290 = zF_C69B6287_parserParseBreakExp(zT_289);
    return zT_290;
    z_bb_80:
    zT_291 = tok.kind;
    if ((unsigned char)(zT_291 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_295 = self;
    zT_296 = zF_73B42F4B_parserParseContinue(zT_295);
    return zT_296;
    z_bb_82:
    zT_297 = tok.kind;
    if ((unsigned char)(zT_297 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_301 = self;
    zT_302 = zF_365CA04A_parserParseBlock(zT_301);
    return zT_302;
    z_bb_84:
    zT_304 = "expected expression";
    zT_306 = 19;
    zT_305.ptr = zT_304;
    zT_305.len = zT_306;
    primary_msg = zT_305;
    zT_307 = self;
    zT_308 = tok;
    zT_309 = primary_msg;
    zF_17DF2CA5_parserAddError(zT_307, zT_308, zT_309);
    zT_310 = 1;
    zT_311.data.err = zT_310;
    zT_311.is_error = 1;
    return zT_311;
}

/* parserParsePostfixChain */
zT_3B6EA323_EU_01 zF_77AD89E7_parserParsePostfixC(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_16;
    unsigned int zT_18;
    int zT_25;
    unsigned int zT_28;
    unsigned short zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_EAC3E484_TokenKind zT_39;
    zT_B559F9DA_Parser* zT_43;
    unsigned int zT_44;
    zT_3B6EA323_EU_01 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_47;
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_52;
    unsigned int zT_53;
    zT_3B6EA323_EU_01 zT_54 = {0};
    unsigned char zT_55;
    unsigned int zT_56;
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_61;
    unsigned int zT_62;
    zT_3B6EA323_EU_01 zT_63 = {0};
    unsigned char zT_64;
    unsigned int zT_65;
    zT_EAC3E484_TokenKind zT_66;
    zT_B559F9DA_Parser* zT_70;
    unsigned int zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_74;
    zT_3B6EA323_EU_01 zT_75;
    unsigned int node;
    zT_3A355BD2_Token tok;
    node = base;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_75.data.payload = node;
    zT_75.is_error = 0;
    return zT_75;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_13 = self->store;
    zT_25 = 0;
    zT_16 = tok.span_start;
    zT_28 = tok.span_start;
    zT_29 = tok.span_len;
    zT_18 = node;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_25), zT_16, (unsigned int)(zT_28 + (unsigned int)((unsigned int)zT_29)), zT_18, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    node = zT_38;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_39 = tok.kind;
    if ((unsigned char)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_43 = self;
    zT_44 = node;
    zT_45 = zF_86B17ABA_parserParseDotAcces(zT_43, zT_44);
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_48 = tok.kind;
    if ((unsigned char)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_14; else goto z_bb_16;
    z_bb_11:
    return zT_45;
    z_bb_12:
    zT_47 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    node = zT_47;
    goto z_bb_9;
    z_bb_14:
    zT_52 = self;
    zT_53 = node;
    zT_54 = zF_8B5A7E08_parserParseIndexOrS(zT_52, zT_53);
    zT_55 = zT_54.is_error;
    if (zT_55) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_57 = tok.kind;
    if ((unsigned char)(zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_20; else goto z_bb_22;
    z_bb_17:
    return zT_54;
    z_bb_18:
    zT_56 = zT_54.data.payload;
    goto z_bb_19;
    z_bb_19:
    node = zT_56;
    goto z_bb_15;
    z_bb_20:
    zT_61 = self;
    zT_62 = node;
    zT_63 = zF_3FC58691_parserParseFnCall(zT_61, zT_62);
    zT_64 = zT_63.is_error;
    if (zT_64) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_66 = tok.kind;
    if ((unsigned char)(zT_66 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_28;
    z_bb_23:
    return zT_63;
    z_bb_24:
    zT_65 = zT_63.data.payload;
    goto z_bb_25;
    z_bb_25:
    node = zT_65;
    goto z_bb_21;
    z_bb_26:
    zT_70 = self;
    zT_71 = node;
    zT_72 = zF_EFD340BA_parserParseStructIn(zT_70, zT_71);
    zT_73 = zT_72.is_error;
    if (zT_73) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_21;
    z_bb_28:
    goto z_bb_3;
    z_bb_29:
    return zT_72;
    z_bb_30:
    zT_74 = zT_72.data.payload;
    goto z_bb_31;
    z_bb_31:
    node = zT_74;
    goto z_bb_27;
}

/* parserParseDotAccess */
zT_3B6EA323_EU_01 zF_86B17ABA_parserParseDotAcces(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_18;
    unsigned int zT_20;
    int zT_27;
    unsigned int zT_30;
    unsigned short zT_31;
    int zT_34;
    int zT_36;
    int zT_38;
    unsigned int zT_40 = 0;
    zT_3B6EA323_EU_01 zT_41;
    unsigned int zT_43;
    zT_EAC3E484_TokenKind zT_44;
    zT_85CBA4DB_TokenValue zT_48;
    unsigned int zT_49;
    zT_EAC3E484_TokenKind zT_50;
    zT_4428DEE2_Arr_unsigned_char_2 zT_55;
    zT_79FAE712_u64 zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_85CBA4DB_TokenValue zT_59;
    int zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67 = 0;
    unsigned int zT_74;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_B559F9DA_Parser* zT_92;
    zT_3A355BD2_Token zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_DBF3575C_ParserError zT_95;
    zT_3B6EA323_EU_01 zT_96;
    zT_B559F9DA_Parser* zT_97;
    zT_3A355BD2_Token zT_98 = {0};
    zT_6B0A7D14_AstStore* zT_99;
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_107;
    int zT_111;
    unsigned int zT_114;
    unsigned short zT_115;
    int zT_118;
    int zT_120;
    unsigned int zT_122 = 0;
    zT_3B6EA323_EU_01 zT_123;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_4428DEE2_Arr_unsigned_char_2 num_buf;
    unsigned int num_len;
    unsigned int num_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)((unsigned int)((unsigned int)zT_7) == (unsigned int)((unsigned int)(zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_15 = self->store;
    zT_27 = 0;
    zT_18 = tok.span_start;
    zT_30 = tok.span_start;
    zT_31 = tok.span_len;
    zT_20 = base;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = zF_6C9FF72F_astStoreAddNode(zT_15, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_27), zT_18, (unsigned int)(zT_30 + (unsigned int)((unsigned int)zT_31)), zT_20, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38));
    zT_41.data.payload = zT_40;
    zT_41.is_error = 0;
    return zT_41;
    z_bb_2:
    zT_43 = 0;
    name_id = zT_43;
    zT_44 = tok.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_48 = tok.value;
    zT_49 = zT_48.string_id;
    name_id = zT_49;
    goto z_bb_4;
    z_bb_4:
    zT_97 = self;
    zT_98 = zF_C241B2C4_parserAdvance(zT_97);
    (void)zT_98;
    zT_99 = self->store;
    zT_111 = 0;
    zT_102 = tok.span_start;
    zT_114 = tok.span_start;
    zT_115 = tok.span_len;
    zT_104 = base;
    zT_118 = 0;
    zT_120 = 0;
    zT_107 = name_id;
    zT_122 = zF_6C9FF72F_astStoreAddNode(zT_99, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_111), zT_102, (unsigned int)(zT_114 + (unsigned int)((unsigned int)zT_115)), zT_104, (unsigned int)((unsigned int)zT_118), (unsigned int)((unsigned int)zT_120), zT_107);
    zT_123.data.payload = zT_122;
    zT_123.is_error = 0;
    return zT_123;
    z_bb_5:
    zT_50 = tok.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        num_buf[_i] = zT_55[_i];
        _i++;
    }
}
    zT_59 = tok.value;
    zT_57 = zT_59.int_val;
    zT_63 = 0;
    zT_64 = (unsigned char*)((unsigned char*)num_buf) + zT_63;
    zT_65 = (unsigned int)(24) - zT_63;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_58 = zT_66;
    zT_67 = zF_A3999586_itoa64(zT_57, zT_58);
    num_len = zT_67;
    zT_74 = (unsigned int)((unsigned int)(24) - (unsigned int)((unsigned int)num_len)) - (unsigned int)(1);
    num_start = zT_74;
    zT_75 = self->interner;
    zT_84 = (unsigned char*)((unsigned char*)num_buf) + num_start;
    zT_85 = (unsigned int)(23) - num_start;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_76 = zT_86;
    zT_87 = zF_50C274AF_stringInternerInter(zT_75, zT_76);
    name_id = zT_87;
    goto z_bb_7;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_89 = "expected field name or index after '.'";
    zT_91 = 38;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    dot_msg = zT_90;
    zT_92 = self;
    zT_93 = tok;
    zT_94 = dot_msg;
    zF_17DF2CA5_parserAddError(zT_92, zT_93, zT_94);
    zT_95 = 1;
    zT_96.data.err = zT_95;
    zT_96.is_error = 1;
    return zT_96;
}

/* parserParseIndexOrSlice */
zT_3B6EA323_EU_01 zF_8B5A7E08_parserParseIndexOrS(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_EAC3E484_TokenKind zT_14;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    int zT_21;
    unsigned int zT_22;
    zT_B559F9DA_Parser* zT_23;
    zT_3A355BD2_Token zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    zT_B559F9DA_Parser* zT_29;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_56;
    unsigned int zT_59;
    unsigned short zT_60;
    int zT_63;
    unsigned int zT_65 = 0;
    zT_3B6EA323_EU_01 zT_66;
    zT_B559F9DA_Parser* zT_67;
    zT_CB78802F_EU_49 zT_71 = {0};
    unsigned char zT_72;
    int zT_73;
    zT_3B6EA323_EU_01 zT_74;
    zT_2B3424E9_ParseToken zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_79;
    unsigned int zT_81;
    unsigned int zT_82;
    int zT_88;
    unsigned int zT_91;
    unsigned short zT_92;
    int zT_95;
    int zT_97;
    unsigned int zT_99 = 0;
    zT_3B6EA323_EU_01 zT_100;
    unsigned int first;
    zT_3A355BD2_Token tok;
    unsigned int last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    first = zT_10;
    zT_12 = self;
    zT_13 = zF_068A2DE5_parserPeek(zT_12);
    tok = zT_13;
    zT_14 = tok.kind;
    if ((unsigned char)(zT_14 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = self;
    zT_19 = zF_C241B2C4_parserAdvance(zT_18);
    (void)zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    last = zT_22;
    zT_23 = self;
    zT_24 = zF_068A2DE5_parserPeek(zT_23);
    zT_25 = zT_24.kind;
    if ((unsigned char)(zT_25 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_67 = self;
    zT_71 = zF_5578C74F_parserExpect(zT_67, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_72 = zT_71.is_error;
    if (zT_72) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_29 = self;
    zT_32 = zF_F07C1F04_parserParseExprPrec(zT_29, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return zT_32;
    z_bb_10:
    zT_34 = zT_32.data.payload;
    goto z_bb_11;
    z_bb_11:
    last = zT_34;
    goto z_bb_7;
    z_bb_12:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_13:
    zT_43 = zT_39.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_43;
    zT_44 = self->store;
    zT_56 = 0;
    zT_47 = tok.span_start;
    zT_59 = tok.span_start;
    zT_60 = tok.span_len;
    zT_49 = base;
    zT_50 = first;
    zT_51 = last;
    zT_63 = 0;
    zT_65 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr), (unsigned char)((unsigned char)zT_56), zT_47, (unsigned int)(zT_59 + (unsigned int)((unsigned int)zT_60)), zT_49, zT_50, zT_51, (unsigned int)((unsigned int)zT_63));
    zT_66.data.payload = zT_65;
    zT_66.is_error = 0;
    return zT_66;
    z_bb_15:
    zT_73 = zT_71.data.err;
    zT_74.data.err = zT_73;
    zT_74.is_error = 1;
    return zT_74;
    z_bb_16:
    zT_75 = zT_71.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_75;
    zT_76 = self->store;
    zT_88 = 0;
    zT_79 = tok.span_start;
    zT_91 = tok.span_start;
    zT_92 = tok.span_len;
    zT_81 = base;
    zT_82 = first;
    zT_95 = 0;
    zT_97 = 0;
    zT_99 = zF_6C9FF72F_astStoreAddNode(zT_76, (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access), (unsigned char)((unsigned char)zT_88), zT_79, (unsigned int)(zT_91 + (unsigned int)((unsigned int)zT_92)), zT_81, zT_82, (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97));
    zT_100.data.payload = zT_99;
    zT_100.is_error = 0;
    return zT_100;
}

/* parserParseFnCall */
zT_3B6EA323_EU_01 zF_3FC58691_parserParseFnCall(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_31;
    int zT_34;
    int zT_36;
    int zT_38;
    unsigned int zT_40 = 0;
    zT_3B6EA323_EU_01 zT_41;
    unsigned int zT_43;
    zT_B559F9DA_Parser* zT_46;
    zT_3B6EA323_EU_01 zT_49 = {0};
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int** zT_52;
    unsigned int* zT_53;
    unsigned int* zT_54;
    zT_3E40CD83_Sand* zT_55;
    unsigned int zT_56;
    zT_B559F9DA_Parser* zT_61;
    zT_3A355BD2_Token zT_62 = {0};
    zT_EAC3E484_TokenKind zT_63;
    zT_B559F9DA_Parser* zT_67;
    zT_CB78802F_EU_49 zT_71 = {0};
    unsigned char zT_72;
    int zT_73;
    zT_3B6EA323_EU_01 zT_74;
    zT_2B3424E9_ParseToken zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_83;
    zT_CB78802F_EU_49 zT_87 = {0};
    unsigned char zT_88;
    int zT_89;
    zT_3B6EA323_EU_01 zT_90;
    zT_2B3424E9_ParseToken zT_91;
    unsigned int zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    zT_B559F9DA_Parser* zT_98;
    unsigned int zT_99;
    unsigned int zT_100 = 0;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_109;
    int zT_113;
    int zT_116;
    int zT_118;
    unsigned int zT_120 = 0;
    zT_3B6EA323_EU_01 zT_121;
    zT_3A355BD2_Token lparen;
    zT_3A355BD2_Token rparen;
    unsigned int end;
    unsigned int saved_fncall;
    unsigned int arg;
    zT_2B3424E9_ParseToken rparen_1;
    unsigned int payload;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lparen = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    rparen = zT_13;
    zT_15 = rparen.span_start;
    zT_16 = rparen.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end = zT_18;
    zT_19 = self->store;
    zT_31 = 0;
    zT_22 = lparen.span_start;
    zT_23 = end;
    zT_24 = base;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = zF_6C9FF72F_astStoreAddNode(zT_19, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_31), zT_22, zT_23, zT_24, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38));
    zT_41.data.payload = zT_40;
    zT_41.is_error = 0;
    return zT_41;
    z_bb_2:
    zT_43 = self->child_buf_len;
    saved_fncall = zT_43;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(1)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_46 = self;
    zT_49 = zF_F07C1F04_parserParseExprPrec(zT_46, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_83 = self;
    zT_87 = zF_5578C74F_parserExpect(zT_83, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_88 = zT_87.is_error;
    if (zT_88) goto z_bb_17; else goto z_bb_18;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return zT_49;
    z_bb_8:
    zT_51 = zT_49.data.payload;
    goto z_bb_9;
    z_bb_9:
    arg = zT_51;
    zT_52 = &self->child_buf_items;
    zT_53 = &self->child_buf_len;
    zT_54 = &self->child_buf_capacity;
    zT_55 = self->allocator;
    zT_56 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_52, zT_53, zT_54, zT_55, zT_56);
    zT_61 = self;
    zT_62 = zF_068A2DE5_parserPeek(zT_61);
    zT_63 = zT_62.kind;
    if ((unsigned char)(zT_63 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    zT_67 = self;
    zT_71 = zF_5578C74F_parserExpect(zT_67, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_72 = zT_71.is_error;
    if (zT_72) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_73 = zT_71.data.err;
    zT_74.data.err = zT_73;
    zT_74.is_error = 1;
    return zT_74;
    z_bb_13:
    zT_75 = zT_71.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_75;
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_5;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_89 = zT_87.data.err;
    zT_90.data.err = zT_89;
    zT_90.is_error = 1;
    return zT_90;
    z_bb_18:
    zT_91 = zT_87.data.payload;
    goto z_bb_19;
    z_bb_19:
    rparen_1 = zT_91;
    zT_93 = rparen_1.span_start;
    zT_94 = rparen_1.span_len;
    zT_96 = zT_93 + (unsigned int)((unsigned int)zT_94);
    end = zT_96;
    zT_98 = self;
    zT_99 = saved_fncall;
    zT_100 = zF_7EC69633_parserListEnd(zT_98, zT_99);
    payload = zT_100;
    zT_101 = self->store;
    zT_113 = 0;
    zT_104 = lparen.span_start;
    zT_105 = end;
    zT_106 = base;
    zT_116 = 0;
    zT_118 = 0;
    zT_109 = payload;
    zT_120 = zF_6C9FF72F_astStoreAddNode(zT_101, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_113), zT_104, zT_105, zT_106, (unsigned int)((unsigned int)zT_116), (unsigned int)((unsigned int)zT_118), zT_109);
    zT_121.data.payload = zT_120;
    zT_121.is_error = 0;
    return zT_121;
}

/* parserParseCatchRHS */
zT_3B6EA323_EU_01 zF_95DDA8C7_parserParseCatchRHS(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min, unsigned int* capture_out) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_CB78802F_EU_49 zT_29 = {0};
    unsigned char zT_30;
    int zT_31;
    zT_3B6EA323_EU_01 zT_32;
    zT_2B3424E9_ParseToken zT_33;
    zT_85CBA4DB_TokenValue zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_40;
    unsigned int zT_45;
    int zT_49;
    unsigned int zT_52;
    unsigned short zT_53;
    int zT_56;
    int zT_58;
    int zT_60;
    unsigned int zT_62 = 0;
    unsigned int zT_64 = 0;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_74;
    zT_B559F9DA_Parser* zT_75;
    zT_2B10107F_Prec zT_76;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char zT_78;
    unsigned int zT_79;
    zT_3B6EA323_EU_01 zT_80;
    zT_3A355BD2_Token ptok;
    zT_3A355BD2_Token name_raw2;
    unsigned int result;
    unsigned int name_id;
    *capture_out = (unsigned int)(0);
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    ptok = zT_6;
    zT_7 = ptok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    name_raw2 = zT_15;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    result = zT_64;
    zT_65 = self;
    zT_66 = zF_068A2DE5_parserPeek(zT_65);
    zT_67 = zT_66.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_9; else goto z_bb_11;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_24;
    zT_25 = self;
    zT_29 = zF_5578C74F_parserExpect(zT_25, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_31 = zT_29.data.err;
    zT_32.data.err = zT_31;
    zT_32.is_error = 1;
    return zT_32;
    z_bb_7:
    zT_33 = zT_29.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_33;
    zT_35 = name_raw2.value;
    zT_36 = zT_35.string_id;
    name_id = zT_36;
    zT_37 = self->store;
    zT_49 = 0;
    zT_40 = name_raw2.span_start;
    zT_52 = name_raw2.span_start;
    zT_53 = name_raw2.span_len;
    zT_56 = 0;
    zT_58 = 0;
    zT_60 = 0;
    zT_45 = name_id;
    zT_62 = zF_6C9FF72F_astStoreAddNode(zT_37, (zT_8143F551_AstKind)(zT_8143F551_AstKind_payload_capture), (unsigned char)((unsigned char)zT_49), zT_40, (unsigned int)(zT_52 + (unsigned int)((unsigned int)zT_53)), (unsigned int)((unsigned int)zT_56), (unsigned int)((unsigned int)zT_58), (unsigned int)((unsigned int)zT_60), zT_45);
    *capture_out = zT_62;
    goto z_bb_2;
    z_bb_9:
    zT_71 = self;
    zT_72 = zF_365CA04A_parserParseBlock(zT_71);
    zT_73 = zT_72.is_error;
    if (zT_73) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_80.data.payload = result;
    zT_80.is_error = 0;
    return zT_80;
    z_bb_11:
    zT_75 = self;
    zT_76 = next_min;
    zT_77 = zF_F07C1F04_parserParseExprPrec(zT_75, zT_76);
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_72;
    z_bb_13:
    zT_74 = zT_72.data.payload;
    goto z_bb_14;
    z_bb_14:
    result = zT_74;
    goto z_bb_10;
    z_bb_15:
    return zT_77;
    z_bb_16:
    zT_79 = zT_77.data.payload;
    goto z_bb_17;
    z_bb_17:
    result = zT_79;
    goto z_bb_10;
}

/* parserParseOrelseRHS */
zT_3B6EA323_EU_01 zF_A059028C_parserParseOrelseRH(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    zT_B559F9DA_Parser* zT_10;
    zT_2B10107F_Prec zT_11;
    zT_3B6EA323_EU_01 zT_12 = {0};
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_365CA04A_parserParseBlock(zT_8);
    return zT_9;
    z_bb_2:
    zT_10 = self;
    zT_11 = next_min;
    zT_12 = zF_F07C1F04_parserParseExprPrec(zT_10, zT_11);
    return zT_12;
}

/* parserParseFieldInitListNamed */
zT_3B6EA323_EU_01 zF_D1EA41E6_parserParseFieldIni(zT_B559F9DA_Parser* self) {
    unsigned int zT_2;
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_CB78802F_EU_49 zT_18 = {0};
    unsigned char zT_19;
    int zT_20;
    zT_3B6EA323_EU_01 zT_21;
    zT_2B3424E9_ParseToken zT_22;
    zT_B559F9DA_Parser* zT_23;
    zT_CB78802F_EU_49 zT_27 = {0};
    unsigned char zT_28;
    int zT_29;
    zT_3B6EA323_EU_01 zT_30;
    zT_2B3424E9_ParseToken zT_31;
    zT_B559F9DA_Parser* zT_33;
    zT_3B6EA323_EU_01 zT_36 = {0};
    unsigned char zT_37;
    unsigned int zT_38;
    zT_85CBA4DB_TokenValue zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_51;
    int zT_55;
    unsigned int zT_58;
    unsigned short zT_59;
    int zT_62;
    int zT_64;
    unsigned int zT_66 = 0;
    unsigned int** zT_67;
    unsigned int* zT_68;
    unsigned int* zT_69;
    zT_3E40CD83_Sand* zT_70;
    unsigned int zT_71;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83 = {0};
    zT_B559F9DA_Parser* zT_85;
    zT_CB78802F_EU_49 zT_89 = {0};
    unsigned char zT_90;
    int zT_91;
    zT_3B6EA323_EU_01 zT_92;
    zT_B559F9DA_Parser* zT_94;
    unsigned int zT_95;
    unsigned int zT_96 = 0;
    zT_3B6EA323_EU_01 zT_97;
    unsigned int saved_child_len;
    zT_3A355BD2_Token name_raw3;
    unsigned int val;
    unsigned int name_id;
    unsigned int field;
    zT_2 = self->child_buf_len;
    saved_child_len = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    if ((unsigned char)(zT_5 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_10 = zF_C241B2C4_parserAdvance(zT_9);
    (void)zT_10;
    zT_12 = self;
    zT_13 = zF_068A2DE5_parserPeek(zT_12);
    name_raw3 = zT_13;
    zT_14 = self;
    zT_18 = zF_5578C74F_parserExpect(zT_14, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_85 = self;
    zT_89 = zF_5578C74F_parserExpect(zT_85, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_90 = zT_89.is_error;
    if (zT_90) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = zT_18.data.err;
    zT_21.data.err = zT_20;
    zT_21.is_error = 1;
    return zT_21;
    z_bb_6:
    zT_22 = zT_18.data.payload;
    goto z_bb_7;
    z_bb_7:
    (void)zT_22;
    zT_23 = self;
    zT_27 = zF_5578C74F_parserExpect(zT_23, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq));
    zT_28 = zT_27.is_error;
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_29 = zT_27.data.err;
    zT_30.data.err = zT_29;
    zT_30.is_error = 1;
    return zT_30;
    z_bb_9:
    zT_31 = zT_27.data.payload;
    goto z_bb_10;
    z_bb_10:
    (void)zT_31;
    zT_33 = self;
    zT_36 = zF_F07C1F04_parserParseExprPrec(zT_33, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return zT_36;
    z_bb_12:
    zT_38 = zT_36.data.payload;
    goto z_bb_13;
    z_bb_13:
    val = zT_38;
    zT_40 = name_raw3.value;
    zT_41 = zT_40.string_id;
    name_id = zT_41;
    zT_43 = self->store;
    zT_55 = 0;
    zT_46 = name_raw3.span_start;
    zT_58 = name_raw3.span_start;
    zT_59 = name_raw3.span_len;
    zT_48 = val;
    zT_62 = 0;
    zT_64 = 0;
    zT_51 = name_id;
    zT_66 = zF_6C9FF72F_astStoreAddNode(zT_43, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_init), (unsigned char)((unsigned char)zT_55), zT_46, (unsigned int)(zT_58 + (unsigned int)((unsigned int)zT_59)), zT_48, (unsigned int)((unsigned int)zT_62), (unsigned int)((unsigned int)zT_64), zT_51);
    field = zT_66;
    zT_67 = &self->child_buf_items;
    zT_68 = &self->child_buf_len;
    zT_69 = &self->child_buf_capacity;
    zT_70 = self->allocator;
    zT_71 = field;
    zF_8B163A32_u32ArrayListAppendI(zT_67, zT_68, zT_69, zT_70, zT_71);
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_82 = self;
    zT_83 = zF_C241B2C4_parserAdvance(zT_82);
    (void)zT_83;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_4;
    z_bb_16:
    zT_91 = zT_89.data.err;
    zT_92.data.err = zT_91;
    zT_92.is_error = 1;
    return zT_92;
    z_bb_17:
    goto z_bb_18;
    z_bb_18:
    zT_94 = self;
    zT_95 = saved_child_len;
    zT_96 = zF_7EC69633_parserListEnd(zT_94, zT_95);
    zT_97.data.payload = zT_96;
    zT_97.is_error = 0;
    return zT_97;
}

/* parserParseStructInit */
zT_3B6EA323_EU_01 zF_EFD340BA_parserParseStructIn(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    int zT_24;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token lbrace;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lbrace = zT_4;
    zT_6 = self;
    zT_7 = zF_D1EA41E6_parserParseFieldIni(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_9;
    zT_11 = self->last_end;
    end_pos = zT_11;
    zT_12 = self->store;
    zT_24 = 0;
    zT_15 = lbrace.span_start;
    zT_16 = end_pos;
    zT_17 = base;
    zT_27 = 0;
    zT_29 = 0;
    zT_20 = payload;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_12, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_24), zT_15, zT_16, zT_17, (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29), zT_20);
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* u32ArrayListAppendInner */
void zF_8B163A32_u32ArrayListAppendI(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int* zT_29;
    unsigned int zT_31;
    zT_6E306FF1_Opt_242 zT_37 = {0};
    unsigned char zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_FF4D4E6C_EU_242 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int* zT_61;
    unsigned int zT_62;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_63;
    unsigned int* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6E306FF1_Opt_242 grown;
    unsigned char* raw;
    unsigned int* new_items_p;
    unsigned int item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((unsigned char)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(4)), (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (unsigned int*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
    z_bb_17:
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
}

/* parserPushU32 */
void zF_0F1462F8_parserPushU32(zT_B559F9DA_Parser* self, unsigned int** buf, unsigned int* len, unsigned int* cap, unsigned int v) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_5 = buf;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = self->allocator;
    zT_9 = v;
    zF_8B163A32_u32ArrayListAppendI(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* parserListEnd */
unsigned int zF_7EC69633_parserListEnd(zT_B559F9DA_Parser* self, unsigned int saved) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned int zT_13;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_14;
    unsigned int zT_15 = 0;
    unsigned int payload;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    payload = zT_4;
    zT_5 = self->child_buf_len;
    if ((unsigned char)(zT_5 > saved)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = self->store;
    zT_10 = self->child_buf_items;
    zT_11 = self->child_buf_len;
    zT_12 = zT_10 + saved;
    zT_13 = zT_11 - saved;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_8 = zT_14;
    zT_15 = zF_583E993C_astStoreAddExtraChi(zT_7, zT_8);
    payload = zT_15;
    goto z_bb_2;
    z_bb_2:
    self->child_buf_len = saved;
    return payload;
}

/* parserParseCaptureName */
zT_CF7AC512_EU_59 zF_E99FEED2_parserParseCaptureN(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    zT_2B3424E9_ParseToken zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_CB78802F_EU_49 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    zT_CF7AC512_EU_59 zT_18;
    zT_2B3424E9_ParseToken zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_CF7AC512_EU_59 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    zT_A68A775E_ParseCapture zT_29;
    zT_B559F9DA_Parser* zT_30;
    zT_2B3424E9_ParseToken zT_31;
    unsigned int zT_32 = 0;
    unsigned int zT_33;
    unsigned short zT_34;
    zT_CF7AC512_EU_59 zT_35;
    zT_2B3424E9_ParseToken name_tok;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    name_tok = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_11 = self;
    zT_15 = zF_5578C74F_parserExpect(zT_11, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    zT_30 = self;
    zT_31 = name_tok;
    zT_32 = zF_ED2167CA_parserInternParseTo(zT_30, zT_31);
    zT_29.name_id = zT_32;
    zT_33 = name_tok.span_start;
    zT_29.tok_start = zT_33;
    zT_34 = name_tok.span_len;
    zT_29.tok_len = zT_34;
    zT_35.data.payload = zT_29;
    zT_35.is_error = 0;
    return zT_35;
    z_bb_3:
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_17 = zT_15.data.err;
    zT_18.data.err = zT_17;
    zT_18.is_error = 1;
    return zT_18;
    z_bb_5:
    zT_19 = zT_15.data.payload;
    goto z_bb_6;
    z_bb_6:
    name_tok = zT_19;
    goto z_bb_2;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    name_tok = zT_28;
    goto z_bb_2;
}

/* parserParseExprListBrace */
zT_08A61393_EU_1 zF_E360EDB5_parserParseExprList(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    zT_EAC3E484_TokenKind zT_3;
    unsigned char zT_7;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    int zT_20;
    zT_08A61393_EU_1 zT_21;
    unsigned int zT_22;
    unsigned int** zT_23;
    unsigned int* zT_24;
    unsigned int* zT_25;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_27;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    zT_08A61393_EU_1 zT_41;
    unsigned int val;
    goto z_bb_1;
    z_bb_1:
    zT_1 = self;
    zT_2 = zF_068A2DE5_parserPeek(zT_1);
    zT_3 = zT_2.kind;
    if ((unsigned char)(zT_3 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = self;
    zT_18 = zF_F07C1F04_parserParseExprPrec(zT_15, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_8; else goto z_bb_9;
    z_bb_3:
    zT_41.err = 0;
    zT_41.is_error = 0;
    return zT_41;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    zT_7 = zT_10 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_7;
    z_bb_6:
    zT_7 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_20 = zT_18.data.err;
    zT_21.err = zT_20;
    zT_21.is_error = 1;
    return zT_21;
    z_bb_9:
    zT_22 = zT_18.data.payload;
    goto z_bb_10;
    z_bb_10:
    val = zT_22;
    zT_23 = &self->child_buf_items;
    zT_24 = &self->child_buf_len;
    zT_25 = &self->child_buf_capacity;
    zT_26 = self->allocator;
    zT_27 = val;
    zF_8B163A32_u32ArrayListAppendI(zT_23, zT_24, zT_25, zT_26, zT_27);
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    zT_34 = zT_33.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = self;
    zT_39 = zF_C241B2C4_parserAdvance(zT_38);
    (void)zT_39;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_4;
}

/* parserParseIntLiteral */
zT_3B6EA323_EU_01 zF_4D06854D_parserParseIntLiter(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_E45552BF_astStoreAddIntLiter(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseFloatLiteral */
zT_3B6EA323_EU_01 zF_FB72DD9C_parserParseFloatLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_C41F1B06_Arr_unsigned_char_6 zT_10;
    zT_00435AEB_f64 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_85CBA4DB_TokenValue zT_15;
    int zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25 = {0};
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    zT_00435AEB_f64 zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_85CBA4DB_TokenValue zT_42;
    unsigned int zT_45 = 0;
    zT_3B6EA323_EU_01 zT_46;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_C41F1B06_Arr_unsigned_char_6 dbg_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        dbg_buf[_i] = zT_10[_i];
        _i++;
    }
}
    zT_15 = tok.value;
    zT_12 = zT_15.float_val;
    zT_19 = 0;
    zT_20 = (unsigned char*)((unsigned char*)dbg_buf) + zT_19;
    zT_21 = (unsigned int)(64) - zT_19;
    zT_22.ptr = zT_20;
    zT_22.len = zT_21;
    zT_13 = zT_22;
    zT_23 = 64;
    zT_25 = zF_4CAEBE7E_formatF64(zT_12, zT_13, (unsigned int)((unsigned int)zT_23));
    dbg = zT_25;
    zT_27 = "PF:";
    zT_29 = 3;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ps = zT_28;
    zT_30 = ps;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_31 = dbg;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_33 = "\n";
    zT_35 = 1;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pn = zT_34;
    zT_36 = pn;
    zF_48AC7B3A_markerWrite(zT_36);
    zT_37 = self->store;
    zT_42 = tok.value;
    zT_38 = zT_42.float_val;
    zT_39 = tok.span_start;
    zT_40 = end;
    zT_45 = zF_0CEAF68A_astStoreAddFloatLit(zT_37, zT_38, zT_39, zT_40);
    zT_46.data.payload = zT_45;
    zT_46.is_error = 0;
    return zT_46;
}

/* parserParseStringLiteral */
zT_3B6EA323_EU_01 zF_397D4BBF_parserParseStringLi(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.string_id;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_042235B9_astStoreAddStringLi(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseCharLiteral */
zT_3B6EA323_EU_01 zF_F509A7F4_parserParseCharLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_2CAC92AE_astStoreAddCharLite(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseBoolLiteral */
zT_3B6EA323_EU_01 zF_0E221A14_parserParseBoolLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned char zT_6;
    zT_EAC3E484_TokenKind zT_7;
    int zT_11;
    unsigned char zT_12;
    unsigned int zT_14;
    unsigned short zT_15;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_31;
    int zT_33;
    int zT_35;
    int zT_37;
    unsigned int zT_39 = 0;
    zT_3B6EA323_EU_01 zT_40;
    zT_3A355BD2_Token tok;
    unsigned char val;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    val = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = 1;
    zT_12 = (unsigned char)zT_11;
    val = zT_12;
    goto z_bb_2;
    z_bb_2:
    zT_14 = tok.span_start;
    zT_15 = tok.span_len;
    zT_17 = zT_14 + (unsigned int)((unsigned int)zT_15);
    end = zT_17;
    zT_18 = self->store;
    zT_20 = val;
    zT_21 = tok.span_start;
    zT_22 = end;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = 0;
    zT_39 = zF_6C9FF72F_astStoreAddNode(zT_18, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal), zT_20, zT_21, zT_22, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35), (unsigned int)((unsigned int)zT_37));
    zT_40.data.payload = zT_39;
    zT_40.is_error = 0;
    return zT_40;
}

/* parserParseSingleToken */
zT_3B6EA323_EU_01 zF_A18ECFB6_parserParseSingleTo(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    unsigned int zT_6;
    unsigned short zT_7;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_10;
    zT_8143F551_AstKind zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_20;
    int zT_23;
    int zT_25;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = tok.span_start;
    zT_7 = tok.span_len;
    zT_9 = zT_6 + (unsigned int)((unsigned int)zT_7);
    end = zT_9;
    zT_10 = self->store;
    zT_11 = kind;
    zT_20 = 0;
    zT_13 = tok.span_start;
    zT_14 = end;
    zT_23 = 0;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_10, zT_11, (unsigned char)((unsigned char)zT_20), zT_13, zT_14, (unsigned int)((unsigned int)zT_23), (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29));
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* parserParseIdentExpr */
zT_3B6EA323_EU_01 zF_F5EAD186_parserParseIdentExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6;
    unsigned int zT_7 = 0;
    unsigned int zT_9;
    unsigned short zT_10;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_22 = 0;
    zT_3B6EA323_EU_01 zT_23;
    zT_3A355BD2_Token tok;
    unsigned int id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = tok;
    zT_7 = zF_9DDDA188_parserInternTokenTe(zT_5, zT_6);
    id = zT_7;
    zT_9 = tok.span_start;
    zT_10 = tok.span_len;
    zT_12 = zT_9 + (unsigned int)((unsigned int)zT_10);
    end = zT_12;
    zT_13 = self->store;
    zT_15 = id;
    zT_16 = tok.span_start;
    zT_17 = end;
    zT_22 = zF_1DF77BD4_astStoreAddIdentifi(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_15, zT_16, zT_17);
    zT_23.data.payload = zT_22;
    zT_23.is_error = 0;
    return zT_23;
}

/* parserParsePrefixUnary */
zT_3B6EA323_EU_01 zF_BE192524_parserParsePrefixUn(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned short zT_14;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_8143F551_AstKind zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_27;
    int zT_30;
    int zT_32;
    int zT_34;
    unsigned int zT_36 = 0;
    zT_3B6EA323_EU_01 zT_37;
    zT_3A355BD2_Token tok;
    unsigned int operand;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = self;
    zT_9 = zF_F07C1F04_parserParseExprPrec(zT_6, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    operand = zT_11;
    zT_13 = tok.span_start;
    zT_14 = tok.span_len;
    zT_16 = zT_13 + (unsigned int)((unsigned int)zT_14);
    end = zT_16;
    zT_17 = self->store;
    zT_18 = kind;
    zT_27 = 0;
    zT_20 = tok.span_start;
    zT_21 = end;
    zT_22 = operand;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = zF_6C9FF72F_astStoreAddNode(zT_17, zT_18, (unsigned char)((unsigned char)zT_27), zT_20, zT_21, zT_22, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34));
    zT_37.data.payload = zT_36;
    zT_37.is_error = 0;
    return zT_37;
}

/* parserParseGroupedExpr */
zT_3B6EA323_EU_01 zF_C5DF83EE_parserParseGroupedE(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_16 = {0};
    unsigned char zT_17;
    int zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_2B3424E9_ParseToken zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24;
    unsigned int zT_26;
    int zT_33;
    unsigned int zT_36;
    unsigned short zT_37;
    int zT_40;
    int zT_42;
    int zT_44;
    unsigned int zT_46 = 0;
    zT_3B6EA323_EU_01 zT_47;
    zT_3A355BD2_Token lparen;
    unsigned int inner;
    zT_2B3424E9_ParseToken rparen;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    lparen = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = self;
    zT_16 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = zT_16.data.err;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_5:
    zT_20 = zT_16.data.payload;
    goto z_bb_6;
    z_bb_6:
    rparen = zT_20;
    zT_21 = self->store;
    zT_33 = 0;
    zT_24 = lparen.span_start;
    zT_36 = rparen.span_start;
    zT_37 = rparen.span_len;
    zT_26 = inner;
    zT_40 = 0;
    zT_42 = 0;
    zT_44 = 0;
    zT_46 = zF_6C9FF72F_astStoreAddNode(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr), (unsigned char)((unsigned char)zT_33), zT_24, (unsigned int)(zT_36 + (unsigned int)((unsigned int)zT_37)), zT_26, (unsigned int)((unsigned int)zT_40), (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44));
    zT_47.data.payload = zT_46;
    zT_47.is_error = 0;
    return zT_47;
}

/* parserParseBuiltinCall */
zT_3B6EA323_EU_01 zF_5D650338_parserParseBuiltinC(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_85CBA4DB_TokenValue zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_8;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11;
    zT_3B6EA323_EU_01 zT_12 = {0};
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned short zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_DBF3575C_ParserError zT_35;
    zT_3B6EA323_EU_01 zT_36;
    zT_B559F9DA_Parser* zT_37;
    zT_3A355BD2_Token zT_38 = {0};
    unsigned int zT_40;
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    zT_B559F9DA_Parser* zT_49;
    zT_3A355BD2_Token zT_50 = {0};
    unsigned char zT_52;
    zT_EAC3E484_TokenKind zT_53;
    unsigned char zT_57;
    zT_EAC3E484_TokenKind zT_58;
    unsigned char zT_62;
    zT_EAC3E484_TokenKind zT_63;
    unsigned char zT_67;
    zT_EAC3E484_TokenKind zT_68;
    unsigned char zT_72;
    zT_EAC3E484_TokenKind zT_73;
    unsigned char zT_77;
    zT_EAC3E484_TokenKind zT_78;
    unsigned char zT_82;
    zT_EAC3E484_TokenKind zT_83;
    unsigned char zT_87;
    zT_EAC3E484_TokenKind zT_88;
    unsigned char zT_92;
    zT_EAC3E484_TokenKind zT_93;
    unsigned char zT_97;
    zT_EAC3E484_TokenKind zT_98;
    unsigned char zT_102;
    zT_B559F9DA_Parser* zT_106;
    zT_3B6EA323_EU_01 zT_107 = {0};
    unsigned char zT_108;
    unsigned int zT_109;
    unsigned int** zT_110;
    unsigned int* zT_111;
    unsigned int* zT_112;
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_B559F9DA_Parser* zT_120;
    zT_3B6EA323_EU_01 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_125;
    unsigned int** zT_126;
    unsigned int* zT_127;
    unsigned int* zT_128;
    zT_3E40CD83_Sand* zT_129;
    unsigned int zT_130;
    zT_B559F9DA_Parser* zT_135;
    zT_3A355BD2_Token zT_136 = {0};
    zT_EAC3E484_TokenKind zT_137;
    zT_B559F9DA_Parser* zT_141;
    zT_CB78802F_EU_49 zT_145 = {0};
    unsigned char zT_146;
    int zT_147;
    zT_3B6EA323_EU_01 zT_148;
    zT_2B3424E9_ParseToken zT_149;
    zT_B559F9DA_Parser* zT_151;
    zT_3A355BD2_Token zT_152 = {0};
    unsigned int zT_153;
    unsigned short zT_154;
    unsigned int zT_156;
    zT_B559F9DA_Parser* zT_158;
    unsigned int zT_159;
    unsigned int zT_160 = 0;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_169;
    int zT_173;
    int zT_176;
    int zT_178;
    unsigned int zT_180 = 0;
    zT_3B6EA323_EU_01 zT_181;
    zT_3A355BD2_Token tok;
    unsigned int id;
    unsigned int end;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    unsigned int saved_builtin;
    zT_3A355BD2_Token rparen;
    unsigned int payload;
    zT_3A355BD2_Token arg_tok;
    unsigned char is_type;
    unsigned int arg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = tok.value;
    zT_5 = zT_4.string_id;
    zT_6 = self->builtin_import_id;
    if ((unsigned char)(zT_5 == zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_8);
    zT_10 = self;
    zT_11 = tok;
    zT_12 = zF_D258E86B_parserParseImportEx(zT_10, zT_11);
    return zT_12;
    z_bb_2:
    zT_14 = tok.value;
    zT_15 = zT_14.string_id;
    id = zT_15;
    zT_17 = tok.span_start;
    zT_18 = tok.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    lparen = zT_23;
    zT_24 = lparen.kind;
    if ((unsigned char)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_29 = "expected '(' after builtin name";
    zT_31 = 31;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    exp_s = zT_30;
    zT_32 = self;
    zT_33 = lparen;
    zT_34 = exp_s;
    zF_17DF2CA5_parserAddError(zT_32, zT_33, zT_34);
    zT_35 = 1;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_4:
    zT_37 = self;
    zT_38 = zF_C241B2C4_parserAdvance(zT_37);
    (void)zT_38;
    zT_40 = self->child_buf_len;
    saved_builtin = zT_40;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(1)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    zT_44 = zT_43.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_151 = self;
    zT_152 = zF_C241B2C4_parserAdvance(zT_151);
    rparen = zT_152;
    zT_153 = rparen.span_start;
    zT_154 = rparen.span_len;
    zT_156 = zT_153 + (unsigned int)((unsigned int)zT_154);
    end = zT_156;
    zT_158 = self;
    zT_159 = saved_builtin;
    zT_160 = zF_7EC69633_parserListEnd(zT_158, zT_159);
    payload = zT_160;
    zT_161 = self->store;
    zT_173 = 0;
    zT_164 = tok.span_start;
    zT_165 = end;
    zT_166 = id;
    zT_176 = 0;
    zT_178 = 0;
    zT_169 = payload;
    zT_180 = zF_6C9FF72F_astStoreAddNode(zT_161, (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call), (unsigned char)((unsigned char)zT_173), zT_164, zT_165, zT_166, (unsigned int)((unsigned int)zT_176), (unsigned int)((unsigned int)zT_178), zT_169);
    zT_181.data.payload = zT_180;
    zT_181.is_error = 0;
    return zT_181;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    zT_49 = self;
    zT_50 = zF_068A2DE5_parserPeek(zT_49);
    arg_tok = zT_50;
    zT_52 = 0;
    is_type = zT_52;
    zT_53 = arg_tok.kind;
    if ((unsigned char)(zT_53 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_57 = 1;
    is_type = zT_57;
    goto z_bb_12;
    z_bb_12:
    zT_58 = arg_tok.kind;
    if ((unsigned char)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_62 = 1;
    is_type = zT_62;
    goto z_bb_14;
    z_bb_14:
    zT_63 = arg_tok.kind;
    if ((unsigned char)(zT_63 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_67 = 1;
    is_type = zT_67;
    goto z_bb_16;
    z_bb_16:
    zT_68 = arg_tok.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_72 = 1;
    is_type = zT_72;
    goto z_bb_18;
    z_bb_18:
    zT_73 = arg_tok.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_77 = 1;
    is_type = zT_77;
    goto z_bb_20;
    z_bb_20:
    zT_78 = arg_tok.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = 1;
    is_type = zT_82;
    goto z_bb_22;
    z_bb_22:
    zT_83 = arg_tok.kind;
    if ((unsigned char)(zT_83 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_87 = 1;
    is_type = zT_87;
    goto z_bb_24;
    z_bb_24:
    zT_88 = arg_tok.kind;
    if ((unsigned char)(zT_88 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_92 = 1;
    is_type = zT_92;
    goto z_bb_26;
    z_bb_26:
    zT_93 = arg_tok.kind;
    if ((unsigned char)(zT_93 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_97 = 1;
    is_type = zT_97;
    goto z_bb_28;
    z_bb_28:
    zT_98 = arg_tok.kind;
    if ((unsigned char)(zT_98 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_102 = 1;
    is_type = zT_102;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)(is_type != (unsigned char)(0))) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_106 = self;
    zT_107 = zF_CBDBFE85_parserParseType(zT_106);
    zT_108 = zT_107.is_error;
    if (zT_108) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    zT_135 = self;
    zT_136 = zF_068A2DE5_parserPeek(zT_135);
    zT_137 = zT_136.kind;
    if ((unsigned char)(zT_137 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_40; else goto z_bb_41;
    z_bb_33:
    zT_120 = self;
    zT_123 = zF_F07C1F04_parserParseExprPrec(zT_120, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    return zT_107;
    z_bb_35:
    zT_109 = zT_107.data.payload;
    goto z_bb_36;
    z_bb_36:
    arg = zT_109;
    zT_110 = &self->child_buf_items;
    zT_111 = &self->child_buf_len;
    zT_112 = &self->child_buf_capacity;
    zT_113 = self->allocator;
    zT_114 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_110, zT_111, zT_112, zT_113, zT_114);
    goto z_bb_32;
    z_bb_37:
    return zT_123;
    z_bb_38:
    zT_125 = zT_123.data.payload;
    goto z_bb_39;
    z_bb_39:
    arg = zT_125;
    zT_126 = &self->child_buf_items;
    zT_127 = &self->child_buf_len;
    zT_128 = &self->child_buf_capacity;
    zT_129 = self->allocator;
    zT_130 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_126, zT_127, zT_128, zT_129, zT_130);
    goto z_bb_32;
    z_bb_40:
    goto z_bb_7;
    z_bb_41:
    zT_141 = self;
    zT_145 = zF_5578C74F_parserExpect(zT_141, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_146 = zT_145.is_error;
    if (zT_146) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_147 = zT_145.data.err;
    zT_148.data.err = zT_147;
    zT_148.is_error = 1;
    return zT_148;
    z_bb_43:
    zT_149 = zT_145.data.payload;
    goto z_bb_44;
    z_bb_44:
    (void)zT_149;
    goto z_bb_8;
}

/* parserParseImportExpr */
zT_3B6EA323_EU_01 zF_D258E86B_parserParseImportEx(zT_B559F9DA_Parser* self, zT_3A355BD2_Token bi_tok) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_DBF3575C_ParserError zT_16;
    zT_3B6EA323_EU_01 zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_DBF3575C_ParserError zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_85CBA4DB_TokenValue zT_37;
    unsigned int zT_38;
    zT_B559F9DA_Parser* zT_39;
    zT_3A355BD2_Token zT_40 = {0};
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_DBF3575C_ParserError zT_55;
    zT_3B6EA323_EU_01 zT_56;
    unsigned int zT_58;
    unsigned short zT_59;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_6F32B01B_Opt_235 zT_64;
    unsigned char zT_65;
    zT_713074AA_Opt_247 zT_67;
    unsigned char zT_68;
    zT_3E40CD83_Sand* zT_70;
    zT_072B53A6_ModuleRegistry* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_BAEE192E_Opt_10 zT_77 = {0};
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_86;
    int zT_90;
    int zT_93;
    int zT_95;
    int zT_97;
    unsigned int zT_99 = 0;
    zT_3B6EA323_EU_01 zT_100;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token path_tok;
    unsigned int path_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_072B53A6_ModuleRegistry* reg;
    zT_3E40CD83_Sand* is;
    zT_BAEE192E_Opt_10 resolved;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    lparen = zT_4;
    zT_5 = lparen.kind;
    if ((unsigned char)(zT_5 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = "expected '(' after @import";
    zT_12 = 26;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    exp_s = zT_11;
    zT_13 = self;
    zT_14 = lparen;
    zT_15 = exp_s;
    zF_17DF2CA5_parserAddError(zT_13, zT_14, zT_15);
    zT_16 = 1;
    zT_17.data.err = zT_16;
    zT_17.is_error = 1;
    return zT_17;
    z_bb_2:
    zT_18 = self;
    zT_19 = zF_C241B2C4_parserAdvance(zT_18);
    (void)zT_19;
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    path_tok = zT_22;
    zT_23 = path_tok.kind;
    if ((unsigned char)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_28 = "expected string literal for @import path";
    zT_30 = 40;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    exp_s = zT_29;
    zT_31 = self;
    zT_32 = path_tok;
    zT_33 = exp_s;
    zF_17DF2CA5_parserAddError(zT_31, zT_32, zT_33);
    zT_34 = 1;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_4:
    zT_37 = path_tok.value;
    zT_38 = zT_37.string_id;
    path_id = zT_38;
    zT_39 = self;
    zT_40 = zF_C241B2C4_parserAdvance(zT_39);
    (void)zT_40;
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    rparen = zT_43;
    zT_44 = rparen.kind;
    if ((unsigned char)(zT_44 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_49 = "expected ')' after @import path";
    zT_51 = 31;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    exp_s = zT_50;
    zT_52 = self;
    zT_53 = rparen;
    zT_54 = exp_s;
    zF_17DF2CA5_parserAddError(zT_52, zT_53, zT_54);
    zT_55 = 1;
    zT_56.data.err = zT_55;
    zT_56.is_error = 1;
    return zT_56;
    z_bb_6:
    zT_58 = rparen.span_start;
    zT_59 = rparen.span_len;
    zT_61 = zT_58 + (unsigned int)((unsigned int)zT_59);
    end_pos = zT_61;
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    zT_64 = self->module_reg;
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    reg = zT_64.value;
    zT_67 = self->import_scratch;
    zT_68 = zT_67.has_value;
    if (zT_68) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_78 = self->store;
    zT_90 = 0;
    zT_81 = bi_tok.span_start;
    zT_82 = end_pos;
    zT_93 = 0;
    zT_95 = 0;
    zT_97 = 0;
    zT_86 = path_id;
    zT_99 = zF_6C9FF72F_astStoreAddNode(zT_78, (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr), (unsigned char)((unsigned char)zT_90), zT_81, zT_82, (unsigned int)((unsigned int)zT_93), (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97), zT_86);
    zT_100.data.payload = zT_99;
    zT_100.is_error = 0;
    return zT_100;
    z_bb_9:
    is = zT_67.value;
    zT_70 = is;
    zF_F1B3F8C2_sandReset(zT_70);
    zT_72 = reg;
    zT_73 = path_id;
    zT_74 = self->current_module_id;
    zT_75 = is;
    zT_77 = zF_620E3E3B_moduleRegistryResol(zT_72, zT_73, zT_74, zT_75);
    resolved = zT_77;
    (void)resolved;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* parserParseCInclude */
zT_3B6EA323_EU_01 zF_C531682A_parserParseCInclude(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_DBF3575C_ParserError zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_B559F9DA_Parser* zT_23;
    zT_3A355BD2_Token zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_B559F9DA_Parser* zT_33;
    zT_3A355BD2_Token zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_DBF3575C_ParserError zT_36;
    zT_3B6EA323_EU_01 zT_37;
    zT_85CBA4DB_TokenValue zT_39;
    unsigned int zT_40;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_DBF3575C_ParserError zT_57;
    zT_3B6EA323_EU_01 zT_58;
    unsigned int zT_60;
    unsigned short zT_61;
    unsigned int zT_63;
    zT_B559F9DA_Parser* zT_64;
    zT_3A355BD2_Token zT_65 = {0};
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_74;
    int zT_78;
    int zT_81;
    int zT_83;
    int zT_85;
    unsigned int zT_87 = 0;
    zT_3B6EA323_EU_01 zT_88;
    zT_3A355BD2_Token bi_tok;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token name_tok;
    unsigned int name_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    bi_tok = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    lparen = zT_6;
    zT_7 = lparen.kind;
    if ((unsigned char)(zT_7 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "expected '(' after @cInclude";
    zT_14 = 28;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    exp_s = zT_13;
    zT_15 = self;
    zT_16 = lparen;
    zT_17 = exp_s;
    zF_17DF2CA5_parserAddError(zT_15, zT_16, zT_17);
    zT_18 = 1;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_2:
    zT_20 = self;
    zT_21 = zF_C241B2C4_parserAdvance(zT_20);
    (void)zT_21;
    zT_23 = self;
    zT_24 = zF_068A2DE5_parserPeek(zT_23);
    name_tok = zT_24;
    zT_25 = name_tok.kind;
    if ((unsigned char)(zT_25 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = "expected string literal for @cInclude name";
    zT_32 = 42;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    exp_s = zT_31;
    zT_33 = self;
    zT_34 = name_tok;
    zT_35 = exp_s;
    zF_17DF2CA5_parserAddError(zT_33, zT_34, zT_35);
    zT_36 = 1;
    zT_37.data.err = zT_36;
    zT_37.is_error = 1;
    return zT_37;
    z_bb_4:
    zT_39 = name_tok.value;
    zT_40 = zT_39.string_id;
    name_id = zT_40;
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    zT_44 = self;
    zT_45 = zF_068A2DE5_parserPeek(zT_44);
    rparen = zT_45;
    zT_46 = rparen.kind;
    if ((unsigned char)(zT_46 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_51 = "expected ')' after @cInclude name";
    zT_53 = 33;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    exp_s = zT_52;
    zT_54 = self;
    zT_55 = rparen;
    zT_56 = exp_s;
    zF_17DF2CA5_parserAddError(zT_54, zT_55, zT_56);
    zT_57 = 1;
    zT_58.data.err = zT_57;
    zT_58.is_error = 1;
    return zT_58;
    z_bb_6:
    zT_60 = rparen.span_start;
    zT_61 = rparen.span_len;
    zT_63 = zT_60 + (unsigned int)((unsigned int)zT_61);
    end_pos = zT_63;
    zT_64 = self;
    zT_65 = zF_C241B2C4_parserAdvance(zT_64);
    (void)zT_65;
    zT_66 = self->store;
    zT_78 = 0;
    zT_69 = bi_tok.span_start;
    zT_70 = end_pos;
    zT_81 = 0;
    zT_83 = 0;
    zT_85 = 0;
    zT_74 = name_id;
    zT_87 = zF_6C9FF72F_astStoreAddNode(zT_66, (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include), (unsigned char)((unsigned char)zT_78), zT_69, zT_70, (unsigned int)((unsigned int)zT_81), (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85), zT_74);
    zT_88.data.payload = zT_87;
    zT_88.is_error = 0;
    return zT_88;
}

/* parserParseErrorLiteral */
zT_3B6EA323_EU_01 zF_AC24A2A0_parserParseErrorLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12;
    zT_3B6EA323_EU_01 zT_13 = {0};
    unsigned char zT_14;
    unsigned int zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_B559F9DA_Parser* zT_25;
    zT_3B6EA323_EU_01 zT_26 = {0};
    unsigned char zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_41;
    unsigned int zT_44;
    unsigned short zT_45;
    int zT_48;
    int zT_50;
    unsigned int zT_52 = 0;
    zT_3B6EA323_EU_01 zT_53;
    zT_3B6EA323_EU_01 zT_54;
    zT_B559F9DA_Parser* zT_55;
    zT_CB78802F_EU_49 zT_59 = {0};
    unsigned char zT_60;
    int zT_61;
    zT_3B6EA323_EU_01 zT_62;
    zT_2B3424E9_ParseToken zT_63;
    zT_B559F9DA_Parser* zT_65;
    zT_CB78802F_EU_49 zT_69 = {0};
    unsigned char zT_70;
    int zT_71;
    zT_3B6EA323_EU_01 zT_72;
    zT_2B3424E9_ParseToken zT_73;
    zT_B559F9DA_Parser* zT_75;
    zT_2B3424E9_ParseToken zT_76;
    unsigned int zT_77 = 0;
    unsigned int zT_79;
    unsigned short zT_80;
    unsigned int zT_82;
    zT_6B0A7D14_AstStore* zT_83;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_91;
    int zT_95;
    int zT_98;
    int zT_100;
    int zT_102;
    unsigned int zT_104 = 0;
    zT_3B6EA323_EU_01 zT_105;
    zT_3A355BD2_Token kw;
    unsigned int es;
    unsigned int eu_payload;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int name_id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = kw;
    zT_13 = zF_2C55CABB_parserParseErrorSet(zT_11, zT_12);
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_55 = self;
    zT_59 = zF_5578C74F_parserExpect(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    return zT_13;
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    es = zT_15;
    zT_16 = self;
    zT_17 = zF_068A2DE5_parserPeek(zT_16);
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self;
    zT_23 = zF_C241B2C4_parserAdvance(zT_22);
    (void)zT_23;
    zT_25 = self;
    zT_26 = zF_CBDBFE85_parserParseType(zT_25);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_54.data.payload = es;
    zT_54.is_error = 0;
    return zT_54;
    z_bb_8:
    return zT_26;
    z_bb_9:
    zT_28 = zT_26.data.payload;
    goto z_bb_10;
    z_bb_10:
    eu_payload = zT_28;
    zT_29 = self->store;
    zT_41 = 0;
    zT_32 = kw.span_start;
    zT_44 = kw.span_start;
    zT_45 = kw.span_len;
    zT_34 = es;
    zT_35 = eu_payload;
    zT_48 = 0;
    zT_50 = 0;
    zT_52 = zF_6C9FF72F_astStoreAddNode(zT_29, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_41), zT_32, (unsigned int)(zT_44 + (unsigned int)((unsigned int)zT_45)), zT_34, zT_35, (unsigned int)((unsigned int)zT_48), (unsigned int)((unsigned int)zT_50));
    zT_53.data.payload = zT_52;
    zT_53.is_error = 0;
    return zT_53;
    z_bb_11:
    zT_61 = zT_59.data.err;
    zT_62.data.err = zT_61;
    zT_62.is_error = 1;
    return zT_62;
    z_bb_12:
    zT_63 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    (void)zT_63;
    zT_65 = self;
    zT_69 = zF_5578C74F_parserExpect(zT_65, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_70 = zT_69.is_error;
    if (zT_70) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_71 = zT_69.data.err;
    zT_72.data.err = zT_71;
    zT_72.is_error = 1;
    return zT_72;
    z_bb_15:
    zT_73 = zT_69.data.payload;
    goto z_bb_16;
    z_bb_16:
    name_tok = zT_73;
    zT_75 = self;
    zT_76 = name_tok;
    zT_77 = zF_ED2167CA_parserInternParseTo(zT_75, zT_76);
    name_id = zT_77;
    zT_79 = name_tok.span_start;
    zT_80 = name_tok.span_len;
    zT_82 = zT_79 + (unsigned int)((unsigned int)zT_80);
    end = zT_82;
    zT_83 = self->store;
    zT_95 = 0;
    zT_86 = kw.span_start;
    zT_87 = end;
    zT_98 = 0;
    zT_100 = 0;
    zT_102 = 0;
    zT_91 = name_id;
    zT_104 = zF_6C9FF72F_astStoreAddNode(zT_83, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal), (unsigned char)((unsigned char)zT_95), zT_86, zT_87, (unsigned int)((unsigned int)zT_98), (unsigned int)((unsigned int)zT_100), (unsigned int)((unsigned int)zT_102), zT_91);
    zT_105.data.payload = zT_104;
    zT_105.is_error = 0;
    return zT_105;
}

/* parserParseTryExpr */
zT_3B6EA323_EU_01 zF_59C88921_parserParseTryExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned short zT_13;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_28;
    int zT_31;
    int zT_33;
    int zT_35;
    unsigned int zT_37 = 0;
    zT_3B6EA323_EU_01 zT_38;
    zT_3A355BD2_Token kw;
    unsigned int inner;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = kw.span_start;
    zT_13 = kw.span_len;
    zT_15 = zT_12 + (unsigned int)((unsigned int)zT_13);
    end_pos = zT_15;
    zT_16 = self->store;
    zT_28 = 0;
    zT_19 = kw.span_start;
    zT_20 = end_pos;
    zT_21 = inner;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = zF_6C9FF72F_astStoreAddNode(zT_16, (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr), (unsigned char)((unsigned char)zT_28), zT_19, zT_20, zT_21, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35));
    zT_38.data.payload = zT_37;
    zT_38.is_error = 0;
    return zT_38;
}

/* parserParseAnonymousLiteral */
zT_3B6EA323_EU_01 zF_9A508F9D_parserParseAnonymou(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    unsigned char zT_11;
    zT_EAC3E484_TokenKind zT_12;
    zT_B559F9DA_Parser* zT_17;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_29;
    int zT_33;
    int zT_37;
    int zT_39;
    int zT_41;
    unsigned int zT_43 = 0;
    zT_3B6EA323_EU_01 zT_44;
    unsigned int zT_46;
    zT_B559F9DA_Parser* zT_47;
    zT_08A61393_EU_1 zT_48 = {0};
    unsigned char zT_49;
    int zT_50;
    zT_3B6EA323_EU_01 zT_51;
    zT_B559F9DA_Parser* zT_54;
    zT_CB78802F_EU_49 zT_58 = {0};
    unsigned char zT_59;
    int zT_60;
    zT_3B6EA323_EU_01 zT_61;
    zT_2B3424E9_ParseToken zT_62;
    zT_B559F9DA_Parser* zT_64;
    unsigned int zT_65;
    unsigned int zT_66 = 0;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_70;
    unsigned int zT_75;
    int zT_79;
    unsigned int zT_82;
    unsigned short zT_83;
    int zT_86;
    int zT_88;
    int zT_90;
    unsigned int zT_92 = 0;
    zT_3B6EA323_EU_01 zT_93;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token peek;
    unsigned int payload;
    unsigned int saved_child_len;
    zT_2B3424E9_ParseToken rbrace;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    peek = zT_6;
    zT_7 = peek.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_12 = peek.kind;
    zT_11 = zT_12 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = self;
    zT_18 = zF_D1EA41E6_parserParseFieldIni(zT_17);
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_46 = self->child_buf_len;
    saved_child_len = zT_46;
    zT_47 = self;
    zT_48 = zF_E360EDB5_parserParseExprList(zT_47);
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    return zT_18;
    z_bb_7:
    zT_20 = zT_18.data.payload;
    goto z_bb_8;
    z_bb_8:
    payload = zT_20;
    zT_21 = self->store;
    zT_33 = 0;
    zT_24 = dot.span_start;
    zT_25 = self->last_end;
    zT_37 = 0;
    zT_39 = 0;
    zT_41 = 0;
    zT_29 = payload;
    zT_43 = zF_6C9FF72F_astStoreAddNode(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_33), zT_24, zT_25, (unsigned int)((unsigned int)zT_37), (unsigned int)((unsigned int)zT_39), (unsigned int)((unsigned int)zT_41), zT_29);
    zT_44.data.payload = zT_43;
    zT_44.is_error = 0;
    return zT_44;
    z_bb_9:
    zT_50 = zT_48.err;
    zT_51.data.err = zT_50;
    zT_51.is_error = 1;
    return zT_51;
    z_bb_10:
    goto z_bb_11;
    z_bb_11:
    zT_54 = self;
    zT_58 = zF_5578C74F_parserExpect(zT_54, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_60 = zT_58.data.err;
    zT_61.data.err = zT_60;
    zT_61.is_error = 1;
    return zT_61;
    z_bb_13:
    zT_62 = zT_58.data.payload;
    goto z_bb_14;
    z_bb_14:
    rbrace = zT_62;
    zT_64 = self;
    zT_65 = saved_child_len;
    zT_66 = zF_7EC69633_parserListEnd(zT_64, zT_65);
    payload = zT_66;
    zT_67 = self->store;
    zT_79 = 0;
    zT_70 = dot.span_start;
    zT_82 = rbrace.span_start;
    zT_83 = rbrace.span_len;
    zT_86 = 0;
    zT_88 = 0;
    zT_90 = 0;
    zT_75 = payload;
    zT_92 = zF_6C9FF72F_astStoreAddNode(zT_67, (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal), (unsigned char)((unsigned char)zT_79), zT_70, (unsigned int)(zT_82 + (unsigned int)((unsigned int)zT_83)), (unsigned int)((unsigned int)zT_86), (unsigned int)((unsigned int)zT_88), (unsigned int)((unsigned int)zT_90), zT_75);
    zT_93.data.payload = zT_92;
    zT_93.is_error = 0;
    return zT_93;
}

/* parserParseEnumLiteral */
zT_3B6EA323_EU_01 zF_BD525F87_parserParseEnumLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_B559F9DA_Parser* zT_7;
    zT_CB78802F_EU_49 zT_11 = {0};
    unsigned char zT_12;
    int zT_13;
    zT_3B6EA323_EU_01 zT_14;
    zT_2B3424E9_ParseToken zT_15;
    unsigned int zT_17;
    unsigned short zT_18;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_85CBA4DB_TokenValue zT_29;
    unsigned int zT_32 = 0;
    zT_3B6EA323_EU_01 zT_33;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token name_tok;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    name_tok = zT_6;
    zT_7 = self;
    zT_11 = zF_5578C74F_parserExpect(zT_7, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = zT_11.data.err;
    zT_14.data.err = zT_13;
    zT_14.is_error = 1;
    return zT_14;
    z_bb_2:
    zT_15 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_15;
    zT_17 = name_tok.span_start;
    zT_18 = name_tok.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end_pos = zT_20;
    zT_21 = self->store;
    zT_29 = name_tok.value;
    zT_23 = zT_29.string_id;
    zT_24 = dot.span_start;
    zT_25 = end_pos;
    zT_32 = zF_1DF77BD4_astStoreAddIdentifi(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal), zT_23, zT_24, zT_25);
    zT_33.data.payload = zT_32;
    zT_33.is_error = 0;
    return zT_33;
}

/* parserParseArrayLiteral */
zT_3B6EA323_EU_01 zF_DE101A45_parserParseArrayLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_3B6EA323_EU_01 zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_08A61393_EU_1 zT_21 = {0};
    unsigned char zT_22;
    int zT_23;
    zT_3B6EA323_EU_01 zT_24;
    zT_B559F9DA_Parser* zT_27;
    zT_CB78802F_EU_49 zT_31 = {0};
    unsigned char zT_32;
    int zT_33;
    zT_3B6EA323_EU_01 zT_34;
    zT_2B3424E9_ParseToken zT_35;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_B559F9DA_Parser* zT_41;
    unsigned int zT_42;
    unsigned int zT_43 = 0;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned int zT_52;
    int zT_56;
    unsigned int zT_59;
    unsigned short zT_60;
    int zT_63;
    int zT_65;
    unsigned int zT_67 = 0;
    zT_3B6EA323_EU_01 zT_68;
    zT_3A355BD2_Token tok;
    unsigned int type_node;
    unsigned int saved_child_len;
    zT_2B3424E9_ParseToken rbrace;
    zT_8F083A69_Slice_zT_0B42B2F8_u gap;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_2BC32683_parserParseBracketT(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    type_node = zT_8;
    zT_9 = self;
    zT_10 = zF_068A2DE5_parserPeek(zT_9);
    zT_11 = zT_10.kind;
    if ((unsigned char)(zT_11 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.data.payload = type_node;
    zT_15.is_error = 0;
    return zT_15;
    z_bb_5:
    zT_16 = self;
    zT_17 = zF_C241B2C4_parserAdvance(zT_16);
    (void)zT_17;
    zT_19 = self->child_buf_len;
    saved_child_len = zT_19;
    zT_20 = self;
    zT_21 = zF_E360EDB5_parserParseExprList(zT_20);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_23 = zT_21.err;
    zT_24.data.err = zT_23;
    zT_24.is_error = 1;
    return zT_24;
    z_bb_7:
    goto z_bb_8;
    z_bb_8:
    zT_27 = self;
    zT_31 = zF_5578C74F_parserExpect(zT_27, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = zT_31.data.err;
    zT_34.data.err = zT_33;
    zT_34.is_error = 1;
    return zT_34;
    z_bb_10:
    zT_35 = zT_31.data.payload;
    goto z_bb_11;
    z_bb_11:
    rbrace = zT_35;
    zT_37 = "";
    zT_39 = 0;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    gap = zT_38;
    (void)gap;
    zT_41 = self;
    zT_42 = saved_child_len;
    zT_43 = zF_7EC69633_parserListEnd(zT_41, zT_42);
    payload = zT_43;
    zT_44 = self->store;
    zT_56 = 0;
    zT_47 = tok.span_start;
    zT_59 = rbrace.span_start;
    zT_60 = rbrace.span_len;
    zT_49 = type_node;
    zT_63 = 0;
    zT_65 = 0;
    zT_52 = payload;
    zT_67 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init), (unsigned char)((unsigned char)zT_56), zT_47, (unsigned int)(zT_59 + (unsigned int)((unsigned int)zT_60)), zT_49, (unsigned int)((unsigned int)zT_63), (unsigned int)((unsigned int)zT_65), zT_52);
    zT_68.data.payload = zT_67;
    zT_68.is_error = 0;
    return zT_68;
}

/* parserParseIfExpr */
zT_3B6EA323_EU_01 zF_79089D39_parserParseIfExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_39;
    zT_CF7AC512_EU_59 zT_40 = {0};
    unsigned char zT_41;
    int zT_42;
    zT_3B6EA323_EU_01 zT_43;
    zT_A68A775E_ParseCapture zT_44;
    zT_B559F9DA_Parser* zT_45;
    zT_CB78802F_EU_49 zT_49 = {0};
    unsigned char zT_50;
    int zT_51;
    zT_3B6EA323_EU_01 zT_52;
    zT_2B3424E9_ParseToken zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_57;
    unsigned int zT_62;
    int zT_66;
    unsigned int zT_69;
    unsigned short zT_70;
    int zT_73;
    int zT_75;
    int zT_77;
    unsigned int zT_80 = 0;
    zT_B559F9DA_Parser* zT_82;
    zT_3B6EA323_EU_01 zT_85 = {0};
    unsigned char zT_86;
    unsigned int zT_87;
    int zT_89;
    unsigned int zT_90;
    zT_B559F9DA_Parser* zT_91;
    zT_3A355BD2_Token zT_92 = {0};
    zT_EAC3E484_TokenKind zT_93;
    zT_B559F9DA_Parser* zT_97;
    zT_3A355BD2_Token zT_98 = {0};
    zT_B559F9DA_Parser* zT_99;
    zT_3B6EA323_EU_01 zT_102 = {0};
    unsigned char zT_103;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned char zT_107;
    zT_3A355BD2_Token zT_109;
    unsigned int zT_110;
    unsigned short zT_111;
    unsigned int zT_113;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    int zT_126;
    unsigned int zT_129 = 0;
    zT_3B6EA323_EU_01 zT_130;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_node;
    zT_A68A775E_ParseCapture cap;
    unsigned int then_body;
    unsigned int else_body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    capture_node = zT_31;
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    zT_34 = zT_33.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = self;
    zT_40 = zF_E99FEED2_parserParseCaptureN(zT_39);
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_82 = self;
    zT_85 = zF_F07C1F04_parserParseExprPrec(zT_82, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_86 = zT_85.is_error;
    if (zT_86) goto z_bb_18; else goto z_bb_19;
    z_bb_12:
    zT_42 = zT_40.data.err;
    zT_43.data.err = zT_42;
    zT_43.is_error = 1;
    return zT_43;
    z_bb_13:
    zT_44 = zT_40.data.payload;
    goto z_bb_14;
    z_bb_14:
    cap = zT_44;
    zT_45 = self;
    zT_49 = zF_5578C74F_parserExpect(zT_45, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_51 = zT_49.data.err;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_16:
    zT_53 = zT_49.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_53;
    zT_54 = self->store;
    zT_66 = 0;
    zT_57 = cap.tok_start;
    zT_69 = cap.tok_start;
    zT_70 = cap.tok_len;
    zT_73 = 0;
    zT_75 = 0;
    zT_77 = 0;
    zT_62 = cap.name_id;
    zT_80 = zF_6C9FF72F_astStoreAddNode(zT_54, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_66), zT_57, (unsigned int)(zT_69 + (unsigned int)((unsigned int)zT_70)), (unsigned int)((unsigned int)zT_73), (unsigned int)((unsigned int)zT_75), (unsigned int)((unsigned int)zT_77), zT_62);
    capture_node = zT_80;
    goto z_bb_11;
    z_bb_18:
    return zT_85;
    z_bb_19:
    zT_87 = zT_85.data.payload;
    goto z_bb_20;
    z_bb_20:
    then_body = zT_87;
    zT_89 = 0;
    zT_90 = (unsigned int)zT_89;
    else_body = zT_90;
    zT_91 = self;
    zT_92 = zF_068A2DE5_parserPeek(zT_91);
    zT_93 = zT_92.kind;
    if ((unsigned char)(zT_93 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_97 = self;
    zT_98 = zF_C241B2C4_parserAdvance(zT_97);
    (void)zT_98;
    zT_99 = self;
    zT_102 = zF_F07C1F04_parserParseExprPrec(zT_99, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_103 = zT_102.is_error;
    if (zT_103) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_106 = kw.span_start;
    end_pos = zT_106;
    zT_107 = self->last_tok_valid;
    if (zT_107) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    return zT_102;
    z_bb_24:
    zT_104 = zT_102.data.payload;
    goto z_bb_25;
    z_bb_25:
    else_body = zT_104;
    goto z_bb_22;
    z_bb_26:
    zT_109 = self->last_tok;
    last = zT_109;
    zT_110 = last.span_start;
    zT_111 = last.span_len;
    zT_113 = zT_110 + (unsigned int)((unsigned int)zT_111);
    end_pos = zT_113;
    goto z_bb_27;
    z_bb_27:
    zT_114 = self->store;
    zT_126 = 0;
    zT_117 = kw.span_start;
    zT_118 = end_pos;
    zT_119 = cond;
    zT_120 = then_body;
    zT_121 = else_body;
    zT_122 = capture_node;
    zT_129 = zF_6C9FF72F_astStoreAddNode(zT_114, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr), (unsigned char)((unsigned char)zT_126), zT_117, zT_118, zT_119, zT_120, zT_121, zT_122);
    zT_130.data.payload = zT_129;
    zT_130.is_error = 0;
    return zT_130;
}

/* parserParseSwitchExpr */
zT_3B6EA323_EU_01 zF_A9AC92CA_parserParseSwitchEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    zT_B559F9DA_Parser* zT_29;
    zT_CB78802F_EU_49 zT_33 = {0};
    unsigned char zT_34;
    int zT_35;
    zT_3B6EA323_EU_01 zT_36;
    zT_2B3424E9_ParseToken zT_37;
    unsigned int zT_39;
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_53;
    zT_3B6EA323_EU_01 zT_54 = {0};
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned int** zT_57;
    unsigned int* zT_58;
    unsigned int* zT_59;
    zT_3E40CD83_Sand* zT_60;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_66;
    zT_3A355BD2_Token zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_72;
    zT_3A355BD2_Token zT_73 = {0};
    zT_B559F9DA_Parser* zT_74;
    zT_CB78802F_EU_49 zT_78 = {0};
    unsigned char zT_79;
    int zT_80;
    zT_3B6EA323_EU_01 zT_81;
    zT_2B3424E9_ParseToken zT_82;
    zT_B559F9DA_Parser* zT_84;
    unsigned int zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_88;
    unsigned short zT_89;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_101;
    int zT_105;
    int zT_108;
    int zT_110;
    unsigned int zT_112 = 0;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    zT_3B6EA323_EU_01 zT_125;
    zT_3A355BD2_Token kw_tok;
    unsigned int cond;
    unsigned int saved_switch;
    zT_3A355BD2_Token tok;
    unsigned int prong;
    unsigned int payload;
    unsigned int end_pos;
    unsigned int pswe_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_pm;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_29 = self;
    zT_33 = zF_5578C74F_parserExpect(zT_29, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = zT_33.data.err;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_11:
    zT_37 = zT_33.data.payload;
    goto z_bb_12;
    z_bb_12:
    (void)zT_37;
    zT_39 = self->child_buf_len;
    saved_switch = zT_39;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(1)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    tok = zT_43;
    zT_44 = tok.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    zT_74 = self;
    zT_78 = zF_5578C74F_parserExpect(zT_74, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_79 = zT_78.is_error;
    if (zT_79) goto z_bb_26; else goto z_bb_27;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_48 = tok.kind;
    if ((unsigned char)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_53 = self;
    zT_54 = zF_CB4EC4E3_parserParseSwitchPr(zT_53);
    zT_55 = zT_54.is_error;
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return zT_54;
    z_bb_22:
    zT_56 = zT_54.data.payload;
    goto z_bb_23;
    z_bb_23:
    prong = zT_56;
    zT_57 = &self->child_buf_items;
    zT_58 = &self->child_buf_len;
    zT_59 = &self->child_buf_capacity;
    zT_60 = self->allocator;
    zT_61 = prong;
    zF_8B163A32_u32ArrayListAppendI(zT_57, zT_58, zT_59, zT_60, zT_61);
    zT_66 = self;
    zT_67 = zF_068A2DE5_parserPeek(zT_66);
    zT_68 = zT_67.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_72 = self;
    zT_73 = zF_C241B2C4_parserAdvance(zT_72);
    (void)zT_73;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_16;
    z_bb_26:
    zT_80 = zT_78.data.err;
    zT_81.data.err = zT_80;
    zT_81.is_error = 1;
    return zT_81;
    z_bb_27:
    zT_82 = zT_78.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_82;
    zT_84 = self;
    zT_85 = saved_switch;
    zT_86 = zF_7EC69633_parserListEnd(zT_84, zT_85);
    payload = zT_86;
    zT_88 = kw_tok.span_start;
    zT_89 = kw_tok.span_len;
    zT_91 = zT_88 + (unsigned int)((unsigned int)zT_89);
    end_pos = zT_91;
    zT_93 = self->store;
    zT_105 = 0;
    zT_96 = kw_tok.span_start;
    zT_97 = end_pos;
    zT_98 = cond;
    zT_108 = 0;
    zT_110 = 0;
    zT_101 = payload;
    zT_112 = zF_6C9FF72F_astStoreAddNode(zT_93, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex), (unsigned char)((unsigned char)zT_105), zT_96, zT_97, zT_98, (unsigned int)((unsigned int)zT_108), (unsigned int)((unsigned int)zT_110), zT_101);
    pswe_node = zT_112;
    zT_114 = "PSWE:n";
    zT_116 = 6;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    pswe_nm = zT_115;
    zT_117 = pswe_nm;
    zT_118 = pswe_node;
    zF_C914CB83_markerWriteInt(zT_117, zT_118);
    zT_120 = "p";
    zT_122 = 1;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    pswe_pm = zT_121;
    zT_123 = pswe_pm;
    zT_124 = payload;
    zF_C914CB83_markerWriteInt(zT_123, zT_124);
    zT_125.data.payload = pswe_node;
    zT_125.is_error = 0;
    return zT_125;
}

/* parserParseSwitchProng */
zT_3B6EA323_EU_01 zF_CB4EC4E3_parserParseSwitchPr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int* zT_5 = 0;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned char zT_14;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    zT_EAC3E484_TokenKind zT_17;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_B559F9DA_Parser* zT_27;
    zT_3A355BD2_Token zT_28 = {0};
    zT_EAC3E484_TokenKind zT_29;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32 = {0};
    int zT_33;
    unsigned char zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_B559F9DA_Parser* zT_42;
    zT_3B6EA323_EU_01 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_50;
    int zT_52;
    unsigned int zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3A355BD2_Token zT_61 = {0};
    zT_B559F9DA_Parser* zT_62;
    zT_3B6EA323_EU_01 zT_65 = {0};
    unsigned char zT_66;
    unsigned int zT_67;
    zT_8143F551_AstKind zT_69;
    zT_B559F9DA_Parser* zT_70;
    zT_3A355BD2_Token zT_71 = {0};
    zT_EAC3E484_TokenKind zT_72;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_B559F9DA_Parser* zT_78;
    zT_3B6EA323_EU_01 zT_81 = {0};
    unsigned char zT_82;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_85;
    zT_6B0A7D14_AstStore* zT_90;
    zT_8143F551_AstKind zT_91;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_96;
    int zT_100;
    unsigned int zT_103;
    unsigned short zT_104;
    int zT_107;
    int zT_109;
    unsigned int zT_111 = 0;
    unsigned int** zT_112;
    unsigned int* zT_113;
    unsigned int* zT_114;
    zT_3E40CD83_Sand* zT_115;
    unsigned int zT_116;
    unsigned int** zT_121;
    unsigned int* zT_122;
    unsigned int* zT_123;
    zT_3E40CD83_Sand* zT_124;
    unsigned int zT_125;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_B559F9DA_Parser* zT_137;
    zT_3A355BD2_Token zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    zT_B559F9DA_Parser* zT_143;
    int zT_145;
    zT_3A355BD2_Token zT_147 = {0};
    zT_EAC3E484_TokenKind zT_148;
    zT_B559F9DA_Parser* zT_152;
    zT_3A355BD2_Token zT_153 = {0};
    zT_B559F9DA_Parser* zT_154;
    zT_CB78802F_EU_49 zT_158 = {0};
    unsigned char zT_159;
    int zT_160;
    zT_3B6EA323_EU_01 zT_161;
    zT_2B3424E9_ParseToken zT_162;
    int zT_164;
    unsigned char zT_165;
    int zT_167;
    unsigned int zT_168;
    zT_B559F9DA_Parser* zT_169;
    zT_3A355BD2_Token zT_170 = {0};
    zT_EAC3E484_TokenKind zT_171;
    zT_B559F9DA_Parser* zT_176;
    zT_CF7AC512_EU_59 zT_177 = {0};
    unsigned char zT_178;
    int zT_179;
    zT_3B6EA323_EU_01 zT_180;
    zT_A68A775E_ParseCapture zT_181;
    zT_B559F9DA_Parser* zT_182;
    zT_CB78802F_EU_49 zT_186 = {0};
    unsigned char zT_187;
    int zT_188;
    zT_3B6EA323_EU_01 zT_189;
    zT_2B3424E9_ParseToken zT_190;
    unsigned int zT_191;
    int zT_192;
    unsigned char zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    int zT_200;
    int zT_202;
    unsigned char zT_203;
    unsigned int zT_205 = 0;
    zT_B559F9DA_Parser* zT_206;
    zT_3A355BD2_Token zT_207 = {0};
    zT_EAC3E484_TokenKind zT_208;
    zT_B559F9DA_Parser* zT_212;
    zT_3B6EA323_EU_01 zT_213 = {0};
    unsigned char zT_214;
    unsigned int zT_215;
    zT_B559F9DA_Parser* zT_216;
    zT_3B6EA323_EU_01 zT_217 = {0};
    unsigned char zT_218;
    unsigned int zT_219;
    unsigned char* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    zT_6B0A7D14_AstStore* zT_242;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_243;
    int zT_245;
    unsigned int* zT_246;
    unsigned int zT_247;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_248;
    unsigned int zT_249 = 0;
    unsigned char* zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    unsigned int zT_257;
    unsigned short zT_258;
    unsigned int zT_260;
    zT_6B0A7D14_AstStore* zT_261;
    unsigned char zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_269;
    int zT_274;
    unsigned int zT_276 = 0;
    zT_3B6EA323_EU_01 zT_277;
    zT_3A355BD2_Token start_tok;
    unsigned int* case_items;
    unsigned int case_len;
    unsigned int case_cap;
    unsigned char is_else;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_em;
    unsigned int item;
    zT_8143F551_AstKind range_kind;
    unsigned int end_item;
    unsigned int range_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb2_m;
    unsigned char flags;
    unsigned int capture_name;
    zT_A68A775E_ParseCapture cap;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpm;
    unsigned int body;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_sm;
    unsigned int items_payload;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppl_m;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    start_tok = zT_3;
    case_items = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    case_len = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    case_cap = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned char)zT_13;
    is_else = zT_14;
    zT_15 = self;
    zT_16 = zF_068A2DE5_parserPeek(zT_15);
    zT_17 = zT_16.kind;
    if ((unsigned char)(zT_17 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_22 = "PCB:T";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    pcb_tm = zT_23;
    zT_25 = pcb_tm;
    zT_27 = self;
    zT_28 = zF_068A2DE5_parserPeek(zT_27);
    zT_29 = zT_28.kind;
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)zT_29));
    zT_31 = self;
    zT_32 = zF_C241B2C4_parserAdvance(zT_31);
    (void)zT_32;
    zT_33 = 1;
    zT_34 = (unsigned char)zT_33;
    is_else = zT_34;
    goto z_bb_2;
    z_bb_2:
    zT_154 = self;
    zT_158 = zF_5578C74F_parserExpect(zT_154, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow));
    zT_159 = zT_158.is_error;
    if (zT_159) goto z_bb_29; else goto z_bb_30;
    z_bb_3:
    zT_36 = "PCB:E";
    zT_38 = 5;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    pcb_em = zT_37;
    zT_39 = pcb_em;
    zF_48AC7B3A_markerWrite(zT_39);
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(1)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_42 = self;
    zT_45 = zF_F07C1F04_parserParseExprPrec(zT_42, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    return zT_45;
    z_bb_9:
    zT_47 = zT_45.data.payload;
    goto z_bb_10;
    z_bb_10:
    item = zT_47;
    zT_50 = zT_8143F551_AstKind_err;
    range_kind = zT_50;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    end_item = zT_53;
    zT_54 = self;
    zT_55 = zF_068A2DE5_parserPeek(zT_54);
    zT_56 = zT_55.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_60 = self;
    zT_61 = zF_C241B2C4_parserAdvance(zT_60);
    (void)zT_61;
    zT_62 = self;
    zT_65 = zF_F07C1F04_parserParseExprPrec(zT_62, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    if ((unsigned char)(range_kind != (zT_8143F551_AstKind)(zT_8143F551_AstKind_err))) goto z_bb_22; else goto z_bb_24;
    z_bb_13:
    zT_70 = self;
    zT_71 = zF_068A2DE5_parserPeek(zT_70);
    zT_72 = zT_71.kind;
    if ((unsigned char)(zT_72 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    return zT_65;
    z_bb_15:
    zT_67 = zT_65.data.payload;
    goto z_bb_16;
    z_bb_16:
    end_item = zT_67;
    zT_69 = zT_8143F551_AstKind_range_exclusive;
    range_kind = zT_69;
    goto z_bb_12;
    z_bb_17:
    zT_76 = self;
    zT_77 = zF_C241B2C4_parserAdvance(zT_76);
    (void)zT_77;
    zT_78 = self;
    zT_81 = zF_F07C1F04_parserParseExprPrec(zT_78, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    return zT_81;
    z_bb_20:
    zT_83 = zT_81.data.payload;
    goto z_bb_21;
    z_bb_21:
    end_item = zT_83;
    zT_85 = zT_8143F551_AstKind_range_inclusive;
    range_kind = zT_85;
    goto z_bb_18;
    z_bb_22:
    zT_90 = self->store;
    zT_91 = range_kind;
    zT_100 = 0;
    zT_93 = start_tok.span_start;
    zT_103 = start_tok.span_start;
    zT_104 = start_tok.span_len;
    zT_95 = item;
    zT_96 = end_item;
    zT_107 = 0;
    zT_109 = 0;
    zT_111 = zF_6C9FF72F_astStoreAddNode(zT_90, zT_91, (unsigned char)((unsigned char)zT_100), zT_93, (unsigned int)(zT_103 + (unsigned int)((unsigned int)zT_104)), zT_95, zT_96, (unsigned int)((unsigned int)zT_107), (unsigned int)((unsigned int)zT_109));
    range_node = zT_111;
    zT_112 = &case_items;
    zT_113 = &case_len;
    zT_114 = &case_cap;
    zT_115 = self->allocator;
    zT_116 = range_node;
    zF_8B163A32_u32ArrayListAppendI(zT_112, zT_113, zT_114, zT_115, zT_116);
    goto z_bb_23;
    z_bb_23:
    zT_137 = self;
    zT_138 = zF_068A2DE5_parserPeek(zT_137);
    zT_139 = zT_138.kind;
    if ((unsigned char)(zT_139 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_121 = &case_items;
    zT_122 = &case_len;
    zT_123 = &case_cap;
    zT_124 = self->allocator;
    zT_125 = item;
    zF_8B163A32_u32ArrayListAppendI(zT_121, zT_122, zT_123, zT_124, zT_125);
    zT_131 = "PCB:B";
    zT_133 = 5;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    pcb2_m = zT_132;
    zT_134 = pcb2_m;
    zF_C914CB83_markerWriteInt(zT_134, (unsigned int)((unsigned int)case_len));
    goto z_bb_23;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_143 = self;
    zT_145 = 1;
    zT_147 = zF_F685E431_parserPeekN(zT_143, (unsigned int)((unsigned int)zT_145));
    zT_148 = zT_147.kind;
    if ((unsigned char)(zT_148 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_152 = self;
    zT_153 = zF_C241B2C4_parserAdvance(zT_152);
    (void)zT_153;
    goto z_bb_7;
    z_bb_29:
    zT_160 = zT_158.data.err;
    zT_161.data.err = zT_160;
    zT_161.is_error = 1;
    return zT_161;
    z_bb_30:
    zT_162 = zT_158.data.payload;
    goto z_bb_31;
    z_bb_31:
    (void)zT_162;
    zT_164 = 0;
    zT_165 = (unsigned char)zT_164;
    flags = zT_165;
    zT_167 = 0;
    zT_168 = (unsigned int)zT_167;
    capture_name = zT_168;
    zT_169 = self;
    zT_170 = zF_068A2DE5_parserPeek(zT_169);
    zT_171 = zT_170.kind;
    if ((unsigned char)(zT_171 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_176 = self;
    zT_177 = zF_E99FEED2_parserParseCaptureN(zT_176);
    zT_178 = zT_177.is_error;
    if (zT_178) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_200 = 0;
    if ((unsigned char)(is_else != zT_200)) goto z_bb_40; else goto z_bb_41;
    z_bb_34:
    zT_179 = zT_177.data.err;
    zT_180.data.err = zT_179;
    zT_180.is_error = 1;
    return zT_180;
    z_bb_35:
    zT_181 = zT_177.data.payload;
    goto z_bb_36;
    z_bb_36:
    cap = zT_181;
    zT_182 = self;
    zT_186 = zF_5578C74F_parserExpect(zT_182, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_187 = zT_186.is_error;
    if (zT_187) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_188 = zT_186.data.err;
    zT_189.data.err = zT_188;
    zT_189.is_error = 1;
    return zT_189;
    z_bb_38:
    zT_190 = zT_186.data.payload;
    goto z_bb_39;
    z_bb_39:
    (void)zT_190;
    zT_191 = cap.name_id;
    capture_name = zT_191;
    zT_192 = 16;
    zT_193 = (unsigned char)zT_192;
    flags = zT_193;
    zT_195 = "CPT:n";
    zT_197 = 5;
    zT_196.ptr = zT_195;
    zT_196.len = zT_197;
    cpm = zT_196;
    zT_198 = cpm;
    zT_199 = capture_name;
    zF_C914CB83_markerWriteInt(zT_198, zT_199);
    goto z_bb_33;
    z_bb_40:
    zT_202 = 1;
    zT_203 = flags | zT_202;
    flags = zT_203;
    goto z_bb_41;
    z_bb_41:
    body = zT_205;
    zT_206 = self;
    zT_207 = zF_068A2DE5_parserPeek(zT_206);
    zT_208 = zT_207.kind;
    if ((unsigned char)(zT_208 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_212 = self;
    zT_213 = zF_365CA04A_parserParseBlock(zT_212);
    zT_214 = zT_213.is_error;
    if (zT_214) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    zT_221 = "PCB:n";
    zT_223 = 5;
    zT_222.ptr = zT_221;
    zT_222.len = zT_223;
    pcb_m = zT_222;
    zT_224 = pcb_m;
    zF_C914CB83_markerWriteInt(zT_224, (unsigned int)((unsigned int)case_len));
    zT_228 = "p=";
    zT_230 = 2;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    pcb_pm = zT_229;
    zT_231 = pcb_pm;
    zF_C914CB83_markerWriteInt(zT_231, (unsigned int)((unsigned int)flags));
    zT_235 = "PCB:S";
    zT_237 = 5;
    zT_236.ptr = zT_235;
    zT_236.len = zT_237;
    pcb_sm = zT_236;
    zT_238 = pcb_sm;
    zF_C914CB83_markerWriteInt(zT_238, (unsigned int)((unsigned int)case_len));
    zT_242 = self->store;
    zT_245 = 0;
    zT_246 = case_items + zT_245;
    zT_247 = case_len - zT_245;
    zT_248.ptr = zT_246;
    zT_248.len = zT_247;
    zT_243 = zT_248;
    zT_249 = zF_583E993C_astStoreAddExtraChi(zT_242, zT_243);
    items_payload = zT_249;
    zT_251 = "PPL:n";
    zT_253 = 5;
    zT_252.ptr = zT_251;
    zT_252.len = zT_253;
    ppl_m = zT_252;
    zT_254 = ppl_m;
    zT_255 = items_payload;
    zF_C914CB83_markerWriteInt(zT_254, zT_255);
    zT_257 = start_tok.span_start;
    zT_258 = start_tok.span_len;
    zT_260 = zT_257 + (unsigned int)((unsigned int)zT_258);
    end_pos = zT_260;
    zT_261 = self->store;
    zT_263 = flags;
    zT_264 = start_tok.span_start;
    zT_265 = end_pos;
    zT_266 = body;
    zT_267 = capture_name;
    zT_274 = 0;
    zT_269 = items_payload;
    zT_276 = zF_6C9FF72F_astStoreAddNode(zT_261, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_prong), zT_263, zT_264, zT_265, zT_266, zT_267, (unsigned int)((unsigned int)zT_274), zT_269);
    zT_277.data.payload = zT_276;
    zT_277.is_error = 0;
    return zT_277;
    z_bb_44:
    zT_216 = self;
    zT_217 = zF_CE2E1DC0_parserParseStmtBody(zT_216);
    zT_218 = zT_217.is_error;
    if (zT_218) goto z_bb_48; else goto z_bb_49;
    z_bb_45:
    return zT_213;
    z_bb_46:
    zT_215 = zT_213.data.payload;
    goto z_bb_47;
    z_bb_47:
    body = zT_215;
    goto z_bb_43;
    z_bb_48:
    return zT_217;
    z_bb_49:
    zT_219 = zT_217.data.payload;
    goto z_bb_50;
    z_bb_50:
    body = zT_219;
    goto z_bb_43;
}

/* parserParseTypeLeading */
zT_1ED12478_EU_196 zF_E3AE4B29_parserParseTypeLead(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_1ED12478_EU_196 zT_12;
    unsigned int zT_13;
    zT_BAEE192E_Opt_10 zT_14;
    zT_1ED12478_EU_196 zT_15;
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    unsigned char zT_22;
    int zT_23;
    zT_1ED12478_EU_196 zT_24;
    unsigned int zT_25;
    zT_BAEE192E_Opt_10 zT_26;
    zT_1ED12478_EU_196 zT_27;
    zT_EAC3E484_TokenKind zT_28;
    zT_B559F9DA_Parser* zT_32;
    zT_3B6EA323_EU_01 zT_33 = {0};
    unsigned char zT_34;
    int zT_35;
    zT_1ED12478_EU_196 zT_36;
    unsigned int zT_37;
    zT_BAEE192E_Opt_10 zT_38;
    zT_1ED12478_EU_196 zT_39;
    zT_EAC3E484_TokenKind zT_40;
    zT_B559F9DA_Parser* zT_44;
    unsigned char zT_45;
    unsigned int zT_46;
    zT_3B6EA323_EU_01 zT_47 = {0};
    unsigned char zT_48;
    int zT_49;
    zT_1ED12478_EU_196 zT_50;
    unsigned int zT_51;
    zT_BAEE192E_Opt_10 zT_52;
    zT_1ED12478_EU_196 zT_53;
    zT_EAC3E484_TokenKind zT_54;
    zT_B559F9DA_Parser* zT_58;
    int zT_60;
    zT_3B6EA323_EU_01 zT_62 = {0};
    unsigned char zT_63;
    int zT_64;
    zT_1ED12478_EU_196 zT_65;
    unsigned int zT_66;
    zT_BAEE192E_Opt_10 zT_67;
    zT_1ED12478_EU_196 zT_68;
    zT_EAC3E484_TokenKind zT_69;
    zT_B559F9DA_Parser* zT_73;
    zT_3B6EA323_EU_01 zT_74 = {0};
    unsigned char zT_75;
    int zT_76;
    zT_1ED12478_EU_196 zT_77;
    unsigned int zT_78;
    zT_BAEE192E_Opt_10 zT_79;
    zT_1ED12478_EU_196 zT_80;
    zT_EAC3E484_TokenKind zT_81;
    zT_B559F9DA_Parser* zT_85;
    int zT_87;
    zT_3B6EA323_EU_01 zT_89 = {0};
    unsigned char zT_90;
    int zT_91;
    zT_1ED12478_EU_196 zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_94;
    zT_1ED12478_EU_196 zT_95;
    zT_EAC3E484_TokenKind zT_96;
    zT_B559F9DA_Parser* zT_100;
    zT_3A355BD2_Token zT_101 = {0};
    zT_B559F9DA_Parser* zT_103;
    zT_3A355BD2_Token zT_104 = {0};
    zT_EAC3E484_TokenKind zT_105;
    zT_B559F9DA_Parser* zT_109;
    int zT_111;
    zT_3B6EA323_EU_01 zT_113 = {0};
    unsigned char zT_114;
    int zT_115;
    zT_1ED12478_EU_196 zT_116;
    unsigned int zT_117;
    zT_BAEE192E_Opt_10 zT_118;
    zT_1ED12478_EU_196 zT_119;
    zT_EAC3E484_TokenKind zT_120;
    zT_B559F9DA_Parser* zT_124;
    int zT_126;
    zT_3B6EA323_EU_01 zT_128 = {0};
    unsigned char zT_129;
    int zT_130;
    zT_1ED12478_EU_196 zT_131;
    unsigned int zT_132;
    zT_BAEE192E_Opt_10 zT_133;
    zT_1ED12478_EU_196 zT_134;
    unsigned char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_B559F9DA_Parser* zT_139;
    zT_3A355BD2_Token zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_DBF3575C_ParserError zT_142;
    zT_1ED12478_EU_196 zT_143;
    zT_BAEE192E_Opt_10 zT_144 = {0};
    zT_1ED12478_EU_196 zT_145;
    zT_3A355BD2_Token tok;
    zT_3A355BD2_Token ntok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_08083D09_parserParsePtrType(zT_8);
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_16 = tok.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_4:
    zT_13 = zT_9.data.payload;
    goto z_bb_5;
    z_bb_5:
    zT_14.has_value = 1;
    zT_14.value = zT_13;
    zT_15.data.payload = zT_14;
    zT_15.is_error = 0;
    return zT_15;
    z_bb_6:
    zT_20 = self;
    zT_21 = zF_F9036399_parserParseOptional(zT_20);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_28 = tok.kind;
    if ((unsigned char)(zT_28 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_23 = zT_21.data.err;
    zT_24.data.err = zT_23;
    zT_24.is_error = 1;
    return zT_24;
    z_bb_9:
    zT_25 = zT_21.data.payload;
    goto z_bb_10;
    z_bb_10:
    zT_26.has_value = 1;
    zT_26.value = zT_25;
    zT_27.data.payload = zT_26;
    zT_27.is_error = 0;
    return zT_27;
    z_bb_11:
    zT_32 = self;
    zT_33 = zF_B83061B7_parserParseExternFn(zT_32);
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_40 = tok.kind;
    if ((unsigned char)(zT_40 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_35 = zT_33.data.err;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_14:
    zT_37 = zT_33.data.payload;
    goto z_bb_15;
    z_bb_15:
    zT_38.has_value = 1;
    zT_38.value = zT_37;
    zT_39.data.payload = zT_38;
    zT_39.is_error = 0;
    return zT_39;
    z_bb_16:
    zT_44 = self;
    zT_46 = 0;
    zT_45 = zT_46;
    zT_47 = zF_B5C9B665_parserParseFnType(zT_44, zT_45);
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_54 = tok.kind;
    if ((unsigned char)(zT_54 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_21; else goto z_bb_22;
    z_bb_18:
    zT_49 = zT_47.data.err;
    zT_50.data.err = zT_49;
    zT_50.is_error = 1;
    return zT_50;
    z_bb_19:
    zT_51 = zT_47.data.payload;
    goto z_bb_20;
    z_bb_20:
    zT_52.has_value = 1;
    zT_52.value = zT_51;
    zT_53.data.payload = zT_52;
    zT_53.is_error = 0;
    return zT_53;
    z_bb_21:
    zT_58 = self;
    zT_60 = 0;
    zT_62 = zF_3530D6C0_parserParseStructTy(zT_58, (unsigned char)((unsigned char)zT_60));
    zT_63 = zT_62.is_error;
    if (zT_63) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_69 = tok.kind;
    if ((unsigned char)(zT_69 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    zT_64 = zT_62.data.err;
    zT_65.data.err = zT_64;
    zT_65.is_error = 1;
    return zT_65;
    z_bb_24:
    zT_66 = zT_62.data.payload;
    goto z_bb_25;
    z_bb_25:
    zT_67.has_value = 1;
    zT_67.value = zT_66;
    zT_68.data.payload = zT_67;
    zT_68.is_error = 0;
    return zT_68;
    z_bb_26:
    zT_73 = self;
    zT_74 = zF_63EC2480_parserParseEnumType(zT_73);
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_81 = tok.kind;
    if ((unsigned char)(zT_81 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_76 = zT_74.data.err;
    zT_77.data.err = zT_76;
    zT_77.is_error = 1;
    return zT_77;
    z_bb_29:
    zT_78 = zT_74.data.payload;
    goto z_bb_30;
    z_bb_30:
    zT_79.has_value = 1;
    zT_79.value = zT_78;
    zT_80.data.payload = zT_79;
    zT_80.is_error = 0;
    return zT_80;
    z_bb_31:
    zT_85 = self;
    zT_87 = 0;
    zT_89 = zF_0881F8E4_parserParseUnionTyp(zT_85, (unsigned char)((unsigned char)zT_87));
    zT_90 = zT_89.is_error;
    if (zT_90) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_96 = tok.kind;
    if ((unsigned char)(zT_96 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_packed))) goto z_bb_36; else goto z_bb_37;
    z_bb_33:
    zT_91 = zT_89.data.err;
    zT_92.data.err = zT_91;
    zT_92.is_error = 1;
    return zT_92;
    z_bb_34:
    zT_93 = zT_89.data.payload;
    goto z_bb_35;
    z_bb_35:
    zT_94.has_value = 1;
    zT_94.value = zT_93;
    zT_95.data.payload = zT_94;
    zT_95.is_error = 0;
    return zT_95;
    z_bb_36:
    zT_100 = self;
    zT_101 = zF_C241B2C4_parserAdvance(zT_100);
    (void)zT_101;
    zT_103 = self;
    zT_104 = zF_068A2DE5_parserPeek(zT_103);
    ntok = zT_104;
    zT_105 = ntok.kind;
    if ((unsigned char)(zT_105 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_144.has_value = 0;
    zT_145.data.payload = zT_144;
    zT_145.is_error = 0;
    return zT_145;
    z_bb_38:
    zT_109 = self;
    zT_111 = 1;
    zT_113 = zF_3530D6C0_parserParseStructTy(zT_109, (unsigned char)((unsigned char)zT_111));
    zT_114 = zT_113.is_error;
    if (zT_114) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_120 = ntok.kind;
    if ((unsigned char)(zT_120 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_115 = zT_113.data.err;
    zT_116.data.err = zT_115;
    zT_116.is_error = 1;
    return zT_116;
    z_bb_41:
    zT_117 = zT_113.data.payload;
    goto z_bb_42;
    z_bb_42:
    zT_118.has_value = 1;
    zT_118.value = zT_117;
    zT_119.data.payload = zT_118;
    zT_119.is_error = 0;
    return zT_119;
    z_bb_43:
    zT_124 = self;
    zT_126 = 1;
    zT_128 = zF_0881F8E4_parserParseUnionTyp(zT_124, (unsigned char)((unsigned char)zT_126));
    zT_129 = zT_128.is_error;
    if (zT_129) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_136 = "expected 'struct' or 'union' after 'packed'";
    zT_138 = 43;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    pmsg = zT_137;
    zT_139 = self;
    zT_140 = ntok;
    zT_141 = pmsg;
    zF_17DF2CA5_parserAddError(zT_139, zT_140, zT_141);
    zT_142 = 1;
    zT_143.data.err = zT_142;
    zT_143.is_error = 1;
    return zT_143;
    z_bb_45:
    zT_130 = zT_128.data.err;
    zT_131.data.err = zT_130;
    zT_131.is_error = 1;
    return zT_131;
    z_bb_46:
    zT_132 = zT_128.data.payload;
    goto z_bb_47;
    z_bb_47:
    zT_133.has_value = 1;
    zT_133.value = zT_132;
    zT_134.data.payload = zT_133;
    zT_134.is_error = 0;
    return zT_134;
}

/* parserParseType */
zT_3B6EA323_EU_01 zF_CBDBFE85_parserParseType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_1ED12478_EU_196 zT_6 = {0};
    unsigned char zT_7;
    int zT_8;
    zT_3B6EA323_EU_01 zT_9;
    zT_BAEE192E_Opt_10 zT_10;
    unsigned char zT_11;
    zT_3B6EA323_EU_01 zT_13;
    zT_EAC3E484_TokenKind zT_14;
    zT_B559F9DA_Parser* zT_18;
    zT_3B6EA323_EU_01 zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    zT_B559F9DA_Parser* zT_24;
    zT_3B6EA323_EU_01 zT_25 = {0};
    zT_EAC3E484_TokenKind zT_26;
    zT_B559F9DA_Parser* zT_31;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_B559F9DA_Parser* zT_44;
    zT_3B6EA323_EU_01 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_51;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_60;
    unsigned int zT_63;
    unsigned short zT_64;
    int zT_67;
    int zT_69;
    unsigned int zT_71 = 0;
    zT_3B6EA323_EU_01 zT_72;
    zT_3B6EA323_EU_01 zT_73;
    zT_EAC3E484_TokenKind zT_74;
    zT_B559F9DA_Parser* zT_79;
    zT_3A355BD2_Token zT_80 = {0};
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83;
    unsigned int zT_84 = 0;
    unsigned int zT_86;
    unsigned short zT_87;
    unsigned int zT_89;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_99 = 0;
    zT_3B6EA323_EU_01 zT_100;
    zT_B559F9DA_Parser* zT_102;
    zT_3B6EA323_EU_01 zT_103 = {0};
    unsigned char zT_104;
    unsigned int zT_105;
    zT_B559F9DA_Parser* zT_106;
    zT_3A355BD2_Token zT_107 = {0};
    zT_EAC3E484_TokenKind zT_108;
    zT_B559F9DA_Parser* zT_112;
    zT_3A355BD2_Token zT_113 = {0};
    zT_B559F9DA_Parser* zT_115;
    zT_3B6EA323_EU_01 zT_116 = {0};
    unsigned char zT_117;
    unsigned int zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    int zT_131;
    unsigned int zT_134;
    unsigned short zT_135;
    int zT_138;
    int zT_140;
    unsigned int zT_142 = 0;
    zT_3B6EA323_EU_01 zT_143;
    zT_3B6EA323_EU_01 zT_144;
    zT_3A355BD2_Token tok;
    zT_BAEE192E_Opt_10 leading;
    unsigned int n;
    unsigned int es;
    unsigned int payload;
    zT_3A355BD2_Token at;
    unsigned int aid;
    unsigned int aend;
    unsigned int base;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_E3AE4B29_parserParseTypeLead(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = zT_6.data.err;
    zT_9.data.err = zT_8;
    zT_9.is_error = 1;
    return zT_9;
    z_bb_2:
    zT_10 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    leading = zT_10;
    zT_11 = leading.has_value;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    n = leading.value;
    zT_13.data.payload = n;
    zT_13.is_error = 0;
    return zT_13;
    z_bb_5:
    zT_14 = tok.kind;
    if ((unsigned char)(zT_14 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = self;
    zT_19 = zF_2BC32683_parserParseBracketT(zT_18);
    return zT_19;
    z_bb_7:
    zT_20 = tok.kind;
    if ((unsigned char)(zT_20 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = self;
    zT_25 = zF_33E5ECC8_parserParseErrorUni(zT_24);
    return zT_25;
    z_bb_9:
    zT_26 = tok.kind;
    if ((unsigned char)(zT_26 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_31 = self;
    zT_32 = zF_BFAD1973_parserParseErrorSet(zT_31);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_74 = tok.kind;
    if ((unsigned char)(zT_74 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_20; else goto z_bb_21;
    z_bb_12:
    return zT_32;
    z_bb_13:
    zT_34 = zT_32.data.payload;
    goto z_bb_14;
    z_bb_14:
    es = zT_34;
    zT_35 = self;
    zT_36 = zF_068A2DE5_parserPeek(zT_35);
    zT_37 = zT_36.kind;
    if ((unsigned char)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    zT_44 = self;
    zT_45 = zF_CBDBFE85_parserParseType(zT_44);
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_73.data.payload = es;
    zT_73.is_error = 0;
    return zT_73;
    z_bb_17:
    return zT_45;
    z_bb_18:
    zT_47 = zT_45.data.payload;
    goto z_bb_19;
    z_bb_19:
    payload = zT_47;
    zT_48 = self->store;
    zT_60 = 0;
    zT_51 = tok.span_start;
    zT_63 = tok.span_start;
    zT_64 = tok.span_len;
    zT_53 = es;
    zT_54 = payload;
    zT_67 = 0;
    zT_69 = 0;
    zT_71 = zF_6C9FF72F_astStoreAddNode(zT_48, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_60), zT_51, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_53, zT_54, (unsigned int)((unsigned int)zT_67), (unsigned int)((unsigned int)zT_69));
    zT_72.data.payload = zT_71;
    zT_72.is_error = 0;
    return zT_72;
    z_bb_20:
    zT_79 = self;
    zT_80 = zF_C241B2C4_parserAdvance(zT_79);
    at = zT_80;
    zT_82 = self;
    zT_83 = at;
    zT_84 = zF_9DDDA188_parserInternTokenTe(zT_82, zT_83);
    aid = zT_84;
    zT_86 = at.span_start;
    zT_87 = at.span_len;
    zT_89 = zT_86 + (unsigned int)((unsigned int)zT_87);
    aend = zT_89;
    zT_90 = self->store;
    zT_92 = aid;
    zT_93 = at.span_start;
    zT_94 = aend;
    zT_99 = zF_1DF77BD4_astStoreAddIdentifi(zT_90, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_92, zT_93, zT_94);
    zT_100.data.payload = zT_99;
    zT_100.is_error = 0;
    return zT_100;
    z_bb_21:
    zT_102 = self;
    zT_103 = zF_C8A1E2C6_parserParseTypeName(zT_102);
    zT_104 = zT_103.is_error;
    if (zT_104) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return zT_103;
    z_bb_23:
    zT_105 = zT_103.data.payload;
    goto z_bb_24;
    z_bb_24:
    base = zT_105;
    zT_106 = self;
    zT_107 = zF_068A2DE5_parserPeek(zT_106);
    zT_108 = zT_107.kind;
    if ((unsigned char)(zT_108 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_112 = self;
    zT_113 = zF_C241B2C4_parserAdvance(zT_112);
    (void)zT_113;
    zT_115 = self;
    zT_116 = zF_CBDBFE85_parserParseType(zT_115);
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_144.data.payload = base;
    zT_144.is_error = 0;
    return zT_144;
    z_bb_27:
    return zT_116;
    z_bb_28:
    zT_118 = zT_116.data.payload;
    goto z_bb_29;
    z_bb_29:
    payload = zT_118;
    zT_119 = self->store;
    zT_131 = 0;
    zT_122 = tok.span_start;
    zT_134 = tok.span_start;
    zT_135 = tok.span_len;
    zT_124 = base;
    zT_125 = payload;
    zT_138 = 0;
    zT_140 = 0;
    zT_142 = zF_6C9FF72F_astStoreAddNode(zT_119, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_131), zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124, zT_125, (unsigned int)((unsigned int)zT_138), (unsigned int)((unsigned int)zT_140));
    zT_143.data.payload = zT_142;
    zT_143.is_error = 0;
    return zT_143;
}

/* parserParsePtrQualifiers */
unsigned char zF_0FA83230_parserParsePtrQuali(zT_B559F9DA_Parser* self) {
    int zT_2;
    unsigned char zT_3;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    int zT_13;
    unsigned char zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    int zT_24;
    unsigned char zT_26;
    unsigned char flags;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    flags = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return flags;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_13 = 1;
    zT_15 = flags | (unsigned char)((unsigned char)zT_13);
    flags = zT_15;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_16 = self;
    zT_17 = zF_068A2DE5_parserPeek(zT_16);
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_volatile))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_22 = self;
    zT_23 = zF_C241B2C4_parserAdvance(zT_22);
    (void)zT_23;
    zT_24 = 2;
    zT_26 = flags | (unsigned char)((unsigned char)zT_24);
    flags = zT_26;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    goto z_bb_3;
}

/* parserParsePtrType */
zT_3B6EA323_EU_01 zF_08083D09_parserParsePtrType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    unsigned char zT_6 = 0;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_26;
    unsigned short zT_27;
    int zT_30;
    int zT_32;
    int zT_34;
    unsigned int zT_36 = 0;
    zT_3B6EA323_EU_01 zT_37;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_0FA83230_parserParsePtrQuali(zT_5);
    flags = zT_6;
    zT_8 = self;
    zT_9 = zF_CBDBFE85_parserParseType(zT_8);
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    base = zT_11;
    end_pos = base;
    (void)end_pos;
    zT_13 = self->store;
    zT_15 = flags;
    zT_16 = tok.span_start;
    zT_26 = tok.span_start;
    zT_27 = tok.span_len;
    zT_18 = base;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = zF_6C9FF72F_astStoreAddNode(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type), zT_15, zT_16, (unsigned int)(zT_26 + (unsigned int)((unsigned int)zT_27)), zT_18, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34));
    zT_37.data.payload = zT_36;
    zT_37.is_error = 0;
    return zT_37;
}

/* parserParseBracketType */
zT_3B6EA323_EU_01 zF_2BC32683_parserParseBracketT(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11 = {0};
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_16 = {0};
    unsigned char zT_17;
    int zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_2B3424E9_ParseToken zT_20;
    zT_B559F9DA_Parser* zT_22;
    unsigned char zT_23 = 0;
    zT_B559F9DA_Parser* zT_25;
    zT_3B6EA323_EU_01 zT_26 = {0};
    unsigned char zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_42;
    unsigned short zT_43;
    int zT_46;
    int zT_48;
    int zT_50;
    unsigned int zT_52 = 0;
    zT_3B6EA323_EU_01 zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3A355BD2_Token zT_61 = {0};
    int zT_63;
    unsigned char zT_64;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    int zT_73;
    unsigned char zT_74;
    zT_B559F9DA_Parser* zT_76;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned int zT_93;
    unsigned short zT_94;
    int zT_97;
    int zT_99;
    int zT_101;
    unsigned int zT_103 = 0;
    zT_3B6EA323_EU_01 zT_104;
    zT_B559F9DA_Parser* zT_106;
    zT_3B6EA323_EU_01 zT_109 = {0};
    unsigned char zT_110;
    unsigned int zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_CB78802F_EU_49 zT_116 = {0};
    unsigned char zT_117;
    int zT_118;
    zT_3B6EA323_EU_01 zT_119;
    zT_2B3424E9_ParseToken zT_120;
    zT_B559F9DA_Parser* zT_122;
    zT_3B6EA323_EU_01 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_129;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_138;
    unsigned int zT_141;
    unsigned short zT_142;
    int zT_145;
    int zT_147;
    unsigned int zT_149 = 0;
    zT_3B6EA323_EU_01 zT_150;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int size_expr;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = zF_C241B2C4_parserAdvance(zT_10);
    (void)zT_11;
    zT_12 = self;
    zT_16 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_54 = self;
    zT_55 = zF_068A2DE5_parserPeek(zT_54);
    zT_56 = zT_55.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_18 = zT_16.data.err;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_4:
    zT_20 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_20;
    zT_22 = self;
    zT_23 = zF_0FA83230_parserParsePtrQuali(zT_22);
    flags = zT_23;
    zT_25 = self;
    zT_26 = zF_CBDBFE85_parserParseType(zT_25);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return zT_26;
    z_bb_7:
    zT_28 = zT_26.data.payload;
    goto z_bb_8;
    z_bb_8:
    base = zT_28;
    zT_29 = self->store;
    zT_31 = flags;
    zT_32 = tok.span_start;
    zT_42 = tok.span_start;
    zT_43 = tok.span_len;
    zT_34 = base;
    zT_46 = 0;
    zT_48 = 0;
    zT_50 = 0;
    zT_52 = zF_6C9FF72F_astStoreAddNode(zT_29, (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type), zT_31, zT_32, (unsigned int)(zT_42 + (unsigned int)((unsigned int)zT_43)), zT_34, (unsigned int)((unsigned int)zT_46), (unsigned int)((unsigned int)zT_48), (unsigned int)((unsigned int)zT_50));
    zT_53.data.payload = zT_52;
    zT_53.is_error = 0;
    return zT_53;
    z_bb_9:
    zT_60 = self;
    zT_61 = zF_C241B2C4_parserAdvance(zT_60);
    (void)zT_61;
    zT_63 = 0;
    zT_64 = (unsigned char)zT_63;
    flags = zT_64;
    zT_65 = self;
    zT_66 = zF_068A2DE5_parserPeek(zT_65);
    zT_67 = zT_66.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_106 = self;
    zT_109 = zF_F07C1F04_parserParseExprPrec(zT_106, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_110 = zT_109.is_error;
    if (zT_110) goto z_bb_16; else goto z_bb_17;
    z_bb_11:
    zT_71 = self;
    zT_72 = zF_C241B2C4_parserAdvance(zT_71);
    (void)zT_72;
    zT_73 = 1;
    zT_74 = (unsigned char)zT_73;
    flags = zT_74;
    goto z_bb_12;
    z_bb_12:
    zT_76 = self;
    zT_77 = zF_CBDBFE85_parserParseType(zT_76);
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return zT_77;
    z_bb_14:
    zT_79 = zT_77.data.payload;
    goto z_bb_15;
    z_bb_15:
    base = zT_79;
    zT_80 = self->store;
    zT_82 = flags;
    zT_83 = tok.span_start;
    zT_93 = tok.span_start;
    zT_94 = tok.span_len;
    zT_85 = base;
    zT_97 = 0;
    zT_99 = 0;
    zT_101 = 0;
    zT_103 = zF_6C9FF72F_astStoreAddNode(zT_80, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type), zT_82, zT_83, (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94)), zT_85, (unsigned int)((unsigned int)zT_97), (unsigned int)((unsigned int)zT_99), (unsigned int)((unsigned int)zT_101));
    zT_104.data.payload = zT_103;
    zT_104.is_error = 0;
    return zT_104;
    z_bb_16:
    return zT_109;
    z_bb_17:
    zT_111 = zT_109.data.payload;
    goto z_bb_18;
    z_bb_18:
    size_expr = zT_111;
    zT_112 = self;
    zT_116 = zF_5578C74F_parserExpect(zT_112, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_118 = zT_116.data.err;
    zT_119.data.err = zT_118;
    zT_119.is_error = 1;
    return zT_119;
    z_bb_20:
    zT_120 = zT_116.data.payload;
    goto z_bb_21;
    z_bb_21:
    (void)zT_120;
    zT_122 = self;
    zT_123 = zF_CBDBFE85_parserParseType(zT_122);
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return zT_123;
    z_bb_23:
    zT_125 = zT_123.data.payload;
    goto z_bb_24;
    z_bb_24:
    base = zT_125;
    zT_126 = self->store;
    zT_138 = 0;
    zT_129 = tok.span_start;
    zT_141 = tok.span_start;
    zT_142 = tok.span_len;
    zT_131 = base;
    zT_132 = size_expr;
    zT_145 = 0;
    zT_147 = 0;
    zT_149 = zF_6C9FF72F_astStoreAddNode(zT_126, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type), (unsigned char)((unsigned char)zT_138), zT_129, (unsigned int)(zT_141 + (unsigned int)((unsigned int)zT_142)), zT_131, zT_132, (unsigned int)((unsigned int)zT_145), (unsigned int)((unsigned int)zT_147));
    zT_150.data.payload = zT_149;
    zT_150.is_error = 0;
    return zT_150;
}

/* parserParseOptionalType */
zT_3B6EA323_EU_01 zF_F9036399_parserParseOptional(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_14;
    int zT_21;
    unsigned int zT_24;
    unsigned short zT_25;
    int zT_28;
    int zT_30;
    int zT_32;
    unsigned int zT_34 = 0;
    zT_3B6EA323_EU_01 zT_35;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_21 = 0;
    zT_12 = tok.span_start;
    zT_24 = tok.span_start;
    zT_25 = tok.span_len;
    zT_14 = payload;
    zT_28 = 0;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type), (unsigned char)((unsigned char)zT_21), zT_12, (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25)), zT_14, (unsigned int)((unsigned int)zT_28), (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32));
    zT_35.data.payload = zT_34;
    zT_35.is_error = 0;
    return zT_35;
}

/* parserParseErrorUnionType */
zT_3B6EA323_EU_01 zF_33E5ECC8_parserParseErrorUni(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_15;
    int zT_21;
    unsigned int zT_24;
    unsigned short zT_25;
    int zT_28;
    int zT_30;
    int zT_32;
    unsigned int zT_34 = 0;
    zT_3B6EA323_EU_01 zT_35;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_21 = 0;
    zT_12 = tok.span_start;
    zT_24 = tok.span_start;
    zT_25 = tok.span_len;
    zT_28 = 0;
    zT_15 = payload;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_21), zT_12, (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25)), (unsigned int)((unsigned int)zT_28), zT_15, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32));
    zT_35.data.payload = zT_34;
    zT_35.is_error = 0;
    return zT_35;
}

/* parserParseExternFnType */
zT_3B6EA323_EU_01 zF_B83061B7_parserParseExternFn(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    unsigned int zT_4;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16;
    zT_85CBA4DB_TokenValue zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20 = {0};
    zT_B559F9DA_Parser* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned char zT_23 = 0;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_B559F9DA_Parser* zT_30;
    zT_3A355BD2_Token zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    int zT_34;
    unsigned int zT_36;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    zT_EAC3E484_TokenKind zT_40;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_DBF3575C_ParserError zT_51;
    zT_3B6EA323_EU_01 zT_52;
    zT_B559F9DA_Parser* zT_53;
    unsigned char zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u efm;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = 0;
    call_conv = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    str_tok = zT_13;
    zT_15 = self->interner;
    zT_18 = str_tok.value;
    zT_16 = zT_18.string_id;
    zT_20 = zF_9134020D_stringInternerGet(zT_15, zT_16);
    text = zT_20;
    zT_21 = self;
    zT_22 = text;
    zT_23 = zF_A095D9EA_parserClassifyCallC(zT_21, zT_22);
    call_conv = zT_23;
    if ((unsigned char)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = self;
    zT_39 = zF_068A2DE5_parserPeek(zT_38);
    nt = zT_39;
    zT_40 = nt.kind;
    if ((unsigned char)(zT_40 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_27 = "unknown calling convention in `extern`";
    zT_29 = 38;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ucv = zT_28;
    zT_30 = self;
    zT_31 = str_tok;
    zT_34 = 3045;
    zT_33 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_30, zT_31, (unsigned short)((unsigned short)zT_34), zT_33);
    zT_36 = 0;
    call_conv = zT_36;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = "expected 'fn' after extern calling convention";
    zT_47 = 45;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    efm = zT_46;
    zT_48 = self;
    zT_49 = nt;
    zT_50 = efm;
    zF_17DF2CA5_parserAddError(zT_48, zT_49, zT_50);
    zT_51 = 1;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_6:
    zT_53 = self;
    zT_54 = call_conv;
    zT_55 = zF_B5C9B665_parserParseFnType(zT_53, zT_54);
    return zT_55;
}

/* parserParseFnType */
zT_3B6EA323_EU_01 zF_B5C9B665_parserParseFnType(zT_B559F9DA_Parser* self, unsigned char call_conv) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    unsigned int* zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_27;
    zT_3A355BD2_Token zT_28 = {0};
    zT_EAC3E484_TokenKind zT_29;
    zT_B559F9DA_Parser* zT_34;
    zT_3A355BD2_Token zT_35 = {0};
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_DBF3575C_ParserError zT_43;
    zT_3B6EA323_EU_01 zT_44;
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    unsigned char zT_51;
    zT_B559F9DA_Parser* zT_52;
    int zT_54;
    zT_3A355BD2_Token zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_61;
    zT_3A355BD2_Token zT_62 = {0};
    zT_B559F9DA_Parser* zT_63;
    zT_CB78802F_EU_49 zT_67 = {0};
    unsigned char zT_68;
    int zT_69;
    zT_3B6EA323_EU_01 zT_70;
    zT_2B3424E9_ParseToken zT_71;
    zT_B559F9DA_Parser* zT_73;
    zT_3B6EA323_EU_01 zT_74 = {0};
    unsigned char zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_77;
    unsigned int** zT_78;
    unsigned int* zT_79;
    unsigned int* zT_80;
    unsigned int zT_81;
    zT_B559F9DA_Parser* zT_85;
    zT_3A355BD2_Token zT_86 = {0};
    zT_EAC3E484_TokenKind zT_87;
    zT_B559F9DA_Parser* zT_91;
    zT_3A355BD2_Token zT_92 = {0};
    zT_B559F9DA_Parser* zT_93;
    zT_CB78802F_EU_49 zT_97 = {0};
    unsigned char zT_98;
    int zT_99;
    zT_3B6EA323_EU_01 zT_100;
    zT_2B3424E9_ParseToken zT_101;
    int zT_103;
    unsigned int zT_104;
    zT_B559F9DA_Parser* zT_105;
    zT_3A355BD2_Token zT_106 = {0};
    zT_EAC3E484_TokenKind zT_107;
    unsigned char zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_3A355BD2_Token zT_113 = {0};
    zT_EAC3E484_TokenKind zT_114;
    unsigned char zT_118;
    zT_B559F9DA_Parser* zT_119;
    zT_3A355BD2_Token zT_120 = {0};
    zT_EAC3E484_TokenKind zT_121;
    unsigned char zT_125;
    zT_B559F9DA_Parser* zT_126;
    zT_3A355BD2_Token zT_127 = {0};
    zT_EAC3E484_TokenKind zT_128;
    unsigned char zT_132;
    zT_B559F9DA_Parser* zT_133;
    zT_3A355BD2_Token zT_134 = {0};
    zT_EAC3E484_TokenKind zT_135;
    unsigned char zT_139;
    zT_B559F9DA_Parser* zT_140;
    zT_3A355BD2_Token zT_141 = {0};
    zT_EAC3E484_TokenKind zT_142;
    zT_B559F9DA_Parser* zT_146;
    zT_3B6EA323_EU_01 zT_147 = {0};
    unsigned char zT_148;
    unsigned int zT_149;
    int zT_151;
    unsigned int zT_152;
    int zT_153;
    zT_6B0A7D14_AstStore* zT_155;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_156;
    int zT_158;
    unsigned int* zT_159;
    unsigned int zT_160;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_161;
    unsigned int zT_162 = 0;
    int zT_164;
    unsigned char zT_165;
    unsigned char zT_169;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned char zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned int zT_178;
    unsigned int zT_183;
    unsigned short zT_184;
    int zT_187;
    int zT_189;
    unsigned int zT_191 = 0;
    zT_3B6EA323_EU_01 zT_192;
    zT_3A355BD2_Token tok;
    unsigned int* param_buf;
    unsigned int param_count;
    unsigned int param_cap;
    zT_3A355BD2_Token vtok;
    zT_8F083A69_Slice_zT_0B42B2F8_u v_msg;
    unsigned int p;
    unsigned int ret_type;
    unsigned int payload;
    unsigned char fn_flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    param_buf = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    param_count = zT_18;
    zT_20 = 0;
    param_cap = zT_20;
    goto z_bb_4;
    z_bb_4:
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    zT_23 = zT_22.kind;
    if ((unsigned char)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = self;
    zT_28 = zF_068A2DE5_parserPeek(zT_27);
    zT_29 = zT_28.kind;
    if ((unsigned char)(zT_29 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_93 = self;
    zT_97 = zF_5578C74F_parserExpect(zT_93, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_98 = zT_97.is_error;
    if (zT_98) goto z_bb_23; else goto z_bb_24;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_34 = self;
    zT_35 = zF_C241B2C4_parserAdvance(zT_34);
    vtok = zT_35;
    zT_37 = "varargs not allowed in function pointer types";
    zT_39 = 45;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    v_msg = zT_38;
    zT_40 = self;
    zT_41 = vtok;
    zT_42 = v_msg;
    zF_17DF2CA5_parserAddError(zT_40, zT_41, zT_42);
    zT_43 = 1;
    zT_44.data.err = zT_43;
    zT_44.is_error = 1;
    return zT_44;
    z_bb_9:
    zT_45 = self;
    zT_46 = zF_068A2DE5_parserPeek(zT_45);
    zT_47 = zT_46.kind;
    if ((unsigned char)(zT_47 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_52 = self;
    zT_54 = 1;
    zT_56 = zF_F685E431_parserPeekN(zT_52, (unsigned int)((unsigned int)zT_54));
    zT_57 = zT_56.kind;
    zT_51 = zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon);
    goto z_bb_12;
    z_bb_11:
    zT_51 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_51) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_61 = self;
    zT_62 = zF_C241B2C4_parserAdvance(zT_61);
    (void)zT_62;
    zT_63 = self;
    zT_67 = zF_5578C74F_parserExpect(zT_63, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_68 = zT_67.is_error;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_73 = self;
    zT_74 = zF_CBDBFE85_parserParseType(zT_73);
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_69 = zT_67.data.err;
    zT_70.data.err = zT_69;
    zT_70.is_error = 1;
    return zT_70;
    z_bb_16:
    zT_71 = zT_67.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_71;
    goto z_bb_14;
    z_bb_18:
    return zT_74;
    z_bb_19:
    zT_76 = zT_74.data.payload;
    goto z_bb_20;
    z_bb_20:
    p = zT_76;
    zT_77 = self;
    zT_78 = &param_buf;
    zT_79 = &param_count;
    zT_80 = &param_cap;
    zT_81 = p;
    zF_0F1462F8_parserPushU32(zT_77, zT_78, zT_79, zT_80, zT_81);
    zT_85 = self;
    zT_86 = zF_068A2DE5_parserPeek(zT_85);
    zT_87 = zT_86.kind;
    if ((unsigned char)(zT_87 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_91 = self;
    zT_92 = zF_C241B2C4_parserAdvance(zT_91);
    (void)zT_92;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_7;
    z_bb_23:
    zT_99 = zT_97.data.err;
    zT_100.data.err = zT_99;
    zT_100.is_error = 1;
    return zT_100;
    z_bb_24:
    zT_101 = zT_97.data.payload;
    goto z_bb_25;
    z_bb_25:
    (void)zT_101;
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    ret_type = zT_104;
    zT_105 = self;
    zT_106 = zF_068A2DE5_parserPeek(zT_105);
    zT_107 = zT_106.kind;
    if ((unsigned char)(zT_107 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_112 = self;
    zT_113 = zF_068A2DE5_parserPeek(zT_112);
    zT_114 = zT_113.kind;
    zT_111 = zT_114 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon);
    goto z_bb_28;
    z_bb_27:
    zT_111 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_111) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_119 = self;
    zT_120 = zF_068A2DE5_parserPeek(zT_119);
    zT_121 = zT_120.kind;
    zT_118 = zT_121 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_31;
    z_bb_30:
    zT_118 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_118) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_126 = self;
    zT_127 = zF_068A2DE5_parserPeek(zT_126);
    zT_128 = zT_127.kind;
    zT_125 = zT_128 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen);
    goto z_bb_34;
    z_bb_33:
    zT_125 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_125) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_133 = self;
    zT_134 = zF_068A2DE5_parserPeek(zT_133);
    zT_135 = zT_134.kind;
    zT_132 = zT_135 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket);
    goto z_bb_37;
    z_bb_36:
    zT_132 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_132) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_140 = self;
    zT_141 = zF_068A2DE5_parserPeek(zT_140);
    zT_142 = zT_141.kind;
    zT_139 = zT_142 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_40;
    z_bb_39:
    zT_139 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_139) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_146 = self;
    zT_147 = zF_CBDBFE85_parserParseType(zT_146);
    zT_148 = zT_147.is_error;
    if (zT_148) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_151 = 0;
    zT_152 = (unsigned int)zT_151;
    payload = zT_152;
    zT_153 = 0;
    if ((unsigned char)(param_count > (unsigned int)zT_153)) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_147;
    z_bb_44:
    zT_149 = zT_147.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type = zT_149;
    goto z_bb_42;
    z_bb_46:
    zT_155 = self->store;
    zT_158 = 0;
    zT_159 = param_buf + zT_158;
    zT_160 = param_count - zT_158;
    zT_161.ptr = zT_159;
    zT_161.len = zT_160;
    zT_156 = zT_161;
    zT_162 = zF_583E993C_astStoreAddExtraChi(zT_155, zT_156);
    payload = zT_162;
    goto z_bb_47;
    z_bb_47:
    zT_164 = 0;
    zT_165 = (unsigned char)zT_164;
    fn_flags = zT_165;
    if ((unsigned char)(call_conv == (unsigned int)(1))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_169 = fn_flags | (unsigned char)(1);
    fn_flags = zT_169;
    goto z_bb_49;
    z_bb_49:
    zT_170 = self->store;
    zT_172 = fn_flags;
    zT_173 = tok.span_start;
    zT_183 = tok.span_start;
    zT_184 = tok.span_len;
    zT_175 = ret_type;
    zT_187 = 0;
    zT_189 = 0;
    zT_178 = payload;
    zT_191 = zF_6C9FF72F_astStoreAddNode(zT_170, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type), zT_172, zT_173, (unsigned int)(zT_183 + (unsigned int)((unsigned int)zT_184)), zT_175, (unsigned int)((unsigned int)zT_187), (unsigned int)((unsigned int)zT_189), zT_178);
    zT_192.data.payload = zT_191;
    zT_192.is_error = 0;
    return zT_192;
}

/* parserParseErrorSetDecl */
zT_3B6EA323_EU_01 zF_BFAD1973_parserParseErrorSet(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = tok;
    zT_6 = zF_2C55CABB_parserParseErrorSet(zT_4, zT_5);
    return zT_6;
}

/* parserParseErrorSetDeclBody */
zT_3B6EA323_EU_01 zF_2C55CABB_parserParseErrorSet(zT_B559F9DA_Parser* self, zT_3A355BD2_Token kw) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_6 = {0};
    unsigned char zT_7;
    int zT_8;
    zT_3B6EA323_EU_01 zT_9;
    zT_2B3424E9_ParseToken zT_10;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    zT_B559F9DA_Parser* zT_25;
    zT_CB78802F_EU_49 zT_29 = {0};
    unsigned char zT_30;
    int zT_31;
    zT_3B6EA323_EU_01 zT_32;
    zT_2B3424E9_ParseToken zT_33;
    zT_B559F9DA_Parser* zT_35;
    zT_2B3424E9_ParseToken zT_36;
    unsigned int zT_37 = 0;
    zT_B559F9DA_Parser* zT_38;
    unsigned int** zT_39;
    unsigned int* zT_40;
    unsigned int* zT_41;
    unsigned int zT_42;
    zT_B559F9DA_Parser* zT_46;
    zT_3A355BD2_Token zT_47 = {0};
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53 = {0};
    zT_B559F9DA_Parser* zT_54;
    zT_CB78802F_EU_49 zT_58 = {0};
    unsigned char zT_59;
    int zT_60;
    zT_3B6EA323_EU_01 zT_61;
    zT_2B3424E9_ParseToken zT_62;
    int zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_6B0A7D14_AstStore* zT_68;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_69;
    int zT_71;
    unsigned int* zT_72;
    unsigned int zT_73;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_74;
    unsigned int zT_75 = 0;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_79;
    unsigned int zT_84;
    int zT_88;
    unsigned int zT_91;
    unsigned short zT_92;
    int zT_95;
    int zT_97;
    int zT_99;
    unsigned int zT_101 = 0;
    zT_3B6EA323_EU_01 zT_102;
    unsigned int* member_buf;
    unsigned int member_count;
    unsigned int member_cap;
    zT_2B3424E9_ParseToken tag_tok;
    unsigned int tag_id;
    unsigned int payload;
    zT_2 = self;
    zT_6 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = zT_6.data.err;
    zT_9.data.err = zT_8;
    zT_9.is_error = 1;
    return zT_9;
    z_bb_2:
    zT_10 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_10;
    zT_12 = 0;
    member_buf = (unsigned int*)zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    member_count = zT_15;
    zT_17 = 0;
    member_cap = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_18 = self;
    zT_19 = zF_068A2DE5_parserPeek(zT_18);
    zT_20 = zT_19.kind;
    if ((unsigned char)(zT_20 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = self;
    zT_29 = zF_5578C74F_parserExpect(zT_25, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_54 = self;
    zT_58 = zF_5578C74F_parserExpect(zT_54, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_13; else goto z_bb_14;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_31 = zT_29.data.err;
    zT_32.data.err = zT_31;
    zT_32.is_error = 1;
    return zT_32;
    z_bb_9:
    zT_33 = zT_29.data.payload;
    goto z_bb_10;
    z_bb_10:
    tag_tok = zT_33;
    zT_35 = self;
    zT_36 = tag_tok;
    zT_37 = zF_ED2167CA_parserInternParseTo(zT_35, zT_36);
    tag_id = zT_37;
    zT_38 = self;
    zT_39 = &member_buf;
    zT_40 = &member_count;
    zT_41 = &member_cap;
    zT_42 = tag_id;
    zF_0F1462F8_parserPushU32(zT_38, zT_39, zT_40, zT_41, zT_42);
    zT_46 = self;
    zT_47 = zF_068A2DE5_parserPeek(zT_46);
    zT_48 = zT_47.kind;
    if ((unsigned char)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_52 = self;
    zT_53 = zF_C241B2C4_parserAdvance(zT_52);
    (void)zT_53;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_60 = zT_58.data.err;
    zT_61.data.err = zT_60;
    zT_61.is_error = 1;
    return zT_61;
    z_bb_14:
    zT_62 = zT_58.data.payload;
    goto z_bb_15;
    z_bb_15:
    (void)zT_62;
    zT_64 = 0;
    zT_65 = (unsigned int)zT_64;
    payload = zT_65;
    zT_66 = 0;
    if ((unsigned char)(member_count > (unsigned int)zT_66)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_68 = self->store;
    zT_71 = 0;
    zT_72 = member_buf + zT_71;
    zT_73 = member_count - zT_71;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_69 = zT_74;
    zT_75 = zF_583E993C_astStoreAddExtraChi(zT_68, zT_69);
    payload = zT_75;
    goto z_bb_17;
    z_bb_17:
    zT_76 = self->store;
    zT_88 = 0;
    zT_79 = kw.span_start;
    zT_91 = kw.span_start;
    zT_92 = kw.span_len;
    zT_95 = 0;
    zT_97 = 0;
    zT_99 = 0;
    zT_84 = payload;
    zT_101 = zF_6C9FF72F_astStoreAddNode(zT_76, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl), (unsigned char)((unsigned char)zT_88), zT_79, (unsigned int)(zT_91 + (unsigned int)((unsigned int)zT_92)), (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97), (unsigned int)((unsigned int)zT_99), zT_84);
    zT_102.data.payload = zT_101;
    zT_102.is_error = 0;
    return zT_102;
}

/* parserParseStructType */
zT_3B6EA323_EU_01 zF_3530D6C0_parserParseStructTy(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    unsigned int* zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_3A355BD2_Token zT_26 = {0};
    zT_EAC3E484_TokenKind zT_27;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    unsigned char zT_35;
    zT_EAC3E484_TokenKind zT_36;
    unsigned char zT_40;
    zT_B559F9DA_Parser* zT_41;
    int zT_43;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    unsigned char zT_50;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_B559F9DA_Parser* zT_59;
    zT_3A355BD2_Token zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    zT_DBF3575C_ParserError zT_62;
    zT_3B6EA323_EU_01 zT_63;
    unsigned char zT_64;
    zT_B559F9DA_Parser* zT_66;
    zT_CB78802F_EU_49 zT_70 = {0};
    unsigned char zT_71;
    int zT_72;
    zT_3B6EA323_EU_01 zT_73;
    zT_2B3424E9_ParseToken zT_74;
    zT_B559F9DA_Parser* zT_75;
    zT_CB78802F_EU_49 zT_79 = {0};
    unsigned char zT_80;
    int zT_81;
    zT_3B6EA323_EU_01 zT_82;
    zT_2B3424E9_ParseToken zT_83;
    zT_B559F9DA_Parser* zT_85;
    zT_2B3424E9_ParseToken zT_86;
    unsigned int zT_87 = 0;
    zT_B559F9DA_Parser* zT_89;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned int zT_102;
    int zT_106;
    unsigned int zT_109;
    unsigned short zT_110;
    int zT_113;
    int zT_115;
    unsigned int zT_117 = 0;
    zT_B559F9DA_Parser* zT_118;
    unsigned int** zT_119;
    unsigned int* zT_120;
    unsigned int* zT_121;
    unsigned int zT_122;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_B559F9DA_Parser* zT_132;
    zT_3A355BD2_Token zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_DBF3575C_ParserError zT_135;
    zT_3B6EA323_EU_01 zT_136;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_B559F9DA_Parser* zT_143;
    zT_3A355BD2_Token zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    zT_DBF3575C_ParserError zT_146;
    zT_3B6EA323_EU_01 zT_147;
    unsigned char zT_148;
    zT_B559F9DA_Parser* zT_150;
    zT_3B6EA323_EU_01 zT_151 = {0};
    unsigned char zT_152;
    unsigned int zT_153;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_158;
    unsigned int zT_160;
    int zT_167;
    unsigned int zT_170;
    unsigned short zT_171;
    int zT_174;
    int zT_176;
    int zT_178;
    unsigned int zT_180 = 0;
    zT_B559F9DA_Parser* zT_181;
    unsigned int** zT_182;
    unsigned int* zT_183;
    unsigned int* zT_184;
    unsigned int zT_185;
    zT_B559F9DA_Parser* zT_189;
    zT_3A355BD2_Token zT_190 = {0};
    zT_EAC3E484_TokenKind zT_191;
    zT_B559F9DA_Parser* zT_195;
    zT_3A355BD2_Token zT_196 = {0};
    zT_B559F9DA_Parser* zT_197;
    zT_CB78802F_EU_49 zT_201 = {0};
    unsigned char zT_202;
    int zT_203;
    zT_3B6EA323_EU_01 zT_204;
    zT_2B3424E9_ParseToken zT_205;
    int zT_207;
    unsigned int zT_208;
    int zT_209;
    zT_6B0A7D14_AstStore* zT_211;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_212;
    int zT_214;
    unsigned int* zT_215;
    unsigned int zT_216;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_217;
    unsigned int zT_218 = 0;
    int zT_220;
    unsigned char zT_221;
    unsigned char zT_225;
    unsigned char zT_229;
    zT_6B0A7D14_AstStore* zT_230;
    unsigned char zT_232;
    unsigned int zT_233;
    unsigned int zT_238;
    unsigned int zT_243;
    unsigned short zT_244;
    int zT_247;
    int zT_249;
    int zT_251;
    unsigned int zT_253 = 0;
    zT_3B6EA323_EU_01 zT_254;
    zT_3A355BD2_Token tok;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    unsigned char saw_named;
    unsigned char saw_positional;
    zT_3A355BD2_Token field_tok;
    unsigned char is_named_field;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_msg;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int name_id;
    unsigned int field_type;
    unsigned int field_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pack_msg;
    unsigned int field_type2;
    unsigned int field_node2;
    unsigned int payload;
    unsigned char flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    fields_buf = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fields_count = zT_18;
    zT_20 = 0;
    fields_cap = zT_20;
    zT_22 = 0;
    saw_named = zT_22;
    zT_24 = 0;
    saw_positional = zT_24;
    goto z_bb_4;
    z_bb_4:
    zT_25 = self;
    zT_26 = zF_068A2DE5_parserPeek(zT_25);
    zT_27 = zT_26.kind;
    if ((unsigned char)(zT_27 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    field_tok = zT_33;
    zT_35 = 0;
    is_named_field = zT_35;
    zT_36 = field_tok.kind;
    if ((unsigned char)(zT_36 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_197 = self;
    zT_201 = zF_5578C74F_parserExpect(zT_197, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_202 = zT_201.is_error;
    if (zT_202) goto z_bb_36; else goto z_bb_37;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_41 = self;
    zT_43 = 1;
    zT_45 = zF_F685E431_parserPeekN(zT_41, (unsigned int)((unsigned int)zT_43));
    zT_46 = zT_45.kind;
    zT_40 = zT_46 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon);
    goto z_bb_10;
    z_bb_9:
    zT_40 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_50 = 1;
    is_named_field = zT_50;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(is_named_field != (unsigned char)(0))) goto z_bb_13; else goto z_bb_15;
    z_bb_13:
    if ((unsigned char)(saw_positional != (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_189 = self;
    zT_190 = zF_068A2DE5_parserPeek(zT_189);
    zT_191 = zT_190.kind;
    if ((unsigned char)(zT_191 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_34; else goto z_bb_35;
    z_bb_15:
    if ((unsigned char)(saw_named != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_16:
    zT_56 = "struct fields must be all named or all positional (tuple)";
    zT_58 = 57;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    mix_msg = zT_57;
    zT_59 = self;
    zT_60 = field_tok;
    zT_61 = mix_msg;
    zF_17DF2CA5_parserAddError(zT_59, zT_60, zT_61);
    zT_62 = 1;
    zT_63.data.err = zT_62;
    zT_63.is_error = 1;
    return zT_63;
    z_bb_17:
    zT_64 = 1;
    saw_named = zT_64;
    zT_66 = self;
    zT_70 = zF_5578C74F_parserExpect(zT_66, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_72 = zT_70.data.err;
    zT_73.data.err = zT_72;
    zT_73.is_error = 1;
    return zT_73;
    z_bb_19:
    zT_74 = zT_70.data.payload;
    goto z_bb_20;
    z_bb_20:
    name_tok = zT_74;
    zT_75 = self;
    zT_79 = zF_5578C74F_parserExpect(zT_75, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_80 = zT_79.is_error;
    if (zT_80) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_81 = zT_79.data.err;
    zT_82.data.err = zT_81;
    zT_82.is_error = 1;
    return zT_82;
    z_bb_22:
    zT_83 = zT_79.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_83;
    zT_85 = self;
    zT_86 = name_tok;
    zT_87 = zF_ED2167CA_parserInternParseTo(zT_85, zT_86);
    name_id = zT_87;
    zT_89 = self;
    zT_90 = zF_CBDBFE85_parserParseType(zT_89);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return zT_90;
    z_bb_25:
    zT_92 = zT_90.data.payload;
    goto z_bb_26;
    z_bb_26:
    field_type = zT_92;
    zT_94 = self->store;
    zT_106 = 0;
    zT_97 = name_tok.span_start;
    zT_109 = name_tok.span_start;
    zT_110 = name_tok.span_len;
    zT_99 = field_type;
    zT_113 = 0;
    zT_115 = 0;
    zT_102 = name_id;
    zT_117 = zF_6C9FF72F_astStoreAddNode(zT_94, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_106), zT_97, (unsigned int)(zT_109 + (unsigned int)((unsigned int)zT_110)), zT_99, (unsigned int)((unsigned int)zT_113), (unsigned int)((unsigned int)zT_115), zT_102);
    field_node = zT_117;
    zT_118 = self;
    zT_119 = &fields_buf;
    zT_120 = &fields_count;
    zT_121 = &fields_cap;
    zT_122 = field_node;
    zF_0F1462F8_parserPushU32(zT_118, zT_119, zT_120, zT_121, zT_122);
    goto z_bb_14;
    z_bb_27:
    zT_129 = "struct fields must be all named or all positional (tuple)";
    zT_131 = 57;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    mix_msg2 = zT_130;
    zT_132 = self;
    zT_133 = field_tok;
    zT_134 = mix_msg2;
    zF_17DF2CA5_parserAddError(zT_132, zT_133, zT_134);
    zT_135 = 1;
    zT_136.data.err = zT_135;
    zT_136.is_error = 1;
    return zT_136;
    z_bb_28:
    if ((unsigned char)(is_packed != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_140 = "packed structs cannot have positional tuple fields";
    zT_142 = 50;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    pack_msg = zT_141;
    zT_143 = self;
    zT_144 = field_tok;
    zT_145 = pack_msg;
    zF_17DF2CA5_parserAddError(zT_143, zT_144, zT_145);
    zT_146 = 1;
    zT_147.data.err = zT_146;
    zT_147.is_error = 1;
    return zT_147;
    z_bb_30:
    zT_148 = 1;
    saw_positional = zT_148;
    zT_150 = self;
    zT_151 = zF_CBDBFE85_parserParseType(zT_150);
    zT_152 = zT_151.is_error;
    if (zT_152) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return zT_151;
    z_bb_32:
    zT_153 = zT_151.data.payload;
    goto z_bb_33;
    z_bb_33:
    field_type2 = zT_153;
    zT_155 = self->store;
    zT_167 = 0;
    zT_158 = field_tok.span_start;
    zT_170 = field_tok.span_start;
    zT_171 = field_tok.span_len;
    zT_160 = field_type2;
    zT_174 = 0;
    zT_176 = 0;
    zT_178 = 0;
    zT_180 = zF_6C9FF72F_astStoreAddNode(zT_155, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_167), zT_158, (unsigned int)(zT_170 + (unsigned int)((unsigned int)zT_171)), zT_160, (unsigned int)((unsigned int)zT_174), (unsigned int)((unsigned int)zT_176), (unsigned int)((unsigned int)zT_178));
    field_node2 = zT_180;
    zT_181 = self;
    zT_182 = &fields_buf;
    zT_183 = &fields_count;
    zT_184 = &fields_cap;
    zT_185 = field_node2;
    zF_0F1462F8_parserPushU32(zT_181, zT_182, zT_183, zT_184, zT_185);
    goto z_bb_14;
    z_bb_34:
    zT_195 = self;
    zT_196 = zF_C241B2C4_parserAdvance(zT_195);
    (void)zT_196;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_7;
    z_bb_36:
    zT_203 = zT_201.data.err;
    zT_204.data.err = zT_203;
    zT_204.is_error = 1;
    return zT_204;
    z_bb_37:
    zT_205 = zT_201.data.payload;
    goto z_bb_38;
    z_bb_38:
    (void)zT_205;
    zT_207 = 0;
    zT_208 = (unsigned int)zT_207;
    payload = zT_208;
    zT_209 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_209)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_211 = self->store;
    zT_214 = 0;
    zT_215 = fields_buf + zT_214;
    zT_216 = fields_count - zT_214;
    zT_217.ptr = zT_215;
    zT_217.len = zT_216;
    zT_212 = zT_217;
    zT_218 = zF_583E993C_astStoreAddExtraChi(zT_211, zT_212);
    payload = zT_218;
    goto z_bb_40;
    z_bb_40:
    zT_220 = 0;
    zT_221 = (unsigned char)zT_220;
    flags = zT_221;
    if ((unsigned char)(is_packed != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_225 = flags | (unsigned char)(16);
    flags = zT_225;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(saw_positional != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_229 = flags | (unsigned char)(32);
    flags = zT_229;
    goto z_bb_44;
    z_bb_44:
    zT_230 = self->store;
    zT_232 = flags;
    zT_233 = tok.span_start;
    zT_243 = tok.span_start;
    zT_244 = tok.span_len;
    zT_247 = 0;
    zT_249 = 0;
    zT_251 = 0;
    zT_238 = payload;
    zT_253 = zF_6C9FF72F_astStoreAddNode(zT_230, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl), zT_232, zT_233, (unsigned int)(zT_243 + (unsigned int)((unsigned int)zT_244)), (unsigned int)((unsigned int)zT_247), (unsigned int)((unsigned int)zT_249), (unsigned int)((unsigned int)zT_251), zT_238);
    zT_254.data.payload = zT_253;
    zT_254.is_error = 0;
    return zT_254;
}

/* parserParseEnumType */
zT_3B6EA323_EU_01 zF_63EC2480_parserParseEnumType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_16 = {0};
    unsigned char zT_17;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_19;
    zT_CB78802F_EU_49 zT_23 = {0};
    unsigned char zT_24;
    int zT_25;
    zT_3B6EA323_EU_01 zT_26;
    zT_2B3424E9_ParseToken zT_27;
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    unsigned int* zT_38 = 0;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    zT_B559F9DA_Parser* zT_51;
    zT_CB78802F_EU_49 zT_55 = {0};
    unsigned char zT_56;
    int zT_57;
    zT_3B6EA323_EU_01 zT_58;
    zT_2B3424E9_ParseToken zT_59;
    zT_B559F9DA_Parser* zT_61;
    zT_2B3424E9_ParseToken zT_62;
    unsigned int zT_63 = 0;
    int zT_65;
    unsigned int zT_66;
    zT_B559F9DA_Parser* zT_67;
    zT_3A355BD2_Token zT_68 = {0};
    zT_EAC3E484_TokenKind zT_69;
    zT_B559F9DA_Parser* zT_73;
    zT_3A355BD2_Token zT_74 = {0};
    zT_B559F9DA_Parser* zT_75;
    zT_3B6EA323_EU_01 zT_78 = {0};
    unsigned char zT_79;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_85;
    unsigned int zT_88;
    unsigned int zT_90;
    int zT_94;
    unsigned int zT_97;
    unsigned short zT_98;
    int zT_101;
    int zT_103;
    unsigned int zT_105 = 0;
    zT_B559F9DA_Parser* zT_106;
    unsigned int** zT_107;
    unsigned int* zT_108;
    unsigned int* zT_109;
    unsigned int zT_110;
    zT_B559F9DA_Parser* zT_114;
    zT_3A355BD2_Token zT_115 = {0};
    zT_EAC3E484_TokenKind zT_116;
    zT_B559F9DA_Parser* zT_120;
    zT_3A355BD2_Token zT_121 = {0};
    zT_B559F9DA_Parser* zT_122;
    zT_CB78802F_EU_49 zT_126 = {0};
    unsigned char zT_127;
    int zT_128;
    zT_3B6EA323_EU_01 zT_129;
    zT_2B3424E9_ParseToken zT_130;
    int zT_132;
    unsigned int zT_133;
    int zT_134;
    zT_6B0A7D14_AstStore* zT_136;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_137;
    int zT_139;
    unsigned int* zT_140;
    unsigned int zT_141;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_142;
    unsigned int zT_143 = 0;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_147;
    unsigned int zT_149;
    unsigned int zT_152;
    int zT_156;
    unsigned int zT_159;
    unsigned short zT_160;
    int zT_163;
    int zT_165;
    unsigned int zT_167 = 0;
    zT_3B6EA323_EU_01 zT_168;
    zT_3A355BD2_Token tok;
    unsigned int backing_type2;
    unsigned int* members_buf;
    unsigned int members_count;
    unsigned int members_cap;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int name_id;
    unsigned int value_expr;
    unsigned int mnode;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    backing_type2 = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_15 = self;
    zT_16 = zF_CBDBFE85_parserParseType(zT_15);
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_28 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    return zT_16;
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    backing_type2 = zT_18;
    zT_19 = self;
    zT_23 = zF_5578C74F_parserExpect(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = zT_23.data.err;
    zT_26.data.err = zT_25;
    zT_26.is_error = 1;
    return zT_26;
    z_bb_7:
    zT_27 = zT_23.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_27;
    goto z_bb_2;
    z_bb_9:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_10:
    zT_36 = zT_32.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_36;
    members_buf = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    members_count = zT_41;
    zT_43 = 0;
    members_cap = zT_43;
    goto z_bb_12;
    z_bb_12:
    zT_44 = self;
    zT_45 = zF_068A2DE5_parserPeek(zT_44);
    zT_46 = zT_45.kind;
    if ((unsigned char)(zT_46 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_51 = self;
    zT_55 = zF_5578C74F_parserExpect(zT_51, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_56 = zT_55.is_error;
    if (zT_56) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_122 = self;
    zT_126 = zF_5578C74F_parserExpect(zT_122, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = zT_55.data.err;
    zT_58.data.err = zT_57;
    zT_58.is_error = 1;
    return zT_58;
    z_bb_17:
    zT_59 = zT_55.data.payload;
    goto z_bb_18;
    z_bb_18:
    name_tok = zT_59;
    zT_61 = self;
    zT_62 = name_tok;
    zT_63 = zF_ED2167CA_parserInternParseTo(zT_61, zT_62);
    name_id = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    value_expr = zT_66;
    zT_67 = self;
    zT_68 = zF_068A2DE5_parserPeek(zT_67);
    zT_69 = zT_68.kind;
    if ((unsigned char)(zT_69 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_73 = self;
    zT_74 = zF_C241B2C4_parserAdvance(zT_73);
    (void)zT_74;
    zT_75 = self;
    zT_78 = zF_F07C1F04_parserParseExprPrec(zT_75, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_79 = zT_78.is_error;
    if (zT_79) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_82 = self->store;
    zT_94 = 0;
    zT_85 = name_tok.span_start;
    zT_97 = name_tok.span_start;
    zT_98 = name_tok.span_len;
    zT_101 = 0;
    zT_88 = value_expr;
    zT_103 = 0;
    zT_90 = name_id;
    zT_105 = zF_6C9FF72F_astStoreAddNode(zT_82, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_94), zT_85, (unsigned int)(zT_97 + (unsigned int)((unsigned int)zT_98)), (unsigned int)((unsigned int)zT_101), zT_88, (unsigned int)((unsigned int)zT_103), zT_90);
    mnode = zT_105;
    zT_106 = self;
    zT_107 = &members_buf;
    zT_108 = &members_count;
    zT_109 = &members_cap;
    zT_110 = mnode;
    zF_0F1462F8_parserPushU32(zT_106, zT_107, zT_108, zT_109, zT_110);
    zT_114 = self;
    zT_115 = zF_068A2DE5_parserPeek(zT_114);
    zT_116 = zT_115.kind;
    if ((unsigned char)(zT_116 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    return zT_78;
    z_bb_22:
    zT_80 = zT_78.data.payload;
    goto z_bb_23;
    z_bb_23:
    value_expr = zT_80;
    goto z_bb_20;
    z_bb_24:
    zT_120 = self;
    zT_121 = zF_C241B2C4_parserAdvance(zT_120);
    (void)zT_121;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_15;
    z_bb_26:
    zT_128 = zT_126.data.err;
    zT_129.data.err = zT_128;
    zT_129.is_error = 1;
    return zT_129;
    z_bb_27:
    zT_130 = zT_126.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_130;
    zT_132 = 0;
    zT_133 = (unsigned int)zT_132;
    payload = zT_133;
    zT_134 = 0;
    if ((unsigned char)(members_count > (unsigned int)zT_134)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_136 = self->store;
    zT_139 = 0;
    zT_140 = members_buf + zT_139;
    zT_141 = members_count - zT_139;
    zT_142.ptr = zT_140;
    zT_142.len = zT_141;
    zT_137 = zT_142;
    zT_143 = zF_583E993C_astStoreAddExtraChi(zT_136, zT_137);
    payload = zT_143;
    goto z_bb_30;
    z_bb_30:
    zT_144 = self->store;
    zT_156 = 0;
    zT_147 = tok.span_start;
    zT_159 = tok.span_start;
    zT_160 = tok.span_len;
    zT_149 = backing_type2;
    zT_163 = 0;
    zT_165 = 0;
    zT_152 = payload;
    zT_167 = zF_6C9FF72F_astStoreAddNode(zT_144, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl), (unsigned char)((unsigned char)zT_156), zT_147, (unsigned int)(zT_159 + (unsigned int)((unsigned int)zT_160)), zT_149, (unsigned int)((unsigned int)zT_163), (unsigned int)((unsigned int)zT_165), zT_152);
    zT_168.data.payload = zT_167;
    zT_168.is_error = 0;
    return zT_168;
}

/* parserParseUnionType */
zT_3B6EA323_EU_01 zF_0881F8E4_parserParseUnionTyp(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned char zT_7;
    int zT_9;
    unsigned char zT_10;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_EAC3E484_TokenKind zT_13;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_B559F9DA_Parser* zT_19;
    zT_CB78802F_EU_49 zT_23 = {0};
    unsigned char zT_24;
    int zT_25;
    zT_3B6EA323_EU_01 zT_26;
    zT_2B3424E9_ParseToken zT_27;
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_DBF3575C_ParserError zT_51;
    zT_3B6EA323_EU_01 zT_52;
    unsigned char zT_56;
    unsigned char zT_60;
    zT_B559F9DA_Parser* zT_61;
    zT_CB78802F_EU_49 zT_65 = {0};
    unsigned char zT_66;
    int zT_67;
    zT_3B6EA323_EU_01 zT_68;
    zT_2B3424E9_ParseToken zT_69;
    unsigned int* zT_71 = 0;
    int zT_73;
    unsigned int zT_74;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_77;
    zT_3A355BD2_Token zT_78 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_B559F9DA_Parser* zT_84;
    zT_CB78802F_EU_49 zT_88 = {0};
    unsigned char zT_89;
    int zT_90;
    zT_3B6EA323_EU_01 zT_91;
    zT_2B3424E9_ParseToken zT_92;
    zT_B559F9DA_Parser* zT_94;
    zT_2B3424E9_ParseToken zT_95;
    unsigned int zT_96 = 0;
    int zT_98;
    unsigned int zT_99;
    zT_B559F9DA_Parser* zT_100;
    zT_3A355BD2_Token zT_101 = {0};
    zT_EAC3E484_TokenKind zT_102;
    zT_B559F9DA_Parser* zT_106;
    zT_3A355BD2_Token zT_107 = {0};
    zT_B559F9DA_Parser* zT_109;
    zT_3B6EA323_EU_01 zT_110 = {0};
    unsigned char zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_113;
    unsigned int zT_116;
    unsigned int zT_118;
    unsigned int zT_121;
    int zT_125;
    unsigned int zT_128;
    unsigned short zT_129;
    int zT_132;
    int zT_134;
    unsigned int zT_136 = 0;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_140;
    unsigned int zT_145;
    int zT_149;
    unsigned int zT_152;
    unsigned short zT_153;
    int zT_156;
    int zT_158;
    int zT_160;
    unsigned int zT_162 = 0;
    zT_B559F9DA_Parser* zT_163;
    unsigned int** zT_164;
    unsigned int* zT_165;
    unsigned int* zT_166;
    unsigned int zT_167;
    zT_B559F9DA_Parser* zT_171;
    zT_3A355BD2_Token zT_172 = {0};
    zT_EAC3E484_TokenKind zT_173;
    zT_B559F9DA_Parser* zT_177;
    zT_3A355BD2_Token zT_178 = {0};
    zT_B559F9DA_Parser* zT_179;
    zT_CB78802F_EU_49 zT_183 = {0};
    unsigned char zT_184;
    int zT_185;
    zT_3B6EA323_EU_01 zT_186;
    zT_2B3424E9_ParseToken zT_187;
    int zT_189;
    unsigned int zT_190;
    int zT_191;
    zT_6B0A7D14_AstStore* zT_193;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_194;
    int zT_196;
    unsigned int* zT_197;
    unsigned int zT_198;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_199;
    unsigned int zT_200 = 0;
    zT_8143F551_AstKind zT_203;
    int zT_204;
    zT_6B0A7D14_AstStore* zT_206;
    zT_8143F551_AstKind zT_207;
    unsigned char zT_208;
    unsigned int zT_209;
    unsigned int zT_214;
    unsigned int zT_217;
    unsigned short zT_218;
    int zT_221;
    int zT_223;
    int zT_225;
    unsigned int zT_227 = 0;
    zT_3B6EA323_EU_01 zT_228;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned char is_tagged;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_msg;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int name_id;
    unsigned int field_node;
    unsigned int field_type;
    unsigned int payload;
    zT_8143F551_AstKind kind;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned char)zT_6;
    flags = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_11 = self;
    zT_12 = zF_068A2DE5_parserPeek(zT_11);
    zT_13 = zT_12.kind;
    if ((unsigned char)(zT_13 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = self;
    zT_18 = zF_C241B2C4_parserAdvance(zT_17);
    (void)zT_18;
    zT_19 = self;
    zT_23 = zF_5578C74F_parserExpect(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(is_tagged != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_25 = zT_23.data.err;
    zT_26.data.err = zT_25;
    zT_26.is_error = 1;
    return zT_26;
    z_bb_4:
    zT_27 = zT_23.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_27;
    zT_28 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_7:
    zT_36 = zT_32.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_36;
    zT_37 = 1;
    zT_38 = (unsigned char)zT_37;
    is_tagged = zT_38;
    goto z_bb_2;
    z_bb_9:
    zT_41 = is_packed != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_41 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_41) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_45 = "packed unions cannot be tagged (union(enum)); packed union is an untagged container";
    zT_47 = 83;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    tag_msg = zT_46;
    zT_48 = self;
    zT_49 = tok;
    zT_50 = tag_msg;
    zF_17DF2CA5_parserAddError(zT_48, zT_49, zT_50);
    zT_51 = 1;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_13:
    if ((unsigned char)(is_tagged != (unsigned char)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_56 = flags | (unsigned char)(1);
    flags = zT_56;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(is_packed != (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_60 = flags | (unsigned char)(16);
    flags = zT_60;
    goto z_bb_17;
    z_bb_17:
    zT_61 = self;
    zT_65 = zF_5578C74F_parserExpect(zT_61, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_67 = zT_65.data.err;
    zT_68.data.err = zT_67;
    zT_68.is_error = 1;
    return zT_68;
    z_bb_19:
    zT_69 = zT_65.data.payload;
    goto z_bb_20;
    z_bb_20:
    (void)zT_69;
    fields_buf = zT_71;
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    fields_count = zT_74;
    zT_76 = 0;
    fields_cap = zT_76;
    goto z_bb_21;
    z_bb_21:
    zT_77 = self;
    zT_78 = zF_068A2DE5_parserPeek(zT_77);
    zT_79 = zT_78.kind;
    if ((unsigned char)(zT_79 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_84 = self;
    zT_88 = zF_5578C74F_parserExpect(zT_84, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_89 = zT_88.is_error;
    if (zT_89) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_179 = self;
    zT_183 = zF_5578C74F_parserExpect(zT_179, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_184 = zT_183.is_error;
    if (zT_184) goto z_bb_36; else goto z_bb_37;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_90 = zT_88.data.err;
    zT_91.data.err = zT_90;
    zT_91.is_error = 1;
    return zT_91;
    z_bb_26:
    zT_92 = zT_88.data.payload;
    goto z_bb_27;
    z_bb_27:
    name_tok = zT_92;
    zT_94 = self;
    zT_95 = name_tok;
    zT_96 = zF_ED2167CA_parserInternParseTo(zT_94, zT_95);
    name_id = zT_96;
    zT_98 = 0;
    zT_99 = (unsigned int)zT_98;
    field_node = zT_99;
    zT_100 = self;
    zT_101 = zF_068A2DE5_parserPeek(zT_100);
    zT_102 = zT_101.kind;
    if ((unsigned char)(zT_102 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_106 = self;
    zT_107 = zF_C241B2C4_parserAdvance(zT_106);
    (void)zT_107;
    zT_109 = self;
    zT_110 = zF_CBDBFE85_parserParseType(zT_109);
    zT_111 = zT_110.is_error;
    if (zT_111) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_163 = self;
    zT_164 = &fields_buf;
    zT_165 = &fields_count;
    zT_166 = &fields_cap;
    zT_167 = field_node;
    zF_0F1462F8_parserPushU32(zT_163, zT_164, zT_165, zT_166, zT_167);
    zT_171 = self;
    zT_172 = zF_068A2DE5_parserPeek(zT_171);
    zT_173 = zT_172.kind;
    if ((unsigned char)(zT_173 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    zT_137 = self->store;
    zT_149 = 0;
    zT_140 = name_tok.span_start;
    zT_152 = name_tok.span_start;
    zT_153 = name_tok.span_len;
    zT_156 = 0;
    zT_158 = 0;
    zT_160 = 0;
    zT_145 = name_id;
    zT_162 = zF_6C9FF72F_astStoreAddNode(zT_137, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_149), zT_140, (unsigned int)(zT_152 + (unsigned int)((unsigned int)zT_153)), (unsigned int)((unsigned int)zT_156), (unsigned int)((unsigned int)zT_158), (unsigned int)((unsigned int)zT_160), zT_145);
    field_node = zT_162;
    goto z_bb_29;
    z_bb_31:
    return zT_110;
    z_bb_32:
    zT_112 = zT_110.data.payload;
    goto z_bb_33;
    z_bb_33:
    field_type = zT_112;
    zT_113 = self->store;
    zT_125 = 0;
    zT_116 = name_tok.span_start;
    zT_128 = name_tok.span_start;
    zT_129 = name_tok.span_len;
    zT_118 = field_type;
    zT_132 = 0;
    zT_134 = 0;
    zT_121 = name_id;
    zT_136 = zF_6C9FF72F_astStoreAddNode(zT_113, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_125), zT_116, (unsigned int)(zT_128 + (unsigned int)((unsigned int)zT_129)), zT_118, (unsigned int)((unsigned int)zT_132), (unsigned int)((unsigned int)zT_134), zT_121);
    field_node = zT_136;
    goto z_bb_29;
    z_bb_34:
    zT_177 = self;
    zT_178 = zF_C241B2C4_parserAdvance(zT_177);
    (void)zT_178;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_24;
    z_bb_36:
    zT_185 = zT_183.data.err;
    zT_186.data.err = zT_185;
    zT_186.is_error = 1;
    return zT_186;
    z_bb_37:
    zT_187 = zT_183.data.payload;
    goto z_bb_38;
    z_bb_38:
    (void)zT_187;
    zT_189 = 0;
    zT_190 = (unsigned int)zT_189;
    payload = zT_190;
    zT_191 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_191)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_193 = self->store;
    zT_196 = 0;
    zT_197 = fields_buf + zT_196;
    zT_198 = fields_count - zT_196;
    zT_199.ptr = zT_197;
    zT_199.len = zT_198;
    zT_194 = zT_199;
    zT_200 = zF_583E993C_astStoreAddExtraChi(zT_193, zT_194);
    payload = zT_200;
    goto z_bb_40;
    z_bb_40:
    zT_203 = zT_8143F551_AstKind_union_decl;
    kind = zT_203;
    zT_204 = 0;
    if ((unsigned char)(is_tagged != zT_204)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_42;
    z_bb_42:
    zT_206 = self->store;
    zT_207 = kind;
    zT_208 = flags;
    zT_209 = tok.span_start;
    zT_217 = tok.span_start;
    zT_218 = tok.span_len;
    zT_221 = 0;
    zT_223 = 0;
    zT_225 = 0;
    zT_214 = payload;
    zT_227 = zF_6C9FF72F_astStoreAddNode(zT_206, zT_207, zT_208, zT_209, (unsigned int)(zT_217 + (unsigned int)((unsigned int)zT_218)), (unsigned int)((unsigned int)zT_221), (unsigned int)((unsigned int)zT_223), (unsigned int)((unsigned int)zT_225), zT_214);
    zT_228.data.payload = zT_227;
    zT_228.is_error = 0;
    return zT_228;
}

/* parserParseTypeName */
zT_3B6EA323_EU_01 zF_C8A1E2C6_parserParseTypeName(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6;
    unsigned int zT_7 = 0;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_18;
    unsigned short zT_19;
    unsigned int zT_22 = 0;
    zT_B559F9DA_Parser* zT_23;
    zT_3A355BD2_Token zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    zT_B559F9DA_Parser* zT_29;
    zT_3A355BD2_Token zT_30 = {0};
    zT_B559F9DA_Parser* zT_32;
    zT_CB78802F_EU_49 zT_36 = {0};
    unsigned char zT_37;
    int zT_38;
    zT_3B6EA323_EU_01 zT_39;
    zT_2B3424E9_ParseToken zT_40;
    zT_B559F9DA_Parser* zT_42;
    zT_2B3424E9_ParseToken zT_43;
    unsigned int zT_44 = 0;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_53;
    int zT_57;
    unsigned int zT_60;
    unsigned short zT_61;
    int zT_64;
    int zT_66;
    unsigned int zT_68 = 0;
    zT_3B6EA323_EU_01 zT_69;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    unsigned int node;
    zT_2B3424E9_ParseToken field_tok;
    unsigned int field_id;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = tok;
    zT_7 = zF_9DDDA188_parserInternTokenTe(zT_5, zT_6);
    name_id = zT_7;
    zT_9 = self->store;
    zT_11 = name_id;
    zT_12 = tok.span_start;
    zT_18 = tok.span_start;
    zT_19 = tok.span_len;
    zT_22 = zF_1DF77BD4_astStoreAddIdentifi(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_11, zT_12, (unsigned int)(zT_18 + (unsigned int)((unsigned int)zT_19)));
    node = zT_22;
    goto z_bb_1;
    z_bb_1:
    zT_23 = self;
    zT_24 = zF_068A2DE5_parserPeek(zT_23);
    zT_25 = zT_24.kind;
    if ((unsigned char)(zT_25 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_29 = self;
    zT_30 = zF_C241B2C4_parserAdvance(zT_29);
    (void)zT_30;
    zT_32 = self;
    zT_36 = zF_5578C74F_parserExpect(zT_32, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_69.data.payload = node;
    zT_69.is_error = 0;
    return zT_69;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_38 = zT_36.data.err;
    zT_39.data.err = zT_38;
    zT_39.is_error = 1;
    return zT_39;
    z_bb_6:
    zT_40 = zT_36.data.payload;
    goto z_bb_7;
    z_bb_7:
    field_tok = zT_40;
    zT_42 = self;
    zT_43 = field_tok;
    zT_44 = zF_ED2167CA_parserInternParseTo(zT_42, zT_43);
    field_id = zT_44;
    zT_45 = self->store;
    zT_57 = 0;
    zT_48 = tok.span_start;
    zT_60 = field_tok.span_start;
    zT_61 = field_tok.span_len;
    zT_50 = node;
    zT_64 = 0;
    zT_66 = 0;
    zT_53 = field_id;
    zT_68 = zF_6C9FF72F_astStoreAddNode(zT_45, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_57), zT_48, (unsigned int)(zT_60 + (unsigned int)((unsigned int)zT_61)), zT_50, (unsigned int)((unsigned int)zT_64), (unsigned int)((unsigned int)zT_66), zT_53);
    node = zT_68;
    goto z_bb_4;
}

/* parserParseStatement */
zT_3B6EA323_EU_01 zF_462FC60E_parserParseStatemen(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_EAC3E484_TokenKind zT_10;
    zT_EAC3E484_TokenKind zT_12;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3B6EA323_EU_01 zT_30 = {0};
    zT_EAC3E484_TokenKind zT_31;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_B559F9DA_Parser* zT_40;
    zT_3B6EA323_EU_01 zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3B6EA323_EU_01 zT_63 = {0};
    zT_EAC3E484_TokenKind zT_64;
    zT_B559F9DA_Parser* zT_68;
    zT_3B6EA323_EU_01 zT_71 = {0};
    zT_EAC3E484_TokenKind zT_72;
    zT_B559F9DA_Parser* zT_76;
    unsigned char zT_81;
    unsigned int zT_86;
    zT_3B6EA323_EU_01 zT_87 = {0};
    zT_EAC3E484_TokenKind zT_88;
    zT_B559F9DA_Parser* zT_92;
    zT_3B6EA323_EU_01 zT_93 = {0};
    zT_EAC3E484_TokenKind zT_94;
    zT_B559F9DA_Parser* zT_98;
    zT_3B6EA323_EU_01 zT_99 = {0};
    zT_EAC3E484_TokenKind zT_100;
    zT_B559F9DA_Parser* zT_104;
    zT_3B6EA323_EU_01 zT_105 = {0};
    zT_EAC3E484_TokenKind zT_106;
    zT_B559F9DA_Parser* zT_110;
    zT_3B6EA323_EU_01 zT_111 = {0};
    zT_EAC3E484_TokenKind zT_112;
    zT_B559F9DA_Parser* zT_116;
    zT_3B6EA323_EU_01 zT_117 = {0};
    zT_EAC3E484_TokenKind zT_118;
    zT_B559F9DA_Parser* zT_122;
    zT_3B6EA323_EU_01 zT_123 = {0};
    zT_EAC3E484_TokenKind zT_124;
    zT_B559F9DA_Parser* zT_128;
    zT_3B6EA323_EU_01 zT_129 = {0};
    zT_EAC3E484_TokenKind zT_130;
    zT_B559F9DA_Parser* zT_134;
    zT_3B6EA323_EU_01 zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    zT_B559F9DA_Parser* zT_143;
    zT_3B6EA323_EU_01 zT_144 = {0};
    zT_EAC3E484_TokenKind zT_145;
    zT_B559F9DA_Parser* zT_149;
    zT_3B6EA323_EU_01 zT_150 = {0};
    zT_EAC3E484_TokenKind zT_151;
    zT_B559F9DA_Parser* zT_155;
    zT_3B6EA323_EU_01 zT_159 = {0};
    zT_EAC3E484_TokenKind zT_160;
    zT_B559F9DA_Parser* zT_164;
    zT_3B6EA323_EU_01 zT_168 = {0};
    zT_EAC3E484_TokenKind zT_169;
    zT_B559F9DA_Parser* zT_173;
    zT_3B6EA323_EU_01 zT_177 = {0};
    zT_EAC3E484_TokenKind zT_178;
    zT_B559F9DA_Parser* zT_182;
    zT_3B6EA323_EU_01 zT_183 = {0};
    zT_EAC3E484_TokenKind zT_184;
    zT_B559F9DA_Parser* zT_188;
    zT_3A355BD2_Token zT_189 = {0};
    zT_B559F9DA_Parser* zT_190;
    zT_EAC3E484_TokenKind zT_192;
    zT_B559F9DA_Parser* zT_196;
    int zT_198;
    zT_3A355BD2_Token zT_200 = {0};
    zT_EAC3E484_TokenKind zT_201;
    zT_B559F9DA_Parser* zT_205;
    zT_3B6EA323_EU_01 zT_206 = {0};
    zT_B559F9DA_Parser* zT_207;
    zT_3B6EA323_EU_01 zT_208 = {0};
    zT_B559F9DA_Parser* zT_209;
    zT_3B6EA323_EU_01 zT_210 = {0};
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pstk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u varc_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u varv_s;
    z_bb_0:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = "PSTK:k";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    pstk_m = zT_6;
    zT_8 = pstk_m;
    zT_10 = tok.kind;
    zF_C914CB83_markerWriteInt(zT_8, (unsigned int)((unsigned int)zT_10));
    zT_12 = tok.kind;
    if ((unsigned char)(zT_12 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = "VARC";
    zT_19 = 4;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    varc_s = zT_18;
    zT_20 = varc_s;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_21 = self;
    zT_30 = zF_7D11B416_parserParseVarDecl(zT_21, (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0));
    return zT_30;
    z_bb_2:
    zT_31 = tok.kind;
    if ((unsigned char)(zT_31 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_36 = "VARV";
    zT_38 = 4;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    varv_s = zT_37;
    zT_39 = varv_s;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_40 = self;
    zT_49 = zF_7D11B416_parserParseVarDecl(zT_40, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0));
    return zT_49;
    z_bb_4:
    zT_50 = tok.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_54 = self;
    zT_55 = zF_A8314C30_parserParsePubDecl(zT_54);
    return zT_55;
    z_bb_6:
    zT_56 = tok.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_60 = self;
    zT_63 = zF_A0D31A63_parserParseExternDe(zT_60, (unsigned char)(0));
    return zT_63;
    z_bb_8:
    zT_64 = tok.kind;
    if ((unsigned char)(zT_64 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_68 = self;
    zT_71 = zF_C3CD8237_parserParseExportDe(zT_68, (unsigned char)(0));
    return zT_71;
    z_bb_10:
    zT_72 = tok.kind;
    if ((unsigned char)(zT_72 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_76 = self;
    zT_86 = 0;
    zT_81 = zT_86;
    zT_87 = zF_3D879A25_parserParseFnDecl(zT_76, (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), zT_81);
    return zT_87;
    z_bb_12:
    zT_88 = tok.kind;
    if ((unsigned char)(zT_88 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_92 = self;
    zT_93 = zF_DB819578_parserParseIfStmt(zT_92);
    return zT_93;
    z_bb_14:
    zT_94 = tok.kind;
    if ((unsigned char)(zT_94 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_98 = self;
    zT_99 = zF_4E7AD820_parserParseWhileStm(zT_98);
    return zT_99;
    z_bb_16:
    zT_100 = tok.kind;
    if ((unsigned char)(zT_100 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_for))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_104 = self;
    zT_105 = zF_54BCF0C6_parserParseForStmt(zT_104);
    return zT_105;
    z_bb_18:
    zT_106 = tok.kind;
    if ((unsigned char)(zT_106 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_110 = self;
    zT_111 = zF_3A6F34C7_parserParseSwitchSt(zT_110);
    return zT_111;
    z_bb_20:
    zT_112 = tok.kind;
    if ((unsigned char)(zT_112 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_116 = self;
    zT_117 = zF_76F5B9F1_parserParseReturnSt(zT_116);
    return zT_117;
    z_bb_22:
    zT_118 = tok.kind;
    if ((unsigned char)(zT_118 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_122 = self;
    zT_123 = zF_6DA396FE_parserParseBreakStm(zT_122);
    return zT_123;
    z_bb_24:
    zT_124 = tok.kind;
    if ((unsigned char)(zT_124 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_128 = self;
    zT_129 = zF_E13A9822_parserParseContinue(zT_128);
    return zT_129;
    z_bb_26:
    zT_130 = tok.kind;
    if ((unsigned char)(zT_130 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_defer))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_134 = self;
    zT_138 = zF_3B25AFD5_parserParseDeferStm(zT_134, (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt));
    return zT_138;
    z_bb_28:
    zT_139 = tok.kind;
    if ((unsigned char)(zT_139 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_errdefer))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_143 = self;
    zT_144 = zF_6C2E50E6_parserParseErrdefer(zT_143);
    return zT_144;
    z_bb_30:
    zT_145 = tok.kind;
    if ((unsigned char)(zT_145 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_149 = self;
    zT_150 = zF_15A196A5_parserParseTestDecl(zT_149);
    return zT_150;
    z_bb_32:
    zT_151 = tok.kind;
    if ((unsigned char)(zT_151 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_155 = self;
    zT_159 = zF_0A0E9C6C_parserParseContaine(zT_155, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl));
    return zT_159;
    z_bb_34:
    zT_160 = tok.kind;
    if ((unsigned char)(zT_160 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_164 = self;
    zT_168 = zF_0A0E9C6C_parserParseContaine(zT_164, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl));
    return zT_168;
    z_bb_36:
    zT_169 = tok.kind;
    if ((unsigned char)(zT_169 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_173 = self;
    zT_177 = zF_0A0E9C6C_parserParseContaine(zT_173, (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl));
    return zT_177;
    z_bb_38:
    zT_178 = tok.kind;
    if ((unsigned char)(zT_178 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_182 = self;
    zT_183 = zF_365CA04A_parserParseBlock(zT_182);
    return zT_183;
    z_bb_40:
    zT_184 = tok.kind;
    if ((unsigned char)(zT_184 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_188 = self;
    zT_189 = zF_C241B2C4_parserAdvance(zT_188);
    (void)zT_189;
    zT_190 = self;
    self = zT_190;
    goto z_bb_0;
    z_bb_42:
    zT_192 = tok.kind;
    if ((unsigned char)(zT_192 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_196 = self;
    zT_198 = 1;
    zT_200 = zF_F685E431_parserPeekN(zT_196, (unsigned int)((unsigned int)zT_198));
    zT_201 = zT_200.kind;
    if ((unsigned char)(zT_201 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_209 = self;
    zT_210 = zF_907B11F0_parserParseExprStmt(zT_209);
    return zT_210;
    z_bb_45:
    zT_205 = self;
    zT_206 = zF_BF6ABAB2_parserParseLabeledS(zT_205);
    return zT_206;
    z_bb_46:
    zT_207 = self;
    zT_208 = zF_907B11F0_parserParseExprStmt(zT_207);
    return zT_208;
}

/* parserEmitErrorNode */
unsigned int zF_8A97D8C1_parserEmitErrorNode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_9;
    int zT_18;
    unsigned int zT_21;
    unsigned short zT_22;
    int zT_25;
    int zT_27;
    int zT_29;
    int zT_31;
    unsigned int zT_33 = 0;
    zT_3 = self;
    zT_4 = tok;
    zT_5 = msg;
    zF_17DF2CA5_parserAddError(zT_3, zT_4, zT_5);
    zT_6 = self->store;
    zT_18 = 0;
    zT_9 = tok.span_start;
    zT_21 = tok.span_start;
    zT_22 = tok.span_len;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = 0;
    zT_33 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_err), (unsigned char)((unsigned char)zT_18), zT_9, (unsigned int)(zT_21 + (unsigned int)((unsigned int)zT_22)), (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29), (unsigned int)((unsigned int)zT_31));
    return zT_33;
}

/* parserParseModuleRoot */
zT_3B6EA323_EU_01 zF_224ED3B5_parserParseModuleRo(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_9;
    zT_3B6EA323_EU_01 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24 = 0;
    zT_B559F9DA_Parser* zT_25;
    unsigned int** zT_26;
    unsigned int* zT_27;
    unsigned int* zT_28;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    unsigned int** zT_44;
    unsigned int* zT_45;
    unsigned int* zT_46;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_59;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_60;
    unsigned int* zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int* zT_65;
    unsigned int zT_66;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_67;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_77;
    int zT_81;
    int zT_83;
    int zT_85;
    int zT_87;
    int zT_89;
    int zT_91;
    unsigned int zT_93 = 0;
    zT_3B6EA323_EU_01 zT_94;
    unsigned int decl;
    unsigned int payload;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    unsigned int err;
    self->decl_buf_len = (unsigned int)(0);
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((unsigned char)(zT_4 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_10 = zF_462FC60E_parserParseStatemen(zT_9);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    payload = zT_55;
    zT_56 = self->decl_buf_len;
    if ((unsigned char)(zT_56 > (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    tok = zT_15;
    zT_17 = "unexpected token";
    zT_19 = 16;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    err_msg = zT_18;
    zT_21 = self;
    zT_22 = tok;
    zT_23 = err_msg;
    zT_24 = zF_8A97D8C1_parserEmitErrorNode(zT_21, zT_22, zT_23);
    err = zT_24;
    zT_25 = self;
    zF_4190C400_parserSynchronize(zT_25);
    zT_26 = &self->decl_buf_items;
    zT_27 = &self->decl_buf_len;
    zT_28 = &self->decl_buf_capacity;
    zT_29 = self->allocator;
    zT_30 = err;
    zF_8B163A32_u32ArrayListAppendI(zT_26, zT_27, zT_28, zT_29, zT_30);
    goto z_bb_8;
    z_bb_6:
    zT_12 = zT_10.data.payload;
    goto z_bb_7;
    z_bb_7:
    decl = zT_12;
    zT_44 = &self->decl_buf_items;
    zT_45 = &self->decl_buf_len;
    zT_46 = &self->decl_buf_capacity;
    zT_47 = self->allocator;
    zT_48 = decl;
    zF_8B163A32_u32ArrayListAppendI(zT_44, zT_45, zT_46, zT_47, zT_48);
    goto z_bb_4;
    z_bb_8:
    zT_35 = self;
    zT_36 = zF_068A2DE5_parserPeek(zT_35);
    zT_37 = zT_36.kind;
    if ((unsigned char)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    goto z_bb_11;
    z_bb_10:
    goto z_bb_4;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_59 = self->store;
    zT_62 = self->decl_buf_items;
    zT_63 = self->decl_buf_len;
    zT_64 = 0;
    zT_65 = zT_62 + zT_64;
    zT_66 = zT_63 - zT_64;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_60 = zT_67;
    zT_68 = zF_583E993C_astStoreAddExtraChi(zT_59, zT_60);
    payload = zT_68;
    goto z_bb_13;
    z_bb_13:
    zT_69 = self->store;
    zT_81 = 0;
    zT_83 = 0;
    zT_85 = 0;
    zT_87 = 0;
    zT_89 = 0;
    zT_91 = 0;
    zT_77 = payload;
    zT_93 = zF_6C9FF72F_astStoreAddNode(zT_69, (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root), (unsigned char)((unsigned char)zT_81), (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85), (unsigned int)((unsigned int)zT_87), (unsigned int)((unsigned int)zT_89), (unsigned int)((unsigned int)zT_91), zT_77);
    zT_94.data.payload = zT_93;
    zT_94.is_error = 0;
    return zT_94;
}

/* parserParseStmtBodyExpr */
zT_3B6EA323_EU_01 zF_CE2E1DC0_parserParseStmtBody(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_7;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_B2DA84DE_Opt_98 zT_13 = {0};
    unsigned char zT_14;
    zT_2B10107F_Prec zT_16;
    zT_B559F9DA_Parser* zT_19;
    zT_3A355BD2_Token zT_20 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_3B6EA323_EU_01 zT_25 = {0};
    unsigned char zT_26;
    unsigned int zT_27;
    zT_B559F9DA_Parser* zT_28;
    zT_3A355BD2_Token zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    unsigned int result;
    zT_3A355BD2_Token atok;
    zT_F4EBEA72_OpInfo info;
    unsigned int rhs;
    zT_2 = self;
    zT_5 = zF_F07C1F04_parserParseExprPrec(zT_2, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_6 = zT_5.is_error;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_5;
    z_bb_2:
    zT_7 = zT_5.data.payload;
    goto z_bb_3;
    z_bb_3:
    result = zT_7;
    zT_9 = self;
    zT_10 = zF_068A2DE5_parserPeek(zT_9);
    atok = zT_10;
    zT_11 = atok.kind;
    zT_13 = zF_1E2936C3_getInfixInfo(zT_11);
    zT_14 = zT_13.has_value;
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    info = zT_13.value;
    zT_16 = info.prec;
    if ((unsigned char)(zT_16 == (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment))) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_35.data.payload = result;
    zT_35.is_error = 0;
    return zT_35;
    z_bb_6:
    zT_19 = self;
    zT_20 = zF_C241B2C4_parserAdvance(zT_19);
    (void)zT_20;
    zT_22 = self;
    zT_25 = zF_F07C1F04_parserParseExprPrec(zT_22, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_5;
    z_bb_8:
    return zT_25;
    z_bb_9:
    zT_27 = zT_25.data.payload;
    goto z_bb_10;
    z_bb_10:
    rhs = zT_27;
    zT_28 = self;
    zT_29 = atok;
    zT_30 = result;
    zT_31 = rhs;
    zT_32 = zF_E702AE30_parserAddBinary(zT_28, zT_29, zT_30, zT_31);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return zT_32;
    z_bb_12:
    zT_34 = zT_32.data.payload;
    goto z_bb_13;
    z_bb_13:
    result = zT_34;
    goto z_bb_7;
}

/* parserParseExprStmt */
zT_3B6EA323_EU_01 zF_907B11F0_parserParseExprStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token zT_7 = {0};
    zT_EAC3E484_TokenKind zT_8;
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_16 = {0};
    unsigned char zT_17;
    int zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_2B3424E9_ParseToken zT_20;
    zT_3B6EA323_EU_01 zT_21;
    unsigned int result;
    zT_2 = self;
    zT_3 = zF_CE2E1DC0_parserParseStmtBody(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    result = zT_5;
    zT_6 = self;
    zT_7 = zF_068A2DE5_parserPeek(zT_6);
    zT_8 = zT_7.kind;
    if ((unsigned char)(zT_8 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = self;
    zT_16 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_21.data.payload = result;
    zT_21.is_error = 0;
    return zT_21;
    z_bb_6:
    zT_18 = zT_16.data.err;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_7:
    zT_20 = zT_16.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_20;
    goto z_bb_5;
}

/* parserParseLabeledStmt */
zT_3B6EA323_EU_01 zF_BF6ABAB2_parserParseLabeledS(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    unsigned char zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_27;
    int zT_31;
    unsigned int zT_34;
    unsigned short zT_35;
    int zT_38;
    int zT_40;
    zT_85CBA4DB_TokenValue zT_42;
    unsigned int zT_44 = 0;
    zT_3B6EA323_EU_01 zT_45;
    zT_3A355BD2_Token label_tok;
    unsigned int inner;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_462FC60E_parserParseStatemen(zT_14);
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_15;
    z_bb_5:
    zT_17 = zT_15.data.payload;
    goto z_bb_6;
    z_bb_6:
    inner = zT_17;
    end = inner;
    (void)end;
    zT_19 = self->store;
    zT_31 = 0;
    zT_22 = label_tok.span_start;
    zT_34 = label_tok.span_start;
    zT_35 = label_tok.span_len;
    zT_24 = inner;
    zT_38 = 0;
    zT_40 = 0;
    zT_42 = label_tok.value;
    zT_27 = zT_42.string_id;
    zT_44 = zF_6C9FF72F_astStoreAddNode(zT_19, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_31), zT_22, (unsigned int)(zT_34 + (unsigned int)((unsigned int)zT_35)), zT_24, (unsigned int)((unsigned int)zT_38), (unsigned int)((unsigned int)zT_40), zT_27);
    zT_45.data.payload = zT_44;
    zT_45.is_error = 0;
    return zT_45;
}

/* parserParseLabeledBlockExpr */
zT_3B6EA323_EU_01 zF_532B277E_parserParseLabeledB(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_3A355BD2_Token zT_22;
    unsigned int zT_23;
    unsigned short zT_24;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35;
    int zT_39;
    int zT_42;
    int zT_44;
    zT_85CBA4DB_TokenValue zT_46;
    unsigned int zT_48 = 0;
    zT_3B6EA323_EU_01 zT_49;
    zT_3A355BD2_Token label_tok;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_365CA04A_parserParseBlock(zT_14);
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_15;
    z_bb_5:
    zT_17 = zT_15.data.payload;
    goto z_bb_6;
    z_bb_6:
    body = zT_17;
    zT_19 = label_tok.span_start;
    end_pos = zT_19;
    zT_20 = self->last_tok_valid;
    if (zT_20) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_22 = self->last_tok;
    last = zT_22;
    zT_23 = last.span_start;
    zT_24 = last.span_len;
    zT_26 = zT_23 + (unsigned int)((unsigned int)zT_24);
    end_pos = zT_26;
    goto z_bb_8;
    z_bb_8:
    zT_27 = self->store;
    zT_39 = 0;
    zT_30 = label_tok.span_start;
    zT_31 = end_pos;
    zT_32 = body;
    zT_42 = 0;
    zT_44 = 0;
    zT_46 = label_tok.value;
    zT_35 = zT_46.string_id;
    zT_48 = zF_6C9FF72F_astStoreAddNode(zT_27, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_39), zT_30, zT_31, zT_32, (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44), zT_35);
    zT_49.data.payload = zT_48;
    zT_49.is_error = 0;
    return zT_49;
}

/* parserParseVarDecl */
zT_3B6EA323_EU_01 zF_7D11B416_parserParseVarDecl(zT_B559F9DA_Parser* self, unsigned char is_mutable, unsigned char is_pub, unsigned char is_extern, unsigned char is_export) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_CB78802F_EU_49 zT_26 = {0};
    unsigned char zT_27;
    int zT_28;
    zT_3B6EA323_EU_01 zT_29;
    zT_2B3424E9_ParseToken zT_30;
    zT_85CBA4DB_TokenValue zT_32;
    unsigned int zT_33;
    int zT_35;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_40;
    unsigned char zT_42;
    unsigned char zT_44;
    int zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_B559F9DA_Parser* zT_56;
    zT_3B6EA323_EU_01 zT_57 = {0};
    unsigned char zT_58;
    unsigned int zT_59;
    int zT_61;
    unsigned int zT_62;
    zT_B559F9DA_Parser* zT_63;
    zT_3A355BD2_Token zT_64 = {0};
    zT_EAC3E484_TokenKind zT_65;
    zT_B559F9DA_Parser* zT_69;
    zT_3A355BD2_Token zT_70 = {0};
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_74 = {0};
    unsigned char zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_78;
    zT_CB78802F_EU_49 zT_82 = {0};
    unsigned char zT_83;
    int zT_84;
    zT_3B6EA323_EU_01 zT_85;
    zT_2B3424E9_ParseToken zT_86;
    unsigned int zT_88;
    unsigned short zT_89;
    unsigned int zT_91;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_22A7C88B_AstNode zT_108 = {0};
    zT_8143F551_AstKind zT_109;
    zT_3B6EA323_EU_01 zT_113;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned char zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_122;
    int zT_127;
    unsigned int zT_129 = 0;
    zT_3B6EA323_EU_01 zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_3A355BD2_Token kw;
    zT_3A355BD2_Token name_raw;
    unsigned int name_id;
    unsigned char flags;
    unsigned int type_node;
    unsigned int init_node;
    zT_2B3424E9_ParseToken semi;
    unsigned int end_pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u vok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pdv_s;
    zT_22A7C88B_AstNode init_check;
    zT_6 = "V";
    zT_8 = 1;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    vmsg = zT_7;
    zT_9 = vmsg;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    kw = zT_12;
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    name_raw = zT_15;
    zT_16 = name_raw.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_20 = self;
    zT_21 = zF_C241B2C4_parserAdvance(zT_20);
    (void)zT_21;
    goto z_bb_2;
    z_bb_2:
    zT_32 = name_raw.value;
    zT_33 = zT_32.string_id;
    name_id = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned char)zT_35;
    flags = zT_36;
    if (is_mutable) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_22 = self;
    zT_26 = zF_5578C74F_parserExpect(zT_22, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = zT_26.data.err;
    zT_29.data.err = zT_28;
    zT_29.is_error = 1;
    return zT_29;
    z_bb_5:
    zT_30 = zT_26.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_30;
    goto z_bb_2;
    z_bb_7:
    zT_38 = flags | (unsigned char)(1);
    flags = zT_38;
    goto z_bb_8;
    z_bb_8:
    if (is_pub) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_40 = flags | (unsigned char)(2);
    flags = zT_40;
    goto z_bb_10;
    z_bb_10:
    if (is_extern) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = flags | (unsigned char)(4);
    flags = zT_42;
    goto z_bb_12;
    z_bb_12:
    if (is_export) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_44 = flags | (unsigned char)(8);
    flags = zT_44;
    goto z_bb_14;
    z_bb_14:
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    type_node = zT_47;
    zT_48 = self;
    zT_49 = zF_068A2DE5_parserPeek(zT_48);
    zT_50 = zT_49.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = self;
    zT_55 = zF_C241B2C4_parserAdvance(zT_54);
    (void)zT_55;
    zT_56 = self;
    zT_57 = zF_CBDBFE85_parserParseType(zT_56);
    zT_58 = zT_57.is_error;
    if (zT_58) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_61 = 0;
    zT_62 = (unsigned int)zT_61;
    init_node = zT_62;
    zT_63 = self;
    zT_64 = zF_068A2DE5_parserPeek(zT_63);
    zT_65 = zT_64.kind;
    if ((unsigned char)(zT_65 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_20; else goto z_bb_21;
    z_bb_17:
    return zT_57;
    z_bb_18:
    zT_59 = zT_57.data.payload;
    goto z_bb_19;
    z_bb_19:
    type_node = zT_59;
    goto z_bb_16;
    z_bb_20:
    zT_69 = self;
    zT_70 = zF_C241B2C4_parserAdvance(zT_69);
    (void)zT_70;
    zT_71 = self;
    zT_74 = zF_F07C1F04_parserParseExprPrec(zT_71, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_78 = self;
    zT_82 = zF_5578C74F_parserExpect(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_25; else goto z_bb_26;
    z_bb_22:
    return zT_74;
    z_bb_23:
    zT_76 = zT_74.data.payload;
    goto z_bb_24;
    z_bb_24:
    init_node = zT_76;
    goto z_bb_21;
    z_bb_25:
    zT_84 = zT_82.data.err;
    zT_85.data.err = zT_84;
    zT_85.is_error = 1;
    return zT_85;
    z_bb_26:
    zT_86 = zT_82.data.payload;
    goto z_bb_27;
    z_bb_27:
    semi = zT_86;
    zT_88 = semi.span_start;
    zT_89 = semi.span_len;
    zT_91 = zT_88 + (unsigned int)((unsigned int)zT_89);
    end_pos = zT_91;
    zT_93 = "v";
    zT_95 = 1;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    vok = zT_94;
    zT_96 = vok;
    zF_48AC7B3A_markerWrite(zT_96);
    zT_98 = "PDVx";
    zT_100 = 4;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    pdv_s = zT_99;
    zT_101 = pdv_s;
    zF_48AC7B3A_markerWrite(zT_101);
    if ((unsigned char)(init_node != (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_105 = self->store;
    zT_106 = init_node;
    zT_108 = zF_FCDD1D35_astStoreNodeAt(zT_105, zT_106);
    init_check = zT_108;
    zT_109 = init_check.kind;
    if ((unsigned char)(zT_109 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_114 = self->store;
    zT_116 = flags;
    zT_117 = kw.span_start;
    zT_118 = end_pos;
    zT_119 = type_node;
    zT_120 = init_node;
    zT_127 = 0;
    zT_122 = name_id;
    zT_129 = zF_6C9FF72F_astStoreAddNode(zT_114, (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl), zT_116, zT_117, zT_118, zT_119, zT_120, (unsigned int)((unsigned int)zT_127), zT_122);
    zT_130.data.payload = zT_129;
    zT_130.is_error = 0;
    return zT_130;
    z_bb_30:
    zT_113.data.payload = init_node;
    zT_113.is_error = 0;
    return zT_113;
    z_bb_31:
    goto z_bb_29;
}

/* parserParsePubDecl */
zT_3B6EA323_EU_01 zF_A8314C30_parserParsePubDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_10;
    unsigned char zT_15;
    unsigned int zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_35 = {0};
    zT_EAC3E484_TokenKind zT_36;
    zT_B559F9DA_Parser* zT_40;
    zT_3B6EA323_EU_01 zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3B6EA323_EU_01 zT_63 = {0};
    zT_EAC3E484_TokenKind zT_64;
    zT_B559F9DA_Parser* zT_68;
    zT_3B6EA323_EU_01 zT_71 = {0};
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_DBF3575C_ParserError zT_79;
    zT_3B6EA323_EU_01 zT_80;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    tok = zT_5;
    zT_6 = tok.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_20 = 0;
    zT_15 = zT_20;
    zT_21 = zF_3D879A25_parserParseFnDecl(zT_10, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), zT_15);
    return zT_21;
    z_bb_2:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = self;
    zT_35 = zF_7D11B416_parserParseVarDecl(zT_26, (unsigned char)(0), (unsigned char)(1), (unsigned char)(0), (unsigned char)(0));
    return zT_35;
    z_bb_4:
    zT_36 = tok.kind;
    if ((unsigned char)(zT_36 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_40 = self;
    zT_49 = zF_7D11B416_parserParseVarDecl(zT_40, (unsigned char)(1), (unsigned char)(1), (unsigned char)(0), (unsigned char)(0));
    return zT_49;
    z_bb_6:
    zT_50 = tok.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_54 = self;
    zT_55 = zF_15A196A5_parserParseTestDecl(zT_54);
    return zT_55;
    z_bb_8:
    zT_56 = tok.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_60 = self;
    zT_63 = zF_A0D31A63_parserParseExternDe(zT_60, (unsigned char)(1));
    return zT_63;
    z_bb_10:
    zT_64 = tok.kind;
    if ((unsigned char)(zT_64 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_68 = self;
    zT_71 = zF_C3CD8237_parserParseExportDe(zT_68, (unsigned char)(1));
    return zT_71;
    z_bb_12:
    zT_73 = "expected fn/const/var after pub";
    zT_75 = 31;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    p_msg = zT_74;
    zT_76 = self;
    zT_77 = tok;
    zT_78 = p_msg;
    zF_17DF2CA5_parserAddError(zT_76, zT_77, zT_78);
    zT_79 = 1;
    zT_80.data.err = zT_79;
    zT_80.is_error = 1;
    return zT_80;
}

/* parserClassifyCallConv */
unsigned char zF_A095D9EA_parserClassifyCallC(zT_B559F9DA_Parser* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    unsigned char zT_6;
    unsigned char* zT_7;
    int zT_8;
    unsigned char zT_9;
    unsigned int zT_14;
    int zT_15;
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    unsigned char* zT_24;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned char* zT_30;
    int zT_31;
    unsigned char zT_32;
    unsigned char zT_35;
    unsigned char* zT_36;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char* zT_42;
    int zT_43;
    unsigned char zT_44;
    unsigned int zT_49;
    int zT_50;
    unsigned char zT_52;
    unsigned char* zT_53;
    int zT_54;
    unsigned char zT_55;
    unsigned char zT_58;
    unsigned char* zT_59;
    int zT_60;
    unsigned char zT_61;
    unsigned char zT_64;
    unsigned char* zT_65;
    int zT_66;
    unsigned char zT_67;
    unsigned char zT_70;
    unsigned char* zT_71;
    int zT_72;
    unsigned char zT_73;
    unsigned char zT_76;
    unsigned char* zT_77;
    int zT_78;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned char zT_85;
    unsigned char zT_88;
    unsigned char* zT_89;
    int zT_90;
    unsigned char zT_91;
    (void)self;
    zT_3 = text.len;
    zT_4 = 1;
    if ((unsigned char)(zT_3 == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = text.ptr;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    zT_6 = zT_9 == (unsigned char)(99);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_14 = text.len;
    zT_15 = 5;
    if ((unsigned char)(zT_14 == (unsigned int)zT_15)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = text.ptr;
    zT_19 = 0;
    zT_20 = zT_18[zT_19];
    zT_17 = zT_20 == (unsigned char)(99);
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_24 = text.ptr;
    zT_25 = 1;
    zT_26 = zT_24[zT_25];
    zT_23 = zT_26 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_23 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_23) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = text.ptr;
    zT_31 = 2;
    zT_32 = zT_30[zT_31];
    zT_29 = zT_32 == (unsigned char)(101);
    goto z_bb_14;
    z_bb_13:
    zT_29 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_29) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_36 = text.ptr;
    zT_37 = 3;
    zT_38 = zT_36[zT_37];
    zT_35 = zT_38 == (unsigned char)(99);
    goto z_bb_17;
    z_bb_16:
    zT_35 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_35) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_42 = text.ptr;
    zT_43 = 4;
    zT_44 = zT_42[zT_43];
    zT_41 = zT_44 == (unsigned char)(108);
    goto z_bb_20;
    z_bb_19:
    zT_41 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_41) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_49 = text.len;
    zT_50 = 7;
    if ((unsigned char)(zT_49 == (unsigned int)zT_50)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_53 = text.ptr;
    zT_54 = 0;
    zT_55 = zT_53[zT_54];
    zT_52 = zT_55 == (unsigned char)(115);
    goto z_bb_25;
    z_bb_24:
    zT_52 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_52) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_59 = text.ptr;
    zT_60 = 1;
    zT_61 = zT_59[zT_60];
    zT_58 = zT_61 == (unsigned char)(116);
    goto z_bb_28;
    z_bb_27:
    zT_58 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_58) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_65 = text.ptr;
    zT_66 = 2;
    zT_67 = zT_65[zT_66];
    zT_64 = zT_67 == (unsigned char)(100);
    goto z_bb_31;
    z_bb_30:
    zT_64 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_64) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_71 = text.ptr;
    zT_72 = 3;
    zT_73 = zT_71[zT_72];
    zT_70 = zT_73 == (unsigned char)(99);
    goto z_bb_34;
    z_bb_33:
    zT_70 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_70) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_77 = text.ptr;
    zT_78 = 4;
    zT_79 = zT_77[zT_78];
    zT_76 = zT_79 == (unsigned char)(97);
    goto z_bb_37;
    z_bb_36:
    zT_76 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_76) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_83 = text.ptr;
    zT_84 = 5;
    zT_85 = zT_83[zT_84];
    zT_82 = zT_85 == (unsigned char)(108);
    goto z_bb_40;
    z_bb_39:
    zT_82 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_82) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_89 = text.ptr;
    zT_90 = 6;
    zT_91 = zT_89[zT_90];
    zT_88 = zT_91 == (unsigned char)(108);
    goto z_bb_43;
    z_bb_42:
    zT_88 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_88) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    return (unsigned char)(1);
    z_bb_45:
    return (unsigned char)(2);
}

/* parserAddErrorCode */
void zF_6E7AEAB4_parserAddErrorCode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned short code, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_4;
    unsigned short zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_4 = self->diag;
    zT_6 = code;
    zT_7 = self->file_id;
    zT_8 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_10 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_4, (unsigned char)(0), zT_6, zT_7, zT_8, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_10);
    return;
}

/* parserParseExternDecl */
zT_3B6EA323_EU_01 zF_A0D31A63_parserParseExternDe(zT_B559F9DA_Parser* self, unsigned char is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token zT_7 = {0};
    zT_EAC3E484_TokenKind zT_8;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_D3EB6303_StringInterner* zT_16;
    unsigned int zT_17;
    zT_85CBA4DB_TokenValue zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char zT_24 = 0;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_35;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_39;
    zT_3A355BD2_Token zT_40 = {0};
    zT_EAC3E484_TokenKind zT_41;
    zT_B559F9DA_Parser* zT_45;
    unsigned char zT_46;
    unsigned char zT_50;
    zT_3B6EA323_EU_01 zT_54 = {0};
    zT_EAC3E484_TokenKind zT_55;
    zT_B559F9DA_Parser* zT_59;
    unsigned char zT_61;
    zT_3B6EA323_EU_01 zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_72;
    unsigned char zT_74;
    zT_3B6EA323_EU_01 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_B559F9DA_Parser* zT_85;
    zT_3A355BD2_Token zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_DBF3575C_ParserError zT_88;
    zT_3B6EA323_EU_01 zT_89;
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u e_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = 0;
    call_conv = zT_5;
    zT_6 = self;
    zT_7 = zF_068A2DE5_parserPeek(zT_6);
    zT_8 = zT_7.kind;
    if ((unsigned char)(zT_8 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    str_tok = zT_14;
    zT_16 = self->interner;
    zT_19 = str_tok.value;
    zT_17 = zT_19.string_id;
    zT_21 = zF_9134020D_stringInternerGet(zT_16, zT_17);
    text = zT_21;
    zT_22 = self;
    zT_23 = text;
    zT_24 = zF_A095D9EA_parserClassifyCallC(zT_22, zT_23);
    call_conv = zT_24;
    if ((unsigned char)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_39 = self;
    zT_40 = zF_068A2DE5_parserPeek(zT_39);
    tok = zT_40;
    zT_41 = tok.kind;
    if ((unsigned char)(zT_41 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_28 = "unknown calling convention in `extern`";
    zT_30 = 38;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ucv = zT_29;
    zT_31 = self;
    zT_32 = str_tok;
    zT_35 = 3045;
    zT_34 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_31, zT_32, (unsigned short)((unsigned short)zT_35), zT_34);
    zT_37 = 0;
    call_conv = zT_37;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = self;
    zT_46 = is_pub;
    zT_50 = call_conv;
    zT_54 = zF_3D879A25_parserParseFnDecl(zT_45, zT_46, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), zT_50);
    return zT_54;
    z_bb_6:
    zT_55 = tok.kind;
    if ((unsigned char)(zT_55 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_59 = self;
    zT_61 = is_pub;
    zT_67 = zF_7D11B416_parserParseVarDecl(zT_59, (unsigned char)(0), zT_61, (unsigned char)(1), (unsigned char)(0));
    return zT_67;
    z_bb_8:
    zT_68 = tok.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_72 = self;
    zT_74 = is_pub;
    zT_80 = zF_7D11B416_parserParseVarDecl(zT_72, (unsigned char)(1), zT_74, (unsigned char)(1), (unsigned char)(0));
    return zT_80;
    z_bb_10:
    zT_82 = "expected fn/const/var after extern";
    zT_84 = 34;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    e_msg = zT_83;
    zT_85 = self;
    zT_86 = tok;
    zT_87 = e_msg;
    zF_17DF2CA5_parserAddError(zT_85, zT_86, zT_87);
    zT_88 = 1;
    zT_89.data.err = zT_88;
    zT_89.is_error = 1;
    return zT_89;
}

/* parserParseExportDecl */
zT_3B6EA323_EU_01 zF_C3CD8237_parserParseExportDe(zT_B559F9DA_Parser* self, unsigned char is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned int zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    unsigned char zT_28;
    zT_3B6EA323_EU_01 zT_34 = {0};
    zT_EAC3E484_TokenKind zT_35;
    zT_B559F9DA_Parser* zT_39;
    unsigned char zT_41;
    zT_3B6EA323_EU_01 zT_47 = {0};
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_DBF3575C_ParserError zT_55;
    zT_3B6EA323_EU_01 zT_56;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u x_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = is_pub;
    zT_20 = 0;
    zT_16 = zT_20;
    zT_21 = zF_3D879A25_parserParseFnDecl(zT_11, zT_12, (unsigned char)(0), (unsigned char)(0), (unsigned char)(1), zT_16);
    return zT_21;
    z_bb_2:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = self;
    zT_28 = is_pub;
    zT_34 = zF_7D11B416_parserParseVarDecl(zT_26, (unsigned char)(0), zT_28, (unsigned char)(0), (unsigned char)(1));
    return zT_34;
    z_bb_4:
    zT_35 = tok.kind;
    if ((unsigned char)(zT_35 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_39 = self;
    zT_41 = is_pub;
    zT_47 = zF_7D11B416_parserParseVarDecl(zT_39, (unsigned char)(1), zT_41, (unsigned char)(0), (unsigned char)(1));
    return zT_47;
    z_bb_6:
    zT_49 = "expected fn/const/var after export";
    zT_51 = 34;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    x_msg = zT_50;
    zT_52 = self;
    zT_53 = tok;
    zT_54 = x_msg;
    zF_17DF2CA5_parserAddError(zT_52, zT_53, zT_54);
    zT_55 = 1;
    zT_56.data.err = zT_55;
    zT_56.is_error = 1;
    return zT_56;
}

/* parserParseFnDecl */
zT_3B6EA323_EU_01 zF_3D879A25_parserParseFnDecl(zT_B559F9DA_Parser* self, unsigned char is_pub, unsigned char is_extern, unsigned char is_test, unsigned char is_export, unsigned char call_conv) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    int zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    unsigned char zT_20;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_B559F9DA_Parser* zT_26;
    zT_CB78802F_EU_49 zT_30 = {0};
    unsigned char zT_31;
    int zT_32;
    zT_3B6EA323_EU_01 zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    int zT_44;
    zT_B559F9DA_Parser* zT_46;
    zT_3A355BD2_Token zT_47 = {0};
    zT_EAC3E484_TokenKind zT_48;
    unsigned char zT_52;
    zT_B559F9DA_Parser* zT_53;
    zT_3A355BD2_Token zT_54 = {0};
    zT_EAC3E484_TokenKind zT_55;
    zT_B559F9DA_Parser* zT_59;
    zT_3A355BD2_Token zT_60 = {0};
    zT_EAC3E484_TokenKind zT_61;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    unsigned char zT_68;
    zT_B559F9DA_Parser* zT_70;
    zT_CB78802F_EU_49 zT_74 = {0};
    unsigned char zT_75;
    int zT_76;
    zT_3B6EA323_EU_01 zT_77;
    zT_2B3424E9_ParseToken zT_78;
    zT_B559F9DA_Parser* zT_79;
    zT_CB78802F_EU_49 zT_83 = {0};
    unsigned char zT_84;
    int zT_85;
    zT_3B6EA323_EU_01 zT_86;
    zT_2B3424E9_ParseToken zT_87;
    zT_B559F9DA_Parser* zT_89;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    zT_B559F9DA_Parser* zT_94;
    zT_2B3424E9_ParseToken zT_95;
    unsigned int zT_96 = 0;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_106;
    int zT_110;
    int zT_114;
    int zT_116;
    unsigned int zT_118 = 0;
    unsigned int** zT_119;
    unsigned int* zT_120;
    unsigned int* zT_121;
    zT_3E40CD83_Sand* zT_122;
    unsigned int zT_123;
    zT_B559F9DA_Parser* zT_128;
    zT_3A355BD2_Token zT_129 = {0};
    zT_EAC3E484_TokenKind zT_130;
    zT_B559F9DA_Parser* zT_134;
    zT_3A355BD2_Token zT_135 = {0};
    zT_B559F9DA_Parser* zT_136;
    zT_CB78802F_EU_49 zT_140 = {0};
    unsigned char zT_141;
    int zT_142;
    zT_3B6EA323_EU_01 zT_143;
    zT_2B3424E9_ParseToken zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned short zT_149;
    unsigned int zT_150;
    zT_6B0A7D14_AstStore* zT_154;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_155;
    unsigned int* zT_157;
    unsigned int zT_158;
    int zT_159;
    unsigned int* zT_160;
    unsigned int zT_161;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_162;
    unsigned int zT_163 = 0;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    zT_79FAE712_u64 zT_167 = 0;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned short zT_172;
    int zT_173;
    int zT_176;
    unsigned int zT_177;
    zT_B559F9DA_Parser* zT_178;
    zT_3A355BD2_Token zT_179 = {0};
    zT_EAC3E484_TokenKind zT_180;
    zT_B559F9DA_Parser* zT_184;
    zT_3A355BD2_Token zT_185 = {0};
    zT_B559F9DA_Parser* zT_186;
    zT_3B6EA323_EU_01 zT_187 = {0};
    unsigned char zT_188;
    unsigned int zT_189;
    zT_B559F9DA_Parser* zT_190;
    zT_3A355BD2_Token zT_191 = {0};
    zT_EAC3E484_TokenKind zT_192;
    unsigned char zT_196;
    zT_B559F9DA_Parser* zT_197;
    zT_3A355BD2_Token zT_198 = {0};
    zT_EAC3E484_TokenKind zT_199;
    zT_B559F9DA_Parser* zT_203;
    zT_3B6EA323_EU_01 zT_204 = {0};
    unsigned char zT_205;
    unsigned int zT_206;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211 = 0;
    zT_B559F9DA_Parser* zT_212;
    zT_3A355BD2_Token zT_213 = {0};
    zT_EAC3E484_TokenKind zT_214;
    zT_B559F9DA_Parser* zT_219;
    zT_3A355BD2_Token zT_220 = {0};
    unsigned int zT_221;
    unsigned short zT_222;
    unsigned int zT_224;
    zT_B559F9DA_Parser* zT_225;
    zT_3B6EA323_EU_01 zT_226 = {0};
    unsigned char zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    zT_B559F9DA_Parser* zT_239;
    zT_2B3424E9_ParseToken zT_240;
    unsigned int zT_241 = 0;
    unsigned char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    zT_243D6A41_FnProto zT_250;
    zT_6B0A7D14_AstStore* zT_252;
    zT_243D6A41_FnProto zT_253;
    unsigned int zT_255 = 0;
    int zT_256;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    zT_6B0A7D14_AstStore* zT_263;
    unsigned char zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_271;
    int zT_276;
    int zT_278;
    unsigned int zT_280 = 0;
    zT_3B6EA323_EU_01 zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmsg;
    zT_3A355BD2_Token kw;
    unsigned char flags;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken param_tok;
    unsigned int param_type;
    unsigned int param_name_id;
    unsigned int param_node;
    unsigned int param_start;
    unsigned short param_count;
    unsigned int pp;
    unsigned int ret_type_node;
    unsigned int body_node;
    unsigned int end_pos;
    zT_3A355BD2_Token semi;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_243D6A41_FnProto proto;
    unsigned int proto_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u fok;
    zT_7 = "Fv";
    zT_9 = 2;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    fmsg = zT_8;
    zT_10 = fmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    kw = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned char)zT_15;
    flags = zT_16;
    if (is_pub) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = flags | (unsigned char)(2);
    flags = zT_18;
    goto z_bb_2;
    z_bb_2:
    if (is_extern) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = flags | (unsigned char)(4);
    flags = zT_20;
    goto z_bb_4;
    z_bb_4:
    if (is_test) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = flags | (unsigned char)(32);
    flags = zT_22;
    goto z_bb_6;
    z_bb_6:
    if (is_export) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = flags | (unsigned char)(8);
    flags = zT_24;
    goto z_bb_8;
    z_bb_8:
    zT_26 = self;
    zT_30 = zF_5578C74F_parserExpect(zT_26, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = zT_30.data.err;
    zT_33.data.err = zT_32;
    zT_33.is_error = 1;
    return zT_33;
    z_bb_10:
    zT_34 = zT_30.data.payload;
    goto z_bb_11;
    z_bb_11:
    name_tok = zT_34;
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_13:
    zT_43 = zT_39.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_43;
    zT_44 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_44);
    goto z_bb_15;
    z_bb_15:
    zT_46 = self;
    zT_47 = zF_068A2DE5_parserPeek(zT_46);
    zT_48 = zT_47.kind;
    if ((unsigned char)(zT_48 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_59 = self;
    zT_60 = zF_068A2DE5_parserPeek(zT_59);
    zT_61 = zT_60.kind;
    if ((unsigned char)(zT_61 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_22; else goto z_bb_23;
    z_bb_17:
    zT_136 = self;
    zT_140 = zF_5578C74F_parserExpect(zT_136, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_141 = zT_140.is_error;
    if (zT_141) goto z_bb_35; else goto z_bb_36;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_53 = self;
    zT_54 = zF_068A2DE5_parserPeek(zT_53);
    zT_55 = zT_54.kind;
    zT_52 = zT_55 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_21;
    z_bb_20:
    zT_52 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_52) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_65 = self;
    zT_66 = zF_C241B2C4_parserAdvance(zT_65);
    (void)zT_66;
    zT_68 = flags | (unsigned char)(1);
    flags = zT_68;
    goto z_bb_17;
    z_bb_23:
    zT_70 = self;
    zT_74 = zF_5578C74F_parserExpect(zT_70, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_76 = zT_74.data.err;
    zT_77.data.err = zT_76;
    zT_77.is_error = 1;
    return zT_77;
    z_bb_25:
    zT_78 = zT_74.data.payload;
    goto z_bb_26;
    z_bb_26:
    param_tok = zT_78;
    zT_79 = self;
    zT_83 = zF_5578C74F_parserExpect(zT_79, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_84 = zT_83.is_error;
    if (zT_84) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_85 = zT_83.data.err;
    zT_86.data.err = zT_85;
    zT_86.is_error = 1;
    return zT_86;
    z_bb_28:
    zT_87 = zT_83.data.payload;
    goto z_bb_29;
    z_bb_29:
    (void)zT_87;
    zT_89 = self;
    zT_90 = zF_CBDBFE85_parserParseType(zT_89);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    return zT_90;
    z_bb_31:
    zT_92 = zT_90.data.payload;
    goto z_bb_32;
    z_bb_32:
    param_type = zT_92;
    zT_94 = self;
    zT_95 = param_tok;
    zT_96 = zF_ED2167CA_parserInternParseTo(zT_94, zT_95);
    param_name_id = zT_96;
    zT_98 = self->store;
    zT_110 = 0;
    zT_101 = param_tok.span_start;
    zT_102 = self->last_end;
    zT_103 = param_type;
    zT_114 = 0;
    zT_116 = 0;
    zT_106 = param_name_id;
    zT_118 = zF_6C9FF72F_astStoreAddNode(zT_98, (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl), (unsigned char)((unsigned char)zT_110), zT_101, zT_102, zT_103, (unsigned int)((unsigned int)zT_114), (unsigned int)((unsigned int)zT_116), zT_106);
    param_node = zT_118;
    zT_119 = &self->child_buf_items;
    zT_120 = &self->child_buf_len;
    zT_121 = &self->child_buf_capacity;
    zT_122 = self->allocator;
    zT_123 = param_node;
    zF_8B163A32_u32ArrayListAppendI(zT_119, zT_120, zT_121, zT_122, zT_123);
    zT_128 = self;
    zT_129 = zF_068A2DE5_parserPeek(zT_128);
    zT_130 = zT_129.kind;
    if ((unsigned char)(zT_130 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_134 = self;
    zT_135 = zF_C241B2C4_parserAdvance(zT_134);
    (void)zT_135;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_18;
    z_bb_35:
    zT_142 = zT_140.data.err;
    zT_143.data.err = zT_142;
    zT_143.is_error = 1;
    return zT_143;
    z_bb_36:
    zT_144 = zT_140.data.payload;
    goto z_bb_37;
    z_bb_37:
    (void)zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    param_start = zT_147;
    zT_149 = 0;
    param_count = zT_149;
    zT_150 = self->child_buf_len;
    if ((unsigned char)(zT_150 > (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_154 = self->store;
    zT_157 = self->child_buf_items;
    zT_158 = self->child_buf_len;
    zT_159 = 0;
    zT_160 = zT_157 + zT_159;
    zT_161 = zT_158 - zT_159;
    zT_162.ptr = zT_160;
    zT_162.len = zT_161;
    zT_155 = zT_162;
    zT_163 = zF_583E993C_astStoreAddExtraChi(zT_154, zT_155);
    pp = zT_163;
    zT_164 = self->store;
    zT_165 = pp;
    zT_167 = zF_F956A1CA_astStoreExtraRangeA(zT_164, zT_165);
    zT_170 = (unsigned int)(zT_79FAE712_u64)(zT_167 >> (zT_79FAE712_u64)(32));
    param_start = zT_170;
    zT_171 = self->child_buf_len;
    zT_172 = (unsigned short)zT_171;
    param_count = zT_172;
    zT_173 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_173);
    goto z_bb_39;
    z_bb_39:
    zT_176 = 0;
    zT_177 = (unsigned int)zT_176;
    ret_type_node = zT_177;
    zT_178 = self;
    zT_179 = zF_068A2DE5_parserPeek(zT_178);
    zT_180 = zT_179.kind;
    if ((unsigned char)(zT_180 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_184 = self;
    zT_185 = zF_C241B2C4_parserAdvance(zT_184);
    (void)zT_185;
    zT_186 = self;
    zT_187 = zF_CBDBFE85_parserParseType(zT_186);
    zT_188 = zT_187.is_error;
    if (zT_188) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_208 = 0;
    zT_209 = (unsigned int)zT_208;
    body_node = zT_209;
    end_pos = zT_211;
    zT_212 = self;
    zT_213 = zF_068A2DE5_parserPeek(zT_212);
    zT_214 = zT_213.kind;
    if ((unsigned char)(zT_214 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_54; else goto z_bb_56;
    z_bb_42:
    zT_190 = self;
    zT_191 = zF_068A2DE5_parserPeek(zT_190);
    zT_192 = zT_191.kind;
    if ((unsigned char)(zT_192 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_187;
    z_bb_44:
    zT_189 = zT_187.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type_node = zT_189;
    goto z_bb_41;
    z_bb_46:
    zT_197 = self;
    zT_198 = zF_068A2DE5_parserPeek(zT_197);
    zT_199 = zT_198.kind;
    zT_196 = zT_199 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_48;
    z_bb_47:
    zT_196 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_196) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_203 = self;
    zT_204 = zF_CBDBFE85_parserParseType(zT_203);
    zT_205 = zT_204.is_error;
    if (zT_205) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_41;
    z_bb_51:
    return zT_204;
    z_bb_52:
    zT_206 = zT_204.data.payload;
    goto z_bb_53;
    z_bb_53:
    ret_type_node = zT_206;
    goto z_bb_50;
    z_bb_54:
    zT_219 = self;
    zT_220 = zF_C241B2C4_parserAdvance(zT_219);
    semi = zT_220;
    zT_221 = semi.span_start;
    zT_222 = semi.span_len;
    zT_224 = zT_221 + (unsigned int)((unsigned int)zT_222);
    end_pos = zT_224;
    goto z_bb_55;
    z_bb_55:
    zT_230 = self->child_buf_len;
    if ((unsigned char)(zT_230 > (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    zT_225 = self;
    zT_226 = zF_365CA04A_parserParseBlock(zT_225);
    zT_227 = zT_226.is_error;
    if (zT_227) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return zT_226;
    z_bb_58:
    zT_228 = zT_226.data.payload;
    goto z_bb_59;
    z_bb_59:
    body_node = zT_228;
    zT_229 = self->last_end;
    end_pos = zT_229;
    goto z_bb_55;
    z_bb_60:
    zT_234 = "DP:child_buf_stale\n";
    zT_236 = 19;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    dmsg = zT_235;
    zT_237 = dmsg;
    zF_48AC7B3A_markerWrite(zT_237);
    goto z_bb_61;
    z_bb_61:
    zT_239 = self;
    zT_240 = name_tok;
    zT_241 = zF_ED2167CA_parserInternParseTo(zT_239, zT_240);
    name_id = zT_241;
    zT_243 = "P:";
    zT_245 = 2;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    pmsg = zT_244;
    zT_246 = pmsg;
    zF_C914CB83_markerWriteInt(zT_246, (unsigned int)((unsigned int)param_count));
    zT_250.name_id = name_id;
    zT_250.params_start = param_start;
    zT_250.params_count = param_count;
    zT_250.call_conv = call_conv;
    zT_250.return_type_node = ret_type_node;
    proto = zT_250;
    zT_252 = self->store;
    zT_253 = proto;
    zT_255 = zF_F1F8D02B_astStoreAddFnProto(zT_252, zT_253);
    proto_idx = zT_255;
    zT_256 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_256);
    zT_259 = "Fk";
    zT_261 = 2;
    zT_260.ptr = zT_259;
    zT_260.len = zT_261;
    fok = zT_260;
    zT_262 = fok;
    zF_48AC7B3A_markerWrite(zT_262);
    zT_263 = self->store;
    zT_265 = flags;
    zT_266 = kw.span_start;
    zT_267 = end_pos;
    zT_268 = body_node;
    zT_276 = 0;
    zT_278 = 0;
    zT_271 = proto_idx;
    zT_280 = zF_6C9FF72F_astStoreAddNode(zT_263, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl), zT_265, zT_266, zT_267, zT_268, (unsigned int)((unsigned int)zT_276), (unsigned int)((unsigned int)zT_278), zT_271);
    zT_281.data.payload = zT_280;
    zT_281.is_error = 0;
    return zT_281;
}

/* parserParseIfStmt */
zT_3B6EA323_EU_01 zF_DB819578_parserParseIfStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_39;
    zT_CF7AC512_EU_59 zT_40 = {0};
    unsigned char zT_41;
    int zT_42;
    zT_3B6EA323_EU_01 zT_43;
    zT_A68A775E_ParseCapture zT_44;
    zT_B559F9DA_Parser* zT_45;
    zT_CB78802F_EU_49 zT_49 = {0};
    unsigned char zT_50;
    int zT_51;
    zT_3B6EA323_EU_01 zT_52;
    zT_2B3424E9_ParseToken zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_57;
    unsigned int zT_62;
    int zT_66;
    unsigned int zT_69;
    unsigned short zT_70;
    int zT_73;
    int zT_75;
    int zT_77;
    unsigned int zT_80 = 0;
    unsigned int zT_82 = 0;
    zT_B559F9DA_Parser* zT_83;
    zT_3A355BD2_Token zT_84 = {0};
    zT_EAC3E484_TokenKind zT_85;
    zT_B559F9DA_Parser* zT_89;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    zT_B559F9DA_Parser* zT_93;
    zT_3B6EA323_EU_01 zT_94 = {0};
    unsigned char zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    zT_22A7C88B_AstNode zT_112 = {0};
    zT_8143F551_AstKind zT_113;
    int zT_116;
    unsigned int zT_117;
    zT_B559F9DA_Parser* zT_118;
    zT_3A355BD2_Token zT_119 = {0};
    zT_EAC3E484_TokenKind zT_120;
    zT_B559F9DA_Parser* zT_124;
    zT_3A355BD2_Token zT_125 = {0};
    zT_B559F9DA_Parser* zT_126;
    zT_3A355BD2_Token zT_127 = {0};
    zT_EAC3E484_TokenKind zT_128;
    zT_B559F9DA_Parser* zT_132;
    zT_3B6EA323_EU_01 zT_133 = {0};
    unsigned char zT_134;
    unsigned int zT_135;
    zT_B559F9DA_Parser* zT_136;
    zT_3A355BD2_Token zT_137 = {0};
    zT_EAC3E484_TokenKind zT_138;
    zT_B559F9DA_Parser* zT_142;
    zT_3B6EA323_EU_01 zT_143 = {0};
    unsigned char zT_144;
    unsigned int zT_145;
    zT_B559F9DA_Parser* zT_146;
    zT_3B6EA323_EU_01 zT_147 = {0};
    unsigned char zT_148;
    unsigned int zT_149;
    zT_B559F9DA_Parser* zT_150;
    zT_3A355BD2_Token zT_151 = {0};
    zT_EAC3E484_TokenKind zT_152;
    zT_B559F9DA_Parser* zT_156;
    zT_3A355BD2_Token zT_157 = {0};
    zT_B559F9DA_Parser* zT_158;
    zT_3A355BD2_Token zT_159 = {0};
    zT_EAC3E484_TokenKind zT_160;
    zT_B559F9DA_Parser* zT_165;
    zT_3A355BD2_Token zT_166 = {0};
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_B559F9DA_Parser* zT_171;
    zT_3A355BD2_Token zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    zT_DBF3575C_ParserError zT_174;
    zT_3B6EA323_EU_01 zT_175;
    unsigned int zT_177;
    unsigned char zT_178;
    zT_3A355BD2_Token zT_180;
    unsigned int zT_181;
    unsigned short zT_182;
    unsigned int zT_184;
    zT_6B0A7D14_AstStore* zT_185;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    int zT_197;
    unsigned int zT_200 = 0;
    zT_3B6EA323_EU_01 zT_201;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_node;
    zT_A68A775E_ParseCapture cap;
    unsigned int then_body;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_km;
    unsigned int else_node;
    unsigned int end_pos;
    zT_3A355BD2_Token else_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u else_msg;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    capture_node = zT_31;
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    zT_34 = zT_33.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = self;
    zT_40 = zF_E99FEED2_parserParseCaptureN(zT_39);
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    then_body = zT_82;
    zT_83 = self;
    zT_84 = zF_068A2DE5_parserPeek(zT_83);
    zT_85 = zT_84.kind;
    if ((unsigned char)(zT_85 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_18; else goto z_bb_20;
    z_bb_12:
    zT_42 = zT_40.data.err;
    zT_43.data.err = zT_42;
    zT_43.is_error = 1;
    return zT_43;
    z_bb_13:
    zT_44 = zT_40.data.payload;
    goto z_bb_14;
    z_bb_14:
    cap = zT_44;
    zT_45 = self;
    zT_49 = zF_5578C74F_parserExpect(zT_45, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_51 = zT_49.data.err;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_16:
    zT_53 = zT_49.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_53;
    zT_54 = self->store;
    zT_66 = 0;
    zT_57 = cap.tok_start;
    zT_69 = cap.tok_start;
    zT_70 = cap.tok_len;
    zT_73 = 0;
    zT_75 = 0;
    zT_77 = 0;
    zT_62 = cap.name_id;
    zT_80 = zF_6C9FF72F_astStoreAddNode(zT_54, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_66), zT_57, (unsigned int)(zT_69 + (unsigned int)((unsigned int)zT_70)), (unsigned int)((unsigned int)zT_73), (unsigned int)((unsigned int)zT_75), (unsigned int)((unsigned int)zT_77), zT_62);
    capture_node = zT_80;
    goto z_bb_11;
    z_bb_18:
    zT_89 = self;
    zT_90 = zF_365CA04A_parserParseBlock(zT_89);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_98 = "PIF:b";
    zT_100 = 5;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    pif_m = zT_99;
    zT_101 = pif_m;
    zT_102 = then_body;
    zF_C914CB83_markerWriteInt(zT_101, zT_102);
    zT_104 = "k";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    pif_km = zT_105;
    zT_107 = pif_km;
    zT_109 = self->store;
    zT_110 = then_body;
    zT_112 = zF_FCDD1D35_astStoreNodeAt(zT_109, zT_110);
    zT_113 = zT_112.kind;
    zF_C914CB83_markerWriteInt(zT_107, (unsigned int)((unsigned int)zT_113));
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    else_node = zT_117;
    zT_118 = self;
    zT_119 = zF_068A2DE5_parserPeek(zT_118);
    zT_120 = zT_119.kind;
    if ((unsigned char)(zT_120 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_27; else goto z_bb_28;
    z_bb_20:
    zT_93 = self;
    zT_94 = zF_CE2E1DC0_parserParseStmtBody(zT_93);
    zT_95 = zT_94.is_error;
    if (zT_95) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    return zT_90;
    z_bb_22:
    zT_92 = zT_90.data.payload;
    goto z_bb_23;
    z_bb_23:
    then_body = zT_92;
    goto z_bb_19;
    z_bb_24:
    return zT_94;
    z_bb_25:
    zT_96 = zT_94.data.payload;
    goto z_bb_26;
    z_bb_26:
    then_body = zT_96;
    goto z_bb_19;
    z_bb_27:
    zT_124 = self;
    zT_125 = zF_C241B2C4_parserAdvance(zT_124);
    (void)zT_125;
    zT_126 = self;
    zT_127 = zF_068A2DE5_parserPeek(zT_126);
    zT_128 = zT_127.kind;
    if ((unsigned char)(zT_128 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    zT_150 = self;
    zT_151 = zF_068A2DE5_parserPeek(zT_150);
    zT_152 = zT_151.kind;
    if ((unsigned char)(zT_152 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_44; else goto z_bb_45;
    z_bb_29:
    zT_132 = self;
    zT_133 = zF_DB819578_parserParseIfStmt(zT_132);
    zT_134 = zT_133.is_error;
    if (zT_134) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_136 = self;
    zT_137 = zF_068A2DE5_parserPeek(zT_136);
    zT_138 = zT_137.kind;
    if ((unsigned char)(zT_138 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_35; else goto z_bb_37;
    z_bb_32:
    return zT_133;
    z_bb_33:
    zT_135 = zT_133.data.payload;
    goto z_bb_34;
    z_bb_34:
    else_node = zT_135;
    goto z_bb_30;
    z_bb_35:
    zT_142 = self;
    zT_143 = zF_365CA04A_parserParseBlock(zT_142);
    zT_144 = zT_143.is_error;
    if (zT_144) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_30;
    z_bb_37:
    zT_146 = self;
    zT_147 = zF_CE2E1DC0_parserParseStmtBody(zT_146);
    zT_148 = zT_147.is_error;
    if (zT_148) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    return zT_143;
    z_bb_39:
    zT_145 = zT_143.data.payload;
    goto z_bb_40;
    z_bb_40:
    else_node = zT_145;
    goto z_bb_36;
    z_bb_41:
    return zT_147;
    z_bb_42:
    zT_149 = zT_147.data.payload;
    goto z_bb_43;
    z_bb_43:
    else_node = zT_149;
    goto z_bb_36;
    z_bb_44:
    zT_156 = self;
    zT_157 = zF_C241B2C4_parserAdvance(zT_156);
    (void)zT_157;
    zT_158 = self;
    zT_159 = zF_068A2DE5_parserPeek(zT_158);
    zT_160 = zT_159.kind;
    if ((unsigned char)(zT_160 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_177 = kw.span_start;
    end_pos = zT_177;
    zT_178 = self->last_tok_valid;
    if (zT_178) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_165 = self;
    zT_166 = zF_068A2DE5_parserPeek(zT_165);
    else_tok = zT_166;
    zT_168 = "';' not allowed before 'else' - use braces: if (cond) { ... } else { ... }";
    zT_170 = 74;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    else_msg = zT_169;
    zT_171 = self;
    zT_172 = else_tok;
    zT_173 = else_msg;
    zF_17DF2CA5_parserAddError(zT_171, zT_172, zT_173);
    zT_174 = 1;
    zT_175.data.err = zT_174;
    zT_175.is_error = 1;
    return zT_175;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_180 = self->last_tok;
    last = zT_180;
    zT_181 = last.span_start;
    zT_182 = last.span_len;
    zT_184 = zT_181 + (unsigned int)((unsigned int)zT_182);
    end_pos = zT_184;
    goto z_bb_49;
    z_bb_49:
    zT_185 = self->store;
    zT_197 = 0;
    zT_188 = kw.span_start;
    zT_189 = end_pos;
    zT_190 = cond;
    zT_191 = then_body;
    zT_192 = else_node;
    zT_193 = capture_node;
    zT_200 = zF_6C9FF72F_astStoreAddNode(zT_185, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt), (unsigned char)((unsigned char)zT_197), zT_188, zT_189, zT_190, zT_191, zT_192, zT_193);
    zT_201.data.payload = zT_200;
    zT_201.is_error = 0;
    return zT_201;
}

/* parserParseWhileStmt */
zT_3B6EA323_EU_01 zF_4E7AD820_parserParseWhileStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_42;
    zT_CF7AC512_EU_59 zT_43 = {0};
    unsigned char zT_44;
    int zT_45;
    zT_3B6EA323_EU_01 zT_46;
    zT_A68A775E_ParseCapture zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_52;
    unsigned int zT_57;
    int zT_61;
    unsigned int zT_64;
    unsigned short zT_65;
    int zT_68;
    int zT_70;
    int zT_72;
    unsigned int zT_74 = 0;
    zT_B559F9DA_Parser* zT_75;
    zT_CB78802F_EU_49 zT_79 = {0};
    unsigned char zT_80;
    int zT_81;
    zT_3B6EA323_EU_01 zT_82;
    zT_2B3424E9_ParseToken zT_83;
    int zT_85;
    unsigned int zT_86;
    zT_B559F9DA_Parser* zT_87;
    zT_3A355BD2_Token zT_88 = {0};
    zT_EAC3E484_TokenKind zT_89;
    zT_B559F9DA_Parser* zT_93;
    zT_3A355BD2_Token zT_94 = {0};
    zT_B559F9DA_Parser* zT_95;
    zT_CB78802F_EU_49 zT_99 = {0};
    unsigned char zT_100;
    int zT_101;
    zT_3B6EA323_EU_01 zT_102;
    zT_2B3424E9_ParseToken zT_103;
    zT_B559F9DA_Parser* zT_104;
    zT_3B6EA323_EU_01 zT_105 = {0};
    unsigned char zT_106;
    unsigned int zT_107;
    zT_B559F9DA_Parser* zT_108;
    zT_CB78802F_EU_49 zT_112 = {0};
    unsigned char zT_113;
    int zT_114;
    zT_3B6EA323_EU_01 zT_115;
    zT_2B3424E9_ParseToken zT_116;
    unsigned int zT_118 = 0;
    zT_B559F9DA_Parser* zT_119;
    zT_3A355BD2_Token zT_120 = {0};
    zT_EAC3E484_TokenKind zT_121;
    zT_B559F9DA_Parser* zT_125;
    zT_3B6EA323_EU_01 zT_126 = {0};
    unsigned char zT_127;
    unsigned int zT_128;
    zT_B559F9DA_Parser* zT_129;
    zT_3B6EA323_EU_01 zT_130 = {0};
    unsigned char zT_131;
    unsigned int zT_132;
    zT_B559F9DA_Parser* zT_133;
    zT_3A355BD2_Token zT_134 = {0};
    zT_EAC3E484_TokenKind zT_135;
    zT_B559F9DA_Parser* zT_139;
    zT_3A355BD2_Token zT_140 = {0};
    unsigned int zT_142 = 0;
    unsigned char zT_143;
    zT_3A355BD2_Token zT_145;
    unsigned int zT_146;
    unsigned short zT_147;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    int zT_170;
    unsigned int zT_173 = 0;
    zT_3B6EA323_EU_01 zT_174;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_name;
    unsigned int cap_node;
    zT_A68A775E_ParseCapture cap;
    unsigned int continue_expr;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_8F083A69_Slice_zT_0B42B2F8_u zzz_c2e_m;
    unsigned int zzz_c2;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    capture_name = zT_31;
    zT_33 = 0;
    zT_34 = (unsigned int)zT_33;
    cap_node = zT_34;
    zT_35 = self;
    zT_36 = zF_068A2DE5_parserPeek(zT_35);
    zT_37 = zT_36.kind;
    if ((unsigned char)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = self;
    zT_43 = zF_E99FEED2_parserParseCaptureN(zT_42);
    zT_44 = zT_43.is_error;
    if (zT_44) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_85 = 0;
    zT_86 = (unsigned int)zT_85;
    continue_expr = zT_86;
    zT_87 = self;
    zT_88 = zF_068A2DE5_parserPeek(zT_87);
    zT_89 = zT_88.kind;
    if ((unsigned char)(zT_89 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_18; else goto z_bb_19;
    z_bb_12:
    zT_45 = zT_43.data.err;
    zT_46.data.err = zT_45;
    zT_46.is_error = 1;
    return zT_46;
    z_bb_13:
    zT_47 = zT_43.data.payload;
    goto z_bb_14;
    z_bb_14:
    cap = zT_47;
    zT_48 = cap.name_id;
    capture_name = zT_48;
    zT_49 = self->store;
    zT_61 = 0;
    zT_52 = cap.tok_start;
    zT_64 = cap.tok_start;
    zT_65 = cap.tok_len;
    zT_68 = 0;
    zT_70 = 0;
    zT_72 = 0;
    zT_57 = capture_name;
    zT_74 = zF_6C9FF72F_astStoreAddNode(zT_49, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture), (unsigned char)((unsigned char)zT_61), zT_52, (unsigned int)(zT_64 + (unsigned int)((unsigned int)zT_65)), (unsigned int)((unsigned int)zT_68), (unsigned int)((unsigned int)zT_70), (unsigned int)((unsigned int)zT_72), zT_57);
    cap_node = zT_74;
    zT_75 = self;
    zT_79 = zF_5578C74F_parserExpect(zT_75, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_80 = zT_79.is_error;
    if (zT_80) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_81 = zT_79.data.err;
    zT_82.data.err = zT_81;
    zT_82.is_error = 1;
    return zT_82;
    z_bb_16:
    zT_83 = zT_79.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_83;
    goto z_bb_11;
    z_bb_18:
    zT_93 = self;
    zT_94 = zF_C241B2C4_parserAdvance(zT_93);
    (void)zT_94;
    zT_95 = self;
    zT_99 = zF_5578C74F_parserExpect(zT_95, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_100 = zT_99.is_error;
    if (zT_100) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    body = zT_118;
    zT_119 = self;
    zT_120 = zF_068A2DE5_parserPeek(zT_119);
    zT_121 = zT_120.kind;
    if ((unsigned char)(zT_121 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_29; else goto z_bb_31;
    z_bb_20:
    zT_101 = zT_99.data.err;
    zT_102.data.err = zT_101;
    zT_102.is_error = 1;
    return zT_102;
    z_bb_21:
    zT_103 = zT_99.data.payload;
    goto z_bb_22;
    z_bb_22:
    (void)zT_103;
    zT_104 = self;
    zT_105 = zF_CE2E1DC0_parserParseStmtBody(zT_104);
    zT_106 = zT_105.is_error;
    if (zT_106) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return zT_105;
    z_bb_24:
    zT_107 = zT_105.data.payload;
    goto z_bb_25;
    z_bb_25:
    continue_expr = zT_107;
    zT_108 = self;
    zT_112 = zF_5578C74F_parserExpect(zT_108, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_113 = zT_112.is_error;
    if (zT_113) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_114 = zT_112.data.err;
    zT_115.data.err = zT_114;
    zT_115.is_error = 1;
    return zT_115;
    z_bb_27:
    zT_116 = zT_112.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_116;
    goto z_bb_19;
    z_bb_29:
    zT_125 = self;
    zT_126 = zF_365CA04A_parserParseBlock(zT_125);
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    zT_133 = self;
    zT_134 = zF_068A2DE5_parserPeek(zT_133);
    zT_135 = zT_134.kind;
    if ((unsigned char)(zT_135 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_38; else goto z_bb_39;
    z_bb_31:
    zT_129 = self;
    zT_130 = zF_CE2E1DC0_parserParseStmtBody(zT_129);
    zT_131 = zT_130.is_error;
    if (zT_131) goto z_bb_35; else goto z_bb_36;
    z_bb_32:
    return zT_126;
    z_bb_33:
    zT_128 = zT_126.data.payload;
    goto z_bb_34;
    z_bb_34:
    body = zT_128;
    goto z_bb_30;
    z_bb_35:
    return zT_130;
    z_bb_36:
    zT_132 = zT_130.data.payload;
    goto z_bb_37;
    z_bb_37:
    body = zT_132;
    goto z_bb_30;
    z_bb_38:
    zT_139 = self;
    zT_140 = zF_C241B2C4_parserAdvance(zT_139);
    (void)zT_140;
    goto z_bb_39;
    z_bb_39:
    end_pos = zT_142;
    zT_143 = self->last_tok_valid;
    if (zT_143) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_145 = self->last_tok;
    last = zT_145;
    zT_146 = last.span_start;
    zT_147 = last.span_len;
    zT_149 = zT_146 + (unsigned int)((unsigned int)zT_147);
    end_pos = zT_149;
    goto z_bb_41;
    z_bb_41:
    zT_152 = "PTC2:e";
    zT_154 = 6;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    zzz_c2e_m = zT_153;
    zT_155 = zzz_c2e_m;
    zT_156 = continue_expr;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    zzz_c2 = continue_expr;
    zT_158 = self->store;
    zT_170 = 0;
    zT_161 = kw.span_start;
    zT_162 = end_pos;
    zT_163 = cond;
    zT_164 = body;
    zT_165 = zzz_c2;
    zT_166 = cap_node;
    zT_173 = zF_6C9FF72F_astStoreAddNode(zT_158, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt), (unsigned char)((unsigned char)zT_170), zT_161, zT_162, zT_163, zT_164, zT_165, zT_166);
    zT_174.data.payload = zT_173;
    zT_174.is_error = 0;
    return zT_174;
    z_bb_42:
    zT_150 = kw.span_start;
    end_pos = zT_150;
    goto z_bb_41;
}

/* parserParseForStmt */
zT_3B6EA323_EU_01 zF_54BCF0C6_parserParseForStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3A355BD2_Token zT_27 = {0};
    zT_B559F9DA_Parser* zT_29;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_47;
    int zT_49;
    int zT_51;
    int zT_53;
    int zT_55;
    unsigned int zT_57 = 0;
    zT_B559F9DA_Parser* zT_58;
    zT_3A355BD2_Token zT_59 = {0};
    zT_EAC3E484_TokenKind zT_60;
    zT_B559F9DA_Parser* zT_64;
    zT_3A355BD2_Token zT_65 = {0};
    zT_B559F9DA_Parser* zT_67;
    zT_3A355BD2_Token zT_68 = {0};
    zT_B559F9DA_Parser* zT_70;
    zT_3B6EA323_EU_01 zT_73 = {0};
    unsigned char zT_74;
    unsigned int zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_82;
    zT_CB78802F_EU_49 zT_86 = {0};
    unsigned char zT_87;
    int zT_88;
    zT_3B6EA323_EU_01 zT_89;
    zT_2B3424E9_ParseToken zT_90;
    zT_B559F9DA_Parser* zT_91;
    zT_3A355BD2_Token zT_92 = {0};
    int zT_94;
    unsigned int zT_95;
    zT_B559F9DA_Parser* zT_96;
    zT_3A355BD2_Token zT_97 = {0};
    zT_EAC3E484_TokenKind zT_98;
    zT_B559F9DA_Parser* zT_102;
    zT_3B6EA323_EU_01 zT_105 = {0};
    unsigned char zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned short zT_110;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_3A355BD2_Token zT_115;
    unsigned int zT_116;
    unsigned short zT_117;
    unsigned int zT_119;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_132;
    int zT_135;
    unsigned int zT_137 = 0;
    zT_B559F9DA_Parser* zT_138;
    zT_CB78802F_EU_49 zT_142 = {0};
    unsigned char zT_143;
    int zT_144;
    zT_3B6EA323_EU_01 zT_145;
    zT_2B3424E9_ParseToken zT_146;
    int zT_148;
    unsigned int zT_149;
    int zT_151;
    unsigned int zT_152;
    zT_B559F9DA_Parser* zT_153;
    zT_3A355BD2_Token zT_154 = {0};
    zT_EAC3E484_TokenKind zT_155;
    zT_B559F9DA_Parser* zT_160;
    zT_CF7AC512_EU_59 zT_161 = {0};
    unsigned char zT_162;
    int zT_163;
    zT_3B6EA323_EU_01 zT_164;
    zT_A68A775E_ParseCapture zT_165;
    unsigned int zT_166;
    zT_B559F9DA_Parser* zT_167;
    zT_3A355BD2_Token zT_168 = {0};
    zT_EAC3E484_TokenKind zT_169;
    zT_B559F9DA_Parser* zT_173;
    zT_3A355BD2_Token zT_174 = {0};
    zT_B559F9DA_Parser* zT_176;
    zT_CB78802F_EU_49 zT_180 = {0};
    unsigned char zT_181;
    int zT_182;
    zT_3B6EA323_EU_01 zT_183;
    zT_2B3424E9_ParseToken zT_184;
    zT_B559F9DA_Parser* zT_185;
    zT_2B3424E9_ParseToken zT_186;
    unsigned int zT_187 = 0;
    zT_B559F9DA_Parser* zT_188;
    zT_CB78802F_EU_49 zT_192 = {0};
    unsigned char zT_193;
    int zT_194;
    zT_3B6EA323_EU_01 zT_195;
    zT_2B3424E9_ParseToken zT_196;
    unsigned int zT_198 = 0;
    zT_B559F9DA_Parser* zT_199;
    zT_3A355BD2_Token zT_200 = {0};
    zT_EAC3E484_TokenKind zT_201;
    zT_B559F9DA_Parser* zT_205;
    zT_3B6EA323_EU_01 zT_206 = {0};
    unsigned char zT_207;
    unsigned int zT_208;
    zT_B559F9DA_Parser* zT_209;
    zT_3B6EA323_EU_01 zT_210 = {0};
    unsigned char zT_211;
    unsigned int zT_212;
    zT_B559F9DA_Parser* zT_213;
    zT_3A355BD2_Token zT_214 = {0};
    zT_EAC3E484_TokenKind zT_215;
    zT_B559F9DA_Parser* zT_219;
    zT_3A355BD2_Token zT_220 = {0};
    unsigned int zT_222 = 0;
    unsigned char zT_223;
    zT_3A355BD2_Token zT_225;
    unsigned int zT_226;
    unsigned short zT_227;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    int zT_243;
    unsigned int zT_246 = 0;
    zT_3B6EA323_EU_01 zT_247;
    zT_3A355BD2_Token kw;
    unsigned int pattern;
    unsigned int end_node;
    zT_3A355BD2_Token idx_tok;
    unsigned int idx_start;
    unsigned int idx_end;
    unsigned int idx_span_end;
    zT_3A355BD2_Token idx_last;
    unsigned int capture_name;
    unsigned int index_name;
    zT_A68A775E_ParseCapture cap;
    unsigned int body;
    zT_2B3424E9_ParseToken idx_tok_1;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    pattern = zT_19;
    zT_20 = self;
    zT_21 = zF_068A2DE5_parserPeek(zT_20);
    zT_22 = zT_21.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_26 = self;
    zT_27 = zF_C241B2C4_parserAdvance(zT_26);
    (void)zT_27;
    zT_29 = self;
    zT_32 = zF_F07C1F04_parserParseExprPrec(zT_29, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    zT_138 = self;
    zT_142 = zF_5578C74F_parserExpect(zT_138, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_143 = zT_142.is_error;
    if (zT_143) goto z_bb_30; else goto z_bb_31;
    z_bb_9:
    zT_58 = self;
    zT_59 = zF_068A2DE5_parserPeek(zT_58);
    zT_60 = zT_59.kind;
    if ((unsigned char)(zT_60 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    return zT_32;
    z_bb_11:
    zT_34 = zT_32.data.payload;
    goto z_bb_12;
    z_bb_12:
    end_node = zT_34;
    zT_35 = self->store;
    zT_47 = 0;
    zT_49 = 0;
    zT_51 = 0;
    zT_40 = pattern;
    zT_41 = end_node;
    zT_53 = 0;
    zT_55 = 0;
    zT_57 = zF_6C9FF72F_astStoreAddNode(zT_35, (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive), (unsigned char)((unsigned char)zT_47), (unsigned int)((unsigned int)zT_49), (unsigned int)((unsigned int)zT_51), zT_40, zT_41, (unsigned int)((unsigned int)zT_53), (unsigned int)((unsigned int)zT_55));
    pattern = zT_57;
    goto z_bb_8;
    z_bb_13:
    zT_64 = self;
    zT_65 = zF_C241B2C4_parserAdvance(zT_64);
    (void)zT_65;
    zT_67 = self;
    zT_68 = zF_068A2DE5_parserPeek(zT_67);
    idx_tok = zT_68;
    zT_70 = self;
    zT_73 = zF_F07C1F04_parserParseExprPrec(zT_70, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_74 = zT_73.is_error;
    if (zT_74) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    return zT_73;
    z_bb_16:
    zT_75 = zT_73.data.payload;
    goto z_bb_17;
    z_bb_17:
    idx_start = zT_75;
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_82 = self;
    zT_86 = zF_5578C74F_parserExpect(zT_82, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot));
    zT_87 = zT_86.is_error;
    if (zT_87) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_91 = self;
    zT_92 = zF_C241B2C4_parserAdvance(zT_91);
    (void)zT_92;
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    idx_end = zT_95;
    zT_96 = self;
    zT_97 = zF_068A2DE5_parserPeek(zT_96);
    zT_98 = zT_97.kind;
    if ((unsigned char)(zT_98 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_88 = zT_86.data.err;
    zT_89.data.err = zT_88;
    zT_89.is_error = 1;
    return zT_89;
    z_bb_21:
    zT_90 = zT_86.data.payload;
    goto z_bb_22;
    z_bb_22:
    (void)zT_90;
    goto z_bb_19;
    z_bb_23:
    zT_102 = self;
    zT_105 = zF_F07C1F04_parserParseExprPrec(zT_102, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_106 = zT_105.is_error;
    if (zT_106) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_109 = idx_tok.span_start;
    zT_110 = idx_tok.span_len;
    zT_112 = zT_109 + (unsigned int)((unsigned int)zT_110);
    idx_span_end = zT_112;
    zT_113 = self->last_tok_valid;
    if (zT_113) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    return zT_105;
    z_bb_26:
    zT_107 = zT_105.data.payload;
    goto z_bb_27;
    z_bb_27:
    idx_end = zT_107;
    goto z_bb_24;
    z_bb_28:
    zT_115 = self->last_tok;
    idx_last = zT_115;
    zT_116 = idx_last.span_start;
    zT_117 = idx_last.span_len;
    zT_119 = zT_116 + (unsigned int)((unsigned int)zT_117);
    idx_span_end = zT_119;
    goto z_bb_29;
    z_bb_29:
    zT_120 = self->store;
    zT_132 = 0;
    zT_123 = idx_tok.span_start;
    zT_124 = idx_span_end;
    zT_125 = pattern;
    zT_126 = idx_start;
    zT_127 = idx_end;
    zT_135 = 0;
    zT_137 = zF_6C9FF72F_astStoreAddNode(zT_120, (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_index_range), (unsigned char)((unsigned char)zT_132), zT_123, zT_124, zT_125, zT_126, zT_127, (unsigned int)((unsigned int)zT_135));
    pattern = zT_137;
    goto z_bb_14;
    z_bb_30:
    zT_144 = zT_142.data.err;
    zT_145.data.err = zT_144;
    zT_145.is_error = 1;
    return zT_145;
    z_bb_31:
    zT_146 = zT_142.data.payload;
    goto z_bb_32;
    z_bb_32:
    (void)zT_146;
    zT_148 = 0;
    zT_149 = (unsigned int)zT_148;
    capture_name = zT_149;
    zT_151 = 0;
    zT_152 = (unsigned int)zT_151;
    index_name = zT_152;
    zT_153 = self;
    zT_154 = zF_068A2DE5_parserPeek(zT_153);
    zT_155 = zT_154.kind;
    if ((unsigned char)(zT_155 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_160 = self;
    zT_161 = zF_E99FEED2_parserParseCaptureN(zT_160);
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    body = zT_198;
    zT_199 = self;
    zT_200 = zF_068A2DE5_parserPeek(zT_199);
    zT_201 = zT_200.kind;
    if ((unsigned char)(zT_201 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_46; else goto z_bb_48;
    z_bb_35:
    zT_163 = zT_161.data.err;
    zT_164.data.err = zT_163;
    zT_164.is_error = 1;
    return zT_164;
    z_bb_36:
    zT_165 = zT_161.data.payload;
    goto z_bb_37;
    z_bb_37:
    cap = zT_165;
    zT_166 = cap.name_id;
    capture_name = zT_166;
    zT_167 = self;
    zT_168 = zF_068A2DE5_parserPeek(zT_167);
    zT_169 = zT_168.kind;
    if ((unsigned char)(zT_169 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_173 = self;
    zT_174 = zF_C241B2C4_parserAdvance(zT_173);
    (void)zT_174;
    zT_176 = self;
    zT_180 = zF_5578C74F_parserExpect(zT_176, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_181 = zT_180.is_error;
    if (zT_181) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_188 = self;
    zT_192 = zF_5578C74F_parserExpect(zT_188, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_193 = zT_192.is_error;
    if (zT_193) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_182 = zT_180.data.err;
    zT_183.data.err = zT_182;
    zT_183.is_error = 1;
    return zT_183;
    z_bb_41:
    zT_184 = zT_180.data.payload;
    goto z_bb_42;
    z_bb_42:
    idx_tok_1 = zT_184;
    zT_185 = self;
    zT_186 = idx_tok_1;
    zT_187 = zF_ED2167CA_parserInternParseTo(zT_185, zT_186);
    index_name = zT_187;
    goto z_bb_39;
    z_bb_43:
    zT_194 = zT_192.data.err;
    zT_195.data.err = zT_194;
    zT_195.is_error = 1;
    return zT_195;
    z_bb_44:
    zT_196 = zT_192.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_196;
    goto z_bb_34;
    z_bb_46:
    zT_205 = self;
    zT_206 = zF_365CA04A_parserParseBlock(zT_205);
    zT_207 = zT_206.is_error;
    if (zT_207) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_213 = self;
    zT_214 = zF_068A2DE5_parserPeek(zT_213);
    zT_215 = zT_214.kind;
    if ((unsigned char)(zT_215 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_55; else goto z_bb_56;
    z_bb_48:
    zT_209 = self;
    zT_210 = zF_CE2E1DC0_parserParseStmtBody(zT_209);
    zT_211 = zT_210.is_error;
    if (zT_211) goto z_bb_52; else goto z_bb_53;
    z_bb_49:
    return zT_206;
    z_bb_50:
    zT_208 = zT_206.data.payload;
    goto z_bb_51;
    z_bb_51:
    body = zT_208;
    goto z_bb_47;
    z_bb_52:
    return zT_210;
    z_bb_53:
    zT_212 = zT_210.data.payload;
    goto z_bb_54;
    z_bb_54:
    body = zT_212;
    goto z_bb_47;
    z_bb_55:
    zT_219 = self;
    zT_220 = zF_C241B2C4_parserAdvance(zT_219);
    (void)zT_220;
    goto z_bb_56;
    z_bb_56:
    end_pos = zT_222;
    zT_223 = self->last_tok_valid;
    if (zT_223) goto z_bb_57; else goto z_bb_59;
    z_bb_57:
    zT_225 = self->last_tok;
    last = zT_225;
    zT_226 = last.span_start;
    zT_227 = last.span_len;
    zT_229 = zT_226 + (unsigned int)((unsigned int)zT_227);
    end_pos = zT_229;
    goto z_bb_58;
    z_bb_58:
    zT_231 = self->store;
    zT_243 = 0;
    zT_234 = kw.span_start;
    zT_235 = end_pos;
    zT_236 = pattern;
    zT_237 = body;
    zT_238 = index_name;
    zT_239 = capture_name;
    zT_246 = zF_6C9FF72F_astStoreAddNode(zT_231, (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt), (unsigned char)((unsigned char)zT_243), zT_234, zT_235, zT_236, zT_237, zT_238, zT_239);
    zT_247.data.payload = zT_246;
    zT_247.is_error = 0;
    return zT_247;
    z_bb_59:
    zT_230 = kw.span_start;
    end_pos = zT_230;
    goto z_bb_58;
}

/* parserParseSwitchStmt */
zT_3B6EA323_EU_01 zF_3A6F34C7_parserParseSwitchSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_11;
    int zT_18;
    int zT_20;
    int zT_22;
    int zT_24;
    int zT_26;
    int zT_28;
    unsigned int zT_30 = 0;
    zT_3B6EA323_EU_01 zT_31;
    unsigned int inner;
    zT_2 = self;
    zT_3 = zF_A9AC92CA_parserParseSwitchEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_5;
    zT_6 = self->store;
    zT_18 = 0;
    zT_20 = 0;
    zT_22 = 0;
    zT_11 = inner;
    zT_24 = 0;
    zT_26 = 0;
    zT_28 = 0;
    zT_30 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt), (unsigned char)((unsigned char)zT_18), (unsigned int)((unsigned int)zT_20), (unsigned int)((unsigned int)zT_22), zT_11, (unsigned int)((unsigned int)zT_24), (unsigned int)((unsigned int)zT_26), (unsigned int)((unsigned int)zT_28));
    zT_31.data.payload = zT_30;
    zT_31.is_error = 0;
    return zT_31;
}

/* parserParseReturnExpr */
zT_3B6EA323_EU_01 zF_224C1394_parserParseReturnEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    unsigned char zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_29 = {0};
    unsigned char zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned short zT_34;
    unsigned int zT_36;
    unsigned char zT_37;
    zT_3A355BD2_Token zT_39;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_56;
    int zT_59;
    int zT_61;
    int zT_63;
    unsigned int zT_65 = 0;
    zT_3B6EA323_EU_01 zT_66;
    zT_3A355BD2_Token kw;
    unsigned int expr;
    zT_EAC3E484_TokenKind nt;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    expr = zT_6;
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    nt = zT_10;
    if ((unsigned char)(nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 0;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_22 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_9;
    z_bb_8:
    zT_22 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_22) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_26 = self;
    zT_29 = zF_F07C1F04_parserParseExprPrec(zT_26, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_33 = kw.span_start;
    zT_34 = kw.span_len;
    zT_36 = zT_33 + (unsigned int)((unsigned int)zT_34);
    end_pos = zT_36;
    zT_37 = self->last_tok_valid;
    if (zT_37) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_29;
    z_bb_13:
    zT_31 = zT_29.data.payload;
    goto z_bb_14;
    z_bb_14:
    expr = zT_31;
    goto z_bb_11;
    z_bb_15:
    zT_39 = self->last_tok;
    last = zT_39;
    zT_40 = last.span_start;
    zT_41 = last.span_len;
    zT_43 = zT_40 + (unsigned int)((unsigned int)zT_41);
    end_pos = zT_43;
    goto z_bb_16;
    z_bb_16:
    zT_44 = self->store;
    zT_56 = 0;
    zT_47 = kw.span_start;
    zT_48 = end_pos;
    zT_49 = expr;
    zT_59 = 0;
    zT_61 = 0;
    zT_63 = 0;
    zT_65 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt), (unsigned char)((unsigned char)zT_56), zT_47, zT_48, zT_49, (unsigned int)((unsigned int)zT_59), (unsigned int)((unsigned int)zT_61), (unsigned int)((unsigned int)zT_63));
    zT_66.data.payload = zT_65;
    zT_66.is_error = 0;
    return zT_66;
}

/* parserParseBreakExpr */
zT_3B6EA323_EU_01 zF_C69B6287_parserParseBreakExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_2B3424E9_ParseToken zT_26;
    unsigned int zT_27 = 0;
    unsigned int zT_29;
    unsigned short zT_30;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_3A355BD2_Token zT_35;
    unsigned int zT_36;
    unsigned short zT_37;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_48;
    int zT_52;
    int zT_55;
    int zT_57;
    int zT_59;
    unsigned int zT_61 = 0;
    zT_3B6EA323_EU_01 zT_62;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_29 = kw.span_start;
    zT_30 = kw.span_len;
    zT_32 = zT_29 + (unsigned int)((unsigned int)zT_30);
    end_pos = zT_32;
    zT_33 = self->last_tok_valid;
    if (zT_33) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_24;
    zT_25 = self;
    zT_26 = label_tok;
    zT_27 = zF_ED2167CA_parserInternParseTo(zT_25, zT_26);
    label_id = zT_27;
    goto z_bb_2;
    z_bb_6:
    zT_35 = self->last_tok;
    last = zT_35;
    zT_36 = last.span_start;
    zT_37 = last.span_len;
    zT_39 = zT_36 + (unsigned int)((unsigned int)zT_37);
    end_pos = zT_39;
    goto z_bb_7;
    z_bb_7:
    zT_40 = self->store;
    zT_52 = 0;
    zT_43 = kw.span_start;
    zT_44 = end_pos;
    zT_55 = 0;
    zT_57 = 0;
    zT_59 = 0;
    zT_48 = label_id;
    zT_61 = zF_6C9FF72F_astStoreAddNode(zT_40, (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt), (unsigned char)((unsigned char)zT_52), zT_43, zT_44, (unsigned int)((unsigned int)zT_55), (unsigned int)((unsigned int)zT_57), (unsigned int)((unsigned int)zT_59), zT_48);
    zT_62.data.payload = zT_61;
    zT_62.is_error = 0;
    return zT_62;
}

/* parserParseContinueExpr */
zT_3B6EA323_EU_01 zF_73B42F4B_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_2B3424E9_ParseToken zT_26;
    unsigned int zT_27 = 0;
    unsigned int zT_29;
    unsigned short zT_30;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_3A355BD2_Token zT_35;
    unsigned int zT_36;
    unsigned short zT_37;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_48;
    int zT_52;
    int zT_55;
    int zT_57;
    int zT_59;
    unsigned int zT_61 = 0;
    zT_3B6EA323_EU_01 zT_62;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_29 = kw.span_start;
    zT_30 = kw.span_len;
    zT_32 = zT_29 + (unsigned int)((unsigned int)zT_30);
    end_pos = zT_32;
    zT_33 = self->last_tok_valid;
    if (zT_33) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_24;
    zT_25 = self;
    zT_26 = label_tok;
    zT_27 = zF_ED2167CA_parserInternParseTo(zT_25, zT_26);
    label_id = zT_27;
    goto z_bb_2;
    z_bb_6:
    zT_35 = self->last_tok;
    last = zT_35;
    zT_36 = last.span_start;
    zT_37 = last.span_len;
    zT_39 = zT_36 + (unsigned int)((unsigned int)zT_37);
    end_pos = zT_39;
    goto z_bb_7;
    z_bb_7:
    zT_40 = self->store;
    zT_52 = 0;
    zT_43 = kw.span_start;
    zT_44 = end_pos;
    zT_55 = 0;
    zT_57 = 0;
    zT_59 = 0;
    zT_48 = label_id;
    zT_61 = zF_6C9FF72F_astStoreAddNode(zT_40, (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt), (unsigned char)((unsigned char)zT_52), zT_43, zT_44, (unsigned int)((unsigned int)zT_55), (unsigned int)((unsigned int)zT_57), (unsigned int)((unsigned int)zT_59), zT_48);
    zT_62.data.payload = zT_61;
    zT_62.is_error = 0;
    return zT_62;
}

/* parserParseReturnStmt */
zT_3B6EA323_EU_01 zF_76F5B9F1_parserParseReturnSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_224C1394_parserParseReturnEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseBreakStmt */
zT_3B6EA323_EU_01 zF_6DA396FE_parserParseBreakStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_C69B6287_parserParseBreakExp(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseContinueStmt */
zT_3B6EA323_EU_01 zF_E13A9822_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_73B42F4B_parserParseContinue(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseDeferStmt */
zT_3B6EA323_EU_01 zF_3B25AFD5_parserParseDeferStm(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char zT_12;
    zT_3A355BD2_Token zT_14;
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_3B6EA323_EU_01 zT_39;
    zT_3A355BD2_Token kw;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    kw = zT_4;
    zT_6 = self;
    zT_7 = zF_462FC60E_parserParseStatemen(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    body = zT_9;
    zT_11 = kw.span_start;
    end_pos = zT_11;
    zT_12 = self->last_tok_valid;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = self->last_tok;
    last = zT_14;
    zT_15 = last.span_start;
    zT_16 = last.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end_pos = zT_18;
    goto z_bb_5;
    z_bb_5:
    zT_19 = self->store;
    zT_20 = kind;
    zT_29 = 0;
    zT_22 = kw.span_start;
    zT_23 = end_pos;
    zT_24 = body;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_19, zT_20, (unsigned char)((unsigned char)zT_29), zT_22, zT_23, zT_24, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    zT_39.data.payload = zT_38;
    zT_39.is_error = 0;
    return zT_39;
}

/* parserParseErrdeferStmt */
zT_3B6EA323_EU_01 zF_6C2E50E6_parserParseErrdefer(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3B6EA323_EU_01 zT_5 = {0};
    zT_1 = self;
    zT_5 = zF_3B25AFD5_parserParseDeferStm(zT_1, (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt));
    return zT_5;
}

/* parserParseTestDecl */
zT_3B6EA323_EU_01 zF_15A196A5_parserParseTestDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17;
    unsigned int zT_18 = 0;
    zT_B559F9DA_Parser* zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned char zT_26;
    zT_3A355BD2_Token zT_28;
    unsigned int zT_29;
    unsigned short zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_42;
    int zT_46;
    int zT_49;
    int zT_51;
    unsigned int zT_53 = 0;
    zT_3B6EA323_EU_01 zT_54;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_3A355BD2_Token name_tok;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    name_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    name_tok = zT_15;
    zT_16 = self;
    zT_17 = name_tok;
    zT_18 = zF_9DDDA188_parserInternTokenTe(zT_16, zT_17);
    name_id = zT_18;
    goto z_bb_2;
    z_bb_2:
    zT_20 = self;
    zT_21 = zF_365CA04A_parserParseBlock(zT_20);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return zT_21;
    z_bb_4:
    zT_23 = zT_21.data.payload;
    goto z_bb_5;
    z_bb_5:
    body = zT_23;
    end_pos = zT_25;
    zT_26 = self->last_tok_valid;
    if (zT_26) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_28 = self->last_tok;
    last = zT_28;
    zT_29 = last.span_start;
    zT_30 = last.span_len;
    zT_32 = zT_29 + (unsigned int)((unsigned int)zT_30);
    end_pos = zT_32;
    goto z_bb_7;
    z_bb_7:
    zT_34 = self->store;
    zT_46 = 0;
    zT_37 = tok.span_start;
    zT_38 = end_pos;
    zT_39 = body;
    zT_49 = 0;
    zT_51 = 0;
    zT_42 = name_id;
    zT_53 = zF_6C9FF72F_astStoreAddNode(zT_34, (zT_8143F551_AstKind)(zT_8143F551_AstKind_test_decl), (unsigned char)((unsigned char)zT_46), zT_37, zT_38, zT_39, (unsigned int)((unsigned int)zT_49), (unsigned int)((unsigned int)zT_51), zT_42);
    zT_54.data.payload = zT_53;
    zT_54.is_error = 0;
    return zT_54;
    z_bb_8:
    zT_33 = tok.span_start;
    end_pos = zT_33;
    goto z_bb_7;
}

/* parserParseContainerDecl */
zT_3B6EA323_EU_01 zF_0A0E9C6C_parserParseContaine(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned char zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_B559F9DA_Parser* zT_26;
    zT_CB78802F_EU_49 zT_30 = {0};
    unsigned char zT_31;
    int zT_32;
    zT_3B6EA323_EU_01 zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    int zT_44;
    unsigned char zT_45;
    unsigned char zT_49;
    zT_B559F9DA_Parser* zT_50;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_52;
    zT_B559F9DA_Parser* zT_56;
    zT_3A355BD2_Token zT_57 = {0};
    zT_B559F9DA_Parser* zT_58;
    zT_3B6EA323_EU_01 zT_59 = {0};
    unsigned char zT_60;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_62;
    zT_CB78802F_EU_49 zT_66 = {0};
    unsigned char zT_67;
    int zT_68;
    zT_3B6EA323_EU_01 zT_69;
    zT_2B3424E9_ParseToken zT_70;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    zT_EAC3E484_TokenKind zT_73;
    zT_B559F9DA_Parser* zT_78;
    zT_3A355BD2_Token zT_79 = {0};
    zT_B559F9DA_Parser* zT_80;
    zT_3A355BD2_Token zT_81;
    unsigned int zT_82 = 0;
    zT_B559F9DA_Parser* zT_83;
    zT_CB78802F_EU_49 zT_87 = {0};
    unsigned char zT_88;
    int zT_89;
    zT_3B6EA323_EU_01 zT_90;
    zT_2B3424E9_ParseToken zT_91;
    unsigned int* zT_93 = 0;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_98;
    zT_B559F9DA_Parser* zT_99;
    zT_3A355BD2_Token zT_100 = {0};
    zT_EAC3E484_TokenKind zT_101;
    zT_B559F9DA_Parser* zT_106;
    zT_CB78802F_EU_49 zT_110 = {0};
    unsigned char zT_111;
    int zT_112;
    zT_3B6EA323_EU_01 zT_113;
    zT_2B3424E9_ParseToken zT_114;
    zT_B559F9DA_Parser* zT_116;
    zT_2B3424E9_ParseToken zT_117;
    unsigned int zT_118 = 0;
    int zT_123;
    unsigned int zT_124;
    zT_B559F9DA_Parser* zT_125;
    zT_3A355BD2_Token zT_126 = {0};
    zT_EAC3E484_TokenKind zT_127;
    zT_B559F9DA_Parser* zT_131;
    zT_3A355BD2_Token zT_132 = {0};
    zT_B559F9DA_Parser* zT_133;
    zT_3B6EA323_EU_01 zT_136 = {0};
    unsigned char zT_137;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_143;
    unsigned int zT_146;
    unsigned int zT_148;
    int zT_152;
    unsigned int zT_155;
    unsigned short zT_156;
    int zT_159;
    int zT_161;
    unsigned int zT_163 = 0;
    zT_B559F9DA_Parser* zT_164;
    unsigned int** zT_165;
    unsigned int* zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    zT_B559F9DA_Parser* zT_172;
    zT_CB78802F_EU_49 zT_176 = {0};
    unsigned char zT_177;
    int zT_178;
    zT_3B6EA323_EU_01 zT_179;
    zT_2B3424E9_ParseToken zT_180;
    zT_B559F9DA_Parser* zT_182;
    zT_3B6EA323_EU_01 zT_183 = {0};
    unsigned char zT_184;
    unsigned int zT_185;
    zT_6B0A7D14_AstStore* zT_187;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned int zT_195;
    int zT_199;
    unsigned int zT_202;
    unsigned short zT_203;
    int zT_206;
    int zT_208;
    unsigned int zT_210 = 0;
    zT_B559F9DA_Parser* zT_211;
    unsigned int** zT_212;
    unsigned int* zT_213;
    unsigned int* zT_214;
    unsigned int zT_215;
    zT_B559F9DA_Parser* zT_219;
    zT_3A355BD2_Token zT_220 = {0};
    zT_EAC3E484_TokenKind zT_221;
    zT_B559F9DA_Parser* zT_225;
    zT_3A355BD2_Token zT_226 = {0};
    zT_B559F9DA_Parser* zT_228;
    zT_CB78802F_EU_49 zT_232 = {0};
    unsigned char zT_233;
    int zT_234;
    zT_3B6EA323_EU_01 zT_235;
    zT_2B3424E9_ParseToken zT_236;
    int zT_238;
    unsigned int zT_239;
    int zT_240;
    zT_6B0A7D14_AstStore* zT_242;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_243;
    int zT_245;
    unsigned int* zT_246;
    unsigned int zT_247;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_248;
    unsigned int zT_249 = 0;
    unsigned int zT_251;
    unsigned short zT_252;
    unsigned int zT_254;
    zT_6B0A7D14_AstStore* zT_255;
    zT_8143F551_AstKind zT_256;
    unsigned char zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned int zT_263;
    int zT_266;
    unsigned int zT_268 = 0;
    zT_3B6EA323_EU_01 zT_269;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    unsigned char is_tagged;
    unsigned int backing_type;
    zT_3A355BD2_Token name_tok;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken ftok;
    zT_2B3424E9_ParseToken rbrace;
    unsigned int fid;
    unsigned int ev;
    unsigned int enode;
    unsigned int ftype;
    unsigned int fnode;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    name_id = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    backing_type = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = self;
    zT_19 = zF_068A2DE5_parserPeek(zT_18);
    zT_20 = zT_19.kind;
    zT_17 = zT_20 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_3;
    z_bb_2:
    zT_17 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_24 = self;
    zT_25 = zF_C241B2C4_parserAdvance(zT_24);
    (void)zT_25;
    zT_26 = self;
    zT_30 = zF_5578C74F_parserExpect(zT_26, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_12; else goto z_bb_13;
    z_bb_6:
    zT_32 = zT_30.data.err;
    zT_33.data.err = zT_32;
    zT_33.is_error = 1;
    return zT_33;
    z_bb_7:
    zT_34 = zT_30.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_34;
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_10:
    zT_43 = zT_39.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_43;
    zT_44 = 1;
    zT_45 = (unsigned char)zT_44;
    is_tagged = zT_45;
    goto z_bb_5;
    z_bb_12:
    zT_50 = self;
    zT_51 = zF_068A2DE5_parserPeek(zT_50);
    zT_52 = zT_51.kind;
    zT_49 = zT_52 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_14;
    z_bb_13:
    zT_49 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_49) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_56 = self;
    zT_57 = zF_C241B2C4_parserAdvance(zT_56);
    (void)zT_57;
    zT_58 = self;
    zT_59 = zF_CBDBFE85_parserParseType(zT_58);
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_71 = self;
    zT_72 = zF_068A2DE5_parserPeek(zT_71);
    zT_73 = zT_72.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_17:
    return zT_59;
    z_bb_18:
    zT_61 = zT_59.data.payload;
    goto z_bb_19;
    z_bb_19:
    backing_type = zT_61;
    zT_62 = self;
    zT_66 = zF_5578C74F_parserExpect(zT_62, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_67 = zT_66.is_error;
    if (zT_67) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_68 = zT_66.data.err;
    zT_69.data.err = zT_68;
    zT_69.is_error = 1;
    return zT_69;
    z_bb_21:
    zT_70 = zT_66.data.payload;
    goto z_bb_22;
    z_bb_22:
    (void)zT_70;
    goto z_bb_16;
    z_bb_23:
    zT_78 = self;
    zT_79 = zF_C241B2C4_parserAdvance(zT_78);
    name_tok = zT_79;
    zT_80 = self;
    zT_81 = name_tok;
    zT_82 = zF_9DDDA188_parserInternTokenTe(zT_80, zT_81);
    name_id = zT_82;
    goto z_bb_24;
    z_bb_24:
    zT_83 = self;
    zT_87 = zF_5578C74F_parserExpect(zT_83, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_88 = zT_87.is_error;
    if (zT_88) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_89 = zT_87.data.err;
    zT_90.data.err = zT_89;
    zT_90.is_error = 1;
    return zT_90;
    z_bb_26:
    zT_91 = zT_87.data.payload;
    goto z_bb_27;
    z_bb_27:
    (void)zT_91;
    fields_buf = zT_93;
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    fields_count = zT_96;
    zT_98 = 0;
    fields_cap = zT_98;
    goto z_bb_28;
    z_bb_28:
    zT_99 = self;
    zT_100 = zF_068A2DE5_parserPeek(zT_99);
    zT_101 = zT_100.kind;
    if ((unsigned char)(zT_101 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_106 = self;
    zT_110 = zF_5578C74F_parserExpect(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_111 = zT_110.is_error;
    if (zT_111) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    zT_228 = self;
    zT_232 = zF_5578C74F_parserExpect(zT_228, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_233 = zT_232.is_error;
    if (zT_233) goto z_bb_51; else goto z_bb_52;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_112 = zT_110.data.err;
    zT_113.data.err = zT_112;
    zT_113.is_error = 1;
    return zT_113;
    z_bb_33:
    zT_114 = zT_110.data.payload;
    goto z_bb_34;
    z_bb_34:
    ftok = zT_114;
    zT_116 = self;
    zT_117 = ftok;
    zT_118 = zF_ED2167CA_parserInternParseTo(zT_116, zT_117);
    fid = zT_118;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_123 = 0;
    zT_124 = (unsigned int)zT_123;
    ev = zT_124;
    zT_125 = self;
    zT_126 = zF_068A2DE5_parserPeek(zT_125);
    zT_127 = zT_126.kind;
    if ((unsigned char)(zT_127 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    zT_219 = self;
    zT_220 = zF_068A2DE5_parserPeek(zT_219);
    zT_221 = zT_220.kind;
    if ((unsigned char)(zT_221 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_49; else goto z_bb_50;
    z_bb_37:
    zT_172 = self;
    zT_176 = zF_5578C74F_parserExpect(zT_172, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_177 = zT_176.is_error;
    if (zT_177) goto z_bb_43; else goto z_bb_44;
    z_bb_38:
    zT_131 = self;
    zT_132 = zF_C241B2C4_parserAdvance(zT_131);
    (void)zT_132;
    zT_133 = self;
    zT_136 = zF_F07C1F04_parserParseExprPrec(zT_133, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prec_orelse));
    zT_137 = zT_136.is_error;
    if (zT_137) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_140 = self->store;
    zT_152 = 0;
    zT_143 = ftok.span_start;
    zT_155 = ftok.span_start;
    zT_156 = ftok.span_len;
    zT_159 = 0;
    zT_146 = ev;
    zT_161 = 0;
    zT_148 = fid;
    zT_163 = zF_6C9FF72F_astStoreAddNode(zT_140, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_152), zT_143, (unsigned int)(zT_155 + (unsigned int)((unsigned int)zT_156)), (unsigned int)((unsigned int)zT_159), zT_146, (unsigned int)((unsigned int)zT_161), zT_148);
    enode = zT_163;
    zT_164 = self;
    zT_165 = &fields_buf;
    zT_166 = &fields_count;
    zT_167 = &fields_cap;
    zT_168 = enode;
    zF_0F1462F8_parserPushU32(zT_164, zT_165, zT_166, zT_167, zT_168);
    goto z_bb_36;
    z_bb_40:
    return zT_136;
    z_bb_41:
    zT_138 = zT_136.data.payload;
    goto z_bb_42;
    z_bb_42:
    ev = zT_138;
    goto z_bb_39;
    z_bb_43:
    zT_178 = zT_176.data.err;
    zT_179.data.err = zT_178;
    zT_179.is_error = 1;
    return zT_179;
    z_bb_44:
    zT_180 = zT_176.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_180;
    zT_182 = self;
    zT_183 = zF_CBDBFE85_parserParseType(zT_182);
    zT_184 = zT_183.is_error;
    if (zT_184) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return zT_183;
    z_bb_47:
    zT_185 = zT_183.data.payload;
    goto z_bb_48;
    z_bb_48:
    ftype = zT_185;
    zT_187 = self->store;
    zT_199 = 0;
    zT_190 = ftok.span_start;
    zT_202 = ftok.span_start;
    zT_203 = ftok.span_len;
    zT_192 = ftype;
    zT_206 = 0;
    zT_208 = 0;
    zT_195 = fid;
    zT_210 = zF_6C9FF72F_astStoreAddNode(zT_187, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_199), zT_190, (unsigned int)(zT_202 + (unsigned int)((unsigned int)zT_203)), zT_192, (unsigned int)((unsigned int)zT_206), (unsigned int)((unsigned int)zT_208), zT_195);
    fnode = zT_210;
    zT_211 = self;
    zT_212 = &fields_buf;
    zT_213 = &fields_count;
    zT_214 = &fields_cap;
    zT_215 = fnode;
    zF_0F1462F8_parserPushU32(zT_211, zT_212, zT_213, zT_214, zT_215);
    goto z_bb_36;
    z_bb_49:
    zT_225 = self;
    zT_226 = zF_C241B2C4_parserAdvance(zT_225);
    (void)zT_226;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_31;
    z_bb_51:
    zT_234 = zT_232.data.err;
    zT_235.data.err = zT_234;
    zT_235.is_error = 1;
    return zT_235;
    z_bb_52:
    zT_236 = zT_232.data.payload;
    goto z_bb_53;
    z_bb_53:
    rbrace = zT_236;
    zT_238 = 0;
    zT_239 = (unsigned int)zT_238;
    payload = zT_239;
    zT_240 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_240)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_242 = self->store;
    zT_245 = 0;
    zT_246 = fields_buf + zT_245;
    zT_247 = fields_count - zT_245;
    zT_248.ptr = zT_246;
    zT_248.len = zT_247;
    zT_243 = zT_248;
    zT_249 = zF_583E993C_astStoreAddExtraChi(zT_242, zT_243);
    payload = zT_249;
    goto z_bb_55;
    z_bb_55:
    zT_251 = rbrace.span_start;
    zT_252 = rbrace.span_len;
    zT_254 = zT_251 + (unsigned int)((unsigned int)zT_252);
    end_pos = zT_254;
    zT_255 = self->store;
    zT_256 = kind;
    zT_257 = is_tagged;
    zT_258 = tok.span_start;
    zT_259 = end_pos;
    zT_260 = name_id;
    zT_261 = backing_type;
    zT_266 = 0;
    zT_263 = payload;
    zT_268 = zF_6C9FF72F_astStoreAddNode(zT_255, zT_256, zT_257, zT_258, zT_259, zT_260, zT_261, (unsigned int)((unsigned int)zT_266), zT_263);
    zT_269.data.payload = zT_268;
    zT_269.is_error = 0;
    return zT_269;
}

/* parserParseBlock */
zT_3B6EA323_EU_01 zF_365CA04A_parserParseBlock(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_6 = {0};
    unsigned char zT_7;
    int zT_8;
    zT_3B6EA323_EU_01 zT_9;
    zT_2B3424E9_ParseToken zT_10;
    unsigned int zT_12;
    zT_993A6923_Arr_unsigned_int_64 zT_14;
    unsigned int zT_16;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_EAC3E484_TokenKind zT_19;
    unsigned char zT_23;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_EAC3E484_TokenKind zT_26;
    zT_B559F9DA_Parser* zT_31;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_41;
    unsigned int** zT_44;
    unsigned int* zT_45;
    unsigned int* zT_46;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    unsigned int zT_55;
    unsigned int** zT_56;
    unsigned int* zT_57;
    unsigned int* zT_58;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_60;
    unsigned int zT_66;
    zT_B559F9DA_Parser* zT_68;
    zT_3A355BD2_Token zT_69 = {0};
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_EAC3E484_TokenKind zT_83;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    zT_EAC3E484_TokenKind zT_97;
    unsigned char zT_101;
    zT_EAC3E484_TokenKind zT_102;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_B559F9DA_Parser* zT_128;
    zT_CB78802F_EU_49 zT_132 = {0};
    unsigned char zT_133;
    int zT_134;
    zT_3B6EA323_EU_01 zT_135;
    zT_2B3424E9_ParseToken zT_136;
    int zT_138;
    unsigned int zT_139;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_143 = {0};
    int zT_148;
    unsigned int* zT_149;
    unsigned int zT_150;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_151;
    unsigned int* zT_152;
    unsigned int* zT_154;
    unsigned int zT_155;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_156;
    zT_6B0A7D14_AstStore* zT_157;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_158;
    unsigned int zT_160 = 0;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_6B0A7D14_AstStore* zT_174;
    unsigned int zT_177;
    unsigned int zT_182;
    int zT_186;
    unsigned int zT_189;
    unsigned short zT_190;
    int zT_193;
    int zT_195;
    int zT_197;
    unsigned int zT_199 = 0;
    zT_3B6EA323_EU_01 zT_200;
    zT_2B3424E9_ParseToken lbrace;
    unsigned int saved_len;
    zT_993A6923_Arr_unsigned_int_64 local_buf;
    unsigned int local_len;
    unsigned int stmt;
    zT_2B3424E9_ParseToken rbrace;
    zT_3A355BD2_Token pk;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_km;
    unsigned int fi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_lm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_pm;
    unsigned int payload;
    zT_3CB0179A_Slice_zT_05F374B1_u slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_pm;
    zT_2 = self;
    zT_6 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = zT_6.data.err;
    zT_9.data.err = zT_8;
    zT_9.is_error = 1;
    return zT_9;
    z_bb_2:
    zT_10 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    lbrace = zT_10;
    zT_12 = self->child_buf_len;
    saved_len = zT_12;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_14[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        local_buf[_i] = zT_14[_i];
        _i++;
    }
}
    zT_16 = 0;
    local_len = zT_16;
    goto z_bb_4;
    z_bb_4:
    zT_17 = self;
    zT_18 = zF_068A2DE5_parserPeek(zT_17);
    zT_19 = zT_18.kind;
    if ((unsigned char)(zT_19 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_31 = self;
    zT_32 = zF_462FC60E_parserParseStatemen(zT_31);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_128 = self;
    zT_132 = zF_5578C74F_parserExpect(zT_128, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_133 = zT_132.is_error;
    if (zT_133) goto z_bb_28; else goto z_bb_29;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_24 = self;
    zT_25 = zF_068A2DE5_parserPeek(zT_24);
    zT_26 = zT_25.kind;
    zT_23 = zT_26 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_10;
    z_bb_9:
    zT_23 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    return zT_32;
    z_bb_12:
    zT_34 = zT_32.data.payload;
    goto z_bb_13;
    z_bb_13:
    stmt = zT_34;
    if ((unsigned char)(local_len < (unsigned int)(64))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_37 = (unsigned int)local_len;
    local_buf[zT_37] = stmt;
    goto z_bb_15;
    z_bb_15:
    zT_66 = local_len + (unsigned int)(1);
    local_len = zT_66;
    zT_68 = self;
    zT_69 = zF_068A2DE5_parserPeek(zT_68);
    pk = zT_69;
    zT_71 = "PBX:S";
    zT_73 = 5;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    pbx_sm = zT_72;
    zT_74 = pbx_sm;
    zF_C914CB83_markerWriteInt(zT_74, (unsigned int)((unsigned int)local_len));
    zT_78 = "PBX:T";
    zT_80 = 5;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    pbx_tm = zT_79;
    zT_81 = pbx_tm;
    zT_83 = pk.kind;
    zF_C914CB83_markerWriteInt(zT_81, (unsigned int)((unsigned int)zT_83));
    zT_86 = "PBX:K";
    zT_88 = 5;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    pbx_km = zT_87;
    zT_89 = pbx_km;
    zT_91 = self->store;
    zT_92 = stmt;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    zT_95 = zT_94.kind;
    zF_C914CB83_markerWriteInt(zT_89, (unsigned int)((unsigned int)zT_95));
    zT_97 = pk.kind;
    if ((unsigned char)(zT_97 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_24; else goto z_bb_23;
    z_bb_16:
    if ((unsigned char)(local_len == (unsigned int)(64))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_41 = 0;
    fi = zT_41;
    goto z_bb_19;
    z_bb_18:
    zT_56 = &self->child_buf_items;
    zT_57 = &self->child_buf_len;
    zT_58 = &self->child_buf_capacity;
    zT_59 = self->allocator;
    zT_60 = stmt;
    zF_8B163A32_u32ArrayListAppendI(zT_56, zT_57, zT_58, zT_59, zT_60);
    goto z_bb_15;
    z_bb_19:
    if ((unsigned char)(fi < (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_44 = &self->child_buf_items;
    zT_45 = &self->child_buf_len;
    zT_46 = &self->child_buf_capacity;
    zT_47 = self->allocator;
    zT_48 = local_buf[fi];
    zF_8B163A32_u32ArrayListAppendI(zT_44, zT_45, zT_46, zT_47, zT_48);
    goto z_bb_22;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_55 = fi + (unsigned int)(1);
    fi = zT_55;
    goto z_bb_19;
    z_bb_23:
    zT_102 = pk.kind;
    zT_101 = zT_102 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_25;
    z_bb_24:
    zT_101 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_101) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_107 = "PBX:L";
    zT_109 = 5;
    zT_108.ptr = zT_107;
    zT_108.len = zT_109;
    pbx_lm = zT_108;
    zT_110 = pbx_lm;
    zF_C914CB83_markerWriteInt(zT_110, (unsigned int)((unsigned int)local_len));
    zT_114 = "PBX:B";
    zT_116 = 5;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    pbx_bm = zT_115;
    zT_117 = pbx_bm;
    zF_C914CB83_markerWriteInt(zT_117, (unsigned int)((unsigned int)saved_len));
    zT_121 = "PBX:P";
    zT_123 = 5;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    pbx_pm = zT_122;
    zT_124 = pbx_pm;
    zT_125 = lbrace.span_start;
    zF_C914CB83_markerWriteInt(zT_124, zT_125);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_7;
    z_bb_28:
    zT_134 = zT_132.data.err;
    zT_135.data.err = zT_134;
    zT_135.is_error = 1;
    return zT_135;
    z_bb_29:
    zT_136 = zT_132.data.payload;
    goto z_bb_30;
    z_bb_30:
    rbrace = zT_136;
    zT_138 = 0;
    zT_139 = (unsigned int)zT_138;
    payload = zT_139;
    if ((unsigned char)(local_len > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    slice = zT_143;
    if ((unsigned char)(local_len <= (unsigned int)(64))) goto z_bb_33; else goto z_bb_35;
    z_bb_32:
    self->child_buf_len = saved_len;
    zT_162 = "PLEN:l";
    zT_164 = 6;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    plen_m = zT_163;
    zT_165 = plen_m;
    zF_C914CB83_markerWriteInt(zT_165, (unsigned int)((unsigned int)local_len));
    zT_169 = "p";
    zT_171 = 1;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    plen_pm = zT_170;
    zT_172 = plen_pm;
    zT_173 = payload;
    zF_C914CB83_markerWriteInt(zT_172, zT_173);
    zT_174 = self->store;
    zT_186 = 0;
    zT_177 = lbrace.span_start;
    zT_189 = rbrace.span_start;
    zT_190 = rbrace.span_len;
    zT_193 = 0;
    zT_195 = 0;
    zT_197 = 0;
    zT_182 = payload;
    zT_199 = zF_6C9FF72F_astStoreAddNode(zT_174, (zT_8143F551_AstKind)(zT_8143F551_AstKind_block), (unsigned char)((unsigned char)zT_186), zT_177, (unsigned int)(zT_189 + (unsigned int)((unsigned int)zT_190)), (unsigned int)((unsigned int)zT_193), (unsigned int)((unsigned int)zT_195), (unsigned int)((unsigned int)zT_197), zT_182);
    zT_200.data.payload = zT_199;
    zT_200.is_error = 0;
    return zT_200;
    z_bb_33:
    zT_148 = 0;
    zT_149 = (unsigned int*)((unsigned int*)local_buf) + zT_148;
    zT_150 = local_len - zT_148;
    zT_151.ptr = zT_149;
    zT_151.len = zT_150;
    slice = zT_151;
    goto z_bb_34;
    z_bb_34:
    zT_157 = self->store;
    zT_158 = slice;
    zT_160 = zF_583E993C_astStoreAddExtraChi(zT_157, zT_158);
    payload = zT_160;
    goto z_bb_32;
    z_bb_35:
    zT_152 = self->child_buf_items;
    zT_154 = zT_152 + saved_len;
    zT_155 = (unsigned int)(saved_len + local_len) - saved_len;
    zT_156.ptr = zT_154;
    zT_156.len = zT_155;
    slice = zT_156;
    goto z_bb_34;
}

/* precToInt */
unsigned char zF_F312BDA3_precToInt(zT_2B10107F_Prec p) {
    return (unsigned char)((unsigned char)p);
}

/* precFromInt */
zT_2B10107F_Prec zF_860100DC_precFromInt(unsigned char v) {
    return (zT_2B10107F_Prec)((zT_2B10107F_Prec)v);
}

/* getInfixInfo */
zT_B2DA84DE_Opt_98 zF_1E2936C3_getInfixInfo(zT_EAC3E484_TokenKind kind) {
    zT_F4EBEA72_OpInfo zT_4;
    zT_8143F551_AstKind zT_6;
    zT_2B10107F_Prec zT_7;
    unsigned char zT_8;
    zT_B2DA84DE_Opt_98 zT_9;
    zT_F4EBEA72_OpInfo zT_13;
    zT_8143F551_AstKind zT_15;
    zT_2B10107F_Prec zT_16;
    unsigned char zT_17;
    zT_B2DA84DE_Opt_98 zT_18;
    zT_F4EBEA72_OpInfo zT_22;
    zT_8143F551_AstKind zT_24;
    zT_2B10107F_Prec zT_25;
    unsigned char zT_26;
    zT_B2DA84DE_Opt_98 zT_27;
    zT_F4EBEA72_OpInfo zT_31;
    zT_8143F551_AstKind zT_33;
    zT_2B10107F_Prec zT_34;
    unsigned char zT_35;
    zT_B2DA84DE_Opt_98 zT_36;
    zT_F4EBEA72_OpInfo zT_40;
    zT_8143F551_AstKind zT_42;
    zT_2B10107F_Prec zT_43;
    unsigned char zT_44;
    zT_B2DA84DE_Opt_98 zT_45;
    zT_F4EBEA72_OpInfo zT_49;
    zT_8143F551_AstKind zT_51;
    zT_2B10107F_Prec zT_52;
    unsigned char zT_53;
    zT_B2DA84DE_Opt_98 zT_54;
    zT_F4EBEA72_OpInfo zT_58;
    zT_8143F551_AstKind zT_60;
    zT_2B10107F_Prec zT_61;
    unsigned char zT_62;
    zT_B2DA84DE_Opt_98 zT_63;
    zT_F4EBEA72_OpInfo zT_67;
    zT_8143F551_AstKind zT_69;
    zT_2B10107F_Prec zT_70;
    unsigned char zT_71;
    zT_B2DA84DE_Opt_98 zT_72;
    zT_F4EBEA72_OpInfo zT_76;
    zT_8143F551_AstKind zT_78;
    zT_2B10107F_Prec zT_79;
    unsigned char zT_80;
    zT_B2DA84DE_Opt_98 zT_81;
    zT_F4EBEA72_OpInfo zT_85;
    zT_8143F551_AstKind zT_87;
    zT_2B10107F_Prec zT_88;
    unsigned char zT_89;
    zT_B2DA84DE_Opt_98 zT_90;
    zT_F4EBEA72_OpInfo zT_94;
    zT_8143F551_AstKind zT_96;
    zT_2B10107F_Prec zT_97;
    unsigned char zT_98;
    zT_B2DA84DE_Opt_98 zT_99;
    zT_F4EBEA72_OpInfo zT_103;
    zT_8143F551_AstKind zT_105;
    zT_2B10107F_Prec zT_106;
    unsigned char zT_107;
    zT_B2DA84DE_Opt_98 zT_108;
    zT_F4EBEA72_OpInfo zT_112;
    zT_8143F551_AstKind zT_114;
    zT_2B10107F_Prec zT_115;
    unsigned char zT_116;
    zT_B2DA84DE_Opt_98 zT_117;
    zT_F4EBEA72_OpInfo zT_121;
    zT_8143F551_AstKind zT_123;
    zT_2B10107F_Prec zT_124;
    unsigned char zT_125;
    zT_B2DA84DE_Opt_98 zT_126;
    zT_F4EBEA72_OpInfo zT_130;
    zT_8143F551_AstKind zT_132;
    zT_2B10107F_Prec zT_133;
    unsigned char zT_134;
    zT_B2DA84DE_Opt_98 zT_135;
    zT_F4EBEA72_OpInfo zT_139;
    zT_8143F551_AstKind zT_141;
    zT_2B10107F_Prec zT_142;
    unsigned char zT_143;
    zT_B2DA84DE_Opt_98 zT_144;
    zT_F4EBEA72_OpInfo zT_148;
    zT_8143F551_AstKind zT_150;
    zT_2B10107F_Prec zT_151;
    unsigned char zT_152;
    zT_B2DA84DE_Opt_98 zT_153;
    zT_F4EBEA72_OpInfo zT_157;
    zT_8143F551_AstKind zT_159;
    zT_2B10107F_Prec zT_160;
    unsigned char zT_161;
    zT_B2DA84DE_Opt_98 zT_162;
    zT_F4EBEA72_OpInfo zT_166;
    zT_8143F551_AstKind zT_168;
    zT_2B10107F_Prec zT_169;
    unsigned char zT_170;
    zT_B2DA84DE_Opt_98 zT_171;
    zT_F4EBEA72_OpInfo zT_175;
    zT_8143F551_AstKind zT_177;
    zT_2B10107F_Prec zT_178;
    unsigned char zT_179;
    zT_B2DA84DE_Opt_98 zT_180;
    zT_F4EBEA72_OpInfo zT_184;
    zT_8143F551_AstKind zT_186;
    zT_2B10107F_Prec zT_187;
    unsigned char zT_188;
    zT_B2DA84DE_Opt_98 zT_189;
    zT_F4EBEA72_OpInfo zT_193;
    zT_8143F551_AstKind zT_195;
    zT_2B10107F_Prec zT_196;
    unsigned char zT_197;
    zT_B2DA84DE_Opt_98 zT_198;
    zT_F4EBEA72_OpInfo zT_202;
    zT_8143F551_AstKind zT_204;
    zT_2B10107F_Prec zT_205;
    unsigned char zT_206;
    zT_B2DA84DE_Opt_98 zT_207;
    zT_F4EBEA72_OpInfo zT_211;
    zT_8143F551_AstKind zT_213;
    zT_2B10107F_Prec zT_214;
    unsigned char zT_215;
    zT_B2DA84DE_Opt_98 zT_216;
    zT_F4EBEA72_OpInfo zT_220;
    zT_8143F551_AstKind zT_222;
    zT_2B10107F_Prec zT_223;
    unsigned char zT_224;
    zT_B2DA84DE_Opt_98 zT_225;
    zT_F4EBEA72_OpInfo zT_229;
    zT_8143F551_AstKind zT_231;
    zT_2B10107F_Prec zT_232;
    unsigned char zT_233;
    zT_B2DA84DE_Opt_98 zT_234;
    zT_F4EBEA72_OpInfo zT_238;
    zT_8143F551_AstKind zT_240;
    zT_2B10107F_Prec zT_241;
    unsigned char zT_242;
    zT_B2DA84DE_Opt_98 zT_243;
    zT_F4EBEA72_OpInfo zT_247;
    zT_8143F551_AstKind zT_249;
    zT_2B10107F_Prec zT_250;
    unsigned char zT_251;
    zT_B2DA84DE_Opt_98 zT_252;
    zT_F4EBEA72_OpInfo zT_256;
    zT_8143F551_AstKind zT_258;
    zT_2B10107F_Prec zT_259;
    unsigned char zT_260;
    zT_B2DA84DE_Opt_98 zT_261;
    zT_F4EBEA72_OpInfo zT_265;
    zT_8143F551_AstKind zT_267;
    zT_2B10107F_Prec zT_268;
    unsigned char zT_269;
    zT_B2DA84DE_Opt_98 zT_270;
    zT_F4EBEA72_OpInfo zT_274;
    zT_8143F551_AstKind zT_276;
    zT_2B10107F_Prec zT_277;
    unsigned char zT_278;
    zT_B2DA84DE_Opt_98 zT_279;
    zT_F4EBEA72_OpInfo zT_283;
    zT_8143F551_AstKind zT_285;
    zT_2B10107F_Prec zT_286;
    unsigned char zT_287;
    zT_B2DA84DE_Opt_98 zT_288;
    zT_F4EBEA72_OpInfo zT_292;
    zT_8143F551_AstKind zT_294;
    zT_2B10107F_Prec zT_295;
    unsigned char zT_296;
    zT_B2DA84DE_Opt_98 zT_297;
    zT_F4EBEA72_OpInfo zT_301;
    zT_8143F551_AstKind zT_303;
    zT_2B10107F_Prec zT_304;
    unsigned char zT_305;
    zT_B2DA84DE_Opt_98 zT_306;
    zT_F4EBEA72_OpInfo zT_310;
    zT_8143F551_AstKind zT_312;
    zT_2B10107F_Prec zT_313;
    unsigned char zT_314;
    zT_B2DA84DE_Opt_98 zT_315;
    zT_F4EBEA72_OpInfo zT_319;
    zT_8143F551_AstKind zT_321;
    zT_2B10107F_Prec zT_322;
    unsigned char zT_323;
    zT_B2DA84DE_Opt_98 zT_324;
    zT_F4EBEA72_OpInfo zT_328;
    zT_8143F551_AstKind zT_330;
    zT_2B10107F_Prec zT_331;
    unsigned char zT_332;
    zT_B2DA84DE_Opt_98 zT_333;
    zT_F4EBEA72_OpInfo zT_337;
    zT_8143F551_AstKind zT_339;
    zT_2B10107F_Prec zT_340;
    unsigned char zT_341;
    zT_B2DA84DE_Opt_98 zT_342;
    zT_F4EBEA72_OpInfo zT_346;
    zT_8143F551_AstKind zT_348;
    zT_2B10107F_Prec zT_349;
    unsigned char zT_350;
    zT_B2DA84DE_Opt_98 zT_351;
    zT_F4EBEA72_OpInfo zT_355;
    zT_8143F551_AstKind zT_357;
    zT_2B10107F_Prec zT_358;
    unsigned char zT_359;
    zT_B2DA84DE_Opt_98 zT_360;
    zT_F4EBEA72_OpInfo zT_364;
    zT_8143F551_AstKind zT_366;
    zT_2B10107F_Prec zT_367;
    unsigned char zT_368;
    zT_B2DA84DE_Opt_98 zT_369;
    zT_F4EBEA72_OpInfo zT_373;
    zT_8143F551_AstKind zT_375;
    zT_2B10107F_Prec zT_376;
    unsigned char zT_377;
    zT_B2DA84DE_Opt_98 zT_378;
    zT_F4EBEA72_OpInfo zT_382;
    zT_8143F551_AstKind zT_384;
    zT_2B10107F_Prec zT_385;
    unsigned char zT_386;
    zT_B2DA84DE_Opt_98 zT_387;
    zT_F4EBEA72_OpInfo zT_391;
    zT_8143F551_AstKind zT_393;
    zT_2B10107F_Prec zT_394;
    unsigned char zT_395;
    zT_B2DA84DE_Opt_98 zT_396;
    zT_F4EBEA72_OpInfo zT_400;
    zT_8143F551_AstKind zT_402;
    zT_2B10107F_Prec zT_403;
    unsigned char zT_404;
    zT_B2DA84DE_Opt_98 zT_405;
    zT_B2DA84DE_Opt_98 zT_406 = {0};
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = zT_8143F551_AstKind_plain_assign;
    zT_4.ast_kind = zT_6;
    zT_7 = zT_2B10107F_Prec_assignment;
    zT_4.prec = zT_7;
    zT_8 = 1;
    zT_4.right_assoc = zT_8;
    zT_9.has_value = 1;
    zT_9.value = zT_4;
    return zT_9;
    z_bb_2:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = zT_8143F551_AstKind_add_assign;
    zT_13.ast_kind = zT_15;
    zT_16 = zT_2B10107F_Prec_assignment;
    zT_13.prec = zT_16;
    zT_17 = 1;
    zT_13.right_assoc = zT_17;
    zT_18.has_value = 1;
    zT_18.value = zT_13;
    return zT_18;
    z_bb_4:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_24 = zT_8143F551_AstKind_sub_assign;
    zT_22.ast_kind = zT_24;
    zT_25 = zT_2B10107F_Prec_assignment;
    zT_22.prec = zT_25;
    zT_26 = 1;
    zT_22.right_assoc = zT_26;
    zT_27.has_value = 1;
    zT_27.value = zT_22;
    return zT_27;
    z_bb_6:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = zT_8143F551_AstKind_mul_assign;
    zT_31.ast_kind = zT_33;
    zT_34 = zT_2B10107F_Prec_assignment;
    zT_31.prec = zT_34;
    zT_35 = 1;
    zT_31.right_assoc = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_31;
    return zT_36;
    z_bb_8:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_42 = zT_8143F551_AstKind_div_assign;
    zT_40.ast_kind = zT_42;
    zT_43 = zT_2B10107F_Prec_assignment;
    zT_40.prec = zT_43;
    zT_44 = 1;
    zT_40.right_assoc = zT_44;
    zT_45.has_value = 1;
    zT_45.value = zT_40;
    return zT_45;
    z_bb_10:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_51 = zT_8143F551_AstKind_mod_assign;
    zT_49.ast_kind = zT_51;
    zT_52 = zT_2B10107F_Prec_assignment;
    zT_49.prec = zT_52;
    zT_53 = 1;
    zT_49.right_assoc = zT_53;
    zT_54.has_value = 1;
    zT_54.value = zT_49;
    return zT_54;
    z_bb_12:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_60 = zT_8143F551_AstKind_shl_assign;
    zT_58.ast_kind = zT_60;
    zT_61 = zT_2B10107F_Prec_assignment;
    zT_58.prec = zT_61;
    zT_62 = 1;
    zT_58.right_assoc = zT_62;
    zT_63.has_value = 1;
    zT_63.value = zT_58;
    return zT_63;
    z_bb_14:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_69 = zT_8143F551_AstKind_shr_assign;
    zT_67.ast_kind = zT_69;
    zT_70 = zT_2B10107F_Prec_assignment;
    zT_67.prec = zT_70;
    zT_71 = 1;
    zT_67.right_assoc = zT_71;
    zT_72.has_value = 1;
    zT_72.value = zT_67;
    return zT_72;
    z_bb_16:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_78 = zT_8143F551_AstKind_and_assign;
    zT_76.ast_kind = zT_78;
    zT_79 = zT_2B10107F_Prec_assignment;
    zT_76.prec = zT_79;
    zT_80 = 1;
    zT_76.right_assoc = zT_80;
    zT_81.has_value = 1;
    zT_81.value = zT_76;
    return zT_81;
    z_bb_18:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_87 = zT_8143F551_AstKind_or_assign;
    zT_85.ast_kind = zT_87;
    zT_88 = zT_2B10107F_Prec_assignment;
    zT_85.prec = zT_88;
    zT_89 = 1;
    zT_85.right_assoc = zT_89;
    zT_90.has_value = 1;
    zT_90.value = zT_85;
    return zT_90;
    z_bb_20:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_96 = zT_8143F551_AstKind_xor_assign;
    zT_94.ast_kind = zT_96;
    zT_97 = zT_2B10107F_Prec_assignment;
    zT_94.prec = zT_97;
    zT_98 = 1;
    zT_94.right_assoc = zT_98;
    zT_99.has_value = 1;
    zT_99.value = zT_94;
    return zT_99;
    z_bb_22:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_105 = zT_8143F551_AstKind_wrap_add_assign;
    zT_103.ast_kind = zT_105;
    zT_106 = zT_2B10107F_Prec_assignment;
    zT_103.prec = zT_106;
    zT_107 = 1;
    zT_103.right_assoc = zT_107;
    zT_108.has_value = 1;
    zT_108.value = zT_103;
    return zT_108;
    z_bb_24:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_114 = zT_8143F551_AstKind_wrap_sub_assign;
    zT_112.ast_kind = zT_114;
    zT_115 = zT_2B10107F_Prec_assignment;
    zT_112.prec = zT_115;
    zT_116 = 1;
    zT_112.right_assoc = zT_116;
    zT_117.has_value = 1;
    zT_117.value = zT_112;
    return zT_117;
    z_bb_26:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_123 = zT_8143F551_AstKind_wrap_mul_assign;
    zT_121.ast_kind = zT_123;
    zT_124 = zT_2B10107F_Prec_assignment;
    zT_121.prec = zT_124;
    zT_125 = 1;
    zT_121.right_assoc = zT_125;
    zT_126.has_value = 1;
    zT_126.value = zT_121;
    return zT_126;
    z_bb_28:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_132 = zT_8143F551_AstKind_sat_add_assign;
    zT_130.ast_kind = zT_132;
    zT_133 = zT_2B10107F_Prec_assignment;
    zT_130.prec = zT_133;
    zT_134 = 1;
    zT_130.right_assoc = zT_134;
    zT_135.has_value = 1;
    zT_135.value = zT_130;
    return zT_135;
    z_bb_30:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_141 = zT_8143F551_AstKind_sat_sub_assign;
    zT_139.ast_kind = zT_141;
    zT_142 = zT_2B10107F_Prec_assignment;
    zT_139.prec = zT_142;
    zT_143 = 1;
    zT_139.right_assoc = zT_143;
    zT_144.has_value = 1;
    zT_144.value = zT_139;
    return zT_144;
    z_bb_32:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_150 = zT_8143F551_AstKind_sat_mul_assign;
    zT_148.ast_kind = zT_150;
    zT_151 = zT_2B10107F_Prec_assignment;
    zT_148.prec = zT_151;
    zT_152 = 1;
    zT_148.right_assoc = zT_152;
    zT_153.has_value = 1;
    zT_153.value = zT_148;
    return zT_153;
    z_bb_34:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_159 = zT_8143F551_AstKind_sat_shl_assign;
    zT_157.ast_kind = zT_159;
    zT_160 = zT_2B10107F_Prec_assignment;
    zT_157.prec = zT_160;
    zT_161 = 1;
    zT_157.right_assoc = zT_161;
    zT_162.has_value = 1;
    zT_162.value = zT_157;
    return zT_162;
    z_bb_36:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_168 = zT_8143F551_AstKind_orelse_expr;
    zT_166.ast_kind = zT_168;
    zT_169 = zT_2B10107F_Prec_prec_orelse;
    zT_166.prec = zT_169;
    zT_170 = 1;
    zT_166.right_assoc = zT_170;
    zT_171.has_value = 1;
    zT_171.value = zT_166;
    return zT_171;
    z_bb_38:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_177 = zT_8143F551_AstKind_catch_expr;
    zT_175.ast_kind = zT_177;
    zT_178 = zT_2B10107F_Prec_prec_catch;
    zT_175.prec = zT_178;
    zT_179 = 1;
    zT_175.right_assoc = zT_179;
    zT_180.has_value = 1;
    zT_180.value = zT_175;
    return zT_180;
    z_bb_40:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_or))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_186 = zT_8143F551_AstKind_bool_or;
    zT_184.ast_kind = zT_186;
    zT_187 = zT_2B10107F_Prec_bool_or;
    zT_184.prec = zT_187;
    zT_188 = 0;
    zT_184.right_assoc = zT_188;
    zT_189.has_value = 1;
    zT_189.value = zT_184;
    return zT_189;
    z_bb_42:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_and))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_195 = zT_8143F551_AstKind_bool_and;
    zT_193.ast_kind = zT_195;
    zT_196 = zT_2B10107F_Prec_bool_and;
    zT_193.prec = zT_196;
    zT_197 = 0;
    zT_193.right_assoc = zT_197;
    zT_198.has_value = 1;
    zT_198.value = zT_193;
    return zT_198;
    z_bb_44:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_204 = zT_8143F551_AstKind_cmp_eq;
    zT_202.ast_kind = zT_204;
    zT_205 = zT_2B10107F_Prec_comparison;
    zT_202.prec = zT_205;
    zT_206 = 0;
    zT_202.right_assoc = zT_206;
    zT_207.has_value = 1;
    zT_207.value = zT_202;
    return zT_207;
    z_bb_46:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_213 = zT_8143F551_AstKind_cmp_ne;
    zT_211.ast_kind = zT_213;
    zT_214 = zT_2B10107F_Prec_comparison;
    zT_211.prec = zT_214;
    zT_215 = 0;
    zT_211.right_assoc = zT_215;
    zT_216.has_value = 1;
    zT_216.value = zT_211;
    return zT_216;
    z_bb_48:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_222 = zT_8143F551_AstKind_cmp_lt;
    zT_220.ast_kind = zT_222;
    zT_223 = zT_2B10107F_Prec_comparison;
    zT_220.prec = zT_223;
    zT_224 = 0;
    zT_220.right_assoc = zT_224;
    zT_225.has_value = 1;
    zT_225.value = zT_220;
    return zT_225;
    z_bb_50:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_231 = zT_8143F551_AstKind_cmp_le;
    zT_229.ast_kind = zT_231;
    zT_232 = zT_2B10107F_Prec_comparison;
    zT_229.prec = zT_232;
    zT_233 = 0;
    zT_229.right_assoc = zT_233;
    zT_234.has_value = 1;
    zT_234.value = zT_229;
    return zT_234;
    z_bb_52:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_240 = zT_8143F551_AstKind_cmp_gt;
    zT_238.ast_kind = zT_240;
    zT_241 = zT_2B10107F_Prec_comparison;
    zT_238.prec = zT_241;
    zT_242 = 0;
    zT_238.right_assoc = zT_242;
    zT_243.has_value = 1;
    zT_243.value = zT_238;
    return zT_243;
    z_bb_54:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_249 = zT_8143F551_AstKind_cmp_ge;
    zT_247.ast_kind = zT_249;
    zT_250 = zT_2B10107F_Prec_comparison;
    zT_247.prec = zT_250;
    zT_251 = 0;
    zT_247.right_assoc = zT_251;
    zT_252.has_value = 1;
    zT_252.value = zT_247;
    return zT_252;
    z_bb_56:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_258 = zT_8143F551_AstKind_bit_or;
    zT_256.ast_kind = zT_258;
    zT_259 = zT_2B10107F_Prec_bit_or;
    zT_256.prec = zT_259;
    zT_260 = 0;
    zT_256.right_assoc = zT_260;
    zT_261.has_value = 1;
    zT_261.value = zT_256;
    return zT_261;
    z_bb_58:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_267 = zT_8143F551_AstKind_bit_xor;
    zT_265.ast_kind = zT_267;
    zT_268 = zT_2B10107F_Prec_bit_xor;
    zT_265.prec = zT_268;
    zT_269 = 0;
    zT_265.right_assoc = zT_269;
    zT_270.has_value = 1;
    zT_270.value = zT_265;
    return zT_270;
    z_bb_60:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_276 = zT_8143F551_AstKind_bit_and;
    zT_274.ast_kind = zT_276;
    zT_277 = zT_2B10107F_Prec_bit_and;
    zT_274.prec = zT_277;
    zT_278 = 0;
    zT_274.right_assoc = zT_278;
    zT_279.has_value = 1;
    zT_279.value = zT_274;
    return zT_279;
    z_bb_62:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_285 = zT_8143F551_AstKind_shl;
    zT_283.ast_kind = zT_285;
    zT_286 = zT_2B10107F_Prec_shift;
    zT_283.prec = zT_286;
    zT_287 = 0;
    zT_283.right_assoc = zT_287;
    zT_288.has_value = 1;
    zT_288.value = zT_283;
    return zT_288;
    z_bb_64:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_294 = zT_8143F551_AstKind_shr;
    zT_292.ast_kind = zT_294;
    zT_295 = zT_2B10107F_Prec_shift;
    zT_292.prec = zT_295;
    zT_296 = 0;
    zT_292.right_assoc = zT_296;
    zT_297.has_value = 1;
    zT_297.value = zT_292;
    return zT_297;
    z_bb_66:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_303 = zT_8143F551_AstKind_sat_shl;
    zT_301.ast_kind = zT_303;
    zT_304 = zT_2B10107F_Prec_shift;
    zT_301.prec = zT_304;
    zT_305 = 0;
    zT_301.right_assoc = zT_305;
    zT_306.has_value = 1;
    zT_306.value = zT_301;
    return zT_306;
    z_bb_68:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_312 = zT_8143F551_AstKind_add;
    zT_310.ast_kind = zT_312;
    zT_313 = zT_2B10107F_Prec_additive;
    zT_310.prec = zT_313;
    zT_314 = 0;
    zT_310.right_assoc = zT_314;
    zT_315.has_value = 1;
    zT_315.value = zT_310;
    return zT_315;
    z_bb_70:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus))) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_321 = zT_8143F551_AstKind_sub;
    zT_319.ast_kind = zT_321;
    zT_322 = zT_2B10107F_Prec_additive;
    zT_319.prec = zT_322;
    zT_323 = 0;
    zT_319.right_assoc = zT_323;
    zT_324.has_value = 1;
    zT_324.value = zT_319;
    return zT_324;
    z_bb_72:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_330 = zT_8143F551_AstKind_wrap_add;
    zT_328.ast_kind = zT_330;
    zT_331 = zT_2B10107F_Prec_additive;
    zT_328.prec = zT_331;
    zT_332 = 0;
    zT_328.right_assoc = zT_332;
    zT_333.has_value = 1;
    zT_333.value = zT_328;
    return zT_333;
    z_bb_74:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_339 = zT_8143F551_AstKind_wrap_sub;
    zT_337.ast_kind = zT_339;
    zT_340 = zT_2B10107F_Prec_additive;
    zT_337.prec = zT_340;
    zT_341 = 0;
    zT_337.right_assoc = zT_341;
    zT_342.has_value = 1;
    zT_342.value = zT_337;
    return zT_342;
    z_bb_76:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_348 = zT_8143F551_AstKind_sat_add;
    zT_346.ast_kind = zT_348;
    zT_349 = zT_2B10107F_Prec_additive;
    zT_346.prec = zT_349;
    zT_350 = 0;
    zT_346.right_assoc = zT_350;
    zT_351.has_value = 1;
    zT_351.value = zT_346;
    return zT_351;
    z_bb_78:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_357 = zT_8143F551_AstKind_sat_sub;
    zT_355.ast_kind = zT_357;
    zT_358 = zT_2B10107F_Prec_additive;
    zT_355.prec = zT_358;
    zT_359 = 0;
    zT_355.right_assoc = zT_359;
    zT_360.has_value = 1;
    zT_360.value = zT_355;
    return zT_360;
    z_bb_80:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_366 = zT_8143F551_AstKind_mul;
    zT_364.ast_kind = zT_366;
    zT_367 = zT_2B10107F_Prec_multiply;
    zT_364.prec = zT_367;
    zT_368 = 0;
    zT_364.right_assoc = zT_368;
    zT_369.has_value = 1;
    zT_369.value = zT_364;
    return zT_369;
    z_bb_82:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_375 = zT_8143F551_AstKind_div;
    zT_373.ast_kind = zT_375;
    zT_376 = zT_2B10107F_Prec_multiply;
    zT_373.prec = zT_376;
    zT_377 = 0;
    zT_373.right_assoc = zT_377;
    zT_378.has_value = 1;
    zT_378.value = zT_373;
    return zT_378;
    z_bb_84:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent))) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_384 = zT_8143F551_AstKind_mod_op;
    zT_382.ast_kind = zT_384;
    zT_385 = zT_2B10107F_Prec_multiply;
    zT_382.prec = zT_385;
    zT_386 = 0;
    zT_382.right_assoc = zT_386;
    zT_387.has_value = 1;
    zT_387.value = zT_382;
    return zT_387;
    z_bb_86:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct))) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_393 = zT_8143F551_AstKind_wrap_mul;
    zT_391.ast_kind = zT_393;
    zT_394 = zT_2B10107F_Prec_multiply;
    zT_391.prec = zT_394;
    zT_395 = 0;
    zT_391.right_assoc = zT_395;
    zT_396.has_value = 1;
    zT_396.value = zT_391;
    return zT_396;
    z_bb_88:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe))) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_402 = zT_8143F551_AstKind_sat_mul;
    zT_400.ast_kind = zT_402;
    zT_403 = zT_2B10107F_Prec_multiply;
    zT_400.prec = zT_403;
    zT_404 = 0;
    zT_400.right_assoc = zT_404;
    zT_405.has_value = 1;
    zT_405.value = zT_400;
    return zT_405;
    z_bb_90:
    zT_406.has_value = 0;
    return zT_406;
}

/* __module_init */
void zF_780653D2___module_init_7(void) {
    zT_F85C5DED_DiagnosticCollector zT_0 = {0};
    zT_072B53A6_ModuleRegistry zT_1 = {0};
    zG_F85C5DED_DiagnosticCollector = zT_0;
    zG_072B53A6_ModuleRegistry = zT_1;
    return;
}

/* EOF */
