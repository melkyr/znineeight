#include "parser_61A67AF1.h"
#include <stdio.h>
/* parserInitCommon */
zT_B559F9DA_Parser zF_EDAEEEE9_parserInitCommon(zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc, unsigned int builtin_import_id) {
    zT_3A355BD2_Token zT_7;
    zT_EAC3E484_TokenKind zT_9;
    unsigned int zT_10;
    unsigned short zT_11;
    zT_85CBA4DB_TokenValue zT_12 = {0};
    zT_B559F9DA_Parser zT_14;
    unsigned char zT_15;
    int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char* zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_31;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_7332B667_Opt_231 zT_37 = {0};
    zT_6D306E5E_Opt_243 zT_38 = {0};
    unsigned int zT_39;
    unsigned int zT_40;
    zT_3A355BD2_Token zero_tok;
    zT_9 = zT_EAC3E484_TokenKind_eof;
    zT_7.kind = zT_9;
    zT_10 = 0;
    zT_7.span_start = zT_10;
    zT_11 = 0;
    zT_7.span_len = zT_11;
    zT_7.value = zT_12;
    zero_tok = zT_7;
    zT_15 = 0;
    zT_14.use_lex = zT_15;
    zT_16 = 0;
    zT_14.lex = (zT_138FFB41_Lexer*)zT_16;
    zT_17 = 0;
    zT_14.tokens_ptr = (zT_3A355BD2_Token*)zT_17;
    zT_18 = 0;
    zT_14.tokens_len = zT_18;
    zT_20 = source.ptr;
    zT_21 = (unsigned char*)zT_20;
    zT_14.source_ptr = zT_21;
    zT_23 = source.len;
    zT_14.source_len = zT_23;
    zT_24 = 0;
    zT_14.pos = zT_24;
    zT_25 = 0;
    zT_14.la_len = zT_25;
    zT_26 = 0;
    zT_14.at_eof = zT_26;
    zT_14.eof_tok = zero_tok;
    zT_14.store = store;
    zT_14.interner = interner;
    zT_14.diag = diag;
    zT_14.allocator = alloc;
    zT_27 = 0;
    zT_14.child_buf_items = (unsigned int*)zT_27;
    zT_28 = 0;
    zT_14.child_buf_len = zT_28;
    zT_29 = 0;
    zT_14.child_buf_capacity = zT_29;
    zT_30 = 0;
    zT_14.last_end = zT_30;
    zT_14.last_tok = zero_tok;
    zT_31 = 0;
    zT_14.last_tok_valid = zT_31;
    zT_32 = 0;
    zT_14.decl_buf_items = (unsigned int*)zT_32;
    zT_33 = 0;
    zT_14.decl_buf_len = zT_33;
    zT_34 = 0;
    zT_14.decl_buf_capacity = zT_34;
    zT_35 = 0;
    zT_14.catch_capture = zT_35;
    zT_36 = 0;
    zT_14.expr_depth = zT_36;
    zT_14.builtin_import_id = builtin_import_id;
    zT_37.has_value = 0;
    zT_14.module_reg = zT_37;
    zT_38.has_value = 0;
    zT_14.import_scratch = zT_38;
    zT_39 = 0;
    zT_14.current_module_id = zT_39;
    zT_40 = 0;
    zT_14.file_id = zT_40;
    return zT_14;
}

/* parserInit */
zT_B559F9DA_Parser zF_74A05BF0_parserInit(zT_F020719E_Slice_zT_3A355BD2_T tokens, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3A355BD2_Token* zT_8;
    zT_3A355BD2_Token* zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    zT_D3EB6303_StringInterner* zT_21;
    zT_F85C5DED_DiagnosticCollector* zT_22;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    zT_B559F9DA_Parser zT_25 = {0};
    unsigned int zT_28;
    zT_3A355BD2_Token* t_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_8 = tokens.ptr;
    zT_9 = (zT_3A355BD2_Token*)zT_8;
    t_ptr = zT_9;
    zT_11 = "@import";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    import_s = zT_12;
    zT_15 = interner;
    zT_16 = import_s;
    zT_17 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    import_id = zT_17;
    zT_19 = source;
    zT_20 = store;
    zT_21 = interner;
    zT_22 = diag;
    zT_23 = alloc;
    zT_24 = import_id;
    zT_25 = zF_EDAEEEE9_parserInitCommon(zT_19, zT_20, zT_21, zT_22, zT_23, zT_24);
    p = zT_25;
    p.use_lex = (unsigned char)(0);
    p.tokens_ptr = t_ptr;
    zT_28 = tokens.len;
    p.tokens_len = zT_28;
    return p;
}

/* parserInitStreaming */
zT_B559F9DA_Parser zF_9E9ED878_parserInitStreaming(zT_138FFB41_Lexer* lex, zT_8F083A69_Slice_zT_0B42B2F8_u source, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_D3EB6303_StringInterner* zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    zT_B559F9DA_Parser zT_21 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u import_s;
    unsigned int import_id;
    zT_B559F9DA_Parser p;
    zT_7 = "@import";
    zT_9 = 7;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    import_s = zT_8;
    zT_11 = interner;
    zT_12 = import_s;
    zT_13 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    import_id = zT_13;
    zT_15 = source;
    zT_16 = store;
    zT_17 = interner;
    zT_18 = diag;
    zT_19 = alloc;
    zT_20 = import_id;
    zT_21 = zF_EDAEEEE9_parserInitCommon(zT_15, zT_16, zT_17, zT_18, zT_19, zT_20);
    p = zT_21;
    p.use_lex = (unsigned char)(1);
    p.lex = lex;
    return p;
}

/* parserSetModuleContext */
void zF_15960D31_parserSetModuleCont(zT_B559F9DA_Parser* self, zT_072B53A6_ModuleRegistry* reg, unsigned int mod_id) {
    zT_7332B667_Opt_231 zT_3;
    zT_E41AEC18_ModuleEntryArrayLis zT_4;
    zT_6E8D187B_ModuleEntry* zT_5;
    zT_6E8D187B_ModuleEntry zT_6;
    unsigned int zT_7;
    zT_3.has_value = 1;
    zT_3.value = reg;
    self->module_reg = zT_3;
    self->current_module_id = mod_id;
    zT_4 = reg->modules;
    zT_5 = zT_4.items;
    zT_6 = zT_5[mod_id];
    zT_7 = zT_6.source_file_id;
    self->file_id = zT_7;
    return;
}

/* parserSetImportScratch */
void zF_C8F08D73_parserSetImportScra(zT_B559F9DA_Parser* self, zT_3E40CD83_Sand* scratch) {
    zT_6D306E5E_Opt_243 zT_2;
    zT_2.has_value = 1;
    zT_2.value = scratch;
    self->import_scratch = zT_2;
    return;
}

/* parserTokenText */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08D61E58_parserTokenText(zT_B559F9DA_Parser* self, zT_2B3424E9_ParseToken tok) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned short zT_6;
    unsigned int zT_8;
    unsigned char* zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int start;
    unsigned int end;
    zT_3 = tok.span_start;
    zT_4 = (unsigned int)zT_3;
    start = zT_4;
    zT_6 = tok.span_len;
    zT_8 = start + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->source_ptr;
    zT_10 = zT_9 + start;
    zT_11 = end - start;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    return zT_12;
}

/* parserPullOne */
void zF_7C3FD09B_parserPullOne(zT_B559F9DA_Parser* self) {
    unsigned char zT_1;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned char zT_4;
    zT_138FFB41_Lexer* zT_5;
    zT_3A355BD2_Token zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_3A355BD2_Token* zT_11;
    unsigned int zT_12;
    zT_3A355BD2_Token zT_13;
    unsigned int zT_14;
    int zT_15;
    zT_3A355BD2_Token* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    zT_3A355BD2_Token zT_22;
    zT_EAC3E484_TokenKind zT_23;
    zT_3A355BD2_Token* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_3A355BD2_Token tok;
    zT_1 = self->at_eof;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    tok = zT_3;
    zT_4 = self->use_lex;
    if (zT_4) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_5 = self->lex;
    zT_7 = zF_B976BEC9_lexerNextToken(zT_5);
    tok = zT_7;
    goto z_bb_4;
    z_bb_4:
    zT_23 = tok.kind;
    if ((unsigned char)(zT_23 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_9; else goto z_bb_10;
    z_bb_5:
    zT_8 = self->pos;
    zT_9 = self->tokens_len;
    if ((unsigned char)(zT_8 < zT_9)) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_11 = self->tokens_ptr;
    zT_12 = self->pos;
    zT_13 = zT_11[zT_12];
    tok = zT_13;
    zT_14 = self->pos;
    zT_15 = 1;
    self->pos = (unsigned int)(zT_14 + (unsigned int)((unsigned int)zT_15));
    goto z_bb_7;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = self->tokens_ptr;
    zT_19 = self->tokens_len;
    zT_20 = 1;
    zT_21 = zT_19 - zT_20;
    zT_22 = zT_18[zT_21];
    tok = zT_22;
    goto z_bb_7;
    z_bb_9:
    self->at_eof = (unsigned char)(1);
    self->eof_tok = tok;
    goto z_bb_10;
    z_bb_10:
    zT_28 = self->la;
    zT_29 = self->la_len;
    zT_28[zT_29] = tok;
    zT_30 = self->la_len;
    zT_31 = 1;
    self->la_len = (unsigned int)(zT_30 + (unsigned int)((unsigned int)zT_31));
    return;
}

/* parserConsumeCurrent */
void zF_2DCC9581_parserConsumeCurren(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    unsigned char zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3A355BD2_Token* zT_16;
    zT_3A355BD2_Token zT_17;
    zT_3A355BD2_Token* zT_18;
    int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    zT_B559F9DA_Parser* zT_28;
    unsigned int i;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    self->last_tok = zT_9;
    self->last_tok_valid = (unsigned char)(1);
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    i = zT_13;
    goto z_bb_5;
    z_bb_3:
    zT_5 = self->eof_tok;
    self->last_tok = zT_5;
    self->last_tok_valid = (unsigned char)(1);
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_14 = self->la_len;
    if ((unsigned char)(i < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_16 = self->la;
    zT_17 = zT_16[i];
    zT_18 = self->la;
    zT_19 = 1;
    zT_20 = i - zT_19;
    zT_18[zT_20] = zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_24 = self->la_len;
    zT_25 = 1;
    self->la_len = (unsigned int)(zT_24 - (unsigned int)((unsigned int)zT_25));
    zT_28 = self;
    zF_7C3FD09B_parserPullOne(zT_28);
    return;
    z_bb_8:
    zT_21 = 1;
    zT_23 = i + (unsigned int)((unsigned int)zT_21);
    i = zT_23;
    goto z_bb_5;
}

/* parserPeek */
zT_3A355BD2_Token zF_068A2DE5_parserPeek(zT_B559F9DA_Parser* self) {
    unsigned int zT_1;
    int zT_2;
    unsigned char zT_4;
    zT_3A355BD2_Token zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token* zT_7;
    int zT_8;
    zT_3A355BD2_Token zT_9;
    zT_1 = self->la_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->at_eof;
    if (zT_4) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_7 = self->la;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    return zT_9;
    z_bb_3:
    zT_5 = self->eof_tok;
    return zT_5;
    z_bb_4:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_2;
}

/* parserPeekN */
zT_3A355BD2_Token zF_F685E431_parserPeekN(zT_B559F9DA_Parser* self, unsigned int n) {
    unsigned int zT_2;
    unsigned char zT_5;
    zT_B559F9DA_Parser* zT_6;
    unsigned int zT_7;
    zT_3A355BD2_Token* zT_10;
    zT_3A355BD2_Token zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_3A355BD2_Token* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_3A355BD2_Token zT_19;
    zT_3A355BD2_Token zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self->la_len;
    if ((unsigned char)(zT_2 <= (unsigned int)((unsigned int)n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self->at_eof;
    if (zT_5) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_7 = self->la_len;
    if ((unsigned char)(zT_7 > (unsigned int)((unsigned int)n))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_6 = self;
    zF_7C3FD09B_parserPullOne(zT_6);
    goto z_bb_4;
    z_bb_7:
    zT_10 = self->la;
    zT_11 = zT_10[n];
    return zT_11;
    z_bb_8:
    zT_12 = self->la_len;
    zT_13 = 0;
    if ((unsigned char)(zT_12 > (unsigned int)zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = self->la;
    zT_16 = self->la_len;
    zT_17 = 1;
    zT_18 = zT_16 - zT_17;
    zT_19 = zT_15[zT_18];
    return zT_19;
    z_bb_10:
    zT_20 = self->eof_tok;
    return zT_20;
}

/* parserAdvance */
zT_3A355BD2_Token zF_C241B2C4_parserAdvance(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_4;
    unsigned short zT_5;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.span_start;
    zT_5 = tok.span_len;
    self->last_end = (unsigned int)(zT_4 + (unsigned int)((unsigned int)zT_5));
    zT_8 = self;
    zF_2DCC9581_parserConsumeCurren(zT_8);
    return tok;
}

/* tokenKindLabel */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_77B50062_tokenKindLabel(zT_EAC3E484_TokenKind kind) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    unsigned char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "';'";
    zT_7 = 3;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s = zT_6;
    return s;
    z_bb_2:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = "'('";
    zT_14 = 3;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    s = zT_13;
    return s;
    z_bb_4:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "')'";
    zT_21 = 3;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    s = zT_20;
    return s;
    z_bb_6:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = "'{'";
    zT_28 = 3;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s = zT_27;
    return s;
    z_bb_8:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = "'}'";
    zT_35 = 3;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s = zT_34;
    return s;
    z_bb_10:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_40 = "'['";
    zT_42 = 3;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    s = zT_41;
    return s;
    z_bb_12:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_47 = "']'";
    zT_49 = 3;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    s = zT_48;
    return s;
    z_bb_14:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = "','";
    zT_56 = 3;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s = zT_55;
    return s;
    z_bb_16:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_61 = "'.'";
    zT_63 = 3;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s = zT_62;
    return s;
    z_bb_18:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_68 = "':'";
    zT_70 = 3;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    s = zT_69;
    return s;
    z_bb_20:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_75 = "'|'";
    zT_77 = 3;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    s = zT_76;
    return s;
    z_bb_22:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_82 = "identifier";
    zT_84 = 10;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s = zT_83;
    return s;
    z_bb_24:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_89 = "string literal";
    zT_91 = 14;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    s = zT_90;
    return s;
    z_bb_26:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_96 = "integer literal";
    zT_98 = 15;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    s = zT_97;
    return s;
    z_bb_28:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_103 = "'fn'";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    s = zT_104;
    return s;
    z_bb_30:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_110 = "'while'";
    zT_112 = 7;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s = zT_111;
    return s;
    z_bb_32:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_117 = "'if'";
    zT_119 = 4;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    s = zT_118;
    return s;
    z_bb_34:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_124 = "'else'";
    zT_126 = 6;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    s = zT_125;
    return s;
    z_bb_36:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_131 = "'return'";
    zT_133 = 8;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    s = zT_132;
    return s;
    z_bb_38:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_138 = "'const'";
    zT_140 = 7;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    s = zT_139;
    return s;
    z_bb_40:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_145 = "'var'";
    zT_147 = 5;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    s = zT_146;
    return s;
    z_bb_42:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_152 = "'pub'";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    s = zT_153;
    return s;
    z_bb_44:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_159 = "'extern'";
    zT_161 = 8;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    s = zT_160;
    return s;
    z_bb_46:
    zT_163 = "token";
    zT_165 = 5;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    fallback = zT_164;
    return fallback;
}

/* parserExpect */
zT_CB78802F_EU_49 zF_5578C74F_parserExpect(zT_B559F9DA_Parser* self, zT_EAC3E484_TokenKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_EAC3E484_TokenKind zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13 = {0};
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_EAC3E484_TokenKind zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_4F2154A7_Arr_zT_8F083A69_Sli zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_30;
    zT_F85C5DED_DiagnosticCollector* zT_32;
    int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_DBF3575C_ParserError zT_41;
    zT_CB78802F_EU_49 zT_42;
    zT_B559F9DA_Parser* zT_43;
    zT_2B3424E9_ParseToken zT_44;
    zT_EAC3E484_TokenKind zT_45;
    unsigned int zT_46;
    unsigned short zT_47;
    zT_CB78802F_EU_49 zT_48;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_lab;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnd_lab;
    zT_4F2154A7_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    tok = zT_4;
    zT_5 = tok.kind;
    if ((unsigned char)(zT_5 != kind)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = "expected ";
    zT_10 = 9;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    exp_s = zT_9;
    zT_12 = kind;
    zT_13 = zF_77B50062_tokenKindLabel(zT_12);
    exp_lab = zT_13;
    zT_15 = " but found ";
    zT_17 = 11;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    fnd_s = zT_16;
    zT_19 = tok.kind;
    zT_21 = zF_77B50062_tokenKindLabel(zT_19);
    fnd_lab = zT_21;
    zT_24 = 0;
    zT_23[zT_24] = exp_s;
    zT_25 = 1;
    zT_23[zT_25] = exp_lab;
    zT_26 = 2;
    zT_23[zT_26] = fnd_s;
    zT_27 = 3;
    zT_23[zT_27] = fnd_lab;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        parts[_i] = zT_23[_i];
        _i++;
    }
}
    zT_32 = self->diag;
    zT_29 = zT_32->interner;
    zT_34 = 0;
    zT_35 = parts + zT_34;
    zT_30 = zT_35;
    zT_37 = zF_8C4BFF7C_diagnosticBuilderMa(zT_29, zT_30, (unsigned int)(4));
    msg = zT_37;
    zT_38 = self;
    zT_39 = tok;
    zT_40 = msg;
    zF_17DF2CA5_parserAddError(zT_38, zT_39, zT_40);
    zT_41 = 1;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_2:
    zT_43 = self;
    zF_2DCC9581_parserConsumeCurren(zT_43);
    zT_45 = tok.kind;
    zT_44.kind = zT_45;
    zT_46 = tok.span_start;
    zT_44.span_start = zT_46;
    zT_47 = tok.span_len;
    zT_44.span_len = zT_47;
    zT_48.data.payload = zT_44;
    zT_48.is_error = 0;
    return zT_48;
}

/* parserAddError */
void zF_17DF2CA5_parserAddError(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_3;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_3 = self->diag;
    zT_6 = self->file_id;
    zT_7 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_9 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_3, (unsigned char)(0), (unsigned short)(2000), zT_6, zT_7, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_9);
    return;
}

/* parserSynchronize */
void zF_4190C400_parserSynchronize(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned char zT_17;
    unsigned char zT_21;
    unsigned char zT_25;
    unsigned char zT_29;
    zT_B559F9DA_Parser* zT_33;
    zT_B559F9DA_Parser* zT_37;
    zT_EAC3E484_TokenKind k;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    k = zT_5;
    if ((unsigned char)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_9 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_7;
    z_bb_6:
    zT_9 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_13 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_13) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_17 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const);
    goto z_bb_13;
    z_bb_12:
    zT_17 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_17) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_21 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var);
    goto z_bb_16;
    z_bb_15:
    zT_21 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_21) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_25 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub);
    goto z_bb_19;
    z_bb_18:
    zT_25 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_25) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_29 = k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test);
    goto z_bb_22;
    z_bb_21:
    zT_29 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_29) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_33 = self;
    zF_2DCC9581_parserConsumeCurren(zT_33);
    return;
    z_bb_24:
    if ((unsigned char)(k == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return;
    z_bb_26:
    zT_37 = self;
    zF_2DCC9581_parserConsumeCurren(zT_37);
    goto z_bb_4;
}

/* parserParseExprPrec */
zT_3B6EA323_EU_01 zF_F07C1F04_parserParseExprPrec(zT_B559F9DA_Parser* self, zT_2B10107F_Prec min_prec) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_6;
    int zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_13;
    unsigned int zT_14;
    char* zT_15;
    unsigned int zT_16;
    char* zT_17;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_21;
    zT_3B6EA323_EU_01 zT_22 = {0};
    unsigned char zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_28;
    zT_B559F9DA_Parser* zT_29;
    unsigned int zT_30;
    zT_3B6EA323_EU_01 zT_31 = {0};
    unsigned char zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41 = {0};
    int zT_43;
    unsigned char zT_44;
    zT_F4EBEA72_OpInfo zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_ADDA7CFF_Opt_97 zT_49 = {0};
    unsigned char zT_50;
    int zT_52;
    unsigned char zT_53;
    int zT_54;
    zT_2B10107F_Prec zT_56;
    unsigned char zT_58 = 0;
    zT_2B10107F_Prec zT_59;
    unsigned char zT_60 = 0;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_2B10107F_Prec zT_65 = 0;
    unsigned char zT_66;
    zT_2B10107F_Prec zT_67;
    zT_2B10107F_Prec zT_69;
    unsigned char zT_71 = 0;
    int zT_72;
    zT_2B10107F_Prec zT_74 = 0;
    unsigned int zT_76 = 0;
    int zT_78;
    unsigned char zT_79;
    zT_EAC3E484_TokenKind zT_80;
    unsigned int zT_85;
    zT_B559F9DA_Parser* zT_86;
    zT_2B10107F_Prec zT_87;
    unsigned int* zT_88;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_96;
    unsigned int zT_98;
    unsigned short zT_99;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    int zT_114;
    int zT_117;
    unsigned int zT_119 = 0;
    int zT_120;
    unsigned char zT_121;
    zT_EAC3E484_TokenKind zT_122;
    zT_B559F9DA_Parser* zT_126;
    zT_2B10107F_Prec zT_127;
    zT_3B6EA323_EU_01 zT_128 = {0};
    unsigned char zT_129;
    unsigned int zT_130;
    int zT_131;
    unsigned int zT_134;
    zT_B559F9DA_Parser* zT_135;
    zT_2B10107F_Prec zT_136;
    zT_3B6EA323_EU_01 zT_137 = {0};
    unsigned char zT_138;
    unsigned int zT_139;
    int zT_140;
    unsigned int zT_143;
    int zT_144;
    zT_B559F9DA_Parser* zT_146;
    zT_3A355BD2_Token zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_3B6EA323_EU_01 zT_150 = {0};
    unsigned char zT_151;
    unsigned int zT_152;
    int zT_153;
    unsigned int zT_156;
    unsigned int zT_157;
    int zT_158;
    zT_3B6EA323_EU_01 zT_161;
    unsigned int zT_162;
    int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int lhs;
    zT_3A355BD2_Token tok;
    unsigned char has_info;
    zT_F4EBEA72_OpInfo info;
    zT_F4EBEA72_OpInfo val;
    zT_2B10107F_Prec next_min;
    unsigned int rhs;
    unsigned char catch_handled;
    unsigned int cap;
    unsigned int end;
    zT_2 = self->expr_depth;
    zT_3 = 1;
    self->expr_depth = (unsigned int)(zT_2 + (unsigned int)((unsigned int)zT_3));
    zT_6 = self->expr_depth;
    zT_7 = 12;
    if ((unsigned char)(zT_6 > (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = "max expression recursion depth exceeded";
    zT_12 = 39;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    msg = zT_11;
    zT_13 = "panic: ";
    zT_14 = 7;
    fwrite(zT_13, 1, zT_14, stderr);
    zT_15 = msg.ptr;
    zT_16 = msg.len;
    fwrite(zT_15, 1, zT_16, stderr);
    zT_17 = "\n";
    zT_18 = 1;
    fwrite(zT_17, 1, zT_18, stderr);
    pal_trap();
    z_bb_2:
    zT_21 = self;
    zT_22 = zF_565DCE21_parserParsePrimary(zT_21);
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = self->expr_depth;
    zT_25 = 1;
    self->expr_depth = (unsigned int)(zT_24 - (unsigned int)((unsigned int)zT_25));
    return zT_22;
    z_bb_4:
    zT_28 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    lhs = zT_28;
    zT_29 = self;
    zT_30 = lhs;
    zT_31 = zF_77AD89E7_parserParsePostfixC(zT_29, zT_30);
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_33 = self->expr_depth;
    zT_34 = 1;
    self->expr_depth = (unsigned int)(zT_33 - (unsigned int)((unsigned int)zT_34));
    return zT_31;
    z_bb_7:
    zT_37 = zT_31.data.payload;
    goto z_bb_8;
    z_bb_8:
    lhs = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(1)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = zF_068A2DE5_parserPeek(zT_40);
    tok = zT_41;
    zT_43 = 0;
    zT_44 = (unsigned char)zT_43;
    has_info = zT_44;
    info = zT_46;
    zT_47 = tok.kind;
    zT_49 = zF_1E2936C3_getInfixInfo(zT_47);
    zT_50 = zT_49.has_value;
    if (zT_50) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_157 = self->expr_depth;
    zT_158 = 1;
    self->expr_depth = (unsigned int)(zT_157 - (unsigned int)((unsigned int)zT_158));
    zT_161.data.payload = lhs;
    zT_161.is_error = 0;
    return zT_161;
    zT_162 = self->expr_depth;
    zT_163 = 1;
    self->expr_depth = (unsigned int)(zT_162 - (unsigned int)((unsigned int)zT_163));
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    val = zT_49.value;
    info = val;
    zT_52 = 1;
    zT_53 = (unsigned char)zT_52;
    has_info = zT_53;
    goto z_bb_14;
    z_bb_14:
    zT_54 = 0;
    if ((unsigned char)(has_info == zT_54)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_56 = info.prec;
    zT_58 = zF_F312BDA3_precToInt(zT_56);
    zT_59 = min_prec;
    zT_60 = zF_F312BDA3_precToInt(zT_59);
    if ((unsigned char)(zT_58 < zT_60)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_11;
    z_bb_18:
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    next_min = zT_65;
    zT_66 = info.right_assoc;
    if (zT_66) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_67 = info.prec;
    next_min = zT_67;
    goto z_bb_20;
    z_bb_20:
    rhs = zT_76;
    zT_78 = 0;
    zT_79 = (unsigned char)zT_78;
    catch_handled = zT_79;
    zT_80 = tok.kind;
    if ((unsigned char)(zT_80 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_22; else goto z_bb_24;
    z_bb_21:
    zT_69 = info.prec;
    zT_71 = zF_F312BDA3_precToInt(zT_69);
    zT_72 = 1;
    zT_74 = zF_860100DC_precFromInt((unsigned char)(zT_71 + zT_72));
    next_min = zT_74;
    goto z_bb_20;
    z_bb_22:
    zT_85 = 0;
    cap = zT_85;
    zT_86 = self;
    zT_87 = next_min;
    zT_88 = &cap;
    zT_90 = zF_95DDA8C7_parserParseCatchRHS(zT_86, zT_87, zT_88);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_144 = 0;
    if ((unsigned char)(catch_handled == zT_144)) goto z_bb_37; else goto z_bb_38;
    z_bb_24:
    zT_122 = tok.kind;
    if ((unsigned char)(zT_122 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_28; else goto z_bb_30;
    z_bb_25:
    zT_92 = self->expr_depth;
    zT_93 = 1;
    self->expr_depth = (unsigned int)(zT_92 - (unsigned int)((unsigned int)zT_93));
    return zT_90;
    z_bb_26:
    zT_96 = zT_90.data.payload;
    goto z_bb_27;
    z_bb_27:
    rhs = zT_96;
    zT_98 = tok.span_start;
    zT_99 = tok.span_len;
    zT_101 = zT_98 + (unsigned int)((unsigned int)zT_99);
    end = zT_101;
    zT_102 = self->store;
    zT_114 = 0;
    zT_105 = tok.span_start;
    zT_106 = end;
    zT_107 = lhs;
    zT_108 = rhs;
    zT_109 = cap;
    zT_117 = 0;
    zT_119 = zF_6C9FF72F_astStoreAddNode(zT_102, (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr), (unsigned char)((unsigned char)zT_114), zT_105, zT_106, zT_107, zT_108, zT_109, (unsigned int)((unsigned int)zT_117));
    lhs = zT_119;
    zT_120 = 1;
    zT_121 = (unsigned char)zT_120;
    catch_handled = zT_121;
    goto z_bb_23;
    z_bb_28:
    zT_126 = self;
    zT_127 = next_min;
    zT_128 = zF_A059028C_parserParseOrelseRH(zT_126, zT_127);
    zT_129 = zT_128.is_error;
    if (zT_129) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_135 = self;
    zT_136 = next_min;
    zT_137 = zF_F07C1F04_parserParseExprPrec(zT_135, zT_136);
    zT_138 = zT_137.is_error;
    if (zT_138) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_130 = self->expr_depth;
    zT_131 = 1;
    self->expr_depth = (unsigned int)(zT_130 - (unsigned int)((unsigned int)zT_131));
    return zT_128;
    z_bb_32:
    zT_134 = zT_128.data.payload;
    goto z_bb_33;
    z_bb_33:
    rhs = zT_134;
    goto z_bb_29;
    z_bb_34:
    zT_139 = self->expr_depth;
    zT_140 = 1;
    self->expr_depth = (unsigned int)(zT_139 - (unsigned int)((unsigned int)zT_140));
    return zT_137;
    z_bb_35:
    zT_143 = zT_137.data.payload;
    goto z_bb_36;
    z_bb_36:
    rhs = zT_143;
    goto z_bb_29;
    z_bb_37:
    zT_146 = self;
    zT_147 = tok;
    zT_148 = lhs;
    zT_149 = rhs;
    zT_150 = zF_E702AE30_parserAddBinary(zT_146, zT_147, zT_148, zT_149);
    zT_151 = zT_150.is_error;
    if (zT_151) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_12;
    z_bb_39:
    zT_152 = self->expr_depth;
    zT_153 = 1;
    self->expr_depth = (unsigned int)(zT_152 - (unsigned int)((unsigned int)zT_153));
    return zT_150;
    z_bb_40:
    zT_156 = zT_150.data.payload;
    goto z_bb_41;
    z_bb_41:
    lhs = zT_156;
    goto z_bb_38;
}

/* parserAddBinary */
zT_3B6EA323_EU_01 zF_E702AE30_parserAddBinary(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned int lhs, unsigned int rhs) {
    zT_8143F551_AstKind zT_5 = 0;
    int zT_7;
    unsigned char zT_8;
    zT_EAC3E484_TokenKind zT_9;
    zT_8143F551_AstKind zT_11;
    int zT_12;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_15;
    int zT_16;
    unsigned char zT_17;
    zT_8143F551_AstKind zT_19;
    int zT_20;
    unsigned char zT_21;
    zT_8143F551_AstKind zT_23;
    int zT_24;
    unsigned char zT_25;
    zT_8143F551_AstKind zT_27;
    int zT_28;
    unsigned char zT_29;
    zT_8143F551_AstKind zT_31;
    int zT_32;
    unsigned char zT_33;
    zT_8143F551_AstKind zT_35;
    int zT_36;
    unsigned char zT_37;
    zT_8143F551_AstKind zT_39;
    int zT_40;
    unsigned char zT_41;
    zT_8143F551_AstKind zT_43;
    int zT_44;
    unsigned char zT_45;
    zT_8143F551_AstKind zT_47;
    int zT_48;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_51;
    int zT_52;
    unsigned char zT_53;
    zT_8143F551_AstKind zT_55;
    int zT_56;
    unsigned char zT_57;
    zT_8143F551_AstKind zT_59;
    int zT_60;
    unsigned char zT_61;
    zT_8143F551_AstKind zT_63;
    int zT_64;
    unsigned char zT_65;
    zT_8143F551_AstKind zT_67;
    int zT_68;
    unsigned char zT_69;
    zT_8143F551_AstKind zT_71;
    int zT_72;
    unsigned char zT_73;
    zT_8143F551_AstKind zT_75;
    int zT_76;
    unsigned char zT_77;
    zT_8143F551_AstKind zT_79;
    int zT_80;
    unsigned char zT_81;
    zT_8143F551_AstKind zT_83;
    int zT_84;
    unsigned char zT_85;
    zT_8143F551_AstKind zT_87;
    int zT_88;
    unsigned char zT_89;
    zT_8143F551_AstKind zT_91;
    int zT_92;
    unsigned char zT_93;
    zT_8143F551_AstKind zT_95;
    int zT_96;
    unsigned char zT_97;
    zT_8143F551_AstKind zT_99;
    int zT_100;
    unsigned char zT_101;
    zT_8143F551_AstKind zT_103;
    int zT_104;
    unsigned char zT_105;
    zT_8143F551_AstKind zT_107;
    int zT_108;
    unsigned char zT_109;
    zT_8143F551_AstKind zT_111;
    int zT_112;
    unsigned char zT_113;
    zT_8143F551_AstKind zT_115;
    int zT_116;
    unsigned char zT_117;
    zT_8143F551_AstKind zT_119;
    int zT_120;
    unsigned char zT_121;
    zT_8143F551_AstKind zT_123;
    int zT_124;
    unsigned char zT_125;
    zT_8143F551_AstKind zT_127;
    int zT_128;
    unsigned char zT_129;
    zT_8143F551_AstKind zT_131;
    int zT_132;
    unsigned char zT_133;
    zT_8143F551_AstKind zT_135;
    int zT_136;
    unsigned char zT_137;
    zT_8143F551_AstKind zT_139;
    int zT_140;
    unsigned char zT_141;
    zT_8143F551_AstKind zT_143;
    int zT_144;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_147;
    int zT_148;
    unsigned char zT_149;
    zT_8143F551_AstKind zT_151;
    int zT_152;
    unsigned char zT_153;
    zT_8143F551_AstKind zT_155;
    int zT_156;
    unsigned char zT_157;
    zT_8143F551_AstKind zT_159;
    int zT_160;
    unsigned char zT_161;
    zT_8143F551_AstKind zT_163;
    int zT_164;
    unsigned char zT_165;
    zT_8143F551_AstKind zT_167;
    int zT_168;
    unsigned char zT_169;
    zT_8143F551_AstKind zT_171;
    int zT_172;
    unsigned char zT_173;
    zT_8143F551_AstKind zT_175;
    int zT_176;
    unsigned char zT_177;
    zT_8143F551_AstKind zT_179;
    int zT_180;
    unsigned char zT_181;
    zT_8143F551_AstKind zT_183;
    int zT_184;
    unsigned char zT_185;
    zT_8143F551_AstKind zT_187;
    int zT_188;
    unsigned char zT_189;
    int zT_190;
    unsigned char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    zT_B559F9DA_Parser* zT_196;
    zT_3A355BD2_Token zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    zT_DBF3575C_ParserError zT_199;
    zT_3B6EA323_EU_01 zT_200;
    unsigned int zT_202;
    unsigned short zT_203;
    unsigned int zT_205;
    zT_6B0A7D14_AstStore* zT_209;
    zT_8143F551_AstKind zT_210;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    int zT_219;
    int zT_223;
    unsigned int zT_225 = 0;
    zT_3B6EA323_EU_01 zT_226;
    unsigned char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    zT_EAC3E484_TokenKind zT_237;
    int zT_241;
    unsigned char* zT_242;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245 = 0;
    unsigned int zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned char* zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    int zT_270;
    unsigned char* zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274 = 0;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_283;
    unsigned int zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    unsigned char* zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    zT_6B0A7D14_AstStore* zT_291;
    zT_8143F551_AstKind zT_292;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    int zT_301;
    int zT_304;
    int zT_306;
    unsigned int zT_308 = 0;
    zT_3B6EA323_EU_01 zT_309;
    zT_8143F551_AstKind kind;
    unsigned char found;
    zT_8F083A69_Slice_zT_0B42B2F8_u add_msg;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u bok;
    zT_5A26C2ED_Arr_unsigned_char_1 bokb;
    unsigned int bokl;
    unsigned int boks;
    zT_8F083A69_Slice_zT_0B42B2F8_u bokk;
    zT_5A26C2ED_Arr_unsigned_char_1 bokkb;
    unsigned int bokkl;
    unsigned int bokks;
    zT_8F083A69_Slice_zT_0B42B2F8_u boknl;
    kind = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    found = zT_8;
    zT_9 = tok.kind;
switch (zT_9) {
case 20: goto z_bb_1;
case 21: goto z_bb_2;
case 22: goto z_bb_3;
case 23: goto z_bb_4;
case 24: goto z_bb_5;
case 25: goto z_bb_6;
case 26: goto z_bb_7;
case 27: goto z_bb_8;
case 29: goto z_bb_9;
case 30: goto z_bb_10;
case 92: goto z_bb_11;
case 93: goto z_bb_12;
case 31: goto z_bb_13;
case 32: goto z_bb_14;
case 33: goto z_bb_15;
case 34: goto z_bb_16;
case 35: goto z_bb_17;
case 36: goto z_bb_18;
case 37: goto z_bb_19;
case 38: goto z_bb_20;
case 39: goto z_bb_21;
case 40: goto z_bb_22;
case 48: goto z_bb_23;
case 49: goto z_bb_24;
case 50: goto z_bb_25;
case 51: goto z_bb_26;
case 52: goto z_bb_27;
case 53: goto z_bb_28;
case 54: goto z_bb_29;
case 55: goto z_bb_30;
case 56: goto z_bb_31;
case 57: goto z_bb_32;
case 58: goto z_bb_33;
case 59: goto z_bb_34;
case 60: goto z_bb_35;
case 61: goto z_bb_36;
case 41: goto z_bb_37;
case 42: goto z_bb_38;
case 46: goto z_bb_39;
case 47: goto z_bb_40;
case 43: goto z_bb_41;
case 44: goto z_bb_42;
case 45: goto z_bb_43;
case 89: goto z_bb_44;
case 90: goto z_bb_45;
default: goto z_bb_46;
}
    z_bb_1:
    zT_11 = zT_8143F551_AstKind_add;
    kind = zT_11;
    zT_12 = 1;
    zT_13 = (unsigned char)zT_12;
    found = zT_13;
    goto z_bb_48;
    z_bb_2:
    zT_15 = zT_8143F551_AstKind_sub;
    kind = zT_15;
    zT_16 = 1;
    zT_17 = (unsigned char)zT_16;
    found = zT_17;
    goto z_bb_48;
    z_bb_3:
    zT_19 = zT_8143F551_AstKind_mul;
    kind = zT_19;
    zT_20 = 1;
    zT_21 = (unsigned char)zT_20;
    found = zT_21;
    goto z_bb_48;
    z_bb_4:
    zT_23 = zT_8143F551_AstKind_div;
    kind = zT_23;
    zT_24 = 1;
    zT_25 = (unsigned char)zT_24;
    found = zT_25;
    goto z_bb_48;
    z_bb_5:
    zT_27 = zT_8143F551_AstKind_mod_op;
    kind = zT_27;
    zT_28 = 1;
    zT_29 = (unsigned char)zT_28;
    found = zT_29;
    goto z_bb_48;
    z_bb_6:
    zT_31 = zT_8143F551_AstKind_bit_and;
    kind = zT_31;
    zT_32 = 1;
    zT_33 = (unsigned char)zT_32;
    found = zT_33;
    goto z_bb_48;
    z_bb_7:
    zT_35 = zT_8143F551_AstKind_bit_or;
    kind = zT_35;
    zT_36 = 1;
    zT_37 = (unsigned char)zT_36;
    found = zT_37;
    goto z_bb_48;
    z_bb_8:
    zT_39 = zT_8143F551_AstKind_bit_xor;
    kind = zT_39;
    zT_40 = 1;
    zT_41 = (unsigned char)zT_40;
    found = zT_41;
    goto z_bb_48;
    z_bb_9:
    zT_43 = zT_8143F551_AstKind_shl;
    kind = zT_43;
    zT_44 = 1;
    zT_45 = (unsigned char)zT_44;
    found = zT_45;
    goto z_bb_48;
    z_bb_10:
    zT_47 = zT_8143F551_AstKind_shr;
    kind = zT_47;
    zT_48 = 1;
    zT_49 = (unsigned char)zT_48;
    found = zT_49;
    goto z_bb_48;
    z_bb_11:
    zT_51 = zT_8143F551_AstKind_bool_and;
    kind = zT_51;
    zT_52 = 1;
    zT_53 = (unsigned char)zT_52;
    found = zT_53;
    goto z_bb_48;
    z_bb_12:
    zT_55 = zT_8143F551_AstKind_bool_or;
    kind = zT_55;
    zT_56 = 1;
    zT_57 = (unsigned char)zT_56;
    found = zT_57;
    goto z_bb_48;
    z_bb_13:
    zT_59 = zT_8143F551_AstKind_cmp_eq;
    kind = zT_59;
    zT_60 = 1;
    zT_61 = (unsigned char)zT_60;
    found = zT_61;
    goto z_bb_48;
    z_bb_14:
    zT_63 = zT_8143F551_AstKind_cmp_ne;
    kind = zT_63;
    zT_64 = 1;
    zT_65 = (unsigned char)zT_64;
    found = zT_65;
    goto z_bb_48;
    z_bb_15:
    zT_67 = zT_8143F551_AstKind_cmp_lt;
    kind = zT_67;
    zT_68 = 1;
    zT_69 = (unsigned char)zT_68;
    found = zT_69;
    goto z_bb_48;
    z_bb_16:
    zT_71 = zT_8143F551_AstKind_cmp_le;
    kind = zT_71;
    zT_72 = 1;
    zT_73 = (unsigned char)zT_72;
    found = zT_73;
    goto z_bb_48;
    z_bb_17:
    zT_75 = zT_8143F551_AstKind_cmp_gt;
    kind = zT_75;
    zT_76 = 1;
    zT_77 = (unsigned char)zT_76;
    found = zT_77;
    goto z_bb_48;
    z_bb_18:
    zT_79 = zT_8143F551_AstKind_cmp_ge;
    kind = zT_79;
    zT_80 = 1;
    zT_81 = (unsigned char)zT_80;
    found = zT_81;
    goto z_bb_48;
    z_bb_19:
    zT_83 = zT_8143F551_AstKind_plain_assign;
    kind = zT_83;
    zT_84 = 1;
    zT_85 = (unsigned char)zT_84;
    found = zT_85;
    goto z_bb_48;
    z_bb_20:
    zT_87 = zT_8143F551_AstKind_add_assign;
    kind = zT_87;
    zT_88 = 1;
    zT_89 = (unsigned char)zT_88;
    found = zT_89;
    goto z_bb_48;
    z_bb_21:
    zT_91 = zT_8143F551_AstKind_sub_assign;
    kind = zT_91;
    zT_92 = 1;
    zT_93 = (unsigned char)zT_92;
    found = zT_93;
    goto z_bb_48;
    z_bb_22:
    zT_95 = zT_8143F551_AstKind_mul_assign;
    kind = zT_95;
    zT_96 = 1;
    zT_97 = (unsigned char)zT_96;
    found = zT_97;
    goto z_bb_48;
    z_bb_23:
    zT_99 = zT_8143F551_AstKind_wrap_add;
    kind = zT_99;
    zT_100 = 1;
    zT_101 = (unsigned char)zT_100;
    found = zT_101;
    goto z_bb_48;
    z_bb_24:
    zT_103 = zT_8143F551_AstKind_wrap_sub;
    kind = zT_103;
    zT_104 = 1;
    zT_105 = (unsigned char)zT_104;
    found = zT_105;
    goto z_bb_48;
    z_bb_25:
    zT_107 = zT_8143F551_AstKind_wrap_mul;
    kind = zT_107;
    zT_108 = 1;
    zT_109 = (unsigned char)zT_108;
    found = zT_109;
    goto z_bb_48;
    z_bb_26:
    zT_111 = zT_8143F551_AstKind_wrap_add_assign;
    kind = zT_111;
    zT_112 = 1;
    zT_113 = (unsigned char)zT_112;
    found = zT_113;
    goto z_bb_48;
    z_bb_27:
    zT_115 = zT_8143F551_AstKind_wrap_sub_assign;
    kind = zT_115;
    zT_116 = 1;
    zT_117 = (unsigned char)zT_116;
    found = zT_117;
    goto z_bb_48;
    z_bb_28:
    zT_119 = zT_8143F551_AstKind_wrap_mul_assign;
    kind = zT_119;
    zT_120 = 1;
    zT_121 = (unsigned char)zT_120;
    found = zT_121;
    goto z_bb_48;
    z_bb_29:
    zT_123 = zT_8143F551_AstKind_sat_add;
    kind = zT_123;
    zT_124 = 1;
    zT_125 = (unsigned char)zT_124;
    found = zT_125;
    goto z_bb_48;
    z_bb_30:
    zT_127 = zT_8143F551_AstKind_sat_sub;
    kind = zT_127;
    zT_128 = 1;
    zT_129 = (unsigned char)zT_128;
    found = zT_129;
    goto z_bb_48;
    z_bb_31:
    zT_131 = zT_8143F551_AstKind_sat_mul;
    kind = zT_131;
    zT_132 = 1;
    zT_133 = (unsigned char)zT_132;
    found = zT_133;
    goto z_bb_48;
    z_bb_32:
    zT_135 = zT_8143F551_AstKind_sat_shl;
    kind = zT_135;
    zT_136 = 1;
    zT_137 = (unsigned char)zT_136;
    found = zT_137;
    goto z_bb_48;
    z_bb_33:
    zT_139 = zT_8143F551_AstKind_sat_add_assign;
    kind = zT_139;
    zT_140 = 1;
    zT_141 = (unsigned char)zT_140;
    found = zT_141;
    goto z_bb_48;
    z_bb_34:
    zT_143 = zT_8143F551_AstKind_sat_sub_assign;
    kind = zT_143;
    zT_144 = 1;
    zT_145 = (unsigned char)zT_144;
    found = zT_145;
    goto z_bb_48;
    z_bb_35:
    zT_147 = zT_8143F551_AstKind_sat_mul_assign;
    kind = zT_147;
    zT_148 = 1;
    zT_149 = (unsigned char)zT_148;
    found = zT_149;
    goto z_bb_48;
    z_bb_36:
    zT_151 = zT_8143F551_AstKind_sat_shl_assign;
    kind = zT_151;
    zT_152 = 1;
    zT_153 = (unsigned char)zT_152;
    found = zT_153;
    goto z_bb_48;
    z_bb_37:
    zT_155 = zT_8143F551_AstKind_div_assign;
    kind = zT_155;
    zT_156 = 1;
    zT_157 = (unsigned char)zT_156;
    found = zT_157;
    goto z_bb_48;
    z_bb_38:
    zT_159 = zT_8143F551_AstKind_mod_assign;
    kind = zT_159;
    zT_160 = 1;
    zT_161 = (unsigned char)zT_160;
    found = zT_161;
    goto z_bb_48;
    z_bb_39:
    zT_163 = zT_8143F551_AstKind_shl_assign;
    kind = zT_163;
    zT_164 = 1;
    zT_165 = (unsigned char)zT_164;
    found = zT_165;
    goto z_bb_48;
    z_bb_40:
    zT_167 = zT_8143F551_AstKind_shr_assign;
    kind = zT_167;
    zT_168 = 1;
    zT_169 = (unsigned char)zT_168;
    found = zT_169;
    goto z_bb_48;
    z_bb_41:
    zT_171 = zT_8143F551_AstKind_and_assign;
    kind = zT_171;
    zT_172 = 1;
    zT_173 = (unsigned char)zT_172;
    found = zT_173;
    goto z_bb_48;
    z_bb_42:
    zT_175 = zT_8143F551_AstKind_or_assign;
    kind = zT_175;
    zT_176 = 1;
    zT_177 = (unsigned char)zT_176;
    found = zT_177;
    goto z_bb_48;
    z_bb_43:
    zT_179 = zT_8143F551_AstKind_xor_assign;
    kind = zT_179;
    zT_180 = 1;
    zT_181 = (unsigned char)zT_180;
    found = zT_181;
    goto z_bb_48;
    z_bb_44:
    zT_183 = zT_8143F551_AstKind_catch_expr;
    kind = zT_183;
    zT_184 = 1;
    zT_185 = (unsigned char)zT_184;
    found = zT_185;
    goto z_bb_48;
    z_bb_45:
    zT_187 = zT_8143F551_AstKind_orelse_expr;
    kind = zT_187;
    zT_188 = 1;
    zT_189 = (unsigned char)zT_188;
    found = zT_189;
    goto z_bb_48;
    z_bb_46:
    goto z_bb_48;
    z_bb_48:
    zT_190 = 0;
    if ((unsigned char)(found == zT_190)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_193 = "invalid token in expression";
    zT_195 = 27;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    add_msg = zT_194;
    zT_196 = self;
    zT_197 = tok;
    zT_198 = add_msg;
    zF_17DF2CA5_parserAddError(zT_196, zT_197, zT_198);
    zT_199 = 1;
    zT_200.data.err = zT_199;
    zT_200.is_error = 1;
    return zT_200;
    z_bb_50:
    zT_202 = tok.span_start;
    zT_203 = tok.span_len;
    zT_205 = zT_202 + (unsigned int)((unsigned int)zT_203);
    end = zT_205;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_209 = self->store;
    zT_210 = kind;
    zT_219 = 0;
    zT_212 = tok.span_start;
    zT_213 = end;
    zT_214 = lhs;
    zT_215 = rhs;
    zT_216 = self->catch_capture;
    zT_223 = 0;
    zT_225 = zF_6C9FF72F_astStoreAddNode(zT_209, zT_210, (unsigned char)((unsigned char)zT_219), zT_212, zT_213, zT_214, zT_215, zT_216, (unsigned int)((unsigned int)zT_223));
    zT_226.data.payload = zT_225;
    zT_226.is_error = 0;
    return zT_226;
    z_bb_52:
    zT_228 = "BOP:tk";
    zT_230 = 6;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    bok = zT_229;
    zT_231 = bok;
    zF_48AC7B3A_markerWrite(zT_231);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_233[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        bokb[_i] = zT_233[_i];
        _i++;
    }
}
    zT_237 = tok.kind;
    zT_241 = 0;
    zT_242 = (unsigned char*)((unsigned char*)bokb) + zT_241;
    zT_243 = (unsigned int)(10) - zT_241;
    zT_244.ptr = zT_242;
    zT_244.len = zT_243;
    zT_236 = zT_244;
    zT_245 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_237), zT_236);
    bokl = zT_245;
    zT_249 = (unsigned int)(9) - (unsigned int)((unsigned int)bokl);
    boks = zT_249;
    zT_254 = (unsigned char*)((unsigned char*)bokb) + boks;
    zT_255 = (unsigned int)(9) - boks;
    zT_256.ptr = zT_254;
    zT_256.len = zT_255;
    zT_250 = zT_256;
    zF_48AC7B3A_markerWrite(zT_250);
    zT_258 = "ak";
    zT_260 = 2;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    bokk = zT_259;
    zT_261 = bokk;
    zF_48AC7B3A_markerWrite(zT_261);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_263[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        bokkb[_i] = zT_263[_i];
        _i++;
    }
}
    zT_270 = 0;
    zT_271 = (unsigned char*)((unsigned char*)bokkb) + zT_270;
    zT_272 = (unsigned int)(10) - zT_270;
    zT_273.ptr = zT_271;
    zT_273.len = zT_272;
    zT_266 = zT_273;
    zT_274 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_266);
    bokkl = zT_274;
    zT_278 = (unsigned int)(9) - (unsigned int)((unsigned int)bokkl);
    bokks = zT_278;
    zT_283 = (unsigned char*)((unsigned char*)bokkb) + bokks;
    zT_284 = (unsigned int)(9) - bokks;
    zT_285.ptr = zT_283;
    zT_285.len = zT_284;
    zT_279 = zT_285;
    zF_48AC7B3A_markerWrite(zT_279);
    zT_287 = " ";
    zT_289 = 1;
    zT_288.ptr = zT_287;
    zT_288.len = zT_289;
    boknl = zT_288;
    zT_290 = boknl;
    zF_48AC7B3A_markerWrite(zT_290);
    zT_291 = self->store;
    zT_292 = kind;
    zT_301 = 0;
    zT_294 = tok.span_start;
    zT_295 = end;
    zT_296 = lhs;
    zT_297 = rhs;
    zT_304 = 0;
    zT_306 = 0;
    zT_308 = zF_6C9FF72F_astStoreAddNode(zT_291, zT_292, (unsigned char)((unsigned char)zT_301), zT_294, zT_295, zT_296, zT_297, (unsigned int)((unsigned int)zT_304), (unsigned int)((unsigned int)zT_306));
    zT_309.data.payload = zT_308;
    zT_309.is_error = 0;
    return zT_309;
}

/* parserParsePrimary */
zT_3B6EA323_EU_01 zF_565DCE21_parserParsePrimary(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_27 = {0};
    zT_EAC3E484_TokenKind zT_28;
    zT_B559F9DA_Parser* zT_32;
    zT_3B6EA323_EU_01 zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    zT_3B6EA323_EU_01 zT_39 = {0};
    zT_EAC3E484_TokenKind zT_40;
    zT_B559F9DA_Parser* zT_44;
    zT_3B6EA323_EU_01 zT_48 = {0};
    zT_EAC3E484_TokenKind zT_49;
    zT_B559F9DA_Parser* zT_53;
    zT_3B6EA323_EU_01 zT_57 = {0};
    zT_EAC3E484_TokenKind zT_58;
    zT_B559F9DA_Parser* zT_62;
    zT_3B6EA323_EU_01 zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    zT_EAC3E484_TokenKind zT_73;
    zT_B559F9DA_Parser* zT_77;
    int zT_79;
    zT_3A355BD2_Token zT_81 = {0};
    zT_EAC3E484_TokenKind zT_82;
    unsigned char zT_86;
    zT_B559F9DA_Parser* zT_87;
    int zT_89;
    zT_3A355BD2_Token zT_91 = {0};
    zT_EAC3E484_TokenKind zT_92;
    zT_B559F9DA_Parser* zT_96;
    zT_3B6EA323_EU_01 zT_97 = {0};
    zT_B559F9DA_Parser* zT_98;
    int zT_100;
    zT_3A355BD2_Token zT_102 = {0};
    zT_EAC3E484_TokenKind zT_103;
    zT_B559F9DA_Parser* zT_108;
    zT_3B6EA323_EU_01 zT_109 = {0};
    unsigned char zT_110;
    unsigned int zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_3A355BD2_Token zT_113 = {0};
    zT_B559F9DA_Parser* zT_115;
    zT_3B6EA323_EU_01 zT_116 = {0};
    unsigned char zT_117;
    unsigned int zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    int zT_131;
    unsigned int zT_134;
    unsigned short zT_135;
    int zT_138;
    int zT_140;
    unsigned int zT_142 = 0;
    zT_3B6EA323_EU_01 zT_143;
    zT_B559F9DA_Parser* zT_144;
    zT_3B6EA323_EU_01 zT_145 = {0};
    zT_EAC3E484_TokenKind zT_146;
    zT_B559F9DA_Parser* zT_150;
    zT_3B6EA323_EU_01 zT_151 = {0};
    zT_EAC3E484_TokenKind zT_152;
    zT_B559F9DA_Parser* zT_156;
    zT_3B6EA323_EU_01 zT_157 = {0};
    zT_EAC3E484_TokenKind zT_158;
    zT_B559F9DA_Parser* zT_162;
    zT_3B6EA323_EU_01 zT_163 = {0};
    zT_EAC3E484_TokenKind zT_164;
    zT_B559F9DA_Parser* zT_168;
    zT_3B6EA323_EU_01 zT_169 = {0};
    zT_EAC3E484_TokenKind zT_170;
    zT_B559F9DA_Parser* zT_174;
    zT_3B6EA323_EU_01 zT_175 = {0};
    zT_EAC3E484_TokenKind zT_176;
    zT_B559F9DA_Parser* zT_180;
    zT_3B6EA323_EU_01 zT_181 = {0};
    zT_EAC3E484_TokenKind zT_182;
    zT_B559F9DA_Parser* zT_186;
    zT_3B6EA323_EU_01 zT_190 = {0};
    zT_EAC3E484_TokenKind zT_191;
    zT_B559F9DA_Parser* zT_195;
    zT_3B6EA323_EU_01 zT_199 = {0};
    zT_EAC3E484_TokenKind zT_200;
    zT_B559F9DA_Parser* zT_204;
    zT_3B6EA323_EU_01 zT_208 = {0};
    zT_EAC3E484_TokenKind zT_209;
    zT_B559F9DA_Parser* zT_213;
    zT_3B6EA323_EU_01 zT_217 = {0};
    zT_EAC3E484_TokenKind zT_218;
    zT_B559F9DA_Parser* zT_222;
    zT_3B6EA323_EU_01 zT_226 = {0};
    zT_EAC3E484_TokenKind zT_227;
    zT_B559F9DA_Parser* zT_231;
    zT_3B6EA323_EU_01 zT_232 = {0};
    zT_EAC3E484_TokenKind zT_233;
    zT_B559F9DA_Parser* zT_237;
    zT_3B6EA323_EU_01 zT_238 = {0};
    zT_EAC3E484_TokenKind zT_239;
    zT_B559F9DA_Parser* zT_243;
    zT_3B6EA323_EU_01 zT_244 = {0};
    zT_EAC3E484_TokenKind zT_245;
    zT_B559F9DA_Parser* zT_249;
    zT_3B6EA323_EU_01 zT_250 = {0};
    zT_EAC3E484_TokenKind zT_251;
    zT_B559F9DA_Parser* zT_255;
    zT_3B6EA323_EU_01 zT_256 = {0};
    zT_EAC3E484_TokenKind zT_257;
    zT_B559F9DA_Parser* zT_261;
    zT_3B6EA323_EU_01 zT_262 = {0};
    zT_EAC3E484_TokenKind zT_263;
    zT_B559F9DA_Parser* zT_267;
    zT_3B6EA323_EU_01 zT_268 = {0};
    zT_EAC3E484_TokenKind zT_269;
    zT_B559F9DA_Parser* zT_273;
    zT_3B6EA323_EU_01 zT_274 = {0};
    zT_EAC3E484_TokenKind zT_275;
    zT_B559F9DA_Parser* zT_279;
    zT_3B6EA323_EU_01 zT_280 = {0};
    zT_EAC3E484_TokenKind zT_281;
    zT_B559F9DA_Parser* zT_285;
    zT_3B6EA323_EU_01 zT_286 = {0};
    zT_EAC3E484_TokenKind zT_287;
    zT_B559F9DA_Parser* zT_291;
    unsigned char zT_292;
    unsigned int zT_293;
    zT_3B6EA323_EU_01 zT_294 = {0};
    zT_EAC3E484_TokenKind zT_295;
    zT_B559F9DA_Parser* zT_299;
    int zT_301;
    zT_3B6EA323_EU_01 zT_303 = {0};
    zT_EAC3E484_TokenKind zT_304;
    zT_B559F9DA_Parser* zT_308;
    zT_3B6EA323_EU_01 zT_309 = {0};
    zT_EAC3E484_TokenKind zT_310;
    zT_B559F9DA_Parser* zT_314;
    int zT_316;
    zT_3B6EA323_EU_01 zT_318 = {0};
    zT_EAC3E484_TokenKind zT_319;
    zT_B559F9DA_Parser* zT_323;
    zT_3A355BD2_Token zT_324 = {0};
    zT_B559F9DA_Parser* zT_326;
    zT_3A355BD2_Token zT_327 = {0};
    zT_EAC3E484_TokenKind zT_328;
    zT_B559F9DA_Parser* zT_332;
    int zT_334;
    zT_3B6EA323_EU_01 zT_336 = {0};
    zT_EAC3E484_TokenKind zT_337;
    zT_B559F9DA_Parser* zT_341;
    int zT_343;
    zT_3B6EA323_EU_01 zT_345 = {0};
    unsigned char* zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned int zT_349;
    zT_B559F9DA_Parser* zT_350;
    zT_3A355BD2_Token zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    zT_DBF3575C_ParserError zT_353;
    zT_3B6EA323_EU_01 zT_354;
    zT_EAC3E484_TokenKind zT_355;
    zT_B559F9DA_Parser* zT_359;
    zT_3B6EA323_EU_01 zT_360 = {0};
    zT_EAC3E484_TokenKind zT_361;
    zT_B559F9DA_Parser* zT_365;
    zT_3B6EA323_EU_01 zT_366 = {0};
    zT_EAC3E484_TokenKind zT_367;
    zT_B559F9DA_Parser* zT_371;
    zT_3B6EA323_EU_01 zT_372 = {0};
    zT_EAC3E484_TokenKind zT_373;
    zT_B559F9DA_Parser* zT_377;
    zT_3B6EA323_EU_01 zT_378 = {0};
    unsigned char* zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned int zT_382;
    zT_B559F9DA_Parser* zT_383;
    zT_3A355BD2_Token zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    zT_DBF3575C_ParserError zT_386;
    zT_3B6EA323_EU_01 zT_387;
    zT_3A355BD2_Token tok;
    unsigned int eu_base;
    unsigned int eu_payload;
    zT_3A355BD2_Token ntok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u primary_msg;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_4D06854D_parserParseIntLiter(zT_8);
    return zT_9;
    z_bb_2:
    zT_10 = tok.kind;
    if ((unsigned char)(zT_10 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zT_15 = zF_FB72DD9C_parserParseFloatLit(zT_14);
    return zT_15;
    z_bb_4:
    zT_16 = tok.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = self;
    zT_21 = zF_397D4BBF_parserParseStringLi(zT_20);
    return zT_21;
    z_bb_6:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self;
    zT_27 = zF_F509A7F4_parserParseCharLite(zT_26);
    return zT_27;
    z_bb_8:
    zT_28 = tok.kind;
    if ((unsigned char)(zT_28 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self;
    zT_33 = zF_0E221A14_parserParseBoolLite(zT_32);
    return zT_33;
    z_bb_10:
    zT_34 = tok.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_false))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = self;
    zT_39 = zF_0E221A14_parserParseBoolLite(zT_38);
    return zT_39;
    z_bb_12:
    zT_40 = tok.kind;
    if ((unsigned char)(zT_40 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_null))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_44 = self;
    zT_48 = zF_A18ECFB6_parserParseSingleTo(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal));
    return zT_48;
    z_bb_14:
    zT_49 = tok.kind;
    if ((unsigned char)(zT_49 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_undefined))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = self;
    zT_57 = zF_A18ECFB6_parserParseSingleTo(zT_53, (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal));
    return zT_57;
    z_bb_16:
    zT_58 = tok.kind;
    if ((unsigned char)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_unreachable))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_62 = self;
    zT_66 = zF_A18ECFB6_parserParseSingleTo(zT_62, (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr));
    return zT_66;
    z_bb_18:
    zT_67 = tok.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_71 = self;
    zT_72 = zF_F5EAD186_parserParseIdentExp(zT_71);
    return zT_72;
    z_bb_20:
    zT_73 = tok.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_77 = self;
    zT_79 = 1;
    zT_81 = zF_F685E431_parserPeekN(zT_77, (unsigned int)((unsigned int)zT_79));
    zT_82 = zT_81.kind;
    if ((unsigned char)(zT_82 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_146 = tok.kind;
    if ((unsigned char)(zT_146 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_bool))) goto z_bb_36; else goto z_bb_37;
    z_bb_23:
    zT_87 = self;
    zT_89 = 2;
    zT_91 = zF_F685E431_parserPeekN(zT_87, (unsigned int)((unsigned int)zT_89));
    zT_92 = zT_91.kind;
    zT_86 = zT_92 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_25;
    z_bb_24:
    zT_86 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_86) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_96 = self;
    zT_97 = zF_532B277E_parserParseLabeledB(zT_96);
    return zT_97;
    z_bb_27:
    zT_98 = self;
    zT_100 = 1;
    zT_102 = zF_F685E431_parserPeekN(zT_98, (unsigned int)((unsigned int)zT_100));
    zT_103 = zT_102.kind;
    if ((unsigned char)(zT_103 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_108 = self;
    zT_109 = zF_F5EAD186_parserParseIdentExp(zT_108);
    zT_110 = zT_109.is_error;
    if (zT_110) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_144 = self;
    zT_145 = zF_F5EAD186_parserParseIdentExp(zT_144);
    return zT_145;
    z_bb_30:
    return zT_109;
    z_bb_31:
    zT_111 = zT_109.data.payload;
    goto z_bb_32;
    z_bb_32:
    eu_base = zT_111;
    zT_112 = self;
    zT_113 = zF_C241B2C4_parserAdvance(zT_112);
    (void)zT_113;
    zT_115 = self;
    zT_116 = zF_CBDBFE85_parserParseType(zT_115);
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return zT_116;
    z_bb_34:
    zT_118 = zT_116.data.payload;
    goto z_bb_35;
    z_bb_35:
    eu_payload = zT_118;
    zT_119 = self->store;
    zT_131 = 0;
    zT_122 = tok.span_start;
    zT_134 = tok.span_start;
    zT_135 = tok.span_len;
    zT_124 = eu_base;
    zT_125 = eu_payload;
    zT_138 = 0;
    zT_140 = 0;
    zT_142 = zF_6C9FF72F_astStoreAddNode(zT_119, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_131), zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124, zT_125, (unsigned int)((unsigned int)zT_138), (unsigned int)((unsigned int)zT_140));
    zT_143.data.payload = zT_142;
    zT_143.is_error = 0;
    return zT_143;
    z_bb_36:
    zT_150 = self;
    zT_151 = zF_F5EAD186_parserParseIdentExp(zT_150);
    return zT_151;
    z_bb_37:
    zT_152 = tok.kind;
    if ((unsigned char)(zT_152 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_c_char))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_156 = self;
    zT_157 = zF_F5EAD186_parserParseIdentExp(zT_156);
    return zT_157;
    z_bb_39:
    zT_158 = tok.kind;
    if ((unsigned char)(zT_158 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_void))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_162 = self;
    zT_163 = zF_F5EAD186_parserParseIdentExp(zT_162);
    return zT_163;
    z_bb_41:
    zT_164 = tok.kind;
    if ((unsigned char)(zT_164 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_168 = self;
    zT_169 = zF_5D650338_parserParseBuiltinC(zT_168);
    return zT_169;
    z_bb_43:
    zT_170 = tok.kind;
    if ((unsigned char)(zT_170 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_174 = self;
    zT_175 = zF_C531682A_parserParseCInclude(zT_174);
    return zT_175;
    z_bb_45:
    zT_176 = tok.kind;
    if ((unsigned char)(zT_176 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_180 = self;
    zT_181 = zF_AC24A2A0_parserParseErrorLit(zT_180);
    return zT_181;
    z_bb_47:
    zT_182 = tok.kind;
    if ((unsigned char)(zT_182 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_186 = self;
    zT_190 = zF_BE192524_parserParsePrefixUn(zT_186, (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate));
    return zT_190;
    z_bb_49:
    zT_191 = tok.kind;
    if ((unsigned char)(zT_191 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_195 = self;
    zT_199 = zF_BE192524_parserParsePrefixUn(zT_195, (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate));
    return zT_199;
    z_bb_51:
    zT_200 = tok.kind;
    if ((unsigned char)(zT_200 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_204 = self;
    zT_208 = zF_BE192524_parserParsePrefixUn(zT_204, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not));
    return zT_208;
    z_bb_53:
    zT_209 = tok.kind;
    if ((unsigned char)(zT_209 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_213 = self;
    zT_217 = zF_BE192524_parserParsePrefixUn(zT_213, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not));
    return zT_217;
    z_bb_55:
    zT_218 = tok.kind;
    if ((unsigned char)(zT_218 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_222 = self;
    zT_226 = zF_BE192524_parserParsePrefixUn(zT_222, (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of));
    return zT_226;
    z_bb_57:
    zT_227 = tok.kind;
    if ((unsigned char)(zT_227 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_try))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_231 = self;
    zT_232 = zF_59C88921_parserParseTryExpr(zT_231);
    return zT_232;
    z_bb_59:
    zT_233 = tok.kind;
    if ((unsigned char)(zT_233 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_237 = self;
    zT_238 = zF_C5DF83EE_parserParseGroupedE(zT_237);
    return zT_238;
    z_bb_61:
    zT_239 = tok.kind;
    if ((unsigned char)(zT_239 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_243 = self;
    zT_244 = zF_9A508F9D_parserParseAnonymou(zT_243);
    return zT_244;
    z_bb_63:
    zT_245 = tok.kind;
    if ((unsigned char)(zT_245 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_249 = self;
    zT_250 = zF_BD525F87_parserParseEnumLite(zT_249);
    return zT_250;
    z_bb_65:
    zT_251 = tok.kind;
    if ((unsigned char)(zT_251 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_255 = self;
    zT_256 = zF_79089D39_parserParseIfExpr(zT_255);
    return zT_256;
    z_bb_67:
    zT_257 = tok.kind;
    if ((unsigned char)(zT_257 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_261 = self;
    zT_262 = zF_A9AC92CA_parserParseSwitchEx(zT_261);
    return zT_262;
    z_bb_69:
    zT_263 = tok.kind;
    if ((unsigned char)(zT_263 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_267 = self;
    zT_268 = zF_DE101A45_parserParseArrayLit(zT_267);
    return zT_268;
    z_bb_71:
    zT_269 = tok.kind;
    if ((unsigned char)(zT_269 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_273 = self;
    zT_274 = zF_08083D09_parserParsePtrType(zT_273);
    return zT_274;
    z_bb_73:
    zT_275 = tok.kind;
    if ((unsigned char)(zT_275 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_279 = self;
    zT_280 = zF_F9036399_parserParseOptional(zT_279);
    return zT_280;
    z_bb_75:
    zT_281 = tok.kind;
    if ((unsigned char)(zT_281 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_285 = self;
    zT_286 = zF_B83061B7_parserParseExternFn(zT_285);
    return zT_286;
    z_bb_77:
    zT_287 = tok.kind;
    if ((unsigned char)(zT_287 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_291 = self;
    zT_293 = 0;
    zT_292 = zT_293;
    zT_294 = zF_B5C9B665_parserParseFnType(zT_291, zT_292);
    return zT_294;
    z_bb_79:
    zT_295 = tok.kind;
    if ((unsigned char)(zT_295 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_299 = self;
    zT_301 = 0;
    zT_303 = zF_3530D6C0_parserParseStructTy(zT_299, (unsigned char)((unsigned char)zT_301));
    return zT_303;
    z_bb_81:
    zT_304 = tok.kind;
    if ((unsigned char)(zT_304 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_308 = self;
    zT_309 = zF_63EC2480_parserParseEnumType(zT_308);
    return zT_309;
    z_bb_83:
    zT_310 = tok.kind;
    if ((unsigned char)(zT_310 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_314 = self;
    zT_316 = 0;
    zT_318 = zF_0881F8E4_parserParseUnionTyp(zT_314, (unsigned char)((unsigned char)zT_316));
    return zT_318;
    z_bb_85:
    zT_319 = tok.kind;
    if ((unsigned char)(zT_319 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_packed))) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_323 = self;
    zT_324 = zF_C241B2C4_parserAdvance(zT_323);
    (void)zT_324;
    zT_326 = self;
    zT_327 = zF_068A2DE5_parserPeek(zT_326);
    ntok = zT_327;
    zT_328 = ntok.kind;
    if ((unsigned char)(zT_328 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    zT_355 = tok.kind;
    if ((unsigned char)(zT_355 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_92; else goto z_bb_93;
    z_bb_88:
    zT_332 = self;
    zT_334 = 1;
    zT_336 = zF_3530D6C0_parserParseStructTy(zT_332, (unsigned char)((unsigned char)zT_334));
    return zT_336;
    z_bb_89:
    zT_337 = ntok.kind;
    if ((unsigned char)(zT_337 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_341 = self;
    zT_343 = 1;
    zT_345 = zF_0881F8E4_parserParseUnionTyp(zT_341, (unsigned char)((unsigned char)zT_343));
    return zT_345;
    z_bb_91:
    zT_347 = "expected 'struct' or 'union' after 'packed'";
    zT_349 = 43;
    zT_348.ptr = zT_347;
    zT_348.len = zT_349;
    pmsg = zT_348;
    zT_350 = self;
    zT_351 = ntok;
    zT_352 = pmsg;
    zF_17DF2CA5_parserAddError(zT_350, zT_351, zT_352);
    zT_353 = 1;
    zT_354.data.err = zT_353;
    zT_354.is_error = 1;
    return zT_354;
    z_bb_92:
    zT_359 = self;
    zT_360 = zF_224C1394_parserParseReturnEx(zT_359);
    return zT_360;
    z_bb_93:
    zT_361 = tok.kind;
    if ((unsigned char)(zT_361 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_365 = self;
    zT_366 = zF_C69B6287_parserParseBreakExp(zT_365);
    return zT_366;
    z_bb_95:
    zT_367 = tok.kind;
    if ((unsigned char)(zT_367 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_371 = self;
    zT_372 = zF_73B42F4B_parserParseContinue(zT_371);
    return zT_372;
    z_bb_97:
    zT_373 = tok.kind;
    if ((unsigned char)(zT_373 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_377 = self;
    zT_378 = zF_365CA04A_parserParseBlock(zT_377);
    return zT_378;
    z_bb_99:
    zT_380 = "expected expression";
    zT_382 = 19;
    zT_381.ptr = zT_380;
    zT_381.len = zT_382;
    primary_msg = zT_381;
    zT_383 = self;
    zT_384 = tok;
    zT_385 = primary_msg;
    zF_17DF2CA5_parserAddError(zT_383, zT_384, zT_385);
    zT_386 = 1;
    zT_387.data.err = zT_386;
    zT_387.is_error = 1;
    return zT_387;
}

/* parserParsePostfixChain */
zT_3B6EA323_EU_01 zF_77AD89E7_parserParsePostfixC(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_16;
    unsigned int zT_18;
    int zT_25;
    unsigned int zT_28;
    unsigned short zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_EAC3E484_TokenKind zT_39;
    zT_B559F9DA_Parser* zT_43;
    unsigned int zT_44;
    zT_3B6EA323_EU_01 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_47;
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_52;
    unsigned int zT_53;
    zT_3B6EA323_EU_01 zT_54 = {0};
    unsigned char zT_55;
    unsigned int zT_56;
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_61;
    unsigned int zT_62;
    zT_3B6EA323_EU_01 zT_63 = {0};
    unsigned char zT_64;
    unsigned int zT_65;
    zT_EAC3E484_TokenKind zT_66;
    zT_B559F9DA_Parser* zT_70;
    unsigned int zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_74;
    zT_3B6EA323_EU_01 zT_75;
    unsigned int node;
    zT_3A355BD2_Token tok;
    node = base;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_75.data.payload = node;
    zT_75.is_error = 0;
    return zT_75;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_13 = self->store;
    zT_25 = 0;
    zT_16 = tok.span_start;
    zT_28 = tok.span_start;
    zT_29 = tok.span_len;
    zT_18 = node;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_25), zT_16, (unsigned int)(zT_28 + (unsigned int)((unsigned int)zT_29)), zT_18, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    node = zT_38;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_39 = tok.kind;
    if ((unsigned char)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_43 = self;
    zT_44 = node;
    zT_45 = zF_86B17ABA_parserParseDotAcces(zT_43, zT_44);
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_48 = tok.kind;
    if ((unsigned char)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_14; else goto z_bb_16;
    z_bb_11:
    return zT_45;
    z_bb_12:
    zT_47 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    node = zT_47;
    goto z_bb_9;
    z_bb_14:
    zT_52 = self;
    zT_53 = node;
    zT_54 = zF_8B5A7E08_parserParseIndexOrS(zT_52, zT_53);
    zT_55 = zT_54.is_error;
    if (zT_55) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_57 = tok.kind;
    if ((unsigned char)(zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_20; else goto z_bb_22;
    z_bb_17:
    return zT_54;
    z_bb_18:
    zT_56 = zT_54.data.payload;
    goto z_bb_19;
    z_bb_19:
    node = zT_56;
    goto z_bb_15;
    z_bb_20:
    zT_61 = self;
    zT_62 = node;
    zT_63 = zF_3FC58691_parserParseFnCall(zT_61, zT_62);
    zT_64 = zT_63.is_error;
    if (zT_64) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_66 = tok.kind;
    if ((unsigned char)(zT_66 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_28;
    z_bb_23:
    return zT_63;
    z_bb_24:
    zT_65 = zT_63.data.payload;
    goto z_bb_25;
    z_bb_25:
    node = zT_65;
    goto z_bb_21;
    z_bb_26:
    zT_70 = self;
    zT_71 = node;
    zT_72 = zF_EFD340BA_parserParseStructIn(zT_70, zT_71);
    zT_73 = zT_72.is_error;
    if (zT_73) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_21;
    z_bb_28:
    goto z_bb_3;
    z_bb_29:
    return zT_72;
    z_bb_30:
    zT_74 = zT_72.data.payload;
    goto z_bb_31;
    z_bb_31:
    node = zT_74;
    goto z_bb_27;
}

/* parserParseDotAccess */
zT_3B6EA323_EU_01 zF_86B17ABA_parserParseDotAcces(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_18;
    unsigned int zT_20;
    int zT_27;
    unsigned int zT_30;
    unsigned short zT_31;
    int zT_34;
    int zT_36;
    int zT_38;
    unsigned int zT_40 = 0;
    zT_3B6EA323_EU_01 zT_41;
    zT_85CBA4DB_TokenValue zT_43;
    unsigned int zT_44;
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_55;
    int zT_59;
    unsigned int zT_62;
    unsigned short zT_63;
    int zT_66;
    int zT_68;
    unsigned int zT_70 = 0;
    zT_3B6EA323_EU_01 zT_71;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)((unsigned int)((unsigned int)zT_7) == (unsigned int)((unsigned int)(zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_15 = self->store;
    zT_27 = 0;
    zT_18 = tok.span_start;
    zT_30 = tok.span_start;
    zT_31 = tok.span_len;
    zT_20 = base;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = zF_6C9FF72F_astStoreAddNode(zT_15, (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref), (unsigned char)((unsigned char)zT_27), zT_18, (unsigned int)(zT_30 + (unsigned int)((unsigned int)zT_31)), zT_20, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38));
    zT_41.data.payload = zT_40;
    zT_41.is_error = 0;
    return zT_41;
    z_bb_2:
    zT_43 = tok.value;
    zT_44 = zT_43.string_id;
    name_id = zT_44;
    zT_45 = self;
    zT_46 = zF_C241B2C4_parserAdvance(zT_45);
    (void)zT_46;
    zT_47 = self->store;
    zT_59 = 0;
    zT_50 = tok.span_start;
    zT_62 = tok.span_start;
    zT_63 = tok.span_len;
    zT_52 = base;
    zT_66 = 0;
    zT_68 = 0;
    zT_55 = name_id;
    zT_70 = zF_6C9FF72F_astStoreAddNode(zT_47, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_59), zT_50, (unsigned int)(zT_62 + (unsigned int)((unsigned int)zT_63)), zT_52, (unsigned int)((unsigned int)zT_66), (unsigned int)((unsigned int)zT_68), zT_55);
    zT_71.data.payload = zT_70;
    zT_71.is_error = 0;
    return zT_71;
}

/* parserParseIndexOrSlice */
zT_3B6EA323_EU_01 zF_8B5A7E08_parserParseIndexOrS(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_EAC3E484_TokenKind zT_14;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    int zT_21;
    unsigned int zT_22;
    zT_B559F9DA_Parser* zT_23;
    zT_3A355BD2_Token zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    zT_B559F9DA_Parser* zT_29;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_56;
    unsigned int zT_59;
    unsigned short zT_60;
    int zT_63;
    unsigned int zT_65 = 0;
    zT_3B6EA323_EU_01 zT_66;
    zT_B559F9DA_Parser* zT_67;
    zT_CB78802F_EU_49 zT_71 = {0};
    unsigned char zT_72;
    int zT_73;
    zT_3B6EA323_EU_01 zT_74;
    zT_2B3424E9_ParseToken zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_79;
    unsigned int zT_81;
    unsigned int zT_82;
    int zT_88;
    unsigned int zT_91;
    unsigned short zT_92;
    int zT_95;
    int zT_97;
    unsigned int zT_99 = 0;
    zT_3B6EA323_EU_01 zT_100;
    unsigned int first;
    zT_3A355BD2_Token tok;
    unsigned int last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    first = zT_10;
    zT_12 = self;
    zT_13 = zF_068A2DE5_parserPeek(zT_12);
    tok = zT_13;
    zT_14 = tok.kind;
    if ((unsigned char)(zT_14 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = self;
    zT_19 = zF_C241B2C4_parserAdvance(zT_18);
    (void)zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    last = zT_22;
    zT_23 = self;
    zT_24 = zF_068A2DE5_parserPeek(zT_23);
    zT_25 = zT_24.kind;
    if ((unsigned char)(zT_25 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_67 = self;
    zT_71 = zF_5578C74F_parserExpect(zT_67, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_72 = zT_71.is_error;
    if (zT_72) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_29 = self;
    zT_32 = zF_F07C1F04_parserParseExprPrec(zT_29, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return zT_32;
    z_bb_10:
    zT_34 = zT_32.data.payload;
    goto z_bb_11;
    z_bb_11:
    last = zT_34;
    goto z_bb_7;
    z_bb_12:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_13:
    zT_43 = zT_39.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_43;
    zT_44 = self->store;
    zT_56 = 0;
    zT_47 = tok.span_start;
    zT_59 = tok.span_start;
    zT_60 = tok.span_len;
    zT_49 = base;
    zT_50 = first;
    zT_51 = last;
    zT_63 = 0;
    zT_65 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr), (unsigned char)((unsigned char)zT_56), zT_47, (unsigned int)(zT_59 + (unsigned int)((unsigned int)zT_60)), zT_49, zT_50, zT_51, (unsigned int)((unsigned int)zT_63));
    zT_66.data.payload = zT_65;
    zT_66.is_error = 0;
    return zT_66;
    z_bb_15:
    zT_73 = zT_71.data.err;
    zT_74.data.err = zT_73;
    zT_74.is_error = 1;
    return zT_74;
    z_bb_16:
    zT_75 = zT_71.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_75;
    zT_76 = self->store;
    zT_88 = 0;
    zT_79 = tok.span_start;
    zT_91 = tok.span_start;
    zT_92 = tok.span_len;
    zT_81 = base;
    zT_82 = first;
    zT_95 = 0;
    zT_97 = 0;
    zT_99 = zF_6C9FF72F_astStoreAddNode(zT_76, (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access), (unsigned char)((unsigned char)zT_88), zT_79, (unsigned int)(zT_91 + (unsigned int)((unsigned int)zT_92)), zT_81, zT_82, (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97));
    zT_100.data.payload = zT_99;
    zT_100.is_error = 0;
    return zT_100;
}

/* parserParseFnCall */
zT_3B6EA323_EU_01 zF_3FC58691_parserParseFnCall(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_31;
    int zT_34;
    int zT_36;
    int zT_38;
    unsigned int zT_40 = 0;
    zT_3B6EA323_EU_01 zT_41;
    unsigned int zT_43;
    zT_B559F9DA_Parser* zT_46;
    zT_3B6EA323_EU_01 zT_49 = {0};
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int** zT_52;
    unsigned int* zT_53;
    unsigned int* zT_54;
    zT_3E40CD83_Sand* zT_55;
    unsigned int zT_56;
    zT_B559F9DA_Parser* zT_61;
    zT_3A355BD2_Token zT_62 = {0};
    zT_EAC3E484_TokenKind zT_63;
    zT_B559F9DA_Parser* zT_67;
    zT_CB78802F_EU_49 zT_71 = {0};
    unsigned char zT_72;
    int zT_73;
    zT_3B6EA323_EU_01 zT_74;
    zT_2B3424E9_ParseToken zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_83;
    zT_CB78802F_EU_49 zT_87 = {0};
    unsigned char zT_88;
    int zT_89;
    zT_3B6EA323_EU_01 zT_90;
    zT_2B3424E9_ParseToken zT_91;
    unsigned int zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_102;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_103;
    unsigned int* zT_105;
    unsigned int zT_106;
    unsigned int* zT_107;
    unsigned int zT_108;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_109;
    unsigned int zT_110 = 0;
    zT_6B0A7D14_AstStore* zT_111;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_119;
    int zT_123;
    int zT_126;
    int zT_128;
    unsigned int zT_130 = 0;
    zT_3B6EA323_EU_01 zT_131;
    zT_3A355BD2_Token lparen;
    zT_3A355BD2_Token rparen;
    unsigned int end;
    unsigned int saved_fncall;
    unsigned int arg;
    zT_2B3424E9_ParseToken rparen_1;
    unsigned int payload;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lparen = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    rparen = zT_13;
    zT_15 = rparen.span_start;
    zT_16 = rparen.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end = zT_18;
    zT_19 = self->store;
    zT_31 = 0;
    zT_22 = lparen.span_start;
    zT_23 = end;
    zT_24 = base;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = 0;
    zT_40 = zF_6C9FF72F_astStoreAddNode(zT_19, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_31), zT_22, zT_23, zT_24, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36), (unsigned int)((unsigned int)zT_38));
    zT_41.data.payload = zT_40;
    zT_41.is_error = 0;
    return zT_41;
    z_bb_2:
    zT_43 = self->child_buf_len;
    saved_fncall = zT_43;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(1)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_46 = self;
    zT_49 = zF_F07C1F04_parserParseExprPrec(zT_46, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_83 = self;
    zT_87 = zF_5578C74F_parserExpect(zT_83, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_88 = zT_87.is_error;
    if (zT_88) goto z_bb_17; else goto z_bb_18;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return zT_49;
    z_bb_8:
    zT_51 = zT_49.data.payload;
    goto z_bb_9;
    z_bb_9:
    arg = zT_51;
    zT_52 = &self->child_buf_items;
    zT_53 = &self->child_buf_len;
    zT_54 = &self->child_buf_capacity;
    zT_55 = self->allocator;
    zT_56 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_52, zT_53, zT_54, zT_55, zT_56);
    zT_61 = self;
    zT_62 = zF_068A2DE5_parserPeek(zT_61);
    zT_63 = zT_62.kind;
    if ((unsigned char)(zT_63 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    zT_67 = self;
    zT_71 = zF_5578C74F_parserExpect(zT_67, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_72 = zT_71.is_error;
    if (zT_72) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_73 = zT_71.data.err;
    zT_74.data.err = zT_73;
    zT_74.is_error = 1;
    return zT_74;
    z_bb_13:
    zT_75 = zT_71.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_75;
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_5;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_89 = zT_87.data.err;
    zT_90.data.err = zT_89;
    zT_90.is_error = 1;
    return zT_90;
    z_bb_18:
    zT_91 = zT_87.data.payload;
    goto z_bb_19;
    z_bb_19:
    rparen_1 = zT_91;
    zT_93 = rparen_1.span_start;
    zT_94 = rparen_1.span_len;
    zT_96 = zT_93 + (unsigned int)((unsigned int)zT_94);
    end = zT_96;
    zT_98 = 0;
    zT_99 = (unsigned int)zT_98;
    payload = zT_99;
    zT_100 = self->child_buf_len;
    if ((unsigned char)(zT_100 > saved_fncall)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_102 = self->store;
    zT_105 = self->child_buf_items;
    zT_106 = self->child_buf_len;
    zT_107 = zT_105 + saved_fncall;
    zT_108 = zT_106 - saved_fncall;
    zT_109.ptr = zT_107;
    zT_109.len = zT_108;
    zT_103 = zT_109;
    zT_110 = zF_583E993C_astStoreAddExtraChi(zT_102, zT_103);
    payload = zT_110;
    goto z_bb_21;
    z_bb_21:
    self->child_buf_len = saved_fncall;
    zT_111 = self->store;
    zT_123 = 0;
    zT_114 = lparen.span_start;
    zT_115 = end;
    zT_116 = base;
    zT_126 = 0;
    zT_128 = 0;
    zT_119 = payload;
    zT_130 = zF_6C9FF72F_astStoreAddNode(zT_111, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call), (unsigned char)((unsigned char)zT_123), zT_114, zT_115, zT_116, (unsigned int)((unsigned int)zT_126), (unsigned int)((unsigned int)zT_128), zT_119);
    zT_131.data.payload = zT_130;
    zT_131.is_error = 0;
    return zT_131;
}

/* parserParseCatchRHS */
zT_3B6EA323_EU_01 zF_95DDA8C7_parserParseCatchRHS(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min, unsigned int* capture_out) {
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_B559F9DA_Parser* zT_25;
    zT_CB78802F_EU_49 zT_29 = {0};
    unsigned char zT_30;
    int zT_31;
    zT_3B6EA323_EU_01 zT_32;
    zT_2B3424E9_ParseToken zT_33;
    zT_85CBA4DB_TokenValue zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_40;
    unsigned int zT_45;
    int zT_49;
    unsigned int zT_52;
    unsigned short zT_53;
    int zT_56;
    int zT_58;
    int zT_60;
    unsigned int zT_62 = 0;
    unsigned int zT_64 = 0;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_72 = {0};
    unsigned char zT_73;
    unsigned int zT_74;
    zT_B559F9DA_Parser* zT_75;
    zT_2B10107F_Prec zT_76;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char zT_78;
    unsigned int zT_79;
    zT_3B6EA323_EU_01 zT_80;
    zT_3A355BD2_Token ptok;
    zT_3A355BD2_Token name_raw2;
    unsigned int result;
    unsigned int name_id;
    *capture_out = (unsigned int)(0);
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    ptok = zT_6;
    zT_7 = ptok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    name_raw2 = zT_15;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    result = zT_64;
    zT_65 = self;
    zT_66 = zF_068A2DE5_parserPeek(zT_65);
    zT_67 = zT_66.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_9; else goto z_bb_11;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_24;
    zT_25 = self;
    zT_29 = zF_5578C74F_parserExpect(zT_25, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_31 = zT_29.data.err;
    zT_32.data.err = zT_31;
    zT_32.is_error = 1;
    return zT_32;
    z_bb_7:
    zT_33 = zT_29.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_33;
    zT_35 = name_raw2.value;
    zT_36 = zT_35.string_id;
    name_id = zT_36;
    zT_37 = self->store;
    zT_49 = 0;
    zT_40 = name_raw2.span_start;
    zT_52 = name_raw2.span_start;
    zT_53 = name_raw2.span_len;
    zT_56 = 0;
    zT_58 = 0;
    zT_60 = 0;
    zT_45 = name_id;
    zT_62 = zF_6C9FF72F_astStoreAddNode(zT_37, (zT_8143F551_AstKind)(zT_8143F551_AstKind_payload_capture), (unsigned char)((unsigned char)zT_49), zT_40, (unsigned int)(zT_52 + (unsigned int)((unsigned int)zT_53)), (unsigned int)((unsigned int)zT_56), (unsigned int)((unsigned int)zT_58), (unsigned int)((unsigned int)zT_60), zT_45);
    *capture_out = zT_62;
    goto z_bb_2;
    z_bb_9:
    zT_71 = self;
    zT_72 = zF_365CA04A_parserParseBlock(zT_71);
    zT_73 = zT_72.is_error;
    if (zT_73) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_80.data.payload = result;
    zT_80.is_error = 0;
    return zT_80;
    z_bb_11:
    zT_75 = self;
    zT_76 = next_min;
    zT_77 = zF_F07C1F04_parserParseExprPrec(zT_75, zT_76);
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_72;
    z_bb_13:
    zT_74 = zT_72.data.payload;
    goto z_bb_14;
    z_bb_14:
    result = zT_74;
    goto z_bb_10;
    z_bb_15:
    return zT_77;
    z_bb_16:
    zT_79 = zT_77.data.payload;
    goto z_bb_17;
    z_bb_17:
    result = zT_79;
    goto z_bb_10;
}

/* parserParseOrelseRHS */
zT_3B6EA323_EU_01 zF_A059028C_parserParseOrelseRH(zT_B559F9DA_Parser* self, zT_2B10107F_Prec next_min) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    zT_B559F9DA_Parser* zT_10;
    zT_2B10107F_Prec zT_11;
    zT_3B6EA323_EU_01 zT_12 = {0};
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_365CA04A_parserParseBlock(zT_8);
    return zT_9;
    z_bb_2:
    zT_10 = self;
    zT_11 = next_min;
    zT_12 = zF_F07C1F04_parserParseExprPrec(zT_10, zT_11);
    return zT_12;
}

/* parserParseFieldInitListNamed */
zT_3B6EA323_EU_01 zF_D1EA41E6_parserParseFieldIni(zT_B559F9DA_Parser* self) {
    unsigned int zT_2;
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_CB78802F_EU_49 zT_18 = {0};
    unsigned char zT_19;
    int zT_20;
    zT_3B6EA323_EU_01 zT_21;
    zT_2B3424E9_ParseToken zT_22;
    zT_B559F9DA_Parser* zT_23;
    zT_CB78802F_EU_49 zT_27 = {0};
    unsigned char zT_28;
    int zT_29;
    zT_3B6EA323_EU_01 zT_30;
    zT_2B3424E9_ParseToken zT_31;
    zT_B559F9DA_Parser* zT_33;
    zT_3B6EA323_EU_01 zT_36 = {0};
    unsigned char zT_37;
    unsigned int zT_38;
    zT_85CBA4DB_TokenValue zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_51;
    int zT_55;
    unsigned int zT_58;
    unsigned short zT_59;
    int zT_62;
    int zT_64;
    unsigned int zT_66 = 0;
    unsigned int** zT_67;
    unsigned int* zT_68;
    unsigned int* zT_69;
    zT_3E40CD83_Sand* zT_70;
    unsigned int zT_71;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83 = {0};
    zT_B559F9DA_Parser* zT_85;
    zT_CB78802F_EU_49 zT_89 = {0};
    unsigned char zT_90;
    int zT_91;
    zT_3B6EA323_EU_01 zT_92;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_99;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_100;
    unsigned int* zT_102;
    unsigned int zT_103;
    unsigned int* zT_104;
    unsigned int zT_105;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_106;
    unsigned int zT_107 = 0;
    zT_3B6EA323_EU_01 zT_108;
    unsigned int saved_child_len;
    zT_3A355BD2_Token name_raw3;
    unsigned int val;
    unsigned int name_id;
    unsigned int field;
    unsigned int payload;
    zT_2 = self->child_buf_len;
    saved_child_len = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    zT_5 = zT_4.kind;
    if ((unsigned char)(zT_5 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_10 = zF_C241B2C4_parserAdvance(zT_9);
    (void)zT_10;
    zT_12 = self;
    zT_13 = zF_068A2DE5_parserPeek(zT_12);
    name_raw3 = zT_13;
    zT_14 = self;
    zT_18 = zF_5578C74F_parserExpect(zT_14, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_85 = self;
    zT_89 = zF_5578C74F_parserExpect(zT_85, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_90 = zT_89.is_error;
    if (zT_90) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = zT_18.data.err;
    zT_21.data.err = zT_20;
    zT_21.is_error = 1;
    return zT_21;
    z_bb_6:
    zT_22 = zT_18.data.payload;
    goto z_bb_7;
    z_bb_7:
    (void)zT_22;
    zT_23 = self;
    zT_27 = zF_5578C74F_parserExpect(zT_23, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq));
    zT_28 = zT_27.is_error;
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_29 = zT_27.data.err;
    zT_30.data.err = zT_29;
    zT_30.is_error = 1;
    return zT_30;
    z_bb_9:
    zT_31 = zT_27.data.payload;
    goto z_bb_10;
    z_bb_10:
    (void)zT_31;
    zT_33 = self;
    zT_36 = zF_F07C1F04_parserParseExprPrec(zT_33, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return zT_36;
    z_bb_12:
    zT_38 = zT_36.data.payload;
    goto z_bb_13;
    z_bb_13:
    val = zT_38;
    zT_40 = name_raw3.value;
    zT_41 = zT_40.string_id;
    name_id = zT_41;
    zT_43 = self->store;
    zT_55 = 0;
    zT_46 = name_raw3.span_start;
    zT_58 = name_raw3.span_start;
    zT_59 = name_raw3.span_len;
    zT_48 = val;
    zT_62 = 0;
    zT_64 = 0;
    zT_51 = name_id;
    zT_66 = zF_6C9FF72F_astStoreAddNode(zT_43, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_init), (unsigned char)((unsigned char)zT_55), zT_46, (unsigned int)(zT_58 + (unsigned int)((unsigned int)zT_59)), zT_48, (unsigned int)((unsigned int)zT_62), (unsigned int)((unsigned int)zT_64), zT_51);
    field = zT_66;
    zT_67 = &self->child_buf_items;
    zT_68 = &self->child_buf_len;
    zT_69 = &self->child_buf_capacity;
    zT_70 = self->allocator;
    zT_71 = field;
    zF_8B163A32_u32ArrayListAppendI(zT_67, zT_68, zT_69, zT_70, zT_71);
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_82 = self;
    zT_83 = zF_C241B2C4_parserAdvance(zT_82);
    (void)zT_83;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_4;
    z_bb_16:
    zT_91 = zT_89.data.err;
    zT_92.data.err = zT_91;
    zT_92.is_error = 1;
    return zT_92;
    z_bb_17:
    goto z_bb_18;
    z_bb_18:
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    payload = zT_96;
    zT_97 = self->child_buf_len;
    if ((unsigned char)(zT_97 > saved_child_len)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_99 = self->store;
    zT_102 = self->child_buf_items;
    zT_103 = self->child_buf_len;
    zT_104 = zT_102 + saved_child_len;
    zT_105 = zT_103 - saved_child_len;
    zT_106.ptr = zT_104;
    zT_106.len = zT_105;
    zT_100 = zT_106;
    zT_107 = zF_583E993C_astStoreAddExtraChi(zT_99, zT_100);
    payload = zT_107;
    goto z_bb_20;
    z_bb_20:
    self->child_buf_len = saved_child_len;
    zT_108.data.payload = payload;
    zT_108.is_error = 0;
    return zT_108;
}

/* parserParseStructInit */
zT_3B6EA323_EU_01 zF_EFD340BA_parserParseStructIn(zT_B559F9DA_Parser* self, unsigned int base) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    int zT_24;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token lbrace;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    lbrace = zT_4;
    zT_6 = self;
    zT_7 = zF_D1EA41E6_parserParseFieldIni(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_9;
    zT_11 = self->last_end;
    end_pos = zT_11;
    zT_12 = self->store;
    zT_24 = 0;
    zT_15 = lbrace.span_start;
    zT_16 = end_pos;
    zT_17 = base;
    zT_27 = 0;
    zT_29 = 0;
    zT_20 = payload;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_12, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_24), zT_15, zT_16, zT_17, (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29), zT_20);
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* u32ArrayListAppendInner */
void zF_8B163A32_u32ArrayListAppendI(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int* zT_29;
    unsigned int zT_31;
    zT_6A32A83C_Opt_238 zT_37 = {0};
    unsigned char zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_0715C9B9_EU_832 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int* zT_61;
    unsigned int zT_62;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_63;
    unsigned int* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6A32A83C_Opt_238 grown;
    unsigned char* raw;
    unsigned int* new_items_p;
    unsigned int item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((unsigned char)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(4)), (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (unsigned int*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* parserPushU32 */
void zF_0F1462F8_parserPushU32(zT_B559F9DA_Parser* self, unsigned int** buf, unsigned int* len, unsigned int* cap, unsigned int v) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_5 = buf;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = self->allocator;
    zT_9 = v;
    zF_8B163A32_u32ArrayListAppendI(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* parserParseIntLiteral */
zT_3B6EA323_EU_01 zF_4D06854D_parserParseIntLiter(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_E45552BF_astStoreAddIntLiter(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseFloatLiteral */
zT_3B6EA323_EU_01 zF_FB72DD9C_parserParseFloatLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_C41F1B06_Arr_unsigned_char_6 zT_10;
    double zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_85CBA4DB_TokenValue zT_15;
    int zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25 = {0};
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    double zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_85CBA4DB_TokenValue zT_42;
    unsigned int zT_45 = 0;
    zT_3B6EA323_EU_01 zT_46;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_C41F1B06_Arr_unsigned_char_6 dbg_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        dbg_buf[_i] = zT_10[_i];
        _i++;
    }
}
    zT_15 = tok.value;
    zT_12 = zT_15.float_val;
    zT_19 = 0;
    zT_20 = (unsigned char*)((unsigned char*)dbg_buf) + zT_19;
    zT_21 = (unsigned int)(64) - zT_19;
    zT_22.ptr = zT_20;
    zT_22.len = zT_21;
    zT_13 = zT_22;
    zT_23 = 64;
    zT_25 = zF_4CAEBE7E_formatF64(zT_12, zT_13, (unsigned int)((unsigned int)zT_23));
    dbg = zT_25;
    zT_27 = "PF:";
    zT_29 = 3;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ps = zT_28;
    zT_30 = ps;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_31 = dbg;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_33 = "\n";
    zT_35 = 1;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pn = zT_34;
    zT_36 = pn;
    zF_48AC7B3A_markerWrite(zT_36);
    zT_37 = self->store;
    zT_42 = tok.value;
    zT_38 = zT_42.float_val;
    zT_39 = tok.span_start;
    zT_40 = end;
    zT_45 = zF_0CEAF68A_astStoreAddFloatLit(zT_37, zT_38, zT_39, zT_40);
    zT_46.data.payload = zT_45;
    zT_46.is_error = 0;
    return zT_46;
}

/* parserParseStringLiteral */
zT_3B6EA323_EU_01 zF_397D4BBF_parserParseStringLi(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.string_id;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_042235B9_astStoreAddStringLi(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseCharLiteral */
zT_3B6EA323_EU_01 zF_F509A7F4_parserParseCharLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    unsigned short zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_17 = 0;
    zT_3B6EA323_EU_01 zT_18;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = tok.span_start;
    zT_6 = tok.span_len;
    zT_8 = zT_5 + (unsigned int)((unsigned int)zT_6);
    end = zT_8;
    zT_9 = self->store;
    zT_14 = tok.value;
    zT_10 = zT_14.int_val;
    zT_11 = tok.span_start;
    zT_12 = end;
    zT_17 = zF_2CAC92AE_astStoreAddCharLite(zT_9, zT_10, zT_11, zT_12);
    zT_18.data.payload = zT_17;
    zT_18.is_error = 0;
    return zT_18;
}

/* parserParseBoolLiteral */
zT_3B6EA323_EU_01 zF_0E221A14_parserParseBoolLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned char zT_6;
    zT_EAC3E484_TokenKind zT_7;
    int zT_11;
    unsigned char zT_12;
    unsigned int zT_14;
    unsigned short zT_15;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_31;
    int zT_33;
    int zT_35;
    int zT_37;
    unsigned int zT_39 = 0;
    zT_3B6EA323_EU_01 zT_40;
    zT_3A355BD2_Token tok;
    unsigned char val;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    val = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_true))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = 1;
    zT_12 = (unsigned char)zT_11;
    val = zT_12;
    goto z_bb_2;
    z_bb_2:
    zT_14 = tok.span_start;
    zT_15 = tok.span_len;
    zT_17 = zT_14 + (unsigned int)((unsigned int)zT_15);
    end = zT_17;
    zT_18 = self->store;
    zT_20 = val;
    zT_21 = tok.span_start;
    zT_22 = end;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = 0;
    zT_39 = zF_6C9FF72F_astStoreAddNode(zT_18, (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal), zT_20, zT_21, zT_22, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35), (unsigned int)((unsigned int)zT_37));
    zT_40.data.payload = zT_39;
    zT_40.is_error = 0;
    return zT_40;
}

/* parserParseSingleToken */
zT_3B6EA323_EU_01 zF_A18ECFB6_parserParseSingleTo(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    unsigned int zT_6;
    unsigned short zT_7;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_10;
    zT_8143F551_AstKind zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_20;
    int zT_23;
    int zT_25;
    int zT_27;
    int zT_29;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token tok;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = tok.span_start;
    zT_7 = tok.span_len;
    zT_9 = zT_6 + (unsigned int)((unsigned int)zT_7);
    end = zT_9;
    zT_10 = self->store;
    zT_11 = kind;
    zT_20 = 0;
    zT_13 = tok.span_start;
    zT_14 = end;
    zT_23 = 0;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = zF_6C9FF72F_astStoreAddNode(zT_10, zT_11, (unsigned char)((unsigned char)zT_20), zT_13, zT_14, (unsigned int)((unsigned int)zT_23), (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29));
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* parserParseIdentExpr */
zT_3B6EA323_EU_01 zF_F5EAD186_parserParseIdentExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_2B3424E9_ParseToken zT_5;
    zT_EAC3E484_TokenKind zT_6;
    unsigned int zT_7;
    unsigned short zT_8;
    zT_D3EB6303_StringInterner* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_B559F9DA_Parser* zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15 = {0};
    unsigned int zT_16 = 0;
    unsigned int zT_18;
    unsigned short zT_19;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_31 = 0;
    zT_3B6EA323_EU_01 zT_32;
    zT_3A355BD2_Token tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_6 = tok.kind;
    zT_5.kind = zT_6;
    zT_7 = tok.span_start;
    zT_5.span_start = zT_7;
    zT_8 = tok.span_len;
    zT_5.span_len = zT_8;
    pt = zT_5;
    zT_10 = self->interner;
    zT_13 = self;
    zT_14 = pt;
    zT_15 = zF_08D61E58_parserTokenText(zT_13, zT_14);
    zT_11 = zT_15;
    zT_16 = zF_50C274AF_stringInternerInter(zT_10, zT_11);
    id = zT_16;
    zT_18 = tok.span_start;
    zT_19 = tok.span_len;
    zT_21 = zT_18 + (unsigned int)((unsigned int)zT_19);
    end = zT_21;
    zT_22 = self->store;
    zT_24 = id;
    zT_25 = tok.span_start;
    zT_26 = end;
    zT_31 = zF_1DF77BD4_astStoreAddIdentifi(zT_22, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_24, zT_25, zT_26);
    zT_32.data.payload = zT_31;
    zT_32.is_error = 0;
    return zT_32;
}

/* parserParsePrefixUnary */
zT_3B6EA323_EU_01 zF_BE192524_parserParsePrefixUn(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned short zT_14;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_8143F551_AstKind zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_27;
    int zT_30;
    int zT_32;
    int zT_34;
    unsigned int zT_36 = 0;
    zT_3B6EA323_EU_01 zT_37;
    zT_3A355BD2_Token tok;
    unsigned int operand;
    unsigned int end;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = self;
    zT_9 = zF_F07C1F04_parserParseExprPrec(zT_6, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    operand = zT_11;
    zT_13 = tok.span_start;
    zT_14 = tok.span_len;
    zT_16 = zT_13 + (unsigned int)((unsigned int)zT_14);
    end = zT_16;
    zT_17 = self->store;
    zT_18 = kind;
    zT_27 = 0;
    zT_20 = tok.span_start;
    zT_21 = end;
    zT_22 = operand;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = zF_6C9FF72F_astStoreAddNode(zT_17, zT_18, (unsigned char)((unsigned char)zT_27), zT_20, zT_21, zT_22, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34));
    zT_37.data.payload = zT_36;
    zT_37.is_error = 0;
    return zT_37;
}

/* parserParseGroupedExpr */
zT_3B6EA323_EU_01 zF_C5DF83EE_parserParseGroupedE(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_16 = {0};
    unsigned char zT_17;
    int zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_2B3424E9_ParseToken zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24;
    unsigned int zT_26;
    int zT_33;
    unsigned int zT_36;
    unsigned short zT_37;
    int zT_40;
    int zT_42;
    int zT_44;
    unsigned int zT_46 = 0;
    zT_3B6EA323_EU_01 zT_47;
    zT_3A355BD2_Token lparen;
    unsigned int inner;
    zT_2B3424E9_ParseToken rparen;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    lparen = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = self;
    zT_16 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = zT_16.data.err;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_5:
    zT_20 = zT_16.data.payload;
    goto z_bb_6;
    z_bb_6:
    rparen = zT_20;
    zT_21 = self->store;
    zT_33 = 0;
    zT_24 = lparen.span_start;
    zT_36 = rparen.span_start;
    zT_37 = rparen.span_len;
    zT_26 = inner;
    zT_40 = 0;
    zT_42 = 0;
    zT_44 = 0;
    zT_46 = zF_6C9FF72F_astStoreAddNode(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr), (unsigned char)((unsigned char)zT_33), zT_24, (unsigned int)(zT_36 + (unsigned int)((unsigned int)zT_37)), zT_26, (unsigned int)((unsigned int)zT_40), (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44));
    zT_47.data.payload = zT_46;
    zT_47.is_error = 0;
    return zT_47;
}

/* parserParseBuiltinCall */
zT_3B6EA323_EU_01 zF_5D650338_parserParseBuiltinC(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_85CBA4DB_TokenValue zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_8;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11;
    zT_3B6EA323_EU_01 zT_12 = {0};
    zT_85CBA4DB_TokenValue zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned short zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_EAC3E484_TokenKind zT_24;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_DBF3575C_ParserError zT_35;
    zT_3B6EA323_EU_01 zT_36;
    zT_B559F9DA_Parser* zT_37;
    zT_3A355BD2_Token zT_38 = {0};
    unsigned int zT_40;
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    zT_B559F9DA_Parser* zT_49;
    zT_3A355BD2_Token zT_50 = {0};
    unsigned char zT_52;
    zT_EAC3E484_TokenKind zT_53;
    unsigned char zT_57;
    zT_EAC3E484_TokenKind zT_58;
    unsigned char zT_62;
    zT_EAC3E484_TokenKind zT_63;
    unsigned char zT_67;
    zT_EAC3E484_TokenKind zT_68;
    unsigned char zT_72;
    zT_EAC3E484_TokenKind zT_73;
    unsigned char zT_77;
    zT_EAC3E484_TokenKind zT_78;
    unsigned char zT_82;
    zT_EAC3E484_TokenKind zT_83;
    unsigned char zT_87;
    zT_EAC3E484_TokenKind zT_88;
    unsigned char zT_92;
    zT_EAC3E484_TokenKind zT_93;
    unsigned char zT_97;
    zT_EAC3E484_TokenKind zT_98;
    unsigned char zT_102;
    zT_B559F9DA_Parser* zT_106;
    zT_3B6EA323_EU_01 zT_107 = {0};
    unsigned char zT_108;
    unsigned int zT_109;
    unsigned int** zT_110;
    unsigned int* zT_111;
    unsigned int* zT_112;
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_B559F9DA_Parser* zT_120;
    zT_3B6EA323_EU_01 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_125;
    unsigned int** zT_126;
    unsigned int* zT_127;
    unsigned int* zT_128;
    zT_3E40CD83_Sand* zT_129;
    unsigned int zT_130;
    zT_B559F9DA_Parser* zT_135;
    zT_3A355BD2_Token zT_136 = {0};
    zT_EAC3E484_TokenKind zT_137;
    zT_B559F9DA_Parser* zT_141;
    zT_CB78802F_EU_49 zT_145 = {0};
    unsigned char zT_146;
    int zT_147;
    zT_3B6EA323_EU_01 zT_148;
    zT_2B3424E9_ParseToken zT_149;
    zT_B559F9DA_Parser* zT_151;
    zT_3A355BD2_Token zT_152 = {0};
    unsigned int zT_153;
    unsigned short zT_154;
    unsigned int zT_156;
    int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_6B0A7D14_AstStore* zT_162;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_163;
    unsigned int* zT_165;
    unsigned int zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_169;
    unsigned int zT_170 = 0;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_179;
    int zT_183;
    int zT_186;
    int zT_188;
    unsigned int zT_190 = 0;
    zT_3B6EA323_EU_01 zT_191;
    zT_3A355BD2_Token tok;
    unsigned int id;
    unsigned int end;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    unsigned int saved_builtin;
    zT_3A355BD2_Token rparen;
    unsigned int payload;
    zT_3A355BD2_Token arg_tok;
    unsigned char is_type;
    unsigned int arg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = tok.value;
    zT_5 = zT_4.string_id;
    zT_6 = self->builtin_import_id;
    if ((unsigned char)(zT_5 == zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_8);
    zT_10 = self;
    zT_11 = tok;
    zT_12 = zF_D258E86B_parserParseImportEx(zT_10, zT_11);
    return zT_12;
    z_bb_2:
    zT_14 = tok.value;
    zT_15 = zT_14.string_id;
    id = zT_15;
    zT_17 = tok.span_start;
    zT_18 = tok.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end = zT_20;
    zT_22 = self;
    zT_23 = zF_068A2DE5_parserPeek(zT_22);
    lparen = zT_23;
    zT_24 = lparen.kind;
    if ((unsigned char)(zT_24 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_29 = "expected '(' after builtin name";
    zT_31 = 31;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    exp_s = zT_30;
    zT_32 = self;
    zT_33 = lparen;
    zT_34 = exp_s;
    zF_17DF2CA5_parserAddError(zT_32, zT_33, zT_34);
    zT_35 = 1;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_4:
    zT_37 = self;
    zT_38 = zF_C241B2C4_parserAdvance(zT_37);
    (void)zT_38;
    zT_40 = self->child_buf_len;
    saved_builtin = zT_40;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(1)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    zT_44 = zT_43.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_151 = self;
    zT_152 = zF_C241B2C4_parserAdvance(zT_151);
    rparen = zT_152;
    zT_153 = rparen.span_start;
    zT_154 = rparen.span_len;
    zT_156 = zT_153 + (unsigned int)((unsigned int)zT_154);
    end = zT_156;
    zT_158 = 0;
    zT_159 = (unsigned int)zT_158;
    payload = zT_159;
    zT_160 = self->child_buf_len;
    if ((unsigned char)(zT_160 > saved_builtin)) goto z_bb_45; else goto z_bb_46;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    zT_49 = self;
    zT_50 = zF_068A2DE5_parserPeek(zT_49);
    arg_tok = zT_50;
    zT_52 = 0;
    is_type = zT_52;
    zT_53 = arg_tok.kind;
    if ((unsigned char)(zT_53 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_57 = 1;
    is_type = zT_57;
    goto z_bb_12;
    z_bb_12:
    zT_58 = arg_tok.kind;
    if ((unsigned char)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_62 = 1;
    is_type = zT_62;
    goto z_bb_14;
    z_bb_14:
    zT_63 = arg_tok.kind;
    if ((unsigned char)(zT_63 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_67 = 1;
    is_type = zT_67;
    goto z_bb_16;
    z_bb_16:
    zT_68 = arg_tok.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_72 = 1;
    is_type = zT_72;
    goto z_bb_18;
    z_bb_18:
    zT_73 = arg_tok.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_77 = 1;
    is_type = zT_77;
    goto z_bb_20;
    z_bb_20:
    zT_78 = arg_tok.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = 1;
    is_type = zT_82;
    goto z_bb_22;
    z_bb_22:
    zT_83 = arg_tok.kind;
    if ((unsigned char)(zT_83 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_87 = 1;
    is_type = zT_87;
    goto z_bb_24;
    z_bb_24:
    zT_88 = arg_tok.kind;
    if ((unsigned char)(zT_88 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_92 = 1;
    is_type = zT_92;
    goto z_bb_26;
    z_bb_26:
    zT_93 = arg_tok.kind;
    if ((unsigned char)(zT_93 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_97 = 1;
    is_type = zT_97;
    goto z_bb_28;
    z_bb_28:
    zT_98 = arg_tok.kind;
    if ((unsigned char)(zT_98 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_102 = 1;
    is_type = zT_102;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)(is_type != (unsigned char)(0))) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_106 = self;
    zT_107 = zF_CBDBFE85_parserParseType(zT_106);
    zT_108 = zT_107.is_error;
    if (zT_108) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    zT_135 = self;
    zT_136 = zF_068A2DE5_parserPeek(zT_135);
    zT_137 = zT_136.kind;
    if ((unsigned char)(zT_137 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_40; else goto z_bb_41;
    z_bb_33:
    zT_120 = self;
    zT_123 = zF_F07C1F04_parserParseExprPrec(zT_120, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    return zT_107;
    z_bb_35:
    zT_109 = zT_107.data.payload;
    goto z_bb_36;
    z_bb_36:
    arg = zT_109;
    zT_110 = &self->child_buf_items;
    zT_111 = &self->child_buf_len;
    zT_112 = &self->child_buf_capacity;
    zT_113 = self->allocator;
    zT_114 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_110, zT_111, zT_112, zT_113, zT_114);
    goto z_bb_32;
    z_bb_37:
    return zT_123;
    z_bb_38:
    zT_125 = zT_123.data.payload;
    goto z_bb_39;
    z_bb_39:
    arg = zT_125;
    zT_126 = &self->child_buf_items;
    zT_127 = &self->child_buf_len;
    zT_128 = &self->child_buf_capacity;
    zT_129 = self->allocator;
    zT_130 = arg;
    zF_8B163A32_u32ArrayListAppendI(zT_126, zT_127, zT_128, zT_129, zT_130);
    goto z_bb_32;
    z_bb_40:
    goto z_bb_7;
    z_bb_41:
    zT_141 = self;
    zT_145 = zF_5578C74F_parserExpect(zT_141, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma));
    zT_146 = zT_145.is_error;
    if (zT_146) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_147 = zT_145.data.err;
    zT_148.data.err = zT_147;
    zT_148.is_error = 1;
    return zT_148;
    z_bb_43:
    zT_149 = zT_145.data.payload;
    goto z_bb_44;
    z_bb_44:
    (void)zT_149;
    goto z_bb_8;
    z_bb_45:
    zT_162 = self->store;
    zT_165 = self->child_buf_items;
    zT_166 = self->child_buf_len;
    zT_167 = zT_165 + saved_builtin;
    zT_168 = zT_166 - saved_builtin;
    zT_169.ptr = zT_167;
    zT_169.len = zT_168;
    zT_163 = zT_169;
    zT_170 = zF_583E993C_astStoreAddExtraChi(zT_162, zT_163);
    payload = zT_170;
    goto z_bb_46;
    z_bb_46:
    self->child_buf_len = saved_builtin;
    zT_171 = self->store;
    zT_183 = 0;
    zT_174 = tok.span_start;
    zT_175 = end;
    zT_176 = id;
    zT_186 = 0;
    zT_188 = 0;
    zT_179 = payload;
    zT_190 = zF_6C9FF72F_astStoreAddNode(zT_171, (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call), (unsigned char)((unsigned char)zT_183), zT_174, zT_175, zT_176, (unsigned int)((unsigned int)zT_186), (unsigned int)((unsigned int)zT_188), zT_179);
    zT_191.data.payload = zT_190;
    zT_191.is_error = 0;
    return zT_191;
}

/* parserParseImportExpr */
zT_3B6EA323_EU_01 zF_D258E86B_parserParseImportEx(zT_B559F9DA_Parser* self, zT_3A355BD2_Token bi_tok) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_EAC3E484_TokenKind zT_5;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_DBF3575C_ParserError zT_16;
    zT_3B6EA323_EU_01 zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_DBF3575C_ParserError zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_85CBA4DB_TokenValue zT_37;
    unsigned int zT_38;
    zT_B559F9DA_Parser* zT_39;
    zT_3A355BD2_Token zT_40 = {0};
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_DBF3575C_ParserError zT_55;
    zT_3B6EA323_EU_01 zT_56;
    unsigned int zT_58;
    unsigned short zT_59;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_62;
    zT_3A355BD2_Token zT_63 = {0};
    zT_7332B667_Opt_231 zT_64;
    unsigned char zT_65;
    zT_6D306E5E_Opt_243 zT_67;
    unsigned char zT_68;
    zT_3E40CD83_Sand* zT_70;
    zT_072B53A6_ModuleRegistry* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_BAEE192E_Opt_10 zT_77 = {0};
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_86;
    int zT_90;
    int zT_93;
    int zT_95;
    int zT_97;
    unsigned int zT_99 = 0;
    zT_3B6EA323_EU_01 zT_100;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token path_tok;
    unsigned int path_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_072B53A6_ModuleRegistry* reg;
    zT_3E40CD83_Sand* is;
    zT_BAEE192E_Opt_10 resolved;
    zT_3 = self;
    zT_4 = zF_068A2DE5_parserPeek(zT_3);
    lparen = zT_4;
    zT_5 = lparen.kind;
    if ((unsigned char)(zT_5 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = "expected '(' after @import";
    zT_12 = 26;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    exp_s = zT_11;
    zT_13 = self;
    zT_14 = lparen;
    zT_15 = exp_s;
    zF_17DF2CA5_parserAddError(zT_13, zT_14, zT_15);
    zT_16 = 1;
    zT_17.data.err = zT_16;
    zT_17.is_error = 1;
    return zT_17;
    z_bb_2:
    zT_18 = self;
    zT_19 = zF_C241B2C4_parserAdvance(zT_18);
    (void)zT_19;
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    path_tok = zT_22;
    zT_23 = path_tok.kind;
    if ((unsigned char)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_28 = "expected string literal for @import path";
    zT_30 = 40;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    exp_s = zT_29;
    zT_31 = self;
    zT_32 = path_tok;
    zT_33 = exp_s;
    zF_17DF2CA5_parserAddError(zT_31, zT_32, zT_33);
    zT_34 = 1;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_4:
    zT_37 = path_tok.value;
    zT_38 = zT_37.string_id;
    path_id = zT_38;
    zT_39 = self;
    zT_40 = zF_C241B2C4_parserAdvance(zT_39);
    (void)zT_40;
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    rparen = zT_43;
    zT_44 = rparen.kind;
    if ((unsigned char)(zT_44 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_49 = "expected ')' after @import path";
    zT_51 = 31;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    exp_s = zT_50;
    zT_52 = self;
    zT_53 = rparen;
    zT_54 = exp_s;
    zF_17DF2CA5_parserAddError(zT_52, zT_53, zT_54);
    zT_55 = 1;
    zT_56.data.err = zT_55;
    zT_56.is_error = 1;
    return zT_56;
    z_bb_6:
    zT_58 = rparen.span_start;
    zT_59 = rparen.span_len;
    zT_61 = zT_58 + (unsigned int)((unsigned int)zT_59);
    end_pos = zT_61;
    zT_62 = self;
    zT_63 = zF_C241B2C4_parserAdvance(zT_62);
    (void)zT_63;
    zT_64 = self->module_reg;
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    reg = zT_64.value;
    zT_67 = self->import_scratch;
    zT_68 = zT_67.has_value;
    if (zT_68) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_78 = self->store;
    zT_90 = 0;
    zT_81 = bi_tok.span_start;
    zT_82 = end_pos;
    zT_93 = 0;
    zT_95 = 0;
    zT_97 = 0;
    zT_86 = path_id;
    zT_99 = zF_6C9FF72F_astStoreAddNode(zT_78, (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr), (unsigned char)((unsigned char)zT_90), zT_81, zT_82, (unsigned int)((unsigned int)zT_93), (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97), zT_86);
    zT_100.data.payload = zT_99;
    zT_100.is_error = 0;
    return zT_100;
    z_bb_9:
    is = zT_67.value;
    zT_70 = is;
    zF_F1B3F8C2_sandReset(zT_70);
    zT_72 = reg;
    zT_73 = path_id;
    zT_74 = self->current_module_id;
    zT_75 = is;
    zT_77 = zF_620E3E3B_moduleRegistryResol(zT_72, zT_73, zT_74, zT_75);
    resolved = zT_77;
    (void)resolved;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* parserParseCInclude */
zT_3B6EA323_EU_01 zF_C531682A_parserParseCInclude(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_DBF3575C_ParserError zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_B559F9DA_Parser* zT_23;
    zT_3A355BD2_Token zT_24 = {0};
    zT_EAC3E484_TokenKind zT_25;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_B559F9DA_Parser* zT_33;
    zT_3A355BD2_Token zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_DBF3575C_ParserError zT_36;
    zT_3B6EA323_EU_01 zT_37;
    zT_85CBA4DB_TokenValue zT_39;
    unsigned int zT_40;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_DBF3575C_ParserError zT_57;
    zT_3B6EA323_EU_01 zT_58;
    unsigned int zT_60;
    unsigned short zT_61;
    unsigned int zT_63;
    zT_B559F9DA_Parser* zT_64;
    zT_3A355BD2_Token zT_65 = {0};
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_74;
    int zT_78;
    int zT_81;
    int zT_83;
    int zT_85;
    unsigned int zT_87 = 0;
    zT_3B6EA323_EU_01 zT_88;
    zT_3A355BD2_Token bi_tok;
    zT_3A355BD2_Token lparen;
    zT_8F083A69_Slice_zT_0B42B2F8_u exp_s;
    zT_3A355BD2_Token name_tok;
    unsigned int name_id;
    zT_3A355BD2_Token rparen;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    bi_tok = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    lparen = zT_6;
    zT_7 = lparen.kind;
    if ((unsigned char)(zT_7 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "expected '(' after @cInclude";
    zT_14 = 28;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    exp_s = zT_13;
    zT_15 = self;
    zT_16 = lparen;
    zT_17 = exp_s;
    zF_17DF2CA5_parserAddError(zT_15, zT_16, zT_17);
    zT_18 = 1;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_2:
    zT_20 = self;
    zT_21 = zF_C241B2C4_parserAdvance(zT_20);
    (void)zT_21;
    zT_23 = self;
    zT_24 = zF_068A2DE5_parserPeek(zT_23);
    name_tok = zT_24;
    zT_25 = name_tok.kind;
    if ((unsigned char)(zT_25 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = "expected string literal for @cInclude name";
    zT_32 = 42;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    exp_s = zT_31;
    zT_33 = self;
    zT_34 = name_tok;
    zT_35 = exp_s;
    zF_17DF2CA5_parserAddError(zT_33, zT_34, zT_35);
    zT_36 = 1;
    zT_37.data.err = zT_36;
    zT_37.is_error = 1;
    return zT_37;
    z_bb_4:
    zT_39 = name_tok.value;
    zT_40 = zT_39.string_id;
    name_id = zT_40;
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    zT_44 = self;
    zT_45 = zF_068A2DE5_parserPeek(zT_44);
    rparen = zT_45;
    zT_46 = rparen.kind;
    if ((unsigned char)(zT_46 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_51 = "expected ')' after @cInclude name";
    zT_53 = 33;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    exp_s = zT_52;
    zT_54 = self;
    zT_55 = rparen;
    zT_56 = exp_s;
    zF_17DF2CA5_parserAddError(zT_54, zT_55, zT_56);
    zT_57 = 1;
    zT_58.data.err = zT_57;
    zT_58.is_error = 1;
    return zT_58;
    z_bb_6:
    zT_60 = rparen.span_start;
    zT_61 = rparen.span_len;
    zT_63 = zT_60 + (unsigned int)((unsigned int)zT_61);
    end_pos = zT_63;
    zT_64 = self;
    zT_65 = zF_C241B2C4_parserAdvance(zT_64);
    (void)zT_65;
    zT_66 = self->store;
    zT_78 = 0;
    zT_69 = bi_tok.span_start;
    zT_70 = end_pos;
    zT_81 = 0;
    zT_83 = 0;
    zT_85 = 0;
    zT_74 = name_id;
    zT_87 = zF_6C9FF72F_astStoreAddNode(zT_66, (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include), (unsigned char)((unsigned char)zT_78), zT_69, zT_70, (unsigned int)((unsigned int)zT_81), (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85), zT_74);
    zT_88.data.payload = zT_87;
    zT_88.is_error = 0;
    return zT_88;
}

/* parserParseErrorLiteral */
zT_3B6EA323_EU_01 zF_AC24A2A0_parserParseErrorLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12;
    zT_3B6EA323_EU_01 zT_13 = {0};
    unsigned char zT_14;
    unsigned int zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    zT_B559F9DA_Parser* zT_25;
    zT_3B6EA323_EU_01 zT_26 = {0};
    unsigned char zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_41;
    unsigned int zT_44;
    unsigned short zT_45;
    int zT_48;
    int zT_50;
    unsigned int zT_52 = 0;
    zT_3B6EA323_EU_01 zT_53;
    zT_3B6EA323_EU_01 zT_54;
    zT_B559F9DA_Parser* zT_55;
    zT_CB78802F_EU_49 zT_59 = {0};
    unsigned char zT_60;
    int zT_61;
    zT_3B6EA323_EU_01 zT_62;
    zT_2B3424E9_ParseToken zT_63;
    zT_B559F9DA_Parser* zT_65;
    zT_CB78802F_EU_49 zT_69 = {0};
    unsigned char zT_70;
    int zT_71;
    zT_3B6EA323_EU_01 zT_72;
    zT_2B3424E9_ParseToken zT_73;
    zT_2B3424E9_ParseToken zT_75;
    zT_EAC3E484_TokenKind zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    zT_D3EB6303_StringInterner* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_B559F9DA_Parser* zT_83;
    zT_2B3424E9_ParseToken zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85 = {0};
    unsigned int zT_86 = 0;
    unsigned int zT_88;
    unsigned short zT_89;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_100;
    int zT_104;
    int zT_107;
    int zT_109;
    int zT_111;
    unsigned int zT_113 = 0;
    zT_3B6EA323_EU_01 zT_114;
    zT_3A355BD2_Token kw;
    unsigned int es;
    unsigned int eu_payload;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = kw;
    zT_13 = zF_2C55CABB_parserParseErrorSet(zT_11, zT_12);
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_55 = self;
    zT_59 = zF_5578C74F_parserExpect(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    return zT_13;
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    es = zT_15;
    zT_16 = self;
    zT_17 = zF_068A2DE5_parserPeek(zT_16);
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self;
    zT_23 = zF_C241B2C4_parserAdvance(zT_22);
    (void)zT_23;
    zT_25 = self;
    zT_26 = zF_CBDBFE85_parserParseType(zT_25);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_54.data.payload = es;
    zT_54.is_error = 0;
    return zT_54;
    z_bb_8:
    return zT_26;
    z_bb_9:
    zT_28 = zT_26.data.payload;
    goto z_bb_10;
    z_bb_10:
    eu_payload = zT_28;
    zT_29 = self->store;
    zT_41 = 0;
    zT_32 = kw.span_start;
    zT_44 = kw.span_start;
    zT_45 = kw.span_len;
    zT_34 = es;
    zT_35 = eu_payload;
    zT_48 = 0;
    zT_50 = 0;
    zT_52 = zF_6C9FF72F_astStoreAddNode(zT_29, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_41), zT_32, (unsigned int)(zT_44 + (unsigned int)((unsigned int)zT_45)), zT_34, zT_35, (unsigned int)((unsigned int)zT_48), (unsigned int)((unsigned int)zT_50));
    zT_53.data.payload = zT_52;
    zT_53.is_error = 0;
    return zT_53;
    z_bb_11:
    zT_61 = zT_59.data.err;
    zT_62.data.err = zT_61;
    zT_62.is_error = 1;
    return zT_62;
    z_bb_12:
    zT_63 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    (void)zT_63;
    zT_65 = self;
    zT_69 = zF_5578C74F_parserExpect(zT_65, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_70 = zT_69.is_error;
    if (zT_70) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_71 = zT_69.data.err;
    zT_72.data.err = zT_71;
    zT_72.is_error = 1;
    return zT_72;
    z_bb_15:
    zT_73 = zT_69.data.payload;
    goto z_bb_16;
    z_bb_16:
    name_tok = zT_73;
    zT_76 = name_tok.kind;
    zT_75.kind = zT_76;
    zT_77 = name_tok.span_start;
    zT_75.span_start = zT_77;
    zT_78 = name_tok.span_len;
    zT_75.span_len = zT_78;
    pt = zT_75;
    zT_80 = self->interner;
    zT_83 = self;
    zT_84 = pt;
    zT_85 = zF_08D61E58_parserTokenText(zT_83, zT_84);
    zT_81 = zT_85;
    zT_86 = zF_50C274AF_stringInternerInter(zT_80, zT_81);
    name_id = zT_86;
    zT_88 = name_tok.span_start;
    zT_89 = name_tok.span_len;
    zT_91 = zT_88 + (unsigned int)((unsigned int)zT_89);
    end = zT_91;
    zT_92 = self->store;
    zT_104 = 0;
    zT_95 = kw.span_start;
    zT_96 = end;
    zT_107 = 0;
    zT_109 = 0;
    zT_111 = 0;
    zT_100 = name_id;
    zT_113 = zF_6C9FF72F_astStoreAddNode(zT_92, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal), (unsigned char)((unsigned char)zT_104), zT_95, zT_96, (unsigned int)((unsigned int)zT_107), (unsigned int)((unsigned int)zT_109), (unsigned int)((unsigned int)zT_111), zT_100);
    zT_114.data.payload = zT_113;
    zT_114.is_error = 0;
    return zT_114;
}

/* parserParseTryExpr */
zT_3B6EA323_EU_01 zF_59C88921_parserParseTryExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_8 = {0};
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned short zT_13;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_28;
    int zT_31;
    int zT_33;
    int zT_35;
    unsigned int zT_37 = 0;
    zT_3B6EA323_EU_01 zT_38;
    zT_3A355BD2_Token kw;
    unsigned int inner;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = self;
    zT_8 = zF_F07C1F04_parserParseExprPrec(zT_5, (zT_2B10107F_Prec)(zT_2B10107F_Prec_prefix));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_10;
    zT_12 = kw.span_start;
    zT_13 = kw.span_len;
    zT_15 = zT_12 + (unsigned int)((unsigned int)zT_13);
    end_pos = zT_15;
    zT_16 = self->store;
    zT_28 = 0;
    zT_19 = kw.span_start;
    zT_20 = end_pos;
    zT_21 = inner;
    zT_31 = 0;
    zT_33 = 0;
    zT_35 = 0;
    zT_37 = zF_6C9FF72F_astStoreAddNode(zT_16, (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr), (unsigned char)((unsigned char)zT_28), zT_19, zT_20, zT_21, (unsigned int)((unsigned int)zT_31), (unsigned int)((unsigned int)zT_33), (unsigned int)((unsigned int)zT_35));
    zT_38.data.payload = zT_37;
    zT_38.is_error = 0;
    return zT_38;
}

/* parserParseAnonymousLiteral */
zT_3B6EA323_EU_01 zF_9A508F9D_parserParseAnonymou(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    unsigned char zT_11;
    zT_EAC3E484_TokenKind zT_12;
    zT_B559F9DA_Parser* zT_17;
    zT_3B6EA323_EU_01 zT_18 = {0};
    unsigned char zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_29;
    int zT_33;
    int zT_37;
    int zT_39;
    int zT_41;
    unsigned int zT_43 = 0;
    zT_3B6EA323_EU_01 zT_44;
    unsigned int zT_46;
    zT_B559F9DA_Parser* zT_47;
    zT_3A355BD2_Token zT_48 = {0};
    zT_EAC3E484_TokenKind zT_49;
    unsigned char zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_61;
    zT_3B6EA323_EU_01 zT_64 = {0};
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned int** zT_67;
    unsigned int* zT_68;
    unsigned int* zT_69;
    zT_3E40CD83_Sand* zT_70;
    unsigned int zT_71;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83 = {0};
    zT_B559F9DA_Parser* zT_85;
    zT_CB78802F_EU_49 zT_89 = {0};
    unsigned char zT_90;
    int zT_91;
    zT_3B6EA323_EU_01 zT_92;
    zT_2B3424E9_ParseToken zT_93;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_99;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_100;
    unsigned int* zT_102;
    unsigned int zT_103;
    unsigned int* zT_104;
    unsigned int zT_105;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_106;
    unsigned int zT_107 = 0;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_111;
    unsigned int zT_116;
    int zT_120;
    unsigned int zT_123;
    unsigned short zT_124;
    int zT_127;
    int zT_129;
    int zT_131;
    unsigned int zT_133 = 0;
    zT_3B6EA323_EU_01 zT_134;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token peek;
    unsigned int payload;
    unsigned int saved_child_len;
    unsigned int val;
    zT_2B3424E9_ParseToken rbrace;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    peek = zT_6;
    zT_7 = peek.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_12 = peek.kind;
    zT_11 = zT_12 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = self;
    zT_18 = zF_D1EA41E6_parserParseFieldIni(zT_17);
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_46 = self->child_buf_len;
    saved_child_len = zT_46;
    goto z_bb_9;
    z_bb_6:
    return zT_18;
    z_bb_7:
    zT_20 = zT_18.data.payload;
    goto z_bb_8;
    z_bb_8:
    payload = zT_20;
    zT_21 = self->store;
    zT_33 = 0;
    zT_24 = dot.span_start;
    zT_25 = self->last_end;
    zT_37 = 0;
    zT_39 = 0;
    zT_41 = 0;
    zT_29 = payload;
    zT_43 = zF_6C9FF72F_astStoreAddNode(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init), (unsigned char)((unsigned char)zT_33), zT_24, zT_25, (unsigned int)((unsigned int)zT_37), (unsigned int)((unsigned int)zT_39), (unsigned int)((unsigned int)zT_41), zT_29);
    zT_44.data.payload = zT_43;
    zT_44.is_error = 0;
    return zT_44;
    z_bb_9:
    zT_47 = self;
    zT_48 = zF_068A2DE5_parserPeek(zT_47);
    zT_49 = zT_48.kind;
    if ((unsigned char)(zT_49 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_61 = self;
    zT_64 = zF_F07C1F04_parserParseExprPrec(zT_61, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_16; else goto z_bb_17;
    z_bb_11:
    zT_85 = self;
    zT_89 = zF_5578C74F_parserExpect(zT_85, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_90 = zT_89.is_error;
    if (zT_90) goto z_bb_21; else goto z_bb_22;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_54 = self;
    zT_55 = zF_068A2DE5_parserPeek(zT_54);
    zT_56 = zT_55.kind;
    zT_53 = zT_56 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_15;
    z_bb_14:
    zT_53 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_16:
    return zT_64;
    z_bb_17:
    zT_66 = zT_64.data.payload;
    goto z_bb_18;
    z_bb_18:
    val = zT_66;
    zT_67 = &self->child_buf_items;
    zT_68 = &self->child_buf_len;
    zT_69 = &self->child_buf_capacity;
    zT_70 = self->allocator;
    zT_71 = val;
    zF_8B163A32_u32ArrayListAppendI(zT_67, zT_68, zT_69, zT_70, zT_71);
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_82 = self;
    zT_83 = zF_C241B2C4_parserAdvance(zT_82);
    (void)zT_83;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_91 = zT_89.data.err;
    zT_92.data.err = zT_91;
    zT_92.is_error = 1;
    return zT_92;
    z_bb_22:
    zT_93 = zT_89.data.payload;
    goto z_bb_23;
    z_bb_23:
    rbrace = zT_93;
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    payload = zT_96;
    zT_97 = self->child_buf_len;
    if ((unsigned char)(zT_97 > saved_child_len)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_99 = self->store;
    zT_102 = self->child_buf_items;
    zT_103 = self->child_buf_len;
    zT_104 = zT_102 + saved_child_len;
    zT_105 = zT_103 - saved_child_len;
    zT_106.ptr = zT_104;
    zT_106.len = zT_105;
    zT_100 = zT_106;
    zT_107 = zF_583E993C_astStoreAddExtraChi(zT_99, zT_100);
    payload = zT_107;
    goto z_bb_25;
    z_bb_25:
    self->child_buf_len = saved_child_len;
    zT_108 = self->store;
    zT_120 = 0;
    zT_111 = dot.span_start;
    zT_123 = rbrace.span_start;
    zT_124 = rbrace.span_len;
    zT_127 = 0;
    zT_129 = 0;
    zT_131 = 0;
    zT_116 = payload;
    zT_133 = zF_6C9FF72F_astStoreAddNode(zT_108, (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal), (unsigned char)((unsigned char)zT_120), zT_111, (unsigned int)(zT_123 + (unsigned int)((unsigned int)zT_124)), (unsigned int)((unsigned int)zT_127), (unsigned int)((unsigned int)zT_129), (unsigned int)((unsigned int)zT_131), zT_116);
    zT_134.data.payload = zT_133;
    zT_134.is_error = 0;
    return zT_134;
}

/* parserParseEnumLiteral */
zT_3B6EA323_EU_01 zF_BD525F87_parserParseEnumLite(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_B559F9DA_Parser* zT_7;
    zT_CB78802F_EU_49 zT_11 = {0};
    unsigned char zT_12;
    int zT_13;
    zT_3B6EA323_EU_01 zT_14;
    zT_2B3424E9_ParseToken zT_15;
    unsigned int zT_17;
    unsigned short zT_18;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_85CBA4DB_TokenValue zT_29;
    unsigned int zT_32 = 0;
    zT_3B6EA323_EU_01 zT_33;
    zT_3A355BD2_Token dot;
    zT_3A355BD2_Token name_tok;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    dot = zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    name_tok = zT_6;
    zT_7 = self;
    zT_11 = zF_5578C74F_parserExpect(zT_7, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = zT_11.data.err;
    zT_14.data.err = zT_13;
    zT_14.is_error = 1;
    return zT_14;
    z_bb_2:
    zT_15 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_15;
    zT_17 = name_tok.span_start;
    zT_18 = name_tok.span_len;
    zT_20 = zT_17 + (unsigned int)((unsigned int)zT_18);
    end_pos = zT_20;
    zT_21 = self->store;
    zT_29 = name_tok.value;
    zT_23 = zT_29.string_id;
    zT_24 = dot.span_start;
    zT_25 = end_pos;
    zT_32 = zF_1DF77BD4_astStoreAddIdentifi(zT_21, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal), zT_23, zT_24, zT_25);
    zT_33.data.payload = zT_32;
    zT_33.is_error = 0;
    return zT_33;
}

/* parserParseArrayLiteral */
zT_3B6EA323_EU_01 zF_DE101A45_parserParseArrayLit(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_B559F9DA_Parser* zT_9;
    zT_3A355BD2_Token zT_10 = {0};
    zT_EAC3E484_TokenKind zT_11;
    zT_3B6EA323_EU_01 zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    unsigned char zT_26;
    zT_B559F9DA_Parser* zT_27;
    zT_3A355BD2_Token zT_28 = {0};
    zT_EAC3E484_TokenKind zT_29;
    zT_B559F9DA_Parser* zT_34;
    zT_3B6EA323_EU_01 zT_37 = {0};
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int** zT_40;
    unsigned int* zT_41;
    unsigned int* zT_42;
    zT_3E40CD83_Sand* zT_43;
    unsigned int zT_44;
    zT_B559F9DA_Parser* zT_49;
    zT_3A355BD2_Token zT_50 = {0};
    zT_EAC3E484_TokenKind zT_51;
    zT_B559F9DA_Parser* zT_55;
    zT_3A355BD2_Token zT_56 = {0};
    zT_B559F9DA_Parser* zT_58;
    zT_CB78802F_EU_49 zT_62 = {0};
    unsigned char zT_63;
    int zT_64;
    zT_3B6EA323_EU_01 zT_65;
    zT_2B3424E9_ParseToken zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_76;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_77;
    unsigned int* zT_79;
    unsigned int zT_80;
    unsigned int* zT_81;
    unsigned int zT_82;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83;
    unsigned int zT_84 = 0;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_88;
    unsigned int zT_90;
    unsigned int zT_93;
    int zT_97;
    unsigned int zT_100;
    unsigned short zT_101;
    int zT_104;
    int zT_106;
    unsigned int zT_108 = 0;
    zT_3B6EA323_EU_01 zT_109;
    zT_3A355BD2_Token tok;
    unsigned int type_node;
    unsigned int saved_child_len;
    unsigned int val;
    zT_2B3424E9_ParseToken rbrace;
    zT_8F083A69_Slice_zT_0B42B2F8_u gap;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_2BC32683_parserParseBracketT(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    type_node = zT_8;
    zT_9 = self;
    zT_10 = zF_068A2DE5_parserPeek(zT_9);
    zT_11 = zT_10.kind;
    if ((unsigned char)(zT_11 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.data.payload = type_node;
    zT_15.is_error = 0;
    return zT_15;
    z_bb_5:
    zT_16 = self;
    zT_17 = zF_C241B2C4_parserAdvance(zT_16);
    (void)zT_17;
    zT_19 = self->child_buf_len;
    saved_child_len = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = self;
    zT_21 = zF_068A2DE5_parserPeek(zT_20);
    zT_22 = zT_21.kind;
    if ((unsigned char)(zT_22 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_10; else goto z_bb_11;
    z_bb_7:
    zT_34 = self;
    zT_37 = zF_F07C1F04_parserParseExprPrec(zT_34, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_38 = zT_37.is_error;
    if (zT_38) goto z_bb_13; else goto z_bb_14;
    z_bb_8:
    zT_58 = self;
    zT_62 = zF_5578C74F_parserExpect(zT_58, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_63 = zT_62.is_error;
    if (zT_63) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_27 = self;
    zT_28 = zF_068A2DE5_parserPeek(zT_27);
    zT_29 = zT_28.kind;
    zT_26 = zT_29 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_12;
    z_bb_11:
    zT_26 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_26) goto z_bb_7; else goto z_bb_8;
    z_bb_13:
    return zT_37;
    z_bb_14:
    zT_39 = zT_37.data.payload;
    goto z_bb_15;
    z_bb_15:
    val = zT_39;
    zT_40 = &self->child_buf_items;
    zT_41 = &self->child_buf_len;
    zT_42 = &self->child_buf_capacity;
    zT_43 = self->allocator;
    zT_44 = val;
    zF_8B163A32_u32ArrayListAppendI(zT_40, zT_41, zT_42, zT_43, zT_44);
    zT_49 = self;
    zT_50 = zF_068A2DE5_parserPeek(zT_49);
    zT_51 = zT_50.kind;
    if ((unsigned char)(zT_51 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_55 = self;
    zT_56 = zF_C241B2C4_parserAdvance(zT_55);
    (void)zT_56;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_9;
    z_bb_18:
    zT_64 = zT_62.data.err;
    zT_65.data.err = zT_64;
    zT_65.is_error = 1;
    return zT_65;
    z_bb_19:
    zT_66 = zT_62.data.payload;
    goto z_bb_20;
    z_bb_20:
    rbrace = zT_66;
    zT_68 = "";
    zT_70 = 0;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    gap = zT_69;
    (void)gap;
    zT_72 = 0;
    zT_73 = (unsigned int)zT_72;
    payload = zT_73;
    zT_74 = self->child_buf_len;
    if ((unsigned char)(zT_74 > saved_child_len)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_76 = self->store;
    zT_79 = self->child_buf_items;
    zT_80 = self->child_buf_len;
    zT_81 = zT_79 + saved_child_len;
    zT_82 = zT_80 - saved_child_len;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_77 = zT_83;
    zT_84 = zF_583E993C_astStoreAddExtraChi(zT_76, zT_77);
    payload = zT_84;
    goto z_bb_22;
    z_bb_22:
    self->child_buf_len = saved_child_len;
    zT_85 = self->store;
    zT_97 = 0;
    zT_88 = tok.span_start;
    zT_100 = rbrace.span_start;
    zT_101 = rbrace.span_len;
    zT_90 = type_node;
    zT_104 = 0;
    zT_106 = 0;
    zT_93 = payload;
    zT_108 = zF_6C9FF72F_astStoreAddNode(zT_85, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init), (unsigned char)((unsigned char)zT_97), zT_88, (unsigned int)(zT_100 + (unsigned int)((unsigned int)zT_101)), zT_90, (unsigned int)((unsigned int)zT_104), (unsigned int)((unsigned int)zT_106), zT_93);
    zT_109.data.payload = zT_108;
    zT_109.is_error = 0;
    return zT_109;
}

/* parserParseIfExpr */
zT_3B6EA323_EU_01 zF_79089D39_parserParseIfExpr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    zT_2B3424E9_ParseToken zT_41 = {0};
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    zT_B559F9DA_Parser* zT_48;
    zT_CB78802F_EU_49 zT_52 = {0};
    unsigned char zT_53;
    int zT_54;
    zT_3B6EA323_EU_01 zT_55;
    zT_2B3424E9_ParseToken zT_56;
    zT_B559F9DA_Parser* zT_57;
    zT_CB78802F_EU_49 zT_61 = {0};
    unsigned char zT_62;
    int zT_63;
    zT_3B6EA323_EU_01 zT_64;
    zT_2B3424E9_ParseToken zT_65;
    zT_B559F9DA_Parser* zT_66;
    zT_CB78802F_EU_49 zT_70 = {0};
    unsigned char zT_71;
    int zT_72;
    zT_3B6EA323_EU_01 zT_73;
    zT_2B3424E9_ParseToken zT_74;
    zT_2B3424E9_ParseToken zT_76;
    zT_EAC3E484_TokenKind zT_77;
    unsigned int zT_78;
    unsigned short zT_79;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_B559F9DA_Parser* zT_84;
    zT_2B3424E9_ParseToken zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86 = {0};
    unsigned int zT_87 = 0;
    zT_6B0A7D14_AstStore* zT_88;
    unsigned int zT_91;
    unsigned int zT_96;
    int zT_100;
    unsigned int zT_103;
    unsigned short zT_104;
    int zT_107;
    int zT_109;
    int zT_111;
    unsigned int zT_113 = 0;
    zT_B559F9DA_Parser* zT_115;
    zT_3B6EA323_EU_01 zT_118 = {0};
    unsigned char zT_119;
    unsigned int zT_120;
    int zT_122;
    unsigned int zT_123;
    zT_B559F9DA_Parser* zT_124;
    zT_3A355BD2_Token zT_125 = {0};
    zT_EAC3E484_TokenKind zT_126;
    zT_B559F9DA_Parser* zT_130;
    zT_3A355BD2_Token zT_131 = {0};
    zT_B559F9DA_Parser* zT_132;
    zT_3B6EA323_EU_01 zT_135 = {0};
    unsigned char zT_136;
    unsigned int zT_137;
    unsigned int zT_139;
    unsigned char zT_140;
    zT_3A355BD2_Token zT_142;
    unsigned int zT_143;
    unsigned short zT_144;
    unsigned int zT_146;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    int zT_159;
    unsigned int zT_162 = 0;
    zT_3B6EA323_EU_01 zT_163;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_node;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int then_body;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int else_body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    capture_node = zT_31;
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    zT_34 = zT_33.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_38 = self;
    zT_39 = zF_C241B2C4_parserAdvance(zT_38);
    (void)zT_39;
    name_tok = zT_41;
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    zT_44 = zT_43.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_115 = self;
    zT_118 = zF_F07C1F04_parserParseExprPrec(zT_115, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_119 = zT_118.is_error;
    if (zT_119) goto z_bb_24; else goto z_bb_25;
    z_bb_12:
    zT_48 = self;
    zT_52 = zF_5578C74F_parserExpect(zT_48, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_66 = self;
    zT_70 = zF_5578C74F_parserExpect(zT_66, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_57 = self;
    zT_61 = zF_5578C74F_parserExpect(zT_57, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_62 = zT_61.is_error;
    if (zT_62) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_54 = zT_52.data.err;
    zT_55.data.err = zT_54;
    zT_55.is_error = 1;
    return zT_55;
    z_bb_16:
    zT_56 = zT_52.data.payload;
    goto z_bb_17;
    z_bb_17:
    name_tok = zT_56;
    goto z_bb_13;
    z_bb_18:
    zT_63 = zT_61.data.err;
    zT_64.data.err = zT_63;
    zT_64.is_error = 1;
    return zT_64;
    z_bb_19:
    zT_65 = zT_61.data.payload;
    goto z_bb_20;
    z_bb_20:
    name_tok = zT_65;
    goto z_bb_13;
    z_bb_21:
    zT_72 = zT_70.data.err;
    zT_73.data.err = zT_72;
    zT_73.is_error = 1;
    return zT_73;
    z_bb_22:
    zT_74 = zT_70.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_74;
    zT_77 = name_tok.kind;
    zT_76.kind = zT_77;
    zT_78 = name_tok.span_start;
    zT_76.span_start = zT_78;
    zT_79 = name_tok.span_len;
    zT_76.span_len = zT_79;
    pt = zT_76;
    zT_81 = self->interner;
    zT_84 = self;
    zT_85 = pt;
    zT_86 = zF_08D61E58_parserTokenText(zT_84, zT_85);
    zT_82 = zT_86;
    zT_87 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    name_id = zT_87;
    zT_88 = self->store;
    zT_100 = 0;
    zT_91 = name_tok.span_start;
    zT_103 = name_tok.span_start;
    zT_104 = name_tok.span_len;
    zT_107 = 0;
    zT_109 = 0;
    zT_111 = 0;
    zT_96 = name_id;
    zT_113 = zF_6C9FF72F_astStoreAddNode(zT_88, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_100), zT_91, (unsigned int)(zT_103 + (unsigned int)((unsigned int)zT_104)), (unsigned int)((unsigned int)zT_107), (unsigned int)((unsigned int)zT_109), (unsigned int)((unsigned int)zT_111), zT_96);
    capture_node = zT_113;
    goto z_bb_11;
    z_bb_24:
    return zT_118;
    z_bb_25:
    zT_120 = zT_118.data.payload;
    goto z_bb_26;
    z_bb_26:
    then_body = zT_120;
    zT_122 = 0;
    zT_123 = (unsigned int)zT_122;
    else_body = zT_123;
    zT_124 = self;
    zT_125 = zF_068A2DE5_parserPeek(zT_124);
    zT_126 = zT_125.kind;
    if ((unsigned char)(zT_126 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_130 = self;
    zT_131 = zF_C241B2C4_parserAdvance(zT_130);
    (void)zT_131;
    zT_132 = self;
    zT_135 = zF_F07C1F04_parserParseExprPrec(zT_132, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_136 = zT_135.is_error;
    if (zT_136) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_139 = kw.span_start;
    end_pos = zT_139;
    zT_140 = self->last_tok_valid;
    if (zT_140) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    return zT_135;
    z_bb_30:
    zT_137 = zT_135.data.payload;
    goto z_bb_31;
    z_bb_31:
    else_body = zT_137;
    goto z_bb_28;
    z_bb_32:
    zT_142 = self->last_tok;
    last = zT_142;
    zT_143 = last.span_start;
    zT_144 = last.span_len;
    zT_146 = zT_143 + (unsigned int)((unsigned int)zT_144);
    end_pos = zT_146;
    goto z_bb_33;
    z_bb_33:
    zT_147 = self->store;
    zT_159 = 0;
    zT_150 = kw.span_start;
    zT_151 = end_pos;
    zT_152 = cond;
    zT_153 = then_body;
    zT_154 = else_body;
    zT_155 = capture_node;
    zT_162 = zF_6C9FF72F_astStoreAddNode(zT_147, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr), (unsigned char)((unsigned char)zT_159), zT_150, zT_151, zT_152, zT_153, zT_154, zT_155);
    zT_163.data.payload = zT_162;
    zT_163.is_error = 0;
    return zT_163;
}

/* parserParseSwitchExpr */
zT_3B6EA323_EU_01 zF_A9AC92CA_parserParseSwitchEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    zT_B559F9DA_Parser* zT_29;
    zT_CB78802F_EU_49 zT_33 = {0};
    unsigned char zT_34;
    int zT_35;
    zT_3B6EA323_EU_01 zT_36;
    zT_2B3424E9_ParseToken zT_37;
    unsigned int zT_39;
    zT_B559F9DA_Parser* zT_42;
    zT_3A355BD2_Token zT_43 = {0};
    zT_EAC3E484_TokenKind zT_44;
    zT_EAC3E484_TokenKind zT_48;
    zT_B559F9DA_Parser* zT_53;
    zT_3B6EA323_EU_01 zT_54 = {0};
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned int** zT_57;
    unsigned int* zT_58;
    unsigned int* zT_59;
    zT_3E40CD83_Sand* zT_60;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_66;
    zT_3A355BD2_Token zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_72;
    zT_3A355BD2_Token zT_73 = {0};
    zT_B559F9DA_Parser* zT_74;
    zT_CB78802F_EU_49 zT_78 = {0};
    unsigned char zT_79;
    int zT_80;
    zT_3B6EA323_EU_01 zT_81;
    zT_2B3424E9_ParseToken zT_82;
    int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_6B0A7D14_AstStore* zT_88;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_89;
    unsigned int* zT_91;
    unsigned int zT_92;
    unsigned int* zT_93;
    unsigned int zT_94;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_95;
    unsigned int zT_96 = 0;
    unsigned int zT_98;
    unsigned short zT_99;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_111;
    int zT_115;
    int zT_118;
    int zT_120;
    unsigned int zT_122 = 0;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_124;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    int zT_130;
    unsigned char* zT_131;
    unsigned int zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134 = 0;
    unsigned int zT_138;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned char* zT_148;
    unsigned int zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_157;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    int zT_163;
    unsigned char* zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167 = 0;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned char* zT_176;
    unsigned int zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    zT_3B6EA323_EU_01 zT_184;
    zT_3A355BD2_Token kw_tok;
    unsigned int cond;
    unsigned int saved_switch;
    zT_3A355BD2_Token tok;
    unsigned int prong;
    unsigned int payload;
    unsigned int end_pos;
    unsigned int pswe_node;
    zT_5A26C2ED_Arr_unsigned_char_1 pswe_b;
    unsigned int pswe_l;
    unsigned int pswe_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 pswe_pb;
    unsigned int pswe_pl;
    unsigned int pswe_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pswe_nl;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_29 = self;
    zT_33 = zF_5578C74F_parserExpect(zT_29, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = zT_33.data.err;
    zT_36.data.err = zT_35;
    zT_36.is_error = 1;
    return zT_36;
    z_bb_11:
    zT_37 = zT_33.data.payload;
    goto z_bb_12;
    z_bb_12:
    (void)zT_37;
    zT_39 = self->child_buf_len;
    saved_switch = zT_39;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(1)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_42 = self;
    zT_43 = zF_068A2DE5_parserPeek(zT_42);
    tok = zT_43;
    zT_44 = tok.kind;
    if ((unsigned char)(zT_44 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    zT_74 = self;
    zT_78 = zF_5578C74F_parserExpect(zT_74, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_79 = zT_78.is_error;
    if (zT_79) goto z_bb_26; else goto z_bb_27;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_48 = tok.kind;
    if ((unsigned char)(zT_48 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_53 = self;
    zT_54 = zF_CB4EC4E3_parserParseSwitchPr(zT_53);
    zT_55 = zT_54.is_error;
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return zT_54;
    z_bb_22:
    zT_56 = zT_54.data.payload;
    goto z_bb_23;
    z_bb_23:
    prong = zT_56;
    zT_57 = &self->child_buf_items;
    zT_58 = &self->child_buf_len;
    zT_59 = &self->child_buf_capacity;
    zT_60 = self->allocator;
    zT_61 = prong;
    zF_8B163A32_u32ArrayListAppendI(zT_57, zT_58, zT_59, zT_60, zT_61);
    zT_66 = self;
    zT_67 = zF_068A2DE5_parserPeek(zT_66);
    zT_68 = zT_67.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_72 = self;
    zT_73 = zF_C241B2C4_parserAdvance(zT_72);
    (void)zT_73;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_16;
    z_bb_26:
    zT_80 = zT_78.data.err;
    zT_81.data.err = zT_80;
    zT_81.is_error = 1;
    return zT_81;
    z_bb_27:
    zT_82 = zT_78.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_82;
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    payload = zT_85;
    zT_86 = self->child_buf_len;
    if ((unsigned char)(zT_86 > saved_switch)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_88 = self->store;
    zT_91 = self->child_buf_items;
    zT_92 = self->child_buf_len;
    zT_93 = zT_91 + saved_switch;
    zT_94 = zT_92 - saved_switch;
    zT_95.ptr = zT_93;
    zT_95.len = zT_94;
    zT_89 = zT_95;
    zT_96 = zF_583E993C_astStoreAddExtraChi(zT_88, zT_89);
    payload = zT_96;
    goto z_bb_30;
    z_bb_30:
    self->child_buf_len = saved_switch;
    zT_98 = kw_tok.span_start;
    zT_99 = kw_tok.span_len;
    zT_101 = zT_98 + (unsigned int)((unsigned int)zT_99);
    end_pos = zT_101;
    zT_103 = self->store;
    zT_115 = 0;
    zT_106 = kw_tok.span_start;
    zT_107 = end_pos;
    zT_108 = cond;
    zT_118 = 0;
    zT_120 = 0;
    zT_111 = payload;
    zT_122 = zF_6C9FF72F_astStoreAddNode(zT_103, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex), (unsigned char)((unsigned char)zT_115), zT_106, zT_107, zT_108, (unsigned int)((unsigned int)zT_118), (unsigned int)((unsigned int)zT_120), zT_111);
    pswe_node = zT_122;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_124[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pswe_b[_i] = zT_124[_i];
        _i++;
    }
}
    zT_126 = pswe_node;
    zT_130 = 0;
    zT_131 = (unsigned char*)((unsigned char*)pswe_b) + zT_130;
    zT_132 = (unsigned int)(10) - zT_130;
    zT_133.ptr = zT_131;
    zT_133.len = zT_132;
    zT_127 = zT_133;
    zT_134 = zF_A7504564_itoa(zT_126, zT_127);
    pswe_l = zT_134;
    zT_138 = (unsigned int)(9) - (unsigned int)((unsigned int)pswe_l);
    pswe_s = zT_138;
    zT_140 = "PSWE:n";
    zT_142 = 6;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    pswe_m = zT_141;
    zT_143 = pswe_m;
    zF_48AC7B3A_markerWrite(zT_143);
    zT_148 = (unsigned char*)((unsigned char*)pswe_b) + pswe_s;
    zT_149 = (unsigned int)(9) - pswe_s;
    zT_150.ptr = zT_148;
    zT_150.len = zT_149;
    zT_144 = zT_150;
    zF_48AC7B3A_markerWrite(zT_144);
    zT_152 = "p";
    zT_154 = 1;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    pswe_pm = zT_153;
    zT_155 = pswe_pm;
    zF_48AC7B3A_markerWrite(zT_155);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_157[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pswe_pb[_i] = zT_157[_i];
        _i++;
    }
}
    zT_159 = payload;
    zT_163 = 0;
    zT_164 = (unsigned char*)((unsigned char*)pswe_pb) + zT_163;
    zT_165 = (unsigned int)(10) - zT_163;
    zT_166.ptr = zT_164;
    zT_166.len = zT_165;
    zT_160 = zT_166;
    zT_167 = zF_A7504564_itoa(zT_159, zT_160);
    pswe_pl = zT_167;
    zT_171 = (unsigned int)(9) - (unsigned int)((unsigned int)pswe_pl);
    pswe_ps = zT_171;
    zT_176 = (unsigned char*)((unsigned char*)pswe_pb) + pswe_ps;
    zT_177 = (unsigned int)(9) - pswe_ps;
    zT_178.ptr = zT_176;
    zT_178.len = zT_177;
    zT_172 = zT_178;
    zF_48AC7B3A_markerWrite(zT_172);
    zT_180 = "\n";
    zT_182 = 1;
    zT_181.ptr = zT_180;
    zT_181.len = zT_182;
    pswe_nl = zT_181;
    zT_183 = pswe_nl;
    zF_48AC7B3A_markerWrite(zT_183);
    zT_184.data.payload = pswe_node;
    zT_184.is_error = 0;
    return zT_184;
}

/* parserParseSwitchProng */
zT_3B6EA323_EU_01 zF_CB4EC4E3_parserParseSwitchPr(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int* zT_5 = 0;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned char zT_14;
    zT_B559F9DA_Parser* zT_15;
    zT_3A355BD2_Token zT_16 = {0};
    zT_EAC3E484_TokenKind zT_17;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_B559F9DA_Parser* zT_27;
    zT_3A355BD2_Token zT_28 = {0};
    zT_EAC3E484_TokenKind zT_29;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32 = {0};
    int zT_33;
    unsigned char zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_B559F9DA_Parser* zT_42;
    zT_3B6EA323_EU_01 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_50;
    int zT_52;
    unsigned int zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3A355BD2_Token zT_61 = {0};
    zT_B559F9DA_Parser* zT_62;
    zT_3B6EA323_EU_01 zT_65 = {0};
    unsigned char zT_66;
    unsigned int zT_67;
    zT_8143F551_AstKind zT_69;
    zT_B559F9DA_Parser* zT_70;
    zT_3A355BD2_Token zT_71 = {0};
    zT_EAC3E484_TokenKind zT_72;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_B559F9DA_Parser* zT_78;
    zT_3B6EA323_EU_01 zT_81 = {0};
    unsigned char zT_82;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_85;
    zT_6B0A7D14_AstStore* zT_90;
    zT_8143F551_AstKind zT_91;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_96;
    int zT_100;
    unsigned int zT_103;
    unsigned short zT_104;
    int zT_107;
    int zT_109;
    unsigned int zT_111 = 0;
    unsigned int** zT_112;
    unsigned int* zT_113;
    unsigned int* zT_114;
    zT_3E40CD83_Sand* zT_115;
    unsigned int zT_116;
    unsigned int** zT_121;
    unsigned int* zT_122;
    unsigned int* zT_123;
    zT_3E40CD83_Sand* zT_124;
    unsigned int zT_125;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_B559F9DA_Parser* zT_137;
    zT_3A355BD2_Token zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    zT_B559F9DA_Parser* zT_143;
    int zT_145;
    zT_3A355BD2_Token zT_147 = {0};
    zT_EAC3E484_TokenKind zT_148;
    zT_B559F9DA_Parser* zT_152;
    zT_3A355BD2_Token zT_153 = {0};
    zT_B559F9DA_Parser* zT_154;
    zT_CB78802F_EU_49 zT_158 = {0};
    unsigned char zT_159;
    int zT_160;
    zT_3B6EA323_EU_01 zT_161;
    zT_2B3424E9_ParseToken zT_162;
    int zT_164;
    unsigned char zT_165;
    int zT_167;
    unsigned int zT_168;
    zT_B559F9DA_Parser* zT_169;
    zT_3A355BD2_Token zT_170 = {0};
    zT_EAC3E484_TokenKind zT_171;
    zT_B559F9DA_Parser* zT_175;
    zT_3A355BD2_Token zT_176 = {0};
    zT_2B3424E9_ParseToken zT_178 = {0};
    zT_B559F9DA_Parser* zT_179;
    zT_3A355BD2_Token zT_180 = {0};
    zT_EAC3E484_TokenKind zT_181;
    zT_B559F9DA_Parser* zT_185;
    zT_CB78802F_EU_49 zT_189 = {0};
    unsigned char zT_190;
    int zT_191;
    zT_3B6EA323_EU_01 zT_192;
    zT_2B3424E9_ParseToken zT_193;
    zT_B559F9DA_Parser* zT_194;
    zT_CB78802F_EU_49 zT_198 = {0};
    unsigned char zT_199;
    int zT_200;
    zT_3B6EA323_EU_01 zT_201;
    zT_2B3424E9_ParseToken zT_202;
    zT_B559F9DA_Parser* zT_203;
    zT_CB78802F_EU_49 zT_207 = {0};
    unsigned char zT_208;
    int zT_209;
    zT_3B6EA323_EU_01 zT_210;
    zT_2B3424E9_ParseToken zT_211;
    zT_2B3424E9_ParseToken zT_213;
    zT_EAC3E484_TokenKind zT_214;
    unsigned int zT_215;
    unsigned short zT_216;
    zT_D3EB6303_StringInterner* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_B559F9DA_Parser* zT_220;
    zT_2B3424E9_ParseToken zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222 = {0};
    unsigned int zT_223 = 0;
    int zT_224;
    unsigned char zT_225;
    unsigned char* zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    unsigned int zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_232;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    int zT_238;
    unsigned char* zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242 = 0;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned char* zT_251;
    unsigned int zT_252;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_253;
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    int zT_259;
    int zT_261;
    unsigned char zT_262;
    unsigned int zT_264 = 0;
    zT_B559F9DA_Parser* zT_265;
    zT_3A355BD2_Token zT_266 = {0};
    zT_EAC3E484_TokenKind zT_267;
    zT_B559F9DA_Parser* zT_271;
    zT_3B6EA323_EU_01 zT_272 = {0};
    unsigned char zT_273;
    unsigned int zT_274;
    zT_B559F9DA_Parser* zT_275;
    zT_3B6EA323_EU_01 zT_278 = {0};
    unsigned char zT_279;
    unsigned int zT_280;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    int zT_294;
    unsigned char* zT_295;
    unsigned int zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298 = 0;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char* zT_307;
    unsigned int zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    unsigned char* zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    int zT_323;
    unsigned char* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327 = 0;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned char* zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    unsigned char* zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned int zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    zT_6B0A7D14_AstStore* zT_352;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_353;
    int zT_355;
    unsigned int* zT_356;
    unsigned int zT_357;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_358;
    unsigned int zT_359 = 0;
    unsigned char* zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    unsigned int zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_366;
    unsigned int zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    int zT_372;
    unsigned char* zT_373;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    unsigned int zT_376 = 0;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned char* zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned char* zT_389;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    unsigned int zT_391;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    unsigned int zT_394;
    unsigned short zT_395;
    unsigned int zT_397;
    zT_6B0A7D14_AstStore* zT_398;
    unsigned char zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned int zT_406;
    int zT_411;
    unsigned int zT_413 = 0;
    zT_3B6EA323_EU_01 zT_414;
    zT_3A355BD2_Token start_tok;
    unsigned int* case_items;
    unsigned int case_len;
    unsigned int case_cap;
    unsigned char is_else;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_em;
    unsigned int item;
    zT_8143F551_AstKind range_kind;
    unsigned int end_item;
    unsigned int range_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb2_m;
    unsigned char flags;
    unsigned int capture_name;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken pt;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpm;
    zT_5A26C2ED_Arr_unsigned_char_1 cpnb;
    unsigned int cpnl;
    unsigned int cpns;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpem;
    unsigned int body;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pcb_nb;
    unsigned int pcb_nl;
    unsigned int pcb_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 pcb_pb;
    unsigned int pcb_pl;
    unsigned int pcb_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcb_sm;
    unsigned int items_payload;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppl_m;
    zT_5A26C2ED_Arr_unsigned_char_1 ppl_pb;
    unsigned int ppl_pl;
    unsigned int ppl_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppl_n;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    start_tok = zT_3;
    case_items = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    case_len = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    case_cap = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned char)zT_13;
    is_else = zT_14;
    zT_15 = self;
    zT_16 = zF_068A2DE5_parserPeek(zT_15);
    zT_17 = zT_16.kind;
    if ((unsigned char)(zT_17 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_22 = "PCB:T";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    pcb_tm = zT_23;
    zT_25 = pcb_tm;
    zT_27 = self;
    zT_28 = zF_068A2DE5_parserPeek(zT_27);
    zT_29 = zT_28.kind;
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)zT_29));
    zT_31 = self;
    zT_32 = zF_C241B2C4_parserAdvance(zT_31);
    (void)zT_32;
    zT_33 = 1;
    zT_34 = (unsigned char)zT_33;
    is_else = zT_34;
    goto z_bb_2;
    z_bb_2:
    zT_154 = self;
    zT_158 = zF_5578C74F_parserExpect(zT_154, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow));
    zT_159 = zT_158.is_error;
    if (zT_159) goto z_bb_29; else goto z_bb_30;
    z_bb_3:
    zT_36 = "PCB:E";
    zT_38 = 5;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    pcb_em = zT_37;
    zT_39 = pcb_em;
    zF_48AC7B3A_markerWrite(zT_39);
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(1)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_42 = self;
    zT_45 = zF_F07C1F04_parserParseExprPrec(zT_42, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    return zT_45;
    z_bb_9:
    zT_47 = zT_45.data.payload;
    goto z_bb_10;
    z_bb_10:
    item = zT_47;
    zT_50 = zT_8143F551_AstKind_err;
    range_kind = zT_50;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    end_item = zT_53;
    zT_54 = self;
    zT_55 = zF_068A2DE5_parserPeek(zT_54);
    zT_56 = zT_55.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_60 = self;
    zT_61 = zF_C241B2C4_parserAdvance(zT_60);
    (void)zT_61;
    zT_62 = self;
    zT_65 = zF_F07C1F04_parserParseExprPrec(zT_62, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    if ((unsigned char)(range_kind != (zT_8143F551_AstKind)(zT_8143F551_AstKind_err))) goto z_bb_22; else goto z_bb_24;
    z_bb_13:
    zT_70 = self;
    zT_71 = zF_068A2DE5_parserPeek(zT_70);
    zT_72 = zT_71.kind;
    if ((unsigned char)(zT_72 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    return zT_65;
    z_bb_15:
    zT_67 = zT_65.data.payload;
    goto z_bb_16;
    z_bb_16:
    end_item = zT_67;
    zT_69 = zT_8143F551_AstKind_range_exclusive;
    range_kind = zT_69;
    goto z_bb_12;
    z_bb_17:
    zT_76 = self;
    zT_77 = zF_C241B2C4_parserAdvance(zT_76);
    (void)zT_77;
    zT_78 = self;
    zT_81 = zF_F07C1F04_parserParseExprPrec(zT_78, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    return zT_81;
    z_bb_20:
    zT_83 = zT_81.data.payload;
    goto z_bb_21;
    z_bb_21:
    end_item = zT_83;
    zT_85 = zT_8143F551_AstKind_range_inclusive;
    range_kind = zT_85;
    goto z_bb_18;
    z_bb_22:
    zT_90 = self->store;
    zT_91 = range_kind;
    zT_100 = 0;
    zT_93 = start_tok.span_start;
    zT_103 = start_tok.span_start;
    zT_104 = start_tok.span_len;
    zT_95 = item;
    zT_96 = end_item;
    zT_107 = 0;
    zT_109 = 0;
    zT_111 = zF_6C9FF72F_astStoreAddNode(zT_90, zT_91, (unsigned char)((unsigned char)zT_100), zT_93, (unsigned int)(zT_103 + (unsigned int)((unsigned int)zT_104)), zT_95, zT_96, (unsigned int)((unsigned int)zT_107), (unsigned int)((unsigned int)zT_109));
    range_node = zT_111;
    zT_112 = &case_items;
    zT_113 = &case_len;
    zT_114 = &case_cap;
    zT_115 = self->allocator;
    zT_116 = range_node;
    zF_8B163A32_u32ArrayListAppendI(zT_112, zT_113, zT_114, zT_115, zT_116);
    goto z_bb_23;
    z_bb_23:
    zT_137 = self;
    zT_138 = zF_068A2DE5_parserPeek(zT_137);
    zT_139 = zT_138.kind;
    if ((unsigned char)(zT_139 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_121 = &case_items;
    zT_122 = &case_len;
    zT_123 = &case_cap;
    zT_124 = self->allocator;
    zT_125 = item;
    zF_8B163A32_u32ArrayListAppendI(zT_121, zT_122, zT_123, zT_124, zT_125);
    zT_131 = "PCB:B";
    zT_133 = 5;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    pcb2_m = zT_132;
    zT_134 = pcb2_m;
    zF_C914CB83_markerWriteInt(zT_134, (unsigned int)((unsigned int)case_len));
    goto z_bb_23;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_143 = self;
    zT_145 = 1;
    zT_147 = zF_F685E431_parserPeekN(zT_143, (unsigned int)((unsigned int)zT_145));
    zT_148 = zT_147.kind;
    if ((unsigned char)(zT_148 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_152 = self;
    zT_153 = zF_C241B2C4_parserAdvance(zT_152);
    (void)zT_153;
    goto z_bb_7;
    z_bb_29:
    zT_160 = zT_158.data.err;
    zT_161.data.err = zT_160;
    zT_161.is_error = 1;
    return zT_161;
    z_bb_30:
    zT_162 = zT_158.data.payload;
    goto z_bb_31;
    z_bb_31:
    (void)zT_162;
    zT_164 = 0;
    zT_165 = (unsigned char)zT_164;
    flags = zT_165;
    zT_167 = 0;
    zT_168 = (unsigned int)zT_167;
    capture_name = zT_168;
    zT_169 = self;
    zT_170 = zF_068A2DE5_parserPeek(zT_169);
    zT_171 = zT_170.kind;
    if ((unsigned char)(zT_171 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_175 = self;
    zT_176 = zF_C241B2C4_parserAdvance(zT_175);
    (void)zT_176;
    name_tok = zT_178;
    zT_179 = self;
    zT_180 = zF_068A2DE5_parserPeek(zT_179);
    zT_181 = zT_180.kind;
    if ((unsigned char)(zT_181 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_259 = 0;
    if ((unsigned char)(is_else != zT_259)) goto z_bb_46; else goto z_bb_47;
    z_bb_34:
    zT_185 = self;
    zT_189 = zF_5578C74F_parserExpect(zT_185, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_190 = zT_189.is_error;
    if (zT_190) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_203 = self;
    zT_207 = zF_5578C74F_parserExpect(zT_203, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_208 = zT_207.is_error;
    if (zT_208) goto z_bb_43; else goto z_bb_44;
    z_bb_36:
    zT_194 = self;
    zT_198 = zF_5578C74F_parserExpect(zT_194, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_199 = zT_198.is_error;
    if (zT_199) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_191 = zT_189.data.err;
    zT_192.data.err = zT_191;
    zT_192.is_error = 1;
    return zT_192;
    z_bb_38:
    zT_193 = zT_189.data.payload;
    goto z_bb_39;
    z_bb_39:
    name_tok = zT_193;
    goto z_bb_35;
    z_bb_40:
    zT_200 = zT_198.data.err;
    zT_201.data.err = zT_200;
    zT_201.is_error = 1;
    return zT_201;
    z_bb_41:
    zT_202 = zT_198.data.payload;
    goto z_bb_42;
    z_bb_42:
    name_tok = zT_202;
    goto z_bb_35;
    z_bb_43:
    zT_209 = zT_207.data.err;
    zT_210.data.err = zT_209;
    zT_210.is_error = 1;
    return zT_210;
    z_bb_44:
    zT_211 = zT_207.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_211;
    zT_214 = name_tok.kind;
    zT_213.kind = zT_214;
    zT_215 = name_tok.span_start;
    zT_213.span_start = zT_215;
    zT_216 = name_tok.span_len;
    zT_213.span_len = zT_216;
    pt = zT_213;
    zT_217 = self->interner;
    zT_220 = self;
    zT_221 = pt;
    zT_222 = zF_08D61E58_parserTokenText(zT_220, zT_221);
    zT_218 = zT_222;
    zT_223 = zF_50C274AF_stringInternerInter(zT_217, zT_218);
    capture_name = zT_223;
    zT_224 = 16;
    zT_225 = (unsigned char)zT_224;
    flags = zT_225;
    zT_227 = "CPT:n";
    zT_229 = 5;
    zT_228.ptr = zT_227;
    zT_228.len = zT_229;
    cpm = zT_228;
    zT_230 = cpm;
    zF_48AC7B3A_markerWrite(zT_230);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_232[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpnb[_i] = zT_232[_i];
        _i++;
    }
}
    zT_234 = capture_name;
    zT_238 = 0;
    zT_239 = (unsigned char*)((unsigned char*)cpnb) + zT_238;
    zT_240 = (unsigned int)(10) - zT_238;
    zT_241.ptr = zT_239;
    zT_241.len = zT_240;
    zT_235 = zT_241;
    zT_242 = zF_A7504564_itoa(zT_234, zT_235);
    cpnl = zT_242;
    zT_246 = (unsigned int)(9) - (unsigned int)((unsigned int)cpnl);
    cpns = zT_246;
    zT_251 = (unsigned char*)((unsigned char*)cpnb) + cpns;
    zT_252 = (unsigned int)(9) - cpns;
    zT_253.ptr = zT_251;
    zT_253.len = zT_252;
    zT_247 = zT_253;
    zF_48AC7B3A_markerWrite(zT_247);
    zT_255 = "\n";
    zT_257 = 1;
    zT_256.ptr = zT_255;
    zT_256.len = zT_257;
    cpem = zT_256;
    zT_258 = cpem;
    zF_48AC7B3A_markerWrite(zT_258);
    goto z_bb_33;
    z_bb_46:
    zT_261 = 1;
    zT_262 = flags | zT_261;
    flags = zT_262;
    goto z_bb_47;
    z_bb_47:
    body = zT_264;
    zT_265 = self;
    zT_266 = zF_068A2DE5_parserPeek(zT_265);
    zT_267 = zT_266.kind;
    if ((unsigned char)(zT_267 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_48; else goto z_bb_50;
    z_bb_48:
    zT_271 = self;
    zT_272 = zF_365CA04A_parserParseBlock(zT_271);
    zT_273 = zT_272.is_error;
    if (zT_273) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    zT_282 = "PCB:n";
    zT_284 = 5;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pcb_m = zT_283;
    zT_285 = pcb_m;
    zF_48AC7B3A_markerWrite(zT_285);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_287[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pcb_nb[_i] = zT_287[_i];
        _i++;
    }
}
    zT_294 = 0;
    zT_295 = (unsigned char*)((unsigned char*)pcb_nb) + zT_294;
    zT_296 = (unsigned int)(10) - zT_294;
    zT_297.ptr = zT_295;
    zT_297.len = zT_296;
    zT_290 = zT_297;
    zT_298 = zF_A7504564_itoa((unsigned int)((unsigned int)case_len), zT_290);
    pcb_nl = zT_298;
    zT_302 = (unsigned int)(9) - (unsigned int)((unsigned int)pcb_nl);
    pcb_ns = zT_302;
    zT_307 = (unsigned char*)((unsigned char*)pcb_nb) + pcb_ns;
    zT_308 = (unsigned int)(9) - pcb_ns;
    zT_309.ptr = zT_307;
    zT_309.len = zT_308;
    zT_303 = zT_309;
    zF_48AC7B3A_markerWrite(zT_303);
    zT_311 = "p=";
    zT_313 = 2;
    zT_312.ptr = zT_311;
    zT_312.len = zT_313;
    pcb_pm = zT_312;
    zT_314 = pcb_pm;
    zF_48AC7B3A_markerWrite(zT_314);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_316[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pcb_pb[_i] = zT_316[_i];
        _i++;
    }
}
    zT_323 = 0;
    zT_324 = (unsigned char*)((unsigned char*)pcb_pb) + zT_323;
    zT_325 = (unsigned int)(10) - zT_323;
    zT_326.ptr = zT_324;
    zT_326.len = zT_325;
    zT_319 = zT_326;
    zT_327 = zF_A7504564_itoa((unsigned int)((unsigned int)flags), zT_319);
    pcb_pl = zT_327;
    zT_331 = (unsigned int)(9) - (unsigned int)((unsigned int)pcb_pl);
    pcb_ps = zT_331;
    zT_336 = (unsigned char*)((unsigned char*)pcb_pb) + pcb_ps;
    zT_337 = (unsigned int)(9) - pcb_ps;
    zT_338.ptr = zT_336;
    zT_338.len = zT_337;
    zT_332 = zT_338;
    zF_48AC7B3A_markerWrite(zT_332);
    zT_340 = "\n";
    zT_342 = 1;
    zT_341.ptr = zT_340;
    zT_341.len = zT_342;
    pcb_n = zT_341;
    zT_343 = pcb_n;
    zF_48AC7B3A_markerWrite(zT_343);
    zT_345 = "PCB:S";
    zT_347 = 5;
    zT_346.ptr = zT_345;
    zT_346.len = zT_347;
    pcb_sm = zT_346;
    zT_348 = pcb_sm;
    zF_C914CB83_markerWriteInt(zT_348, (unsigned int)((unsigned int)case_len));
    zT_352 = self->store;
    zT_355 = 0;
    zT_356 = case_items + zT_355;
    zT_357 = case_len - zT_355;
    zT_358.ptr = zT_356;
    zT_358.len = zT_357;
    zT_353 = zT_358;
    zT_359 = zF_583E993C_astStoreAddExtraChi(zT_352, zT_353);
    items_payload = zT_359;
    zT_361 = "PPL:n";
    zT_363 = 5;
    zT_362.ptr = zT_361;
    zT_362.len = zT_363;
    ppl_m = zT_362;
    zT_364 = ppl_m;
    zF_48AC7B3A_markerWrite(zT_364);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_366[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppl_pb[_i] = zT_366[_i];
        _i++;
    }
}
    zT_368 = items_payload;
    zT_372 = 0;
    zT_373 = (unsigned char*)((unsigned char*)ppl_pb) + zT_372;
    zT_374 = (unsigned int)(10) - zT_372;
    zT_375.ptr = zT_373;
    zT_375.len = zT_374;
    zT_369 = zT_375;
    zT_376 = zF_A7504564_itoa(zT_368, zT_369);
    ppl_pl = zT_376;
    zT_380 = (unsigned int)(9) - (unsigned int)((unsigned int)ppl_pl);
    ppl_ps = zT_380;
    zT_385 = (unsigned char*)((unsigned char*)ppl_pb) + ppl_ps;
    zT_386 = (unsigned int)(9) - ppl_ps;
    zT_387.ptr = zT_385;
    zT_387.len = zT_386;
    zT_381 = zT_387;
    zF_48AC7B3A_markerWrite(zT_381);
    zT_389 = "\n";
    zT_391 = 1;
    zT_390.ptr = zT_389;
    zT_390.len = zT_391;
    ppl_n = zT_390;
    zT_392 = ppl_n;
    zF_48AC7B3A_markerWrite(zT_392);
    zT_394 = start_tok.span_start;
    zT_395 = start_tok.span_len;
    zT_397 = zT_394 + (unsigned int)((unsigned int)zT_395);
    end_pos = zT_397;
    zT_398 = self->store;
    zT_400 = flags;
    zT_401 = start_tok.span_start;
    zT_402 = end_pos;
    zT_403 = body;
    zT_404 = capture_name;
    zT_411 = 0;
    zT_406 = items_payload;
    zT_413 = zF_6C9FF72F_astStoreAddNode(zT_398, (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_prong), zT_400, zT_401, zT_402, zT_403, zT_404, (unsigned int)((unsigned int)zT_411), zT_406);
    zT_414.data.payload = zT_413;
    zT_414.is_error = 0;
    return zT_414;
    z_bb_50:
    zT_275 = self;
    zT_278 = zF_F07C1F04_parserParseExprPrec(zT_275, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_279 = zT_278.is_error;
    if (zT_279) goto z_bb_54; else goto z_bb_55;
    z_bb_51:
    return zT_272;
    z_bb_52:
    zT_274 = zT_272.data.payload;
    goto z_bb_53;
    z_bb_53:
    body = zT_274;
    goto z_bb_49;
    z_bb_54:
    return zT_278;
    z_bb_55:
    zT_280 = zT_278.data.payload;
    goto z_bb_56;
    z_bb_56:
    body = zT_280;
    goto z_bb_49;
}

/* parserParseType */
zT_3B6EA323_EU_01 zF_CBDBFE85_parserParseType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_27 = {0};
    zT_EAC3E484_TokenKind zT_28;
    zT_B559F9DA_Parser* zT_32;
    zT_3B6EA323_EU_01 zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    unsigned char zT_39;
    unsigned int zT_40;
    zT_3B6EA323_EU_01 zT_41 = {0};
    zT_EAC3E484_TokenKind zT_42;
    zT_B559F9DA_Parser* zT_47;
    zT_3B6EA323_EU_01 zT_48 = {0};
    unsigned char zT_49;
    unsigned int zT_50;
    zT_B559F9DA_Parser* zT_51;
    zT_3A355BD2_Token zT_52 = {0};
    zT_EAC3E484_TokenKind zT_53;
    zT_B559F9DA_Parser* zT_57;
    zT_3A355BD2_Token zT_58 = {0};
    zT_B559F9DA_Parser* zT_60;
    zT_3B6EA323_EU_01 zT_61 = {0};
    unsigned char zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_67;
    unsigned int zT_69;
    unsigned int zT_70;
    int zT_76;
    unsigned int zT_79;
    unsigned short zT_80;
    int zT_83;
    int zT_85;
    unsigned int zT_87 = 0;
    zT_3B6EA323_EU_01 zT_88;
    zT_3B6EA323_EU_01 zT_89;
    zT_EAC3E484_TokenKind zT_90;
    zT_B559F9DA_Parser* zT_94;
    int zT_96;
    zT_3B6EA323_EU_01 zT_98 = {0};
    zT_EAC3E484_TokenKind zT_99;
    zT_B559F9DA_Parser* zT_103;
    zT_3B6EA323_EU_01 zT_104 = {0};
    zT_EAC3E484_TokenKind zT_105;
    zT_B559F9DA_Parser* zT_109;
    int zT_111;
    zT_3B6EA323_EU_01 zT_113 = {0};
    zT_EAC3E484_TokenKind zT_114;
    zT_B559F9DA_Parser* zT_118;
    zT_3A355BD2_Token zT_119 = {0};
    zT_B559F9DA_Parser* zT_121;
    zT_3A355BD2_Token zT_122 = {0};
    zT_EAC3E484_TokenKind zT_123;
    zT_B559F9DA_Parser* zT_127;
    int zT_129;
    zT_3B6EA323_EU_01 zT_131 = {0};
    zT_EAC3E484_TokenKind zT_132;
    zT_B559F9DA_Parser* zT_136;
    int zT_138;
    zT_3B6EA323_EU_01 zT_140 = {0};
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_B559F9DA_Parser* zT_145;
    zT_3A355BD2_Token zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    zT_DBF3575C_ParserError zT_148;
    zT_3B6EA323_EU_01 zT_149;
    zT_EAC3E484_TokenKind zT_150;
    zT_B559F9DA_Parser* zT_154;
    zT_3A355BD2_Token zT_155 = {0};
    unsigned int zT_157;
    zT_3B6EA323_EU_01 zT_158;
    zT_B559F9DA_Parser* zT_160;
    zT_3B6EA323_EU_01 zT_161 = {0};
    unsigned char zT_162;
    unsigned int zT_163;
    zT_B559F9DA_Parser* zT_164;
    zT_3A355BD2_Token zT_165 = {0};
    zT_EAC3E484_TokenKind zT_166;
    zT_B559F9DA_Parser* zT_170;
    zT_3A355BD2_Token zT_171 = {0};
    zT_B559F9DA_Parser* zT_173;
    zT_3B6EA323_EU_01 zT_174 = {0};
    unsigned char zT_175;
    unsigned int zT_176;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned int zT_183;
    int zT_189;
    unsigned int zT_192;
    unsigned short zT_193;
    int zT_196;
    int zT_198;
    unsigned int zT_200 = 0;
    zT_3B6EA323_EU_01 zT_201;
    zT_3B6EA323_EU_01 zT_202;
    zT_3A355BD2_Token tok;
    unsigned int es;
    unsigned int payload;
    zT_3A355BD2_Token ntok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    unsigned int z;
    unsigned int base;
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_4 = tok.kind;
    if ((unsigned char)(zT_4 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = self;
    zT_9 = zF_08083D09_parserParsePtrType(zT_8);
    return zT_9;
    z_bb_2:
    zT_10 = tok.kind;
    if ((unsigned char)(zT_10 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zT_15 = zF_2BC32683_parserParseBracketT(zT_14);
    return zT_15;
    z_bb_4:
    zT_16 = tok.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = self;
    zT_21 = zF_F9036399_parserParseOptional(zT_20);
    return zT_21;
    z_bb_6:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self;
    zT_27 = zF_33E5ECC8_parserParseErrorUni(zT_26);
    return zT_27;
    z_bb_8:
    zT_28 = tok.kind;
    if ((unsigned char)(zT_28 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self;
    zT_33 = zF_B83061B7_parserParseExternFn(zT_32);
    return zT_33;
    z_bb_10:
    zT_34 = tok.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = self;
    zT_40 = 0;
    zT_39 = zT_40;
    zT_41 = zF_B5C9B665_parserParseFnType(zT_38, zT_39);
    return zT_41;
    z_bb_12:
    zT_42 = tok.kind;
    if ((unsigned char)(zT_42 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_error))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_47 = self;
    zT_48 = zF_BFAD1973_parserParseErrorSet(zT_47);
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_90 = tok.kind;
    if ((unsigned char)(zT_90 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    return zT_48;
    z_bb_16:
    zT_50 = zT_48.data.payload;
    goto z_bb_17;
    z_bb_17:
    es = zT_50;
    zT_51 = self;
    zT_52 = zF_068A2DE5_parserPeek(zT_51);
    zT_53 = zT_52.kind;
    if ((unsigned char)(zT_53 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_57 = self;
    zT_58 = zF_C241B2C4_parserAdvance(zT_57);
    (void)zT_58;
    zT_60 = self;
    zT_61 = zF_CBDBFE85_parserParseType(zT_60);
    zT_62 = zT_61.is_error;
    if (zT_62) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_89.data.payload = es;
    zT_89.is_error = 0;
    return zT_89;
    z_bb_20:
    return zT_61;
    z_bb_21:
    zT_63 = zT_61.data.payload;
    goto z_bb_22;
    z_bb_22:
    payload = zT_63;
    zT_64 = self->store;
    zT_76 = 0;
    zT_67 = tok.span_start;
    zT_79 = tok.span_start;
    zT_80 = tok.span_len;
    zT_69 = es;
    zT_70 = payload;
    zT_83 = 0;
    zT_85 = 0;
    zT_87 = zF_6C9FF72F_astStoreAddNode(zT_64, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_76), zT_67, (unsigned int)(zT_79 + (unsigned int)((unsigned int)zT_80)), zT_69, zT_70, (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85));
    zT_88.data.payload = zT_87;
    zT_88.is_error = 0;
    return zT_88;
    z_bb_23:
    zT_94 = self;
    zT_96 = 0;
    zT_98 = zF_3530D6C0_parserParseStructTy(zT_94, (unsigned char)((unsigned char)zT_96));
    return zT_98;
    z_bb_24:
    zT_99 = tok.kind;
    if ((unsigned char)(zT_99 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_103 = self;
    zT_104 = zF_63EC2480_parserParseEnumType(zT_103);
    return zT_104;
    z_bb_26:
    zT_105 = tok.kind;
    if ((unsigned char)(zT_105 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_109 = self;
    zT_111 = 0;
    zT_113 = zF_0881F8E4_parserParseUnionTyp(zT_109, (unsigned char)((unsigned char)zT_111));
    return zT_113;
    z_bb_28:
    zT_114 = tok.kind;
    if ((unsigned char)(zT_114 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_packed))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_118 = self;
    zT_119 = zF_C241B2C4_parserAdvance(zT_118);
    (void)zT_119;
    zT_121 = self;
    zT_122 = zF_068A2DE5_parserPeek(zT_121);
    ntok = zT_122;
    zT_123 = ntok.kind;
    if ((unsigned char)(zT_123 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_150 = tok.kind;
    if ((unsigned char)(zT_150 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_anytype))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    zT_127 = self;
    zT_129 = 1;
    zT_131 = zF_3530D6C0_parserParseStructTy(zT_127, (unsigned char)((unsigned char)zT_129));
    return zT_131;
    z_bb_32:
    zT_132 = ntok.kind;
    if ((unsigned char)(zT_132 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_136 = self;
    zT_138 = 1;
    zT_140 = zF_0881F8E4_parserParseUnionTyp(zT_136, (unsigned char)((unsigned char)zT_138));
    return zT_140;
    z_bb_34:
    zT_142 = "expected 'struct' or 'union' after 'packed'";
    zT_144 = 43;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    pmsg = zT_143;
    zT_145 = self;
    zT_146 = ntok;
    zT_147 = pmsg;
    zF_17DF2CA5_parserAddError(zT_145, zT_146, zT_147);
    zT_148 = 1;
    zT_149.data.err = zT_148;
    zT_149.is_error = 1;
    return zT_149;
    z_bb_35:
    zT_154 = self;
    zT_155 = zF_C241B2C4_parserAdvance(zT_154);
    (void)zT_155;
    zT_157 = 0;
    z = zT_157;
    zT_158.data.payload = z;
    zT_158.is_error = 0;
    return zT_158;
    z_bb_36:
    zT_160 = self;
    zT_161 = zF_C8A1E2C6_parserParseTypeName(zT_160);
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return zT_161;
    z_bb_38:
    zT_163 = zT_161.data.payload;
    goto z_bb_39;
    z_bb_39:
    base = zT_163;
    zT_164 = self;
    zT_165 = zF_068A2DE5_parserPeek(zT_164);
    zT_166 = zT_165.kind;
    if ((unsigned char)(zT_166 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_170 = self;
    zT_171 = zF_C241B2C4_parserAdvance(zT_170);
    (void)zT_171;
    zT_173 = self;
    zT_174 = zF_CBDBFE85_parserParseType(zT_173);
    zT_175 = zT_174.is_error;
    if (zT_175) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_202.data.payload = base;
    zT_202.is_error = 0;
    return zT_202;
    z_bb_42:
    return zT_174;
    z_bb_43:
    zT_176 = zT_174.data.payload;
    goto z_bb_44;
    z_bb_44:
    payload = zT_176;
    zT_177 = self->store;
    zT_189 = 0;
    zT_180 = tok.span_start;
    zT_192 = tok.span_start;
    zT_193 = tok.span_len;
    zT_182 = base;
    zT_183 = payload;
    zT_196 = 0;
    zT_198 = 0;
    zT_200 = zF_6C9FF72F_astStoreAddNode(zT_177, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_189), zT_180, (unsigned int)(zT_192 + (unsigned int)((unsigned int)zT_193)), zT_182, zT_183, (unsigned int)((unsigned int)zT_196), (unsigned int)((unsigned int)zT_198));
    zT_201.data.payload = zT_200;
    zT_201.is_error = 0;
    return zT_201;
}

/* parserParsePtrQualifiers */
unsigned char zF_0FA83230_parserParsePtrQuali(zT_B559F9DA_Parser* self) {
    int zT_2;
    unsigned char zT_3;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    int zT_13;
    unsigned char zT_15;
    zT_B559F9DA_Parser* zT_16;
    zT_3A355BD2_Token zT_17 = {0};
    zT_EAC3E484_TokenKind zT_18;
    zT_B559F9DA_Parser* zT_22;
    zT_3A355BD2_Token zT_23 = {0};
    int zT_24;
    unsigned char zT_26;
    unsigned char flags;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    flags = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return flags;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    (void)zT_12;
    zT_13 = 1;
    zT_15 = flags | (unsigned char)((unsigned char)zT_13);
    flags = zT_15;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_16 = self;
    zT_17 = zF_068A2DE5_parserPeek(zT_16);
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_volatile))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_22 = self;
    zT_23 = zF_C241B2C4_parserAdvance(zT_22);
    (void)zT_23;
    zT_24 = 2;
    zT_26 = flags | (unsigned char)((unsigned char)zT_24);
    flags = zT_26;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    goto z_bb_3;
}

/* parserParsePtrType */
zT_3B6EA323_EU_01 zF_08083D09_parserParsePtrType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    unsigned char zT_6 = 0;
    zT_B559F9DA_Parser* zT_8;
    zT_3B6EA323_EU_01 zT_9 = {0};
    unsigned char zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_26;
    unsigned short zT_27;
    int zT_30;
    int zT_32;
    int zT_34;
    unsigned int zT_36 = 0;
    zT_3B6EA323_EU_01 zT_37;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int end_pos;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_0FA83230_parserParsePtrQuali(zT_5);
    flags = zT_6;
    zT_8 = self;
    zT_9 = zF_CBDBFE85_parserParseType(zT_8);
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_9;
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    base = zT_11;
    end_pos = base;
    (void)end_pos;
    zT_13 = self->store;
    zT_15 = flags;
    zT_16 = tok.span_start;
    zT_26 = tok.span_start;
    zT_27 = tok.span_len;
    zT_18 = base;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = zF_6C9FF72F_astStoreAddNode(zT_13, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type), zT_15, zT_16, (unsigned int)(zT_26 + (unsigned int)((unsigned int)zT_27)), zT_18, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34));
    zT_37.data.payload = zT_36;
    zT_37.is_error = 0;
    return zT_37;
}

/* parserParseBracketType */
zT_3B6EA323_EU_01 zF_2BC32683_parserParseBracketT(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_10;
    zT_3A355BD2_Token zT_11 = {0};
    zT_B559F9DA_Parser* zT_12;
    zT_CB78802F_EU_49 zT_16 = {0};
    unsigned char zT_17;
    int zT_18;
    zT_3B6EA323_EU_01 zT_19;
    zT_2B3424E9_ParseToken zT_20;
    zT_B559F9DA_Parser* zT_22;
    unsigned char zT_23 = 0;
    zT_B559F9DA_Parser* zT_25;
    zT_3B6EA323_EU_01 zT_26 = {0};
    unsigned char zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_42;
    unsigned short zT_43;
    int zT_46;
    int zT_48;
    int zT_50;
    unsigned int zT_52 = 0;
    zT_3B6EA323_EU_01 zT_53;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3A355BD2_Token zT_61 = {0};
    int zT_63;
    unsigned char zT_64;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    zT_EAC3E484_TokenKind zT_67;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    int zT_73;
    unsigned char zT_74;
    zT_B559F9DA_Parser* zT_76;
    zT_3B6EA323_EU_01 zT_77 = {0};
    unsigned char zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned int zT_93;
    unsigned short zT_94;
    int zT_97;
    int zT_99;
    int zT_101;
    unsigned int zT_103 = 0;
    zT_3B6EA323_EU_01 zT_104;
    zT_B559F9DA_Parser* zT_106;
    zT_3B6EA323_EU_01 zT_109 = {0};
    unsigned char zT_110;
    unsigned int zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_CB78802F_EU_49 zT_116 = {0};
    unsigned char zT_117;
    int zT_118;
    zT_3B6EA323_EU_01 zT_119;
    zT_2B3424E9_ParseToken zT_120;
    zT_B559F9DA_Parser* zT_122;
    zT_3B6EA323_EU_01 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_129;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_138;
    unsigned int zT_141;
    unsigned short zT_142;
    int zT_145;
    int zT_147;
    unsigned int zT_149 = 0;
    zT_3B6EA323_EU_01 zT_150;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned int base;
    unsigned int size_expr;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    zT_6 = zT_5.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = zF_C241B2C4_parserAdvance(zT_10);
    (void)zT_11;
    zT_12 = self;
    zT_16 = zF_5578C74F_parserExpect(zT_12, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_54 = self;
    zT_55 = zF_068A2DE5_parserPeek(zT_54);
    zT_56 = zT_55.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_18 = zT_16.data.err;
    zT_19.data.err = zT_18;
    zT_19.is_error = 1;
    return zT_19;
    z_bb_4:
    zT_20 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_20;
    zT_22 = self;
    zT_23 = zF_0FA83230_parserParsePtrQuali(zT_22);
    flags = zT_23;
    zT_25 = self;
    zT_26 = zF_CBDBFE85_parserParseType(zT_25);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return zT_26;
    z_bb_7:
    zT_28 = zT_26.data.payload;
    goto z_bb_8;
    z_bb_8:
    base = zT_28;
    zT_29 = self->store;
    zT_31 = flags;
    zT_32 = tok.span_start;
    zT_42 = tok.span_start;
    zT_43 = tok.span_len;
    zT_34 = base;
    zT_46 = 0;
    zT_48 = 0;
    zT_50 = 0;
    zT_52 = zF_6C9FF72F_astStoreAddNode(zT_29, (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type), zT_31, zT_32, (unsigned int)(zT_42 + (unsigned int)((unsigned int)zT_43)), zT_34, (unsigned int)((unsigned int)zT_46), (unsigned int)((unsigned int)zT_48), (unsigned int)((unsigned int)zT_50));
    zT_53.data.payload = zT_52;
    zT_53.is_error = 0;
    return zT_53;
    z_bb_9:
    zT_60 = self;
    zT_61 = zF_C241B2C4_parserAdvance(zT_60);
    (void)zT_61;
    zT_63 = 0;
    zT_64 = (unsigned char)zT_63;
    flags = zT_64;
    zT_65 = self;
    zT_66 = zF_068A2DE5_parserPeek(zT_65);
    zT_67 = zT_66.kind;
    if ((unsigned char)(zT_67 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_106 = self;
    zT_109 = zF_F07C1F04_parserParseExprPrec(zT_106, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_110 = zT_109.is_error;
    if (zT_110) goto z_bb_16; else goto z_bb_17;
    z_bb_11:
    zT_71 = self;
    zT_72 = zF_C241B2C4_parserAdvance(zT_71);
    (void)zT_72;
    zT_73 = 1;
    zT_74 = (unsigned char)zT_73;
    flags = zT_74;
    goto z_bb_12;
    z_bb_12:
    zT_76 = self;
    zT_77 = zF_CBDBFE85_parserParseType(zT_76);
    zT_78 = zT_77.is_error;
    if (zT_78) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return zT_77;
    z_bb_14:
    zT_79 = zT_77.data.payload;
    goto z_bb_15;
    z_bb_15:
    base = zT_79;
    zT_80 = self->store;
    zT_82 = flags;
    zT_83 = tok.span_start;
    zT_93 = tok.span_start;
    zT_94 = tok.span_len;
    zT_85 = base;
    zT_97 = 0;
    zT_99 = 0;
    zT_101 = 0;
    zT_103 = zF_6C9FF72F_astStoreAddNode(zT_80, (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type), zT_82, zT_83, (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94)), zT_85, (unsigned int)((unsigned int)zT_97), (unsigned int)((unsigned int)zT_99), (unsigned int)((unsigned int)zT_101));
    zT_104.data.payload = zT_103;
    zT_104.is_error = 0;
    return zT_104;
    z_bb_16:
    return zT_109;
    z_bb_17:
    zT_111 = zT_109.data.payload;
    goto z_bb_18;
    z_bb_18:
    size_expr = zT_111;
    zT_112 = self;
    zT_116 = zF_5578C74F_parserExpect(zT_112, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket));
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_118 = zT_116.data.err;
    zT_119.data.err = zT_118;
    zT_119.is_error = 1;
    return zT_119;
    z_bb_20:
    zT_120 = zT_116.data.payload;
    goto z_bb_21;
    z_bb_21:
    (void)zT_120;
    zT_122 = self;
    zT_123 = zF_CBDBFE85_parserParseType(zT_122);
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return zT_123;
    z_bb_23:
    zT_125 = zT_123.data.payload;
    goto z_bb_24;
    z_bb_24:
    base = zT_125;
    zT_126 = self->store;
    zT_138 = 0;
    zT_129 = tok.span_start;
    zT_141 = tok.span_start;
    zT_142 = tok.span_len;
    zT_131 = base;
    zT_132 = size_expr;
    zT_145 = 0;
    zT_147 = 0;
    zT_149 = zF_6C9FF72F_astStoreAddNode(zT_126, (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type), (unsigned char)((unsigned char)zT_138), zT_129, (unsigned int)(zT_141 + (unsigned int)((unsigned int)zT_142)), zT_131, zT_132, (unsigned int)((unsigned int)zT_145), (unsigned int)((unsigned int)zT_147));
    zT_150.data.payload = zT_149;
    zT_150.is_error = 0;
    return zT_150;
}

/* parserParseOptionalType */
zT_3B6EA323_EU_01 zF_F9036399_parserParseOptional(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_14;
    int zT_21;
    unsigned int zT_24;
    unsigned short zT_25;
    int zT_28;
    int zT_30;
    int zT_32;
    unsigned int zT_34 = 0;
    zT_3B6EA323_EU_01 zT_35;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_21 = 0;
    zT_12 = tok.span_start;
    zT_24 = tok.span_start;
    zT_25 = tok.span_len;
    zT_14 = payload;
    zT_28 = 0;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type), (unsigned char)((unsigned char)zT_21), zT_12, (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25)), zT_14, (unsigned int)((unsigned int)zT_28), (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32));
    zT_35.data.payload = zT_34;
    zT_35.is_error = 0;
    return zT_35;
}

/* parserParseErrorUnionType */
zT_3B6EA323_EU_01 zF_33E5ECC8_parserParseErrorUni(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_12;
    unsigned int zT_15;
    int zT_21;
    unsigned int zT_24;
    unsigned short zT_25;
    int zT_28;
    int zT_30;
    int zT_32;
    unsigned int zT_34 = 0;
    zT_3B6EA323_EU_01 zT_35;
    zT_3A355BD2_Token tok;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = self;
    zT_6 = zF_CBDBFE85_parserParseType(zT_5);
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_6;
    z_bb_2:
    zT_8 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    payload = zT_8;
    zT_9 = self->store;
    zT_21 = 0;
    zT_12 = tok.span_start;
    zT_24 = tok.span_start;
    zT_25 = tok.span_len;
    zT_28 = 0;
    zT_15 = payload;
    zT_30 = 0;
    zT_32 = 0;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_9, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type), (unsigned char)((unsigned char)zT_21), zT_12, (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25)), (unsigned int)((unsigned int)zT_28), zT_15, (unsigned int)((unsigned int)zT_30), (unsigned int)((unsigned int)zT_32));
    zT_35.data.payload = zT_34;
    zT_35.is_error = 0;
    return zT_35;
}

/* parserParseExternFnType */
zT_3B6EA323_EU_01 zF_B83061B7_parserParseExternFn(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    unsigned int zT_4;
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16;
    zT_85CBA4DB_TokenValue zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20 = {0};
    zT_B559F9DA_Parser* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned char zT_23 = 0;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_B559F9DA_Parser* zT_30;
    zT_3A355BD2_Token zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    int zT_34;
    unsigned int zT_36;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    zT_EAC3E484_TokenKind zT_40;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_DBF3575C_ParserError zT_51;
    zT_3B6EA323_EU_01 zT_52;
    zT_B559F9DA_Parser* zT_53;
    unsigned char zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u efm;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = 0;
    call_conv = zT_4;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    zT_7 = zT_6.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    str_tok = zT_13;
    zT_15 = self->interner;
    zT_18 = str_tok.value;
    zT_16 = zT_18.string_id;
    zT_20 = zF_9134020D_stringInternerGet(zT_15, zT_16);
    text = zT_20;
    zT_21 = self;
    zT_22 = text;
    zT_23 = zF_A095D9EA_parserClassifyCallC(zT_21, zT_22);
    call_conv = zT_23;
    if ((unsigned char)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = self;
    zT_39 = zF_068A2DE5_parserPeek(zT_38);
    nt = zT_39;
    zT_40 = nt.kind;
    if ((unsigned char)(zT_40 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_27 = "unknown calling convention in `extern`";
    zT_29 = 38;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ucv = zT_28;
    zT_30 = self;
    zT_31 = str_tok;
    zT_34 = 3045;
    zT_33 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_30, zT_31, (unsigned short)((unsigned short)zT_34), zT_33);
    zT_36 = 0;
    call_conv = zT_36;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = "expected 'fn' after extern calling convention";
    zT_47 = 45;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    efm = zT_46;
    zT_48 = self;
    zT_49 = nt;
    zT_50 = efm;
    zF_17DF2CA5_parserAddError(zT_48, zT_49, zT_50);
    zT_51 = 1;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_6:
    zT_53 = self;
    zT_54 = call_conv;
    zT_55 = zF_B5C9B665_parserParseFnType(zT_53, zT_54);
    return zT_55;
}

/* parserParseFnType */
zT_3B6EA323_EU_01 zF_B5C9B665_parserParseFnType(zT_B559F9DA_Parser* self, unsigned char call_conv) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    unsigned int* zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_27;
    zT_3A355BD2_Token zT_28 = {0};
    zT_EAC3E484_TokenKind zT_29;
    zT_B559F9DA_Parser* zT_34;
    zT_3A355BD2_Token zT_35 = {0};
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_B559F9DA_Parser* zT_40;
    zT_3A355BD2_Token zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_DBF3575C_ParserError zT_43;
    zT_3B6EA323_EU_01 zT_44;
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    unsigned char zT_51;
    zT_B559F9DA_Parser* zT_52;
    int zT_54;
    zT_3A355BD2_Token zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_61;
    zT_3A355BD2_Token zT_62 = {0};
    zT_B559F9DA_Parser* zT_63;
    zT_CB78802F_EU_49 zT_67 = {0};
    unsigned char zT_68;
    int zT_69;
    zT_3B6EA323_EU_01 zT_70;
    zT_2B3424E9_ParseToken zT_71;
    zT_B559F9DA_Parser* zT_73;
    zT_3B6EA323_EU_01 zT_74 = {0};
    unsigned char zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_77;
    unsigned int** zT_78;
    unsigned int* zT_79;
    unsigned int* zT_80;
    unsigned int zT_81;
    zT_B559F9DA_Parser* zT_85;
    zT_3A355BD2_Token zT_86 = {0};
    zT_EAC3E484_TokenKind zT_87;
    zT_B559F9DA_Parser* zT_91;
    zT_3A355BD2_Token zT_92 = {0};
    zT_B559F9DA_Parser* zT_93;
    zT_CB78802F_EU_49 zT_97 = {0};
    unsigned char zT_98;
    int zT_99;
    zT_3B6EA323_EU_01 zT_100;
    zT_2B3424E9_ParseToken zT_101;
    int zT_103;
    unsigned int zT_104;
    zT_B559F9DA_Parser* zT_105;
    zT_3A355BD2_Token zT_106 = {0};
    zT_EAC3E484_TokenKind zT_107;
    unsigned char zT_111;
    zT_B559F9DA_Parser* zT_112;
    zT_3A355BD2_Token zT_113 = {0};
    zT_EAC3E484_TokenKind zT_114;
    unsigned char zT_118;
    zT_B559F9DA_Parser* zT_119;
    zT_3A355BD2_Token zT_120 = {0};
    zT_EAC3E484_TokenKind zT_121;
    unsigned char zT_125;
    zT_B559F9DA_Parser* zT_126;
    zT_3A355BD2_Token zT_127 = {0};
    zT_EAC3E484_TokenKind zT_128;
    unsigned char zT_132;
    zT_B559F9DA_Parser* zT_133;
    zT_3A355BD2_Token zT_134 = {0};
    zT_EAC3E484_TokenKind zT_135;
    unsigned char zT_139;
    zT_B559F9DA_Parser* zT_140;
    zT_3A355BD2_Token zT_141 = {0};
    zT_EAC3E484_TokenKind zT_142;
    zT_B559F9DA_Parser* zT_146;
    zT_3B6EA323_EU_01 zT_147 = {0};
    unsigned char zT_148;
    unsigned int zT_149;
    int zT_151;
    unsigned int zT_152;
    int zT_153;
    zT_6B0A7D14_AstStore* zT_155;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_156;
    int zT_158;
    unsigned int* zT_159;
    unsigned int zT_160;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_161;
    unsigned int zT_162 = 0;
    int zT_164;
    unsigned char zT_165;
    unsigned char zT_169;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned char zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned int zT_178;
    unsigned int zT_183;
    unsigned short zT_184;
    int zT_187;
    int zT_189;
    unsigned int zT_191 = 0;
    zT_3B6EA323_EU_01 zT_192;
    zT_3A355BD2_Token tok;
    unsigned int* param_buf;
    unsigned int param_count;
    unsigned int param_cap;
    zT_3A355BD2_Token vtok;
    zT_8F083A69_Slice_zT_0B42B2F8_u v_msg;
    unsigned int p;
    unsigned int ret_type;
    unsigned int payload;
    unsigned char fn_flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    param_buf = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    param_count = zT_18;
    zT_20 = 0;
    param_cap = zT_20;
    goto z_bb_4;
    z_bb_4:
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    zT_23 = zT_22.kind;
    if ((unsigned char)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = self;
    zT_28 = zF_068A2DE5_parserPeek(zT_27);
    zT_29 = zT_28.kind;
    if ((unsigned char)(zT_29 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_93 = self;
    zT_97 = zF_5578C74F_parserExpect(zT_93, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_98 = zT_97.is_error;
    if (zT_98) goto z_bb_23; else goto z_bb_24;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_34 = self;
    zT_35 = zF_C241B2C4_parserAdvance(zT_34);
    vtok = zT_35;
    zT_37 = "varargs not allowed in function pointer types";
    zT_39 = 45;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    v_msg = zT_38;
    zT_40 = self;
    zT_41 = vtok;
    zT_42 = v_msg;
    zF_17DF2CA5_parserAddError(zT_40, zT_41, zT_42);
    zT_43 = 1;
    zT_44.data.err = zT_43;
    zT_44.is_error = 1;
    return zT_44;
    z_bb_9:
    zT_45 = self;
    zT_46 = zF_068A2DE5_parserPeek(zT_45);
    zT_47 = zT_46.kind;
    if ((unsigned char)(zT_47 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_52 = self;
    zT_54 = 1;
    zT_56 = zF_F685E431_parserPeekN(zT_52, (unsigned int)((unsigned int)zT_54));
    zT_57 = zT_56.kind;
    zT_51 = zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon);
    goto z_bb_12;
    z_bb_11:
    zT_51 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_51) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_61 = self;
    zT_62 = zF_C241B2C4_parserAdvance(zT_61);
    (void)zT_62;
    zT_63 = self;
    zT_67 = zF_5578C74F_parserExpect(zT_63, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_68 = zT_67.is_error;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_73 = self;
    zT_74 = zF_CBDBFE85_parserParseType(zT_73);
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_69 = zT_67.data.err;
    zT_70.data.err = zT_69;
    zT_70.is_error = 1;
    return zT_70;
    z_bb_16:
    zT_71 = zT_67.data.payload;
    goto z_bb_17;
    z_bb_17:
    (void)zT_71;
    goto z_bb_14;
    z_bb_18:
    return zT_74;
    z_bb_19:
    zT_76 = zT_74.data.payload;
    goto z_bb_20;
    z_bb_20:
    p = zT_76;
    zT_77 = self;
    zT_78 = &param_buf;
    zT_79 = &param_count;
    zT_80 = &param_cap;
    zT_81 = p;
    zF_0F1462F8_parserPushU32(zT_77, zT_78, zT_79, zT_80, zT_81);
    zT_85 = self;
    zT_86 = zF_068A2DE5_parserPeek(zT_85);
    zT_87 = zT_86.kind;
    if ((unsigned char)(zT_87 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_91 = self;
    zT_92 = zF_C241B2C4_parserAdvance(zT_91);
    (void)zT_92;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_7;
    z_bb_23:
    zT_99 = zT_97.data.err;
    zT_100.data.err = zT_99;
    zT_100.is_error = 1;
    return zT_100;
    z_bb_24:
    zT_101 = zT_97.data.payload;
    goto z_bb_25;
    z_bb_25:
    (void)zT_101;
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    ret_type = zT_104;
    zT_105 = self;
    zT_106 = zF_068A2DE5_parserPeek(zT_105);
    zT_107 = zT_106.kind;
    if ((unsigned char)(zT_107 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_112 = self;
    zT_113 = zF_068A2DE5_parserPeek(zT_112);
    zT_114 = zT_113.kind;
    zT_111 = zT_114 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon);
    goto z_bb_28;
    z_bb_27:
    zT_111 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_111) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_119 = self;
    zT_120 = zF_068A2DE5_parserPeek(zT_119);
    zT_121 = zT_120.kind;
    zT_118 = zT_121 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_31;
    z_bb_30:
    zT_118 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_118) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_126 = self;
    zT_127 = zF_068A2DE5_parserPeek(zT_126);
    zT_128 = zT_127.kind;
    zT_125 = zT_128 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen);
    goto z_bb_34;
    z_bb_33:
    zT_125 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_125) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_133 = self;
    zT_134 = zF_068A2DE5_parserPeek(zT_133);
    zT_135 = zT_134.kind;
    zT_132 = zT_135 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket);
    goto z_bb_37;
    z_bb_36:
    zT_132 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_132) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_140 = self;
    zT_141 = zF_068A2DE5_parserPeek(zT_140);
    zT_142 = zT_141.kind;
    zT_139 = zT_142 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_40;
    z_bb_39:
    zT_139 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_139) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_146 = self;
    zT_147 = zF_CBDBFE85_parserParseType(zT_146);
    zT_148 = zT_147.is_error;
    if (zT_148) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_151 = 0;
    zT_152 = (unsigned int)zT_151;
    payload = zT_152;
    zT_153 = 0;
    if ((unsigned char)(param_count > (unsigned int)zT_153)) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_147;
    z_bb_44:
    zT_149 = zT_147.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type = zT_149;
    goto z_bb_42;
    z_bb_46:
    zT_155 = self->store;
    zT_158 = 0;
    zT_159 = param_buf + zT_158;
    zT_160 = param_count - zT_158;
    zT_161.ptr = zT_159;
    zT_161.len = zT_160;
    zT_156 = zT_161;
    zT_162 = zF_583E993C_astStoreAddExtraChi(zT_155, zT_156);
    payload = zT_162;
    goto z_bb_47;
    z_bb_47:
    zT_164 = 0;
    zT_165 = (unsigned char)zT_164;
    fn_flags = zT_165;
    if ((unsigned char)(call_conv == (unsigned int)(1))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_169 = fn_flags | (unsigned char)(1);
    fn_flags = zT_169;
    goto z_bb_49;
    z_bb_49:
    zT_170 = self->store;
    zT_172 = fn_flags;
    zT_173 = tok.span_start;
    zT_183 = tok.span_start;
    zT_184 = tok.span_len;
    zT_175 = ret_type;
    zT_187 = 0;
    zT_189 = 0;
    zT_178 = payload;
    zT_191 = zF_6C9FF72F_astStoreAddNode(zT_170, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type), zT_172, zT_173, (unsigned int)(zT_183 + (unsigned int)((unsigned int)zT_184)), zT_175, (unsigned int)((unsigned int)zT_187), (unsigned int)((unsigned int)zT_189), zT_178);
    zT_192.data.payload = zT_191;
    zT_192.is_error = 0;
    return zT_192;
}

/* parserParseErrorSetDecl */
zT_3B6EA323_EU_01 zF_BFAD1973_parserParseErrorSet(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5;
    zT_3B6EA323_EU_01 zT_6 = {0};
    zT_3A355BD2_Token tok;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_4 = self;
    zT_5 = tok;
    zT_6 = zF_2C55CABB_parserParseErrorSet(zT_4, zT_5);
    return zT_6;
}

/* parserParseErrorSetDeclBody */
zT_3B6EA323_EU_01 zF_2C55CABB_parserParseErrorSet(zT_B559F9DA_Parser* self, zT_3A355BD2_Token kw) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_6 = {0};
    unsigned char zT_7;
    int zT_8;
    zT_3B6EA323_EU_01 zT_9;
    zT_2B3424E9_ParseToken zT_10;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    zT_B559F9DA_Parser* zT_25;
    zT_CB78802F_EU_49 zT_29 = {0};
    unsigned char zT_30;
    int zT_31;
    zT_3B6EA323_EU_01 zT_32;
    zT_2B3424E9_ParseToken zT_33;
    zT_2B3424E9_ParseToken zT_35;
    zT_EAC3E484_TokenKind zT_36;
    unsigned int zT_37;
    unsigned short zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    zT_B559F9DA_Parser* zT_43;
    zT_2B3424E9_ParseToken zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    unsigned int zT_46 = 0;
    zT_B559F9DA_Parser* zT_47;
    unsigned int** zT_48;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_B559F9DA_Parser* zT_55;
    zT_3A355BD2_Token zT_56 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_B559F9DA_Parser* zT_61;
    zT_3A355BD2_Token zT_62 = {0};
    zT_B559F9DA_Parser* zT_63;
    zT_CB78802F_EU_49 zT_67 = {0};
    unsigned char zT_68;
    int zT_69;
    zT_3B6EA323_EU_01 zT_70;
    zT_2B3424E9_ParseToken zT_71;
    int zT_73;
    unsigned int zT_74;
    int zT_75;
    zT_6B0A7D14_AstStore* zT_77;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_78;
    int zT_80;
    unsigned int* zT_81;
    unsigned int zT_82;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83;
    unsigned int zT_84 = 0;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_88;
    unsigned int zT_93;
    int zT_97;
    unsigned int zT_100;
    unsigned short zT_101;
    int zT_104;
    int zT_106;
    int zT_108;
    unsigned int zT_110 = 0;
    zT_3B6EA323_EU_01 zT_111;
    unsigned int* member_buf;
    unsigned int member_count;
    unsigned int member_cap;
    zT_2B3424E9_ParseToken tag_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int tag_id;
    unsigned int payload;
    zT_2 = self;
    zT_6 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = zT_6.data.err;
    zT_9.data.err = zT_8;
    zT_9.is_error = 1;
    return zT_9;
    z_bb_2:
    zT_10 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_10;
    zT_12 = 0;
    member_buf = (unsigned int*)zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    member_count = zT_15;
    zT_17 = 0;
    member_cap = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_18 = self;
    zT_19 = zF_068A2DE5_parserPeek(zT_18);
    zT_20 = zT_19.kind;
    if ((unsigned char)(zT_20 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = self;
    zT_29 = zF_5578C74F_parserExpect(zT_25, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_63 = self;
    zT_67 = zF_5578C74F_parserExpect(zT_63, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_68 = zT_67.is_error;
    if (zT_68) goto z_bb_13; else goto z_bb_14;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_31 = zT_29.data.err;
    zT_32.data.err = zT_31;
    zT_32.is_error = 1;
    return zT_32;
    z_bb_9:
    zT_33 = zT_29.data.payload;
    goto z_bb_10;
    z_bb_10:
    tag_tok = zT_33;
    zT_36 = tag_tok.kind;
    zT_35.kind = zT_36;
    zT_37 = tag_tok.span_start;
    zT_35.span_start = zT_37;
    zT_38 = tag_tok.span_len;
    zT_35.span_len = zT_38;
    pt = zT_35;
    zT_40 = self->interner;
    zT_43 = self;
    zT_44 = pt;
    zT_45 = zF_08D61E58_parserTokenText(zT_43, zT_44);
    zT_41 = zT_45;
    zT_46 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    tag_id = zT_46;
    zT_47 = self;
    zT_48 = &member_buf;
    zT_49 = &member_count;
    zT_50 = &member_cap;
    zT_51 = tag_id;
    zF_0F1462F8_parserPushU32(zT_47, zT_48, zT_49, zT_50, zT_51);
    zT_55 = self;
    zT_56 = zF_068A2DE5_parserPeek(zT_55);
    zT_57 = zT_56.kind;
    if ((unsigned char)(zT_57 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_61 = self;
    zT_62 = zF_C241B2C4_parserAdvance(zT_61);
    (void)zT_62;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_69 = zT_67.data.err;
    zT_70.data.err = zT_69;
    zT_70.is_error = 1;
    return zT_70;
    z_bb_14:
    zT_71 = zT_67.data.payload;
    goto z_bb_15;
    z_bb_15:
    (void)zT_71;
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    payload = zT_74;
    zT_75 = 0;
    if ((unsigned char)(member_count > (unsigned int)zT_75)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_77 = self->store;
    zT_80 = 0;
    zT_81 = member_buf + zT_80;
    zT_82 = member_count - zT_80;
    zT_83.ptr = zT_81;
    zT_83.len = zT_82;
    zT_78 = zT_83;
    zT_84 = zF_583E993C_astStoreAddExtraChi(zT_77, zT_78);
    payload = zT_84;
    goto z_bb_17;
    z_bb_17:
    zT_85 = self->store;
    zT_97 = 0;
    zT_88 = kw.span_start;
    zT_100 = kw.span_start;
    zT_101 = kw.span_len;
    zT_104 = 0;
    zT_106 = 0;
    zT_108 = 0;
    zT_93 = payload;
    zT_110 = zF_6C9FF72F_astStoreAddNode(zT_85, (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl), (unsigned char)((unsigned char)zT_97), zT_88, (unsigned int)(zT_100 + (unsigned int)((unsigned int)zT_101)), (unsigned int)((unsigned int)zT_104), (unsigned int)((unsigned int)zT_106), (unsigned int)((unsigned int)zT_108), zT_93);
    zT_111.data.payload = zT_110;
    zT_111.is_error = 0;
    return zT_111;
}

/* parserParseStructType */
zT_3B6EA323_EU_01 zF_3530D6C0_parserParseStructTy(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_CB78802F_EU_49 zT_9 = {0};
    unsigned char zT_10;
    int zT_11;
    zT_3B6EA323_EU_01 zT_12;
    zT_2B3424E9_ParseToken zT_13;
    unsigned int* zT_15 = 0;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22 = {0};
    zT_EAC3E484_TokenKind zT_23;
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    zT_B559F9DA_Parser* zT_37;
    zT_CB78802F_EU_49 zT_41 = {0};
    unsigned char zT_42;
    int zT_43;
    zT_3B6EA323_EU_01 zT_44;
    zT_2B3424E9_ParseToken zT_45;
    zT_2B3424E9_ParseToken zT_47;
    zT_EAC3E484_TokenKind zT_48;
    unsigned int zT_49;
    unsigned short zT_50;
    zT_D3EB6303_StringInterner* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_B559F9DA_Parser* zT_55;
    zT_2B3424E9_ParseToken zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57 = {0};
    unsigned int zT_58 = 0;
    zT_B559F9DA_Parser* zT_60;
    zT_3B6EA323_EU_01 zT_61 = {0};
    unsigned char zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_73;
    int zT_77;
    unsigned int zT_80;
    unsigned short zT_81;
    int zT_84;
    int zT_86;
    unsigned int zT_88 = 0;
    zT_B559F9DA_Parser* zT_89;
    unsigned int** zT_90;
    unsigned int* zT_91;
    unsigned int* zT_92;
    unsigned int zT_93;
    zT_B559F9DA_Parser* zT_97;
    zT_3A355BD2_Token zT_98 = {0};
    zT_EAC3E484_TokenKind zT_99;
    zT_B559F9DA_Parser* zT_103;
    zT_3A355BD2_Token zT_104 = {0};
    zT_B559F9DA_Parser* zT_105;
    zT_CB78802F_EU_49 zT_109 = {0};
    unsigned char zT_110;
    int zT_111;
    zT_3B6EA323_EU_01 zT_112;
    zT_2B3424E9_ParseToken zT_113;
    int zT_115;
    unsigned int zT_116;
    int zT_117;
    zT_6B0A7D14_AstStore* zT_119;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_120;
    int zT_122;
    unsigned int* zT_123;
    unsigned int zT_124;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_125;
    unsigned int zT_126 = 0;
    int zT_128;
    unsigned char zT_129;
    unsigned char zT_133;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned char zT_136;
    unsigned int zT_137;
    unsigned int zT_142;
    unsigned int zT_147;
    unsigned short zT_148;
    int zT_151;
    int zT_153;
    int zT_155;
    unsigned int zT_157 = 0;
    zT_3B6EA323_EU_01 zT_158;
    zT_3A355BD2_Token tok;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken npt;
    unsigned int name_id;
    unsigned int field_type;
    unsigned int field_node;
    unsigned int payload;
    unsigned char flags;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_5 = self;
    zT_9 = zF_5578C74F_parserExpect(zT_5, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = zT_9.data.err;
    zT_12.data.err = zT_11;
    zT_12.is_error = 1;
    return zT_12;
    z_bb_2:
    zT_13 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_13;
    fields_buf = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fields_count = zT_18;
    zT_20 = 0;
    fields_cap = zT_20;
    goto z_bb_4;
    z_bb_4:
    zT_21 = self;
    zT_22 = zF_068A2DE5_parserPeek(zT_21);
    zT_23 = zT_22.kind;
    if ((unsigned char)(zT_23 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_28 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_105 = self;
    zT_109 = zF_5578C74F_parserExpect(zT_105, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_110 = zT_109.is_error;
    if (zT_110) goto z_bb_19; else goto z_bb_20;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_9:
    zT_36 = zT_32.data.payload;
    goto z_bb_10;
    z_bb_10:
    name_tok = zT_36;
    zT_37 = self;
    zT_41 = zF_5578C74F_parserExpect(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = zT_41.data.err;
    zT_44.data.err = zT_43;
    zT_44.is_error = 1;
    return zT_44;
    z_bb_12:
    zT_45 = zT_41.data.payload;
    goto z_bb_13;
    z_bb_13:
    (void)zT_45;
    zT_48 = name_tok.kind;
    zT_47.kind = zT_48;
    zT_49 = name_tok.span_start;
    zT_47.span_start = zT_49;
    zT_50 = name_tok.span_len;
    zT_47.span_len = zT_50;
    npt = zT_47;
    zT_52 = self->interner;
    zT_55 = self;
    zT_56 = npt;
    zT_57 = zF_08D61E58_parserTokenText(zT_55, zT_56);
    zT_53 = zT_57;
    zT_58 = zF_50C274AF_stringInternerInter(zT_52, zT_53);
    name_id = zT_58;
    zT_60 = self;
    zT_61 = zF_CBDBFE85_parserParseType(zT_60);
    zT_62 = zT_61.is_error;
    if (zT_62) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return zT_61;
    z_bb_15:
    zT_63 = zT_61.data.payload;
    goto z_bb_16;
    z_bb_16:
    field_type = zT_63;
    zT_65 = self->store;
    zT_77 = 0;
    zT_68 = name_tok.span_start;
    zT_80 = name_tok.span_start;
    zT_81 = name_tok.span_len;
    zT_70 = field_type;
    zT_84 = 0;
    zT_86 = 0;
    zT_73 = name_id;
    zT_88 = zF_6C9FF72F_astStoreAddNode(zT_65, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_77), zT_68, (unsigned int)(zT_80 + (unsigned int)((unsigned int)zT_81)), zT_70, (unsigned int)((unsigned int)zT_84), (unsigned int)((unsigned int)zT_86), zT_73);
    field_node = zT_88;
    zT_89 = self;
    zT_90 = &fields_buf;
    zT_91 = &fields_count;
    zT_92 = &fields_cap;
    zT_93 = field_node;
    zF_0F1462F8_parserPushU32(zT_89, zT_90, zT_91, zT_92, zT_93);
    zT_97 = self;
    zT_98 = zF_068A2DE5_parserPeek(zT_97);
    zT_99 = zT_98.kind;
    if ((unsigned char)(zT_99 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_103 = self;
    zT_104 = zF_C241B2C4_parserAdvance(zT_103);
    (void)zT_104;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_7;
    z_bb_19:
    zT_111 = zT_109.data.err;
    zT_112.data.err = zT_111;
    zT_112.is_error = 1;
    return zT_112;
    z_bb_20:
    zT_113 = zT_109.data.payload;
    goto z_bb_21;
    z_bb_21:
    (void)zT_113;
    zT_115 = 0;
    zT_116 = (unsigned int)zT_115;
    payload = zT_116;
    zT_117 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_117)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_119 = self->store;
    zT_122 = 0;
    zT_123 = fields_buf + zT_122;
    zT_124 = fields_count - zT_122;
    zT_125.ptr = zT_123;
    zT_125.len = zT_124;
    zT_120 = zT_125;
    zT_126 = zF_583E993C_astStoreAddExtraChi(zT_119, zT_120);
    payload = zT_126;
    goto z_bb_23;
    z_bb_23:
    zT_128 = 0;
    zT_129 = (unsigned char)zT_128;
    flags = zT_129;
    if ((unsigned char)(is_packed != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_133 = flags | (unsigned char)(16);
    flags = zT_133;
    goto z_bb_25;
    z_bb_25:
    zT_134 = self->store;
    zT_136 = flags;
    zT_137 = tok.span_start;
    zT_147 = tok.span_start;
    zT_148 = tok.span_len;
    zT_151 = 0;
    zT_153 = 0;
    zT_155 = 0;
    zT_142 = payload;
    zT_157 = zF_6C9FF72F_astStoreAddNode(zT_134, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl), zT_136, zT_137, (unsigned int)(zT_147 + (unsigned int)((unsigned int)zT_148)), (unsigned int)((unsigned int)zT_151), (unsigned int)((unsigned int)zT_153), (unsigned int)((unsigned int)zT_155), zT_142);
    zT_158.data.payload = zT_157;
    zT_158.is_error = 0;
    return zT_158;
}

/* parserParseEnumType */
zT_3B6EA323_EU_01 zF_63EC2480_parserParseEnumType(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_15;
    zT_3B6EA323_EU_01 zT_16 = {0};
    unsigned char zT_17;
    unsigned int zT_18;
    zT_B559F9DA_Parser* zT_19;
    zT_CB78802F_EU_49 zT_23 = {0};
    unsigned char zT_24;
    int zT_25;
    zT_3B6EA323_EU_01 zT_26;
    zT_2B3424E9_ParseToken zT_27;
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    unsigned int* zT_38 = 0;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_B559F9DA_Parser* zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    zT_B559F9DA_Parser* zT_51;
    zT_CB78802F_EU_49 zT_55 = {0};
    unsigned char zT_56;
    int zT_57;
    zT_3B6EA323_EU_01 zT_58;
    zT_2B3424E9_ParseToken zT_59;
    zT_2B3424E9_ParseToken zT_61;
    zT_EAC3E484_TokenKind zT_62;
    unsigned int zT_63;
    unsigned short zT_64;
    zT_D3EB6303_StringInterner* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_B559F9DA_Parser* zT_69;
    zT_2B3424E9_ParseToken zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71 = {0};
    unsigned int zT_72 = 0;
    int zT_74;
    unsigned int zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_B559F9DA_Parser* zT_82;
    zT_3A355BD2_Token zT_83 = {0};
    zT_B559F9DA_Parser* zT_84;
    zT_3B6EA323_EU_01 zT_87 = {0};
    unsigned char zT_88;
    unsigned int zT_89;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_94;
    unsigned int zT_97;
    unsigned int zT_99;
    int zT_103;
    unsigned int zT_106;
    unsigned short zT_107;
    int zT_110;
    int zT_112;
    unsigned int zT_114 = 0;
    zT_B559F9DA_Parser* zT_115;
    unsigned int** zT_116;
    unsigned int* zT_117;
    unsigned int* zT_118;
    unsigned int zT_119;
    zT_B559F9DA_Parser* zT_123;
    zT_3A355BD2_Token zT_124 = {0};
    zT_EAC3E484_TokenKind zT_125;
    zT_B559F9DA_Parser* zT_129;
    zT_3A355BD2_Token zT_130 = {0};
    zT_B559F9DA_Parser* zT_131;
    zT_CB78802F_EU_49 zT_135 = {0};
    unsigned char zT_136;
    int zT_137;
    zT_3B6EA323_EU_01 zT_138;
    zT_2B3424E9_ParseToken zT_139;
    int zT_141;
    unsigned int zT_142;
    int zT_143;
    zT_6B0A7D14_AstStore* zT_145;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_146;
    int zT_148;
    unsigned int* zT_149;
    unsigned int zT_150;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_151;
    unsigned int zT_152 = 0;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_156;
    unsigned int zT_158;
    unsigned int zT_161;
    int zT_165;
    unsigned int zT_168;
    unsigned short zT_169;
    int zT_172;
    int zT_174;
    unsigned int zT_176 = 0;
    zT_3B6EA323_EU_01 zT_177;
    zT_3A355BD2_Token tok;
    unsigned int backing_type2;
    unsigned int* members_buf;
    unsigned int members_count;
    unsigned int members_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken mpt;
    unsigned int name_id;
    unsigned int value_expr;
    unsigned int mnode;
    unsigned int payload;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    backing_type2 = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_15 = self;
    zT_16 = zF_CBDBFE85_parserParseType(zT_15);
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_28 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    return zT_16;
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    backing_type2 = zT_18;
    zT_19 = self;
    zT_23 = zF_5578C74F_parserExpect(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = zT_23.data.err;
    zT_26.data.err = zT_25;
    zT_26.is_error = 1;
    return zT_26;
    z_bb_7:
    zT_27 = zT_23.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_27;
    goto z_bb_2;
    z_bb_9:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_10:
    zT_36 = zT_32.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_36;
    members_buf = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    members_count = zT_41;
    zT_43 = 0;
    members_cap = zT_43;
    goto z_bb_12;
    z_bb_12:
    zT_44 = self;
    zT_45 = zF_068A2DE5_parserPeek(zT_44);
    zT_46 = zT_45.kind;
    if ((unsigned char)(zT_46 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_51 = self;
    zT_55 = zF_5578C74F_parserExpect(zT_51, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_56 = zT_55.is_error;
    if (zT_56) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_131 = self;
    zT_135 = zF_5578C74F_parserExpect(zT_131, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_136 = zT_135.is_error;
    if (zT_136) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = zT_55.data.err;
    zT_58.data.err = zT_57;
    zT_58.is_error = 1;
    return zT_58;
    z_bb_17:
    zT_59 = zT_55.data.payload;
    goto z_bb_18;
    z_bb_18:
    name_tok = zT_59;
    zT_62 = name_tok.kind;
    zT_61.kind = zT_62;
    zT_63 = name_tok.span_start;
    zT_61.span_start = zT_63;
    zT_64 = name_tok.span_len;
    zT_61.span_len = zT_64;
    mpt = zT_61;
    zT_66 = self->interner;
    zT_69 = self;
    zT_70 = mpt;
    zT_71 = zF_08D61E58_parserTokenText(zT_69, zT_70);
    zT_67 = zT_71;
    zT_72 = zF_50C274AF_stringInternerInter(zT_66, zT_67);
    name_id = zT_72;
    zT_74 = 0;
    zT_75 = (unsigned int)zT_74;
    value_expr = zT_75;
    zT_76 = self;
    zT_77 = zF_068A2DE5_parserPeek(zT_76);
    zT_78 = zT_77.kind;
    if ((unsigned char)(zT_78 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_82 = self;
    zT_83 = zF_C241B2C4_parserAdvance(zT_82);
    (void)zT_83;
    zT_84 = self;
    zT_87 = zF_F07C1F04_parserParseExprPrec(zT_84, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_88 = zT_87.is_error;
    if (zT_88) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_91 = self->store;
    zT_103 = 0;
    zT_94 = name_tok.span_start;
    zT_106 = name_tok.span_start;
    zT_107 = name_tok.span_len;
    zT_110 = 0;
    zT_97 = value_expr;
    zT_112 = 0;
    zT_99 = name_id;
    zT_114 = zF_6C9FF72F_astStoreAddNode(zT_91, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_103), zT_94, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), (unsigned int)((unsigned int)zT_110), zT_97, (unsigned int)((unsigned int)zT_112), zT_99);
    mnode = zT_114;
    zT_115 = self;
    zT_116 = &members_buf;
    zT_117 = &members_count;
    zT_118 = &members_cap;
    zT_119 = mnode;
    zF_0F1462F8_parserPushU32(zT_115, zT_116, zT_117, zT_118, zT_119);
    zT_123 = self;
    zT_124 = zF_068A2DE5_parserPeek(zT_123);
    zT_125 = zT_124.kind;
    if ((unsigned char)(zT_125 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    return zT_87;
    z_bb_22:
    zT_89 = zT_87.data.payload;
    goto z_bb_23;
    z_bb_23:
    value_expr = zT_89;
    goto z_bb_20;
    z_bb_24:
    zT_129 = self;
    zT_130 = zF_C241B2C4_parserAdvance(zT_129);
    (void)zT_130;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_15;
    z_bb_26:
    zT_137 = zT_135.data.err;
    zT_138.data.err = zT_137;
    zT_138.is_error = 1;
    return zT_138;
    z_bb_27:
    zT_139 = zT_135.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_139;
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    payload = zT_142;
    zT_143 = 0;
    if ((unsigned char)(members_count > (unsigned int)zT_143)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_145 = self->store;
    zT_148 = 0;
    zT_149 = members_buf + zT_148;
    zT_150 = members_count - zT_148;
    zT_151.ptr = zT_149;
    zT_151.len = zT_150;
    zT_146 = zT_151;
    zT_152 = zF_583E993C_astStoreAddExtraChi(zT_145, zT_146);
    payload = zT_152;
    goto z_bb_30;
    z_bb_30:
    zT_153 = self->store;
    zT_165 = 0;
    zT_156 = tok.span_start;
    zT_168 = tok.span_start;
    zT_169 = tok.span_len;
    zT_158 = backing_type2;
    zT_172 = 0;
    zT_174 = 0;
    zT_161 = payload;
    zT_176 = zF_6C9FF72F_astStoreAddNode(zT_153, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl), (unsigned char)((unsigned char)zT_165), zT_156, (unsigned int)(zT_168 + (unsigned int)((unsigned int)zT_169)), zT_158, (unsigned int)((unsigned int)zT_172), (unsigned int)((unsigned int)zT_174), zT_161);
    zT_177.data.payload = zT_176;
    zT_177.is_error = 0;
    return zT_177;
}

/* parserParseUnionType */
zT_3B6EA323_EU_01 zF_0881F8E4_parserParseUnionTyp(zT_B559F9DA_Parser* self, unsigned char is_packed) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned char zT_7;
    int zT_9;
    unsigned char zT_10;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_EAC3E484_TokenKind zT_13;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_B559F9DA_Parser* zT_19;
    zT_CB78802F_EU_49 zT_23 = {0};
    unsigned char zT_24;
    int zT_25;
    zT_3B6EA323_EU_01 zT_26;
    zT_2B3424E9_ParseToken zT_27;
    zT_B559F9DA_Parser* zT_28;
    zT_CB78802F_EU_49 zT_32 = {0};
    unsigned char zT_33;
    int zT_34;
    zT_3B6EA323_EU_01 zT_35;
    zT_2B3424E9_ParseToken zT_36;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_DBF3575C_ParserError zT_51;
    zT_3B6EA323_EU_01 zT_52;
    unsigned char zT_56;
    unsigned char zT_60;
    zT_B559F9DA_Parser* zT_61;
    zT_CB78802F_EU_49 zT_65 = {0};
    unsigned char zT_66;
    int zT_67;
    zT_3B6EA323_EU_01 zT_68;
    zT_2B3424E9_ParseToken zT_69;
    unsigned int* zT_71 = 0;
    int zT_73;
    unsigned int zT_74;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_77;
    zT_3A355BD2_Token zT_78 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_B559F9DA_Parser* zT_84;
    zT_CB78802F_EU_49 zT_88 = {0};
    unsigned char zT_89;
    int zT_90;
    zT_3B6EA323_EU_01 zT_91;
    zT_2B3424E9_ParseToken zT_92;
    zT_2B3424E9_ParseToken zT_94;
    zT_EAC3E484_TokenKind zT_95;
    unsigned int zT_96;
    unsigned short zT_97;
    zT_D3EB6303_StringInterner* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    zT_B559F9DA_Parser* zT_102;
    zT_2B3424E9_ParseToken zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104 = {0};
    unsigned int zT_105 = 0;
    int zT_107;
    unsigned int zT_108;
    zT_B559F9DA_Parser* zT_109;
    zT_3A355BD2_Token zT_110 = {0};
    zT_EAC3E484_TokenKind zT_111;
    zT_B559F9DA_Parser* zT_115;
    zT_3A355BD2_Token zT_116 = {0};
    zT_B559F9DA_Parser* zT_118;
    zT_3B6EA323_EU_01 zT_119 = {0};
    unsigned char zT_120;
    unsigned int zT_121;
    zT_6B0A7D14_AstStore* zT_122;
    unsigned int zT_125;
    unsigned int zT_127;
    unsigned int zT_130;
    int zT_134;
    unsigned int zT_137;
    unsigned short zT_138;
    int zT_141;
    int zT_143;
    unsigned int zT_145 = 0;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_149;
    unsigned int zT_154;
    int zT_158;
    unsigned int zT_161;
    unsigned short zT_162;
    int zT_165;
    int zT_167;
    int zT_169;
    unsigned int zT_171 = 0;
    zT_B559F9DA_Parser* zT_172;
    unsigned int** zT_173;
    unsigned int* zT_174;
    unsigned int* zT_175;
    unsigned int zT_176;
    zT_B559F9DA_Parser* zT_180;
    zT_3A355BD2_Token zT_181 = {0};
    zT_EAC3E484_TokenKind zT_182;
    zT_B559F9DA_Parser* zT_186;
    zT_3A355BD2_Token zT_187 = {0};
    zT_B559F9DA_Parser* zT_188;
    zT_CB78802F_EU_49 zT_192 = {0};
    unsigned char zT_193;
    int zT_194;
    zT_3B6EA323_EU_01 zT_195;
    zT_2B3424E9_ParseToken zT_196;
    int zT_198;
    unsigned int zT_199;
    int zT_200;
    zT_6B0A7D14_AstStore* zT_202;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_203;
    int zT_205;
    unsigned int* zT_206;
    unsigned int zT_207;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_208;
    unsigned int zT_209 = 0;
    zT_8143F551_AstKind zT_212;
    int zT_213;
    zT_6B0A7D14_AstStore* zT_215;
    zT_8143F551_AstKind zT_216;
    unsigned char zT_217;
    unsigned int zT_218;
    unsigned int zT_223;
    unsigned int zT_226;
    unsigned short zT_227;
    int zT_230;
    int zT_232;
    int zT_234;
    unsigned int zT_236 = 0;
    zT_3B6EA323_EU_01 zT_237;
    zT_3A355BD2_Token tok;
    unsigned char flags;
    unsigned char is_tagged;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_msg;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken upt;
    unsigned int name_id;
    unsigned int field_node;
    unsigned int field_type;
    unsigned int payload;
    zT_8143F551_AstKind kind;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned char)zT_6;
    flags = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_11 = self;
    zT_12 = zF_068A2DE5_parserPeek(zT_11);
    zT_13 = zT_12.kind;
    if ((unsigned char)(zT_13 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = self;
    zT_18 = zF_C241B2C4_parserAdvance(zT_17);
    (void)zT_18;
    zT_19 = self;
    zT_23 = zF_5578C74F_parserExpect(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(is_tagged != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_25 = zT_23.data.err;
    zT_26.data.err = zT_25;
    zT_26.is_error = 1;
    return zT_26;
    z_bb_4:
    zT_27 = zT_23.data.payload;
    goto z_bb_5;
    z_bb_5:
    (void)zT_27;
    zT_28 = self;
    zT_32 = zF_5578C74F_parserExpect(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_34 = zT_32.data.err;
    zT_35.data.err = zT_34;
    zT_35.is_error = 1;
    return zT_35;
    z_bb_7:
    zT_36 = zT_32.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_36;
    zT_37 = 1;
    zT_38 = (unsigned char)zT_37;
    is_tagged = zT_38;
    goto z_bb_2;
    z_bb_9:
    zT_41 = is_packed != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_41 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_41) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_45 = "packed unions cannot be tagged (union(enum)); packed union is an untagged container";
    zT_47 = 83;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    tag_msg = zT_46;
    zT_48 = self;
    zT_49 = tok;
    zT_50 = tag_msg;
    zF_17DF2CA5_parserAddError(zT_48, zT_49, zT_50);
    zT_51 = 1;
    zT_52.data.err = zT_51;
    zT_52.is_error = 1;
    return zT_52;
    z_bb_13:
    if ((unsigned char)(is_tagged != (unsigned char)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_56 = flags | (unsigned char)(1);
    flags = zT_56;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(is_packed != (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_60 = flags | (unsigned char)(16);
    flags = zT_60;
    goto z_bb_17;
    z_bb_17:
    zT_61 = self;
    zT_65 = zF_5578C74F_parserExpect(zT_61, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_66 = zT_65.is_error;
    if (zT_66) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_67 = zT_65.data.err;
    zT_68.data.err = zT_67;
    zT_68.is_error = 1;
    return zT_68;
    z_bb_19:
    zT_69 = zT_65.data.payload;
    goto z_bb_20;
    z_bb_20:
    (void)zT_69;
    fields_buf = zT_71;
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    fields_count = zT_74;
    zT_76 = 0;
    fields_cap = zT_76;
    goto z_bb_21;
    z_bb_21:
    zT_77 = self;
    zT_78 = zF_068A2DE5_parserPeek(zT_77);
    zT_79 = zT_78.kind;
    if ((unsigned char)(zT_79 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_84 = self;
    zT_88 = zF_5578C74F_parserExpect(zT_84, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_89 = zT_88.is_error;
    if (zT_89) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_188 = self;
    zT_192 = zF_5578C74F_parserExpect(zT_188, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_193 = zT_192.is_error;
    if (zT_193) goto z_bb_36; else goto z_bb_37;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_90 = zT_88.data.err;
    zT_91.data.err = zT_90;
    zT_91.is_error = 1;
    return zT_91;
    z_bb_26:
    zT_92 = zT_88.data.payload;
    goto z_bb_27;
    z_bb_27:
    name_tok = zT_92;
    zT_95 = name_tok.kind;
    zT_94.kind = zT_95;
    zT_96 = name_tok.span_start;
    zT_94.span_start = zT_96;
    zT_97 = name_tok.span_len;
    zT_94.span_len = zT_97;
    upt = zT_94;
    zT_99 = self->interner;
    zT_102 = self;
    zT_103 = upt;
    zT_104 = zF_08D61E58_parserTokenText(zT_102, zT_103);
    zT_100 = zT_104;
    zT_105 = zF_50C274AF_stringInternerInter(zT_99, zT_100);
    name_id = zT_105;
    zT_107 = 0;
    zT_108 = (unsigned int)zT_107;
    field_node = zT_108;
    zT_109 = self;
    zT_110 = zF_068A2DE5_parserPeek(zT_109);
    zT_111 = zT_110.kind;
    if ((unsigned char)(zT_111 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_115 = self;
    zT_116 = zF_C241B2C4_parserAdvance(zT_115);
    (void)zT_116;
    zT_118 = self;
    zT_119 = zF_CBDBFE85_parserParseType(zT_118);
    zT_120 = zT_119.is_error;
    if (zT_120) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_172 = self;
    zT_173 = &fields_buf;
    zT_174 = &fields_count;
    zT_175 = &fields_cap;
    zT_176 = field_node;
    zF_0F1462F8_parserPushU32(zT_172, zT_173, zT_174, zT_175, zT_176);
    zT_180 = self;
    zT_181 = zF_068A2DE5_parserPeek(zT_180);
    zT_182 = zT_181.kind;
    if ((unsigned char)(zT_182 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    zT_146 = self->store;
    zT_158 = 0;
    zT_149 = name_tok.span_start;
    zT_161 = name_tok.span_start;
    zT_162 = name_tok.span_len;
    zT_165 = 0;
    zT_167 = 0;
    zT_169 = 0;
    zT_154 = name_id;
    zT_171 = zF_6C9FF72F_astStoreAddNode(zT_146, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_158), zT_149, (unsigned int)(zT_161 + (unsigned int)((unsigned int)zT_162)), (unsigned int)((unsigned int)zT_165), (unsigned int)((unsigned int)zT_167), (unsigned int)((unsigned int)zT_169), zT_154);
    field_node = zT_171;
    goto z_bb_29;
    z_bb_31:
    return zT_119;
    z_bb_32:
    zT_121 = zT_119.data.payload;
    goto z_bb_33;
    z_bb_33:
    field_type = zT_121;
    zT_122 = self->store;
    zT_134 = 0;
    zT_125 = name_tok.span_start;
    zT_137 = name_tok.span_start;
    zT_138 = name_tok.span_len;
    zT_127 = field_type;
    zT_141 = 0;
    zT_143 = 0;
    zT_130 = name_id;
    zT_145 = zF_6C9FF72F_astStoreAddNode(zT_122, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_134), zT_125, (unsigned int)(zT_137 + (unsigned int)((unsigned int)zT_138)), zT_127, (unsigned int)((unsigned int)zT_141), (unsigned int)((unsigned int)zT_143), zT_130);
    field_node = zT_145;
    goto z_bb_29;
    z_bb_34:
    zT_186 = self;
    zT_187 = zF_C241B2C4_parserAdvance(zT_186);
    (void)zT_187;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_24;
    z_bb_36:
    zT_194 = zT_192.data.err;
    zT_195.data.err = zT_194;
    zT_195.is_error = 1;
    return zT_195;
    z_bb_37:
    zT_196 = zT_192.data.payload;
    goto z_bb_38;
    z_bb_38:
    (void)zT_196;
    zT_198 = 0;
    zT_199 = (unsigned int)zT_198;
    payload = zT_199;
    zT_200 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_200)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_202 = self->store;
    zT_205 = 0;
    zT_206 = fields_buf + zT_205;
    zT_207 = fields_count - zT_205;
    zT_208.ptr = zT_206;
    zT_208.len = zT_207;
    zT_203 = zT_208;
    zT_209 = zF_583E993C_astStoreAddExtraChi(zT_202, zT_203);
    payload = zT_209;
    goto z_bb_40;
    z_bb_40:
    zT_212 = zT_8143F551_AstKind_union_decl;
    kind = zT_212;
    zT_213 = 0;
    if ((unsigned char)(is_tagged != zT_213)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_42;
    z_bb_42:
    zT_215 = self->store;
    zT_216 = kind;
    zT_217 = flags;
    zT_218 = tok.span_start;
    zT_226 = tok.span_start;
    zT_227 = tok.span_len;
    zT_230 = 0;
    zT_232 = 0;
    zT_234 = 0;
    zT_223 = payload;
    zT_236 = zF_6C9FF72F_astStoreAddNode(zT_215, zT_216, zT_217, zT_218, (unsigned int)(zT_226 + (unsigned int)((unsigned int)zT_227)), (unsigned int)((unsigned int)zT_230), (unsigned int)((unsigned int)zT_232), (unsigned int)((unsigned int)zT_234), zT_223);
    zT_237.data.payload = zT_236;
    zT_237.is_error = 0;
    return zT_237;
}

/* parserParseTypeName */
zT_3B6EA323_EU_01 zF_C8A1E2C6_parserParseTypeName(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_2B3424E9_ParseToken zT_5;
    zT_EAC3E484_TokenKind zT_6;
    unsigned int zT_7;
    unsigned short zT_8;
    zT_D3EB6303_StringInterner* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_B559F9DA_Parser* zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15 = {0};
    unsigned int zT_16 = 0;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_31 = 0;
    zT_B559F9DA_Parser* zT_32;
    zT_3A355BD2_Token zT_33 = {0};
    zT_EAC3E484_TokenKind zT_34;
    zT_B559F9DA_Parser* zT_38;
    zT_3A355BD2_Token zT_39 = {0};
    zT_B559F9DA_Parser* zT_41;
    zT_CB78802F_EU_49 zT_45 = {0};
    unsigned char zT_46;
    int zT_47;
    zT_3B6EA323_EU_01 zT_48;
    zT_2B3424E9_ParseToken zT_49;
    zT_2B3424E9_ParseToken zT_51;
    zT_EAC3E484_TokenKind zT_52;
    unsigned int zT_53;
    unsigned short zT_54;
    zT_D3EB6303_StringInterner* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_B559F9DA_Parser* zT_59;
    zT_2B3424E9_ParseToken zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61 = {0};
    unsigned int zT_62 = 0;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_71;
    int zT_75;
    unsigned int zT_78;
    unsigned short zT_79;
    int zT_82;
    int zT_84;
    unsigned int zT_86 = 0;
    zT_3B6EA323_EU_01 zT_87;
    zT_3A355BD2_Token tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    unsigned int node;
    zT_2B3424E9_ParseToken field_tok;
    zT_2B3424E9_ParseToken fpt;
    unsigned int field_id;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_6 = tok.kind;
    zT_5.kind = zT_6;
    zT_7 = tok.span_start;
    zT_5.span_start = zT_7;
    zT_8 = tok.span_len;
    zT_5.span_len = zT_8;
    pt = zT_5;
    zT_10 = self->interner;
    zT_13 = self;
    zT_14 = pt;
    zT_15 = zF_08D61E58_parserTokenText(zT_13, zT_14);
    zT_11 = zT_15;
    zT_16 = zF_50C274AF_stringInternerInter(zT_10, zT_11);
    name_id = zT_16;
    zT_18 = self->store;
    zT_20 = name_id;
    zT_21 = tok.span_start;
    zT_27 = tok.span_start;
    zT_28 = tok.span_len;
    zT_31 = zF_1DF77BD4_astStoreAddIdentifi(zT_18, (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr), zT_20, zT_21, (unsigned int)(zT_27 + (unsigned int)((unsigned int)zT_28)));
    node = zT_31;
    goto z_bb_1;
    z_bb_1:
    zT_32 = self;
    zT_33 = zF_068A2DE5_parserPeek(zT_32);
    zT_34 = zT_33.kind;
    if ((unsigned char)(zT_34 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = self;
    zT_39 = zF_C241B2C4_parserAdvance(zT_38);
    (void)zT_39;
    zT_41 = self;
    zT_45 = zF_5578C74F_parserExpect(zT_41, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_87.data.payload = node;
    zT_87.is_error = 0;
    return zT_87;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_47 = zT_45.data.err;
    zT_48.data.err = zT_47;
    zT_48.is_error = 1;
    return zT_48;
    z_bb_6:
    zT_49 = zT_45.data.payload;
    goto z_bb_7;
    z_bb_7:
    field_tok = zT_49;
    zT_52 = field_tok.kind;
    zT_51.kind = zT_52;
    zT_53 = field_tok.span_start;
    zT_51.span_start = zT_53;
    zT_54 = field_tok.span_len;
    zT_51.span_len = zT_54;
    fpt = zT_51;
    zT_56 = self->interner;
    zT_59 = self;
    zT_60 = fpt;
    zT_61 = zF_08D61E58_parserTokenText(zT_59, zT_60);
    zT_57 = zT_61;
    zT_62 = zF_50C274AF_stringInternerInter(zT_56, zT_57);
    field_id = zT_62;
    zT_63 = self->store;
    zT_75 = 0;
    zT_66 = tok.span_start;
    zT_78 = field_tok.span_start;
    zT_79 = field_tok.span_len;
    zT_68 = node;
    zT_82 = 0;
    zT_84 = 0;
    zT_71 = field_id;
    zT_86 = zF_6C9FF72F_astStoreAddNode(zT_63, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access), (unsigned char)((unsigned char)zT_75), zT_66, (unsigned int)(zT_78 + (unsigned int)((unsigned int)zT_79)), zT_68, (unsigned int)((unsigned int)zT_82), (unsigned int)((unsigned int)zT_84), zT_71);
    node = zT_86;
    goto z_bb_4;
}

/* parserParseStatement */
zT_3B6EA323_EU_01 zF_462FC60E_parserParseStatemen(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_EAC3E484_TokenKind zT_14;
    int zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22 = 0;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_EAC3E484_TokenKind zT_39;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3B6EA323_EU_01 zT_57 = {0};
    zT_EAC3E484_TokenKind zT_58;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_B559F9DA_Parser* zT_67;
    zT_3B6EA323_EU_01 zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    zT_B559F9DA_Parser* zT_81;
    zT_3B6EA323_EU_01 zT_82 = {0};
    zT_EAC3E484_TokenKind zT_83;
    zT_B559F9DA_Parser* zT_87;
    zT_3B6EA323_EU_01 zT_90 = {0};
    zT_EAC3E484_TokenKind zT_91;
    zT_B559F9DA_Parser* zT_95;
    zT_3B6EA323_EU_01 zT_98 = {0};
    zT_EAC3E484_TokenKind zT_99;
    zT_B559F9DA_Parser* zT_103;
    unsigned char zT_108;
    unsigned int zT_113;
    zT_3B6EA323_EU_01 zT_114 = {0};
    zT_EAC3E484_TokenKind zT_115;
    zT_B559F9DA_Parser* zT_119;
    zT_3B6EA323_EU_01 zT_120 = {0};
    zT_EAC3E484_TokenKind zT_121;
    zT_B559F9DA_Parser* zT_125;
    zT_3B6EA323_EU_01 zT_126 = {0};
    zT_EAC3E484_TokenKind zT_127;
    zT_B559F9DA_Parser* zT_131;
    zT_3B6EA323_EU_01 zT_132 = {0};
    zT_EAC3E484_TokenKind zT_133;
    zT_B559F9DA_Parser* zT_137;
    zT_3B6EA323_EU_01 zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    zT_B559F9DA_Parser* zT_143;
    zT_3B6EA323_EU_01 zT_144 = {0};
    zT_EAC3E484_TokenKind zT_145;
    zT_B559F9DA_Parser* zT_149;
    zT_3B6EA323_EU_01 zT_150 = {0};
    zT_EAC3E484_TokenKind zT_151;
    zT_B559F9DA_Parser* zT_155;
    zT_3B6EA323_EU_01 zT_156 = {0};
    zT_EAC3E484_TokenKind zT_157;
    zT_B559F9DA_Parser* zT_161;
    zT_3B6EA323_EU_01 zT_165 = {0};
    zT_EAC3E484_TokenKind zT_166;
    zT_B559F9DA_Parser* zT_170;
    zT_3B6EA323_EU_01 zT_171 = {0};
    zT_EAC3E484_TokenKind zT_172;
    zT_B559F9DA_Parser* zT_176;
    zT_3B6EA323_EU_01 zT_177 = {0};
    zT_EAC3E484_TokenKind zT_178;
    zT_B559F9DA_Parser* zT_182;
    zT_3B6EA323_EU_01 zT_186 = {0};
    zT_EAC3E484_TokenKind zT_187;
    zT_B559F9DA_Parser* zT_191;
    zT_3B6EA323_EU_01 zT_195 = {0};
    zT_EAC3E484_TokenKind zT_196;
    zT_B559F9DA_Parser* zT_200;
    zT_3B6EA323_EU_01 zT_204 = {0};
    zT_EAC3E484_TokenKind zT_205;
    zT_B559F9DA_Parser* zT_209;
    zT_3B6EA323_EU_01 zT_210 = {0};
    zT_EAC3E484_TokenKind zT_211;
    zT_B559F9DA_Parser* zT_215;
    zT_3A355BD2_Token zT_216 = {0};
    zT_B559F9DA_Parser* zT_217;
    zT_EAC3E484_TokenKind zT_219;
    zT_B559F9DA_Parser* zT_223;
    int zT_225;
    zT_3A355BD2_Token zT_227 = {0};
    zT_EAC3E484_TokenKind zT_228;
    zT_B559F9DA_Parser* zT_232;
    zT_3B6EA323_EU_01 zT_233 = {0};
    zT_B559F9DA_Parser* zT_234;
    zT_3B6EA323_EU_01 zT_235 = {0};
    zT_B559F9DA_Parser* zT_236;
    zT_3B6EA323_EU_01 zT_237 = {0};
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pstk_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pstk_b;
    unsigned int pstk_l;
    unsigned int pstk_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pstk_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u varc_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u varv_s;
    z_bb_0:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    tok = zT_3;
    zT_5 = "PSTK:k";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    pstk_m = zT_6;
    zT_8 = pstk_m;
    zF_48AC7B3A_markerWrite(zT_8);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pstk_b[_i] = zT_10[_i];
        _i++;
    }
}
    zT_14 = tok.kind;
    zT_18 = 0;
    zT_19 = (unsigned char*)((unsigned char*)pstk_b) + zT_18;
    zT_20 = (unsigned int)(10) - zT_18;
    zT_21.ptr = zT_19;
    zT_21.len = zT_20;
    zT_13 = zT_21;
    zT_22 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_14), zT_13);
    pstk_l = zT_22;
    zT_26 = (unsigned int)(9) - (unsigned int)((unsigned int)pstk_l);
    pstk_s = zT_26;
    zT_31 = (unsigned char*)((unsigned char*)pstk_b) + pstk_s;
    zT_32 = (unsigned int)(9) - pstk_s;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zF_48AC7B3A_markerWrite(zT_27);
    zT_35 = "\n";
    zT_37 = 1;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    pstk_nl = zT_36;
    zT_38 = pstk_nl;
    zF_48AC7B3A_markerWrite(zT_38);
    zT_39 = tok.kind;
    if ((unsigned char)(zT_39 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_44 = "VARC";
    zT_46 = 4;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    varc_s = zT_45;
    zT_47 = varc_s;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_48 = self;
    zT_57 = zF_7D11B416_parserParseVarDecl(zT_48, (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0));
    return zT_57;
    z_bb_2:
    zT_58 = tok.kind;
    if ((unsigned char)(zT_58 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_63 = "VARV";
    zT_65 = 4;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    varv_s = zT_64;
    zT_66 = varv_s;
    zF_48AC7B3A_markerWrite(zT_66);
    zT_67 = self;
    zT_76 = zF_7D11B416_parserParseVarDecl(zT_67, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0));
    return zT_76;
    z_bb_4:
    zT_77 = tok.kind;
    if ((unsigned char)(zT_77 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_pub))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_81 = self;
    zT_82 = zF_A8314C30_parserParsePubDecl(zT_81);
    return zT_82;
    z_bb_6:
    zT_83 = tok.kind;
    if ((unsigned char)(zT_83 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_87 = self;
    zT_90 = zF_A0D31A63_parserParseExternDe(zT_87, (unsigned char)(0));
    return zT_90;
    z_bb_8:
    zT_91 = tok.kind;
    if ((unsigned char)(zT_91 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_95 = self;
    zT_98 = zF_C3CD8237_parserParseExportDe(zT_95, (unsigned char)(0));
    return zT_98;
    z_bb_10:
    zT_99 = tok.kind;
    if ((unsigned char)(zT_99 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_103 = self;
    zT_113 = 0;
    zT_108 = zT_113;
    zT_114 = zF_3D879A25_parserParseFnDecl(zT_103, (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), zT_108);
    return zT_114;
    z_bb_12:
    zT_115 = tok.kind;
    if ((unsigned char)(zT_115 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_119 = self;
    zT_120 = zF_DB819578_parserParseIfStmt(zT_119);
    return zT_120;
    z_bb_14:
    zT_121 = tok.kind;
    if ((unsigned char)(zT_121 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_while))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_125 = self;
    zT_126 = zF_4E7AD820_parserParseWhileStm(zT_125);
    return zT_126;
    z_bb_16:
    zT_127 = tok.kind;
    if ((unsigned char)(zT_127 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_for))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_131 = self;
    zT_132 = zF_54BCF0C6_parserParseForStmt(zT_131);
    return zT_132;
    z_bb_18:
    zT_133 = tok.kind;
    if ((unsigned char)(zT_133 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_switch))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_137 = self;
    zT_138 = zF_3A6F34C7_parserParseSwitchSt(zT_137);
    return zT_138;
    z_bb_20:
    zT_139 = tok.kind;
    if ((unsigned char)(zT_139 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_return))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_143 = self;
    zT_144 = zF_76F5B9F1_parserParseReturnSt(zT_143);
    return zT_144;
    z_bb_22:
    zT_145 = tok.kind;
    if ((unsigned char)(zT_145 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_break))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_149 = self;
    zT_150 = zF_6DA396FE_parserParseBreakStm(zT_149);
    return zT_150;
    z_bb_24:
    zT_151 = tok.kind;
    if ((unsigned char)(zT_151 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_continue))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_155 = self;
    zT_156 = zF_E13A9822_parserParseContinue(zT_155);
    return zT_156;
    z_bb_26:
    zT_157 = tok.kind;
    if ((unsigned char)(zT_157 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_defer))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_161 = self;
    zT_165 = zF_3B25AFD5_parserParseDeferStm(zT_161, (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt));
    return zT_165;
    z_bb_28:
    zT_166 = tok.kind;
    if ((unsigned char)(zT_166 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_errdefer))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_170 = self;
    zT_171 = zF_6C2E50E6_parserParseErrdefer(zT_170);
    return zT_171;
    z_bb_30:
    zT_172 = tok.kind;
    if ((unsigned char)(zT_172 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_176 = self;
    zT_177 = zF_15A196A5_parserParseTestDecl(zT_176);
    return zT_177;
    z_bb_32:
    zT_178 = tok.kind;
    if ((unsigned char)(zT_178 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_struct))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_182 = self;
    zT_186 = zF_0A0E9C6C_parserParseContaine(zT_182, (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl));
    return zT_186;
    z_bb_34:
    zT_187 = tok.kind;
    if ((unsigned char)(zT_187 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_191 = self;
    zT_195 = zF_0A0E9C6C_parserParseContaine(zT_191, (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl));
    return zT_195;
    z_bb_36:
    zT_196 = tok.kind;
    if ((unsigned char)(zT_196 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_union))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_200 = self;
    zT_204 = zF_0A0E9C6C_parserParseContaine(zT_200, (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl));
    return zT_204;
    z_bb_38:
    zT_205 = tok.kind;
    if ((unsigned char)(zT_205 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_209 = self;
    zT_210 = zF_365CA04A_parserParseBlock(zT_209);
    return zT_210;
    z_bb_40:
    zT_211 = tok.kind;
    if ((unsigned char)(zT_211 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_215 = self;
    zT_216 = zF_C241B2C4_parserAdvance(zT_215);
    (void)zT_216;
    zT_217 = self;
    self = zT_217;
    goto z_bb_0;
    z_bb_42:
    zT_219 = tok.kind;
    if ((unsigned char)(zT_219 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_223 = self;
    zT_225 = 1;
    zT_227 = zF_F685E431_parserPeekN(zT_223, (unsigned int)((unsigned int)zT_225));
    zT_228 = zT_227.kind;
    if ((unsigned char)(zT_228 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_236 = self;
    zT_237 = zF_907B11F0_parserParseExprStmt(zT_236);
    return zT_237;
    z_bb_45:
    zT_232 = self;
    zT_233 = zF_BF6ABAB2_parserParseLabeledS(zT_232);
    return zT_233;
    z_bb_46:
    zT_234 = self;
    zT_235 = zF_907B11F0_parserParseExprStmt(zT_234);
    return zT_235;
}

/* parserEmitErrorNode */
unsigned int zF_8A97D8C1_parserEmitErrorNode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_9;
    int zT_18;
    unsigned int zT_21;
    unsigned short zT_22;
    int zT_25;
    int zT_27;
    int zT_29;
    int zT_31;
    unsigned int zT_33 = 0;
    zT_3 = self;
    zT_4 = tok;
    zT_5 = msg;
    zF_17DF2CA5_parserAddError(zT_3, zT_4, zT_5);
    zT_6 = self->store;
    zT_18 = 0;
    zT_9 = tok.span_start;
    zT_21 = tok.span_start;
    zT_22 = tok.span_len;
    zT_25 = 0;
    zT_27 = 0;
    zT_29 = 0;
    zT_31 = 0;
    zT_33 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_err), (unsigned char)((unsigned char)zT_18), zT_9, (unsigned int)(zT_21 + (unsigned int)((unsigned int)zT_22)), (unsigned int)((unsigned int)zT_25), (unsigned int)((unsigned int)zT_27), (unsigned int)((unsigned int)zT_29), (unsigned int)((unsigned int)zT_31));
    return zT_33;
}

/* parserParseModuleRoot */
zT_3B6EA323_EU_01 zF_224ED3B5_parserParseModuleRo(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_EAC3E484_TokenKind zT_4;
    zT_B559F9DA_Parser* zT_9;
    zT_3B6EA323_EU_01 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_21;
    zT_3A355BD2_Token zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24 = 0;
    zT_B559F9DA_Parser* zT_25;
    unsigned int** zT_26;
    unsigned int* zT_27;
    unsigned int* zT_28;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    unsigned int** zT_44;
    unsigned int* zT_45;
    unsigned int* zT_46;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_59;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_60;
    unsigned int* zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int* zT_65;
    unsigned int zT_66;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_67;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_77;
    int zT_81;
    int zT_83;
    int zT_85;
    int zT_87;
    int zT_89;
    int zT_91;
    unsigned int zT_93 = 0;
    zT_3B6EA323_EU_01 zT_94;
    unsigned int decl;
    unsigned int payload;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    unsigned int err;
    self->decl_buf_len = (unsigned int)(0);
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_068A2DE5_parserPeek(zT_2);
    zT_4 = zT_3.kind;
    if ((unsigned char)(zT_4 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_10 = zF_462FC60E_parserParseStatemen(zT_9);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    payload = zT_55;
    zT_56 = self->decl_buf_len;
    if ((unsigned char)(zT_56 > (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    tok = zT_15;
    zT_17 = "unexpected token";
    zT_19 = 16;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    err_msg = zT_18;
    zT_21 = self;
    zT_22 = tok;
    zT_23 = err_msg;
    zT_24 = zF_8A97D8C1_parserEmitErrorNode(zT_21, zT_22, zT_23);
    err = zT_24;
    zT_25 = self;
    zF_4190C400_parserSynchronize(zT_25);
    zT_26 = &self->decl_buf_items;
    zT_27 = &self->decl_buf_len;
    zT_28 = &self->decl_buf_capacity;
    zT_29 = self->allocator;
    zT_30 = err;
    zF_8B163A32_u32ArrayListAppendI(zT_26, zT_27, zT_28, zT_29, zT_30);
    goto z_bb_8;
    z_bb_6:
    zT_12 = zT_10.data.payload;
    goto z_bb_7;
    z_bb_7:
    decl = zT_12;
    zT_44 = &self->decl_buf_items;
    zT_45 = &self->decl_buf_len;
    zT_46 = &self->decl_buf_capacity;
    zT_47 = self->allocator;
    zT_48 = decl;
    zF_8B163A32_u32ArrayListAppendI(zT_44, zT_45, zT_46, zT_47, zT_48);
    goto z_bb_4;
    z_bb_8:
    zT_35 = self;
    zT_36 = zF_068A2DE5_parserPeek(zT_35);
    zT_37 = zT_36.kind;
    if ((unsigned char)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    goto z_bb_11;
    z_bb_10:
    goto z_bb_4;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_59 = self->store;
    zT_62 = self->decl_buf_items;
    zT_63 = self->decl_buf_len;
    zT_64 = 0;
    zT_65 = zT_62 + zT_64;
    zT_66 = zT_63 - zT_64;
    zT_67.ptr = zT_65;
    zT_67.len = zT_66;
    zT_60 = zT_67;
    zT_68 = zF_583E993C_astStoreAddExtraChi(zT_59, zT_60);
    payload = zT_68;
    goto z_bb_13;
    z_bb_13:
    zT_69 = self->store;
    zT_81 = 0;
    zT_83 = 0;
    zT_85 = 0;
    zT_87 = 0;
    zT_89 = 0;
    zT_91 = 0;
    zT_77 = payload;
    zT_93 = zF_6C9FF72F_astStoreAddNode(zT_69, (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root), (unsigned char)((unsigned char)zT_81), (unsigned int)((unsigned int)zT_83), (unsigned int)((unsigned int)zT_85), (unsigned int)((unsigned int)zT_87), (unsigned int)((unsigned int)zT_89), (unsigned int)((unsigned int)zT_91), zT_77);
    zT_94.data.payload = zT_93;
    zT_94.is_error = 0;
    return zT_94;
}

/* parserParseExprStmt */
zT_3B6EA323_EU_01 zF_907B11F0_parserParseExprStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_7;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    zT_B559F9DA_Parser* zT_14;
    zT_CB78802F_EU_49 zT_18 = {0};
    unsigned char zT_19;
    int zT_20;
    zT_3B6EA323_EU_01 zT_21;
    zT_2B3424E9_ParseToken zT_22;
    zT_3B6EA323_EU_01 zT_23;
    unsigned int result;
    zT_2 = self;
    zT_5 = zF_F07C1F04_parserParseExprPrec(zT_2, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_6 = zT_5.is_error;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_5;
    z_bb_2:
    zT_7 = zT_5.data.payload;
    goto z_bb_3;
    z_bb_3:
    result = zT_7;
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    if ((unsigned char)(zT_10 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = self;
    zT_18 = zF_5578C74F_parserExpect(zT_14, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_23.data.payload = result;
    zT_23.is_error = 0;
    return zT_23;
    z_bb_6:
    zT_20 = zT_18.data.err;
    zT_21.data.err = zT_20;
    zT_21.is_error = 1;
    return zT_21;
    z_bb_7:
    zT_22 = zT_18.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_22;
    goto z_bb_5;
}

/* parserParseLabeledStmt */
zT_3B6EA323_EU_01 zF_BF6ABAB2_parserParseLabeledS(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    unsigned char zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_27;
    int zT_31;
    unsigned int zT_34;
    unsigned short zT_35;
    int zT_38;
    int zT_40;
    zT_85CBA4DB_TokenValue zT_42;
    unsigned int zT_44 = 0;
    zT_3B6EA323_EU_01 zT_45;
    zT_3A355BD2_Token label_tok;
    unsigned int inner;
    unsigned int end;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_462FC60E_parserParseStatemen(zT_14);
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_15;
    z_bb_5:
    zT_17 = zT_15.data.payload;
    goto z_bb_6;
    z_bb_6:
    inner = zT_17;
    end = inner;
    (void)end;
    zT_19 = self->store;
    zT_31 = 0;
    zT_22 = label_tok.span_start;
    zT_34 = label_tok.span_start;
    zT_35 = label_tok.span_len;
    zT_24 = inner;
    zT_38 = 0;
    zT_40 = 0;
    zT_42 = label_tok.value;
    zT_27 = zT_42.string_id;
    zT_44 = zF_6C9FF72F_astStoreAddNode(zT_19, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_31), zT_22, (unsigned int)(zT_34 + (unsigned int)((unsigned int)zT_35)), zT_24, (unsigned int)((unsigned int)zT_38), (unsigned int)((unsigned int)zT_40), zT_27);
    zT_45.data.payload = zT_44;
    zT_45.is_error = 0;
    return zT_45;
}

/* parserParseLabeledBlockExpr */
zT_3B6EA323_EU_01 zF_532B277E_parserParseLabeledB(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_15 = {0};
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_3A355BD2_Token zT_22;
    unsigned int zT_23;
    unsigned short zT_24;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35;
    int zT_39;
    int zT_42;
    int zT_44;
    zT_85CBA4DB_TokenValue zT_46;
    unsigned int zT_48 = 0;
    zT_3B6EA323_EU_01 zT_49;
    zT_3A355BD2_Token label_tok;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    label_tok = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_15 = zF_365CA04A_parserParseBlock(zT_14);
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_15;
    z_bb_5:
    zT_17 = zT_15.data.payload;
    goto z_bb_6;
    z_bb_6:
    body = zT_17;
    zT_19 = label_tok.span_start;
    end_pos = zT_19;
    zT_20 = self->last_tok_valid;
    if (zT_20) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_22 = self->last_tok;
    last = zT_22;
    zT_23 = last.span_start;
    zT_24 = last.span_len;
    zT_26 = zT_23 + (unsigned int)((unsigned int)zT_24);
    end_pos = zT_26;
    goto z_bb_8;
    z_bb_8:
    zT_27 = self->store;
    zT_39 = 0;
    zT_30 = label_tok.span_start;
    zT_31 = end_pos;
    zT_32 = body;
    zT_42 = 0;
    zT_44 = 0;
    zT_46 = label_tok.value;
    zT_35 = zT_46.string_id;
    zT_48 = zF_6C9FF72F_astStoreAddNode(zT_27, (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt), (unsigned char)((unsigned char)zT_39), zT_30, zT_31, zT_32, (unsigned int)((unsigned int)zT_42), (unsigned int)((unsigned int)zT_44), zT_35);
    zT_49.data.payload = zT_48;
    zT_49.is_error = 0;
    return zT_49;
}

/* parserParseVarDecl */
zT_3B6EA323_EU_01 zF_7D11B416_parserParseVarDecl(zT_B559F9DA_Parser* self, unsigned char is_mutable, unsigned char is_pub, unsigned char is_extern, unsigned char is_export) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_B559F9DA_Parser* zT_11;
    zT_3A355BD2_Token zT_12 = {0};
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_EAC3E484_TokenKind zT_16;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_CB78802F_EU_49 zT_26 = {0};
    unsigned char zT_27;
    int zT_28;
    zT_3B6EA323_EU_01 zT_29;
    zT_2B3424E9_ParseToken zT_30;
    zT_85CBA4DB_TokenValue zT_32;
    unsigned int zT_33;
    int zT_35;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_40;
    unsigned char zT_42;
    unsigned char zT_44;
    int zT_46;
    unsigned int zT_47;
    zT_B559F9DA_Parser* zT_48;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_B559F9DA_Parser* zT_56;
    zT_3B6EA323_EU_01 zT_57 = {0};
    unsigned char zT_58;
    unsigned int zT_59;
    int zT_61;
    unsigned int zT_62;
    zT_B559F9DA_Parser* zT_63;
    zT_3A355BD2_Token zT_64 = {0};
    zT_EAC3E484_TokenKind zT_65;
    zT_B559F9DA_Parser* zT_69;
    zT_3A355BD2_Token zT_70 = {0};
    zT_B559F9DA_Parser* zT_71;
    zT_3B6EA323_EU_01 zT_74 = {0};
    unsigned char zT_75;
    unsigned int zT_76;
    zT_B559F9DA_Parser* zT_78;
    zT_CB78802F_EU_49 zT_82 = {0};
    unsigned char zT_83;
    int zT_84;
    zT_3B6EA323_EU_01 zT_85;
    zT_2B3424E9_ParseToken zT_86;
    unsigned int zT_88;
    unsigned short zT_89;
    unsigned int zT_91;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_22A7C88B_AstNode zT_108 = {0};
    zT_8143F551_AstKind zT_109;
    zT_3B6EA323_EU_01 zT_113;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned char zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_122;
    int zT_127;
    unsigned int zT_129 = 0;
    zT_3B6EA323_EU_01 zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_3A355BD2_Token kw;
    zT_3A355BD2_Token name_raw;
    unsigned int name_id;
    unsigned char flags;
    unsigned int type_node;
    unsigned int init_node;
    zT_2B3424E9_ParseToken semi;
    unsigned int end_pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u vok;
    zT_8F083A69_Slice_zT_0B42B2F8_u pdv_s;
    zT_22A7C88B_AstNode init_check;
    zT_6 = "V";
    zT_8 = 1;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    vmsg = zT_7;
    zT_9 = vmsg;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self;
    zT_12 = zF_C241B2C4_parserAdvance(zT_11);
    kw = zT_12;
    zT_14 = self;
    zT_15 = zF_068A2DE5_parserPeek(zT_14);
    name_raw = zT_15;
    zT_16 = name_raw.kind;
    if ((unsigned char)(zT_16 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_20 = self;
    zT_21 = zF_C241B2C4_parserAdvance(zT_20);
    (void)zT_21;
    goto z_bb_2;
    z_bb_2:
    zT_32 = name_raw.value;
    zT_33 = zT_32.string_id;
    name_id = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned char)zT_35;
    flags = zT_36;
    if (is_mutable) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_22 = self;
    zT_26 = zF_5578C74F_parserExpect(zT_22, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = zT_26.data.err;
    zT_29.data.err = zT_28;
    zT_29.is_error = 1;
    return zT_29;
    z_bb_5:
    zT_30 = zT_26.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_30;
    goto z_bb_2;
    z_bb_7:
    zT_38 = flags | (unsigned char)(1);
    flags = zT_38;
    goto z_bb_8;
    z_bb_8:
    if (is_pub) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_40 = flags | (unsigned char)(2);
    flags = zT_40;
    goto z_bb_10;
    z_bb_10:
    if (is_extern) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = flags | (unsigned char)(4);
    flags = zT_42;
    goto z_bb_12;
    z_bb_12:
    if (is_export) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_44 = flags | (unsigned char)(8);
    flags = zT_44;
    goto z_bb_14;
    z_bb_14:
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    type_node = zT_47;
    zT_48 = self;
    zT_49 = zF_068A2DE5_parserPeek(zT_48);
    zT_50 = zT_49.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = self;
    zT_55 = zF_C241B2C4_parserAdvance(zT_54);
    (void)zT_55;
    zT_56 = self;
    zT_57 = zF_CBDBFE85_parserParseType(zT_56);
    zT_58 = zT_57.is_error;
    if (zT_58) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_61 = 0;
    zT_62 = (unsigned int)zT_61;
    init_node = zT_62;
    zT_63 = self;
    zT_64 = zF_068A2DE5_parserPeek(zT_63);
    zT_65 = zT_64.kind;
    if ((unsigned char)(zT_65 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_20; else goto z_bb_21;
    z_bb_17:
    return zT_57;
    z_bb_18:
    zT_59 = zT_57.data.payload;
    goto z_bb_19;
    z_bb_19:
    type_node = zT_59;
    goto z_bb_16;
    z_bb_20:
    zT_69 = self;
    zT_70 = zF_C241B2C4_parserAdvance(zT_69);
    (void)zT_70;
    zT_71 = self;
    zT_74 = zF_F07C1F04_parserParseExprPrec(zT_71, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_78 = self;
    zT_82 = zF_5578C74F_parserExpect(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_83 = zT_82.is_error;
    if (zT_83) goto z_bb_25; else goto z_bb_26;
    z_bb_22:
    return zT_74;
    z_bb_23:
    zT_76 = zT_74.data.payload;
    goto z_bb_24;
    z_bb_24:
    init_node = zT_76;
    goto z_bb_21;
    z_bb_25:
    zT_84 = zT_82.data.err;
    zT_85.data.err = zT_84;
    zT_85.is_error = 1;
    return zT_85;
    z_bb_26:
    zT_86 = zT_82.data.payload;
    goto z_bb_27;
    z_bb_27:
    semi = zT_86;
    zT_88 = semi.span_start;
    zT_89 = semi.span_len;
    zT_91 = zT_88 + (unsigned int)((unsigned int)zT_89);
    end_pos = zT_91;
    zT_93 = "v";
    zT_95 = 1;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    vok = zT_94;
    zT_96 = vok;
    zF_48AC7B3A_markerWrite(zT_96);
    zT_98 = "PDVx";
    zT_100 = 4;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    pdv_s = zT_99;
    zT_101 = pdv_s;
    zF_48AC7B3A_markerWrite(zT_101);
    if ((unsigned char)(init_node != (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_105 = self->store;
    zT_106 = init_node;
    zT_108 = zF_FCDD1D35_astStoreNodeAt(zT_105, zT_106);
    init_check = zT_108;
    zT_109 = init_check.kind;
    if ((unsigned char)(zT_109 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_114 = self->store;
    zT_116 = flags;
    zT_117 = kw.span_start;
    zT_118 = end_pos;
    zT_119 = type_node;
    zT_120 = init_node;
    zT_127 = 0;
    zT_122 = name_id;
    zT_129 = zF_6C9FF72F_astStoreAddNode(zT_114, (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl), zT_116, zT_117, zT_118, zT_119, zT_120, (unsigned int)((unsigned int)zT_127), zT_122);
    zT_130.data.payload = zT_129;
    zT_130.is_error = 0;
    return zT_130;
    z_bb_30:
    zT_113.data.payload = init_node;
    zT_113.is_error = 0;
    return zT_113;
    z_bb_31:
    goto z_bb_29;
}

/* parserParsePubDecl */
zT_3B6EA323_EU_01 zF_A8314C30_parserParsePubDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3A355BD2_Token zT_2 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6;
    zT_B559F9DA_Parser* zT_10;
    unsigned char zT_15;
    unsigned int zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_35 = {0};
    zT_EAC3E484_TokenKind zT_36;
    zT_B559F9DA_Parser* zT_40;
    zT_3B6EA323_EU_01 zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    zT_B559F9DA_Parser* zT_54;
    zT_3B6EA323_EU_01 zT_55 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_B559F9DA_Parser* zT_60;
    zT_3B6EA323_EU_01 zT_63 = {0};
    zT_EAC3E484_TokenKind zT_64;
    zT_B559F9DA_Parser* zT_68;
    zT_3B6EA323_EU_01 zT_71 = {0};
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_B559F9DA_Parser* zT_76;
    zT_3A355BD2_Token zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_DBF3575C_ParserError zT_79;
    zT_3B6EA323_EU_01 zT_80;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_1 = self;
    zT_2 = zF_C241B2C4_parserAdvance(zT_1);
    (void)zT_2;
    zT_4 = self;
    zT_5 = zF_068A2DE5_parserPeek(zT_4);
    tok = zT_5;
    zT_6 = tok.kind;
    if ((unsigned char)(zT_6 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_20 = 0;
    zT_15 = zT_20;
    zT_21 = zF_3D879A25_parserParseFnDecl(zT_10, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), (unsigned char)(0), zT_15);
    return zT_21;
    z_bb_2:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = self;
    zT_35 = zF_7D11B416_parserParseVarDecl(zT_26, (unsigned char)(0), (unsigned char)(1), (unsigned char)(0), (unsigned char)(0));
    return zT_35;
    z_bb_4:
    zT_36 = tok.kind;
    if ((unsigned char)(zT_36 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_40 = self;
    zT_49 = zF_7D11B416_parserParseVarDecl(zT_40, (unsigned char)(1), (unsigned char)(1), (unsigned char)(0), (unsigned char)(0));
    return zT_49;
    z_bb_6:
    zT_50 = tok.kind;
    if ((unsigned char)(zT_50 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_test))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_54 = self;
    zT_55 = zF_15A196A5_parserParseTestDecl(zT_54);
    return zT_55;
    z_bb_8:
    zT_56 = tok.kind;
    if ((unsigned char)(zT_56 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_extern))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_60 = self;
    zT_63 = zF_A0D31A63_parserParseExternDe(zT_60, (unsigned char)(1));
    return zT_63;
    z_bb_10:
    zT_64 = tok.kind;
    if ((unsigned char)(zT_64 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_export))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_68 = self;
    zT_71 = zF_C3CD8237_parserParseExportDe(zT_68, (unsigned char)(1));
    return zT_71;
    z_bb_12:
    zT_73 = "expected fn/const/var after pub";
    zT_75 = 31;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    p_msg = zT_74;
    zT_76 = self;
    zT_77 = tok;
    zT_78 = p_msg;
    zF_17DF2CA5_parserAddError(zT_76, zT_77, zT_78);
    zT_79 = 1;
    zT_80.data.err = zT_79;
    zT_80.is_error = 1;
    return zT_80;
}

/* parserClassifyCallConv */
unsigned char zF_A095D9EA_parserClassifyCallC(zT_B559F9DA_Parser* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    unsigned char zT_6;
    unsigned char* zT_7;
    int zT_8;
    unsigned char zT_9;
    unsigned int zT_14;
    int zT_15;
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    unsigned char* zT_24;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned char* zT_30;
    int zT_31;
    unsigned char zT_32;
    unsigned char zT_35;
    unsigned char* zT_36;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char* zT_42;
    int zT_43;
    unsigned char zT_44;
    unsigned int zT_49;
    int zT_50;
    unsigned char zT_52;
    unsigned char* zT_53;
    int zT_54;
    unsigned char zT_55;
    unsigned char zT_58;
    unsigned char* zT_59;
    int zT_60;
    unsigned char zT_61;
    unsigned char zT_64;
    unsigned char* zT_65;
    int zT_66;
    unsigned char zT_67;
    unsigned char zT_70;
    unsigned char* zT_71;
    int zT_72;
    unsigned char zT_73;
    unsigned char zT_76;
    unsigned char* zT_77;
    int zT_78;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned char zT_85;
    unsigned char zT_88;
    unsigned char* zT_89;
    int zT_90;
    unsigned char zT_91;
    (void)self;
    zT_3 = text.len;
    zT_4 = 1;
    if ((unsigned char)(zT_3 == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = text.ptr;
    zT_8 = 0;
    zT_9 = zT_7[zT_8];
    zT_6 = zT_9 == (unsigned char)(99);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_14 = text.len;
    zT_15 = 5;
    if ((unsigned char)(zT_14 == (unsigned int)zT_15)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = text.ptr;
    zT_19 = 0;
    zT_20 = zT_18[zT_19];
    zT_17 = zT_20 == (unsigned char)(99);
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_24 = text.ptr;
    zT_25 = 1;
    zT_26 = zT_24[zT_25];
    zT_23 = zT_26 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_23 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_23) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = text.ptr;
    zT_31 = 2;
    zT_32 = zT_30[zT_31];
    zT_29 = zT_32 == (unsigned char)(101);
    goto z_bb_14;
    z_bb_13:
    zT_29 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_29) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_36 = text.ptr;
    zT_37 = 3;
    zT_38 = zT_36[zT_37];
    zT_35 = zT_38 == (unsigned char)(99);
    goto z_bb_17;
    z_bb_16:
    zT_35 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_35) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_42 = text.ptr;
    zT_43 = 4;
    zT_44 = zT_42[zT_43];
    zT_41 = zT_44 == (unsigned char)(108);
    goto z_bb_20;
    z_bb_19:
    zT_41 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_41) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_49 = text.len;
    zT_50 = 7;
    if ((unsigned char)(zT_49 == (unsigned int)zT_50)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_53 = text.ptr;
    zT_54 = 0;
    zT_55 = zT_53[zT_54];
    zT_52 = zT_55 == (unsigned char)(115);
    goto z_bb_25;
    z_bb_24:
    zT_52 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_52) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_59 = text.ptr;
    zT_60 = 1;
    zT_61 = zT_59[zT_60];
    zT_58 = zT_61 == (unsigned char)(116);
    goto z_bb_28;
    z_bb_27:
    zT_58 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_58) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_65 = text.ptr;
    zT_66 = 2;
    zT_67 = zT_65[zT_66];
    zT_64 = zT_67 == (unsigned char)(100);
    goto z_bb_31;
    z_bb_30:
    zT_64 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_64) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_71 = text.ptr;
    zT_72 = 3;
    zT_73 = zT_71[zT_72];
    zT_70 = zT_73 == (unsigned char)(99);
    goto z_bb_34;
    z_bb_33:
    zT_70 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_70) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_77 = text.ptr;
    zT_78 = 4;
    zT_79 = zT_77[zT_78];
    zT_76 = zT_79 == (unsigned char)(97);
    goto z_bb_37;
    z_bb_36:
    zT_76 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_76) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_83 = text.ptr;
    zT_84 = 5;
    zT_85 = zT_83[zT_84];
    zT_82 = zT_85 == (unsigned char)(108);
    goto z_bb_40;
    z_bb_39:
    zT_82 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_82) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_89 = text.ptr;
    zT_90 = 6;
    zT_91 = zT_89[zT_90];
    zT_88 = zT_91 == (unsigned char)(108);
    goto z_bb_43;
    z_bb_42:
    zT_88 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_88) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    return (unsigned char)(1);
    z_bb_45:
    return (unsigned char)(2);
}

/* parserAddErrorCode */
void zF_6E7AEAB4_parserAddErrorCode(zT_B559F9DA_Parser* self, zT_3A355BD2_Token tok, unsigned short code, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_F85C5DED_DiagnosticCollector* zT_4;
    unsigned short zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_15;
    unsigned short zT_16;
    zT_4 = self->diag;
    zT_6 = code;
    zT_7 = self->file_id;
    zT_8 = tok.span_start;
    zT_15 = tok.span_start;
    zT_16 = tok.span_len;
    zT_10 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_4, (unsigned char)(0), zT_6, zT_7, zT_8, (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16)), zT_10);
    return;
}

/* parserParseExternDecl */
zT_3B6EA323_EU_01 zF_A0D31A63_parserParseExternDe(zT_B559F9DA_Parser* self, unsigned char is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_3A355BD2_Token zT_7 = {0};
    zT_EAC3E484_TokenKind zT_8;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_D3EB6303_StringInterner* zT_16;
    unsigned int zT_17;
    zT_85CBA4DB_TokenValue zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    zT_B559F9DA_Parser* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char zT_24 = 0;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_B559F9DA_Parser* zT_31;
    zT_3A355BD2_Token zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_35;
    unsigned int zT_37;
    zT_B559F9DA_Parser* zT_39;
    zT_3A355BD2_Token zT_40 = {0};
    zT_EAC3E484_TokenKind zT_41;
    zT_B559F9DA_Parser* zT_45;
    unsigned char zT_46;
    unsigned char zT_50;
    zT_3B6EA323_EU_01 zT_54 = {0};
    zT_EAC3E484_TokenKind zT_55;
    zT_B559F9DA_Parser* zT_59;
    unsigned char zT_61;
    zT_3B6EA323_EU_01 zT_67 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_B559F9DA_Parser* zT_72;
    unsigned char zT_74;
    zT_3B6EA323_EU_01 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_B559F9DA_Parser* zT_85;
    zT_3A355BD2_Token zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_DBF3575C_ParserError zT_88;
    zT_3B6EA323_EU_01 zT_89;
    unsigned char call_conv;
    zT_3A355BD2_Token str_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u ucv;
    zT_8F083A69_Slice_zT_0B42B2F8_u e_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = 0;
    call_conv = zT_5;
    zT_6 = self;
    zT_7 = zF_068A2DE5_parserPeek(zT_6);
    zT_8 = zT_7.kind;
    if ((unsigned char)(zT_8 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    str_tok = zT_14;
    zT_16 = self->interner;
    zT_19 = str_tok.value;
    zT_17 = zT_19.string_id;
    zT_21 = zF_9134020D_stringInternerGet(zT_16, zT_17);
    text = zT_21;
    zT_22 = self;
    zT_23 = text;
    zT_24 = zF_A095D9EA_parserClassifyCallC(zT_22, zT_23);
    call_conv = zT_24;
    if ((unsigned char)(call_conv == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_39 = self;
    zT_40 = zF_068A2DE5_parserPeek(zT_39);
    tok = zT_40;
    zT_41 = tok.kind;
    if ((unsigned char)(zT_41 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_28 = "unknown calling convention in `extern`";
    zT_30 = 38;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ucv = zT_29;
    zT_31 = self;
    zT_32 = str_tok;
    zT_35 = 3045;
    zT_34 = ucv;
    zF_6E7AEAB4_parserAddErrorCode(zT_31, zT_32, (unsigned short)((unsigned short)zT_35), zT_34);
    zT_37 = 0;
    call_conv = zT_37;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = self;
    zT_46 = is_pub;
    zT_50 = call_conv;
    zT_54 = zF_3D879A25_parserParseFnDecl(zT_45, zT_46, (unsigned char)(1), (unsigned char)(0), (unsigned char)(0), zT_50);
    return zT_54;
    z_bb_6:
    zT_55 = tok.kind;
    if ((unsigned char)(zT_55 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_59 = self;
    zT_61 = is_pub;
    zT_67 = zF_7D11B416_parserParseVarDecl(zT_59, (unsigned char)(0), zT_61, (unsigned char)(1), (unsigned char)(0));
    return zT_67;
    z_bb_8:
    zT_68 = tok.kind;
    if ((unsigned char)(zT_68 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_72 = self;
    zT_74 = is_pub;
    zT_80 = zF_7D11B416_parserParseVarDecl(zT_72, (unsigned char)(1), zT_74, (unsigned char)(1), (unsigned char)(0));
    return zT_80;
    z_bb_10:
    zT_82 = "expected fn/const/var after extern";
    zT_84 = 34;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    e_msg = zT_83;
    zT_85 = self;
    zT_86 = tok;
    zT_87 = e_msg;
    zF_17DF2CA5_parserAddError(zT_85, zT_86, zT_87);
    zT_88 = 1;
    zT_89.data.err = zT_88;
    zT_89.is_error = 1;
    return zT_89;
}

/* parserParseExportDecl */
zT_3B6EA323_EU_01 zF_C3CD8237_parserParseExportDe(zT_B559F9DA_Parser* self, unsigned char is_pub) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_5;
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7;
    zT_B559F9DA_Parser* zT_11;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned int zT_20;
    zT_3B6EA323_EU_01 zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    unsigned char zT_28;
    zT_3B6EA323_EU_01 zT_34 = {0};
    zT_EAC3E484_TokenKind zT_35;
    zT_B559F9DA_Parser* zT_39;
    unsigned char zT_41;
    zT_3B6EA323_EU_01 zT_47 = {0};
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_B559F9DA_Parser* zT_52;
    zT_3A355BD2_Token zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_DBF3575C_ParserError zT_55;
    zT_3B6EA323_EU_01 zT_56;
    zT_3A355BD2_Token tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u x_msg;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    (void)zT_3;
    zT_5 = self;
    zT_6 = zF_068A2DE5_parserPeek(zT_5);
    tok = zT_6;
    zT_7 = tok.kind;
    if ((unsigned char)(zT_7 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = is_pub;
    zT_20 = 0;
    zT_16 = zT_20;
    zT_21 = zF_3D879A25_parserParseFnDecl(zT_11, zT_12, (unsigned char)(0), (unsigned char)(0), (unsigned char)(1), zT_16);
    return zT_21;
    z_bb_2:
    zT_22 = tok.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = self;
    zT_28 = is_pub;
    zT_34 = zF_7D11B416_parserParseVarDecl(zT_26, (unsigned char)(0), zT_28, (unsigned char)(0), (unsigned char)(1));
    return zT_34;
    z_bb_4:
    zT_35 = tok.kind;
    if ((unsigned char)(zT_35 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_var))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_39 = self;
    zT_41 = is_pub;
    zT_47 = zF_7D11B416_parserParseVarDecl(zT_39, (unsigned char)(1), zT_41, (unsigned char)(0), (unsigned char)(1));
    return zT_47;
    z_bb_6:
    zT_49 = "expected fn/const/var after export";
    zT_51 = 34;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    x_msg = zT_50;
    zT_52 = self;
    zT_53 = tok;
    zT_54 = x_msg;
    zF_17DF2CA5_parserAddError(zT_52, zT_53, zT_54);
    zT_55 = 1;
    zT_56.data.err = zT_55;
    zT_56.is_error = 1;
    return zT_56;
}

/* parserParseFnDecl */
zT_3B6EA323_EU_01 zF_3D879A25_parserParseFnDecl(zT_B559F9DA_Parser* self, unsigned char is_pub, unsigned char is_extern, unsigned char is_test, unsigned char is_export, unsigned char call_conv) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_B559F9DA_Parser* zT_12;
    zT_3A355BD2_Token zT_13 = {0};
    int zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    unsigned char zT_20;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_B559F9DA_Parser* zT_26;
    zT_CB78802F_EU_49 zT_30 = {0};
    unsigned char zT_31;
    int zT_32;
    zT_3B6EA323_EU_01 zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    int zT_44;
    zT_B559F9DA_Parser* zT_46;
    zT_3A355BD2_Token zT_47 = {0};
    zT_EAC3E484_TokenKind zT_48;
    unsigned char zT_52;
    zT_B559F9DA_Parser* zT_53;
    zT_3A355BD2_Token zT_54 = {0};
    zT_EAC3E484_TokenKind zT_55;
    zT_B559F9DA_Parser* zT_59;
    zT_3A355BD2_Token zT_60 = {0};
    zT_EAC3E484_TokenKind zT_61;
    zT_B559F9DA_Parser* zT_65;
    zT_3A355BD2_Token zT_66 = {0};
    unsigned char zT_68;
    zT_B559F9DA_Parser* zT_70;
    zT_CB78802F_EU_49 zT_74 = {0};
    unsigned char zT_75;
    int zT_76;
    zT_3B6EA323_EU_01 zT_77;
    zT_2B3424E9_ParseToken zT_78;
    zT_B559F9DA_Parser* zT_79;
    zT_CB78802F_EU_49 zT_83 = {0};
    unsigned char zT_84;
    int zT_85;
    zT_3B6EA323_EU_01 zT_86;
    zT_2B3424E9_ParseToken zT_87;
    zT_B559F9DA_Parser* zT_89;
    zT_3B6EA323_EU_01 zT_90 = {0};
    unsigned char zT_91;
    unsigned int zT_92;
    zT_D3EB6303_StringInterner* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_B559F9DA_Parser* zT_97;
    zT_2B3424E9_ParseToken zT_98;
    zT_2B3424E9_ParseToken zT_99;
    zT_EAC3E484_TokenKind zT_100;
    unsigned int zT_101;
    unsigned short zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103 = {0};
    unsigned int zT_104 = 0;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_114;
    int zT_118;
    int zT_122;
    int zT_124;
    unsigned int zT_126 = 0;
    unsigned int** zT_127;
    unsigned int* zT_128;
    unsigned int* zT_129;
    zT_3E40CD83_Sand* zT_130;
    unsigned int zT_131;
    zT_B559F9DA_Parser* zT_136;
    zT_3A355BD2_Token zT_137 = {0};
    zT_EAC3E484_TokenKind zT_138;
    zT_B559F9DA_Parser* zT_142;
    zT_3A355BD2_Token zT_143 = {0};
    zT_B559F9DA_Parser* zT_144;
    zT_CB78802F_EU_49 zT_148 = {0};
    unsigned char zT_149;
    int zT_150;
    zT_3B6EA323_EU_01 zT_151;
    zT_2B3424E9_ParseToken zT_152;
    int zT_154;
    unsigned int zT_155;
    unsigned short zT_157;
    unsigned int zT_158;
    zT_6B0A7D14_AstStore* zT_162;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_163;
    unsigned int* zT_165;
    unsigned int zT_166;
    int zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_170;
    unsigned int zT_171 = 0;
    zT_6B0A7D14_AstStore* zT_172;
    unsigned int zT_173;
    zT_79FAE712_u64 zT_175 = 0;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned short zT_180;
    int zT_181;
    int zT_184;
    unsigned int zT_185;
    zT_B559F9DA_Parser* zT_186;
    zT_3A355BD2_Token zT_187 = {0};
    zT_EAC3E484_TokenKind zT_188;
    zT_B559F9DA_Parser* zT_192;
    zT_3A355BD2_Token zT_193 = {0};
    zT_B559F9DA_Parser* zT_194;
    zT_3B6EA323_EU_01 zT_195 = {0};
    unsigned char zT_196;
    unsigned int zT_197;
    zT_B559F9DA_Parser* zT_198;
    zT_3A355BD2_Token zT_199 = {0};
    zT_EAC3E484_TokenKind zT_200;
    unsigned char zT_204;
    zT_B559F9DA_Parser* zT_205;
    zT_3A355BD2_Token zT_206 = {0};
    zT_EAC3E484_TokenKind zT_207;
    zT_B559F9DA_Parser* zT_211;
    zT_3B6EA323_EU_01 zT_212 = {0};
    unsigned char zT_213;
    unsigned int zT_214;
    int zT_216;
    unsigned int zT_217;
    unsigned int zT_219 = 0;
    zT_B559F9DA_Parser* zT_220;
    zT_3A355BD2_Token zT_221 = {0};
    zT_EAC3E484_TokenKind zT_222;
    zT_B559F9DA_Parser* zT_227;
    zT_3A355BD2_Token zT_228 = {0};
    unsigned int zT_229;
    unsigned short zT_230;
    unsigned int zT_232;
    zT_B559F9DA_Parser* zT_233;
    zT_3B6EA323_EU_01 zT_234 = {0};
    unsigned char zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    zT_D3EB6303_StringInterner* zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_B559F9DA_Parser* zT_250;
    zT_2B3424E9_ParseToken zT_251;
    zT_2B3424E9_ParseToken zT_252;
    zT_EAC3E484_TokenKind zT_253;
    unsigned int zT_254;
    unsigned short zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256 = {0};
    unsigned int zT_257 = 0;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    zT_4028D896_Arr_unsigned_char_2 zT_264;
    unsigned int zT_266;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    int zT_272;
    unsigned char* zT_273;
    unsigned int zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276 = 0;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned char* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_243D6A41_FnProto zT_294;
    zT_6B0A7D14_AstStore* zT_296;
    zT_243D6A41_FnProto zT_297;
    unsigned int zT_299 = 0;
    int zT_300;
    unsigned char* zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    zT_6B0A7D14_AstStore* zT_307;
    unsigned char zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_315;
    int zT_320;
    int zT_322;
    unsigned int zT_324 = 0;
    zT_3B6EA323_EU_01 zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmsg;
    zT_3A355BD2_Token kw;
    unsigned char flags;
    zT_2B3424E9_ParseToken name_tok;
    zT_2B3424E9_ParseToken param_tok;
    unsigned int param_type;
    unsigned int param_name_id;
    unsigned int param_node;
    unsigned int param_start;
    unsigned short param_count;
    unsigned int pp;
    unsigned int ret_type_node;
    unsigned int body_node;
    unsigned int end_pos;
    zT_3A355BD2_Token semi;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pmsg;
    zT_4028D896_Arr_unsigned_char_2 pa_buf;
    unsigned int pa_val;
    unsigned int pa_len;
    unsigned int pa_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    zT_243D6A41_FnProto proto;
    unsigned int proto_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u fok;
    zT_7 = "Fv";
    zT_9 = 2;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    fmsg = zT_8;
    zT_10 = fmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = self;
    zT_13 = zF_C241B2C4_parserAdvance(zT_12);
    kw = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned char)zT_15;
    flags = zT_16;
    if (is_pub) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = flags | (unsigned char)(2);
    flags = zT_18;
    goto z_bb_2;
    z_bb_2:
    if (is_extern) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = flags | (unsigned char)(4);
    flags = zT_20;
    goto z_bb_4;
    z_bb_4:
    if (is_test) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = flags | (unsigned char)(32);
    flags = zT_22;
    goto z_bb_6;
    z_bb_6:
    if (is_export) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = flags | (unsigned char)(8);
    flags = zT_24;
    goto z_bb_8;
    z_bb_8:
    zT_26 = self;
    zT_30 = zF_5578C74F_parserExpect(zT_26, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = zT_30.data.err;
    zT_33.data.err = zT_32;
    zT_33.is_error = 1;
    return zT_33;
    z_bb_10:
    zT_34 = zT_30.data.payload;
    goto z_bb_11;
    z_bb_11:
    name_tok = zT_34;
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_13:
    zT_43 = zT_39.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_43;
    zT_44 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_44);
    goto z_bb_15;
    z_bb_15:
    zT_46 = self;
    zT_47 = zF_068A2DE5_parserPeek(zT_46);
    zT_48 = zT_47.kind;
    if ((unsigned char)(zT_48 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen))) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_59 = self;
    zT_60 = zF_068A2DE5_parserPeek(zT_59);
    zT_61 = zT_60.kind;
    if ((unsigned char)(zT_61 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot))) goto z_bb_22; else goto z_bb_23;
    z_bb_17:
    zT_144 = self;
    zT_148 = zF_5578C74F_parserExpect(zT_144, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_149 = zT_148.is_error;
    if (zT_149) goto z_bb_35; else goto z_bb_36;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_53 = self;
    zT_54 = zF_068A2DE5_parserPeek(zT_53);
    zT_55 = zT_54.kind;
    zT_52 = zT_55 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_21;
    z_bb_20:
    zT_52 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_52) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_65 = self;
    zT_66 = zF_C241B2C4_parserAdvance(zT_65);
    (void)zT_66;
    zT_68 = flags | (unsigned char)(1);
    flags = zT_68;
    goto z_bb_17;
    z_bb_23:
    zT_70 = self;
    zT_74 = zF_5578C74F_parserExpect(zT_70, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_76 = zT_74.data.err;
    zT_77.data.err = zT_76;
    zT_77.is_error = 1;
    return zT_77;
    z_bb_25:
    zT_78 = zT_74.data.payload;
    goto z_bb_26;
    z_bb_26:
    param_tok = zT_78;
    zT_79 = self;
    zT_83 = zF_5578C74F_parserExpect(zT_79, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_84 = zT_83.is_error;
    if (zT_84) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_85 = zT_83.data.err;
    zT_86.data.err = zT_85;
    zT_86.is_error = 1;
    return zT_86;
    z_bb_28:
    zT_87 = zT_83.data.payload;
    goto z_bb_29;
    z_bb_29:
    (void)zT_87;
    zT_89 = self;
    zT_90 = zF_CBDBFE85_parserParseType(zT_89);
    zT_91 = zT_90.is_error;
    if (zT_91) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    return zT_90;
    z_bb_31:
    zT_92 = zT_90.data.payload;
    goto z_bb_32;
    z_bb_32:
    param_type = zT_92;
    zT_94 = self->interner;
    zT_97 = self;
    zT_100 = param_tok.kind;
    zT_99.kind = zT_100;
    zT_101 = param_tok.span_start;
    zT_99.span_start = zT_101;
    zT_102 = param_tok.span_len;
    zT_99.span_len = zT_102;
    zT_98 = zT_99;
    zT_103 = zF_08D61E58_parserTokenText(zT_97, zT_98);
    zT_95 = zT_103;
    zT_104 = zF_50C274AF_stringInternerInter(zT_94, zT_95);
    param_name_id = zT_104;
    zT_106 = self->store;
    zT_118 = 0;
    zT_109 = param_tok.span_start;
    zT_110 = self->last_end;
    zT_111 = param_type;
    zT_122 = 0;
    zT_124 = 0;
    zT_114 = param_name_id;
    zT_126 = zF_6C9FF72F_astStoreAddNode(zT_106, (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl), (unsigned char)((unsigned char)zT_118), zT_109, zT_110, zT_111, (unsigned int)((unsigned int)zT_122), (unsigned int)((unsigned int)zT_124), zT_114);
    param_node = zT_126;
    zT_127 = &self->child_buf_items;
    zT_128 = &self->child_buf_len;
    zT_129 = &self->child_buf_capacity;
    zT_130 = self->allocator;
    zT_131 = param_node;
    zF_8B163A32_u32ArrayListAppendI(zT_127, zT_128, zT_129, zT_130, zT_131);
    zT_136 = self;
    zT_137 = zF_068A2DE5_parserPeek(zT_136);
    zT_138 = zT_137.kind;
    if ((unsigned char)(zT_138 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_142 = self;
    zT_143 = zF_C241B2C4_parserAdvance(zT_142);
    (void)zT_143;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_18;
    z_bb_35:
    zT_150 = zT_148.data.err;
    zT_151.data.err = zT_150;
    zT_151.is_error = 1;
    return zT_151;
    z_bb_36:
    zT_152 = zT_148.data.payload;
    goto z_bb_37;
    z_bb_37:
    (void)zT_152;
    zT_154 = 0;
    zT_155 = (unsigned int)zT_154;
    param_start = zT_155;
    zT_157 = 0;
    param_count = zT_157;
    zT_158 = self->child_buf_len;
    if ((unsigned char)(zT_158 > (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_162 = self->store;
    zT_165 = self->child_buf_items;
    zT_166 = self->child_buf_len;
    zT_167 = 0;
    zT_168 = zT_165 + zT_167;
    zT_169 = zT_166 - zT_167;
    zT_170.ptr = zT_168;
    zT_170.len = zT_169;
    zT_163 = zT_170;
    zT_171 = zF_583E993C_astStoreAddExtraChi(zT_162, zT_163);
    pp = zT_171;
    zT_172 = self->store;
    zT_173 = pp;
    zT_175 = zF_F956A1CA_astStoreExtraRangeA(zT_172, zT_173);
    zT_178 = (unsigned int)(zT_79FAE712_u64)(zT_175 >> (zT_79FAE712_u64)(32));
    param_start = zT_178;
    zT_179 = self->child_buf_len;
    zT_180 = (unsigned short)zT_179;
    param_count = zT_180;
    zT_181 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_181);
    goto z_bb_39;
    z_bb_39:
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    ret_type_node = zT_185;
    zT_186 = self;
    zT_187 = zF_068A2DE5_parserPeek(zT_186);
    zT_188 = zT_187.kind;
    if ((unsigned char)(zT_188 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_192 = self;
    zT_193 = zF_C241B2C4_parserAdvance(zT_192);
    (void)zT_193;
    zT_194 = self;
    zT_195 = zF_CBDBFE85_parserParseType(zT_194);
    zT_196 = zT_195.is_error;
    if (zT_196) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_216 = 0;
    zT_217 = (unsigned int)zT_216;
    body_node = zT_217;
    end_pos = zT_219;
    zT_220 = self;
    zT_221 = zF_068A2DE5_parserPeek(zT_220);
    zT_222 = zT_221.kind;
    if ((unsigned char)(zT_222 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_54; else goto z_bb_56;
    z_bb_42:
    zT_198 = self;
    zT_199 = zF_068A2DE5_parserPeek(zT_198);
    zT_200 = zT_199.kind;
    if ((unsigned char)(zT_200 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_46; else goto z_bb_47;
    z_bb_43:
    return zT_195;
    z_bb_44:
    zT_197 = zT_195.data.payload;
    goto z_bb_45;
    z_bb_45:
    ret_type_node = zT_197;
    goto z_bb_41;
    z_bb_46:
    zT_205 = self;
    zT_206 = zF_068A2DE5_parserPeek(zT_205);
    zT_207 = zT_206.kind;
    zT_204 = zT_207 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace);
    goto z_bb_48;
    z_bb_47:
    zT_204 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_204) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_211 = self;
    zT_212 = zF_CBDBFE85_parserParseType(zT_211);
    zT_213 = zT_212.is_error;
    if (zT_213) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_41;
    z_bb_51:
    return zT_212;
    z_bb_52:
    zT_214 = zT_212.data.payload;
    goto z_bb_53;
    z_bb_53:
    ret_type_node = zT_214;
    goto z_bb_50;
    z_bb_54:
    zT_227 = self;
    zT_228 = zF_C241B2C4_parserAdvance(zT_227);
    semi = zT_228;
    zT_229 = semi.span_start;
    zT_230 = semi.span_len;
    zT_232 = zT_229 + (unsigned int)((unsigned int)zT_230);
    end_pos = zT_232;
    goto z_bb_55;
    z_bb_55:
    zT_238 = self->child_buf_len;
    if ((unsigned char)(zT_238 > (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    zT_233 = self;
    zT_234 = zF_365CA04A_parserParseBlock(zT_233);
    zT_235 = zT_234.is_error;
    if (zT_235) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return zT_234;
    z_bb_58:
    zT_236 = zT_234.data.payload;
    goto z_bb_59;
    z_bb_59:
    body_node = zT_236;
    zT_237 = self->last_end;
    end_pos = zT_237;
    goto z_bb_55;
    z_bb_60:
    zT_242 = "DP:child_buf_stale\n";
    zT_244 = 19;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    dmsg = zT_243;
    zT_245 = dmsg;
    zF_48AC7B3A_markerWrite(zT_245);
    goto z_bb_61;
    z_bb_61:
    zT_247 = self->interner;
    zT_250 = self;
    zT_253 = name_tok.kind;
    zT_252.kind = zT_253;
    zT_254 = name_tok.span_start;
    zT_252.span_start = zT_254;
    zT_255 = name_tok.span_len;
    zT_252.span_len = zT_255;
    zT_251 = zT_252;
    zT_256 = zF_08D61E58_parserTokenText(zT_250, zT_251);
    zT_248 = zT_256;
    zT_257 = zF_50C274AF_stringInternerInter(zT_247, zT_248);
    name_id = zT_257;
    zT_259 = "P:";
    zT_261 = 2;
    zT_260.ptr = zT_259;
    zT_260.len = zT_261;
    pmsg = zT_260;
    zT_262 = pmsg;
    zF_48AC7B3A_markerWrite(zT_262);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_264[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pa_buf[_i] = zT_264[_i];
        _i++;
    }
}
    zT_266 = (unsigned int)param_count;
    pa_val = zT_266;
    zT_268 = pa_val;
    zT_272 = 0;
    zT_273 = (unsigned char*)((unsigned char*)pa_buf) + zT_272;
    zT_274 = (unsigned int)(20) - zT_272;
    zT_275.ptr = zT_273;
    zT_275.len = zT_274;
    zT_269 = zT_275;
    zT_276 = zF_A7504564_itoa(zT_268, zT_269);
    pa_len = zT_276;
    zT_280 = (unsigned int)(19) - (unsigned int)((unsigned int)pa_len);
    pa_start = zT_280;
    zT_285 = (unsigned char*)((unsigned char*)pa_buf) + pa_start;
    zT_286 = (unsigned int)(19) - pa_start;
    zT_287.ptr = zT_285;
    zT_287.len = zT_286;
    zT_281 = zT_287;
    zF_48AC7B3A_markerWrite(zT_281);
    zT_289 = "\n";
    zT_291 = 1;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    pnl = zT_290;
    zT_292 = pnl;
    zF_48AC7B3A_markerWrite(zT_292);
    zT_294.name_id = name_id;
    zT_294.params_start = param_start;
    zT_294.params_count = param_count;
    zT_294.call_conv = call_conv;
    zT_294.return_type_node = ret_type_node;
    proto = zT_294;
    zT_296 = self->store;
    zT_297 = proto;
    zT_299 = zF_F1F8D02B_astStoreAddFnProto(zT_296, zT_297);
    proto_idx = zT_299;
    zT_300 = 0;
    self->child_buf_len = (unsigned int)((unsigned int)zT_300);
    zT_303 = "Fk";
    zT_305 = 2;
    zT_304.ptr = zT_303;
    zT_304.len = zT_305;
    fok = zT_304;
    zT_306 = fok;
    zF_48AC7B3A_markerWrite(zT_306);
    zT_307 = self->store;
    zT_309 = flags;
    zT_310 = kw.span_start;
    zT_311 = end_pos;
    zT_312 = body_node;
    zT_320 = 0;
    zT_322 = 0;
    zT_315 = proto_idx;
    zT_324 = zF_6C9FF72F_astStoreAddNode(zT_307, (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl), zT_309, zT_310, zT_311, zT_312, (unsigned int)((unsigned int)zT_320), (unsigned int)((unsigned int)zT_322), zT_315);
    zT_325.data.payload = zT_324;
    zT_325.is_error = 0;
    return zT_325;
}

/* parserParseIfStmt */
zT_3B6EA323_EU_01 zF_DB819578_parserParseIfStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_26;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36 = 0;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_8143F551_AstKind zT_63;
    int zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    int zT_96;
    unsigned char* zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100 = 0;
    unsigned int zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned char* zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_118;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    int zT_125;
    unsigned char* zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129 = 0;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned char* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    zT_22A7C88B_AstNode zT_151 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    zT_8143F551_AstKind zT_157;
    int zT_161;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165 = 0;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned char* zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    zT_22A7C88B_AstNode zT_187 = {0};
    zT_5A26C2ED_Arr_unsigned_char_1 zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_8143F551_AstKind zT_193;
    int zT_197;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201 = 0;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned char* zT_210;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    zT_B559F9DA_Parser* zT_218;
    zT_CB78802F_EU_49 zT_222 = {0};
    unsigned char zT_223;
    int zT_224;
    zT_3B6EA323_EU_01 zT_225;
    zT_2B3424E9_ParseToken zT_226;
    int zT_228;
    unsigned int zT_229;
    zT_B559F9DA_Parser* zT_230;
    zT_3A355BD2_Token zT_231 = {0};
    zT_EAC3E484_TokenKind zT_232;
    zT_B559F9DA_Parser* zT_236;
    zT_3A355BD2_Token zT_237 = {0};
    zT_2B3424E9_ParseToken zT_239 = {0};
    zT_B559F9DA_Parser* zT_240;
    zT_3A355BD2_Token zT_241 = {0};
    zT_EAC3E484_TokenKind zT_242;
    zT_B559F9DA_Parser* zT_246;
    zT_CB78802F_EU_49 zT_250 = {0};
    unsigned char zT_251;
    int zT_252;
    zT_3B6EA323_EU_01 zT_253;
    zT_2B3424E9_ParseToken zT_254;
    zT_B559F9DA_Parser* zT_255;
    zT_CB78802F_EU_49 zT_259 = {0};
    unsigned char zT_260;
    int zT_261;
    zT_3B6EA323_EU_01 zT_262;
    zT_2B3424E9_ParseToken zT_263;
    zT_B559F9DA_Parser* zT_264;
    zT_CB78802F_EU_49 zT_268 = {0};
    unsigned char zT_269;
    int zT_270;
    zT_3B6EA323_EU_01 zT_271;
    zT_2B3424E9_ParseToken zT_272;
    zT_2B3424E9_ParseToken zT_274;
    zT_EAC3E484_TokenKind zT_275;
    unsigned int zT_276;
    unsigned short zT_277;
    zT_D3EB6303_StringInterner* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    zT_B559F9DA_Parser* zT_282;
    zT_2B3424E9_ParseToken zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284 = {0};
    unsigned int zT_285 = 0;
    zT_6B0A7D14_AstStore* zT_286;
    unsigned int zT_289;
    unsigned int zT_294;
    int zT_298;
    unsigned int zT_301;
    unsigned short zT_302;
    int zT_305;
    int zT_307;
    int zT_309;
    unsigned int zT_311 = 0;
    unsigned int zT_313 = 0;
    zT_B559F9DA_Parser* zT_314;
    zT_3A355BD2_Token zT_315 = {0};
    zT_EAC3E484_TokenKind zT_316;
    zT_B559F9DA_Parser* zT_320;
    zT_3B6EA323_EU_01 zT_321 = {0};
    unsigned char zT_322;
    unsigned int zT_323;
    zT_B559F9DA_Parser* zT_324;
    zT_3B6EA323_EU_01 zT_327 = {0};
    unsigned char zT_328;
    unsigned int zT_329;
    unsigned char* zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_336;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    int zT_342;
    unsigned char* zT_343;
    unsigned int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    unsigned int zT_346 = 0;
    unsigned int zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    unsigned char* zT_355;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char* zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    zT_6B0A7D14_AstStore* zT_368;
    unsigned int zT_369;
    zT_22A7C88B_AstNode zT_371 = {0};
    zT_8143F551_AstKind zT_372;
    int zT_376;
    unsigned char* zT_377;
    unsigned int zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380 = 0;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned char* zT_389;
    unsigned int zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned char* zT_393;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_394;
    unsigned int zT_395;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_396;
    int zT_398;
    unsigned int zT_399;
    zT_B559F9DA_Parser* zT_400;
    zT_3A355BD2_Token zT_401 = {0};
    zT_EAC3E484_TokenKind zT_402;
    zT_B559F9DA_Parser* zT_406;
    zT_3A355BD2_Token zT_407 = {0};
    zT_B559F9DA_Parser* zT_408;
    zT_3A355BD2_Token zT_409 = {0};
    zT_EAC3E484_TokenKind zT_410;
    zT_B559F9DA_Parser* zT_414;
    zT_3B6EA323_EU_01 zT_415 = {0};
    unsigned char zT_416;
    unsigned int zT_417;
    zT_B559F9DA_Parser* zT_418;
    zT_3A355BD2_Token zT_419 = {0};
    zT_EAC3E484_TokenKind zT_420;
    zT_B559F9DA_Parser* zT_424;
    zT_3B6EA323_EU_01 zT_425 = {0};
    unsigned char zT_426;
    unsigned int zT_427;
    zT_B559F9DA_Parser* zT_428;
    zT_3B6EA323_EU_01 zT_431 = {0};
    unsigned char zT_432;
    unsigned int zT_433;
    zT_B559F9DA_Parser* zT_434;
    zT_3A355BD2_Token zT_435 = {0};
    zT_EAC3E484_TokenKind zT_436;
    zT_B559F9DA_Parser* zT_440;
    zT_3A355BD2_Token zT_441 = {0};
    zT_B559F9DA_Parser* zT_442;
    zT_3A355BD2_Token zT_443 = {0};
    zT_EAC3E484_TokenKind zT_444;
    zT_B559F9DA_Parser* zT_449;
    zT_3A355BD2_Token zT_450 = {0};
    unsigned char* zT_452;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_453;
    unsigned int zT_454;
    zT_B559F9DA_Parser* zT_455;
    zT_3A355BD2_Token zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457;
    zT_DBF3575C_ParserError zT_458;
    zT_3B6EA323_EU_01 zT_459;
    unsigned int zT_461;
    unsigned char zT_462;
    zT_3A355BD2_Token zT_464;
    unsigned int zT_465;
    unsigned short zT_466;
    unsigned int zT_468;
    zT_6B0A7D14_AstStore* zT_469;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    int zT_481;
    unsigned int zT_484 = 0;
    zT_3B6EA323_EU_01 zT_485;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc0;
    zT_5A26C2ED_Arr_unsigned_char_1 pc0b;
    unsigned int pc0l;
    unsigned int pc0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck;
    zT_22A7C88B_AstNode cond_n;
    zT_5A26C2ED_Arr_unsigned_char_1 pckb;
    unsigned int pckl;
    unsigned int pcks;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc1;
    zT_5A26C2ED_Arr_unsigned_char_1 pc1b;
    unsigned int pc1l;
    unsigned int pc1s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2;
    zT_5A26C2ED_Arr_unsigned_char_1 pc2b;
    unsigned int pc2l;
    unsigned int pc2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck1;
    zT_22A7C88B_AstNode cn1;
    zT_5A26C2ED_Arr_unsigned_char_1 pck1b;
    unsigned int pck1l;
    unsigned int pck1s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pck2;
    zT_22A7C88B_AstNode cn2;
    zT_5A26C2ED_Arr_unsigned_char_1 pck2b;
    unsigned int pck2l;
    unsigned int pck2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pknl;
    unsigned int capture_node;
    zT_2B3424E9_ParseToken name_tok;
    unsigned int then_body;
    zT_2B3424E9_ParseToken pt;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pif_b;
    unsigned int pif_l;
    unsigned int pif_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_km;
    zT_5A26C2ED_Arr_unsigned_char_1 pif_kb;
    unsigned int pif_kl;
    unsigned int pif_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u pif_nl;
    unsigned int else_node;
    unsigned int end_pos;
    zT_3A355BD2_Token else_tok;
    zT_8F083A69_Slice_zT_0B42B2F8_u else_msg;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_21 = "PIF:c=";
    zT_23 = 6;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    pc0 = zT_22;
    zT_24 = pc0;
    zF_48AC7B3A_markerWrite(zT_24);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_26[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc0b[_i] = zT_26[_i];
        _i++;
    }
}
    zT_28 = cond;
    zT_32 = 0;
    zT_33 = (unsigned char*)((unsigned char*)pc0b) + zT_32;
    zT_34 = (unsigned int)(10) - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_29 = zT_35;
    zT_36 = zF_A7504564_itoa(zT_28, zT_29);
    pc0l = zT_36;
    zT_40 = (unsigned int)(9) - (unsigned int)((unsigned int)pc0l);
    pc0s = zT_40;
    zT_45 = (unsigned char*)((unsigned char*)pc0b) + pc0s;
    zT_46 = (unsigned int)(9) - pc0s;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_41 = zT_47;
    zF_48AC7B3A_markerWrite(zT_41);
    zT_49 = "k";
    zT_51 = 1;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    pck = zT_50;
    zT_52 = pck;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_54 = self->store;
    zT_55 = cond;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    cond_n = zT_57;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_59[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pckb[_i] = zT_59[_i];
        _i++;
    }
}
    zT_63 = cond_n.kind;
    zT_67 = 0;
    zT_68 = (unsigned char*)((unsigned char*)pckb) + zT_67;
    zT_69 = (unsigned int)(10) - zT_67;
    zT_70.ptr = zT_68;
    zT_70.len = zT_69;
    zT_62 = zT_70;
    zT_71 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_63), zT_62);
    pckl = zT_71;
    zT_75 = (unsigned int)(9) - (unsigned int)((unsigned int)pckl);
    pcks = zT_75;
    zT_80 = (unsigned char*)((unsigned char*)pckb) + pcks;
    zT_81 = (unsigned int)(9) - pcks;
    zT_82.ptr = zT_80;
    zT_82.len = zT_81;
    zT_76 = zT_82;
    zF_48AC7B3A_markerWrite(zT_76);
    zT_84 = "c1";
    zT_86 = 2;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    pc1 = zT_85;
    zT_87 = pc1;
    zF_48AC7B3A_markerWrite(zT_87);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc1b[_i] = zT_89[_i];
        _i++;
    }
}
    zT_91 = cond_n.child_0;
    zT_96 = 0;
    zT_97 = (unsigned char*)((unsigned char*)pc1b) + zT_96;
    zT_98 = (unsigned int)(10) - zT_96;
    zT_99.ptr = zT_97;
    zT_99.len = zT_98;
    zT_92 = zT_99;
    zT_100 = zF_A7504564_itoa(zT_91, zT_92);
    pc1l = zT_100;
    zT_104 = (unsigned int)(9) - (unsigned int)((unsigned int)pc1l);
    pc1s = zT_104;
    zT_109 = (unsigned char*)((unsigned char*)pc1b) + pc1s;
    zT_110 = (unsigned int)(9) - pc1s;
    zT_111.ptr = zT_109;
    zT_111.len = zT_110;
    zT_105 = zT_111;
    zF_48AC7B3A_markerWrite(zT_105);
    zT_113 = "c2";
    zT_115 = 2;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    pc2 = zT_114;
    zT_116 = pc2;
    zF_48AC7B3A_markerWrite(zT_116);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_118[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pc2b[_i] = zT_118[_i];
        _i++;
    }
}
    zT_120 = cond_n.child_1;
    zT_125 = 0;
    zT_126 = (unsigned char*)((unsigned char*)pc2b) + zT_125;
    zT_127 = (unsigned int)(10) - zT_125;
    zT_128.ptr = zT_126;
    zT_128.len = zT_127;
    zT_121 = zT_128;
    zT_129 = zF_A7504564_itoa(zT_120, zT_121);
    pc2l = zT_129;
    zT_133 = (unsigned int)(9) - (unsigned int)((unsigned int)pc2l);
    pc2s = zT_133;
    zT_138 = (unsigned char*)((unsigned char*)pc2b) + pc2s;
    zT_139 = (unsigned int)(9) - pc2s;
    zT_140.ptr = zT_138;
    zT_140.len = zT_139;
    zT_134 = zT_140;
    zF_48AC7B3A_markerWrite(zT_134);
    zT_142 = "k1";
    zT_144 = 2;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    pck1 = zT_143;
    zT_145 = pck1;
    zF_48AC7B3A_markerWrite(zT_145);
    zT_147 = self->store;
    zT_148 = cond_n.child_0;
    zT_151 = zF_FCDD1D35_astStoreNodeAt(zT_147, zT_148);
    cn1 = zT_151;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_153[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pck1b[_i] = zT_153[_i];
        _i++;
    }
}
    zT_157 = cn1.kind;
    zT_161 = 0;
    zT_162 = (unsigned char*)((unsigned char*)pck1b) + zT_161;
    zT_163 = (unsigned int)(10) - zT_161;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_156 = zT_164;
    zT_165 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_157), zT_156);
    pck1l = zT_165;
    zT_169 = (unsigned int)(9) - (unsigned int)((unsigned int)pck1l);
    pck1s = zT_169;
    zT_174 = (unsigned char*)((unsigned char*)pck1b) + pck1s;
    zT_175 = (unsigned int)(9) - pck1s;
    zT_176.ptr = zT_174;
    zT_176.len = zT_175;
    zT_170 = zT_176;
    zF_48AC7B3A_markerWrite(zT_170);
    zT_178 = "k2";
    zT_180 = 2;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pck2 = zT_179;
    zT_181 = pck2;
    zF_48AC7B3A_markerWrite(zT_181);
    zT_183 = self->store;
    zT_184 = cond_n.child_1;
    zT_187 = zF_FCDD1D35_astStoreNodeAt(zT_183, zT_184);
    cn2 = zT_187;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_189[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pck2b[_i] = zT_189[_i];
        _i++;
    }
}
    zT_193 = cn2.kind;
    zT_197 = 0;
    zT_198 = (unsigned char*)((unsigned char*)pck2b) + zT_197;
    zT_199 = (unsigned int)(10) - zT_197;
    zT_200.ptr = zT_198;
    zT_200.len = zT_199;
    zT_192 = zT_200;
    zT_201 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_193), zT_192);
    pck2l = zT_201;
    zT_205 = (unsigned int)(9) - (unsigned int)((unsigned int)pck2l);
    pck2s = zT_205;
    zT_210 = (unsigned char*)((unsigned char*)pck2b) + pck2s;
    zT_211 = (unsigned int)(9) - pck2s;
    zT_212.ptr = zT_210;
    zT_212.len = zT_211;
    zT_206 = zT_212;
    zF_48AC7B3A_markerWrite(zT_206);
    zT_214 = "\n";
    zT_216 = 1;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    pknl = zT_215;
    zT_217 = pknl;
    zF_48AC7B3A_markerWrite(zT_217);
    zT_218 = self;
    zT_222 = zF_5578C74F_parserExpect(zT_218, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_223 = zT_222.is_error;
    if (zT_223) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_224 = zT_222.data.err;
    zT_225.data.err = zT_224;
    zT_225.is_error = 1;
    return zT_225;
    z_bb_8:
    zT_226 = zT_222.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_226;
    zT_228 = 0;
    zT_229 = (unsigned int)zT_228;
    capture_node = zT_229;
    zT_230 = self;
    zT_231 = zF_068A2DE5_parserPeek(zT_230);
    zT_232 = zT_231.kind;
    if ((unsigned char)(zT_232 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_236 = self;
    zT_237 = zF_C241B2C4_parserAdvance(zT_236);
    (void)zT_237;
    name_tok = zT_239;
    zT_240 = self;
    zT_241 = zF_068A2DE5_parserPeek(zT_240);
    zT_242 = zT_241.kind;
    if ((unsigned char)(zT_242 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    then_body = zT_313;
    zT_314 = self;
    zT_315 = zF_068A2DE5_parserPeek(zT_314);
    zT_316 = zT_315.kind;
    if ((unsigned char)(zT_316 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_24; else goto z_bb_26;
    z_bb_12:
    zT_246 = self;
    zT_250 = zF_5578C74F_parserExpect(zT_246, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_251 = zT_250.is_error;
    if (zT_251) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_264 = self;
    zT_268 = zF_5578C74F_parserExpect(zT_264, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_269 = zT_268.is_error;
    if (zT_269) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_255 = self;
    zT_259 = zF_5578C74F_parserExpect(zT_255, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_260 = zT_259.is_error;
    if (zT_260) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_252 = zT_250.data.err;
    zT_253.data.err = zT_252;
    zT_253.is_error = 1;
    return zT_253;
    z_bb_16:
    zT_254 = zT_250.data.payload;
    goto z_bb_17;
    z_bb_17:
    name_tok = zT_254;
    goto z_bb_13;
    z_bb_18:
    zT_261 = zT_259.data.err;
    zT_262.data.err = zT_261;
    zT_262.is_error = 1;
    return zT_262;
    z_bb_19:
    zT_263 = zT_259.data.payload;
    goto z_bb_20;
    z_bb_20:
    name_tok = zT_263;
    goto z_bb_13;
    z_bb_21:
    zT_270 = zT_268.data.err;
    zT_271.data.err = zT_270;
    zT_271.is_error = 1;
    return zT_271;
    z_bb_22:
    zT_272 = zT_268.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_272;
    zT_275 = name_tok.kind;
    zT_274.kind = zT_275;
    zT_276 = name_tok.span_start;
    zT_274.span_start = zT_276;
    zT_277 = name_tok.span_len;
    zT_274.span_len = zT_277;
    pt = zT_274;
    zT_279 = self->interner;
    zT_282 = self;
    zT_283 = pt;
    zT_284 = zF_08D61E58_parserTokenText(zT_282, zT_283);
    zT_280 = zT_284;
    zT_285 = zF_50C274AF_stringInternerInter(zT_279, zT_280);
    name_id = zT_285;
    zT_286 = self->store;
    zT_298 = 0;
    zT_289 = name_tok.span_start;
    zT_301 = name_tok.span_start;
    zT_302 = name_tok.span_len;
    zT_305 = 0;
    zT_307 = 0;
    zT_309 = 0;
    zT_294 = name_id;
    zT_311 = zF_6C9FF72F_astStoreAddNode(zT_286, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture), (unsigned char)((unsigned char)zT_298), zT_289, (unsigned int)(zT_301 + (unsigned int)((unsigned int)zT_302)), (unsigned int)((unsigned int)zT_305), (unsigned int)((unsigned int)zT_307), (unsigned int)((unsigned int)zT_309), zT_294);
    capture_node = zT_311;
    goto z_bb_11;
    z_bb_24:
    zT_320 = self;
    zT_321 = zF_365CA04A_parserParseBlock(zT_320);
    zT_322 = zT_321.is_error;
    if (zT_322) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_331 = "PIF:b";
    zT_333 = 5;
    zT_332.ptr = zT_331;
    zT_332.len = zT_333;
    pif_m = zT_332;
    zT_334 = pif_m;
    zF_48AC7B3A_markerWrite(zT_334);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_336[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pif_b[_i] = zT_336[_i];
        _i++;
    }
}
    zT_338 = then_body;
    zT_342 = 0;
    zT_343 = (unsigned char*)((unsigned char*)pif_b) + zT_342;
    zT_344 = (unsigned int)(10) - zT_342;
    zT_345.ptr = zT_343;
    zT_345.len = zT_344;
    zT_339 = zT_345;
    zT_346 = zF_A7504564_itoa(zT_338, zT_339);
    pif_l = zT_346;
    zT_350 = (unsigned int)(9) - (unsigned int)((unsigned int)pif_l);
    pif_s = zT_350;
    zT_355 = (unsigned char*)((unsigned char*)pif_b) + pif_s;
    zT_356 = (unsigned int)(9) - pif_s;
    zT_357.ptr = zT_355;
    zT_357.len = zT_356;
    zT_351 = zT_357;
    zF_48AC7B3A_markerWrite(zT_351);
    zT_359 = "k";
    zT_361 = 1;
    zT_360.ptr = zT_359;
    zT_360.len = zT_361;
    pif_km = zT_360;
    zT_362 = pif_km;
    zF_48AC7B3A_markerWrite(zT_362);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_364[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pif_kb[_i] = zT_364[_i];
        _i++;
    }
}
    zT_368 = self->store;
    zT_369 = then_body;
    zT_371 = zF_FCDD1D35_astStoreNodeAt(zT_368, zT_369);
    zT_372 = zT_371.kind;
    zT_376 = 0;
    zT_377 = (unsigned char*)((unsigned char*)pif_kb) + zT_376;
    zT_378 = (unsigned int)(10) - zT_376;
    zT_379.ptr = zT_377;
    zT_379.len = zT_378;
    zT_367 = zT_379;
    zT_380 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_372), zT_367);
    pif_kl = zT_380;
    zT_384 = (unsigned int)(9) - (unsigned int)((unsigned int)pif_kl);
    pif_ks = zT_384;
    zT_389 = (unsigned char*)((unsigned char*)pif_kb) + pif_ks;
    zT_390 = (unsigned int)(9) - pif_ks;
    zT_391.ptr = zT_389;
    zT_391.len = zT_390;
    zT_385 = zT_391;
    zF_48AC7B3A_markerWrite(zT_385);
    zT_393 = "\n";
    zT_395 = 1;
    zT_394.ptr = zT_393;
    zT_394.len = zT_395;
    pif_nl = zT_394;
    zT_396 = pif_nl;
    zF_48AC7B3A_markerWrite(zT_396);
    zT_398 = 0;
    zT_399 = (unsigned int)zT_398;
    else_node = zT_399;
    zT_400 = self;
    zT_401 = zF_068A2DE5_parserPeek(zT_400);
    zT_402 = zT_401.kind;
    if ((unsigned char)(zT_402 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_33; else goto z_bb_34;
    z_bb_26:
    zT_324 = self;
    zT_327 = zF_F07C1F04_parserParseExprPrec(zT_324, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_328 = zT_327.is_error;
    if (zT_328) goto z_bb_30; else goto z_bb_31;
    z_bb_27:
    return zT_321;
    z_bb_28:
    zT_323 = zT_321.data.payload;
    goto z_bb_29;
    z_bb_29:
    then_body = zT_323;
    goto z_bb_25;
    z_bb_30:
    return zT_327;
    z_bb_31:
    zT_329 = zT_327.data.payload;
    goto z_bb_32;
    z_bb_32:
    then_body = zT_329;
    goto z_bb_25;
    z_bb_33:
    zT_406 = self;
    zT_407 = zF_C241B2C4_parserAdvance(zT_406);
    (void)zT_407;
    zT_408 = self;
    zT_409 = zF_068A2DE5_parserPeek(zT_408);
    zT_410 = zT_409.kind;
    if ((unsigned char)(zT_410 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_if))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    zT_434 = self;
    zT_435 = zF_068A2DE5_parserPeek(zT_434);
    zT_436 = zT_435.kind;
    if ((unsigned char)(zT_436 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_50; else goto z_bb_51;
    z_bb_35:
    zT_414 = self;
    zT_415 = zF_DB819578_parserParseIfStmt(zT_414);
    zT_416 = zT_415.is_error;
    if (zT_416) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_418 = self;
    zT_419 = zF_068A2DE5_parserPeek(zT_418);
    zT_420 = zT_419.kind;
    if ((unsigned char)(zT_420 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_41; else goto z_bb_43;
    z_bb_38:
    return zT_415;
    z_bb_39:
    zT_417 = zT_415.data.payload;
    goto z_bb_40;
    z_bb_40:
    else_node = zT_417;
    goto z_bb_36;
    z_bb_41:
    zT_424 = self;
    zT_425 = zF_365CA04A_parserParseBlock(zT_424);
    zT_426 = zT_425.is_error;
    if (zT_426) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_428 = self;
    zT_431 = zF_F07C1F04_parserParseExprPrec(zT_428, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_432 = zT_431.is_error;
    if (zT_432) goto z_bb_47; else goto z_bb_48;
    z_bb_44:
    return zT_425;
    z_bb_45:
    zT_427 = zT_425.data.payload;
    goto z_bb_46;
    z_bb_46:
    else_node = zT_427;
    goto z_bb_42;
    z_bb_47:
    return zT_431;
    z_bb_48:
    zT_433 = zT_431.data.payload;
    goto z_bb_49;
    z_bb_49:
    else_node = zT_433;
    goto z_bb_42;
    z_bb_50:
    zT_440 = self;
    zT_441 = zF_C241B2C4_parserAdvance(zT_440);
    (void)zT_441;
    zT_442 = self;
    zT_443 = zF_068A2DE5_parserPeek(zT_442);
    zT_444 = zT_443.kind;
    if ((unsigned char)(zT_444 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_else))) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_461 = kw.span_start;
    end_pos = zT_461;
    zT_462 = self->last_tok_valid;
    if (zT_462) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_449 = self;
    zT_450 = zF_068A2DE5_parserPeek(zT_449);
    else_tok = zT_450;
    zT_452 = "';' not allowed before 'else' - use braces: if (cond) { ... } else { ... }";
    zT_454 = 74;
    zT_453.ptr = zT_452;
    zT_453.len = zT_454;
    else_msg = zT_453;
    zT_455 = self;
    zT_456 = else_tok;
    zT_457 = else_msg;
    zF_17DF2CA5_parserAddError(zT_455, zT_456, zT_457);
    zT_458 = 1;
    zT_459.data.err = zT_458;
    zT_459.is_error = 1;
    return zT_459;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_464 = self->last_tok;
    last = zT_464;
    zT_465 = last.span_start;
    zT_466 = last.span_len;
    zT_468 = zT_465 + (unsigned int)((unsigned int)zT_466);
    end_pos = zT_468;
    goto z_bb_55;
    z_bb_55:
    zT_469 = self->store;
    zT_481 = 0;
    zT_472 = kw.span_start;
    zT_473 = end_pos;
    zT_474 = cond;
    zT_475 = then_body;
    zT_476 = else_node;
    zT_477 = capture_node;
    zT_484 = zF_6C9FF72F_astStoreAddNode(zT_469, (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt), (unsigned char)((unsigned char)zT_481), zT_472, zT_473, zT_474, zT_475, zT_476, zT_477);
    zT_485.data.payload = zT_484;
    zT_485.is_error = 0;
    return zT_485;
}

/* parserParseWhileStmt */
zT_3B6EA323_EU_01 zF_4E7AD820_parserParseWhileStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_CB78802F_EU_49 zT_24 = {0};
    unsigned char zT_25;
    int zT_26;
    zT_3B6EA323_EU_01 zT_27;
    zT_2B3424E9_ParseToken zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_3A355BD2_Token zT_36 = {0};
    zT_EAC3E484_TokenKind zT_37;
    zT_B559F9DA_Parser* zT_41;
    zT_3A355BD2_Token zT_42 = {0};
    zT_2B3424E9_ParseToken zT_44 = {0};
    zT_B559F9DA_Parser* zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    zT_EAC3E484_TokenKind zT_47;
    zT_B559F9DA_Parser* zT_51;
    zT_CB78802F_EU_49 zT_55 = {0};
    unsigned char zT_56;
    int zT_57;
    zT_3B6EA323_EU_01 zT_58;
    zT_2B3424E9_ParseToken zT_59;
    zT_B559F9DA_Parser* zT_60;
    zT_CB78802F_EU_49 zT_64 = {0};
    unsigned char zT_65;
    int zT_66;
    zT_3B6EA323_EU_01 zT_67;
    zT_2B3424E9_ParseToken zT_68;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_B559F9DA_Parser* zT_72;
    zT_2B3424E9_ParseToken zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74 = {0};
    unsigned int zT_75 = 0;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_79;
    unsigned int zT_84;
    int zT_88;
    unsigned int zT_91;
    unsigned short zT_92;
    int zT_95;
    int zT_97;
    int zT_99;
    unsigned int zT_101 = 0;
    zT_B559F9DA_Parser* zT_102;
    zT_CB78802F_EU_49 zT_106 = {0};
    unsigned char zT_107;
    int zT_108;
    zT_3B6EA323_EU_01 zT_109;
    zT_2B3424E9_ParseToken zT_110;
    int zT_112;
    unsigned int zT_113;
    zT_B559F9DA_Parser* zT_114;
    zT_3A355BD2_Token zT_115 = {0};
    zT_EAC3E484_TokenKind zT_116;
    zT_B559F9DA_Parser* zT_120;
    zT_3A355BD2_Token zT_121 = {0};
    zT_B559F9DA_Parser* zT_122;
    zT_CB78802F_EU_49 zT_126 = {0};
    unsigned char zT_127;
    int zT_128;
    zT_3B6EA323_EU_01 zT_129;
    zT_2B3424E9_ParseToken zT_130;
    zT_B559F9DA_Parser* zT_131;
    zT_3B6EA323_EU_01 zT_134 = {0};
    unsigned char zT_135;
    unsigned int zT_136;
    zT_B559F9DA_Parser* zT_137;
    zT_CB78802F_EU_49 zT_141 = {0};
    unsigned char zT_142;
    int zT_143;
    zT_3B6EA323_EU_01 zT_144;
    zT_2B3424E9_ParseToken zT_145;
    unsigned int zT_147 = 0;
    zT_B559F9DA_Parser* zT_148;
    zT_3A355BD2_Token zT_149 = {0};
    zT_EAC3E484_TokenKind zT_150;
    zT_B559F9DA_Parser* zT_154;
    zT_3B6EA323_EU_01 zT_155 = {0};
    unsigned char zT_156;
    unsigned int zT_157;
    zT_B559F9DA_Parser* zT_158;
    zT_3B6EA323_EU_01 zT_161 = {0};
    unsigned char zT_162;
    unsigned int zT_163;
    zT_B559F9DA_Parser* zT_164;
    zT_3A355BD2_Token zT_165 = {0};
    zT_EAC3E484_TokenKind zT_166;
    zT_B559F9DA_Parser* zT_170;
    zT_3A355BD2_Token zT_171 = {0};
    unsigned int zT_173 = 0;
    unsigned char zT_174;
    zT_3A355BD2_Token zT_176;
    unsigned int zT_177;
    unsigned short zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_185;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    int zT_196;
    unsigned char* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200 = 0;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_6B0A7D14_AstStore* zT_218;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    int zT_230;
    unsigned int zT_233 = 0;
    zT_3B6EA323_EU_01 zT_234;
    zT_3A355BD2_Token kw;
    unsigned int cond;
    unsigned int capture_name;
    unsigned int cap_node;
    zT_2B3424E9_ParseToken cap_tok;
    unsigned int continue_expr;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_5A26C2ED_Arr_unsigned_char_1 zzz_buf_c2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zzz_c2e_m;
    unsigned int zzz_c2e_l;
    unsigned int zzz_c2e_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u zzz_c2e_nl;
    unsigned int zzz_c2;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    cond = zT_19;
    zT_20 = self;
    zT_24 = zF_5578C74F_parserExpect(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = zT_24.data.err;
    zT_27.data.err = zT_26;
    zT_27.is_error = 1;
    return zT_27;
    z_bb_8:
    zT_28 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    (void)zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    capture_name = zT_31;
    zT_33 = 0;
    zT_34 = (unsigned int)zT_33;
    cap_node = zT_34;
    zT_35 = self;
    zT_36 = zF_068A2DE5_parserPeek(zT_35);
    zT_37 = zT_36.kind;
    if ((unsigned char)(zT_37 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_41 = self;
    zT_42 = zF_C241B2C4_parserAdvance(zT_41);
    (void)zT_42;
    cap_tok = zT_44;
    zT_45 = self;
    zT_46 = zF_068A2DE5_parserPeek(zT_45);
    zT_47 = zT_46.kind;
    if ((unsigned char)(zT_47 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_112 = 0;
    zT_113 = (unsigned int)zT_112;
    continue_expr = zT_113;
    zT_114 = self;
    zT_115 = zF_068A2DE5_parserPeek(zT_114);
    zT_116 = zT_115.kind;
    if ((unsigned char)(zT_116 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_24; else goto z_bb_25;
    z_bb_12:
    zT_51 = self;
    zT_55 = zF_5578C74F_parserExpect(zT_51, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_56 = zT_55.is_error;
    if (zT_56) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_69 = self->interner;
    zT_72 = self;
    zT_73 = cap_tok;
    zT_74 = zF_08D61E58_parserTokenText(zT_72, zT_73);
    zT_70 = zT_74;
    zT_75 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    capture_name = zT_75;
    zT_76 = self->store;
    zT_88 = 0;
    zT_79 = cap_tok.span_start;
    zT_91 = cap_tok.span_start;
    zT_92 = cap_tok.span_len;
    zT_95 = 0;
    zT_97 = 0;
    zT_99 = 0;
    zT_84 = capture_name;
    zT_101 = zF_6C9FF72F_astStoreAddNode(zT_76, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture), (unsigned char)((unsigned char)zT_88), zT_79, (unsigned int)(zT_91 + (unsigned int)((unsigned int)zT_92)), (unsigned int)((unsigned int)zT_95), (unsigned int)((unsigned int)zT_97), (unsigned int)((unsigned int)zT_99), zT_84);
    cap_node = zT_101;
    zT_102 = self;
    zT_106 = zF_5578C74F_parserExpect(zT_102, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_107 = zT_106.is_error;
    if (zT_107) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_60 = self;
    zT_64 = zF_5578C74F_parserExpect(zT_60, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_57 = zT_55.data.err;
    zT_58.data.err = zT_57;
    zT_58.is_error = 1;
    return zT_58;
    z_bb_16:
    zT_59 = zT_55.data.payload;
    goto z_bb_17;
    z_bb_17:
    cap_tok = zT_59;
    goto z_bb_13;
    z_bb_18:
    zT_66 = zT_64.data.err;
    zT_67.data.err = zT_66;
    zT_67.is_error = 1;
    return zT_67;
    z_bb_19:
    zT_68 = zT_64.data.payload;
    goto z_bb_20;
    z_bb_20:
    cap_tok = zT_68;
    goto z_bb_13;
    z_bb_21:
    zT_108 = zT_106.data.err;
    zT_109.data.err = zT_108;
    zT_109.is_error = 1;
    return zT_109;
    z_bb_22:
    zT_110 = zT_106.data.payload;
    goto z_bb_23;
    z_bb_23:
    (void)zT_110;
    goto z_bb_11;
    z_bb_24:
    zT_120 = self;
    zT_121 = zF_C241B2C4_parserAdvance(zT_120);
    (void)zT_121;
    zT_122 = self;
    zT_126 = zF_5578C74F_parserExpect(zT_122, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    body = zT_147;
    zT_148 = self;
    zT_149 = zF_068A2DE5_parserPeek(zT_148);
    zT_150 = zT_149.kind;
    if ((unsigned char)(zT_150 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_35; else goto z_bb_37;
    z_bb_26:
    zT_128 = zT_126.data.err;
    zT_129.data.err = zT_128;
    zT_129.is_error = 1;
    return zT_129;
    z_bb_27:
    zT_130 = zT_126.data.payload;
    goto z_bb_28;
    z_bb_28:
    (void)zT_130;
    zT_131 = self;
    zT_134 = zF_F07C1F04_parserParseExprPrec(zT_131, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_135 = zT_134.is_error;
    if (zT_135) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return zT_134;
    z_bb_30:
    zT_136 = zT_134.data.payload;
    goto z_bb_31;
    z_bb_31:
    continue_expr = zT_136;
    zT_137 = self;
    zT_141 = zF_5578C74F_parserExpect(zT_137, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_142 = zT_141.is_error;
    if (zT_142) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_143 = zT_141.data.err;
    zT_144.data.err = zT_143;
    zT_144.is_error = 1;
    return zT_144;
    z_bb_33:
    zT_145 = zT_141.data.payload;
    goto z_bb_34;
    z_bb_34:
    (void)zT_145;
    goto z_bb_25;
    z_bb_35:
    zT_154 = self;
    zT_155 = zF_365CA04A_parserParseBlock(zT_154);
    zT_156 = zT_155.is_error;
    if (zT_156) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    zT_164 = self;
    zT_165 = zF_068A2DE5_parserPeek(zT_164);
    zT_166 = zT_165.kind;
    if ((unsigned char)(zT_166 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_44; else goto z_bb_45;
    z_bb_37:
    zT_158 = self;
    zT_161 = zF_F07C1F04_parserParseExprPrec(zT_158, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    return zT_155;
    z_bb_39:
    zT_157 = zT_155.data.payload;
    goto z_bb_40;
    z_bb_40:
    body = zT_157;
    goto z_bb_36;
    z_bb_41:
    return zT_161;
    z_bb_42:
    zT_163 = zT_161.data.payload;
    goto z_bb_43;
    z_bb_43:
    body = zT_163;
    goto z_bb_36;
    z_bb_44:
    zT_170 = self;
    zT_171 = zF_C241B2C4_parserAdvance(zT_170);
    (void)zT_171;
    goto z_bb_45;
    z_bb_45:
    end_pos = zT_173;
    zT_174 = self->last_tok_valid;
    if (zT_174) goto z_bb_46; else goto z_bb_48;
    z_bb_46:
    zT_176 = self->last_tok;
    last = zT_176;
    zT_177 = last.span_start;
    zT_178 = last.span_len;
    zT_180 = zT_177 + (unsigned int)((unsigned int)zT_178);
    end_pos = zT_180;
    goto z_bb_47;
    z_bb_47:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_185[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zzz_buf_c2[_i] = zT_185[_i];
        _i++;
    }
}
    zT_187 = "PTC2:e";
    zT_189 = 6;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    zzz_c2e_m = zT_188;
    zT_190 = zzz_c2e_m;
    zF_48AC7B3A_markerWrite(zT_190);
    zT_192 = continue_expr;
    zT_196 = 0;
    zT_197 = (unsigned char*)((unsigned char*)zzz_buf_c2) + zT_196;
    zT_198 = (unsigned int)(10) - zT_196;
    zT_199.ptr = zT_197;
    zT_199.len = zT_198;
    zT_193 = zT_199;
    zT_200 = zF_A7504564_itoa(zT_192, zT_193);
    zzz_c2e_l = zT_200;
    zT_204 = (unsigned int)(9) - (unsigned int)((unsigned int)zzz_c2e_l);
    zzz_c2e_s = zT_204;
    zT_209 = (unsigned char*)((unsigned char*)zzz_buf_c2) + zzz_c2e_s;
    zT_210 = (unsigned int)(9) - zzz_c2e_s;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_205 = zT_211;
    zF_48AC7B3A_markerWrite(zT_205);
    zT_213 = "\n";
    zT_215 = 1;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    zzz_c2e_nl = zT_214;
    zT_216 = zzz_c2e_nl;
    zF_48AC7B3A_markerWrite(zT_216);
    zzz_c2 = continue_expr;
    zT_218 = self->store;
    zT_230 = 0;
    zT_221 = kw.span_start;
    zT_222 = end_pos;
    zT_223 = cond;
    zT_224 = body;
    zT_225 = zzz_c2;
    zT_226 = cap_node;
    zT_233 = zF_6C9FF72F_astStoreAddNode(zT_218, (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt), (unsigned char)((unsigned char)zT_230), zT_221, zT_222, zT_223, zT_224, zT_225, zT_226);
    zT_234.data.payload = zT_233;
    zT_234.is_error = 0;
    return zT_234;
    z_bb_48:
    zT_181 = kw.span_start;
    end_pos = zT_181;
    goto z_bb_47;
}

/* parserParseForStmt */
zT_3B6EA323_EU_01 zF_54BCF0C6_parserParseForStmt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    zT_B559F9DA_Parser* zT_4;
    zT_CB78802F_EU_49 zT_8 = {0};
    unsigned char zT_9;
    int zT_10;
    zT_3B6EA323_EU_01 zT_11;
    zT_2B3424E9_ParseToken zT_12;
    zT_B559F9DA_Parser* zT_14;
    zT_3B6EA323_EU_01 zT_17 = {0};
    unsigned char zT_18;
    unsigned int zT_19;
    zT_B559F9DA_Parser* zT_20;
    zT_3A355BD2_Token zT_21 = {0};
    zT_EAC3E484_TokenKind zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3A355BD2_Token zT_27 = {0};
    zT_B559F9DA_Parser* zT_29;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_47;
    int zT_49;
    int zT_51;
    int zT_53;
    int zT_55;
    unsigned int zT_57 = 0;
    zT_B559F9DA_Parser* zT_58;
    zT_CB78802F_EU_49 zT_62 = {0};
    unsigned char zT_63;
    int zT_64;
    zT_3B6EA323_EU_01 zT_65;
    zT_2B3424E9_ParseToken zT_66;
    int zT_68;
    unsigned int zT_69;
    int zT_71;
    unsigned int zT_72;
    zT_B559F9DA_Parser* zT_73;
    zT_3A355BD2_Token zT_74 = {0};
    zT_EAC3E484_TokenKind zT_75;
    zT_B559F9DA_Parser* zT_79;
    zT_3A355BD2_Token zT_80 = {0};
    zT_2B3424E9_ParseToken zT_82 = {0};
    zT_B559F9DA_Parser* zT_83;
    zT_3A355BD2_Token zT_84 = {0};
    zT_EAC3E484_TokenKind zT_85;
    zT_B559F9DA_Parser* zT_89;
    zT_CB78802F_EU_49 zT_93 = {0};
    unsigned char zT_94;
    int zT_95;
    zT_3B6EA323_EU_01 zT_96;
    zT_2B3424E9_ParseToken zT_97;
    zT_B559F9DA_Parser* zT_98;
    zT_CB78802F_EU_49 zT_102 = {0};
    unsigned char zT_103;
    int zT_104;
    zT_3B6EA323_EU_01 zT_105;
    zT_2B3424E9_ParseToken zT_106;
    zT_D3EB6303_StringInterner* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_B559F9DA_Parser* zT_110;
    zT_2B3424E9_ParseToken zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112 = {0};
    unsigned int zT_113 = 0;
    zT_B559F9DA_Parser* zT_114;
    zT_3A355BD2_Token zT_115 = {0};
    zT_EAC3E484_TokenKind zT_116;
    zT_B559F9DA_Parser* zT_120;
    zT_3A355BD2_Token zT_121 = {0};
    zT_B559F9DA_Parser* zT_123;
    zT_CB78802F_EU_49 zT_127 = {0};
    unsigned char zT_128;
    int zT_129;
    zT_3B6EA323_EU_01 zT_130;
    zT_2B3424E9_ParseToken zT_131;
    zT_D3EB6303_StringInterner* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    zT_B559F9DA_Parser* zT_135;
    zT_2B3424E9_ParseToken zT_136;
    zT_2B3424E9_ParseToken zT_137;
    zT_EAC3E484_TokenKind zT_138;
    unsigned int zT_139;
    unsigned short zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141 = {0};
    unsigned int zT_142 = 0;
    zT_B559F9DA_Parser* zT_143;
    zT_CB78802F_EU_49 zT_147 = {0};
    unsigned char zT_148;
    int zT_149;
    zT_3B6EA323_EU_01 zT_150;
    zT_2B3424E9_ParseToken zT_151;
    unsigned int zT_153 = 0;
    zT_B559F9DA_Parser* zT_154;
    zT_3A355BD2_Token zT_155 = {0};
    zT_EAC3E484_TokenKind zT_156;
    zT_B559F9DA_Parser* zT_160;
    zT_3B6EA323_EU_01 zT_161 = {0};
    unsigned char zT_162;
    unsigned int zT_163;
    zT_B559F9DA_Parser* zT_164;
    zT_3B6EA323_EU_01 zT_167 = {0};
    unsigned char zT_168;
    unsigned int zT_169;
    zT_B559F9DA_Parser* zT_170;
    zT_3A355BD2_Token zT_171 = {0};
    zT_EAC3E484_TokenKind zT_172;
    zT_B559F9DA_Parser* zT_176;
    zT_3A355BD2_Token zT_177 = {0};
    unsigned int zT_179 = 0;
    unsigned char zT_180;
    zT_3A355BD2_Token zT_182;
    unsigned int zT_183;
    unsigned short zT_184;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_6B0A7D14_AstStore* zT_188;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    int zT_200;
    unsigned int zT_203 = 0;
    zT_3B6EA323_EU_01 zT_204;
    zT_3A355BD2_Token kw;
    unsigned int pattern;
    unsigned int end_node;
    unsigned int capture_name;
    unsigned int index_name;
    zT_2B3424E9_ParseToken cap_tok;
    unsigned int body;
    zT_2B3424E9_ParseToken idx_tok;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_4 = self;
    zT_8 = zF_5578C74F_parserExpect(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = zT_8.data.err;
    zT_11.data.err = zT_10;
    zT_11.is_error = 1;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    (void)zT_12;
    zT_14 = self;
    zT_17 = zF_F07C1F04_parserParseExprPrec(zT_14, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return zT_17;
    z_bb_5:
    zT_19 = zT_17.data.payload;
    goto z_bb_6;
    z_bb_6:
    pattern = zT_19;
    zT_20 = self;
    zT_21 = zF_068A2DE5_parserPeek(zT_20);
    zT_22 = zT_21.kind;
    if ((unsigned char)(zT_22 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self;
    zT_27 = zF_C241B2C4_parserAdvance(zT_26);
    (void)zT_27;
    zT_29 = self;
    zT_32 = zF_F07C1F04_parserParseExprPrec(zT_29, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_58 = self;
    zT_62 = zF_5578C74F_parserExpect(zT_58, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_63 = zT_62.is_error;
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    return zT_32;
    z_bb_10:
    zT_34 = zT_32.data.payload;
    goto z_bb_11;
    z_bb_11:
    end_node = zT_34;
    zT_35 = self->store;
    zT_47 = 0;
    zT_49 = 0;
    zT_51 = 0;
    zT_40 = pattern;
    zT_41 = end_node;
    zT_53 = 0;
    zT_55 = 0;
    zT_57 = zF_6C9FF72F_astStoreAddNode(zT_35, (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive), (unsigned char)((unsigned char)zT_47), (unsigned int)((unsigned int)zT_49), (unsigned int)((unsigned int)zT_51), zT_40, zT_41, (unsigned int)((unsigned int)zT_53), (unsigned int)((unsigned int)zT_55));
    pattern = zT_57;
    goto z_bb_8;
    z_bb_12:
    zT_64 = zT_62.data.err;
    zT_65.data.err = zT_64;
    zT_65.is_error = 1;
    return zT_65;
    z_bb_13:
    zT_66 = zT_62.data.payload;
    goto z_bb_14;
    z_bb_14:
    (void)zT_66;
    zT_68 = 0;
    zT_69 = (unsigned int)zT_68;
    capture_name = zT_69;
    zT_71 = 0;
    zT_72 = (unsigned int)zT_71;
    index_name = zT_72;
    zT_73 = self;
    zT_74 = zF_068A2DE5_parserPeek(zT_73);
    zT_75 = zT_74.kind;
    if ((unsigned char)(zT_75 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_79 = self;
    zT_80 = zF_C241B2C4_parserAdvance(zT_79);
    (void)zT_80;
    cap_tok = zT_82;
    zT_83 = self;
    zT_84 = zF_068A2DE5_parserPeek(zT_83);
    zT_85 = zT_84.kind;
    if ((unsigned char)(zT_85 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore))) goto z_bb_17; else goto z_bb_19;
    z_bb_16:
    body = zT_153;
    zT_154 = self;
    zT_155 = zF_068A2DE5_parserPeek(zT_154);
    zT_156 = zT_155.kind;
    if ((unsigned char)(zT_156 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace))) goto z_bb_34; else goto z_bb_36;
    z_bb_17:
    zT_89 = self;
    zT_93 = zF_5578C74F_parserExpect(zT_89, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore));
    zT_94 = zT_93.is_error;
    if (zT_94) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_107 = self->interner;
    zT_110 = self;
    zT_111 = cap_tok;
    zT_112 = zF_08D61E58_parserTokenText(zT_110, zT_111);
    zT_108 = zT_112;
    zT_113 = zF_50C274AF_stringInternerInter(zT_107, zT_108);
    capture_name = zT_113;
    zT_114 = self;
    zT_115 = zF_068A2DE5_parserPeek(zT_114);
    zT_116 = zT_115.kind;
    if ((unsigned char)(zT_116 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_26; else goto z_bb_27;
    z_bb_19:
    zT_98 = self;
    zT_102 = zF_5578C74F_parserExpect(zT_98, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_103 = zT_102.is_error;
    if (zT_103) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_95 = zT_93.data.err;
    zT_96.data.err = zT_95;
    zT_96.is_error = 1;
    return zT_96;
    z_bb_21:
    zT_97 = zT_93.data.payload;
    goto z_bb_22;
    z_bb_22:
    cap_tok = zT_97;
    goto z_bb_18;
    z_bb_23:
    zT_104 = zT_102.data.err;
    zT_105.data.err = zT_104;
    zT_105.is_error = 1;
    return zT_105;
    z_bb_24:
    zT_106 = zT_102.data.payload;
    goto z_bb_25;
    z_bb_25:
    cap_tok = zT_106;
    goto z_bb_18;
    z_bb_26:
    zT_120 = self;
    zT_121 = zF_C241B2C4_parserAdvance(zT_120);
    (void)zT_121;
    zT_123 = self;
    zT_127 = zF_5578C74F_parserExpect(zT_123, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_128 = zT_127.is_error;
    if (zT_128) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_143 = self;
    zT_147 = zF_5578C74F_parserExpect(zT_143, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe));
    zT_148 = zT_147.is_error;
    if (zT_148) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_129 = zT_127.data.err;
    zT_130.data.err = zT_129;
    zT_130.is_error = 1;
    return zT_130;
    z_bb_29:
    zT_131 = zT_127.data.payload;
    goto z_bb_30;
    z_bb_30:
    idx_tok = zT_131;
    zT_132 = self->interner;
    zT_135 = self;
    zT_138 = idx_tok.kind;
    zT_137.kind = zT_138;
    zT_139 = idx_tok.span_start;
    zT_137.span_start = zT_139;
    zT_140 = idx_tok.span_len;
    zT_137.span_len = zT_140;
    zT_136 = zT_137;
    zT_141 = zF_08D61E58_parserTokenText(zT_135, zT_136);
    zT_133 = zT_141;
    zT_142 = zF_50C274AF_stringInternerInter(zT_132, zT_133);
    index_name = zT_142;
    goto z_bb_27;
    z_bb_31:
    zT_149 = zT_147.data.err;
    zT_150.data.err = zT_149;
    zT_150.is_error = 1;
    return zT_150;
    z_bb_32:
    zT_151 = zT_147.data.payload;
    goto z_bb_33;
    z_bb_33:
    (void)zT_151;
    goto z_bb_16;
    z_bb_34:
    zT_160 = self;
    zT_161 = zF_365CA04A_parserParseBlock(zT_160);
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_170 = self;
    zT_171 = zF_068A2DE5_parserPeek(zT_170);
    zT_172 = zT_171.kind;
    if ((unsigned char)(zT_172 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_43; else goto z_bb_44;
    z_bb_36:
    zT_164 = self;
    zT_167 = zF_F07C1F04_parserParseExprPrec(zT_164, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_168 = zT_167.is_error;
    if (zT_168) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    return zT_161;
    z_bb_38:
    zT_163 = zT_161.data.payload;
    goto z_bb_39;
    z_bb_39:
    body = zT_163;
    goto z_bb_35;
    z_bb_40:
    return zT_167;
    z_bb_41:
    zT_169 = zT_167.data.payload;
    goto z_bb_42;
    z_bb_42:
    body = zT_169;
    goto z_bb_35;
    z_bb_43:
    zT_176 = self;
    zT_177 = zF_C241B2C4_parserAdvance(zT_176);
    (void)zT_177;
    goto z_bb_44;
    z_bb_44:
    end_pos = zT_179;
    zT_180 = self->last_tok_valid;
    if (zT_180) goto z_bb_45; else goto z_bb_47;
    z_bb_45:
    zT_182 = self->last_tok;
    last = zT_182;
    zT_183 = last.span_start;
    zT_184 = last.span_len;
    zT_186 = zT_183 + (unsigned int)((unsigned int)zT_184);
    end_pos = zT_186;
    goto z_bb_46;
    z_bb_46:
    zT_188 = self->store;
    zT_200 = 0;
    zT_191 = kw.span_start;
    zT_192 = end_pos;
    zT_193 = pattern;
    zT_194 = body;
    zT_195 = index_name;
    zT_196 = capture_name;
    zT_203 = zF_6C9FF72F_astStoreAddNode(zT_188, (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt), (unsigned char)((unsigned char)zT_200), zT_191, zT_192, zT_193, zT_194, zT_195, zT_196);
    zT_204.data.payload = zT_203;
    zT_204.is_error = 0;
    return zT_204;
    z_bb_47:
    zT_187 = kw.span_start;
    end_pos = zT_187;
    goto z_bb_46;
}

/* parserParseSwitchStmt */
zT_3B6EA323_EU_01 zF_3A6F34C7_parserParseSwitchSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_11;
    int zT_18;
    int zT_20;
    int zT_22;
    int zT_24;
    int zT_26;
    int zT_28;
    unsigned int zT_30 = 0;
    zT_3B6EA323_EU_01 zT_31;
    unsigned int inner;
    zT_2 = self;
    zT_3 = zF_A9AC92CA_parserParseSwitchEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    inner = zT_5;
    zT_6 = self->store;
    zT_18 = 0;
    zT_20 = 0;
    zT_22 = 0;
    zT_11 = inner;
    zT_24 = 0;
    zT_26 = 0;
    zT_28 = 0;
    zT_30 = zF_6C9FF72F_astStoreAddNode(zT_6, (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt), (unsigned char)((unsigned char)zT_18), (unsigned int)((unsigned int)zT_20), (unsigned int)((unsigned int)zT_22), zT_11, (unsigned int)((unsigned int)zT_24), (unsigned int)((unsigned int)zT_26), (unsigned int)((unsigned int)zT_28));
    zT_31.data.payload = zT_30;
    zT_31.is_error = 0;
    return zT_31;
}

/* parserParseReturnExpr */
zT_3B6EA323_EU_01 zF_224C1394_parserParseReturnEx(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_8;
    zT_3A355BD2_Token zT_9 = {0};
    zT_EAC3E484_TokenKind zT_10;
    unsigned char zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    zT_B559F9DA_Parser* zT_26;
    zT_3B6EA323_EU_01 zT_29 = {0};
    unsigned char zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned short zT_34;
    unsigned int zT_36;
    unsigned char zT_37;
    zT_3A355BD2_Token zT_39;
    unsigned int zT_40;
    unsigned short zT_41;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_56;
    int zT_59;
    int zT_61;
    int zT_63;
    unsigned int zT_65 = 0;
    zT_3B6EA323_EU_01 zT_66;
    zT_3A355BD2_Token kw;
    unsigned int expr;
    zT_EAC3E484_TokenKind nt;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    expr = zT_6;
    zT_8 = self;
    zT_9 = zF_068A2DE5_parserPeek(zT_8);
    zT_10 = zT_9.kind;
    nt = zT_10;
    if ((unsigned char)(nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_18 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 0;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_22 = nt != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_9;
    z_bb_8:
    zT_22 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_22) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_26 = self;
    zT_29 = zF_F07C1F04_parserParseExprPrec(zT_26, (zT_2B10107F_Prec)(zT_2B10107F_Prec_none));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_33 = kw.span_start;
    zT_34 = kw.span_len;
    zT_36 = zT_33 + (unsigned int)((unsigned int)zT_34);
    end_pos = zT_36;
    zT_37 = self->last_tok_valid;
    if (zT_37) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    return zT_29;
    z_bb_13:
    zT_31 = zT_29.data.payload;
    goto z_bb_14;
    z_bb_14:
    expr = zT_31;
    goto z_bb_11;
    z_bb_15:
    zT_39 = self->last_tok;
    last = zT_39;
    zT_40 = last.span_start;
    zT_41 = last.span_len;
    zT_43 = zT_40 + (unsigned int)((unsigned int)zT_41);
    end_pos = zT_43;
    goto z_bb_16;
    z_bb_16:
    zT_44 = self->store;
    zT_56 = 0;
    zT_47 = kw.span_start;
    zT_48 = end_pos;
    zT_49 = expr;
    zT_59 = 0;
    zT_61 = 0;
    zT_63 = 0;
    zT_65 = zF_6C9FF72F_astStoreAddNode(zT_44, (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt), (unsigned char)((unsigned char)zT_56), zT_47, zT_48, zT_49, (unsigned int)((unsigned int)zT_59), (unsigned int)((unsigned int)zT_61), (unsigned int)((unsigned int)zT_63));
    zT_66.data.payload = zT_65;
    zT_66.is_error = 0;
    return zT_66;
}

/* parserParseBreakExpr */
zT_3B6EA323_EU_01 zF_C69B6287_parserParseBreakExp(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_2B3424E9_ParseToken zT_26;
    zT_EAC3E484_TokenKind zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_D3EB6303_StringInterner* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_B559F9DA_Parser* zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35 = {0};
    unsigned int zT_36 = 0;
    unsigned int zT_38;
    unsigned short zT_39;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_3A355BD2_Token zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_57;
    int zT_61;
    int zT_64;
    int zT_66;
    int zT_68;
    unsigned int zT_70 = 0;
    zT_3B6EA323_EU_01 zT_71;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_2B3424E9_ParseToken pt;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = kw.span_start;
    zT_39 = kw.span_len;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    end_pos = zT_41;
    zT_42 = self->last_tok_valid;
    if (zT_42) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_24;
    zT_27 = label_tok.kind;
    zT_26.kind = zT_27;
    zT_28 = label_tok.span_start;
    zT_26.span_start = zT_28;
    zT_29 = label_tok.span_len;
    zT_26.span_len = zT_29;
    pt = zT_26;
    zT_30 = self->interner;
    zT_33 = self;
    zT_34 = pt;
    zT_35 = zF_08D61E58_parserTokenText(zT_33, zT_34);
    zT_31 = zT_35;
    zT_36 = zF_50C274AF_stringInternerInter(zT_30, zT_31);
    label_id = zT_36;
    goto z_bb_2;
    z_bb_6:
    zT_44 = self->last_tok;
    last = zT_44;
    zT_45 = last.span_start;
    zT_46 = last.span_len;
    zT_48 = zT_45 + (unsigned int)((unsigned int)zT_46);
    end_pos = zT_48;
    goto z_bb_7;
    z_bb_7:
    zT_49 = self->store;
    zT_61 = 0;
    zT_52 = kw.span_start;
    zT_53 = end_pos;
    zT_64 = 0;
    zT_66 = 0;
    zT_68 = 0;
    zT_57 = label_id;
    zT_70 = zF_6C9FF72F_astStoreAddNode(zT_49, (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt), (unsigned char)((unsigned char)zT_61), zT_52, zT_53, (unsigned int)((unsigned int)zT_64), (unsigned int)((unsigned int)zT_66), (unsigned int)((unsigned int)zT_68), zT_57);
    zT_71.data.payload = zT_70;
    zT_71.is_error = 0;
    return zT_71;
}

/* parserParseContinueExpr */
zT_3B6EA323_EU_01 zF_73B42F4B_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_13;
    zT_3A355BD2_Token zT_14 = {0};
    zT_B559F9DA_Parser* zT_16;
    zT_CB78802F_EU_49 zT_20 = {0};
    unsigned char zT_21;
    int zT_22;
    zT_3B6EA323_EU_01 zT_23;
    zT_2B3424E9_ParseToken zT_24;
    zT_2B3424E9_ParseToken zT_26;
    zT_EAC3E484_TokenKind zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_D3EB6303_StringInterner* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_B559F9DA_Parser* zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35 = {0};
    unsigned int zT_36 = 0;
    unsigned int zT_38;
    unsigned short zT_39;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_3A355BD2_Token zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_57;
    int zT_61;
    int zT_64;
    int zT_66;
    int zT_68;
    unsigned int zT_70 = 0;
    zT_3B6EA323_EU_01 zT_71;
    zT_3A355BD2_Token kw;
    unsigned int label_id;
    zT_2B3424E9_ParseToken label_tok;
    unsigned int end_pos;
    zT_2B3424E9_ParseToken pt;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    kw = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    label_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = self;
    zT_14 = zF_C241B2C4_parserAdvance(zT_13);
    (void)zT_14;
    zT_16 = self;
    zT_20 = zF_5578C74F_parserExpect(zT_16, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = kw.span_start;
    zT_39 = kw.span_len;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    end_pos = zT_41;
    zT_42 = self->last_tok_valid;
    if (zT_42) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_22 = zT_20.data.err;
    zT_23.data.err = zT_22;
    zT_23.is_error = 1;
    return zT_23;
    z_bb_4:
    zT_24 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    label_tok = zT_24;
    zT_27 = label_tok.kind;
    zT_26.kind = zT_27;
    zT_28 = label_tok.span_start;
    zT_26.span_start = zT_28;
    zT_29 = label_tok.span_len;
    zT_26.span_len = zT_29;
    pt = zT_26;
    zT_30 = self->interner;
    zT_33 = self;
    zT_34 = pt;
    zT_35 = zF_08D61E58_parserTokenText(zT_33, zT_34);
    zT_31 = zT_35;
    zT_36 = zF_50C274AF_stringInternerInter(zT_30, zT_31);
    label_id = zT_36;
    goto z_bb_2;
    z_bb_6:
    zT_44 = self->last_tok;
    last = zT_44;
    zT_45 = last.span_start;
    zT_46 = last.span_len;
    zT_48 = zT_45 + (unsigned int)((unsigned int)zT_46);
    end_pos = zT_48;
    goto z_bb_7;
    z_bb_7:
    zT_49 = self->store;
    zT_61 = 0;
    zT_52 = kw.span_start;
    zT_53 = end_pos;
    zT_64 = 0;
    zT_66 = 0;
    zT_68 = 0;
    zT_57 = label_id;
    zT_70 = zF_6C9FF72F_astStoreAddNode(zT_49, (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt), (unsigned char)((unsigned char)zT_61), zT_52, zT_53, (unsigned int)((unsigned int)zT_64), (unsigned int)((unsigned int)zT_66), (unsigned int)((unsigned int)zT_68), zT_57);
    zT_71.data.payload = zT_70;
    zT_71.is_error = 0;
    return zT_71;
}

/* parserParseReturnStmt */
zT_3B6EA323_EU_01 zF_76F5B9F1_parserParseReturnSt(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_224C1394_parserParseReturnEx(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseBreakStmt */
zT_3B6EA323_EU_01 zF_6DA396FE_parserParseBreakStm(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_C69B6287_parserParseBreakExp(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseContinueStmt */
zT_3B6EA323_EU_01 zF_E13A9822_parserParseContinue(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3B6EA323_EU_01 zT_3 = {0};
    unsigned char zT_4;
    unsigned int zT_5;
    zT_B559F9DA_Parser* zT_6;
    zT_CB78802F_EU_49 zT_10 = {0};
    unsigned char zT_11;
    int zT_12;
    zT_3B6EA323_EU_01 zT_13;
    zT_2B3424E9_ParseToken zT_14;
    zT_3B6EA323_EU_01 zT_15;
    unsigned int node;
    zT_2 = self;
    zT_3 = zF_73B42F4B_parserParseContinue(zT_2);
    zT_4 = zT_3.is_error;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_3;
    z_bb_2:
    zT_5 = zT_3.data.payload;
    goto z_bb_3;
    z_bb_3:
    node = zT_5;
    zT_6 = self;
    zT_10 = zF_5578C74F_parserExpect(zT_6, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = zT_10.data.err;
    zT_13.data.err = zT_12;
    zT_13.is_error = 1;
    return zT_13;
    z_bb_5:
    zT_14 = zT_10.data.payload;
    goto z_bb_6;
    z_bb_6:
    (void)zT_14;
    zT_15.data.payload = node;
    zT_15.is_error = 0;
    return zT_15;
}

/* parserParseDeferStmt */
zT_3B6EA323_EU_01 zF_3B25AFD5_parserParseDeferStm(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    zT_B559F9DA_Parser* zT_6;
    zT_3B6EA323_EU_01 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char zT_12;
    zT_3A355BD2_Token zT_14;
    unsigned int zT_15;
    unsigned short zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_29;
    int zT_32;
    int zT_34;
    int zT_36;
    unsigned int zT_38 = 0;
    zT_3B6EA323_EU_01 zT_39;
    zT_3A355BD2_Token kw;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    kw = zT_4;
    zT_6 = self;
    zT_7 = zF_462FC60E_parserParseStatemen(zT_6);
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_7;
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    body = zT_9;
    zT_11 = kw.span_start;
    end_pos = zT_11;
    zT_12 = self->last_tok_valid;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = self->last_tok;
    last = zT_14;
    zT_15 = last.span_start;
    zT_16 = last.span_len;
    zT_18 = zT_15 + (unsigned int)((unsigned int)zT_16);
    end_pos = zT_18;
    goto z_bb_5;
    z_bb_5:
    zT_19 = self->store;
    zT_20 = kind;
    zT_29 = 0;
    zT_22 = kw.span_start;
    zT_23 = end_pos;
    zT_24 = body;
    zT_32 = 0;
    zT_34 = 0;
    zT_36 = 0;
    zT_38 = zF_6C9FF72F_astStoreAddNode(zT_19, zT_20, (unsigned char)((unsigned char)zT_29), zT_22, zT_23, zT_24, (unsigned int)((unsigned int)zT_32), (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)zT_36));
    zT_39.data.payload = zT_38;
    zT_39.is_error = 0;
    return zT_39;
}

/* parserParseErrdeferStmt */
zT_3B6EA323_EU_01 zF_6C2E50E6_parserParseErrdefer(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_1;
    zT_3B6EA323_EU_01 zT_5 = {0};
    zT_1 = self;
    zT_5 = zF_3B25AFD5_parserParseDeferStm(zT_1, (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt));
    return zT_5;
}

/* parserParseTestDecl */
zT_3B6EA323_EU_01 zF_15A196A5_parserParseTestDecl(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_3A355BD2_Token zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    zT_B559F9DA_Parser* zT_7;
    zT_3A355BD2_Token zT_8 = {0};
    zT_EAC3E484_TokenKind zT_9;
    zT_B559F9DA_Parser* zT_14;
    zT_3A355BD2_Token zT_15 = {0};
    zT_2B3424E9_ParseToken zT_17;
    zT_EAC3E484_TokenKind zT_18;
    unsigned int zT_19;
    unsigned short zT_20;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_B559F9DA_Parser* zT_24;
    zT_2B3424E9_ParseToken zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26 = {0};
    unsigned int zT_27 = 0;
    zT_B559F9DA_Parser* zT_29;
    zT_3B6EA323_EU_01 zT_30 = {0};
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    unsigned char zT_35;
    zT_3A355BD2_Token zT_37;
    unsigned int zT_38;
    unsigned short zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_51;
    int zT_55;
    int zT_58;
    int zT_60;
    unsigned int zT_62 = 0;
    zT_3B6EA323_EU_01 zT_63;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    zT_3A355BD2_Token name_tok;
    zT_2B3424E9_ParseToken npt;
    unsigned int body;
    unsigned int end_pos;
    zT_3A355BD2_Token last;
    zT_2 = self;
    zT_3 = zF_C241B2C4_parserAdvance(zT_2);
    tok = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    name_id = zT_6;
    zT_7 = self;
    zT_8 = zF_068A2DE5_parserPeek(zT_7);
    zT_9 = zT_8.kind;
    if ((unsigned char)(zT_9 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self;
    zT_15 = zF_C241B2C4_parserAdvance(zT_14);
    name_tok = zT_15;
    zT_18 = name_tok.kind;
    zT_17.kind = zT_18;
    zT_19 = name_tok.span_start;
    zT_17.span_start = zT_19;
    zT_20 = name_tok.span_len;
    zT_17.span_len = zT_20;
    npt = zT_17;
    zT_21 = self->interner;
    zT_24 = self;
    zT_25 = npt;
    zT_26 = zF_08D61E58_parserTokenText(zT_24, zT_25);
    zT_22 = zT_26;
    zT_27 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    name_id = zT_27;
    goto z_bb_2;
    z_bb_2:
    zT_29 = self;
    zT_30 = zF_365CA04A_parserParseBlock(zT_29);
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return zT_30;
    z_bb_4:
    zT_32 = zT_30.data.payload;
    goto z_bb_5;
    z_bb_5:
    body = zT_32;
    end_pos = zT_34;
    zT_35 = self->last_tok_valid;
    if (zT_35) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_37 = self->last_tok;
    last = zT_37;
    zT_38 = last.span_start;
    zT_39 = last.span_len;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    end_pos = zT_41;
    goto z_bb_7;
    z_bb_7:
    zT_43 = self->store;
    zT_55 = 0;
    zT_46 = tok.span_start;
    zT_47 = end_pos;
    zT_48 = body;
    zT_58 = 0;
    zT_60 = 0;
    zT_51 = name_id;
    zT_62 = zF_6C9FF72F_astStoreAddNode(zT_43, (zT_8143F551_AstKind)(zT_8143F551_AstKind_test_decl), (unsigned char)((unsigned char)zT_55), zT_46, zT_47, zT_48, (unsigned int)((unsigned int)zT_58), (unsigned int)((unsigned int)zT_60), zT_51);
    zT_63.data.payload = zT_62;
    zT_63.is_error = 0;
    return zT_63;
    z_bb_8:
    zT_42 = tok.span_start;
    end_pos = zT_42;
    goto z_bb_7;
}

/* parserParseContainerDecl */
zT_3B6EA323_EU_01 zF_0A0E9C6C_parserParseContaine(zT_B559F9DA_Parser* self, zT_8143F551_AstKind kind) {
    zT_B559F9DA_Parser* zT_3;
    zT_3A355BD2_Token zT_4 = {0};
    int zT_6;
    unsigned int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned char zT_17;
    zT_B559F9DA_Parser* zT_18;
    zT_3A355BD2_Token zT_19 = {0};
    zT_EAC3E484_TokenKind zT_20;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_B559F9DA_Parser* zT_26;
    zT_CB78802F_EU_49 zT_30 = {0};
    unsigned char zT_31;
    int zT_32;
    zT_3B6EA323_EU_01 zT_33;
    zT_2B3424E9_ParseToken zT_34;
    zT_B559F9DA_Parser* zT_35;
    zT_CB78802F_EU_49 zT_39 = {0};
    unsigned char zT_40;
    int zT_41;
    zT_3B6EA323_EU_01 zT_42;
    zT_2B3424E9_ParseToken zT_43;
    int zT_44;
    unsigned char zT_45;
    unsigned char zT_49;
    zT_B559F9DA_Parser* zT_50;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_52;
    zT_B559F9DA_Parser* zT_56;
    zT_3A355BD2_Token zT_57 = {0};
    zT_B559F9DA_Parser* zT_58;
    zT_3B6EA323_EU_01 zT_59 = {0};
    unsigned char zT_60;
    unsigned int zT_61;
    zT_B559F9DA_Parser* zT_62;
    zT_CB78802F_EU_49 zT_66 = {0};
    unsigned char zT_67;
    int zT_68;
    zT_3B6EA323_EU_01 zT_69;
    zT_2B3424E9_ParseToken zT_70;
    zT_B559F9DA_Parser* zT_71;
    zT_3A355BD2_Token zT_72 = {0};
    zT_EAC3E484_TokenKind zT_73;
    zT_B559F9DA_Parser* zT_78;
    zT_3A355BD2_Token zT_79 = {0};
    zT_2B3424E9_ParseToken zT_81;
    zT_EAC3E484_TokenKind zT_82;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_B559F9DA_Parser* zT_88;
    zT_2B3424E9_ParseToken zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90 = {0};
    unsigned int zT_91 = 0;
    zT_B559F9DA_Parser* zT_92;
    zT_CB78802F_EU_49 zT_96 = {0};
    unsigned char zT_97;
    int zT_98;
    zT_3B6EA323_EU_01 zT_99;
    zT_2B3424E9_ParseToken zT_100;
    unsigned int* zT_102 = 0;
    int zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    zT_B559F9DA_Parser* zT_108;
    zT_3A355BD2_Token zT_109 = {0};
    zT_EAC3E484_TokenKind zT_110;
    zT_B559F9DA_Parser* zT_115;
    zT_CB78802F_EU_49 zT_119 = {0};
    unsigned char zT_120;
    int zT_121;
    zT_3B6EA323_EU_01 zT_122;
    zT_2B3424E9_ParseToken zT_123;
    zT_2B3424E9_ParseToken zT_125;
    zT_EAC3E484_TokenKind zT_126;
    unsigned int zT_127;
    unsigned short zT_128;
    zT_D3EB6303_StringInterner* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_B559F9DA_Parser* zT_133;
    zT_2B3424E9_ParseToken zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135 = {0};
    unsigned int zT_136 = 0;
    int zT_141;
    unsigned int zT_142;
    zT_B559F9DA_Parser* zT_143;
    zT_3A355BD2_Token zT_144 = {0};
    zT_EAC3E484_TokenKind zT_145;
    zT_B559F9DA_Parser* zT_149;
    zT_3A355BD2_Token zT_150 = {0};
    zT_B559F9DA_Parser* zT_151;
    zT_3B6EA323_EU_01 zT_154 = {0};
    unsigned char zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_161;
    unsigned int zT_164;
    unsigned int zT_166;
    int zT_170;
    unsigned int zT_173;
    unsigned short zT_174;
    int zT_177;
    int zT_179;
    unsigned int zT_181 = 0;
    zT_B559F9DA_Parser* zT_182;
    unsigned int** zT_183;
    unsigned int* zT_184;
    unsigned int* zT_185;
    unsigned int zT_186;
    zT_B559F9DA_Parser* zT_190;
    zT_CB78802F_EU_49 zT_194 = {0};
    unsigned char zT_195;
    int zT_196;
    zT_3B6EA323_EU_01 zT_197;
    zT_2B3424E9_ParseToken zT_198;
    zT_B559F9DA_Parser* zT_200;
    zT_3B6EA323_EU_01 zT_201 = {0};
    unsigned char zT_202;
    unsigned int zT_203;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned int zT_213;
    int zT_217;
    unsigned int zT_220;
    unsigned short zT_221;
    int zT_224;
    int zT_226;
    unsigned int zT_228 = 0;
    zT_B559F9DA_Parser* zT_229;
    unsigned int** zT_230;
    unsigned int* zT_231;
    unsigned int* zT_232;
    unsigned int zT_233;
    zT_B559F9DA_Parser* zT_237;
    zT_3A355BD2_Token zT_238 = {0};
    zT_EAC3E484_TokenKind zT_239;
    zT_B559F9DA_Parser* zT_243;
    zT_3A355BD2_Token zT_244 = {0};
    zT_B559F9DA_Parser* zT_246;
    zT_CB78802F_EU_49 zT_250 = {0};
    unsigned char zT_251;
    int zT_252;
    zT_3B6EA323_EU_01 zT_253;
    zT_2B3424E9_ParseToken zT_254;
    int zT_256;
    unsigned int zT_257;
    int zT_258;
    zT_6B0A7D14_AstStore* zT_260;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_261;
    int zT_263;
    unsigned int* zT_264;
    unsigned int zT_265;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_266;
    unsigned int zT_267 = 0;
    unsigned int zT_269;
    unsigned short zT_270;
    unsigned int zT_272;
    zT_6B0A7D14_AstStore* zT_273;
    zT_8143F551_AstKind zT_274;
    unsigned char zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned int zT_281;
    int zT_284;
    unsigned int zT_286 = 0;
    zT_3B6EA323_EU_01 zT_287;
    zT_3A355BD2_Token tok;
    unsigned int name_id;
    unsigned char is_tagged;
    unsigned int backing_type;
    zT_3A355BD2_Token name_tok;
    zT_2B3424E9_ParseToken pt;
    unsigned int* fields_buf;
    unsigned int fields_count;
    unsigned int fields_cap;
    zT_2B3424E9_ParseToken ftok;
    zT_2B3424E9_ParseToken rbrace;
    zT_2B3424E9_ParseToken fpt;
    unsigned int fid;
    unsigned int ev;
    unsigned int enode;
    unsigned int ftype;
    unsigned int fnode;
    unsigned int payload;
    unsigned int end_pos;
    zT_3 = self;
    zT_4 = zF_C241B2C4_parserAdvance(zT_3);
    tok = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    name_id = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned char)zT_9;
    is_tagged = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    backing_type = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = self;
    zT_19 = zF_068A2DE5_parserPeek(zT_18);
    zT_20 = zT_19.kind;
    zT_17 = zT_20 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_3;
    z_bb_2:
    zT_17 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_17) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_24 = self;
    zT_25 = zF_C241B2C4_parserAdvance(zT_24);
    (void)zT_25;
    zT_26 = self;
    zT_30 = zF_5578C74F_parserExpect(zT_26, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_enum));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_12; else goto z_bb_13;
    z_bb_6:
    zT_32 = zT_30.data.err;
    zT_33.data.err = zT_32;
    zT_33.is_error = 1;
    return zT_33;
    z_bb_7:
    zT_34 = zT_30.data.payload;
    goto z_bb_8;
    z_bb_8:
    (void)zT_34;
    zT_35 = self;
    zT_39 = zF_5578C74F_parserExpect(zT_35, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = zT_39.data.err;
    zT_42.data.err = zT_41;
    zT_42.is_error = 1;
    return zT_42;
    z_bb_10:
    zT_43 = zT_39.data.payload;
    goto z_bb_11;
    z_bb_11:
    (void)zT_43;
    zT_44 = 1;
    zT_45 = (unsigned char)zT_44;
    is_tagged = zT_45;
    goto z_bb_5;
    z_bb_12:
    zT_50 = self;
    zT_51 = zF_068A2DE5_parserPeek(zT_50);
    zT_52 = zT_51.kind;
    zT_49 = zT_52 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen);
    goto z_bb_14;
    z_bb_13:
    zT_49 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_49) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_56 = self;
    zT_57 = zF_C241B2C4_parserAdvance(zT_56);
    (void)zT_57;
    zT_58 = self;
    zT_59 = zF_CBDBFE85_parserParseType(zT_58);
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_71 = self;
    zT_72 = zF_068A2DE5_parserPeek(zT_71);
    zT_73 = zT_72.kind;
    if ((unsigned char)(zT_73 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier))) goto z_bb_23; else goto z_bb_24;
    z_bb_17:
    return zT_59;
    z_bb_18:
    zT_61 = zT_59.data.payload;
    goto z_bb_19;
    z_bb_19:
    backing_type = zT_61;
    zT_62 = self;
    zT_66 = zF_5578C74F_parserExpect(zT_62, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen));
    zT_67 = zT_66.is_error;
    if (zT_67) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_68 = zT_66.data.err;
    zT_69.data.err = zT_68;
    zT_69.is_error = 1;
    return zT_69;
    z_bb_21:
    zT_70 = zT_66.data.payload;
    goto z_bb_22;
    z_bb_22:
    (void)zT_70;
    goto z_bb_16;
    z_bb_23:
    zT_78 = self;
    zT_79 = zF_C241B2C4_parserAdvance(zT_78);
    name_tok = zT_79;
    zT_82 = name_tok.kind;
    zT_81.kind = zT_82;
    zT_83 = name_tok.span_start;
    zT_81.span_start = zT_83;
    zT_84 = name_tok.span_len;
    zT_81.span_len = zT_84;
    pt = zT_81;
    zT_85 = self->interner;
    zT_88 = self;
    zT_89 = pt;
    zT_90 = zF_08D61E58_parserTokenText(zT_88, zT_89);
    zT_86 = zT_90;
    zT_91 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    name_id = zT_91;
    goto z_bb_24;
    z_bb_24:
    zT_92 = self;
    zT_96 = zF_5578C74F_parserExpect(zT_92, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_97 = zT_96.is_error;
    if (zT_97) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_98 = zT_96.data.err;
    zT_99.data.err = zT_98;
    zT_99.is_error = 1;
    return zT_99;
    z_bb_26:
    zT_100 = zT_96.data.payload;
    goto z_bb_27;
    z_bb_27:
    (void)zT_100;
    fields_buf = zT_102;
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    fields_count = zT_105;
    zT_107 = 0;
    fields_cap = zT_107;
    goto z_bb_28;
    z_bb_28:
    zT_108 = self;
    zT_109 = zF_068A2DE5_parserPeek(zT_108);
    zT_110 = zT_109.kind;
    if ((unsigned char)(zT_110 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_115 = self;
    zT_119 = zF_5578C74F_parserExpect(zT_115, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier));
    zT_120 = zT_119.is_error;
    if (zT_120) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    zT_246 = self;
    zT_250 = zF_5578C74F_parserExpect(zT_246, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_251 = zT_250.is_error;
    if (zT_251) goto z_bb_51; else goto z_bb_52;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_121 = zT_119.data.err;
    zT_122.data.err = zT_121;
    zT_122.is_error = 1;
    return zT_122;
    z_bb_33:
    zT_123 = zT_119.data.payload;
    goto z_bb_34;
    z_bb_34:
    ftok = zT_123;
    zT_126 = ftok.kind;
    zT_125.kind = zT_126;
    zT_127 = ftok.span_start;
    zT_125.span_start = zT_127;
    zT_128 = ftok.span_len;
    zT_125.span_len = zT_128;
    fpt = zT_125;
    zT_130 = self->interner;
    zT_133 = self;
    zT_134 = fpt;
    zT_135 = zF_08D61E58_parserTokenText(zT_133, zT_134);
    zT_131 = zT_135;
    zT_136 = zF_50C274AF_stringInternerInter(zT_130, zT_131);
    fid = zT_136;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    ev = zT_142;
    zT_143 = self;
    zT_144 = zF_068A2DE5_parserPeek(zT_143);
    zT_145 = zT_144.kind;
    if ((unsigned char)(zT_145 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    zT_237 = self;
    zT_238 = zF_068A2DE5_parserPeek(zT_237);
    zT_239 = zT_238.kind;
    if ((unsigned char)(zT_239 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma))) goto z_bb_49; else goto z_bb_50;
    z_bb_37:
    zT_190 = self;
    zT_194 = zF_5578C74F_parserExpect(zT_190, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon));
    zT_195 = zT_194.is_error;
    if (zT_195) goto z_bb_43; else goto z_bb_44;
    z_bb_38:
    zT_149 = self;
    zT_150 = zF_C241B2C4_parserAdvance(zT_149);
    (void)zT_150;
    zT_151 = self;
    zT_154 = zF_F07C1F04_parserParseExprPrec(zT_151, (zT_2B10107F_Prec)(zT_2B10107F_Prec_assignment));
    zT_155 = zT_154.is_error;
    if (zT_155) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_158 = self->store;
    zT_170 = 0;
    zT_161 = ftok.span_start;
    zT_173 = ftok.span_start;
    zT_174 = ftok.span_len;
    zT_177 = 0;
    zT_164 = ev;
    zT_179 = 0;
    zT_166 = fid;
    zT_181 = zF_6C9FF72F_astStoreAddNode(zT_158, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_170), zT_161, (unsigned int)(zT_173 + (unsigned int)((unsigned int)zT_174)), (unsigned int)((unsigned int)zT_177), zT_164, (unsigned int)((unsigned int)zT_179), zT_166);
    enode = zT_181;
    zT_182 = self;
    zT_183 = &fields_buf;
    zT_184 = &fields_count;
    zT_185 = &fields_cap;
    zT_186 = enode;
    zF_0F1462F8_parserPushU32(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_36;
    z_bb_40:
    return zT_154;
    z_bb_41:
    zT_156 = zT_154.data.payload;
    goto z_bb_42;
    z_bb_42:
    ev = zT_156;
    goto z_bb_39;
    z_bb_43:
    zT_196 = zT_194.data.err;
    zT_197.data.err = zT_196;
    zT_197.is_error = 1;
    return zT_197;
    z_bb_44:
    zT_198 = zT_194.data.payload;
    goto z_bb_45;
    z_bb_45:
    (void)zT_198;
    zT_200 = self;
    zT_201 = zF_CBDBFE85_parserParseType(zT_200);
    zT_202 = zT_201.is_error;
    if (zT_202) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return zT_201;
    z_bb_47:
    zT_203 = zT_201.data.payload;
    goto z_bb_48;
    z_bb_48:
    ftype = zT_203;
    zT_205 = self->store;
    zT_217 = 0;
    zT_208 = ftok.span_start;
    zT_220 = ftok.span_start;
    zT_221 = ftok.span_len;
    zT_210 = ftype;
    zT_224 = 0;
    zT_226 = 0;
    zT_213 = fid;
    zT_228 = zF_6C9FF72F_astStoreAddNode(zT_205, (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl), (unsigned char)((unsigned char)zT_217), zT_208, (unsigned int)(zT_220 + (unsigned int)((unsigned int)zT_221)), zT_210, (unsigned int)((unsigned int)zT_224), (unsigned int)((unsigned int)zT_226), zT_213);
    fnode = zT_228;
    zT_229 = self;
    zT_230 = &fields_buf;
    zT_231 = &fields_count;
    zT_232 = &fields_cap;
    zT_233 = fnode;
    zF_0F1462F8_parserPushU32(zT_229, zT_230, zT_231, zT_232, zT_233);
    goto z_bb_36;
    z_bb_49:
    zT_243 = self;
    zT_244 = zF_C241B2C4_parserAdvance(zT_243);
    (void)zT_244;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_31;
    z_bb_51:
    zT_252 = zT_250.data.err;
    zT_253.data.err = zT_252;
    zT_253.is_error = 1;
    return zT_253;
    z_bb_52:
    zT_254 = zT_250.data.payload;
    goto z_bb_53;
    z_bb_53:
    rbrace = zT_254;
    zT_256 = 0;
    zT_257 = (unsigned int)zT_256;
    payload = zT_257;
    zT_258 = 0;
    if ((unsigned char)(fields_count > (unsigned int)zT_258)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_260 = self->store;
    zT_263 = 0;
    zT_264 = fields_buf + zT_263;
    zT_265 = fields_count - zT_263;
    zT_266.ptr = zT_264;
    zT_266.len = zT_265;
    zT_261 = zT_266;
    zT_267 = zF_583E993C_astStoreAddExtraChi(zT_260, zT_261);
    payload = zT_267;
    goto z_bb_55;
    z_bb_55:
    zT_269 = rbrace.span_start;
    zT_270 = rbrace.span_len;
    zT_272 = zT_269 + (unsigned int)((unsigned int)zT_270);
    end_pos = zT_272;
    zT_273 = self->store;
    zT_274 = kind;
    zT_275 = is_tagged;
    zT_276 = tok.span_start;
    zT_277 = end_pos;
    zT_278 = name_id;
    zT_279 = backing_type;
    zT_284 = 0;
    zT_281 = payload;
    zT_286 = zF_6C9FF72F_astStoreAddNode(zT_273, zT_274, zT_275, zT_276, zT_277, zT_278, zT_279, (unsigned int)((unsigned int)zT_284), zT_281);
    zT_287.data.payload = zT_286;
    zT_287.is_error = 0;
    return zT_287;
}

/* parserParseBlock */
zT_3B6EA323_EU_01 zF_365CA04A_parserParseBlock(zT_B559F9DA_Parser* self) {
    zT_B559F9DA_Parser* zT_2;
    zT_CB78802F_EU_49 zT_6 = {0};
    unsigned char zT_7;
    int zT_8;
    zT_3B6EA323_EU_01 zT_9;
    zT_2B3424E9_ParseToken zT_10;
    unsigned int zT_12;
    zT_993A6923_Arr_unsigned_int_64 zT_14;
    unsigned int zT_16;
    zT_B559F9DA_Parser* zT_17;
    zT_3A355BD2_Token zT_18 = {0};
    zT_EAC3E484_TokenKind zT_19;
    unsigned char zT_23;
    zT_B559F9DA_Parser* zT_24;
    zT_3A355BD2_Token zT_25 = {0};
    zT_EAC3E484_TokenKind zT_26;
    zT_B559F9DA_Parser* zT_31;
    zT_3B6EA323_EU_01 zT_32 = {0};
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_41;
    unsigned int** zT_44;
    unsigned int* zT_45;
    unsigned int* zT_46;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    unsigned int zT_55;
    unsigned int** zT_56;
    unsigned int* zT_57;
    unsigned int* zT_58;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_60;
    unsigned int zT_66;
    zT_B559F9DA_Parser* zT_68;
    zT_3A355BD2_Token zT_69 = {0};
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_EAC3E484_TokenKind zT_83;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    zT_EAC3E484_TokenKind zT_97;
    unsigned char zT_101;
    zT_EAC3E484_TokenKind zT_102;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_B559F9DA_Parser* zT_128;
    zT_CB78802F_EU_49 zT_132 = {0};
    unsigned char zT_133;
    int zT_134;
    zT_3B6EA323_EU_01 zT_135;
    zT_2B3424E9_ParseToken zT_136;
    int zT_138;
    unsigned int zT_139;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_143 = {0};
    int zT_148;
    unsigned int* zT_149;
    unsigned int zT_150;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_151;
    unsigned int* zT_152;
    unsigned int* zT_154;
    unsigned int zT_155;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_156;
    zT_6B0A7D14_AstStore* zT_157;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_158;
    unsigned int zT_160 = 0;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int zT_174;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178 = 0;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_196;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    int zT_202;
    unsigned char* zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206 = 0;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned char* zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned int zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    zT_6B0A7D14_AstStore* zT_223;
    unsigned int zT_226;
    unsigned int zT_231;
    int zT_235;
    unsigned int zT_238;
    unsigned short zT_239;
    int zT_242;
    int zT_244;
    int zT_246;
    unsigned int zT_248 = 0;
    zT_3B6EA323_EU_01 zT_249;
    zT_2B3424E9_ParseToken lbrace;
    unsigned int saved_len;
    zT_993A6923_Arr_unsigned_int_64 local_buf;
    unsigned int local_len;
    unsigned int stmt;
    zT_2B3424E9_ParseToken rbrace;
    zT_3A355BD2_Token pk;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_km;
    unsigned int fi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_lm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbx_pm;
    unsigned int payload;
    zT_3CB0179A_Slice_zT_05F374B1_u slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_m;
    zT_5A26C2ED_Arr_unsigned_char_1 plen_lb;
    unsigned int plen_ll;
    unsigned int plen_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_pm;
    zT_5A26C2ED_Arr_unsigned_char_1 plen_pb;
    unsigned int plen_pl;
    unsigned int plen_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u plen_nl;
    zT_2 = self;
    zT_6 = zF_5578C74F_parserExpect(zT_2, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace));
    zT_7 = zT_6.is_error;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = zT_6.data.err;
    zT_9.data.err = zT_8;
    zT_9.is_error = 1;
    return zT_9;
    z_bb_2:
    zT_10 = zT_6.data.payload;
    goto z_bb_3;
    z_bb_3:
    lbrace = zT_10;
    zT_12 = self->child_buf_len;
    saved_len = zT_12;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_14[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        local_buf[_i] = zT_14[_i];
        _i++;
    }
}
    zT_16 = 0;
    local_len = zT_16;
    goto z_bb_4;
    z_bb_4:
    zT_17 = self;
    zT_18 = zF_068A2DE5_parserPeek(zT_17);
    zT_19 = zT_18.kind;
    if ((unsigned char)(zT_19 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_31 = self;
    zT_32 = zF_462FC60E_parserParseStatemen(zT_31);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_128 = self;
    zT_132 = zF_5578C74F_parserExpect(zT_128, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace));
    zT_133 = zT_132.is_error;
    if (zT_133) goto z_bb_28; else goto z_bb_29;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_24 = self;
    zT_25 = zF_068A2DE5_parserPeek(zT_24);
    zT_26 = zT_25.kind;
    zT_23 = zT_26 != (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_10;
    z_bb_9:
    zT_23 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    return zT_32;
    z_bb_12:
    zT_34 = zT_32.data.payload;
    goto z_bb_13;
    z_bb_13:
    stmt = zT_34;
    if ((unsigned char)(local_len < (unsigned int)(64))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_37 = (unsigned int)local_len;
    local_buf[zT_37] = stmt;
    goto z_bb_15;
    z_bb_15:
    zT_66 = local_len + (unsigned int)(1);
    local_len = zT_66;
    zT_68 = self;
    zT_69 = zF_068A2DE5_parserPeek(zT_68);
    pk = zT_69;
    zT_71 = "PBX:S";
    zT_73 = 5;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    pbx_sm = zT_72;
    zT_74 = pbx_sm;
    zF_C914CB83_markerWriteInt(zT_74, (unsigned int)((unsigned int)local_len));
    zT_78 = "PBX:T";
    zT_80 = 5;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    pbx_tm = zT_79;
    zT_81 = pbx_tm;
    zT_83 = pk.kind;
    zF_C914CB83_markerWriteInt(zT_81, (unsigned int)((unsigned int)zT_83));
    zT_86 = "PBX:K";
    zT_88 = 5;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    pbx_km = zT_87;
    zT_89 = pbx_km;
    zT_91 = self->store;
    zT_92 = stmt;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    zT_95 = zT_94.kind;
    zF_C914CB83_markerWriteInt(zT_89, (unsigned int)((unsigned int)zT_95));
    zT_97 = pk.kind;
    if ((unsigned char)(zT_97 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace))) goto z_bb_24; else goto z_bb_23;
    z_bb_16:
    if ((unsigned char)(local_len == (unsigned int)(64))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_41 = 0;
    fi = zT_41;
    goto z_bb_19;
    z_bb_18:
    zT_56 = &self->child_buf_items;
    zT_57 = &self->child_buf_len;
    zT_58 = &self->child_buf_capacity;
    zT_59 = self->allocator;
    zT_60 = stmt;
    zF_8B163A32_u32ArrayListAppendI(zT_56, zT_57, zT_58, zT_59, zT_60);
    goto z_bb_15;
    z_bb_19:
    if ((unsigned char)(fi < (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_44 = &self->child_buf_items;
    zT_45 = &self->child_buf_len;
    zT_46 = &self->child_buf_capacity;
    zT_47 = self->allocator;
    zT_48 = local_buf[fi];
    zF_8B163A32_u32ArrayListAppendI(zT_44, zT_45, zT_46, zT_47, zT_48);
    goto z_bb_22;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_55 = fi + (unsigned int)(1);
    fi = zT_55;
    goto z_bb_19;
    z_bb_23:
    zT_102 = pk.kind;
    zT_101 = zT_102 == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof);
    goto z_bb_25;
    z_bb_24:
    zT_101 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_101) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_107 = "PBX:L";
    zT_109 = 5;
    zT_108.ptr = zT_107;
    zT_108.len = zT_109;
    pbx_lm = zT_108;
    zT_110 = pbx_lm;
    zF_C914CB83_markerWriteInt(zT_110, (unsigned int)((unsigned int)local_len));
    zT_114 = "PBX:B";
    zT_116 = 5;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    pbx_bm = zT_115;
    zT_117 = pbx_bm;
    zF_C914CB83_markerWriteInt(zT_117, (unsigned int)((unsigned int)saved_len));
    zT_121 = "PBX:P";
    zT_123 = 5;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    pbx_pm = zT_122;
    zT_124 = pbx_pm;
    zT_125 = lbrace.span_start;
    zF_C914CB83_markerWriteInt(zT_124, zT_125);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_7;
    z_bb_28:
    zT_134 = zT_132.data.err;
    zT_135.data.err = zT_134;
    zT_135.is_error = 1;
    return zT_135;
    z_bb_29:
    zT_136 = zT_132.data.payload;
    goto z_bb_30;
    z_bb_30:
    rbrace = zT_136;
    zT_138 = 0;
    zT_139 = (unsigned int)zT_138;
    payload = zT_139;
    if ((unsigned char)(local_len > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    slice = zT_143;
    if ((unsigned char)(local_len <= (unsigned int)(64))) goto z_bb_33; else goto z_bb_35;
    z_bb_32:
    self->child_buf_len = saved_len;
    zT_162 = "PLEN:l";
    zT_164 = 6;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    plen_m = zT_163;
    zT_165 = plen_m;
    zF_48AC7B3A_markerWrite(zT_165);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_167[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        plen_lb[_i] = zT_167[_i];
        _i++;
    }
}
    zT_174 = 0;
    zT_175 = (unsigned char*)((unsigned char*)plen_lb) + zT_174;
    zT_176 = (unsigned int)(10) - zT_174;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_170 = zT_177;
    zT_178 = zF_A7504564_itoa((unsigned int)((unsigned int)local_len), zT_170);
    plen_ll = zT_178;
    zT_182 = (unsigned int)(9) - (unsigned int)((unsigned int)plen_ll);
    plen_ls = zT_182;
    zT_187 = (unsigned char*)((unsigned char*)plen_lb) + plen_ls;
    zT_188 = (unsigned int)(9) - plen_ls;
    zT_189.ptr = zT_187;
    zT_189.len = zT_188;
    zT_183 = zT_189;
    zF_48AC7B3A_markerWrite(zT_183);
    zT_191 = "p";
    zT_193 = 1;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    plen_pm = zT_192;
    zT_194 = plen_pm;
    zF_48AC7B3A_markerWrite(zT_194);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_196[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        plen_pb[_i] = zT_196[_i];
        _i++;
    }
}
    zT_198 = payload;
    zT_202 = 0;
    zT_203 = (unsigned char*)((unsigned char*)plen_pb) + zT_202;
    zT_204 = (unsigned int)(10) - zT_202;
    zT_205.ptr = zT_203;
    zT_205.len = zT_204;
    zT_199 = zT_205;
    zT_206 = zF_A7504564_itoa(zT_198, zT_199);
    plen_pl = zT_206;
    zT_210 = (unsigned int)(9) - (unsigned int)((unsigned int)plen_pl);
    plen_ps = zT_210;
    zT_215 = (unsigned char*)((unsigned char*)plen_pb) + plen_ps;
    zT_216 = (unsigned int)(9) - plen_ps;
    zT_217.ptr = zT_215;
    zT_217.len = zT_216;
    zT_211 = zT_217;
    zF_48AC7B3A_markerWrite(zT_211);
    zT_219 = "\n";
    zT_221 = 1;
    zT_220.ptr = zT_219;
    zT_220.len = zT_221;
    plen_nl = zT_220;
    zT_222 = plen_nl;
    zF_48AC7B3A_markerWrite(zT_222);
    zT_223 = self->store;
    zT_235 = 0;
    zT_226 = lbrace.span_start;
    zT_238 = rbrace.span_start;
    zT_239 = rbrace.span_len;
    zT_242 = 0;
    zT_244 = 0;
    zT_246 = 0;
    zT_231 = payload;
    zT_248 = zF_6C9FF72F_astStoreAddNode(zT_223, (zT_8143F551_AstKind)(zT_8143F551_AstKind_block), (unsigned char)((unsigned char)zT_235), zT_226, (unsigned int)(zT_238 + (unsigned int)((unsigned int)zT_239)), (unsigned int)((unsigned int)zT_242), (unsigned int)((unsigned int)zT_244), (unsigned int)((unsigned int)zT_246), zT_231);
    zT_249.data.payload = zT_248;
    zT_249.is_error = 0;
    return zT_249;
    z_bb_33:
    zT_148 = 0;
    zT_149 = (unsigned int*)((unsigned int*)local_buf) + zT_148;
    zT_150 = local_len - zT_148;
    zT_151.ptr = zT_149;
    zT_151.len = zT_150;
    slice = zT_151;
    goto z_bb_34;
    z_bb_34:
    zT_157 = self->store;
    zT_158 = slice;
    zT_160 = zF_583E993C_astStoreAddExtraChi(zT_157, zT_158);
    payload = zT_160;
    goto z_bb_32;
    z_bb_35:
    zT_152 = self->child_buf_items;
    zT_154 = zT_152 + saved_len;
    zT_155 = (unsigned int)(saved_len + local_len) - saved_len;
    zT_156.ptr = zT_154;
    zT_156.len = zT_155;
    slice = zT_156;
    goto z_bb_34;
}

/* precToInt */
unsigned char zF_F312BDA3_precToInt(zT_2B10107F_Prec p) {
    return (unsigned char)((unsigned char)p);
}

/* precFromInt */
zT_2B10107F_Prec zF_860100DC_precFromInt(unsigned char v) {
    return (zT_2B10107F_Prec)((zT_2B10107F_Prec)v);
}

/* getInfixInfo */
zT_ADDA7CFF_Opt_97 zF_1E2936C3_getInfixInfo(zT_EAC3E484_TokenKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    unsigned char zT_28;
    unsigned char zT_32;
    unsigned char zT_36;
    unsigned char zT_40;
    unsigned char zT_44;
    unsigned char zT_48;
    unsigned char zT_52;
    unsigned char zT_56;
    unsigned char zT_60;
    unsigned char zT_64;
    unsigned char zT_68;
    zT_F4EBEA72_OpInfo zT_72;
    zT_2B10107F_Prec zT_73;
    unsigned char zT_74;
    zT_ADDA7CFF_Opt_97 zT_75;
    zT_F4EBEA72_OpInfo zT_79;
    zT_2B10107F_Prec zT_80;
    unsigned char zT_81;
    zT_ADDA7CFF_Opt_97 zT_82;
    zT_F4EBEA72_OpInfo zT_86;
    zT_2B10107F_Prec zT_87;
    unsigned char zT_88;
    zT_ADDA7CFF_Opt_97 zT_89;
    zT_F4EBEA72_OpInfo zT_93;
    zT_2B10107F_Prec zT_94;
    unsigned char zT_95;
    zT_ADDA7CFF_Opt_97 zT_96;
    zT_F4EBEA72_OpInfo zT_100;
    zT_2B10107F_Prec zT_101;
    unsigned char zT_102;
    zT_ADDA7CFF_Opt_97 zT_103;
    unsigned char zT_107;
    unsigned char zT_111;
    unsigned char zT_115;
    unsigned char zT_119;
    unsigned char zT_123;
    zT_F4EBEA72_OpInfo zT_127;
    zT_2B10107F_Prec zT_128;
    unsigned char zT_129;
    zT_ADDA7CFF_Opt_97 zT_130;
    zT_F4EBEA72_OpInfo zT_134;
    zT_2B10107F_Prec zT_135;
    unsigned char zT_136;
    zT_ADDA7CFF_Opt_97 zT_137;
    zT_F4EBEA72_OpInfo zT_141;
    zT_2B10107F_Prec zT_142;
    unsigned char zT_143;
    zT_ADDA7CFF_Opt_97 zT_144;
    zT_F4EBEA72_OpInfo zT_148;
    zT_2B10107F_Prec zT_149;
    unsigned char zT_150;
    zT_ADDA7CFF_Opt_97 zT_151;
    unsigned char zT_155;
    unsigned char zT_159;
    zT_F4EBEA72_OpInfo zT_163;
    zT_2B10107F_Prec zT_164;
    unsigned char zT_165;
    zT_ADDA7CFF_Opt_97 zT_166;
    unsigned char zT_170;
    unsigned char zT_174;
    unsigned char zT_178;
    unsigned char zT_182;
    unsigned char zT_186;
    zT_F4EBEA72_OpInfo zT_190;
    zT_2B10107F_Prec zT_191;
    unsigned char zT_192;
    zT_ADDA7CFF_Opt_97 zT_193;
    unsigned char zT_197;
    unsigned char zT_201;
    unsigned char zT_205;
    unsigned char zT_209;
    zT_F4EBEA72_OpInfo zT_213;
    zT_2B10107F_Prec zT_214;
    unsigned char zT_215;
    zT_ADDA7CFF_Opt_97 zT_216;
    zT_ADDA7CFF_Opt_97 zT_217 = {0};
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_24) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_28 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq);
    goto z_bb_21;
    z_bb_20:
    zT_28 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_28) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_32 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq);
    goto z_bb_24;
    z_bb_23:
    zT_32 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_32) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_36 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq);
    goto z_bb_27;
    z_bb_26:
    zT_36 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_36) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_40 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq);
    goto z_bb_30;
    z_bb_29:
    zT_40 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_40) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_44 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq);
    goto z_bb_33;
    z_bb_32:
    zT_44 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_44) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_48 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq);
    goto z_bb_36;
    z_bb_35:
    zT_48 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_48) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_52 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq);
    goto z_bb_39;
    z_bb_38:
    zT_52 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_52) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_56 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq);
    goto z_bb_42;
    z_bb_41:
    zT_56 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_56) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_60 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq);
    goto z_bb_45;
    z_bb_44:
    zT_60 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_60) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_64 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq);
    goto z_bb_48;
    z_bb_47:
    zT_64 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_64) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_68 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq);
    goto z_bb_51;
    z_bb_50:
    zT_68 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_68) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_73 = zT_2B10107F_Prec_assignment;
    zT_72.prec = zT_73;
    zT_74 = 1;
    zT_72.right_assoc = zT_74;
    zT_75.has_value = 1;
    zT_75.value = zT_72;
    return zT_75;
    z_bb_53:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_orelse))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_80 = zT_2B10107F_Prec_prec_orelse;
    zT_79.prec = zT_80;
    zT_81 = 1;
    zT_79.right_assoc = zT_81;
    zT_82.has_value = 1;
    zT_82.value = zT_79;
    return zT_82;
    z_bb_55:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_catch))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_87 = zT_2B10107F_Prec_prec_catch;
    zT_86.prec = zT_87;
    zT_88 = 1;
    zT_86.right_assoc = zT_88;
    zT_89.has_value = 1;
    zT_89.value = zT_86;
    return zT_89;
    z_bb_57:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_or))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_94 = zT_2B10107F_Prec_bool_or;
    zT_93.prec = zT_94;
    zT_95 = 0;
    zT_93.right_assoc = zT_95;
    zT_96.has_value = 1;
    zT_96.value = zT_93;
    return zT_96;
    z_bb_59:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_and))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_101 = zT_2B10107F_Prec_bool_and;
    zT_100.prec = zT_101;
    zT_102 = 0;
    zT_100.right_assoc = zT_102;
    zT_103.has_value = 1;
    zT_103.value = zT_100;
    return zT_103;
    z_bb_61:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq))) goto z_bb_63; else goto z_bb_62;
    z_bb_62:
    zT_107 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq);
    goto z_bb_64;
    z_bb_63:
    zT_107 = 1;
    goto z_bb_64;
    z_bb_64:
    if (zT_107) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_111 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less);
    goto z_bb_67;
    z_bb_66:
    zT_111 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_111) goto z_bb_69; else goto z_bb_68;
    z_bb_68:
    zT_115 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq);
    goto z_bb_70;
    z_bb_69:
    zT_115 = 1;
    goto z_bb_70;
    z_bb_70:
    if (zT_115) goto z_bb_72; else goto z_bb_71;
    z_bb_71:
    zT_119 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater);
    goto z_bb_73;
    z_bb_72:
    zT_119 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_119) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_123 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq);
    goto z_bb_76;
    z_bb_75:
    zT_123 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_123) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_128 = zT_2B10107F_Prec_comparison;
    zT_127.prec = zT_128;
    zT_129 = 0;
    zT_127.right_assoc = zT_129;
    zT_130.has_value = 1;
    zT_130.value = zT_127;
    return zT_130;
    z_bb_78:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_135 = zT_2B10107F_Prec_bit_or;
    zT_134.prec = zT_135;
    zT_136 = 0;
    zT_134.right_assoc = zT_136;
    zT_137.has_value = 1;
    zT_137.value = zT_134;
    return zT_137;
    z_bb_80:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_142 = zT_2B10107F_Prec_bit_xor;
    zT_141.prec = zT_142;
    zT_143 = 0;
    zT_141.right_assoc = zT_143;
    zT_144.has_value = 1;
    zT_144.value = zT_141;
    return zT_144;
    z_bb_82:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_149 = zT_2B10107F_Prec_bit_and;
    zT_148.prec = zT_149;
    zT_150 = 0;
    zT_148.right_assoc = zT_150;
    zT_151.has_value = 1;
    zT_151.value = zT_148;
    return zT_151;
    z_bb_84:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_155 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr);
    goto z_bb_87;
    z_bb_86:
    zT_155 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_155) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_159 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe);
    goto z_bb_90;
    z_bb_89:
    zT_159 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_159) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_164 = zT_2B10107F_Prec_shift;
    zT_163.prec = zT_164;
    zT_165 = 0;
    zT_163.right_assoc = zT_165;
    zT_166.has_value = 1;
    zT_166.value = zT_163;
    return zT_166;
    z_bb_92:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus))) goto z_bb_94; else goto z_bb_93;
    z_bb_93:
    zT_170 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus);
    goto z_bb_95;
    z_bb_94:
    zT_170 = 1;
    goto z_bb_95;
    z_bb_95:
    if (zT_170) goto z_bb_97; else goto z_bb_96;
    z_bb_96:
    zT_174 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct);
    goto z_bb_98;
    z_bb_97:
    zT_174 = 1;
    goto z_bb_98;
    z_bb_98:
    if (zT_174) goto z_bb_100; else goto z_bb_99;
    z_bb_99:
    zT_178 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct);
    goto z_bb_101;
    z_bb_100:
    zT_178 = 1;
    goto z_bb_101;
    z_bb_101:
    if (zT_178) goto z_bb_103; else goto z_bb_102;
    z_bb_102:
    zT_182 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe);
    goto z_bb_104;
    z_bb_103:
    zT_182 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_182) goto z_bb_106; else goto z_bb_105;
    z_bb_105:
    zT_186 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe);
    goto z_bb_107;
    z_bb_106:
    zT_186 = 1;
    goto z_bb_107;
    z_bb_107:
    if (zT_186) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_191 = zT_2B10107F_Prec_additive;
    zT_190.prec = zT_191;
    zT_192 = 0;
    zT_190.right_assoc = zT_192;
    zT_193.has_value = 1;
    zT_193.value = zT_190;
    return zT_193;
    z_bb_109:
    if ((unsigned char)(kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star))) goto z_bb_111; else goto z_bb_110;
    z_bb_110:
    zT_197 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash);
    goto z_bb_112;
    z_bb_111:
    zT_197 = 1;
    goto z_bb_112;
    z_bb_112:
    if (zT_197) goto z_bb_114; else goto z_bb_113;
    z_bb_113:
    zT_201 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent);
    goto z_bb_115;
    z_bb_114:
    zT_201 = 1;
    goto z_bb_115;
    z_bb_115:
    if (zT_201) goto z_bb_117; else goto z_bb_116;
    z_bb_116:
    zT_205 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct);
    goto z_bb_118;
    z_bb_117:
    zT_205 = 1;
    goto z_bb_118;
    z_bb_118:
    if (zT_205) goto z_bb_120; else goto z_bb_119;
    z_bb_119:
    zT_209 = kind == (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe);
    goto z_bb_121;
    z_bb_120:
    zT_209 = 1;
    goto z_bb_121;
    z_bb_121:
    if (zT_209) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_214 = zT_2B10107F_Prec_multiply;
    zT_213.prec = zT_214;
    zT_215 = 0;
    zT_213.right_assoc = zT_215;
    zT_216.has_value = 1;
    zT_216.value = zT_213;
    return zT_216;
    z_bb_123:
    zT_217.has_value = 0;
    return zT_217;
}

/* __module_init */
void zF_780653D2___module_init_7(void) {
    zT_F85C5DED_DiagnosticCollector zT_0 = {0};
    zT_072B53A6_ModuleRegistry zT_1 = {0};
    zG_F85C5DED_DiagnosticCollector = zT_0;
    zG_072B53A6_ModuleRegistry = zT_1;
    return;
}

/* EOF */
