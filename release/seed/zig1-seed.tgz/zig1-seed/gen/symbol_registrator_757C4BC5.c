#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zT_5 = 0;
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_6A32A83C_Opt_238 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_0715C9B9_EU_832 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6A32A83C_Opt_238 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->cap;
    zT_14 = 0;
    if ((unsigned char)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->items;
    zT_25 = self->cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->items;
    zT_48 = self->len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    self->len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_9;
    zT_0715C9B9_EU_832 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_52CDA6EF_DepEdge* zT_35;
    zT_52CDA6EF_DepEdge zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    zT_52CDA6EF_DepEdge* zT_43;
    zT_52CDA6EF_DepEdge zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_5 = (unsigned int)(unsigned int)(max_type_id + (unsigned int)(1));
    count = zT_5;
    zT_6 = self->in_degree_cap;
    if ((unsigned char)(count > zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_9, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_6;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    zT_26 = self->in_degree_items;
    zT_26[i] = zT_25;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_32 = self->len;
    if ((unsigned char)(i < zT_32)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self->in_degree_items;
    zT_35 = self->items;
    zT_36 = zT_35[i];
    zT_37 = zT_36.to;
    zT_38 = zT_34[zT_37];
    zT_39 = 1;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    zT_42 = self->in_degree_items;
    zT_43 = self->items;
    zT_44 = zT_43[i];
    zT_45 = zT_44.to;
    zT_42[zT_45] = zT_41;
    zT_46 = 1;
    zT_48 = i + (unsigned int)((unsigned int)zT_46);
    i = zT_48;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_28 = 0;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_4D61441E_DepGraph* zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_40;
    unsigned int children_n;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_14, zT_15);
    children_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < children_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = store;
    zT_24 = store;
    zT_25 = decl_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_24, zT_25, (unsigned int)((unsigned int)i));
    zT_23 = zT_28;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    field_node = zT_29;
    zT_30 = field_node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_34 = g;
    zT_36 = tid;
    zF_AA751A34_depGraphAddEdge(zT_34, (unsigned int)(0), zT_36);
    goto z_bb_8;
    z_bb_8:
    zT_38 = 1;
    zT_40 = i + (unsigned int)((unsigned int)zT_38);
    i = zT_40;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    int zT_18;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_40 = 0;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    zT_338B7C76_TypeRegistry* zT_46;
    zT_2DF01B61_FieldEntry zT_47;
    zT_2DF01B61_FieldEntry zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    unsigned int zT_55 = 0;
    unsigned int zT_56 = 0;
    unsigned int zT_57;
    unsigned int zT_58;
    int zT_59;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    int zT_65;
    zT_338B7C76_TypeRegistry* zT_67;
    zT_406493CE_StructPayload zT_68;
    zT_406493CE_StructPayload zT_69;
    unsigned int zT_70;
    unsigned short zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_D155D06D_Type* zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    zT_D155D06D_Type zT_84;
    zT_D155D06D_Type* zT_85;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_94;
    unsigned int zT_95;
    int zT_97;
    unsigned int zT_98;
    int zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    unsigned int zT_110 = 0;
    zT_22A7C88B_AstNode zT_111 = {0};
    zT_8143F551_AstKind zT_112;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_2DF01B61_FieldEntry zT_117;
    zT_2DF01B61_FieldEntry zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_125 = 0;
    unsigned int zT_126 = 0;
    unsigned int zT_127;
    unsigned int zT_128;
    int zT_129;
    unsigned int zT_131;
    int zT_132;
    unsigned int zT_134;
    unsigned char zT_135;
    int zT_137;
    int zT_139;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_54FF90FA_TaggedUnionPayload zT_142;
    zT_54FF90FA_TaggedUnionPayload zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned short zT_146;
    unsigned int zT_148;
    unsigned int zT_150;
    unsigned int zT_152;
    zT_D155D06D_Type* zT_154;
    unsigned int zT_155;
    unsigned int zT_158;
    zT_D155D06D_Type zT_159;
    zT_D155D06D_Type* zT_160;
    unsigned int zT_161;
    unsigned int zT_164;
    zT_338B7C76_TypeRegistry* zT_165;
    zT_AF9231A2_UnionPayload zT_166;
    zT_AF9231A2_UnionPayload zT_167;
    unsigned int zT_168;
    unsigned short zT_169;
    unsigned int zT_170;
    unsigned int zT_172;
    unsigned int zT_174;
    unsigned int zT_176;
    zT_D155D06D_Type* zT_178;
    unsigned int zT_179;
    unsigned int zT_182;
    zT_D155D06D_Type zT_183;
    zT_D155D06D_Type* zT_184;
    unsigned int zT_185;
    unsigned int zT_188;
    zT_ABC1EBBE_TypeResolveEnv zT_193;
    zT_D3EB6303_StringInterner* zT_194;
    unsigned int zT_196;
    zT_7034F045_Opt_228 zT_197 = {0};
    zT_03B97CED_Opt_398 zT_198 = {0};
    zT_05CE5599_Opt_400 zT_199 = {0};
    zT_939EE900_Arr_unsigned_int_1 zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    int zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    int zT_209;
    zT_ABC1EBBE_TypeResolveEnv* zT_212;
    unsigned int zT_213;
    unsigned int zT_218 = 0;
    unsigned char zT_221;
    int zT_224;
    unsigned char zT_225;
    unsigned int zT_227;
    unsigned int zT_228;
    int zT_230;
    unsigned int zT_231;
    int zT_233;
    unsigned int zT_234;
    int zT_236;
    unsigned int zT_237;
    zT_ABC1EBBE_TypeResolveEnv* zT_238;
    unsigned int zT_239;
    unsigned int* zT_244;
    unsigned int* zT_245;
    unsigned int* zT_246;
    unsigned char zT_255 = 0;
    zT_338B7C76_TypeRegistry* zT_256;
    zT_457ECFEE_EnumPayload zT_257;
    zT_457ECFEE_EnumPayload zT_258;
    unsigned int zT_259;
    unsigned short zT_260;
    int zT_261;
    unsigned int zT_262;
    unsigned int zT_264;
    unsigned int zT_266;
    unsigned int zT_268;
    zT_D155D06D_Type* zT_270;
    unsigned int zT_271;
    unsigned int zT_274;
    zT_D155D06D_Type zT_275;
    zT_D155D06D_Type* zT_276;
    unsigned int zT_277;
    unsigned int zT_280;
    unsigned int zT_285;
    unsigned int zT_286;
    int zT_288;
    unsigned int zT_289;
    zT_338B7C76_TypeRegistry* zT_291;
    unsigned int zT_292;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_294;
    unsigned int zT_297 = 0;
    int zT_298;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_0B73C507_ErrorSetPayload zT_302;
    zT_0B73C507_ErrorSetPayload zT_303;
    unsigned short zT_304;
    unsigned int zT_306;
    unsigned int zT_308;
    unsigned int zT_310;
    zT_D155D06D_Type* zT_312;
    unsigned int zT_313;
    unsigned int zT_316;
    zT_D155D06D_Type zT_317;
    zT_D155D06D_Type* zT_318;
    unsigned int zT_319;
    unsigned int zT_322;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    unsigned int fail_node;
    unsigned int fail_kind;
    unsigned int en_last;
    unsigned int en_idx;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_6 = store;
    zT_7 = decl_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    if ((unsigned char)(zT_11 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_15 = store;
    zT_16 = decl_idx;
    zT_17 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    children_n = zT_17;
    zT_18 = 0;
    if ((unsigned char)(children_n == (unsigned int)zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_24 = type_reg->fe_len;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_7;
    z_bb_6:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_7:
    if ((unsigned char)(i < children_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_34 = store;
    zT_36 = store;
    zT_37 = decl_idx;
    zT_40 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)i));
    zT_35 = zT_40;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    fd = zT_41;
    zT_42 = fd.kind;
    if ((unsigned char)(zT_42 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_65 = 0;
    if ((unsigned char)(fcount > (unsigned int)zT_65)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_46 = type_reg;
    zT_49 = store;
    zT_51 = store;
    zT_52 = decl_idx;
    zT_55 = zF_B10B1BC1_astStoreNodeExtraCh(zT_51, zT_52, (unsigned int)((unsigned int)i));
    zT_50 = zT_55;
    zT_56 = zF_8BA26B9E_astStoreNodePayload(zT_49, zT_50);
    zT_48.name_id = zT_56;
    zT_57 = 1;
    zT_48.type_id = zT_57;
    zT_58 = 0;
    zT_48.offset = zT_58;
    zT_47 = zT_48;
    zF_701DF154_feAppend(zT_46, zT_47);
    zT_59 = 1;
    zT_61 = fcount + (unsigned int)((unsigned int)zT_59);
    fcount = zT_61;
    goto z_bb_12;
    z_bb_12:
    zT_62 = 1;
    zT_64 = i + (unsigned int)((unsigned int)zT_62);
    i = zT_64;
    goto z_bb_10;
    z_bb_13:
    zT_67 = type_reg;
    zT_70 = (unsigned int)fstart;
    zT_69.fields_start = zT_70;
    zT_71 = (unsigned short)fcount;
    zT_69.fields_count = zT_71;
    zT_68 = zT_69;
    zF_CF849366_stAppend(zT_67, zT_68);
    goto z_bb_14;
    z_bb_14:
    zT_73 = type_reg->st_len;
    zT_75 = zT_73 - (unsigned int)(1);
    st_last = zT_75;
    zT_77 = (unsigned int)st_last;
    st_idx = zT_77;
    zT_79 = type_reg->types_items;
    zT_80 = type_reg->types_len;
    zT_83 = (unsigned int)(unsigned int)(zT_80 - (unsigned int)(1));
    zT_84 = zT_79[zT_83];
    ty = zT_84;
    ty.payload_idx = st_idx;
    zT_85 = type_reg->types_items;
    zT_86 = type_reg->types_len;
    zT_89 = (unsigned int)(unsigned int)(zT_86 - (unsigned int)(1));
    zT_85[zT_89] = ty;
    goto z_bb_6;
    z_bb_15:
    zT_94 = type_reg->fe_len;
    zT_95 = (unsigned int)zT_94;
    fstart = zT_95;
    zT_97 = 0;
    zT_98 = (unsigned int)zT_97;
    fcount = zT_98;
    zT_100 = 0;
    zT_101 = (unsigned int)zT_100;
    i = zT_101;
    goto z_bb_17;
    z_bb_16:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_26; else goto z_bb_27;
    z_bb_17:
    if ((unsigned char)(i < children_n)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_104 = store;
    zT_106 = store;
    zT_107 = decl_idx;
    zT_110 = zF_B10B1BC1_astStoreNodeExtraCh(zT_106, zT_107, (unsigned int)((unsigned int)i));
    zT_105 = zT_110;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_104, zT_105);
    fd = zT_111;
    zT_112 = fd.kind;
    if ((unsigned char)(zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_135 = node.flags;
    zT_137 = 1;
    zT_139 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_135) & zT_137) != zT_139)) goto z_bb_23; else goto z_bb_25;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_116 = type_reg;
    zT_119 = store;
    zT_121 = store;
    zT_122 = decl_idx;
    zT_125 = zF_B10B1BC1_astStoreNodeExtraCh(zT_121, zT_122, (unsigned int)((unsigned int)i));
    zT_120 = zT_125;
    zT_126 = zF_8BA26B9E_astStoreNodePayload(zT_119, zT_120);
    zT_118.name_id = zT_126;
    zT_127 = 1;
    zT_118.type_id = zT_127;
    zT_128 = 0;
    zT_118.offset = zT_128;
    zT_117 = zT_118;
    zF_701DF154_feAppend(zT_116, zT_117);
    zT_129 = 1;
    zT_131 = fcount + (unsigned int)((unsigned int)zT_129);
    fcount = zT_131;
    goto z_bb_22;
    z_bb_22:
    zT_132 = 1;
    zT_134 = i + (unsigned int)((unsigned int)zT_132);
    i = zT_134;
    goto z_bb_20;
    z_bb_23:
    zT_141 = type_reg;
    zT_144 = 10;
    zT_143.tag_type = zT_144;
    zT_145 = (unsigned int)fstart;
    zT_143.fields_start = zT_145;
    zT_146 = (unsigned short)fcount;
    zT_143.fields_count = zT_146;
    zT_142 = zT_143;
    zF_FB6B57C6_tuAppend(zT_141, zT_142);
    zT_148 = type_reg->tu_len;
    zT_150 = zT_148 - (unsigned int)(1);
    tu_last = zT_150;
    zT_152 = (unsigned int)tu_last;
    tu_idx = zT_152;
    zT_154 = type_reg->types_items;
    zT_155 = type_reg->types_len;
    zT_158 = (unsigned int)(unsigned int)(zT_155 - (unsigned int)(1));
    zT_159 = zT_154[zT_158];
    ty = zT_159;
    ty.payload_idx = tu_idx;
    zT_160 = type_reg->types_items;
    zT_161 = type_reg->types_len;
    zT_164 = (unsigned int)(unsigned int)(zT_161 - (unsigned int)(1));
    zT_160[zT_164] = ty;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_16;
    z_bb_25:
    zT_165 = type_reg;
    zT_168 = (unsigned int)fstart;
    zT_167.fields_start = zT_168;
    zT_169 = (unsigned short)fcount;
    zT_167.fields_count = zT_169;
    zT_170 = 1;
    zT_167.tag_type = zT_170;
    zT_166 = zT_167;
    zF_1718422E_unAppend(zT_165, zT_166);
    zT_172 = type_reg->un_len;
    zT_174 = zT_172 - (unsigned int)(1);
    un_last = zT_174;
    zT_176 = (unsigned int)un_last;
    un_idx = zT_176;
    zT_178 = type_reg->types_items;
    zT_179 = type_reg->types_len;
    zT_182 = (unsigned int)(unsigned int)(zT_179 - (unsigned int)(1));
    zT_183 = zT_178[zT_182];
    ty = zT_183;
    ty.payload_idx = un_idx;
    zT_184 = type_reg->types_items;
    zT_185 = type_reg->types_len;
    zT_188 = (unsigned int)(unsigned int)(zT_185 - (unsigned int)(1));
    zT_184[zT_188] = ty;
    goto z_bb_24;
    z_bb_26:
    zT_193.store = store;
    zT_193.typereg = type_reg;
    zT_193.symbol_reg = sym_reg;
    zT_194 = type_reg->interner;
    zT_193.interner = zT_194;
    zT_193.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_196 = 0;
    zT_193.source_file_id = zT_196;
    zT_197.has_value = 0;
    zT_193.diag = zT_197;
    zT_198.has_value = 0;
    zT_193.local_consts = zT_198;
    zT_199.has_value = 0;
    zT_193.local_types = zT_199;
    tre_env = zT_193;
    zT_202 = 0;
    zT_203 = 0;
    zT_201[zT_203] = zT_202;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_201[_i];
        _i++;
    }
}
    zT_204 = 10;
    zT_205 = 0;
    backing_box[zT_205] = zT_204;
    zT_207 = 0;
    expl_flag = zT_207;
    zT_208 = node.child_0;
    zT_209 = 0;
    if ((unsigned char)(zT_208 != (unsigned int)zT_209)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_28:
    zT_212 = &tre_env;
    zT_213 = node.child_0;
    zT_218 = zF_F2107C15_resolveTypeExprFull(zT_212, zT_213, (unsigned int)(0));
    bt = zT_218;
    if ((unsigned char)(bt != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_227 = type_reg->em_len;
    zT_228 = (unsigned int)zT_227;
    mstart = zT_228;
    zT_230 = 0;
    zT_231 = (unsigned int)zT_230;
    mcount = zT_231;
    zT_233 = 0;
    zT_234 = (unsigned int)zT_233;
    fail_node = zT_234;
    zT_236 = 0;
    zT_237 = (unsigned int)zT_236;
    fail_kind = zT_237;
    zT_238 = &tre_env;
    zT_239 = decl_idx;
    zT_244 = &mcount;
    zT_245 = &fail_node;
    zT_246 = &fail_kind;
    zT_255 = zF_0FFDEDBD_enumMembersResolve(zT_238, zT_239, (unsigned char)(1), (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), zT_244, zT_245, zT_246);
    (void)zT_255;
    zT_256 = type_reg;
    zT_259 = (unsigned int)mstart;
    zT_258.members_start = zT_259;
    zT_260 = (unsigned short)mcount;
    zT_258.members_count = zT_260;
    zT_261 = 0;
    zT_262 = backing_box[zT_261];
    zT_258.backing_type = zT_262;
    zT_258.explicit_backing = expl_flag;
    zT_257 = zT_258;
    zF_298371DE_enAppend(zT_256, zT_257);
    zT_264 = type_reg->en_len;
    zT_266 = zT_264 - (unsigned int)(1);
    en_last = zT_266;
    zT_268 = (unsigned int)en_last;
    en_idx = zT_268;
    zT_270 = type_reg->types_items;
    zT_271 = type_reg->types_len;
    zT_274 = (unsigned int)(unsigned int)(zT_271 - (unsigned int)(1));
    zT_275 = zT_270[zT_274];
    ty = zT_275;
    ty.payload_idx = en_idx;
    zT_276 = type_reg->types_items;
    zT_277 = type_reg->types_len;
    zT_280 = (unsigned int)(unsigned int)(zT_277 - (unsigned int)(1));
    zT_276[zT_280] = ty;
    goto z_bb_27;
    z_bb_30:
    zT_221 = bt != (unsigned int)(1);
    goto z_bb_32;
    z_bb_31:
    zT_221 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_221) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_224 = 0;
    backing_box[zT_224] = bt;
    goto z_bb_34;
    z_bb_34:
    zT_225 = 1;
    expl_flag = zT_225;
    goto z_bb_29;
    z_bb_35:
    zT_285 = type_reg->xn_len;
    zT_286 = (unsigned int)zT_285;
    tags_start_idx = zT_286;
    zT_288 = 0;
    zT_289 = (unsigned int)zT_288;
    i = zT_289;
    goto z_bb_37;
    z_bb_36:
    return;
    z_bb_37:
    if ((unsigned char)(i < children_n)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_291 = type_reg;
    zT_293 = store;
    zT_294 = decl_idx;
    zT_297 = zF_B10B1BC1_astStoreNodeExtraCh(zT_293, zT_294, (unsigned int)((unsigned int)i));
    zT_292 = zT_297;
    zF_A648B1CB_xnAppend(zT_291, zT_292);
    goto z_bb_40;
    z_bb_39:
    zT_301 = type_reg;
    zT_303.tags_start = tags_start_idx;
    zT_304 = (unsigned short)children_n;
    zT_303.tags_count = zT_304;
    zT_302 = zT_303;
    zF_B86143DD_esAppend(zT_301, zT_302);
    zT_306 = type_reg->es_len;
    zT_308 = zT_306 - (unsigned int)(1);
    es_last = zT_308;
    zT_310 = (unsigned int)es_last;
    es_idx = zT_310;
    zT_312 = type_reg->types_items;
    zT_313 = type_reg->types_len;
    zT_316 = (unsigned int)(unsigned int)(zT_313 - (unsigned int)(1));
    zT_317 = zT_312[zT_316];
    ty = zT_317;
    ty.payload_idx = es_idx;
    zT_318 = type_reg->types_items;
    zT_319 = type_reg->types_len;
    zT_322 = (unsigned int)(unsigned int)(zT_319 - (unsigned int)(1));
    zT_318[zT_322] = ty;
    goto z_bb_36;
    z_bb_40:
    zT_298 = 1;
    zT_300 = i + (unsigned int)((unsigned int)zT_298);
    i = zT_300;
    goto z_bb_37;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, unsigned char populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_3C598AEF_SymbolKind zT_57;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    zT_072B53A6_ModuleRegistry* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_79 = 0;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101 = 0;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned char zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_3C598AEF_SymbolKind zT_121;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_128;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    int zT_134;
    unsigned char* zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138 = 0;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_156;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    int zT_162;
    unsigned char* zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166 = 0;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_184;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    int zT_190;
    unsigned char* zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194 = 0;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208 = 0;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    zT_8143F551_AstKind zT_214;
    unsigned char zT_218;
    zT_8143F551_AstKind zT_219;
    unsigned char zT_223;
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    zT_8143F551_AstKind zT_229;
    zT_8143F551_AstKind zT_234;
    zT_33EF6BFB_TypeKind zT_235;
    unsigned char zT_240;
    int zT_244;
    zT_33EF6BFB_TypeKind zT_246;
    unsigned char zT_249;
    int zT_251;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_255;
    zT_338B7C76_TypeRegistry* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_33EF6BFB_TypeKind zT_267;
    unsigned int zT_268 = 0;
    zT_8143F551_AstKind zT_269;
    unsigned char zT_273;
    zT_8143F551_AstKind zT_274;
    unsigned char zT_278;
    unsigned char zT_279;
    zT_338B7C76_TypeRegistry* zT_285;
    unsigned int zT_286;
    zT_338B7C76_TypeRegistry* zT_287;
    zT_6B0A7D14_AstStore* zT_288;
    zT_8143F551_AstKind zT_289;
    unsigned int zT_290;
    zT_3D7259E2_SymbolRegistry* zT_291;
    zT_6B0A7D14_AstStore* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_4D61441E_DepGraph* zT_297;
    zT_3C598AEF_SymbolKind zT_300;
    zT_8143F551_AstKind zT_301;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    unsigned int zT_310;
    zT_6B0A7D14_AstStore* zT_311;
    unsigned int zT_312;
    unsigned int zT_314 = 0;
    zT_6B0A7D14_AstStore* zT_316;
    unsigned int zT_317;
    unsigned int zT_319 = 0;
    unsigned char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    zT_338B7C76_TypeRegistry* zT_327;
    zT_BAEE192E_Opt_10 zT_334 = {0};
    unsigned char zT_335;
    zT_338B7C76_TypeRegistry* zT_337;
    zT_BAEE192E_Opt_10 zT_340 = {0};
    unsigned char zT_341;
    unsigned char* zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    unsigned int zT_348;
    zT_79FAE712_u64 zT_354;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_79FAE712_u64 zT_356;
    unsigned int zT_357;
    zT_3C598AEF_SymbolKind zT_359;
    unsigned char zT_361;
    zT_D3EB6303_StringInterner* zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_366 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned char* zT_368;
    unsigned int zT_370 = 0;
    zT_338B7C76_TypeRegistry* zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    unsigned int zT_376 = 0;
    zT_79FAE712_u64 zT_384;
    zT_338B7C76_TypeRegistry* zT_385;
    zT_79FAE712_u64 zT_386;
    unsigned int zT_387;
    zT_3C598AEF_SymbolKind zT_389;
    zT_8143F551_AstKind zT_390;
    unsigned char zT_394;
    zT_8143F551_AstKind zT_395;
    unsigned char zT_399;
    zT_8143F551_AstKind zT_400;
    unsigned char zT_404;
    zT_8143F551_AstKind zT_405;
    unsigned char zT_409;
    zT_8143F551_AstKind zT_410;
    unsigned char zT_414;
    zT_8143F551_AstKind zT_415;
    unsigned char zT_419;
    zT_8143F551_AstKind zT_420;
    unsigned char* zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    unsigned int zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428;
    unsigned int zT_429;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_BAEE192E_Opt_10 zT_438 = {0};
    unsigned char zT_439;
    zT_338B7C76_TypeRegistry* zT_441;
    zT_BAEE192E_Opt_10 zT_444 = {0};
    unsigned char zT_445;
    zT_3C598AEF_SymbolKind zT_448;
    zT_3A105EF1_Symbol zT_450;
    unsigned char zT_451;
    unsigned short zT_452;
    unsigned int zT_453;
    zT_3D7259E2_SymbolRegistry* zT_455;
    unsigned int zT_456;
    zT_060CD1EB_SymbolTable* zT_457 = 0;
    zT_060CD1EB_SymbolTable* zT_459;
    zT_3A105EF1_Symbol zT_460;
    unsigned char zT_461 = 0;
    unsigned char* zT_464;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_465;
    unsigned int zT_466;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_467;
    unsigned char* zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    unsigned int zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    zT_4028D896_Arr_unsigned_char_2 zT_474;
    unsigned int zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    int zT_480;
    unsigned char* zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484 = 0;
    unsigned int zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned char* zT_495;
    unsigned int zT_496;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_497;
    unsigned char* zT_499;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_500;
    unsigned int zT_501;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_502;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    int zT_509;
    unsigned char* zT_510;
    unsigned int zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned int zT_513 = 0;
    unsigned int zT_519;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_520;
    unsigned char* zT_524;
    unsigned int zT_525;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_526;
    unsigned char* zT_528;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_529;
    unsigned int zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_531;
    unsigned char* zT_533;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_534;
    unsigned int zT_535;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    zT_ABE81E73_anon_235160 zT_538;
    zT_243D6A41_FnProto* zT_539;
    zT_6B0A7D14_AstStore* zT_540;
    unsigned int zT_541;
    unsigned int zT_542 = 0;
    unsigned int zT_543;
    zT_243D6A41_FnProto zT_544;
    zT_3A105EF1_Symbol zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    zT_3C598AEF_SymbolKind zT_550;
    unsigned char zT_551;
    unsigned short zT_552;
    unsigned int zT_553;
    zT_3D7259E2_SymbolRegistry* zT_555;
    unsigned int zT_556;
    zT_060CD1EB_SymbolTable* zT_557 = 0;
    zT_060CD1EB_SymbolTable* zT_558;
    zT_3A105EF1_Symbol zT_559;
    unsigned char zT_560 = 0;
    zT_6B0A7D14_AstStore* zT_561;
    unsigned int zT_562;
    unsigned int zT_563 = 0;
    zT_3A105EF1_Symbol zT_567;
    zT_6B0A7D14_AstStore* zT_568;
    unsigned int zT_569;
    unsigned int zT_570 = 0;
    unsigned int zT_571;
    zT_3C598AEF_SymbolKind zT_573;
    unsigned char zT_574;
    unsigned short zT_575;
    unsigned int zT_576;
    zT_3D7259E2_SymbolRegistry* zT_578;
    unsigned int zT_579;
    zT_060CD1EB_SymbolTable* zT_580 = 0;
    zT_060CD1EB_SymbolTable* zT_581;
    zT_3A105EF1_Symbol zT_582;
    unsigned char zT_583 = 0;
    zT_6B0A7D14_AstStore* zT_585;
    unsigned int zT_586;
    zT_8143F551_AstKind zT_587;
    zT_79FAE712_u64 zT_589 = 0;
    unsigned int zT_592;
    zT_8143F551_AstKind zT_594;
    zT_33EF6BFB_TypeKind zT_595;
    unsigned char zT_600;
    int zT_604;
    zT_33EF6BFB_TypeKind zT_606;
    unsigned char zT_609;
    int zT_611;
    int zT_613;
    zT_33EF6BFB_TypeKind zT_615;
    zT_338B7C76_TypeRegistry* zT_623;
    unsigned int zT_624;
    unsigned int zT_625;
    zT_33EF6BFB_TypeKind zT_626;
    unsigned int zT_627 = 0;
    zT_8143F551_AstKind zT_628;
    unsigned char zT_632;
    zT_8143F551_AstKind zT_633;
    unsigned char zT_637;
    unsigned char zT_638;
    zT_338B7C76_TypeRegistry* zT_644;
    unsigned int zT_645;
    zT_338B7C76_TypeRegistry* zT_646;
    zT_6B0A7D14_AstStore* zT_647;
    zT_8143F551_AstKind zT_648;
    unsigned int zT_649;
    zT_3D7259E2_SymbolRegistry* zT_650;
    zT_6B0A7D14_AstStore* zT_652;
    unsigned int zT_653;
    unsigned int zT_654;
    zT_4D61441E_DepGraph* zT_655;
    zT_3A105EF1_Symbol zT_657;
    zT_3C598AEF_SymbolKind zT_659;
    unsigned char zT_660;
    unsigned short zT_661;
    unsigned int zT_662;
    zT_3D7259E2_SymbolRegistry* zT_664;
    unsigned int zT_665;
    zT_060CD1EB_SymbolTable* zT_666 = 0;
    zT_060CD1EB_SymbolTable* zT_667;
    zT_3A105EF1_Symbol zT_668;
    unsigned char zT_669 = 0;
    zT_6B0A7D14_AstStore* zT_671;
    unsigned int zT_672;
    zT_8143F551_AstKind zT_673;
    zT_79FAE712_u64 zT_675 = 0;
    unsigned int zT_678;
    zT_338B7C76_TypeRegistry* zT_680;
    unsigned int zT_681;
    unsigned int zT_682;
    unsigned int zT_686 = 0;
    zT_338B7C76_TypeRegistry* zT_687;
    zT_6B0A7D14_AstStore* zT_688;
    zT_8143F551_AstKind zT_689;
    unsigned int zT_690;
    zT_3D7259E2_SymbolRegistry* zT_691;
    zT_3A105EF1_Symbol zT_694;
    zT_3C598AEF_SymbolKind zT_696;
    unsigned char zT_697;
    unsigned short zT_698;
    unsigned int zT_699;
    zT_3D7259E2_SymbolRegistry* zT_701;
    unsigned int zT_702;
    zT_060CD1EB_SymbolTable* zT_703 = 0;
    zT_060CD1EB_SymbolTable* zT_704;
    zT_3A105EF1_Symbol zT_705;
    unsigned char zT_706 = 0;
    zT_6B0A7D14_AstStore* zT_708;
    unsigned int zT_709;
    unsigned int zT_710 = 0;
    zT_072B53A6_ModuleRegistry* zT_712;
    unsigned int zT_713;
    zT_BAEE192E_Opt_10 zT_714 = {0};
    unsigned char zT_715;
    zT_3A105EF1_Symbol zT_718;
    zT_338B7C76_TypeRegistry* zT_719;
    unsigned int zT_720;
    unsigned int zT_721 = 0;
    zT_3C598AEF_SymbolKind zT_723;
    unsigned short zT_724;
    unsigned int zT_725;
    zT_3D7259E2_SymbolRegistry* zT_727;
    unsigned int zT_728;
    zT_060CD1EB_SymbolTable* zT_729 = 0;
    zT_060CD1EB_SymbolTable* zT_730;
    zT_3A105EF1_Symbol zT_731;
    unsigned char zT_732 = 0;
    unsigned char* zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_737;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_739;
    unsigned int zT_741;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_742;
    int zT_745;
    unsigned char* zT_746;
    unsigned int zT_747;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_748;
    unsigned int zT_749 = 0;
    unsigned int zT_753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_754;
    unsigned char* zT_758;
    unsigned int zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_760;
    unsigned char* zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned int zT_764;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_765;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_767;
    unsigned int zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_770;
    int zT_773;
    unsigned char* zT_774;
    unsigned int zT_775;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_776;
    unsigned int zT_777 = 0;
    unsigned int zT_781;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_782;
    unsigned char* zT_786;
    unsigned int zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788;
    unsigned char* zT_790;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    unsigned int zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    unsigned char inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    unsigned char arb_u;
    zT_8F083A69_Slice_zT_0B42B2F8_u ident_text;
    unsigned int arb_tid;
    zT_79FAE712_u64 atk;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_28[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_42 = (unsigned int)(19) - (unsigned int)((unsigned int)d12l);
    d12s = zT_42;
    zT_47 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_48 = (unsigned int)(19) - d12s;
    zT_49.ptr = zT_47;
    zT_49.len = zT_48;
    zT_43 = zT_49;
    zF_B5478454_measureMarkerWrite(zT_43);
    zT_51 = "\n";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    d12nl = zT_52;
    zT_54 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_54);
    zT_57 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_57;
    sym_mod_id = mod_id;
    zT_60 = 0;
    sym_type_id = zT_60;
    zT_61 = node.child_1;
    zT_62 = 0;
    if ((unsigned char)(zT_61 != (unsigned int)zT_62)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_538 = store->fn_protos;
    zT_539 = zT_538.items;
    zT_540 = store;
    zT_541 = decl_idx;
    zT_542 = zF_8BA26B9E_astStoreNodePayload(zT_540, zT_541);
    zT_543 = (unsigned int)zT_542;
    zT_544 = zT_539[zT_543];
    proto = zT_544;
    zT_547 = proto.name_id;
    zT_546.name_id = zT_547;
    zT_548 = 0;
    zT_546.type_id = zT_548;
    zT_550 = zT_3C598AEF_SymbolKind_function;
    zT_546.kind = zT_550;
    zT_551 = node.flags;
    zT_552 = (unsigned short)zT_551;
    zT_546.flags = zT_552;
    zT_546.decl_node = decl_idx;
    zT_546.module_id = mod_id;
    zT_553 = 0;
    zT_546.scope_level = zT_553;
    sym = zT_546;
    zT_555 = sym_reg;
    zT_556 = mod_id;
    zT_557 = zF_9B36C202_symbolRegistryGetTa(zT_555, zT_556);
    table = zT_557;
    zT_558 = table;
    zT_559 = sym;
    zT_560 = zF_D0156DDA_symbolTableInsert(zT_558, zT_559);
    (void)zT_560;
    goto z_bb_9;
    z_bb_3:
    zT_561 = store;
    zT_562 = decl_idx;
    zT_563 = zF_8BA26B9E_astStoreNodePayload(zT_561, zT_562);
    if ((unsigned char)(zT_563 != (unsigned int)(0))) goto z_bb_90; else goto z_bb_91;
    z_bb_4:
    zT_585 = store;
    zT_586 = decl_idx;
    zT_587 = node.kind;
    zT_589 = zF_0E4E10C6_astStoreNodePayload(zT_585, zT_586, zT_587);
    zT_592 = (unsigned int)(zT_79FAE712_u64)(zT_589 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_592;
    zT_594 = node.kind;
switch (zT_594) {
case 3: goto z_bb_92;
case 4: goto z_bb_93;
case 5: goto z_bb_94;
default: goto z_bb_95;
}
    z_bb_5:
    zT_671 = store;
    zT_672 = decl_idx;
    zT_673 = node.kind;
    zT_675 = zF_0E4E10C6_astStoreNodePayload(zT_671, zT_672, zT_673);
    zT_678 = (unsigned int)(zT_79FAE712_u64)(zT_675 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_678;
    zT_680 = type_reg;
    zT_681 = mod_id;
    zT_682 = name_id;
    zT_686 = zF_3A64E2E0_typeRegistryRegiste(zT_680, zT_681, zT_682, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_686;
    if (populate) goto z_bb_114; else goto z_bb_115;
    z_bb_6:
    zT_708 = store;
    zT_709 = decl_idx;
    zT_710 = zF_8BA26B9E_astStoreNodePayload(zT_708, zT_709);
    path_id = zT_710;
    zT_712 = reg;
    zT_713 = path_id;
    zT_714 = zF_A258E183_moduleRegistryPathT(zT_712, zT_713);
    target_mod_id = zT_714;
    zT_715 = target_mod_id.has_value;
    if (zT_715) goto z_bb_116; else goto z_bb_117;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_65 = store;
    zT_66 = node.child_1;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    init_node = zT_68;
    zT_69 = init_node.kind;
    if ((unsigned char)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_450.name_id = name_id;
    zT_450.type_id = sym_type_id;
    zT_450.kind = sym_kind;
    zT_451 = node.flags;
    zT_452 = (unsigned short)zT_451;
    zT_450.flags = zT_452;
    zT_450.decl_node = decl_idx;
    zT_450.module_id = sym_mod_id;
    zT_453 = 0;
    zT_450.scope_level = zT_453;
    sym = zT_450;
    zT_455 = sym_reg;
    zT_456 = mod_id;
    zT_457 = zF_9B36C202_symbolRegistryGetTa(zT_455, zT_456);
    table = zT_457;
    zT_459 = table;
    zT_460 = sym;
    zT_461 = zF_D0156DDA_symbolTableInsert(zT_459, zT_460);
    inserted = zT_461;
    if ((unsigned char)(!inserted)) goto z_bb_88; else goto z_bb_89;
    z_bb_12:
    zT_74 = reg;
    zT_76 = store;
    zT_77 = node.child_1;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_76, zT_77);
    zT_75 = zT_79;
    zT_80 = zF_A258E183_moduleRegistryPathT(zT_74, zT_75);
    target = zT_80;
    zT_82 = "M5:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    m5m = zT_83;
    zT_85 = m5m;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_91 = store;
    zT_92 = node.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_94;
    zT_97 = 0;
    zT_98 = (unsigned char*)((unsigned char*)m5pb) + zT_97;
    zT_99 = (unsigned int)(20) - zT_97;
    zT_100.ptr = zT_98;
    zT_100.len = zT_99;
    zT_90 = zT_100;
    zT_101 = zF_A7504564_itoa(zT_89, zT_90);
    m5pl = zT_101;
    zT_105 = (unsigned int)(19) - (unsigned int)((unsigned int)m5pl);
    m5ps = zT_105;
    zT_110 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_111 = (unsigned int)(19) - m5ps;
    zT_112.ptr = zT_110;
    zT_112.len = zT_111;
    zT_106 = zT_112;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_113 = target.has_value;
    if (zT_113) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_214 = init_node.kind;
    if ((unsigned char)(zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    mtid = target.value;
    zT_116 = "Rs";
    zT_118 = 2;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    rs_msg = zT_117;
    zT_119 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_119);
    zT_121 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_121;
    sym_mod_id = mtid;
    zT_123 = "FIX1:mid=";
    zT_125 = 9;
    zT_124.ptr = zT_123;
    zT_124.len = zT_125;
    di_m = zT_124;
    zT_126 = di_m;
    zF_48AC7B3A_markerWrite(zT_126);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_128[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_128[_i];
        _i++;
    }
}
    zT_130 = sym_mod_id;
    zT_134 = 0;
    zT_135 = (unsigned char*)((unsigned char*)di_mb) + zT_134;
    zT_136 = (unsigned int)(10) - zT_134;
    zT_137.ptr = zT_135;
    zT_137.len = zT_136;
    zT_131 = zT_137;
    zT_138 = zF_A7504564_itoa(zT_130, zT_131);
    di_ml = zT_138;
    zT_142 = (unsigned int)(9) - (unsigned int)((unsigned int)di_ml);
    di_ms = zT_142;
    zT_147 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_148 = (unsigned int)(9) - di_ms;
    zT_149.ptr = zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zF_48AC7B3A_markerWrite(zT_143);
    zT_151 = "t";
    zT_153 = 1;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    di_t = zT_152;
    zT_154 = di_t;
    zF_48AC7B3A_markerWrite(zT_154);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_156[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_156[_i];
        _i++;
    }
}
    zT_158 = mtid;
    zT_162 = 0;
    zT_163 = (unsigned char*)((unsigned char*)di_tb) + zT_162;
    zT_164 = (unsigned int)(10) - zT_162;
    zT_165.ptr = zT_163;
    zT_165.len = zT_164;
    zT_159 = zT_165;
    zT_166 = zF_A7504564_itoa(zT_158, zT_159);
    di_tl = zT_166;
    zT_170 = (unsigned int)(9) - (unsigned int)((unsigned int)di_tl);
    di_ts = zT_170;
    zT_175 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_176 = (unsigned int)(9) - di_ts;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_179 = "n";
    zT_181 = 1;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    di_n = zT_180;
    zT_182 = di_n;
    zF_48AC7B3A_markerWrite(zT_182);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_184[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_184[_i];
        _i++;
    }
}
    zT_186 = mod_id;
    zT_190 = 0;
    zT_191 = (unsigned char*)((unsigned char*)di_nb) + zT_190;
    zT_192 = (unsigned int)(10) - zT_190;
    zT_193.ptr = zT_191;
    zT_193.len = zT_192;
    zT_187 = zT_193;
    zT_194 = zF_A7504564_itoa(zT_186, zT_187);
    di_nl = zT_194;
    zT_198 = (unsigned int)(9) - (unsigned int)((unsigned int)di_nl);
    di_ns = zT_198;
    zT_203 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_204 = (unsigned int)(9) - di_ns;
    zT_205.ptr = zT_203;
    zT_205.len = zT_204;
    zT_199 = zT_205;
    zF_48AC7B3A_markerWrite(zT_199);
    zT_206 = type_reg;
    zT_207 = mtid;
    zT_208 = zF_2ECA9F93_typeRegistryGetOrCr(zT_206, zT_207);
    sym_type_id = zT_208;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_210 = "Rf";
    zT_212 = 2;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    rf_msg = zT_211;
    zT_213 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_213);
    goto z_bb_15;
    z_bb_17:
    zT_219 = init_node.kind;
    zT_218 = zT_219 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_218 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_218) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_224 = init_node.kind;
    zT_223 = zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_223 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_223) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_229 = init_node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_228 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_228) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_234 = init_node.kind;
switch (zT_234) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_301 = init_node.kind;
    if ((unsigned char)(zT_301 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_52; else goto z_bb_54;
    z_bb_29:
    zT_235 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_35;
    z_bb_30:
    zT_235 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_240 = init_node.flags;
    zT_244 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_240) & (unsigned short)(16)) != zT_244)) goto z_bb_36; else goto z_bb_37;
    z_bb_32:
    zT_235 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_235 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_235;
    zT_264 = type_reg;
    zT_265 = mod_id;
    zT_266 = name_id;
    zT_267 = type_kind;
    zT_268 = zF_3A64E2E0_typeRegistryRegiste(zT_264, zT_265, zT_266, zT_267);
    sym_type_id = zT_268;
    zT_269 = init_node.kind;
    if ((unsigned char)(zT_269 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_43; else goto z_bb_42;
    z_bb_36:
    zT_246 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_38;
    z_bb_37:
    zT_249 = init_node.flags;
    zT_251 = 1;
    zT_253 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_249) & zT_251) != zT_253)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_235 = zT_246;
    goto z_bb_35;
    z_bb_39:
    zT_255 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_255 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_41;
    z_bb_41:
    zT_246 = zT_255;
    goto z_bb_38;
    z_bb_42:
    zT_274 = init_node.kind;
    zT_273 = zT_274 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_44;
    z_bb_43:
    zT_273 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_273) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_279 = init_node.flags;
    zT_278 = (unsigned short)((unsigned short)((unsigned short)zT_279) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_47;
    z_bb_46:
    zT_278 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_278) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_285 = type_reg;
    zT_286 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_285, zT_286);
    goto z_bb_49;
    z_bb_49:
    if (populate) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_287 = type_reg;
    zT_288 = store;
    zT_289 = init_node.kind;
    zT_290 = node.child_1;
    zT_291 = sym_reg;
    zF_020995FB_populateTypePayload(zT_287, zT_288, zT_289, zT_290, zT_291);
    goto z_bb_51;
    z_bb_51:
    zT_294 = store;
    zT_295 = node.child_1;
    zT_296 = sym_type_id;
    zT_297 = g;
    zF_4976C319_addTypeDependencies(zT_294, zT_295, zT_296, zT_297);
    zT_300 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_300;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_52:
    zT_306 = "RCA:p";
    zT_308 = 5;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    rca_m = zT_307;
    zT_309 = rca_m;
    zT_311 = store;
    zT_312 = node.child_1;
    zT_314 = zF_8BA26B9E_astStoreNodePayload(zT_311, zT_312);
    zT_310 = zT_314;
    zF_C914CB83_markerWriteInt(zT_309, zT_310);
    zT_316 = store;
    zT_317 = node.child_1;
    zT_319 = zF_53458827_astStoreIdentifier(zT_316, zT_317);
    ident_name_id = zT_319;
    zT_321 = "RCA:i";
    zT_323 = 5;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    rca_i = zT_322;
    zT_324 = rca_i;
    zT_325 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_324, zT_325);
    zT_327 = type_reg;
    zT_334 = zF_0EB68360_nameCacheGet(zT_327, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id)));
    cached = zT_334;
    zT_335 = cached.has_value;
    if ((unsigned char)(!zT_335)) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_27;
    z_bb_54:
    zT_390 = init_node.kind;
    if ((unsigned char)(zT_390 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_65; else goto z_bb_64;
    z_bb_55:
    zT_337 = type_reg;
    zT_340 = zF_0EB68360_nameCacheGet(zT_337, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_340;
    goto z_bb_56;
    z_bb_56:
    zT_341 = cached.has_value;
    if (zT_341) goto z_bb_57; else goto z_bb_59;
    z_bb_57:
    ct = cached.value;
    zT_344 = "RCA:H";
    zT_346 = 5;
    zT_345.ptr = zT_344;
    zT_345.len = zT_346;
    rca_h = zT_345;
    zT_347 = rca_h;
    zT_348 = ct;
    zF_C914CB83_markerWriteInt(zT_347, zT_348);
    zT_354 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    ck = zT_354;
    zT_355 = type_reg;
    zT_356 = ck;
    zT_357 = ct;
    zF_5E95558D_nameCachePut(zT_355, zT_356, zT_357);
    sym_type_id = ct;
    zT_359 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_359;
    sym_mod_id = mod_id;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_53;
    z_bb_59:
    zT_361 = 0;
    arb_u = zT_361;
    zT_363 = type_reg->interner;
    zT_364 = ident_name_id;
    zT_366 = zF_9134020D_stringInternerGet(zT_363, zT_364);
    ident_text = zT_366;
    zT_367 = ident_text;
    zT_368 = &arb_u;
    zT_370 = zF_741B5264_parseArbIntWidth(zT_367, zT_368);
    if ((unsigned char)(zT_370 != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_374 = type_reg;
    zT_375 = ident_text;
    zT_376 = zF_B8CF3697_typeRegistryGetOrCr(zT_374, zT_375);
    arb_tid = zT_376;
    if ((unsigned char)(arb_tid != (unsigned int)(18))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_58;
    z_bb_62:
    zT_384 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    atk = zT_384;
    zT_385 = type_reg;
    zT_386 = atk;
    zT_387 = arb_tid;
    zF_5E95558D_nameCachePut(zT_385, zT_386, zT_387);
    sym_type_id = arb_tid;
    zT_389 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_389;
    sym_mod_id = mod_id;
    goto z_bb_63;
    z_bb_63:
    goto z_bb_61;
    z_bb_64:
    zT_395 = init_node.kind;
    zT_394 = zT_395 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_66;
    z_bb_65:
    zT_394 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_394) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_400 = init_node.kind;
    zT_399 = zT_400 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_69;
    z_bb_68:
    zT_399 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_399) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_405 = init_node.kind;
    zT_404 = zT_405 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type);
    goto z_bb_72;
    z_bb_71:
    zT_404 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_404) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_410 = init_node.kind;
    zT_409 = zT_410 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_75;
    z_bb_74:
    zT_409 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_409) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_415 = init_node.kind;
    zT_414 = zT_415 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_78;
    z_bb_77:
    zT_414 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_414) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_420 = init_node.kind;
    zT_419 = zT_420 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_81;
    z_bb_80:
    zT_419 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_419) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_425 = "AT:p";
    zT_427 = 4;
    zT_426.ptr = zT_425;
    zT_426.len = zT_427;
    at_m = zT_426;
    zT_428 = at_m;
    zT_429 = name_id;
    zF_C914CB83_markerWriteInt(zT_428, zT_429);
    zT_431 = type_reg;
    zT_438 = zF_0EB68360_nameCacheGet(zT_431, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id)));
    acached = zT_438;
    zT_439 = acached.has_value;
    if ((unsigned char)(!zT_439)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_53;
    z_bb_84:
    zT_441 = type_reg;
    zT_444 = zF_0EB68360_nameCacheGet(zT_441, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_444;
    goto z_bb_85;
    z_bb_85:
    zT_445 = acached.has_value;
    if (zT_445) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    act = acached.value;
    sym_type_id = act;
    goto z_bb_87;
    z_bb_87:
    zT_448 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_448;
    sym_mod_id = mod_id;
    goto z_bb_83;
    z_bb_88:
    zT_464 = "VR";
    zT_466 = 2;
    zT_465.ptr = zT_464;
    zT_465.len = zT_466;
    vr = zT_465;
    zT_467 = vr;
    zF_48AC7B3A_markerWrite(zT_467);
    goto z_bb_89;
    z_bb_89:
    zT_469 = "VD";
    zT_471 = 2;
    zT_470.ptr = zT_469;
    zT_470.len = zT_471;
    vd = zT_470;
    zT_472 = vd;
    zF_48AC7B3A_markerWrite(zT_472);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_474[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_474[_i];
        _i++;
    }
}
    zT_476 = name_id;
    zT_480 = 0;
    zT_481 = (unsigned char*)((unsigned char*)vb) + zT_480;
    zT_482 = (unsigned int)(20) - zT_480;
    zT_483.ptr = zT_481;
    zT_483.len = zT_482;
    zT_477 = zT_483;
    zT_484 = zF_A7504564_itoa(zT_476, zT_477);
    vn = zT_484;
    zT_490 = (unsigned int)(19) - (unsigned int)((unsigned int)vn);
    vns = zT_490;
    zT_495 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_496 = (unsigned int)(20) - vns;
    zT_497.ptr = zT_495;
    zT_497.len = zT_496;
    zT_491 = zT_497;
    zF_48AC7B3A_markerWrite(zT_491);
    zT_499 = ":";
    zT_501 = 1;
    zT_500.ptr = zT_499;
    zT_500.len = zT_501;
    vc = zT_500;
    zT_502 = vc;
    zF_48AC7B3A_markerWrite(zT_502);
    zT_509 = 0;
    zT_510 = (unsigned char*)((unsigned char*)vb) + zT_509;
    zT_511 = (unsigned int)(20) - zT_509;
    zT_512.ptr = zT_510;
    zT_512.len = zT_511;
    zT_505 = zT_512;
    zT_513 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_505);
    vk = zT_513;
    zT_519 = (unsigned int)(19) - (unsigned int)((unsigned int)vk);
    vks = zT_519;
    zT_524 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_525 = (unsigned int)(20) - vks;
    zT_526.ptr = zT_524;
    zT_526.len = zT_525;
    zT_520 = zT_526;
    zF_48AC7B3A_markerWrite(zT_520);
    zT_528 = "\n";
    zT_530 = 1;
    zT_529.ptr = zT_528;
    zT_529.len = zT_530;
    ven = zT_529;
    zT_531 = ven;
    zF_48AC7B3A_markerWrite(zT_531);
    zT_533 = "Vi";
    zT_535 = 2;
    zT_534.ptr = zT_533;
    zT_534.len = zT_535;
    vi_msg = zT_534;
    zT_536 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_536);
    goto z_bb_9;
    z_bb_90:
    zT_568 = store;
    zT_569 = decl_idx;
    zT_570 = zF_8BA26B9E_astStoreNodePayload(zT_568, zT_569);
    zT_567.name_id = zT_570;
    zT_571 = 0;
    zT_567.type_id = zT_571;
    zT_573 = zT_3C598AEF_SymbolKind_test_sym;
    zT_567.kind = zT_573;
    zT_574 = node.flags;
    zT_575 = (unsigned short)zT_574;
    zT_567.flags = zT_575;
    zT_567.decl_node = decl_idx;
    zT_567.module_id = mod_id;
    zT_576 = 0;
    zT_567.scope_level = zT_576;
    sym = zT_567;
    zT_578 = sym_reg;
    zT_579 = mod_id;
    zT_580 = zF_9B36C202_symbolRegistryGetTa(zT_578, zT_579);
    table = zT_580;
    zT_581 = table;
    zT_582 = sym;
    zT_583 = zF_D0156DDA_symbolTableInsert(zT_581, zT_582);
    (void)zT_583;
    goto z_bb_91;
    z_bb_91:
    goto z_bb_9;
    z_bb_92:
    zT_595 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_97;
    z_bb_93:
    zT_595 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_97;
    z_bb_94:
    zT_600 = node.flags;
    zT_604 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_600) & (unsigned short)(16)) != zT_604)) goto z_bb_98; else goto z_bb_99;
    z_bb_95:
    zT_595 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_97;
    z_bb_97:
    type_kind = zT_595;
    zT_623 = type_reg;
    zT_624 = mod_id;
    zT_625 = name_id;
    zT_626 = type_kind;
    zT_627 = zF_3A64E2E0_typeRegistryRegiste(zT_623, zT_624, zT_625, zT_626);
    tid = zT_627;
    zT_628 = node.kind;
    if ((unsigned char)(zT_628 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_105; else goto z_bb_104;
    z_bb_98:
    zT_606 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_100;
    z_bb_99:
    zT_609 = node.flags;
    zT_611 = 1;
    zT_613 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_609) & zT_611) != zT_613)) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    zT_595 = zT_606;
    goto z_bb_97;
    z_bb_101:
    zT_615 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_103;
    z_bb_102:
    zT_615 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_103;
    z_bb_103:
    zT_606 = zT_615;
    goto z_bb_100;
    z_bb_104:
    zT_633 = node.kind;
    zT_632 = zT_633 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_106;
    z_bb_105:
    zT_632 = 1;
    goto z_bb_106;
    z_bb_106:
    if (zT_632) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_638 = node.flags;
    zT_637 = (unsigned short)((unsigned short)((unsigned short)zT_638) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_109;
    z_bb_108:
    zT_637 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_637) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_644 = type_reg;
    zT_645 = tid;
    zF_52816016_typeRegistrySetPack(zT_644, zT_645);
    goto z_bb_111;
    z_bb_111:
    if (populate) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_646 = type_reg;
    zT_647 = store;
    zT_648 = node.kind;
    zT_649 = decl_idx;
    zT_650 = sym_reg;
    zF_020995FB_populateTypePayload(zT_646, zT_647, zT_648, zT_649, zT_650);
    goto z_bb_113;
    z_bb_113:
    zT_652 = store;
    zT_653 = decl_idx;
    zT_654 = tid;
    zT_655 = g;
    zF_4976C319_addTypeDependencies(zT_652, zT_653, zT_654, zT_655);
    zT_657.name_id = name_id;
    zT_657.type_id = tid;
    zT_659 = zT_3C598AEF_SymbolKind_type_alias;
    zT_657.kind = zT_659;
    zT_660 = node.flags;
    zT_661 = (unsigned short)zT_660;
    zT_657.flags = zT_661;
    zT_657.decl_node = decl_idx;
    zT_657.module_id = mod_id;
    zT_662 = 0;
    zT_657.scope_level = zT_662;
    sym = zT_657;
    zT_664 = sym_reg;
    zT_665 = mod_id;
    zT_666 = zF_9B36C202_symbolRegistryGetTa(zT_664, zT_665);
    table = zT_666;
    zT_667 = table;
    zT_668 = sym;
    zT_669 = zF_D0156DDA_symbolTableInsert(zT_667, zT_668);
    (void)zT_669;
    goto z_bb_9;
    z_bb_114:
    zT_687 = type_reg;
    zT_688 = store;
    zT_689 = node.kind;
    zT_690 = decl_idx;
    zT_691 = sym_reg;
    zF_020995FB_populateTypePayload(zT_687, zT_688, zT_689, zT_690, zT_691);
    goto z_bb_115;
    z_bb_115:
    zT_694.name_id = name_id;
    zT_694.type_id = tid;
    zT_696 = zT_3C598AEF_SymbolKind_type_alias;
    zT_694.kind = zT_696;
    zT_697 = node.flags;
    zT_698 = (unsigned short)zT_697;
    zT_694.flags = zT_698;
    zT_694.decl_node = decl_idx;
    zT_694.module_id = mod_id;
    zT_699 = 0;
    zT_694.scope_level = zT_699;
    sym = zT_694;
    zT_701 = sym_reg;
    zT_702 = mod_id;
    zT_703 = zF_9B36C202_symbolRegistryGetTa(zT_701, zT_702);
    table = zT_703;
    zT_704 = table;
    zT_705 = sym;
    zT_706 = zF_D0156DDA_symbolTableInsert(zT_704, zT_705);
    (void)zT_706;
    goto z_bb_9;
    z_bb_116:
    tid = target_mod_id.value;
    zT_718.name_id = path_id;
    zT_719 = type_reg;
    zT_720 = tid;
    zT_721 = zF_2ECA9F93_typeRegistryGetOrCr(zT_719, zT_720);
    zT_718.type_id = zT_721;
    zT_723 = zT_3C598AEF_SymbolKind_module;
    zT_718.kind = zT_723;
    zT_724 = 0;
    zT_718.flags = zT_724;
    zT_718.decl_node = decl_idx;
    zT_718.module_id = tid;
    zT_725 = 0;
    zT_718.scope_level = zT_725;
    sym = zT_718;
    zT_727 = sym_reg;
    zT_728 = mod_id;
    zT_729 = zF_9B36C202_symbolRegistryGetTa(zT_727, zT_728);
    table = zT_729;
    zT_730 = table;
    zT_731 = sym;
    zT_732 = zF_D0156DDA_symbolTableInsert(zT_730, zT_731);
    (void)zT_732;
    zT_734 = "IMR:n";
    zT_736 = 5;
    zT_735.ptr = zT_734;
    zT_735.len = zT_736;
    imr = zT_735;
    zT_737 = imr;
    zF_48AC7B3A_markerWrite(zT_737);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_739[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_739[_i];
        _i++;
    }
}
    zT_741 = path_id;
    zT_745 = 0;
    zT_746 = (unsigned char*)((unsigned char*)imb) + zT_745;
    zT_747 = (unsigned int)(10) - zT_745;
    zT_748.ptr = zT_746;
    zT_748.len = zT_747;
    zT_742 = zT_748;
    zT_749 = zF_A7504564_itoa(zT_741, zT_742);
    iml = zT_749;
    zT_753 = (unsigned int)(9) - (unsigned int)((unsigned int)iml);
    ims = zT_753;
    zT_758 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_759 = (unsigned int)(9) - ims;
    zT_760.ptr = zT_758;
    zT_760.len = zT_759;
    zT_754 = zT_760;
    zF_48AC7B3A_markerWrite(zT_754);
    zT_762 = "m";
    zT_764 = 1;
    zT_763.ptr = zT_762;
    zT_763.len = zT_764;
    imm = zT_763;
    zT_765 = imm;
    zF_48AC7B3A_markerWrite(zT_765);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_767[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_767[_i];
        _i++;
    }
}
    zT_769 = tid;
    zT_773 = 0;
    zT_774 = (unsigned char*)((unsigned char*)immb) + zT_773;
    zT_775 = (unsigned int)(10) - zT_773;
    zT_776.ptr = zT_774;
    zT_776.len = zT_775;
    zT_770 = zT_776;
    zT_777 = zF_A7504564_itoa(zT_769, zT_770);
    imml = zT_777;
    zT_781 = (unsigned int)(9) - (unsigned int)((unsigned int)imml);
    imms = zT_781;
    zT_786 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_787 = (unsigned int)(9) - imms;
    zT_788.ptr = zT_786;
    zT_788.len = zT_787;
    zT_782 = zT_788;
    zF_48AC7B3A_markerWrite(zT_782);
    zT_790 = " ";
    zT_792 = 1;
    zT_791.ptr = zT_790;
    zT_791.len = zT_792;
    imsnl = zT_791;
    zT_793 = imsnl;
    zF_48AC7B3A_markerWrite(zT_793);
    goto z_bb_117;
    z_bb_117:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, unsigned char populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned char zT_16;
    zT_9FE1BFFE_ModuleState zT_17;
    unsigned char zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    zT_79FAE712_u64 zT_56 = 0;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66 = 0;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned char* zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    int zT_84;
    unsigned int zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_98 = 0;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_130 = 0;
    zT_22A7C88B_AstNode zT_131 = {0};
    zT_8143F551_AstKind zT_133;
    unsigned int zT_134;
    zT_4028D896_Arr_unsigned_char_2 zT_136;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146 = 0;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    int zT_163;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int zT_172;
    unsigned int zT_173;
    zT_3D7259E2_SymbolRegistry* zT_176;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_4D61441E_DepGraph* zT_181;
    zT_072B53A6_ModuleRegistry* zT_182;
    unsigned char zT_183;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    unsigned int zT_189 = 0;
    int zT_190;
    unsigned int zT_192;
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((unsigned char)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = entry.state;
    zT_16 = zT_17 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = entry.ast_root;
    zT_23 = 0;
    zT_21 = zT_22 == (unsigned int)zT_23;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = store;
    zT_27 = entry.ast_root;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    root = zT_29;
    zT_30 = root.kind;
    if ((unsigned char)(zT_30 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_35 = store;
    zT_36 = entry.ast_root;
    zT_38 = zF_152E19CB_astStoreNodeExtraCh(zT_35, zT_36);
    decls_n = zT_38;
    if ((unsigned char)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = "RS";
    zT_44 = 2;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    dg = zT_43;
    zT_45 = dg;
    zF_48AC7B3A_markerWrite(zT_45);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = store;
    zT_52 = entry.ast_root;
    zT_53 = root.kind;
    zT_56 = zF_0E4E10C6_astStoreNodePayload(zT_51, zT_52, zT_53);
    zT_62 = 0;
    zT_63 = (unsigned char*)((unsigned char*)pb) + zT_62;
    zT_64 = (unsigned int)(20) - zT_62;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_50 = zT_65;
    zT_66 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_56 & (zT_79FAE712_u64)(4294967295u))), zT_50);
    pl = zT_66;
    zT_70 = (unsigned int)(19) - (unsigned int)((unsigned int)pl);
    ps = zT_70;
    zT_75 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_76 = (unsigned int)(19) - ps;
    zT_77.ptr = zT_75;
    zT_77.len = zT_76;
    zT_71 = zT_77;
    zF_48AC7B3A_markerWrite(zT_71);
    zT_79 = ":";
    zT_81 = 1;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    sc = zT_80;
    zT_82 = sc;
    zF_48AC7B3A_markerWrite(zT_82);
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    i2 = zT_85;
    goto z_bb_13;
    z_bb_12:
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    i = zT_173;
    goto z_bb_17;
    z_bb_13:
    if ((unsigned char)(i2 < (unsigned int)((unsigned int)decls_n))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_89[_i];
        _i++;
    }
}
    zT_93 = store;
    zT_94 = entry.ast_root;
    zT_98 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)i2));
    zT_91 = zT_98;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)ii_buf) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = zT_102;
    zT_104.len = zT_103;
    zT_92 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_91, zT_92);
    ii_len = zT_105;
    zT_109 = (unsigned int)(19) - (unsigned int)((unsigned int)ii_len);
    ii_start = zT_109;
    zT_114 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_115 = (unsigned int)(19) - ii_start;
    zT_116.ptr = zT_114;
    zT_116.len = zT_115;
    zT_110 = zT_116;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_118 = "=";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    ss = zT_119;
    zT_121 = ss;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_123 = store;
    zT_125 = store;
    zT_126 = entry.ast_root;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_125, zT_126, (unsigned int)((unsigned int)i2));
    zT_124 = zT_130;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_123, zT_124);
    dc = zT_131;
    zT_133 = dc.kind;
    zT_134 = (unsigned int)zT_133;
    dk = zT_134;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_136[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_136[_i];
        _i++;
    }
}
    zT_138 = dk;
    zT_142 = 0;
    zT_143 = (unsigned char*)((unsigned char*)db) + zT_142;
    zT_144 = (unsigned int)(20) - zT_142;
    zT_145.ptr = zT_143;
    zT_145.len = zT_144;
    zT_139 = zT_145;
    zT_146 = zF_A7504564_itoa(zT_138, zT_139);
    dl = zT_146;
    zT_150 = (unsigned int)(19) - (unsigned int)((unsigned int)dl);
    ds = zT_150;
    zT_155 = (unsigned char*)((unsigned char*)db) + ds;
    zT_156 = (unsigned int)(19) - ds;
    zT_157.ptr = zT_155;
    zT_157.len = zT_156;
    zT_151 = zT_157;
    zF_48AC7B3A_markerWrite(zT_151);
    zT_159 = " ";
    zT_161 = 1;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    dsp = zT_160;
    zT_162 = dsp;
    zF_48AC7B3A_markerWrite(zT_162);
    goto z_bb_16;
    z_bb_15:
    zT_167 = "\n";
    zT_169 = 1;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    dn = zT_168;
    zT_170 = dn;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_163 = 1;
    zT_165 = i2 + (unsigned int)((unsigned int)zT_163);
    i2 = zT_165;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(i < (unsigned int)((unsigned int)decls_n))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_176 = sym_reg;
    zT_177 = type_reg;
    zT_178 = store;
    zT_179 = module_id;
    zT_184 = store;
    zT_185 = entry.ast_root;
    zT_189 = zF_B10B1BC1_astStoreNodeExtraCh(zT_184, zT_185, (unsigned int)((unsigned int)i));
    zT_180 = zT_189;
    zT_181 = g;
    zT_182 = reg;
    zT_183 = populate;
    zF_CBEB26BC_registerDecl(zT_176, zT_177, zT_178, zT_179, zT_180, zT_181, zT_182, zT_183);
    zT_190 = 1;
    zT_192 = i + (unsigned int)((unsigned int)zT_190);
    i = zT_192;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_19(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_33EF6BFB_TypeKind zT_1 = 0;
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
