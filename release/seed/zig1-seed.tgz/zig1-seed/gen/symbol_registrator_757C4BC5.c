#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zT_5 = 0;
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_70307317_Opt_244 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_E1B9232E_EU_442 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_70307317_Opt_244 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->cap;
    zT_14 = 0;
    if ((unsigned char)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->items;
    zT_25 = self->cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->items;
    zT_48 = self->len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    goto z_bb_16;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
    z_bb_16:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    self->len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_9;
    zT_E1B9232E_EU_442 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_52CDA6EF_DepEdge* zT_35;
    zT_52CDA6EF_DepEdge zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    zT_52CDA6EF_DepEdge* zT_43;
    zT_52CDA6EF_DepEdge zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_5 = (unsigned int)(unsigned int)(max_type_id + (unsigned int)(1));
    count = zT_5;
    zT_6 = self->in_degree_cap;
    if ((unsigned char)(count > zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_9, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_6;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    zT_26 = self->in_degree_items;
    zT_26[i] = zT_25;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_32 = self->len;
    if ((unsigned char)(i < zT_32)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self->in_degree_items;
    zT_35 = self->items;
    zT_36 = zT_35[i];
    zT_37 = zT_36.to;
    zT_38 = zT_34[zT_37];
    zT_39 = 1;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    zT_42 = self->in_degree_items;
    zT_43 = self->items;
    zT_44 = zT_43[i];
    zT_45 = zT_44.to;
    zT_42[zT_45] = zT_41;
    zT_46 = 1;
    zT_48 = i + (unsigned int)((unsigned int)zT_46);
    i = zT_48;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_28 = 0;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_4D61441E_DepGraph* zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_40;
    unsigned int children_n;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_14, zT_15);
    children_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < children_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = store;
    zT_24 = store;
    zT_25 = decl_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_24, zT_25, (unsigned int)((unsigned int)i));
    zT_23 = zT_28;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    field_node = zT_29;
    zT_30 = field_node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_34 = g;
    zT_36 = tid;
    zF_AA751A34_depGraphAddEdge(zT_34, (unsigned int)(0), zT_36);
    goto z_bb_8;
    z_bb_8:
    zT_38 = 1;
    zT_40 = i + (unsigned int)((unsigned int)zT_38);
    i = zT_40;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, unsigned int tid, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned char zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    unsigned char zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_30 = 0;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    unsigned char zT_38;
    int zT_39;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_55;
    unsigned int zT_56;
    int zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int zT_68 = 0;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    zT_338B7C76_TypeRegistry* zT_74;
    int zT_77;
    unsigned int zT_79;
    int zT_80;
    unsigned int zT_82;
    int zT_83;
    zT_338B7C76_TypeRegistry* zT_85;
    zT_666DC2E1_TuplePayload zT_86;
    zT_666DC2E1_TuplePayload zT_87;
    unsigned short zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned int zT_94;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    zT_D155D06D_Type zT_98;
    zT_D155D06D_Type* zT_99;
    unsigned int zT_100;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_108;
    unsigned int zT_109;
    int zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    unsigned int zT_121 = 0;
    zT_22A7C88B_AstNode zT_122 = {0};
    zT_8143F551_AstKind zT_123;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_2DF01B61_FieldEntry zT_128;
    zT_2DF01B61_FieldEntry zT_129;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    unsigned int zT_136 = 0;
    unsigned int zT_137 = 0;
    unsigned int zT_138;
    unsigned int zT_139;
    int zT_140;
    unsigned int zT_142;
    int zT_143;
    unsigned int zT_145;
    zT_338B7C76_TypeRegistry* zT_146;
    zT_406493CE_StructPayload zT_147;
    zT_406493CE_StructPayload zT_148;
    unsigned int zT_149;
    unsigned short zT_150;
    unsigned int zT_152;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_D155D06D_Type* zT_158;
    unsigned int zT_159;
    zT_D155D06D_Type zT_160;
    zT_D155D06D_Type* zT_161;
    unsigned int zT_162;
    unsigned int zT_167;
    unsigned int zT_168;
    int zT_170;
    unsigned int zT_171;
    int zT_173;
    unsigned int zT_174;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_6B0A7D14_AstStore* zT_179;
    unsigned int zT_180;
    unsigned int zT_183 = 0;
    zT_22A7C88B_AstNode zT_184 = {0};
    zT_8143F551_AstKind zT_185;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_2DF01B61_FieldEntry zT_190;
    zT_2DF01B61_FieldEntry zT_191;
    zT_6B0A7D14_AstStore* zT_192;
    unsigned int zT_193;
    zT_6B0A7D14_AstStore* zT_194;
    unsigned int zT_195;
    unsigned int zT_198 = 0;
    unsigned int zT_199 = 0;
    unsigned int zT_200;
    unsigned int zT_201;
    int zT_202;
    unsigned int zT_204;
    int zT_205;
    unsigned int zT_207;
    unsigned char zT_208;
    int zT_210;
    int zT_212;
    zT_338B7C76_TypeRegistry* zT_214;
    zT_54FF90FA_TaggedUnionPayload zT_215;
    zT_54FF90FA_TaggedUnionPayload zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned short zT_219;
    unsigned int zT_221;
    unsigned int zT_223;
    unsigned int zT_225;
    zT_D155D06D_Type* zT_227;
    unsigned int zT_228;
    zT_D155D06D_Type zT_229;
    zT_D155D06D_Type* zT_230;
    unsigned int zT_231;
    zT_338B7C76_TypeRegistry* zT_232;
    zT_AF9231A2_UnionPayload zT_233;
    zT_AF9231A2_UnionPayload zT_234;
    unsigned int zT_235;
    unsigned short zT_236;
    unsigned int zT_237;
    unsigned int zT_239;
    unsigned int zT_241;
    unsigned int zT_243;
    zT_D155D06D_Type* zT_245;
    unsigned int zT_246;
    zT_D155D06D_Type zT_247;
    zT_D155D06D_Type* zT_248;
    unsigned int zT_249;
    zT_ABC1EBBE_TypeResolveEnv zT_254;
    zT_D3EB6303_StringInterner* zT_255;
    unsigned int zT_257;
    zT_6F32B01B_Opt_235 zT_258 = {0};
    zT_0DCE6231_Opt_408 zT_259 = {0};
    zT_FFCC0D90_Opt_410 zT_260 = {0};
    zT_939EE900_Arr_unsigned_int_1 zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    int zT_266;
    unsigned char zT_268;
    unsigned int zT_269;
    int zT_270;
    zT_ABC1EBBE_TypeResolveEnv* zT_273;
    unsigned int zT_274;
    unsigned int zT_279 = 0;
    unsigned char zT_282;
    int zT_285;
    unsigned char zT_286;
    unsigned int zT_288;
    unsigned int zT_289;
    int zT_291;
    unsigned int zT_292;
    int zT_294;
    unsigned int zT_295;
    int zT_297;
    unsigned int zT_298;
    zT_ABC1EBBE_TypeResolveEnv* zT_299;
    unsigned int zT_300;
    unsigned int* zT_305;
    unsigned int* zT_306;
    unsigned int* zT_307;
    unsigned char zT_316 = 0;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_457ECFEE_EnumPayload zT_318;
    zT_457ECFEE_EnumPayload zT_319;
    unsigned int zT_320;
    unsigned short zT_321;
    int zT_322;
    unsigned int zT_323;
    unsigned int zT_325;
    unsigned int zT_327;
    unsigned int zT_329;
    zT_D155D06D_Type* zT_331;
    unsigned int zT_332;
    zT_D155D06D_Type zT_333;
    zT_D155D06D_Type* zT_334;
    unsigned int zT_335;
    unsigned int zT_340;
    unsigned int zT_341;
    int zT_343;
    unsigned int zT_344;
    zT_338B7C76_TypeRegistry* zT_346;
    unsigned int zT_347;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    unsigned int zT_352 = 0;
    int zT_353;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_356;
    zT_0B73C507_ErrorSetPayload zT_357;
    zT_0B73C507_ErrorSetPayload zT_358;
    unsigned short zT_359;
    unsigned int zT_361;
    unsigned int zT_363;
    unsigned int zT_365;
    zT_D155D06D_Type* zT_367;
    unsigned int zT_368;
    zT_D155D06D_Type zT_369;
    zT_D155D06D_Type* zT_370;
    unsigned int zT_371;
    zT_22A7C88B_AstNode node;
    unsigned char is_container;
    unsigned int children_n;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ti;
    zT_22A7C88B_AstNode efd;
    unsigned int tup_last;
    unsigned int tup_idx;
    zT_D155D06D_Type tty;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    unsigned int fail_node;
    unsigned int fail_kind;
    unsigned int en_last;
    unsigned int en_idx;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_7 = store;
    zT_8 = decl_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_9;
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_18 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_22 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_22 = 1;
    goto z_bb_9;
    z_bb_9:
    is_container = zT_22;
    if ((unsigned char)(!is_container)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_28 = store;
    zT_29 = decl_idx;
    zT_30 = zF_8BA26B9E_astStoreNodePayload(zT_28, zT_29);
    zT_27 = zT_30 == (unsigned int)(0);
    goto z_bb_12;
    z_bb_11:
    zT_27 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_27) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return;
    z_bb_14:
    zT_34 = store;
    zT_35 = decl_idx;
    zT_36 = zF_152E19CB_astStoreNodeExtraCh(zT_34, zT_35);
    children_n = zT_36;
    if ((unsigned char)(!is_container)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_39 = 0;
    zT_38 = children_n == (unsigned int)zT_39;
    goto z_bb_17;
    z_bb_16:
    zT_38 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return;
    z_bb_19:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_45 = node.flags;
    zT_44 = (unsigned short)((unsigned short)((unsigned short)zT_45) & (unsigned short)(32)) != (unsigned short)(0);
    goto z_bb_22;
    z_bb_21:
    zT_44 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_44) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_52 = type_reg->xt_len;
    zT_53 = (unsigned int)zT_52;
    estart = zT_53;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    ecount = zT_56;
    zT_58 = 0;
    zT_59 = (unsigned int)zT_58;
    ti = zT_59;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_33; else goto z_bb_34;
    z_bb_25:
    if ((unsigned char)(ti < children_n)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_62 = store;
    zT_64 = store;
    zT_65 = decl_idx;
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_64, zT_65, (unsigned int)((unsigned int)ti));
    zT_63 = zT_68;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_62, zT_63);
    efd = zT_69;
    zT_70 = efd.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_83 = 0;
    if ((unsigned char)(ecount > (unsigned int)zT_83)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_80 = 1;
    zT_82 = ti + (unsigned int)((unsigned int)zT_80);
    ti = zT_82;
    goto z_bb_25;
    z_bb_29:
    zT_74 = type_reg;
    zF_4C03AE3D_xtAppend(zT_74, (unsigned int)(1));
    zT_77 = 1;
    zT_79 = ecount + (unsigned int)((unsigned int)zT_77);
    ecount = zT_79;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_85 = type_reg;
    zT_87.elems_start = estart;
    zT_88 = (unsigned short)ecount;
    zT_87.elems_count = zT_88;
    zT_86 = zT_87;
    zF_C94DF842_tupAppend(zT_85, zT_86);
    zT_90 = type_reg->tup_len;
    zT_92 = zT_90 - (unsigned int)(1);
    tup_last = zT_92;
    zT_94 = (unsigned int)tup_last;
    tup_idx = zT_94;
    zT_96 = type_reg->types_items;
    zT_97 = (unsigned int)tid;
    zT_98 = zT_96[zT_97];
    tty = zT_98;
    tty.payload_idx = tup_idx;
    zT_99 = type_reg->types_items;
    zT_100 = (unsigned int)tid;
    zT_99[zT_100] = tty;
    goto z_bb_32;
    z_bb_32:
    return;
    z_bb_33:
    zT_105 = type_reg->fe_len;
    zT_106 = (unsigned int)zT_105;
    fstart = zT_106;
    zT_108 = 0;
    zT_109 = (unsigned int)zT_108;
    fcount = zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    i = zT_112;
    goto z_bb_35;
    z_bb_34:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_35:
    if ((unsigned char)(i < children_n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_115 = store;
    zT_117 = store;
    zT_118 = decl_idx;
    zT_121 = zF_B10B1BC1_astStoreNodeExtraCh(zT_117, zT_118, (unsigned int)((unsigned int)i));
    zT_116 = zT_121;
    zT_122 = zF_FCDD1D35_astStoreNodeAt(zT_115, zT_116);
    fd = zT_122;
    zT_123 = fd.kind;
    if ((unsigned char)(zT_123 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_146 = type_reg;
    zT_149 = (unsigned int)fstart;
    zT_148.fields_start = zT_149;
    zT_150 = (unsigned short)fcount;
    zT_148.fields_count = zT_150;
    zT_147 = zT_148;
    zF_CF849366_stAppend(zT_146, zT_147);
    zT_152 = type_reg->st_len;
    zT_154 = zT_152 - (unsigned int)(1);
    st_last = zT_154;
    zT_156 = (unsigned int)st_last;
    st_idx = zT_156;
    zT_158 = type_reg->types_items;
    zT_159 = (unsigned int)tid;
    zT_160 = zT_158[zT_159];
    ty = zT_160;
    ty.payload_idx = st_idx;
    zT_161 = type_reg->types_items;
    zT_162 = (unsigned int)tid;
    zT_161[zT_162] = ty;
    goto z_bb_34;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_127 = type_reg;
    zT_130 = store;
    zT_132 = store;
    zT_133 = decl_idx;
    zT_136 = zF_B10B1BC1_astStoreNodeExtraCh(zT_132, zT_133, (unsigned int)((unsigned int)i));
    zT_131 = zT_136;
    zT_137 = zF_8BA26B9E_astStoreNodePayload(zT_130, zT_131);
    zT_129.name_id = zT_137;
    zT_138 = 1;
    zT_129.type_id = zT_138;
    zT_139 = 0;
    zT_129.offset = zT_139;
    zT_128 = zT_129;
    zF_701DF154_feAppend(zT_127, zT_128);
    zT_140 = 1;
    zT_142 = fcount + (unsigned int)((unsigned int)zT_140);
    fcount = zT_142;
    goto z_bb_40;
    z_bb_40:
    zT_143 = 1;
    zT_145 = i + (unsigned int)((unsigned int)zT_143);
    i = zT_145;
    goto z_bb_38;
    z_bb_41:
    zT_167 = type_reg->fe_len;
    zT_168 = (unsigned int)zT_167;
    fstart = zT_168;
    zT_170 = 0;
    zT_171 = (unsigned int)zT_170;
    fcount = zT_171;
    zT_173 = 0;
    zT_174 = (unsigned int)zT_173;
    i = zT_174;
    goto z_bb_43;
    z_bb_42:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_52; else goto z_bb_53;
    z_bb_43:
    if ((unsigned char)(i < children_n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_177 = store;
    zT_179 = store;
    zT_180 = decl_idx;
    zT_183 = zF_B10B1BC1_astStoreNodeExtraCh(zT_179, zT_180, (unsigned int)((unsigned int)i));
    zT_178 = zT_183;
    zT_184 = zF_FCDD1D35_astStoreNodeAt(zT_177, zT_178);
    fd = zT_184;
    zT_185 = fd.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    zT_208 = node.flags;
    zT_210 = 1;
    zT_212 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_208) & zT_210) != zT_212)) goto z_bb_49; else goto z_bb_51;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_189 = type_reg;
    zT_192 = store;
    zT_194 = store;
    zT_195 = decl_idx;
    zT_198 = zF_B10B1BC1_astStoreNodeExtraCh(zT_194, zT_195, (unsigned int)((unsigned int)i));
    zT_193 = zT_198;
    zT_199 = zF_8BA26B9E_astStoreNodePayload(zT_192, zT_193);
    zT_191.name_id = zT_199;
    zT_200 = 1;
    zT_191.type_id = zT_200;
    zT_201 = 0;
    zT_191.offset = zT_201;
    zT_190 = zT_191;
    zF_701DF154_feAppend(zT_189, zT_190);
    zT_202 = 1;
    zT_204 = fcount + (unsigned int)((unsigned int)zT_202);
    fcount = zT_204;
    goto z_bb_48;
    z_bb_48:
    zT_205 = 1;
    zT_207 = i + (unsigned int)((unsigned int)zT_205);
    i = zT_207;
    goto z_bb_46;
    z_bb_49:
    zT_214 = type_reg;
    zT_217 = 10;
    zT_216.tag_type = zT_217;
    zT_218 = (unsigned int)fstart;
    zT_216.fields_start = zT_218;
    zT_219 = (unsigned short)fcount;
    zT_216.fields_count = zT_219;
    zT_215 = zT_216;
    zF_FB6B57C6_tuAppend(zT_214, zT_215);
    zT_221 = type_reg->tu_len;
    zT_223 = zT_221 - (unsigned int)(1);
    tu_last = zT_223;
    zT_225 = (unsigned int)tu_last;
    tu_idx = zT_225;
    zT_227 = type_reg->types_items;
    zT_228 = (unsigned int)tid;
    zT_229 = zT_227[zT_228];
    ty = zT_229;
    ty.payload_idx = tu_idx;
    zT_230 = type_reg->types_items;
    zT_231 = (unsigned int)tid;
    zT_230[zT_231] = ty;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_42;
    z_bb_51:
    zT_232 = type_reg;
    zT_235 = (unsigned int)fstart;
    zT_234.fields_start = zT_235;
    zT_236 = (unsigned short)fcount;
    zT_234.fields_count = zT_236;
    zT_237 = 1;
    zT_234.tag_type = zT_237;
    zT_233 = zT_234;
    zF_1718422E_unAppend(zT_232, zT_233);
    zT_239 = type_reg->un_len;
    zT_241 = zT_239 - (unsigned int)(1);
    un_last = zT_241;
    zT_243 = (unsigned int)un_last;
    un_idx = zT_243;
    zT_245 = type_reg->types_items;
    zT_246 = (unsigned int)tid;
    zT_247 = zT_245[zT_246];
    ty = zT_247;
    ty.payload_idx = un_idx;
    zT_248 = type_reg->types_items;
    zT_249 = (unsigned int)tid;
    zT_248[zT_249] = ty;
    goto z_bb_50;
    z_bb_52:
    zT_254.store = store;
    zT_254.typereg = type_reg;
    zT_254.symbol_reg = sym_reg;
    zT_255 = type_reg->interner;
    zT_254.interner = zT_255;
    zT_254.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_257 = 0;
    zT_254.source_file_id = zT_257;
    zT_258.has_value = 0;
    zT_254.diag = zT_258;
    zT_259.has_value = 0;
    zT_254.local_consts = zT_259;
    zT_260.has_value = 0;
    zT_254.local_types = zT_260;
    tre_env = zT_254;
    zT_263 = 0;
    zT_264 = 0;
    zT_262[zT_264] = zT_263;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_262[_i];
        _i++;
    }
}
    zT_265 = 10;
    zT_266 = 0;
    backing_box[zT_266] = zT_265;
    zT_268 = 0;
    expl_flag = zT_268;
    zT_269 = node.child_0;
    zT_270 = 0;
    if ((unsigned char)(zT_269 != (unsigned int)zT_270)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_61; else goto z_bb_62;
    z_bb_54:
    zT_273 = &tre_env;
    zT_274 = node.child_0;
    zT_279 = zF_F2107C15_resolveTypeExprFull(zT_273, zT_274, (unsigned int)(0));
    bt = zT_279;
    if ((unsigned char)(bt != (unsigned int)(18))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_288 = type_reg->em_len;
    zT_289 = (unsigned int)zT_288;
    mstart = zT_289;
    zT_291 = 0;
    zT_292 = (unsigned int)zT_291;
    mcount = zT_292;
    zT_294 = 0;
    zT_295 = (unsigned int)zT_294;
    fail_node = zT_295;
    zT_297 = 0;
    zT_298 = (unsigned int)zT_297;
    fail_kind = zT_298;
    zT_299 = &tre_env;
    zT_300 = decl_idx;
    zT_305 = &mcount;
    zT_306 = &fail_node;
    zT_307 = &fail_kind;
    zT_316 = zF_0FFDEDBD_enumMembersResolve(zT_299, zT_300, (unsigned char)(1), (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), zT_305, zT_306, zT_307);
    (void)zT_316;
    zT_317 = type_reg;
    zT_320 = (unsigned int)mstart;
    zT_319.members_start = zT_320;
    zT_321 = (unsigned short)mcount;
    zT_319.members_count = zT_321;
    zT_322 = 0;
    zT_323 = backing_box[zT_322];
    zT_319.backing_type = zT_323;
    zT_319.explicit_backing = expl_flag;
    zT_318 = zT_319;
    zF_298371DE_enAppend(zT_317, zT_318);
    zT_325 = type_reg->en_len;
    zT_327 = zT_325 - (unsigned int)(1);
    en_last = zT_327;
    zT_329 = (unsigned int)en_last;
    en_idx = zT_329;
    zT_331 = type_reg->types_items;
    zT_332 = (unsigned int)tid;
    zT_333 = zT_331[zT_332];
    ty = zT_333;
    ty.payload_idx = en_idx;
    zT_334 = type_reg->types_items;
    zT_335 = (unsigned int)tid;
    zT_334[zT_335] = ty;
    goto z_bb_53;
    z_bb_56:
    zT_282 = bt != (unsigned int)(1);
    goto z_bb_58;
    z_bb_57:
    zT_282 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_282) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_285 = 0;
    backing_box[zT_285] = bt;
    goto z_bb_60;
    z_bb_60:
    zT_286 = 1;
    expl_flag = zT_286;
    goto z_bb_55;
    z_bb_61:
    zT_340 = type_reg->xn_len;
    zT_341 = (unsigned int)zT_340;
    tags_start_idx = zT_341;
    zT_343 = 0;
    zT_344 = (unsigned int)zT_343;
    i = zT_344;
    goto z_bb_63;
    z_bb_62:
    return;
    z_bb_63:
    if ((unsigned char)(i < children_n)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_346 = type_reg;
    zT_348 = store;
    zT_349 = decl_idx;
    zT_352 = zF_B10B1BC1_astStoreNodeExtraCh(zT_348, zT_349, (unsigned int)((unsigned int)i));
    zT_347 = zT_352;
    zF_A648B1CB_xnAppend(zT_346, zT_347);
    goto z_bb_66;
    z_bb_65:
    zT_356 = type_reg;
    zT_358.tags_start = tags_start_idx;
    zT_359 = (unsigned short)children_n;
    zT_358.tags_count = zT_359;
    zT_357 = zT_358;
    zF_B86143DD_esAppend(zT_356, zT_357);
    zT_361 = type_reg->es_len;
    zT_363 = zT_361 - (unsigned int)(1);
    es_last = zT_363;
    zT_365 = (unsigned int)es_last;
    es_idx = zT_365;
    zT_367 = type_reg->types_items;
    zT_368 = (unsigned int)tid;
    zT_369 = zT_367[zT_368];
    ty = zT_369;
    ty.payload_idx = es_idx;
    zT_370 = type_reg->types_items;
    zT_371 = (unsigned int)tid;
    zT_370[zT_371] = ty;
    goto z_bb_62;
    z_bb_66:
    zT_353 = 1;
    zT_355 = i + (unsigned int)((unsigned int)zT_353);
    i = zT_355;
    goto z_bb_63;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, unsigned char populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_3C598AEF_SymbolKind zT_57;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    zT_072B53A6_ModuleRegistry* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_79 = 0;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101 = 0;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned char zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_3C598AEF_SymbolKind zT_121;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_128;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    int zT_134;
    unsigned char* zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138 = 0;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_156;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    int zT_162;
    unsigned char* zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166 = 0;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_184;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    int zT_190;
    unsigned char* zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194 = 0;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208 = 0;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    zT_8143F551_AstKind zT_214;
    unsigned char zT_218;
    zT_8143F551_AstKind zT_219;
    unsigned char zT_223;
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    zT_8143F551_AstKind zT_229;
    zT_8143F551_AstKind zT_234;
    zT_33EF6BFB_TypeKind zT_235;
    unsigned char zT_236;
    int zT_240;
    zT_33EF6BFB_TypeKind zT_242;
    unsigned char zT_249;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char zT_258;
    int zT_260;
    int zT_262;
    zT_33EF6BFB_TypeKind zT_264;
    zT_338B7C76_TypeRegistry* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    unsigned int zT_277 = 0;
    zT_8143F551_AstKind zT_278;
    unsigned char zT_282;
    zT_8143F551_AstKind zT_283;
    unsigned char zT_287;
    unsigned char zT_288;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    zT_338B7C76_TypeRegistry* zT_296;
    zT_6B0A7D14_AstStore* zT_297;
    zT_8143F551_AstKind zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    zT_3D7259E2_SymbolRegistry* zT_301;
    zT_6B0A7D14_AstStore* zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    zT_4D61441E_DepGraph* zT_307;
    zT_3C598AEF_SymbolKind zT_310;
    zT_8143F551_AstKind zT_311;
    unsigned char* zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320;
    zT_6B0A7D14_AstStore* zT_321;
    unsigned int zT_322;
    unsigned int zT_324 = 0;
    zT_6B0A7D14_AstStore* zT_326;
    unsigned int zT_327;
    unsigned int zT_329 = 0;
    unsigned char* zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    unsigned int zT_335;
    zT_338B7C76_TypeRegistry* zT_337;
    zT_BAEE192E_Opt_10 zT_344 = {0};
    unsigned char zT_345;
    zT_338B7C76_TypeRegistry* zT_347;
    zT_BAEE192E_Opt_10 zT_350 = {0};
    unsigned char zT_351;
    unsigned char* zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_358;
    zT_79FAE712_u64 zT_364;
    zT_338B7C76_TypeRegistry* zT_365;
    zT_79FAE712_u64 zT_366;
    unsigned int zT_367;
    zT_3C598AEF_SymbolKind zT_369;
    unsigned char zT_371;
    zT_D3EB6303_StringInterner* zT_373;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    unsigned char* zT_378;
    unsigned int zT_380 = 0;
    zT_338B7C76_TypeRegistry* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386 = 0;
    zT_79FAE712_u64 zT_394;
    zT_338B7C76_TypeRegistry* zT_395;
    zT_79FAE712_u64 zT_396;
    unsigned int zT_397;
    zT_3C598AEF_SymbolKind zT_399;
    zT_8143F551_AstKind zT_400;
    unsigned char zT_404;
    zT_8143F551_AstKind zT_405;
    unsigned char zT_409;
    zT_8143F551_AstKind zT_410;
    unsigned char zT_414;
    zT_8143F551_AstKind zT_415;
    unsigned char zT_419;
    zT_8143F551_AstKind zT_420;
    unsigned char zT_424;
    zT_8143F551_AstKind zT_425;
    unsigned char zT_429;
    zT_8143F551_AstKind zT_430;
    unsigned char* zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    unsigned int zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_439;
    zT_338B7C76_TypeRegistry* zT_441;
    zT_BAEE192E_Opt_10 zT_448 = {0};
    unsigned char zT_449;
    zT_338B7C76_TypeRegistry* zT_451;
    zT_BAEE192E_Opt_10 zT_454 = {0};
    unsigned char zT_455;
    zT_3C598AEF_SymbolKind zT_458;
    zT_3A105EF1_Symbol zT_460;
    unsigned char zT_461;
    unsigned short zT_462;
    zT_E41AEC18_ModuleEntryArrayLis zT_463;
    zT_6E8D187B_ModuleEntry* zT_464;
    unsigned int zT_465;
    zT_6E8D187B_ModuleEntry zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    zT_3D7259E2_SymbolRegistry* zT_470;
    unsigned int zT_471;
    zT_060CD1EB_SymbolTable* zT_472 = 0;
    zT_060CD1EB_SymbolTable* zT_474;
    zT_3A105EF1_Symbol zT_475;
    unsigned char zT_476 = 0;
    unsigned char* zT_479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    unsigned char* zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_487;
    zT_4028D896_Arr_unsigned_char_2 zT_489;
    unsigned int zT_491;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_492;
    int zT_495;
    unsigned char* zT_496;
    unsigned int zT_497;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_498;
    unsigned int zT_499 = 0;
    unsigned int zT_505;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_506;
    unsigned char* zT_510;
    unsigned int zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned char* zT_514;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_515;
    unsigned int zT_516;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_517;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_520;
    int zT_524;
    unsigned char* zT_525;
    unsigned int zT_526;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_527;
    unsigned int zT_528 = 0;
    unsigned int zT_534;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_535;
    unsigned char* zT_539;
    unsigned int zT_540;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_541;
    unsigned char* zT_543;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_544;
    unsigned int zT_545;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_546;
    unsigned char* zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    unsigned int zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    zT_E2261874_anon_263683 zT_553;
    zT_243D6A41_FnProto* zT_554;
    zT_6B0A7D14_AstStore* zT_555;
    unsigned int zT_556;
    unsigned int zT_557 = 0;
    unsigned int zT_558;
    zT_243D6A41_FnProto zT_559;
    zT_3A105EF1_Symbol zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    zT_3C598AEF_SymbolKind zT_565;
    unsigned char zT_566;
    unsigned short zT_567;
    zT_E41AEC18_ModuleEntryArrayLis zT_568;
    zT_6E8D187B_ModuleEntry* zT_569;
    unsigned int zT_570;
    zT_6E8D187B_ModuleEntry zT_571;
    unsigned int zT_572;
    unsigned int zT_573;
    zT_3D7259E2_SymbolRegistry* zT_575;
    unsigned int zT_576;
    zT_060CD1EB_SymbolTable* zT_577 = 0;
    zT_060CD1EB_SymbolTable* zT_578;
    zT_3A105EF1_Symbol zT_579;
    unsigned char zT_580 = 0;
    zT_6B0A7D14_AstStore* zT_581;
    unsigned int zT_582;
    unsigned int zT_583 = 0;
    zT_3A105EF1_Symbol zT_587;
    zT_6B0A7D14_AstStore* zT_588;
    unsigned int zT_589;
    unsigned int zT_590 = 0;
    unsigned int zT_591;
    zT_3C598AEF_SymbolKind zT_593;
    unsigned char zT_594;
    unsigned short zT_595;
    zT_E41AEC18_ModuleEntryArrayLis zT_596;
    zT_6E8D187B_ModuleEntry* zT_597;
    unsigned int zT_598;
    zT_6E8D187B_ModuleEntry zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    zT_3D7259E2_SymbolRegistry* zT_603;
    unsigned int zT_604;
    zT_060CD1EB_SymbolTable* zT_605 = 0;
    zT_060CD1EB_SymbolTable* zT_606;
    zT_3A105EF1_Symbol zT_607;
    unsigned char zT_608 = 0;
    zT_6B0A7D14_AstStore* zT_610;
    unsigned int zT_611;
    zT_8143F551_AstKind zT_612;
    zT_79FAE712_u64 zT_614 = 0;
    unsigned int zT_617;
    zT_8143F551_AstKind zT_619;
    zT_33EF6BFB_TypeKind zT_620;
    unsigned char zT_621;
    int zT_625;
    zT_33EF6BFB_TypeKind zT_627;
    unsigned char zT_634;
    int zT_638;
    zT_33EF6BFB_TypeKind zT_640;
    unsigned char zT_643;
    int zT_645;
    int zT_647;
    zT_33EF6BFB_TypeKind zT_649;
    zT_338B7C76_TypeRegistry* zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_33EF6BFB_TypeKind zT_660;
    unsigned int zT_661 = 0;
    zT_8143F551_AstKind zT_662;
    unsigned char zT_666;
    zT_8143F551_AstKind zT_667;
    unsigned char zT_671;
    unsigned char zT_672;
    zT_338B7C76_TypeRegistry* zT_678;
    unsigned int zT_679;
    zT_338B7C76_TypeRegistry* zT_680;
    zT_6B0A7D14_AstStore* zT_681;
    zT_8143F551_AstKind zT_682;
    unsigned int zT_683;
    unsigned int zT_684;
    zT_3D7259E2_SymbolRegistry* zT_685;
    zT_6B0A7D14_AstStore* zT_687;
    unsigned int zT_688;
    unsigned int zT_689;
    zT_4D61441E_DepGraph* zT_690;
    zT_3A105EF1_Symbol zT_692;
    zT_3C598AEF_SymbolKind zT_694;
    unsigned char zT_695;
    unsigned short zT_696;
    zT_E41AEC18_ModuleEntryArrayLis zT_697;
    zT_6E8D187B_ModuleEntry* zT_698;
    unsigned int zT_699;
    zT_6E8D187B_ModuleEntry zT_700;
    unsigned int zT_701;
    unsigned int zT_702;
    zT_3D7259E2_SymbolRegistry* zT_704;
    unsigned int zT_705;
    zT_060CD1EB_SymbolTable* zT_706 = 0;
    zT_060CD1EB_SymbolTable* zT_707;
    zT_3A105EF1_Symbol zT_708;
    unsigned char zT_709 = 0;
    zT_6B0A7D14_AstStore* zT_711;
    unsigned int zT_712;
    zT_8143F551_AstKind zT_713;
    zT_79FAE712_u64 zT_715 = 0;
    unsigned int zT_718;
    zT_338B7C76_TypeRegistry* zT_720;
    unsigned int zT_721;
    unsigned int zT_722;
    unsigned int zT_726 = 0;
    zT_338B7C76_TypeRegistry* zT_727;
    zT_6B0A7D14_AstStore* zT_728;
    zT_8143F551_AstKind zT_729;
    unsigned int zT_730;
    unsigned int zT_731;
    zT_3D7259E2_SymbolRegistry* zT_732;
    zT_3A105EF1_Symbol zT_735;
    zT_3C598AEF_SymbolKind zT_737;
    unsigned char zT_738;
    unsigned short zT_739;
    zT_E41AEC18_ModuleEntryArrayLis zT_740;
    zT_6E8D187B_ModuleEntry* zT_741;
    unsigned int zT_742;
    zT_6E8D187B_ModuleEntry zT_743;
    unsigned int zT_744;
    unsigned int zT_745;
    zT_3D7259E2_SymbolRegistry* zT_747;
    unsigned int zT_748;
    zT_060CD1EB_SymbolTable* zT_749 = 0;
    zT_060CD1EB_SymbolTable* zT_750;
    zT_3A105EF1_Symbol zT_751;
    unsigned char zT_752 = 0;
    zT_6B0A7D14_AstStore* zT_754;
    unsigned int zT_755;
    unsigned int zT_756 = 0;
    zT_072B53A6_ModuleRegistry* zT_758;
    unsigned int zT_759;
    zT_BAEE192E_Opt_10 zT_760 = {0};
    unsigned char zT_761;
    zT_3A105EF1_Symbol zT_764;
    zT_338B7C76_TypeRegistry* zT_765;
    unsigned int zT_766;
    unsigned int zT_767 = 0;
    zT_3C598AEF_SymbolKind zT_769;
    unsigned short zT_770;
    zT_E41AEC18_ModuleEntryArrayLis zT_771;
    zT_6E8D187B_ModuleEntry* zT_772;
    unsigned int zT_773;
    zT_6E8D187B_ModuleEntry zT_774;
    unsigned int zT_775;
    unsigned int zT_776;
    zT_3D7259E2_SymbolRegistry* zT_778;
    unsigned int zT_779;
    zT_060CD1EB_SymbolTable* zT_780 = 0;
    zT_060CD1EB_SymbolTable* zT_781;
    zT_3A105EF1_Symbol zT_782;
    unsigned char zT_783 = 0;
    unsigned char* zT_785;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_786;
    unsigned int zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_790;
    unsigned int zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    int zT_796;
    unsigned char* zT_797;
    unsigned int zT_798;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_799;
    unsigned int zT_800 = 0;
    unsigned int zT_804;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_805;
    unsigned char* zT_809;
    unsigned int zT_810;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811;
    unsigned char* zT_813;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_814;
    unsigned int zT_815;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_816;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_818;
    unsigned int zT_820;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_821;
    int zT_824;
    unsigned char* zT_825;
    unsigned int zT_826;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_827;
    unsigned int zT_828 = 0;
    unsigned int zT_832;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_833;
    unsigned char* zT_837;
    unsigned int zT_838;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_839;
    unsigned char* zT_841;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_842;
    unsigned int zT_843;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_844;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    unsigned char inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    unsigned char arb_u;
    zT_8F083A69_Slice_zT_0B42B2F8_u ident_text;
    unsigned int arb_tid;
    zT_79FAE712_u64 atk;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_28[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_42 = (unsigned int)(19) - (unsigned int)((unsigned int)d12l);
    d12s = zT_42;
    zT_47 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_48 = (unsigned int)(19) - d12s;
    zT_49.ptr = zT_47;
    zT_49.len = zT_48;
    zT_43 = zT_49;
    zF_B5478454_measureMarkerWrite(zT_43);
    zT_51 = "\n";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    d12nl = zT_52;
    zT_54 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_54);
    zT_57 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_57;
    sym_mod_id = mod_id;
    zT_60 = 0;
    sym_type_id = zT_60;
    zT_61 = node.child_1;
    zT_62 = 0;
    if ((unsigned char)(zT_61 != (unsigned int)zT_62)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_553 = store->fn_protos;
    zT_554 = zT_553.items;
    zT_555 = store;
    zT_556 = decl_idx;
    zT_557 = zF_8BA26B9E_astStoreNodePayload(zT_555, zT_556);
    zT_558 = (unsigned int)zT_557;
    zT_559 = zT_554[zT_558];
    proto = zT_559;
    zT_562 = proto.name_id;
    zT_561.name_id = zT_562;
    zT_563 = 0;
    zT_561.type_id = zT_563;
    zT_565 = zT_3C598AEF_SymbolKind_function;
    zT_561.kind = zT_565;
    zT_566 = node.flags;
    zT_567 = (unsigned short)zT_566;
    zT_561.flags = zT_567;
    zT_561.decl_node = decl_idx;
    zT_561.module_id = mod_id;
    zT_568 = reg->modules;
    zT_569 = zT_568.items;
    zT_570 = (unsigned int)mod_id;
    zT_571 = zT_569[zT_570];
    zT_572 = zT_571.source_file_id;
    zT_561.file_id = zT_572;
    zT_573 = 0;
    zT_561.scope_level = zT_573;
    sym = zT_561;
    zT_575 = sym_reg;
    zT_576 = mod_id;
    zT_577 = zF_9B36C202_symbolRegistryGetTa(zT_575, zT_576);
    table = zT_577;
    zT_578 = table;
    zT_579 = sym;
    zT_580 = zF_D0156DDA_symbolTableInsert(zT_578, zT_579);
    (void)zT_580;
    goto z_bb_9;
    z_bb_3:
    zT_581 = store;
    zT_582 = decl_idx;
    zT_583 = zF_8BA26B9E_astStoreNodePayload(zT_581, zT_582);
    if ((unsigned char)(zT_583 != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_4:
    zT_610 = store;
    zT_611 = decl_idx;
    zT_612 = node.kind;
    zT_614 = zF_0E4E10C6_astStoreNodePayload(zT_610, zT_611, zT_612);
    zT_617 = (unsigned int)(zT_79FAE712_u64)(zT_614 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_617;
    zT_619 = node.kind;
switch (zT_619) {
case 3: goto z_bb_95;
case 4: goto z_bb_96;
case 5: goto z_bb_97;
default: goto z_bb_98;
}
    z_bb_5:
    zT_711 = store;
    zT_712 = decl_idx;
    zT_713 = node.kind;
    zT_715 = zF_0E4E10C6_astStoreNodePayload(zT_711, zT_712, zT_713);
    zT_718 = (unsigned int)(zT_79FAE712_u64)(zT_715 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_718;
    zT_720 = type_reg;
    zT_721 = mod_id;
    zT_722 = name_id;
    zT_726 = zF_3A64E2E0_typeRegistryRegiste(zT_720, zT_721, zT_722, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_726;
    if (populate) goto z_bb_120; else goto z_bb_121;
    z_bb_6:
    zT_754 = store;
    zT_755 = decl_idx;
    zT_756 = zF_8BA26B9E_astStoreNodePayload(zT_754, zT_755);
    path_id = zT_756;
    zT_758 = reg;
    zT_759 = path_id;
    zT_760 = zF_A258E183_moduleRegistryPathT(zT_758, zT_759);
    target_mod_id = zT_760;
    zT_761 = target_mod_id.has_value;
    if (zT_761) goto z_bb_122; else goto z_bb_123;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_65 = store;
    zT_66 = node.child_1;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    init_node = zT_68;
    zT_69 = init_node.kind;
    if ((unsigned char)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_460.name_id = name_id;
    zT_460.type_id = sym_type_id;
    zT_460.kind = sym_kind;
    zT_461 = node.flags;
    zT_462 = (unsigned short)zT_461;
    zT_460.flags = zT_462;
    zT_460.decl_node = decl_idx;
    zT_460.module_id = sym_mod_id;
    zT_463 = reg->modules;
    zT_464 = zT_463.items;
    zT_465 = (unsigned int)mod_id;
    zT_466 = zT_464[zT_465];
    zT_467 = zT_466.source_file_id;
    zT_460.file_id = zT_467;
    zT_468 = 0;
    zT_460.scope_level = zT_468;
    sym = zT_460;
    zT_470 = sym_reg;
    zT_471 = mod_id;
    zT_472 = zF_9B36C202_symbolRegistryGetTa(zT_470, zT_471);
    table = zT_472;
    zT_474 = table;
    zT_475 = sym;
    zT_476 = zF_D0156DDA_symbolTableInsert(zT_474, zT_475);
    inserted = zT_476;
    if ((unsigned char)(!inserted)) goto z_bb_91; else goto z_bb_92;
    z_bb_12:
    zT_74 = reg;
    zT_76 = store;
    zT_77 = node.child_1;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_76, zT_77);
    zT_75 = zT_79;
    zT_80 = zF_A258E183_moduleRegistryPathT(zT_74, zT_75);
    target = zT_80;
    zT_82 = "M5:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    m5m = zT_83;
    zT_85 = m5m;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_91 = store;
    zT_92 = node.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_94;
    zT_97 = 0;
    zT_98 = (unsigned char*)((unsigned char*)m5pb) + zT_97;
    zT_99 = (unsigned int)(20) - zT_97;
    zT_100.ptr = zT_98;
    zT_100.len = zT_99;
    zT_90 = zT_100;
    zT_101 = zF_A7504564_itoa(zT_89, zT_90);
    m5pl = zT_101;
    zT_105 = (unsigned int)(19) - (unsigned int)((unsigned int)m5pl);
    m5ps = zT_105;
    zT_110 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_111 = (unsigned int)(19) - m5ps;
    zT_112.ptr = zT_110;
    zT_112.len = zT_111;
    zT_106 = zT_112;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_113 = target.has_value;
    if (zT_113) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_214 = init_node.kind;
    if ((unsigned char)(zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    mtid = target.value;
    zT_116 = "Rs";
    zT_118 = 2;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    rs_msg = zT_117;
    zT_119 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_119);
    zT_121 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_121;
    sym_mod_id = mtid;
    zT_123 = "FIX1:mid=";
    zT_125 = 9;
    zT_124.ptr = zT_123;
    zT_124.len = zT_125;
    di_m = zT_124;
    zT_126 = di_m;
    zF_48AC7B3A_markerWrite(zT_126);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_128[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_128[_i];
        _i++;
    }
}
    zT_130 = sym_mod_id;
    zT_134 = 0;
    zT_135 = (unsigned char*)((unsigned char*)di_mb) + zT_134;
    zT_136 = (unsigned int)(10) - zT_134;
    zT_137.ptr = zT_135;
    zT_137.len = zT_136;
    zT_131 = zT_137;
    zT_138 = zF_A7504564_itoa(zT_130, zT_131);
    di_ml = zT_138;
    zT_142 = (unsigned int)(9) - (unsigned int)((unsigned int)di_ml);
    di_ms = zT_142;
    zT_147 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_148 = (unsigned int)(9) - di_ms;
    zT_149.ptr = zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zF_48AC7B3A_markerWrite(zT_143);
    zT_151 = "t";
    zT_153 = 1;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    di_t = zT_152;
    zT_154 = di_t;
    zF_48AC7B3A_markerWrite(zT_154);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_156[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_156[_i];
        _i++;
    }
}
    zT_158 = mtid;
    zT_162 = 0;
    zT_163 = (unsigned char*)((unsigned char*)di_tb) + zT_162;
    zT_164 = (unsigned int)(10) - zT_162;
    zT_165.ptr = zT_163;
    zT_165.len = zT_164;
    zT_159 = zT_165;
    zT_166 = zF_A7504564_itoa(zT_158, zT_159);
    di_tl = zT_166;
    zT_170 = (unsigned int)(9) - (unsigned int)((unsigned int)di_tl);
    di_ts = zT_170;
    zT_175 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_176 = (unsigned int)(9) - di_ts;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_179 = "n";
    zT_181 = 1;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    di_n = zT_180;
    zT_182 = di_n;
    zF_48AC7B3A_markerWrite(zT_182);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_184[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_184[_i];
        _i++;
    }
}
    zT_186 = mod_id;
    zT_190 = 0;
    zT_191 = (unsigned char*)((unsigned char*)di_nb) + zT_190;
    zT_192 = (unsigned int)(10) - zT_190;
    zT_193.ptr = zT_191;
    zT_193.len = zT_192;
    zT_187 = zT_193;
    zT_194 = zF_A7504564_itoa(zT_186, zT_187);
    di_nl = zT_194;
    zT_198 = (unsigned int)(9) - (unsigned int)((unsigned int)di_nl);
    di_ns = zT_198;
    zT_203 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_204 = (unsigned int)(9) - di_ns;
    zT_205.ptr = zT_203;
    zT_205.len = zT_204;
    zT_199 = zT_205;
    zF_48AC7B3A_markerWrite(zT_199);
    zT_206 = type_reg;
    zT_207 = mtid;
    zT_208 = zF_2ECA9F93_typeRegistryGetOrCr(zT_206, zT_207);
    sym_type_id = zT_208;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_210 = "Rf";
    zT_212 = 2;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    rf_msg = zT_211;
    zT_213 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_213);
    goto z_bb_15;
    z_bb_17:
    zT_219 = init_node.kind;
    zT_218 = zT_219 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_218 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_218) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_224 = init_node.kind;
    zT_223 = zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_223 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_223) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_229 = init_node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_228 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_228) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_234 = init_node.kind;
switch (zT_234) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_311 = init_node.kind;
    if ((unsigned char)(zT_311 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_55; else goto z_bb_57;
    z_bb_29:
    zT_236 = init_node.flags;
    zT_240 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_236) & (unsigned short)(32)) != zT_240)) goto z_bb_36; else goto z_bb_37;
    z_bb_30:
    zT_235 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_249 = init_node.flags;
    zT_253 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_249) & (unsigned short)(16)) != zT_253)) goto z_bb_39; else goto z_bb_40;
    z_bb_32:
    zT_235 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_235 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_235;
    zT_273 = type_reg;
    zT_274 = mod_id;
    zT_275 = name_id;
    zT_276 = type_kind;
    zT_277 = zF_3A64E2E0_typeRegistryRegiste(zT_273, zT_274, zT_275, zT_276);
    sym_type_id = zT_277;
    zT_278 = init_node.kind;
    if ((unsigned char)(zT_278 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_46; else goto z_bb_45;
    z_bb_36:
    zT_242 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_38;
    z_bb_37:
    zT_242 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_38;
    z_bb_38:
    zT_235 = zT_242;
    goto z_bb_35;
    z_bb_39:
    zT_255 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_258 = init_node.flags;
    zT_260 = 1;
    zT_262 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_258) & zT_260) != zT_262)) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_235 = zT_255;
    goto z_bb_35;
    z_bb_42:
    zT_264 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_44;
    z_bb_43:
    zT_264 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_44;
    z_bb_44:
    zT_255 = zT_264;
    goto z_bb_41;
    z_bb_45:
    zT_283 = init_node.kind;
    zT_282 = zT_283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_47;
    z_bb_46:
    zT_282 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_282) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_288 = init_node.flags;
    zT_287 = (unsigned short)((unsigned short)((unsigned short)zT_288) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_50;
    z_bb_49:
    zT_287 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_287) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_294 = type_reg;
    zT_295 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_294, zT_295);
    goto z_bb_52;
    z_bb_52:
    if (populate) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_296 = type_reg;
    zT_297 = store;
    zT_298 = init_node.kind;
    zT_299 = node.child_1;
    zT_300 = sym_type_id;
    zT_301 = sym_reg;
    zF_020995FB_populateTypePayload(zT_296, zT_297, zT_298, zT_299, zT_300, zT_301);
    goto z_bb_54;
    z_bb_54:
    zT_304 = store;
    zT_305 = node.child_1;
    zT_306 = sym_type_id;
    zT_307 = g;
    zF_4976C319_addTypeDependencies(zT_304, zT_305, zT_306, zT_307);
    zT_310 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_310;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_55:
    zT_316 = "RCA:p";
    zT_318 = 5;
    zT_317.ptr = zT_316;
    zT_317.len = zT_318;
    rca_m = zT_317;
    zT_319 = rca_m;
    zT_321 = store;
    zT_322 = node.child_1;
    zT_324 = zF_8BA26B9E_astStoreNodePayload(zT_321, zT_322);
    zT_320 = zT_324;
    zF_C914CB83_markerWriteInt(zT_319, zT_320);
    zT_326 = store;
    zT_327 = node.child_1;
    zT_329 = zF_53458827_astStoreIdentifier(zT_326, zT_327);
    ident_name_id = zT_329;
    zT_331 = "RCA:i";
    zT_333 = 5;
    zT_332.ptr = zT_331;
    zT_332.len = zT_333;
    rca_i = zT_332;
    zT_334 = rca_i;
    zT_335 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_334, zT_335);
    zT_337 = type_reg;
    zT_344 = zF_0EB68360_nameCacheGet(zT_337, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id)));
    cached = zT_344;
    zT_345 = cached.has_value;
    if ((unsigned char)(!zT_345)) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_27;
    z_bb_57:
    zT_400 = init_node.kind;
    if ((unsigned char)(zT_400 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_68; else goto z_bb_67;
    z_bb_58:
    zT_347 = type_reg;
    zT_350 = zF_0EB68360_nameCacheGet(zT_347, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_350;
    goto z_bb_59;
    z_bb_59:
    zT_351 = cached.has_value;
    if (zT_351) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    ct = cached.value;
    zT_354 = "RCA:H";
    zT_356 = 5;
    zT_355.ptr = zT_354;
    zT_355.len = zT_356;
    rca_h = zT_355;
    zT_357 = rca_h;
    zT_358 = ct;
    zF_C914CB83_markerWriteInt(zT_357, zT_358);
    zT_364 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    ck = zT_364;
    zT_365 = type_reg;
    zT_366 = ck;
    zT_367 = ct;
    zF_5E95558D_nameCachePut(zT_365, zT_366, zT_367);
    sym_type_id = ct;
    zT_369 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_369;
    sym_mod_id = mod_id;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_56;
    z_bb_62:
    zT_371 = 0;
    arb_u = zT_371;
    zT_373 = type_reg->interner;
    zT_374 = ident_name_id;
    zT_376 = zF_9134020D_stringInternerGet(zT_373, zT_374);
    ident_text = zT_376;
    zT_377 = ident_text;
    zT_378 = &arb_u;
    zT_380 = zF_741B5264_parseArbIntWidth(zT_377, zT_378);
    if ((unsigned char)(zT_380 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_384 = type_reg;
    zT_385 = ident_text;
    zT_386 = zF_B8CF3697_typeRegistryGetOrCr(zT_384, zT_385);
    arb_tid = zT_386;
    if ((unsigned char)(arb_tid != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_394 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    atk = zT_394;
    zT_395 = type_reg;
    zT_396 = atk;
    zT_397 = arb_tid;
    zF_5E95558D_nameCachePut(zT_395, zT_396, zT_397);
    sym_type_id = arb_tid;
    zT_399 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_399;
    sym_mod_id = mod_id;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_405 = init_node.kind;
    zT_404 = zT_405 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_69;
    z_bb_68:
    zT_404 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_404) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_410 = init_node.kind;
    zT_409 = zT_410 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_72;
    z_bb_71:
    zT_409 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_409) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_415 = init_node.kind;
    zT_414 = zT_415 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_414 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_414) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_420 = init_node.kind;
    zT_419 = zT_420 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_419 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_419) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_425 = init_node.kind;
    zT_424 = zT_425 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_424 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_424) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_430 = init_node.kind;
    zT_429 = zT_430 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_84;
    z_bb_83:
    zT_429 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_429) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_435 = "AT:p";
    zT_437 = 4;
    zT_436.ptr = zT_435;
    zT_436.len = zT_437;
    at_m = zT_436;
    zT_438 = at_m;
    zT_439 = name_id;
    zF_C914CB83_markerWriteInt(zT_438, zT_439);
    zT_441 = type_reg;
    zT_448 = zF_0EB68360_nameCacheGet(zT_441, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id)));
    acached = zT_448;
    zT_449 = acached.has_value;
    if ((unsigned char)(!zT_449)) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    goto z_bb_56;
    z_bb_87:
    zT_451 = type_reg;
    zT_454 = zF_0EB68360_nameCacheGet(zT_451, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_454;
    goto z_bb_88;
    z_bb_88:
    zT_455 = acached.has_value;
    if (zT_455) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    act = acached.value;
    sym_type_id = act;
    goto z_bb_90;
    z_bb_90:
    zT_458 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_458;
    sym_mod_id = mod_id;
    goto z_bb_86;
    z_bb_91:
    zT_479 = "VR";
    zT_481 = 2;
    zT_480.ptr = zT_479;
    zT_480.len = zT_481;
    vr = zT_480;
    zT_482 = vr;
    zF_48AC7B3A_markerWrite(zT_482);
    goto z_bb_92;
    z_bb_92:
    zT_484 = "VD";
    zT_486 = 2;
    zT_485.ptr = zT_484;
    zT_485.len = zT_486;
    vd = zT_485;
    zT_487 = vd;
    zF_48AC7B3A_markerWrite(zT_487);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_489[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_489[_i];
        _i++;
    }
}
    zT_491 = name_id;
    zT_495 = 0;
    zT_496 = (unsigned char*)((unsigned char*)vb) + zT_495;
    zT_497 = (unsigned int)(20) - zT_495;
    zT_498.ptr = zT_496;
    zT_498.len = zT_497;
    zT_492 = zT_498;
    zT_499 = zF_A7504564_itoa(zT_491, zT_492);
    vn = zT_499;
    zT_505 = (unsigned int)(19) - (unsigned int)((unsigned int)vn);
    vns = zT_505;
    zT_510 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_511 = (unsigned int)(20) - vns;
    zT_512.ptr = zT_510;
    zT_512.len = zT_511;
    zT_506 = zT_512;
    zF_48AC7B3A_markerWrite(zT_506);
    zT_514 = ":";
    zT_516 = 1;
    zT_515.ptr = zT_514;
    zT_515.len = zT_516;
    vc = zT_515;
    zT_517 = vc;
    zF_48AC7B3A_markerWrite(zT_517);
    zT_524 = 0;
    zT_525 = (unsigned char*)((unsigned char*)vb) + zT_524;
    zT_526 = (unsigned int)(20) - zT_524;
    zT_527.ptr = zT_525;
    zT_527.len = zT_526;
    zT_520 = zT_527;
    zT_528 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_520);
    vk = zT_528;
    zT_534 = (unsigned int)(19) - (unsigned int)((unsigned int)vk);
    vks = zT_534;
    zT_539 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_540 = (unsigned int)(20) - vks;
    zT_541.ptr = zT_539;
    zT_541.len = zT_540;
    zT_535 = zT_541;
    zF_48AC7B3A_markerWrite(zT_535);
    zT_543 = "\n";
    zT_545 = 1;
    zT_544.ptr = zT_543;
    zT_544.len = zT_545;
    ven = zT_544;
    zT_546 = ven;
    zF_48AC7B3A_markerWrite(zT_546);
    zT_548 = "Vi";
    zT_550 = 2;
    zT_549.ptr = zT_548;
    zT_549.len = zT_550;
    vi_msg = zT_549;
    zT_551 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_551);
    goto z_bb_9;
    z_bb_93:
    zT_588 = store;
    zT_589 = decl_idx;
    zT_590 = zF_8BA26B9E_astStoreNodePayload(zT_588, zT_589);
    zT_587.name_id = zT_590;
    zT_591 = 0;
    zT_587.type_id = zT_591;
    zT_593 = zT_3C598AEF_SymbolKind_test_sym;
    zT_587.kind = zT_593;
    zT_594 = node.flags;
    zT_595 = (unsigned short)zT_594;
    zT_587.flags = zT_595;
    zT_587.decl_node = decl_idx;
    zT_587.module_id = mod_id;
    zT_596 = reg->modules;
    zT_597 = zT_596.items;
    zT_598 = (unsigned int)mod_id;
    zT_599 = zT_597[zT_598];
    zT_600 = zT_599.source_file_id;
    zT_587.file_id = zT_600;
    zT_601 = 0;
    zT_587.scope_level = zT_601;
    sym = zT_587;
    zT_603 = sym_reg;
    zT_604 = mod_id;
    zT_605 = zF_9B36C202_symbolRegistryGetTa(zT_603, zT_604);
    table = zT_605;
    zT_606 = table;
    zT_607 = sym;
    zT_608 = zF_D0156DDA_symbolTableInsert(zT_606, zT_607);
    (void)zT_608;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_9;
    z_bb_95:
    zT_621 = node.flags;
    zT_625 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_621) & (unsigned short)(32)) != zT_625)) goto z_bb_101; else goto z_bb_102;
    z_bb_96:
    zT_620 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_100;
    z_bb_97:
    zT_634 = node.flags;
    zT_638 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_634) & (unsigned short)(16)) != zT_638)) goto z_bb_104; else goto z_bb_105;
    z_bb_98:
    zT_620 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_100;
    z_bb_100:
    type_kind = zT_620;
    zT_657 = type_reg;
    zT_658 = mod_id;
    zT_659 = name_id;
    zT_660 = type_kind;
    zT_661 = zF_3A64E2E0_typeRegistryRegiste(zT_657, zT_658, zT_659, zT_660);
    tid = zT_661;
    zT_662 = node.kind;
    if ((unsigned char)(zT_662 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_111; else goto z_bb_110;
    z_bb_101:
    zT_627 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_103;
    z_bb_102:
    zT_627 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_103;
    z_bb_103:
    zT_620 = zT_627;
    goto z_bb_100;
    z_bb_104:
    zT_640 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_106;
    z_bb_105:
    zT_643 = node.flags;
    zT_645 = 1;
    zT_647 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_643) & zT_645) != zT_647)) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_620 = zT_640;
    goto z_bb_100;
    z_bb_107:
    zT_649 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_109;
    z_bb_108:
    zT_649 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_109;
    z_bb_109:
    zT_640 = zT_649;
    goto z_bb_106;
    z_bb_110:
    zT_667 = node.kind;
    zT_666 = zT_667 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_112;
    z_bb_111:
    zT_666 = 1;
    goto z_bb_112;
    z_bb_112:
    if (zT_666) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_672 = node.flags;
    zT_671 = (unsigned short)((unsigned short)((unsigned short)zT_672) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_115;
    z_bb_114:
    zT_671 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_671) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_678 = type_reg;
    zT_679 = tid;
    zF_52816016_typeRegistrySetPack(zT_678, zT_679);
    goto z_bb_117;
    z_bb_117:
    if (populate) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_680 = type_reg;
    zT_681 = store;
    zT_682 = node.kind;
    zT_683 = decl_idx;
    zT_684 = tid;
    zT_685 = sym_reg;
    zF_020995FB_populateTypePayload(zT_680, zT_681, zT_682, zT_683, zT_684, zT_685);
    goto z_bb_119;
    z_bb_119:
    zT_687 = store;
    zT_688 = decl_idx;
    zT_689 = tid;
    zT_690 = g;
    zF_4976C319_addTypeDependencies(zT_687, zT_688, zT_689, zT_690);
    zT_692.name_id = name_id;
    zT_692.type_id = tid;
    zT_694 = zT_3C598AEF_SymbolKind_type_alias;
    zT_692.kind = zT_694;
    zT_695 = node.flags;
    zT_696 = (unsigned short)zT_695;
    zT_692.flags = zT_696;
    zT_692.decl_node = decl_idx;
    zT_692.module_id = mod_id;
    zT_697 = reg->modules;
    zT_698 = zT_697.items;
    zT_699 = (unsigned int)mod_id;
    zT_700 = zT_698[zT_699];
    zT_701 = zT_700.source_file_id;
    zT_692.file_id = zT_701;
    zT_702 = 0;
    zT_692.scope_level = zT_702;
    sym = zT_692;
    zT_704 = sym_reg;
    zT_705 = mod_id;
    zT_706 = zF_9B36C202_symbolRegistryGetTa(zT_704, zT_705);
    table = zT_706;
    zT_707 = table;
    zT_708 = sym;
    zT_709 = zF_D0156DDA_symbolTableInsert(zT_707, zT_708);
    (void)zT_709;
    goto z_bb_9;
    z_bb_120:
    zT_727 = type_reg;
    zT_728 = store;
    zT_729 = node.kind;
    zT_730 = decl_idx;
    zT_731 = tid;
    zT_732 = sym_reg;
    zF_020995FB_populateTypePayload(zT_727, zT_728, zT_729, zT_730, zT_731, zT_732);
    goto z_bb_121;
    z_bb_121:
    zT_735.name_id = name_id;
    zT_735.type_id = tid;
    zT_737 = zT_3C598AEF_SymbolKind_type_alias;
    zT_735.kind = zT_737;
    zT_738 = node.flags;
    zT_739 = (unsigned short)zT_738;
    zT_735.flags = zT_739;
    zT_735.decl_node = decl_idx;
    zT_735.module_id = mod_id;
    zT_740 = reg->modules;
    zT_741 = zT_740.items;
    zT_742 = (unsigned int)mod_id;
    zT_743 = zT_741[zT_742];
    zT_744 = zT_743.source_file_id;
    zT_735.file_id = zT_744;
    zT_745 = 0;
    zT_735.scope_level = zT_745;
    sym = zT_735;
    zT_747 = sym_reg;
    zT_748 = mod_id;
    zT_749 = zF_9B36C202_symbolRegistryGetTa(zT_747, zT_748);
    table = zT_749;
    zT_750 = table;
    zT_751 = sym;
    zT_752 = zF_D0156DDA_symbolTableInsert(zT_750, zT_751);
    (void)zT_752;
    goto z_bb_9;
    z_bb_122:
    tid = target_mod_id.value;
    zT_764.name_id = path_id;
    zT_765 = type_reg;
    zT_766 = tid;
    zT_767 = zF_2ECA9F93_typeRegistryGetOrCr(zT_765, zT_766);
    zT_764.type_id = zT_767;
    zT_769 = zT_3C598AEF_SymbolKind_module;
    zT_764.kind = zT_769;
    zT_770 = 0;
    zT_764.flags = zT_770;
    zT_764.decl_node = decl_idx;
    zT_764.module_id = tid;
    zT_771 = reg->modules;
    zT_772 = zT_771.items;
    zT_773 = (unsigned int)mod_id;
    zT_774 = zT_772[zT_773];
    zT_775 = zT_774.source_file_id;
    zT_764.file_id = zT_775;
    zT_776 = 0;
    zT_764.scope_level = zT_776;
    sym = zT_764;
    zT_778 = sym_reg;
    zT_779 = mod_id;
    zT_780 = zF_9B36C202_symbolRegistryGetTa(zT_778, zT_779);
    table = zT_780;
    zT_781 = table;
    zT_782 = sym;
    zT_783 = zF_D0156DDA_symbolTableInsert(zT_781, zT_782);
    (void)zT_783;
    zT_785 = "IMR:n";
    zT_787 = 5;
    zT_786.ptr = zT_785;
    zT_786.len = zT_787;
    imr = zT_786;
    zT_788 = imr;
    zF_48AC7B3A_markerWrite(zT_788);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_790[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_790[_i];
        _i++;
    }
}
    zT_792 = path_id;
    zT_796 = 0;
    zT_797 = (unsigned char*)((unsigned char*)imb) + zT_796;
    zT_798 = (unsigned int)(10) - zT_796;
    zT_799.ptr = zT_797;
    zT_799.len = zT_798;
    zT_793 = zT_799;
    zT_800 = zF_A7504564_itoa(zT_792, zT_793);
    iml = zT_800;
    zT_804 = (unsigned int)(9) - (unsigned int)((unsigned int)iml);
    ims = zT_804;
    zT_809 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_810 = (unsigned int)(9) - ims;
    zT_811.ptr = zT_809;
    zT_811.len = zT_810;
    zT_805 = zT_811;
    zF_48AC7B3A_markerWrite(zT_805);
    zT_813 = "m";
    zT_815 = 1;
    zT_814.ptr = zT_813;
    zT_814.len = zT_815;
    imm = zT_814;
    zT_816 = imm;
    zF_48AC7B3A_markerWrite(zT_816);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_818[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_818[_i];
        _i++;
    }
}
    zT_820 = tid;
    zT_824 = 0;
    zT_825 = (unsigned char*)((unsigned char*)immb) + zT_824;
    zT_826 = (unsigned int)(10) - zT_824;
    zT_827.ptr = zT_825;
    zT_827.len = zT_826;
    zT_821 = zT_827;
    zT_828 = zF_A7504564_itoa(zT_820, zT_821);
    imml = zT_828;
    zT_832 = (unsigned int)(9) - (unsigned int)((unsigned int)imml);
    imms = zT_832;
    zT_837 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_838 = (unsigned int)(9) - imms;
    zT_839.ptr = zT_837;
    zT_839.len = zT_838;
    zT_833 = zT_839;
    zF_48AC7B3A_markerWrite(zT_833);
    zT_841 = " ";
    zT_843 = 1;
    zT_842.ptr = zT_841;
    zT_842.len = zT_843;
    imsnl = zT_842;
    zT_844 = imsnl;
    zF_48AC7B3A_markerWrite(zT_844);
    goto z_bb_123;
    z_bb_123:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, unsigned char populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned char zT_16;
    zT_9FE1BFFE_ModuleState zT_17;
    unsigned char zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    zT_79FAE712_u64 zT_56 = 0;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66 = 0;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned char* zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    int zT_84;
    unsigned int zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_98 = 0;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_130 = 0;
    zT_22A7C88B_AstNode zT_131 = {0};
    zT_8143F551_AstKind zT_133;
    unsigned int zT_134;
    zT_4028D896_Arr_unsigned_char_2 zT_136;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146 = 0;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    int zT_163;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int zT_172;
    unsigned int zT_173;
    zT_3D7259E2_SymbolRegistry* zT_176;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_4D61441E_DepGraph* zT_181;
    zT_072B53A6_ModuleRegistry* zT_182;
    unsigned char zT_183;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    unsigned int zT_189 = 0;
    int zT_190;
    unsigned int zT_192;
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((unsigned char)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = entry.state;
    zT_16 = zT_17 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = entry.ast_root;
    zT_23 = 0;
    zT_21 = zT_22 == (unsigned int)zT_23;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = store;
    zT_27 = entry.ast_root;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    root = zT_29;
    zT_30 = root.kind;
    if ((unsigned char)(zT_30 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_35 = store;
    zT_36 = entry.ast_root;
    zT_38 = zF_152E19CB_astStoreNodeExtraCh(zT_35, zT_36);
    decls_n = zT_38;
    if ((unsigned char)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = "RS";
    zT_44 = 2;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    dg = zT_43;
    zT_45 = dg;
    zF_48AC7B3A_markerWrite(zT_45);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = store;
    zT_52 = entry.ast_root;
    zT_53 = root.kind;
    zT_56 = zF_0E4E10C6_astStoreNodePayload(zT_51, zT_52, zT_53);
    zT_62 = 0;
    zT_63 = (unsigned char*)((unsigned char*)pb) + zT_62;
    zT_64 = (unsigned int)(20) - zT_62;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_50 = zT_65;
    zT_66 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_56 & (zT_79FAE712_u64)(4294967295u))), zT_50);
    pl = zT_66;
    zT_70 = (unsigned int)(19) - (unsigned int)((unsigned int)pl);
    ps = zT_70;
    zT_75 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_76 = (unsigned int)(19) - ps;
    zT_77.ptr = zT_75;
    zT_77.len = zT_76;
    zT_71 = zT_77;
    zF_48AC7B3A_markerWrite(zT_71);
    zT_79 = ":";
    zT_81 = 1;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    sc = zT_80;
    zT_82 = sc;
    zF_48AC7B3A_markerWrite(zT_82);
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    i2 = zT_85;
    goto z_bb_13;
    z_bb_12:
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    i = zT_173;
    goto z_bb_17;
    z_bb_13:
    if ((unsigned char)(i2 < (unsigned int)((unsigned int)decls_n))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_89[_i];
        _i++;
    }
}
    zT_93 = store;
    zT_94 = entry.ast_root;
    zT_98 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)i2));
    zT_91 = zT_98;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)ii_buf) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = zT_102;
    zT_104.len = zT_103;
    zT_92 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_91, zT_92);
    ii_len = zT_105;
    zT_109 = (unsigned int)(19) - (unsigned int)((unsigned int)ii_len);
    ii_start = zT_109;
    zT_114 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_115 = (unsigned int)(19) - ii_start;
    zT_116.ptr = zT_114;
    zT_116.len = zT_115;
    zT_110 = zT_116;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_118 = "=";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    ss = zT_119;
    zT_121 = ss;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_123 = store;
    zT_125 = store;
    zT_126 = entry.ast_root;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_125, zT_126, (unsigned int)((unsigned int)i2));
    zT_124 = zT_130;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_123, zT_124);
    dc = zT_131;
    zT_133 = dc.kind;
    zT_134 = (unsigned int)zT_133;
    dk = zT_134;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_136[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_136[_i];
        _i++;
    }
}
    zT_138 = dk;
    zT_142 = 0;
    zT_143 = (unsigned char*)((unsigned char*)db) + zT_142;
    zT_144 = (unsigned int)(20) - zT_142;
    zT_145.ptr = zT_143;
    zT_145.len = zT_144;
    zT_139 = zT_145;
    zT_146 = zF_A7504564_itoa(zT_138, zT_139);
    dl = zT_146;
    zT_150 = (unsigned int)(19) - (unsigned int)((unsigned int)dl);
    ds = zT_150;
    zT_155 = (unsigned char*)((unsigned char*)db) + ds;
    zT_156 = (unsigned int)(19) - ds;
    zT_157.ptr = zT_155;
    zT_157.len = zT_156;
    zT_151 = zT_157;
    zF_48AC7B3A_markerWrite(zT_151);
    zT_159 = " ";
    zT_161 = 1;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    dsp = zT_160;
    zT_162 = dsp;
    zF_48AC7B3A_markerWrite(zT_162);
    goto z_bb_16;
    z_bb_15:
    zT_167 = "\n";
    zT_169 = 1;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    dn = zT_168;
    zT_170 = dn;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_163 = 1;
    zT_165 = i2 + (unsigned int)((unsigned int)zT_163);
    i2 = zT_165;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(i < (unsigned int)((unsigned int)decls_n))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_176 = sym_reg;
    zT_177 = type_reg;
    zT_178 = store;
    zT_179 = module_id;
    zT_184 = store;
    zT_185 = entry.ast_root;
    zT_189 = zF_B10B1BC1_astStoreNodeExtraCh(zT_184, zT_185, (unsigned int)((unsigned int)i));
    zT_180 = zT_189;
    zT_181 = g;
    zT_182 = reg;
    zT_183 = populate;
    zF_CBEB26BC_registerDecl(zT_176, zT_177, zT_178, zT_179, zT_180, zT_181, zT_182, zT_183);
    zT_190 = 1;
    zT_192 = i + (unsigned int)((unsigned int)zT_190);
    i = zT_192;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_19(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_33EF6BFB_TypeKind zT_1 = 0;
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
