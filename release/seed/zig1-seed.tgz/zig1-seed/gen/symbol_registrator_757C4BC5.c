#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zT_5 = 0;
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_6F32B01B_Opt_235 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_C6536882_EU_532 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->items;
    zT_25 = self->cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->items;
    zT_48 = self->len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    self->len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_9;
    zT_C6536882_EU_532 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_52CDA6EF_DepEdge* zT_35;
    zT_52CDA6EF_DepEdge zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    zT_52CDA6EF_DepEdge* zT_43;
    zT_52CDA6EF_DepEdge zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_5 = (unsigned int)(unsigned int)(max_type_id + (unsigned int)(1));
    count = zT_5;
    zT_6 = self->in_degree_cap;
    if ((int)(count > zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_9, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_6;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((int)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    zT_26 = self->in_degree_items;
    zT_26[i] = zT_25;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_32 = self->len;
    if ((int)(i < zT_32)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self->in_degree_items;
    zT_35 = self->items;
    zT_36 = zT_35[i];
    zT_37 = zT_36.to;
    zT_38 = zT_34[zT_37];
    zT_39 = 1;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    zT_42 = self->in_degree_items;
    zT_43 = self->items;
    zT_44 = zT_43[i];
    zT_45 = zT_44.to;
    zT_42[zT_45] = zT_41;
    zT_46 = 1;
    zT_48 = i + (unsigned int)((unsigned int)zT_46);
    i = zT_48;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_28 = 0;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_4D61441E_DepGraph* zT_35;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_41;
    unsigned int children_n;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((int)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_14, zT_15);
    children_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((int)(i < children_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = store;
    zT_24 = store;
    zT_25 = decl_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_24, zT_25, (unsigned int)((unsigned int)i));
    zT_23 = zT_28;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    field_node = zT_29;
    zT_30 = field_node.kind;
    if ((int)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_35 = g;
    zT_37 = tid;
    zF_AA751A34_depGraphAddEdge(zT_35, (unsigned int)(0), zT_37);
    goto z_bb_8;
    z_bb_8:
    zT_39 = 1;
    zT_41 = i + (unsigned int)((unsigned int)zT_39);
    i = zT_41;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    int zT_18;
    unsigned int zT_25;
    unsigned int zT_26;
    int zT_28;
    unsigned int zT_29;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_41 = 0;
    zT_22A7C88B_AstNode zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    zT_338B7C76_TypeRegistry* zT_48;
    zT_2DF01B61_FieldEntry zT_49;
    zT_2DF01B61_FieldEntry zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_57 = 0;
    unsigned int zT_58 = 0;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_66;
    int zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_406493CE_StructPayload zT_70;
    zT_406493CE_StructPayload zT_71;
    unsigned int zT_72;
    unsigned short zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    unsigned int zT_79;
    zT_D155D06D_Type* zT_81;
    unsigned int zT_82;
    unsigned int zT_85;
    zT_D155D06D_Type zT_86;
    zT_D155D06D_Type* zT_87;
    unsigned int zT_88;
    unsigned int zT_91;
    unsigned int zT_97;
    unsigned int zT_98;
    int zT_100;
    unsigned int zT_101;
    int zT_103;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    unsigned int zT_113 = 0;
    zT_22A7C88B_AstNode zT_114 = {0};
    zT_8143F551_AstKind zT_115;
    zT_338B7C76_TypeRegistry* zT_120;
    zT_2DF01B61_FieldEntry zT_121;
    zT_2DF01B61_FieldEntry zT_122;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_129 = 0;
    unsigned int zT_130 = 0;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_133;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_138;
    unsigned char zT_139;
    int zT_141;
    int zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_54FF90FA_TaggedUnionPayload zT_146;
    zT_54FF90FA_TaggedUnionPayload zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned short zT_150;
    unsigned int zT_152;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_D155D06D_Type* zT_158;
    unsigned int zT_159;
    unsigned int zT_162;
    zT_D155D06D_Type zT_163;
    zT_D155D06D_Type* zT_164;
    unsigned int zT_165;
    unsigned int zT_168;
    zT_338B7C76_TypeRegistry* zT_169;
    zT_AF9231A2_UnionPayload zT_170;
    zT_AF9231A2_UnionPayload zT_171;
    unsigned int zT_172;
    unsigned short zT_173;
    unsigned int zT_174;
    unsigned int zT_176;
    unsigned int zT_178;
    unsigned int zT_180;
    zT_D155D06D_Type* zT_182;
    unsigned int zT_183;
    unsigned int zT_186;
    zT_D155D06D_Type zT_187;
    zT_D155D06D_Type* zT_188;
    unsigned int zT_189;
    unsigned int zT_192;
    zT_ABC1EBBE_TypeResolveEnv zT_198;
    zT_D3EB6303_StringInterner* zT_199;
    unsigned int zT_201;
    zT_7334F4FE_Opt_225 zT_202 = {0};
    zT_F8B96B9C_Opt_393 zT_203 = {0};
    zT_939EE900_Arr_unsigned_int_1 zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    int zT_209;
    unsigned char zT_211;
    unsigned int zT_212;
    int zT_213;
    zT_ABC1EBBE_TypeResolveEnv* zT_216;
    unsigned int zT_217;
    unsigned int zT_222 = 0;
    int zT_225;
    int zT_228;
    unsigned char zT_229;
    unsigned int zT_231;
    unsigned int zT_232;
    int zT_234;
    unsigned int zT_235;
    zT_C69B2266_i64 zT_237;
    int zT_239;
    unsigned int zT_240;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_244;
    zT_6B0A7D14_AstStore* zT_245;
    unsigned int zT_246;
    unsigned int zT_249 = 0;
    zT_22A7C88B_AstNode zT_250 = {0};
    zT_8143F551_AstKind zT_251;
    unsigned int zT_257;
    int zT_258;
    zT_ABC1EBBE_TypeResolveEnv* zT_261;
    unsigned int zT_262;
    zT_44E16D78_Opt_7 zT_265 = {0};
    unsigned char zT_266;
    zT_338B7C76_TypeRegistry* zT_268;
    zT_D96DCDF2_EnumMember zT_269;
    zT_D96DCDF2_EnumMember zT_270;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    zT_6B0A7D14_AstStore* zT_273;
    unsigned int zT_274;
    unsigned int zT_277 = 0;
    unsigned int zT_278 = 0;
    int zT_279;
    unsigned int zT_281;
    zT_C69B2266_i64 zT_283;
    int zT_284;
    unsigned int zT_286;
    zT_338B7C76_TypeRegistry* zT_287;
    zT_457ECFEE_EnumPayload zT_288;
    zT_457ECFEE_EnumPayload zT_289;
    unsigned int zT_290;
    unsigned short zT_291;
    int zT_292;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned int zT_297;
    unsigned int zT_299;
    zT_D155D06D_Type* zT_301;
    unsigned int zT_302;
    unsigned int zT_305;
    zT_D155D06D_Type zT_306;
    zT_D155D06D_Type* zT_307;
    unsigned int zT_308;
    unsigned int zT_311;
    unsigned int zT_317;
    unsigned int zT_318;
    int zT_320;
    unsigned int zT_321;
    zT_338B7C76_TypeRegistry* zT_323;
    unsigned int zT_324;
    zT_6B0A7D14_AstStore* zT_325;
    unsigned int zT_326;
    unsigned int zT_329 = 0;
    int zT_330;
    unsigned int zT_332;
    zT_338B7C76_TypeRegistry* zT_333;
    zT_0B73C507_ErrorSetPayload zT_334;
    zT_0B73C507_ErrorSetPayload zT_335;
    unsigned short zT_336;
    unsigned int zT_338;
    unsigned int zT_340;
    unsigned int zT_342;
    zT_D155D06D_Type* zT_344;
    unsigned int zT_345;
    unsigned int zT_348;
    zT_D155D06D_Type zT_349;
    zT_D155D06D_Type* zT_350;
    unsigned int zT_351;
    unsigned int zT_354;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    zT_C69B2266_i64 auto_val;
    zT_22A7C88B_AstNode mnode;
    unsigned int en_last;
    unsigned int en_idx;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_6 = store;
    zT_7 = decl_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    if ((int)(zT_11 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_15 = store;
    zT_16 = decl_idx;
    zT_17 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    children_n = zT_17;
    zT_18 = 0;
    if ((int)(children_n == (unsigned int)zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = type_reg->fe_len;
    zT_26 = (unsigned int)zT_25;
    fstart = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    fcount = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    i = zT_32;
    goto z_bb_7;
    z_bb_6:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_7:
    if ((int)(i < children_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = store;
    zT_37 = store;
    zT_38 = decl_idx;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)i));
    zT_36 = zT_41;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_42;
    zT_43 = fd.kind;
    if ((int)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_67 = 0;
    if ((int)(fcount > (unsigned int)zT_67)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_48 = type_reg;
    zT_51 = store;
    zT_53 = store;
    zT_54 = decl_idx;
    zT_57 = zF_B10B1BC1_astStoreNodeExtraCh(zT_53, zT_54, (unsigned int)((unsigned int)i));
    zT_52 = zT_57;
    zT_58 = zF_8BA26B9E_astStoreNodePayload(zT_51, zT_52);
    zT_50.name_id = zT_58;
    zT_59 = 1;
    zT_50.type_id = zT_59;
    zT_60 = 0;
    zT_50.offset = zT_60;
    zT_49 = zT_50;
    zF_701DF154_feAppend(zT_48, zT_49);
    zT_61 = 1;
    zT_63 = fcount + (unsigned int)((unsigned int)zT_61);
    fcount = zT_63;
    goto z_bb_12;
    z_bb_12:
    zT_64 = 1;
    zT_66 = i + (unsigned int)((unsigned int)zT_64);
    i = zT_66;
    goto z_bb_10;
    z_bb_13:
    zT_69 = type_reg;
    zT_72 = (unsigned int)fstart;
    zT_71.fields_start = zT_72;
    zT_73 = (unsigned short)fcount;
    zT_71.fields_count = zT_73;
    zT_70 = zT_71;
    zF_CF849366_stAppend(zT_69, zT_70);
    goto z_bb_14;
    z_bb_14:
    zT_75 = type_reg->st_len;
    zT_77 = zT_75 - (unsigned int)(1);
    st_last = zT_77;
    zT_79 = (unsigned int)st_last;
    st_idx = zT_79;
    zT_81 = type_reg->types_items;
    zT_82 = type_reg->types_len;
    zT_85 = (unsigned int)(unsigned int)(zT_82 - (unsigned int)(1));
    zT_86 = zT_81[zT_85];
    ty = zT_86;
    ty.payload_idx = st_idx;
    zT_87 = type_reg->types_items;
    zT_88 = type_reg->types_len;
    zT_91 = (unsigned int)(unsigned int)(zT_88 - (unsigned int)(1));
    zT_87[zT_91] = ty;
    goto z_bb_6;
    z_bb_15:
    zT_97 = type_reg->fe_len;
    zT_98 = (unsigned int)zT_97;
    fstart = zT_98;
    zT_100 = 0;
    zT_101 = (unsigned int)zT_100;
    fcount = zT_101;
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    i = zT_104;
    goto z_bb_17;
    z_bb_16:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_26; else goto z_bb_27;
    z_bb_17:
    if ((int)(i < children_n)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_107 = store;
    zT_109 = store;
    zT_110 = decl_idx;
    zT_113 = zF_B10B1BC1_astStoreNodeExtraCh(zT_109, zT_110, (unsigned int)((unsigned int)i));
    zT_108 = zT_113;
    zT_114 = zF_FCDD1D35_astStoreNodeAt(zT_107, zT_108);
    fd = zT_114;
    zT_115 = fd.kind;
    if ((int)(zT_115 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_139 = node.flags;
    zT_141 = 1;
    zT_143 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_139) & zT_141) != zT_143)) goto z_bb_23; else goto z_bb_25;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_120 = type_reg;
    zT_123 = store;
    zT_125 = store;
    zT_126 = decl_idx;
    zT_129 = zF_B10B1BC1_astStoreNodeExtraCh(zT_125, zT_126, (unsigned int)((unsigned int)i));
    zT_124 = zT_129;
    zT_130 = zF_8BA26B9E_astStoreNodePayload(zT_123, zT_124);
    zT_122.name_id = zT_130;
    zT_131 = 1;
    zT_122.type_id = zT_131;
    zT_132 = 0;
    zT_122.offset = zT_132;
    zT_121 = zT_122;
    zF_701DF154_feAppend(zT_120, zT_121);
    zT_133 = 1;
    zT_135 = fcount + (unsigned int)((unsigned int)zT_133);
    fcount = zT_135;
    goto z_bb_22;
    z_bb_22:
    zT_136 = 1;
    zT_138 = i + (unsigned int)((unsigned int)zT_136);
    i = zT_138;
    goto z_bb_20;
    z_bb_23:
    zT_145 = type_reg;
    zT_148 = 10;
    zT_147.tag_type = zT_148;
    zT_149 = (unsigned int)fstart;
    zT_147.fields_start = zT_149;
    zT_150 = (unsigned short)fcount;
    zT_147.fields_count = zT_150;
    zT_146 = zT_147;
    zF_FB6B57C6_tuAppend(zT_145, zT_146);
    zT_152 = type_reg->tu_len;
    zT_154 = zT_152 - (unsigned int)(1);
    tu_last = zT_154;
    zT_156 = (unsigned int)tu_last;
    tu_idx = zT_156;
    zT_158 = type_reg->types_items;
    zT_159 = type_reg->types_len;
    zT_162 = (unsigned int)(unsigned int)(zT_159 - (unsigned int)(1));
    zT_163 = zT_158[zT_162];
    ty = zT_163;
    ty.payload_idx = tu_idx;
    zT_164 = type_reg->types_items;
    zT_165 = type_reg->types_len;
    zT_168 = (unsigned int)(unsigned int)(zT_165 - (unsigned int)(1));
    zT_164[zT_168] = ty;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_16;
    z_bb_25:
    zT_169 = type_reg;
    zT_172 = (unsigned int)fstart;
    zT_171.fields_start = zT_172;
    zT_173 = (unsigned short)fcount;
    zT_171.fields_count = zT_173;
    zT_174 = 1;
    zT_171.tag_type = zT_174;
    zT_170 = zT_171;
    zF_1718422E_unAppend(zT_169, zT_170);
    zT_176 = type_reg->un_len;
    zT_178 = zT_176 - (unsigned int)(1);
    un_last = zT_178;
    zT_180 = (unsigned int)un_last;
    un_idx = zT_180;
    zT_182 = type_reg->types_items;
    zT_183 = type_reg->types_len;
    zT_186 = (unsigned int)(unsigned int)(zT_183 - (unsigned int)(1));
    zT_187 = zT_182[zT_186];
    ty = zT_187;
    ty.payload_idx = un_idx;
    zT_188 = type_reg->types_items;
    zT_189 = type_reg->types_len;
    zT_192 = (unsigned int)(unsigned int)(zT_189 - (unsigned int)(1));
    zT_188[zT_192] = ty;
    goto z_bb_24;
    z_bb_26:
    zT_198.store = store;
    zT_198.typereg = type_reg;
    zT_198.symbol_reg = sym_reg;
    zT_199 = type_reg->interner;
    zT_198.interner = zT_199;
    zT_198.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_201 = 0;
    zT_198.source_file_id = zT_201;
    zT_202.has_value = 0;
    zT_198.diag = zT_202;
    zT_203.has_value = 0;
    zT_198.local_consts = zT_203;
    tre_env = zT_198;
    zT_206 = 0;
    zT_207 = 0;
    zT_205[zT_207] = zT_206;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_205[_i];
        _i++;
    }
}
    zT_208 = 10;
    zT_209 = 0;
    backing_box[zT_209] = zT_208;
    zT_211 = 0;
    expl_flag = zT_211;
    zT_212 = node.child_0;
    zT_213 = 0;
    if ((int)(zT_212 != (unsigned int)zT_213)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_28:
    zT_216 = &tre_env;
    zT_217 = node.child_0;
    zT_222 = zF_F2107C15_resolveTypeExprFull(zT_216, zT_217, (unsigned int)(0));
    bt = zT_222;
    if ((int)(bt != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_231 = type_reg->em_len;
    zT_232 = (unsigned int)zT_231;
    mstart = zT_232;
    zT_234 = 0;
    zT_235 = (unsigned int)zT_234;
    mcount = zT_235;
    zT_237 = 0;
    auto_val = zT_237;
    zT_239 = 0;
    zT_240 = (unsigned int)zT_239;
    i = zT_240;
    goto z_bb_35;
    z_bb_30:
    zT_225 = bt != (unsigned int)(1);
    goto z_bb_32;
    z_bb_31:
    zT_225 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_225) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_228 = 0;
    backing_box[zT_228] = bt;
    goto z_bb_34;
    z_bb_34:
    zT_229 = 1;
    expl_flag = zT_229;
    goto z_bb_29;
    z_bb_35:
    if ((int)(i < children_n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_243 = store;
    zT_245 = store;
    zT_246 = decl_idx;
    zT_249 = zF_B10B1BC1_astStoreNodeExtraCh(zT_245, zT_246, (unsigned int)((unsigned int)i));
    zT_244 = zT_249;
    zT_250 = zF_FCDD1D35_astStoreNodeAt(zT_243, zT_244);
    mnode = zT_250;
    zT_251 = mnode.kind;
    if ((int)(zT_251 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_287 = type_reg;
    zT_290 = (unsigned int)mstart;
    zT_289.members_start = zT_290;
    zT_291 = (unsigned short)mcount;
    zT_289.members_count = zT_291;
    zT_292 = 0;
    zT_293 = backing_box[zT_292];
    zT_289.backing_type = zT_293;
    zT_289.explicit_backing = expl_flag;
    zT_288 = zT_289;
    zF_298371DE_enAppend(zT_287, zT_288);
    zT_295 = type_reg->en_len;
    zT_297 = zT_295 - (unsigned int)(1);
    en_last = zT_297;
    zT_299 = (unsigned int)en_last;
    en_idx = zT_299;
    zT_301 = type_reg->types_items;
    zT_302 = type_reg->types_len;
    zT_305 = (unsigned int)(unsigned int)(zT_302 - (unsigned int)(1));
    zT_306 = zT_301[zT_305];
    ty = zT_306;
    ty.payload_idx = en_idx;
    zT_307 = type_reg->types_items;
    zT_308 = type_reg->types_len;
    zT_311 = (unsigned int)(unsigned int)(zT_308 - (unsigned int)(1));
    zT_307[zT_311] = ty;
    goto z_bb_27;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    mval = auto_val;
    zT_257 = mnode.child_1;
    zT_258 = 0;
    if ((int)(zT_257 != (unsigned int)zT_258)) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_284 = 1;
    zT_286 = i + (unsigned int)((unsigned int)zT_284);
    i = zT_286;
    goto z_bb_38;
    z_bb_41:
    zT_261 = &tre_env;
    zT_262 = mnode.child_1;
    zT_265 = zF_FFFAAD16_evalConstI64Full(zT_261, zT_262);
    ev_opt = zT_265;
    zT_266 = ev_opt.has_value;
    if (zT_266) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_268 = type_reg;
    zT_271 = store;
    zT_273 = store;
    zT_274 = decl_idx;
    zT_277 = zF_B10B1BC1_astStoreNodeExtraCh(zT_273, zT_274, (unsigned int)((unsigned int)i));
    zT_272 = zT_277;
    zT_278 = zF_8BA26B9E_astStoreNodePayload(zT_271, zT_272);
    zT_270.name_id = zT_278;
    zT_270.value = mval;
    zT_269 = zT_270;
    zF_157DA7BF_emAppend(zT_268, zT_269);
    zT_279 = 1;
    zT_281 = mcount + (unsigned int)((unsigned int)zT_279);
    mcount = zT_281;
    zT_283 = mval + (zT_C69B2266_i64)(1);
    auto_val = zT_283;
    goto z_bb_40;
    z_bb_43:
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_317 = type_reg->xn_len;
    zT_318 = (unsigned int)zT_317;
    tags_start_idx = zT_318;
    zT_320 = 0;
    zT_321 = (unsigned int)zT_320;
    i = zT_321;
    goto z_bb_47;
    z_bb_46:
    return;
    z_bb_47:
    if ((int)(i < children_n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_323 = type_reg;
    zT_325 = store;
    zT_326 = decl_idx;
    zT_329 = zF_B10B1BC1_astStoreNodeExtraCh(zT_325, zT_326, (unsigned int)((unsigned int)i));
    zT_324 = zT_329;
    zF_A648B1CB_xnAppend(zT_323, zT_324);
    goto z_bb_50;
    z_bb_49:
    zT_333 = type_reg;
    zT_335.tags_start = tags_start_idx;
    zT_336 = (unsigned short)children_n;
    zT_335.tags_count = zT_336;
    zT_334 = zT_335;
    zF_B86143DD_esAppend(zT_333, zT_334);
    zT_338 = type_reg->es_len;
    zT_340 = zT_338 - (unsigned int)(1);
    es_last = zT_340;
    zT_342 = (unsigned int)es_last;
    es_idx = zT_342;
    zT_344 = type_reg->types_items;
    zT_345 = type_reg->types_len;
    zT_348 = (unsigned int)(unsigned int)(zT_345 - (unsigned int)(1));
    zT_349 = zT_344[zT_348];
    ty = zT_349;
    ty.payload_idx = es_idx;
    zT_350 = type_reg->types_items;
    zT_351 = type_reg->types_len;
    zT_354 = (unsigned int)(unsigned int)(zT_351 - (unsigned int)(1));
    zT_350[zT_354] = ty;
    goto z_bb_46;
    z_bb_50:
    zT_330 = 1;
    zT_332 = i + (unsigned int)((unsigned int)zT_330);
    i = zT_332;
    goto z_bb_47;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, int populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_3C598AEF_SymbolKind zT_58;
    unsigned int zT_61;
    unsigned int zT_62;
    int zT_63;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    zT_072B53A6_ModuleRegistry* zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_81 = 0;
    zT_BAEE192E_Opt_10 zT_82 = {0};
    unsigned char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_4028D896_Arr_unsigned_char_2 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_96 = 0;
    int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char zT_115;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_3C598AEF_SymbolKind zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_131;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    int zT_137;
    unsigned char* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141 = 0;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_159;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    int zT_165;
    unsigned char* zT_166;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169 = 0;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned char* zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_187;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    int zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197 = 0;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned char* zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    zT_338B7C76_TypeRegistry* zT_209;
    unsigned int zT_210;
    unsigned int zT_211 = 0;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8143F551_AstKind zT_217;
    int zT_222;
    zT_8143F551_AstKind zT_223;
    int zT_228;
    zT_8143F551_AstKind zT_229;
    int zT_234;
    zT_8143F551_AstKind zT_235;
    zT_8143F551_AstKind zT_241;
    zT_33EF6BFB_TypeKind zT_242;
    unsigned char zT_249;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char zT_259;
    int zT_261;
    int zT_263;
    zT_33EF6BFB_TypeKind zT_265;
    zT_338B7C76_TypeRegistry* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    zT_33EF6BFB_TypeKind zT_281;
    unsigned int zT_282 = 0;
    zT_8143F551_AstKind zT_283;
    int zT_288;
    zT_8143F551_AstKind zT_289;
    int zT_294;
    unsigned char zT_295;
    zT_338B7C76_TypeRegistry* zT_301;
    unsigned int zT_302;
    zT_338B7C76_TypeRegistry* zT_303;
    zT_6B0A7D14_AstStore* zT_304;
    zT_8143F551_AstKind zT_305;
    unsigned int zT_306;
    zT_3D7259E2_SymbolRegistry* zT_307;
    zT_6B0A7D14_AstStore* zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    zT_4D61441E_DepGraph* zT_313;
    zT_3C598AEF_SymbolKind zT_317;
    zT_8143F551_AstKind zT_318;
    unsigned char* zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_6B0A7D14_AstStore* zT_329;
    unsigned int zT_330;
    unsigned int zT_332 = 0;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_337 = 0;
    unsigned char* zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_BAEE192E_Opt_10 zT_352 = {0};
    unsigned char zT_353;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_BAEE192E_Opt_10 zT_358 = {0};
    unsigned char zT_359;
    unsigned char* zT_362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned int zT_366;
    zT_79FAE712_u64 zT_372;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_79FAE712_u64 zT_374;
    unsigned int zT_375;
    zT_3C598AEF_SymbolKind zT_378;
    int zT_380;
    zT_D3EB6303_StringInterner* zT_382;
    unsigned int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_386;
    int* zT_387;
    unsigned int zT_389 = 0;
    zT_338B7C76_TypeRegistry* zT_393;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_394;
    unsigned int zT_395 = 0;
    zT_79FAE712_u64 zT_403;
    zT_338B7C76_TypeRegistry* zT_404;
    zT_79FAE712_u64 zT_405;
    unsigned int zT_406;
    zT_3C598AEF_SymbolKind zT_409;
    zT_8143F551_AstKind zT_410;
    int zT_415;
    zT_8143F551_AstKind zT_416;
    int zT_421;
    zT_8143F551_AstKind zT_422;
    int zT_427;
    zT_8143F551_AstKind zT_428;
    int zT_433;
    zT_8143F551_AstKind zT_434;
    int zT_439;
    zT_8143F551_AstKind zT_440;
    int zT_445;
    zT_8143F551_AstKind zT_446;
    unsigned char* zT_452;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_453;
    unsigned int zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    zT_338B7C76_TypeRegistry* zT_458;
    zT_BAEE192E_Opt_10 zT_465 = {0};
    unsigned char zT_466;
    zT_338B7C76_TypeRegistry* zT_468;
    zT_BAEE192E_Opt_10 zT_471 = {0};
    unsigned char zT_472;
    zT_3C598AEF_SymbolKind zT_476;
    zT_3A105EF1_Symbol zT_478;
    unsigned char zT_479;
    unsigned short zT_480;
    unsigned int zT_481;
    zT_3D7259E2_SymbolRegistry* zT_483;
    unsigned int zT_484;
    zT_060CD1EB_SymbolTable* zT_485 = 0;
    zT_060CD1EB_SymbolTable* zT_487;
    zT_3A105EF1_Symbol zT_488;
    int zT_489 = 0;
    unsigned char* zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned int zT_494;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    unsigned char* zT_497;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_498;
    unsigned int zT_499;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_500;
    zT_4028D896_Arr_unsigned_char_2 zT_502;
    unsigned int zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    int zT_508;
    unsigned char* zT_509;
    unsigned int zT_510;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_511;
    unsigned int zT_512 = 0;
    unsigned int zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned char* zT_523;
    unsigned int zT_524;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_525;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_533;
    int zT_537;
    unsigned char* zT_538;
    unsigned int zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    unsigned int zT_541 = 0;
    unsigned int zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    unsigned char* zT_552;
    unsigned int zT_553;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_554;
    unsigned char* zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_559;
    unsigned char* zT_561;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_562;
    unsigned int zT_563;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_564;
    zT_423AEC35_anon_227693 zT_566;
    zT_243D6A41_FnProto* zT_567;
    zT_6B0A7D14_AstStore* zT_568;
    unsigned int zT_569;
    unsigned int zT_570 = 0;
    unsigned int zT_571;
    zT_243D6A41_FnProto zT_572;
    zT_3A105EF1_Symbol zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    zT_3C598AEF_SymbolKind zT_579;
    unsigned char zT_580;
    unsigned short zT_581;
    unsigned int zT_582;
    zT_3D7259E2_SymbolRegistry* zT_584;
    unsigned int zT_585;
    zT_060CD1EB_SymbolTable* zT_586 = 0;
    zT_060CD1EB_SymbolTable* zT_587;
    zT_3A105EF1_Symbol zT_588;
    int zT_589 = 0;
    zT_6B0A7D14_AstStore* zT_590;
    unsigned int zT_591;
    unsigned int zT_592 = 0;
    zT_3A105EF1_Symbol zT_596;
    zT_6B0A7D14_AstStore* zT_597;
    unsigned int zT_598;
    unsigned int zT_599 = 0;
    unsigned int zT_600;
    zT_3C598AEF_SymbolKind zT_603;
    unsigned char zT_604;
    unsigned short zT_605;
    unsigned int zT_606;
    zT_3D7259E2_SymbolRegistry* zT_608;
    unsigned int zT_609;
    zT_060CD1EB_SymbolTable* zT_610 = 0;
    zT_060CD1EB_SymbolTable* zT_611;
    zT_3A105EF1_Symbol zT_612;
    int zT_613 = 0;
    zT_6B0A7D14_AstStore* zT_615;
    unsigned int zT_616;
    zT_8143F551_AstKind zT_617;
    zT_79FAE712_u64 zT_619 = 0;
    unsigned int zT_622;
    zT_8143F551_AstKind zT_624;
    zT_33EF6BFB_TypeKind zT_625;
    unsigned char zT_632;
    int zT_636;
    zT_33EF6BFB_TypeKind zT_638;
    unsigned char zT_642;
    int zT_644;
    int zT_646;
    zT_33EF6BFB_TypeKind zT_648;
    zT_338B7C76_TypeRegistry* zT_659;
    unsigned int zT_660;
    unsigned int zT_661;
    zT_33EF6BFB_TypeKind zT_662;
    unsigned int zT_663 = 0;
    zT_8143F551_AstKind zT_664;
    int zT_669;
    zT_8143F551_AstKind zT_670;
    int zT_675;
    unsigned char zT_676;
    zT_338B7C76_TypeRegistry* zT_682;
    unsigned int zT_683;
    zT_338B7C76_TypeRegistry* zT_684;
    zT_6B0A7D14_AstStore* zT_685;
    zT_8143F551_AstKind zT_686;
    unsigned int zT_687;
    zT_3D7259E2_SymbolRegistry* zT_688;
    zT_6B0A7D14_AstStore* zT_690;
    unsigned int zT_691;
    unsigned int zT_692;
    zT_4D61441E_DepGraph* zT_693;
    zT_3A105EF1_Symbol zT_695;
    zT_3C598AEF_SymbolKind zT_698;
    unsigned char zT_699;
    unsigned short zT_700;
    unsigned int zT_701;
    zT_3D7259E2_SymbolRegistry* zT_703;
    unsigned int zT_704;
    zT_060CD1EB_SymbolTable* zT_705 = 0;
    zT_060CD1EB_SymbolTable* zT_706;
    zT_3A105EF1_Symbol zT_707;
    int zT_708 = 0;
    zT_6B0A7D14_AstStore* zT_710;
    unsigned int zT_711;
    zT_8143F551_AstKind zT_712;
    zT_79FAE712_u64 zT_714 = 0;
    unsigned int zT_717;
    zT_338B7C76_TypeRegistry* zT_719;
    unsigned int zT_720;
    unsigned int zT_721;
    unsigned int zT_726 = 0;
    zT_338B7C76_TypeRegistry* zT_727;
    zT_6B0A7D14_AstStore* zT_728;
    zT_8143F551_AstKind zT_729;
    unsigned int zT_730;
    zT_3D7259E2_SymbolRegistry* zT_731;
    zT_3A105EF1_Symbol zT_734;
    zT_3C598AEF_SymbolKind zT_737;
    unsigned char zT_738;
    unsigned short zT_739;
    unsigned int zT_740;
    zT_3D7259E2_SymbolRegistry* zT_742;
    unsigned int zT_743;
    zT_060CD1EB_SymbolTable* zT_744 = 0;
    zT_060CD1EB_SymbolTable* zT_745;
    zT_3A105EF1_Symbol zT_746;
    int zT_747 = 0;
    zT_6B0A7D14_AstStore* zT_749;
    unsigned int zT_750;
    unsigned int zT_751 = 0;
    zT_072B53A6_ModuleRegistry* zT_753;
    unsigned int zT_754;
    zT_BAEE192E_Opt_10 zT_755 = {0};
    unsigned char zT_756;
    zT_3A105EF1_Symbol zT_759;
    zT_338B7C76_TypeRegistry* zT_760;
    unsigned int zT_761;
    unsigned int zT_762 = 0;
    zT_3C598AEF_SymbolKind zT_765;
    unsigned short zT_766;
    unsigned int zT_767;
    zT_3D7259E2_SymbolRegistry* zT_769;
    unsigned int zT_770;
    zT_060CD1EB_SymbolTable* zT_771 = 0;
    zT_060CD1EB_SymbolTable* zT_772;
    zT_3A105EF1_Symbol zT_773;
    int zT_774 = 0;
    unsigned char* zT_776;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_777;
    unsigned int zT_778;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_779;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_781;
    unsigned int zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    int zT_787;
    unsigned char* zT_788;
    unsigned int zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    unsigned int zT_791 = 0;
    unsigned int zT_795;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_796;
    unsigned char* zT_800;
    unsigned int zT_801;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_802;
    unsigned char* zT_804;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_805;
    unsigned int zT_806;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_807;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_809;
    unsigned int zT_811;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_812;
    int zT_815;
    unsigned char* zT_816;
    unsigned int zT_817;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_818;
    unsigned int zT_819 = 0;
    unsigned int zT_823;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_824;
    unsigned char* zT_828;
    unsigned int zT_829;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_830;
    unsigned char* zT_832;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_833;
    unsigned int zT_834;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_835;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    int inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    int arb_u;
    zT_8F083A69_Slice_zT_0B42B2F8_u ident_text;
    unsigned int arb_tid;
    zT_79FAE712_u64 atk;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_28[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_42 = (unsigned int)(19) - (unsigned int)((unsigned int)d12l);
    d12s = zT_42;
    zT_47 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_48 = (unsigned int)(19) - d12s;
    zT_49.ptr = zT_47;
    zT_49.len = zT_48;
    zT_43 = zT_49;
    zF_B5478454_measureMarkerWrite(zT_43);
    zT_51 = "\n";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    d12nl = zT_52;
    zT_54 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_54);
    zT_58 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_58;
    sym_mod_id = mod_id;
    zT_61 = 0;
    sym_type_id = zT_61;
    zT_62 = node.child_1;
    zT_63 = 0;
    if ((int)(zT_62 != (unsigned int)zT_63)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_566 = store->fn_protos;
    zT_567 = zT_566.items;
    zT_568 = store;
    zT_569 = decl_idx;
    zT_570 = zF_8BA26B9E_astStoreNodePayload(zT_568, zT_569);
    zT_571 = (unsigned int)zT_570;
    zT_572 = zT_567[zT_571];
    proto = zT_572;
    zT_575 = proto.name_id;
    zT_574.name_id = zT_575;
    zT_576 = 0;
    zT_574.type_id = zT_576;
    zT_579 = zT_3C598AEF_SymbolKind_function;
    zT_574.kind = zT_579;
    zT_580 = node.flags;
    zT_581 = (unsigned short)zT_580;
    zT_574.flags = zT_581;
    zT_574.decl_node = decl_idx;
    zT_574.module_id = mod_id;
    zT_582 = 0;
    zT_574.scope_level = zT_582;
    sym = zT_574;
    zT_584 = sym_reg;
    zT_585 = mod_id;
    zT_586 = zF_9B36C202_symbolRegistryGetTa(zT_584, zT_585);
    table = zT_586;
    zT_587 = table;
    zT_588 = sym;
    zT_589 = zF_D0156DDA_symbolTableInsert(zT_587, zT_588);
    (void)zT_589;
    goto z_bb_9;
    z_bb_3:
    zT_590 = store;
    zT_591 = decl_idx;
    zT_592 = zF_8BA26B9E_astStoreNodePayload(zT_590, zT_591);
    if ((int)(zT_592 != (unsigned int)(0))) goto z_bb_90; else goto z_bb_91;
    z_bb_4:
    zT_615 = store;
    zT_616 = decl_idx;
    zT_617 = node.kind;
    zT_619 = zF_0E4E10C6_astStoreNodePayload(zT_615, zT_616, zT_617);
    zT_622 = (unsigned int)(zT_79FAE712_u64)(zT_619 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_622;
    zT_624 = node.kind;
switch (zT_624) {
case 3: goto z_bb_92;
case 4: goto z_bb_93;
case 5: goto z_bb_94;
default: goto z_bb_95;
}
    z_bb_5:
    zT_710 = store;
    zT_711 = decl_idx;
    zT_712 = node.kind;
    zT_714 = zF_0E4E10C6_astStoreNodePayload(zT_710, zT_711, zT_712);
    zT_717 = (unsigned int)(zT_79FAE712_u64)(zT_714 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_717;
    zT_719 = type_reg;
    zT_720 = mod_id;
    zT_721 = name_id;
    zT_726 = zF_3A64E2E0_typeRegistryRegiste(zT_719, zT_720, zT_721, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_726;
    if (populate) goto z_bb_114; else goto z_bb_115;
    z_bb_6:
    zT_749 = store;
    zT_750 = decl_idx;
    zT_751 = zF_8BA26B9E_astStoreNodePayload(zT_749, zT_750);
    path_id = zT_751;
    zT_753 = reg;
    zT_754 = path_id;
    zT_755 = zF_A258E183_moduleRegistryPathT(zT_753, zT_754);
    target_mod_id = zT_755;
    zT_756 = target_mod_id.has_value;
    if (zT_756) goto z_bb_116; else goto z_bb_117;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_66 = store;
    zT_67 = node.child_1;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    init_node = zT_69;
    zT_70 = init_node.kind;
    if ((int)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_478.name_id = name_id;
    zT_478.type_id = sym_type_id;
    zT_478.kind = sym_kind;
    zT_479 = node.flags;
    zT_480 = (unsigned short)zT_479;
    zT_478.flags = zT_480;
    zT_478.decl_node = decl_idx;
    zT_478.module_id = sym_mod_id;
    zT_481 = 0;
    zT_478.scope_level = zT_481;
    sym = zT_478;
    zT_483 = sym_reg;
    zT_484 = mod_id;
    zT_485 = zF_9B36C202_symbolRegistryGetTa(zT_483, zT_484);
    table = zT_485;
    zT_487 = table;
    zT_488 = sym;
    zT_489 = zF_D0156DDA_symbolTableInsert(zT_487, zT_488);
    inserted = zT_489;
    if ((int)(!inserted)) goto z_bb_88; else goto z_bb_89;
    z_bb_12:
    zT_76 = reg;
    zT_78 = store;
    zT_79 = node.child_1;
    zT_81 = zF_8BA26B9E_astStoreNodePayload(zT_78, zT_79);
    zT_77 = zT_81;
    zT_82 = zF_A258E183_moduleRegistryPathT(zT_76, zT_77);
    target = zT_82;
    zT_84 = "M5:p";
    zT_86 = 4;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    m5m = zT_85;
    zT_87 = m5m;
    zF_48AC7B3A_markerWrite(zT_87);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_89[_i];
        _i++;
    }
}
    zT_93 = store;
    zT_94 = node.child_1;
    zT_96 = zF_8BA26B9E_astStoreNodePayload(zT_93, zT_94);
    zT_91 = zT_96;
    zT_99 = 0;
    zT_100 = (unsigned char*)((unsigned char*)m5pb) + zT_99;
    zT_101 = (unsigned int)(20) - zT_99;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_92 = zT_102;
    zT_103 = zF_A7504564_itoa(zT_91, zT_92);
    m5pl = zT_103;
    zT_107 = (unsigned int)(19) - (unsigned int)((unsigned int)m5pl);
    m5ps = zT_107;
    zT_112 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_113 = (unsigned int)(19) - m5ps;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_115 = target.has_value;
    if (zT_115) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_217 = init_node.kind;
    if ((int)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    mtid = target.value;
    zT_118 = "Rs";
    zT_120 = 2;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    rs_msg = zT_119;
    zT_121 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_124 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_124;
    sym_mod_id = mtid;
    zT_126 = "FIX1:mid=";
    zT_128 = 9;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    di_m = zT_127;
    zT_129 = di_m;
    zF_48AC7B3A_markerWrite(zT_129);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_131[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_131[_i];
        _i++;
    }
}
    zT_133 = sym_mod_id;
    zT_137 = 0;
    zT_138 = (unsigned char*)((unsigned char*)di_mb) + zT_137;
    zT_139 = (unsigned int)(10) - zT_137;
    zT_140.ptr = zT_138;
    zT_140.len = zT_139;
    zT_134 = zT_140;
    zT_141 = zF_A7504564_itoa(zT_133, zT_134);
    di_ml = zT_141;
    zT_145 = (unsigned int)(9) - (unsigned int)((unsigned int)di_ml);
    di_ms = zT_145;
    zT_150 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_151 = (unsigned int)(9) - di_ms;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zF_48AC7B3A_markerWrite(zT_146);
    zT_154 = "t";
    zT_156 = 1;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    di_t = zT_155;
    zT_157 = di_t;
    zF_48AC7B3A_markerWrite(zT_157);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_159[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_159[_i];
        _i++;
    }
}
    zT_161 = mtid;
    zT_165 = 0;
    zT_166 = (unsigned char*)((unsigned char*)di_tb) + zT_165;
    zT_167 = (unsigned int)(10) - zT_165;
    zT_168.ptr = zT_166;
    zT_168.len = zT_167;
    zT_162 = zT_168;
    zT_169 = zF_A7504564_itoa(zT_161, zT_162);
    di_tl = zT_169;
    zT_173 = (unsigned int)(9) - (unsigned int)((unsigned int)di_tl);
    di_ts = zT_173;
    zT_178 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_179 = (unsigned int)(9) - di_ts;
    zT_180.ptr = zT_178;
    zT_180.len = zT_179;
    zT_174 = zT_180;
    zF_48AC7B3A_markerWrite(zT_174);
    zT_182 = "n";
    zT_184 = 1;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    di_n = zT_183;
    zT_185 = di_n;
    zF_48AC7B3A_markerWrite(zT_185);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_187[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_187[_i];
        _i++;
    }
}
    zT_189 = mod_id;
    zT_193 = 0;
    zT_194 = (unsigned char*)((unsigned char*)di_nb) + zT_193;
    zT_195 = (unsigned int)(10) - zT_193;
    zT_196.ptr = zT_194;
    zT_196.len = zT_195;
    zT_190 = zT_196;
    zT_197 = zF_A7504564_itoa(zT_189, zT_190);
    di_nl = zT_197;
    zT_201 = (unsigned int)(9) - (unsigned int)((unsigned int)di_nl);
    di_ns = zT_201;
    zT_206 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_207 = (unsigned int)(9) - di_ns;
    zT_208.ptr = zT_206;
    zT_208.len = zT_207;
    zT_202 = zT_208;
    zF_48AC7B3A_markerWrite(zT_202);
    zT_209 = type_reg;
    zT_210 = mtid;
    zT_211 = zF_2ECA9F93_typeRegistryGetOrCr(zT_209, zT_210);
    sym_type_id = zT_211;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_213 = "Rf";
    zT_215 = 2;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    rf_msg = zT_214;
    zT_216 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    goto z_bb_15;
    z_bb_17:
    zT_223 = init_node.kind;
    zT_222 = zT_223 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_222 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_222) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_229 = init_node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_228 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_228) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_235 = init_node.kind;
    zT_234 = zT_235 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_234 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_234) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_241 = init_node.kind;
switch (zT_241) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_318 = init_node.kind;
    if ((int)(zT_318 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_52; else goto z_bb_54;
    z_bb_29:
    zT_242 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_35;
    z_bb_30:
    zT_242 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_249 = init_node.flags;
    zT_253 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_249) & (unsigned short)(16)) != zT_253)) goto z_bb_36; else goto z_bb_37;
    z_bb_32:
    zT_242 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_242 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_242;
    zT_278 = type_reg;
    zT_279 = mod_id;
    zT_280 = name_id;
    zT_281 = type_kind;
    zT_282 = zF_3A64E2E0_typeRegistryRegiste(zT_278, zT_279, zT_280, zT_281);
    sym_type_id = zT_282;
    zT_283 = init_node.kind;
    if ((int)(zT_283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_43; else goto z_bb_42;
    z_bb_36:
    zT_255 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_38;
    z_bb_37:
    zT_259 = init_node.flags;
    zT_261 = 1;
    zT_263 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_259) & zT_261) != zT_263)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_242 = zT_255;
    goto z_bb_35;
    z_bb_39:
    zT_265 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_265 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_41;
    z_bb_41:
    zT_255 = zT_265;
    goto z_bb_38;
    z_bb_42:
    zT_289 = init_node.kind;
    zT_288 = zT_289 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_44;
    z_bb_43:
    zT_288 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_288) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_295 = init_node.flags;
    zT_294 = (unsigned short)((unsigned short)((unsigned short)zT_295) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_47;
    z_bb_46:
    zT_294 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_294) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_301 = type_reg;
    zT_302 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_301, zT_302);
    goto z_bb_49;
    z_bb_49:
    if (populate) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_303 = type_reg;
    zT_304 = store;
    zT_305 = init_node.kind;
    zT_306 = node.child_1;
    zT_307 = sym_reg;
    zF_020995FB_populateTypePayload(zT_303, zT_304, zT_305, zT_306, zT_307);
    goto z_bb_51;
    z_bb_51:
    zT_310 = store;
    zT_311 = node.child_1;
    zT_312 = sym_type_id;
    zT_313 = g;
    zF_4976C319_addTypeDependencies(zT_310, zT_311, zT_312, zT_313);
    zT_317 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_317;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_52:
    zT_324 = "RCA:p";
    zT_326 = 5;
    zT_325.ptr = zT_324;
    zT_325.len = zT_326;
    rca_m = zT_325;
    zT_327 = rca_m;
    zT_329 = store;
    zT_330 = node.child_1;
    zT_332 = zF_8BA26B9E_astStoreNodePayload(zT_329, zT_330);
    zT_328 = zT_332;
    zF_C914CB83_markerWriteInt(zT_327, zT_328);
    zT_334 = store;
    zT_335 = node.child_1;
    zT_337 = zF_53458827_astStoreIdentifier(zT_334, zT_335);
    ident_name_id = zT_337;
    zT_339 = "RCA:i";
    zT_341 = 5;
    zT_340.ptr = zT_339;
    zT_340.len = zT_341;
    rca_i = zT_340;
    zT_342 = rca_i;
    zT_343 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_342, zT_343);
    zT_345 = type_reg;
    zT_352 = zF_0EB68360_nameCacheGet(zT_345, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id)));
    cached = zT_352;
    zT_353 = cached.has_value;
    if ((int)(!zT_353)) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_27;
    z_bb_54:
    zT_410 = init_node.kind;
    if ((int)(zT_410 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_65; else goto z_bb_64;
    z_bb_55:
    zT_355 = type_reg;
    zT_358 = zF_0EB68360_nameCacheGet(zT_355, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_358;
    goto z_bb_56;
    z_bb_56:
    zT_359 = cached.has_value;
    if (zT_359) goto z_bb_57; else goto z_bb_59;
    z_bb_57:
    ct = cached.value;
    zT_362 = "RCA:H";
    zT_364 = 5;
    zT_363.ptr = zT_362;
    zT_363.len = zT_364;
    rca_h = zT_363;
    zT_365 = rca_h;
    zT_366 = ct;
    zF_C914CB83_markerWriteInt(zT_365, zT_366);
    zT_372 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    ck = zT_372;
    zT_373 = type_reg;
    zT_374 = ck;
    zT_375 = ct;
    zF_5E95558D_nameCachePut(zT_373, zT_374, zT_375);
    sym_type_id = ct;
    zT_378 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_378;
    sym_mod_id = mod_id;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_53;
    z_bb_59:
    zT_380 = 0;
    arb_u = zT_380;
    zT_382 = type_reg->interner;
    zT_383 = ident_name_id;
    zT_385 = zF_9134020D_stringInternerGet(zT_382, zT_383);
    ident_text = zT_385;
    zT_386 = ident_text;
    zT_387 = &arb_u;
    zT_389 = zF_741B5264_parseArbIntWidth(zT_386, zT_387);
    if ((int)(zT_389 != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_393 = type_reg;
    zT_394 = ident_text;
    zT_395 = zF_B8CF3697_typeRegistryGetOrCr(zT_393, zT_394);
    arb_tid = zT_395;
    if ((int)(arb_tid != (unsigned int)(18))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_58;
    z_bb_62:
    zT_403 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    atk = zT_403;
    zT_404 = type_reg;
    zT_405 = atk;
    zT_406 = arb_tid;
    zF_5E95558D_nameCachePut(zT_404, zT_405, zT_406);
    sym_type_id = arb_tid;
    zT_409 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_409;
    sym_mod_id = mod_id;
    goto z_bb_63;
    z_bb_63:
    goto z_bb_61;
    z_bb_64:
    zT_416 = init_node.kind;
    zT_415 = zT_416 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_66;
    z_bb_65:
    zT_415 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_415) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_422 = init_node.kind;
    zT_421 = zT_422 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_69;
    z_bb_68:
    zT_421 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_421) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_428 = init_node.kind;
    zT_427 = zT_428 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type);
    goto z_bb_72;
    z_bb_71:
    zT_427 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_427) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_434 = init_node.kind;
    zT_433 = zT_434 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_75;
    z_bb_74:
    zT_433 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_433) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_440 = init_node.kind;
    zT_439 = zT_440 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_78;
    z_bb_77:
    zT_439 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_439) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_446 = init_node.kind;
    zT_445 = zT_446 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_81;
    z_bb_80:
    zT_445 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_445) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_452 = "AT:p";
    zT_454 = 4;
    zT_453.ptr = zT_452;
    zT_453.len = zT_454;
    at_m = zT_453;
    zT_455 = at_m;
    zT_456 = name_id;
    zF_C914CB83_markerWriteInt(zT_455, zT_456);
    zT_458 = type_reg;
    zT_465 = zF_0EB68360_nameCacheGet(zT_458, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id)));
    acached = zT_465;
    zT_466 = acached.has_value;
    if ((int)(!zT_466)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_53;
    z_bb_84:
    zT_468 = type_reg;
    zT_471 = zF_0EB68360_nameCacheGet(zT_468, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_471;
    goto z_bb_85;
    z_bb_85:
    zT_472 = acached.has_value;
    if (zT_472) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    act = acached.value;
    sym_type_id = act;
    goto z_bb_87;
    z_bb_87:
    zT_476 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_476;
    sym_mod_id = mod_id;
    goto z_bb_83;
    z_bb_88:
    zT_492 = "VR";
    zT_494 = 2;
    zT_493.ptr = zT_492;
    zT_493.len = zT_494;
    vr = zT_493;
    zT_495 = vr;
    zF_48AC7B3A_markerWrite(zT_495);
    goto z_bb_89;
    z_bb_89:
    zT_497 = "VD";
    zT_499 = 2;
    zT_498.ptr = zT_497;
    zT_498.len = zT_499;
    vd = zT_498;
    zT_500 = vd;
    zF_48AC7B3A_markerWrite(zT_500);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_502[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_502[_i];
        _i++;
    }
}
    zT_504 = name_id;
    zT_508 = 0;
    zT_509 = (unsigned char*)((unsigned char*)vb) + zT_508;
    zT_510 = (unsigned int)(20) - zT_508;
    zT_511.ptr = zT_509;
    zT_511.len = zT_510;
    zT_505 = zT_511;
    zT_512 = zF_A7504564_itoa(zT_504, zT_505);
    vn = zT_512;
    zT_518 = (unsigned int)(19) - (unsigned int)((unsigned int)vn);
    vns = zT_518;
    zT_523 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_524 = (unsigned int)(20) - vns;
    zT_525.ptr = zT_523;
    zT_525.len = zT_524;
    zT_519 = zT_525;
    zF_48AC7B3A_markerWrite(zT_519);
    zT_527 = ":";
    zT_529 = 1;
    zT_528.ptr = zT_527;
    zT_528.len = zT_529;
    vc = zT_528;
    zT_530 = vc;
    zF_48AC7B3A_markerWrite(zT_530);
    zT_537 = 0;
    zT_538 = (unsigned char*)((unsigned char*)vb) + zT_537;
    zT_539 = (unsigned int)(20) - zT_537;
    zT_540.ptr = zT_538;
    zT_540.len = zT_539;
    zT_533 = zT_540;
    zT_541 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_533);
    vk = zT_541;
    zT_547 = (unsigned int)(19) - (unsigned int)((unsigned int)vk);
    vks = zT_547;
    zT_552 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_553 = (unsigned int)(20) - vks;
    zT_554.ptr = zT_552;
    zT_554.len = zT_553;
    zT_548 = zT_554;
    zF_48AC7B3A_markerWrite(zT_548);
    zT_556 = "\n";
    zT_558 = 1;
    zT_557.ptr = zT_556;
    zT_557.len = zT_558;
    ven = zT_557;
    zT_559 = ven;
    zF_48AC7B3A_markerWrite(zT_559);
    zT_561 = "Vi";
    zT_563 = 2;
    zT_562.ptr = zT_561;
    zT_562.len = zT_563;
    vi_msg = zT_562;
    zT_564 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_564);
    goto z_bb_9;
    z_bb_90:
    zT_597 = store;
    zT_598 = decl_idx;
    zT_599 = zF_8BA26B9E_astStoreNodePayload(zT_597, zT_598);
    zT_596.name_id = zT_599;
    zT_600 = 0;
    zT_596.type_id = zT_600;
    zT_603 = zT_3C598AEF_SymbolKind_test_sym;
    zT_596.kind = zT_603;
    zT_604 = node.flags;
    zT_605 = (unsigned short)zT_604;
    zT_596.flags = zT_605;
    zT_596.decl_node = decl_idx;
    zT_596.module_id = mod_id;
    zT_606 = 0;
    zT_596.scope_level = zT_606;
    sym = zT_596;
    zT_608 = sym_reg;
    zT_609 = mod_id;
    zT_610 = zF_9B36C202_symbolRegistryGetTa(zT_608, zT_609);
    table = zT_610;
    zT_611 = table;
    zT_612 = sym;
    zT_613 = zF_D0156DDA_symbolTableInsert(zT_611, zT_612);
    (void)zT_613;
    goto z_bb_91;
    z_bb_91:
    goto z_bb_9;
    z_bb_92:
    zT_625 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_97;
    z_bb_93:
    zT_625 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_97;
    z_bb_94:
    zT_632 = node.flags;
    zT_636 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_632) & (unsigned short)(16)) != zT_636)) goto z_bb_98; else goto z_bb_99;
    z_bb_95:
    zT_625 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_97;
    z_bb_97:
    type_kind = zT_625;
    zT_659 = type_reg;
    zT_660 = mod_id;
    zT_661 = name_id;
    zT_662 = type_kind;
    zT_663 = zF_3A64E2E0_typeRegistryRegiste(zT_659, zT_660, zT_661, zT_662);
    tid = zT_663;
    zT_664 = node.kind;
    if ((int)(zT_664 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_105; else goto z_bb_104;
    z_bb_98:
    zT_638 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_100;
    z_bb_99:
    zT_642 = node.flags;
    zT_644 = 1;
    zT_646 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_642) & zT_644) != zT_646)) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    zT_625 = zT_638;
    goto z_bb_97;
    z_bb_101:
    zT_648 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_103;
    z_bb_102:
    zT_648 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_103;
    z_bb_103:
    zT_638 = zT_648;
    goto z_bb_100;
    z_bb_104:
    zT_670 = node.kind;
    zT_669 = zT_670 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_106;
    z_bb_105:
    zT_669 = 1;
    goto z_bb_106;
    z_bb_106:
    if (zT_669) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_676 = node.flags;
    zT_675 = (unsigned short)((unsigned short)((unsigned short)zT_676) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_109;
    z_bb_108:
    zT_675 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_675) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_682 = type_reg;
    zT_683 = tid;
    zF_52816016_typeRegistrySetPack(zT_682, zT_683);
    goto z_bb_111;
    z_bb_111:
    if (populate) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_684 = type_reg;
    zT_685 = store;
    zT_686 = node.kind;
    zT_687 = decl_idx;
    zT_688 = sym_reg;
    zF_020995FB_populateTypePayload(zT_684, zT_685, zT_686, zT_687, zT_688);
    goto z_bb_113;
    z_bb_113:
    zT_690 = store;
    zT_691 = decl_idx;
    zT_692 = tid;
    zT_693 = g;
    zF_4976C319_addTypeDependencies(zT_690, zT_691, zT_692, zT_693);
    zT_695.name_id = name_id;
    zT_695.type_id = tid;
    zT_698 = zT_3C598AEF_SymbolKind_type_alias;
    zT_695.kind = zT_698;
    zT_699 = node.flags;
    zT_700 = (unsigned short)zT_699;
    zT_695.flags = zT_700;
    zT_695.decl_node = decl_idx;
    zT_695.module_id = mod_id;
    zT_701 = 0;
    zT_695.scope_level = zT_701;
    sym = zT_695;
    zT_703 = sym_reg;
    zT_704 = mod_id;
    zT_705 = zF_9B36C202_symbolRegistryGetTa(zT_703, zT_704);
    table = zT_705;
    zT_706 = table;
    zT_707 = sym;
    zT_708 = zF_D0156DDA_symbolTableInsert(zT_706, zT_707);
    (void)zT_708;
    goto z_bb_9;
    z_bb_114:
    zT_727 = type_reg;
    zT_728 = store;
    zT_729 = node.kind;
    zT_730 = decl_idx;
    zT_731 = sym_reg;
    zF_020995FB_populateTypePayload(zT_727, zT_728, zT_729, zT_730, zT_731);
    goto z_bb_115;
    z_bb_115:
    zT_734.name_id = name_id;
    zT_734.type_id = tid;
    zT_737 = zT_3C598AEF_SymbolKind_type_alias;
    zT_734.kind = zT_737;
    zT_738 = node.flags;
    zT_739 = (unsigned short)zT_738;
    zT_734.flags = zT_739;
    zT_734.decl_node = decl_idx;
    zT_734.module_id = mod_id;
    zT_740 = 0;
    zT_734.scope_level = zT_740;
    sym = zT_734;
    zT_742 = sym_reg;
    zT_743 = mod_id;
    zT_744 = zF_9B36C202_symbolRegistryGetTa(zT_742, zT_743);
    table = zT_744;
    zT_745 = table;
    zT_746 = sym;
    zT_747 = zF_D0156DDA_symbolTableInsert(zT_745, zT_746);
    (void)zT_747;
    goto z_bb_9;
    z_bb_116:
    tid = target_mod_id.value;
    zT_759.name_id = path_id;
    zT_760 = type_reg;
    zT_761 = tid;
    zT_762 = zF_2ECA9F93_typeRegistryGetOrCr(zT_760, zT_761);
    zT_759.type_id = zT_762;
    zT_765 = zT_3C598AEF_SymbolKind_module;
    zT_759.kind = zT_765;
    zT_766 = 0;
    zT_759.flags = zT_766;
    zT_759.decl_node = decl_idx;
    zT_759.module_id = tid;
    zT_767 = 0;
    zT_759.scope_level = zT_767;
    sym = zT_759;
    zT_769 = sym_reg;
    zT_770 = mod_id;
    zT_771 = zF_9B36C202_symbolRegistryGetTa(zT_769, zT_770);
    table = zT_771;
    zT_772 = table;
    zT_773 = sym;
    zT_774 = zF_D0156DDA_symbolTableInsert(zT_772, zT_773);
    (void)zT_774;
    zT_776 = "IMR:n";
    zT_778 = 5;
    zT_777.ptr = zT_776;
    zT_777.len = zT_778;
    imr = zT_777;
    zT_779 = imr;
    zF_48AC7B3A_markerWrite(zT_779);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_781[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_781[_i];
        _i++;
    }
}
    zT_783 = path_id;
    zT_787 = 0;
    zT_788 = (unsigned char*)((unsigned char*)imb) + zT_787;
    zT_789 = (unsigned int)(10) - zT_787;
    zT_790.ptr = zT_788;
    zT_790.len = zT_789;
    zT_784 = zT_790;
    zT_791 = zF_A7504564_itoa(zT_783, zT_784);
    iml = zT_791;
    zT_795 = (unsigned int)(9) - (unsigned int)((unsigned int)iml);
    ims = zT_795;
    zT_800 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_801 = (unsigned int)(9) - ims;
    zT_802.ptr = zT_800;
    zT_802.len = zT_801;
    zT_796 = zT_802;
    zF_48AC7B3A_markerWrite(zT_796);
    zT_804 = "m";
    zT_806 = 1;
    zT_805.ptr = zT_804;
    zT_805.len = zT_806;
    imm = zT_805;
    zT_807 = imm;
    zF_48AC7B3A_markerWrite(zT_807);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_809[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_809[_i];
        _i++;
    }
}
    zT_811 = tid;
    zT_815 = 0;
    zT_816 = (unsigned char*)((unsigned char*)immb) + zT_815;
    zT_817 = (unsigned int)(10) - zT_815;
    zT_818.ptr = zT_816;
    zT_818.len = zT_817;
    zT_812 = zT_818;
    zT_819 = zF_A7504564_itoa(zT_811, zT_812);
    imml = zT_819;
    zT_823 = (unsigned int)(9) - (unsigned int)((unsigned int)imml);
    imms = zT_823;
    zT_828 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_829 = (unsigned int)(9) - imms;
    zT_830.ptr = zT_828;
    zT_830.len = zT_829;
    zT_824 = zT_830;
    zF_48AC7B3A_markerWrite(zT_824);
    zT_832 = " ";
    zT_834 = 1;
    zT_833.ptr = zT_832;
    zT_833.len = zT_834;
    imsnl = zT_833;
    zT_835 = imsnl;
    zF_48AC7B3A_markerWrite(zT_835);
    goto z_bb_117;
    z_bb_117:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, int populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    int zT_17;
    zT_9FE1BFFE_ModuleState zT_18;
    int zT_23;
    unsigned int zT_24;
    int zT_25;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_32;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_41 = 0;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_4028D896_Arr_unsigned_char_2 zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_8143F551_AstKind zT_56;
    zT_79FAE712_u64 zT_59 = 0;
    int zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    int zT_87;
    unsigned int zT_88;
    zT_4028D896_Arr_unsigned_char_2 zT_92;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_101 = 0;
    int zT_104;
    unsigned char* zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108 = 0;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned char* zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    unsigned int zT_133 = 0;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_136;
    unsigned int zT_137;
    zT_4028D896_Arr_unsigned_char_2 zT_139;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    int zT_145;
    unsigned char* zT_146;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    unsigned int zT_149 = 0;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned char* zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    int zT_166;
    unsigned int zT_168;
    unsigned char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    int zT_175;
    unsigned int zT_176;
    zT_3D7259E2_SymbolRegistry* zT_179;
    zT_338B7C76_TypeRegistry* zT_180;
    zT_6B0A7D14_AstStore* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_4D61441E_DepGraph* zT_184;
    zT_072B53A6_ModuleRegistry* zT_185;
    int zT_186;
    zT_6B0A7D14_AstStore* zT_187;
    unsigned int zT_188;
    unsigned int zT_192 = 0;
    int zT_193;
    unsigned int zT_195;
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((int)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = entry.state;
    zT_17 = zT_18 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_17 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_17) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_24 = entry.ast_root;
    zT_25 = 0;
    zT_23 = zT_24 == (unsigned int)zT_25;
    goto z_bb_6;
    z_bb_5:
    zT_23 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_23) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_28 = store;
    zT_29 = entry.ast_root;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    root = zT_31;
    zT_32 = root.kind;
    if ((int)(zT_32 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_38 = store;
    zT_39 = entry.ast_root;
    zT_41 = zF_152E19CB_astStoreNodeExtraCh(zT_38, zT_39);
    decls_n = zT_41;
    if ((int)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_45 = "RS";
    zT_47 = 2;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    dg = zT_46;
    zT_48 = dg;
    zF_48AC7B3A_markerWrite(zT_48);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_50[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_50[_i];
        _i++;
    }
}
    zT_54 = store;
    zT_55 = entry.ast_root;
    zT_56 = root.kind;
    zT_59 = zF_0E4E10C6_astStoreNodePayload(zT_54, zT_55, zT_56);
    zT_65 = 0;
    zT_66 = (unsigned char*)((unsigned char*)pb) + zT_65;
    zT_67 = (unsigned int)(20) - zT_65;
    zT_68.ptr = zT_66;
    zT_68.len = zT_67;
    zT_53 = zT_68;
    zT_69 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_59 & (zT_79FAE712_u64)(4294967295u))), zT_53);
    pl = zT_69;
    zT_73 = (unsigned int)(19) - (unsigned int)((unsigned int)pl);
    ps = zT_73;
    zT_78 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_79 = (unsigned int)(19) - ps;
    zT_80.ptr = zT_78;
    zT_80.len = zT_79;
    zT_74 = zT_80;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_82 = ":";
    zT_84 = 1;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    sc = zT_83;
    zT_85 = sc;
    zF_48AC7B3A_markerWrite(zT_85);
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    i2 = zT_88;
    goto z_bb_13;
    z_bb_12:
    zT_175 = 0;
    zT_176 = (unsigned int)zT_175;
    i = zT_176;
    goto z_bb_17;
    z_bb_13:
    if ((int)(i2 < (unsigned int)((unsigned int)decls_n))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_92[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_92[_i];
        _i++;
    }
}
    zT_96 = store;
    zT_97 = entry.ast_root;
    zT_101 = zF_B10B1BC1_astStoreNodeExtraCh(zT_96, zT_97, (unsigned int)((unsigned int)i2));
    zT_94 = zT_101;
    zT_104 = 0;
    zT_105 = (unsigned char*)((unsigned char*)ii_buf) + zT_104;
    zT_106 = (unsigned int)(20) - zT_104;
    zT_107.ptr = zT_105;
    zT_107.len = zT_106;
    zT_95 = zT_107;
    zT_108 = zF_A7504564_itoa(zT_94, zT_95);
    ii_len = zT_108;
    zT_112 = (unsigned int)(19) - (unsigned int)((unsigned int)ii_len);
    ii_start = zT_112;
    zT_117 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_118 = (unsigned int)(19) - ii_start;
    zT_119.ptr = zT_117;
    zT_119.len = zT_118;
    zT_113 = zT_119;
    zF_48AC7B3A_markerWrite(zT_113);
    zT_121 = "=";
    zT_123 = 1;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    ss = zT_122;
    zT_124 = ss;
    zF_48AC7B3A_markerWrite(zT_124);
    zT_126 = store;
    zT_128 = store;
    zT_129 = entry.ast_root;
    zT_133 = zF_B10B1BC1_astStoreNodeExtraCh(zT_128, zT_129, (unsigned int)((unsigned int)i2));
    zT_127 = zT_133;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_126, zT_127);
    dc = zT_134;
    zT_136 = dc.kind;
    zT_137 = (unsigned int)zT_136;
    dk = zT_137;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_139[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_139[_i];
        _i++;
    }
}
    zT_141 = dk;
    zT_145 = 0;
    zT_146 = (unsigned char*)((unsigned char*)db) + zT_145;
    zT_147 = (unsigned int)(20) - zT_145;
    zT_148.ptr = zT_146;
    zT_148.len = zT_147;
    zT_142 = zT_148;
    zT_149 = zF_A7504564_itoa(zT_141, zT_142);
    dl = zT_149;
    zT_153 = (unsigned int)(19) - (unsigned int)((unsigned int)dl);
    ds = zT_153;
    zT_158 = (unsigned char*)((unsigned char*)db) + ds;
    zT_159 = (unsigned int)(19) - ds;
    zT_160.ptr = zT_158;
    zT_160.len = zT_159;
    zT_154 = zT_160;
    zF_48AC7B3A_markerWrite(zT_154);
    zT_162 = " ";
    zT_164 = 1;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    dsp = zT_163;
    zT_165 = dsp;
    zF_48AC7B3A_markerWrite(zT_165);
    goto z_bb_16;
    z_bb_15:
    zT_170 = "\n";
    zT_172 = 1;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    dn = zT_171;
    zT_173 = dn;
    zF_48AC7B3A_markerWrite(zT_173);
    goto z_bb_12;
    z_bb_16:
    zT_166 = 1;
    zT_168 = i2 + (unsigned int)((unsigned int)zT_166);
    i2 = zT_168;
    goto z_bb_13;
    z_bb_17:
    if ((int)(i < (unsigned int)((unsigned int)decls_n))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_179 = sym_reg;
    zT_180 = type_reg;
    zT_181 = store;
    zT_182 = module_id;
    zT_187 = store;
    zT_188 = entry.ast_root;
    zT_192 = zF_B10B1BC1_astStoreNodeExtraCh(zT_187, zT_188, (unsigned int)((unsigned int)i));
    zT_183 = zT_192;
    zT_184 = g;
    zT_185 = reg;
    zT_186 = populate;
    zF_CBEB26BC_registerDecl(zT_179, zT_180, zT_181, zT_182, zT_183, zT_184, zT_185, zT_186);
    zT_193 = 1;
    zT_195 = i + (unsigned int)((unsigned int)zT_193);
    i = zT_195;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_33EF6BFB_TypeKind zT_1 = 0;
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
