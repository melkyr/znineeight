#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zT_5 = 0;
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_6C306CCB_Opt_240 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_36325BAA_EU_042 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_6C306CCB_Opt_240 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->cap;
    zT_14 = 0;
    if ((unsigned char)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->items;
    zT_25 = self->cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->items;
    zT_48 = self->len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    goto z_bb_16;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
    z_bb_16:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    self->len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_9;
    zT_36325BAA_EU_042 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_52CDA6EF_DepEdge* zT_35;
    zT_52CDA6EF_DepEdge zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    zT_52CDA6EF_DepEdge* zT_43;
    zT_52CDA6EF_DepEdge zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_5 = (unsigned int)(unsigned int)(max_type_id + (unsigned int)(1));
    count = zT_5;
    zT_6 = self->in_degree_cap;
    if ((unsigned char)(count > zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_9, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_6;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    zT_26 = self->in_degree_items;
    zT_26[i] = zT_25;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_32 = self->len;
    if ((unsigned char)(i < zT_32)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self->in_degree_items;
    zT_35 = self->items;
    zT_36 = zT_35[i];
    zT_37 = zT_36.to;
    zT_38 = zT_34[zT_37];
    zT_39 = 1;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    zT_42 = self->in_degree_items;
    zT_43 = self->items;
    zT_44 = zT_43[i];
    zT_45 = zT_44.to;
    zT_42[zT_45] = zT_41;
    zT_46 = 1;
    zT_48 = i + (unsigned int)((unsigned int)zT_46);
    i = zT_48;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_28 = 0;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_4D61441E_DepGraph* zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_40;
    unsigned int children_n;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_14, zT_15);
    children_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < children_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = store;
    zT_24 = store;
    zT_25 = decl_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_24, zT_25, (unsigned int)((unsigned int)i));
    zT_23 = zT_28;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    field_node = zT_29;
    zT_30 = field_node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_34 = g;
    zT_36 = tid;
    zF_AA751A34_depGraphAddEdge(zT_34, (unsigned int)(0), zT_36);
    goto z_bb_8;
    z_bb_8:
    zT_38 = 1;
    zT_40 = i + (unsigned int)((unsigned int)zT_38);
    i = zT_40;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    int zT_18;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned int zT_31;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_47 = 0;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_8143F551_AstKind zT_49;
    zT_338B7C76_TypeRegistry* zT_53;
    int zT_56;
    unsigned int zT_58;
    int zT_59;
    unsigned int zT_61;
    int zT_62;
    zT_338B7C76_TypeRegistry* zT_64;
    zT_666DC2E1_TuplePayload zT_65;
    zT_666DC2E1_TuplePayload zT_66;
    unsigned short zT_67;
    unsigned int zT_69;
    unsigned int zT_71;
    unsigned int zT_73;
    zT_D155D06D_Type* zT_75;
    unsigned int zT_76;
    unsigned int zT_79;
    zT_D155D06D_Type zT_80;
    zT_D155D06D_Type* zT_81;
    unsigned int zT_82;
    unsigned int zT_85;
    unsigned int zT_90;
    unsigned int zT_91;
    int zT_93;
    unsigned int zT_94;
    int zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_103;
    unsigned int zT_106 = 0;
    zT_22A7C88B_AstNode zT_107 = {0};
    zT_8143F551_AstKind zT_108;
    zT_338B7C76_TypeRegistry* zT_112;
    zT_2DF01B61_FieldEntry zT_113;
    zT_2DF01B61_FieldEntry zT_114;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    unsigned int zT_121 = 0;
    unsigned int zT_122 = 0;
    unsigned int zT_123;
    unsigned int zT_124;
    int zT_125;
    unsigned int zT_127;
    int zT_128;
    unsigned int zT_130;
    int zT_131;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_406493CE_StructPayload zT_134;
    zT_406493CE_StructPayload zT_135;
    unsigned int zT_136;
    unsigned short zT_137;
    unsigned int zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    zT_D155D06D_Type* zT_145;
    unsigned int zT_146;
    unsigned int zT_149;
    zT_D155D06D_Type zT_150;
    zT_D155D06D_Type* zT_151;
    unsigned int zT_152;
    unsigned int zT_155;
    unsigned int zT_160;
    unsigned int zT_161;
    int zT_163;
    unsigned int zT_164;
    int zT_166;
    unsigned int zT_167;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    zT_6B0A7D14_AstStore* zT_172;
    unsigned int zT_173;
    unsigned int zT_176 = 0;
    zT_22A7C88B_AstNode zT_177 = {0};
    zT_8143F551_AstKind zT_178;
    zT_338B7C76_TypeRegistry* zT_182;
    zT_2DF01B61_FieldEntry zT_183;
    zT_2DF01B61_FieldEntry zT_184;
    zT_6B0A7D14_AstStore* zT_185;
    unsigned int zT_186;
    zT_6B0A7D14_AstStore* zT_187;
    unsigned int zT_188;
    unsigned int zT_191 = 0;
    unsigned int zT_192 = 0;
    unsigned int zT_193;
    unsigned int zT_194;
    int zT_195;
    unsigned int zT_197;
    int zT_198;
    unsigned int zT_200;
    unsigned char zT_201;
    int zT_203;
    int zT_205;
    zT_338B7C76_TypeRegistry* zT_207;
    zT_54FF90FA_TaggedUnionPayload zT_208;
    zT_54FF90FA_TaggedUnionPayload zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned short zT_212;
    unsigned int zT_214;
    unsigned int zT_216;
    unsigned int zT_218;
    zT_D155D06D_Type* zT_220;
    unsigned int zT_221;
    unsigned int zT_224;
    zT_D155D06D_Type zT_225;
    zT_D155D06D_Type* zT_226;
    unsigned int zT_227;
    unsigned int zT_230;
    zT_338B7C76_TypeRegistry* zT_231;
    zT_AF9231A2_UnionPayload zT_232;
    zT_AF9231A2_UnionPayload zT_233;
    unsigned int zT_234;
    unsigned short zT_235;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned int zT_242;
    zT_D155D06D_Type* zT_244;
    unsigned int zT_245;
    unsigned int zT_248;
    zT_D155D06D_Type zT_249;
    zT_D155D06D_Type* zT_250;
    unsigned int zT_251;
    unsigned int zT_254;
    zT_ABC1EBBE_TypeResolveEnv zT_259;
    zT_D3EB6303_StringInterner* zT_260;
    unsigned int zT_262;
    zT_6F34EEB2_Opt_229 zT_263 = {0};
    zT_05CE5599_Opt_400 zT_264 = {0};
    zT_03CE5273_Opt_402 zT_265 = {0};
    zT_939EE900_Arr_unsigned_int_1 zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    int zT_271;
    unsigned char zT_273;
    unsigned int zT_274;
    int zT_275;
    zT_ABC1EBBE_TypeResolveEnv* zT_278;
    unsigned int zT_279;
    unsigned int zT_284 = 0;
    unsigned char zT_287;
    int zT_290;
    unsigned char zT_291;
    unsigned int zT_293;
    unsigned int zT_294;
    int zT_296;
    unsigned int zT_297;
    int zT_299;
    unsigned int zT_300;
    int zT_302;
    unsigned int zT_303;
    zT_ABC1EBBE_TypeResolveEnv* zT_304;
    unsigned int zT_305;
    unsigned int* zT_310;
    unsigned int* zT_311;
    unsigned int* zT_312;
    unsigned char zT_321 = 0;
    zT_338B7C76_TypeRegistry* zT_322;
    zT_457ECFEE_EnumPayload zT_323;
    zT_457ECFEE_EnumPayload zT_324;
    unsigned int zT_325;
    unsigned short zT_326;
    int zT_327;
    unsigned int zT_328;
    unsigned int zT_330;
    unsigned int zT_332;
    unsigned int zT_334;
    zT_D155D06D_Type* zT_336;
    unsigned int zT_337;
    unsigned int zT_340;
    zT_D155D06D_Type zT_341;
    zT_D155D06D_Type* zT_342;
    unsigned int zT_343;
    unsigned int zT_346;
    unsigned int zT_351;
    unsigned int zT_352;
    int zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_357;
    unsigned int zT_358;
    zT_6B0A7D14_AstStore* zT_359;
    unsigned int zT_360;
    unsigned int zT_363 = 0;
    int zT_364;
    unsigned int zT_366;
    zT_338B7C76_TypeRegistry* zT_367;
    zT_0B73C507_ErrorSetPayload zT_368;
    zT_0B73C507_ErrorSetPayload zT_369;
    unsigned short zT_370;
    unsigned int zT_372;
    unsigned int zT_374;
    unsigned int zT_376;
    zT_D155D06D_Type* zT_378;
    unsigned int zT_379;
    unsigned int zT_382;
    zT_D155D06D_Type zT_383;
    zT_D155D06D_Type* zT_384;
    unsigned int zT_385;
    unsigned int zT_388;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ti;
    zT_22A7C88B_AstNode efd;
    unsigned int tup_last;
    unsigned int tup_idx;
    zT_D155D06D_Type tty;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    unsigned int fail_node;
    unsigned int fail_kind;
    unsigned int en_last;
    unsigned int en_idx;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_6 = store;
    zT_7 = decl_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    if ((unsigned char)(zT_11 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_15 = store;
    zT_16 = decl_idx;
    zT_17 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    children_n = zT_17;
    zT_18 = 0;
    if ((unsigned char)(children_n == (unsigned int)zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_24 = node.flags;
    zT_23 = (unsigned short)((unsigned short)((unsigned short)zT_24) & (unsigned short)(32)) != (unsigned short)(0);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = type_reg->xt_len;
    zT_32 = (unsigned int)zT_31;
    estart = zT_32;
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    ecount = zT_35;
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    ti = zT_38;
    goto z_bb_10;
    z_bb_9:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_10:
    if ((unsigned char)(ti < children_n)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = store;
    zT_43 = store;
    zT_44 = decl_idx;
    zT_47 = zF_B10B1BC1_astStoreNodeExtraCh(zT_43, zT_44, (unsigned int)((unsigned int)ti));
    zT_42 = zT_47;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_41, zT_42);
    efd = zT_48;
    zT_49 = efd.kind;
    if ((unsigned char)(zT_49 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    zT_62 = 0;
    if ((unsigned char)(ecount > (unsigned int)zT_62)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_59 = 1;
    zT_61 = ti + (unsigned int)((unsigned int)zT_59);
    ti = zT_61;
    goto z_bb_10;
    z_bb_14:
    zT_53 = type_reg;
    zF_4C03AE3D_xtAppend(zT_53, (unsigned int)(1));
    zT_56 = 1;
    zT_58 = ecount + (unsigned int)((unsigned int)zT_56);
    ecount = zT_58;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_64 = type_reg;
    zT_66.elems_start = estart;
    zT_67 = (unsigned short)ecount;
    zT_66.elems_count = zT_67;
    zT_65 = zT_66;
    zF_C94DF842_tupAppend(zT_64, zT_65);
    zT_69 = type_reg->tup_len;
    zT_71 = zT_69 - (unsigned int)(1);
    tup_last = zT_71;
    zT_73 = (unsigned int)tup_last;
    tup_idx = zT_73;
    zT_75 = type_reg->types_items;
    zT_76 = type_reg->types_len;
    zT_79 = (unsigned int)(unsigned int)(zT_76 - (unsigned int)(1));
    zT_80 = zT_75[zT_79];
    tty = zT_80;
    tty.payload_idx = tup_idx;
    zT_81 = type_reg->types_items;
    zT_82 = type_reg->types_len;
    zT_85 = (unsigned int)(unsigned int)(zT_82 - (unsigned int)(1));
    zT_81[zT_85] = tty;
    goto z_bb_17;
    z_bb_17:
    return;
    z_bb_18:
    zT_90 = type_reg->fe_len;
    zT_91 = (unsigned int)zT_90;
    fstart = zT_91;
    zT_93 = 0;
    zT_94 = (unsigned int)zT_93;
    fcount = zT_94;
    zT_96 = 0;
    zT_97 = (unsigned int)zT_96;
    i = zT_97;
    goto z_bb_20;
    z_bb_19:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_28; else goto z_bb_29;
    z_bb_20:
    if ((unsigned char)(i < children_n)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_100 = store;
    zT_102 = store;
    zT_103 = decl_idx;
    zT_106 = zF_B10B1BC1_astStoreNodeExtraCh(zT_102, zT_103, (unsigned int)((unsigned int)i));
    zT_101 = zT_106;
    zT_107 = zF_FCDD1D35_astStoreNodeAt(zT_100, zT_101);
    fd = zT_107;
    zT_108 = fd.kind;
    if ((unsigned char)(zT_108 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    zT_131 = 0;
    if ((unsigned char)(fcount > (unsigned int)zT_131)) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_112 = type_reg;
    zT_115 = store;
    zT_117 = store;
    zT_118 = decl_idx;
    zT_121 = zF_B10B1BC1_astStoreNodeExtraCh(zT_117, zT_118, (unsigned int)((unsigned int)i));
    zT_116 = zT_121;
    zT_122 = zF_8BA26B9E_astStoreNodePayload(zT_115, zT_116);
    zT_114.name_id = zT_122;
    zT_123 = 1;
    zT_114.type_id = zT_123;
    zT_124 = 0;
    zT_114.offset = zT_124;
    zT_113 = zT_114;
    zF_701DF154_feAppend(zT_112, zT_113);
    zT_125 = 1;
    zT_127 = fcount + (unsigned int)((unsigned int)zT_125);
    fcount = zT_127;
    goto z_bb_25;
    z_bb_25:
    zT_128 = 1;
    zT_130 = i + (unsigned int)((unsigned int)zT_128);
    i = zT_130;
    goto z_bb_23;
    z_bb_26:
    zT_133 = type_reg;
    zT_136 = (unsigned int)fstart;
    zT_135.fields_start = zT_136;
    zT_137 = (unsigned short)fcount;
    zT_135.fields_count = zT_137;
    zT_134 = zT_135;
    zF_CF849366_stAppend(zT_133, zT_134);
    goto z_bb_27;
    z_bb_27:
    zT_139 = type_reg->st_len;
    zT_141 = zT_139 - (unsigned int)(1);
    st_last = zT_141;
    zT_143 = (unsigned int)st_last;
    st_idx = zT_143;
    zT_145 = type_reg->types_items;
    zT_146 = type_reg->types_len;
    zT_149 = (unsigned int)(unsigned int)(zT_146 - (unsigned int)(1));
    zT_150 = zT_145[zT_149];
    ty = zT_150;
    ty.payload_idx = st_idx;
    zT_151 = type_reg->types_items;
    zT_152 = type_reg->types_len;
    zT_155 = (unsigned int)(unsigned int)(zT_152 - (unsigned int)(1));
    zT_151[zT_155] = ty;
    goto z_bb_19;
    z_bb_28:
    zT_160 = type_reg->fe_len;
    zT_161 = (unsigned int)zT_160;
    fstart = zT_161;
    zT_163 = 0;
    zT_164 = (unsigned int)zT_163;
    fcount = zT_164;
    zT_166 = 0;
    zT_167 = (unsigned int)zT_166;
    i = zT_167;
    goto z_bb_30;
    z_bb_29:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_39; else goto z_bb_40;
    z_bb_30:
    if ((unsigned char)(i < children_n)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_170 = store;
    zT_172 = store;
    zT_173 = decl_idx;
    zT_176 = zF_B10B1BC1_astStoreNodeExtraCh(zT_172, zT_173, (unsigned int)((unsigned int)i));
    zT_171 = zT_176;
    zT_177 = zF_FCDD1D35_astStoreNodeAt(zT_170, zT_171);
    fd = zT_177;
    zT_178 = fd.kind;
    if ((unsigned char)(zT_178 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    zT_201 = node.flags;
    zT_203 = 1;
    zT_205 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_201) & zT_203) != zT_205)) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_182 = type_reg;
    zT_185 = store;
    zT_187 = store;
    zT_188 = decl_idx;
    zT_191 = zF_B10B1BC1_astStoreNodeExtraCh(zT_187, zT_188, (unsigned int)((unsigned int)i));
    zT_186 = zT_191;
    zT_192 = zF_8BA26B9E_astStoreNodePayload(zT_185, zT_186);
    zT_184.name_id = zT_192;
    zT_193 = 1;
    zT_184.type_id = zT_193;
    zT_194 = 0;
    zT_184.offset = zT_194;
    zT_183 = zT_184;
    zF_701DF154_feAppend(zT_182, zT_183);
    zT_195 = 1;
    zT_197 = fcount + (unsigned int)((unsigned int)zT_195);
    fcount = zT_197;
    goto z_bb_35;
    z_bb_35:
    zT_198 = 1;
    zT_200 = i + (unsigned int)((unsigned int)zT_198);
    i = zT_200;
    goto z_bb_33;
    z_bb_36:
    zT_207 = type_reg;
    zT_210 = 10;
    zT_209.tag_type = zT_210;
    zT_211 = (unsigned int)fstart;
    zT_209.fields_start = zT_211;
    zT_212 = (unsigned short)fcount;
    zT_209.fields_count = zT_212;
    zT_208 = zT_209;
    zF_FB6B57C6_tuAppend(zT_207, zT_208);
    zT_214 = type_reg->tu_len;
    zT_216 = zT_214 - (unsigned int)(1);
    tu_last = zT_216;
    zT_218 = (unsigned int)tu_last;
    tu_idx = zT_218;
    zT_220 = type_reg->types_items;
    zT_221 = type_reg->types_len;
    zT_224 = (unsigned int)(unsigned int)(zT_221 - (unsigned int)(1));
    zT_225 = zT_220[zT_224];
    ty = zT_225;
    ty.payload_idx = tu_idx;
    zT_226 = type_reg->types_items;
    zT_227 = type_reg->types_len;
    zT_230 = (unsigned int)(unsigned int)(zT_227 - (unsigned int)(1));
    zT_226[zT_230] = ty;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_29;
    z_bb_38:
    zT_231 = type_reg;
    zT_234 = (unsigned int)fstart;
    zT_233.fields_start = zT_234;
    zT_235 = (unsigned short)fcount;
    zT_233.fields_count = zT_235;
    zT_236 = 1;
    zT_233.tag_type = zT_236;
    zT_232 = zT_233;
    zF_1718422E_unAppend(zT_231, zT_232);
    zT_238 = type_reg->un_len;
    zT_240 = zT_238 - (unsigned int)(1);
    un_last = zT_240;
    zT_242 = (unsigned int)un_last;
    un_idx = zT_242;
    zT_244 = type_reg->types_items;
    zT_245 = type_reg->types_len;
    zT_248 = (unsigned int)(unsigned int)(zT_245 - (unsigned int)(1));
    zT_249 = zT_244[zT_248];
    ty = zT_249;
    ty.payload_idx = un_idx;
    zT_250 = type_reg->types_items;
    zT_251 = type_reg->types_len;
    zT_254 = (unsigned int)(unsigned int)(zT_251 - (unsigned int)(1));
    zT_250[zT_254] = ty;
    goto z_bb_37;
    z_bb_39:
    zT_259.store = store;
    zT_259.typereg = type_reg;
    zT_259.symbol_reg = sym_reg;
    zT_260 = type_reg->interner;
    zT_259.interner = zT_260;
    zT_259.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_262 = 0;
    zT_259.source_file_id = zT_262;
    zT_263.has_value = 0;
    zT_259.diag = zT_263;
    zT_264.has_value = 0;
    zT_259.local_consts = zT_264;
    zT_265.has_value = 0;
    zT_259.local_types = zT_265;
    tre_env = zT_259;
    zT_268 = 0;
    zT_269 = 0;
    zT_267[zT_269] = zT_268;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_267[_i];
        _i++;
    }
}
    zT_270 = 10;
    zT_271 = 0;
    backing_box[zT_271] = zT_270;
    zT_273 = 0;
    expl_flag = zT_273;
    zT_274 = node.child_0;
    zT_275 = 0;
    if ((unsigned char)(zT_274 != (unsigned int)zT_275)) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_48; else goto z_bb_49;
    z_bb_41:
    zT_278 = &tre_env;
    zT_279 = node.child_0;
    zT_284 = zF_F2107C15_resolveTypeExprFull(zT_278, zT_279, (unsigned int)(0));
    bt = zT_284;
    if ((unsigned char)(bt != (unsigned int)(18))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_293 = type_reg->em_len;
    zT_294 = (unsigned int)zT_293;
    mstart = zT_294;
    zT_296 = 0;
    zT_297 = (unsigned int)zT_296;
    mcount = zT_297;
    zT_299 = 0;
    zT_300 = (unsigned int)zT_299;
    fail_node = zT_300;
    zT_302 = 0;
    zT_303 = (unsigned int)zT_302;
    fail_kind = zT_303;
    zT_304 = &tre_env;
    zT_305 = decl_idx;
    zT_310 = &mcount;
    zT_311 = &fail_node;
    zT_312 = &fail_kind;
    zT_321 = zF_0FFDEDBD_enumMembersResolve(zT_304, zT_305, (unsigned char)(1), (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), zT_310, zT_311, zT_312);
    (void)zT_321;
    zT_322 = type_reg;
    zT_325 = (unsigned int)mstart;
    zT_324.members_start = zT_325;
    zT_326 = (unsigned short)mcount;
    zT_324.members_count = zT_326;
    zT_327 = 0;
    zT_328 = backing_box[zT_327];
    zT_324.backing_type = zT_328;
    zT_324.explicit_backing = expl_flag;
    zT_323 = zT_324;
    zF_298371DE_enAppend(zT_322, zT_323);
    zT_330 = type_reg->en_len;
    zT_332 = zT_330 - (unsigned int)(1);
    en_last = zT_332;
    zT_334 = (unsigned int)en_last;
    en_idx = zT_334;
    zT_336 = type_reg->types_items;
    zT_337 = type_reg->types_len;
    zT_340 = (unsigned int)(unsigned int)(zT_337 - (unsigned int)(1));
    zT_341 = zT_336[zT_340];
    ty = zT_341;
    ty.payload_idx = en_idx;
    zT_342 = type_reg->types_items;
    zT_343 = type_reg->types_len;
    zT_346 = (unsigned int)(unsigned int)(zT_343 - (unsigned int)(1));
    zT_342[zT_346] = ty;
    goto z_bb_40;
    z_bb_43:
    zT_287 = bt != (unsigned int)(1);
    goto z_bb_45;
    z_bb_44:
    zT_287 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_287) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_290 = 0;
    backing_box[zT_290] = bt;
    goto z_bb_47;
    z_bb_47:
    zT_291 = 1;
    expl_flag = zT_291;
    goto z_bb_42;
    z_bb_48:
    zT_351 = type_reg->xn_len;
    zT_352 = (unsigned int)zT_351;
    tags_start_idx = zT_352;
    zT_354 = 0;
    zT_355 = (unsigned int)zT_354;
    i = zT_355;
    goto z_bb_50;
    z_bb_49:
    return;
    z_bb_50:
    if ((unsigned char)(i < children_n)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_357 = type_reg;
    zT_359 = store;
    zT_360 = decl_idx;
    zT_363 = zF_B10B1BC1_astStoreNodeExtraCh(zT_359, zT_360, (unsigned int)((unsigned int)i));
    zT_358 = zT_363;
    zF_A648B1CB_xnAppend(zT_357, zT_358);
    goto z_bb_53;
    z_bb_52:
    zT_367 = type_reg;
    zT_369.tags_start = tags_start_idx;
    zT_370 = (unsigned short)children_n;
    zT_369.tags_count = zT_370;
    zT_368 = zT_369;
    zF_B86143DD_esAppend(zT_367, zT_368);
    zT_372 = type_reg->es_len;
    zT_374 = zT_372 - (unsigned int)(1);
    es_last = zT_374;
    zT_376 = (unsigned int)es_last;
    es_idx = zT_376;
    zT_378 = type_reg->types_items;
    zT_379 = type_reg->types_len;
    zT_382 = (unsigned int)(unsigned int)(zT_379 - (unsigned int)(1));
    zT_383 = zT_378[zT_382];
    ty = zT_383;
    ty.payload_idx = es_idx;
    zT_384 = type_reg->types_items;
    zT_385 = type_reg->types_len;
    zT_388 = (unsigned int)(unsigned int)(zT_385 - (unsigned int)(1));
    zT_384[zT_388] = ty;
    goto z_bb_49;
    z_bb_53:
    zT_364 = 1;
    zT_366 = i + (unsigned int)((unsigned int)zT_364);
    i = zT_366;
    goto z_bb_50;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, unsigned char populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_3C598AEF_SymbolKind zT_57;
    unsigned int zT_60;
    unsigned int zT_61;
    int zT_62;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    zT_072B53A6_ModuleRegistry* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_79 = 0;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101 = 0;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned char zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_3C598AEF_SymbolKind zT_121;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_128;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    int zT_134;
    unsigned char* zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138 = 0;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_156;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    int zT_162;
    unsigned char* zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166 = 0;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_184;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    int zT_190;
    unsigned char* zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194 = 0;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208 = 0;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    zT_8143F551_AstKind zT_214;
    unsigned char zT_218;
    zT_8143F551_AstKind zT_219;
    unsigned char zT_223;
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    zT_8143F551_AstKind zT_229;
    zT_8143F551_AstKind zT_234;
    zT_33EF6BFB_TypeKind zT_235;
    unsigned char zT_236;
    int zT_240;
    zT_33EF6BFB_TypeKind zT_242;
    unsigned char zT_249;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char zT_258;
    int zT_260;
    int zT_262;
    zT_33EF6BFB_TypeKind zT_264;
    zT_338B7C76_TypeRegistry* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    unsigned int zT_277 = 0;
    zT_8143F551_AstKind zT_278;
    unsigned char zT_282;
    zT_8143F551_AstKind zT_283;
    unsigned char zT_287;
    unsigned char zT_288;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    zT_338B7C76_TypeRegistry* zT_296;
    zT_6B0A7D14_AstStore* zT_297;
    zT_8143F551_AstKind zT_298;
    unsigned int zT_299;
    zT_3D7259E2_SymbolRegistry* zT_300;
    zT_6B0A7D14_AstStore* zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    zT_4D61441E_DepGraph* zT_306;
    zT_3C598AEF_SymbolKind zT_309;
    zT_8143F551_AstKind zT_310;
    unsigned char* zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    unsigned int zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    unsigned int zT_319;
    zT_6B0A7D14_AstStore* zT_320;
    unsigned int zT_321;
    unsigned int zT_323 = 0;
    zT_6B0A7D14_AstStore* zT_325;
    unsigned int zT_326;
    unsigned int zT_328 = 0;
    unsigned char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    zT_338B7C76_TypeRegistry* zT_336;
    zT_BAEE192E_Opt_10 zT_343 = {0};
    unsigned char zT_344;
    zT_338B7C76_TypeRegistry* zT_346;
    zT_BAEE192E_Opt_10 zT_349 = {0};
    unsigned char zT_350;
    unsigned char* zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned int zT_357;
    zT_79FAE712_u64 zT_363;
    zT_338B7C76_TypeRegistry* zT_364;
    zT_79FAE712_u64 zT_365;
    unsigned int zT_366;
    zT_3C598AEF_SymbolKind zT_368;
    unsigned char zT_370;
    zT_D3EB6303_StringInterner* zT_372;
    unsigned int zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned char* zT_377;
    unsigned int zT_379 = 0;
    zT_338B7C76_TypeRegistry* zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned int zT_385 = 0;
    zT_79FAE712_u64 zT_393;
    zT_338B7C76_TypeRegistry* zT_394;
    zT_79FAE712_u64 zT_395;
    unsigned int zT_396;
    zT_3C598AEF_SymbolKind zT_398;
    zT_8143F551_AstKind zT_399;
    unsigned char zT_403;
    zT_8143F551_AstKind zT_404;
    unsigned char zT_408;
    zT_8143F551_AstKind zT_409;
    unsigned char zT_413;
    zT_8143F551_AstKind zT_414;
    unsigned char zT_418;
    zT_8143F551_AstKind zT_419;
    unsigned char zT_423;
    zT_8143F551_AstKind zT_424;
    unsigned char zT_428;
    zT_8143F551_AstKind zT_429;
    unsigned char* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    unsigned int zT_438;
    zT_338B7C76_TypeRegistry* zT_440;
    zT_BAEE192E_Opt_10 zT_447 = {0};
    unsigned char zT_448;
    zT_338B7C76_TypeRegistry* zT_450;
    zT_BAEE192E_Opt_10 zT_453 = {0};
    unsigned char zT_454;
    zT_3C598AEF_SymbolKind zT_457;
    zT_3A105EF1_Symbol zT_459;
    unsigned char zT_460;
    unsigned short zT_461;
    zT_E41AEC18_ModuleEntryArrayLis zT_462;
    zT_6E8D187B_ModuleEntry* zT_463;
    unsigned int zT_464;
    zT_6E8D187B_ModuleEntry zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    zT_3D7259E2_SymbolRegistry* zT_469;
    unsigned int zT_470;
    zT_060CD1EB_SymbolTable* zT_471 = 0;
    zT_060CD1EB_SymbolTable* zT_473;
    zT_3A105EF1_Symbol zT_474;
    unsigned char zT_475 = 0;
    unsigned char* zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    unsigned int zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned char* zT_483;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_484;
    unsigned int zT_485;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_486;
    zT_4028D896_Arr_unsigned_char_2 zT_488;
    unsigned int zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    int zT_494;
    unsigned char* zT_495;
    unsigned int zT_496;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_497;
    unsigned int zT_498 = 0;
    unsigned int zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    unsigned char* zT_509;
    unsigned int zT_510;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_511;
    unsigned char* zT_513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_514;
    unsigned int zT_515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_516;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    int zT_523;
    unsigned char* zT_524;
    unsigned int zT_525;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_526;
    unsigned int zT_527 = 0;
    unsigned int zT_533;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_534;
    unsigned char* zT_538;
    unsigned int zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    unsigned char* zT_542;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_543;
    unsigned int zT_544;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_545;
    unsigned char* zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    unsigned int zT_549;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_550;
    zT_0AEE6C4B_anon_274206 zT_552;
    zT_243D6A41_FnProto* zT_553;
    zT_6B0A7D14_AstStore* zT_554;
    unsigned int zT_555;
    unsigned int zT_556 = 0;
    unsigned int zT_557;
    zT_243D6A41_FnProto zT_558;
    zT_3A105EF1_Symbol zT_560;
    unsigned int zT_561;
    unsigned int zT_562;
    zT_3C598AEF_SymbolKind zT_564;
    unsigned char zT_565;
    unsigned short zT_566;
    zT_E41AEC18_ModuleEntryArrayLis zT_567;
    zT_6E8D187B_ModuleEntry* zT_568;
    unsigned int zT_569;
    zT_6E8D187B_ModuleEntry zT_570;
    unsigned int zT_571;
    unsigned int zT_572;
    zT_3D7259E2_SymbolRegistry* zT_574;
    unsigned int zT_575;
    zT_060CD1EB_SymbolTable* zT_576 = 0;
    zT_060CD1EB_SymbolTable* zT_577;
    zT_3A105EF1_Symbol zT_578;
    unsigned char zT_579 = 0;
    zT_6B0A7D14_AstStore* zT_580;
    unsigned int zT_581;
    unsigned int zT_582 = 0;
    zT_3A105EF1_Symbol zT_586;
    zT_6B0A7D14_AstStore* zT_587;
    unsigned int zT_588;
    unsigned int zT_589 = 0;
    unsigned int zT_590;
    zT_3C598AEF_SymbolKind zT_592;
    unsigned char zT_593;
    unsigned short zT_594;
    zT_E41AEC18_ModuleEntryArrayLis zT_595;
    zT_6E8D187B_ModuleEntry* zT_596;
    unsigned int zT_597;
    zT_6E8D187B_ModuleEntry zT_598;
    unsigned int zT_599;
    unsigned int zT_600;
    zT_3D7259E2_SymbolRegistry* zT_602;
    unsigned int zT_603;
    zT_060CD1EB_SymbolTable* zT_604 = 0;
    zT_060CD1EB_SymbolTable* zT_605;
    zT_3A105EF1_Symbol zT_606;
    unsigned char zT_607 = 0;
    zT_6B0A7D14_AstStore* zT_609;
    unsigned int zT_610;
    zT_8143F551_AstKind zT_611;
    zT_79FAE712_u64 zT_613 = 0;
    unsigned int zT_616;
    zT_8143F551_AstKind zT_618;
    zT_33EF6BFB_TypeKind zT_619;
    unsigned char zT_620;
    int zT_624;
    zT_33EF6BFB_TypeKind zT_626;
    unsigned char zT_633;
    int zT_637;
    zT_33EF6BFB_TypeKind zT_639;
    unsigned char zT_642;
    int zT_644;
    int zT_646;
    zT_33EF6BFB_TypeKind zT_648;
    zT_338B7C76_TypeRegistry* zT_656;
    unsigned int zT_657;
    unsigned int zT_658;
    zT_33EF6BFB_TypeKind zT_659;
    unsigned int zT_660 = 0;
    zT_8143F551_AstKind zT_661;
    unsigned char zT_665;
    zT_8143F551_AstKind zT_666;
    unsigned char zT_670;
    unsigned char zT_671;
    zT_338B7C76_TypeRegistry* zT_677;
    unsigned int zT_678;
    zT_338B7C76_TypeRegistry* zT_679;
    zT_6B0A7D14_AstStore* zT_680;
    zT_8143F551_AstKind zT_681;
    unsigned int zT_682;
    zT_3D7259E2_SymbolRegistry* zT_683;
    zT_6B0A7D14_AstStore* zT_685;
    unsigned int zT_686;
    unsigned int zT_687;
    zT_4D61441E_DepGraph* zT_688;
    zT_3A105EF1_Symbol zT_690;
    zT_3C598AEF_SymbolKind zT_692;
    unsigned char zT_693;
    unsigned short zT_694;
    zT_E41AEC18_ModuleEntryArrayLis zT_695;
    zT_6E8D187B_ModuleEntry* zT_696;
    unsigned int zT_697;
    zT_6E8D187B_ModuleEntry zT_698;
    unsigned int zT_699;
    unsigned int zT_700;
    zT_3D7259E2_SymbolRegistry* zT_702;
    unsigned int zT_703;
    zT_060CD1EB_SymbolTable* zT_704 = 0;
    zT_060CD1EB_SymbolTable* zT_705;
    zT_3A105EF1_Symbol zT_706;
    unsigned char zT_707 = 0;
    zT_6B0A7D14_AstStore* zT_709;
    unsigned int zT_710;
    zT_8143F551_AstKind zT_711;
    zT_79FAE712_u64 zT_713 = 0;
    unsigned int zT_716;
    zT_338B7C76_TypeRegistry* zT_718;
    unsigned int zT_719;
    unsigned int zT_720;
    unsigned int zT_724 = 0;
    zT_338B7C76_TypeRegistry* zT_725;
    zT_6B0A7D14_AstStore* zT_726;
    zT_8143F551_AstKind zT_727;
    unsigned int zT_728;
    zT_3D7259E2_SymbolRegistry* zT_729;
    zT_3A105EF1_Symbol zT_732;
    zT_3C598AEF_SymbolKind zT_734;
    unsigned char zT_735;
    unsigned short zT_736;
    zT_E41AEC18_ModuleEntryArrayLis zT_737;
    zT_6E8D187B_ModuleEntry* zT_738;
    unsigned int zT_739;
    zT_6E8D187B_ModuleEntry zT_740;
    unsigned int zT_741;
    unsigned int zT_742;
    zT_3D7259E2_SymbolRegistry* zT_744;
    unsigned int zT_745;
    zT_060CD1EB_SymbolTable* zT_746 = 0;
    zT_060CD1EB_SymbolTable* zT_747;
    zT_3A105EF1_Symbol zT_748;
    unsigned char zT_749 = 0;
    zT_6B0A7D14_AstStore* zT_751;
    unsigned int zT_752;
    unsigned int zT_753 = 0;
    zT_072B53A6_ModuleRegistry* zT_755;
    unsigned int zT_756;
    zT_BAEE192E_Opt_10 zT_757 = {0};
    unsigned char zT_758;
    zT_3A105EF1_Symbol zT_761;
    zT_338B7C76_TypeRegistry* zT_762;
    unsigned int zT_763;
    unsigned int zT_764 = 0;
    zT_3C598AEF_SymbolKind zT_766;
    unsigned short zT_767;
    zT_E41AEC18_ModuleEntryArrayLis zT_768;
    zT_6E8D187B_ModuleEntry* zT_769;
    unsigned int zT_770;
    zT_6E8D187B_ModuleEntry zT_771;
    unsigned int zT_772;
    unsigned int zT_773;
    zT_3D7259E2_SymbolRegistry* zT_775;
    unsigned int zT_776;
    zT_060CD1EB_SymbolTable* zT_777 = 0;
    zT_060CD1EB_SymbolTable* zT_778;
    zT_3A105EF1_Symbol zT_779;
    unsigned char zT_780 = 0;
    unsigned char* zT_782;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_783;
    unsigned int zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_787;
    unsigned int zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    int zT_793;
    unsigned char* zT_794;
    unsigned int zT_795;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_796;
    unsigned int zT_797 = 0;
    unsigned int zT_801;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_802;
    unsigned char* zT_806;
    unsigned int zT_807;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_808;
    unsigned char* zT_810;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811;
    unsigned int zT_812;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_813;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_815;
    unsigned int zT_817;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_818;
    int zT_821;
    unsigned char* zT_822;
    unsigned int zT_823;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_824;
    unsigned int zT_825 = 0;
    unsigned int zT_829;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_830;
    unsigned char* zT_834;
    unsigned int zT_835;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_836;
    unsigned char* zT_838;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_839;
    unsigned int zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    unsigned char inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    unsigned char arb_u;
    zT_8F083A69_Slice_zT_0B42B2F8_u ident_text;
    unsigned int arb_tid;
    zT_79FAE712_u64 atk;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_28[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_42 = (unsigned int)(19) - (unsigned int)((unsigned int)d12l);
    d12s = zT_42;
    zT_47 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_48 = (unsigned int)(19) - d12s;
    zT_49.ptr = zT_47;
    zT_49.len = zT_48;
    zT_43 = zT_49;
    zF_B5478454_measureMarkerWrite(zT_43);
    zT_51 = "\n";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    d12nl = zT_52;
    zT_54 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_54);
    zT_57 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_57;
    sym_mod_id = mod_id;
    zT_60 = 0;
    sym_type_id = zT_60;
    zT_61 = node.child_1;
    zT_62 = 0;
    if ((unsigned char)(zT_61 != (unsigned int)zT_62)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_552 = store->fn_protos;
    zT_553 = zT_552.items;
    zT_554 = store;
    zT_555 = decl_idx;
    zT_556 = zF_8BA26B9E_astStoreNodePayload(zT_554, zT_555);
    zT_557 = (unsigned int)zT_556;
    zT_558 = zT_553[zT_557];
    proto = zT_558;
    zT_561 = proto.name_id;
    zT_560.name_id = zT_561;
    zT_562 = 0;
    zT_560.type_id = zT_562;
    zT_564 = zT_3C598AEF_SymbolKind_function;
    zT_560.kind = zT_564;
    zT_565 = node.flags;
    zT_566 = (unsigned short)zT_565;
    zT_560.flags = zT_566;
    zT_560.decl_node = decl_idx;
    zT_560.module_id = mod_id;
    zT_567 = reg->modules;
    zT_568 = zT_567.items;
    zT_569 = (unsigned int)mod_id;
    zT_570 = zT_568[zT_569];
    zT_571 = zT_570.source_file_id;
    zT_560.file_id = zT_571;
    zT_572 = 0;
    zT_560.scope_level = zT_572;
    sym = zT_560;
    zT_574 = sym_reg;
    zT_575 = mod_id;
    zT_576 = zF_9B36C202_symbolRegistryGetTa(zT_574, zT_575);
    table = zT_576;
    zT_577 = table;
    zT_578 = sym;
    zT_579 = zF_D0156DDA_symbolTableInsert(zT_577, zT_578);
    (void)zT_579;
    goto z_bb_9;
    z_bb_3:
    zT_580 = store;
    zT_581 = decl_idx;
    zT_582 = zF_8BA26B9E_astStoreNodePayload(zT_580, zT_581);
    if ((unsigned char)(zT_582 != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_4:
    zT_609 = store;
    zT_610 = decl_idx;
    zT_611 = node.kind;
    zT_613 = zF_0E4E10C6_astStoreNodePayload(zT_609, zT_610, zT_611);
    zT_616 = (unsigned int)(zT_79FAE712_u64)(zT_613 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_616;
    zT_618 = node.kind;
switch (zT_618) {
case 3: goto z_bb_95;
case 4: goto z_bb_96;
case 5: goto z_bb_97;
default: goto z_bb_98;
}
    z_bb_5:
    zT_709 = store;
    zT_710 = decl_idx;
    zT_711 = node.kind;
    zT_713 = zF_0E4E10C6_astStoreNodePayload(zT_709, zT_710, zT_711);
    zT_716 = (unsigned int)(zT_79FAE712_u64)(zT_713 & (zT_79FAE712_u64)(4294967295u));
    name_id = zT_716;
    zT_718 = type_reg;
    zT_719 = mod_id;
    zT_720 = name_id;
    zT_724 = zF_3A64E2E0_typeRegistryRegiste(zT_718, zT_719, zT_720, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_724;
    if (populate) goto z_bb_120; else goto z_bb_121;
    z_bb_6:
    zT_751 = store;
    zT_752 = decl_idx;
    zT_753 = zF_8BA26B9E_astStoreNodePayload(zT_751, zT_752);
    path_id = zT_753;
    zT_755 = reg;
    zT_756 = path_id;
    zT_757 = zF_A258E183_moduleRegistryPathT(zT_755, zT_756);
    target_mod_id = zT_757;
    zT_758 = target_mod_id.has_value;
    if (zT_758) goto z_bb_122; else goto z_bb_123;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_65 = store;
    zT_66 = node.child_1;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    init_node = zT_68;
    zT_69 = init_node.kind;
    if ((unsigned char)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_459.name_id = name_id;
    zT_459.type_id = sym_type_id;
    zT_459.kind = sym_kind;
    zT_460 = node.flags;
    zT_461 = (unsigned short)zT_460;
    zT_459.flags = zT_461;
    zT_459.decl_node = decl_idx;
    zT_459.module_id = sym_mod_id;
    zT_462 = reg->modules;
    zT_463 = zT_462.items;
    zT_464 = (unsigned int)mod_id;
    zT_465 = zT_463[zT_464];
    zT_466 = zT_465.source_file_id;
    zT_459.file_id = zT_466;
    zT_467 = 0;
    zT_459.scope_level = zT_467;
    sym = zT_459;
    zT_469 = sym_reg;
    zT_470 = mod_id;
    zT_471 = zF_9B36C202_symbolRegistryGetTa(zT_469, zT_470);
    table = zT_471;
    zT_473 = table;
    zT_474 = sym;
    zT_475 = zF_D0156DDA_symbolTableInsert(zT_473, zT_474);
    inserted = zT_475;
    if ((unsigned char)(!inserted)) goto z_bb_91; else goto z_bb_92;
    z_bb_12:
    zT_74 = reg;
    zT_76 = store;
    zT_77 = node.child_1;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_76, zT_77);
    zT_75 = zT_79;
    zT_80 = zF_A258E183_moduleRegistryPathT(zT_74, zT_75);
    target = zT_80;
    zT_82 = "M5:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    m5m = zT_83;
    zT_85 = m5m;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_91 = store;
    zT_92 = node.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_94;
    zT_97 = 0;
    zT_98 = (unsigned char*)((unsigned char*)m5pb) + zT_97;
    zT_99 = (unsigned int)(20) - zT_97;
    zT_100.ptr = zT_98;
    zT_100.len = zT_99;
    zT_90 = zT_100;
    zT_101 = zF_A7504564_itoa(zT_89, zT_90);
    m5pl = zT_101;
    zT_105 = (unsigned int)(19) - (unsigned int)((unsigned int)m5pl);
    m5ps = zT_105;
    zT_110 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_111 = (unsigned int)(19) - m5ps;
    zT_112.ptr = zT_110;
    zT_112.len = zT_111;
    zT_106 = zT_112;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_113 = target.has_value;
    if (zT_113) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_214 = init_node.kind;
    if ((unsigned char)(zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    mtid = target.value;
    zT_116 = "Rs";
    zT_118 = 2;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    rs_msg = zT_117;
    zT_119 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_119);
    zT_121 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_121;
    sym_mod_id = mtid;
    zT_123 = "FIX1:mid=";
    zT_125 = 9;
    zT_124.ptr = zT_123;
    zT_124.len = zT_125;
    di_m = zT_124;
    zT_126 = di_m;
    zF_48AC7B3A_markerWrite(zT_126);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_128[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_128[_i];
        _i++;
    }
}
    zT_130 = sym_mod_id;
    zT_134 = 0;
    zT_135 = (unsigned char*)((unsigned char*)di_mb) + zT_134;
    zT_136 = (unsigned int)(10) - zT_134;
    zT_137.ptr = zT_135;
    zT_137.len = zT_136;
    zT_131 = zT_137;
    zT_138 = zF_A7504564_itoa(zT_130, zT_131);
    di_ml = zT_138;
    zT_142 = (unsigned int)(9) - (unsigned int)((unsigned int)di_ml);
    di_ms = zT_142;
    zT_147 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_148 = (unsigned int)(9) - di_ms;
    zT_149.ptr = zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zF_48AC7B3A_markerWrite(zT_143);
    zT_151 = "t";
    zT_153 = 1;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    di_t = zT_152;
    zT_154 = di_t;
    zF_48AC7B3A_markerWrite(zT_154);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_156[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_156[_i];
        _i++;
    }
}
    zT_158 = mtid;
    zT_162 = 0;
    zT_163 = (unsigned char*)((unsigned char*)di_tb) + zT_162;
    zT_164 = (unsigned int)(10) - zT_162;
    zT_165.ptr = zT_163;
    zT_165.len = zT_164;
    zT_159 = zT_165;
    zT_166 = zF_A7504564_itoa(zT_158, zT_159);
    di_tl = zT_166;
    zT_170 = (unsigned int)(9) - (unsigned int)((unsigned int)di_tl);
    di_ts = zT_170;
    zT_175 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_176 = (unsigned int)(9) - di_ts;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_179 = "n";
    zT_181 = 1;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    di_n = zT_180;
    zT_182 = di_n;
    zF_48AC7B3A_markerWrite(zT_182);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_184[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_184[_i];
        _i++;
    }
}
    zT_186 = mod_id;
    zT_190 = 0;
    zT_191 = (unsigned char*)((unsigned char*)di_nb) + zT_190;
    zT_192 = (unsigned int)(10) - zT_190;
    zT_193.ptr = zT_191;
    zT_193.len = zT_192;
    zT_187 = zT_193;
    zT_194 = zF_A7504564_itoa(zT_186, zT_187);
    di_nl = zT_194;
    zT_198 = (unsigned int)(9) - (unsigned int)((unsigned int)di_nl);
    di_ns = zT_198;
    zT_203 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_204 = (unsigned int)(9) - di_ns;
    zT_205.ptr = zT_203;
    zT_205.len = zT_204;
    zT_199 = zT_205;
    zF_48AC7B3A_markerWrite(zT_199);
    zT_206 = type_reg;
    zT_207 = mtid;
    zT_208 = zF_2ECA9F93_typeRegistryGetOrCr(zT_206, zT_207);
    sym_type_id = zT_208;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_210 = "Rf";
    zT_212 = 2;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    rf_msg = zT_211;
    zT_213 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_213);
    goto z_bb_15;
    z_bb_17:
    zT_219 = init_node.kind;
    zT_218 = zT_219 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_218 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_218) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_224 = init_node.kind;
    zT_223 = zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_223 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_223) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_229 = init_node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_228 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_228) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_234 = init_node.kind;
switch (zT_234) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_310 = init_node.kind;
    if ((unsigned char)(zT_310 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_55; else goto z_bb_57;
    z_bb_29:
    zT_236 = init_node.flags;
    zT_240 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_236) & (unsigned short)(32)) != zT_240)) goto z_bb_36; else goto z_bb_37;
    z_bb_30:
    zT_235 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_249 = init_node.flags;
    zT_253 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_249) & (unsigned short)(16)) != zT_253)) goto z_bb_39; else goto z_bb_40;
    z_bb_32:
    zT_235 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_235 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_235;
    zT_273 = type_reg;
    zT_274 = mod_id;
    zT_275 = name_id;
    zT_276 = type_kind;
    zT_277 = zF_3A64E2E0_typeRegistryRegiste(zT_273, zT_274, zT_275, zT_276);
    sym_type_id = zT_277;
    zT_278 = init_node.kind;
    if ((unsigned char)(zT_278 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_46; else goto z_bb_45;
    z_bb_36:
    zT_242 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_38;
    z_bb_37:
    zT_242 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_38;
    z_bb_38:
    zT_235 = zT_242;
    goto z_bb_35;
    z_bb_39:
    zT_255 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_258 = init_node.flags;
    zT_260 = 1;
    zT_262 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_258) & zT_260) != zT_262)) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_235 = zT_255;
    goto z_bb_35;
    z_bb_42:
    zT_264 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_44;
    z_bb_43:
    zT_264 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_44;
    z_bb_44:
    zT_255 = zT_264;
    goto z_bb_41;
    z_bb_45:
    zT_283 = init_node.kind;
    zT_282 = zT_283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_47;
    z_bb_46:
    zT_282 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_282) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_288 = init_node.flags;
    zT_287 = (unsigned short)((unsigned short)((unsigned short)zT_288) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_50;
    z_bb_49:
    zT_287 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_287) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_294 = type_reg;
    zT_295 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_294, zT_295);
    goto z_bb_52;
    z_bb_52:
    if (populate) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_296 = type_reg;
    zT_297 = store;
    zT_298 = init_node.kind;
    zT_299 = node.child_1;
    zT_300 = sym_reg;
    zF_020995FB_populateTypePayload(zT_296, zT_297, zT_298, zT_299, zT_300);
    goto z_bb_54;
    z_bb_54:
    zT_303 = store;
    zT_304 = node.child_1;
    zT_305 = sym_type_id;
    zT_306 = g;
    zF_4976C319_addTypeDependencies(zT_303, zT_304, zT_305, zT_306);
    zT_309 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_309;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_55:
    zT_315 = "RCA:p";
    zT_317 = 5;
    zT_316.ptr = zT_315;
    zT_316.len = zT_317;
    rca_m = zT_316;
    zT_318 = rca_m;
    zT_320 = store;
    zT_321 = node.child_1;
    zT_323 = zF_8BA26B9E_astStoreNodePayload(zT_320, zT_321);
    zT_319 = zT_323;
    zF_C914CB83_markerWriteInt(zT_318, zT_319);
    zT_325 = store;
    zT_326 = node.child_1;
    zT_328 = zF_53458827_astStoreIdentifier(zT_325, zT_326);
    ident_name_id = zT_328;
    zT_330 = "RCA:i";
    zT_332 = 5;
    zT_331.ptr = zT_330;
    zT_331.len = zT_332;
    rca_i = zT_331;
    zT_333 = rca_i;
    zT_334 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_333, zT_334);
    zT_336 = type_reg;
    zT_343 = zF_0EB68360_nameCacheGet(zT_336, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id)));
    cached = zT_343;
    zT_344 = cached.has_value;
    if ((unsigned char)(!zT_344)) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_27;
    z_bb_57:
    zT_399 = init_node.kind;
    if ((unsigned char)(zT_399 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_68; else goto z_bb_67;
    z_bb_58:
    zT_346 = type_reg;
    zT_349 = zF_0EB68360_nameCacheGet(zT_346, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_349;
    goto z_bb_59;
    z_bb_59:
    zT_350 = cached.has_value;
    if (zT_350) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    ct = cached.value;
    zT_353 = "RCA:H";
    zT_355 = 5;
    zT_354.ptr = zT_353;
    zT_354.len = zT_355;
    rca_h = zT_354;
    zT_356 = rca_h;
    zT_357 = ct;
    zF_C914CB83_markerWriteInt(zT_356, zT_357);
    zT_363 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    ck = zT_363;
    zT_364 = type_reg;
    zT_365 = ck;
    zT_366 = ct;
    zF_5E95558D_nameCachePut(zT_364, zT_365, zT_366);
    sym_type_id = ct;
    zT_368 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_368;
    sym_mod_id = mod_id;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_56;
    z_bb_62:
    zT_370 = 0;
    arb_u = zT_370;
    zT_372 = type_reg->interner;
    zT_373 = ident_name_id;
    zT_375 = zF_9134020D_stringInternerGet(zT_372, zT_373);
    ident_text = zT_375;
    zT_376 = ident_text;
    zT_377 = &arb_u;
    zT_379 = zF_741B5264_parseArbIntWidth(zT_376, zT_377);
    if ((unsigned char)(zT_379 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_383 = type_reg;
    zT_384 = ident_text;
    zT_385 = zF_B8CF3697_typeRegistryGetOrCr(zT_383, zT_384);
    arb_tid = zT_385;
    if ((unsigned char)(arb_tid != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_393 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    atk = zT_393;
    zT_394 = type_reg;
    zT_395 = atk;
    zT_396 = arb_tid;
    zF_5E95558D_nameCachePut(zT_394, zT_395, zT_396);
    sym_type_id = arb_tid;
    zT_398 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_398;
    sym_mod_id = mod_id;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_404 = init_node.kind;
    zT_403 = zT_404 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_69;
    z_bb_68:
    zT_403 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_403) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_409 = init_node.kind;
    zT_408 = zT_409 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_72;
    z_bb_71:
    zT_408 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_408) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_414 = init_node.kind;
    zT_413 = zT_414 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_413 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_413) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_419 = init_node.kind;
    zT_418 = zT_419 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_418 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_418) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_424 = init_node.kind;
    zT_423 = zT_424 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_423 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_423) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_429 = init_node.kind;
    zT_428 = zT_429 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_84;
    z_bb_83:
    zT_428 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_428) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_434 = "AT:p";
    zT_436 = 4;
    zT_435.ptr = zT_434;
    zT_435.len = zT_436;
    at_m = zT_435;
    zT_437 = at_m;
    zT_438 = name_id;
    zF_C914CB83_markerWriteInt(zT_437, zT_438);
    zT_440 = type_reg;
    zT_447 = zF_0EB68360_nameCacheGet(zT_440, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id)));
    acached = zT_447;
    zT_448 = acached.has_value;
    if ((unsigned char)(!zT_448)) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    goto z_bb_56;
    z_bb_87:
    zT_450 = type_reg;
    zT_453 = zF_0EB68360_nameCacheGet(zT_450, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_453;
    goto z_bb_88;
    z_bb_88:
    zT_454 = acached.has_value;
    if (zT_454) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    act = acached.value;
    sym_type_id = act;
    goto z_bb_90;
    z_bb_90:
    zT_457 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_457;
    sym_mod_id = mod_id;
    goto z_bb_86;
    z_bb_91:
    zT_478 = "VR";
    zT_480 = 2;
    zT_479.ptr = zT_478;
    zT_479.len = zT_480;
    vr = zT_479;
    zT_481 = vr;
    zF_48AC7B3A_markerWrite(zT_481);
    goto z_bb_92;
    z_bb_92:
    zT_483 = "VD";
    zT_485 = 2;
    zT_484.ptr = zT_483;
    zT_484.len = zT_485;
    vd = zT_484;
    zT_486 = vd;
    zF_48AC7B3A_markerWrite(zT_486);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_488[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_488[_i];
        _i++;
    }
}
    zT_490 = name_id;
    zT_494 = 0;
    zT_495 = (unsigned char*)((unsigned char*)vb) + zT_494;
    zT_496 = (unsigned int)(20) - zT_494;
    zT_497.ptr = zT_495;
    zT_497.len = zT_496;
    zT_491 = zT_497;
    zT_498 = zF_A7504564_itoa(zT_490, zT_491);
    vn = zT_498;
    zT_504 = (unsigned int)(19) - (unsigned int)((unsigned int)vn);
    vns = zT_504;
    zT_509 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_510 = (unsigned int)(20) - vns;
    zT_511.ptr = zT_509;
    zT_511.len = zT_510;
    zT_505 = zT_511;
    zF_48AC7B3A_markerWrite(zT_505);
    zT_513 = ":";
    zT_515 = 1;
    zT_514.ptr = zT_513;
    zT_514.len = zT_515;
    vc = zT_514;
    zT_516 = vc;
    zF_48AC7B3A_markerWrite(zT_516);
    zT_523 = 0;
    zT_524 = (unsigned char*)((unsigned char*)vb) + zT_523;
    zT_525 = (unsigned int)(20) - zT_523;
    zT_526.ptr = zT_524;
    zT_526.len = zT_525;
    zT_519 = zT_526;
    zT_527 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_519);
    vk = zT_527;
    zT_533 = (unsigned int)(19) - (unsigned int)((unsigned int)vk);
    vks = zT_533;
    zT_538 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_539 = (unsigned int)(20) - vks;
    zT_540.ptr = zT_538;
    zT_540.len = zT_539;
    zT_534 = zT_540;
    zF_48AC7B3A_markerWrite(zT_534);
    zT_542 = "\n";
    zT_544 = 1;
    zT_543.ptr = zT_542;
    zT_543.len = zT_544;
    ven = zT_543;
    zT_545 = ven;
    zF_48AC7B3A_markerWrite(zT_545);
    zT_547 = "Vi";
    zT_549 = 2;
    zT_548.ptr = zT_547;
    zT_548.len = zT_549;
    vi_msg = zT_548;
    zT_550 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_550);
    goto z_bb_9;
    z_bb_93:
    zT_587 = store;
    zT_588 = decl_idx;
    zT_589 = zF_8BA26B9E_astStoreNodePayload(zT_587, zT_588);
    zT_586.name_id = zT_589;
    zT_590 = 0;
    zT_586.type_id = zT_590;
    zT_592 = zT_3C598AEF_SymbolKind_test_sym;
    zT_586.kind = zT_592;
    zT_593 = node.flags;
    zT_594 = (unsigned short)zT_593;
    zT_586.flags = zT_594;
    zT_586.decl_node = decl_idx;
    zT_586.module_id = mod_id;
    zT_595 = reg->modules;
    zT_596 = zT_595.items;
    zT_597 = (unsigned int)mod_id;
    zT_598 = zT_596[zT_597];
    zT_599 = zT_598.source_file_id;
    zT_586.file_id = zT_599;
    zT_600 = 0;
    zT_586.scope_level = zT_600;
    sym = zT_586;
    zT_602 = sym_reg;
    zT_603 = mod_id;
    zT_604 = zF_9B36C202_symbolRegistryGetTa(zT_602, zT_603);
    table = zT_604;
    zT_605 = table;
    zT_606 = sym;
    zT_607 = zF_D0156DDA_symbolTableInsert(zT_605, zT_606);
    (void)zT_607;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_9;
    z_bb_95:
    zT_620 = node.flags;
    zT_624 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_620) & (unsigned short)(32)) != zT_624)) goto z_bb_101; else goto z_bb_102;
    z_bb_96:
    zT_619 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_100;
    z_bb_97:
    zT_633 = node.flags;
    zT_637 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_633) & (unsigned short)(16)) != zT_637)) goto z_bb_104; else goto z_bb_105;
    z_bb_98:
    zT_619 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_100;
    z_bb_100:
    type_kind = zT_619;
    zT_656 = type_reg;
    zT_657 = mod_id;
    zT_658 = name_id;
    zT_659 = type_kind;
    zT_660 = zF_3A64E2E0_typeRegistryRegiste(zT_656, zT_657, zT_658, zT_659);
    tid = zT_660;
    zT_661 = node.kind;
    if ((unsigned char)(zT_661 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_111; else goto z_bb_110;
    z_bb_101:
    zT_626 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_103;
    z_bb_102:
    zT_626 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_103;
    z_bb_103:
    zT_619 = zT_626;
    goto z_bb_100;
    z_bb_104:
    zT_639 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_106;
    z_bb_105:
    zT_642 = node.flags;
    zT_644 = 1;
    zT_646 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_642) & zT_644) != zT_646)) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_619 = zT_639;
    goto z_bb_100;
    z_bb_107:
    zT_648 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_109;
    z_bb_108:
    zT_648 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_109;
    z_bb_109:
    zT_639 = zT_648;
    goto z_bb_106;
    z_bb_110:
    zT_666 = node.kind;
    zT_665 = zT_666 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_112;
    z_bb_111:
    zT_665 = 1;
    goto z_bb_112;
    z_bb_112:
    if (zT_665) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_671 = node.flags;
    zT_670 = (unsigned short)((unsigned short)((unsigned short)zT_671) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_115;
    z_bb_114:
    zT_670 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_670) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_677 = type_reg;
    zT_678 = tid;
    zF_52816016_typeRegistrySetPack(zT_677, zT_678);
    goto z_bb_117;
    z_bb_117:
    if (populate) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_679 = type_reg;
    zT_680 = store;
    zT_681 = node.kind;
    zT_682 = decl_idx;
    zT_683 = sym_reg;
    zF_020995FB_populateTypePayload(zT_679, zT_680, zT_681, zT_682, zT_683);
    goto z_bb_119;
    z_bb_119:
    zT_685 = store;
    zT_686 = decl_idx;
    zT_687 = tid;
    zT_688 = g;
    zF_4976C319_addTypeDependencies(zT_685, zT_686, zT_687, zT_688);
    zT_690.name_id = name_id;
    zT_690.type_id = tid;
    zT_692 = zT_3C598AEF_SymbolKind_type_alias;
    zT_690.kind = zT_692;
    zT_693 = node.flags;
    zT_694 = (unsigned short)zT_693;
    zT_690.flags = zT_694;
    zT_690.decl_node = decl_idx;
    zT_690.module_id = mod_id;
    zT_695 = reg->modules;
    zT_696 = zT_695.items;
    zT_697 = (unsigned int)mod_id;
    zT_698 = zT_696[zT_697];
    zT_699 = zT_698.source_file_id;
    zT_690.file_id = zT_699;
    zT_700 = 0;
    zT_690.scope_level = zT_700;
    sym = zT_690;
    zT_702 = sym_reg;
    zT_703 = mod_id;
    zT_704 = zF_9B36C202_symbolRegistryGetTa(zT_702, zT_703);
    table = zT_704;
    zT_705 = table;
    zT_706 = sym;
    zT_707 = zF_D0156DDA_symbolTableInsert(zT_705, zT_706);
    (void)zT_707;
    goto z_bb_9;
    z_bb_120:
    zT_725 = type_reg;
    zT_726 = store;
    zT_727 = node.kind;
    zT_728 = decl_idx;
    zT_729 = sym_reg;
    zF_020995FB_populateTypePayload(zT_725, zT_726, zT_727, zT_728, zT_729);
    goto z_bb_121;
    z_bb_121:
    zT_732.name_id = name_id;
    zT_732.type_id = tid;
    zT_734 = zT_3C598AEF_SymbolKind_type_alias;
    zT_732.kind = zT_734;
    zT_735 = node.flags;
    zT_736 = (unsigned short)zT_735;
    zT_732.flags = zT_736;
    zT_732.decl_node = decl_idx;
    zT_732.module_id = mod_id;
    zT_737 = reg->modules;
    zT_738 = zT_737.items;
    zT_739 = (unsigned int)mod_id;
    zT_740 = zT_738[zT_739];
    zT_741 = zT_740.source_file_id;
    zT_732.file_id = zT_741;
    zT_742 = 0;
    zT_732.scope_level = zT_742;
    sym = zT_732;
    zT_744 = sym_reg;
    zT_745 = mod_id;
    zT_746 = zF_9B36C202_symbolRegistryGetTa(zT_744, zT_745);
    table = zT_746;
    zT_747 = table;
    zT_748 = sym;
    zT_749 = zF_D0156DDA_symbolTableInsert(zT_747, zT_748);
    (void)zT_749;
    goto z_bb_9;
    z_bb_122:
    tid = target_mod_id.value;
    zT_761.name_id = path_id;
    zT_762 = type_reg;
    zT_763 = tid;
    zT_764 = zF_2ECA9F93_typeRegistryGetOrCr(zT_762, zT_763);
    zT_761.type_id = zT_764;
    zT_766 = zT_3C598AEF_SymbolKind_module;
    zT_761.kind = zT_766;
    zT_767 = 0;
    zT_761.flags = zT_767;
    zT_761.decl_node = decl_idx;
    zT_761.module_id = tid;
    zT_768 = reg->modules;
    zT_769 = zT_768.items;
    zT_770 = (unsigned int)mod_id;
    zT_771 = zT_769[zT_770];
    zT_772 = zT_771.source_file_id;
    zT_761.file_id = zT_772;
    zT_773 = 0;
    zT_761.scope_level = zT_773;
    sym = zT_761;
    zT_775 = sym_reg;
    zT_776 = mod_id;
    zT_777 = zF_9B36C202_symbolRegistryGetTa(zT_775, zT_776);
    table = zT_777;
    zT_778 = table;
    zT_779 = sym;
    zT_780 = zF_D0156DDA_symbolTableInsert(zT_778, zT_779);
    (void)zT_780;
    zT_782 = "IMR:n";
    zT_784 = 5;
    zT_783.ptr = zT_782;
    zT_783.len = zT_784;
    imr = zT_783;
    zT_785 = imr;
    zF_48AC7B3A_markerWrite(zT_785);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_787[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_787[_i];
        _i++;
    }
}
    zT_789 = path_id;
    zT_793 = 0;
    zT_794 = (unsigned char*)((unsigned char*)imb) + zT_793;
    zT_795 = (unsigned int)(10) - zT_793;
    zT_796.ptr = zT_794;
    zT_796.len = zT_795;
    zT_790 = zT_796;
    zT_797 = zF_A7504564_itoa(zT_789, zT_790);
    iml = zT_797;
    zT_801 = (unsigned int)(9) - (unsigned int)((unsigned int)iml);
    ims = zT_801;
    zT_806 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_807 = (unsigned int)(9) - ims;
    zT_808.ptr = zT_806;
    zT_808.len = zT_807;
    zT_802 = zT_808;
    zF_48AC7B3A_markerWrite(zT_802);
    zT_810 = "m";
    zT_812 = 1;
    zT_811.ptr = zT_810;
    zT_811.len = zT_812;
    imm = zT_811;
    zT_813 = imm;
    zF_48AC7B3A_markerWrite(zT_813);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_815[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_815[_i];
        _i++;
    }
}
    zT_817 = tid;
    zT_821 = 0;
    zT_822 = (unsigned char*)((unsigned char*)immb) + zT_821;
    zT_823 = (unsigned int)(10) - zT_821;
    zT_824.ptr = zT_822;
    zT_824.len = zT_823;
    zT_818 = zT_824;
    zT_825 = zF_A7504564_itoa(zT_817, zT_818);
    imml = zT_825;
    zT_829 = (unsigned int)(9) - (unsigned int)((unsigned int)imml);
    imms = zT_829;
    zT_834 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_835 = (unsigned int)(9) - imms;
    zT_836.ptr = zT_834;
    zT_836.len = zT_835;
    zT_830 = zT_836;
    zF_48AC7B3A_markerWrite(zT_830);
    zT_838 = " ";
    zT_840 = 1;
    zT_839.ptr = zT_838;
    zT_839.len = zT_840;
    imsnl = zT_839;
    zT_841 = imsnl;
    zF_48AC7B3A_markerWrite(zT_841);
    goto z_bb_123;
    z_bb_123:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, unsigned char populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned char zT_16;
    zT_9FE1BFFE_ModuleState zT_17;
    unsigned char zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_29 = {0};
    zT_8143F551_AstKind zT_30;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    zT_79FAE712_u64 zT_56 = 0;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66 = 0;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned char* zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    int zT_84;
    unsigned int zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_98 = 0;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_130 = 0;
    zT_22A7C88B_AstNode zT_131 = {0};
    zT_8143F551_AstKind zT_133;
    unsigned int zT_134;
    zT_4028D896_Arr_unsigned_char_2 zT_136;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146 = 0;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    int zT_163;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int zT_172;
    unsigned int zT_173;
    zT_3D7259E2_SymbolRegistry* zT_176;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_4D61441E_DepGraph* zT_181;
    zT_072B53A6_ModuleRegistry* zT_182;
    unsigned char zT_183;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    unsigned int zT_189 = 0;
    int zT_190;
    unsigned int zT_192;
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((unsigned char)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = entry.state;
    zT_16 = zT_17 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = entry.ast_root;
    zT_23 = 0;
    zT_21 = zT_22 == (unsigned int)zT_23;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = store;
    zT_27 = entry.ast_root;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    root = zT_29;
    zT_30 = root.kind;
    if ((unsigned char)(zT_30 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_35 = store;
    zT_36 = entry.ast_root;
    zT_38 = zF_152E19CB_astStoreNodeExtraCh(zT_35, zT_36);
    decls_n = zT_38;
    if ((unsigned char)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = "RS";
    zT_44 = 2;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    dg = zT_43;
    zT_45 = dg;
    zF_48AC7B3A_markerWrite(zT_45);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = store;
    zT_52 = entry.ast_root;
    zT_53 = root.kind;
    zT_56 = zF_0E4E10C6_astStoreNodePayload(zT_51, zT_52, zT_53);
    zT_62 = 0;
    zT_63 = (unsigned char*)((unsigned char*)pb) + zT_62;
    zT_64 = (unsigned int)(20) - zT_62;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_50 = zT_65;
    zT_66 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_56 & (zT_79FAE712_u64)(4294967295u))), zT_50);
    pl = zT_66;
    zT_70 = (unsigned int)(19) - (unsigned int)((unsigned int)pl);
    ps = zT_70;
    zT_75 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_76 = (unsigned int)(19) - ps;
    zT_77.ptr = zT_75;
    zT_77.len = zT_76;
    zT_71 = zT_77;
    zF_48AC7B3A_markerWrite(zT_71);
    zT_79 = ":";
    zT_81 = 1;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    sc = zT_80;
    zT_82 = sc;
    zF_48AC7B3A_markerWrite(zT_82);
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    i2 = zT_85;
    goto z_bb_13;
    z_bb_12:
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    i = zT_173;
    goto z_bb_17;
    z_bb_13:
    if ((unsigned char)(i2 < (unsigned int)((unsigned int)decls_n))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_89[_i];
        _i++;
    }
}
    zT_93 = store;
    zT_94 = entry.ast_root;
    zT_98 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)i2));
    zT_91 = zT_98;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)ii_buf) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = zT_102;
    zT_104.len = zT_103;
    zT_92 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_91, zT_92);
    ii_len = zT_105;
    zT_109 = (unsigned int)(19) - (unsigned int)((unsigned int)ii_len);
    ii_start = zT_109;
    zT_114 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_115 = (unsigned int)(19) - ii_start;
    zT_116.ptr = zT_114;
    zT_116.len = zT_115;
    zT_110 = zT_116;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_118 = "=";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    ss = zT_119;
    zT_121 = ss;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_123 = store;
    zT_125 = store;
    zT_126 = entry.ast_root;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_125, zT_126, (unsigned int)((unsigned int)i2));
    zT_124 = zT_130;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_123, zT_124);
    dc = zT_131;
    zT_133 = dc.kind;
    zT_134 = (unsigned int)zT_133;
    dk = zT_134;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_136[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_136[_i];
        _i++;
    }
}
    zT_138 = dk;
    zT_142 = 0;
    zT_143 = (unsigned char*)((unsigned char*)db) + zT_142;
    zT_144 = (unsigned int)(20) - zT_142;
    zT_145.ptr = zT_143;
    zT_145.len = zT_144;
    zT_139 = zT_145;
    zT_146 = zF_A7504564_itoa(zT_138, zT_139);
    dl = zT_146;
    zT_150 = (unsigned int)(19) - (unsigned int)((unsigned int)dl);
    ds = zT_150;
    zT_155 = (unsigned char*)((unsigned char*)db) + ds;
    zT_156 = (unsigned int)(19) - ds;
    zT_157.ptr = zT_155;
    zT_157.len = zT_156;
    zT_151 = zT_157;
    zF_48AC7B3A_markerWrite(zT_151);
    zT_159 = " ";
    zT_161 = 1;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    dsp = zT_160;
    zT_162 = dsp;
    zF_48AC7B3A_markerWrite(zT_162);
    goto z_bb_16;
    z_bb_15:
    zT_167 = "\n";
    zT_169 = 1;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    dn = zT_168;
    zT_170 = dn;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_163 = 1;
    zT_165 = i2 + (unsigned int)((unsigned int)zT_163);
    i2 = zT_165;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(i < (unsigned int)((unsigned int)decls_n))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_176 = sym_reg;
    zT_177 = type_reg;
    zT_178 = store;
    zT_179 = module_id;
    zT_184 = store;
    zT_185 = entry.ast_root;
    zT_189 = zF_B10B1BC1_astStoreNodeExtraCh(zT_184, zT_185, (unsigned int)((unsigned int)i));
    zT_180 = zT_189;
    zT_181 = g;
    zT_182 = reg;
    zT_183 = populate;
    zF_CBEB26BC_registerDecl(zT_176, zT_177, zT_178, zT_179, zT_180, zT_181, zT_182, zT_183);
    zT_190 = 1;
    zT_192 = i + (unsigned int)((unsigned int)zT_190);
    i = zT_192;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_33EF6BFB_TypeKind zT_1 = 0;
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
