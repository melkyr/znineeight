#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zT_5 = 0;
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_3E40CD83_Sand* zT_17;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned int zT_25;
    zT_7634F9B7_Opt_222 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_0F51E4CA_EU_222 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    unsigned int zT_59;
    unsigned int nc;
    zT_7634F9B7_Opt_222 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((int)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((int)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_8 = zT_10 * zT_11;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_13 = self->cap;
    zT_14 = 0;
    if ((int)(zT_13 > (unsigned int)zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = self->alloc;
    zT_23 = self->items;
    zT_25 = self->cap;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, (unsigned char*)((unsigned char*)zT_23), (unsigned int)(zT_25 * (unsigned int)(8)), (unsigned int)(nc * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_34 = self->alloc;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    z_bb_11:
    zT_43 = zT_41.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    zT_47 = self->items;
    zT_48 = self->len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((int)(i < zT_54)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    self->len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_9;
    zT_0F51E4CA_EU_222 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    int zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    zT_52CDA6EF_DepEdge* zT_35;
    zT_52CDA6EF_DepEdge zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    zT_52CDA6EF_DepEdge* zT_43;
    zT_52CDA6EF_DepEdge zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_5 = (unsigned int)(unsigned int)(max_type_id + (unsigned int)(1));
    count = zT_5;
    zT_6 = self->in_degree_cap;
    if ((int)(count > zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_9, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_6;
    z_bb_3:
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((int)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    zT_26 = self->in_degree_items;
    zT_26[i] = zT_25;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_32 = self->len;
    if ((int)(i < zT_32)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self->in_degree_items;
    zT_35 = self->items;
    zT_36 = zT_35[i];
    zT_37 = zT_36.to;
    zT_38 = zT_34[zT_37];
    zT_39 = 1;
    zT_41 = zT_38 + (unsigned int)((unsigned int)zT_39);
    zT_42 = self->in_degree_items;
    zT_43 = self->items;
    zT_44 = zT_43[i];
    zT_45 = zT_44.to;
    zT_42[zT_45] = zT_41;
    zT_46 = 1;
    zT_48 = i + (unsigned int)((unsigned int)zT_46);
    i = zT_48;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_16 = {0};
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int* zT_26;
    zT_22A7C88B_AstNode zT_28 = {0};
    zT_8143F551_AstKind zT_29;
    zT_4D61441E_DepGraph* zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_40;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((int)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_850FDF81_astStoreNodeExtraCh(zT_14, zT_15);
    children = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    zT_21 = children.len;
    if ((int)(i < zT_21)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_24 = store;
    zT_26 = children.ptr;
    zT_25 = zT_26[i];
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    field_node = zT_28;
    zT_29 = field_node.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_34 = g;
    zT_36 = tid;
    zF_AA751A34_depGraphAddEdge(zT_34, (unsigned int)(0), zT_36);
    goto z_bb_8;
    z_bb_8:
    zT_38 = 1;
    zT_40 = i + (unsigned int)((unsigned int)zT_38);
    i = zT_40;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_17 = {0};
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    unsigned int* zT_41;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_2DF01B61_FieldEntry zT_50;
    zT_2DF01B61_FieldEntry zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int* zT_54;
    unsigned int zT_56 = 0;
    unsigned int zT_57;
    unsigned int zT_58;
    int zT_59;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    int zT_65;
    zT_338B7C76_TypeRegistry* zT_67;
    zT_406493CE_StructPayload zT_68;
    zT_406493CE_StructPayload zT_69;
    unsigned int zT_70;
    unsigned short zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_D155D06D_Type* zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    zT_D155D06D_Type zT_84;
    zT_D155D06D_Type* zT_85;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_95;
    unsigned int zT_96;
    int zT_98;
    unsigned int zT_99;
    int zT_101;
    unsigned int zT_102;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    unsigned int* zT_109;
    zT_22A7C88B_AstNode zT_111 = {0};
    zT_8143F551_AstKind zT_112;
    zT_338B7C76_TypeRegistry* zT_117;
    zT_2DF01B61_FieldEntry zT_118;
    zT_2DF01B61_FieldEntry zT_119;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned int zT_121;
    unsigned int* zT_122;
    unsigned int zT_124 = 0;
    unsigned int zT_125;
    unsigned int zT_126;
    int zT_127;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_132;
    unsigned char zT_133;
    int zT_135;
    int zT_137;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_54FF90FA_TaggedUnionPayload zT_140;
    zT_54FF90FA_TaggedUnionPayload zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned short zT_144;
    unsigned int zT_146;
    unsigned int zT_148;
    unsigned int zT_150;
    zT_D155D06D_Type* zT_152;
    unsigned int zT_153;
    unsigned int zT_156;
    zT_D155D06D_Type zT_157;
    zT_D155D06D_Type* zT_158;
    unsigned int zT_159;
    unsigned int zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_AF9231A2_UnionPayload zT_164;
    zT_AF9231A2_UnionPayload zT_165;
    unsigned int zT_166;
    unsigned short zT_167;
    unsigned int zT_168;
    unsigned int zT_170;
    unsigned int zT_172;
    unsigned int zT_174;
    zT_D155D06D_Type* zT_176;
    unsigned int zT_177;
    unsigned int zT_180;
    zT_D155D06D_Type zT_181;
    zT_D155D06D_Type* zT_182;
    unsigned int zT_183;
    unsigned int zT_186;
    zT_ABC1EBBE_TypeResolveEnv zT_192;
    zT_D3EB6303_StringInterner* zT_193;
    zT_939EE900_Arr_unsigned_int_1 zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    int zT_200;
    unsigned char zT_202;
    unsigned int zT_203;
    int zT_204;
    zT_ABC1EBBE_TypeResolveEnv* zT_207;
    unsigned int zT_208;
    unsigned int zT_213 = 0;
    int zT_216;
    int zT_219;
    unsigned char zT_220;
    unsigned int zT_222;
    unsigned int zT_223;
    int zT_225;
    unsigned int zT_226;
    zT_C69B2266_i64 zT_228;
    int zT_230;
    unsigned int zT_231;
    unsigned int zT_233;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int zT_237;
    unsigned int* zT_238;
    zT_22A7C88B_AstNode zT_240 = {0};
    zT_8143F551_AstKind zT_241;
    unsigned int zT_247;
    int zT_248;
    zT_ABC1EBBE_TypeResolveEnv* zT_251;
    unsigned int zT_252;
    zT_44E16D78_Opt_7 zT_255 = {0};
    unsigned char zT_256;
    zT_338B7C76_TypeRegistry* zT_258;
    zT_D96DCDF2_EnumMember zT_259;
    zT_D96DCDF2_EnumMember zT_260;
    zT_6B0A7D14_AstStore* zT_261;
    unsigned int zT_262;
    unsigned int* zT_263;
    unsigned int zT_265 = 0;
    int zT_266;
    unsigned int zT_268;
    zT_C69B2266_i64 zT_270;
    int zT_271;
    unsigned int zT_273;
    zT_338B7C76_TypeRegistry* zT_274;
    zT_457ECFEE_EnumPayload zT_275;
    zT_457ECFEE_EnumPayload zT_276;
    unsigned int zT_277;
    unsigned short zT_278;
    int zT_279;
    unsigned int zT_280;
    unsigned int zT_282;
    unsigned int zT_284;
    unsigned int zT_286;
    zT_D155D06D_Type* zT_288;
    unsigned int zT_289;
    unsigned int zT_292;
    zT_D155D06D_Type zT_293;
    zT_D155D06D_Type* zT_294;
    unsigned int zT_295;
    unsigned int zT_298;
    unsigned int zT_304;
    unsigned int zT_305;
    int zT_307;
    unsigned int zT_308;
    unsigned int zT_310;
    zT_338B7C76_TypeRegistry* zT_312;
    unsigned int zT_313;
    unsigned int* zT_314;
    int zT_316;
    unsigned int zT_317;
    zT_338B7C76_TypeRegistry* zT_318;
    zT_0B73C507_ErrorSetPayload zT_319;
    zT_0B73C507_ErrorSetPayload zT_320;
    unsigned int zT_322;
    unsigned short zT_323;
    unsigned int zT_325;
    unsigned int zT_327;
    unsigned int zT_329;
    zT_D155D06D_Type* zT_331;
    unsigned int zT_332;
    unsigned int zT_335;
    zT_D155D06D_Type zT_336;
    zT_D155D06D_Type* zT_337;
    unsigned int zT_338;
    unsigned int zT_341;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    zT_C69B2266_i64 auto_val;
    zT_22A7C88B_AstNode mnode;
    unsigned int en_last;
    unsigned int en_idx;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_6 = store;
    zT_7 = decl_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    if ((int)(zT_11 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_15 = store;
    zT_16 = decl_idx;
    zT_17 = zF_850FDF81_astStoreNodeExtraCh(zT_15, zT_16);
    children = zT_17;
    zT_19 = children.len;
    zT_20 = 0;
    if ((int)(zT_19 == (unsigned int)zT_20)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = type_reg->fe_len;
    zT_28 = (unsigned int)zT_27;
    fstart = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    fcount = zT_31;
    zT_33 = 0;
    zT_34 = (unsigned int)zT_33;
    i = zT_34;
    goto z_bb_7;
    z_bb_6:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_7:
    zT_36 = children.len;
    if ((int)(i < zT_36)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = store;
    zT_41 = children.ptr;
    zT_40 = zT_41[i];
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    fd = zT_43;
    zT_44 = fd.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_65 = 0;
    if ((int)(fcount > (unsigned int)zT_65)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_49 = type_reg;
    zT_52 = store;
    zT_54 = children.ptr;
    zT_53 = zT_54[i];
    zT_56 = zF_8BA26B9E_astStoreNodePayload(zT_52, zT_53);
    zT_51.name_id = zT_56;
    zT_57 = 1;
    zT_51.type_id = zT_57;
    zT_58 = 0;
    zT_51.offset = zT_58;
    zT_50 = zT_51;
    zF_701DF154_feAppend(zT_49, zT_50);
    zT_59 = 1;
    zT_61 = fcount + (unsigned int)((unsigned int)zT_59);
    fcount = zT_61;
    goto z_bb_12;
    z_bb_12:
    zT_62 = 1;
    zT_64 = i + (unsigned int)((unsigned int)zT_62);
    i = zT_64;
    goto z_bb_10;
    z_bb_13:
    zT_67 = type_reg;
    zT_70 = (unsigned int)fstart;
    zT_69.fields_start = zT_70;
    zT_71 = (unsigned short)fcount;
    zT_69.fields_count = zT_71;
    zT_68 = zT_69;
    zF_CF849366_stAppend(zT_67, zT_68);
    goto z_bb_14;
    z_bb_14:
    zT_73 = type_reg->st_len;
    zT_75 = zT_73 - (unsigned int)(1);
    st_last = zT_75;
    zT_77 = (unsigned int)st_last;
    st_idx = zT_77;
    zT_79 = type_reg->types_items;
    zT_80 = type_reg->types_len;
    zT_83 = (unsigned int)(unsigned int)(zT_80 - (unsigned int)(1));
    zT_84 = zT_79[zT_83];
    ty = zT_84;
    ty.payload_idx = st_idx;
    zT_85 = type_reg->types_items;
    zT_86 = type_reg->types_len;
    zT_89 = (unsigned int)(unsigned int)(zT_86 - (unsigned int)(1));
    zT_85[zT_89] = ty;
    goto z_bb_6;
    z_bb_15:
    zT_95 = type_reg->fe_len;
    zT_96 = (unsigned int)zT_95;
    fstart = zT_96;
    zT_98 = 0;
    zT_99 = (unsigned int)zT_98;
    fcount = zT_99;
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    i = zT_102;
    goto z_bb_17;
    z_bb_16:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_26; else goto z_bb_27;
    z_bb_17:
    zT_104 = children.len;
    if ((int)(i < zT_104)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_107 = store;
    zT_109 = children.ptr;
    zT_108 = zT_109[i];
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_107, zT_108);
    fd = zT_111;
    zT_112 = fd.kind;
    if ((int)(zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_133 = node.flags;
    zT_135 = 1;
    zT_137 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_133) & zT_135) != zT_137)) goto z_bb_23; else goto z_bb_25;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_117 = type_reg;
    zT_120 = store;
    zT_122 = children.ptr;
    zT_121 = zT_122[i];
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_120, zT_121);
    zT_119.name_id = zT_124;
    zT_125 = 1;
    zT_119.type_id = zT_125;
    zT_126 = 0;
    zT_119.offset = zT_126;
    zT_118 = zT_119;
    zF_701DF154_feAppend(zT_117, zT_118);
    zT_127 = 1;
    zT_129 = fcount + (unsigned int)((unsigned int)zT_127);
    fcount = zT_129;
    goto z_bb_22;
    z_bb_22:
    zT_130 = 1;
    zT_132 = i + (unsigned int)((unsigned int)zT_130);
    i = zT_132;
    goto z_bb_20;
    z_bb_23:
    zT_139 = type_reg;
    zT_142 = 10;
    zT_141.tag_type = zT_142;
    zT_143 = (unsigned int)fstart;
    zT_141.fields_start = zT_143;
    zT_144 = (unsigned short)fcount;
    zT_141.fields_count = zT_144;
    zT_140 = zT_141;
    zF_FB6B57C6_tuAppend(zT_139, zT_140);
    zT_146 = type_reg->tu_len;
    zT_148 = zT_146 - (unsigned int)(1);
    tu_last = zT_148;
    zT_150 = (unsigned int)tu_last;
    tu_idx = zT_150;
    zT_152 = type_reg->types_items;
    zT_153 = type_reg->types_len;
    zT_156 = (unsigned int)(unsigned int)(zT_153 - (unsigned int)(1));
    zT_157 = zT_152[zT_156];
    ty = zT_157;
    ty.payload_idx = tu_idx;
    zT_158 = type_reg->types_items;
    zT_159 = type_reg->types_len;
    zT_162 = (unsigned int)(unsigned int)(zT_159 - (unsigned int)(1));
    zT_158[zT_162] = ty;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_16;
    z_bb_25:
    zT_163 = type_reg;
    zT_166 = (unsigned int)fstart;
    zT_165.fields_start = zT_166;
    zT_167 = (unsigned short)fcount;
    zT_165.fields_count = zT_167;
    zT_168 = 1;
    zT_165.tag_type = zT_168;
    zT_164 = zT_165;
    zF_1718422E_unAppend(zT_163, zT_164);
    zT_170 = type_reg->un_len;
    zT_172 = zT_170 - (unsigned int)(1);
    un_last = zT_172;
    zT_174 = (unsigned int)un_last;
    un_idx = zT_174;
    zT_176 = type_reg->types_items;
    zT_177 = type_reg->types_len;
    zT_180 = (unsigned int)(unsigned int)(zT_177 - (unsigned int)(1));
    zT_181 = zT_176[zT_180];
    ty = zT_181;
    ty.payload_idx = un_idx;
    zT_182 = type_reg->types_items;
    zT_183 = type_reg->types_len;
    zT_186 = (unsigned int)(unsigned int)(zT_183 - (unsigned int)(1));
    zT_182[zT_186] = ty;
    goto z_bb_24;
    z_bb_26:
    zT_192.store = store;
    zT_192.typereg = type_reg;
    zT_192.symbol_reg = sym_reg;
    zT_193 = type_reg->interner;
    zT_192.interner = zT_193;
    zT_192.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    tre_env = zT_192;
    zT_197 = 0;
    zT_198 = 0;
    zT_196[zT_198] = zT_197;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_196[_i];
        _i++;
    }
}
    zT_199 = 10;
    zT_200 = 0;
    backing_box[zT_200] = zT_199;
    zT_202 = 0;
    expl_flag = zT_202;
    zT_203 = node.child_0;
    zT_204 = 0;
    if ((int)(zT_203 != (unsigned int)zT_204)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    if ((int)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_28:
    zT_207 = &tre_env;
    zT_208 = node.child_0;
    zT_213 = zF_F2107C15_resolveTypeExprFull(zT_207, zT_208, (unsigned int)(0));
    bt = zT_213;
    if ((int)(bt != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_222 = type_reg->em_len;
    zT_223 = (unsigned int)zT_222;
    mstart = zT_223;
    zT_225 = 0;
    zT_226 = (unsigned int)zT_225;
    mcount = zT_226;
    zT_228 = 0;
    auto_val = zT_228;
    zT_230 = 0;
    zT_231 = (unsigned int)zT_230;
    i = zT_231;
    goto z_bb_35;
    z_bb_30:
    zT_216 = bt != (unsigned int)(1);
    goto z_bb_32;
    z_bb_31:
    zT_216 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_216) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_219 = 0;
    backing_box[zT_219] = bt;
    goto z_bb_34;
    z_bb_34:
    zT_220 = 1;
    expl_flag = zT_220;
    goto z_bb_29;
    z_bb_35:
    zT_233 = children.len;
    if ((int)(i < zT_233)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_236 = store;
    zT_238 = children.ptr;
    zT_237 = zT_238[i];
    zT_240 = zF_FCDD1D35_astStoreNodeAt(zT_236, zT_237);
    mnode = zT_240;
    zT_241 = mnode.kind;
    if ((int)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_274 = type_reg;
    zT_277 = (unsigned int)mstart;
    zT_276.members_start = zT_277;
    zT_278 = (unsigned short)mcount;
    zT_276.members_count = zT_278;
    zT_279 = 0;
    zT_280 = backing_box[zT_279];
    zT_276.backing_type = zT_280;
    zT_276.explicit_backing = expl_flag;
    zT_275 = zT_276;
    zF_298371DE_enAppend(zT_274, zT_275);
    zT_282 = type_reg->en_len;
    zT_284 = zT_282 - (unsigned int)(1);
    en_last = zT_284;
    zT_286 = (unsigned int)en_last;
    en_idx = zT_286;
    zT_288 = type_reg->types_items;
    zT_289 = type_reg->types_len;
    zT_292 = (unsigned int)(unsigned int)(zT_289 - (unsigned int)(1));
    zT_293 = zT_288[zT_292];
    ty = zT_293;
    ty.payload_idx = en_idx;
    zT_294 = type_reg->types_items;
    zT_295 = type_reg->types_len;
    zT_298 = (unsigned int)(unsigned int)(zT_295 - (unsigned int)(1));
    zT_294[zT_298] = ty;
    goto z_bb_27;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    mval = auto_val;
    zT_247 = mnode.child_1;
    zT_248 = 0;
    if ((int)(zT_247 != (unsigned int)zT_248)) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_271 = 1;
    zT_273 = i + (unsigned int)((unsigned int)zT_271);
    i = zT_273;
    goto z_bb_38;
    z_bb_41:
    zT_251 = &tre_env;
    zT_252 = mnode.child_1;
    zT_255 = zF_FFFAAD16_evalConstI64Full(zT_251, zT_252);
    ev_opt = zT_255;
    zT_256 = ev_opt.has_value;
    if (zT_256) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_258 = type_reg;
    zT_261 = store;
    zT_263 = children.ptr;
    zT_262 = zT_263[i];
    zT_265 = zF_8BA26B9E_astStoreNodePayload(zT_261, zT_262);
    zT_260.name_id = zT_265;
    zT_260.value = mval;
    zT_259 = zT_260;
    zF_157DA7BF_emAppend(zT_258, zT_259);
    zT_266 = 1;
    zT_268 = mcount + (unsigned int)((unsigned int)zT_266);
    mcount = zT_268;
    zT_270 = mval + (zT_C69B2266_i64)(1);
    auto_val = zT_270;
    goto z_bb_40;
    z_bb_43:
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_304 = type_reg->xn_len;
    zT_305 = (unsigned int)zT_304;
    tags_start_idx = zT_305;
    zT_307 = 0;
    zT_308 = (unsigned int)zT_307;
    i = zT_308;
    goto z_bb_47;
    z_bb_46:
    return;
    z_bb_47:
    zT_310 = children.len;
    if ((int)(i < zT_310)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_312 = type_reg;
    zT_314 = children.ptr;
    zT_313 = zT_314[i];
    zF_A648B1CB_xnAppend(zT_312, zT_313);
    goto z_bb_50;
    z_bb_49:
    zT_318 = type_reg;
    zT_320.tags_start = tags_start_idx;
    zT_322 = children.len;
    zT_323 = (unsigned short)zT_322;
    zT_320.tags_count = zT_323;
    zT_319 = zT_320;
    zF_B86143DD_esAppend(zT_318, zT_319);
    zT_325 = type_reg->es_len;
    zT_327 = zT_325 - (unsigned int)(1);
    es_last = zT_327;
    zT_329 = (unsigned int)es_last;
    es_idx = zT_329;
    zT_331 = type_reg->types_items;
    zT_332 = type_reg->types_len;
    zT_335 = (unsigned int)(unsigned int)(zT_332 - (unsigned int)(1));
    zT_336 = zT_331[zT_335];
    ty = zT_336;
    ty.payload_idx = es_idx;
    zT_337 = type_reg->types_items;
    zT_338 = type_reg->types_len;
    zT_341 = (unsigned int)(unsigned int)(zT_338 - (unsigned int)(1));
    zT_337[zT_341] = ty;
    goto z_bb_46;
    z_bb_50:
    zT_316 = 1;
    zT_317 = i + zT_316;
    i = zT_317;
    goto z_bb_47;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, int populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21 = 0;
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_3C598AEF_SymbolKind zT_58;
    unsigned int zT_61;
    unsigned int zT_62;
    int zT_63;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    zT_072B53A6_ModuleRegistry* zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_81 = 0;
    zT_BAEE192E_Opt_10 zT_82 = {0};
    char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_4028D896_Arr_unsigned_char_2 zT_89;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    unsigned int zT_96 = 0;
    int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char zT_115;
    char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_3C598AEF_SymbolKind zT_124;
    char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_131;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    int zT_137;
    unsigned char* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141 = 0;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_159;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    int zT_165;
    unsigned char* zT_166;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169 = 0;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned char* zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_187;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    int zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197 = 0;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned char* zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    zT_338B7C76_TypeRegistry* zT_209;
    unsigned int zT_210;
    unsigned int zT_211 = 0;
    char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8143F551_AstKind zT_217;
    int zT_222;
    zT_8143F551_AstKind zT_223;
    int zT_228;
    zT_8143F551_AstKind zT_229;
    int zT_234;
    zT_8143F551_AstKind zT_235;
    zT_8143F551_AstKind zT_241;
    zT_33EF6BFB_TypeKind zT_242;
    unsigned char zT_249;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char zT_259;
    int zT_261;
    int zT_263;
    zT_33EF6BFB_TypeKind zT_265;
    zT_338B7C76_TypeRegistry* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    zT_33EF6BFB_TypeKind zT_281;
    unsigned int zT_282 = 0;
    zT_8143F551_AstKind zT_283;
    int zT_288;
    zT_8143F551_AstKind zT_289;
    int zT_294;
    unsigned char zT_295;
    zT_338B7C76_TypeRegistry* zT_301;
    unsigned int zT_302;
    zT_338B7C76_TypeRegistry* zT_303;
    zT_6B0A7D14_AstStore* zT_304;
    zT_8143F551_AstKind zT_305;
    unsigned int zT_306;
    zT_3D7259E2_SymbolRegistry* zT_307;
    zT_6B0A7D14_AstStore* zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    zT_4D61441E_DepGraph* zT_313;
    zT_3C598AEF_SymbolKind zT_317;
    zT_8143F551_AstKind zT_318;
    char* zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_6B0A7D14_AstStore* zT_329;
    unsigned int zT_330;
    unsigned int zT_332 = 0;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_337 = 0;
    char* zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_BAEE192E_Opt_10 zT_352 = {0};
    unsigned char zT_353;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_BAEE192E_Opt_10 zT_358 = {0};
    unsigned char zT_359;
    char* zT_362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned int zT_366;
    zT_79FAE712_u64 zT_372;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_79FAE712_u64 zT_374;
    unsigned int zT_375;
    zT_3C598AEF_SymbolKind zT_378;
    zT_8143F551_AstKind zT_379;
    int zT_384;
    zT_8143F551_AstKind zT_385;
    int zT_390;
    zT_8143F551_AstKind zT_391;
    char* zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    unsigned int zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    unsigned int zT_401;
    zT_338B7C76_TypeRegistry* zT_403;
    zT_BAEE192E_Opt_10 zT_410 = {0};
    unsigned char zT_411;
    zT_338B7C76_TypeRegistry* zT_413;
    zT_BAEE192E_Opt_10 zT_416 = {0};
    unsigned char zT_417;
    zT_3C598AEF_SymbolKind zT_421;
    zT_3A105EF1_Symbol zT_423;
    unsigned char zT_424;
    unsigned short zT_425;
    unsigned int zT_426;
    zT_3D7259E2_SymbolRegistry* zT_428;
    unsigned int zT_429;
    zT_060CD1EB_SymbolTable* zT_430 = 0;
    zT_060CD1EB_SymbolTable* zT_432;
    zT_3A105EF1_Symbol zT_433;
    int zT_434 = 0;
    char* zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    char* zT_442;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_443;
    unsigned int zT_444;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_445;
    zT_4028D896_Arr_unsigned_char_2 zT_447;
    unsigned int zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    int zT_453;
    unsigned char* zT_454;
    unsigned int zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    unsigned int zT_457 = 0;
    unsigned int zT_463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    unsigned char* zT_468;
    unsigned int zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    char* zT_472;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_473;
    unsigned int zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_478;
    int zT_482;
    unsigned char* zT_483;
    unsigned int zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486 = 0;
    unsigned int zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned char* zT_497;
    unsigned int zT_498;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_499;
    char* zT_501;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_502;
    unsigned int zT_503;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_504;
    char* zT_506;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_507;
    unsigned int zT_508;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_509;
    zT_4F85C30D_anon_184538 zT_511;
    zT_243D6A41_FnProto* zT_512;
    zT_6B0A7D14_AstStore* zT_513;
    unsigned int zT_514;
    unsigned int zT_515 = 0;
    unsigned int zT_516;
    zT_243D6A41_FnProto zT_517;
    zT_3A105EF1_Symbol zT_519;
    unsigned int zT_520;
    unsigned int zT_521;
    zT_3C598AEF_SymbolKind zT_524;
    unsigned char zT_525;
    unsigned short zT_526;
    unsigned int zT_527;
    zT_3D7259E2_SymbolRegistry* zT_529;
    unsigned int zT_530;
    zT_060CD1EB_SymbolTable* zT_531 = 0;
    zT_060CD1EB_SymbolTable* zT_532;
    zT_3A105EF1_Symbol zT_533;
    int zT_534 = 0;
    zT_6B0A7D14_AstStore* zT_535;
    unsigned int zT_536;
    unsigned int zT_537 = 0;
    zT_3A105EF1_Symbol zT_541;
    zT_6B0A7D14_AstStore* zT_542;
    unsigned int zT_543;
    unsigned int zT_544 = 0;
    unsigned int zT_545;
    zT_3C598AEF_SymbolKind zT_548;
    unsigned char zT_549;
    unsigned short zT_550;
    unsigned int zT_551;
    zT_3D7259E2_SymbolRegistry* zT_553;
    unsigned int zT_554;
    zT_060CD1EB_SymbolTable* zT_555 = 0;
    zT_060CD1EB_SymbolTable* zT_556;
    zT_3A105EF1_Symbol zT_557;
    int zT_558 = 0;
    zT_6B0A7D14_AstStore* zT_560;
    unsigned int zT_561;
    zT_8143F551_AstKind zT_562;
    zT_79FAE712_u64 zT_564 = 0;
    zT_79FAE712_u64 zT_566;
    unsigned int zT_567;
    zT_8143F551_AstKind zT_569;
    zT_33EF6BFB_TypeKind zT_570;
    unsigned char zT_577;
    int zT_581;
    zT_33EF6BFB_TypeKind zT_583;
    unsigned char zT_587;
    int zT_589;
    int zT_591;
    zT_33EF6BFB_TypeKind zT_593;
    zT_338B7C76_TypeRegistry* zT_604;
    unsigned int zT_605;
    unsigned int zT_606;
    zT_33EF6BFB_TypeKind zT_607;
    unsigned int zT_608 = 0;
    zT_8143F551_AstKind zT_609;
    int zT_614;
    zT_8143F551_AstKind zT_615;
    int zT_620;
    unsigned char zT_621;
    zT_338B7C76_TypeRegistry* zT_627;
    unsigned int zT_628;
    zT_338B7C76_TypeRegistry* zT_629;
    zT_6B0A7D14_AstStore* zT_630;
    zT_8143F551_AstKind zT_631;
    unsigned int zT_632;
    zT_3D7259E2_SymbolRegistry* zT_633;
    zT_6B0A7D14_AstStore* zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    zT_4D61441E_DepGraph* zT_638;
    zT_3A105EF1_Symbol zT_640;
    zT_3C598AEF_SymbolKind zT_643;
    unsigned char zT_644;
    unsigned short zT_645;
    unsigned int zT_646;
    zT_3D7259E2_SymbolRegistry* zT_648;
    unsigned int zT_649;
    zT_060CD1EB_SymbolTable* zT_650 = 0;
    zT_060CD1EB_SymbolTable* zT_651;
    zT_3A105EF1_Symbol zT_652;
    int zT_653 = 0;
    zT_6B0A7D14_AstStore* zT_655;
    unsigned int zT_656;
    zT_8143F551_AstKind zT_657;
    zT_79FAE712_u64 zT_659 = 0;
    zT_79FAE712_u64 zT_661;
    unsigned int zT_662;
    zT_338B7C76_TypeRegistry* zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    unsigned int zT_671 = 0;
    zT_338B7C76_TypeRegistry* zT_672;
    zT_6B0A7D14_AstStore* zT_673;
    zT_8143F551_AstKind zT_674;
    unsigned int zT_675;
    zT_3D7259E2_SymbolRegistry* zT_676;
    zT_3A105EF1_Symbol zT_679;
    zT_3C598AEF_SymbolKind zT_682;
    unsigned char zT_683;
    unsigned short zT_684;
    unsigned int zT_685;
    zT_3D7259E2_SymbolRegistry* zT_687;
    unsigned int zT_688;
    zT_060CD1EB_SymbolTable* zT_689 = 0;
    zT_060CD1EB_SymbolTable* zT_690;
    zT_3A105EF1_Symbol zT_691;
    int zT_692 = 0;
    zT_6B0A7D14_AstStore* zT_694;
    unsigned int zT_695;
    unsigned int zT_696 = 0;
    zT_072B53A6_ModuleRegistry* zT_698;
    unsigned int zT_699;
    zT_BAEE192E_Opt_10 zT_700 = {0};
    unsigned char zT_701;
    zT_3A105EF1_Symbol zT_704;
    zT_338B7C76_TypeRegistry* zT_705;
    unsigned int zT_706;
    unsigned int zT_707 = 0;
    zT_3C598AEF_SymbolKind zT_710;
    unsigned short zT_711;
    unsigned int zT_712;
    zT_3D7259E2_SymbolRegistry* zT_714;
    unsigned int zT_715;
    zT_060CD1EB_SymbolTable* zT_716 = 0;
    zT_060CD1EB_SymbolTable* zT_717;
    zT_3A105EF1_Symbol zT_718;
    int zT_719 = 0;
    char* zT_721;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_722;
    unsigned int zT_723;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_724;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_726;
    unsigned int zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    int zT_732;
    unsigned char* zT_733;
    unsigned int zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736 = 0;
    unsigned int zT_740;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_741;
    unsigned char* zT_745;
    unsigned int zT_746;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_747;
    char* zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    unsigned int zT_751;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_752;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_754;
    unsigned int zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    int zT_760;
    unsigned char* zT_761;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned int zT_764 = 0;
    unsigned int zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned char* zT_773;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    char* zT_777;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    int inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_28[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_42 = (unsigned int)(19) - (unsigned int)((unsigned int)d12l);
    d12s = zT_42;
    zT_47 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_48 = (unsigned int)(19) - d12s;
    zT_49.ptr = zT_47;
    zT_49.len = zT_48;
    zT_43 = zT_49;
    zF_B5478454_measureMarkerWrite(zT_43);
    zT_51 = "\n";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    d12nl = zT_52;
    zT_54 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_54);
    zT_58 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_58;
    sym_mod_id = mod_id;
    zT_61 = 0;
    sym_type_id = zT_61;
    zT_62 = node.child_1;
    zT_63 = 0;
    if ((int)(zT_62 != (unsigned int)zT_63)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_511 = store->fn_protos;
    zT_512 = zT_511.items;
    zT_513 = store;
    zT_514 = decl_idx;
    zT_515 = zF_8BA26B9E_astStoreNodePayload(zT_513, zT_514);
    zT_516 = (unsigned int)zT_515;
    zT_517 = zT_512[zT_516];
    proto = zT_517;
    zT_520 = proto.name_id;
    zT_519.name_id = zT_520;
    zT_521 = 0;
    zT_519.type_id = zT_521;
    zT_524 = zT_3C598AEF_SymbolKind_function;
    zT_519.kind = zT_524;
    zT_525 = node.flags;
    zT_526 = (unsigned short)zT_525;
    zT_519.flags = zT_526;
    zT_519.decl_node = decl_idx;
    zT_519.module_id = mod_id;
    zT_527 = 0;
    zT_519.scope_level = zT_527;
    sym = zT_519;
    zT_529 = sym_reg;
    zT_530 = mod_id;
    zT_531 = zF_9B36C202_symbolRegistryGetTa(zT_529, zT_530);
    table = zT_531;
    zT_532 = table;
    zT_533 = sym;
    zT_534 = zF_D0156DDA_symbolTableInsert(zT_532, zT_533);
    (void)zT_534;
    goto z_bb_9;
    z_bb_3:
    zT_535 = store;
    zT_536 = decl_idx;
    zT_537 = zF_8BA26B9E_astStoreNodePayload(zT_535, zT_536);
    if ((int)(zT_537 != (unsigned int)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_4:
    zT_560 = store;
    zT_561 = decl_idx;
    zT_562 = node.kind;
    zT_564 = zF_0E4E10C6_astStoreNodePayload(zT_560, zT_561, zT_562);
    zT_566 = zT_564 & (zT_79FAE712_u64)(4294967295u);
    zT_567 = __bootstrap_u32_from_u64(zT_566);
    name_id = zT_567;
    zT_569 = node.kind;
switch (zT_569) {
case 3: goto z_bb_75;
case 4: goto z_bb_76;
case 5: goto z_bb_77;
default: goto z_bb_78;
}
    z_bb_5:
    zT_655 = store;
    zT_656 = decl_idx;
    zT_657 = node.kind;
    zT_659 = zF_0E4E10C6_astStoreNodePayload(zT_655, zT_656, zT_657);
    zT_661 = zT_659 & (zT_79FAE712_u64)(4294967295u);
    zT_662 = __bootstrap_u32_from_u64(zT_661);
    name_id = zT_662;
    zT_664 = type_reg;
    zT_665 = mod_id;
    zT_666 = name_id;
    zT_671 = zF_3A64E2E0_typeRegistryRegiste(zT_664, zT_665, zT_666, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_671;
    if (populate) goto z_bb_97; else goto z_bb_98;
    z_bb_6:
    zT_694 = store;
    zT_695 = decl_idx;
    zT_696 = zF_8BA26B9E_astStoreNodePayload(zT_694, zT_695);
    path_id = zT_696;
    zT_698 = reg;
    zT_699 = path_id;
    zT_700 = zF_A258E183_moduleRegistryPathT(zT_698, zT_699);
    target_mod_id = zT_700;
    zT_701 = target_mod_id.has_value;
    if (zT_701) goto z_bb_99; else goto z_bb_100;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_66 = store;
    zT_67 = node.child_1;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    init_node = zT_69;
    zT_70 = init_node.kind;
    if ((int)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_423.name_id = name_id;
    zT_423.type_id = sym_type_id;
    zT_423.kind = sym_kind;
    zT_424 = node.flags;
    zT_425 = (unsigned short)zT_424;
    zT_423.flags = zT_425;
    zT_423.decl_node = decl_idx;
    zT_423.module_id = sym_mod_id;
    zT_426 = 0;
    zT_423.scope_level = zT_426;
    sym = zT_423;
    zT_428 = sym_reg;
    zT_429 = mod_id;
    zT_430 = zF_9B36C202_symbolRegistryGetTa(zT_428, zT_429);
    table = zT_430;
    zT_432 = table;
    zT_433 = sym;
    zT_434 = zF_D0156DDA_symbolTableInsert(zT_432, zT_433);
    inserted = zT_434;
    if ((int)(!inserted)) goto z_bb_71; else goto z_bb_72;
    z_bb_12:
    zT_76 = reg;
    zT_78 = store;
    zT_79 = node.child_1;
    zT_81 = zF_8BA26B9E_astStoreNodePayload(zT_78, zT_79);
    zT_77 = zT_81;
    zT_82 = zF_A258E183_moduleRegistryPathT(zT_76, zT_77);
    target = zT_82;
    zT_84 = "M5:p";
    zT_86 = 4;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    m5m = zT_85;
    zT_87 = m5m;
    zF_48AC7B3A_markerWrite(zT_87);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_89[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_89[_i];
        _i++;
    }
}
    zT_93 = store;
    zT_94 = node.child_1;
    zT_96 = zF_8BA26B9E_astStoreNodePayload(zT_93, zT_94);
    zT_91 = zT_96;
    zT_99 = 0;
    zT_100 = (unsigned char*)((unsigned char*)m5pb) + zT_99;
    zT_101 = (unsigned int)(20) - zT_99;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_92 = zT_102;
    zT_103 = zF_A7504564_itoa(zT_91, zT_92);
    m5pl = zT_103;
    zT_107 = (unsigned int)(19) - (unsigned int)((unsigned int)m5pl);
    m5ps = zT_107;
    zT_112 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_113 = (unsigned int)(19) - m5ps;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_115 = target.has_value;
    if (zT_115) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_217 = init_node.kind;
    if ((int)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    mtid = target.value;
    zT_118 = "Rs";
    zT_120 = 2;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    rs_msg = zT_119;
    zT_121 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_124 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_124;
    sym_mod_id = mtid;
    zT_126 = "FIX1:mid=";
    zT_128 = 9;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    di_m = zT_127;
    zT_129 = di_m;
    zF_48AC7B3A_markerWrite(zT_129);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_131[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_131[_i];
        _i++;
    }
}
    zT_133 = sym_mod_id;
    zT_137 = 0;
    zT_138 = (unsigned char*)((unsigned char*)di_mb) + zT_137;
    zT_139 = (unsigned int)(10) - zT_137;
    zT_140.ptr = zT_138;
    zT_140.len = zT_139;
    zT_134 = zT_140;
    zT_141 = zF_A7504564_itoa(zT_133, zT_134);
    di_ml = zT_141;
    zT_145 = (unsigned int)(9) - (unsigned int)((unsigned int)di_ml);
    di_ms = zT_145;
    zT_150 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_151 = (unsigned int)(9) - di_ms;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zF_48AC7B3A_markerWrite(zT_146);
    zT_154 = "t";
    zT_156 = 1;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    di_t = zT_155;
    zT_157 = di_t;
    zF_48AC7B3A_markerWrite(zT_157);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_159[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_159[_i];
        _i++;
    }
}
    zT_161 = mtid;
    zT_165 = 0;
    zT_166 = (unsigned char*)((unsigned char*)di_tb) + zT_165;
    zT_167 = (unsigned int)(10) - zT_165;
    zT_168.ptr = zT_166;
    zT_168.len = zT_167;
    zT_162 = zT_168;
    zT_169 = zF_A7504564_itoa(zT_161, zT_162);
    di_tl = zT_169;
    zT_173 = (unsigned int)(9) - (unsigned int)((unsigned int)di_tl);
    di_ts = zT_173;
    zT_178 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_179 = (unsigned int)(9) - di_ts;
    zT_180.ptr = zT_178;
    zT_180.len = zT_179;
    zT_174 = zT_180;
    zF_48AC7B3A_markerWrite(zT_174);
    zT_182 = "n";
    zT_184 = 1;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    di_n = zT_183;
    zT_185 = di_n;
    zF_48AC7B3A_markerWrite(zT_185);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_187[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_187[_i];
        _i++;
    }
}
    zT_189 = mod_id;
    zT_193 = 0;
    zT_194 = (unsigned char*)((unsigned char*)di_nb) + zT_193;
    zT_195 = (unsigned int)(10) - zT_193;
    zT_196.ptr = zT_194;
    zT_196.len = zT_195;
    zT_190 = zT_196;
    zT_197 = zF_A7504564_itoa(zT_189, zT_190);
    di_nl = zT_197;
    zT_201 = (unsigned int)(9) - (unsigned int)((unsigned int)di_nl);
    di_ns = zT_201;
    zT_206 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_207 = (unsigned int)(9) - di_ns;
    zT_208.ptr = zT_206;
    zT_208.len = zT_207;
    zT_202 = zT_208;
    zF_48AC7B3A_markerWrite(zT_202);
    zT_209 = type_reg;
    zT_210 = mtid;
    zT_211 = zF_2ECA9F93_typeRegistryGetOrCr(zT_209, zT_210);
    sym_type_id = zT_211;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_213 = "Rf";
    zT_215 = 2;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    rf_msg = zT_214;
    zT_216 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    goto z_bb_15;
    z_bb_17:
    zT_223 = init_node.kind;
    zT_222 = zT_223 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_222 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_222) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_229 = init_node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_228 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_228) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_235 = init_node.kind;
    zT_234 = zT_235 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_234 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_234) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_241 = init_node.kind;
switch (zT_241) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_318 = init_node.kind;
    if ((int)(zT_318 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_52; else goto z_bb_54;
    z_bb_29:
    zT_242 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_35;
    z_bb_30:
    zT_242 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_249 = init_node.flags;
    zT_253 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_249) & (unsigned short)(16)) != zT_253)) goto z_bb_36; else goto z_bb_37;
    z_bb_32:
    zT_242 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_242 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_242;
    zT_278 = type_reg;
    zT_279 = mod_id;
    zT_280 = name_id;
    zT_281 = type_kind;
    zT_282 = zF_3A64E2E0_typeRegistryRegiste(zT_278, zT_279, zT_280, zT_281);
    sym_type_id = zT_282;
    zT_283 = init_node.kind;
    if ((int)(zT_283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_43; else goto z_bb_42;
    z_bb_36:
    zT_255 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_38;
    z_bb_37:
    zT_259 = init_node.flags;
    zT_261 = 1;
    zT_263 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_259) & zT_261) != zT_263)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_242 = zT_255;
    goto z_bb_35;
    z_bb_39:
    zT_265 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_265 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_41;
    z_bb_41:
    zT_255 = zT_265;
    goto z_bb_38;
    z_bb_42:
    zT_289 = init_node.kind;
    zT_288 = zT_289 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_44;
    z_bb_43:
    zT_288 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_288) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_295 = init_node.flags;
    zT_294 = (unsigned short)((unsigned short)((unsigned short)zT_295) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_47;
    z_bb_46:
    zT_294 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_294) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_301 = type_reg;
    zT_302 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_301, zT_302);
    goto z_bb_49;
    z_bb_49:
    if (populate) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_303 = type_reg;
    zT_304 = store;
    zT_305 = init_node.kind;
    zT_306 = node.child_1;
    zT_307 = sym_reg;
    zF_020995FB_populateTypePayload(zT_303, zT_304, zT_305, zT_306, zT_307);
    goto z_bb_51;
    z_bb_51:
    zT_310 = store;
    zT_311 = node.child_1;
    zT_312 = sym_type_id;
    zT_313 = g;
    zF_4976C319_addTypeDependencies(zT_310, zT_311, zT_312, zT_313);
    zT_317 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_317;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_52:
    zT_324 = "RCA:p";
    zT_326 = 5;
    zT_325.ptr = zT_324;
    zT_325.len = zT_326;
    rca_m = zT_325;
    zT_327 = rca_m;
    zT_329 = store;
    zT_330 = node.child_1;
    zT_332 = zF_8BA26B9E_astStoreNodePayload(zT_329, zT_330);
    zT_328 = zT_332;
    zF_C914CB83_markerWriteInt(zT_327, zT_328);
    zT_334 = store;
    zT_335 = node.child_1;
    zT_337 = zF_53458827_astStoreIdentifier(zT_334, zT_335);
    ident_name_id = zT_337;
    zT_339 = "RCA:i";
    zT_341 = 5;
    zT_340.ptr = zT_339;
    zT_340.len = zT_341;
    rca_i = zT_340;
    zT_342 = rca_i;
    zT_343 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_342, zT_343);
    zT_345 = type_reg;
    zT_352 = zF_0EB68360_nameCacheGet(zT_345, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id)));
    cached = zT_352;
    zT_353 = cached.has_value;
    if ((int)(!zT_353)) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_27;
    z_bb_54:
    zT_379 = init_node.kind;
    if ((int)(zT_379 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_60; else goto z_bb_59;
    z_bb_55:
    zT_355 = type_reg;
    zT_358 = zF_0EB68360_nameCacheGet(zT_355, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_358;
    goto z_bb_56;
    z_bb_56:
    zT_359 = cached.has_value;
    if (zT_359) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    ct = cached.value;
    zT_362 = "RCA:H";
    zT_364 = 5;
    zT_363.ptr = zT_362;
    zT_363.len = zT_364;
    rca_h = zT_363;
    zT_365 = rca_h;
    zT_366 = ct;
    zF_C914CB83_markerWriteInt(zT_365, zT_366);
    zT_372 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    ck = zT_372;
    zT_373 = type_reg;
    zT_374 = ck;
    zT_375 = ct;
    zF_5E95558D_nameCachePut(zT_373, zT_374, zT_375);
    sym_type_id = ct;
    zT_378 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_378;
    sym_mod_id = mod_id;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_53;
    z_bb_59:
    zT_385 = init_node.kind;
    zT_384 = zT_385 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_61;
    z_bb_60:
    zT_384 = 1;
    goto z_bb_61;
    z_bb_61:
    if (zT_384) goto z_bb_63; else goto z_bb_62;
    z_bb_62:
    zT_391 = init_node.kind;
    zT_390 = zT_391 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_64;
    z_bb_63:
    zT_390 = 1;
    goto z_bb_64;
    z_bb_64:
    if (zT_390) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_397 = "AT:p";
    zT_399 = 4;
    zT_398.ptr = zT_397;
    zT_398.len = zT_399;
    at_m = zT_398;
    zT_400 = at_m;
    zT_401 = name_id;
    zF_C914CB83_markerWriteInt(zT_400, zT_401);
    zT_403 = type_reg;
    zT_410 = zF_0EB68360_nameCacheGet(zT_403, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id)));
    acached = zT_410;
    zT_411 = acached.has_value;
    if ((int)(!zT_411)) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_53;
    z_bb_67:
    zT_413 = type_reg;
    zT_416 = zF_0EB68360_nameCacheGet(zT_413, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_416;
    goto z_bb_68;
    z_bb_68:
    zT_417 = acached.has_value;
    if (zT_417) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    act = acached.value;
    sym_type_id = act;
    goto z_bb_70;
    z_bb_70:
    zT_421 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_421;
    sym_mod_id = mod_id;
    goto z_bb_66;
    z_bb_71:
    zT_437 = "VR";
    zT_439 = 2;
    zT_438.ptr = zT_437;
    zT_438.len = zT_439;
    vr = zT_438;
    zT_440 = vr;
    zF_48AC7B3A_markerWrite(zT_440);
    goto z_bb_72;
    z_bb_72:
    zT_442 = "VD";
    zT_444 = 2;
    zT_443.ptr = zT_442;
    zT_443.len = zT_444;
    vd = zT_443;
    zT_445 = vd;
    zF_48AC7B3A_markerWrite(zT_445);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_447[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_447[_i];
        _i++;
    }
}
    zT_449 = name_id;
    zT_453 = 0;
    zT_454 = (unsigned char*)((unsigned char*)vb) + zT_453;
    zT_455 = (unsigned int)(20) - zT_453;
    zT_456.ptr = zT_454;
    zT_456.len = zT_455;
    zT_450 = zT_456;
    zT_457 = zF_A7504564_itoa(zT_449, zT_450);
    vn = zT_457;
    zT_463 = (unsigned int)(19) - (unsigned int)((unsigned int)vn);
    vns = zT_463;
    zT_468 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_469 = (unsigned int)(20) - vns;
    zT_470.ptr = zT_468;
    zT_470.len = zT_469;
    zT_464 = zT_470;
    zF_48AC7B3A_markerWrite(zT_464);
    zT_472 = ":";
    zT_474 = 1;
    zT_473.ptr = zT_472;
    zT_473.len = zT_474;
    vc = zT_473;
    zT_475 = vc;
    zF_48AC7B3A_markerWrite(zT_475);
    zT_482 = 0;
    zT_483 = (unsigned char*)((unsigned char*)vb) + zT_482;
    zT_484 = (unsigned int)(20) - zT_482;
    zT_485.ptr = zT_483;
    zT_485.len = zT_484;
    zT_478 = zT_485;
    zT_486 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_478);
    vk = zT_486;
    zT_492 = (unsigned int)(19) - (unsigned int)((unsigned int)vk);
    vks = zT_492;
    zT_497 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_498 = (unsigned int)(20) - vks;
    zT_499.ptr = zT_497;
    zT_499.len = zT_498;
    zT_493 = zT_499;
    zF_48AC7B3A_markerWrite(zT_493);
    zT_501 = "\n";
    zT_503 = 1;
    zT_502.ptr = zT_501;
    zT_502.len = zT_503;
    ven = zT_502;
    zT_504 = ven;
    zF_48AC7B3A_markerWrite(zT_504);
    zT_506 = "Vi";
    zT_508 = 2;
    zT_507.ptr = zT_506;
    zT_507.len = zT_508;
    vi_msg = zT_507;
    zT_509 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_509);
    goto z_bb_9;
    z_bb_73:
    zT_542 = store;
    zT_543 = decl_idx;
    zT_544 = zF_8BA26B9E_astStoreNodePayload(zT_542, zT_543);
    zT_541.name_id = zT_544;
    zT_545 = 0;
    zT_541.type_id = zT_545;
    zT_548 = zT_3C598AEF_SymbolKind_test_sym;
    zT_541.kind = zT_548;
    zT_549 = node.flags;
    zT_550 = (unsigned short)zT_549;
    zT_541.flags = zT_550;
    zT_541.decl_node = decl_idx;
    zT_541.module_id = mod_id;
    zT_551 = 0;
    zT_541.scope_level = zT_551;
    sym = zT_541;
    zT_553 = sym_reg;
    zT_554 = mod_id;
    zT_555 = zF_9B36C202_symbolRegistryGetTa(zT_553, zT_554);
    table = zT_555;
    zT_556 = table;
    zT_557 = sym;
    zT_558 = zF_D0156DDA_symbolTableInsert(zT_556, zT_557);
    (void)zT_558;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_9;
    z_bb_75:
    zT_570 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_80;
    z_bb_76:
    zT_570 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_80;
    z_bb_77:
    zT_577 = node.flags;
    zT_581 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_577) & (unsigned short)(16)) != zT_581)) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_570 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_80;
    z_bb_80:
    type_kind = zT_570;
    zT_604 = type_reg;
    zT_605 = mod_id;
    zT_606 = name_id;
    zT_607 = type_kind;
    zT_608 = zF_3A64E2E0_typeRegistryRegiste(zT_604, zT_605, zT_606, zT_607);
    tid = zT_608;
    zT_609 = node.kind;
    if ((int)(zT_609 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_88; else goto z_bb_87;
    z_bb_81:
    zT_583 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_83;
    z_bb_82:
    zT_587 = node.flags;
    zT_589 = 1;
    zT_591 = 0;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_587) & zT_589) != zT_591)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_570 = zT_583;
    goto z_bb_80;
    z_bb_84:
    zT_593 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_86;
    z_bb_85:
    zT_593 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_86;
    z_bb_86:
    zT_583 = zT_593;
    goto z_bb_83;
    z_bb_87:
    zT_615 = node.kind;
    zT_614 = zT_615 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_89;
    z_bb_88:
    zT_614 = 1;
    goto z_bb_89;
    z_bb_89:
    if (zT_614) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_621 = node.flags;
    zT_620 = (unsigned short)((unsigned short)((unsigned short)zT_621) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_92;
    z_bb_91:
    zT_620 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_620) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_627 = type_reg;
    zT_628 = tid;
    zF_52816016_typeRegistrySetPack(zT_627, zT_628);
    goto z_bb_94;
    z_bb_94:
    if (populate) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_629 = type_reg;
    zT_630 = store;
    zT_631 = node.kind;
    zT_632 = decl_idx;
    zT_633 = sym_reg;
    zF_020995FB_populateTypePayload(zT_629, zT_630, zT_631, zT_632, zT_633);
    goto z_bb_96;
    z_bb_96:
    zT_635 = store;
    zT_636 = decl_idx;
    zT_637 = tid;
    zT_638 = g;
    zF_4976C319_addTypeDependencies(zT_635, zT_636, zT_637, zT_638);
    zT_640.name_id = name_id;
    zT_640.type_id = tid;
    zT_643 = zT_3C598AEF_SymbolKind_type_alias;
    zT_640.kind = zT_643;
    zT_644 = node.flags;
    zT_645 = (unsigned short)zT_644;
    zT_640.flags = zT_645;
    zT_640.decl_node = decl_idx;
    zT_640.module_id = mod_id;
    zT_646 = 0;
    zT_640.scope_level = zT_646;
    sym = zT_640;
    zT_648 = sym_reg;
    zT_649 = mod_id;
    zT_650 = zF_9B36C202_symbolRegistryGetTa(zT_648, zT_649);
    table = zT_650;
    zT_651 = table;
    zT_652 = sym;
    zT_653 = zF_D0156DDA_symbolTableInsert(zT_651, zT_652);
    (void)zT_653;
    goto z_bb_9;
    z_bb_97:
    zT_672 = type_reg;
    zT_673 = store;
    zT_674 = node.kind;
    zT_675 = decl_idx;
    zT_676 = sym_reg;
    zF_020995FB_populateTypePayload(zT_672, zT_673, zT_674, zT_675, zT_676);
    goto z_bb_98;
    z_bb_98:
    zT_679.name_id = name_id;
    zT_679.type_id = tid;
    zT_682 = zT_3C598AEF_SymbolKind_type_alias;
    zT_679.kind = zT_682;
    zT_683 = node.flags;
    zT_684 = (unsigned short)zT_683;
    zT_679.flags = zT_684;
    zT_679.decl_node = decl_idx;
    zT_679.module_id = mod_id;
    zT_685 = 0;
    zT_679.scope_level = zT_685;
    sym = zT_679;
    zT_687 = sym_reg;
    zT_688 = mod_id;
    zT_689 = zF_9B36C202_symbolRegistryGetTa(zT_687, zT_688);
    table = zT_689;
    zT_690 = table;
    zT_691 = sym;
    zT_692 = zF_D0156DDA_symbolTableInsert(zT_690, zT_691);
    (void)zT_692;
    goto z_bb_9;
    z_bb_99:
    tid = target_mod_id.value;
    zT_704.name_id = path_id;
    zT_705 = type_reg;
    zT_706 = tid;
    zT_707 = zF_2ECA9F93_typeRegistryGetOrCr(zT_705, zT_706);
    zT_704.type_id = zT_707;
    zT_710 = zT_3C598AEF_SymbolKind_module;
    zT_704.kind = zT_710;
    zT_711 = 0;
    zT_704.flags = zT_711;
    zT_704.decl_node = decl_idx;
    zT_704.module_id = tid;
    zT_712 = 0;
    zT_704.scope_level = zT_712;
    sym = zT_704;
    zT_714 = sym_reg;
    zT_715 = mod_id;
    zT_716 = zF_9B36C202_symbolRegistryGetTa(zT_714, zT_715);
    table = zT_716;
    zT_717 = table;
    zT_718 = sym;
    zT_719 = zF_D0156DDA_symbolTableInsert(zT_717, zT_718);
    (void)zT_719;
    zT_721 = "IMR:n";
    zT_723 = 5;
    zT_722.ptr = zT_721;
    zT_722.len = zT_723;
    imr = zT_722;
    zT_724 = imr;
    zF_48AC7B3A_markerWrite(zT_724);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_726[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_726[_i];
        _i++;
    }
}
    zT_728 = path_id;
    zT_732 = 0;
    zT_733 = (unsigned char*)((unsigned char*)imb) + zT_732;
    zT_734 = (unsigned int)(10) - zT_732;
    zT_735.ptr = zT_733;
    zT_735.len = zT_734;
    zT_729 = zT_735;
    zT_736 = zF_A7504564_itoa(zT_728, zT_729);
    iml = zT_736;
    zT_740 = (unsigned int)(9) - (unsigned int)((unsigned int)iml);
    ims = zT_740;
    zT_745 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_746 = (unsigned int)(9) - ims;
    zT_747.ptr = zT_745;
    zT_747.len = zT_746;
    zT_741 = zT_747;
    zF_48AC7B3A_markerWrite(zT_741);
    zT_749 = "m";
    zT_751 = 1;
    zT_750.ptr = zT_749;
    zT_750.len = zT_751;
    imm = zT_750;
    zT_752 = imm;
    zF_48AC7B3A_markerWrite(zT_752);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_754[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_754[_i];
        _i++;
    }
}
    zT_756 = tid;
    zT_760 = 0;
    zT_761 = (unsigned char*)((unsigned char*)immb) + zT_760;
    zT_762 = (unsigned int)(10) - zT_760;
    zT_763.ptr = zT_761;
    zT_763.len = zT_762;
    zT_757 = zT_763;
    zT_764 = zF_A7504564_itoa(zT_756, zT_757);
    imml = zT_764;
    zT_768 = (unsigned int)(9) - (unsigned int)((unsigned int)imml);
    imms = zT_768;
    zT_773 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_774 = (unsigned int)(9) - imms;
    zT_775.ptr = zT_773;
    zT_775.len = zT_774;
    zT_769 = zT_775;
    zF_48AC7B3A_markerWrite(zT_769);
    zT_777 = " ";
    zT_779 = 1;
    zT_778.ptr = zT_777;
    zT_778.len = zT_779;
    imsnl = zT_778;
    zT_780 = imsnl;
    zF_48AC7B3A_markerWrite(zT_780);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, int populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    int zT_17;
    zT_9FE1BFFE_ModuleState zT_18;
    int zT_23;
    unsigned int zT_24;
    int zT_25;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode zT_31 = {0};
    zT_8143F551_AstKind zT_32;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_41 = {0};
    char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_4028D896_Arr_unsigned_char_2 zT_50;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_8143F551_AstKind zT_56;
    zT_79FAE712_u64 zT_59 = 0;
    zT_79FAE712_u64 zT_61;
    int zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    int zT_87;
    unsigned int zT_88;
    unsigned int zT_90;
    zT_4028D896_Arr_unsigned_char_2 zT_93;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int* zT_97;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105 = 0;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    unsigned int* zT_125;
    zT_22A7C88B_AstNode zT_127 = {0};
    zT_8143F551_AstKind zT_129;
    unsigned int zT_130;
    zT_4028D896_Arr_unsigned_char_2 zT_132;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    int zT_138;
    unsigned char* zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned char* zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    int zT_159;
    unsigned int zT_160;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    int zT_167;
    unsigned int zT_168;
    unsigned int zT_170;
    zT_3D7259E2_SymbolRegistry* zT_172;
    zT_338B7C76_TypeRegistry* zT_173;
    zT_6B0A7D14_AstStore* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_4D61441E_DepGraph* zT_177;
    zT_072B53A6_ModuleRegistry* zT_178;
    int zT_179;
    unsigned int* zT_180;
    int zT_182;
    unsigned int zT_184;
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((int)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = entry.state;
    zT_17 = zT_18 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_17 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_17) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_24 = entry.ast_root;
    zT_25 = 0;
    zT_23 = zT_24 == (unsigned int)zT_25;
    goto z_bb_6;
    z_bb_5:
    zT_23 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_23) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_28 = store;
    zT_29 = entry.ast_root;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    root = zT_31;
    zT_32 = root.kind;
    if ((int)(zT_32 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_38 = store;
    zT_39 = entry.ast_root;
    zT_41 = zF_850FDF81_astStoreNodeExtraCh(zT_38, zT_39);
    decls = zT_41;
    if ((int)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_45 = "RS";
    zT_47 = 2;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    dg = zT_46;
    zT_48 = dg;
    zF_48AC7B3A_markerWrite(zT_48);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_50[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_50[_i];
        _i++;
    }
}
    zT_54 = store;
    zT_55 = entry.ast_root;
    zT_56 = root.kind;
    zT_59 = zF_0E4E10C6_astStoreNodePayload(zT_54, zT_55, zT_56);
    zT_61 = zT_59 & (zT_79FAE712_u64)(4294967295u);
    zT_52 = __bootstrap_u32_from_u64(zT_61);
    zT_65 = 0;
    zT_66 = (unsigned char*)((unsigned char*)pb) + zT_65;
    zT_67 = (unsigned int)(20) - zT_65;
    zT_68.ptr = zT_66;
    zT_68.len = zT_67;
    zT_53 = zT_68;
    zT_69 = zF_A7504564_itoa(zT_52, zT_53);
    pl = zT_69;
    zT_73 = (unsigned int)(19) - (unsigned int)((unsigned int)pl);
    ps = zT_73;
    zT_78 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_79 = (unsigned int)(19) - ps;
    zT_80.ptr = zT_78;
    zT_80.len = zT_79;
    zT_74 = zT_80;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_82 = ":";
    zT_84 = 1;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    sc = zT_83;
    zT_85 = sc;
    zF_48AC7B3A_markerWrite(zT_85);
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    i2 = zT_88;
    goto z_bb_13;
    z_bb_12:
    zT_167 = 0;
    zT_168 = (unsigned int)zT_167;
    i = zT_168;
    goto z_bb_17;
    z_bb_13:
    zT_90 = decls.len;
    if ((int)(i2 < zT_90)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_93[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_93[_i];
        _i++;
    }
}
    zT_97 = decls.ptr;
    zT_95 = zT_97[i2];
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)ii_buf) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = zT_102;
    zT_104.len = zT_103;
    zT_96 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_95, zT_96);
    ii_len = zT_105;
    zT_109 = (unsigned int)(19) - (unsigned int)((unsigned int)ii_len);
    ii_start = zT_109;
    zT_114 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_115 = (unsigned int)(19) - ii_start;
    zT_116.ptr = zT_114;
    zT_116.len = zT_115;
    zT_110 = zT_116;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_118 = "=";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    ss = zT_119;
    zT_121 = ss;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_123 = store;
    zT_125 = decls.ptr;
    zT_124 = zT_125[i2];
    zT_127 = zF_FCDD1D35_astStoreNodeAt(zT_123, zT_124);
    dc = zT_127;
    zT_129 = dc.kind;
    zT_130 = (unsigned int)zT_129;
    dk = zT_130;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_132[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_132[_i];
        _i++;
    }
}
    zT_134 = dk;
    zT_138 = 0;
    zT_139 = (unsigned char*)((unsigned char*)db) + zT_138;
    zT_140 = (unsigned int)(20) - zT_138;
    zT_141.ptr = zT_139;
    zT_141.len = zT_140;
    zT_135 = zT_141;
    zT_142 = zF_A7504564_itoa(zT_134, zT_135);
    dl = zT_142;
    zT_146 = (unsigned int)(19) - (unsigned int)((unsigned int)dl);
    ds = zT_146;
    zT_151 = (unsigned char*)((unsigned char*)db) + ds;
    zT_152 = (unsigned int)(19) - ds;
    zT_153.ptr = zT_151;
    zT_153.len = zT_152;
    zT_147 = zT_153;
    zF_48AC7B3A_markerWrite(zT_147);
    zT_155 = " ";
    zT_157 = 1;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    dsp = zT_156;
    zT_158 = dsp;
    zF_48AC7B3A_markerWrite(zT_158);
    goto z_bb_16;
    z_bb_15:
    zT_162 = "\n";
    zT_164 = 1;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    dn = zT_163;
    zT_165 = dn;
    zF_48AC7B3A_markerWrite(zT_165);
    goto z_bb_12;
    z_bb_16:
    zT_159 = 1;
    zT_160 = i2 + zT_159;
    i2 = zT_160;
    goto z_bb_13;
    z_bb_17:
    zT_170 = decls.len;
    if ((int)(i < zT_170)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_172 = sym_reg;
    zT_173 = type_reg;
    zT_174 = store;
    zT_175 = module_id;
    zT_180 = decls.ptr;
    zT_176 = zT_180[i];
    zT_177 = g;
    zT_178 = reg;
    zT_179 = populate;
    zF_CBEB26BC_registerDecl(zT_172, zT_173, zT_174, zT_175, zT_176, zT_177, zT_178, zT_179);
    zT_182 = 1;
    zT_184 = i + (unsigned int)((unsigned int)zT_182);
    i = zT_184;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_33EF6BFB_TypeKind zT_1 = 0;
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
