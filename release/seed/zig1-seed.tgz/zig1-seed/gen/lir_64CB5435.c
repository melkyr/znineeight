#include "lir_64CB5435.h"
zT_CA01C129_LirSlotArrayList zG_CA01C129_LirSlotArrayList;
unsigned char zG_85047B93_CHECK_OP_ADD;
unsigned char zG_92FF6172_CHECK_OP_SUB;
unsigned char zG_08A9DD8E_CHECK_OP_MUL;
unsigned char zG_DB0C9EBD_CHECK_OP_SHL;
unsigned char zG_5C81A75E_CHECK_OP_NEG;
zT_BBC23664_LirFunction zG_BBC23664_LirFunction;
zT_E7714190_LirSlot zG_E7714190_LirSlot;
zT_6BA597BC_LirInst zG_6BA597BC_LirInst;
/* lirSideEntryArrayListInit */
zT_AC00B5F6_LirSideEntryArrayLi zF_4231AD2C_lirSideEntryArrayLi(zT_3E40CD83_Sand* allocator) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_A8A5B231_LirSideEntry*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirSideEntryArrayListEnsureCapacity */
void zF_B5A8F8E4_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_A8A5B231_LirSideEntry* zT_28;
    zT_A8A5B231_LirSideEntry* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_A8A5B231_LirSideEntry* zT_32;
    unsigned int zT_33;
    zT_99DE57BF_Slice_zT_A8A5B231_L zT_34;
    zT_A8A5B231_LirSideEntry* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_A8A5B231_LirSideEntry* new_items;
    zT_A8A5B231_LirSideEntry item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(28) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_A8A5B231_LirSideEntry*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* lirSideEntryArrayListAppend */
void zF_6E2511C2_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self, zT_A8A5B231_LirSideEntry value) {
    zT_AC00B5F6_LirSideEntryArrayLi* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_A8A5B231_LirSideEntry* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_B5A8F8E4_lirSideEntryArrayLi(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* lirSideEntryArrayListGetSlice */
zT_99DE57BF_Slice_zT_A8A5B231_L zF_AC1429C8_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self) {
    zT_A8A5B231_LirSideEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_A8A5B231_LirSideEntry* zT_4;
    unsigned int zT_5;
    zT_99DE57BF_Slice_zT_A8A5B231_L zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* lirInstArrayListInit */
zT_DAE4631D_LirInstArrayList zF_C6E3B5BB_lirInstArrayListIni(zT_3E40CD83_Sand* allocator) {
    zT_DAE4631D_LirInstArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_6BA597BC_LirInst*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirInstArrayListEnsureCapacity */
void zF_178C876B_lirInstArrayListEns(zT_DAE4631D_LirInstArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_6BA597BC_LirInst* zT_28;
    zT_6BA597BC_LirInst* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_6BA597BC_LirInst* zT_32;
    unsigned int zT_33;
    zT_804A8058_Slice_zT_6BA597BC_L zT_34;
    zT_6BA597BC_LirInst* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_6BA597BC_LirInst* new_items;
    zT_6BA597BC_LirInst item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(32) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_6BA597BC_LirInst*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* lirInstArrayListAppend */
void zF_4BFD6009_lirInstArrayListApp(zT_DAE4631D_LirInstArrayList* self, zT_6BA597BC_LirInst value) {
    zT_DAE4631D_LirInstArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_6BA597BC_LirInst* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_178C876B_lirInstArrayListEns(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* lirInstArrayListGetSlice */
zT_804A8058_Slice_zT_6BA597BC_L zF_33BACEFF_lirInstArrayListGet(zT_DAE4631D_LirInstArrayList* self) {
    zT_6BA597BC_LirInst* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6BA597BC_LirInst* zT_4;
    unsigned int zT_5;
    zT_804A8058_Slice_zT_6BA597BC_L zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* basicBlockArrayListInit */
zT_1CF28CA3_BasicBlockArrayList zF_2B78727D_basicBlockArrayList(zT_3E40CD83_Sand* allocator) {
    zT_1CF28CA3_BasicBlockArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_88A68B1A_BasicBlock*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* basicBlockArrayListEnsureCapacity */
void zF_DFD16D95_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_88A68B1A_BasicBlock* zT_28;
    zT_88A68B1A_BasicBlock* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_88A68B1A_BasicBlock* zT_32;
    unsigned int zT_33;
    zT_A12E931C_Slice_zT_88A68B1A_B zT_34;
    zT_88A68B1A_BasicBlock* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_88A68B1A_BasicBlock* new_items;
    zT_88A68B1A_BasicBlock item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(24) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_88A68B1A_BasicBlock*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* basicBlockArrayListAppend */
void zF_09D85813_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self, zT_88A68B1A_BasicBlock value) {
    zT_1CF28CA3_BasicBlockArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_88A68B1A_BasicBlock* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_DFD16D95_basicBlockArrayList(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* basicBlockArrayListGetSlice */
zT_A12E931C_Slice_zT_88A68B1A_B zF_EF689609_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self) {
    zT_88A68B1A_BasicBlock* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_88A68B1A_BasicBlock* zT_4;
    unsigned int zT_5;
    zT_A12E931C_Slice_zT_88A68B1A_B zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* lirParamArrayListInit */
zT_CFE23D0A_LirParamArrayList zF_0ED358C0_lirParamArrayListIn(zT_3E40CD83_Sand* allocator) {
    zT_CFE23D0A_LirParamArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_8779209D_LirParam*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirParamArrayListEnsureCapacity */
void zF_D7BA6100_lirParamArrayListEn(zT_CFE23D0A_LirParamArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_8779209D_LirParam* zT_28;
    zT_8779209D_LirParam* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_8779209D_LirParam* zT_32;
    unsigned int zT_33;
    zT_2F054080_Slice_zT_8779209D_L zT_34;
    zT_8779209D_LirParam* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_8779209D_LirParam* new_items;
    zT_8779209D_LirParam item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(12) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_8779209D_LirParam*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* lirParamArrayListAppend */
void zF_5266C13E_lirParamArrayListAp(zT_CFE23D0A_LirParamArrayList* self, zT_8779209D_LirParam value) {
    zT_CFE23D0A_LirParamArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_8779209D_LirParam* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_D7BA6100_lirParamArrayListEn(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* lirParamArrayListGetSlice */
zT_2F054080_Slice_zT_8779209D_L zF_DFC53FA4_lirParamArrayListGe(zT_CFE23D0A_LirParamArrayList* self) {
    zT_8779209D_LirParam* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_8779209D_LirParam* zT_4;
    unsigned int zT_5;
    zT_2F054080_Slice_zT_8779209D_L zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* tempDeclArrayListInit */
zT_5D72FBF8_TempDeclArrayList zF_DE63156A_tempDeclArrayListIn(zT_3E40CD83_Sand* allocator) {
    zT_5D72FBF8_TempDeclArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_1937645B_TempDecl*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* tempDeclArrayListEnsureCapacity */
void zF_2A1781A2_tempDeclArrayListEn(zT_5D72FBF8_TempDeclArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_1937645B_TempDecl* zT_28;
    zT_1937645B_TempDecl* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_1937645B_TempDecl* zT_32;
    unsigned int zT_33;
    zT_732DFD13_Slice_zT_1937645B_T zT_34;
    zT_1937645B_TempDecl* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_1937645B_TempDecl* new_items;
    zT_1937645B_TempDecl item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_1937645B_TempDecl*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* tempDeclArrayListAppend */
void zF_70DD3460_tempDeclArrayListAp(zT_5D72FBF8_TempDeclArrayList* self, zT_1937645B_TempDecl value) {
    zT_5D72FBF8_TempDeclArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_1937645B_TempDecl* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_2A1781A2_tempDeclArrayListEn(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* tempDeclArrayListGetSlice */
zT_732DFD13_Slice_zT_1937645B_T zF_5450447E_tempDeclArrayListGe(zT_5D72FBF8_TempDeclArrayList* self) {
    zT_1937645B_TempDecl* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_1937645B_TempDecl* zT_4;
    unsigned int zT_5;
    zT_732DFD13_Slice_zT_1937645B_T zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* switchCaseArrayListInit */
zT_9F514E82_SwitchCaseArrayList zF_64707188_switchCaseArrayList(zT_3E40CD83_Sand* allocator) {
    zT_9F514E82_SwitchCaseArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_4BD97095_SwitchCase*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* switchCaseArrayListEnsureCapacity */
void zF_937B1D28_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_4BD97095_SwitchCase* zT_28;
    zT_4BD97095_SwitchCase* zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_4BD97095_SwitchCase* zT_32;
    unsigned int zT_33;
    zT_11D00852_Slice_zT_4BD97095_S zT_34;
    zT_4BD97095_SwitchCase* zT_35;
    unsigned int zT_36;
    unsigned int zT_41;
    unsigned int new_cap;
    unsigned char* raw;
    zT_4BD97095_SwitchCase* new_items;
    zT_4BD97095_SwitchCase item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(16) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_4BD97095_SwitchCase*)raw;
    new_items = zT_28;
    zT_29 = self->items;
    zT_30 = self->len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_35 = zT_34.ptr;
    zT_36 = zT_34.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_36)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_35[i];
    new_items[i] = item;
    zT_41 = i + (unsigned int)(1);
    i = zT_41;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* switchCaseArrayListAppend */
void zF_AFFB7306_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self, zT_4BD97095_SwitchCase value) {
    zT_9F514E82_SwitchCaseArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_4BD97095_SwitchCase* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_937B1D28_switchCaseArrayList(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* switchCaseArrayListGetSlice */
zT_11D00852_Slice_zT_4BD97095_S zF_82C0CEBC_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self) {
    zT_4BD97095_SwitchCase* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_4BD97095_SwitchCase* zT_4;
    unsigned int zT_5;
    zT_11D00852_Slice_zT_4BD97095_S zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* lirSlotArrayListInit */
zT_CA01C129_LirSlotArrayList zF_F91F6677_lirSlotArrayListIni(zT_3E40CD83_Sand* allocator) {
    zT_CA01C129_LirSlotArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_E7714190_LirSlot*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirSlotArrayListEnsureCapacity */
void zF_851221CF_lirSlotArrayListEns(zT_CA01C129_LirSlotArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_ACA03DB3_EU_632 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_E7714190_LirSlot* zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_E7714190_LirSlot* zT_33;
    zT_E7714190_LirSlot zT_34;
    unsigned int zT_36;
    unsigned int new_cap;
    unsigned char* raw;
    zT_E7714190_LirSlot* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 4;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(12) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_E7714190_LirSlot*)raw;
    new_items = zT_28;
    zT_30 = 0;
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    zT_31 = self->len;
    if ((unsigned char)(i < zT_31)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->items;
    zT_34 = zT_33[i];
    new_items[i] = zT_34;
    goto z_bb_13;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13:
    zT_36 = i + (unsigned int)(1);
    i = zT_36;
    goto z_bb_10;
}

/* lirSlotArrayListAppend */
void zF_BD1C46FD_lirSlotArrayListApp(zT_CA01C129_LirSlotArrayList* self, zT_E7714190_LirSlot value) {
    zT_CA01C129_LirSlotArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_E7714190_LirSlot* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_851221CF_lirSlotArrayListEns(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* lirSlotArrayListGetSlice */
zT_E44058BB_Slice_zT_E7714190_L zF_8E0BDF63_lirSlotArrayListGet(zT_CA01C129_LirSlotArrayList* self) {
    zT_E7714190_LirSlot* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_E7714190_LirSlot* zT_4;
    unsigned int zT_5;
    zT_E44058BB_Slice_zT_E7714190_L zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* lirSideAppendCallDirect */
unsigned int zF_F05FBDC6_lirSideAppendCallDi(zT_BBC23664_LirFunction* lfn, zT_3BFB1E70_CallDirectData d) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_AC00B5F6_LirSideEntryArrayLi* zT_6;
    zT_A8A5B231_LirSideEntry zT_7;
    zT_A8A5B231_LirSideEntry zT_9;
    unsigned int slot;
    zT_3 = lfn->side_table;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    slot = zT_5;
    zT_6 = &lfn->side_table;
    zT_9.call_direct = d;
    zT_7 = zT_9;
    zF_6E2511C2_lirSideEntryArrayLi(zT_6, zT_7);
    return slot;
}

/* lirSideAppendTailCall */
unsigned int zF_79C20A59_lirSideAppendTailCa(zT_BBC23664_LirFunction* lfn, zT_0624AC1B_TailCallData d) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_AC00B5F6_LirSideEntryArrayLi* zT_6;
    zT_A8A5B231_LirSideEntry zT_7;
    zT_A8A5B231_LirSideEntry zT_9;
    unsigned int slot;
    zT_3 = lfn->side_table;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    slot = zT_5;
    zT_6 = &lfn->side_table;
    zT_9.tail_call = d;
    zT_7 = zT_9;
    zF_6E2511C2_lirSideEntryArrayLi(zT_6, zT_7);
    return slot;
}

/* lirSideGetCallDirect */
zT_3BFB1E70_CallDirectData zF_75DE985C_lirSideGetCallDirec(zT_BBC23664_LirFunction* lfn, unsigned int slot) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_2;
    zT_A8A5B231_LirSideEntry* zT_3;
    unsigned int zT_4;
    zT_A8A5B231_LirSideEntry zT_5;
    zT_3BFB1E70_CallDirectData zT_6;
    zT_2 = lfn->side_table;
    zT_3 = zT_2.items;
    zT_4 = (unsigned int)slot;
    zT_5 = zT_3[zT_4];
    zT_6 = zT_5.call_direct;
    return zT_6;
}

/* lirSideGetTailCall */
zT_0624AC1B_TailCallData zF_1AB3807F_lirSideGetTailCall(zT_BBC23664_LirFunction* lfn, unsigned int slot) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_2;
    zT_A8A5B231_LirSideEntry* zT_3;
    unsigned int zT_4;
    zT_A8A5B231_LirSideEntry zT_5;
    zT_0624AC1B_TailCallData zT_6;
    zT_2 = lfn->side_table;
    zT_3 = zT_2.items;
    zT_4 = (unsigned int)slot;
    zT_5 = zT_3[zT_4];
    zT_6 = zT_5.tail_call;
    return zT_6;
}

/* globalDeclArrayListInit */
zT_E1A783EF_GlobalDeclArrayList zF_EB0B1609_globalDeclArrayList(zT_3E40CD83_Sand* allocator) {
    zT_E1A783EF_GlobalDeclArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_54906056_ModuleGlobalDecl*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* globalDeclArrayListEnsureCapacity */
void zF_31512729_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    zT_3E40CD83_Sand* zT_19;
    zT_54906056_ModuleGlobalDecl* zT_25;
    unsigned int zT_27;
    zT_7032B1AE_Opt_236 zT_33 = {0};
    unsigned char zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_ACA03DB3_EU_632 zT_43 = {0};
    unsigned char zT_44;
    unsigned char* zT_45;
    zT_54906056_ModuleGlobalDecl* zT_48;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_54906056_ModuleGlobalDecl* zT_53;
    zT_54906056_ModuleGlobalDecl zT_54;
    unsigned int zT_56;
    unsigned int new_cap;
    zT_7032B1AE_Opt_236 grown;
    unsigned char* raw;
    zT_54906056_ModuleGlobalDecl* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 4;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_15 = self->capacity;
    zT_16 = 0;
    if ((unsigned char)(zT_15 > (unsigned int)zT_16)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_19 = self->allocator;
    zT_25 = self->items;
    zT_27 = self->capacity;
    zT_33 = zF_33A3D4F8_sandTryReallocInPla(zT_19, (unsigned char*)((unsigned char*)zT_25), (unsigned int)(zT_27 * (unsigned int)(16)), (unsigned int)(new_cap * (unsigned int)(16)), (unsigned int)(4));
    grown = zT_33;
    zT_34 = grown.has_value;
    if (zT_34) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_36 = self->allocator;
    zT_43 = zF_1395EB68_sandAlloc(zT_36, (unsigned int)((unsigned int)(16) * new_cap), (unsigned int)(4));
    zT_44 = zT_43.is_error;
    if (zT_44) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_45 = zT_43.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_45;
    zT_48 = (zT_54906056_ModuleGlobalDecl*)raw;
    new_items = zT_48;
    zT_50 = 0;
    i = zT_50;
    goto z_bb_14;
    z_bb_14:
    zT_51 = self->len;
    if ((unsigned char)(i < zT_51)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = self->items;
    zT_54 = zT_53[i];
    new_items[i] = zT_54;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17:
    zT_56 = i + (unsigned int)(1);
    i = zT_56;
    goto z_bb_14;
}

/* globalDeclArrayListAppend */
void zF_F2C82CE7_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self, zT_54906056_ModuleGlobalDecl value) {
    zT_E1A783EF_GlobalDeclArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_54906056_ModuleGlobalDecl* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_31512729_globalDeclArrayList(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* globalDeclArrayListGetSlice */
zT_23133B1E_Slice_zT_54906056_M zF_6ACCE52D_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self) {
    zT_54906056_ModuleGlobalDecl* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_54906056_ModuleGlobalDecl* zT_4;
    unsigned int zT_5;
    zT_23133B1E_Slice_zT_54906056_M zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* __module_init */
void zF_780653D2___module_init_13(void) {
    zG_85047B93_CHECK_OP_ADD = (unsigned char)(0);
    zG_92FF6172_CHECK_OP_SUB = (unsigned char)(1);
    zG_08A9DD8E_CHECK_OP_MUL = (unsigned char)(2);
    zG_DB0C9EBD_CHECK_OP_SHL = (unsigned char)(3);
    zG_5C81A75E_CHECK_OP_NEG = (unsigned char)(4);
    return;
}

/* EOF */
