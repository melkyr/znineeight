#ifndef ZIG_MODULE_CONST_ALIAS_PREPASS_A733A209_H
#define ZIG_MODULE_CONST_ALIAS_PREPASS_A733A209_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "symbol_table_74081C75.h"
#include "type_registry_8EE489B8.h"
#include "hash_02AFCD13.h"
#include "string_interner_51340A9F.h"
#include "ast_2FA12982.h"
#include "pal_388A8A1B.h"


/* Forward declarations */
unsigned int zF_0D410D69_resolveWellKnownTyp(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_62CBE4C7_growDep(zT_3E40CD83_Sand*, unsigned int**, unsigned int**, unsigned int*);
void zF_EF7F7D3C_constAliasPrepass(zT_3D7259E2_SymbolRegistry*, zT_338B7C76_TypeRegistry*, zT_D3EB6303_StringInterner*, zT_6B0A7D14_AstStore*, zT_3E40CD83_Sand*);
void zF_780653D2___module_init_18(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_CONST_ALIAS_PREPASS_A733A209_H */
