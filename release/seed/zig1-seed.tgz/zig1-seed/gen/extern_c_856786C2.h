#ifndef ZIG_MODULE_EXTERN_C_856786C2_H
#define ZIG_MODULE_EXTERN_C_856786C2_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_EXTERN_C_856786C2_H */
