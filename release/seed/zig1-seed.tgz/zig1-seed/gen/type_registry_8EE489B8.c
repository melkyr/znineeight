#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)ubuf) + zT_15;
    zT_17 = (unsigned int)(16) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa((unsigned int)((unsigned int)used), zT_11);
    ulen = zT_19;
    zT_23 = (unsigned int)(15) - (unsigned int)((unsigned int)ulen);
    ustart = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)ubuf) + ustart;
    zT_29 = (unsigned int)(15) - ustart;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)nbuf) + zT_44;
    zT_46 = (unsigned int)(16) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa((unsigned int)((unsigned int)new_bytes), zT_40);
    nlen = zT_48;
    zT_52 = (unsigned int)(15) - (unsigned int)((unsigned int)nlen);
    nstart = zT_52;
    zT_57 = (unsigned char*)((unsigned char*)nbuf) + nstart;
    zT_58 = (unsigned int)(15) - nstart;
    zT_59.ptr = zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_FBF0B3E4_EU_332 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_25;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    if ((int)(zT_6 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_15 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)(elem_size * nc), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zF_9091237C_typeDbOom((unsigned int)(zT_25 * elem_size), (unsigned int)(elem_size * nc));
    return;
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    if ((int)(i < (unsigned int)(zT_37 * elem_size))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    if ((int)(new_cap <= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_29;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    if ((int)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    if ((int)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    if ((int)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->types_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(32) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zF_9091237C_typeDbOom((unsigned int)(zT_29 * (unsigned int)(32)), (unsigned int)((unsigned int)(32) * nc));
    return;
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_44)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    zT_49 = i + (unsigned int)(1);
    i = zT_49;
    goto z_bb_10;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zF_BCE30624_typeRegistryEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    self->types_len = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_25 = 0;
    zT_26 = (unsigned char*)((unsigned char*)dc_k) + zT_25;
    zT_27 = (unsigned int)(20) - zT_25;
    zT_28.ptr = zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_21), zT_20);
    dc_kl = zT_29;
    zT_33 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_kl);
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_43 = (unsigned char*)((unsigned char*)dc_k) + dc_ks;
    zT_44 = (unsigned int)(19) - dc_ks;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_49 = t.name_id;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)dc_n) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_nl);
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_72 = (unsigned char*)((unsigned char*)dc_n) + dc_ns;
    zT_73 = (unsigned int)(19) - dc_ns;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_82 = 0;
    zT_83 = (unsigned char*)((unsigned char*)dc_i) + zT_82;
    zT_84 = (unsigned int)(20) - zT_82;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    zT_90 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_il);
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_100 = (unsigned char*)((unsigned char*)dc_i) + dc_is;
    zT_101 = (unsigned int)(19) - dc_is;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    if ((int)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_112BF819_PtrPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->ptr_items;
    zT_3 = &self->ptr_len;
    zT_4 = &self->ptr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    self->ptr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->array_items;
    zT_3 = &self->array_len;
    zT_4 = &self->array_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->array_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    self->array_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->slice_items;
    zT_3 = &self->slice_len;
    zT_4 = &self->slice_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    self->slice_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->opt_items;
    zT_3 = &self->opt_len;
    zT_4 = &self->opt_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    self->opt_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->eu_items;
    zT_3 = &self->eu_len;
    zT_4 = &self->eu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    self->eu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->es_items;
    zT_3 = &self->es_len;
    zT_4 = &self->es_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->es_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    self->es_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fn_items;
    zT_3 = &self->fn_len;
    zT_4 = &self->fn_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(24), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    self->fn_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_406493CE_StructPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->st_items;
    zT_3 = &self->st_len;
    zT_4 = &self->st_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->st_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    self->st_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_925BA889_pkStructAppend(zT_24, zT_25);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_struct_items;
    zT_3 = &self->pk_struct_len;
    zT_4 = &self->pk_struct_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_struct_items;
    zT_19 = self->pk_struct_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_struct_len;
    zT_21 = 1;
    self->pk_struct_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E276DDD0_PackedBitField* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_items;
    zT_3 = &self->pk_len;
    zT_4 = &self->pk_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_items;
    zT_19 = self->pk_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_len;
    zT_21 = 1;
    self->pk_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->en_items;
    zT_3 = &self->en_len;
    zT_4 = &self->en_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->en_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    self->en_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->un_items;
    zT_3 = &self->un_len;
    zT_4 = &self->un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    self->un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_96B8622A_pkUnStructAppend(zT_24, zT_25);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_un_items;
    zT_3 = &self->pk_un_len;
    zT_4 = &self->pk_un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_un_items;
    zT_19 = self->pk_un_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_un_len;
    zT_21 = 1;
    self->pk_un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tu_items;
    zT_3 = &self->tu_len;
    zT_4 = &self->tu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    self->tu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tup_items;
    zT_3 = &self->tup_len;
    zT_4 = &self->tup_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    self->tup_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->unr_items;
    zT_3 = &self->unr_len;
    zT_4 = &self->unr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    self->unr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fe_items;
    zT_3 = &self->fe_len;
    zT_4 = &self->fe_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    self->fe_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->em_items;
    zT_3 = &self->em_len;
    zT_4 = &self->em_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->em_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    self->em_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xt_items;
    zT_3 = &self->xt_len;
    zT_4 = &self->xt_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    self->xt_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xn_items;
    zT_3 = &self->xn_len;
    zT_4 = &self->xn_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    self->xn_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    int zT_3;
    int zT_6;
    int zT_12;
    int zT_18;
    int zT_21;
    int zT_24;
    int zT_30;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(8);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(16);
    z_bb_13:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_18 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_21 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(32);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(64);
    z_bb_29:
    return (unsigned char)(0);
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_8;
    int zT_11;
    int zT_14;
    int zT_17;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    unsigned char p_wb;
    unsigned char p_sg;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    zT_8 = 0;
    p_sg = zT_8;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_14 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_17 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_17 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_23 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_15;
    z_bb_14:
    zT_23 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_23) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_26 = 1;
    p_sg = zT_26;
    goto z_bb_17;
    z_bb_17:
    zT_27 = self;
    zT_29.kind = kind;
    zT_30 = 2;
    zT_29.state = zT_30;
    zT_31 = 0;
    zT_29.flags = zT_31;
    zT_29.is_signed = p_sg;
    zT_29.width_bits = p_wb;
    zT_29.size = size;
    zT_29.alignment = alignment;
    zT_32 = 0;
    zT_29.name_id = zT_32;
    zT_33 = 0;
    zT_29.c_name_id = zT_33;
    zT_34 = 0;
    zT_29.module_id = zT_34;
    zT_35 = 0;
    zT_29.payload_idx = zT_35;
    zT_28 = zT_29;
    zT_36 = zF_D4993F02_typeRegistryAppend(zT_27, zT_28);
    return zT_36;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    *len = (unsigned int)(0);
    *cap = (unsigned int)(0);
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68 = {0};
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70 = {0};
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72 = {0};
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74 = {0};
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76 = {0};
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78 = {0};
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = 0;
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zT_61 = 0;
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zT_64 = 0;
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    reg = zT_3;
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_9;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    key_lo = zT_9;
    if ((int)(key_lo == (zT_79FAE712_u64)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)np_k) + zT_17;
    zT_19 = (unsigned int)(20) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(65535))), zT_11);
    np_kl = zT_21;
    zT_25 = (unsigned int)(19) - (unsigned int)((unsigned int)np_kl);
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_35 = (unsigned char*)((unsigned char*)np_k) + np_ks;
    zT_36 = (unsigned int)(19) - np_ks;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_45 = 0;
    zT_46 = (unsigned char*)((unsigned char*)np_v) + zT_45;
    zT_47 = (unsigned int)(20) - zT_45;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    zT_53 = (unsigned int)(19) - (unsigned int)((unsigned int)np_vl);
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_63 = (unsigned char*)((unsigned char*)np_v) + np_vs;
    zT_64 = (unsigned int)(19) - np_vs;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_0C0306D6_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (int)(0));
    return zT_8;
}

/* typeRegistryGetOrCreatePtrQ */
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const, int is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_827207A1_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (int)(0));
    return zT_8;
}

/* typeRegistryGetOrCreateManyPtrQ */
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const, int is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->many_ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->many_ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    unsigned char zT_112;
    int zT_113;
    int zT_115;
    unsigned char zT_117;
    unsigned char zT_118;
    unsigned char zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_128;
    unsigned int zT_129 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    zT_4028D896_Arr_unsigned_char_2 zT_140;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    int zT_146;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150 = 0;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned char* zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_4028D896_Arr_unsigned_char_2 zT_168;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    int zT_174;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178 = 0;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    zT_4028D896_Arr_unsigned_char_2 zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    int zT_203;
    unsigned char* zT_204;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned char* zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    zT_11 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(1)) | ic;
    key = zT_11;
    zT_12 = &self->slice_cache;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_30 = 0;
    zT_31 = (unsigned char*)((unsigned char*)u2h_eb) + zT_30;
    zT_32 = (unsigned int)(20) - zT_30;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    zT_38 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_el);
    u2h_es = zT_38;
    zT_43 = (unsigned char*)((unsigned char*)u2h_eb) + u2h_es;
    zT_44 = (unsigned int)(19) - u2h_es;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)u2h_rb) + zT_58;
    zT_60 = (unsigned int)(20) - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    zT_66 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_rl);
    u2h_rs = zT_66;
    zT_71 = (unsigned char*)((unsigned char*)u2h_rb) + u2h_rs;
    zT_72 = (unsigned int)(19) - u2h_rs;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_87 = 0;
    zT_88 = (unsigned char*)((unsigned char*)u2h_cb) + zT_87;
    zT_89 = (unsigned int)(20) - zT_87;
    zT_90.ptr = zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_83);
    u2h_cl = zT_91;
    zT_95 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_cl);
    u2h_cs = zT_95;
    zT_100 = (unsigned char*)((unsigned char*)u2h_cb) + u2h_cs;
    zT_101 = (unsigned int)(19) - u2h_cs;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = (unsigned char)zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_115 = 0;
    zT_112 = (unsigned char)zT_115;
    goto z_bb_8;
    z_bb_8:
    zT_117 = (unsigned char)zT_112;
    zT_109.flags = zT_117;
    zT_118 = 0;
    zT_109.is_signed = zT_118;
    zT_119 = 0;
    zT_109.width_bits = zT_119;
    zT_120 = 8;
    zT_109.size = zT_120;
    zT_121 = 4;
    zT_109.alignment = zT_121;
    zT_122 = 0;
    zT_109.name_id = zT_122;
    zT_123 = 0;
    zT_109.c_name_id = zT_123;
    zT_124 = 0;
    zT_109.module_id = zT_124;
    zT_125 = self->slice_len;
    zT_128 = (unsigned int)(unsigned int)(zT_125 - (unsigned int)(1));
    zT_109.payload_idx = zT_128;
    zT_108 = zT_109;
    zT_129 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_129;
    zT_130 = &self->slice_cache;
    zT_131 = key;
    zT_132 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_130, zT_131, zT_132);
    zT_135 = "U2N:e";
    zT_137 = 5;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    u2n_m = zT_136;
    zT_138 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_138);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_140[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_140[_i];
        _i++;
    }
}
    zT_142 = elem;
    zT_146 = 0;
    zT_147 = (unsigned char*)((unsigned char*)u2n_eb) + zT_146;
    zT_148 = (unsigned int)(20) - zT_146;
    zT_149.ptr = zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zT_150 = zF_A7504564_itoa(zT_142, zT_143);
    u2n_el = zT_150;
    zT_154 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_el);
    u2n_es = zT_154;
    zT_159 = (unsigned char*)((unsigned char*)u2n_eb) + u2n_es;
    zT_160 = (unsigned int)(19) - u2n_es;
    zT_161.ptr = zT_159;
    zT_161.len = zT_160;
    zT_155 = zT_161;
    zF_48AC7B3A_markerWrite(zT_155);
    zT_163 = "r";
    zT_165 = 1;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    u2n_rm = zT_164;
    zT_166 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_166);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_168[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_168[_i];
        _i++;
    }
}
    zT_170 = tid;
    zT_174 = 0;
    zT_175 = (unsigned char*)((unsigned char*)u2n_rb) + zT_174;
    zT_176 = (unsigned int)(20) - zT_174;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zT_178 = zF_A7504564_itoa(zT_170, zT_171);
    u2n_rl = zT_178;
    zT_182 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_rl);
    u2n_rs = zT_182;
    zT_187 = (unsigned char*)((unsigned char*)u2n_rb) + u2n_rs;
    zT_188 = (unsigned int)(19) - u2n_rs;
    zT_189.ptr = zT_187;
    zT_189.len = zT_188;
    zT_183 = zT_189;
    zF_48AC7B3A_markerWrite(zT_183);
    zT_191 = "c";
    zT_193 = 1;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    u2n_cm = zT_192;
    zT_194 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_194);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_196[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_196[_i];
        _i++;
    }
}
    zT_203 = 0;
    zT_204 = (unsigned char*)((unsigned char*)u2n_cb) + zT_203;
    zT_205 = (unsigned int)(20) - zT_203;
    zT_206.ptr = zT_204;
    zT_206.len = zT_205;
    zT_199 = zT_206;
    zT_207 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_199);
    u2n_cl = zT_207;
    zT_211 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_cl);
    u2n_cs = zT_211;
    zT_216 = (unsigned char*)((unsigned char*)u2n_cb) + u2n_cs;
    zT_217 = (unsigned int)(19) - u2n_cs;
    zT_218.ptr = zT_216;
    zT_218.len = zT_217;
    zT_212 = zT_218;
    zF_48AC7B3A_markerWrite(zT_212);
    return tid;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39 = 0;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_0B10E8E9_OptionalPayload zT_42;
    zT_0B10E8E9_OptionalPayload zT_43;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    zT_21D3708C_U32ToU32Map* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_2 = &self->optional_cache;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    return existing;
    z_bb_2:
    zT_9 = self->types_items;
    zT_10 = zT_9[payload];
    pay_type = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    opt_size = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    opt_align = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned char)zT_18;
    opt_state = zT_19;
    zT_20 = pay_type.state;
    if ((int)(zT_20 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = pay_type.alignment;
    if ((int)(zT_24 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_41 = self;
    zT_43.payload = payload;
    zT_42 = zT_43;
    zF_4569340E_optAppend(zT_41, zT_42);
    zT_45 = self;
    zT_48 = zT_33EF6BFB_TypeKind_optional_type;
    zT_47.kind = zT_48;
    zT_47.state = opt_state;
    zT_49 = 0;
    zT_47.flags = zT_49;
    zT_50 = 0;
    zT_47.is_signed = zT_50;
    zT_51 = 0;
    zT_47.width_bits = zT_51;
    zT_47.size = opt_size;
    zT_47.alignment = opt_align;
    zT_52 = 0;
    zT_47.name_id = zT_52;
    zT_53 = 0;
    zT_47.c_name_id = zT_53;
    zT_54 = 0;
    zT_47.module_id = zT_54;
    zT_55 = self->opt_len;
    zT_58 = (unsigned int)(unsigned int)(zT_55 - (unsigned int)(1));
    zT_47.payload_idx = zT_58;
    zT_46 = zT_47;
    zT_59 = zF_D4993F02_typeRegistryAppend(zT_45, zT_46);
    tid = zT_59;
    if ((int)(opt_state == (unsigned char)(2))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_27 = pay_type.alignment;
    goto z_bb_7;
    z_bb_6:
    zT_27 = 4;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_27;
    zT_30 = pay_type.size;
    zT_34 = zF_D2BAC673_alignUp(zT_30, (unsigned int)(4));
    zT_36 = zT_34 + (unsigned int)(4);
    opt_size = zT_36;
    zT_37 = opt_size;
    zT_38 = pay_align;
    zT_39 = zF_D2BAC673_alignUp(zT_37, zT_38);
    opt_size = zT_39;
    opt_align = pay_align;
    zT_40 = 2;
    opt_state = zT_40;
    goto z_bb_4;
    z_bb_8:
    zT_62 = &self->optional_cache;
    zT_63 = payload;
    zT_64 = tid;
    zF_26476265_u32ToU32MapPut(zT_62, zT_63, zT_64);
    goto z_bb_9;
    z_bb_9:
    return tid;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_D155D06D_Type* zT_16;
    zT_D155D06D_Type zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned int zT_31;
    unsigned int zT_34;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_51 = 0;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56 = 0;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_42C2D6BF_EUPayload zT_59;
    zT_42C2D6BF_EUPayload zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type zT_63;
    zT_D155D06D_Type zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned int zT_76 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_79;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_8 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)payload) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)error_set);
    eu_key = zT_8;
    zT_9 = &self->eu_cache;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self->types_items;
    zT_17 = zT_16[payload];
    pay_type = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    eu_size = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    eu_align = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned char)zT_25;
    eu_state = zT_26;
    zT_27 = pay_type.state;
    if ((int)(zT_27 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = pay_type.size;
    if ((int)(zT_31 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_58 = self;
    zT_60.payload = payload;
    zT_60.error_set = error_set;
    zT_59 = zT_60;
    zF_ABBA52E7_euAppend(zT_58, zT_59);
    zT_62 = self;
    zT_65 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_64.kind = zT_65;
    zT_64.state = eu_state;
    zT_66 = 0;
    zT_64.flags = zT_66;
    zT_67 = 0;
    zT_64.is_signed = zT_67;
    zT_68 = 0;
    zT_64.width_bits = zT_68;
    zT_64.size = eu_size;
    zT_64.alignment = eu_align;
    zT_69 = 0;
    zT_64.name_id = zT_69;
    zT_70 = 0;
    zT_64.c_name_id = zT_70;
    zT_71 = 0;
    zT_64.module_id = zT_71;
    zT_72 = self->eu_len;
    zT_75 = (unsigned int)(unsigned int)(zT_72 - (unsigned int)(1));
    zT_64.payload_idx = zT_75;
    zT_63 = zT_64;
    zT_76 = zF_D4993F02_typeRegistryAppend(zT_62, zT_63);
    tid = zT_76;
    zT_77 = &self->eu_cache;
    zT_78 = eu_key;
    zT_79 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_77, zT_78, zT_79);
    return tid;
    z_bb_5:
    zT_34 = pay_type.size;
    goto z_bb_7;
    z_bb_6:
    zT_34 = 4;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_34;
    zT_38 = pay_type.alignment;
    if ((int)(zT_38 > (unsigned int)(4))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_41 = pay_type.alignment;
    goto z_bb_10;
    z_bb_9:
    zT_41 = 4;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_41;
    zT_45 = union_size;
    zT_46 = union_align;
    zT_47 = zF_D2BAC673_alignUp(zT_45, zT_46);
    total = zT_47;
    zT_48 = total;
    zT_51 = zF_D2BAC673_alignUp(zT_48, (unsigned int)(4));
    zT_53 = zT_51 + (unsigned int)(4);
    total = zT_53;
    zT_54 = total;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    eu_size = zT_56;
    eu_align = union_align;
    zT_57 = 2;
    eu_state = zT_57;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_E834303C_ArrayPayload zT_100;
    zT_E834303C_ArrayPayload zT_101;
    zT_D155D06D_Type* zT_103;
    zT_D155D06D_Type zT_104;
    int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_136 = 0;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_4028D896_Arr_unsigned_char_2 zT_143;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    int zT_149;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153 = 0;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned char zT_165;
    zT_A4CE86B7_U64ToU32Map* zT_168;
    zT_79FAE712_u64 zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)o0b) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    zT_23 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l);
    o0s = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)o0b) + o0s;
    zT_29 = (unsigned int)(19) - o0s;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)o0b2) + zT_43;
    zT_45 = (unsigned int)(20) - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    zT_51 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l2);
    o0s2 = zT_51;
    zT_56 = (unsigned char*)((unsigned char*)o0b2) + o0s2;
    zT_57 = (unsigned int)(19) - o0s2;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_64 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)length);
    key = zT_64;
    zT_65 = &self->array_cache;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_83 = 0;
    zT_84 = (unsigned char*)((unsigned char*)o1b) + zT_83;
    zT_85 = (unsigned int)(20) - zT_83;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    zT_91 = (unsigned int)(19) - (unsigned int)((unsigned int)o1l);
    o1s = zT_91;
    zT_96 = (unsigned char*)((unsigned char*)o1b) + o1s;
    zT_97 = (unsigned int)(19) - o1s;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    return existing;
    z_bb_2:
    zT_99 = self;
    zT_101.elem = elem;
    zT_101.length = length;
    zT_100 = zT_101;
    zF_4D5CD212_arrayAppend(zT_99, zT_100);
    zT_103 = self->types_items;
    zT_104 = zT_103[elem];
    elem_ty = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    arr_size = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    arr_align = zT_110;
    zT_112 = 0;
    zT_113 = (unsigned char)zT_112;
    arr_state = zT_113;
    zT_114 = elem_ty.state;
    if ((int)(zT_114 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_117 = elem_ty.size;
    zT_118 = zT_117 * length;
    arr_size = zT_118;
    zT_119 = elem_ty.alignment;
    arr_align = zT_119;
    zT_120 = 2;
    arr_state = zT_120;
    goto z_bb_4;
    z_bb_4:
    zT_122 = self;
    zT_125 = zT_33EF6BFB_TypeKind_array_type;
    zT_124.kind = zT_125;
    zT_124.state = arr_state;
    zT_126 = 0;
    zT_124.flags = zT_126;
    zT_127 = 0;
    zT_124.is_signed = zT_127;
    zT_128 = 0;
    zT_124.width_bits = zT_128;
    zT_124.size = arr_size;
    zT_124.alignment = arr_align;
    zT_129 = 0;
    zT_124.name_id = zT_129;
    zT_130 = 0;
    zT_124.c_name_id = zT_130;
    zT_131 = 0;
    zT_124.module_id = zT_131;
    zT_132 = self->array_len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 - (unsigned int)(1));
    zT_124.payload_idx = zT_135;
    zT_123 = zT_124;
    zT_136 = zF_D4993F02_typeRegistryAppend(zT_122, zT_123);
    tid = zT_136;
    zT_138 = "O2N";
    zT_140 = 3;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    o2m = zT_139;
    zT_141 = o2m;
    zF_48AC7B3A_markerWrite(zT_141);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_143[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_143[_i];
        _i++;
    }
}
    zT_145 = tid;
    zT_149 = 0;
    zT_150 = (unsigned char*)((unsigned char*)o2b) + zT_149;
    zT_151 = (unsigned int)(20) - zT_149;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zT_153 = zF_A7504564_itoa(zT_145, zT_146);
    o2l = zT_153;
    zT_157 = (unsigned int)(19) - (unsigned int)((unsigned int)o2l);
    o2s = zT_157;
    zT_162 = (unsigned char*)((unsigned char*)o2b) + o2s;
    zT_163 = (unsigned int)(19) - o2s;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_158 = zT_164;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_165 = elem_ty.state;
    if ((int)(zT_165 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_168 = &self->array_cache;
    zT_169 = key;
    zT_170 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_168, zT_169, zT_170);
    goto z_bb_6;
    z_bb_6:
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.is_signed = zT_13;
    zT_14 = 0;
    zT_9.width_bits = zT_14;
    zT_15 = 0;
    zT_9.size = zT_15;
    zT_16 = 1;
    zT_9.alignment = zT_16;
    zT_17 = 0;
    zT_9.name_id = zT_17;
    zT_18 = 0;
    zT_9.c_name_id = zT_18;
    zT_19 = 0;
    zT_9.module_id = zT_19;
    zT_20 = self->tup_len;
    zT_23 = (unsigned int)(unsigned int)(zT_20 - (unsigned int)(1));
    zT_9.payload_idx = zT_23;
    zT_8 = zT_9;
    zT_24 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_24;
    return tid;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type, unsigned char call_conv) {
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned char zT_38;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_53;
    unsigned int zT_54;
    int zT_56;
    zT_0317B1D5_FnPayload* zT_57;
    zT_D155D06D_Type* zT_58;
    zT_D155D06D_Type zT_59;
    unsigned int zT_60;
    zT_0317B1D5_FnPayload zT_61;
    unsigned int zT_62;
    int zT_64;
    zT_0317B1D5_FnPayload* zT_65;
    zT_D155D06D_Type* zT_66;
    zT_D155D06D_Type zT_67;
    unsigned int zT_68;
    zT_0317B1D5_FnPayload zT_69;
    unsigned char zT_70;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    zT_D155D06D_Type* zT_86;
    zT_D155D06D_Type* zT_87;
    int zT_89;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_0317B1D5_FnPayload zT_92;
    zT_0317B1D5_FnPayload zT_93;
    unsigned char zT_94;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_D155D06D_Type zT_97;
    zT_D155D06D_Type zT_98;
    zT_33EF6BFB_TypeKind zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_111;
    unsigned int zT_112 = 0;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    zT_D155D06D_Type zT_117;
    unsigned char zT_118;
    zT_D155D06D_Type* zT_121;
    zT_D155D06D_Type* zT_123;
    zT_4028D896_Arr_unsigned_char_2 zT_125;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    int zT_131;
    unsigned char* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned char conv_bit;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_10 = "P2:n";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    p2m = zT_11;
    zT_13 = p2m;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = name_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)p2nb) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    p2nl = zT_25;
    zT_29 = (unsigned int)(19) - (unsigned int)((unsigned int)p2nl);
    p2ns = zT_29;
    zT_34 = (unsigned char*)((unsigned char*)p2nb) + p2ns;
    zT_35 = (unsigned int)(19) - p2ns;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_30 = zT_36;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_38 = 0;
    conv_bit = zT_38;
    if ((int)(call_conv == (unsigned char)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_41 = 2;
    conv_bit = zT_41;
    goto z_bb_2;
    z_bb_2:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    i = zT_44;
    goto z_bb_3;
    z_bb_3:
    zT_45 = self->types_len;
    if ((int)(i < zT_45)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_48 = self->types_items;
    zT_49 = zT_48[i];
    it = zT_49;
    zT_50 = it.kind;
    if ((int)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_91 = self;
    zT_93.name_id = name_id;
    zT_93.module_id = module_id;
    zT_93.is_extern = is_extern;
    zT_93.params_start = params_start;
    zT_93.params_count = params_count;
    zT_93.return_type = return_type;
    zT_94 = is_variadic | conv_bit;
    zT_93.flags_packed = zT_94;
    zT_92 = zT_93;
    zF_07DDC351_fnAppend(zT_91, zT_92);
    zT_96 = self;
    zT_99 = zT_33EF6BFB_TypeKind_fn_type;
    zT_98.kind = zT_99;
    zT_100 = 2;
    zT_98.state = zT_100;
    zT_101 = 0;
    zT_98.flags = zT_101;
    zT_102 = 0;
    zT_98.is_signed = zT_102;
    zT_103 = 0;
    zT_98.width_bits = zT_103;
    zT_104 = 4;
    zT_98.size = zT_104;
    zT_105 = 4;
    zT_98.alignment = zT_105;
    zT_98.name_id = name_id;
    zT_106 = 0;
    zT_98.c_name_id = zT_106;
    zT_107 = 0;
    zT_98.module_id = zT_107;
    zT_108 = self->fn_len;
    zT_111 = (unsigned int)(unsigned int)(zT_108 - (unsigned int)(1));
    zT_98.payload_idx = zT_111;
    zT_97 = zT_98;
    zT_112 = zF_D4993F02_typeRegistryAppend(zT_96, zT_97);
    tid = zT_112;
    if ((int)(conv_bit != (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_6:
    zT_89 = 1;
    zT_90 = i + zT_89;
    i = zT_90;
    goto z_bb_3;
    z_bb_7:
    zT_54 = it.name_id;
    zT_53 = zT_54 == name_id;
    goto z_bb_9;
    z_bb_8:
    zT_53 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->fn_items;
    zT_58 = self->types_items;
    zT_59 = zT_58[i];
    zT_60 = zT_59.payload_idx;
    zT_61 = zT_57[zT_60];
    zT_62 = zT_61.module_id;
    zT_56 = zT_62 == module_id;
    goto z_bb_12;
    z_bb_11:
    zT_56 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_56) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_65 = self->fn_items;
    zT_66 = self->types_items;
    zT_67 = zT_66[i];
    zT_68 = zT_67.payload_idx;
    zT_69 = zT_65[zT_68];
    zT_70 = zT_69.flags_packed;
    zT_64 = (unsigned char)(zT_70 & (unsigned int)(2)) == conv_bit;
    goto z_bb_15;
    z_bb_14:
    zT_64 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_64) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_75 = "H";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    p2hm = zT_76;
    zT_78 = p2hm;
    zF_48AC7B3A_markerWrite(zT_78);
    if ((int)(conv_bit != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_81 = self->types_items;
    zT_82 = zT_81[i];
    zT_83 = zT_82.flags;
    zT_86 = self->types_items;
    zT_87 = zT_86 + i;
    zT_87->flags = (unsigned char)(zT_83 | (unsigned char)(1));
    goto z_bb_19;
    z_bb_19:
    return (unsigned int)((unsigned int)i);
    z_bb_20:
    zT_115 = self->types_items;
    zT_116 = (unsigned int)tid;
    zT_117 = zT_115[zT_116];
    zT_118 = zT_117.flags;
    zT_121 = self->types_items;
    zT_123 = zT_121 + (unsigned int)((unsigned int)tid);
    zT_123->flags = (unsigned char)(zT_118 | (unsigned char)(1));
    goto z_bb_21;
    z_bb_21:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_125[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_125[_i];
        _i++;
    }
}
    zT_127 = tid;
    zT_131 = 0;
    zT_132 = (unsigned char*)((unsigned char*)p2sb) + zT_131;
    zT_133 = (unsigned int)(20) - zT_131;
    zT_134.ptr = zT_132;
    zT_134.len = zT_133;
    zT_128 = zT_134;
    zT_135 = zF_A7504564_itoa(zT_127, zT_128);
    p2sl = zT_135;
    zT_139 = (unsigned int)(19) - (unsigned int)((unsigned int)p2sl);
    p2ss = zT_139;
    zT_144 = (unsigned char*)((unsigned char*)p2sb) + p2ss;
    zT_145 = (unsigned int)(19) - p2ss;
    zT_146.ptr = zT_144;
    zT_146.len = zT_145;
    zT_140 = zT_146;
    zF_48AC7B3A_markerWrite(zT_140);
    zT_148 = "\n";
    zT_150 = 1;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    p2nl2 = zT_149;
    zT_151 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_151);
    return tid;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_8 = self->types_items;
    zT_10 = zT_8 + (unsigned int)((unsigned int)tid);
    zT_10->flags = (unsigned char)(zT_5 | (unsigned char)(1));
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    unsigned int* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_79FAE712_u64 zT_22;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_0B73C507_ErrorSetPayload zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((int)(ki < tags_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_13 = (unsigned int)(unsigned int)(tags_start + (unsigned int)((unsigned int)ki));
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    zT_18 = (zT_79FAE712_u64)(key ^ (zT_79FAE712_u64)((zT_79FAE712_u64)tag)) * (zT_79FAE712_u64)(1099511628211ULL);
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_21 = &self->es_cache;
    zT_22 = key;
    zT_24 = zF_A05A7BE1_u64ToU32MapGet(zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_20 = ki + zT_19;
    ki = zT_20;
    goto z_bb_1;
    z_bb_5:
    existing = zT_24.value;
    return existing;
    z_bb_6:
    zT_27 = self;
    zT_29.tags_start = tags_start;
    zT_29.tags_count = tags_count;
    zT_28 = zT_29;
    zF_B86143DD_esAppend(zT_27, zT_28);
    zT_31 = self;
    zT_34 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_33.kind = zT_34;
    zT_35 = 2;
    zT_33.state = zT_35;
    zT_36 = 0;
    zT_33.flags = zT_36;
    zT_37 = 0;
    zT_33.is_signed = zT_37;
    zT_38 = 0;
    zT_33.width_bits = zT_38;
    zT_39 = 4;
    zT_33.size = zT_39;
    zT_40 = 4;
    zT_33.alignment = zT_40;
    zT_41 = 0;
    zT_33.name_id = zT_41;
    zT_42 = 0;
    zT_33.c_name_id = zT_42;
    zT_43 = 0;
    zT_33.module_id = zT_43;
    zT_44 = self->es_len;
    zT_47 = (unsigned int)(unsigned int)(zT_44 - (unsigned int)(1));
    zT_33.payload_idx = zT_47;
    zT_32 = zT_33;
    zT_48 = zF_D4993F02_typeRegistryAppend(zT_31, zT_32);
    tid = zT_48;
    zT_49 = &self->es_cache;
    zT_50 = key;
    zT_51 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_49, zT_50, zT_51);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_36;
    unsigned int zT_37;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    if ((int)(es_type_id >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    zT_32 = reg->xn_len;
    if ((int)((unsigned int)(tags_start + tags_count) > zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(4294967295u);
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((int)(i < tags_count)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    if ((int)(zT_41 == name_id)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned int)(4294967295u);
    z_bb_12:
    zT_44 = 1;
    zT_45 = i + zT_44;
    i = zT_45;
    goto z_bb_9;
    z_bb_13:
    return (unsigned int)((unsigned int)i);
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_13;
    unsigned int zT_14;
    int zT_17;
    unsigned int zT_18;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type zT_38;
    unsigned int zT_39 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    if ((int)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    zT_10 = it.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = zT_33EF6BFB_TypeKind_module_type;
    zT_20.kind = zT_21;
    zT_22 = 0;
    zT_20.state = zT_22;
    zT_23 = 0;
    zT_20.flags = zT_23;
    zT_24 = 0;
    zT_20.is_signed = zT_24;
    zT_25 = 0;
    zT_20.width_bits = zT_25;
    zT_26 = 0;
    zT_20.size = zT_26;
    zT_27 = 0;
    zT_20.alignment = zT_27;
    zT_28 = 0;
    zT_20.name_id = zT_28;
    zT_29 = 0;
    zT_20.c_name_id = zT_29;
    zT_20.module_id = module_id;
    zT_30 = 0;
    zT_20.payload_idx = zT_30;
    t = zT_20;
    zT_32 = "MC";
    zT_34 = 2;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    mc = zT_33;
    zT_35 = mc;
    zF_48AC7B3A_markerWrite(zT_35);
    zT_37 = self;
    zT_38 = t;
    zT_39 = zF_D4993F02_typeRegistryAppend(zT_37, zT_38);
    mcid = zT_39;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_13 = zT_14 == module_id;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)((unsigned int)i);
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    (void)zF_4F84B621_registerPrimitive(zT_1, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel), (unsigned int)(0), (unsigned int)(0));
    zT_9 = self;
    (void)zF_4F84B621_registerPrimitive(zT_9, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type), (unsigned int)(0), (unsigned int)(0));
    zT_17 = self;
    (void)zF_4F84B621_registerPrimitive(zT_17, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type), (unsigned int)(4), (unsigned int)(4));
    zT_25 = self;
    (void)zF_4F84B621_registerPrimitive(zT_25, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type), (unsigned int)(0), (unsigned int)(0));
    zT_33 = self;
    (void)zF_4F84B621_registerPrimitive(zT_33, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type), (unsigned int)(1), (unsigned int)(1));
    zT_41 = self;
    (void)zF_4F84B621_registerPrimitive(zT_41, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type), (unsigned int)(2), (unsigned int)(2));
    zT_49 = self;
    (void)zF_4F84B621_registerPrimitive(zT_49, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type), (unsigned int)(4), (unsigned int)(4));
    zT_57 = self;
    (void)zF_4F84B621_registerPrimitive(zT_57, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type), (unsigned int)(8), (unsigned int)(8));
    zT_65 = self;
    (void)zF_4F84B621_registerPrimitive(zT_65, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type), (unsigned int)(1), (unsigned int)(1));
    zT_73 = self;
    (void)zF_4F84B621_registerPrimitive(zT_73, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type), (unsigned int)(2), (unsigned int)(2));
    zT_81 = self;
    (void)zF_4F84B621_registerPrimitive(zT_81, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type), (unsigned int)(4), (unsigned int)(4));
    zT_89 = self;
    (void)zF_4F84B621_registerPrimitive(zT_89, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type), (unsigned int)(8), (unsigned int)(8));
    zT_97 = self;
    (void)zF_4F84B621_registerPrimitive(zT_97, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type), (unsigned int)(4), (unsigned int)(4));
    zT_105 = self;
    (void)zF_4F84B621_registerPrimitive(zT_105, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type), (unsigned int)(4), (unsigned int)(4));
    zT_113 = self;
    (void)zF_4F84B621_registerPrimitive(zT_113, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type), (unsigned int)(1), (unsigned int)(1));
    zT_121 = self;
    (void)zF_4F84B621_registerPrimitive(zT_121, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type), (unsigned int)(4), (unsigned int)(4));
    zT_129 = self;
    (void)zF_4F84B621_registerPrimitive(zT_129, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type), (unsigned int)(8), (unsigned int)(8));
    zT_137 = self;
    (void)zF_4F84B621_registerPrimitive(zT_137, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type), (unsigned int)(0), (unsigned int)(0));
    zT_145 = self;
    (void)zF_4F84B621_registerPrimitive(zT_145, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type), (unsigned int)(0), (unsigned int)(0));
    zT_153 = self;
    (void)zF_4F84B621_registerPrimitive(zT_153, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type), (unsigned int)(0), (unsigned int)(0));
    zT_161 = self;
    (void)zF_4F84B621_registerPrimitive(zT_161, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type), (unsigned int)(0), (unsigned int)(0));
    zT_169 = self;
    (void)zF_4F84B621_registerPrimitive(zT_169, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type), (unsigned int)(4), (unsigned int)(4));
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    zT_181 = self;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, (unsigned int)(1), zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    zT_189 = self;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, (unsigned int)(2), zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, (unsigned int)(4), zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, (unsigned int)(5), zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, (unsigned int)(6), zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, (unsigned int)(7), zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, (unsigned int)(8), zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, (unsigned int)(9), zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, (unsigned int)(10), zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, (unsigned int)(11), zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    zT_261 = self;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, (unsigned int)(12), zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    zT_269 = self;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, (unsigned int)(13), zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, (unsigned int)(14), zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, (unsigned int)(15), zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, (unsigned int)(16), zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    zT_301 = self;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, (unsigned int)(17), zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, (unsigned int)(18), zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    zT_317 = self;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, (unsigned int)(20), zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, (unsigned int)(21), zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_16;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_4 = self->interner;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, (zT_79FAE712_u64)((zT_79FAE712_u64)nid), zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, int* is_unsigned) {
    unsigned int zT_4;
    unsigned char* zT_9;
    int zT_10;
    unsigned char zT_11;
    int zT_14;
    int zT_17;
    int zT_19;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_30;
    unsigned char zT_31;
    int zT_34;
    unsigned int zT_41;
    unsigned int zT_44;
    int zT_48;
    unsigned int zT_49;
    int zT_52;
    int zT_58;
    unsigned int nlen;
    unsigned char prefix;
    int is_u;
    int is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    if ((int)(nlen < (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = zT_9[zT_10];
    prefix = zT_11;
    zT_14 = prefix == (unsigned char)(117);
    is_u = zT_14;
    zT_17 = prefix == (unsigned char)(105);
    is_i = zT_17;
    if ((int)(!is_u)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = !is_i;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    *is_unsigned = (int)(1);
    goto z_bb_9;
    z_bb_9:
    zT_25 = 0;
    w = zT_25;
    zT_27 = 1;
    i = zT_27;
    goto z_bb_11;
    z_bb_10:
    *is_unsigned = (int)(0);
    goto z_bb_9;
    z_bb_11:
    if ((int)(i < nlen)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = name.ptr;
    zT_31 = zT_30[i];
    c = zT_31;
    if ((int)(c < (unsigned char)(48))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_48 = 1;
    zT_49 = i + zT_48;
    i = zT_49;
    goto z_bb_11;
    z_bb_15:
    zT_34 = c > (unsigned char)(57);
    goto z_bb_17;
    z_bb_16:
    zT_34 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_34) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned int)(0);
    z_bb_19:
    zT_41 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_41;
    zT_44 = (unsigned int)(w * (unsigned int)(10)) + d;
    w = zT_44;
    if ((int)(w > (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    if ((int)(w < (unsigned int)(1))) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    if ((int)(w < (unsigned int)(1))) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_52 = w > (unsigned int)(64);
    goto z_bb_27;
    z_bb_26:
    zT_52 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_52) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_58 = w > (unsigned int)(63);
    goto z_bb_32;
    z_bb_31:
    zT_58 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_58) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned int)(0);
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int* zT_6;
    unsigned int zT_8 = 0;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53 = 0;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    zT_5 = name;
    zT_6 = &arb_u;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    if ((int)(arb_w == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_13 = self->interner;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    zT_18 = self;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, (zT_79FAE712_u64)((zT_79FAE712_u64)nid));
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = zT_33EF6BFB_TypeKind_arb_uint_type;
    goto z_bb_7;
    z_bb_6:
    zT_25 = zT_33EF6BFB_TypeKind_arb_int_type;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    if ((int)(arb_w > (unsigned int)(8))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    if ((int)(arb_w > (unsigned int)(16))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    if ((int)(arb_w > (unsigned int)(32))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    if (arb_u) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = 0;
    goto z_bb_16;
    z_bb_15:
    zT_45 = 1;
    goto z_bb_16;
    z_bb_16:
    zT_42.is_signed = zT_45;
    zT_48 = (unsigned char)arb_w;
    zT_42.width_bits = zT_48;
    zT_42.size = carrier;
    zT_42.alignment = carrier;
    zT_49 = 0;
    zT_42.name_id = zT_49;
    zT_50 = 0;
    zT_42.c_name_id = zT_50;
    zT_51 = 0;
    zT_42.module_id = zT_51;
    zT_52 = 0;
    zT_42.payload_idx = zT_52;
    zT_41 = zT_42;
    zT_53 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_53;
    zT_54 = self;
    zT_55 = tid;
    zT_56 = name;
    zF_BA76727A_registerPrimitiveNa(zT_54, zT_55, zT_56);
    return tid;
}

/* typeRegistryEnumBackingType */
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(10);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(10);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(10);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.backing_type;
    return zT_24;
}

/* typeRegistryEnumHasExplicitBacking */
int zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned char zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.explicit_backing;
    return (int)(zT_24 != (unsigned char)(0));
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_29 = 0;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_23 = ty.kind;
    zT_22 = zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = ty.width_bits;
    return zT_26;
    z_bb_9:
    zT_27 = ty.kind;
    zT_29 = zF_534230F8_typeWidthBitsForKin(zT_27);
    return zT_29;
}

/* typeRegistryIntIsSigned */
int zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    int zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    int zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_23 = ty.kind;
    if ((int)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_27 = ty.kind;
    if ((int)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = ty.kind;
    zT_30 = zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_30 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_30) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_35 = ty.kind;
    zT_34 = zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_39 = ty.kind;
    zT_38 = zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_20;
    z_bb_19:
    zT_42 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_42) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(0);
    z_bb_22:
    zT_47 = ty.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_25;
    z_bb_24:
    zT_50 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_50) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = ty.kind;
    zT_54 = zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_28;
    z_bb_27:
    zT_54 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_54) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_31;
    z_bb_30:
    zT_58 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_58) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_63 = ty.kind;
    zT_62 = zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_34;
    z_bb_33:
    zT_62 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_62) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_67 = ty.kind;
    zT_66 = zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_37;
    z_bb_36:
    zT_66 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_66) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (int)(1);
    z_bb_39:
    return (int)(0);
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27 = 0;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    zT_4028D896_Arr_unsigned_char_2 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    unsigned int zT_46;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_4028D896_Arr_unsigned_char_2 zT_60;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_4028D896_Arr_unsigned_char_2 zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99 = 0;
    unsigned int zT_103;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_4028D896_Arr_unsigned_char_2 zT_117;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    int zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned int zT_131;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_9 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18.is_signed = zT_21;
    zT_22 = 0;
    zT_18.width_bits = zT_22;
    zT_23 = 0;
    zT_18.size = zT_23;
    zT_24 = 0;
    zT_18.alignment = zT_24;
    zT_18.name_id = name_id;
    zT_25 = 0;
    zT_18.c_name_id = zT_25;
    zT_18.module_id = module_id;
    zT_26 = 0;
    zT_18.payload_idx = zT_26;
    zT_17 = zT_18;
    zT_27 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_27;
    zT_28 = self;
    zT_29 = key;
    zT_30 = tid;
    zF_5E95558D_nameCachePut(zT_28, zT_29, zT_30);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = module_id;
    zT_38 = 0;
    zT_39 = (unsigned char*)((unsigned char*)rn_m) + zT_38;
    zT_40 = (unsigned int)(20) - zT_38;
    zT_41.ptr = zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zT_42 = zF_A7504564_itoa(zT_34, zT_35);
    rn_ml = zT_42;
    zT_46 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_ml);
    rn_ms = zT_46;
    zT_48 = "RN:m";
    zT_50 = 4;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    rnm = zT_49;
    zT_51 = rnm;
    zF_48AC7B3A_markerWrite(zT_51);
    zT_56 = (unsigned char*)((unsigned char*)rn_m) + rn_ms;
    zT_57 = (unsigned int)(19) - rn_ms;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_60[_i];
        _i++;
    }
}
    zT_62 = name_id;
    zT_66 = 0;
    zT_67 = (unsigned char*)((unsigned char*)rn_n) + zT_66;
    zT_68 = (unsigned int)(20) - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zT_70 = zF_A7504564_itoa(zT_62, zT_63);
    rn_nl = zT_70;
    zT_74 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_nl);
    rn_ns = zT_74;
    zT_76 = "n";
    zT_78 = 1;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    rnn = zT_77;
    zT_79 = rnn;
    zF_48AC7B3A_markerWrite(zT_79);
    zT_84 = (unsigned char*)((unsigned char*)rn_n) + rn_ns;
    zT_85 = (unsigned int)(19) - rn_ns;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zF_48AC7B3A_markerWrite(zT_80);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_88[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_88[_i];
        _i++;
    }
}
    zT_95 = 0;
    zT_96 = (unsigned char*)((unsigned char*)rn_k) + zT_95;
    zT_97 = (unsigned int)(20) - zT_95;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_91 = zT_98;
    zT_99 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_91);
    rn_kl = zT_99;
    zT_103 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_kl);
    rn_ks = zT_103;
    zT_105 = "k";
    zT_107 = 1;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rnk = zT_106;
    zT_108 = rnk;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_113 = (unsigned char*)((unsigned char*)rn_k) + rn_ks;
    zT_114 = (unsigned int)(19) - rn_ks;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_109 = zT_115;
    zF_48AC7B3A_markerWrite(zT_109);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_117[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_117[_i];
        _i++;
    }
}
    zT_119 = tid;
    zT_123 = 0;
    zT_124 = (unsigned char*)((unsigned char*)rn_t) + zT_123;
    zT_125 = (unsigned int)(20) - zT_123;
    zT_126.ptr = zT_124;
    zT_126.len = zT_125;
    zT_120 = zT_126;
    zT_127 = zF_A7504564_itoa(zT_119, zT_120);
    rn_tl = zT_127;
    zT_131 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_tl);
    rn_ts = zT_131;
    zT_133 = "t";
    zT_135 = 1;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    rnt = zT_134;
    zT_136 = rnt;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_141 = (unsigned char*)((unsigned char*)rn_t) + rn_ts;
    zT_142 = (unsigned int)(19) - rn_ts;
    zT_143.ptr = zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zF_48AC7B3A_markerWrite(zT_137);
    zT_145 = "\n";
    zT_147 = 1;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    rnnl = zT_146;
    zT_148 = rnnl;
    zF_48AC7B3A_markerWrite(zT_148);
    return tid;
}

/* isValueDependency */
int zF_2FA4221F_isValueDependency(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
int zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    return (int)(0);
}

/* typeRegistryIsInteger */
int zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    return (int)(0);
}

/* typeRegistryIsUnsigned */
int zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    return (int)(0);
}

/* typeRegistryIsPointer */
int zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_8;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
int zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type));
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((int)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_8 = zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeRegistryArrayByteSize */
zT_BAEE192E_Opt_10 zF_C35DA834_typeRegistryArrayBy(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((int)(zT_6 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9.has_value = 0;
    return zT_9;
    z_bb_2:
    zT_10 = ty.state;
    if ((int)(zT_10 != (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.size;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((int)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((int)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    if ((int)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    if ((int)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    if ((int)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
int zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type));
}

/* typeRegistryIsErrorSet */
int zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsPacked */
int zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    return (int)((unsigned char)(zT_14 & (unsigned char)(16)) != (unsigned char)(0));
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_10;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    int zT_64;
    unsigned char zT_65;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    unsigned int zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_E276DDD0_PackedBitField zT_80;
    zT_E276DDD0_PackedBitField zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    zT_FA398D58_PackedStructInfo zT_88;
    zT_FA398D58_PackedStructInfo zT_90;
    unsigned short zT_91;
    unsigned int zT_96;
    unsigned int zT_99;
    zT_D155D06D_Type* zT_101;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((int)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    if ((int)((unsigned char)(zT_10 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    if ((int)(fi < fcount)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = fstart + fi;
    zT_46 = zT_44[zT_45];
    fe = zT_46;
    zT_48 = 1;
    w = zT_48;
    zT_49 = fe.type_id;
    zT_50 = self->types_len;
    if ((int)(zT_49 < (unsigned int)((unsigned int)zT_50))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_86 = self;
    zT_87 = ty.payload_idx;
    zT_90.pk_start = pk_start;
    zT_91 = (unsigned short)fcount;
    zT_90.pk_count = zT_91;
    zT_90.total_bits = total_bits;
    zT_88 = zT_90;
    zF_41767D71_pkSetFields(zT_86, zT_87, zT_88);
    zT_96 = (unsigned int)(total_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_96;
    if ((int)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_84 = 1;
    zT_85 = fi + zT_84;
    fi = zT_85;
    goto z_bb_9;
    z_bb_13:
    zT_54 = self->types_items;
    zT_55 = fe.type_id;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    ft = zT_57;
    zT_58 = ft.kind;
    if ((int)(zT_58 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_81.bit_offset = total_bits;
    zT_82 = (unsigned short)w;
    zT_81.bit_width = zT_82;
    zT_80 = zT_81;
    zF_E48D8B88_pkFieldAppend(zT_79, zT_80);
    zT_83 = total_bits + w;
    total_bits = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_61 = ft.kind;
    if ((int)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_65 = ft.flags;
    zT_64 = (unsigned char)(zT_65 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_19;
    z_bb_18:
    zT_64 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_70 = self;
    zT_71 = fe.type_id;
    zT_73 = zF_CB27DBA4_typeRegistryGetPack(zT_70, zT_71);
    w = zT_73;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_74 = self;
    zT_75 = fe.type_id;
    zT_77 = zF_655972D5_typeRegistryIntWidt(zT_74, zT_75);
    zT_78 = (unsigned int)zT_77;
    w = zT_78;
    goto z_bb_21;
    z_bb_23:
    zT_99 = 1;
    sz = zT_99;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_101 = self->types_items;
    zT_101[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
int zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_E276DDD0_PackedBitField* zT_46;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_50;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_15 = ty.flags;
    if ((int)((unsigned char)(zT_15 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    if ((int)(zT_21 >= (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_28 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_26) >= zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    zT_43 = self->pk_len;
    if ((int)((unsigned int)(pstart + pcount) > zT_43)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_46 = self->pk_items;
    zT_48 = zT_46 + pstart;
    zT_49 = (unsigned int)(pstart + pcount) - pstart;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    *out = zT_50;
    return (int)(1);
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    if ((int)((unsigned char)(zT_14 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    if ((int)(zT_20 >= (unsigned int)((unsigned int)zT_21))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_27 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_25) >= zT_27)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(0);
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.flags;
    ty.flags = (unsigned char)(zT_6 | (unsigned char)(16));
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    zT_2DF01B61_FieldEntry zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D155D06D_Type zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    zT_33EF6BFB_TypeKind zT_56;
    int zT_59;
    unsigned char zT_60;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_E276DDD0_PackedBitField zT_75;
    zT_E276DDD0_PackedBitField zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    int zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    zT_FA398D58_PackedStructInfo zT_84;
    zT_FA398D58_PackedStructInfo zT_86;
    unsigned short zT_87;
    unsigned int zT_92;
    unsigned int zT_95;
    zT_D155D06D_Type* zT_97;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((int)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    if ((int)(zT_10 >= (unsigned int)((unsigned int)zT_11))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    if ((int)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = fstart + fi;
    zT_41 = zT_39[zT_40];
    fe = zT_41;
    zT_43 = 1;
    w = zT_43;
    zT_44 = fe.type_id;
    zT_45 = self->types_len;
    if ((int)(zT_44 < (unsigned int)((unsigned int)zT_45))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_82 = self;
    zT_83 = ty.payload_idx;
    zT_86.pk_start = pk_start;
    zT_87 = (unsigned short)fcount;
    zT_86.pk_count = zT_87;
    zT_86.total_bits = max_bits;
    zT_84 = zT_86;
    zF_0213D00C_pkUnSetFields(zT_82, zT_83, zT_84);
    zT_92 = (unsigned int)(max_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_92;
    if ((int)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_80 = 1;
    zT_81 = fi + zT_80;
    fi = zT_81;
    goto z_bb_7;
    z_bb_11:
    zT_49 = self->types_items;
    zT_50 = fe.type_id;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    ft = zT_52;
    zT_53 = ft.kind;
    if ((int)(zT_53 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_74 = self;
    zT_77 = 0;
    zT_76.bit_offset = zT_77;
    zT_78 = (unsigned short)w;
    zT_76.bit_width = zT_78;
    zT_75 = zT_76;
    zF_E48D8B88_pkFieldAppend(zT_74, zT_75);
    if ((int)(w > max_bits)) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_56 = ft.kind;
    if ((int)(zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_60 = ft.flags;
    zT_59 = (unsigned char)(zT_60 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_17;
    z_bb_16:
    zT_59 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_59) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_65 = self;
    zT_66 = fe.type_id;
    zT_68 = zF_CB27DBA4_typeRegistryGetPack(zT_65, zT_66);
    w = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_69 = self;
    zT_70 = fe.type_id;
    zT_72 = zF_655972D5_typeRegistryIntWidt(zT_69, zT_70);
    zT_73 = (unsigned int)zT_72;
    w = zT_73;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_95 = 1;
    sz = zT_95;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_97 = self->types_items;
    zT_97[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
int zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_E276DDD0_PackedBitField* zT_40;
    zT_E276DDD0_PackedBitField* zT_42;
    unsigned int zT_43;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_44;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_22 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_20) >= zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    zT_37 = self->pk_len;
    if ((int)((unsigned int)(pstart + pcount) > zT_37)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_40 = self->pk_items;
    zT_42 = zT_40 + pstart;
    zT_43 = (unsigned int)(pstart + pcount) - pstart;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    *out = zT_44;
    return (int)(1);
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    if ((int)(zT_14 >= (unsigned int)((unsigned int)zT_15))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* pointerQualifiersMonotone */
int zF_08C13644_pointerQualifiersMo(unsigned char src_flags, unsigned char tgt_flags, unsigned char mask) {
    return (int)((unsigned char)((unsigned char)(src_flags & mask) & (unsigned char)(~(unsigned char)(tgt_flags & mask))) == (unsigned char)(0));
}

/* typeRegistryIsAssignable */
int zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_17;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_24;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    int zT_27 = 0;
    zT_33EF6BFB_TypeKind zT_29;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    int zT_38 = 0;
    int zT_39;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    int zT_42 = 0;
    int zT_43;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    int zT_48 = 0;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    int zT_51 = 0;
    int zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    unsigned char zT_56 = 0;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    unsigned char zT_59 = 0;
    int zT_64;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_71;
    unsigned int zT_72;
    int zT_73 = 0;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_79;
    zT_33EF6BFB_TypeKind zT_83;
    int zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_112BF819_PtrPayload* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_112BF819_PtrPayload zT_94;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    zT_0317B1D5_FnPayload* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_0317B1D5_FnPayload zT_107;
    zT_0317B1D5_FnPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_0317B1D5_FnPayload zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    int zT_116;
    unsigned short zT_117;
    unsigned short zT_118;
    int zT_120;
    unsigned char zT_121;
    unsigned char zT_124;
    int zT_128;
    unsigned char zT_129;
    unsigned char zT_132;
    int zT_137;
    int zT_139;
    unsigned short zT_140;
    unsigned short zT_141;
    unsigned int* zT_143;
    unsigned int zT_144;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int* zT_149;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_156;
    int zT_157;
    unsigned int zT_158;
    zT_33EF6BFB_TypeKind zT_160;
    zT_0B10E8E9_OptionalPayload* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_0B10E8E9_OptionalPayload zT_167;
    zT_338B7C76_TypeRegistry* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    int zT_172 = 0;
    zT_33EF6BFB_TypeKind zT_174;
    zT_33EF6BFB_TypeKind zT_178;
    int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_42C2D6BF_EUPayload* zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    zT_42C2D6BF_EUPayload zT_189;
    zT_42C2D6BF_EUPayload* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_42C2D6BF_EUPayload zT_194;
    unsigned int zT_196;
    unsigned int zT_197;
    int zT_198;
    zT_338B7C76_TypeRegistry* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    int zT_205 = 0;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_33EF6BFB_TypeKind zT_212;
    zT_42C2D6BF_EUPayload* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    zT_42C2D6BF_EUPayload zT_219;
    zT_338B7C76_TypeRegistry* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    int zT_224 = 0;
    zT_33EF6BFB_TypeKind zT_226;
    int zT_229;
    zT_33EF6BFB_TypeKind zT_230;
    zT_33EF6BFB_TypeKind zT_234;
    int zT_237;
    zT_33EF6BFB_TypeKind zT_238;
    zT_112BF819_PtrPayload* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_112BF819_PtrPayload zT_245;
    zT_112BF819_PtrPayload* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    zT_112BF819_PtrPayload zT_250;
    unsigned char zT_252;
    unsigned char zT_253;
    unsigned char zT_254;
    unsigned int zT_257;
    int zT_258 = 0;
    unsigned int zT_259;
    unsigned int zT_262;
    unsigned char zT_265;
    int zT_270;
    unsigned char zT_271;
    unsigned int zT_276;
    unsigned int zT_277;
    int zT_279;
    unsigned char zT_281;
    int zT_286;
    unsigned char zT_287;
    unsigned int zT_292;
    unsigned int zT_293;
    int zT_295;
    unsigned char zT_296;
    int zT_301;
    unsigned char zT_302;
    zT_33EF6BFB_TypeKind zT_308;
    int zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    unsigned char zT_316;
    unsigned char zT_317;
    unsigned char zT_318;
    unsigned int zT_321;
    int zT_322 = 0;
    unsigned char zT_323;
    int zT_328;
    unsigned char zT_329;
    zT_0BB2A741_SlicePayload* zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    zT_0BB2A741_SlicePayload zT_338;
    zT_0BB2A741_SlicePayload* zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    zT_0BB2A741_SlicePayload zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    int zT_347;
    unsigned char zT_349;
    int zT_354;
    unsigned char zT_355;
    zT_0BB2A741_SlicePayload* zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    zT_0BB2A741_SlicePayload zT_364;
    zT_0BB2A741_SlicePayload* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    zT_0BB2A741_SlicePayload zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    int zT_373;
    unsigned char zT_374;
    int zT_379;
    unsigned char zT_380;
    zT_33EF6BFB_TypeKind zT_386;
    int zT_389;
    zT_33EF6BFB_TypeKind zT_390;
    unsigned char zT_394;
    unsigned char zT_395;
    unsigned char zT_396;
    unsigned int zT_399;
    int zT_400 = 0;
    zT_112BF819_PtrPayload* zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    zT_112BF819_PtrPayload zT_405;
    zT_0BB2A741_SlicePayload* zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    zT_0BB2A741_SlicePayload zT_410;
    zT_D155D06D_Type* zT_412;
    unsigned int zT_413;
    unsigned int zT_414;
    zT_D155D06D_Type zT_415;
    zT_33EF6BFB_TypeKind zT_416;
    zT_E834303C_ArrayPayload* zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    zT_E834303C_ArrayPayload zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    int zT_427;
    zT_33EF6BFB_TypeKind zT_429;
    int zT_432;
    zT_33EF6BFB_TypeKind zT_433;
    unsigned char zT_437;
    unsigned char zT_438;
    unsigned char zT_439;
    unsigned int zT_442;
    int zT_443 = 0;
    unsigned char zT_444;
    int zT_449;
    unsigned char zT_450;
    zT_112BF819_PtrPayload* zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    zT_112BF819_PtrPayload zT_459;
    zT_112BF819_PtrPayload* zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    zT_112BF819_PtrPayload zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    int zT_468;
    unsigned char zT_470;
    int zT_475;
    unsigned char zT_476;
    zT_112BF819_PtrPayload* zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    zT_112BF819_PtrPayload zT_485;
    zT_112BF819_PtrPayload* zT_487;
    unsigned int zT_488;
    unsigned int zT_489;
    zT_112BF819_PtrPayload zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    int zT_494;
    unsigned char zT_495;
    int zT_500;
    unsigned char zT_501;
    zT_33EF6BFB_TypeKind zT_507;
    int zT_510;
    zT_33EF6BFB_TypeKind zT_511;
    unsigned char zT_515;
    unsigned char zT_516;
    unsigned char zT_517;
    unsigned int zT_520;
    int zT_521 = 0;
    zT_E834303C_ArrayPayload* zT_523;
    unsigned int zT_524;
    unsigned int zT_525;
    zT_E834303C_ArrayPayload zT_526;
    zT_0BB2A741_SlicePayload* zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    zT_0BB2A741_SlicePayload zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    int zT_535;
    unsigned char zT_537;
    int zT_542;
    unsigned int zT_543;
    unsigned int zT_544;
    int zT_546;
    zT_33EF6BFB_TypeKind zT_548;
    int zT_551;
    zT_33EF6BFB_TypeKind zT_552;
    unsigned char zT_556;
    unsigned char zT_557;
    unsigned char zT_558;
    unsigned int zT_561;
    int zT_562 = 0;
    zT_E834303C_ArrayPayload* zT_564;
    unsigned int zT_565;
    unsigned int zT_566;
    zT_E834303C_ArrayPayload zT_567;
    zT_112BF819_PtrPayload* zT_569;
    unsigned int zT_570;
    unsigned int zT_571;
    zT_112BF819_PtrPayload zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    int zT_576;
    zT_33EF6BFB_TypeKind zT_578;
    int zT_581;
    zT_33EF6BFB_TypeKind zT_582;
    unsigned char zT_586;
    unsigned char zT_587;
    unsigned char zT_588;
    unsigned int zT_591;
    int zT_592 = 0;
    zT_112BF819_PtrPayload* zT_594;
    unsigned int zT_595;
    unsigned int zT_596;
    zT_112BF819_PtrPayload zT_597;
    zT_112BF819_PtrPayload* zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    zT_112BF819_PtrPayload zT_602;
    zT_D155D06D_Type* zT_604;
    unsigned int zT_605;
    unsigned int zT_606;
    zT_D155D06D_Type zT_607;
    zT_33EF6BFB_TypeKind zT_608;
    zT_E834303C_ArrayPayload* zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    zT_E834303C_ArrayPayload zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    int zT_619;
    zT_33EF6BFB_TypeKind zT_621;
    int zT_624;
    zT_33EF6BFB_TypeKind zT_625;
    zT_E834303C_ArrayPayload* zT_629;
    unsigned int zT_630;
    unsigned int zT_631;
    zT_E834303C_ArrayPayload zT_632;
    zT_E834303C_ArrayPayload* zT_634;
    unsigned int zT_635;
    unsigned int zT_636;
    zT_E834303C_ArrayPayload zT_637;
    unsigned int zT_638;
    unsigned int zT_639;
    int zT_641;
    unsigned int zT_642;
    unsigned int zT_643;
    zT_33EF6BFB_TypeKind zT_646;
    int zT_649;
    zT_33EF6BFB_TypeKind zT_650;
    unsigned char zT_654;
    unsigned char zT_655;
    unsigned char zT_656;
    unsigned int zT_659;
    int zT_660 = 0;
    zT_0BB2A741_SlicePayload* zT_662;
    unsigned int zT_663;
    unsigned int zT_664;
    zT_0BB2A741_SlicePayload zT_665;
    zT_112BF819_PtrPayload* zT_667;
    unsigned int zT_668;
    unsigned int zT_669;
    zT_112BF819_PtrPayload zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    int zT_674;
    zT_33EF6BFB_TypeKind zT_676;
    int zT_679;
    zT_33EF6BFB_TypeKind zT_680;
    zT_0B10E8E9_OptionalPayload* zT_684;
    unsigned int zT_685;
    unsigned int zT_686;
    zT_0B10E8E9_OptionalPayload zT_687;
    zT_D155D06D_Type* zT_689;
    unsigned int zT_690;
    unsigned int zT_691;
    zT_D155D06D_Type zT_692;
    zT_33EF6BFB_TypeKind zT_693;
    zT_338B7C76_TypeRegistry* zT_696;
    unsigned int zT_697;
    unsigned int zT_699;
    int zT_703;
    int zT_706;
    int zT_709;
    zT_33EF6BFB_TypeKind zT_713;
    int zT_716;
    zT_33EF6BFB_TypeKind zT_717;
    zT_666DC2E1_TuplePayload* zT_721;
    unsigned int zT_722;
    unsigned int zT_723;
    zT_666DC2E1_TuplePayload zT_724;
    zT_E834303C_ArrayPayload* zT_726;
    unsigned int zT_727;
    unsigned int zT_728;
    zT_E834303C_ArrayPayload zT_729;
    unsigned short zT_730;
    unsigned int zT_732;
    int zT_735;
    int zT_737;
    unsigned short zT_738;
    unsigned short zT_739;
    zT_338B7C76_TypeRegistry* zT_741;
    unsigned int zT_742;
    unsigned int zT_743;
    unsigned int* zT_744;
    unsigned int zT_745;
    unsigned int zT_748;
    int zT_751 = 0;
    int zT_753;
    int zT_754;
    unsigned int zT_755;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0317B1D5_FnPayload src_f;
    zT_0317B1D5_FnPayload tgt_f;
    int ok;
    unsigned short fi;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    int es_ok;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    int qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload s_sl2;
    zT_0BB2A741_SlicePayload t_sl2;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload s_pp2;
    zT_112BF819_PtrPayload t_pp2;
    zT_112BF819_PtrPayload pp;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_D155D06D_Type opt_ty;
    zT_666DC2E1_TuplePayload tup;
    unsigned short k;
    z_bb_0:
    if ((int)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_17 = src.kind;
    if ((int)(zT_17 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_21 = src.kind;
    if ((int)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self;
    zT_26 = target;
    zT_27 = zF_3087E0A5_typeRegistryIsNumer(zT_25, zT_26);
    zT_24 = zT_27;
    goto z_bb_9;
    z_bb_8:
    zT_24 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (int)(1);
    z_bb_11:
    zT_29 = src.kind;
    if ((int)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_32 = target == (unsigned int)(14);
    goto z_bb_14;
    z_bb_13:
    zT_32 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_32) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    zT_36 = self;
    zT_37 = source;
    zT_38 = zF_3290E9C4_typeRegistryIsInteg(zT_36, zT_37);
    if (zT_38) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_40 = self;
    zT_41 = target;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_40, zT_41);
    zT_39 = zT_42;
    goto z_bb_19;
    z_bb_18:
    zT_39 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_39) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_43 = source != (unsigned int)(19);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_B664AC19_typeRegistryIsUnsig(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_B664AC19_typeRegistryIsUnsig(zT_49, zT_50);
    if ((int)(zT_48 == zT_51)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((int)(source == (unsigned int)(15))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_54 = self;
    zT_55 = source;
    zT_56 = zF_655972D5_typeRegistryIntWidt(zT_54, zT_55);
    zT_57 = self;
    zT_58 = target;
    zT_59 = zF_655972D5_typeRegistryIntWidt(zT_57, zT_58);
    zT_53 = zT_56 < zT_59;
    goto z_bb_27;
    z_bb_26:
    zT_53 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (int)(1);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    zT_64 = target == (unsigned int)(16);
    goto z_bb_32;
    z_bb_31:
    zT_64 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_64) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (int)(1);
    z_bb_34:
    zT_68 = src.kind;
    if ((int)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_71 = self;
    zT_72 = target;
    zT_73 = zF_AD61DB1B_typeRegistryIsPoint(zT_71, zT_72);
    if (zT_73) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_83 = src.kind;
    if ((int)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    zT_75 = tgt.kind;
    if ((int)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (int)(1);
    z_bb_40:
    zT_79 = tgt.kind;
    if ((int)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (int)(1);
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_87 = tgt.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_45;
    z_bb_44:
    zT_86 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_86) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_91 = self->ptr_items;
    zT_92 = tgt.payload_idx;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    tpp = zT_94;
    zT_96 = self->types_items;
    zT_97 = tpp.base;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    bt = zT_99;
    zT_100 = bt.kind;
    if ((int)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_160 = tgt.kind;
    if ((int)(zT_160 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_48:
    zT_104 = self->fn_items;
    zT_105 = src.payload_idx;
    zT_106 = (unsigned int)zT_105;
    zT_107 = zT_104[zT_106];
    src_f = zT_107;
    zT_109 = self->fn_items;
    zT_110 = bt.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    tgt_f = zT_112;
    zT_113 = src_f.return_type;
    zT_114 = tgt_f.return_type;
    if ((int)(zT_113 == zT_114)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_117 = src_f.params_count;
    zT_118 = tgt_f.params_count;
    zT_116 = zT_117 == zT_118;
    goto z_bb_52;
    z_bb_51:
    zT_116 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_116) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_121 = src_f.flags_packed;
    zT_124 = tgt_f.flags_packed;
    zT_120 = (unsigned char)(zT_121 & (unsigned char)(1)) == (unsigned char)(zT_124 & (unsigned char)(1));
    goto z_bb_55;
    z_bb_54:
    zT_120 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_120) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_129 = src_f.flags_packed;
    zT_132 = tgt_f.flags_packed;
    zT_128 = (unsigned char)(zT_129 & (unsigned char)(2)) == (unsigned char)(zT_132 & (unsigned char)(2));
    goto z_bb_58;
    z_bb_57:
    zT_128 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_128) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_137 = 1;
    ok = zT_137;
    zT_139 = 0;
    zT_140 = (unsigned short)zT_139;
    fi = zT_140;
    goto z_bb_61;
    z_bb_60:
    goto z_bb_49;
    z_bb_61:
    zT_141 = src_f.params_count;
    if ((int)(fi < zT_141)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_143 = self->xt_items;
    zT_144 = src_f.params_start;
    zT_147 = (unsigned int)(unsigned int)(zT_144 + (unsigned int)((unsigned int)fi));
    zT_148 = zT_143[zT_147];
    zT_149 = self->xt_items;
    zT_150 = tgt_f.params_start;
    zT_153 = (unsigned int)(unsigned int)(zT_150 + (unsigned int)((unsigned int)fi));
    zT_154 = zT_149[zT_153];
    if ((int)(zT_148 != zT_154)) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    if (ok) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_157 = 1;
    zT_158 = fi + zT_157;
    fi = zT_158;
    goto z_bb_61;
    z_bb_65:
    zT_156 = 0;
    ok = zT_156;
    goto z_bb_63;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    return (int)(1);
    z_bb_68:
    goto z_bb_60;
    z_bb_69:
    zT_164 = self->opt_items;
    zT_165 = tgt.payload_idx;
    zT_166 = (unsigned int)zT_165;
    zT_167 = zT_164[zT_166];
    opt = zT_167;
    zT_168 = self;
    zT_169 = source;
    zT_170 = opt.payload;
    zT_172 = zF_683AEB7F_typeRegistryIsAssig(zT_168, zT_169, zT_170);
    if (zT_172) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    zT_178 = src.kind;
    if ((int)(zT_178 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_71:
    return (int)(1);
    z_bb_72:
    zT_174 = src.kind;
    if ((int)(zT_174 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (int)(1);
    z_bb_74:
    goto z_bb_70;
    z_bb_75:
    zT_182 = tgt.kind;
    zT_181 = zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_77;
    z_bb_76:
    zT_181 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_181) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_186 = self->eu_items;
    zT_187 = src.payload_idx;
    zT_188 = (unsigned int)zT_187;
    zT_189 = zT_186[zT_188];
    eu_src = zT_189;
    zT_191 = self->eu_items;
    zT_192 = tgt.payload_idx;
    zT_193 = (unsigned int)zT_192;
    zT_194 = zT_191[zT_193];
    eu_tgt = zT_194;
    zT_196 = eu_src.error_set;
    zT_197 = eu_tgt.error_set;
    zT_198 = zT_196 == zT_197;
    es_ok = zT_198;
    if ((int)(!es_ok)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_212 = tgt.kind;
    if ((int)(zT_212 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_80:
    zT_200 = self;
    zT_201 = eu_src.error_set;
    zT_202 = eu_tgt.error_set;
    zT_205 = zF_E35E11A5_errorSetIsSubset(zT_200, zT_201, zT_202);
    es_ok = zT_205;
    goto z_bb_81;
    z_bb_81:
    if (es_ok) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_206 = self;
    zT_209 = eu_src.payload;
    zT_210 = eu_tgt.payload;
    self = zT_206;
    source = zT_209;
    target = zT_210;
    goto z_bb_0;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_216 = self->eu_items;
    zT_217 = tgt.payload_idx;
    zT_218 = (unsigned int)zT_217;
    zT_219 = zT_216[zT_218];
    eu = zT_219;
    zT_220 = self;
    zT_221 = source;
    zT_222 = eu.payload;
    zT_224 = zF_683AEB7F_typeRegistryIsAssig(zT_220, zT_221, zT_222);
    if (zT_224) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_226 = src.kind;
    if ((int)(zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    return (int)(1);
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_230 = tgt.kind;
    zT_229 = zT_230 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_90;
    z_bb_89:
    zT_229 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_229) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    return (int)(1);
    z_bb_92:
    zT_234 = src.kind;
    if ((int)(zT_234 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_238 = tgt.kind;
    zT_237 = zT_238 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_95;
    z_bb_94:
    zT_237 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_237) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_242 = self->ptr_items;
    zT_243 = tgt.payload_idx;
    zT_244 = (unsigned int)zT_243;
    zT_245 = zT_242[zT_244];
    tgt_pp = zT_245;
    zT_247 = self->ptr_items;
    zT_248 = src.payload_idx;
    zT_249 = (unsigned int)zT_248;
    zT_250 = zT_247[zT_249];
    src_pp = zT_250;
    zT_252 = src.flags;
    zT_253 = tgt.flags;
    zT_257 = 2;
    zT_254 = zT_257;
    zT_258 = zF_08C13644_pointerQualifiersMo(zT_252, zT_253, zT_254);
    qok = zT_258;
    zT_259 = tgt_pp.base;
    if ((int)(zT_259 == (unsigned int)(1))) goto z_bb_98; else goto z_bb_99;
    z_bb_97:
    zT_308 = tgt.kind;
    if ((int)(zT_308 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_125; else goto z_bb_126;
    z_bb_98:
    return qok;
    z_bb_99:
    zT_262 = src_pp.base;
    if ((int)(zT_262 == (unsigned int)(1))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return qok;
    z_bb_101:
    zT_265 = tgt.flags;
    if ((int)((unsigned char)(zT_265 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_271 = src.flags;
    zT_270 = (unsigned char)(zT_271 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_104;
    z_bb_103:
    zT_270 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_270) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_276 = src_pp.base;
    zT_277 = tgt_pp.base;
    if ((int)(zT_276 == zT_277)) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_281 = tgt.flags;
    if ((int)((unsigned char)(zT_281 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_107:
    zT_279 = qok;
    goto z_bb_109;
    z_bb_108:
    zT_279 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_279) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (int)(1);
    z_bb_111:
    goto z_bb_106;
    z_bb_112:
    zT_287 = src.flags;
    zT_286 = (unsigned char)(zT_287 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_114;
    z_bb_113:
    zT_286 = 0;
    goto z_bb_114;
    z_bb_114:
    if (zT_286) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_292 = src_pp.base;
    zT_293 = tgt_pp.base;
    if ((int)(zT_292 == zT_293)) goto z_bb_117; else goto z_bb_118;
    z_bb_116:
    goto z_bb_97;
    z_bb_117:
    zT_296 = src.flags;
    if ((int)((unsigned char)(zT_296 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_121; else goto z_bb_120;
    z_bb_118:
    zT_295 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_295) goto z_bb_123; else goto z_bb_124;
    z_bb_120:
    zT_302 = tgt.flags;
    zT_301 = (unsigned char)(zT_302 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_122;
    z_bb_121:
    zT_301 = 1;
    goto z_bb_122;
    z_bb_122:
    zT_295 = zT_301;
    goto z_bb_119;
    z_bb_123:
    return (int)(1);
    z_bb_124:
    goto z_bb_116;
    z_bb_125:
    zT_312 = src.kind;
    zT_311 = zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_127;
    z_bb_126:
    zT_311 = 0;
    goto z_bb_127;
    z_bb_127:
    if (zT_311) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_316 = src.flags;
    zT_317 = tgt.flags;
    zT_321 = 2;
    zT_318 = zT_321;
    zT_322 = zF_08C13644_pointerQualifiersMo(zT_316, zT_317, zT_318);
    qok = zT_322;
    zT_323 = tgt.flags;
    if ((int)((unsigned char)(zT_323 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_130; else goto z_bb_131;
    z_bb_129:
    zT_386 = tgt.kind;
    if ((int)(zT_386 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_153; else goto z_bb_154;
    z_bb_130:
    zT_329 = src.flags;
    zT_328 = (unsigned char)(zT_329 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_132;
    z_bb_131:
    zT_328 = 0;
    goto z_bb_132;
    z_bb_132:
    if (zT_328) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    zT_335 = self->slice_items;
    zT_336 = src.payload_idx;
    zT_337 = (unsigned int)zT_336;
    zT_338 = zT_335[zT_337];
    s_sl = zT_338;
    zT_340 = self->slice_items;
    zT_341 = tgt.payload_idx;
    zT_342 = (unsigned int)zT_341;
    zT_343 = zT_340[zT_342];
    t_sl = zT_343;
    zT_344 = s_sl.elem;
    zT_345 = t_sl.elem;
    if ((int)(zT_344 == zT_345)) goto z_bb_135; else goto z_bb_136;
    z_bb_134:
    zT_349 = tgt.flags;
    if ((int)((unsigned char)(zT_349 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_135:
    zT_347 = qok;
    goto z_bb_137;
    z_bb_136:
    zT_347 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_347) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (int)(1);
    z_bb_139:
    goto z_bb_134;
    z_bb_140:
    zT_355 = src.flags;
    zT_354 = (unsigned char)(zT_355 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_142;
    z_bb_141:
    zT_354 = 0;
    goto z_bb_142;
    z_bb_142:
    if (zT_354) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    zT_361 = self->slice_items;
    zT_362 = src.payload_idx;
    zT_363 = (unsigned int)zT_362;
    zT_364 = zT_361[zT_363];
    s_sl2 = zT_364;
    zT_366 = self->slice_items;
    zT_367 = tgt.payload_idx;
    zT_368 = (unsigned int)zT_367;
    zT_369 = zT_366[zT_368];
    t_sl2 = zT_369;
    zT_370 = s_sl2.elem;
    zT_371 = t_sl2.elem;
    if ((int)(zT_370 == zT_371)) goto z_bb_145; else goto z_bb_146;
    z_bb_144:
    goto z_bb_129;
    z_bb_145:
    zT_374 = src.flags;
    if ((int)((unsigned char)(zT_374 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_149; else goto z_bb_148;
    z_bb_146:
    zT_373 = 0;
    goto z_bb_147;
    z_bb_147:
    if (zT_373) goto z_bb_151; else goto z_bb_152;
    z_bb_148:
    zT_380 = tgt.flags;
    zT_379 = (unsigned char)(zT_380 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_150;
    z_bb_149:
    zT_379 = 1;
    goto z_bb_150;
    z_bb_150:
    zT_373 = zT_379;
    goto z_bb_147;
    z_bb_151:
    return (int)(1);
    z_bb_152:
    goto z_bb_144;
    z_bb_153:
    zT_390 = src.kind;
    zT_389 = zT_390 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_155;
    z_bb_154:
    zT_389 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_389) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_394 = src.flags;
    zT_395 = tgt.flags;
    zT_399 = 2;
    zT_396 = zT_399;
    zT_400 = zF_08C13644_pointerQualifiersMo(zT_394, zT_395, zT_396);
    qok = zT_400;
    zT_402 = self->ptr_items;
    zT_403 = src.payload_idx;
    zT_404 = (unsigned int)zT_403;
    zT_405 = zT_402[zT_404];
    src_pp = zT_405;
    zT_407 = self->slice_items;
    zT_408 = tgt.payload_idx;
    zT_409 = (unsigned int)zT_408;
    zT_410 = zT_407[zT_409];
    sl = zT_410;
    zT_412 = self->types_items;
    zT_413 = src_pp.base;
    zT_414 = (unsigned int)zT_413;
    zT_415 = zT_412[zT_414];
    src_pointee = zT_415;
    zT_416 = src_pointee.kind;
    if ((int)(zT_416 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_429 = tgt.kind;
    if ((int)(zT_429 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_165; else goto z_bb_166;
    z_bb_158:
    zT_420 = self->array_items;
    zT_421 = src_pointee.payload_idx;
    zT_422 = (unsigned int)zT_421;
    zT_423 = zT_420[zT_422];
    arr = zT_423;
    zT_424 = arr.elem;
    zT_425 = sl.elem;
    if ((int)(zT_424 == zT_425)) goto z_bb_160; else goto z_bb_161;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    zT_427 = qok;
    goto z_bb_162;
    z_bb_161:
    zT_427 = 0;
    goto z_bb_162;
    z_bb_162:
    if (zT_427) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    return (int)(1);
    z_bb_164:
    goto z_bb_159;
    z_bb_165:
    zT_433 = src.kind;
    zT_432 = zT_433 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_167;
    z_bb_166:
    zT_432 = 0;
    goto z_bb_167;
    z_bb_167:
    if (zT_432) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_437 = src.flags;
    zT_438 = tgt.flags;
    zT_442 = 2;
    zT_439 = zT_442;
    zT_443 = zF_08C13644_pointerQualifiersMo(zT_437, zT_438, zT_439);
    qok = zT_443;
    zT_444 = tgt.flags;
    if ((int)((unsigned char)(zT_444 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_170; else goto z_bb_171;
    z_bb_169:
    zT_507 = src.kind;
    if ((int)(zT_507 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_170:
    zT_450 = src.flags;
    zT_449 = (unsigned char)(zT_450 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_172;
    z_bb_171:
    zT_449 = 0;
    goto z_bb_172;
    z_bb_172:
    if (zT_449) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_456 = self->ptr_items;
    zT_457 = src.payload_idx;
    zT_458 = (unsigned int)zT_457;
    zT_459 = zT_456[zT_458];
    s_pp = zT_459;
    zT_461 = self->ptr_items;
    zT_462 = tgt.payload_idx;
    zT_463 = (unsigned int)zT_462;
    zT_464 = zT_461[zT_463];
    t_pp = zT_464;
    zT_465 = s_pp.base;
    zT_466 = t_pp.base;
    if ((int)(zT_465 == zT_466)) goto z_bb_175; else goto z_bb_176;
    z_bb_174:
    zT_470 = tgt.flags;
    if ((int)((unsigned char)(zT_470 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_180; else goto z_bb_181;
    z_bb_175:
    zT_468 = qok;
    goto z_bb_177;
    z_bb_176:
    zT_468 = 0;
    goto z_bb_177;
    z_bb_177:
    if (zT_468) goto z_bb_178; else goto z_bb_179;
    z_bb_178:
    return (int)(1);
    z_bb_179:
    goto z_bb_174;
    z_bb_180:
    zT_476 = src.flags;
    zT_475 = (unsigned char)(zT_476 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_182;
    z_bb_181:
    zT_475 = 0;
    goto z_bb_182;
    z_bb_182:
    if (zT_475) goto z_bb_183; else goto z_bb_184;
    z_bb_183:
    zT_482 = self->ptr_items;
    zT_483 = src.payload_idx;
    zT_484 = (unsigned int)zT_483;
    zT_485 = zT_482[zT_484];
    s_pp2 = zT_485;
    zT_487 = self->ptr_items;
    zT_488 = tgt.payload_idx;
    zT_489 = (unsigned int)zT_488;
    zT_490 = zT_487[zT_489];
    t_pp2 = zT_490;
    zT_491 = s_pp2.base;
    zT_492 = t_pp2.base;
    if ((int)(zT_491 == zT_492)) goto z_bb_185; else goto z_bb_186;
    z_bb_184:
    goto z_bb_169;
    z_bb_185:
    zT_495 = src.flags;
    if ((int)((unsigned char)(zT_495 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_189; else goto z_bb_188;
    z_bb_186:
    zT_494 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_494) goto z_bb_191; else goto z_bb_192;
    z_bb_188:
    zT_501 = tgt.flags;
    zT_500 = (unsigned char)(zT_501 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_190;
    z_bb_189:
    zT_500 = 1;
    goto z_bb_190;
    z_bb_190:
    zT_494 = zT_500;
    goto z_bb_187;
    z_bb_191:
    return (int)(1);
    z_bb_192:
    goto z_bb_184;
    z_bb_193:
    zT_511 = tgt.kind;
    zT_510 = zT_511 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_195;
    z_bb_194:
    zT_510 = 0;
    goto z_bb_195;
    z_bb_195:
    if (zT_510) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    zT_515 = src.flags;
    zT_516 = tgt.flags;
    zT_520 = 2;
    zT_517 = zT_520;
    zT_521 = zF_08C13644_pointerQualifiersMo(zT_515, zT_516, zT_517);
    qok = zT_521;
    zT_523 = self->array_items;
    zT_524 = src.payload_idx;
    zT_525 = (unsigned int)zT_524;
    zT_526 = zT_523[zT_525];
    arr = zT_526;
    zT_528 = self->slice_items;
    zT_529 = tgt.payload_idx;
    zT_530 = (unsigned int)zT_529;
    zT_531 = zT_528[zT_530];
    sl = zT_531;
    zT_532 = arr.elem;
    zT_533 = sl.elem;
    if ((int)(zT_532 == zT_533)) goto z_bb_198; else goto z_bb_199;
    z_bb_197:
    zT_548 = src.kind;
    if ((int)(zT_548 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_211; else goto z_bb_212;
    z_bb_198:
    zT_535 = qok;
    goto z_bb_200;
    z_bb_199:
    zT_535 = 0;
    goto z_bb_200;
    z_bb_200:
    if (zT_535) goto z_bb_201; else goto z_bb_202;
    z_bb_201:
    return (int)(1);
    z_bb_202:
    zT_537 = tgt.flags;
    if ((int)((unsigned char)(zT_537 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    zT_543 = arr.elem;
    zT_544 = sl.elem;
    zT_542 = zT_543 == zT_544;
    goto z_bb_205;
    z_bb_204:
    zT_542 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_542) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_546 = qok;
    goto z_bb_208;
    z_bb_207:
    zT_546 = 0;
    goto z_bb_208;
    z_bb_208:
    if (zT_546) goto z_bb_209; else goto z_bb_210;
    z_bb_209:
    return (int)(1);
    z_bb_210:
    goto z_bb_197;
    z_bb_211:
    zT_552 = tgt.kind;
    zT_551 = zT_552 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_213;
    z_bb_212:
    zT_551 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_551) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    zT_556 = src.flags;
    zT_557 = tgt.flags;
    zT_561 = 2;
    zT_558 = zT_561;
    zT_562 = zF_08C13644_pointerQualifiersMo(zT_556, zT_557, zT_558);
    qok = zT_562;
    zT_564 = self->array_items;
    zT_565 = src.payload_idx;
    zT_566 = (unsigned int)zT_565;
    zT_567 = zT_564[zT_566];
    arr = zT_567;
    zT_569 = self->ptr_items;
    zT_570 = tgt.payload_idx;
    zT_571 = (unsigned int)zT_570;
    zT_572 = zT_569[zT_571];
    pp = zT_572;
    zT_573 = arr.elem;
    zT_574 = pp.base;
    if ((int)(zT_573 == zT_574)) goto z_bb_216; else goto z_bb_217;
    z_bb_215:
    zT_578 = src.kind;
    if ((int)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_221; else goto z_bb_222;
    z_bb_216:
    zT_576 = qok;
    goto z_bb_218;
    z_bb_217:
    zT_576 = 0;
    goto z_bb_218;
    z_bb_218:
    if (zT_576) goto z_bb_219; else goto z_bb_220;
    z_bb_219:
    return (int)(1);
    z_bb_220:
    goto z_bb_215;
    z_bb_221:
    zT_582 = tgt.kind;
    zT_581 = zT_582 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_223;
    z_bb_222:
    zT_581 = 0;
    goto z_bb_223;
    z_bb_223:
    if (zT_581) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    zT_586 = src.flags;
    zT_587 = tgt.flags;
    zT_591 = 2;
    zT_588 = zT_591;
    zT_592 = zF_08C13644_pointerQualifiersMo(zT_586, zT_587, zT_588);
    qok = zT_592;
    zT_594 = self->ptr_items;
    zT_595 = src.payload_idx;
    zT_596 = (unsigned int)zT_595;
    zT_597 = zT_594[zT_596];
    sp = zT_597;
    zT_599 = self->ptr_items;
    zT_600 = tgt.payload_idx;
    zT_601 = (unsigned int)zT_600;
    zT_602 = zT_599[zT_601];
    tp = zT_602;
    zT_604 = self->types_items;
    zT_605 = sp.base;
    zT_606 = (unsigned int)zT_605;
    zT_607 = zT_604[zT_606];
    spo = zT_607;
    zT_608 = spo.kind;
    if ((int)(zT_608 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_226; else goto z_bb_227;
    z_bb_225:
    zT_621 = src.kind;
    if ((int)(zT_621 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_233; else goto z_bb_234;
    z_bb_226:
    zT_612 = self->array_items;
    zT_613 = spo.payload_idx;
    zT_614 = (unsigned int)zT_613;
    zT_615 = zT_612[zT_614];
    arr = zT_615;
    zT_616 = arr.elem;
    zT_617 = tp.base;
    if ((int)(zT_616 == zT_617)) goto z_bb_228; else goto z_bb_229;
    z_bb_227:
    goto z_bb_225;
    z_bb_228:
    zT_619 = qok;
    goto z_bb_230;
    z_bb_229:
    zT_619 = 0;
    goto z_bb_230;
    z_bb_230:
    if (zT_619) goto z_bb_231; else goto z_bb_232;
    z_bb_231:
    return (int)(1);
    z_bb_232:
    goto z_bb_227;
    z_bb_233:
    zT_625 = tgt.kind;
    zT_624 = zT_625 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_235;
    z_bb_234:
    zT_624 = 0;
    goto z_bb_235;
    z_bb_235:
    if (zT_624) goto z_bb_236; else goto z_bb_237;
    z_bb_236:
    zT_629 = self->array_items;
    zT_630 = src.payload_idx;
    zT_631 = (unsigned int)zT_630;
    zT_632 = zT_629[zT_631];
    s_arr = zT_632;
    zT_634 = self->array_items;
    zT_635 = tgt.payload_idx;
    zT_636 = (unsigned int)zT_635;
    zT_637 = zT_634[zT_636];
    t_arr = zT_637;
    zT_638 = s_arr.elem;
    zT_639 = t_arr.elem;
    if ((int)(zT_638 == zT_639)) goto z_bb_238; else goto z_bb_239;
    z_bb_237:
    zT_646 = src.kind;
    if ((int)(zT_646 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_243; else goto z_bb_244;
    z_bb_238:
    zT_642 = s_arr.length;
    zT_643 = t_arr.length;
    zT_641 = zT_642 == zT_643;
    goto z_bb_240;
    z_bb_239:
    zT_641 = 0;
    goto z_bb_240;
    z_bb_240:
    if (zT_641) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    return (int)(1);
    z_bb_242:
    goto z_bb_237;
    z_bb_243:
    zT_650 = tgt.kind;
    zT_649 = zT_650 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_245;
    z_bb_244:
    zT_649 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_649) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_654 = src.flags;
    zT_655 = tgt.flags;
    zT_659 = 2;
    zT_656 = zT_659;
    zT_660 = zF_08C13644_pointerQualifiersMo(zT_654, zT_655, zT_656);
    qok = zT_660;
    zT_662 = self->slice_items;
    zT_663 = src.payload_idx;
    zT_664 = (unsigned int)zT_663;
    zT_665 = zT_662[zT_664];
    sl = zT_665;
    zT_667 = self->ptr_items;
    zT_668 = tgt.payload_idx;
    zT_669 = (unsigned int)zT_668;
    zT_670 = zT_667[zT_669];
    pp = zT_670;
    zT_671 = sl.elem;
    zT_672 = pp.base;
    if ((int)(zT_671 == zT_672)) goto z_bb_248; else goto z_bb_249;
    z_bb_247:
    zT_676 = src.kind;
    if ((int)(zT_676 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_253; else goto z_bb_254;
    z_bb_248:
    zT_674 = qok;
    goto z_bb_250;
    z_bb_249:
    zT_674 = 0;
    goto z_bb_250;
    z_bb_250:
    if (zT_674) goto z_bb_251; else goto z_bb_252;
    z_bb_251:
    return (int)(1);
    z_bb_252:
    goto z_bb_247;
    z_bb_253:
    zT_680 = tgt.kind;
    zT_679 = zT_680 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_255;
    z_bb_254:
    zT_679 = 0;
    goto z_bb_255;
    z_bb_255:
    if (zT_679) goto z_bb_256; else goto z_bb_257;
    z_bb_256:
    zT_684 = self->opt_items;
    zT_685 = tgt.payload_idx;
    zT_686 = (unsigned int)zT_685;
    zT_687 = zT_684[zT_686];
    opt = zT_687;
    zT_689 = self->types_items;
    zT_690 = opt.payload;
    zT_691 = (unsigned int)zT_690;
    zT_692 = zT_689[zT_691];
    opt_ty = zT_692;
    zT_693 = opt_ty.kind;
    if ((int)(zT_693 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_258; else goto z_bb_259;
    z_bb_257:
    if ((int)(source == (unsigned int)(8))) goto z_bb_260; else goto z_bb_261;
    z_bb_258:
    zT_696 = self;
    zT_697 = source;
    zT_699 = opt.payload;
    self = zT_696;
    source = zT_697;
    target = zT_699;
    goto z_bb_0;
    z_bb_259:
    goto z_bb_257;
    z_bb_260:
    zT_703 = target == (unsigned int)(14);
    goto z_bb_262;
    z_bb_261:
    zT_703 = 0;
    goto z_bb_262;
    z_bb_262:
    if (zT_703) goto z_bb_264; else goto z_bb_263;
    z_bb_263:
    if ((int)(source == (unsigned int)(14))) goto z_bb_266; else goto z_bb_267;
    z_bb_264:
    zT_706 = 1;
    goto z_bb_265;
    z_bb_265:
    if (zT_706) goto z_bb_269; else goto z_bb_270;
    z_bb_266:
    zT_709 = target == (unsigned int)(8);
    goto z_bb_268;
    z_bb_267:
    zT_709 = 0;
    goto z_bb_268;
    z_bb_268:
    zT_706 = zT_709;
    goto z_bb_265;
    z_bb_269:
    return (int)(1);
    z_bb_270:
    zT_713 = src.kind;
    if ((int)(zT_713 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_271; else goto z_bb_272;
    z_bb_271:
    zT_717 = tgt.kind;
    zT_716 = zT_717 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_273;
    z_bb_272:
    zT_716 = 0;
    goto z_bb_273;
    z_bb_273:
    if (zT_716) goto z_bb_274; else goto z_bb_275;
    z_bb_274:
    zT_721 = self->tup_items;
    zT_722 = src.payload_idx;
    zT_723 = (unsigned int)zT_722;
    zT_724 = zT_721[zT_723];
    tup = zT_724;
    zT_726 = self->array_items;
    zT_727 = tgt.payload_idx;
    zT_728 = (unsigned int)zT_727;
    zT_729 = zT_726[zT_728];
    arr = zT_729;
    zT_730 = tup.elems_count;
    zT_732 = arr.length;
    if ((int)((unsigned int)((unsigned int)zT_730) == zT_732)) goto z_bb_276; else goto z_bb_277;
    z_bb_275:
    return (int)(0);
    z_bb_276:
    zT_735 = 1;
    ok = zT_735;
    zT_737 = 0;
    zT_738 = (unsigned short)zT_737;
    k = zT_738;
    goto z_bb_278;
    z_bb_277:
    goto z_bb_275;
    z_bb_278:
    zT_739 = tup.elems_count;
    if ((int)(k < zT_739)) goto z_bb_279; else goto z_bb_280;
    z_bb_279:
    zT_741 = self;
    zT_744 = self->xt_items;
    zT_745 = tup.elems_start;
    zT_748 = (unsigned int)(unsigned int)(zT_745 + (unsigned int)((unsigned int)k));
    zT_742 = zT_744[zT_748];
    zT_743 = arr.elem;
    zT_751 = zF_683AEB7F_typeRegistryIsAssig(zT_741, zT_742, zT_743);
    if ((int)(!zT_751)) goto z_bb_282; else goto z_bb_283;
    z_bb_280:
    if (ok) goto z_bb_284; else goto z_bb_285;
    z_bb_281:
    zT_754 = 1;
    zT_755 = k + zT_754;
    k = zT_755;
    goto z_bb_278;
    z_bb_282:
    zT_753 = 0;
    ok = zT_753;
    goto z_bb_280;
    z_bb_283:
    goto z_bb_281;
    z_bb_284:
    return (int)(1);
    z_bb_285:
    goto z_bb_277;
}

/* errorSetIsSubset */
int zF_E35E11A5_errorSetIsSubset(zT_338B7C76_TypeRegistry* self, unsigned int src, unsigned int tgt) {
    unsigned int zT_12;
    unsigned int zT_16;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_0B73C507_ErrorSetPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B73C507_ErrorSetPayload zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned short zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    int zT_56;
    unsigned int zT_57;
    zT_338B7C76_TypeRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    int zT_69;
    unsigned int zT_70;
    zT_D155D06D_Type sty;
    zT_D155D06D_Type tty;
    zT_0B73C507_ErrorSetPayload sp;
    unsigned int sstart;
    unsigned int scount;
    unsigned int i;
    if ((int)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(src == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(tgt == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_12 = self->types_len;
    if ((int)((unsigned int)((unsigned int)src) >= zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_16 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tgt) >= zT_16)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_20 = self->types_items;
    zT_21 = (unsigned int)src;
    zT_22 = zT_20[zT_21];
    sty = zT_22;
    zT_24 = self->types_items;
    zT_25 = (unsigned int)tgt;
    zT_26 = zT_24[zT_25];
    tty = zT_26;
    zT_27 = sty.kind;
    if ((int)(zT_27 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_31 = tty.kind;
    if ((int)(zT_31 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_35 = sty.payload_idx;
    zT_37 = self->es_len;
    if ((int)((unsigned int)((unsigned int)zT_35) >= zT_37)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_41 = self->es_items;
    zT_42 = sty.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    sp = zT_44;
    zT_46 = sp.tags_start;
    zT_47 = (unsigned int)zT_46;
    sstart = zT_47;
    zT_49 = sp.tags_count;
    zT_50 = (unsigned int)zT_49;
    scount = zT_50;
    zT_52 = self->xn_len;
    if ((int)((unsigned int)(sstart + scount) > zT_52)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    i = zT_57;
    goto z_bb_19;
    z_bb_19:
    if ((int)(i < scount)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_59 = self;
    zT_60 = tgt;
    zT_62 = self->xn_items;
    zT_63 = sstart + i;
    zT_61 = zT_62[zT_63];
    zT_65 = zF_D2ECD176_typeRegistryErrorSe(zT_59, zT_60, zT_61);
    if ((int)(zT_65 == (unsigned int)(4294967295u))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    zT_69 = 1;
    zT_70 = i + zT_69;
    i = zT_70;
    goto z_bb_19;
    z_bb_23:
    return (int)(0);
    z_bb_24:
    goto z_bb_22;
}

/* canLiteralFitInType */
int zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    int zT_6;
    int zT_13;
    int zT_22;
    int zT_32;
    int zT_39;
    int zT_46;
    int zT_59;
    int zT_66;
    int zT_71;
    if ((int)(target == (unsigned int)(4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-128))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((int)(target == (unsigned int)(5))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_6 = value <= (zT_C69B2266_i64)(127);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-32768))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((int)(target == (unsigned int)(6))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_13 = value <= (zT_C69B2266_i64)(32767);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    if ((int)(target == (unsigned int)(7))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_22 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    if ((int)(target == (unsigned int)(8))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((int)(target == (unsigned int)(9))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_32 = value <= (zT_C69B2266_i64)(255);
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((int)(target == (unsigned int)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_39 = value <= (zT_C69B2266_i64)(65535);
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    if ((int)(target == (unsigned int)(11))) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_46 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    return (int)(value >= (zT_C69B2266_i64)(0));
    z_bb_34:
    if ((int)(target == (unsigned int)(12))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((int)(target == (unsigned int)(13))) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_59 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    if ((int)(target == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_66 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_71 = target == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return (int)(1);
    z_bb_49:
    return (int)(0);
}

/* EOF */
