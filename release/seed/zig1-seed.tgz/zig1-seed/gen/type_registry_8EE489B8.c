#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
unsigned int const zG_D3698568_TYPE_VOID = (unsigned int)(1);
unsigned int const zG_98A640DA_TYPE_BOOL = (unsigned int)(2);
unsigned int const zG_F9BAA47F_TYPE_NORETURN = (unsigned int)(3);
unsigned int const zG_8A81E76F_TYPE_I8 = (unsigned int)(4);
unsigned int const zG_51905DE6_TYPE_I16 = (unsigned int)(5);
unsigned int const zG_DD95B778_TYPE_I32 = (unsigned int)(6);
unsigned int const zG_518E1F4F_TYPE_I64 = (unsigned int)(7);
unsigned int const zG_023BECD3_TYPE_U8 = (unsigned int)(8);
unsigned int const zG_77674BAA_TYPE_U16 = (unsigned int)(9);
unsigned int const zG_7B6BCF24_TYPE_U32 = (unsigned int)(10);
unsigned int const zG_777894CB_TYPE_U64 = (unsigned int)(11);
unsigned int const zG_5C2F9844_TYPE_ISIZE = (unsigned int)(12);
unsigned int const zG_916E46A8_TYPE_USIZE = (unsigned int)(13);
unsigned int const zG_1E69444C_TYPE_C_CHAR = (unsigned int)(14);
unsigned int const zG_FD27E511_TYPE_F32 = (unsigned int)(15);
unsigned int const zG_712F5772_TYPE_F64 = (unsigned int)(16);
unsigned int const zG_41346447_TYPE_NULL = (unsigned int)(17);
unsigned int const zG_7DF595D2_TYPE_UNDEFINED = (unsigned int)(18);
unsigned int const zG_718E9CA1_TYPE_INT_LIT = (unsigned int)(19);
unsigned int const zG_1E022DA6_TYPE_TYPE = (unsigned int)(20);
unsigned int const zG_A87EA08C_TYPE_VA_LIST = (unsigned int)(21);
unsigned int const zG_4FF9553F_SLICE_FIELD_PTR = (unsigned int)(0);
unsigned int const zG_4B466382_SLICE_FIELD_LEN = (unsigned int)(1);
unsigned int const zG_269BE98A_TU_FIELD_TAG = (unsigned int)(0);
unsigned int const zG_C0257238_TU_FIELD_PAYLOAD = (unsigned int)(1);
unsigned int const zG_C7DB4B56_FIRST_USER_TYPE = (unsigned int)(20);
unsigned char const zG_5FFE6058_VOLATILE_FLAG = (unsigned char)(2);
unsigned char const zG_53F06A4B_CONST_FLAG = (unsigned char)(1);
unsigned char const zG_DFDEC5C8_FN_FLAG_VARIADIC = (unsigned char)(1);
unsigned char const zG_A9D5651E_FN_FLAG_STDCALL = (unsigned char)(2);
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)ubuf) + zT_15;
    zT_17 = (unsigned int)(16) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa((unsigned int)((unsigned int)used), zT_11);
    ulen = zT_19;
    zT_23 = (unsigned int)(15) - (unsigned int)((unsigned int)ulen);
    ustart = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)ubuf) + ustart;
    zT_29 = (unsigned int)(15) - ustart;
    zT_30.ptr = (unsigned char*)zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)nbuf) + zT_44;
    zT_46 = (unsigned int)(16) - zT_44;
    zT_47.ptr = (unsigned char*)zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa((unsigned int)((unsigned int)new_bytes), zT_40);
    nlen = zT_48;
    zT_52 = (unsigned int)(15) - (unsigned int)((unsigned int)nlen);
    nstart = zT_52;
    zT_57 = (unsigned char*)((unsigned char*)nbuf) + nstart;
    zT_58 = (unsigned int)(15) - nstart;
    zT_59.ptr = (unsigned char*)zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_FDFD82FD_EU_362 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_25;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    if ((unsigned char)(zT_6 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_15 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)(elem_size * nc), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zF_9091237C_typeDbOom((unsigned int)(zT_25 * elem_size), (unsigned int)(elem_size * nc));
    return;
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    if ((unsigned char)(i < (unsigned int)(zT_37 * elem_size))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)(new_cap <= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* arrayReserve */
void zF_EC48931A_arrayReserve(unsigned char** items_out, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int cap) {
    zT_3E40CD83_Sand* zT_8;
    zT_FDFD82FD_EU_362 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* raw;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = alloc;
    zT_13 = zF_1395EB68_sandAlloc(zT_8, (unsigned int)(elem_size * cap), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zF_9091237C_typeDbOom((unsigned int)(0), (unsigned int)(elem_size * cap));
    return;
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    *items_out = raw;
    *cap_ptr = cap;
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FDFD82FD_EU_362 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_29;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->types_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(20) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zF_9091237C_typeDbOom((unsigned int)(zT_29 * (unsigned int)(20)), (unsigned int)((unsigned int)(20) * nc));
    return;
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = (zT_D155D06D_Type*)zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_44)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
    z_bb_13:
    zT_49 = i + (unsigned int)(1);
    i = zT_49;
    goto z_bb_10;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zF_BCE30624_typeRegistryEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    self->types_len = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_25 = 0;
    zT_26 = (unsigned char*)((unsigned char*)dc_k) + zT_25;
    zT_27 = (unsigned int)(20) - zT_25;
    zT_28.ptr = (unsigned char*)zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_21), zT_20);
    dc_kl = zT_29;
    zT_33 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_kl);
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_43 = (unsigned char*)((unsigned char*)dc_k) + dc_ks;
    zT_44 = (unsigned int)(19) - dc_ks;
    zT_45.ptr = (unsigned char*)zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_49 = t.name_id;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)dc_n) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_nl);
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = (unsigned char*)zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_72 = (unsigned char*)((unsigned char*)dc_n) + dc_ns;
    zT_73 = (unsigned int)(19) - dc_ns;
    zT_74.ptr = (unsigned char*)zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_82 = 0;
    zT_83 = (unsigned char*)((unsigned char*)dc_i) + zT_82;
    zT_84 = (unsigned int)(20) - zT_82;
    zT_85.ptr = (unsigned char*)zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    zT_90 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_il);
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = (unsigned char*)zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_100 = (unsigned char*)((unsigned char*)dc_i) + dc_is;
    zT_101 = (unsigned int)(19) - dc_is;
    zT_102.ptr = (unsigned char*)zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    if ((unsigned char)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = (unsigned char*)zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_112BF819_PtrPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->ptr_items;
    zT_3 = &self->ptr_len;
    zT_4 = &self->ptr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    self->ptr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->array_items;
    zT_3 = &self->array_len;
    zT_4 = &self->array_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->array_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    self->array_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->slice_items;
    zT_3 = &self->slice_len;
    zT_4 = &self->slice_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    self->slice_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->opt_items;
    zT_3 = &self->opt_len;
    zT_4 = &self->opt_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    self->opt_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->eu_items;
    zT_3 = &self->eu_len;
    zT_4 = &self->eu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    self->eu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->es_items;
    zT_3 = &self->es_len;
    zT_4 = &self->es_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->es_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    self->es_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fn_items;
    zT_3 = &self->fn_len;
    zT_4 = &self->fn_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(24), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    self->fn_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_406493CE_StructPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->st_items;
    zT_3 = &self->st_len;
    zT_4 = &self->st_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->st_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    self->st_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_925BA889_pkStructAppend(zT_24, zT_25);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_struct_items;
    zT_3 = &self->pk_struct_len;
    zT_4 = &self->pk_struct_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_struct_items;
    zT_19 = self->pk_struct_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_struct_len;
    zT_21 = 1;
    self->pk_struct_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E276DDD0_PackedBitField* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_items;
    zT_3 = &self->pk_len;
    zT_4 = &self->pk_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_items;
    zT_19 = self->pk_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_len;
    zT_21 = 1;
    self->pk_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->en_items;
    zT_3 = &self->en_len;
    zT_4 = &self->en_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->en_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    self->en_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->un_items;
    zT_3 = &self->un_len;
    zT_4 = &self->un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    self->un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_96B8622A_pkUnStructAppend(zT_24, zT_25);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_un_items;
    zT_3 = &self->pk_un_len;
    zT_4 = &self->pk_un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_un_items;
    zT_19 = self->pk_un_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_un_len;
    zT_21 = 1;
    self->pk_un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tu_items;
    zT_3 = &self->tu_len;
    zT_4 = &self->tu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    self->tu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tup_items;
    zT_3 = &self->tup_len;
    zT_4 = &self->tup_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    self->tup_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->unr_items;
    zT_3 = &self->unr_len;
    zT_4 = &self->unr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    self->unr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fe_items;
    zT_3 = &self->fe_len;
    zT_4 = &self->fe_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    self->fe_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->em_items;
    zT_3 = &self->em_len;
    zT_4 = &self->em_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->em_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    self->em_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xt_items;
    zT_3 = &self->xt_len;
    zT_4 = &self->xt_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    self->xt_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xn_items;
    zT_3 = &self->xn_len;
    zT_4 = &self->xn_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    self->xn_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_12;
    unsigned char zT_18;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_30;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(8);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(16);
    z_bb_13:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_18 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_21 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(32);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(64);
    z_bb_29:
    return (unsigned char)(0);
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6 = 0;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned short zT_12;
    unsigned int zT_13;
    unsigned short zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    unsigned char p_wb;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    zT_7 = self;
    zT_9.kind = kind;
    zT_10 = 2;
    zT_9.state = zT_10;
    zT_11 = 0;
    zT_9.flags = zT_11;
    zT_9.iw = p_wb;
    zT_9.size = size;
    zT_12 = (unsigned short)alignment;
    zT_9.alignment = zT_12;
    zT_13 = 0;
    zT_9.name_id = zT_13;
    zT_14 = 0;
    zT_9.module_id = zT_14;
    zT_15 = 0;
    zT_9.payload_idx = zT_15;
    zT_8 = zT_9;
    zT_16 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    return zT_16;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    *len = (unsigned int)(0);
    *cap = (unsigned int)(0);
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68 = {0};
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70 = {0};
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72 = {0};
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74 = {0};
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76 = {0};
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78 = {0};
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82 = {0};
    zT_3E40CD83_Sand* zT_83;
    zT_21D3708C_U32ToU32Map zT_84 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = 0;
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zT_61 = 0;
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zT_64 = 0;
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    zT_83 = alloc;
    zT_84 = zF_58BDA2DE_u32ToU32MapInit(zT_83);
    zT_3.c_name_map = zT_84;
    reg = zT_3;
    return reg;
}

/* typeRegistryInitSized */
zT_338B7C76_TypeRegistry zF_28AE6613_typeRegistryInitSiz(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, unsigned int type_hint, unsigned int name_hint) {
    zT_3E40CD83_Sand* zT_5;
    zT_D3EB6303_StringInterner* zT_6;
    zT_338B7C76_TypeRegistry zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_13;
    zT_3E40CD83_Sand* zT_14;
    zT_A4CE86B7_U64ToU32Map zT_18 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_A4CE86B7_U64ToU32Map zT_23 = {0};
    zT_3E40CD83_Sand* zT_24;
    zT_A4CE86B7_U64ToU32Map zT_28 = {0};
    zT_3E40CD83_Sand* zT_29;
    zT_21D3708C_U32ToU32Map zT_33 = {0};
    zT_3E40CD83_Sand* zT_34;
    zT_A4CE86B7_U64ToU32Map zT_38 = {0};
    zT_3E40CD83_Sand* zT_39;
    zT_A4CE86B7_U64ToU32Map zT_42 = {0};
    zT_3E40CD83_Sand* zT_43;
    zT_A4CE86B7_U64ToU32Map zT_46 = {0};
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    zT_A4CE86B7_U64ToU32Map zT_49 = {0};
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned int* zT_54;
    zT_3E40CD83_Sand* zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_112BF819_PtrPayload** zT_59;
    zT_338B7C76_TypeRegistry* zT_61;
    unsigned int* zT_68;
    zT_3E40CD83_Sand* zT_69;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload** zT_73;
    zT_338B7C76_TypeRegistry* zT_75;
    unsigned int* zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_0BB2A741_SlicePayload** zT_87;
    zT_338B7C76_TypeRegistry* zT_89;
    unsigned int* zT_96;
    zT_3E40CD83_Sand* zT_97;
    zT_338B7C76_TypeRegistry* zT_100;
    zT_0B10E8E9_OptionalPayload** zT_101;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned int* zT_110;
    zT_3E40CD83_Sand* zT_111;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_42C2D6BF_EUPayload** zT_115;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int* zT_123;
    zT_3E40CD83_Sand* zT_124;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_0B73C507_ErrorSetPayload** zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    unsigned int* zT_136;
    zT_3E40CD83_Sand* zT_137;
    zT_338B7C76_TypeRegistry* zT_140;
    zT_0317B1D5_FnPayload** zT_141;
    zT_338B7C76_TypeRegistry* zT_143;
    unsigned int* zT_150;
    zT_3E40CD83_Sand* zT_151;
    zT_338B7C76_TypeRegistry* zT_154;
    zT_406493CE_StructPayload** zT_155;
    zT_338B7C76_TypeRegistry* zT_157;
    unsigned int* zT_164;
    zT_3E40CD83_Sand* zT_165;
    zT_338B7C76_TypeRegistry* zT_168;
    zT_457ECFEE_EnumPayload** zT_169;
    zT_338B7C76_TypeRegistry* zT_171;
    unsigned int* zT_177;
    zT_3E40CD83_Sand* zT_178;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_AF9231A2_UnionPayload** zT_182;
    zT_338B7C76_TypeRegistry* zT_184;
    unsigned int* zT_190;
    zT_3E40CD83_Sand* zT_191;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_54FF90FA_TaggedUnionPayload** zT_195;
    zT_338B7C76_TypeRegistry* zT_197;
    unsigned int* zT_203;
    zT_3E40CD83_Sand* zT_204;
    zT_338B7C76_TypeRegistry* zT_207;
    zT_666DC2E1_TuplePayload** zT_208;
    zT_338B7C76_TypeRegistry* zT_210;
    unsigned int* zT_216;
    zT_3E40CD83_Sand* zT_217;
    zT_338B7C76_TypeRegistry* zT_220;
    zT_42E798B0_UnresolvedPayload** zT_221;
    zT_338B7C76_TypeRegistry* zT_223;
    unsigned int* zT_229;
    zT_3E40CD83_Sand* zT_230;
    zT_338B7C76_TypeRegistry* zT_233;
    zT_2DF01B61_FieldEntry** zT_234;
    zT_338B7C76_TypeRegistry* zT_236;
    unsigned int* zT_243;
    zT_3E40CD83_Sand* zT_244;
    zT_338B7C76_TypeRegistry* zT_247;
    zT_D96DCDF2_EnumMember** zT_248;
    zT_338B7C76_TypeRegistry* zT_250;
    unsigned int* zT_257;
    zT_3E40CD83_Sand* zT_258;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    unsigned int** zT_262;
    zT_338B7C76_TypeRegistry* zT_264;
    unsigned int* zT_268;
    zT_3E40CD83_Sand* zT_269;
    zT_338B7C76_TypeRegistry* zT_272;
    unsigned int** zT_273;
    zT_338B7C76_TypeRegistry* zT_275;
    unsigned int* zT_281;
    zT_3E40CD83_Sand* zT_282;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_E276DDD0_PackedBitField** zT_286;
    zT_338B7C76_TypeRegistry* zT_288;
    unsigned int* zT_295;
    zT_3E40CD83_Sand* zT_296;
    zT_338B7C76_TypeRegistry* zT_299;
    zT_FA398D58_PackedStructInfo** zT_300;
    zT_338B7C76_TypeRegistry* zT_302;
    unsigned int* zT_309;
    zT_3E40CD83_Sand* zT_310;
    zT_338B7C76_TypeRegistry* zT_313;
    zT_FA398D58_PackedStructInfo** zT_314;
    zT_338B7C76_TypeRegistry* zT_316;
    zT_338B7C76_TypeRegistry reg;
    unsigned int th;
    unsigned int nh;
    zT_5 = alloc;
    zT_6 = interner;
    zT_7 = zF_4801746C_typeRegistryInit(zT_5, zT_6);
    reg = zT_7;
    zT_9 = (unsigned int)type_hint;
    th = zT_9;
    if ((unsigned char)(th == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return reg;
    z_bb_2:
    zT_13 = (unsigned int)name_hint;
    nh = zT_13;
    zT_14 = alloc;
    zT_18 = zF_CE4144CF_u64ToU32MapInitCap(zT_14, (unsigned int)(th / (unsigned int)(16)));
    reg.ptr_cache = zT_18;
    zT_19 = alloc;
    zT_23 = zF_CE4144CF_u64ToU32MapInitCap(zT_19, (unsigned int)(th / (unsigned int)(64)));
    reg.many_ptr_cache = zT_23;
    zT_24 = alloc;
    zT_28 = zF_CE4144CF_u64ToU32MapInitCap(zT_24, (unsigned int)(th / (unsigned int)(128)));
    reg.slice_cache = zT_28;
    zT_29 = alloc;
    zT_33 = zF_619D56E6_u32ToU32MapInitCap(zT_29, (unsigned int)(th / (unsigned int)(128)));
    reg.optional_cache = zT_33;
    zT_34 = alloc;
    zT_38 = zF_CE4144CF_u64ToU32MapInitCap(zT_34, (unsigned int)(th / (unsigned int)(32)));
    reg.array_cache = zT_38;
    zT_39 = alloc;
    zT_42 = zF_CE4144CF_u64ToU32MapInitCap(zT_39, (unsigned int)(8));
    reg.eu_cache = zT_42;
    zT_43 = alloc;
    zT_46 = zF_CE4144CF_u64ToU32MapInitCap(zT_43, (unsigned int)(4));
    reg.es_cache = zT_46;
    zT_47 = alloc;
    zT_48 = nh;
    zT_49 = zF_CE4144CF_u64ToU32MapInitCap(zT_47, zT_48);
    reg.name_cache = zT_49;
    zT_50 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_51 = th;
    zF_BCE30624_typeRegistryEnsureC(zT_50, zT_51);
    zT_58 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_59 = &zT_58->ptr_items;
    zT_61 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_54 = &zT_61->ptr_cap;
    zT_55 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_59), zT_54, zT_55, (unsigned int)(4), (unsigned int)(th / (unsigned int)(8)));
    zT_72 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_73 = &zT_72->array_items;
    zT_75 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_68 = &zT_75->array_cap;
    zT_69 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_73), zT_68, zT_69, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_86 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_87 = &zT_86->slice_items;
    zT_89 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_82 = &zT_89->slice_cap;
    zT_83 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_87), zT_82, zT_83, (unsigned int)(4), (unsigned int)(th / (unsigned int)(64)));
    zT_100 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_101 = &zT_100->opt_items;
    zT_103 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_96 = &zT_103->opt_cap;
    zT_97 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_101), zT_96, zT_97, (unsigned int)(4), (unsigned int)(th / (unsigned int)(64)));
    zT_114 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_115 = &zT_114->eu_items;
    zT_117 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_110 = &zT_117->eu_cap;
    zT_111 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_115), zT_110, zT_111, (unsigned int)(8), (unsigned int)(16));
    zT_127 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_128 = &zT_127->es_items;
    zT_130 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_123 = &zT_130->es_cap;
    zT_124 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_128), zT_123, zT_124, (unsigned int)(8), (unsigned int)(8));
    zT_140 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_141 = &zT_140->fn_items;
    zT_143 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_136 = &zT_143->fn_cap;
    zT_137 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_141), zT_136, zT_137, (unsigned int)(24), (unsigned int)(th / (unsigned int)(2)));
    zT_154 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_155 = &zT_154->st_items;
    zT_157 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_150 = &zT_157->st_cap;
    zT_151 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_155), zT_150, zT_151, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_168 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_169 = &zT_168->en_items;
    zT_171 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_164 = &zT_171->en_cap;
    zT_165 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_169), zT_164, zT_165, (unsigned int)(16), (unsigned int)(32));
    zT_181 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_182 = &zT_181->un_items;
    zT_184 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_177 = &zT_184->un_cap;
    zT_178 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_182), zT_177, zT_178, (unsigned int)(12), (unsigned int)(8));
    zT_194 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_195 = &zT_194->tu_items;
    zT_197 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_190 = &zT_197->tu_cap;
    zT_191 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_195), zT_190, zT_191, (unsigned int)(12), (unsigned int)(8));
    zT_207 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_208 = &zT_207->tup_items;
    zT_210 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_203 = &zT_210->tup_cap;
    zT_204 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_208), zT_203, zT_204, (unsigned int)(8), (unsigned int)(8));
    zT_220 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_221 = &zT_220->unr_items;
    zT_223 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_216 = &zT_223->unr_cap;
    zT_217 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_221), zT_216, zT_217, (unsigned int)(8), (unsigned int)(8));
    zT_233 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_234 = &zT_233->fe_items;
    zT_236 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_229 = &zT_236->fe_cap;
    zT_230 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_234), zT_229, zT_230, (unsigned int)(12), (unsigned int)(th / (unsigned int)(2)));
    zT_247 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_248 = &zT_247->em_items;
    zT_250 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_243 = &zT_250->em_cap;
    zT_244 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_248), zT_243, zT_244, (unsigned int)(16), (unsigned int)(th / (unsigned int)(16)));
    zT_261 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_262 = &zT_261->xt_items;
    zT_264 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_257 = &zT_264->xt_cap;
    zT_258 = alloc;
    zT_260 = th;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_262), zT_257, zT_258, (unsigned int)(4), zT_260);
    zT_272 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_273 = &zT_272->xn_items;
    zT_275 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_268 = &zT_275->xn_cap;
    zT_269 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_273), zT_268, zT_269, (unsigned int)(4), (unsigned int)(th / (unsigned int)(16)));
    zT_285 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_286 = &zT_285->pk_items;
    zT_288 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_281 = &zT_288->pk_cap;
    zT_282 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_286), zT_281, zT_282, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_299 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_300 = &zT_299->pk_struct_items;
    zT_302 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_295 = &zT_302->pk_struct_cap;
    zT_296 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_300), zT_295, zT_296, (unsigned int)(12), (unsigned int)(th / (unsigned int)(16)));
    zT_313 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_314 = &zT_313->pk_un_items;
    zT_316 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_309 = &zT_316->pk_un_cap;
    zT_310 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_314), zT_309, zT_310, (unsigned int)(12), (unsigned int)(8));
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_9;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    key_lo = zT_9;
    if ((unsigned char)(key_lo == (zT_79FAE712_u64)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = (unsigned char*)zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)np_k) + zT_17;
    zT_19 = (unsigned int)(20) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(65535))), zT_11);
    np_kl = zT_21;
    zT_25 = (unsigned int)(19) - (unsigned int)((unsigned int)np_kl);
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_35 = (unsigned char*)((unsigned char*)np_k) + np_ks;
    zT_36 = (unsigned int)(19) - np_ks;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_45 = 0;
    zT_46 = (unsigned char*)((unsigned char*)np_v) + zT_45;
    zT_47 = (unsigned int)(20) - zT_45;
    zT_48.ptr = (unsigned char*)zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    zT_53 = (unsigned int)(19) - (unsigned int)((unsigned int)np_vl);
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = (unsigned char*)zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_63 = (unsigned char*)((unsigned char*)np_v) + np_vs;
    zT_64 = (unsigned int)(19) - np_vs;
    zT_65.ptr = (unsigned char*)zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryCNameIdGet */
unsigned int zF_41B57F53_typeRegistryCNameId(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_7;
    zT_2 = &self->c_name_map;
    zT_3 = tid;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_7 = 0;
    goto z_bb_3;
    z_bb_2:
    zT_7 = zT_5.value;
    goto z_bb_3;
    z_bb_3:
    return zT_7;
}

/* typeRegistryCNameIdSet */
void zF_6D108807_typeRegistryCNameId(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int c_name_id) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = &self->c_name_map;
    zT_4 = tid;
    zT_5 = c_name_id;
    zF_26476265_u32ToU32MapPut(zT_3, zT_4, zT_5);
    return;
}

/* typeSliceElementName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_28D4FDB0_typeSliceElementNam(zT_338B7C76_TypeRegistry* self, zT_CEC2984A_NameMangler* mangler, unsigned int elem_tid) {
    zT_D155D06D_Type* zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type zT_7;
    unsigned int zT_8;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_CEC2984A_NameMangler* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    zT_CEC2984A_NameMangler* zT_16;
    unsigned int zT_17;
    unsigned int zT_23 = 0;
    zT_D3EB6303_StringInterner* zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27 = {0};
    zT_338B7C76_TypeRegistry* reg;
    zT_D155D06D_Type elem_ty;
    unsigned int elem_mid;
    reg = self;
    zT_5 = reg->types_items;
    zT_6 = (unsigned int)elem_tid;
    zT_7 = zT_5[zT_6];
    elem_ty = zT_7;
    zT_8 = elem_ty.name_id;
    if ((unsigned char)(zT_8 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = reg;
    zT_12 = mangler;
    zT_13 = elem_tid;
    zT_14 = zF_08CFA1F1_typeCName(zT_11, zT_12, zT_13);
    return zT_14;
    z_bb_2:
    zT_16 = mangler;
    zT_17 = elem_ty.name_id;
    zT_23 = zF_713D1938_nameManglerMangle(zT_16, zT_17, (unsigned char)(2), (unsigned int)(0));
    elem_mid = zT_23;
    zT_24 = mangler->interner;
    zT_25 = elem_mid;
    zT_27 = zF_9134020D_stringInternerGet(zT_24, zT_25);
    return zT_27;
}

/* typeCName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08CFA1F1_typeCName(zT_338B7C76_TypeRegistry* self, zT_CEC2984A_NameMangler* mangler, unsigned int tid) {
    zT_D155D06D_Type* zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type zT_7;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_4028D896_Arr_unsigned_char_2 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    int zT_52;
    unsigned char* zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56 = 0;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_33EF6BFB_TypeKind zT_75;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_33EF6BFB_TypeKind zT_89;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_33EF6BFB_TypeKind zT_96;
    unsigned char* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    zT_33EF6BFB_TypeKind zT_103;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    zT_CEC2984A_NameMangler* zT_114;
    unsigned int zT_115;
    unsigned short zT_120;
    unsigned int zT_122 = 0;
    zT_D3EB6303_StringInterner* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126 = {0};
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_33EF6BFB_TypeKind zT_148;
    zT_CEC2984A_NameMangler* zT_152;
    unsigned int zT_153;
    unsigned short zT_158;
    unsigned int zT_160 = 0;
    zT_D3EB6303_StringInterner* zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164 = {0};
    zT_33EF6BFB_TypeKind zT_165;
    unsigned int zT_168;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    zT_338B7C76_TypeRegistry* zT_185;
    zT_CEC2984A_NameMangler* zT_186;
    unsigned int zT_188;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    unsigned int zT_197;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned char* zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_338B7C76_TypeRegistry* zT_214;
    zT_CEC2984A_NameMangler* zT_215;
    unsigned int zT_217;
    unsigned char* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222;
    zT_33EF6BFB_TypeKind zT_223;
    unsigned char* zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    unsigned int zT_229;
    zT_33EF6BFB_TypeKind zT_230;
    zT_CEC2984A_NameMangler* zT_234;
    unsigned int zT_235;
    unsigned short zT_240;
    unsigned int zT_242 = 0;
    zT_D3EB6303_StringInterner* zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246 = {0};
    zT_33EF6BFB_TypeKind zT_247;
    unsigned char* zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_33EF6BFB_TypeKind zT_261;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_33EF6BFB_TypeKind zT_268;
    unsigned char* zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    zT_33EF6BFB_TypeKind zT_275;
    zT_CEC2984A_NameMangler* zT_279;
    unsigned int zT_280;
    unsigned short zT_285;
    unsigned int zT_287 = 0;
    zT_D3EB6303_StringInterner* zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291 = {0};
    zT_33EF6BFB_TypeKind zT_292;
    zT_E834303C_ArrayPayload* zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_E834303C_ArrayPayload zT_299;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_CEC2984A_NameMangler* zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305 = {0};
    zT_5426B97B_Arr_unsigned_char_1 zT_307;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    int zT_314;
    unsigned char* zT_315;
    unsigned int zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    unsigned int zT_318 = 0;
    unsigned int zT_324;
    unsigned char* zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_CEC2984A_NameMangler* zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned char* zT_339;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343 = {0};
    zT_33EF6BFB_TypeKind zT_344;
    zT_5426B97B_Arr_unsigned_char_1 zT_348;
    unsigned int zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    int zT_354;
    unsigned char* zT_355;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_358 = 0;
    unsigned int zT_364;
    unsigned char* zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned int zT_368;
    unsigned char* zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    unsigned int zT_372;
    zT_CEC2984A_NameMangler* zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned char* zT_383;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387 = {0};
    zT_33EF6BFB_TypeKind zT_388;
    unsigned char zT_391;
    zT_33EF6BFB_TypeKind zT_392;
    zT_112BF819_PtrPayload* zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    zT_112BF819_PtrPayload zT_399;
    zT_D155D06D_Type* zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_D155D06D_Type zT_404;
    unsigned char zT_406;
    unsigned char zT_410;
    zT_33EF6BFB_TypeKind zT_411;
    zT_338B7C76_TypeRegistry* zT_414;
    zT_CEC2984A_NameMangler* zT_415;
    unsigned int zT_417;
    unsigned char zT_420;
    unsigned char zT_421;
    unsigned char zT_426;
    zT_33EF6BFB_TypeKind zT_427;
    zT_E834303C_ArrayPayload* zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    zT_E834303C_ArrayPayload zT_434;
    unsigned int zT_435;
    unsigned char* zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    unsigned int zT_441;
    zT_33EF6BFB_TypeKind zT_443;
    unsigned char* zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    unsigned int zT_449;
    zT_33EF6BFB_TypeKind zT_450;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    zT_33EF6BFB_TypeKind zT_457;
    unsigned char* zT_461;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_462;
    unsigned int zT_463;
    zT_33EF6BFB_TypeKind zT_464;
    unsigned char* zT_468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_469;
    unsigned int zT_470;
    zT_33EF6BFB_TypeKind zT_471;
    unsigned char* zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned int zT_477;
    zT_338B7C76_TypeRegistry* zT_479;
    zT_CEC2984A_NameMangler* zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 zT_485;
    int zT_487;
    unsigned int zT_488;
    zT_33EF6BFB_TypeKind zT_490;
    unsigned char zT_493;
    zT_33EF6BFB_TypeKind zT_494;
    unsigned char zT_497;
    unsigned char* zT_500;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_501;
    unsigned int zT_502;
    int zT_504;
    unsigned int zT_505;
    unsigned int zT_507;
    unsigned char zT_509;
    int zT_510;
    unsigned char* zT_512;
    unsigned char zT_513;
    int zT_514;
    unsigned int zT_516;
    int zT_517;
    unsigned int zT_519;
    int zT_521;
    unsigned int zT_522;
    unsigned int zT_524;
    unsigned char zT_526;
    int zT_527;
    unsigned char* zT_529;
    unsigned char zT_530;
    int zT_531;
    unsigned int zT_533;
    int zT_534;
    unsigned int zT_536;
    unsigned char zT_537;
    unsigned char* zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    unsigned int zT_541;
    int zT_543;
    unsigned int zT_544;
    unsigned int zT_546;
    unsigned char zT_548;
    int zT_549;
    unsigned char* zT_551;
    unsigned char zT_552;
    int zT_553;
    unsigned int zT_555;
    int zT_556;
    unsigned int zT_558;
    unsigned char zT_559;
    int zT_560;
    unsigned int zT_562;
    int zT_563;
    unsigned char zT_564;
    int zT_565;
    unsigned int zT_567;
    zT_D3EB6303_StringInterner* zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_570;
    int zT_576;
    unsigned char* zT_577;
    unsigned int zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    unsigned int zT_580 = 0;
    zT_D3EB6303_StringInterner* zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584 = {0};
    zT_33EF6BFB_TypeKind zT_585;
    unsigned char* zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    zT_33EF6BFB_TypeKind zT_592;
    unsigned char* zT_596;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_597;
    unsigned int zT_598;
    zT_33EF6BFB_TypeKind zT_599;
    unsigned char* zT_603;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_604;
    unsigned int zT_605;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_606;
    unsigned char* zT_608;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_609;
    unsigned int zT_610;
    zT_33EF6BFB_TypeKind zT_611;
    zT_0BB2A741_SlicePayload* zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    zT_0BB2A741_SlicePayload zT_618;
    zT_338B7C76_TypeRegistry* zT_620;
    zT_CEC2984A_NameMangler* zT_621;
    unsigned int zT_622;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_624 = {0};
    unsigned char* zT_626;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_627;
    unsigned int zT_628;
    unsigned char* zT_630;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_631;
    unsigned int zT_632;
    zT_CEC2984A_NameMangler* zT_633;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_635;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_639 = {0};
    zT_33EF6BFB_TypeKind zT_640;
    zT_0B10E8E9_OptionalPayload* zT_644;
    unsigned int zT_645;
    unsigned int zT_646;
    zT_0B10E8E9_OptionalPayload zT_647;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_649;
    unsigned int zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    int zT_656;
    unsigned char* zT_657;
    unsigned int zT_658;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_659;
    unsigned int zT_660 = 0;
    unsigned int zT_664;
    unsigned char* zT_666;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_667;
    unsigned int zT_668;
    unsigned char* zT_670;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_671;
    unsigned int zT_672;
    zT_CEC2984A_NameMangler* zT_673;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_674;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_676;
    unsigned char* zT_681;
    unsigned int zT_682;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_685 = {0};
    zT_338B7C76_TypeRegistry* zT_687;
    unsigned int zT_688;
    unsigned int zT_689 = 0;
    int zT_690;
    zT_D3EB6303_StringInterner* zT_692;
    unsigned int zT_693;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_695 = {0};
    zT_33EF6BFB_TypeKind zT_696;
    zT_42C2D6BF_EUPayload* zT_700;
    unsigned int zT_701;
    unsigned int zT_702;
    zT_42C2D6BF_EUPayload zT_703;
    zT_C41F1B06_Arr_unsigned_char_6 zT_705;
    unsigned int zT_707;
    unsigned char* zT_709;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_710;
    unsigned int zT_711;
    unsigned int zT_713;
    unsigned int zT_715;
    unsigned char zT_717;
    unsigned char* zT_720;
    unsigned char zT_721;
    unsigned int zT_723;
    unsigned int zT_725;
    unsigned int zT_727;
    unsigned char zT_731;
    unsigned char zT_737;
    unsigned int zT_739;
    unsigned int zT_743;
    zT_CEC2984A_NameMangler* zT_745;
    unsigned int zT_746;
    zT_D3EB6303_StringInterner* zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    int zT_754;
    unsigned char* zT_755;
    unsigned int zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758 = 0;
    unsigned int zT_761 = 0;
    zT_338B7C76_TypeRegistry* zT_762;
    unsigned int zT_763;
    unsigned int zT_764;
    zT_D3EB6303_StringInterner* zT_765;
    unsigned int zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_768 = {0};
    zT_33EF6BFB_TypeKind zT_769;
    zT_0317B1D5_FnPayload* zT_773;
    unsigned int zT_774;
    unsigned int zT_775;
    zT_0317B1D5_FnPayload zT_776;
    zT_443A2803_Arr_unsigned_char_9 zT_778;
    unsigned int zT_780;
    unsigned char zT_781;
    int zT_782;
    unsigned char zT_783;
    int zT_784;
    unsigned char zT_785;
    unsigned char zT_790;
    int zT_791;
    unsigned char zT_792;
    unsigned char zT_794;
    unsigned char zT_797;
    int zT_798;
    unsigned char zT_799;
    int zT_800;
    unsigned int zT_801;
    zT_338B7C76_TypeRegistry* zT_803;
    zT_CEC2984A_NameMangler* zT_804;
    unsigned int zT_805;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_807 = {0};
    unsigned int zT_809;
    unsigned int zT_811;
    unsigned char zT_813;
    unsigned char* zT_817;
    unsigned char zT_818;
    unsigned char zT_821;
    unsigned char zT_824;
    unsigned int zT_826;
    unsigned int zT_828;
    unsigned short zT_830;
    unsigned int zT_832;
    unsigned int zT_835;
    unsigned int zT_836;
    unsigned int zT_839;
    unsigned int zT_840;
    unsigned char zT_842;
    unsigned char zT_847;
    unsigned int zT_849;
    unsigned int* zT_851;
    unsigned int zT_852;
    zT_338B7C76_TypeRegistry* zT_854;
    zT_CEC2984A_NameMangler* zT_855;
    unsigned int zT_856;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_857 = {0};
    unsigned int zT_859;
    unsigned int zT_861;
    unsigned char zT_863;
    unsigned char* zT_867;
    unsigned char zT_868;
    unsigned char zT_871;
    unsigned char zT_874;
    unsigned int zT_876;
    unsigned int zT_878;
    unsigned int zT_880;
    zT_D3EB6303_StringInterner* zT_882;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_883;
    int zT_887;
    unsigned char* zT_888;
    unsigned int zT_889;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_890;
    unsigned int zT_891 = 0;
    zT_CEC2984A_NameMangler* zT_893;
    unsigned int zT_894;
    unsigned int zT_899 = 0;
    zT_338B7C76_TypeRegistry* zT_900;
    unsigned int zT_901;
    unsigned int zT_902;
    zT_D3EB6303_StringInterner* zT_903;
    unsigned int zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_906 = {0};
    zT_33EF6BFB_TypeKind zT_907;
    unsigned int zT_910;
    zT_C41F1B06_Arr_unsigned_char_6 zT_914;
    unsigned int zT_916;
    unsigned char* zT_918;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_919;
    unsigned int zT_920;
    unsigned int zT_922;
    unsigned int zT_924;
    unsigned char zT_926;
    unsigned char* zT_929;
    unsigned char zT_930;
    unsigned int zT_932;
    unsigned int zT_934;
    unsigned int zT_936;
    unsigned int zT_937;
    unsigned char zT_941;
    unsigned char zT_947;
    unsigned int zT_949;
    unsigned int zT_953;
    zT_CEC2984A_NameMangler* zT_955;
    unsigned int zT_956;
    zT_D3EB6303_StringInterner* zT_959;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_960;
    int zT_964;
    unsigned char* zT_965;
    unsigned int zT_966;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_967;
    unsigned int zT_968 = 0;
    unsigned int zT_971 = 0;
    zT_338B7C76_TypeRegistry* zT_972;
    unsigned int zT_973;
    unsigned int zT_974;
    zT_D3EB6303_StringInterner* zT_975;
    unsigned int zT_976;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_978 = {0};
    zT_CEC2984A_NameMangler* zT_980;
    unsigned int zT_981;
    unsigned short zT_986;
    unsigned int zT_988 = 0;
    zT_338B7C76_TypeRegistry* zT_989;
    unsigned int zT_990;
    unsigned int zT_991;
    zT_D3EB6303_StringInterner* zT_992;
    unsigned int zT_993;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_995 = {0};
    zT_CEC2984A_NameMangler* zT_997;
    unsigned int zT_998;
    unsigned short zT_1003;
    unsigned int zT_1005 = 0;
    zT_338B7C76_TypeRegistry* zT_1006;
    unsigned int zT_1007;
    unsigned int zT_1008;
    zT_D3EB6303_StringInterner* zT_1009;
    unsigned int zT_1010;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1012 = {0};
    zT_338B7C76_TypeRegistry* reg;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6m;
    zT_4028D896_Arr_unsigned_char_2 d6tb;
    unsigned int d6tl;
    unsigned int d6ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6kn;
    zT_4028D896_Arr_unsigned_char_2 d6kb;
    unsigned int d6kl;
    unsigned int d6ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6nn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int mid;
    zT_E834303C_ArrayPayload ap;
    zT_8F083A69_Slice_zT_0B42B2F8_u e_cname;
    zT_5426B97B_Arr_unsigned_char_1 a_dig;
    unsigned int a_dl;
    unsigned int a_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u a_pref;
    zT_5426B97B_Arr_unsigned_char_1 t_dig;
    unsigned int t_dl;
    unsigned int t_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u t_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u t_pref;
    zT_112BF819_PtrPayload pp;
    zT_D155D06D_Type et;
    unsigned char is_vol;
    zT_E834303C_ArrayPayload sc_ap;
    zT_8F083A69_Slice_zT_0B42B2F8_u base_cname;
    zT_C4003E6D_Arr_unsigned_char_1 pbuf;
    unsigned int bi;
    unsigned char et_is_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vpx;
    unsigned int vpi;
    unsigned int bcj;
    zT_8F083A69_Slice_zT_0B42B2F8_u vpx2;
    unsigned int vpi2;
    unsigned int ptr_mid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nul_m;
    zT_0BB2A741_SlicePayload sp;
    zT_8F083A69_Slice_zT_0B42B2F8_u elem_mangled2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_pref;
    zT_0B10E8E9_OptionalPayload op;
    zT_5A26C2ED_Arr_unsigned_char_1 o_dig;
    unsigned int o_dl;
    unsigned int o_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u o_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u o_pref;
    unsigned int c_nid;
    zT_42C2D6BF_EUPayload ep;
    zT_C41F1B06_Arr_unsigned_char_6 buf;
    unsigned int p;
    zT_8F083A69_Slice_zT_0B42B2F8_u pref;
    unsigned int pi;
    unsigned int pl;
    unsigned int di;
    unsigned int eu_nid;
    zT_0317B1D5_FnPayload fpp;
    zT_443A2803_Arr_unsigned_char_9 fbuf;
    unsigned int fpos;
    zT_8F083A69_Slice_zT_0B42B2F8_u fret_c;
    unsigned int fri;
    unsigned char fc;
    unsigned short fpcnt;
    unsigned int fpend;
    unsigned int fpcur;
    unsigned int fp_nid;
    unsigned int fp_mid;
    unsigned int fptid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fp_c;
    unsigned int fpj;
    unsigned char fc2;
    unsigned int es_nid;
    z_bb_0:
    reg = self;
    zT_5 = reg->types_items;
    zT_6 = (unsigned int)tid;
    zT_7 = zT_5[zT_6];
    ty = zT_7;
    if ((unsigned char)(tid >= (unsigned int)(20))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = "D6:";
    zT_13 = 3;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    d6m = zT_12;
    zT_14 = d6m;
    zF_48AC7B3A_markerWrite(zT_14);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_16[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d6tb[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = tid;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)d6tb) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = (unsigned char*)zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    d6tl = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)d6tl);
    d6ts = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)d6tb) + d6ts;
    zT_36 = (unsigned int)(19) - d6ts;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = "k";
    zT_41 = 1;
    zT_40.ptr = (unsigned char*)zT_39;
    zT_40.len = zT_41;
    d6kn = zT_40;
    zT_42 = d6kn;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d6kb[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ty.kind;
    zT_52 = 0;
    zT_53 = (unsigned char*)((unsigned char*)d6kb) + zT_52;
    zT_54 = (unsigned int)(20) - zT_52;
    zT_55.ptr = (unsigned char*)zT_53;
    zT_55.len = zT_54;
    zT_47 = zT_55;
    zT_56 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_48), zT_47);
    d6kl = zT_56;
    zT_60 = (unsigned int)(19) - (unsigned int)((unsigned int)d6kl);
    d6ks = zT_60;
    zT_65 = (unsigned char*)((unsigned char*)d6kb) + d6ks;
    zT_66 = (unsigned int)(19) - d6ks;
    zT_67.ptr = (unsigned char*)zT_65;
    zT_67.len = zT_66;
    zT_61 = zT_67;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_69 = "n";
    zT_71 = 1;
    zT_70.ptr = (unsigned char*)zT_69;
    zT_70.len = zT_71;
    d6nn = zT_70;
    zT_72 = d6nn;
    zT_73 = ty.name_id;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    goto z_bb_2;
    z_bb_2:
    zT_75 = ty.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_79 = "void";
    zT_81 = 4;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    s = zT_80;
    return s;
    z_bb_4:
    zT_82 = ty.kind;
    if ((unsigned char)(zT_82 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_86 = "unsigned char";
    zT_88 = 13;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    s = zT_87;
    return s;
    z_bb_6:
    zT_89 = ty.kind;
    if ((unsigned char)(zT_89 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_93 = "signed char";
    zT_95 = 11;
    zT_94.ptr = (unsigned char*)zT_93;
    zT_94.len = zT_95;
    s = zT_94;
    return s;
    z_bb_8:
    zT_96 = ty.kind;
    if ((unsigned char)(zT_96 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_100 = "short";
    zT_102 = 5;
    zT_101.ptr = (unsigned char*)zT_100;
    zT_101.len = zT_102;
    s = zT_101;
    return s;
    z_bb_10:
    zT_103 = ty.kind;
    if ((unsigned char)(zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_107 = "int";
    zT_109 = 3;
    zT_108.ptr = (unsigned char*)zT_107;
    zT_108.len = zT_109;
    s = zT_108;
    return s;
    z_bb_12:
    zT_110 = ty.kind;
    if ((unsigned char)(zT_110 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_114 = mangler;
    zT_115 = ty.name_id;
    zT_120 = ty.module_id;
    zT_122 = zF_713D1938_nameManglerMangle(zT_114, zT_115, (unsigned char)(2), (unsigned int)((unsigned int)zT_120));
    mid = zT_122;
    zT_123 = mangler->interner;
    zT_124 = mid;
    zT_126 = zF_9134020D_stringInternerGet(zT_123, zT_124);
    return zT_126;
    z_bb_14:
    zT_127 = ty.kind;
    if ((unsigned char)(zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_131 = "unsigned char";
    zT_133 = 13;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    s = zT_132;
    return s;
    z_bb_16:
    zT_134 = ty.kind;
    if ((unsigned char)(zT_134 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_138 = "unsigned short";
    zT_140 = 14;
    zT_139.ptr = (unsigned char*)zT_138;
    zT_139.len = zT_140;
    s = zT_139;
    return s;
    z_bb_18:
    zT_141 = ty.kind;
    if ((unsigned char)(zT_141 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_145 = "unsigned int";
    zT_147 = 12;
    zT_146.ptr = (unsigned char*)zT_145;
    zT_146.len = zT_147;
    s = zT_146;
    return s;
    z_bb_20:
    zT_148 = ty.kind;
    if ((unsigned char)(zT_148 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_152 = mangler;
    zT_153 = ty.name_id;
    zT_158 = ty.module_id;
    zT_160 = zF_713D1938_nameManglerMangle(zT_152, zT_153, (unsigned char)(2), (unsigned int)((unsigned int)zT_158));
    mid = zT_160;
    zT_161 = mangler->interner;
    zT_162 = mid;
    zT_164 = zF_9134020D_stringInternerGet(zT_161, zT_162);
    return zT_164;
    z_bb_22:
    zT_165 = ty.kind;
    if ((unsigned char)(zT_165 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_168 = ty.size;
    if ((unsigned char)(zT_168 == (unsigned int)(2))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    zT_172 = "unsigned short";
    zT_174 = 14;
    zT_173.ptr = (unsigned char*)zT_172;
    zT_173.len = zT_174;
    s = zT_173;
    return s;
    z_bb_26:
    zT_175 = ty.size;
    if ((unsigned char)(zT_175 == (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_179 = "unsigned int";
    zT_181 = 12;
    zT_180.ptr = (unsigned char*)zT_179;
    zT_180.len = zT_181;
    s = zT_180;
    return s;
    z_bb_28:
    zT_182 = ty.size;
    if ((unsigned char)(zT_182 == (unsigned int)(8))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_185 = reg;
    zT_186 = mangler;
    zT_188 = 11;
    self = zT_185;
    mangler = zT_186;
    tid = zT_188;
    goto z_bb_0;
    z_bb_30:
    zT_191 = "unsigned char";
    zT_193 = 13;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    s = zT_192;
    return s;
    z_bb_31:
    zT_197 = ty.size;
    if ((unsigned char)(zT_197 == (unsigned int)(2))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_223 = ty.kind;
    if ((unsigned char)(zT_223 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_33:
    zT_201 = "short";
    zT_203 = 5;
    zT_202.ptr = (unsigned char*)zT_201;
    zT_202.len = zT_203;
    s = zT_202;
    return s;
    z_bb_34:
    zT_204 = ty.size;
    if ((unsigned char)(zT_204 == (unsigned int)(4))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_208 = "int";
    zT_210 = 3;
    zT_209.ptr = (unsigned char*)zT_208;
    zT_209.len = zT_210;
    s = zT_209;
    return s;
    z_bb_36:
    zT_211 = ty.size;
    if ((unsigned char)(zT_211 == (unsigned int)(8))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_214 = reg;
    zT_215 = mangler;
    zT_217 = 7;
    self = zT_214;
    mangler = zT_215;
    tid = zT_217;
    goto z_bb_0;
    z_bb_38:
    zT_220 = "signed char";
    zT_222 = 11;
    zT_221.ptr = (unsigned char*)zT_220;
    zT_221.len = zT_222;
    s = zT_221;
    return s;
    z_bb_39:
    zT_227 = "float";
    zT_229 = 5;
    zT_228.ptr = (unsigned char*)zT_227;
    zT_228.len = zT_229;
    s = zT_228;
    return s;
    z_bb_40:
    zT_230 = ty.kind;
    if ((unsigned char)(zT_230 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_234 = mangler;
    zT_235 = ty.name_id;
    zT_240 = ty.module_id;
    zT_242 = zF_713D1938_nameManglerMangle(zT_234, zT_235, (unsigned char)(2), (unsigned int)((unsigned int)zT_240));
    mid = zT_242;
    zT_243 = mangler->interner;
    zT_244 = mid;
    zT_246 = zF_9134020D_stringInternerGet(zT_243, zT_244);
    return zT_246;
    z_bb_42:
    zT_247 = ty.kind;
    if ((unsigned char)(zT_247 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_251 = "unsigned int";
    zT_253 = 12;
    zT_252.ptr = (unsigned char*)zT_251;
    zT_252.len = zT_253;
    s = zT_252;
    return s;
    z_bb_44:
    zT_254 = ty.kind;
    if ((unsigned char)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_258 = "int";
    zT_260 = 3;
    zT_259.ptr = (unsigned char*)zT_258;
    zT_259.len = zT_260;
    s = zT_259;
    return s;
    z_bb_46:
    zT_261 = ty.kind;
    if ((unsigned char)(zT_261 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_265 = "char";
    zT_267 = 4;
    zT_266.ptr = (unsigned char*)zT_265;
    zT_266.len = zT_267;
    s = zT_266;
    return s;
    z_bb_48:
    zT_268 = ty.kind;
    if ((unsigned char)(zT_268 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_272 = "va_list";
    zT_274 = 7;
    zT_273.ptr = (unsigned char*)zT_272;
    zT_273.len = zT_274;
    s = zT_273;
    return s;
    z_bb_50:
    zT_275 = ty.kind;
    if ((unsigned char)(zT_275 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_279 = mangler;
    zT_280 = ty.name_id;
    zT_285 = ty.module_id;
    zT_287 = zF_713D1938_nameManglerMangle(zT_279, zT_280, (unsigned char)(2), (unsigned int)((unsigned int)zT_285));
    mid = zT_287;
    zT_288 = mangler->interner;
    zT_289 = mid;
    zT_291 = zF_9134020D_stringInternerGet(zT_288, zT_289);
    return zT_291;
    z_bb_52:
    zT_292 = ty.kind;
    if ((unsigned char)(zT_292 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_296 = reg->array_items;
    zT_297 = ty.payload_idx;
    zT_298 = (unsigned int)zT_297;
    zT_299 = zT_296[zT_298];
    ap = zT_299;
    zT_301 = reg;
    zT_302 = mangler;
    zT_303 = ap.elem;
    zT_305 = zF_08CFA1F1_typeCName(zT_301, zT_302, zT_303);
    e_cname = zT_305;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_307[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        a_dig[_i] = zT_307[_i];
        _i++;
    }
}
    zT_309 = ap.length;
    zT_314 = 0;
    zT_315 = (unsigned char*)((unsigned char*)a_dig) + zT_314;
    zT_316 = (unsigned int)(16) - zT_314;
    zT_317.ptr = (unsigned char*)zT_315;
    zT_317.len = zT_316;
    zT_310 = zT_317;
    zT_318 = zF_A7504564_itoa(zT_309, zT_310);
    a_dl = zT_318;
    zT_324 = (unsigned int)(15) - (unsigned int)((unsigned int)a_dl);
    a_ds = zT_324;
    zT_326 = "Arr_";
    zT_328 = 4;
    zT_327.ptr = (unsigned char*)zT_326;
    zT_327.len = zT_328;
    a_pref = zT_327;
    zT_329 = mangler;
    zT_330 = a_pref;
    zT_331 = e_cname;
    zT_339 = (unsigned char*)((unsigned char*)a_dig) + a_ds;
    zT_340 = (unsigned int)(15) - a_ds;
    zT_341.ptr = (unsigned char*)zT_339;
    zT_341.len = zT_340;
    zT_332 = zT_341;
    zT_343 = zF_9DABAED9_nameManglerMintSynt(zT_329, zT_330, zT_331, zT_332, (unsigned int)(127));
    return zT_343;
    z_bb_54:
    zT_344 = ty.kind;
    if ((unsigned char)(zT_344 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_348[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        t_dig[_i] = zT_348[_i];
        _i++;
    }
}
    zT_350 = tid;
    zT_354 = 0;
    zT_355 = (unsigned char*)((unsigned char*)t_dig) + zT_354;
    zT_356 = (unsigned int)(16) - zT_354;
    zT_357.ptr = (unsigned char*)zT_355;
    zT_357.len = zT_356;
    zT_351 = zT_357;
    zT_358 = zF_A7504564_itoa(zT_350, zT_351);
    t_dl = zT_358;
    zT_364 = (unsigned int)(15) - (unsigned int)((unsigned int)t_dl);
    t_ds = zT_364;
    zT_366 = "";
    zT_368 = 0;
    zT_367.ptr = (unsigned char*)zT_366;
    zT_367.len = zT_368;
    t_empty = zT_367;
    zT_370 = "Tup_";
    zT_372 = 4;
    zT_371.ptr = (unsigned char*)zT_370;
    zT_371.len = zT_372;
    t_pref = zT_371;
    zT_373 = mangler;
    zT_374 = t_pref;
    zT_375 = t_empty;
    zT_383 = (unsigned char*)((unsigned char*)t_dig) + t_ds;
    zT_384 = (unsigned int)(15) - t_ds;
    zT_385.ptr = (unsigned char*)zT_383;
    zT_385.len = zT_384;
    zT_376 = zT_385;
    zT_387 = zF_9DABAED9_nameManglerMintSynt(zT_373, zT_374, zT_375, zT_376, (unsigned int)(31));
    return zT_387;
    z_bb_56:
    zT_388 = ty.kind;
    if ((unsigned char)(zT_388 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_392 = ty.kind;
    zT_391 = zT_392 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_59;
    z_bb_58:
    zT_391 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_391) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_396 = reg->ptr_items;
    zT_397 = ty.payload_idx;
    zT_398 = (unsigned int)zT_397;
    zT_399 = zT_396[zT_398];
    pp = zT_399;
    zT_401 = reg->types_items;
    zT_402 = pp.base;
    zT_403 = (unsigned int)zT_402;
    zT_404 = zT_401[zT_403];
    et = zT_404;
    zT_406 = ty.flags;
    zT_410 = (unsigned char)(zT_406 & (unsigned char)(2)) != (unsigned char)(0);
    is_vol = zT_410;
    zT_411 = et.kind;
    if ((unsigned char)(zT_411 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_585 = ty.kind;
    if ((unsigned char)(zT_585 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_120; else goto z_bb_121;
    z_bb_62:
    zT_414 = reg;
    zT_415 = mangler;
    zT_417 = pp.base;
    self = zT_414;
    mangler = zT_415;
    tid = zT_417;
    goto z_bb_0;
    z_bb_63:
    if ((unsigned char)(!is_vol)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_421 = ty.flags;
    zT_420 = (unsigned char)(zT_421 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_66;
    z_bb_65:
    zT_420 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_420) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_427 = et.kind;
    zT_426 = zT_427 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_69;
    z_bb_68:
    zT_426 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_426) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_431 = reg->array_items;
    zT_432 = et.payload_idx;
    zT_433 = (unsigned int)zT_432;
    zT_434 = zT_431[zT_433];
    sc_ap = zT_434;
    zT_435 = sc_ap.elem;
    if ((unsigned char)(zT_435 == (unsigned int)(8))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    if ((unsigned char)(!is_vol)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_439 = "unsigned char*";
    zT_441 = 14;
    zT_440.ptr = (unsigned char*)zT_439;
    zT_440.len = zT_441;
    s = zT_440;
    return s;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_443 = et.kind;
    if ((unsigned char)(zT_443 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_479 = reg;
    zT_480 = mangler;
    zT_481 = pp.base;
    zT_483 = zF_08CFA1F1_typeCName(zT_479, zT_480, zT_481);
    base_cname = zT_483;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_485[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        pbuf[_i] = zT_485[_i];
        _i++;
    }
}
    zT_487 = 0;
    zT_488 = (unsigned int)zT_487;
    bi = zT_488;
    zT_490 = et.kind;
    if ((unsigned char)(zT_490 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_87; else goto z_bb_86;
    z_bb_76:
    zT_447 = "unsigned char*";
    zT_449 = 14;
    zT_448.ptr = (unsigned char*)zT_447;
    zT_448.len = zT_449;
    s = zT_448;
    return s;
    z_bb_77:
    zT_450 = et.kind;
    if ((unsigned char)(zT_450 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_454 = "unsigned int*";
    zT_456 = 13;
    zT_455.ptr = (unsigned char*)zT_454;
    zT_455.len = zT_456;
    s = zT_455;
    return s;
    z_bb_79:
    zT_457 = et.kind;
    if ((unsigned char)(zT_457 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_461 = "int*";
    zT_463 = 4;
    zT_462.ptr = (unsigned char*)zT_461;
    zT_462.len = zT_463;
    s = zT_462;
    return s;
    z_bb_81:
    zT_464 = et.kind;
    if ((unsigned char)(zT_464 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_468 = "char*";
    zT_470 = 5;
    zT_469.ptr = (unsigned char*)zT_468;
    zT_469.len = zT_470;
    s = zT_469;
    return s;
    z_bb_83:
    zT_471 = et.kind;
    if ((unsigned char)(zT_471 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_475 = "unsigned int*";
    zT_477 = 13;
    zT_476.ptr = (unsigned char*)zT_475;
    zT_476.len = zT_477;
    s = zT_476;
    return s;
    z_bb_85:
    goto z_bb_75;
    z_bb_86:
    zT_494 = et.kind;
    zT_493 = zT_494 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_88;
    z_bb_87:
    zT_493 = 1;
    goto z_bb_88;
    z_bb_88:
    et_is_ptr = zT_493;
    if (is_vol) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_497 = !et_is_ptr;
    goto z_bb_91;
    z_bb_90:
    zT_497 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_497) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_500 = "volatile ";
    zT_502 = 9;
    zT_501.ptr = (unsigned char*)zT_500;
    zT_501.len = zT_502;
    vpx = zT_501;
    zT_504 = 0;
    zT_505 = (unsigned int)zT_504;
    vpi = zT_505;
    goto z_bb_94;
    z_bb_93:
    zT_521 = 0;
    zT_522 = (unsigned int)zT_521;
    bcj = zT_522;
    goto z_bb_101;
    z_bb_94:
    zT_507 = vpx.len;
    if ((unsigned char)(vpi < zT_507)) goto z_bb_98; else goto z_bb_99;
    z_bb_95:
    zT_512 = vpx.ptr;
    zT_513 = zT_512[vpi];
    pbuf[bi] = zT_513;
    zT_514 = 1;
    zT_516 = bi + (unsigned int)((unsigned int)zT_514);
    bi = zT_516;
    goto z_bb_97;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_517 = 1;
    zT_519 = vpi + (unsigned int)((unsigned int)zT_517);
    vpi = zT_519;
    goto z_bb_94;
    z_bb_98:
    zT_510 = 126;
    zT_509 = bi < (unsigned int)zT_510;
    goto z_bb_100;
    z_bb_99:
    zT_509 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_509) goto z_bb_95; else goto z_bb_96;
    z_bb_101:
    zT_524 = base_cname.len;
    if ((unsigned char)(bcj < zT_524)) goto z_bb_105; else goto z_bb_106;
    z_bb_102:
    zT_529 = base_cname.ptr;
    zT_530 = zT_529[bcj];
    pbuf[bi] = zT_530;
    zT_531 = 1;
    zT_533 = bi + (unsigned int)((unsigned int)zT_531);
    bi = zT_533;
    goto z_bb_104;
    z_bb_103:
    if (is_vol) goto z_bb_108; else goto z_bb_109;
    z_bb_104:
    zT_534 = 1;
    zT_536 = bcj + (unsigned int)((unsigned int)zT_534);
    bcj = zT_536;
    goto z_bb_101;
    z_bb_105:
    zT_527 = 126;
    zT_526 = bi < (unsigned int)zT_527;
    goto z_bb_107;
    z_bb_106:
    zT_526 = 0;
    goto z_bb_107;
    z_bb_107:
    if (zT_526) goto z_bb_102; else goto z_bb_103;
    z_bb_108:
    zT_537 = et_is_ptr;
    goto z_bb_110;
    z_bb_109:
    zT_537 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_537) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_539 = " volatile";
    zT_541 = 9;
    zT_540.ptr = (unsigned char*)zT_539;
    zT_540.len = zT_541;
    vpx2 = zT_540;
    zT_543 = 0;
    zT_544 = (unsigned int)zT_543;
    vpi2 = zT_544;
    goto z_bb_113;
    z_bb_112:
    zT_559 = 42;
    pbuf[bi] = zT_559;
    zT_560 = 1;
    zT_562 = bi + (unsigned int)((unsigned int)zT_560);
    bi = zT_562;
    zT_563 = 0;
    zT_564 = (unsigned char)zT_563;
    pbuf[bi] = zT_564;
    zT_565 = 1;
    zT_567 = bi + (unsigned int)((unsigned int)zT_565);
    bi = zT_567;
    zT_569 = mangler->interner;
    zT_576 = 0;
    zT_577 = (unsigned char*)((unsigned char*)pbuf) + zT_576;
    zT_578 = (unsigned int)(bi - (unsigned int)(1)) - zT_576;
    zT_579.ptr = (unsigned char*)zT_577;
    zT_579.len = zT_578;
    zT_570 = zT_579;
    zT_580 = zF_50C274AF_stringInternerInter(zT_569, zT_570);
    ptr_mid = zT_580;
    zT_581 = mangler->interner;
    zT_582 = ptr_mid;
    zT_584 = zF_9134020D_stringInternerGet(zT_581, zT_582);
    return zT_584;
    z_bb_113:
    zT_546 = vpx2.len;
    if ((unsigned char)(vpi2 < zT_546)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_551 = vpx2.ptr;
    zT_552 = zT_551[vpi2];
    pbuf[bi] = zT_552;
    zT_553 = 1;
    zT_555 = bi + (unsigned int)((unsigned int)zT_553);
    bi = zT_555;
    goto z_bb_116;
    z_bb_115:
    goto z_bb_112;
    z_bb_116:
    zT_556 = 1;
    zT_558 = vpi2 + (unsigned int)((unsigned int)zT_556);
    vpi2 = zT_558;
    goto z_bb_113;
    z_bb_117:
    zT_549 = 126;
    zT_548 = bi < (unsigned int)zT_549;
    goto z_bb_119;
    z_bb_118:
    zT_548 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_548) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    zT_589 = "int";
    zT_591 = 3;
    zT_590.ptr = (unsigned char*)zT_589;
    zT_590.len = zT_591;
    s = zT_590;
    return s;
    z_bb_121:
    zT_592 = ty.kind;
    if ((unsigned char)(zT_592 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_596 = "int";
    zT_598 = 3;
    zT_597.ptr = (unsigned char*)zT_596;
    zT_597.len = zT_598;
    s = zT_597;
    return s;
    z_bb_123:
    zT_599 = ty.kind;
    if ((unsigned char)(zT_599 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_603 = "NUL:TYnul ";
    zT_605 = 10;
    zT_604.ptr = (unsigned char*)zT_603;
    zT_604.len = zT_605;
    nul_m = zT_604;
    zT_606 = nul_m;
    zF_48AC7B3A_markerWrite(zT_606);
    zT_608 = "int";
    zT_610 = 3;
    zT_609.ptr = (unsigned char*)zT_608;
    zT_609.len = zT_610;
    s = zT_609;
    return s;
    z_bb_125:
    zT_611 = ty.kind;
    if ((unsigned char)(zT_611 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_615 = reg->slice_items;
    zT_616 = ty.payload_idx;
    zT_617 = (unsigned int)zT_616;
    zT_618 = zT_615[zT_617];
    sp = zT_618;
    zT_620 = reg;
    zT_621 = mangler;
    zT_622 = sp.elem;
    zT_624 = zF_28D4FDB0_typeSliceElementNam(zT_620, zT_621, zT_622);
    elem_mangled2 = zT_624;
    zT_626 = "";
    zT_628 = 0;
    zT_627.ptr = (unsigned char*)zT_626;
    zT_627.len = zT_628;
    s_empty = zT_627;
    zT_630 = "Slice_";
    zT_632 = 6;
    zT_631.ptr = (unsigned char*)zT_630;
    zT_631.len = zT_632;
    s_pref = zT_631;
    zT_633 = mangler;
    zT_634 = s_pref;
    zT_635 = elem_mangled2;
    zT_636 = s_empty;
    zT_639 = zF_9DABAED9_nameManglerMintSynt(zT_633, zT_634, zT_635, zT_636, (unsigned int)(63));
    return zT_639;
    z_bb_127:
    zT_640 = ty.kind;
    if ((unsigned char)(zT_640 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_644 = reg->opt_items;
    zT_645 = ty.payload_idx;
    zT_646 = (unsigned int)zT_645;
    zT_647 = zT_644[zT_646];
    op = zT_647;
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_649[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        o_dig[_i] = zT_649[_i];
        _i++;
    }
}
    zT_651 = op.payload;
    zT_656 = 0;
    zT_657 = (unsigned char*)((unsigned char*)o_dig) + zT_656;
    zT_658 = (unsigned int)(10) - zT_656;
    zT_659.ptr = (unsigned char*)zT_657;
    zT_659.len = zT_658;
    zT_652 = zT_659;
    zT_660 = zF_A7504564_itoa(zT_651, zT_652);
    o_dl = zT_660;
    zT_664 = (unsigned int)(9) - (unsigned int)((unsigned int)o_dl);
    o_ds = zT_664;
    zT_666 = "";
    zT_668 = 0;
    zT_667.ptr = (unsigned char*)zT_666;
    zT_667.len = zT_668;
    o_empty = zT_667;
    zT_670 = "Opt_";
    zT_672 = 4;
    zT_671.ptr = (unsigned char*)zT_670;
    zT_671.len = zT_672;
    o_pref = zT_671;
    zT_673 = mangler;
    zT_674 = o_pref;
    zT_675 = o_empty;
    zT_681 = (unsigned char*)((unsigned char*)o_dig) + o_ds;
    zT_682 = (unsigned int)(9) - o_ds;
    zT_683.ptr = (unsigned char*)zT_681;
    zT_683.len = zT_682;
    zT_676 = zT_683;
    zT_685 = zF_9DABAED9_nameManglerMintSynt(zT_673, zT_674, zT_675, zT_676, (unsigned int)(63));
    return zT_685;
    z_bb_129:
    zT_687 = reg;
    zT_688 = tid;
    zT_689 = zF_41B57F53_typeRegistryCNameId(zT_687, zT_688);
    c_nid = zT_689;
    zT_690 = 0;
    if ((unsigned char)(c_nid != (unsigned int)zT_690)) goto z_bb_130; else goto z_bb_131;
    z_bb_130:
    zT_692 = mangler->interner;
    zT_693 = c_nid;
    zT_695 = zF_9134020D_stringInternerGet(zT_692, zT_693);
    return zT_695;
    z_bb_131:
    zT_696 = ty.kind;
    if ((unsigned char)(zT_696 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_132; else goto z_bb_133;
    z_bb_132:
    zT_700 = reg->eu_items;
    zT_701 = ty.payload_idx;
    zT_702 = (unsigned int)zT_701;
    zT_703 = zT_700[zT_702];
    ep = zT_703;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_705[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_705[_i];
        _i++;
    }
}
    zT_707 = 0;
    p = zT_707;
    zT_709 = "EU_";
    zT_711 = 3;
    zT_710.ptr = (unsigned char*)zT_709;
    zT_710.len = zT_711;
    pref = zT_710;
    zT_713 = 0;
    pi = zT_713;
    goto z_bb_134;
    z_bb_133:
    zT_769 = ty.kind;
    if ((unsigned char)(zT_769 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_150; else goto z_bb_151;
    z_bb_134:
    zT_715 = pref.len;
    if ((unsigned char)(pi < zT_715)) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    zT_720 = pref.ptr;
    zT_721 = zT_720[pi];
    buf[p] = zT_721;
    zT_723 = p + (unsigned int)(1);
    p = zT_723;
    goto z_bb_137;
    z_bb_136:
    zT_727 = ep.payload;
    pl = zT_727;
    di = p;
    goto z_bb_141;
    z_bb_137:
    zT_725 = pi + (unsigned int)(1);
    pi = zT_725;
    goto z_bb_134;
    z_bb_138:
    zT_717 = p < (unsigned int)(63);
    goto z_bb_140;
    z_bb_139:
    zT_717 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_717) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    if ((unsigned char)(pl > (unsigned int)(0))) goto z_bb_146; else goto z_bb_145;
    z_bb_142:
    zT_737 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(pl % (unsigned int)(10)));
    buf[di] = zT_737;
    zT_739 = pl / (unsigned int)(10);
    pl = zT_739;
    if ((unsigned char)(di >= (unsigned int)(63))) goto z_bb_148; else goto z_bb_149;
    z_bb_143:
    p = di;
    zT_745 = mangler;
    zT_749 = mangler->interner;
    zT_754 = 0;
    zT_755 = (unsigned char*)((unsigned char*)buf) + zT_754;
    zT_756 = p - zT_754;
    zT_757.ptr = (unsigned char*)zT_755;
    zT_757.len = zT_756;
    zT_750 = zT_757;
    zT_758 = zF_50C274AF_stringInternerInter(zT_749, zT_750);
    zT_746 = zT_758;
    zT_761 = zF_713D1938_nameManglerMangle(zT_745, zT_746, (unsigned char)(2), (unsigned int)(0));
    eu_nid = zT_761;
    zT_762 = reg;
    zT_763 = tid;
    zT_764 = eu_nid;
    zF_6D108807_typeRegistryCNameId(zT_762, zT_763, zT_764);
    zT_765 = mangler->interner;
    zT_766 = eu_nid;
    zT_768 = zF_9134020D_stringInternerGet(zT_765, zT_766);
    return zT_768;
    z_bb_144:
    zT_743 = di + (unsigned int)(1);
    di = zT_743;
    goto z_bb_141;
    z_bb_145:
    zT_731 = di == p;
    goto z_bb_147;
    z_bb_146:
    zT_731 = 1;
    goto z_bb_147;
    z_bb_147:
    if (zT_731) goto z_bb_142; else goto z_bb_143;
    z_bb_148:
    goto z_bb_143;
    z_bb_149:
    goto z_bb_144;
    z_bb_150:
    zT_773 = reg->fn_items;
    zT_774 = ty.payload_idx;
    zT_775 = (unsigned int)zT_774;
    zT_776 = zT_773[zT_775];
    fpp = zT_776;
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_778[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fbuf[_i] = zT_778[_i];
        _i++;
    }
}
    zT_780 = 0;
    fpos = zT_780;
    zT_781 = 70;
    zT_782 = 0;
    fbuf[zT_782] = zT_781;
    zT_783 = 95;
    zT_784 = 2;
    fbuf[zT_784] = zT_783;
    zT_785 = fpp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_785 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_152; else goto z_bb_154;
    z_bb_151:
    zT_907 = ty.kind;
    if ((unsigned char)(zT_907 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_152:
    zT_790 = 83;
    zT_791 = 1;
    fbuf[zT_791] = zT_790;
    goto z_bb_153;
    z_bb_153:
    zT_801 = 3;
    fpos = zT_801;
    zT_803 = reg;
    zT_804 = mangler;
    zT_805 = fpp.return_type;
    zT_807 = zF_08CFA1F1_typeCName(zT_803, zT_804, zT_805);
    fret_c = zT_807;
    zT_809 = 0;
    fri = zT_809;
    goto z_bb_158;
    z_bb_154:
    zT_792 = ty.flags;
    zT_794 = zT_792 & (unsigned int)(1);
    if ((unsigned char)(zT_794 != (unsigned int)(0))) goto z_bb_155; else goto z_bb_157;
    z_bb_155:
    zT_797 = 80;
    zT_798 = 1;
    fbuf[zT_798] = zT_797;
    goto z_bb_156;
    z_bb_156:
    goto z_bb_153;
    z_bb_157:
    zT_799 = 78;
    zT_800 = 1;
    fbuf[zT_800] = zT_799;
    goto z_bb_156;
    z_bb_158:
    zT_811 = fret_c.len;
    if ((unsigned char)(fri < zT_811)) goto z_bb_162; else goto z_bb_163;
    z_bb_159:
    zT_817 = fret_c.ptr;
    zT_818 = zT_817[fri];
    fc = zT_818;
    if ((unsigned char)(fc == (unsigned char)(32))) goto z_bb_166; else goto z_bb_165;
    z_bb_160:
    zT_830 = fpp.params_count;
    fpcnt = zT_830;
    zT_832 = fpp.params_start;
    zT_835 = (unsigned int)((unsigned int)zT_832) + (unsigned int)((unsigned int)fpcnt);
    fpend = zT_835;
    zT_836 = reg->xt_len;
    if ((unsigned char)(fpend <= zT_836)) goto z_bb_170; else goto z_bb_171;
    z_bb_161:
    zT_828 = fri + (unsigned int)(1);
    fri = zT_828;
    goto z_bb_158;
    z_bb_162:
    zT_813 = fpos < (unsigned int)(95);
    goto z_bb_164;
    z_bb_163:
    zT_813 = 0;
    goto z_bb_164;
    z_bb_164:
    if (zT_813) goto z_bb_159; else goto z_bb_160;
    z_bb_165:
    zT_821 = fc == (unsigned char)(42);
    goto z_bb_167;
    z_bb_166:
    zT_821 = 1;
    goto z_bb_167;
    z_bb_167:
    if (zT_821) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_824 = 95;
    fc = zT_824;
    goto z_bb_169;
    z_bb_169:
    fbuf[fpos] = fc;
    zT_826 = fpos + (unsigned int)(1);
    fpos = zT_826;
    goto z_bb_161;
    z_bb_170:
    zT_839 = fpp.params_start;
    zT_840 = (unsigned int)zT_839;
    fpcur = zT_840;
    goto z_bb_172;
    z_bb_171:
    zT_882 = mangler->interner;
    zT_887 = 0;
    zT_888 = (unsigned char*)((unsigned char*)fbuf) + zT_887;
    zT_889 = fpos - zT_887;
    zT_890.ptr = (unsigned char*)zT_888;
    zT_890.len = zT_889;
    zT_883 = zT_890;
    zT_891 = zF_50C274AF_stringInternerInter(zT_882, zT_883);
    fp_nid = zT_891;
    zT_893 = mangler;
    zT_894 = fp_nid;
    zT_899 = zF_713D1938_nameManglerMangle(zT_893, zT_894, (unsigned char)(2), (unsigned int)(0));
    fp_mid = zT_899;
    zT_900 = reg;
    zT_901 = tid;
    zT_902 = fp_mid;
    zF_6D108807_typeRegistryCNameId(zT_900, zT_901, zT_902);
    zT_903 = mangler->interner;
    zT_904 = fp_mid;
    zT_906 = zF_9134020D_stringInternerGet(zT_903, zT_904);
    return zT_906;
    z_bb_172:
    if ((unsigned char)(fpcur < fpend)) goto z_bb_176; else goto z_bb_177;
    z_bb_173:
    if ((unsigned char)(fpos < (unsigned int)(95))) goto z_bb_179; else goto z_bb_180;
    z_bb_174:
    goto z_bb_171;
    z_bb_175:
    zT_880 = fpcur + (unsigned int)(1);
    fpcur = zT_880;
    goto z_bb_172;
    z_bb_176:
    zT_842 = fpos < (unsigned int)(95);
    goto z_bb_178;
    z_bb_177:
    zT_842 = 0;
    goto z_bb_178;
    z_bb_178:
    if (zT_842) goto z_bb_173; else goto z_bb_174;
    z_bb_179:
    zT_847 = 95;
    fbuf[fpos] = zT_847;
    zT_849 = fpos + (unsigned int)(1);
    fpos = zT_849;
    goto z_bb_180;
    z_bb_180:
    zT_851 = reg->xt_items;
    zT_852 = zT_851[fpcur];
    fptid = zT_852;
    zT_854 = reg;
    zT_855 = mangler;
    zT_856 = fptid;
    zT_857 = zF_08CFA1F1_typeCName(zT_854, zT_855, zT_856);
    fp_c = zT_857;
    zT_859 = 0;
    fpj = zT_859;
    goto z_bb_181;
    z_bb_181:
    zT_861 = fp_c.len;
    if ((unsigned char)(fpj < zT_861)) goto z_bb_185; else goto z_bb_186;
    z_bb_182:
    zT_867 = fp_c.ptr;
    zT_868 = zT_867[fpj];
    fc2 = zT_868;
    if ((unsigned char)(fc2 == (unsigned char)(32))) goto z_bb_189; else goto z_bb_188;
    z_bb_183:
    goto z_bb_175;
    z_bb_184:
    zT_878 = fpj + (unsigned int)(1);
    fpj = zT_878;
    goto z_bb_181;
    z_bb_185:
    zT_863 = fpos < (unsigned int)(95);
    goto z_bb_187;
    z_bb_186:
    zT_863 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_863) goto z_bb_182; else goto z_bb_183;
    z_bb_188:
    zT_871 = fc2 == (unsigned char)(42);
    goto z_bb_190;
    z_bb_189:
    zT_871 = 1;
    goto z_bb_190;
    z_bb_190:
    if (zT_871) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_874 = 95;
    fc2 = zT_874;
    goto z_bb_192;
    z_bb_192:
    fbuf[fpos] = fc2;
    zT_876 = fpos + (unsigned int)(1);
    fpos = zT_876;
    goto z_bb_184;
    z_bb_193:
    zT_910 = ty.name_id;
    if ((unsigned char)(zT_910 == (unsigned int)(0))) goto z_bb_195; else goto z_bb_196;
    z_bb_194:
    zT_997 = mangler;
    zT_998 = ty.name_id;
    zT_1003 = ty.module_id;
    zT_1005 = zF_713D1938_nameManglerMangle(zT_997, zT_998, (unsigned char)(2), (unsigned int)((unsigned int)zT_1003));
    mid = zT_1005;
    zT_1006 = reg;
    zT_1007 = tid;
    zT_1008 = mid;
    zF_6D108807_typeRegistryCNameId(zT_1006, zT_1007, zT_1008);
    zT_1009 = mangler->interner;
    zT_1010 = mid;
    zT_1012 = zF_9134020D_stringInternerGet(zT_1009, zT_1010);
    return zT_1012;
    z_bb_195:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_914[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_914[_i];
        _i++;
    }
}
    zT_916 = 0;
    p = zT_916;
    zT_918 = "ES_";
    zT_920 = 3;
    zT_919.ptr = (unsigned char*)zT_918;
    zT_919.len = zT_920;
    pref = zT_919;
    zT_922 = 0;
    pi = zT_922;
    goto z_bb_197;
    z_bb_196:
    zT_980 = mangler;
    zT_981 = ty.name_id;
    zT_986 = ty.module_id;
    zT_988 = zF_713D1938_nameManglerMangle(zT_980, zT_981, (unsigned char)(2), (unsigned int)((unsigned int)zT_986));
    mid = zT_988;
    zT_989 = reg;
    zT_990 = tid;
    zT_991 = mid;
    zF_6D108807_typeRegistryCNameId(zT_989, zT_990, zT_991);
    zT_992 = mangler->interner;
    zT_993 = mid;
    zT_995 = zF_9134020D_stringInternerGet(zT_992, zT_993);
    return zT_995;
    z_bb_197:
    zT_924 = pref.len;
    if ((unsigned char)(pi < zT_924)) goto z_bb_201; else goto z_bb_202;
    z_bb_198:
    zT_929 = pref.ptr;
    zT_930 = zT_929[pi];
    buf[p] = zT_930;
    zT_932 = p + (unsigned int)(1);
    p = zT_932;
    goto z_bb_200;
    z_bb_199:
    zT_936 = ty.payload_idx;
    zT_937 = (unsigned int)zT_936;
    pl = zT_937;
    di = p;
    goto z_bb_204;
    z_bb_200:
    zT_934 = pi + (unsigned int)(1);
    pi = zT_934;
    goto z_bb_197;
    z_bb_201:
    zT_926 = p < (unsigned int)(63);
    goto z_bb_203;
    z_bb_202:
    zT_926 = 0;
    goto z_bb_203;
    z_bb_203:
    if (zT_926) goto z_bb_198; else goto z_bb_199;
    z_bb_204:
    if ((unsigned char)(pl > (unsigned int)(0))) goto z_bb_209; else goto z_bb_208;
    z_bb_205:
    zT_947 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(pl % (unsigned int)(10)));
    buf[di] = zT_947;
    zT_949 = pl / (unsigned int)(10);
    pl = zT_949;
    if ((unsigned char)(di >= (unsigned int)(63))) goto z_bb_211; else goto z_bb_212;
    z_bb_206:
    p = di;
    zT_955 = mangler;
    zT_959 = mangler->interner;
    zT_964 = 0;
    zT_965 = (unsigned char*)((unsigned char*)buf) + zT_964;
    zT_966 = p - zT_964;
    zT_967.ptr = (unsigned char*)zT_965;
    zT_967.len = zT_966;
    zT_960 = zT_967;
    zT_968 = zF_50C274AF_stringInternerInter(zT_959, zT_960);
    zT_956 = zT_968;
    zT_971 = zF_713D1938_nameManglerMangle(zT_955, zT_956, (unsigned char)(2), (unsigned int)(0));
    es_nid = zT_971;
    zT_972 = reg;
    zT_973 = tid;
    zT_974 = es_nid;
    zF_6D108807_typeRegistryCNameId(zT_972, zT_973, zT_974);
    zT_975 = mangler->interner;
    zT_976 = es_nid;
    zT_978 = zF_9134020D_stringInternerGet(zT_975, zT_976);
    return zT_978;
    z_bb_207:
    zT_953 = di + (unsigned int)(1);
    di = zT_953;
    goto z_bb_204;
    z_bb_208:
    zT_941 = di == p;
    goto z_bb_210;
    z_bb_209:
    zT_941 = 1;
    goto z_bb_210;
    z_bb_210:
    if (zT_941) goto z_bb_205; else goto z_bb_206;
    z_bb_211:
    goto z_bb_206;
    z_bb_212:
    goto z_bb_207;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_0C0306D6_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreatePtrQ */
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned short zT_33;
    unsigned int zT_34;
    unsigned short zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_41;
    zT_79FAE712_u64 zT_42;
    unsigned int zT_43;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.iw = zT_31;
    zT_32 = 4;
    zT_27.size = zT_32;
    zT_33 = 4;
    zT_27.alignment = zT_33;
    zT_34 = 0;
    zT_27.name_id = zT_34;
    zT_35 = 0;
    zT_27.module_id = zT_35;
    zT_36 = self->ptr_len;
    zT_39 = (unsigned int)(unsigned int)(zT_36 - (unsigned int)(1));
    zT_27.payload_idx = zT_39;
    zT_26 = zT_27;
    zT_40 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_40;
    zT_41 = &self->ptr_cache;
    zT_42 = key;
    zT_43 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_41, zT_42, zT_43);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_827207A1_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreateManyPtrQ */
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned short zT_33;
    unsigned int zT_34;
    unsigned short zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_41;
    zT_79FAE712_u64 zT_42;
    unsigned int zT_43;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->many_ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.iw = zT_31;
    zT_32 = 4;
    zT_27.size = zT_32;
    zT_33 = 4;
    zT_27.alignment = zT_33;
    zT_34 = 0;
    zT_27.name_id = zT_34;
    zT_35 = 0;
    zT_27.module_id = zT_35;
    zT_36 = self->ptr_len;
    zT_39 = (unsigned int)(unsigned int)(zT_36 - (unsigned int)(1));
    zT_27.payload_idx = zT_39;
    zT_26 = zT_27;
    zT_40 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_40;
    zT_41 = &self->many_ptr_cache;
    zT_42 = key;
    zT_43 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_41, zT_42, zT_43);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned char is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    unsigned char zT_112;
    int zT_113;
    int zT_115;
    unsigned char zT_117;
    unsigned char zT_118;
    unsigned int zT_119;
    unsigned short zT_120;
    unsigned int zT_121;
    unsigned short zT_122;
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_127 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_128;
    zT_79FAE712_u64 zT_129;
    unsigned int zT_130;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_4028D896_Arr_unsigned_char_2 zT_138;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    int zT_144;
    unsigned char* zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned char* zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    zT_4028D896_Arr_unsigned_char_2 zT_166;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    int zT_172;
    unsigned char* zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176 = 0;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned char* zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_4028D896_Arr_unsigned_char_2 zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    int zT_201;
    unsigned char* zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205 = 0;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned char* zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    zT_11 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(1)) | ic;
    key = zT_11;
    zT_12 = &self->slice_cache;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = (unsigned char*)zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_30 = 0;
    zT_31 = (unsigned char*)((unsigned char*)u2h_eb) + zT_30;
    zT_32 = (unsigned int)(20) - zT_30;
    zT_33.ptr = (unsigned char*)zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    zT_38 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_el);
    u2h_es = zT_38;
    zT_43 = (unsigned char*)((unsigned char*)u2h_eb) + u2h_es;
    zT_44 = (unsigned int)(19) - u2h_es;
    zT_45.ptr = (unsigned char*)zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)u2h_rb) + zT_58;
    zT_60 = (unsigned int)(20) - zT_58;
    zT_61.ptr = (unsigned char*)zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    zT_66 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_rl);
    u2h_rs = zT_66;
    zT_71 = (unsigned char*)((unsigned char*)u2h_rb) + u2h_rs;
    zT_72 = (unsigned int)(19) - u2h_rs;
    zT_73.ptr = (unsigned char*)zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_87 = 0;
    zT_88 = (unsigned char*)((unsigned char*)u2h_cb) + zT_87;
    zT_89 = (unsigned int)(20) - zT_87;
    zT_90.ptr = (unsigned char*)zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_83);
    u2h_cl = zT_91;
    zT_95 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_cl);
    u2h_cs = zT_95;
    zT_100 = (unsigned char*)((unsigned char*)u2h_cb) + u2h_cs;
    zT_101 = (unsigned int)(19) - u2h_cs;
    zT_102.ptr = (unsigned char*)zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = (unsigned char)zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_115 = 0;
    zT_112 = (unsigned char)zT_115;
    goto z_bb_8;
    z_bb_8:
    zT_117 = (unsigned char)zT_112;
    zT_109.flags = zT_117;
    zT_118 = 0;
    zT_109.iw = zT_118;
    zT_119 = 8;
    zT_109.size = zT_119;
    zT_120 = 4;
    zT_109.alignment = zT_120;
    zT_121 = 0;
    zT_109.name_id = zT_121;
    zT_122 = 0;
    zT_109.module_id = zT_122;
    zT_123 = self->slice_len;
    zT_126 = (unsigned int)(unsigned int)(zT_123 - (unsigned int)(1));
    zT_109.payload_idx = zT_126;
    zT_108 = zT_109;
    zT_127 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_127;
    zT_128 = &self->slice_cache;
    zT_129 = key;
    zT_130 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_128, zT_129, zT_130);
    zT_133 = "U2N:e";
    zT_135 = 5;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    u2n_m = zT_134;
    zT_136 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_136);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_138[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_138[_i];
        _i++;
    }
}
    zT_140 = elem;
    zT_144 = 0;
    zT_145 = (unsigned char*)((unsigned char*)u2n_eb) + zT_144;
    zT_146 = (unsigned int)(20) - zT_144;
    zT_147.ptr = (unsigned char*)zT_145;
    zT_147.len = zT_146;
    zT_141 = zT_147;
    zT_148 = zF_A7504564_itoa(zT_140, zT_141);
    u2n_el = zT_148;
    zT_152 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_el);
    u2n_es = zT_152;
    zT_157 = (unsigned char*)((unsigned char*)u2n_eb) + u2n_es;
    zT_158 = (unsigned int)(19) - u2n_es;
    zT_159.ptr = (unsigned char*)zT_157;
    zT_159.len = zT_158;
    zT_153 = zT_159;
    zF_48AC7B3A_markerWrite(zT_153);
    zT_161 = "r";
    zT_163 = 1;
    zT_162.ptr = (unsigned char*)zT_161;
    zT_162.len = zT_163;
    u2n_rm = zT_162;
    zT_164 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_164);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_166[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_166[_i];
        _i++;
    }
}
    zT_168 = tid;
    zT_172 = 0;
    zT_173 = (unsigned char*)((unsigned char*)u2n_rb) + zT_172;
    zT_174 = (unsigned int)(20) - zT_172;
    zT_175.ptr = (unsigned char*)zT_173;
    zT_175.len = zT_174;
    zT_169 = zT_175;
    zT_176 = zF_A7504564_itoa(zT_168, zT_169);
    u2n_rl = zT_176;
    zT_180 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_rl);
    u2n_rs = zT_180;
    zT_185 = (unsigned char*)((unsigned char*)u2n_rb) + u2n_rs;
    zT_186 = (unsigned int)(19) - u2n_rs;
    zT_187.ptr = (unsigned char*)zT_185;
    zT_187.len = zT_186;
    zT_181 = zT_187;
    zF_48AC7B3A_markerWrite(zT_181);
    zT_189 = "c";
    zT_191 = 1;
    zT_190.ptr = (unsigned char*)zT_189;
    zT_190.len = zT_191;
    u2n_cm = zT_190;
    zT_192 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_192);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_194[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_194[_i];
        _i++;
    }
}
    zT_201 = 0;
    zT_202 = (unsigned char*)((unsigned char*)u2n_cb) + zT_201;
    zT_203 = (unsigned int)(20) - zT_201;
    zT_204.ptr = (unsigned char*)zT_202;
    zT_204.len = zT_203;
    zT_197 = zT_204;
    zT_205 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_197);
    u2n_cl = zT_205;
    zT_209 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_cl);
    u2n_cs = zT_209;
    zT_214 = (unsigned char*)((unsigned char*)u2n_cb) + u2n_cs;
    zT_215 = (unsigned int)(19) - u2n_cs;
    zT_216.ptr = (unsigned char*)zT_214;
    zT_216.len = zT_215;
    zT_210 = zT_216;
    zF_48AC7B3A_markerWrite(zT_210);
    return tid;
}

/* optionalCompleteIfReady */
void zF_B75A61E8_optionalCompleteIfR(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_0B10E8E9_OptionalPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0B10E8E9_OptionalPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned short zT_33;
    unsigned int zT_37;
    unsigned short zT_38;
    unsigned int zT_42;
    unsigned int zT_46 = 0;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    zT_D155D06D_Type ty;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pay_type;
    unsigned int pay_align;
    unsigned int opt_size;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->opt_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->opt_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    op = zT_20;
    zT_21 = op.payload;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = op.payload;
    zT_28 = zT_26[zT_27];
    pay_type = zT_28;
    zT_29 = pay_type.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_33 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_33) > (unsigned int)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = pay_type.alignment;
    zT_37 = (unsigned int)zT_38;
    goto z_bb_13;
    z_bb_12:
    zT_37 = 4;
    goto z_bb_13;
    z_bb_13:
    pay_align = zT_37;
    zT_42 = pay_type.size;
    zT_46 = zF_D2BAC673_alignUp(zT_42, (unsigned int)(4));
    zT_48 = zT_46 + (unsigned int)(4);
    opt_size = zT_48;
    zT_49 = opt_size;
    zT_50 = pay_align;
    zT_51 = zF_D2BAC673_alignUp(zT_49, zT_50);
    opt_size = zT_51;
    ty.size = opt_size;
    ty.alignment = (unsigned short)((unsigned short)pay_align);
    ty.state = (unsigned char)(2);
    zT_54 = self->types_items;
    zT_55 = (unsigned int)tid;
    zT_54[zT_55] = ty;
    return;
}

/* errorUnionCompleteIfReady */
void zF_35E259CB_errorUnionCompleteI(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_42C2D6BF_EUPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_42C2D6BF_EUPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned short zT_40;
    unsigned int zT_44;
    unsigned short zT_45;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    unsigned int zT_52;
    unsigned int zT_55 = 0;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60 = 0;
    zT_D155D06D_Type* zT_63;
    unsigned int zT_64;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eup;
    zT_D155D06D_Type pay_type;
    unsigned int union_size;
    unsigned int union_align;
    unsigned int total;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->eu_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->eu_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    eup = zT_20;
    zT_21 = eup.payload;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = eup.payload;
    zT_28 = zT_26[zT_27];
    pay_type = zT_28;
    zT_29 = pay_type.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_33 = pay_type.size;
    if ((unsigned char)(zT_33 > (unsigned int)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_36 = pay_type.size;
    goto z_bb_13;
    z_bb_12:
    zT_36 = 4;
    goto z_bb_13;
    z_bb_13:
    union_size = zT_36;
    zT_40 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_40) > (unsigned int)(4))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = pay_type.alignment;
    zT_44 = (unsigned int)zT_45;
    goto z_bb_16;
    z_bb_15:
    zT_44 = 4;
    goto z_bb_16;
    z_bb_16:
    union_align = zT_44;
    zT_49 = union_size;
    zT_50 = union_align;
    zT_51 = zF_D2BAC673_alignUp(zT_49, zT_50);
    total = zT_51;
    zT_52 = total;
    zT_55 = zF_D2BAC673_alignUp(zT_52, (unsigned int)(4));
    zT_57 = zT_55 + (unsigned int)(4);
    total = zT_57;
    zT_58 = total;
    zT_59 = union_align;
    zT_60 = zF_D2BAC673_alignUp(zT_58, zT_59);
    ty.size = zT_60;
    ty.alignment = (unsigned short)((unsigned short)union_align);
    ty.state = (unsigned char)(2);
    zT_63 = self->types_items;
    zT_64 = (unsigned int)tid;
    zT_63[zT_64] = ty;
    return;
}

/* arrayCompleteIfReady */
void zF_C173376D_arrayCompleteIfRead(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E834303C_ArrayPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_E834303C_ArrayPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned short zT_35;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    zT_D155D06D_Type ty;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type elem_ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->array_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->array_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    ap = zT_20;
    zT_21 = ap.elem;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = ap.elem;
    zT_28 = zT_26[zT_27];
    elem_ty = zT_28;
    zT_29 = elem_ty.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_32 = elem_ty.size;
    zT_33 = ap.length;
    ty.size = (unsigned int)(zT_32 * zT_33);
    zT_35 = elem_ty.alignment;
    ty.alignment = zT_35;
    ty.state = (unsigned char)(2);
    zT_37 = self->types_items;
    zT_38 = (unsigned int)tid;
    zT_37[zT_38] = ty;
    return;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_11;
    zT_D155D06D_Type zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned short zT_26;
    unsigned int zT_30;
    unsigned short zT_31;
    unsigned int zT_34;
    unsigned int zT_38 = 0;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43 = 0;
    unsigned char zT_44;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_0B10E8E9_OptionalPayload zT_46;
    zT_0B10E8E9_OptionalPayload zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_D155D06D_Type zT_50;
    zT_D155D06D_Type zT_51;
    zT_33EF6BFB_TypeKind zT_52;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned short zT_55;
    unsigned int zT_56;
    unsigned short zT_57;
    unsigned int zT_58;
    unsigned int zT_61;
    unsigned int zT_62 = 0;
    zT_21D3708C_U32ToU32Map* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_2 = &self->optional_cache;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    zT_8 = self;
    zT_9 = existing;
    zF_B75A61E8_optionalCompleteIfR(zT_8, zT_9);
    return existing;
    z_bb_2:
    zT_11 = self->types_items;
    zT_12 = zT_11[payload];
    pay_type = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    opt_size = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    opt_align = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned char)zT_20;
    opt_state = zT_21;
    zT_22 = pay_type.state;
    if ((unsigned char)(zT_22 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_26) > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_45 = self;
    zT_47.payload = payload;
    zT_46 = zT_47;
    zF_4569340E_optAppend(zT_45, zT_46);
    zT_49 = self;
    zT_52 = zT_33EF6BFB_TypeKind_optional_type;
    zT_51.kind = zT_52;
    zT_51.state = opt_state;
    zT_53 = 0;
    zT_51.flags = zT_53;
    zT_54 = 0;
    zT_51.iw = zT_54;
    zT_51.size = opt_size;
    zT_55 = (unsigned short)opt_align;
    zT_51.alignment = zT_55;
    zT_56 = 0;
    zT_51.name_id = zT_56;
    zT_57 = 0;
    zT_51.module_id = zT_57;
    zT_58 = self->opt_len;
    zT_61 = (unsigned int)(unsigned int)(zT_58 - (unsigned int)(1));
    zT_51.payload_idx = zT_61;
    zT_50 = zT_51;
    zT_62 = zF_D4993F02_typeRegistryAppend(zT_49, zT_50);
    tid = zT_62;
    zT_63 = &self->optional_cache;
    zT_64 = payload;
    zT_65 = tid;
    zF_26476265_u32ToU32MapPut(zT_63, zT_64, zT_65);
    return tid;
    z_bb_5:
    zT_31 = pay_type.alignment;
    zT_30 = (unsigned int)zT_31;
    goto z_bb_7;
    z_bb_6:
    zT_30 = 4;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_30;
    zT_34 = pay_type.size;
    zT_38 = zF_D2BAC673_alignUp(zT_34, (unsigned int)(4));
    zT_40 = zT_38 + (unsigned int)(4);
    opt_size = zT_40;
    zT_41 = opt_size;
    zT_42 = pay_align;
    zT_43 = zF_D2BAC673_alignUp(zT_41, zT_42);
    opt_size = zT_43;
    opt_align = pay_align;
    zT_44 = 2;
    opt_state = zT_44;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type* zT_18;
    zT_D155D06D_Type zT_19;
    int zT_21;
    unsigned int zT_22;
    int zT_24;
    unsigned int zT_25;
    int zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned short zT_40;
    unsigned int zT_44;
    unsigned short zT_45;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    unsigned int zT_52;
    unsigned int zT_55 = 0;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60 = 0;
    unsigned char zT_61;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_42C2D6BF_EUPayload zT_63;
    zT_42C2D6BF_EUPayload zT_64;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_D155D06D_Type zT_67;
    zT_D155D06D_Type zT_68;
    zT_33EF6BFB_TypeKind zT_69;
    unsigned char zT_70;
    unsigned char zT_71;
    unsigned short zT_72;
    unsigned int zT_73;
    unsigned short zT_74;
    unsigned int zT_75;
    unsigned int zT_78;
    unsigned int zT_79 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_80;
    zT_79FAE712_u64 zT_81;
    unsigned int zT_82;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_8 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)payload) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)error_set);
    eu_key = zT_8;
    zT_9 = &self->eu_cache;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    zT_15 = self;
    zT_16 = existing;
    zF_35E259CB_errorUnionCompleteI(zT_15, zT_16);
    return existing;
    z_bb_2:
    zT_18 = self->types_items;
    zT_19 = zT_18[payload];
    pay_type = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    eu_size = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    eu_align = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned char)zT_27;
    eu_state = zT_28;
    zT_29 = pay_type.state;
    if ((unsigned char)(zT_29 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_33 = pay_type.size;
    if ((unsigned char)(zT_33 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_62 = self;
    zT_64.payload = payload;
    zT_64.error_set = error_set;
    zT_63 = zT_64;
    zF_ABBA52E7_euAppend(zT_62, zT_63);
    zT_66 = self;
    zT_69 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_68.kind = zT_69;
    zT_68.state = eu_state;
    zT_70 = 0;
    zT_68.flags = zT_70;
    zT_71 = 0;
    zT_68.iw = zT_71;
    zT_68.size = eu_size;
    zT_72 = (unsigned short)eu_align;
    zT_68.alignment = zT_72;
    zT_73 = 0;
    zT_68.name_id = zT_73;
    zT_74 = 0;
    zT_68.module_id = zT_74;
    zT_75 = self->eu_len;
    zT_78 = (unsigned int)(unsigned int)(zT_75 - (unsigned int)(1));
    zT_68.payload_idx = zT_78;
    zT_67 = zT_68;
    zT_79 = zF_D4993F02_typeRegistryAppend(zT_66, zT_67);
    tid = zT_79;
    zT_80 = &self->eu_cache;
    zT_81 = eu_key;
    zT_82 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_80, zT_81, zT_82);
    return tid;
    z_bb_5:
    zT_36 = pay_type.size;
    goto z_bb_7;
    z_bb_6:
    zT_36 = 4;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_36;
    zT_40 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_40) > (unsigned int)(4))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_45 = pay_type.alignment;
    zT_44 = (unsigned int)zT_45;
    goto z_bb_10;
    z_bb_9:
    zT_44 = 4;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_44;
    zT_49 = union_size;
    zT_50 = union_align;
    zT_51 = zF_D2BAC673_alignUp(zT_49, zT_50);
    total = zT_51;
    zT_52 = total;
    zT_55 = zF_D2BAC673_alignUp(zT_52, (unsigned int)(4));
    zT_57 = zT_55 + (unsigned int)(4);
    total = zT_57;
    zT_58 = total;
    zT_59 = union_align;
    zT_60 = zF_D2BAC673_alignUp(zT_58, zT_59);
    eu_size = zT_60;
    eu_align = union_align;
    zT_61 = 2;
    eu_state = zT_61;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    unsigned int zT_100;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_E834303C_ArrayPayload zT_102;
    zT_E834303C_ArrayPayload zT_103;
    zT_D155D06D_Type* zT_105;
    zT_D155D06D_Type zT_106;
    int zT_108;
    unsigned int zT_109;
    int zT_111;
    unsigned int zT_112;
    int zT_114;
    unsigned char zT_115;
    unsigned char zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned short zT_121;
    unsigned int zT_122;
    unsigned char zT_123;
    zT_338B7C76_TypeRegistry* zT_125;
    zT_D155D06D_Type zT_126;
    zT_D155D06D_Type zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    unsigned char zT_129;
    unsigned char zT_130;
    unsigned short zT_131;
    unsigned int zT_132;
    unsigned short zT_133;
    unsigned int zT_134;
    unsigned int zT_137;
    unsigned int zT_138 = 0;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    zT_4028D896_Arr_unsigned_char_2 zT_145;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    int zT_151;
    unsigned char* zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155 = 0;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned char* zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_A4CE86B7_U64ToU32Map* zT_167;
    zT_79FAE712_u64 zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = (unsigned char*)zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)o0b) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    zT_23 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l);
    o0s = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)o0b) + o0s;
    zT_29 = (unsigned int)(19) - o0s;
    zT_30.ptr = (unsigned char*)zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)o0b2) + zT_43;
    zT_45 = (unsigned int)(20) - zT_43;
    zT_46.ptr = (unsigned char*)zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    zT_51 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l2);
    o0s2 = zT_51;
    zT_56 = (unsigned char*)((unsigned char*)o0b2) + o0s2;
    zT_57 = (unsigned int)(19) - o0s2;
    zT_58.ptr = (unsigned char*)zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_64 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)length);
    key = zT_64;
    zT_65 = &self->array_cache;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = (unsigned char*)zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_83 = 0;
    zT_84 = (unsigned char*)((unsigned char*)o1b) + zT_83;
    zT_85 = (unsigned int)(20) - zT_83;
    zT_86.ptr = (unsigned char*)zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    zT_91 = (unsigned int)(19) - (unsigned int)((unsigned int)o1l);
    o1s = zT_91;
    zT_96 = (unsigned char*)((unsigned char*)o1b) + o1s;
    zT_97 = (unsigned int)(19) - o1s;
    zT_98.ptr = (unsigned char*)zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    zT_99 = self;
    zT_100 = existing;
    zF_C173376D_arrayCompleteIfRead(zT_99, zT_100);
    return existing;
    z_bb_2:
    zT_101 = self;
    zT_103.elem = elem;
    zT_103.length = length;
    zT_102 = zT_103;
    zF_4D5CD212_arrayAppend(zT_101, zT_102);
    zT_105 = self->types_items;
    zT_106 = zT_105[elem];
    elem_ty = zT_106;
    zT_108 = 0;
    zT_109 = (unsigned int)zT_108;
    arr_size = zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    arr_align = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned char)zT_114;
    arr_state = zT_115;
    zT_116 = elem_ty.state;
    if ((unsigned char)(zT_116 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_119 = elem_ty.size;
    zT_120 = zT_119 * length;
    arr_size = zT_120;
    zT_121 = elem_ty.alignment;
    zT_122 = (unsigned int)zT_121;
    arr_align = zT_122;
    zT_123 = 2;
    arr_state = zT_123;
    goto z_bb_4;
    z_bb_4:
    zT_125 = self;
    zT_128 = zT_33EF6BFB_TypeKind_array_type;
    zT_127.kind = zT_128;
    zT_127.state = arr_state;
    zT_129 = 0;
    zT_127.flags = zT_129;
    zT_130 = 0;
    zT_127.iw = zT_130;
    zT_127.size = arr_size;
    zT_131 = (unsigned short)arr_align;
    zT_127.alignment = zT_131;
    zT_132 = 0;
    zT_127.name_id = zT_132;
    zT_133 = 0;
    zT_127.module_id = zT_133;
    zT_134 = self->array_len;
    zT_137 = (unsigned int)(unsigned int)(zT_134 - (unsigned int)(1));
    zT_127.payload_idx = zT_137;
    zT_126 = zT_127;
    zT_138 = zF_D4993F02_typeRegistryAppend(zT_125, zT_126);
    tid = zT_138;
    zT_140 = "O2N";
    zT_142 = 3;
    zT_141.ptr = (unsigned char*)zT_140;
    zT_141.len = zT_142;
    o2m = zT_141;
    zT_143 = o2m;
    zF_48AC7B3A_markerWrite(zT_143);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_145[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_145[_i];
        _i++;
    }
}
    zT_147 = tid;
    zT_151 = 0;
    zT_152 = (unsigned char*)((unsigned char*)o2b) + zT_151;
    zT_153 = (unsigned int)(20) - zT_151;
    zT_154.ptr = (unsigned char*)zT_152;
    zT_154.len = zT_153;
    zT_148 = zT_154;
    zT_155 = zF_A7504564_itoa(zT_147, zT_148);
    o2l = zT_155;
    zT_159 = (unsigned int)(19) - (unsigned int)((unsigned int)o2l);
    o2s = zT_159;
    zT_164 = (unsigned char*)((unsigned char*)o2b) + o2s;
    zT_165 = (unsigned int)(19) - o2s;
    zT_166.ptr = (unsigned char*)zT_164;
    zT_166.len = zT_165;
    zT_160 = zT_166;
    zF_48AC7B3A_markerWrite(zT_160);
    zT_167 = &self->array_cache;
    zT_168 = key;
    zT_169 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_167, zT_168, zT_169);
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned short zT_15;
    unsigned int zT_16;
    unsigned short zT_17;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned int zT_22 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.iw = zT_13;
    zT_14 = 0;
    zT_9.size = zT_14;
    zT_15 = 1;
    zT_9.alignment = zT_15;
    zT_16 = 0;
    zT_9.name_id = zT_16;
    zT_17 = 0;
    zT_9.module_id = zT_17;
    zT_18 = self->tup_len;
    zT_21 = (unsigned int)(unsigned int)(zT_18 - (unsigned int)(1));
    zT_9.payload_idx = zT_21;
    zT_8 = zT_9;
    zT_22 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_22;
    return tid;
}

/* typeRegistryTupleElem */
zT_BAEE192E_Opt_10 zF_ACB4F3DB_typeRegistryTupleEl(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ordinal) {
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    unsigned int zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_19 = {0};
    zT_666DC2E1_TuplePayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_666DC2E1_TuplePayload zT_24;
    unsigned short zT_25;
    zT_BAEE192E_Opt_10 zT_28 = {0};
    unsigned int* zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_34;
    zT_D155D06D_Type ty;
    zT_666DC2E1_TuplePayload tup;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->tup_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_6:
    zT_21 = self->tup_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    tup = zT_24;
    zT_25 = tup.elems_count;
    if ((unsigned char)(ordinal >= (unsigned int)((unsigned int)zT_25))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28.has_value = 0;
    return zT_28;
    z_bb_8:
    zT_29 = self->xt_items;
    zT_30 = tup.elems_start;
    zT_32 = (unsigned int)(unsigned int)(zT_30 + ordinal);
    zT_33 = zT_29[zT_32];
    zT_34.has_value = 1;
    zT_34.value = zT_33;
    return zT_34;
}

/* typeRegistryTupleOrdinalFromNameId */
zT_BAEE192E_Opt_10 zF_D3BC911B_typeRegistryTupleOr(zT_338B7C76_TypeRegistry* self, unsigned int name_id) {
    zT_D3EB6303_StringInterner* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    unsigned int zT_9;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned int zT_14;
    unsigned char* zT_15;
    int zT_16;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned int zT_25;
    unsigned char* zT_29;
    unsigned char zT_30;
    unsigned char zT_33;
    zT_BAEE192E_Opt_10 zT_36 = {0};
    unsigned int zT_39;
    zT_BAEE192E_Opt_10 zT_40;
    unsigned int zT_44;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_50;
    zT_BAEE192E_Opt_10 zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int nlen;
    unsigned int start;
    unsigned int v;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_3 = self->interner;
    zT_4 = name_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_3, zT_4);
    text = zT_6;
    zT_9 = text.len;
    nlen = zT_9;
    if ((unsigned char)(nlen == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_2:
    zT_14 = 0;
    start = zT_14;
    zT_15 = text.ptr;
    zT_16 = 0;
    zT_17 = zT_15[zT_16];
    if ((unsigned char)(zT_17 == (unsigned char)(95))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = 1;
    start = zT_20;
    if ((unsigned char)(nlen == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_25 = 0;
    v = zT_25;
    i = start;
    goto z_bb_7;
    z_bb_5:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    if ((unsigned char)(i < nlen)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_29 = text.ptr;
    zT_30 = zT_29[i];
    c = zT_30;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_12; else goto z_bb_11;
    z_bb_9:
    zT_51.has_value = 1;
    zT_51.value = v;
    return zT_51;
    z_bb_10:
    zT_48 = 1;
    zT_50 = i + (unsigned int)((unsigned int)zT_48);
    i = zT_50;
    goto z_bb_7;
    z_bb_11:
    zT_33 = c > (unsigned char)(57);
    goto z_bb_13;
    z_bb_12:
    zT_33 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_33) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36.has_value = 0;
    return zT_36;
    z_bb_15:
    if ((unsigned char)(v > (unsigned int)(99999999))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_39 = 1000000000;
    zT_40.has_value = 1;
    zT_40.value = zT_39;
    return zT_40;
    z_bb_17:
    zT_44 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_44;
    zT_47 = (unsigned int)(v * (unsigned int)(10)) + d;
    v = zT_47;
    goto z_bb_10;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type, unsigned char call_conv) {
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned char zT_38;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_0317B1D5_FnPayload* zT_57;
    zT_D155D06D_Type* zT_58;
    zT_D155D06D_Type zT_59;
    unsigned int zT_60;
    zT_0317B1D5_FnPayload zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    zT_0317B1D5_FnPayload* zT_65;
    zT_D155D06D_Type* zT_66;
    zT_D155D06D_Type zT_67;
    unsigned int zT_68;
    zT_0317B1D5_FnPayload zT_69;
    unsigned char zT_70;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    zT_D155D06D_Type* zT_86;
    zT_D155D06D_Type* zT_87;
    int zT_89;
    unsigned int zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_0317B1D5_FnPayload zT_93;
    zT_0317B1D5_FnPayload zT_94;
    unsigned char zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned int zT_104;
    unsigned short zT_105;
    unsigned short zT_106;
    unsigned int zT_107;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_D155D06D_Type* zT_114;
    unsigned int zT_115;
    zT_D155D06D_Type zT_116;
    unsigned char zT_117;
    zT_D155D06D_Type* zT_120;
    zT_D155D06D_Type* zT_122;
    zT_4028D896_Arr_unsigned_char_2 zT_124;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    int zT_130;
    unsigned char* zT_131;
    unsigned int zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134 = 0;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned char* zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    unsigned int zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned char conv_bit;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_10 = "P2:n";
    zT_12 = 4;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    p2m = zT_11;
    zT_13 = p2m;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = name_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)p2nb) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = (unsigned char*)zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    p2nl = zT_25;
    zT_29 = (unsigned int)(19) - (unsigned int)((unsigned int)p2nl);
    p2ns = zT_29;
    zT_34 = (unsigned char*)((unsigned char*)p2nb) + p2ns;
    zT_35 = (unsigned int)(19) - p2ns;
    zT_36.ptr = (unsigned char*)zT_34;
    zT_36.len = zT_35;
    zT_30 = zT_36;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_38 = 0;
    conv_bit = zT_38;
    if ((unsigned char)(call_conv == (unsigned char)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_41 = 2;
    conv_bit = zT_41;
    goto z_bb_2;
    z_bb_2:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    i = zT_44;
    goto z_bb_3;
    z_bb_3:
    zT_45 = self->types_len;
    if ((unsigned char)(i < zT_45)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_48 = self->types_items;
    zT_49 = zT_48[i];
    it = zT_49;
    zT_50 = it.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_92 = self;
    zT_94.name_id = name_id;
    zT_94.module_id = module_id;
    zT_94.is_extern = is_extern;
    zT_94.params_start = params_start;
    zT_94.params_count = params_count;
    zT_94.return_type = return_type;
    zT_95 = is_variadic | conv_bit;
    zT_94.flags_packed = zT_95;
    zT_93 = zT_94;
    zF_07DDC351_fnAppend(zT_92, zT_93);
    zT_97 = self;
    zT_100 = zT_33EF6BFB_TypeKind_fn_type;
    zT_99.kind = zT_100;
    zT_101 = 2;
    zT_99.state = zT_101;
    zT_102 = 0;
    zT_99.flags = zT_102;
    zT_103 = 0;
    zT_99.iw = zT_103;
    zT_104 = 4;
    zT_99.size = zT_104;
    zT_105 = 4;
    zT_99.alignment = zT_105;
    zT_99.name_id = name_id;
    zT_106 = 0;
    zT_99.module_id = zT_106;
    zT_107 = self->fn_len;
    zT_110 = (unsigned int)(unsigned int)(zT_107 - (unsigned int)(1));
    zT_99.payload_idx = zT_110;
    zT_98 = zT_99;
    zT_111 = zF_D4993F02_typeRegistryAppend(zT_97, zT_98);
    tid = zT_111;
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_6:
    zT_89 = 1;
    zT_91 = i + (unsigned int)((unsigned int)zT_89);
    i = zT_91;
    goto z_bb_3;
    z_bb_7:
    zT_54 = it.name_id;
    zT_53 = zT_54 == name_id;
    goto z_bb_9;
    z_bb_8:
    zT_53 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->fn_items;
    zT_58 = self->types_items;
    zT_59 = zT_58[i];
    zT_60 = zT_59.payload_idx;
    zT_61 = zT_57[zT_60];
    zT_62 = zT_61.module_id;
    zT_56 = zT_62 == module_id;
    goto z_bb_12;
    z_bb_11:
    zT_56 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_56) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_65 = self->fn_items;
    zT_66 = self->types_items;
    zT_67 = zT_66[i];
    zT_68 = zT_67.payload_idx;
    zT_69 = zT_65[zT_68];
    zT_70 = zT_69.flags_packed;
    zT_64 = (unsigned char)(zT_70 & (unsigned int)(2)) == conv_bit;
    goto z_bb_15;
    z_bb_14:
    zT_64 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_64) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_75 = "H";
    zT_77 = 1;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    p2hm = zT_76;
    zT_78 = p2hm;
    zF_48AC7B3A_markerWrite(zT_78);
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_81 = self->types_items;
    zT_82 = zT_81[i];
    zT_83 = zT_82.flags;
    zT_86 = self->types_items;
    zT_87 = zT_86 + i;
    zT_87->flags = (unsigned char)(zT_83 | (unsigned char)(1));
    goto z_bb_19;
    z_bb_19:
    return (unsigned int)((unsigned int)i);
    z_bb_20:
    zT_114 = self->types_items;
    zT_115 = (unsigned int)tid;
    zT_116 = zT_114[zT_115];
    zT_117 = zT_116.flags;
    zT_120 = self->types_items;
    zT_122 = zT_120 + (unsigned int)((unsigned int)tid);
    zT_122->flags = (unsigned char)(zT_117 | (unsigned char)(1));
    goto z_bb_21;
    z_bb_21:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_124[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_124[_i];
        _i++;
    }
}
    zT_126 = tid;
    zT_130 = 0;
    zT_131 = (unsigned char*)((unsigned char*)p2sb) + zT_130;
    zT_132 = (unsigned int)(20) - zT_130;
    zT_133.ptr = (unsigned char*)zT_131;
    zT_133.len = zT_132;
    zT_127 = zT_133;
    zT_134 = zF_A7504564_itoa(zT_126, zT_127);
    p2sl = zT_134;
    zT_138 = (unsigned int)(19) - (unsigned int)((unsigned int)p2sl);
    p2ss = zT_138;
    zT_143 = (unsigned char*)((unsigned char*)p2sb) + p2ss;
    zT_144 = (unsigned int)(19) - p2ss;
    zT_145.ptr = (unsigned char*)zT_143;
    zT_145.len = zT_144;
    zT_139 = zT_145;
    zF_48AC7B3A_markerWrite(zT_139);
    zT_147 = "\n";
    zT_149 = 1;
    zT_148.ptr = (unsigned char*)zT_147;
    zT_148.len = zT_149;
    p2nl2 = zT_148;
    zT_150 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_150);
    return tid;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_8 = self->types_items;
    zT_10 = zT_8 + (unsigned int)((unsigned int)tid);
    zT_10->flags = (unsigned char)(zT_5 | (unsigned char)(1));
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    unsigned int* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned short zT_21;
    zT_A4CE86B7_U64ToU32Map* zT_22;
    zT_79FAE712_u64 zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_0B73C507_ErrorSetPayload zT_30;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_D155D06D_Type zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned short zT_42;
    unsigned int zT_43;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_48;
    zT_79FAE712_u64 zT_49;
    unsigned int zT_50;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ki < tags_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_13 = (unsigned int)(unsigned int)(tags_start + (unsigned int)((unsigned int)ki));
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    zT_18 = (zT_79FAE712_u64)(key ^ (zT_79FAE712_u64)((zT_79FAE712_u64)tag)) * (zT_79FAE712_u64)(Z98_U64_C(1099511628211));
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_22 = &self->es_cache;
    zT_23 = key;
    zT_25 = zF_A05A7BE1_u64ToU32MapGet(zT_22, zT_23);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_21 = ki + (unsigned short)((unsigned short)zT_19);
    ki = zT_21;
    goto z_bb_1;
    z_bb_5:
    existing = zT_25.value;
    return existing;
    z_bb_6:
    zT_28 = self;
    zT_30.tags_start = tags_start;
    zT_30.tags_count = tags_count;
    zT_29 = zT_30;
    zF_B86143DD_esAppend(zT_28, zT_29);
    zT_32 = self;
    zT_35 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_34.kind = zT_35;
    zT_36 = 2;
    zT_34.state = zT_36;
    zT_37 = 0;
    zT_34.flags = zT_37;
    zT_38 = 0;
    zT_34.iw = zT_38;
    zT_39 = 4;
    zT_34.size = zT_39;
    zT_40 = 4;
    zT_34.alignment = zT_40;
    zT_41 = 0;
    zT_34.name_id = zT_41;
    zT_42 = 0;
    zT_34.module_id = zT_42;
    zT_43 = self->es_len;
    zT_46 = (unsigned int)(unsigned int)(zT_43 - (unsigned int)(1));
    zT_34.payload_idx = zT_46;
    zT_33 = zT_34;
    zT_47 = zF_D4993F02_typeRegistryAppend(zT_32, zT_33);
    tid = zT_47;
    zT_48 = &self->es_cache;
    zT_49 = key;
    zT_50 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_48, zT_49, zT_50);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_36;
    unsigned int zT_37;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_44;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    if ((unsigned char)(es_type_id >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    zT_32 = reg->xn_len;
    if ((unsigned char)((unsigned int)(tags_start + tags_count) > zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(4294967295u);
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(i < tags_count)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    if ((unsigned char)(zT_41 == name_id)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned int)(4294967295u);
    z_bb_12:
    zT_44 = 1;
    zT_46 = i + (unsigned int)((unsigned int)zT_44);
    i = zT_46;
    goto z_bb_9;
    z_bb_13:
    return (unsigned int)((unsigned int)i);
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_13;
    unsigned short zT_14;
    int zT_17;
    unsigned int zT_19;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type zT_38;
    unsigned int zT_39 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    zT_10 = it.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_22 = zT_33EF6BFB_TypeKind_module_type;
    zT_21.kind = zT_22;
    zT_23 = 0;
    zT_21.state = zT_23;
    zT_24 = 0;
    zT_21.flags = zT_24;
    zT_25 = 0;
    zT_21.iw = zT_25;
    zT_26 = 0;
    zT_21.size = zT_26;
    zT_27 = 0;
    zT_21.alignment = zT_27;
    zT_28 = 0;
    zT_21.name_id = zT_28;
    zT_29 = (unsigned short)module_id;
    zT_21.module_id = zT_29;
    zT_30 = 0;
    zT_21.payload_idx = zT_30;
    t = zT_21;
    zT_32 = "MC";
    zT_34 = 2;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    mc = zT_33;
    zT_35 = mc;
    zF_48AC7B3A_markerWrite(zT_35);
    zT_37 = self;
    zT_38 = t;
    zT_39 = zF_D4993F02_typeRegistryAppend(zT_37, zT_38);
    mcid = zT_39;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_13 = zT_14 == module_id;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)((unsigned int)i);
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    (void)zF_4F84B621_registerPrimitive(zT_1, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel), (unsigned int)(0), (unsigned int)(0));
    zT_9 = self;
    (void)zF_4F84B621_registerPrimitive(zT_9, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type), (unsigned int)(0), (unsigned int)(0));
    zT_17 = self;
    (void)zF_4F84B621_registerPrimitive(zT_17, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type), (unsigned int)(1), (unsigned int)(1));
    zT_25 = self;
    (void)zF_4F84B621_registerPrimitive(zT_25, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type), (unsigned int)(0), (unsigned int)(0));
    zT_33 = self;
    (void)zF_4F84B621_registerPrimitive(zT_33, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type), (unsigned int)(1), (unsigned int)(1));
    zT_41 = self;
    (void)zF_4F84B621_registerPrimitive(zT_41, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type), (unsigned int)(2), (unsigned int)(2));
    zT_49 = self;
    (void)zF_4F84B621_registerPrimitive(zT_49, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type), (unsigned int)(4), (unsigned int)(4));
    zT_57 = self;
    (void)zF_4F84B621_registerPrimitive(zT_57, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type), (unsigned int)(8), (unsigned int)(8));
    zT_65 = self;
    (void)zF_4F84B621_registerPrimitive(zT_65, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type), (unsigned int)(1), (unsigned int)(1));
    zT_73 = self;
    (void)zF_4F84B621_registerPrimitive(zT_73, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type), (unsigned int)(2), (unsigned int)(2));
    zT_81 = self;
    (void)zF_4F84B621_registerPrimitive(zT_81, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type), (unsigned int)(4), (unsigned int)(4));
    zT_89 = self;
    (void)zF_4F84B621_registerPrimitive(zT_89, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type), (unsigned int)(8), (unsigned int)(8));
    zT_97 = self;
    (void)zF_4F84B621_registerPrimitive(zT_97, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type), (unsigned int)(4), (unsigned int)(4));
    zT_105 = self;
    (void)zF_4F84B621_registerPrimitive(zT_105, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type), (unsigned int)(4), (unsigned int)(4));
    zT_113 = self;
    (void)zF_4F84B621_registerPrimitive(zT_113, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type), (unsigned int)(1), (unsigned int)(1));
    zT_121 = self;
    (void)zF_4F84B621_registerPrimitive(zT_121, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type), (unsigned int)(4), (unsigned int)(4));
    zT_129 = self;
    (void)zF_4F84B621_registerPrimitive(zT_129, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type), (unsigned int)(8), (unsigned int)(8));
    zT_137 = self;
    (void)zF_4F84B621_registerPrimitive(zT_137, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type), (unsigned int)(0), (unsigned int)(0));
    zT_145 = self;
    (void)zF_4F84B621_registerPrimitive(zT_145, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type), (unsigned int)(0), (unsigned int)(0));
    zT_153 = self;
    (void)zF_4F84B621_registerPrimitive(zT_153, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type), (unsigned int)(0), (unsigned int)(0));
    zT_161 = self;
    (void)zF_4F84B621_registerPrimitive(zT_161, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type), (unsigned int)(0), (unsigned int)(0));
    zT_169 = self;
    (void)zF_4F84B621_registerPrimitive(zT_169, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type), (unsigned int)(4), (unsigned int)(4));
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = (unsigned char*)zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    zT_181 = self;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, (unsigned int)(1), zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    zT_189 = self;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, (unsigned int)(2), zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = (unsigned char*)zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, (unsigned int)(4), zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = (unsigned char*)zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, (unsigned int)(5), zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = (unsigned char*)zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, (unsigned int)(6), zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = (unsigned char*)zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, (unsigned int)(7), zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = (unsigned char*)zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, (unsigned int)(8), zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = (unsigned char*)zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, (unsigned int)(9), zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = (unsigned char*)zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, (unsigned int)(10), zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = (unsigned char*)zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, (unsigned int)(11), zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = (unsigned char*)zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    zT_261 = self;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, (unsigned int)(12), zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = (unsigned char*)zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    zT_269 = self;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, (unsigned int)(13), zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = (unsigned char*)zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, (unsigned int)(14), zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = (unsigned char*)zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, (unsigned int)(15), zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = (unsigned char*)zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, (unsigned int)(16), zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = (unsigned char*)zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    zT_301 = self;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, (unsigned int)(17), zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = (unsigned char*)zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, (unsigned int)(18), zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = (unsigned char*)zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    zT_317 = self;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, (unsigned int)(20), zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = (unsigned char*)zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, (unsigned int)(21), zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_16;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_4 = self->interner;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, (zT_79FAE712_u64)((zT_79FAE712_u64)nid), zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, unsigned char* is_unsigned) {
    unsigned int zT_4;
    unsigned char* zT_9;
    int zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned char zT_19;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_30;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned int zT_41;
    unsigned int zT_44;
    int zT_48;
    unsigned int zT_50;
    unsigned char zT_53;
    unsigned char zT_59;
    unsigned int nlen;
    unsigned char prefix;
    unsigned char is_u;
    unsigned char is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    if ((unsigned char)(nlen < (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = zT_9[zT_10];
    prefix = zT_11;
    zT_14 = prefix == (unsigned char)(117);
    is_u = zT_14;
    zT_17 = prefix == (unsigned char)(105);
    is_i = zT_17;
    if ((unsigned char)(!is_u)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = !is_i;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    *is_unsigned = (unsigned char)(1);
    goto z_bb_9;
    z_bb_9:
    zT_25 = 0;
    w = zT_25;
    zT_27 = 1;
    i = zT_27;
    goto z_bb_11;
    z_bb_10:
    *is_unsigned = (unsigned char)(0);
    goto z_bb_9;
    z_bb_11:
    if ((unsigned char)(i < nlen)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = name.ptr;
    zT_31 = zT_30[i];
    c = zT_31;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_48 = 1;
    zT_50 = i + (unsigned int)((unsigned int)zT_48);
    i = zT_50;
    goto z_bb_11;
    z_bb_15:
    zT_34 = c > (unsigned char)(57);
    goto z_bb_17;
    z_bb_16:
    zT_34 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_34) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned int)(0);
    z_bb_19:
    zT_41 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_41;
    zT_44 = (unsigned int)(w * (unsigned int)(10)) + d;
    w = zT_44;
    if ((unsigned char)(w > (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_53 = w > (unsigned int)(64);
    goto z_bb_27;
    z_bb_26:
    zT_53 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_59 = w > (unsigned int)(63);
    goto z_bb_32;
    z_bb_31:
    zT_59 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_59) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned int)(0);
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned char zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6;
    unsigned int zT_8 = 0;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned short zT_46;
    unsigned int zT_47;
    unsigned short zT_48;
    unsigned int zT_49;
    unsigned int zT_50 = 0;
    zT_338B7C76_TypeRegistry* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    zT_5 = name;
    zT_6 = (unsigned char*)&arb_u;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    if ((unsigned char)(arb_w == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_13 = self->interner;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    zT_18 = self;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, (zT_79FAE712_u64)((zT_79FAE712_u64)nid));
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = zT_33EF6BFB_TypeKind_arb_uint_type;
    goto z_bb_7;
    z_bb_6:
    zT_25 = zT_33EF6BFB_TypeKind_arb_int_type;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    if ((unsigned char)(arb_w > (unsigned int)(8))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(arb_w > (unsigned int)(16))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(arb_w > (unsigned int)(32))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    zT_45 = (unsigned char)arb_w;
    zT_42.iw = zT_45;
    zT_42.size = carrier;
    zT_46 = (unsigned short)carrier;
    zT_42.alignment = zT_46;
    zT_47 = 0;
    zT_42.name_id = zT_47;
    zT_48 = 0;
    zT_42.module_id = zT_48;
    zT_49 = 0;
    zT_42.payload_idx = zT_49;
    zT_41 = zT_42;
    zT_50 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_50;
    zT_51 = self;
    zT_52 = tid;
    zT_53 = name;
    zF_BA76727A_registerPrimitiveNa(zT_51, zT_52, zT_53);
    return tid;
}

/* typeRegistryEnumBackingType */
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(10);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(10);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(10);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.backing_type;
    return zT_24;
}

/* typeRegistryEnumHasExplicitBacking */
unsigned char zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned char zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.explicit_backing;
    return (unsigned char)(zT_24 != (unsigned char)(0));
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_29 = 0;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_23 = ty.kind;
    zT_22 = zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = ty.iw;
    return zT_26;
    z_bb_9:
    zT_27 = ty.kind;
    zT_29 = zF_534230F8_typeWidthBitsForKin(zT_27);
    return zT_29;
}

/* typeRegistryIntIsSigned */
unsigned char zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_47;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    unsigned char zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_27 = ty.kind;
    if ((unsigned char)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = ty.kind;
    zT_30 = zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_30 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_30) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_35 = ty.kind;
    zT_34 = zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_39 = ty.kind;
    zT_38 = zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_20;
    z_bb_19:
    zT_42 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_42) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_47 = ty.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_25;
    z_bb_24:
    zT_50 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_50) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = ty.kind;
    zT_54 = zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_28;
    z_bb_27:
    zT_54 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_54) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_31;
    z_bb_30:
    zT_58 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_58) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_63 = ty.kind;
    zT_62 = zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_34;
    z_bb_33:
    zT_62 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_62) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_67 = ty.kind;
    zT_66 = zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_37;
    z_bb_36:
    zT_66 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_66) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    return (unsigned char)(0);
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned short zT_23;
    unsigned short zT_24;
    unsigned int zT_25;
    unsigned int zT_26 = 0;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_79FAE712_u64 zT_28;
    unsigned int zT_29;
    zT_4028D896_Arr_unsigned_char_2 zT_31;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41 = 0;
    unsigned int zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_4028D896_Arr_unsigned_char_2 zT_59;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    int zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    int zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98 = 0;
    unsigned int zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_4028D896_Arr_unsigned_char_2 zT_116;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    int zT_122;
    unsigned char* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126 = 0;
    unsigned int zT_130;
    unsigned char* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned char* zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_9 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) * (zT_79FAE712_u64)(Z98_U64_C(4294967296))) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18.iw = zT_21;
    zT_22 = 0;
    zT_18.size = zT_22;
    zT_23 = 0;
    zT_18.alignment = zT_23;
    zT_18.name_id = name_id;
    zT_24 = (unsigned short)module_id;
    zT_18.module_id = zT_24;
    zT_25 = 0;
    zT_18.payload_idx = zT_25;
    zT_17 = zT_18;
    zT_26 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_26;
    zT_27 = self;
    zT_28 = key;
    zT_29 = tid;
    zF_5E95558D_nameCachePut(zT_27, zT_28, zT_29);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_31[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_31[_i];
        _i++;
    }
}
    zT_33 = module_id;
    zT_37 = 0;
    zT_38 = (unsigned char*)((unsigned char*)rn_m) + zT_37;
    zT_39 = (unsigned int)(20) - zT_37;
    zT_40.ptr = (unsigned char*)zT_38;
    zT_40.len = zT_39;
    zT_34 = zT_40;
    zT_41 = zF_A7504564_itoa(zT_33, zT_34);
    rn_ml = zT_41;
    zT_45 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_ml);
    rn_ms = zT_45;
    zT_47 = "RN:m";
    zT_49 = 4;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    rnm = zT_48;
    zT_50 = rnm;
    zF_48AC7B3A_markerWrite(zT_50);
    zT_55 = (unsigned char*)((unsigned char*)rn_m) + rn_ms;
    zT_56 = (unsigned int)(19) - rn_ms;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_51 = zT_57;
    zF_48AC7B3A_markerWrite(zT_51);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_59[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_59[_i];
        _i++;
    }
}
    zT_61 = name_id;
    zT_65 = 0;
    zT_66 = (unsigned char*)((unsigned char*)rn_n) + zT_65;
    zT_67 = (unsigned int)(20) - zT_65;
    zT_68.ptr = (unsigned char*)zT_66;
    zT_68.len = zT_67;
    zT_62 = zT_68;
    zT_69 = zF_A7504564_itoa(zT_61, zT_62);
    rn_nl = zT_69;
    zT_73 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_nl);
    rn_ns = zT_73;
    zT_75 = "n";
    zT_77 = 1;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    rnn = zT_76;
    zT_78 = rnn;
    zF_48AC7B3A_markerWrite(zT_78);
    zT_83 = (unsigned char*)((unsigned char*)rn_n) + rn_ns;
    zT_84 = (unsigned int)(19) - rn_ns;
    zT_85.ptr = (unsigned char*)zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zF_48AC7B3A_markerWrite(zT_79);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_87[_i];
        _i++;
    }
}
    zT_94 = 0;
    zT_95 = (unsigned char*)((unsigned char*)rn_k) + zT_94;
    zT_96 = (unsigned int)(20) - zT_94;
    zT_97.ptr = (unsigned char*)zT_95;
    zT_97.len = zT_96;
    zT_90 = zT_97;
    zT_98 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_90);
    rn_kl = zT_98;
    zT_102 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_kl);
    rn_ks = zT_102;
    zT_104 = "k";
    zT_106 = 1;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    rnk = zT_105;
    zT_107 = rnk;
    zF_48AC7B3A_markerWrite(zT_107);
    zT_112 = (unsigned char*)((unsigned char*)rn_k) + rn_ks;
    zT_113 = (unsigned int)(19) - rn_ks;
    zT_114.ptr = (unsigned char*)zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_116[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_116[_i];
        _i++;
    }
}
    zT_118 = tid;
    zT_122 = 0;
    zT_123 = (unsigned char*)((unsigned char*)rn_t) + zT_122;
    zT_124 = (unsigned int)(20) - zT_122;
    zT_125.ptr = (unsigned char*)zT_123;
    zT_125.len = zT_124;
    zT_119 = zT_125;
    zT_126 = zF_A7504564_itoa(zT_118, zT_119);
    rn_tl = zT_126;
    zT_130 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_tl);
    rn_ts = zT_130;
    zT_132 = "t";
    zT_134 = 1;
    zT_133.ptr = (unsigned char*)zT_132;
    zT_133.len = zT_134;
    rnt = zT_133;
    zT_135 = rnt;
    zF_48AC7B3A_markerWrite(zT_135);
    zT_140 = (unsigned char*)((unsigned char*)rn_t) + rn_ts;
    zT_141 = (unsigned int)(19) - rn_ts;
    zT_142.ptr = (unsigned char*)zT_140;
    zT_142.len = zT_141;
    zT_136 = zT_142;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_144 = "\n";
    zT_146 = 1;
    zT_145.ptr = (unsigned char*)zT_144;
    zT_145.len = zT_146;
    rnnl = zT_145;
    zT_147 = rnnl;
    zF_48AC7B3A_markerWrite(zT_147);
    return tid;
}

/* typeHasForwardDecl */
unsigned char zF_A42DCA4C_typeHasForwardDecl(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    unsigned int zT_10;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_18;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned char zT_27 = 0;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.name_id;
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_18 = ty.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_22 = ty.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = self;
    zT_26 = tid;
    zT_27 = zF_041ACB92_typeRegistryIsPacke(zT_25, zT_26);
    if (zT_27) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    return (unsigned char)(1);
}

/* typeNeedsFullDef */
unsigned char zF_E789C17A_typeNeedsFullDef(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    zT_10 = zT_9.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    return (unsigned char)(0);
}

/* typeRefPtrLeaf */
unsigned int zF_7AC9839C_typeRefPtrLeaf(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_4;
    unsigned int zT_8;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    unsigned char zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_112BF819_PtrPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_112BF819_PtrPayload zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_28;
    unsigned int cur;
    unsigned int steps;
    zT_D155D06D_Type ty;
    cur = tid;
    zT_4 = 0;
    steps = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(steps < (unsigned int)(64))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cur) >= zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cur;
    z_bb_4:
    zT_26 = 1;
    zT_28 = steps + (unsigned int)((unsigned int)zT_26);
    steps = zT_28;
    goto z_bb_1;
    z_bb_5:
    return cur;
    z_bb_6:
    zT_11 = self->types_items;
    zT_12 = (unsigned int)cur;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_18 = ty.kind;
    zT_17 = zT_18 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_9;
    z_bb_8:
    zT_17 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return cur;
    z_bb_11:
    zT_21 = self->ptr_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    zT_25 = zT_24.base;
    cur = zT_25;
    goto z_bb_4;
}

/* typeRefEdgeTarget */
unsigned int zF_E447DE16_typeRefEdgeTarget(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ref, unsigned char name_pos) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    unsigned char zT_19;
    zT_33EF6BFB_TypeKind zT_20;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25 = 0;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_29;
    unsigned int zT_30;
    unsigned char zT_31 = 0;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38 = 0;
    zT_D155D06D_Type ref_ty;
    unsigned int tgt;
    unsigned char tgt_name_pos;
    if ((unsigned char)(ref == tid)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_7 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ref) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_11 = self->types_items;
    zT_12 = (unsigned int)ref;
    zT_13 = zT_11[zT_12];
    ref_ty = zT_13;
    tgt = ref;
    tgt_name_pos = name_pos;
    zT_16 = ref_ty.kind;
    if ((unsigned char)(zT_16 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_20 = ref_ty.kind;
    zT_19 = zT_20 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_19 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_23 = self;
    zT_24 = ref;
    zT_25 = zF_7AC9839C_typeRefPtrLeaf(zT_23, zT_24);
    tgt = zT_25;
    zT_26 = 1;
    tgt_name_pos = zT_26;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(tgt == tid)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_29 = self;
    zT_30 = tgt;
    zT_31 = zF_E789C17A_typeNeedsFullDef(zT_29, zT_30);
    if ((unsigned char)(!zT_31)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(4294967295u);
    z_bb_13:
    if ((unsigned char)(tgt_name_pos != (unsigned char)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = self;
    zT_37 = tgt;
    zT_38 = zF_A42DCA4C_typeHasForwardDecl(zT_36, zT_37);
    if (zT_38) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    return tgt;
    z_bb_16:
    return (unsigned int)(4294967295u);
    z_bb_17:
    goto z_bb_15;
}

/* typeRefsSeenOut */
unsigned char zF_15186E0C_typeRefsSeenOut(unsigned int* out, unsigned int start, unsigned int off, unsigned int tgt) {
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_10;
    unsigned int zT_12;
    unsigned int j;
    j = start;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(j < off)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = (unsigned int)j;
    zT_7 = out[zT_6];
    if ((unsigned char)(zT_7 == tgt)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_10 = 1;
    zT_12 = j + (unsigned int)((unsigned int)zT_10);
    j = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_4;
}

/* typeRefsNote */
unsigned int zF_DAC9FA8B_typeRefsNote(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ref, unsigned char name_pos, unsigned int* out, unsigned int* off, unsigned int start, unsigned int probe, unsigned int probe_target) {
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned int zT_14 = 0;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28 = 0;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int etgt;
    zT_10 = self;
    zT_11 = tid;
    zT_12 = ref;
    zT_13 = name_pos;
    zT_14 = zF_E447DE16_typeRefEdgeTarget(zT_10, zT_11, zT_12, zT_13);
    etgt = zT_14;
    if ((unsigned char)(etgt == (unsigned int)(4294967295u))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    if ((unsigned char)(probe != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(etgt == probe_target)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = out;
    zT_24 = start;
    zT_25 = *off;
    zT_26 = etgt;
    zT_28 = zF_15186E0C_typeRefsSeenOut(zT_23, zT_24, zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_30 = *off;
    zT_31 = (unsigned int)zT_30;
    out[zT_31] = etgt;
    zT_32 = *off;
    *off = (unsigned int)(zT_32 + (unsigned int)(1));
    goto z_bb_8;
    z_bb_8:
    return (unsigned int)(0);
}

/* typeRefsWalk */
unsigned int zF_07B0FCB6_typeRefsWalk(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int* out, unsigned int start, unsigned int probe, unsigned int probe_target) {
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    unsigned char zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned int zT_23;
    unsigned short zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_406493CE_StructPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    unsigned int zT_34;
    unsigned short zT_35;
    zT_AF9231A2_UnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_AF9231A2_UnionPayload zT_40;
    unsigned int zT_41;
    unsigned short zT_42;
    unsigned int zT_44;
    zT_2DF01B61_FieldEntry* zT_48;
    unsigned int zT_50;
    zT_2DF01B61_FieldEntry zT_51;
    unsigned int zT_52;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int* zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_64 = 0;
    int zT_68;
    unsigned int zT_70;
    zT_33EF6BFB_TypeKind zT_71;
    zT_54FF90FA_TaggedUnionPayload* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_54FF90FA_TaggedUnionPayload zT_78;
    unsigned int zT_80;
    unsigned short zT_81;
    zT_2DF01B61_FieldEntry* zT_85;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_2DF01B61_FieldEntry zT_89;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int* zT_95;
    unsigned int* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_102 = 0;
    int zT_106;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int* zT_113;
    unsigned int* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_121 = 0;
    zT_33EF6BFB_TypeKind zT_125;
    zT_E834303C_ArrayPayload* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    zT_E834303C_ArrayPayload zT_132;
    unsigned int zT_133;
    zT_338B7C76_TypeRegistry* zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int* zT_138;
    unsigned int* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_145 = 0;
    zT_33EF6BFB_TypeKind zT_149;
    zT_42C2D6BF_EUPayload* zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_42C2D6BF_EUPayload zT_156;
    unsigned int zT_157;
    zT_338B7C76_TypeRegistry* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int* zT_162;
    unsigned int* zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_169 = 0;
    zT_33EF6BFB_TypeKind zT_173;
    zT_0B10E8E9_OptionalPayload* zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_0B10E8E9_OptionalPayload zT_180;
    unsigned int zT_181;
    zT_338B7C76_TypeRegistry* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int* zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_193 = 0;
    zT_33EF6BFB_TypeKind zT_197;
    zT_0BB2A741_SlicePayload* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    zT_0BB2A741_SlicePayload zT_204;
    unsigned int zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int* zT_210;
    unsigned int* zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned int zT_217 = 0;
    zT_33EF6BFB_TypeKind zT_221;
    zT_666DC2E1_TuplePayload* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    zT_666DC2E1_TuplePayload zT_228;
    unsigned int zT_230;
    unsigned short zT_231;
    unsigned int* zT_235;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_338B7C76_TypeRegistry* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int* zT_244;
    unsigned int* zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned int zT_251 = 0;
    int zT_255;
    unsigned int zT_257;
    zT_33EF6BFB_TypeKind zT_258;
    zT_0317B1D5_FnPayload* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    zT_0317B1D5_FnPayload zT_265;
    zT_338B7C76_TypeRegistry* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int* zT_270;
    unsigned int* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned int zT_278 = 0;
    unsigned int zT_283;
    unsigned short zT_285;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int* zT_298;
    unsigned int* zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int* zT_303;
    unsigned int zT_307 = 0;
    unsigned int zT_312;
    unsigned int off;
    zT_D155D06D_Type ty;
    unsigned int fstart;
    unsigned short fcount;
    zT_406493CE_StructPayload sp;
    unsigned int i;
    zT_AF9231A2_UnionPayload up;
    unsigned int ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int et;
    unsigned int eup;
    unsigned int op;
    unsigned int se;
    zT_666DC2E1_TuplePayload tp_1;
    zT_0317B1D5_FnPayload fp;
    unsigned int fpend;
    unsigned int pi;
    off = start;
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_15 = ty.kind;
    zT_14 = zT_15 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_19 = ty.kind;
    zT_18 = zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_23 = 0;
    fstart = zT_23;
    zT_25 = 0;
    fcount = zT_25;
    zT_26 = ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_8:
    if ((unsigned char)(probe != (unsigned int)(0))) goto z_bb_71; else goto z_bb_72;
    z_bb_9:
    zT_71 = ty.kind;
    if ((unsigned char)(zT_71 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_19; else goto z_bb_21;
    z_bb_10:
    zT_30 = self->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = sp.fields_start;
    fstart = zT_34;
    zT_35 = sp.fields_count;
    fcount = zT_35;
    goto z_bb_11;
    z_bb_11:
    zT_44 = 0;
    i = zT_44;
    goto z_bb_13;
    z_bb_12:
    zT_37 = self->un_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    up = zT_40;
    zT_41 = up.fields_start;
    fstart = zT_41;
    zT_42 = up.fields_count;
    fcount = zT_42;
    goto z_bb_11;
    z_bb_13:
    if ((unsigned char)(i < (unsigned int)((unsigned int)fcount))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_48 = self->fe_items;
    zT_50 = (unsigned int)((unsigned int)fstart) + i;
    zT_51 = zT_48[zT_50];
    zT_52 = zT_51.type_id;
    ft = zT_52;
    zT_53 = self;
    zT_54 = tid;
    zT_55 = ft;
    zT_57 = out;
    zT_58 = (unsigned int*)&off;
    zT_59 = start;
    zT_60 = probe;
    zT_61 = probe_target;
    zT_64 = zF_DAC9FA8B_typeRefsNote(zT_53, zT_54, zT_55, (unsigned char)(0), zT_57, zT_58, zT_59, zT_60, zT_61);
    if ((unsigned char)(zT_64 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_68 = 1;
    zT_70 = i + (unsigned int)((unsigned int)zT_68);
    i = zT_70;
    goto z_bb_13;
    z_bb_17:
    return (unsigned int)(1);
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_75 = self->tu_items;
    zT_76 = ty.payload_idx;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zT_75[zT_77];
    tp = zT_78;
    zT_80 = 0;
    i = zT_80;
    goto z_bb_22;
    z_bb_20:
    goto z_bb_8;
    z_bb_21:
    zT_125 = ty.kind;
    if ((unsigned char)(zT_125 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_30; else goto z_bb_32;
    z_bb_22:
    zT_81 = tp.fields_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_81))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_85 = self->fe_items;
    zT_86 = tp.fields_start;
    zT_88 = (unsigned int)((unsigned int)zT_86) + i;
    zT_89 = zT_85[zT_88];
    zT_90 = zT_89.type_id;
    ft = zT_90;
    zT_91 = self;
    zT_92 = tid;
    zT_93 = ft;
    zT_95 = out;
    zT_96 = (unsigned int*)&off;
    zT_97 = start;
    zT_98 = probe;
    zT_99 = probe_target;
    zT_102 = zF_DAC9FA8B_typeRefsNote(zT_91, zT_92, zT_93, (unsigned char)(0), zT_95, zT_96, zT_97, zT_98, zT_99);
    if ((unsigned char)(zT_102 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    zT_109 = self;
    zT_110 = tid;
    zT_111 = tp.tag_type;
    zT_113 = out;
    zT_114 = (unsigned int*)&off;
    zT_115 = start;
    zT_116 = probe;
    zT_117 = probe_target;
    zT_121 = zF_DAC9FA8B_typeRefsNote(zT_109, zT_110, zT_111, (unsigned char)(0), zT_113, zT_114, zT_115, zT_116, zT_117);
    if ((unsigned char)(zT_121 != (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_106 = 1;
    zT_108 = i + (unsigned int)((unsigned int)zT_106);
    i = zT_108;
    goto z_bb_22;
    z_bb_26:
    return (unsigned int)(1);
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    return (unsigned int)(1);
    z_bb_29:
    goto z_bb_20;
    z_bb_30:
    zT_129 = self->array_items;
    zT_130 = ty.payload_idx;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zT_129[zT_131];
    zT_133 = zT_132.elem;
    et = zT_133;
    zT_134 = self;
    zT_135 = tid;
    zT_136 = et;
    zT_138 = out;
    zT_139 = (unsigned int*)&off;
    zT_140 = start;
    zT_141 = probe;
    zT_142 = probe_target;
    zT_145 = zF_DAC9FA8B_typeRefsNote(zT_134, zT_135, zT_136, (unsigned char)(0), zT_138, zT_139, zT_140, zT_141, zT_142);
    if ((unsigned char)(zT_145 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_20;
    z_bb_32:
    zT_149 = ty.kind;
    if ((unsigned char)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    return (unsigned int)(1);
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_153 = self->eu_items;
    zT_154 = ty.payload_idx;
    zT_155 = (unsigned int)zT_154;
    zT_156 = zT_153[zT_155];
    zT_157 = zT_156.payload;
    eup = zT_157;
    zT_158 = self;
    zT_159 = tid;
    zT_160 = eup;
    zT_162 = out;
    zT_163 = (unsigned int*)&off;
    zT_164 = start;
    zT_165 = probe;
    zT_166 = probe_target;
    zT_169 = zF_DAC9FA8B_typeRefsNote(zT_158, zT_159, zT_160, (unsigned char)(0), zT_162, zT_163, zT_164, zT_165, zT_166);
    if ((unsigned char)(zT_169 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_173 = ty.kind;
    if ((unsigned char)(zT_173 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_38:
    return (unsigned int)(1);
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_177 = self->opt_items;
    zT_178 = ty.payload_idx;
    zT_179 = (unsigned int)zT_178;
    zT_180 = zT_177[zT_179];
    zT_181 = zT_180.payload;
    op = zT_181;
    zT_182 = self;
    zT_183 = tid;
    zT_184 = op;
    zT_186 = out;
    zT_187 = (unsigned int*)&off;
    zT_188 = start;
    zT_189 = probe;
    zT_190 = probe_target;
    zT_193 = zF_DAC9FA8B_typeRefsNote(zT_182, zT_183, zT_184, (unsigned char)(0), zT_186, zT_187, zT_188, zT_189, zT_190);
    if ((unsigned char)(zT_193 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_36;
    z_bb_42:
    zT_197 = ty.kind;
    if ((unsigned char)(zT_197 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_45; else goto z_bb_47;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    goto z_bb_41;
    z_bb_45:
    zT_201 = self->slice_items;
    zT_202 = ty.payload_idx;
    zT_203 = (unsigned int)zT_202;
    zT_204 = zT_201[zT_203];
    zT_205 = zT_204.elem;
    se = zT_205;
    zT_206 = self;
    zT_207 = tid;
    zT_208 = se;
    zT_210 = out;
    zT_211 = (unsigned int*)&off;
    zT_212 = start;
    zT_213 = probe;
    zT_214 = probe_target;
    zT_217 = zF_DAC9FA8B_typeRefsNote(zT_206, zT_207, zT_208, (unsigned char)(1), zT_210, zT_211, zT_212, zT_213, zT_214);
    if ((unsigned char)(zT_217 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    goto z_bb_41;
    z_bb_47:
    zT_221 = ty.kind;
    if ((unsigned char)(zT_221 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_50; else goto z_bb_52;
    z_bb_48:
    return (unsigned int)(1);
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_225 = self->tup_items;
    zT_226 = ty.payload_idx;
    zT_227 = (unsigned int)zT_226;
    zT_228 = zT_225[zT_227];
    tp_1 = zT_228;
    zT_230 = 0;
    i = zT_230;
    goto z_bb_53;
    z_bb_51:
    goto z_bb_46;
    z_bb_52:
    zT_258 = ty.kind;
    if ((unsigned char)(zT_258 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_59; else goto z_bb_60;
    z_bb_53:
    zT_231 = tp_1.elems_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_231))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_235 = self->xt_items;
    zT_236 = tp_1.elems_start;
    zT_238 = (unsigned int)((unsigned int)zT_236) + i;
    zT_239 = zT_235[zT_238];
    et = zT_239;
    zT_240 = self;
    zT_241 = tid;
    zT_242 = et;
    zT_244 = out;
    zT_245 = (unsigned int*)&off;
    zT_246 = start;
    zT_247 = probe;
    zT_248 = probe_target;
    zT_251 = zF_DAC9FA8B_typeRefsNote(zT_240, zT_241, zT_242, (unsigned char)(0), zT_244, zT_245, zT_246, zT_247, zT_248);
    if ((unsigned char)(zT_251 != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    goto z_bb_51;
    z_bb_56:
    zT_255 = 1;
    zT_257 = i + (unsigned int)((unsigned int)zT_255);
    i = zT_257;
    goto z_bb_53;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_262 = self->fn_items;
    zT_263 = ty.payload_idx;
    zT_264 = (unsigned int)zT_263;
    zT_265 = zT_262[zT_264];
    fp = zT_265;
    zT_266 = self;
    zT_267 = tid;
    zT_268 = fp.return_type;
    zT_270 = out;
    zT_271 = (unsigned int*)&off;
    zT_272 = start;
    zT_273 = probe;
    zT_274 = probe_target;
    zT_278 = zF_DAC9FA8B_typeRefsNote(zT_266, zT_267, zT_268, (unsigned char)(1), zT_270, zT_271, zT_272, zT_273, zT_274);
    if ((unsigned char)(zT_278 != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_51;
    z_bb_61:
    return (unsigned int)(1);
    z_bb_62:
    zT_283 = fp.params_start;
    zT_285 = fp.params_count;
    zT_287 = (unsigned int)((unsigned int)zT_283) + (unsigned int)((unsigned int)zT_285);
    fpend = zT_287;
    zT_288 = self->xt_len;
    if ((unsigned char)(fpend <= zT_288)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_291 = fp.params_start;
    zT_292 = (unsigned int)zT_291;
    pi = zT_292;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_60;
    z_bb_65:
    if ((unsigned char)(pi < fpend)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_294 = self;
    zT_295 = tid;
    zT_303 = self->xt_items;
    zT_296 = zT_303[pi];
    zT_298 = out;
    zT_299 = (unsigned int*)&off;
    zT_300 = start;
    zT_301 = probe;
    zT_302 = probe_target;
    zT_307 = zF_DAC9FA8B_typeRefsNote(zT_294, zT_295, zT_296, (unsigned char)(1), zT_298, zT_299, zT_300, zT_301, zT_302);
    if ((unsigned char)(zT_307 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_312 = pi + (unsigned int)(1);
    pi = zT_312;
    goto z_bb_65;
    z_bb_69:
    return (unsigned int)(1);
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    return (unsigned int)(0);
    z_bb_72:
    return (unsigned int)(off - start);
}

/* typeRefs */
unsigned int zF_F41AC8EB_typeRefs(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int* out) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int* zT_5;
    unsigned int zT_12 = 0;
    zT_3 = self;
    zT_4 = tid;
    zT_5 = out;
    zT_12 = zF_07B0FCB6_typeRefsWalk(zT_3, zT_4, zT_5, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0));
    return zT_12;
}

/* typeRefsContains */
unsigned char zF_8A421992_typeRefsContains(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int target) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    unsigned char zT_7 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_23 = 0;
    zT_939EE900_Arr_unsigned_int_1 dummy;
    if ((unsigned char)(target == tid)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_5 = self;
    zT_6 = target;
    zT_7 = zF_E789C17A_typeNeedsFullDef(zT_5, zT_6);
    if ((unsigned char)(!zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_11[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        dummy[_i] = zT_11[_i];
        _i++;
    }
}
    zT_12 = self;
    zT_13 = tid;
    zT_18 = 0;
    zT_17 = target;
    zT_23 = zF_07B0FCB6_typeRefsWalk(zT_12, zT_13, (unsigned int*)((unsigned int*)(unsigned int*)(dummy + zT_18)), (unsigned int)(0), (unsigned int)(1), zT_17);
    if ((unsigned char)(zT_23 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(0);
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
unsigned char zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    return (unsigned char)(0);
}

/* typeRegistryIsInteger */
unsigned char zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    return (unsigned char)(0);
}

/* typeRegistryIsUnsigned */
unsigned char zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(0);
}

/* typeRegistryIsPointer */
unsigned char zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
unsigned char zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type));
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_8 = zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeKindIsSignedIntBase */
unsigned char zF_6D4AC571_typeKindIsSignedInt(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char zT_15;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_9 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_9) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_12) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_15 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_15;
    z_bb_14:
    zT_15 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_15) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
}

/* typeKindIsUnsignedIntBase */
unsigned char zF_C8A7A444_typeKindIsUnsignedI(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char zT_15;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_9 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_9) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_12) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_15 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type);
    goto z_bb_15;
    z_bb_14:
    zT_15 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_15) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
}

/* typeKindIntWidthBytes */
unsigned int zF_450A9F7B_typeKindIntWidthByt(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_12;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_27;
    unsigned char zT_30;
    unsigned char zT_33;
    unsigned char zT_36;
    unsigned char zT_42;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(1);
    z_bb_8:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(2);
    z_bb_13:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned int)(1);
    z_bb_15:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_21 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_18;
    z_bb_17:
    zT_21 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_21) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_24 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_21;
    z_bb_20:
    zT_24 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_24) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_27 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_24;
    z_bb_23:
    zT_27 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_27) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_33 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_30;
    z_bb_29:
    zT_33 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_33) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_36 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_33;
    z_bb_32:
    zT_36 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_36) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return (unsigned int)(4);
    z_bb_35:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_42 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_38;
    z_bb_37:
    zT_42 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_42) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned int)(8);
    z_bb_40:
    return (unsigned int)(0);
}

/* typeRegistryIntSignednessClass */
signed char zF_DE90B14C_typeRegistryIntSign(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11 = 0;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned char zT_20;
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_28 = 0;
    unsigned char zT_31;
    zT_33EF6BFB_TypeKind k;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (signed char)((signed char)-1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_10 = k;
    zT_11 = zF_6D4AC571_typeKindIsSignedInt(zT_10);
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_17 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_20 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_11;
    z_bb_10:
    zT_20 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_20) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_23 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_14;
    z_bb_13:
    zT_23 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_23) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (signed char)(1);
    z_bb_16:
    zT_27 = k;
    zT_28 = zF_C8A7A444_typeKindIsUnsignedI(zT_27);
    if ((unsigned char)(zT_28 != (unsigned char)(0))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_31 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_19;
    z_bb_18:
    zT_31 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_31) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (signed char)(0);
    z_bb_21:
    return (signed char)((signed char)-1);
}

/* typeRegistryIntNeedsWidthWrap */
unsigned char zF_AA3DF530_typeRegistryIntNeed(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    unsigned char zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_20 = 0;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned char zT_29;
    zT_D155D06D_Type ty;
    unsigned char w;
    unsigned int cb;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.kind;
    if ((unsigned char)(zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = ty.kind;
    zT_12 = zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_5;
    z_bb_4:
    zT_12 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = self;
    zT_19 = tyid;
    zT_20 = zF_655972D5_typeRegistryIntWidt(zT_18, zT_19);
    w = zT_20;
    zT_22 = ty.size;
    zT_25 = (unsigned int)(unsigned int)(zT_22 * (unsigned int)(8));
    cb = zT_25;
    if ((unsigned char)((unsigned int)((unsigned int)w) < (unsigned int)(1))) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_29 = (unsigned int)((unsigned int)w) >= cb;
    goto z_bb_10;
    z_bb_9:
    zT_29 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    return (unsigned char)(1);
}

/* typeRegistryIntByteWidth */
unsigned int zF_47244FDF_typeRegistryIntByte(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_12 = 0;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    unsigned int zT_18;
    zT_33EF6BFB_TypeKind k;
    unsigned int w;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_11 = k;
    zT_12 = zF_450A9F7B_typeKindIntWidthByt(zT_11);
    w = zT_12;
    if ((unsigned char)(w != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return w;
    z_bb_4:
    zT_15 = self->types_items;
    zT_16 = (unsigned int)tyid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17.size;
    return zT_18;
}

/* typeRegistryIsIntKind */
unsigned char zF_AA5656C9_typeRegistryIsIntKi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11 = 0;
    unsigned char zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    unsigned char zT_16 = 0;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    zT_33EF6BFB_TypeKind k;
    if ((unsigned char)(tid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_10 = k;
    zT_11 = zF_6D4AC571_typeKindIsSignedInt(zT_10);
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_15 = k;
    zT_16 = zF_C8A7A444_typeKindIsUnsignedI(zT_15);
    zT_14 = zT_16 != (unsigned char)(0);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_19 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_22 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_11;
    z_bb_10:
    zT_22 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_22) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_25 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_14;
    z_bb_13:
    zT_25 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_25) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_28 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_17;
    z_bb_16:
    zT_28 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_28) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_31 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_20;
    z_bb_19:
    zT_31 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_31) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    return (unsigned char)(0);
}

/* typeRegistryIsScalarC */
unsigned char zF_7B6AECEB_typeRegistryIsScala(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned char zT_4;
    unsigned char zT_7;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    unsigned char zT_17 = 0;
    unsigned char zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22 = 0;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned char zT_37;
    unsigned char zT_40;
    unsigned char zT_43;
    unsigned char zT_46;
    unsigned char zT_49;
    unsigned char zT_52;
    unsigned char zT_55;
    zT_33EF6BFB_TypeKind rv_k;
    if ((unsigned char)(tid == (unsigned int)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = tid == (unsigned int)(18);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = tid == (unsigned int)(0);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    zT_15 = zT_14.kind;
    rv_k = zT_15;
    zT_16 = rv_k;
    zT_17 = zF_6D4AC571_typeKindIsSignedInt(zT_16);
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_21 = rv_k;
    zT_22 = zF_C8A7A444_typeKindIsUnsignedI(zT_21);
    zT_20 = zT_22 != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_20 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_20) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_25 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_14;
    z_bb_13:
    zT_25 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_25) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_28 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_17;
    z_bb_16:
    zT_28 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_28) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_31 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_20;
    z_bb_19:
    zT_31 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_31) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_34 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_23;
    z_bb_22:
    zT_34 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_34) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_37 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type);
    goto z_bb_26;
    z_bb_25:
    zT_37 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_37) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_40 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_29;
    z_bb_28:
    zT_40 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_40) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_43 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_32;
    z_bb_31:
    zT_43 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_43) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_46 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_35;
    z_bb_34:
    zT_46 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_46) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_49 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_38;
    z_bb_37:
    zT_49 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_49) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_52 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_41;
    z_bb_40:
    zT_52 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_52) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_55 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_44;
    z_bb_43:
    zT_55 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_55) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    return (unsigned char)(0);
}

/* typeRegistryArrayByteSize */
zT_BAEE192E_Opt_10 zF_C35DA834_typeRegistryArrayBy(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9.has_value = 0;
    return zT_9;
    z_bb_2:
    zT_10 = ty.state;
    if ((unsigned char)(zT_10 != (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.size;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    unsigned char zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    if ((unsigned char)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
unsigned char zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type));
}

/* typeRegistryIsErrorSet */
unsigned char zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = (zT_2DF01B61_FieldEntry*)zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsPacked */
unsigned char zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.flags;
    return (unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) != (unsigned char)(0));
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_10;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    unsigned char zT_64;
    unsigned char zT_65;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    unsigned int zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_E276DDD0_PackedBitField zT_80;
    zT_E276DDD0_PackedBitField zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_86;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    zT_FA398D58_PackedStructInfo zT_89;
    zT_FA398D58_PackedStructInfo zT_91;
    unsigned short zT_92;
    unsigned int zT_97;
    unsigned int zT_100;
    zT_D155D06D_Type* zT_102;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_10 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(fi < fcount)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = fstart + fi;
    zT_46 = zT_44[zT_45];
    fe = zT_46;
    zT_48 = 1;
    w = zT_48;
    zT_49 = fe.type_id;
    zT_50 = self->types_len;
    if ((unsigned char)(zT_49 < (unsigned int)((unsigned int)zT_50))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_87 = self;
    zT_88 = ty.payload_idx;
    zT_91.pk_start = pk_start;
    zT_92 = (unsigned short)fcount;
    zT_91.pk_count = zT_92;
    zT_91.total_bits = total_bits;
    zT_89 = zT_91;
    zF_41767D71_pkSetFields(zT_87, zT_88, zT_89);
    zT_97 = (unsigned int)(total_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_97;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_84 = 1;
    zT_86 = fi + (unsigned int)((unsigned int)zT_84);
    fi = zT_86;
    goto z_bb_9;
    z_bb_13:
    zT_54 = self->types_items;
    zT_55 = fe.type_id;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    ft = zT_57;
    zT_58 = ft.kind;
    if ((unsigned char)(zT_58 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_81.bit_offset = total_bits;
    zT_82 = (unsigned short)w;
    zT_81.bit_width = zT_82;
    zT_80 = zT_81;
    zF_E48D8B88_pkFieldAppend(zT_79, zT_80);
    zT_83 = total_bits + w;
    total_bits = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_61 = ft.kind;
    if ((unsigned char)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_65 = ft.flags;
    zT_64 = (unsigned char)(zT_65 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_19;
    z_bb_18:
    zT_64 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_70 = self;
    zT_71 = fe.type_id;
    zT_73 = zF_CB27DBA4_typeRegistryGetPack(zT_70, zT_71);
    w = zT_73;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_74 = self;
    zT_75 = fe.type_id;
    zT_77 = zF_655972D5_typeRegistryIntWidt(zT_74, zT_75);
    zT_78 = (unsigned int)zT_77;
    w = zT_78;
    goto z_bb_21;
    z_bb_23:
    zT_100 = 1;
    sz = zT_100;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned short)(1);
    zT_102 = self->types_items;
    zT_102[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
unsigned char zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_E276DDD0_PackedBitField* zT_46;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_50;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_15 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    if ((unsigned char)(zT_21 >= (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_28 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_26) >= zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    zT_43 = self->pk_len;
    if ((unsigned char)((unsigned int)(pstart + pcount) > zT_43)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_46 = self->pk_items;
    zT_48 = zT_46 + pstart;
    zT_49 = (unsigned int)(pstart + pcount) - pstart;
    zT_50.ptr = (zT_E276DDD0_PackedBitField*)zT_48;
    zT_50.len = zT_49;
    *out = zT_50;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    if ((unsigned char)(zT_20 >= (unsigned int)((unsigned int)zT_21))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_27 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_25) >= zT_27)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(0);
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.flags;
    ty.flags = (unsigned char)(zT_6 | (unsigned char)(16));
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    zT_2DF01B61_FieldEntry zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D155D06D_Type zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_59;
    unsigned char zT_60;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_E276DDD0_PackedBitField zT_75;
    zT_E276DDD0_PackedBitField zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    int zT_80;
    unsigned int zT_82;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_FA398D58_PackedStructInfo zT_85;
    zT_FA398D58_PackedStructInfo zT_87;
    unsigned short zT_88;
    unsigned int zT_93;
    unsigned int zT_96;
    zT_D155D06D_Type* zT_98;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    if ((unsigned char)(zT_10 >= (unsigned int)((unsigned int)zT_11))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = fstart + fi;
    zT_41 = zT_39[zT_40];
    fe = zT_41;
    zT_43 = 1;
    w = zT_43;
    zT_44 = fe.type_id;
    zT_45 = self->types_len;
    if ((unsigned char)(zT_44 < (unsigned int)((unsigned int)zT_45))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_83 = self;
    zT_84 = ty.payload_idx;
    zT_87.pk_start = pk_start;
    zT_88 = (unsigned short)fcount;
    zT_87.pk_count = zT_88;
    zT_87.total_bits = max_bits;
    zT_85 = zT_87;
    zF_0213D00C_pkUnSetFields(zT_83, zT_84, zT_85);
    zT_93 = (unsigned int)(max_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_93;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_80 = 1;
    zT_82 = fi + (unsigned int)((unsigned int)zT_80);
    fi = zT_82;
    goto z_bb_7;
    z_bb_11:
    zT_49 = self->types_items;
    zT_50 = fe.type_id;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    ft = zT_52;
    zT_53 = ft.kind;
    if ((unsigned char)(zT_53 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_74 = self;
    zT_77 = 0;
    zT_76.bit_offset = zT_77;
    zT_78 = (unsigned short)w;
    zT_76.bit_width = zT_78;
    zT_75 = zT_76;
    zF_E48D8B88_pkFieldAppend(zT_74, zT_75);
    if ((unsigned char)(w > max_bits)) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_56 = ft.kind;
    if ((unsigned char)(zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_60 = ft.flags;
    zT_59 = (unsigned char)(zT_60 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_17;
    z_bb_16:
    zT_59 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_59) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_65 = self;
    zT_66 = fe.type_id;
    zT_68 = zF_CB27DBA4_typeRegistryGetPack(zT_65, zT_66);
    w = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_69 = self;
    zT_70 = fe.type_id;
    zT_72 = zF_655972D5_typeRegistryIntWidt(zT_69, zT_70);
    zT_73 = (unsigned int)zT_72;
    w = zT_73;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_96 = 1;
    sz = zT_96;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned short)(1);
    zT_98 = self->types_items;
    zT_98[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
unsigned char zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_E276DDD0_PackedBitField* zT_40;
    zT_E276DDD0_PackedBitField* zT_42;
    unsigned int zT_43;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_44;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_22 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_20) >= zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    zT_37 = self->pk_len;
    if ((unsigned char)((unsigned int)(pstart + pcount) > zT_37)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_40 = self->pk_items;
    zT_42 = zT_40 + pstart;
    zT_43 = (unsigned int)(pstart + pcount) - pstart;
    zT_44.ptr = (zT_E276DDD0_PackedBitField*)zT_42;
    zT_44.len = zT_43;
    *out = zT_44;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    if ((unsigned char)(zT_14 >= (unsigned int)((unsigned int)zT_15))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = (zT_2DF01B61_FieldEntry*)zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* pointerQualifiersMonotone */
unsigned char zF_08C13644_pointerQualifiersMo(unsigned char src_flags, unsigned char tgt_flags, unsigned char mask) {
    return (unsigned char)((unsigned char)((unsigned char)(src_flags & mask) & (unsigned char)(~(unsigned char)(tgt_flags & mask))) == (unsigned char)(0));
}

/* typeRegistryTypesEquiv */
unsigned char zF_3130DDCF_typeRegistryTypesEq(zT_338B7C76_TypeRegistry* self, unsigned int a, unsigned int b) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned char zT_8 = 0;
    zT_3 = self;
    zT_4 = a;
    zT_5 = b;
    zT_8 = zF_4D8FED56_typesEquivRec(zT_3, zT_4, zT_5, (unsigned int)(0));
    return zT_8;
}

/* typesEquivRec */
unsigned char zF_4D8FED56_typesEquivRec(zT_338B7C76_TypeRegistry* self, unsigned int a, unsigned int b, unsigned int depth) {
    unsigned int zT_10;
    unsigned int zT_14;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_0B10E8E9_OptionalPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_0B10E8E9_OptionalPayload zT_46;
    zT_0B10E8E9_OptionalPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_0B10E8E9_OptionalPayload zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    zT_33EF6BFB_TypeKind zT_61;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_42C2D6BF_EUPayload* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_42C2D6BF_EUPayload zT_78;
    zT_42C2D6BF_EUPayload* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_42C2D6BF_EUPayload zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_338B7C76_TypeRegistry* zT_88;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_33EF6BFB_TypeKind zT_97;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_E834303C_ArrayPayload* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_E834303C_ArrayPayload zT_114;
    zT_E834303C_ArrayPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_E834303C_ArrayPayload zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_338B7C76_TypeRegistry* zT_124;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_131;
    zT_33EF6BFB_TypeKind zT_133;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_146;
    unsigned char zT_147;
    zT_0BB2A741_SlicePayload* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    zT_0BB2A741_SlicePayload zT_154;
    zT_0BB2A741_SlicePayload* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_0BB2A741_SlicePayload zT_159;
    zT_338B7C76_TypeRegistry* zT_160;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_167;
    zT_33EF6BFB_TypeKind zT_169;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_666DC2E1_TuplePayload* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_666DC2E1_TuplePayload zT_186;
    zT_666DC2E1_TuplePayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_666DC2E1_TuplePayload zT_191;
    unsigned short zT_192;
    unsigned short zT_193;
    int zT_197;
    unsigned short zT_198;
    unsigned short zT_199;
    unsigned int* zT_202;
    unsigned int zT_203;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int* zT_209;
    unsigned int zT_210;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_338B7C76_TypeRegistry* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned char zT_221 = 0;
    int zT_224;
    unsigned short zT_226;
    zT_33EF6BFB_TypeKind zT_228;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_0317B1D5_FnPayload* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_0317B1D5_FnPayload zT_245;
    zT_0317B1D5_FnPayload* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    zT_0317B1D5_FnPayload zT_250;
    unsigned short zT_251;
    unsigned short zT_252;
    unsigned char zT_255;
    unsigned char zT_256;
    zT_338B7C76_TypeRegistry* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned char zT_267 = 0;
    int zT_271;
    unsigned short zT_272;
    unsigned short zT_273;
    unsigned int* zT_276;
    unsigned int zT_277;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned int* zT_283;
    unsigned int zT_284;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_338B7C76_TypeRegistry* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_295 = 0;
    int zT_298;
    unsigned short zT_300;
    zT_D155D06D_Type ta;
    zT_D155D06D_Type tb;
    zT_0B10E8E9_OptionalPayload oa;
    zT_0B10E8E9_OptionalPayload ob;
    zT_42C2D6BF_EUPayload ea;
    zT_42C2D6BF_EUPayload eb;
    zT_E834303C_ArrayPayload aa;
    zT_E834303C_ArrayPayload ab;
    zT_0BB2A741_SlicePayload sa;
    zT_0BB2A741_SlicePayload sb;
    zT_666DC2E1_TuplePayload pa;
    zT_666DC2E1_TuplePayload pb;
    unsigned short ei;
    unsigned int xa;
    unsigned int xb;
    zT_0317B1D5_FnPayload fa;
    zT_0317B1D5_FnPayload fb;
    unsigned short fi;
    unsigned int xa2;
    unsigned int xb2;
    z_bb_0:
    if ((unsigned char)(a == b)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_10 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)a) >= zT_10)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_14 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)b) >= zT_14)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_18 = self->types_items;
    zT_19 = (unsigned int)a;
    zT_20 = zT_18[zT_19];
    ta = zT_20;
    zT_22 = self->types_items;
    zT_23 = (unsigned int)b;
    zT_24 = zT_22[zT_23];
    tb = zT_24;
    zT_25 = ta.kind;
    zT_26 = tb.kind;
    if ((unsigned char)(zT_25 != zT_26)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_29 = ta.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ta.payload_idx;
    zT_33 = self->opt_len;
    if ((unsigned char)(zT_32 >= (unsigned int)((unsigned int)zT_33))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_61 = ta.kind;
    if ((unsigned char)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_37 = tb.payload_idx;
    zT_38 = self->opt_len;
    if ((unsigned char)(zT_37 >= (unsigned int)((unsigned int)zT_38))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_43 = self->opt_items;
    zT_44 = ta.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    oa = zT_46;
    zT_48 = self->opt_items;
    zT_49 = tb.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    ob = zT_51;
    zT_52 = self;
    zT_56 = oa.payload;
    zT_57 = ob.payload;
    zT_59 = depth + (unsigned int)(1);
    self = zT_52;
    a = zT_56;
    b = zT_57;
    depth = zT_59;
    goto z_bb_0;
    z_bb_17:
    zT_64 = ta.payload_idx;
    zT_65 = self->eu_len;
    if ((unsigned char)(zT_64 >= (unsigned int)((unsigned int)zT_65))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_97 = ta.kind;
    if ((unsigned char)(zT_97 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    zT_69 = tb.payload_idx;
    zT_70 = self->eu_len;
    if ((unsigned char)(zT_69 >= (unsigned int)((unsigned int)zT_70))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_75 = self->eu_items;
    zT_76 = ta.payload_idx;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zT_75[zT_77];
    ea = zT_78;
    zT_80 = self->eu_items;
    zT_81 = tb.payload_idx;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zT_80[zT_82];
    eb = zT_83;
    zT_84 = ea.error_set;
    zT_85 = eb.error_set;
    if ((unsigned char)(zT_84 != zT_85)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    zT_88 = self;
    zT_92 = ea.payload;
    zT_93 = eb.payload;
    zT_95 = depth + (unsigned int)(1);
    self = zT_88;
    a = zT_92;
    b = zT_93;
    depth = zT_95;
    goto z_bb_0;
    z_bb_25:
    zT_100 = ta.payload_idx;
    zT_101 = self->array_len;
    if ((unsigned char)(zT_100 >= (unsigned int)((unsigned int)zT_101))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_133 = ta.kind;
    if ((unsigned char)(zT_133 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_105 = tb.payload_idx;
    zT_106 = self->array_len;
    if ((unsigned char)(zT_105 >= (unsigned int)((unsigned int)zT_106))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(0);
    z_bb_30:
    zT_111 = self->array_items;
    zT_112 = ta.payload_idx;
    zT_113 = (unsigned int)zT_112;
    zT_114 = zT_111[zT_113];
    aa = zT_114;
    zT_116 = self->array_items;
    zT_117 = tb.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    ab = zT_119;
    zT_120 = aa.length;
    zT_121 = ab.length;
    if ((unsigned char)(zT_120 != zT_121)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (unsigned char)(0);
    z_bb_32:
    zT_124 = self;
    zT_128 = aa.elem;
    zT_129 = ab.elem;
    zT_131 = depth + (unsigned int)(1);
    self = zT_124;
    a = zT_128;
    b = zT_129;
    depth = zT_131;
    goto z_bb_0;
    z_bb_33:
    zT_136 = ta.payload_idx;
    zT_137 = self->slice_len;
    if ((unsigned char)(zT_136 >= (unsigned int)((unsigned int)zT_137))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_169 = ta.kind;
    if ((unsigned char)(zT_169 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_35:
    return (unsigned char)(0);
    z_bb_36:
    zT_141 = tb.payload_idx;
    zT_142 = self->slice_len;
    if ((unsigned char)(zT_141 >= (unsigned int)((unsigned int)zT_142))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(0);
    z_bb_38:
    zT_146 = ta.flags;
    zT_147 = tb.flags;
    if ((unsigned char)(zT_146 != zT_147)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(0);
    z_bb_40:
    zT_151 = self->slice_items;
    zT_152 = ta.payload_idx;
    zT_153 = (unsigned int)zT_152;
    zT_154 = zT_151[zT_153];
    sa = zT_154;
    zT_156 = self->slice_items;
    zT_157 = tb.payload_idx;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_156[zT_158];
    sb = zT_159;
    zT_160 = self;
    zT_164 = sa.elem;
    zT_165 = sb.elem;
    zT_167 = depth + (unsigned int)(1);
    self = zT_160;
    a = zT_164;
    b = zT_165;
    depth = zT_167;
    goto z_bb_0;
    z_bb_41:
    zT_172 = ta.payload_idx;
    zT_173 = self->tup_len;
    if ((unsigned char)(zT_172 >= (unsigned int)((unsigned int)zT_173))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_228 = ta.kind;
    if ((unsigned char)(zT_228 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_43:
    return (unsigned char)(0);
    z_bb_44:
    zT_177 = tb.payload_idx;
    zT_178 = self->tup_len;
    if ((unsigned char)(zT_177 >= (unsigned int)((unsigned int)zT_178))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(0);
    z_bb_46:
    zT_183 = self->tup_items;
    zT_184 = ta.payload_idx;
    zT_185 = (unsigned int)zT_184;
    zT_186 = zT_183[zT_185];
    pa = zT_186;
    zT_188 = self->tup_items;
    zT_189 = tb.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    pb = zT_191;
    zT_192 = pa.elems_count;
    zT_193 = pb.elems_count;
    if ((unsigned char)(zT_192 != zT_193)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(0);
    z_bb_48:
    zT_197 = 0;
    zT_198 = (unsigned short)zT_197;
    ei = zT_198;
    goto z_bb_49;
    z_bb_49:
    zT_199 = pa.elems_count;
    if ((unsigned char)(ei < zT_199)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_202 = self->xt_items;
    zT_203 = pa.elems_start;
    zT_206 = (unsigned int)((unsigned int)zT_203) + (unsigned int)((unsigned int)ei);
    zT_207 = zT_202[zT_206];
    xa = zT_207;
    zT_209 = self->xt_items;
    zT_210 = pb.elems_start;
    zT_213 = (unsigned int)((unsigned int)zT_210) + (unsigned int)((unsigned int)ei);
    zT_214 = zT_209[zT_213];
    xb = zT_214;
    zT_215 = self;
    zT_216 = xa;
    zT_217 = xb;
    zT_221 = zF_4D8FED56_typesEquivRec(zT_215, zT_216, zT_217, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_221)) goto z_bb_53; else goto z_bb_54;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    zT_224 = 1;
    zT_226 = ei + (unsigned short)((unsigned short)zT_224);
    ei = zT_226;
    goto z_bb_49;
    z_bb_53:
    return (unsigned char)(0);
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_231 = ta.payload_idx;
    zT_232 = self->fn_len;
    if ((unsigned char)(zT_231 >= (unsigned int)((unsigned int)zT_232))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    return (unsigned char)(0);
    z_bb_57:
    return (unsigned char)(0);
    z_bb_58:
    zT_236 = tb.payload_idx;
    zT_237 = self->fn_len;
    if ((unsigned char)(zT_236 >= (unsigned int)((unsigned int)zT_237))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(0);
    z_bb_60:
    zT_242 = self->fn_items;
    zT_243 = ta.payload_idx;
    zT_244 = (unsigned int)zT_243;
    zT_245 = zT_242[zT_244];
    fa = zT_245;
    zT_247 = self->fn_items;
    zT_248 = tb.payload_idx;
    zT_249 = (unsigned int)zT_248;
    zT_250 = zT_247[zT_249];
    fb = zT_250;
    zT_251 = fa.params_count;
    zT_252 = fb.params_count;
    if ((unsigned char)(zT_251 != zT_252)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (unsigned char)(0);
    z_bb_62:
    zT_255 = fa.flags_packed;
    zT_256 = fb.flags_packed;
    if ((unsigned char)(zT_255 != zT_256)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    zT_259 = self;
    zT_260 = fa.return_type;
    zT_261 = fb.return_type;
    zT_267 = zF_4D8FED56_typesEquivRec(zT_259, zT_260, zT_261, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_267)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (unsigned char)(0);
    z_bb_66:
    zT_271 = 0;
    zT_272 = (unsigned short)zT_271;
    fi = zT_272;
    goto z_bb_67;
    z_bb_67:
    zT_273 = fa.params_count;
    if ((unsigned char)(fi < zT_273)) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_276 = self->xt_items;
    zT_277 = fa.params_start;
    zT_280 = (unsigned int)((unsigned int)zT_277) + (unsigned int)((unsigned int)fi);
    zT_281 = zT_276[zT_280];
    xa2 = zT_281;
    zT_283 = self->xt_items;
    zT_284 = fb.params_start;
    zT_287 = (unsigned int)((unsigned int)zT_284) + (unsigned int)((unsigned int)fi);
    zT_288 = zT_283[zT_287];
    xb2 = zT_288;
    zT_289 = self;
    zT_290 = xa2;
    zT_291 = xb2;
    zT_295 = zF_4D8FED56_typesEquivRec(zT_289, zT_290, zT_291, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_295)) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    zT_298 = 1;
    zT_300 = fi + (unsigned short)((unsigned short)zT_298);
    fi = zT_300;
    goto z_bb_67;
    z_bb_71:
    return (unsigned char)(0);
    z_bb_72:
    goto z_bb_70;
}

/* typeRegistryIsAssignable */
unsigned char zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_17;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned char zT_27 = 0;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38 = 0;
    unsigned char zT_39;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    unsigned char zT_42 = 0;
    unsigned char zT_43;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned char zT_48 = 0;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_51 = 0;
    unsigned char zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    unsigned char zT_56 = 0;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    unsigned char zT_59 = 0;
    unsigned char zT_64;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_71;
    unsigned int zT_72;
    unsigned char zT_73 = 0;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_79;
    zT_33EF6BFB_TypeKind zT_83;
    unsigned char zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_112BF819_PtrPayload* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_112BF819_PtrPayload zT_94;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107 = 0;
    zT_33EF6BFB_TypeKind zT_109;
    zT_0B10E8E9_OptionalPayload* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    zT_0B10E8E9_OptionalPayload zT_116;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_121 = 0;
    zT_33EF6BFB_TypeKind zT_123;
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char zT_130;
    zT_33EF6BFB_TypeKind zT_131;
    zT_42C2D6BF_EUPayload* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_42C2D6BF_EUPayload zT_138;
    zT_42C2D6BF_EUPayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_42C2D6BF_EUPayload zT_143;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned char zT_147;
    zT_338B7C76_TypeRegistry* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_154 = 0;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_33EF6BFB_TypeKind zT_158;
    zT_42C2D6BF_EUPayload* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_42C2D6BF_EUPayload zT_165;
    zT_338B7C76_TypeRegistry* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned char zT_170 = 0;
    zT_33EF6BFB_TypeKind zT_172;
    unsigned char zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    zT_33EF6BFB_TypeKind zT_180;
    unsigned char zT_183;
    zT_33EF6BFB_TypeKind zT_184;
    zT_112BF819_PtrPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_112BF819_PtrPayload zT_191;
    zT_112BF819_PtrPayload* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_112BF819_PtrPayload zT_196;
    unsigned char zT_198;
    unsigned char zT_199;
    unsigned char zT_200;
    unsigned int zT_203;
    unsigned char zT_204 = 0;
    unsigned int zT_205;
    unsigned int zT_208;
    unsigned char zT_211;
    unsigned char zT_216;
    unsigned char zT_217;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    unsigned char zT_227;
    unsigned char zT_232;
    unsigned char zT_233;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned char zT_241;
    unsigned char zT_242;
    unsigned char zT_247;
    unsigned char zT_248;
    zT_33EF6BFB_TypeKind zT_254;
    unsigned char zT_257;
    zT_33EF6BFB_TypeKind zT_258;
    unsigned char zT_262;
    unsigned char zT_263;
    unsigned char zT_264;
    unsigned int zT_267;
    unsigned char zT_268 = 0;
    unsigned char zT_269;
    unsigned char zT_274;
    unsigned char zT_275;
    zT_0BB2A741_SlicePayload* zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    zT_0BB2A741_SlicePayload zT_284;
    zT_0BB2A741_SlicePayload* zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_0BB2A741_SlicePayload zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    unsigned char zT_295;
    unsigned char zT_300;
    unsigned char zT_301;
    zT_0BB2A741_SlicePayload* zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    zT_0BB2A741_SlicePayload zT_310;
    zT_0BB2A741_SlicePayload* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_0BB2A741_SlicePayload zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned char zT_319;
    unsigned char zT_320;
    unsigned char zT_325;
    unsigned char zT_326;
    zT_33EF6BFB_TypeKind zT_332;
    unsigned char zT_335;
    zT_33EF6BFB_TypeKind zT_336;
    unsigned char zT_340;
    unsigned char zT_341;
    unsigned char zT_342;
    unsigned int zT_345;
    unsigned char zT_346 = 0;
    zT_112BF819_PtrPayload* zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_112BF819_PtrPayload zT_351;
    zT_0BB2A741_SlicePayload* zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    zT_0BB2A741_SlicePayload zT_356;
    zT_D155D06D_Type* zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    zT_D155D06D_Type zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    zT_E834303C_ArrayPayload* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    zT_E834303C_ArrayPayload zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned char zT_373;
    zT_33EF6BFB_TypeKind zT_375;
    unsigned char zT_378;
    zT_33EF6BFB_TypeKind zT_379;
    unsigned char zT_383;
    unsigned char zT_384;
    unsigned char zT_385;
    unsigned int zT_388;
    unsigned char zT_389 = 0;
    unsigned char zT_390;
    unsigned char zT_395;
    unsigned char zT_396;
    zT_112BF819_PtrPayload* zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    zT_112BF819_PtrPayload zT_405;
    zT_112BF819_PtrPayload* zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    zT_112BF819_PtrPayload zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned char zT_414;
    unsigned char zT_416;
    unsigned char zT_421;
    unsigned char zT_422;
    zT_112BF819_PtrPayload* zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    zT_112BF819_PtrPayload zT_431;
    zT_112BF819_PtrPayload* zT_433;
    unsigned int zT_434;
    unsigned int zT_435;
    zT_112BF819_PtrPayload zT_436;
    unsigned int zT_437;
    unsigned int zT_438;
    unsigned char zT_440;
    unsigned char zT_441;
    unsigned char zT_446;
    unsigned char zT_447;
    zT_33EF6BFB_TypeKind zT_453;
    unsigned char zT_456;
    zT_33EF6BFB_TypeKind zT_457;
    unsigned char zT_461;
    unsigned char zT_462;
    unsigned char zT_463;
    unsigned int zT_466;
    unsigned char zT_467 = 0;
    zT_E834303C_ArrayPayload* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    zT_E834303C_ArrayPayload zT_472;
    zT_0BB2A741_SlicePayload* zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_0BB2A741_SlicePayload zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned char zT_481;
    unsigned char zT_483;
    unsigned char zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned char zT_492;
    zT_33EF6BFB_TypeKind zT_494;
    unsigned char zT_497;
    zT_33EF6BFB_TypeKind zT_498;
    unsigned char zT_502;
    unsigned char zT_503;
    unsigned char zT_504;
    unsigned int zT_507;
    unsigned char zT_508 = 0;
    zT_E834303C_ArrayPayload* zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    zT_E834303C_ArrayPayload zT_513;
    zT_112BF819_PtrPayload* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    zT_112BF819_PtrPayload zT_518;
    unsigned int zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    zT_33EF6BFB_TypeKind zT_524;
    unsigned char zT_527;
    zT_33EF6BFB_TypeKind zT_528;
    unsigned char zT_532;
    unsigned char zT_533;
    unsigned char zT_534;
    unsigned int zT_537;
    unsigned char zT_538 = 0;
    zT_112BF819_PtrPayload* zT_540;
    unsigned int zT_541;
    unsigned int zT_542;
    zT_112BF819_PtrPayload zT_543;
    zT_112BF819_PtrPayload* zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    zT_112BF819_PtrPayload zT_548;
    zT_D155D06D_Type* zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    zT_D155D06D_Type zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    zT_E834303C_ArrayPayload* zT_558;
    unsigned int zT_559;
    unsigned int zT_560;
    zT_E834303C_ArrayPayload zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    unsigned char zT_565;
    zT_33EF6BFB_TypeKind zT_567;
    unsigned char zT_570;
    zT_33EF6BFB_TypeKind zT_571;
    zT_E834303C_ArrayPayload* zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    zT_E834303C_ArrayPayload zT_578;
    zT_E834303C_ArrayPayload* zT_580;
    unsigned int zT_581;
    unsigned int zT_582;
    zT_E834303C_ArrayPayload zT_583;
    unsigned int zT_584;
    unsigned int zT_585;
    unsigned char zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    zT_33EF6BFB_TypeKind zT_592;
    unsigned char zT_595;
    zT_33EF6BFB_TypeKind zT_596;
    unsigned char zT_600;
    unsigned char zT_601;
    unsigned char zT_602;
    unsigned int zT_605;
    unsigned char zT_606 = 0;
    zT_0BB2A741_SlicePayload* zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    zT_0BB2A741_SlicePayload zT_611;
    zT_112BF819_PtrPayload* zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    zT_112BF819_PtrPayload zT_616;
    unsigned int zT_617;
    unsigned int zT_618;
    unsigned char zT_620;
    zT_33EF6BFB_TypeKind zT_622;
    unsigned char zT_625;
    zT_33EF6BFB_TypeKind zT_626;
    zT_0B10E8E9_OptionalPayload* zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    zT_0B10E8E9_OptionalPayload zT_633;
    zT_D155D06D_Type* zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    zT_D155D06D_Type zT_638;
    zT_33EF6BFB_TypeKind zT_639;
    zT_338B7C76_TypeRegistry* zT_642;
    unsigned int zT_643;
    unsigned int zT_645;
    unsigned char zT_649;
    unsigned char zT_652;
    unsigned char zT_655;
    zT_33EF6BFB_TypeKind zT_659;
    unsigned char zT_662;
    zT_33EF6BFB_TypeKind zT_663;
    zT_666DC2E1_TuplePayload* zT_667;
    unsigned int zT_668;
    unsigned int zT_669;
    zT_666DC2E1_TuplePayload zT_670;
    zT_666DC2E1_TuplePayload* zT_672;
    unsigned int zT_673;
    unsigned int zT_674;
    zT_666DC2E1_TuplePayload zT_675;
    unsigned short zT_676;
    unsigned short zT_677;
    unsigned char zT_680;
    int zT_682;
    unsigned short zT_683;
    unsigned short zT_684;
    unsigned int* zT_687;
    unsigned int zT_688;
    unsigned int zT_691;
    unsigned int zT_692;
    unsigned int* zT_694;
    unsigned int zT_695;
    unsigned int zT_698;
    unsigned int zT_699;
    unsigned int zT_701;
    unsigned char zT_703;
    zT_D155D06D_Type* zT_704;
    unsigned int zT_705;
    zT_D155D06D_Type zT_706;
    zT_33EF6BFB_TypeKind zT_707;
    unsigned char zT_710;
    unsigned int zT_712;
    unsigned char zT_714;
    zT_D155D06D_Type* zT_715;
    unsigned int zT_716;
    zT_D155D06D_Type zT_717;
    zT_33EF6BFB_TypeKind zT_718;
    unsigned char zT_721;
    zT_338B7C76_TypeRegistry* zT_722;
    unsigned int zT_723;
    unsigned int zT_724;
    unsigned char zT_725 = 0;
    unsigned char zT_727;
    int zT_728;
    unsigned short zT_730;
    zT_33EF6BFB_TypeKind zT_732;
    unsigned char zT_735;
    zT_33EF6BFB_TypeKind zT_736;
    zT_666DC2E1_TuplePayload* zT_740;
    unsigned int zT_741;
    unsigned int zT_742;
    zT_666DC2E1_TuplePayload zT_743;
    zT_E834303C_ArrayPayload* zT_745;
    unsigned int zT_746;
    unsigned int zT_747;
    zT_E834303C_ArrayPayload zT_748;
    unsigned short zT_749;
    unsigned int zT_751;
    unsigned char zT_754;
    int zT_756;
    unsigned short zT_757;
    unsigned short zT_758;
    zT_338B7C76_TypeRegistry* zT_760;
    unsigned int zT_761;
    unsigned int zT_762;
    unsigned int* zT_763;
    unsigned int zT_764;
    unsigned int zT_767;
    unsigned char zT_770 = 0;
    unsigned char zT_772;
    int zT_773;
    unsigned short zT_775;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned char es_ok;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    unsigned char qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload s_sl2;
    zT_0BB2A741_SlicePayload t_sl2;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload s_pp2;
    zT_112BF819_PtrPayload t_pp2;
    zT_112BF819_PtrPayload pp;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_D155D06D_Type opt_ty;
    zT_666DC2E1_TuplePayload s_tup;
    zT_666DC2E1_TuplePayload t_tup;
    unsigned char ok;
    unsigned short k;
    unsigned int se;
    unsigned int te;
    zT_666DC2E1_TuplePayload tup;
    z_bb_0:
    if ((unsigned char)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_17 = src.kind;
    if ((unsigned char)(zT_17 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_21 = src.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self;
    zT_26 = target;
    zT_27 = zF_3087E0A5_typeRegistryIsNumer(zT_25, zT_26);
    zT_24 = zT_27;
    goto z_bb_9;
    z_bb_8:
    zT_24 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    zT_29 = src.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_32 = target == (unsigned int)(14);
    goto z_bb_14;
    z_bb_13:
    zT_32 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_32) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_36 = self;
    zT_37 = source;
    zT_38 = zF_3290E9C4_typeRegistryIsInteg(zT_36, zT_37);
    if (zT_38) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_40 = self;
    zT_41 = target;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_40, zT_41);
    zT_39 = zT_42;
    goto z_bb_19;
    z_bb_18:
    zT_39 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_39) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_43 = source != (unsigned int)(19);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_B664AC19_typeRegistryIsUnsig(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_B664AC19_typeRegistryIsUnsig(zT_49, zT_50);
    if ((unsigned char)(zT_48 == zT_51)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(source == (unsigned int)(15))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_54 = self;
    zT_55 = source;
    zT_56 = zF_655972D5_typeRegistryIntWidt(zT_54, zT_55);
    zT_57 = self;
    zT_58 = target;
    zT_59 = zF_655972D5_typeRegistryIntWidt(zT_57, zT_58);
    zT_53 = zT_56 < zT_59;
    goto z_bb_27;
    z_bb_26:
    zT_53 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    zT_64 = target == (unsigned int)(16);
    goto z_bb_32;
    z_bb_31:
    zT_64 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_64) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    zT_68 = src.kind;
    if ((unsigned char)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_71 = self;
    zT_72 = target;
    zT_73 = zF_AD61DB1B_typeRegistryIsPoint(zT_71, zT_72);
    if (zT_73) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_83 = src.kind;
    if ((unsigned char)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_75 = tgt.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_79 = tgt.kind;
    if ((unsigned char)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_87 = tgt.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_45;
    z_bb_44:
    zT_86 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_86) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_91 = self->ptr_items;
    zT_92 = tgt.payload_idx;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    tpp = zT_94;
    zT_96 = self->types_items;
    zT_97 = tpp.base;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    bt = zT_99;
    zT_100 = bt.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_109 = tgt.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_48:
    zT_103 = self;
    zT_104 = source;
    zT_105 = tpp.base;
    zT_107 = zF_3130DDCF_typeRegistryTypesEq(zT_103, zT_104, zT_105);
    if (zT_107) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    return (unsigned char)(1);
    z_bb_51:
    goto z_bb_49;
    z_bb_52:
    zT_113 = self->opt_items;
    zT_114 = tgt.payload_idx;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zT_113[zT_115];
    opt = zT_116;
    zT_117 = self;
    zT_118 = source;
    zT_119 = opt.payload;
    zT_121 = zF_683AEB7F_typeRegistryIsAssig(zT_117, zT_118, zT_119);
    if (zT_121) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_127 = src.kind;
    if ((unsigned char)(zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_54:
    return (unsigned char)(1);
    z_bb_55:
    zT_123 = src.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    return (unsigned char)(1);
    z_bb_57:
    goto z_bb_53;
    z_bb_58:
    zT_131 = tgt.kind;
    zT_130 = zT_131 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_60;
    z_bb_59:
    zT_130 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_130) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_135 = self->eu_items;
    zT_136 = src.payload_idx;
    zT_137 = (unsigned int)zT_136;
    zT_138 = zT_135[zT_137];
    eu_src = zT_138;
    zT_140 = self->eu_items;
    zT_141 = tgt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    eu_tgt = zT_143;
    zT_145 = eu_src.error_set;
    zT_146 = eu_tgt.error_set;
    zT_147 = zT_145 == zT_146;
    es_ok = zT_147;
    if ((unsigned char)(!es_ok)) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_158 = tgt.kind;
    if ((unsigned char)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_63:
    zT_149 = self;
    zT_150 = eu_src.error_set;
    zT_151 = eu_tgt.error_set;
    zT_154 = zF_E35E11A5_errorSetIsSubset(zT_149, zT_150, zT_151);
    es_ok = zT_154;
    goto z_bb_64;
    z_bb_64:
    if (es_ok) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_155 = eu_src.payload;
    zT_156 = eu_tgt.payload;
    return (unsigned char)(zT_155 == zT_156);
    z_bb_66:
    goto z_bb_62;
    z_bb_67:
    zT_162 = self->eu_items;
    zT_163 = tgt.payload_idx;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zT_162[zT_164];
    eu = zT_165;
    zT_166 = self;
    zT_167 = source;
    zT_168 = eu.payload;
    zT_170 = zF_683AEB7F_typeRegistryIsAssig(zT_166, zT_167, zT_168);
    if (zT_170) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_172 = src.kind;
    if ((unsigned char)(zT_172 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_176 = tgt.kind;
    zT_175 = zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_73;
    z_bb_72:
    zT_175 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_175) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    return (unsigned char)(1);
    z_bb_75:
    zT_180 = src.kind;
    if ((unsigned char)(zT_180 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_184 = tgt.kind;
    zT_183 = zT_184 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_78;
    z_bb_77:
    zT_183 = 0;
    goto z_bb_78;
    z_bb_78:
    if (zT_183) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_188 = self->ptr_items;
    zT_189 = tgt.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    tgt_pp = zT_191;
    zT_193 = self->ptr_items;
    zT_194 = src.payload_idx;
    zT_195 = (unsigned int)zT_194;
    zT_196 = zT_193[zT_195];
    src_pp = zT_196;
    zT_198 = src.flags;
    zT_199 = tgt.flags;
    zT_203 = 2;
    zT_200 = zT_203;
    zT_204 = zF_08C13644_pointerQualifiersMo(zT_198, zT_199, zT_200);
    qok = zT_204;
    zT_205 = tgt_pp.base;
    if ((unsigned char)(zT_205 == (unsigned int)(1))) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_254 = tgt.kind;
    if ((unsigned char)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_81:
    return qok;
    z_bb_82:
    zT_208 = src_pp.base;
    if ((unsigned char)(zT_208 == (unsigned int)(1))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    return qok;
    z_bb_84:
    zT_211 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_211 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_217 = src.flags;
    zT_216 = (unsigned char)(zT_217 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_87;
    z_bb_86:
    zT_216 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_216) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_222 = src_pp.base;
    zT_223 = tgt_pp.base;
    if ((unsigned char)(zT_222 == zT_223)) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    zT_227 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_227 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_90:
    zT_225 = qok;
    goto z_bb_92;
    z_bb_91:
    zT_225 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_225) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned char)(1);
    z_bb_94:
    goto z_bb_89;
    z_bb_95:
    zT_233 = src.flags;
    zT_232 = (unsigned char)(zT_233 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_97;
    z_bb_96:
    zT_232 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_232) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_238 = src_pp.base;
    zT_239 = tgt_pp.base;
    if ((unsigned char)(zT_238 == zT_239)) goto z_bb_100; else goto z_bb_101;
    z_bb_99:
    goto z_bb_80;
    z_bb_100:
    zT_242 = src.flags;
    if ((unsigned char)((unsigned char)(zT_242 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_104; else goto z_bb_103;
    z_bb_101:
    zT_241 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_241) goto z_bb_106; else goto z_bb_107;
    z_bb_103:
    zT_248 = tgt.flags;
    zT_247 = (unsigned char)(zT_248 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_105;
    z_bb_104:
    zT_247 = 1;
    goto z_bb_105;
    z_bb_105:
    zT_241 = zT_247;
    goto z_bb_102;
    z_bb_106:
    return (unsigned char)(1);
    z_bb_107:
    goto z_bb_99;
    z_bb_108:
    zT_258 = src.kind;
    zT_257 = zT_258 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_110;
    z_bb_109:
    zT_257 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_257) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_262 = src.flags;
    zT_263 = tgt.flags;
    zT_267 = 2;
    zT_264 = zT_267;
    zT_268 = zF_08C13644_pointerQualifiersMo(zT_262, zT_263, zT_264);
    qok = zT_268;
    zT_269 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_269 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_332 = tgt.kind;
    if ((unsigned char)(zT_332 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_136; else goto z_bb_137;
    z_bb_113:
    zT_275 = src.flags;
    zT_274 = (unsigned char)(zT_275 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_115;
    z_bb_114:
    zT_274 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_274) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_281 = self->slice_items;
    zT_282 = src.payload_idx;
    zT_283 = (unsigned int)zT_282;
    zT_284 = zT_281[zT_283];
    s_sl = zT_284;
    zT_286 = self->slice_items;
    zT_287 = tgt.payload_idx;
    zT_288 = (unsigned int)zT_287;
    zT_289 = zT_286[zT_288];
    t_sl = zT_289;
    zT_290 = s_sl.elem;
    zT_291 = t_sl.elem;
    if ((unsigned char)(zT_290 == zT_291)) goto z_bb_118; else goto z_bb_119;
    z_bb_117:
    zT_295 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_295 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_123; else goto z_bb_124;
    z_bb_118:
    zT_293 = qok;
    goto z_bb_120;
    z_bb_119:
    zT_293 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_293) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    return (unsigned char)(1);
    z_bb_122:
    goto z_bb_117;
    z_bb_123:
    zT_301 = src.flags;
    zT_300 = (unsigned char)(zT_301 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_125;
    z_bb_124:
    zT_300 = 0;
    goto z_bb_125;
    z_bb_125:
    if (zT_300) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_307 = self->slice_items;
    zT_308 = src.payload_idx;
    zT_309 = (unsigned int)zT_308;
    zT_310 = zT_307[zT_309];
    s_sl2 = zT_310;
    zT_312 = self->slice_items;
    zT_313 = tgt.payload_idx;
    zT_314 = (unsigned int)zT_313;
    zT_315 = zT_312[zT_314];
    t_sl2 = zT_315;
    zT_316 = s_sl2.elem;
    zT_317 = t_sl2.elem;
    if ((unsigned char)(zT_316 == zT_317)) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_112;
    z_bb_128:
    zT_320 = src.flags;
    if ((unsigned char)((unsigned char)(zT_320 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_132; else goto z_bb_131;
    z_bb_129:
    zT_319 = 0;
    goto z_bb_130;
    z_bb_130:
    if (zT_319) goto z_bb_134; else goto z_bb_135;
    z_bb_131:
    zT_326 = tgt.flags;
    zT_325 = (unsigned char)(zT_326 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_133;
    z_bb_132:
    zT_325 = 1;
    goto z_bb_133;
    z_bb_133:
    zT_319 = zT_325;
    goto z_bb_130;
    z_bb_134:
    return (unsigned char)(1);
    z_bb_135:
    goto z_bb_127;
    z_bb_136:
    zT_336 = src.kind;
    zT_335 = zT_336 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_138;
    z_bb_137:
    zT_335 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_335) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_340 = src.flags;
    zT_341 = tgt.flags;
    zT_345 = 2;
    zT_342 = zT_345;
    zT_346 = zF_08C13644_pointerQualifiersMo(zT_340, zT_341, zT_342);
    qok = zT_346;
    zT_348 = self->ptr_items;
    zT_349 = src.payload_idx;
    zT_350 = (unsigned int)zT_349;
    zT_351 = zT_348[zT_350];
    src_pp = zT_351;
    zT_353 = self->slice_items;
    zT_354 = tgt.payload_idx;
    zT_355 = (unsigned int)zT_354;
    zT_356 = zT_353[zT_355];
    sl = zT_356;
    zT_358 = self->types_items;
    zT_359 = src_pp.base;
    zT_360 = (unsigned int)zT_359;
    zT_361 = zT_358[zT_360];
    src_pointee = zT_361;
    zT_362 = src_pointee.kind;
    if ((unsigned char)(zT_362 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_375 = tgt.kind;
    if ((unsigned char)(zT_375 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_148; else goto z_bb_149;
    z_bb_141:
    zT_366 = self->array_items;
    zT_367 = src_pointee.payload_idx;
    zT_368 = (unsigned int)zT_367;
    zT_369 = zT_366[zT_368];
    arr = zT_369;
    zT_370 = arr.elem;
    zT_371 = sl.elem;
    if ((unsigned char)(zT_370 == zT_371)) goto z_bb_143; else goto z_bb_144;
    z_bb_142:
    goto z_bb_140;
    z_bb_143:
    zT_373 = qok;
    goto z_bb_145;
    z_bb_144:
    zT_373 = 0;
    goto z_bb_145;
    z_bb_145:
    if (zT_373) goto z_bb_146; else goto z_bb_147;
    z_bb_146:
    return (unsigned char)(1);
    z_bb_147:
    goto z_bb_142;
    z_bb_148:
    zT_379 = src.kind;
    zT_378 = zT_379 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_150;
    z_bb_149:
    zT_378 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_378) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_383 = src.flags;
    zT_384 = tgt.flags;
    zT_388 = 2;
    zT_385 = zT_388;
    zT_389 = zF_08C13644_pointerQualifiersMo(zT_383, zT_384, zT_385);
    qok = zT_389;
    zT_390 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_390 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    zT_453 = src.kind;
    if ((unsigned char)(zT_453 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_176; else goto z_bb_177;
    z_bb_153:
    zT_396 = src.flags;
    zT_395 = (unsigned char)(zT_396 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_155;
    z_bb_154:
    zT_395 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_395) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_402 = self->ptr_items;
    zT_403 = src.payload_idx;
    zT_404 = (unsigned int)zT_403;
    zT_405 = zT_402[zT_404];
    s_pp = zT_405;
    zT_407 = self->ptr_items;
    zT_408 = tgt.payload_idx;
    zT_409 = (unsigned int)zT_408;
    zT_410 = zT_407[zT_409];
    t_pp = zT_410;
    zT_411 = s_pp.base;
    zT_412 = t_pp.base;
    if ((unsigned char)(zT_411 == zT_412)) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_416 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_416 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_163; else goto z_bb_164;
    z_bb_158:
    zT_414 = qok;
    goto z_bb_160;
    z_bb_159:
    zT_414 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_414) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (unsigned char)(1);
    z_bb_162:
    goto z_bb_157;
    z_bb_163:
    zT_422 = src.flags;
    zT_421 = (unsigned char)(zT_422 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_165;
    z_bb_164:
    zT_421 = 0;
    goto z_bb_165;
    z_bb_165:
    if (zT_421) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    zT_428 = self->ptr_items;
    zT_429 = src.payload_idx;
    zT_430 = (unsigned int)zT_429;
    zT_431 = zT_428[zT_430];
    s_pp2 = zT_431;
    zT_433 = self->ptr_items;
    zT_434 = tgt.payload_idx;
    zT_435 = (unsigned int)zT_434;
    zT_436 = zT_433[zT_435];
    t_pp2 = zT_436;
    zT_437 = s_pp2.base;
    zT_438 = t_pp2.base;
    if ((unsigned char)(zT_437 == zT_438)) goto z_bb_168; else goto z_bb_169;
    z_bb_167:
    goto z_bb_152;
    z_bb_168:
    zT_441 = src.flags;
    if ((unsigned char)((unsigned char)(zT_441 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_172; else goto z_bb_171;
    z_bb_169:
    zT_440 = 0;
    goto z_bb_170;
    z_bb_170:
    if (zT_440) goto z_bb_174; else goto z_bb_175;
    z_bb_171:
    zT_447 = tgt.flags;
    zT_446 = (unsigned char)(zT_447 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_173;
    z_bb_172:
    zT_446 = 1;
    goto z_bb_173;
    z_bb_173:
    zT_440 = zT_446;
    goto z_bb_170;
    z_bb_174:
    return (unsigned char)(1);
    z_bb_175:
    goto z_bb_167;
    z_bb_176:
    zT_457 = tgt.kind;
    zT_456 = zT_457 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_178;
    z_bb_177:
    zT_456 = 0;
    goto z_bb_178;
    z_bb_178:
    if (zT_456) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_461 = src.flags;
    zT_462 = tgt.flags;
    zT_466 = 2;
    zT_463 = zT_466;
    zT_467 = zF_08C13644_pointerQualifiersMo(zT_461, zT_462, zT_463);
    qok = zT_467;
    zT_469 = self->array_items;
    zT_470 = src.payload_idx;
    zT_471 = (unsigned int)zT_470;
    zT_472 = zT_469[zT_471];
    arr = zT_472;
    zT_474 = self->slice_items;
    zT_475 = tgt.payload_idx;
    zT_476 = (unsigned int)zT_475;
    zT_477 = zT_474[zT_476];
    sl = zT_477;
    zT_478 = arr.elem;
    zT_479 = sl.elem;
    if ((unsigned char)(zT_478 == zT_479)) goto z_bb_181; else goto z_bb_182;
    z_bb_180:
    zT_494 = src.kind;
    if ((unsigned char)(zT_494 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_194; else goto z_bb_195;
    z_bb_181:
    zT_481 = qok;
    goto z_bb_183;
    z_bb_182:
    zT_481 = 0;
    goto z_bb_183;
    z_bb_183:
    if (zT_481) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    return (unsigned char)(1);
    z_bb_185:
    zT_483 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_483 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_489 = arr.elem;
    zT_490 = sl.elem;
    zT_488 = zT_489 == zT_490;
    goto z_bb_188;
    z_bb_187:
    zT_488 = 0;
    goto z_bb_188;
    z_bb_188:
    if (zT_488) goto z_bb_189; else goto z_bb_190;
    z_bb_189:
    zT_492 = qok;
    goto z_bb_191;
    z_bb_190:
    zT_492 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_492) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    return (unsigned char)(1);
    z_bb_193:
    goto z_bb_180;
    z_bb_194:
    zT_498 = tgt.kind;
    zT_497 = zT_498 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_196;
    z_bb_195:
    zT_497 = 0;
    goto z_bb_196;
    z_bb_196:
    if (zT_497) goto z_bb_197; else goto z_bb_198;
    z_bb_197:
    zT_502 = src.flags;
    zT_503 = tgt.flags;
    zT_507 = 2;
    zT_504 = zT_507;
    zT_508 = zF_08C13644_pointerQualifiersMo(zT_502, zT_503, zT_504);
    qok = zT_508;
    zT_510 = self->array_items;
    zT_511 = src.payload_idx;
    zT_512 = (unsigned int)zT_511;
    zT_513 = zT_510[zT_512];
    arr = zT_513;
    zT_515 = self->ptr_items;
    zT_516 = tgt.payload_idx;
    zT_517 = (unsigned int)zT_516;
    zT_518 = zT_515[zT_517];
    pp = zT_518;
    zT_519 = arr.elem;
    zT_520 = pp.base;
    if ((unsigned char)(zT_519 == zT_520)) goto z_bb_199; else goto z_bb_200;
    z_bb_198:
    zT_524 = src.kind;
    if ((unsigned char)(zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_204; else goto z_bb_205;
    z_bb_199:
    zT_522 = qok;
    goto z_bb_201;
    z_bb_200:
    zT_522 = 0;
    goto z_bb_201;
    z_bb_201:
    if (zT_522) goto z_bb_202; else goto z_bb_203;
    z_bb_202:
    return (unsigned char)(1);
    z_bb_203:
    goto z_bb_198;
    z_bb_204:
    zT_528 = tgt.kind;
    zT_527 = zT_528 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_206;
    z_bb_205:
    zT_527 = 0;
    goto z_bb_206;
    z_bb_206:
    if (zT_527) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_532 = src.flags;
    zT_533 = tgt.flags;
    zT_537 = 2;
    zT_534 = zT_537;
    zT_538 = zF_08C13644_pointerQualifiersMo(zT_532, zT_533, zT_534);
    qok = zT_538;
    zT_540 = self->ptr_items;
    zT_541 = src.payload_idx;
    zT_542 = (unsigned int)zT_541;
    zT_543 = zT_540[zT_542];
    sp = zT_543;
    zT_545 = self->ptr_items;
    zT_546 = tgt.payload_idx;
    zT_547 = (unsigned int)zT_546;
    zT_548 = zT_545[zT_547];
    tp = zT_548;
    zT_550 = self->types_items;
    zT_551 = sp.base;
    zT_552 = (unsigned int)zT_551;
    zT_553 = zT_550[zT_552];
    spo = zT_553;
    zT_554 = spo.kind;
    if ((unsigned char)(zT_554 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_209; else goto z_bb_210;
    z_bb_208:
    zT_567 = src.kind;
    if ((unsigned char)(zT_567 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_216; else goto z_bb_217;
    z_bb_209:
    zT_558 = self->array_items;
    zT_559 = spo.payload_idx;
    zT_560 = (unsigned int)zT_559;
    zT_561 = zT_558[zT_560];
    arr = zT_561;
    zT_562 = arr.elem;
    zT_563 = tp.base;
    if ((unsigned char)(zT_562 == zT_563)) goto z_bb_211; else goto z_bb_212;
    z_bb_210:
    goto z_bb_208;
    z_bb_211:
    zT_565 = qok;
    goto z_bb_213;
    z_bb_212:
    zT_565 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_565) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    return (unsigned char)(1);
    z_bb_215:
    goto z_bb_210;
    z_bb_216:
    zT_571 = tgt.kind;
    zT_570 = zT_571 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_218;
    z_bb_217:
    zT_570 = 0;
    goto z_bb_218;
    z_bb_218:
    if (zT_570) goto z_bb_219; else goto z_bb_220;
    z_bb_219:
    zT_575 = self->array_items;
    zT_576 = src.payload_idx;
    zT_577 = (unsigned int)zT_576;
    zT_578 = zT_575[zT_577];
    s_arr = zT_578;
    zT_580 = self->array_items;
    zT_581 = tgt.payload_idx;
    zT_582 = (unsigned int)zT_581;
    zT_583 = zT_580[zT_582];
    t_arr = zT_583;
    zT_584 = s_arr.elem;
    zT_585 = t_arr.elem;
    if ((unsigned char)(zT_584 == zT_585)) goto z_bb_221; else goto z_bb_222;
    z_bb_220:
    zT_592 = src.kind;
    if ((unsigned char)(zT_592 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_226; else goto z_bb_227;
    z_bb_221:
    zT_588 = s_arr.length;
    zT_589 = t_arr.length;
    zT_587 = zT_588 == zT_589;
    goto z_bb_223;
    z_bb_222:
    zT_587 = 0;
    goto z_bb_223;
    z_bb_223:
    if (zT_587) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    return (unsigned char)(1);
    z_bb_225:
    goto z_bb_220;
    z_bb_226:
    zT_596 = tgt.kind;
    zT_595 = zT_596 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_228;
    z_bb_227:
    zT_595 = 0;
    goto z_bb_228;
    z_bb_228:
    if (zT_595) goto z_bb_229; else goto z_bb_230;
    z_bb_229:
    zT_600 = src.flags;
    zT_601 = tgt.flags;
    zT_605 = 2;
    zT_602 = zT_605;
    zT_606 = zF_08C13644_pointerQualifiersMo(zT_600, zT_601, zT_602);
    qok = zT_606;
    zT_608 = self->slice_items;
    zT_609 = src.payload_idx;
    zT_610 = (unsigned int)zT_609;
    zT_611 = zT_608[zT_610];
    sl = zT_611;
    zT_613 = self->ptr_items;
    zT_614 = tgt.payload_idx;
    zT_615 = (unsigned int)zT_614;
    zT_616 = zT_613[zT_615];
    pp = zT_616;
    zT_617 = sl.elem;
    zT_618 = pp.base;
    if ((unsigned char)(zT_617 == zT_618)) goto z_bb_231; else goto z_bb_232;
    z_bb_230:
    zT_622 = src.kind;
    if ((unsigned char)(zT_622 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_236; else goto z_bb_237;
    z_bb_231:
    zT_620 = qok;
    goto z_bb_233;
    z_bb_232:
    zT_620 = 0;
    goto z_bb_233;
    z_bb_233:
    if (zT_620) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (unsigned char)(1);
    z_bb_235:
    goto z_bb_230;
    z_bb_236:
    zT_626 = tgt.kind;
    zT_625 = zT_626 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_238;
    z_bb_237:
    zT_625 = 0;
    goto z_bb_238;
    z_bb_238:
    if (zT_625) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    zT_630 = self->opt_items;
    zT_631 = tgt.payload_idx;
    zT_632 = (unsigned int)zT_631;
    zT_633 = zT_630[zT_632];
    opt = zT_633;
    zT_635 = self->types_items;
    zT_636 = opt.payload;
    zT_637 = (unsigned int)zT_636;
    zT_638 = zT_635[zT_637];
    opt_ty = zT_638;
    zT_639 = opt_ty.kind;
    if ((unsigned char)(zT_639 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_241; else goto z_bb_242;
    z_bb_240:
    if ((unsigned char)(source == (unsigned int)(8))) goto z_bb_243; else goto z_bb_244;
    z_bb_241:
    zT_642 = self;
    zT_643 = source;
    zT_645 = opt.payload;
    self = zT_642;
    source = zT_643;
    target = zT_645;
    goto z_bb_0;
    z_bb_242:
    goto z_bb_240;
    z_bb_243:
    zT_649 = target == (unsigned int)(14);
    goto z_bb_245;
    z_bb_244:
    zT_649 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_649) goto z_bb_247; else goto z_bb_246;
    z_bb_246:
    if ((unsigned char)(source == (unsigned int)(14))) goto z_bb_249; else goto z_bb_250;
    z_bb_247:
    zT_652 = 1;
    goto z_bb_248;
    z_bb_248:
    if (zT_652) goto z_bb_252; else goto z_bb_253;
    z_bb_249:
    zT_655 = target == (unsigned int)(8);
    goto z_bb_251;
    z_bb_250:
    zT_655 = 0;
    goto z_bb_251;
    z_bb_251:
    zT_652 = zT_655;
    goto z_bb_248;
    z_bb_252:
    return (unsigned char)(1);
    z_bb_253:
    zT_659 = src.kind;
    if ((unsigned char)(zT_659 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_254; else goto z_bb_255;
    z_bb_254:
    zT_663 = tgt.kind;
    zT_662 = zT_663 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type);
    goto z_bb_256;
    z_bb_255:
    zT_662 = 0;
    goto z_bb_256;
    z_bb_256:
    if (zT_662) goto z_bb_257; else goto z_bb_258;
    z_bb_257:
    zT_667 = self->tup_items;
    zT_668 = src.payload_idx;
    zT_669 = (unsigned int)zT_668;
    zT_670 = zT_667[zT_669];
    s_tup = zT_670;
    zT_672 = self->tup_items;
    zT_673 = tgt.payload_idx;
    zT_674 = (unsigned int)zT_673;
    zT_675 = zT_672[zT_674];
    t_tup = zT_675;
    zT_676 = s_tup.elems_count;
    zT_677 = t_tup.elems_count;
    if ((unsigned char)(zT_676 == zT_677)) goto z_bb_259; else goto z_bb_260;
    z_bb_258:
    zT_732 = src.kind;
    if ((unsigned char)(zT_732 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_279; else goto z_bb_280;
    z_bb_259:
    zT_680 = 1;
    ok = zT_680;
    zT_682 = 0;
    zT_683 = (unsigned short)zT_682;
    k = zT_683;
    goto z_bb_261;
    z_bb_260:
    goto z_bb_258;
    z_bb_261:
    zT_684 = s_tup.elems_count;
    if ((unsigned char)(k < zT_684)) goto z_bb_262; else goto z_bb_263;
    z_bb_262:
    zT_687 = self->xt_items;
    zT_688 = s_tup.elems_start;
    zT_691 = (unsigned int)(unsigned int)(zT_688 + (unsigned int)((unsigned int)k));
    zT_692 = zT_687[zT_691];
    se = zT_692;
    zT_694 = self->xt_items;
    zT_695 = t_tup.elems_start;
    zT_698 = (unsigned int)(unsigned int)(zT_695 + (unsigned int)((unsigned int)k));
    zT_699 = zT_694[zT_698];
    te = zT_699;
    zT_701 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)se) < zT_701)) goto z_bb_265; else goto z_bb_266;
    z_bb_263:
    if (ok) goto z_bb_277; else goto z_bb_278;
    z_bb_264:
    zT_728 = 1;
    zT_730 = k + (unsigned short)((unsigned short)zT_728);
    k = zT_730;
    goto z_bb_261;
    z_bb_265:
    zT_704 = self->types_items;
    zT_705 = (unsigned int)se;
    zT_706 = zT_704[zT_705];
    zT_707 = zT_706.kind;
    zT_703 = zT_707 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_267;
    z_bb_266:
    zT_703 = 0;
    goto z_bb_267;
    z_bb_267:
    if (zT_703) goto z_bb_268; else goto z_bb_269;
    z_bb_268:
    zT_710 = 0;
    ok = zT_710;
    goto z_bb_263;
    z_bb_269:
    zT_712 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)te) < zT_712)) goto z_bb_270; else goto z_bb_271;
    z_bb_270:
    zT_715 = self->types_items;
    zT_716 = (unsigned int)te;
    zT_717 = zT_715[zT_716];
    zT_718 = zT_717.kind;
    zT_714 = zT_718 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_272;
    z_bb_271:
    zT_714 = 0;
    goto z_bb_272;
    z_bb_272:
    if (zT_714) goto z_bb_273; else goto z_bb_274;
    z_bb_273:
    zT_721 = 0;
    ok = zT_721;
    goto z_bb_263;
    z_bb_274:
    zT_722 = self;
    zT_723 = se;
    zT_724 = te;
    zT_725 = zF_683AEB7F_typeRegistryIsAssig(zT_722, zT_723, zT_724);
    if ((unsigned char)(!zT_725)) goto z_bb_275; else goto z_bb_276;
    z_bb_275:
    zT_727 = 0;
    ok = zT_727;
    goto z_bb_263;
    z_bb_276:
    goto z_bb_264;
    z_bb_277:
    return (unsigned char)(1);
    z_bb_278:
    goto z_bb_260;
    z_bb_279:
    zT_736 = tgt.kind;
    zT_735 = zT_736 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_281;
    z_bb_280:
    zT_735 = 0;
    goto z_bb_281;
    z_bb_281:
    if (zT_735) goto z_bb_282; else goto z_bb_283;
    z_bb_282:
    zT_740 = self->tup_items;
    zT_741 = src.payload_idx;
    zT_742 = (unsigned int)zT_741;
    zT_743 = zT_740[zT_742];
    tup = zT_743;
    zT_745 = self->array_items;
    zT_746 = tgt.payload_idx;
    zT_747 = (unsigned int)zT_746;
    zT_748 = zT_745[zT_747];
    arr = zT_748;
    zT_749 = tup.elems_count;
    zT_751 = arr.length;
    if ((unsigned char)((unsigned int)((unsigned int)zT_749) == zT_751)) goto z_bb_284; else goto z_bb_285;
    z_bb_283:
    return (unsigned char)(0);
    z_bb_284:
    zT_754 = 1;
    ok = zT_754;
    zT_756 = 0;
    zT_757 = (unsigned short)zT_756;
    k = zT_757;
    goto z_bb_286;
    z_bb_285:
    goto z_bb_283;
    z_bb_286:
    zT_758 = tup.elems_count;
    if ((unsigned char)(k < zT_758)) goto z_bb_287; else goto z_bb_288;
    z_bb_287:
    zT_760 = self;
    zT_763 = self->xt_items;
    zT_764 = tup.elems_start;
    zT_767 = (unsigned int)(unsigned int)(zT_764 + (unsigned int)((unsigned int)k));
    zT_761 = zT_763[zT_767];
    zT_762 = arr.elem;
    zT_770 = zF_683AEB7F_typeRegistryIsAssig(zT_760, zT_761, zT_762);
    if ((unsigned char)(!zT_770)) goto z_bb_290; else goto z_bb_291;
    z_bb_288:
    if (ok) goto z_bb_292; else goto z_bb_293;
    z_bb_289:
    zT_773 = 1;
    zT_775 = k + (unsigned short)((unsigned short)zT_773);
    k = zT_775;
    goto z_bb_286;
    z_bb_290:
    zT_772 = 0;
    ok = zT_772;
    goto z_bb_288;
    z_bb_291:
    goto z_bb_289;
    z_bb_292:
    return (unsigned char)(1);
    z_bb_293:
    goto z_bb_285;
}

/* errorSetIsSubset */
unsigned char zF_E35E11A5_errorSetIsSubset(zT_338B7C76_TypeRegistry* self, unsigned int src, unsigned int tgt) {
    unsigned int zT_12;
    unsigned int zT_16;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_0B73C507_ErrorSetPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B73C507_ErrorSetPayload zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned short zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    int zT_56;
    unsigned int zT_57;
    zT_338B7C76_TypeRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    int zT_69;
    unsigned int zT_71;
    zT_D155D06D_Type sty;
    zT_D155D06D_Type tty;
    zT_0B73C507_ErrorSetPayload sp;
    unsigned int sstart;
    unsigned int scount;
    unsigned int i;
    if ((unsigned char)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(src == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(tgt == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_12 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src) >= zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_16 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tgt) >= zT_16)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_20 = self->types_items;
    zT_21 = (unsigned int)src;
    zT_22 = zT_20[zT_21];
    sty = zT_22;
    zT_24 = self->types_items;
    zT_25 = (unsigned int)tgt;
    zT_26 = zT_24[zT_25];
    tty = zT_26;
    zT_27 = sty.kind;
    if ((unsigned char)(zT_27 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_31 = tty.kind;
    if ((unsigned char)(zT_31 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_35 = sty.payload_idx;
    zT_37 = self->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_35) >= zT_37)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_41 = self->es_items;
    zT_42 = sty.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    sp = zT_44;
    zT_46 = sp.tags_start;
    zT_47 = (unsigned int)zT_46;
    sstart = zT_47;
    zT_49 = sp.tags_count;
    zT_50 = (unsigned int)zT_49;
    scount = zT_50;
    zT_52 = self->xn_len;
    if ((unsigned char)((unsigned int)(sstart + scount) > zT_52)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    i = zT_57;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(i < scount)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_59 = self;
    zT_60 = tgt;
    zT_62 = self->xn_items;
    zT_63 = sstart + i;
    zT_61 = zT_62[zT_63];
    zT_65 = zF_D2ECD176_typeRegistryErrorSe(zT_59, zT_60, zT_61);
    if ((unsigned char)(zT_65 == (unsigned int)(4294967295u))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    zT_69 = 1;
    zT_71 = i + (unsigned int)((unsigned int)zT_69);
    i = zT_71;
    goto z_bb_19;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    goto z_bb_22;
}

/* canLiteralFitInType */
unsigned char zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    unsigned char zT_6;
    unsigned char zT_13;
    unsigned char zT_22;
    unsigned char zT_32;
    unsigned char zT_39;
    unsigned char zT_46;
    unsigned char zT_59;
    unsigned char zT_66;
    unsigned char zT_71;
    if ((unsigned char)(target == (unsigned int)(4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-128))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(target == (unsigned int)(5))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_6 = value <= (zT_C69B2266_i64)(127);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-32768))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(target == (unsigned int)(6))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_13 = value <= (zT_C69B2266_i64)(32767);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-Z98_I64_C(2147483648)))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    if ((unsigned char)(target == (unsigned int)(7))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_22 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    if ((unsigned char)(target == (unsigned int)(8))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((unsigned char)(target == (unsigned int)(9))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_32 = value <= (zT_C69B2266_i64)(255);
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(target == (unsigned int)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_39 = value <= (zT_C69B2266_i64)(65535);
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    if ((unsigned char)(target == (unsigned int)(11))) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_46 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    return (unsigned char)(value >= (zT_C69B2266_i64)(0));
    z_bb_34:
    if ((unsigned char)(target == (unsigned int)(12))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-Z98_I64_C(2147483648)))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((unsigned char)(target == (unsigned int)(13))) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_59 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    if ((unsigned char)(target == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_66 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_71 = target == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return (unsigned char)(1);
    z_bb_49:
    return (unsigned char)(0);
}

/* __module_init */
void zF_780653D2___module_init_9(void) {
    zT_CEC2984A_NameMangler zT_0 = {0};
    zG_CEC2984A_NameMangler = zT_0;
    return;
}

/* EOF */
