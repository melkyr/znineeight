#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)ubuf) + zT_15;
    zT_17 = (unsigned int)(16) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa((unsigned int)((unsigned int)used), zT_11);
    ulen = zT_19;
    zT_23 = (unsigned int)(15) - (unsigned int)((unsigned int)ulen);
    ustart = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)ubuf) + ustart;
    zT_29 = (unsigned int)(15) - ustart;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)nbuf) + zT_44;
    zT_46 = (unsigned int)(16) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa((unsigned int)((unsigned int)new_bytes), zT_40);
    nlen = zT_48;
    zT_52 = (unsigned int)(15) - (unsigned int)((unsigned int)nlen);
    nstart = zT_52;
    zT_57 = (unsigned char*)((unsigned char*)nbuf) + nstart;
    zT_58 = (unsigned int)(15) - nstart;
    zT_59.ptr = zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_0715C9B9_EU_832 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_25;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    if ((unsigned char)(zT_6 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_15 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)(elem_size * nc), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zF_9091237C_typeDbOom((unsigned int)(zT_25 * elem_size), (unsigned int)(elem_size * nc));
    return;
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    if ((unsigned char)(i < (unsigned int)(zT_37 * elem_size))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)(new_cap <= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_0715C9B9_EU_832 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_29;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->types_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(32) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zF_9091237C_typeDbOom((unsigned int)(zT_29 * (unsigned int)(32)), (unsigned int)((unsigned int)(32) * nc));
    return;
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_44)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    zT_49 = i + (unsigned int)(1);
    i = zT_49;
    goto z_bb_10;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zF_BCE30624_typeRegistryEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    self->types_len = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_25 = 0;
    zT_26 = (unsigned char*)((unsigned char*)dc_k) + zT_25;
    zT_27 = (unsigned int)(20) - zT_25;
    zT_28.ptr = zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_21), zT_20);
    dc_kl = zT_29;
    zT_33 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_kl);
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_43 = (unsigned char*)((unsigned char*)dc_k) + dc_ks;
    zT_44 = (unsigned int)(19) - dc_ks;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_49 = t.name_id;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)dc_n) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_nl);
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_72 = (unsigned char*)((unsigned char*)dc_n) + dc_ns;
    zT_73 = (unsigned int)(19) - dc_ns;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_82 = 0;
    zT_83 = (unsigned char*)((unsigned char*)dc_i) + zT_82;
    zT_84 = (unsigned int)(20) - zT_82;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    zT_90 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_il);
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_100 = (unsigned char*)((unsigned char*)dc_i) + dc_is;
    zT_101 = (unsigned int)(19) - dc_is;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    if ((unsigned char)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_112BF819_PtrPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->ptr_items;
    zT_3 = &self->ptr_len;
    zT_4 = &self->ptr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    self->ptr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->array_items;
    zT_3 = &self->array_len;
    zT_4 = &self->array_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->array_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    self->array_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->slice_items;
    zT_3 = &self->slice_len;
    zT_4 = &self->slice_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    self->slice_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->opt_items;
    zT_3 = &self->opt_len;
    zT_4 = &self->opt_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    self->opt_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->eu_items;
    zT_3 = &self->eu_len;
    zT_4 = &self->eu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    self->eu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->es_items;
    zT_3 = &self->es_len;
    zT_4 = &self->es_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->es_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    self->es_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fn_items;
    zT_3 = &self->fn_len;
    zT_4 = &self->fn_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(24), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    self->fn_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_406493CE_StructPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->st_items;
    zT_3 = &self->st_len;
    zT_4 = &self->st_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->st_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    self->st_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_925BA889_pkStructAppend(zT_24, zT_25);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_struct_items;
    zT_3 = &self->pk_struct_len;
    zT_4 = &self->pk_struct_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_struct_items;
    zT_19 = self->pk_struct_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_struct_len;
    zT_21 = 1;
    self->pk_struct_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E276DDD0_PackedBitField* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_items;
    zT_3 = &self->pk_len;
    zT_4 = &self->pk_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_items;
    zT_19 = self->pk_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_len;
    zT_21 = 1;
    self->pk_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->en_items;
    zT_3 = &self->en_len;
    zT_4 = &self->en_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->en_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    self->en_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->un_items;
    zT_3 = &self->un_len;
    zT_4 = &self->un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    self->un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_96B8622A_pkUnStructAppend(zT_24, zT_25);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_un_items;
    zT_3 = &self->pk_un_len;
    zT_4 = &self->pk_un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_un_items;
    zT_19 = self->pk_un_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_un_len;
    zT_21 = 1;
    self->pk_un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tu_items;
    zT_3 = &self->tu_len;
    zT_4 = &self->tu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    self->tu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tup_items;
    zT_3 = &self->tup_len;
    zT_4 = &self->tup_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    self->tup_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->unr_items;
    zT_3 = &self->unr_len;
    zT_4 = &self->unr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    self->unr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fe_items;
    zT_3 = &self->fe_len;
    zT_4 = &self->fe_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    self->fe_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->em_items;
    zT_3 = &self->em_len;
    zT_4 = &self->em_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->em_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    self->em_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xt_items;
    zT_3 = &self->xt_len;
    zT_4 = &self->xt_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    self->xt_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xn_items;
    zT_3 = &self->xn_len;
    zT_4 = &self->xn_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    self->xn_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_12;
    unsigned char zT_18;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_30;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(8);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(16);
    z_bb_13:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_18 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_21 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(32);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(64);
    z_bb_29:
    return (unsigned char)(0);
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_8;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned char zT_20;
    unsigned char zT_23;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    unsigned char p_wb;
    unsigned char p_sg;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    zT_8 = 0;
    p_sg = zT_8;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_14 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_17 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_17 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_23 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_15;
    z_bb_14:
    zT_23 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_23) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_26 = 1;
    p_sg = zT_26;
    goto z_bb_17;
    z_bb_17:
    zT_27 = self;
    zT_29.kind = kind;
    zT_30 = 2;
    zT_29.state = zT_30;
    zT_31 = 0;
    zT_29.flags = zT_31;
    zT_29.is_signed = p_sg;
    zT_29.width_bits = p_wb;
    zT_29.size = size;
    zT_29.alignment = alignment;
    zT_32 = 0;
    zT_29.name_id = zT_32;
    zT_33 = 0;
    zT_29.c_name_id = zT_33;
    zT_34 = 0;
    zT_29.module_id = zT_34;
    zT_35 = 0;
    zT_29.payload_idx = zT_35;
    zT_28 = zT_29;
    zT_36 = zF_D4993F02_typeRegistryAppend(zT_27, zT_28);
    return zT_36;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    *len = (unsigned int)(0);
    *cap = (unsigned int)(0);
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68 = {0};
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70 = {0};
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72 = {0};
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74 = {0};
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76 = {0};
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78 = {0};
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = 0;
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zT_61 = 0;
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zT_64 = 0;
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    reg = zT_3;
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_9;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    key_lo = zT_9;
    if ((unsigned char)(key_lo == (zT_79FAE712_u64)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)np_k) + zT_17;
    zT_19 = (unsigned int)(20) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(65535))), zT_11);
    np_kl = zT_21;
    zT_25 = (unsigned int)(19) - (unsigned int)((unsigned int)np_kl);
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_35 = (unsigned char*)((unsigned char*)np_k) + np_ks;
    zT_36 = (unsigned int)(19) - np_ks;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_45 = 0;
    zT_46 = (unsigned char*)((unsigned char*)np_v) + zT_45;
    zT_47 = (unsigned int)(20) - zT_45;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    zT_53 = (unsigned int)(19) - (unsigned int)((unsigned int)np_vl);
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_63 = (unsigned char*)((unsigned char*)np_v) + np_vs;
    zT_64 = (unsigned int)(19) - np_vs;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_0C0306D6_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreatePtrQ */
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_827207A1_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreateManyPtrQ */
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->many_ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->many_ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned char is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    unsigned char zT_112;
    int zT_113;
    int zT_115;
    unsigned char zT_117;
    unsigned char zT_118;
    unsigned char zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_128;
    unsigned int zT_129 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    zT_4028D896_Arr_unsigned_char_2 zT_140;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    int zT_146;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150 = 0;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned char* zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_4028D896_Arr_unsigned_char_2 zT_168;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    int zT_174;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178 = 0;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    zT_4028D896_Arr_unsigned_char_2 zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    int zT_203;
    unsigned char* zT_204;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned char* zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    zT_11 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(1)) | ic;
    key = zT_11;
    zT_12 = &self->slice_cache;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_30 = 0;
    zT_31 = (unsigned char*)((unsigned char*)u2h_eb) + zT_30;
    zT_32 = (unsigned int)(20) - zT_30;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    zT_38 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_el);
    u2h_es = zT_38;
    zT_43 = (unsigned char*)((unsigned char*)u2h_eb) + u2h_es;
    zT_44 = (unsigned int)(19) - u2h_es;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)u2h_rb) + zT_58;
    zT_60 = (unsigned int)(20) - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    zT_66 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_rl);
    u2h_rs = zT_66;
    zT_71 = (unsigned char*)((unsigned char*)u2h_rb) + u2h_rs;
    zT_72 = (unsigned int)(19) - u2h_rs;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_87 = 0;
    zT_88 = (unsigned char*)((unsigned char*)u2h_cb) + zT_87;
    zT_89 = (unsigned int)(20) - zT_87;
    zT_90.ptr = zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_83);
    u2h_cl = zT_91;
    zT_95 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_cl);
    u2h_cs = zT_95;
    zT_100 = (unsigned char*)((unsigned char*)u2h_cb) + u2h_cs;
    zT_101 = (unsigned int)(19) - u2h_cs;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = (unsigned char)zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_115 = 0;
    zT_112 = (unsigned char)zT_115;
    goto z_bb_8;
    z_bb_8:
    zT_117 = (unsigned char)zT_112;
    zT_109.flags = zT_117;
    zT_118 = 0;
    zT_109.is_signed = zT_118;
    zT_119 = 0;
    zT_109.width_bits = zT_119;
    zT_120 = 8;
    zT_109.size = zT_120;
    zT_121 = 4;
    zT_109.alignment = zT_121;
    zT_122 = 0;
    zT_109.name_id = zT_122;
    zT_123 = 0;
    zT_109.c_name_id = zT_123;
    zT_124 = 0;
    zT_109.module_id = zT_124;
    zT_125 = self->slice_len;
    zT_128 = (unsigned int)(unsigned int)(zT_125 - (unsigned int)(1));
    zT_109.payload_idx = zT_128;
    zT_108 = zT_109;
    zT_129 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_129;
    zT_130 = &self->slice_cache;
    zT_131 = key;
    zT_132 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_130, zT_131, zT_132);
    zT_135 = "U2N:e";
    zT_137 = 5;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    u2n_m = zT_136;
    zT_138 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_138);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_140[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_140[_i];
        _i++;
    }
}
    zT_142 = elem;
    zT_146 = 0;
    zT_147 = (unsigned char*)((unsigned char*)u2n_eb) + zT_146;
    zT_148 = (unsigned int)(20) - zT_146;
    zT_149.ptr = zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zT_150 = zF_A7504564_itoa(zT_142, zT_143);
    u2n_el = zT_150;
    zT_154 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_el);
    u2n_es = zT_154;
    zT_159 = (unsigned char*)((unsigned char*)u2n_eb) + u2n_es;
    zT_160 = (unsigned int)(19) - u2n_es;
    zT_161.ptr = zT_159;
    zT_161.len = zT_160;
    zT_155 = zT_161;
    zF_48AC7B3A_markerWrite(zT_155);
    zT_163 = "r";
    zT_165 = 1;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    u2n_rm = zT_164;
    zT_166 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_166);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_168[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_168[_i];
        _i++;
    }
}
    zT_170 = tid;
    zT_174 = 0;
    zT_175 = (unsigned char*)((unsigned char*)u2n_rb) + zT_174;
    zT_176 = (unsigned int)(20) - zT_174;
    zT_177.ptr = zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zT_178 = zF_A7504564_itoa(zT_170, zT_171);
    u2n_rl = zT_178;
    zT_182 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_rl);
    u2n_rs = zT_182;
    zT_187 = (unsigned char*)((unsigned char*)u2n_rb) + u2n_rs;
    zT_188 = (unsigned int)(19) - u2n_rs;
    zT_189.ptr = zT_187;
    zT_189.len = zT_188;
    zT_183 = zT_189;
    zF_48AC7B3A_markerWrite(zT_183);
    zT_191 = "c";
    zT_193 = 1;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    u2n_cm = zT_192;
    zT_194 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_194);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_196[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_196[_i];
        _i++;
    }
}
    zT_203 = 0;
    zT_204 = (unsigned char*)((unsigned char*)u2n_cb) + zT_203;
    zT_205 = (unsigned int)(20) - zT_203;
    zT_206.ptr = zT_204;
    zT_206.len = zT_205;
    zT_199 = zT_206;
    zT_207 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_199);
    u2n_cl = zT_207;
    zT_211 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_cl);
    u2n_cs = zT_211;
    zT_216 = (unsigned char*)((unsigned char*)u2n_cb) + u2n_cs;
    zT_217 = (unsigned int)(19) - u2n_cs;
    zT_218.ptr = zT_216;
    zT_218.len = zT_217;
    zT_212 = zT_218;
    zF_48AC7B3A_markerWrite(zT_212);
    return tid;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39 = 0;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_0B10E8E9_OptionalPayload zT_42;
    zT_0B10E8E9_OptionalPayload zT_43;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    zT_21D3708C_U32ToU32Map* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_2 = &self->optional_cache;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    return existing;
    z_bb_2:
    zT_9 = self->types_items;
    zT_10 = zT_9[payload];
    pay_type = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    opt_size = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    opt_align = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned char)zT_18;
    opt_state = zT_19;
    zT_20 = pay_type.state;
    if ((unsigned char)(zT_20 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = pay_type.alignment;
    if ((unsigned char)(zT_24 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_41 = self;
    zT_43.payload = payload;
    zT_42 = zT_43;
    zF_4569340E_optAppend(zT_41, zT_42);
    zT_45 = self;
    zT_48 = zT_33EF6BFB_TypeKind_optional_type;
    zT_47.kind = zT_48;
    zT_47.state = opt_state;
    zT_49 = 0;
    zT_47.flags = zT_49;
    zT_50 = 0;
    zT_47.is_signed = zT_50;
    zT_51 = 0;
    zT_47.width_bits = zT_51;
    zT_47.size = opt_size;
    zT_47.alignment = opt_align;
    zT_52 = 0;
    zT_47.name_id = zT_52;
    zT_53 = 0;
    zT_47.c_name_id = zT_53;
    zT_54 = 0;
    zT_47.module_id = zT_54;
    zT_55 = self->opt_len;
    zT_58 = (unsigned int)(unsigned int)(zT_55 - (unsigned int)(1));
    zT_47.payload_idx = zT_58;
    zT_46 = zT_47;
    zT_59 = zF_D4993F02_typeRegistryAppend(zT_45, zT_46);
    tid = zT_59;
    if ((unsigned char)(opt_state == (unsigned char)(2))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_27 = pay_type.alignment;
    goto z_bb_7;
    z_bb_6:
    zT_27 = 4;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_27;
    zT_30 = pay_type.size;
    zT_34 = zF_D2BAC673_alignUp(zT_30, (unsigned int)(4));
    zT_36 = zT_34 + (unsigned int)(4);
    opt_size = zT_36;
    zT_37 = opt_size;
    zT_38 = pay_align;
    zT_39 = zF_D2BAC673_alignUp(zT_37, zT_38);
    opt_size = zT_39;
    opt_align = pay_align;
    zT_40 = 2;
    opt_state = zT_40;
    goto z_bb_4;
    z_bb_8:
    zT_62 = &self->optional_cache;
    zT_63 = payload;
    zT_64 = tid;
    zF_26476265_u32ToU32MapPut(zT_62, zT_63, zT_64);
    goto z_bb_9;
    z_bb_9:
    return tid;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_D155D06D_Type* zT_16;
    zT_D155D06D_Type zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned int zT_31;
    unsigned int zT_34;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_51 = 0;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56 = 0;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_42C2D6BF_EUPayload zT_59;
    zT_42C2D6BF_EUPayload zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type zT_63;
    zT_D155D06D_Type zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned int zT_76 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_79;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_8 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)payload) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)error_set);
    eu_key = zT_8;
    zT_9 = &self->eu_cache;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self->types_items;
    zT_17 = zT_16[payload];
    pay_type = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    eu_size = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    eu_align = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned char)zT_25;
    eu_state = zT_26;
    zT_27 = pay_type.state;
    if ((unsigned char)(zT_27 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = pay_type.size;
    if ((unsigned char)(zT_31 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_58 = self;
    zT_60.payload = payload;
    zT_60.error_set = error_set;
    zT_59 = zT_60;
    zF_ABBA52E7_euAppend(zT_58, zT_59);
    zT_62 = self;
    zT_65 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_64.kind = zT_65;
    zT_64.state = eu_state;
    zT_66 = 0;
    zT_64.flags = zT_66;
    zT_67 = 0;
    zT_64.is_signed = zT_67;
    zT_68 = 0;
    zT_64.width_bits = zT_68;
    zT_64.size = eu_size;
    zT_64.alignment = eu_align;
    zT_69 = 0;
    zT_64.name_id = zT_69;
    zT_70 = 0;
    zT_64.c_name_id = zT_70;
    zT_71 = 0;
    zT_64.module_id = zT_71;
    zT_72 = self->eu_len;
    zT_75 = (unsigned int)(unsigned int)(zT_72 - (unsigned int)(1));
    zT_64.payload_idx = zT_75;
    zT_63 = zT_64;
    zT_76 = zF_D4993F02_typeRegistryAppend(zT_62, zT_63);
    tid = zT_76;
    zT_77 = &self->eu_cache;
    zT_78 = eu_key;
    zT_79 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_77, zT_78, zT_79);
    return tid;
    z_bb_5:
    zT_34 = pay_type.size;
    goto z_bb_7;
    z_bb_6:
    zT_34 = 4;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_34;
    zT_38 = pay_type.alignment;
    if ((unsigned char)(zT_38 > (unsigned int)(4))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_41 = pay_type.alignment;
    goto z_bb_10;
    z_bb_9:
    zT_41 = 4;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_41;
    zT_45 = union_size;
    zT_46 = union_align;
    zT_47 = zF_D2BAC673_alignUp(zT_45, zT_46);
    total = zT_47;
    zT_48 = total;
    zT_51 = zF_D2BAC673_alignUp(zT_48, (unsigned int)(4));
    zT_53 = zT_51 + (unsigned int)(4);
    total = zT_53;
    zT_54 = total;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    eu_size = zT_56;
    eu_align = union_align;
    zT_57 = 2;
    eu_state = zT_57;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_E834303C_ArrayPayload zT_100;
    zT_E834303C_ArrayPayload zT_101;
    zT_D155D06D_Type* zT_103;
    zT_D155D06D_Type zT_104;
    int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_136 = 0;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_4028D896_Arr_unsigned_char_2 zT_143;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    int zT_149;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153 = 0;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned char zT_165;
    zT_A4CE86B7_U64ToU32Map* zT_168;
    zT_79FAE712_u64 zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)o0b) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    zT_23 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l);
    o0s = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)o0b) + o0s;
    zT_29 = (unsigned int)(19) - o0s;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)o0b2) + zT_43;
    zT_45 = (unsigned int)(20) - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    zT_51 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l2);
    o0s2 = zT_51;
    zT_56 = (unsigned char*)((unsigned char*)o0b2) + o0s2;
    zT_57 = (unsigned int)(19) - o0s2;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_64 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)length);
    key = zT_64;
    zT_65 = &self->array_cache;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_83 = 0;
    zT_84 = (unsigned char*)((unsigned char*)o1b) + zT_83;
    zT_85 = (unsigned int)(20) - zT_83;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    zT_91 = (unsigned int)(19) - (unsigned int)((unsigned int)o1l);
    o1s = zT_91;
    zT_96 = (unsigned char*)((unsigned char*)o1b) + o1s;
    zT_97 = (unsigned int)(19) - o1s;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    return existing;
    z_bb_2:
    zT_99 = self;
    zT_101.elem = elem;
    zT_101.length = length;
    zT_100 = zT_101;
    zF_4D5CD212_arrayAppend(zT_99, zT_100);
    zT_103 = self->types_items;
    zT_104 = zT_103[elem];
    elem_ty = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    arr_size = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    arr_align = zT_110;
    zT_112 = 0;
    zT_113 = (unsigned char)zT_112;
    arr_state = zT_113;
    zT_114 = elem_ty.state;
    if ((unsigned char)(zT_114 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_117 = elem_ty.size;
    zT_118 = zT_117 * length;
    arr_size = zT_118;
    zT_119 = elem_ty.alignment;
    arr_align = zT_119;
    zT_120 = 2;
    arr_state = zT_120;
    goto z_bb_4;
    z_bb_4:
    zT_122 = self;
    zT_125 = zT_33EF6BFB_TypeKind_array_type;
    zT_124.kind = zT_125;
    zT_124.state = arr_state;
    zT_126 = 0;
    zT_124.flags = zT_126;
    zT_127 = 0;
    zT_124.is_signed = zT_127;
    zT_128 = 0;
    zT_124.width_bits = zT_128;
    zT_124.size = arr_size;
    zT_124.alignment = arr_align;
    zT_129 = 0;
    zT_124.name_id = zT_129;
    zT_130 = 0;
    zT_124.c_name_id = zT_130;
    zT_131 = 0;
    zT_124.module_id = zT_131;
    zT_132 = self->array_len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 - (unsigned int)(1));
    zT_124.payload_idx = zT_135;
    zT_123 = zT_124;
    zT_136 = zF_D4993F02_typeRegistryAppend(zT_122, zT_123);
    tid = zT_136;
    zT_138 = "O2N";
    zT_140 = 3;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    o2m = zT_139;
    zT_141 = o2m;
    zF_48AC7B3A_markerWrite(zT_141);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_143[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_143[_i];
        _i++;
    }
}
    zT_145 = tid;
    zT_149 = 0;
    zT_150 = (unsigned char*)((unsigned char*)o2b) + zT_149;
    zT_151 = (unsigned int)(20) - zT_149;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zT_153 = zF_A7504564_itoa(zT_145, zT_146);
    o2l = zT_153;
    zT_157 = (unsigned int)(19) - (unsigned int)((unsigned int)o2l);
    o2s = zT_157;
    zT_162 = (unsigned char*)((unsigned char*)o2b) + o2s;
    zT_163 = (unsigned int)(19) - o2s;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_158 = zT_164;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_165 = elem_ty.state;
    if ((unsigned char)(zT_165 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_168 = &self->array_cache;
    zT_169 = key;
    zT_170 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_168, zT_169, zT_170);
    goto z_bb_6;
    z_bb_6:
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.is_signed = zT_13;
    zT_14 = 0;
    zT_9.width_bits = zT_14;
    zT_15 = 0;
    zT_9.size = zT_15;
    zT_16 = 1;
    zT_9.alignment = zT_16;
    zT_17 = 0;
    zT_9.name_id = zT_17;
    zT_18 = 0;
    zT_9.c_name_id = zT_18;
    zT_19 = 0;
    zT_9.module_id = zT_19;
    zT_20 = self->tup_len;
    zT_23 = (unsigned int)(unsigned int)(zT_20 - (unsigned int)(1));
    zT_9.payload_idx = zT_23;
    zT_8 = zT_9;
    zT_24 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_24;
    return tid;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type, unsigned char call_conv) {
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned char zT_38;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_0317B1D5_FnPayload* zT_57;
    zT_D155D06D_Type* zT_58;
    zT_D155D06D_Type zT_59;
    unsigned int zT_60;
    zT_0317B1D5_FnPayload zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    zT_0317B1D5_FnPayload* zT_65;
    zT_D155D06D_Type* zT_66;
    zT_D155D06D_Type zT_67;
    unsigned int zT_68;
    zT_0317B1D5_FnPayload zT_69;
    unsigned char zT_70;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    zT_D155D06D_Type* zT_86;
    zT_D155D06D_Type* zT_87;
    int zT_89;
    unsigned int zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_0317B1D5_FnPayload zT_93;
    zT_0317B1D5_FnPayload zT_94;
    unsigned char zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned char zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_112;
    unsigned int zT_113 = 0;
    zT_D155D06D_Type* zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    unsigned char zT_119;
    zT_D155D06D_Type* zT_122;
    zT_D155D06D_Type* zT_124;
    zT_4028D896_Arr_unsigned_char_2 zT_126;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    int zT_132;
    unsigned char* zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136 = 0;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned char* zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned char conv_bit;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_10 = "P2:n";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    p2m = zT_11;
    zT_13 = p2m;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = name_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)p2nb) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    p2nl = zT_25;
    zT_29 = (unsigned int)(19) - (unsigned int)((unsigned int)p2nl);
    p2ns = zT_29;
    zT_34 = (unsigned char*)((unsigned char*)p2nb) + p2ns;
    zT_35 = (unsigned int)(19) - p2ns;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_30 = zT_36;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_38 = 0;
    conv_bit = zT_38;
    if ((unsigned char)(call_conv == (unsigned char)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_41 = 2;
    conv_bit = zT_41;
    goto z_bb_2;
    z_bb_2:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    i = zT_44;
    goto z_bb_3;
    z_bb_3:
    zT_45 = self->types_len;
    if ((unsigned char)(i < zT_45)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_48 = self->types_items;
    zT_49 = zT_48[i];
    it = zT_49;
    zT_50 = it.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_92 = self;
    zT_94.name_id = name_id;
    zT_94.module_id = module_id;
    zT_94.is_extern = is_extern;
    zT_94.params_start = params_start;
    zT_94.params_count = params_count;
    zT_94.return_type = return_type;
    zT_95 = is_variadic | conv_bit;
    zT_94.flags_packed = zT_95;
    zT_93 = zT_94;
    zF_07DDC351_fnAppend(zT_92, zT_93);
    zT_97 = self;
    zT_100 = zT_33EF6BFB_TypeKind_fn_type;
    zT_99.kind = zT_100;
    zT_101 = 2;
    zT_99.state = zT_101;
    zT_102 = 0;
    zT_99.flags = zT_102;
    zT_103 = 0;
    zT_99.is_signed = zT_103;
    zT_104 = 0;
    zT_99.width_bits = zT_104;
    zT_105 = 4;
    zT_99.size = zT_105;
    zT_106 = 4;
    zT_99.alignment = zT_106;
    zT_99.name_id = name_id;
    zT_107 = 0;
    zT_99.c_name_id = zT_107;
    zT_108 = 0;
    zT_99.module_id = zT_108;
    zT_109 = self->fn_len;
    zT_112 = (unsigned int)(unsigned int)(zT_109 - (unsigned int)(1));
    zT_99.payload_idx = zT_112;
    zT_98 = zT_99;
    zT_113 = zF_D4993F02_typeRegistryAppend(zT_97, zT_98);
    tid = zT_113;
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_6:
    zT_89 = 1;
    zT_91 = i + (unsigned int)((unsigned int)zT_89);
    i = zT_91;
    goto z_bb_3;
    z_bb_7:
    zT_54 = it.name_id;
    zT_53 = zT_54 == name_id;
    goto z_bb_9;
    z_bb_8:
    zT_53 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->fn_items;
    zT_58 = self->types_items;
    zT_59 = zT_58[i];
    zT_60 = zT_59.payload_idx;
    zT_61 = zT_57[zT_60];
    zT_62 = zT_61.module_id;
    zT_56 = zT_62 == module_id;
    goto z_bb_12;
    z_bb_11:
    zT_56 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_56) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_65 = self->fn_items;
    zT_66 = self->types_items;
    zT_67 = zT_66[i];
    zT_68 = zT_67.payload_idx;
    zT_69 = zT_65[zT_68];
    zT_70 = zT_69.flags_packed;
    zT_64 = (unsigned char)(zT_70 & (unsigned int)(2)) == conv_bit;
    goto z_bb_15;
    z_bb_14:
    zT_64 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_64) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_75 = "H";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    p2hm = zT_76;
    zT_78 = p2hm;
    zF_48AC7B3A_markerWrite(zT_78);
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_81 = self->types_items;
    zT_82 = zT_81[i];
    zT_83 = zT_82.flags;
    zT_86 = self->types_items;
    zT_87 = zT_86 + i;
    zT_87->flags = (unsigned char)(zT_83 | (unsigned char)(1));
    goto z_bb_19;
    z_bb_19:
    return (unsigned int)((unsigned int)i);
    z_bb_20:
    zT_116 = self->types_items;
    zT_117 = (unsigned int)tid;
    zT_118 = zT_116[zT_117];
    zT_119 = zT_118.flags;
    zT_122 = self->types_items;
    zT_124 = zT_122 + (unsigned int)((unsigned int)tid);
    zT_124->flags = (unsigned char)(zT_119 | (unsigned char)(1));
    goto z_bb_21;
    z_bb_21:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_126[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_126[_i];
        _i++;
    }
}
    zT_128 = tid;
    zT_132 = 0;
    zT_133 = (unsigned char*)((unsigned char*)p2sb) + zT_132;
    zT_134 = (unsigned int)(20) - zT_132;
    zT_135.ptr = zT_133;
    zT_135.len = zT_134;
    zT_129 = zT_135;
    zT_136 = zF_A7504564_itoa(zT_128, zT_129);
    p2sl = zT_136;
    zT_140 = (unsigned int)(19) - (unsigned int)((unsigned int)p2sl);
    p2ss = zT_140;
    zT_145 = (unsigned char*)((unsigned char*)p2sb) + p2ss;
    zT_146 = (unsigned int)(19) - p2ss;
    zT_147.ptr = zT_145;
    zT_147.len = zT_146;
    zT_141 = zT_147;
    zF_48AC7B3A_markerWrite(zT_141);
    zT_149 = "\n";
    zT_151 = 1;
    zT_150.ptr = zT_149;
    zT_150.len = zT_151;
    p2nl2 = zT_150;
    zT_152 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_152);
    return tid;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_8 = self->types_items;
    zT_10 = zT_8 + (unsigned int)((unsigned int)tid);
    zT_10->flags = (unsigned char)(zT_5 | (unsigned char)(1));
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    unsigned int* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned short zT_21;
    zT_A4CE86B7_U64ToU32Map* zT_22;
    zT_79FAE712_u64 zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_0B73C507_ErrorSetPayload zT_30;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_D155D06D_Type zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_48;
    unsigned int zT_49 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_52;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ki < tags_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_13 = (unsigned int)(unsigned int)(tags_start + (unsigned int)((unsigned int)ki));
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    zT_18 = (zT_79FAE712_u64)(key ^ (zT_79FAE712_u64)((zT_79FAE712_u64)tag)) * (zT_79FAE712_u64)(1099511628211ULL);
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_22 = &self->es_cache;
    zT_23 = key;
    zT_25 = zF_A05A7BE1_u64ToU32MapGet(zT_22, zT_23);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_21 = ki + (unsigned short)((unsigned short)zT_19);
    ki = zT_21;
    goto z_bb_1;
    z_bb_5:
    existing = zT_25.value;
    return existing;
    z_bb_6:
    zT_28 = self;
    zT_30.tags_start = tags_start;
    zT_30.tags_count = tags_count;
    zT_29 = zT_30;
    zF_B86143DD_esAppend(zT_28, zT_29);
    zT_32 = self;
    zT_35 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_34.kind = zT_35;
    zT_36 = 2;
    zT_34.state = zT_36;
    zT_37 = 0;
    zT_34.flags = zT_37;
    zT_38 = 0;
    zT_34.is_signed = zT_38;
    zT_39 = 0;
    zT_34.width_bits = zT_39;
    zT_40 = 4;
    zT_34.size = zT_40;
    zT_41 = 4;
    zT_34.alignment = zT_41;
    zT_42 = 0;
    zT_34.name_id = zT_42;
    zT_43 = 0;
    zT_34.c_name_id = zT_43;
    zT_44 = 0;
    zT_34.module_id = zT_44;
    zT_45 = self->es_len;
    zT_48 = (unsigned int)(unsigned int)(zT_45 - (unsigned int)(1));
    zT_34.payload_idx = zT_48;
    zT_33 = zT_34;
    zT_49 = zF_D4993F02_typeRegistryAppend(zT_32, zT_33);
    tid = zT_49;
    zT_50 = &self->es_cache;
    zT_51 = key;
    zT_52 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_50, zT_51, zT_52);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_36;
    unsigned int zT_37;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_44;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    if ((unsigned char)(es_type_id >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    zT_32 = reg->xn_len;
    if ((unsigned char)((unsigned int)(tags_start + tags_count) > zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(4294967295u);
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(i < tags_count)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    if ((unsigned char)(zT_41 == name_id)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned int)(4294967295u);
    z_bb_12:
    zT_44 = 1;
    zT_46 = i + (unsigned int)((unsigned int)zT_44);
    i = zT_46;
    goto z_bb_9;
    z_bb_13:
    return (unsigned int)((unsigned int)i);
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_13;
    unsigned int zT_14;
    int zT_17;
    unsigned int zT_19;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D155D06D_Type zT_39;
    unsigned int zT_40 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    zT_10 = it.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_22 = zT_33EF6BFB_TypeKind_module_type;
    zT_21.kind = zT_22;
    zT_23 = 0;
    zT_21.state = zT_23;
    zT_24 = 0;
    zT_21.flags = zT_24;
    zT_25 = 0;
    zT_21.is_signed = zT_25;
    zT_26 = 0;
    zT_21.width_bits = zT_26;
    zT_27 = 0;
    zT_21.size = zT_27;
    zT_28 = 0;
    zT_21.alignment = zT_28;
    zT_29 = 0;
    zT_21.name_id = zT_29;
    zT_30 = 0;
    zT_21.c_name_id = zT_30;
    zT_21.module_id = module_id;
    zT_31 = 0;
    zT_21.payload_idx = zT_31;
    t = zT_21;
    zT_33 = "MC";
    zT_35 = 2;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    mc = zT_34;
    zT_36 = mc;
    zF_48AC7B3A_markerWrite(zT_36);
    zT_38 = self;
    zT_39 = t;
    zT_40 = zF_D4993F02_typeRegistryAppend(zT_38, zT_39);
    mcid = zT_40;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_13 = zT_14 == module_id;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)((unsigned int)i);
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    (void)zF_4F84B621_registerPrimitive(zT_1, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel), (unsigned int)(0), (unsigned int)(0));
    zT_9 = self;
    (void)zF_4F84B621_registerPrimitive(zT_9, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type), (unsigned int)(0), (unsigned int)(0));
    zT_17 = self;
    (void)zF_4F84B621_registerPrimitive(zT_17, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type), (unsigned int)(1), (unsigned int)(1));
    zT_25 = self;
    (void)zF_4F84B621_registerPrimitive(zT_25, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type), (unsigned int)(0), (unsigned int)(0));
    zT_33 = self;
    (void)zF_4F84B621_registerPrimitive(zT_33, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type), (unsigned int)(1), (unsigned int)(1));
    zT_41 = self;
    (void)zF_4F84B621_registerPrimitive(zT_41, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type), (unsigned int)(2), (unsigned int)(2));
    zT_49 = self;
    (void)zF_4F84B621_registerPrimitive(zT_49, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type), (unsigned int)(4), (unsigned int)(4));
    zT_57 = self;
    (void)zF_4F84B621_registerPrimitive(zT_57, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type), (unsigned int)(8), (unsigned int)(8));
    zT_65 = self;
    (void)zF_4F84B621_registerPrimitive(zT_65, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type), (unsigned int)(1), (unsigned int)(1));
    zT_73 = self;
    (void)zF_4F84B621_registerPrimitive(zT_73, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type), (unsigned int)(2), (unsigned int)(2));
    zT_81 = self;
    (void)zF_4F84B621_registerPrimitive(zT_81, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type), (unsigned int)(4), (unsigned int)(4));
    zT_89 = self;
    (void)zF_4F84B621_registerPrimitive(zT_89, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type), (unsigned int)(8), (unsigned int)(8));
    zT_97 = self;
    (void)zF_4F84B621_registerPrimitive(zT_97, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type), (unsigned int)(4), (unsigned int)(4));
    zT_105 = self;
    (void)zF_4F84B621_registerPrimitive(zT_105, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type), (unsigned int)(4), (unsigned int)(4));
    zT_113 = self;
    (void)zF_4F84B621_registerPrimitive(zT_113, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type), (unsigned int)(1), (unsigned int)(1));
    zT_121 = self;
    (void)zF_4F84B621_registerPrimitive(zT_121, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type), (unsigned int)(4), (unsigned int)(4));
    zT_129 = self;
    (void)zF_4F84B621_registerPrimitive(zT_129, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type), (unsigned int)(8), (unsigned int)(8));
    zT_137 = self;
    (void)zF_4F84B621_registerPrimitive(zT_137, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type), (unsigned int)(0), (unsigned int)(0));
    zT_145 = self;
    (void)zF_4F84B621_registerPrimitive(zT_145, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type), (unsigned int)(0), (unsigned int)(0));
    zT_153 = self;
    (void)zF_4F84B621_registerPrimitive(zT_153, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type), (unsigned int)(0), (unsigned int)(0));
    zT_161 = self;
    (void)zF_4F84B621_registerPrimitive(zT_161, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type), (unsigned int)(0), (unsigned int)(0));
    zT_169 = self;
    (void)zF_4F84B621_registerPrimitive(zT_169, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type), (unsigned int)(4), (unsigned int)(4));
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    zT_181 = self;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, (unsigned int)(1), zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    zT_189 = self;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, (unsigned int)(2), zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, (unsigned int)(4), zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, (unsigned int)(5), zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, (unsigned int)(6), zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, (unsigned int)(7), zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, (unsigned int)(8), zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, (unsigned int)(9), zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, (unsigned int)(10), zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, (unsigned int)(11), zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    zT_261 = self;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, (unsigned int)(12), zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    zT_269 = self;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, (unsigned int)(13), zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, (unsigned int)(14), zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, (unsigned int)(15), zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, (unsigned int)(16), zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    zT_301 = self;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, (unsigned int)(17), zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, (unsigned int)(18), zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    zT_317 = self;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, (unsigned int)(20), zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, (unsigned int)(21), zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_16;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_4 = self->interner;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, (zT_79FAE712_u64)((zT_79FAE712_u64)nid), zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, unsigned char* is_unsigned) {
    unsigned int zT_4;
    unsigned char* zT_9;
    int zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned char zT_19;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_30;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned int zT_41;
    unsigned int zT_44;
    int zT_48;
    unsigned int zT_50;
    unsigned char zT_53;
    unsigned char zT_59;
    unsigned int nlen;
    unsigned char prefix;
    unsigned char is_u;
    unsigned char is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    if ((unsigned char)(nlen < (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = zT_9[zT_10];
    prefix = zT_11;
    zT_14 = prefix == (unsigned char)(117);
    is_u = zT_14;
    zT_17 = prefix == (unsigned char)(105);
    is_i = zT_17;
    if ((unsigned char)(!is_u)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = !is_i;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    *is_unsigned = (unsigned char)(1);
    goto z_bb_9;
    z_bb_9:
    zT_25 = 0;
    w = zT_25;
    zT_27 = 1;
    i = zT_27;
    goto z_bb_11;
    z_bb_10:
    *is_unsigned = (unsigned char)(0);
    goto z_bb_9;
    z_bb_11:
    if ((unsigned char)(i < nlen)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = name.ptr;
    zT_31 = zT_30[i];
    c = zT_31;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_48 = 1;
    zT_50 = i + (unsigned int)((unsigned int)zT_48);
    i = zT_50;
    goto z_bb_11;
    z_bb_15:
    zT_34 = c > (unsigned char)(57);
    goto z_bb_17;
    z_bb_16:
    zT_34 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_34) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned int)(0);
    z_bb_19:
    zT_41 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_41;
    zT_44 = (unsigned int)(w * (unsigned int)(10)) + d;
    w = zT_44;
    if ((unsigned char)(w > (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_53 = w > (unsigned int)(64);
    goto z_bb_27;
    z_bb_26:
    zT_53 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_59 = w > (unsigned int)(63);
    goto z_bb_32;
    z_bb_31:
    zT_59 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_59) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned int)(0);
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned char zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6;
    unsigned int zT_8 = 0;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53 = 0;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned char arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    zT_5 = name;
    zT_6 = &arb_u;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    if ((unsigned char)(arb_w == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_13 = self->interner;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    zT_18 = self;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, (zT_79FAE712_u64)((zT_79FAE712_u64)nid));
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = zT_33EF6BFB_TypeKind_arb_uint_type;
    goto z_bb_7;
    z_bb_6:
    zT_25 = zT_33EF6BFB_TypeKind_arb_int_type;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    if ((unsigned char)(arb_w > (unsigned int)(8))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(arb_w > (unsigned int)(16))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(arb_w > (unsigned int)(32))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    if (arb_u) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = 0;
    goto z_bb_16;
    z_bb_15:
    zT_45 = 1;
    goto z_bb_16;
    z_bb_16:
    zT_42.is_signed = zT_45;
    zT_48 = (unsigned char)arb_w;
    zT_42.width_bits = zT_48;
    zT_42.size = carrier;
    zT_42.alignment = carrier;
    zT_49 = 0;
    zT_42.name_id = zT_49;
    zT_50 = 0;
    zT_42.c_name_id = zT_50;
    zT_51 = 0;
    zT_42.module_id = zT_51;
    zT_52 = 0;
    zT_42.payload_idx = zT_52;
    zT_41 = zT_42;
    zT_53 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_53;
    zT_54 = self;
    zT_55 = tid;
    zT_56 = name;
    zF_BA76727A_registerPrimitiveNa(zT_54, zT_55, zT_56);
    return tid;
}

/* typeRegistryEnumBackingType */
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(10);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(10);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(10);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.backing_type;
    return zT_24;
}

/* typeRegistryEnumHasExplicitBacking */
unsigned char zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned char zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.explicit_backing;
    return (unsigned char)(zT_24 != (unsigned char)(0));
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_29 = 0;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_23 = ty.kind;
    zT_22 = zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = ty.width_bits;
    return zT_26;
    z_bb_9:
    zT_27 = ty.kind;
    zT_29 = zF_534230F8_typeWidthBitsForKin(zT_27);
    return zT_29;
}

/* typeRegistryIntIsSigned */
unsigned char zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_47;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    unsigned char zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_27 = ty.kind;
    if ((unsigned char)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = ty.kind;
    zT_30 = zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_30 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_30) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_35 = ty.kind;
    zT_34 = zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_39 = ty.kind;
    zT_38 = zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_20;
    z_bb_19:
    zT_42 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_42) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_47 = ty.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_25;
    z_bb_24:
    zT_50 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_50) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = ty.kind;
    zT_54 = zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_28;
    z_bb_27:
    zT_54 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_54) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_31;
    z_bb_30:
    zT_58 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_58) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_63 = ty.kind;
    zT_62 = zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_34;
    z_bb_33:
    zT_62 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_62) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_67 = ty.kind;
    zT_66 = zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_37;
    z_bb_36:
    zT_66 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_66) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    return (unsigned char)(0);
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27 = 0;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    zT_4028D896_Arr_unsigned_char_2 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    unsigned int zT_46;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_4028D896_Arr_unsigned_char_2 zT_60;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_4028D896_Arr_unsigned_char_2 zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99 = 0;
    unsigned int zT_103;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_4028D896_Arr_unsigned_char_2 zT_117;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    int zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned int zT_131;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_9 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18.is_signed = zT_21;
    zT_22 = 0;
    zT_18.width_bits = zT_22;
    zT_23 = 0;
    zT_18.size = zT_23;
    zT_24 = 0;
    zT_18.alignment = zT_24;
    zT_18.name_id = name_id;
    zT_25 = 0;
    zT_18.c_name_id = zT_25;
    zT_18.module_id = module_id;
    zT_26 = 0;
    zT_18.payload_idx = zT_26;
    zT_17 = zT_18;
    zT_27 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_27;
    zT_28 = self;
    zT_29 = key;
    zT_30 = tid;
    zF_5E95558D_nameCachePut(zT_28, zT_29, zT_30);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = module_id;
    zT_38 = 0;
    zT_39 = (unsigned char*)((unsigned char*)rn_m) + zT_38;
    zT_40 = (unsigned int)(20) - zT_38;
    zT_41.ptr = zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zT_42 = zF_A7504564_itoa(zT_34, zT_35);
    rn_ml = zT_42;
    zT_46 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_ml);
    rn_ms = zT_46;
    zT_48 = "RN:m";
    zT_50 = 4;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    rnm = zT_49;
    zT_51 = rnm;
    zF_48AC7B3A_markerWrite(zT_51);
    zT_56 = (unsigned char*)((unsigned char*)rn_m) + rn_ms;
    zT_57 = (unsigned int)(19) - rn_ms;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_60[_i];
        _i++;
    }
}
    zT_62 = name_id;
    zT_66 = 0;
    zT_67 = (unsigned char*)((unsigned char*)rn_n) + zT_66;
    zT_68 = (unsigned int)(20) - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zT_70 = zF_A7504564_itoa(zT_62, zT_63);
    rn_nl = zT_70;
    zT_74 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_nl);
    rn_ns = zT_74;
    zT_76 = "n";
    zT_78 = 1;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    rnn = zT_77;
    zT_79 = rnn;
    zF_48AC7B3A_markerWrite(zT_79);
    zT_84 = (unsigned char*)((unsigned char*)rn_n) + rn_ns;
    zT_85 = (unsigned int)(19) - rn_ns;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zF_48AC7B3A_markerWrite(zT_80);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_88[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_88[_i];
        _i++;
    }
}
    zT_95 = 0;
    zT_96 = (unsigned char*)((unsigned char*)rn_k) + zT_95;
    zT_97 = (unsigned int)(20) - zT_95;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_91 = zT_98;
    zT_99 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_91);
    rn_kl = zT_99;
    zT_103 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_kl);
    rn_ks = zT_103;
    zT_105 = "k";
    zT_107 = 1;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rnk = zT_106;
    zT_108 = rnk;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_113 = (unsigned char*)((unsigned char*)rn_k) + rn_ks;
    zT_114 = (unsigned int)(19) - rn_ks;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_109 = zT_115;
    zF_48AC7B3A_markerWrite(zT_109);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_117[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_117[_i];
        _i++;
    }
}
    zT_119 = tid;
    zT_123 = 0;
    zT_124 = (unsigned char*)((unsigned char*)rn_t) + zT_123;
    zT_125 = (unsigned int)(20) - zT_123;
    zT_126.ptr = zT_124;
    zT_126.len = zT_125;
    zT_120 = zT_126;
    zT_127 = zF_A7504564_itoa(zT_119, zT_120);
    rn_tl = zT_127;
    zT_131 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_tl);
    rn_ts = zT_131;
    zT_133 = "t";
    zT_135 = 1;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    rnt = zT_134;
    zT_136 = rnt;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_141 = (unsigned char*)((unsigned char*)rn_t) + rn_ts;
    zT_142 = (unsigned int)(19) - rn_ts;
    zT_143.ptr = zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zF_48AC7B3A_markerWrite(zT_137);
    zT_145 = "\n";
    zT_147 = 1;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    rnnl = zT_146;
    zT_148 = rnnl;
    zF_48AC7B3A_markerWrite(zT_148);
    return tid;
}

/* isValueDependency */
unsigned char zF_2FA4221F_isValueDependency(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(0);
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
unsigned char zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    return (unsigned char)(0);
}

/* typeRegistryIsInteger */
unsigned char zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    return (unsigned char)(0);
}

/* typeRegistryIsUnsigned */
unsigned char zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(0);
}

/* typeRegistryIsPointer */
unsigned char zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
unsigned char zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type));
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_8 = zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeRegistryArrayByteSize */
zT_BAEE192E_Opt_10 zF_C35DA834_typeRegistryArrayBy(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9.has_value = 0;
    return zT_9;
    z_bb_2:
    zT_10 = ty.state;
    if ((unsigned char)(zT_10 != (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.size;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    unsigned char zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    if ((unsigned char)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
unsigned char zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type));
}

/* typeRegistryIsErrorSet */
unsigned char zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsPacked */
unsigned char zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.flags;
    return (unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) != (unsigned char)(0));
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_10;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    unsigned char zT_64;
    unsigned char zT_65;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    unsigned int zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_E276DDD0_PackedBitField zT_80;
    zT_E276DDD0_PackedBitField zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_86;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    zT_FA398D58_PackedStructInfo zT_89;
    zT_FA398D58_PackedStructInfo zT_91;
    unsigned short zT_92;
    unsigned int zT_97;
    unsigned int zT_100;
    zT_D155D06D_Type* zT_102;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_10 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(fi < fcount)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = fstart + fi;
    zT_46 = zT_44[zT_45];
    fe = zT_46;
    zT_48 = 1;
    w = zT_48;
    zT_49 = fe.type_id;
    zT_50 = self->types_len;
    if ((unsigned char)(zT_49 < (unsigned int)((unsigned int)zT_50))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_87 = self;
    zT_88 = ty.payload_idx;
    zT_91.pk_start = pk_start;
    zT_92 = (unsigned short)fcount;
    zT_91.pk_count = zT_92;
    zT_91.total_bits = total_bits;
    zT_89 = zT_91;
    zF_41767D71_pkSetFields(zT_87, zT_88, zT_89);
    zT_97 = (unsigned int)(total_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_97;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_84 = 1;
    zT_86 = fi + (unsigned int)((unsigned int)zT_84);
    fi = zT_86;
    goto z_bb_9;
    z_bb_13:
    zT_54 = self->types_items;
    zT_55 = fe.type_id;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    ft = zT_57;
    zT_58 = ft.kind;
    if ((unsigned char)(zT_58 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_81.bit_offset = total_bits;
    zT_82 = (unsigned short)w;
    zT_81.bit_width = zT_82;
    zT_80 = zT_81;
    zF_E48D8B88_pkFieldAppend(zT_79, zT_80);
    zT_83 = total_bits + w;
    total_bits = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_61 = ft.kind;
    if ((unsigned char)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_65 = ft.flags;
    zT_64 = (unsigned char)(zT_65 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_19;
    z_bb_18:
    zT_64 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_70 = self;
    zT_71 = fe.type_id;
    zT_73 = zF_CB27DBA4_typeRegistryGetPack(zT_70, zT_71);
    w = zT_73;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_74 = self;
    zT_75 = fe.type_id;
    zT_77 = zF_655972D5_typeRegistryIntWidt(zT_74, zT_75);
    zT_78 = (unsigned int)zT_77;
    w = zT_78;
    goto z_bb_21;
    z_bb_23:
    zT_100 = 1;
    sz = zT_100;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_102 = self->types_items;
    zT_102[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
unsigned char zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_E276DDD0_PackedBitField* zT_46;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_50;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_15 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    if ((unsigned char)(zT_21 >= (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_28 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_26) >= zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    zT_43 = self->pk_len;
    if ((unsigned char)((unsigned int)(pstart + pcount) > zT_43)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_46 = self->pk_items;
    zT_48 = zT_46 + pstart;
    zT_49 = (unsigned int)(pstart + pcount) - pstart;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    *out = zT_50;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    if ((unsigned char)(zT_20 >= (unsigned int)((unsigned int)zT_21))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_27 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_25) >= zT_27)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(0);
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.flags;
    ty.flags = (unsigned char)(zT_6 | (unsigned char)(16));
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    zT_2DF01B61_FieldEntry zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D155D06D_Type zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_59;
    unsigned char zT_60;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_E276DDD0_PackedBitField zT_75;
    zT_E276DDD0_PackedBitField zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    int zT_80;
    unsigned int zT_82;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_FA398D58_PackedStructInfo zT_85;
    zT_FA398D58_PackedStructInfo zT_87;
    unsigned short zT_88;
    unsigned int zT_93;
    unsigned int zT_96;
    zT_D155D06D_Type* zT_98;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    if ((unsigned char)(zT_10 >= (unsigned int)((unsigned int)zT_11))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = fstart + fi;
    zT_41 = zT_39[zT_40];
    fe = zT_41;
    zT_43 = 1;
    w = zT_43;
    zT_44 = fe.type_id;
    zT_45 = self->types_len;
    if ((unsigned char)(zT_44 < (unsigned int)((unsigned int)zT_45))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_83 = self;
    zT_84 = ty.payload_idx;
    zT_87.pk_start = pk_start;
    zT_88 = (unsigned short)fcount;
    zT_87.pk_count = zT_88;
    zT_87.total_bits = max_bits;
    zT_85 = zT_87;
    zF_0213D00C_pkUnSetFields(zT_83, zT_84, zT_85);
    zT_93 = (unsigned int)(max_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_93;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_80 = 1;
    zT_82 = fi + (unsigned int)((unsigned int)zT_80);
    fi = zT_82;
    goto z_bb_7;
    z_bb_11:
    zT_49 = self->types_items;
    zT_50 = fe.type_id;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    ft = zT_52;
    zT_53 = ft.kind;
    if ((unsigned char)(zT_53 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_74 = self;
    zT_77 = 0;
    zT_76.bit_offset = zT_77;
    zT_78 = (unsigned short)w;
    zT_76.bit_width = zT_78;
    zT_75 = zT_76;
    zF_E48D8B88_pkFieldAppend(zT_74, zT_75);
    if ((unsigned char)(w > max_bits)) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_56 = ft.kind;
    if ((unsigned char)(zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_60 = ft.flags;
    zT_59 = (unsigned char)(zT_60 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_17;
    z_bb_16:
    zT_59 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_59) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_65 = self;
    zT_66 = fe.type_id;
    zT_68 = zF_CB27DBA4_typeRegistryGetPack(zT_65, zT_66);
    w = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_69 = self;
    zT_70 = fe.type_id;
    zT_72 = zF_655972D5_typeRegistryIntWidt(zT_69, zT_70);
    zT_73 = (unsigned int)zT_72;
    w = zT_73;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_96 = 1;
    sz = zT_96;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_98 = self->types_items;
    zT_98[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
unsigned char zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_E276DDD0_PackedBitField* zT_40;
    zT_E276DDD0_PackedBitField* zT_42;
    unsigned int zT_43;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_44;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_22 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_20) >= zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    zT_37 = self->pk_len;
    if ((unsigned char)((unsigned int)(pstart + pcount) > zT_37)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_40 = self->pk_items;
    zT_42 = zT_40 + pstart;
    zT_43 = (unsigned int)(pstart + pcount) - pstart;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    *out = zT_44;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    if ((unsigned char)(zT_14 >= (unsigned int)((unsigned int)zT_15))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* pointerQualifiersMonotone */
unsigned char zF_08C13644_pointerQualifiersMo(unsigned char src_flags, unsigned char tgt_flags, unsigned char mask) {
    return (unsigned char)((unsigned char)((unsigned char)(src_flags & mask) & (unsigned char)(~(unsigned char)(tgt_flags & mask))) == (unsigned char)(0));
}

/* typeRegistryIsAssignable */
unsigned char zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_17;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned char zT_27 = 0;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38 = 0;
    unsigned char zT_39;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    unsigned char zT_42 = 0;
    unsigned char zT_43;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned char zT_48 = 0;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_51 = 0;
    unsigned char zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    unsigned char zT_56 = 0;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    unsigned char zT_59 = 0;
    unsigned char zT_64;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_71;
    unsigned int zT_72;
    unsigned char zT_73 = 0;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_79;
    zT_33EF6BFB_TypeKind zT_83;
    unsigned char zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_112BF819_PtrPayload* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_112BF819_PtrPayload zT_94;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    zT_0317B1D5_FnPayload* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_0317B1D5_FnPayload zT_107;
    zT_0317B1D5_FnPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_0317B1D5_FnPayload zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    unsigned short zT_117;
    unsigned short zT_118;
    unsigned char zT_120;
    unsigned char zT_121;
    unsigned char zT_124;
    unsigned char zT_128;
    unsigned char zT_129;
    unsigned char zT_132;
    unsigned char zT_137;
    int zT_139;
    unsigned short zT_140;
    unsigned short zT_141;
    unsigned int* zT_143;
    unsigned int zT_144;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int* zT_149;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    int zT_157;
    unsigned short zT_159;
    zT_33EF6BFB_TypeKind zT_161;
    zT_0B10E8E9_OptionalPayload* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_0B10E8E9_OptionalPayload zT_168;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned char zT_173 = 0;
    zT_33EF6BFB_TypeKind zT_175;
    zT_33EF6BFB_TypeKind zT_179;
    unsigned char zT_182;
    zT_33EF6BFB_TypeKind zT_183;
    zT_42C2D6BF_EUPayload* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_42C2D6BF_EUPayload zT_190;
    zT_42C2D6BF_EUPayload* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_42C2D6BF_EUPayload zT_195;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned char zT_206 = 0;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_33EF6BFB_TypeKind zT_210;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_338B7C76_TypeRegistry* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned char zT_222 = 0;
    zT_33EF6BFB_TypeKind zT_224;
    unsigned char zT_227;
    zT_33EF6BFB_TypeKind zT_228;
    zT_33EF6BFB_TypeKind zT_232;
    unsigned char zT_235;
    zT_33EF6BFB_TypeKind zT_236;
    zT_112BF819_PtrPayload* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    zT_112BF819_PtrPayload zT_243;
    zT_112BF819_PtrPayload* zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    zT_112BF819_PtrPayload zT_248;
    unsigned char zT_250;
    unsigned char zT_251;
    unsigned char zT_252;
    unsigned int zT_255;
    unsigned char zT_256 = 0;
    unsigned int zT_257;
    unsigned int zT_260;
    unsigned char zT_263;
    unsigned char zT_268;
    unsigned char zT_269;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned char zT_277;
    unsigned char zT_279;
    unsigned char zT_284;
    unsigned char zT_285;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    unsigned char zT_294;
    unsigned char zT_299;
    unsigned char zT_300;
    zT_33EF6BFB_TypeKind zT_306;
    unsigned char zT_309;
    zT_33EF6BFB_TypeKind zT_310;
    unsigned char zT_314;
    unsigned char zT_315;
    unsigned char zT_316;
    unsigned int zT_319;
    unsigned char zT_320 = 0;
    unsigned char zT_321;
    unsigned char zT_326;
    unsigned char zT_327;
    zT_0BB2A741_SlicePayload* zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    zT_0BB2A741_SlicePayload zT_336;
    zT_0BB2A741_SlicePayload* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_0BB2A741_SlicePayload zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    unsigned char zT_345;
    unsigned char zT_347;
    unsigned char zT_352;
    unsigned char zT_353;
    zT_0BB2A741_SlicePayload* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_0BB2A741_SlicePayload zT_362;
    zT_0BB2A741_SlicePayload* zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    zT_0BB2A741_SlicePayload zT_367;
    unsigned int zT_368;
    unsigned int zT_369;
    unsigned char zT_371;
    unsigned char zT_372;
    unsigned char zT_377;
    unsigned char zT_378;
    zT_33EF6BFB_TypeKind zT_384;
    unsigned char zT_387;
    zT_33EF6BFB_TypeKind zT_388;
    unsigned char zT_392;
    unsigned char zT_393;
    unsigned char zT_394;
    unsigned int zT_397;
    unsigned char zT_398 = 0;
    zT_112BF819_PtrPayload* zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    zT_112BF819_PtrPayload zT_403;
    zT_0BB2A741_SlicePayload* zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    zT_0BB2A741_SlicePayload zT_408;
    zT_D155D06D_Type* zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    zT_D155D06D_Type zT_413;
    zT_33EF6BFB_TypeKind zT_414;
    zT_E834303C_ArrayPayload* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    zT_E834303C_ArrayPayload zT_421;
    unsigned int zT_422;
    unsigned int zT_423;
    unsigned char zT_425;
    zT_33EF6BFB_TypeKind zT_427;
    unsigned char zT_430;
    zT_33EF6BFB_TypeKind zT_431;
    unsigned char zT_435;
    unsigned char zT_436;
    unsigned char zT_437;
    unsigned int zT_440;
    unsigned char zT_441 = 0;
    unsigned char zT_442;
    unsigned char zT_447;
    unsigned char zT_448;
    zT_112BF819_PtrPayload* zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    zT_112BF819_PtrPayload zT_457;
    zT_112BF819_PtrPayload* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    zT_112BF819_PtrPayload zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned char zT_466;
    unsigned char zT_468;
    unsigned char zT_473;
    unsigned char zT_474;
    zT_112BF819_PtrPayload* zT_480;
    unsigned int zT_481;
    unsigned int zT_482;
    zT_112BF819_PtrPayload zT_483;
    zT_112BF819_PtrPayload* zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    zT_112BF819_PtrPayload zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned char zT_493;
    unsigned char zT_498;
    unsigned char zT_499;
    zT_33EF6BFB_TypeKind zT_505;
    unsigned char zT_508;
    zT_33EF6BFB_TypeKind zT_509;
    unsigned char zT_513;
    unsigned char zT_514;
    unsigned char zT_515;
    unsigned int zT_518;
    unsigned char zT_519 = 0;
    zT_E834303C_ArrayPayload* zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    zT_E834303C_ArrayPayload zT_524;
    zT_0BB2A741_SlicePayload* zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    zT_0BB2A741_SlicePayload zT_529;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned char zT_533;
    unsigned char zT_535;
    unsigned char zT_540;
    unsigned int zT_541;
    unsigned int zT_542;
    unsigned char zT_544;
    zT_33EF6BFB_TypeKind zT_546;
    unsigned char zT_549;
    zT_33EF6BFB_TypeKind zT_550;
    unsigned char zT_554;
    unsigned char zT_555;
    unsigned char zT_556;
    unsigned int zT_559;
    unsigned char zT_560 = 0;
    zT_E834303C_ArrayPayload* zT_562;
    unsigned int zT_563;
    unsigned int zT_564;
    zT_E834303C_ArrayPayload zT_565;
    zT_112BF819_PtrPayload* zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    zT_112BF819_PtrPayload zT_570;
    unsigned int zT_571;
    unsigned int zT_572;
    unsigned char zT_574;
    zT_33EF6BFB_TypeKind zT_576;
    unsigned char zT_579;
    zT_33EF6BFB_TypeKind zT_580;
    unsigned char zT_584;
    unsigned char zT_585;
    unsigned char zT_586;
    unsigned int zT_589;
    unsigned char zT_590 = 0;
    zT_112BF819_PtrPayload* zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    zT_112BF819_PtrPayload zT_595;
    zT_112BF819_PtrPayload* zT_597;
    unsigned int zT_598;
    unsigned int zT_599;
    zT_112BF819_PtrPayload zT_600;
    zT_D155D06D_Type* zT_602;
    unsigned int zT_603;
    unsigned int zT_604;
    zT_D155D06D_Type zT_605;
    zT_33EF6BFB_TypeKind zT_606;
    zT_E834303C_ArrayPayload* zT_610;
    unsigned int zT_611;
    unsigned int zT_612;
    zT_E834303C_ArrayPayload zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned char zT_617;
    zT_33EF6BFB_TypeKind zT_619;
    unsigned char zT_622;
    zT_33EF6BFB_TypeKind zT_623;
    zT_E834303C_ArrayPayload* zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    zT_E834303C_ArrayPayload zT_630;
    zT_E834303C_ArrayPayload* zT_632;
    unsigned int zT_633;
    unsigned int zT_634;
    zT_E834303C_ArrayPayload zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned char zT_639;
    unsigned int zT_640;
    unsigned int zT_641;
    zT_33EF6BFB_TypeKind zT_644;
    unsigned char zT_647;
    zT_33EF6BFB_TypeKind zT_648;
    unsigned char zT_652;
    unsigned char zT_653;
    unsigned char zT_654;
    unsigned int zT_657;
    unsigned char zT_658 = 0;
    zT_0BB2A741_SlicePayload* zT_660;
    unsigned int zT_661;
    unsigned int zT_662;
    zT_0BB2A741_SlicePayload zT_663;
    zT_112BF819_PtrPayload* zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    zT_112BF819_PtrPayload zT_668;
    unsigned int zT_669;
    unsigned int zT_670;
    unsigned char zT_672;
    zT_33EF6BFB_TypeKind zT_674;
    unsigned char zT_677;
    zT_33EF6BFB_TypeKind zT_678;
    zT_0B10E8E9_OptionalPayload* zT_682;
    unsigned int zT_683;
    unsigned int zT_684;
    zT_0B10E8E9_OptionalPayload zT_685;
    zT_D155D06D_Type* zT_687;
    unsigned int zT_688;
    unsigned int zT_689;
    zT_D155D06D_Type zT_690;
    zT_33EF6BFB_TypeKind zT_691;
    zT_338B7C76_TypeRegistry* zT_694;
    unsigned int zT_695;
    unsigned int zT_697;
    unsigned char zT_701;
    unsigned char zT_704;
    unsigned char zT_707;
    zT_33EF6BFB_TypeKind zT_711;
    unsigned char zT_714;
    zT_33EF6BFB_TypeKind zT_715;
    zT_666DC2E1_TuplePayload* zT_719;
    unsigned int zT_720;
    unsigned int zT_721;
    zT_666DC2E1_TuplePayload zT_722;
    zT_E834303C_ArrayPayload* zT_724;
    unsigned int zT_725;
    unsigned int zT_726;
    zT_E834303C_ArrayPayload zT_727;
    unsigned short zT_728;
    unsigned int zT_730;
    unsigned char zT_733;
    int zT_735;
    unsigned short zT_736;
    unsigned short zT_737;
    zT_338B7C76_TypeRegistry* zT_739;
    unsigned int zT_740;
    unsigned int zT_741;
    unsigned int* zT_742;
    unsigned int zT_743;
    unsigned int zT_746;
    unsigned char zT_749 = 0;
    unsigned char zT_751;
    int zT_752;
    unsigned short zT_754;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0317B1D5_FnPayload src_f;
    zT_0317B1D5_FnPayload tgt_f;
    unsigned char ok;
    unsigned short fi;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned char es_ok;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    unsigned char qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload s_sl2;
    zT_0BB2A741_SlicePayload t_sl2;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload s_pp2;
    zT_112BF819_PtrPayload t_pp2;
    zT_112BF819_PtrPayload pp;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_D155D06D_Type opt_ty;
    zT_666DC2E1_TuplePayload tup;
    unsigned short k;
    z_bb_0:
    if ((unsigned char)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_17 = src.kind;
    if ((unsigned char)(zT_17 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_21 = src.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self;
    zT_26 = target;
    zT_27 = zF_3087E0A5_typeRegistryIsNumer(zT_25, zT_26);
    zT_24 = zT_27;
    goto z_bb_9;
    z_bb_8:
    zT_24 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    zT_29 = src.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_32 = target == (unsigned int)(14);
    goto z_bb_14;
    z_bb_13:
    zT_32 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_32) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_36 = self;
    zT_37 = source;
    zT_38 = zF_3290E9C4_typeRegistryIsInteg(zT_36, zT_37);
    if (zT_38) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_40 = self;
    zT_41 = target;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_40, zT_41);
    zT_39 = zT_42;
    goto z_bb_19;
    z_bb_18:
    zT_39 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_39) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_43 = source != (unsigned int)(19);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_B664AC19_typeRegistryIsUnsig(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_B664AC19_typeRegistryIsUnsig(zT_49, zT_50);
    if ((unsigned char)(zT_48 == zT_51)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(source == (unsigned int)(15))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_54 = self;
    zT_55 = source;
    zT_56 = zF_655972D5_typeRegistryIntWidt(zT_54, zT_55);
    zT_57 = self;
    zT_58 = target;
    zT_59 = zF_655972D5_typeRegistryIntWidt(zT_57, zT_58);
    zT_53 = zT_56 < zT_59;
    goto z_bb_27;
    z_bb_26:
    zT_53 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    zT_64 = target == (unsigned int)(16);
    goto z_bb_32;
    z_bb_31:
    zT_64 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_64) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    zT_68 = src.kind;
    if ((unsigned char)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_71 = self;
    zT_72 = target;
    zT_73 = zF_AD61DB1B_typeRegistryIsPoint(zT_71, zT_72);
    if (zT_73) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_83 = src.kind;
    if ((unsigned char)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_75 = tgt.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_79 = tgt.kind;
    if ((unsigned char)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_87 = tgt.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_45;
    z_bb_44:
    zT_86 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_86) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_91 = self->ptr_items;
    zT_92 = tgt.payload_idx;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    tpp = zT_94;
    zT_96 = self->types_items;
    zT_97 = tpp.base;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    bt = zT_99;
    zT_100 = bt.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_161 = tgt.kind;
    if ((unsigned char)(zT_161 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_48:
    zT_104 = self->fn_items;
    zT_105 = src.payload_idx;
    zT_106 = (unsigned int)zT_105;
    zT_107 = zT_104[zT_106];
    src_f = zT_107;
    zT_109 = self->fn_items;
    zT_110 = bt.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    tgt_f = zT_112;
    zT_113 = src_f.return_type;
    zT_114 = tgt_f.return_type;
    if ((unsigned char)(zT_113 == zT_114)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_117 = src_f.params_count;
    zT_118 = tgt_f.params_count;
    zT_116 = zT_117 == zT_118;
    goto z_bb_52;
    z_bb_51:
    zT_116 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_116) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_121 = src_f.flags_packed;
    zT_124 = tgt_f.flags_packed;
    zT_120 = (unsigned char)(zT_121 & (unsigned char)(1)) == (unsigned char)(zT_124 & (unsigned char)(1));
    goto z_bb_55;
    z_bb_54:
    zT_120 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_120) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_129 = src_f.flags_packed;
    zT_132 = tgt_f.flags_packed;
    zT_128 = (unsigned char)(zT_129 & (unsigned char)(2)) == (unsigned char)(zT_132 & (unsigned char)(2));
    goto z_bb_58;
    z_bb_57:
    zT_128 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_128) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_137 = 1;
    ok = zT_137;
    zT_139 = 0;
    zT_140 = (unsigned short)zT_139;
    fi = zT_140;
    goto z_bb_61;
    z_bb_60:
    goto z_bb_49;
    z_bb_61:
    zT_141 = src_f.params_count;
    if ((unsigned char)(fi < zT_141)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_143 = self->xt_items;
    zT_144 = src_f.params_start;
    zT_147 = (unsigned int)(unsigned int)(zT_144 + (unsigned int)((unsigned int)fi));
    zT_148 = zT_143[zT_147];
    zT_149 = self->xt_items;
    zT_150 = tgt_f.params_start;
    zT_153 = (unsigned int)(unsigned int)(zT_150 + (unsigned int)((unsigned int)fi));
    zT_154 = zT_149[zT_153];
    if ((unsigned char)(zT_148 != zT_154)) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    if (ok) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_157 = 1;
    zT_159 = fi + (unsigned short)((unsigned short)zT_157);
    fi = zT_159;
    goto z_bb_61;
    z_bb_65:
    zT_156 = 0;
    ok = zT_156;
    goto z_bb_63;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    return (unsigned char)(1);
    z_bb_68:
    goto z_bb_60;
    z_bb_69:
    zT_165 = self->opt_items;
    zT_166 = tgt.payload_idx;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zT_165[zT_167];
    opt = zT_168;
    zT_169 = self;
    zT_170 = source;
    zT_171 = opt.payload;
    zT_173 = zF_683AEB7F_typeRegistryIsAssig(zT_169, zT_170, zT_171);
    if (zT_173) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    zT_179 = src.kind;
    if ((unsigned char)(zT_179 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_71:
    return (unsigned char)(1);
    z_bb_72:
    zT_175 = src.kind;
    if ((unsigned char)(zT_175 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (unsigned char)(1);
    z_bb_74:
    goto z_bb_70;
    z_bb_75:
    zT_183 = tgt.kind;
    zT_182 = zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_77;
    z_bb_76:
    zT_182 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_182) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_187 = self->eu_items;
    zT_188 = src.payload_idx;
    zT_189 = (unsigned int)zT_188;
    zT_190 = zT_187[zT_189];
    eu_src = zT_190;
    zT_192 = self->eu_items;
    zT_193 = tgt.payload_idx;
    zT_194 = (unsigned int)zT_193;
    zT_195 = zT_192[zT_194];
    eu_tgt = zT_195;
    zT_197 = eu_src.error_set;
    zT_198 = eu_tgt.error_set;
    zT_199 = zT_197 == zT_198;
    es_ok = zT_199;
    if ((unsigned char)(!es_ok)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_210 = tgt.kind;
    if ((unsigned char)(zT_210 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_80:
    zT_201 = self;
    zT_202 = eu_src.error_set;
    zT_203 = eu_tgt.error_set;
    zT_206 = zF_E35E11A5_errorSetIsSubset(zT_201, zT_202, zT_203);
    es_ok = zT_206;
    goto z_bb_81;
    z_bb_81:
    if (es_ok) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_207 = eu_src.payload;
    zT_208 = eu_tgt.payload;
    return (unsigned char)(zT_207 == zT_208);
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_214 = self->eu_items;
    zT_215 = tgt.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    eu = zT_217;
    zT_218 = self;
    zT_219 = source;
    zT_220 = eu.payload;
    zT_222 = zF_683AEB7F_typeRegistryIsAssig(zT_218, zT_219, zT_220);
    if (zT_222) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_224 = src.kind;
    if ((unsigned char)(zT_224 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    return (unsigned char)(1);
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_228 = tgt.kind;
    zT_227 = zT_228 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_90;
    z_bb_89:
    zT_227 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_227) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    return (unsigned char)(1);
    z_bb_92:
    zT_232 = src.kind;
    if ((unsigned char)(zT_232 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_236 = tgt.kind;
    zT_235 = zT_236 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_95;
    z_bb_94:
    zT_235 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_235) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_240 = self->ptr_items;
    zT_241 = tgt.payload_idx;
    zT_242 = (unsigned int)zT_241;
    zT_243 = zT_240[zT_242];
    tgt_pp = zT_243;
    zT_245 = self->ptr_items;
    zT_246 = src.payload_idx;
    zT_247 = (unsigned int)zT_246;
    zT_248 = zT_245[zT_247];
    src_pp = zT_248;
    zT_250 = src.flags;
    zT_251 = tgt.flags;
    zT_255 = 2;
    zT_252 = zT_255;
    zT_256 = zF_08C13644_pointerQualifiersMo(zT_250, zT_251, zT_252);
    qok = zT_256;
    zT_257 = tgt_pp.base;
    if ((unsigned char)(zT_257 == (unsigned int)(1))) goto z_bb_98; else goto z_bb_99;
    z_bb_97:
    zT_306 = tgt.kind;
    if ((unsigned char)(zT_306 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_125; else goto z_bb_126;
    z_bb_98:
    return qok;
    z_bb_99:
    zT_260 = src_pp.base;
    if ((unsigned char)(zT_260 == (unsigned int)(1))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return qok;
    z_bb_101:
    zT_263 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_263 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_269 = src.flags;
    zT_268 = (unsigned char)(zT_269 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_104;
    z_bb_103:
    zT_268 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_268) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_274 = src_pp.base;
    zT_275 = tgt_pp.base;
    if ((unsigned char)(zT_274 == zT_275)) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_279 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_279 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_107:
    zT_277 = qok;
    goto z_bb_109;
    z_bb_108:
    zT_277 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_277) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (unsigned char)(1);
    z_bb_111:
    goto z_bb_106;
    z_bb_112:
    zT_285 = src.flags;
    zT_284 = (unsigned char)(zT_285 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_114;
    z_bb_113:
    zT_284 = 0;
    goto z_bb_114;
    z_bb_114:
    if (zT_284) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_290 = src_pp.base;
    zT_291 = tgt_pp.base;
    if ((unsigned char)(zT_290 == zT_291)) goto z_bb_117; else goto z_bb_118;
    z_bb_116:
    goto z_bb_97;
    z_bb_117:
    zT_294 = src.flags;
    if ((unsigned char)((unsigned char)(zT_294 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_121; else goto z_bb_120;
    z_bb_118:
    zT_293 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_293) goto z_bb_123; else goto z_bb_124;
    z_bb_120:
    zT_300 = tgt.flags;
    zT_299 = (unsigned char)(zT_300 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_122;
    z_bb_121:
    zT_299 = 1;
    goto z_bb_122;
    z_bb_122:
    zT_293 = zT_299;
    goto z_bb_119;
    z_bb_123:
    return (unsigned char)(1);
    z_bb_124:
    goto z_bb_116;
    z_bb_125:
    zT_310 = src.kind;
    zT_309 = zT_310 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_127;
    z_bb_126:
    zT_309 = 0;
    goto z_bb_127;
    z_bb_127:
    if (zT_309) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_314 = src.flags;
    zT_315 = tgt.flags;
    zT_319 = 2;
    zT_316 = zT_319;
    zT_320 = zF_08C13644_pointerQualifiersMo(zT_314, zT_315, zT_316);
    qok = zT_320;
    zT_321 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_321 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_130; else goto z_bb_131;
    z_bb_129:
    zT_384 = tgt.kind;
    if ((unsigned char)(zT_384 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_153; else goto z_bb_154;
    z_bb_130:
    zT_327 = src.flags;
    zT_326 = (unsigned char)(zT_327 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_132;
    z_bb_131:
    zT_326 = 0;
    goto z_bb_132;
    z_bb_132:
    if (zT_326) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    zT_333 = self->slice_items;
    zT_334 = src.payload_idx;
    zT_335 = (unsigned int)zT_334;
    zT_336 = zT_333[zT_335];
    s_sl = zT_336;
    zT_338 = self->slice_items;
    zT_339 = tgt.payload_idx;
    zT_340 = (unsigned int)zT_339;
    zT_341 = zT_338[zT_340];
    t_sl = zT_341;
    zT_342 = s_sl.elem;
    zT_343 = t_sl.elem;
    if ((unsigned char)(zT_342 == zT_343)) goto z_bb_135; else goto z_bb_136;
    z_bb_134:
    zT_347 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_347 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_135:
    zT_345 = qok;
    goto z_bb_137;
    z_bb_136:
    zT_345 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_345) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (unsigned char)(1);
    z_bb_139:
    goto z_bb_134;
    z_bb_140:
    zT_353 = src.flags;
    zT_352 = (unsigned char)(zT_353 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_142;
    z_bb_141:
    zT_352 = 0;
    goto z_bb_142;
    z_bb_142:
    if (zT_352) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    zT_359 = self->slice_items;
    zT_360 = src.payload_idx;
    zT_361 = (unsigned int)zT_360;
    zT_362 = zT_359[zT_361];
    s_sl2 = zT_362;
    zT_364 = self->slice_items;
    zT_365 = tgt.payload_idx;
    zT_366 = (unsigned int)zT_365;
    zT_367 = zT_364[zT_366];
    t_sl2 = zT_367;
    zT_368 = s_sl2.elem;
    zT_369 = t_sl2.elem;
    if ((unsigned char)(zT_368 == zT_369)) goto z_bb_145; else goto z_bb_146;
    z_bb_144:
    goto z_bb_129;
    z_bb_145:
    zT_372 = src.flags;
    if ((unsigned char)((unsigned char)(zT_372 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_149; else goto z_bb_148;
    z_bb_146:
    zT_371 = 0;
    goto z_bb_147;
    z_bb_147:
    if (zT_371) goto z_bb_151; else goto z_bb_152;
    z_bb_148:
    zT_378 = tgt.flags;
    zT_377 = (unsigned char)(zT_378 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_150;
    z_bb_149:
    zT_377 = 1;
    goto z_bb_150;
    z_bb_150:
    zT_371 = zT_377;
    goto z_bb_147;
    z_bb_151:
    return (unsigned char)(1);
    z_bb_152:
    goto z_bb_144;
    z_bb_153:
    zT_388 = src.kind;
    zT_387 = zT_388 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_155;
    z_bb_154:
    zT_387 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_387) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_392 = src.flags;
    zT_393 = tgt.flags;
    zT_397 = 2;
    zT_394 = zT_397;
    zT_398 = zF_08C13644_pointerQualifiersMo(zT_392, zT_393, zT_394);
    qok = zT_398;
    zT_400 = self->ptr_items;
    zT_401 = src.payload_idx;
    zT_402 = (unsigned int)zT_401;
    zT_403 = zT_400[zT_402];
    src_pp = zT_403;
    zT_405 = self->slice_items;
    zT_406 = tgt.payload_idx;
    zT_407 = (unsigned int)zT_406;
    zT_408 = zT_405[zT_407];
    sl = zT_408;
    zT_410 = self->types_items;
    zT_411 = src_pp.base;
    zT_412 = (unsigned int)zT_411;
    zT_413 = zT_410[zT_412];
    src_pointee = zT_413;
    zT_414 = src_pointee.kind;
    if ((unsigned char)(zT_414 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_427 = tgt.kind;
    if ((unsigned char)(zT_427 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_165; else goto z_bb_166;
    z_bb_158:
    zT_418 = self->array_items;
    zT_419 = src_pointee.payload_idx;
    zT_420 = (unsigned int)zT_419;
    zT_421 = zT_418[zT_420];
    arr = zT_421;
    zT_422 = arr.elem;
    zT_423 = sl.elem;
    if ((unsigned char)(zT_422 == zT_423)) goto z_bb_160; else goto z_bb_161;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    zT_425 = qok;
    goto z_bb_162;
    z_bb_161:
    zT_425 = 0;
    goto z_bb_162;
    z_bb_162:
    if (zT_425) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    return (unsigned char)(1);
    z_bb_164:
    goto z_bb_159;
    z_bb_165:
    zT_431 = src.kind;
    zT_430 = zT_431 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_167;
    z_bb_166:
    zT_430 = 0;
    goto z_bb_167;
    z_bb_167:
    if (zT_430) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_435 = src.flags;
    zT_436 = tgt.flags;
    zT_440 = 2;
    zT_437 = zT_440;
    zT_441 = zF_08C13644_pointerQualifiersMo(zT_435, zT_436, zT_437);
    qok = zT_441;
    zT_442 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_442 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_170; else goto z_bb_171;
    z_bb_169:
    zT_505 = src.kind;
    if ((unsigned char)(zT_505 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_170:
    zT_448 = src.flags;
    zT_447 = (unsigned char)(zT_448 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_172;
    z_bb_171:
    zT_447 = 0;
    goto z_bb_172;
    z_bb_172:
    if (zT_447) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_454 = self->ptr_items;
    zT_455 = src.payload_idx;
    zT_456 = (unsigned int)zT_455;
    zT_457 = zT_454[zT_456];
    s_pp = zT_457;
    zT_459 = self->ptr_items;
    zT_460 = tgt.payload_idx;
    zT_461 = (unsigned int)zT_460;
    zT_462 = zT_459[zT_461];
    t_pp = zT_462;
    zT_463 = s_pp.base;
    zT_464 = t_pp.base;
    if ((unsigned char)(zT_463 == zT_464)) goto z_bb_175; else goto z_bb_176;
    z_bb_174:
    zT_468 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_468 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_180; else goto z_bb_181;
    z_bb_175:
    zT_466 = qok;
    goto z_bb_177;
    z_bb_176:
    zT_466 = 0;
    goto z_bb_177;
    z_bb_177:
    if (zT_466) goto z_bb_178; else goto z_bb_179;
    z_bb_178:
    return (unsigned char)(1);
    z_bb_179:
    goto z_bb_174;
    z_bb_180:
    zT_474 = src.flags;
    zT_473 = (unsigned char)(zT_474 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_182;
    z_bb_181:
    zT_473 = 0;
    goto z_bb_182;
    z_bb_182:
    if (zT_473) goto z_bb_183; else goto z_bb_184;
    z_bb_183:
    zT_480 = self->ptr_items;
    zT_481 = src.payload_idx;
    zT_482 = (unsigned int)zT_481;
    zT_483 = zT_480[zT_482];
    s_pp2 = zT_483;
    zT_485 = self->ptr_items;
    zT_486 = tgt.payload_idx;
    zT_487 = (unsigned int)zT_486;
    zT_488 = zT_485[zT_487];
    t_pp2 = zT_488;
    zT_489 = s_pp2.base;
    zT_490 = t_pp2.base;
    if ((unsigned char)(zT_489 == zT_490)) goto z_bb_185; else goto z_bb_186;
    z_bb_184:
    goto z_bb_169;
    z_bb_185:
    zT_493 = src.flags;
    if ((unsigned char)((unsigned char)(zT_493 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_189; else goto z_bb_188;
    z_bb_186:
    zT_492 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_492) goto z_bb_191; else goto z_bb_192;
    z_bb_188:
    zT_499 = tgt.flags;
    zT_498 = (unsigned char)(zT_499 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_190;
    z_bb_189:
    zT_498 = 1;
    goto z_bb_190;
    z_bb_190:
    zT_492 = zT_498;
    goto z_bb_187;
    z_bb_191:
    return (unsigned char)(1);
    z_bb_192:
    goto z_bb_184;
    z_bb_193:
    zT_509 = tgt.kind;
    zT_508 = zT_509 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_195;
    z_bb_194:
    zT_508 = 0;
    goto z_bb_195;
    z_bb_195:
    if (zT_508) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    zT_513 = src.flags;
    zT_514 = tgt.flags;
    zT_518 = 2;
    zT_515 = zT_518;
    zT_519 = zF_08C13644_pointerQualifiersMo(zT_513, zT_514, zT_515);
    qok = zT_519;
    zT_521 = self->array_items;
    zT_522 = src.payload_idx;
    zT_523 = (unsigned int)zT_522;
    zT_524 = zT_521[zT_523];
    arr = zT_524;
    zT_526 = self->slice_items;
    zT_527 = tgt.payload_idx;
    zT_528 = (unsigned int)zT_527;
    zT_529 = zT_526[zT_528];
    sl = zT_529;
    zT_530 = arr.elem;
    zT_531 = sl.elem;
    if ((unsigned char)(zT_530 == zT_531)) goto z_bb_198; else goto z_bb_199;
    z_bb_197:
    zT_546 = src.kind;
    if ((unsigned char)(zT_546 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_211; else goto z_bb_212;
    z_bb_198:
    zT_533 = qok;
    goto z_bb_200;
    z_bb_199:
    zT_533 = 0;
    goto z_bb_200;
    z_bb_200:
    if (zT_533) goto z_bb_201; else goto z_bb_202;
    z_bb_201:
    return (unsigned char)(1);
    z_bb_202:
    zT_535 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_535 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    zT_541 = arr.elem;
    zT_542 = sl.elem;
    zT_540 = zT_541 == zT_542;
    goto z_bb_205;
    z_bb_204:
    zT_540 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_540) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_544 = qok;
    goto z_bb_208;
    z_bb_207:
    zT_544 = 0;
    goto z_bb_208;
    z_bb_208:
    if (zT_544) goto z_bb_209; else goto z_bb_210;
    z_bb_209:
    return (unsigned char)(1);
    z_bb_210:
    goto z_bb_197;
    z_bb_211:
    zT_550 = tgt.kind;
    zT_549 = zT_550 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_213;
    z_bb_212:
    zT_549 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_549) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    zT_554 = src.flags;
    zT_555 = tgt.flags;
    zT_559 = 2;
    zT_556 = zT_559;
    zT_560 = zF_08C13644_pointerQualifiersMo(zT_554, zT_555, zT_556);
    qok = zT_560;
    zT_562 = self->array_items;
    zT_563 = src.payload_idx;
    zT_564 = (unsigned int)zT_563;
    zT_565 = zT_562[zT_564];
    arr = zT_565;
    zT_567 = self->ptr_items;
    zT_568 = tgt.payload_idx;
    zT_569 = (unsigned int)zT_568;
    zT_570 = zT_567[zT_569];
    pp = zT_570;
    zT_571 = arr.elem;
    zT_572 = pp.base;
    if ((unsigned char)(zT_571 == zT_572)) goto z_bb_216; else goto z_bb_217;
    z_bb_215:
    zT_576 = src.kind;
    if ((unsigned char)(zT_576 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_221; else goto z_bb_222;
    z_bb_216:
    zT_574 = qok;
    goto z_bb_218;
    z_bb_217:
    zT_574 = 0;
    goto z_bb_218;
    z_bb_218:
    if (zT_574) goto z_bb_219; else goto z_bb_220;
    z_bb_219:
    return (unsigned char)(1);
    z_bb_220:
    goto z_bb_215;
    z_bb_221:
    zT_580 = tgt.kind;
    zT_579 = zT_580 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_223;
    z_bb_222:
    zT_579 = 0;
    goto z_bb_223;
    z_bb_223:
    if (zT_579) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    zT_584 = src.flags;
    zT_585 = tgt.flags;
    zT_589 = 2;
    zT_586 = zT_589;
    zT_590 = zF_08C13644_pointerQualifiersMo(zT_584, zT_585, zT_586);
    qok = zT_590;
    zT_592 = self->ptr_items;
    zT_593 = src.payload_idx;
    zT_594 = (unsigned int)zT_593;
    zT_595 = zT_592[zT_594];
    sp = zT_595;
    zT_597 = self->ptr_items;
    zT_598 = tgt.payload_idx;
    zT_599 = (unsigned int)zT_598;
    zT_600 = zT_597[zT_599];
    tp = zT_600;
    zT_602 = self->types_items;
    zT_603 = sp.base;
    zT_604 = (unsigned int)zT_603;
    zT_605 = zT_602[zT_604];
    spo = zT_605;
    zT_606 = spo.kind;
    if ((unsigned char)(zT_606 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_226; else goto z_bb_227;
    z_bb_225:
    zT_619 = src.kind;
    if ((unsigned char)(zT_619 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_233; else goto z_bb_234;
    z_bb_226:
    zT_610 = self->array_items;
    zT_611 = spo.payload_idx;
    zT_612 = (unsigned int)zT_611;
    zT_613 = zT_610[zT_612];
    arr = zT_613;
    zT_614 = arr.elem;
    zT_615 = tp.base;
    if ((unsigned char)(zT_614 == zT_615)) goto z_bb_228; else goto z_bb_229;
    z_bb_227:
    goto z_bb_225;
    z_bb_228:
    zT_617 = qok;
    goto z_bb_230;
    z_bb_229:
    zT_617 = 0;
    goto z_bb_230;
    z_bb_230:
    if (zT_617) goto z_bb_231; else goto z_bb_232;
    z_bb_231:
    return (unsigned char)(1);
    z_bb_232:
    goto z_bb_227;
    z_bb_233:
    zT_623 = tgt.kind;
    zT_622 = zT_623 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_235;
    z_bb_234:
    zT_622 = 0;
    goto z_bb_235;
    z_bb_235:
    if (zT_622) goto z_bb_236; else goto z_bb_237;
    z_bb_236:
    zT_627 = self->array_items;
    zT_628 = src.payload_idx;
    zT_629 = (unsigned int)zT_628;
    zT_630 = zT_627[zT_629];
    s_arr = zT_630;
    zT_632 = self->array_items;
    zT_633 = tgt.payload_idx;
    zT_634 = (unsigned int)zT_633;
    zT_635 = zT_632[zT_634];
    t_arr = zT_635;
    zT_636 = s_arr.elem;
    zT_637 = t_arr.elem;
    if ((unsigned char)(zT_636 == zT_637)) goto z_bb_238; else goto z_bb_239;
    z_bb_237:
    zT_644 = src.kind;
    if ((unsigned char)(zT_644 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_243; else goto z_bb_244;
    z_bb_238:
    zT_640 = s_arr.length;
    zT_641 = t_arr.length;
    zT_639 = zT_640 == zT_641;
    goto z_bb_240;
    z_bb_239:
    zT_639 = 0;
    goto z_bb_240;
    z_bb_240:
    if (zT_639) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    return (unsigned char)(1);
    z_bb_242:
    goto z_bb_237;
    z_bb_243:
    zT_648 = tgt.kind;
    zT_647 = zT_648 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_245;
    z_bb_244:
    zT_647 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_647) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_652 = src.flags;
    zT_653 = tgt.flags;
    zT_657 = 2;
    zT_654 = zT_657;
    zT_658 = zF_08C13644_pointerQualifiersMo(zT_652, zT_653, zT_654);
    qok = zT_658;
    zT_660 = self->slice_items;
    zT_661 = src.payload_idx;
    zT_662 = (unsigned int)zT_661;
    zT_663 = zT_660[zT_662];
    sl = zT_663;
    zT_665 = self->ptr_items;
    zT_666 = tgt.payload_idx;
    zT_667 = (unsigned int)zT_666;
    zT_668 = zT_665[zT_667];
    pp = zT_668;
    zT_669 = sl.elem;
    zT_670 = pp.base;
    if ((unsigned char)(zT_669 == zT_670)) goto z_bb_248; else goto z_bb_249;
    z_bb_247:
    zT_674 = src.kind;
    if ((unsigned char)(zT_674 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_253; else goto z_bb_254;
    z_bb_248:
    zT_672 = qok;
    goto z_bb_250;
    z_bb_249:
    zT_672 = 0;
    goto z_bb_250;
    z_bb_250:
    if (zT_672) goto z_bb_251; else goto z_bb_252;
    z_bb_251:
    return (unsigned char)(1);
    z_bb_252:
    goto z_bb_247;
    z_bb_253:
    zT_678 = tgt.kind;
    zT_677 = zT_678 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_255;
    z_bb_254:
    zT_677 = 0;
    goto z_bb_255;
    z_bb_255:
    if (zT_677) goto z_bb_256; else goto z_bb_257;
    z_bb_256:
    zT_682 = self->opt_items;
    zT_683 = tgt.payload_idx;
    zT_684 = (unsigned int)zT_683;
    zT_685 = zT_682[zT_684];
    opt = zT_685;
    zT_687 = self->types_items;
    zT_688 = opt.payload;
    zT_689 = (unsigned int)zT_688;
    zT_690 = zT_687[zT_689];
    opt_ty = zT_690;
    zT_691 = opt_ty.kind;
    if ((unsigned char)(zT_691 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_258; else goto z_bb_259;
    z_bb_257:
    if ((unsigned char)(source == (unsigned int)(8))) goto z_bb_260; else goto z_bb_261;
    z_bb_258:
    zT_694 = self;
    zT_695 = source;
    zT_697 = opt.payload;
    self = zT_694;
    source = zT_695;
    target = zT_697;
    goto z_bb_0;
    z_bb_259:
    goto z_bb_257;
    z_bb_260:
    zT_701 = target == (unsigned int)(14);
    goto z_bb_262;
    z_bb_261:
    zT_701 = 0;
    goto z_bb_262;
    z_bb_262:
    if (zT_701) goto z_bb_264; else goto z_bb_263;
    z_bb_263:
    if ((unsigned char)(source == (unsigned int)(14))) goto z_bb_266; else goto z_bb_267;
    z_bb_264:
    zT_704 = 1;
    goto z_bb_265;
    z_bb_265:
    if (zT_704) goto z_bb_269; else goto z_bb_270;
    z_bb_266:
    zT_707 = target == (unsigned int)(8);
    goto z_bb_268;
    z_bb_267:
    zT_707 = 0;
    goto z_bb_268;
    z_bb_268:
    zT_704 = zT_707;
    goto z_bb_265;
    z_bb_269:
    return (unsigned char)(1);
    z_bb_270:
    zT_711 = src.kind;
    if ((unsigned char)(zT_711 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_271; else goto z_bb_272;
    z_bb_271:
    zT_715 = tgt.kind;
    zT_714 = zT_715 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_273;
    z_bb_272:
    zT_714 = 0;
    goto z_bb_273;
    z_bb_273:
    if (zT_714) goto z_bb_274; else goto z_bb_275;
    z_bb_274:
    zT_719 = self->tup_items;
    zT_720 = src.payload_idx;
    zT_721 = (unsigned int)zT_720;
    zT_722 = zT_719[zT_721];
    tup = zT_722;
    zT_724 = self->array_items;
    zT_725 = tgt.payload_idx;
    zT_726 = (unsigned int)zT_725;
    zT_727 = zT_724[zT_726];
    arr = zT_727;
    zT_728 = tup.elems_count;
    zT_730 = arr.length;
    if ((unsigned char)((unsigned int)((unsigned int)zT_728) == zT_730)) goto z_bb_276; else goto z_bb_277;
    z_bb_275:
    return (unsigned char)(0);
    z_bb_276:
    zT_733 = 1;
    ok = zT_733;
    zT_735 = 0;
    zT_736 = (unsigned short)zT_735;
    k = zT_736;
    goto z_bb_278;
    z_bb_277:
    goto z_bb_275;
    z_bb_278:
    zT_737 = tup.elems_count;
    if ((unsigned char)(k < zT_737)) goto z_bb_279; else goto z_bb_280;
    z_bb_279:
    zT_739 = self;
    zT_742 = self->xt_items;
    zT_743 = tup.elems_start;
    zT_746 = (unsigned int)(unsigned int)(zT_743 + (unsigned int)((unsigned int)k));
    zT_740 = zT_742[zT_746];
    zT_741 = arr.elem;
    zT_749 = zF_683AEB7F_typeRegistryIsAssig(zT_739, zT_740, zT_741);
    if ((unsigned char)(!zT_749)) goto z_bb_282; else goto z_bb_283;
    z_bb_280:
    if (ok) goto z_bb_284; else goto z_bb_285;
    z_bb_281:
    zT_752 = 1;
    zT_754 = k + (unsigned short)((unsigned short)zT_752);
    k = zT_754;
    goto z_bb_278;
    z_bb_282:
    zT_751 = 0;
    ok = zT_751;
    goto z_bb_280;
    z_bb_283:
    goto z_bb_281;
    z_bb_284:
    return (unsigned char)(1);
    z_bb_285:
    goto z_bb_277;
}

/* errorSetIsSubset */
unsigned char zF_E35E11A5_errorSetIsSubset(zT_338B7C76_TypeRegistry* self, unsigned int src, unsigned int tgt) {
    unsigned int zT_12;
    unsigned int zT_16;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_0B73C507_ErrorSetPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B73C507_ErrorSetPayload zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned short zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    int zT_56;
    unsigned int zT_57;
    zT_338B7C76_TypeRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    int zT_69;
    unsigned int zT_71;
    zT_D155D06D_Type sty;
    zT_D155D06D_Type tty;
    zT_0B73C507_ErrorSetPayload sp;
    unsigned int sstart;
    unsigned int scount;
    unsigned int i;
    if ((unsigned char)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(src == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(tgt == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_12 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src) >= zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_16 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tgt) >= zT_16)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_20 = self->types_items;
    zT_21 = (unsigned int)src;
    zT_22 = zT_20[zT_21];
    sty = zT_22;
    zT_24 = self->types_items;
    zT_25 = (unsigned int)tgt;
    zT_26 = zT_24[zT_25];
    tty = zT_26;
    zT_27 = sty.kind;
    if ((unsigned char)(zT_27 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_31 = tty.kind;
    if ((unsigned char)(zT_31 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_35 = sty.payload_idx;
    zT_37 = self->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_35) >= zT_37)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_41 = self->es_items;
    zT_42 = sty.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    sp = zT_44;
    zT_46 = sp.tags_start;
    zT_47 = (unsigned int)zT_46;
    sstart = zT_47;
    zT_49 = sp.tags_count;
    zT_50 = (unsigned int)zT_49;
    scount = zT_50;
    zT_52 = self->xn_len;
    if ((unsigned char)((unsigned int)(sstart + scount) > zT_52)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    i = zT_57;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(i < scount)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_59 = self;
    zT_60 = tgt;
    zT_62 = self->xn_items;
    zT_63 = sstart + i;
    zT_61 = zT_62[zT_63];
    zT_65 = zF_D2ECD176_typeRegistryErrorSe(zT_59, zT_60, zT_61);
    if ((unsigned char)(zT_65 == (unsigned int)(4294967295u))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    zT_69 = 1;
    zT_71 = i + (unsigned int)((unsigned int)zT_69);
    i = zT_71;
    goto z_bb_19;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    goto z_bb_22;
}

/* canLiteralFitInType */
unsigned char zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    unsigned char zT_6;
    unsigned char zT_13;
    unsigned char zT_22;
    unsigned char zT_32;
    unsigned char zT_39;
    unsigned char zT_46;
    unsigned char zT_59;
    unsigned char zT_66;
    unsigned char zT_71;
    if ((unsigned char)(target == (unsigned int)(4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-128))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(target == (unsigned int)(5))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_6 = value <= (zT_C69B2266_i64)(127);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-32768))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(target == (unsigned int)(6))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_13 = value <= (zT_C69B2266_i64)(32767);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    if ((unsigned char)(target == (unsigned int)(7))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_22 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    if ((unsigned char)(target == (unsigned int)(8))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((unsigned char)(target == (unsigned int)(9))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_32 = value <= (zT_C69B2266_i64)(255);
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(target == (unsigned int)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_39 = value <= (zT_C69B2266_i64)(65535);
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    if ((unsigned char)(target == (unsigned int)(11))) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_46 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    return (unsigned char)(value >= (zT_C69B2266_i64)(0));
    z_bb_34:
    if ((unsigned char)(target == (unsigned int)(12))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((unsigned char)(target == (unsigned int)(13))) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_59 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    if ((unsigned char)(target == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_66 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_71 = target == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return (unsigned char)(1);
    z_bb_49:
    return (unsigned char)(0);
}

/* EOF */
