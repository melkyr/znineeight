#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_25;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_54;
    unsigned int zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char zT_65;
    unsigned char zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    p0 = zT_4;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_12 = (unsigned int)used;
    zT_10 = zT_12;
    zT_13 = (unsigned char*)ubuf;
    zT_14 = 16;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = zT_14 - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_10, zT_11);
    ulen = zT_19;
    ulen = zT_19;
    ulen = zT_19;
    zT_21 = 15;
    zT_22 = (unsigned int)ulen;
    zT_23 = zT_21 - zT_22;
    ustart = zT_23;
    ustart = zT_23;
    ustart = zT_23;
    zT_25 = (unsigned char*)ubuf;
    zT_27 = 15;
    zT_28 = zT_25 + ustart;
    zT_29 = zT_27 - ustart;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    p1 = zT_33;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_41 = (unsigned int)new_bytes;
    zT_39 = zT_41;
    zT_42 = (unsigned char*)nbuf;
    zT_43 = 16;
    zT_44 = 0;
    zT_45 = zT_42 + zT_44;
    zT_46 = zT_43 - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa(zT_39, zT_40);
    nlen = zT_48;
    nlen = zT_48;
    nlen = zT_48;
    zT_50 = 15;
    zT_51 = (unsigned int)nlen;
    zT_52 = zT_50 - zT_51;
    nstart = zT_52;
    nstart = zT_52;
    nstart = zT_52;
    zT_54 = (unsigned char*)nbuf;
    zT_56 = 15;
    zT_57 = zT_54 + nstart;
    zT_58 = zT_56 - nstart;
    zT_59.ptr = zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    p2 = zT_62;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = 1;
    zT_65 = zT_66;
    zF_CDED1A85_exit(zT_65);
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3E40CD83_Sand* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_A62CFBCC_EU_022 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    zT_7 = 8;
    zT_8 = zT_6 < zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = 8;
    zT_9 = zT_10;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_12 = 2;
    zT_13 = zT_11 * zT_12;
    zT_9 = zT_13;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    nc = zT_9;
    nc = zT_9;
    zT_15 = alloc;
    zT_18 = elem_size * nc;
    zT_16 = zT_18;
    zT_19 = 4;
    zT_17 = zT_19;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, zT_16, zT_17);
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zT_26 = zT_25 * elem_size;
    zT_23 = zT_26;
    zT_27 = elem_size * nc;
    zT_24 = zT_27;
    zF_9091237C_typeDbOom(zT_23, zT_24);
    return;
    z_bb_5:
    zT_28 = zT_20.data.payload;
    zT_22 = zT_28;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    raw = zT_22;
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    src = zT_31;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    dst = zT_33;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    i = zT_36;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    zT_38 = zT_37 * elem_size;
    zT_39 = i < zT_38;
    if (zT_39) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    zT_43 = i + zT_42;
    i = zT_43;
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    int zT_7;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    zT_7 = new_cap <= zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_A62CFBCC_EU_022 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char* zT_34;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    int zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_20 = self->types_alloc;
    zT_17 = zT_20;
    zT_21 = 32;
    zT_22 = zT_21 * nc;
    zT_18 = zT_22;
    zT_23 = 4;
    zT_19 = zT_23;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, zT_18, zT_19);
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zT_30 = 32;
    zT_31 = zT_29 * zT_30;
    zT_27 = zT_31;
    zT_32 = 32;
    zT_33 = zT_32 * nc;
    zT_28 = zT_33;
    zF_9091237C_typeDbOom(zT_27, zT_28);
    return;
    z_bb_8:
    zT_34 = zT_24.data.payload;
    zT_26 = zT_34;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    raw = zT_26;
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    new_items = zT_36;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    zT_46 = i < zT_44;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    zT_48 = 1;
    zT_49 = i + zT_48;
    i = zT_49;
    goto z_bb_10;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_40;
    unsigned int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_69;
    unsigned int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_80;
    unsigned int zT_81;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_97;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zT_6 = zT_4 + zT_5;
    zT_3 = zT_6;
    zF_BCE30624_typeRegistryEnsureC(zT_2, zT_3);
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    id = zT_9;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zT_12 + zT_14;
    self->types_len = zT_15;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_22 = (unsigned int)zT_21;
    zT_19 = zT_22;
    zT_23 = (unsigned char*)dc_k;
    zT_24 = 20;
    zT_25 = 0;
    zT_26 = zT_23 + zT_25;
    zT_27 = zT_24 - zT_25;
    zT_28.ptr = zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa(zT_19, zT_20);
    dc_kl = zT_29;
    dc_kl = zT_29;
    dc_kl = zT_29;
    zT_31 = 19;
    zT_32 = (unsigned int)dc_kl;
    zT_33 = zT_31 - zT_32;
    dc_ks = zT_33;
    dc_ks = zT_33;
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    dcm = zT_36;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_40 = (unsigned char*)dc_k;
    zT_42 = 19;
    zT_43 = zT_40 + dc_ks;
    zT_44 = zT_42 - dc_ks;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = t.name_id;
    zT_49 = zT_51;
    zT_52 = (unsigned char*)dc_n;
    zT_53 = 20;
    zT_54 = 0;
    zT_55 = zT_52 + zT_54;
    zT_56 = zT_53 - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    dc_nl = zT_58;
    dc_nl = zT_58;
    zT_60 = 19;
    zT_61 = (unsigned int)dc_nl;
    zT_62 = zT_60 - zT_61;
    dc_ns = zT_62;
    dc_ns = zT_62;
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    dcn = zT_65;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_69 = (unsigned char*)dc_n;
    zT_71 = 19;
    zT_72 = zT_69 + dc_ns;
    zT_73 = zT_71 - dc_ns;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_80 = (unsigned char*)dc_i;
    zT_81 = 20;
    zT_82 = 0;
    zT_83 = zT_80 + zT_82;
    zT_84 = zT_81 - zT_82;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    dc_il = zT_86;
    dc_il = zT_86;
    zT_88 = 19;
    zT_89 = (unsigned int)dc_il;
    zT_90 = zT_88 - zT_89;
    dc_is = zT_90;
    dc_is = zT_90;
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    dci = zT_93;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_97 = (unsigned char*)dc_i;
    zT_99 = 19;
    zT_100 = zT_97 + dc_is;
    zT_101 = zT_99 - dc_is;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    dcnl = zT_105;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    zT_109 = zT_33EF6BFB_TypeKind_struct_type;
    zT_110 = zT_108 == zT_109;
    if (zT_110) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    xs = zT_113;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_112BF819_PtrPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->ptr_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->ptr_len;
    zT_3 = zT_10;
    zT_11 = &self->ptr_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->ptr_len = zT_23;
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->array_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->array_len;
    zT_3 = zT_10;
    zT_11 = &self->array_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->array_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->array_len = zT_23;
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->slice_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->slice_len;
    zT_3 = zT_10;
    zT_11 = &self->slice_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->slice_len = zT_23;
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->opt_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->opt_len;
    zT_3 = zT_10;
    zT_11 = &self->opt_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->opt_len = zT_23;
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->eu_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->eu_len;
    zT_3 = zT_10;
    zT_11 = &self->eu_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->eu_len = zT_23;
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->es_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->es_len;
    zT_3 = zT_10;
    zT_11 = &self->es_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->es_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->es_len = zT_23;
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->fn_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->fn_len;
    zT_3 = zT_10;
    zT_11 = &self->fn_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 24;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->fn_len = zT_23;
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_406493CE_StructPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->st_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->st_len;
    zT_3 = zT_10;
    zT_11 = &self->st_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->st_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->st_len = zT_23;
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_925BA889_pkStructAppend(zT_24, zT_25);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->pk_struct_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->pk_struct_len;
    zT_3 = zT_10;
    zT_11 = &self->pk_struct_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->pk_struct_items;
    zT_19 = self->pk_struct_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_struct_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->pk_struct_len = zT_23;
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_E276DDD0_PackedBitField* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->pk_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->pk_len;
    zT_3 = zT_10;
    zT_11 = &self->pk_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->pk_items;
    zT_19 = self->pk_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->pk_len = zT_23;
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->en_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->en_len;
    zT_3 = zT_10;
    zT_11 = &self->en_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->en_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->en_len = zT_23;
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->un_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->un_len;
    zT_3 = zT_10;
    zT_11 = &self->un_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->un_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->un_len = zT_23;
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_96B8622A_pkUnStructAppend(zT_24, zT_25);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->pk_un_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->pk_un_len;
    zT_3 = zT_10;
    zT_11 = &self->pk_un_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->pk_un_items;
    zT_19 = self->pk_un_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_un_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->pk_un_len = zT_23;
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->tu_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->tu_len;
    zT_3 = zT_10;
    zT_11 = &self->tu_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->tu_len = zT_23;
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->tup_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->tup_len;
    zT_3 = zT_10;
    zT_11 = &self->tup_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->tup_len = zT_23;
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->unr_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->unr_len;
    zT_3 = zT_10;
    zT_11 = &self->unr_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->unr_len = zT_23;
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->fe_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->fe_len;
    zT_3 = zT_10;
    zT_11 = &self->fe_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->fe_len = zT_23;
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->em_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->em_len;
    zT_3 = zT_10;
    zT_11 = &self->em_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 16;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->em_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->em_len = zT_23;
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_8 = &self->xt_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->xt_len;
    zT_3 = zT_10;
    zT_11 = &self->xt_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_6 = zT_13;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zT_16 = zT_14 + zT_15;
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19 + zT_21;
    self->xt_len = zT_22;
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_8 = &self->xn_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->xn_len;
    zT_3 = zT_10;
    zT_11 = &self->xn_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_6 = zT_13;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zT_16 = zT_14 + zT_15;
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19 + zT_21;
    self->xn_len = zT_22;
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    int zT_2;
    int zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    int zT_5;
    int zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    int zT_8;
    unsigned char zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_11;
    int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    unsigned char zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    int zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_20;
    int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_23;
    int zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    int zT_26;
    unsigned char zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    int zT_32;
    unsigned char zT_33;
    unsigned char zT_34;
    zT_1 = zT_33EF6BFB_TypeKind_i8_type;
    zT_2 = kind == zT_1;
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = zT_33EF6BFB_TypeKind_u8_type;
    zT_5 = kind == zT_4;
    zT_3 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = zT_33EF6BFB_TypeKind_c_char_type;
    zT_8 = kind == zT_7;
    zT_6 = zT_8;
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_9 = 8;
    return zT_9;
    z_bb_8:
    zT_10 = zT_33EF6BFB_TypeKind_i16_type;
    zT_11 = kind == zT_10;
    if (zT_11) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_13 = zT_33EF6BFB_TypeKind_u16_type;
    zT_14 = kind == zT_13;
    zT_12 = zT_14;
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_15 = 16;
    return zT_15;
    z_bb_13:
    zT_16 = zT_33EF6BFB_TypeKind_i32_type;
    zT_17 = kind == zT_16;
    if (zT_17) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_19 = zT_33EF6BFB_TypeKind_u32_type;
    zT_20 = kind == zT_19;
    zT_18 = zT_20;
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_22 = zT_33EF6BFB_TypeKind_isize_type;
    zT_23 = kind == zT_22;
    zT_21 = zT_23;
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_25 = zT_33EF6BFB_TypeKind_usize_type;
    zT_26 = kind == zT_25;
    zT_24 = zT_26;
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_27 = 32;
    return zT_27;
    z_bb_24:
    zT_28 = zT_33EF6BFB_TypeKind_i64_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_31 = zT_33EF6BFB_TypeKind_u64_type;
    zT_32 = kind == zT_31;
    zT_30 = zT_32;
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_33 = 64;
    return zT_33;
    z_bb_29:
    zT_34 = 0;
    return zT_34;
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    int zT_25;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    unsigned char p_wb;
    unsigned char p_sg;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    p_wb = zT_6;
    p_wb = zT_6;
    zT_8 = 0;
    p_sg = zT_8;
    p_sg = zT_8;
    p_sg = zT_8;
    zT_9 = zT_33EF6BFB_TypeKind_i8_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_12 = zT_33EF6BFB_TypeKind_i16_type;
    zT_13 = kind == zT_12;
    zT_11 = zT_13;
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_15 = zT_33EF6BFB_TypeKind_i32_type;
    zT_16 = kind == zT_15;
    zT_14 = zT_16;
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_18 = zT_33EF6BFB_TypeKind_i64_type;
    zT_19 = kind == zT_18;
    zT_17 = zT_19;
    goto z_bb_9;
    z_bb_8:
    zT_17 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_isize_type;
    zT_22 = kind == zT_21;
    zT_20 = zT_22;
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_24 = zT_33EF6BFB_TypeKind_c_char_type;
    zT_25 = kind == zT_24;
    zT_23 = zT_25;
    goto z_bb_15;
    z_bb_14:
    zT_23 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_23) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_26 = 1;
    p_sg = zT_26;
    p_sg = zT_26;
    goto z_bb_17;
    z_bb_17:
    zT_27 = self;
    zT_29.kind = kind;
    zT_30 = 2;
    zT_29.state = zT_30;
    zT_31 = 0;
    zT_29.flags = zT_31;
    zT_29.is_signed = p_sg;
    zT_29.width_bits = p_wb;
    zT_29.size = size;
    zT_29.alignment = alignment;
    zT_32 = 0;
    zT_29.name_id = zT_32;
    zT_33 = 0;
    zT_29.c_name_id = zT_33;
    zT_34 = 0;
    zT_29.module_id = zT_34;
    zT_35 = 0;
    zT_29.payload_idx = zT_35;
    zT_28 = zT_29;
    zT_36 = zF_D4993F02_typeRegistryAppend(zT_27, zT_28);
    return zT_36;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = v + a;
    zT_3 = 1;
    zT_4 = zT_2 - zT_3;
    zT_5 = 1;
    zT_6 = a - zT_5;
    zT_7 = ~zT_6;
    zT_8 = zT_4 & zT_7;
    return zT_8;
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    zT_4 = 0;
    *len = zT_4;
    zT_5 = 0;
    *cap = zT_5;
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68 = {0};
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70 = {0};
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72 = {0};
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74 = {0};
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76 = {0};
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78 = {0};
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = 0;
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zT_61 = 0;
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zT_64 = 0;
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    reg = zT_3;
    reg = zT_3;
    reg = zT_3;
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_A4CE86B7_U64ToU32Map* zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    int zT_11;
    char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_5 = &self->name_cache;
    zT_3 = zT_5;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    val = zT_6;
    val = zT_6;
    zT_8 = 4294967295u;
    zT_9 = key & zT_8;
    key_lo = zT_9;
    key_lo = zT_9;
    key_lo = zT_9;
    zT_10 = 1;
    zT_11 = key_lo == zT_10;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    ngc_m = zT_14;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_21 = 0;
    zT_19 = zT_21;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 zT_13;
    unsigned int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_32;
    unsigned int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_60;
    unsigned int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_6 = &self->name_cache;
    zT_3 = zT_6;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_12 = 65535;
    zT_13 = key & zT_12;
    zT_14 = __bootstrap_u32_from_u64(zT_13);
    zT_10 = zT_14;
    zT_15 = (unsigned char*)np_k;
    zT_16 = 20;
    zT_17 = 0;
    zT_18 = zT_15 + zT_17;
    zT_19 = zT_16 - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa(zT_10, zT_11);
    np_kl = zT_21;
    np_kl = zT_21;
    np_kl = zT_21;
    zT_23 = 19;
    zT_24 = (unsigned int)np_kl;
    zT_25 = zT_23 - zT_24;
    np_ks = zT_25;
    np_ks = zT_25;
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    npm = zT_28;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_32 = (unsigned char*)np_k;
    zT_34 = 19;
    zT_35 = zT_32 + np_ks;
    zT_36 = zT_34 - np_ks;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_43 = (unsigned char*)np_v;
    zT_44 = 20;
    zT_45 = 0;
    zT_46 = zT_43 + zT_45;
    zT_47 = zT_44 - zT_45;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    np_vl = zT_49;
    np_vl = zT_49;
    zT_51 = 19;
    zT_52 = (unsigned int)np_vl;
    zT_53 = zT_51 - zT_52;
    np_vs = zT_53;
    np_vs = zT_53;
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    npv = zT_56;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_60 = (unsigned char*)np_v;
    zT_62 = 19;
    zT_63 = zT_60 + np_vs;
    zT_64 = zT_62 - np_vs;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    npnl = zT_68;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_112BF819_PtrPayload zT_19;
    zT_112BF819_PtrPayload zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_D155D06D_Type zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned char zT_26;
    int zT_27;
    int zT_28;
    int zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_A4CE86B7_U64ToU32Map* zT_46;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)base;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->ptr_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    return existing;
    z_bb_5:
    zT_18 = self;
    zT_20.base = base;
    zT_19 = zT_20;
    zF_E5939FBD_ptrAppend(zT_18, zT_19);
    zT_22 = self;
    zT_25 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_24.kind = zT_25;
    zT_26 = 2;
    zT_24.state = zT_26;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    zT_27 = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_29 = 0;
    zT_27 = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_30 = (unsigned char)zT_27;
    zT_24.flags = zT_30;
    zT_31 = 0;
    zT_24.is_signed = zT_31;
    zT_32 = 0;
    zT_24.width_bits = zT_32;
    zT_33 = 4;
    zT_24.size = zT_33;
    zT_34 = 4;
    zT_24.alignment = zT_34;
    zT_35 = 0;
    zT_24.name_id = zT_35;
    zT_36 = 0;
    zT_24.c_name_id = zT_36;
    zT_37 = 0;
    zT_24.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_39 = 1;
    zT_40 = zT_38 - zT_39;
    zT_41 = (unsigned int)zT_40;
    zT_24.payload_idx = zT_41;
    zT_23 = zT_24;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_22, zT_23);
    tid = zT_42;
    tid = zT_42;
    tid = zT_42;
    zT_46 = &self->ptr_cache;
    zT_43 = zT_46;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_112BF819_PtrPayload zT_19;
    zT_112BF819_PtrPayload zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_D155D06D_Type zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned char zT_26;
    int zT_27;
    int zT_28;
    int zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_A4CE86B7_U64ToU32Map* zT_46;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)base;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->many_ptr_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    return existing;
    z_bb_5:
    zT_18 = self;
    zT_20.base = base;
    zT_19 = zT_20;
    zF_E5939FBD_ptrAppend(zT_18, zT_19);
    zT_22 = self;
    zT_25 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_24.kind = zT_25;
    zT_26 = 2;
    zT_24.state = zT_26;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    zT_27 = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_29 = 0;
    zT_27 = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_30 = (unsigned char)zT_27;
    zT_24.flags = zT_30;
    zT_31 = 0;
    zT_24.is_signed = zT_31;
    zT_32 = 0;
    zT_24.width_bits = zT_32;
    zT_33 = 4;
    zT_24.size = zT_33;
    zT_34 = 4;
    zT_24.alignment = zT_34;
    zT_35 = 0;
    zT_24.name_id = zT_35;
    zT_36 = 0;
    zT_24.c_name_id = zT_36;
    zT_37 = 0;
    zT_24.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_39 = 1;
    zT_40 = zT_38 - zT_39;
    zT_41 = (unsigned int)zT_40;
    zT_24.payload_idx = zT_41;
    zT_23 = zT_24;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_22, zT_23);
    tid = zT_42;
    tid = zT_42;
    tid = zT_42;
    zT_46 = &self->many_ptr_cache;
    zT_43 = zT_46;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_40;
    unsigned int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_68;
    unsigned int zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_97;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    int zT_112;
    int zT_113;
    int zT_114;
    unsigned char zT_115;
    unsigned char zT_116;
    unsigned char zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_128;
    zT_79FAE712_u64 zT_129;
    unsigned int zT_130;
    zT_A4CE86B7_U64ToU32Map* zT_131;
    char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_4028D896_Arr_unsigned_char_2 zT_138;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned char* zT_142;
    unsigned int zT_143;
    int zT_144;
    unsigned char* zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned char* zT_154;
    unsigned int zT_156;
    unsigned char* zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    zT_4028D896_Arr_unsigned_char_2 zT_166;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned char* zT_170;
    unsigned int zT_171;
    int zT_172;
    unsigned char* zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176 = 0;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned char* zT_182;
    unsigned int zT_184;
    unsigned char* zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_4028D896_Arr_unsigned_char_2 zT_194;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    unsigned char* zT_199;
    unsigned int zT_200;
    int zT_201;
    unsigned char* zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205 = 0;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned char* zT_211;
    unsigned int zT_213;
    unsigned char* zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)elem;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->slice_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    u2h_m = zT_20;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_28 = (unsigned char*)u2h_eb;
    zT_29 = 20;
    zT_30 = 0;
    zT_31 = zT_28 + zT_30;
    zT_32 = zT_29 - zT_30;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    u2h_el = zT_34;
    u2h_el = zT_34;
    zT_36 = 19;
    zT_37 = (unsigned int)u2h_el;
    zT_38 = zT_36 - zT_37;
    u2h_es = zT_38;
    u2h_es = zT_38;
    u2h_es = zT_38;
    zT_40 = (unsigned char*)u2h_eb;
    zT_42 = 19;
    zT_43 = zT_40 + u2h_es;
    zT_44 = zT_42 - u2h_es;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    u2h_rm = zT_48;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_56 = (unsigned char*)u2h_rb;
    zT_57 = 20;
    zT_58 = 0;
    zT_59 = zT_56 + zT_58;
    zT_60 = zT_57 - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    u2h_rl = zT_62;
    u2h_rl = zT_62;
    zT_64 = 19;
    zT_65 = (unsigned int)u2h_rl;
    zT_66 = zT_64 - zT_65;
    u2h_rs = zT_66;
    u2h_rs = zT_66;
    u2h_rs = zT_66;
    zT_68 = (unsigned char*)u2h_rb;
    zT_70 = 19;
    zT_71 = zT_68 + u2h_rs;
    zT_72 = zT_70 - u2h_rs;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    u2h_cm = zT_76;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_84 = __bootstrap_u32_from_u64(ic);
    zT_82 = zT_84;
    zT_85 = (unsigned char*)u2h_cb;
    zT_86 = 20;
    zT_87 = 0;
    zT_88 = zT_85 + zT_87;
    zT_89 = zT_86 - zT_87;
    zT_90.ptr = zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa(zT_82, zT_83);
    u2h_cl = zT_91;
    u2h_cl = zT_91;
    u2h_cl = zT_91;
    zT_93 = 19;
    zT_94 = (unsigned int)u2h_cl;
    zT_95 = zT_93 - zT_94;
    u2h_cs = zT_95;
    u2h_cs = zT_95;
    u2h_cs = zT_95;
    zT_97 = (unsigned char*)u2h_cb;
    zT_99 = 19;
    zT_100 = zT_97 + u2h_cs;
    zT_101 = zT_99 - u2h_cs;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_114 = 0;
    zT_112 = zT_114;
    goto z_bb_8;
    z_bb_8:
    zT_115 = (unsigned char)zT_112;
    zT_109.flags = zT_115;
    zT_116 = 0;
    zT_109.is_signed = zT_116;
    zT_117 = 0;
    zT_109.width_bits = zT_117;
    zT_118 = 8;
    zT_109.size = zT_118;
    zT_119 = 4;
    zT_109.alignment = zT_119;
    zT_120 = 0;
    zT_109.name_id = zT_120;
    zT_121 = 0;
    zT_109.c_name_id = zT_121;
    zT_122 = 0;
    zT_109.module_id = zT_122;
    zT_123 = self->slice_len;
    zT_124 = 1;
    zT_125 = zT_123 - zT_124;
    zT_126 = (unsigned int)zT_125;
    zT_109.payload_idx = zT_126;
    zT_108 = zT_109;
    zT_127 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_127;
    tid = zT_127;
    tid = zT_127;
    zT_131 = &self->slice_cache;
    zT_128 = zT_131;
    zT_129 = key;
    zT_130 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_128, zT_129, zT_130);
    zT_133 = "U2N:e";
    zT_135 = 5;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    u2n_m = zT_134;
    u2n_m = zT_134;
    u2n_m = zT_134;
    zT_136 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_136);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_138[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_138[_i];
        _i++;
    }
}
    zT_140 = elem;
    zT_142 = (unsigned char*)u2n_eb;
    zT_143 = 20;
    zT_144 = 0;
    zT_145 = zT_142 + zT_144;
    zT_146 = zT_143 - zT_144;
    zT_147.ptr = zT_145;
    zT_147.len = zT_146;
    zT_141 = zT_147;
    zT_148 = zF_A7504564_itoa(zT_140, zT_141);
    u2n_el = zT_148;
    u2n_el = zT_148;
    u2n_el = zT_148;
    zT_150 = 19;
    zT_151 = (unsigned int)u2n_el;
    zT_152 = zT_150 - zT_151;
    u2n_es = zT_152;
    u2n_es = zT_152;
    u2n_es = zT_152;
    zT_154 = (unsigned char*)u2n_eb;
    zT_156 = 19;
    zT_157 = zT_154 + u2n_es;
    zT_158 = zT_156 - u2n_es;
    zT_159.ptr = zT_157;
    zT_159.len = zT_158;
    zT_153 = zT_159;
    zF_48AC7B3A_markerWrite(zT_153);
    zT_161 = "r";
    zT_163 = 1;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    u2n_rm = zT_162;
    u2n_rm = zT_162;
    u2n_rm = zT_162;
    zT_164 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_164);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_166[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_166[_i];
        _i++;
    }
}
    zT_168 = tid;
    zT_170 = (unsigned char*)u2n_rb;
    zT_171 = 20;
    zT_172 = 0;
    zT_173 = zT_170 + zT_172;
    zT_174 = zT_171 - zT_172;
    zT_175.ptr = zT_173;
    zT_175.len = zT_174;
    zT_169 = zT_175;
    zT_176 = zF_A7504564_itoa(zT_168, zT_169);
    u2n_rl = zT_176;
    u2n_rl = zT_176;
    u2n_rl = zT_176;
    zT_178 = 19;
    zT_179 = (unsigned int)u2n_rl;
    zT_180 = zT_178 - zT_179;
    u2n_rs = zT_180;
    u2n_rs = zT_180;
    u2n_rs = zT_180;
    zT_182 = (unsigned char*)u2n_rb;
    zT_184 = 19;
    zT_185 = zT_182 + u2n_rs;
    zT_186 = zT_184 - u2n_rs;
    zT_187.ptr = zT_185;
    zT_187.len = zT_186;
    zT_181 = zT_187;
    zF_48AC7B3A_markerWrite(zT_181);
    zT_189 = "c";
    zT_191 = 1;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    u2n_cm = zT_190;
    u2n_cm = zT_190;
    u2n_cm = zT_190;
    zT_192 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_192);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_194[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_194[_i];
        _i++;
    }
}
    zT_198 = __bootstrap_u32_from_u64(ic);
    zT_196 = zT_198;
    zT_199 = (unsigned char*)u2n_cb;
    zT_200 = 20;
    zT_201 = 0;
    zT_202 = zT_199 + zT_201;
    zT_203 = zT_200 - zT_201;
    zT_204.ptr = zT_202;
    zT_204.len = zT_203;
    zT_197 = zT_204;
    zT_205 = zF_A7504564_itoa(zT_196, zT_197);
    u2n_cl = zT_205;
    u2n_cl = zT_205;
    u2n_cl = zT_205;
    zT_207 = 19;
    zT_208 = (unsigned int)u2n_cl;
    zT_209 = zT_207 - zT_208;
    u2n_cs = zT_209;
    u2n_cs = zT_209;
    u2n_cs = zT_209;
    zT_211 = (unsigned char*)u2n_cb;
    zT_213 = 19;
    zT_214 = zT_211 + u2n_cs;
    zT_215 = zT_213 - u2n_cs;
    zT_216.ptr = zT_214;
    zT_216.len = zT_215;
    zT_210 = zT_216;
    zF_48AC7B3A_markerWrite(zT_210);
    return tid;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_21D3708C_U32ToU32Map* zT_4;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39 = 0;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_0B10E8E9_OptionalPayload zT_42;
    zT_0B10E8E9_OptionalPayload zT_43;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned char zT_60;
    int zT_61;
    zT_21D3708C_U32ToU32Map* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_21D3708C_U32ToU32Map* zT_65;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_4 = &self->optional_cache;
    zT_2 = zT_4;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    return existing;
    z_bb_2:
    zT_9 = self->types_items;
    zT_10 = zT_9[payload];
    pay_type = zT_10;
    pay_type = zT_10;
    pay_type = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    opt_size = zT_13;
    opt_size = zT_13;
    opt_size = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    opt_align = zT_16;
    opt_align = zT_16;
    opt_align = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned char)zT_18;
    opt_state = zT_19;
    opt_state = zT_19;
    opt_state = zT_19;
    zT_20 = pay_type.state;
    zT_21 = 2;
    zT_22 = zT_20 == zT_21;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = pay_type.alignment;
    zT_25 = 4;
    zT_26 = zT_24 > zT_25;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_41 = self;
    zT_43.payload = payload;
    zT_42 = zT_43;
    zF_4569340E_optAppend(zT_41, zT_42);
    zT_45 = self;
    zT_48 = zT_33EF6BFB_TypeKind_optional_type;
    zT_47.kind = zT_48;
    zT_47.state = opt_state;
    zT_49 = 0;
    zT_47.flags = zT_49;
    zT_50 = 0;
    zT_47.is_signed = zT_50;
    zT_51 = 0;
    zT_47.width_bits = zT_51;
    zT_47.size = opt_size;
    zT_47.alignment = opt_align;
    zT_52 = 0;
    zT_47.name_id = zT_52;
    zT_53 = 0;
    zT_47.c_name_id = zT_53;
    zT_54 = 0;
    zT_47.module_id = zT_54;
    zT_55 = self->opt_len;
    zT_56 = 1;
    zT_57 = zT_55 - zT_56;
    zT_58 = (unsigned int)zT_57;
    zT_47.payload_idx = zT_58;
    zT_46 = zT_47;
    zT_59 = zF_D4993F02_typeRegistryAppend(zT_45, zT_46);
    tid = zT_59;
    tid = zT_59;
    tid = zT_59;
    zT_60 = 2;
    zT_61 = opt_state == zT_60;
    if (zT_61) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_28 = pay_type.alignment;
    zT_27 = zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 4;
    zT_27 = zT_29;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_27;
    pay_align = zT_27;
    pay_align = zT_27;
    zT_32 = pay_type.size;
    zT_30 = zT_32;
    zT_33 = 4;
    zT_31 = zT_33;
    zT_34 = zF_D2BAC673_alignUp(zT_30, zT_31);
    zT_35 = 4;
    zT_36 = zT_34 + zT_35;
    opt_size = zT_36;
    opt_size = zT_36;
    zT_37 = opt_size;
    zT_38 = pay_align;
    zT_39 = zF_D2BAC673_alignUp(zT_37, zT_38);
    opt_size = zT_39;
    opt_size = zT_39;
    opt_align = pay_align;
    opt_align = pay_align;
    zT_40 = 2;
    opt_state = zT_40;
    opt_state = zT_40;
    goto z_bb_4;
    z_bb_8:
    zT_65 = &self->optional_cache;
    zT_62 = zT_65;
    zT_63 = payload;
    zT_64 = tid;
    zF_26476265_u32ToU32MapPut(zT_62, zT_63, zT_64);
    goto z_bb_9;
    z_bb_9:
    return tid;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_A4CE86B7_U64ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_D155D06D_Type* zT_16;
    zT_D155D06D_Type zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    int zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56 = 0;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_42C2D6BF_EUPayload zT_59;
    zT_42C2D6BF_EUPayload zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type zT_63;
    zT_D155D06D_Type zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_79;
    zT_A4CE86B7_U64ToU32Map* zT_80;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_4 = (zT_79FAE712_u64)payload;
    zT_5 = 32;
    zT_6 = zT_4 << zT_5;
    zT_7 = (zT_79FAE712_u64)error_set;
    zT_8 = zT_6 | zT_7;
    eu_key = zT_8;
    eu_key = zT_8;
    eu_key = zT_8;
    zT_11 = &self->eu_cache;
    zT_9 = zT_11;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self->types_items;
    zT_17 = zT_16[payload];
    pay_type = zT_17;
    pay_type = zT_17;
    pay_type = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    eu_size = zT_20;
    eu_size = zT_20;
    eu_size = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    eu_align = zT_23;
    eu_align = zT_23;
    eu_align = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned char)zT_25;
    eu_state = zT_26;
    eu_state = zT_26;
    eu_state = zT_26;
    zT_27 = pay_type.state;
    zT_28 = 2;
    zT_29 = zT_27 == zT_28;
    if (zT_29) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = pay_type.size;
    zT_32 = 4;
    zT_33 = zT_31 > zT_32;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_58 = self;
    zT_60.payload = payload;
    zT_60.error_set = error_set;
    zT_59 = zT_60;
    zF_ABBA52E7_euAppend(zT_58, zT_59);
    zT_62 = self;
    zT_65 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_64.kind = zT_65;
    zT_64.state = eu_state;
    zT_66 = 0;
    zT_64.flags = zT_66;
    zT_67 = 0;
    zT_64.is_signed = zT_67;
    zT_68 = 0;
    zT_64.width_bits = zT_68;
    zT_64.size = eu_size;
    zT_64.alignment = eu_align;
    zT_69 = 0;
    zT_64.name_id = zT_69;
    zT_70 = 0;
    zT_64.c_name_id = zT_70;
    zT_71 = 0;
    zT_64.module_id = zT_71;
    zT_72 = self->eu_len;
    zT_73 = 1;
    zT_74 = zT_72 - zT_73;
    zT_75 = (unsigned int)zT_74;
    zT_64.payload_idx = zT_75;
    zT_63 = zT_64;
    zT_76 = zF_D4993F02_typeRegistryAppend(zT_62, zT_63);
    tid = zT_76;
    tid = zT_76;
    tid = zT_76;
    zT_80 = &self->eu_cache;
    zT_77 = zT_80;
    zT_78 = eu_key;
    zT_79 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_77, zT_78, zT_79);
    return tid;
    z_bb_5:
    zT_35 = pay_type.size;
    zT_34 = zT_35;
    goto z_bb_7;
    z_bb_6:
    zT_36 = 4;
    zT_34 = zT_36;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_34;
    union_size = zT_34;
    union_size = zT_34;
    zT_38 = pay_type.alignment;
    zT_39 = 4;
    zT_40 = zT_38 > zT_39;
    if (zT_40) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_42 = pay_type.alignment;
    zT_41 = zT_42;
    goto z_bb_10;
    z_bb_9:
    zT_43 = 4;
    zT_41 = zT_43;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_41;
    union_align = zT_41;
    union_align = zT_41;
    zT_45 = union_size;
    zT_46 = union_align;
    zT_47 = zF_D2BAC673_alignUp(zT_45, zT_46);
    total = zT_47;
    total = zT_47;
    total = zT_47;
    zT_48 = total;
    zT_50 = 4;
    zT_49 = zT_50;
    zT_51 = zF_D2BAC673_alignUp(zT_48, zT_49);
    zT_52 = 4;
    zT_53 = zT_51 + zT_52;
    total = zT_53;
    total = zT_53;
    zT_54 = total;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    eu_size = zT_56;
    eu_size = zT_56;
    eu_align = union_align;
    eu_align = union_align;
    zT_57 = 2;
    eu_state = zT_57;
    eu_state = zT_57;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_25;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_53;
    unsigned int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_60;
    zT_79FAE712_u64 zT_61;
    zT_79FAE712_u64 zT_62;
    zT_79FAE712_u64 zT_63;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_A4CE86B7_U64ToU32Map* zT_67;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_93;
    unsigned int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_E834303C_ArrayPayload zT_100;
    zT_E834303C_ArrayPayload zT_101;
    zT_D155D06D_Type* zT_103;
    zT_D155D06D_Type zT_104;
    int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned char zT_115;
    int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136 = 0;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_4028D896_Arr_unsigned_char_2 zT_143;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned char* zT_147;
    unsigned int zT_148;
    int zT_149;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153 = 0;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_159;
    unsigned int zT_161;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned char zT_165;
    unsigned char zT_166;
    int zT_167;
    zT_A4CE86B7_U64ToU32Map* zT_168;
    zT_79FAE712_u64 zT_169;
    unsigned int zT_170;
    zT_A4CE86B7_U64ToU32Map* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    o0m = zT_5;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_13 = (unsigned char*)o0b;
    zT_14 = 20;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = zT_14 - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    o0l = zT_19;
    o0l = zT_19;
    zT_21 = 19;
    zT_22 = (unsigned int)o0l;
    zT_23 = zT_21 - zT_22;
    o0s = zT_23;
    o0s = zT_23;
    o0s = zT_23;
    zT_25 = (unsigned char*)o0b;
    zT_27 = 19;
    zT_28 = zT_25 + o0s;
    zT_29 = zT_27 - o0s;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    o0m2 = zT_33;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_41 = (unsigned char*)o0b2;
    zT_42 = 20;
    zT_43 = 0;
    zT_44 = zT_41 + zT_43;
    zT_45 = zT_42 - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    o0l2 = zT_47;
    o0l2 = zT_47;
    zT_49 = 19;
    zT_50 = (unsigned int)o0l2;
    zT_51 = zT_49 - zT_50;
    o0s2 = zT_51;
    o0s2 = zT_51;
    o0s2 = zT_51;
    zT_53 = (unsigned char*)o0b2;
    zT_55 = 19;
    zT_56 = zT_53 + o0s2;
    zT_57 = zT_55 - o0s2;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_60 = (zT_79FAE712_u64)elem;
    zT_61 = 32;
    zT_62 = zT_60 << zT_61;
    zT_63 = (zT_79FAE712_u64)length;
    zT_64 = zT_62 | zT_63;
    key = zT_64;
    key = zT_64;
    key = zT_64;
    zT_67 = &self->array_cache;
    zT_65 = zT_67;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    o1m = zT_73;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_81 = (unsigned char*)o1b;
    zT_82 = 20;
    zT_83 = 0;
    zT_84 = zT_81 + zT_83;
    zT_85 = zT_82 - zT_83;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    o1l = zT_87;
    o1l = zT_87;
    zT_89 = 19;
    zT_90 = (unsigned int)o1l;
    zT_91 = zT_89 - zT_90;
    o1s = zT_91;
    o1s = zT_91;
    o1s = zT_91;
    zT_93 = (unsigned char*)o1b;
    zT_95 = 19;
    zT_96 = zT_93 + o1s;
    zT_97 = zT_95 - o1s;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    return existing;
    z_bb_2:
    zT_99 = self;
    zT_101.elem = elem;
    zT_101.length = length;
    zT_100 = zT_101;
    zF_4D5CD212_arrayAppend(zT_99, zT_100);
    zT_103 = self->types_items;
    zT_104 = zT_103[elem];
    elem_ty = zT_104;
    elem_ty = zT_104;
    elem_ty = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    arr_size = zT_107;
    arr_size = zT_107;
    arr_size = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    arr_align = zT_110;
    arr_align = zT_110;
    arr_align = zT_110;
    zT_112 = 0;
    zT_113 = (unsigned char)zT_112;
    arr_state = zT_113;
    arr_state = zT_113;
    arr_state = zT_113;
    zT_114 = elem_ty.state;
    zT_115 = 2;
    zT_116 = zT_114 == zT_115;
    if (zT_116) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_117 = elem_ty.size;
    zT_118 = zT_117 * length;
    arr_size = zT_118;
    arr_size = zT_118;
    zT_119 = elem_ty.alignment;
    arr_align = zT_119;
    arr_align = zT_119;
    zT_120 = 2;
    arr_state = zT_120;
    arr_state = zT_120;
    goto z_bb_4;
    z_bb_4:
    zT_122 = self;
    zT_125 = zT_33EF6BFB_TypeKind_array_type;
    zT_124.kind = zT_125;
    zT_124.state = arr_state;
    zT_126 = 0;
    zT_124.flags = zT_126;
    zT_127 = 0;
    zT_124.is_signed = zT_127;
    zT_128 = 0;
    zT_124.width_bits = zT_128;
    zT_124.size = arr_size;
    zT_124.alignment = arr_align;
    zT_129 = 0;
    zT_124.name_id = zT_129;
    zT_130 = 0;
    zT_124.c_name_id = zT_130;
    zT_131 = 0;
    zT_124.module_id = zT_131;
    zT_132 = self->array_len;
    zT_133 = 1;
    zT_134 = zT_132 - zT_133;
    zT_135 = (unsigned int)zT_134;
    zT_124.payload_idx = zT_135;
    zT_123 = zT_124;
    zT_136 = zF_D4993F02_typeRegistryAppend(zT_122, zT_123);
    tid = zT_136;
    tid = zT_136;
    tid = zT_136;
    zT_138 = "O2N";
    zT_140 = 3;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    o2m = zT_139;
    o2m = zT_139;
    o2m = zT_139;
    zT_141 = o2m;
    zF_48AC7B3A_markerWrite(zT_141);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_143[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_143[_i];
        _i++;
    }
}
    zT_145 = tid;
    zT_147 = (unsigned char*)o2b;
    zT_148 = 20;
    zT_149 = 0;
    zT_150 = zT_147 + zT_149;
    zT_151 = zT_148 - zT_149;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zT_153 = zF_A7504564_itoa(zT_145, zT_146);
    o2l = zT_153;
    o2l = zT_153;
    o2l = zT_153;
    zT_155 = 19;
    zT_156 = (unsigned int)o2l;
    zT_157 = zT_155 - zT_156;
    o2s = zT_157;
    o2s = zT_157;
    o2s = zT_157;
    zT_159 = (unsigned char*)o2b;
    zT_161 = 19;
    zT_162 = zT_159 + o2s;
    zT_163 = zT_161 - o2s;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_158 = zT_164;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_165 = elem_ty.state;
    zT_166 = 2;
    zT_167 = zT_165 == zT_166;
    if (zT_167) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_171 = &self->array_cache;
    zT_168 = zT_171;
    zT_169 = key;
    zT_170 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_168, zT_169, zT_170);
    goto z_bb_6;
    z_bb_6:
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.is_signed = zT_13;
    zT_14 = 0;
    zT_9.width_bits = zT_14;
    zT_15 = 0;
    zT_9.size = zT_15;
    zT_16 = 1;
    zT_9.alignment = zT_16;
    zT_17 = 0;
    zT_9.name_id = zT_17;
    zT_18 = 0;
    zT_9.c_name_id = zT_18;
    zT_19 = 0;
    zT_9.module_id = zT_19;
    zT_20 = self->tup_len;
    zT_21 = 1;
    zT_22 = zT_20 - zT_21;
    zT_23 = (unsigned int)zT_22;
    zT_9.payload_idx = zT_23;
    zT_8 = zT_9;
    zT_24 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_24;
    tid = zT_24;
    tid = zT_24;
    return tid;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type) {
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_4028D896_Arr_unsigned_char_2 zT_14;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24 = 0;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_30;
    unsigned int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_D155D06D_Type* zT_42;
    zT_D155D06D_Type zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    int zT_46;
    int zT_47;
    unsigned int zT_48;
    int zT_49;
    int zT_50;
    zT_0317B1D5_FnPayload* zT_51;
    zT_D155D06D_Type* zT_52;
    zT_D155D06D_Type zT_53;
    unsigned int zT_54;
    zT_0317B1D5_FnPayload zT_55;
    unsigned int zT_56;
    int zT_57;
    char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0317B1D5_FnPayload zT_67;
    zT_0317B1D5_FnPayload zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_D155D06D_Type zT_71;
    zT_D155D06D_Type zT_72;
    zT_33EF6BFB_TypeKind zT_73;
    unsigned char zT_74;
    unsigned char zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_88;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    int zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98 = 0;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned char* zT_104;
    unsigned int zT_106;
    unsigned char* zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_9 = "P2:n";
    zT_11 = 4;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    p2m = zT_10;
    p2m = zT_10;
    p2m = zT_10;
    zT_12 = p2m;
    zF_48AC7B3A_markerWrite(zT_12);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_14[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_14[_i];
        _i++;
    }
}
    zT_16 = name_id;
    zT_18 = (unsigned char*)p2nb;
    zT_19 = 20;
    zT_20 = 0;
    zT_21 = zT_18 + zT_20;
    zT_22 = zT_19 - zT_20;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    zT_17 = zT_23;
    zT_24 = zF_A7504564_itoa(zT_16, zT_17);
    p2nl = zT_24;
    p2nl = zT_24;
    p2nl = zT_24;
    zT_26 = 19;
    zT_27 = (unsigned int)p2nl;
    zT_28 = zT_26 - zT_27;
    p2ns = zT_28;
    p2ns = zT_28;
    p2ns = zT_28;
    zT_30 = (unsigned char*)p2nb;
    zT_32 = 19;
    zT_33 = zT_30 + p2ns;
    zT_34 = zT_32 - p2ns;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_29 = zT_35;
    zF_48AC7B3A_markerWrite(zT_29);
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    i = zT_38;
    i = zT_38;
    i = zT_38;
    goto z_bb_1;
    z_bb_1:
    zT_39 = self->types_len;
    zT_40 = i < zT_39;
    if (zT_40) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_42 = self->types_items;
    zT_43 = zT_42[i];
    it = zT_43;
    it = zT_43;
    it = zT_43;
    zT_44 = it.kind;
    zT_45 = zT_33EF6BFB_TypeKind_fn_type;
    zT_46 = zT_44 == zT_45;
    if (zT_46) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_66 = self;
    zT_68.name_id = name_id;
    zT_68.module_id = module_id;
    zT_68.is_extern = is_extern;
    zT_68.params_start = params_start;
    zT_68.params_count = params_count;
    zT_68.return_type = return_type;
    zT_68.flags_packed = is_variadic;
    zT_67 = zT_68;
    zF_07DDC351_fnAppend(zT_66, zT_67);
    zT_70 = self;
    zT_73 = zT_33EF6BFB_TypeKind_fn_type;
    zT_72.kind = zT_73;
    zT_74 = 2;
    zT_72.state = zT_74;
    zT_75 = 0;
    zT_72.flags = zT_75;
    zT_76 = 0;
    zT_72.is_signed = zT_76;
    zT_77 = 0;
    zT_72.width_bits = zT_77;
    zT_78 = 4;
    zT_72.size = zT_78;
    zT_79 = 4;
    zT_72.alignment = zT_79;
    zT_72.name_id = name_id;
    zT_80 = 0;
    zT_72.c_name_id = zT_80;
    zT_81 = 0;
    zT_72.module_id = zT_81;
    zT_82 = self->fn_len;
    zT_83 = 1;
    zT_84 = zT_82 - zT_83;
    zT_85 = (unsigned int)zT_84;
    zT_72.payload_idx = zT_85;
    zT_71 = zT_72;
    zT_86 = zF_D4993F02_typeRegistryAppend(zT_70, zT_71);
    tid = zT_86;
    tid = zT_86;
    tid = zT_86;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_88[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_88[_i];
        _i++;
    }
}
    zT_90 = tid;
    zT_92 = (unsigned char*)p2sb;
    zT_93 = 20;
    zT_94 = 0;
    zT_95 = zT_92 + zT_94;
    zT_96 = zT_93 - zT_94;
    zT_97.ptr = zT_95;
    zT_97.len = zT_96;
    zT_91 = zT_97;
    zT_98 = zF_A7504564_itoa(zT_90, zT_91);
    p2sl = zT_98;
    p2sl = zT_98;
    p2sl = zT_98;
    zT_100 = 19;
    zT_101 = (unsigned int)p2sl;
    zT_102 = zT_100 - zT_101;
    p2ss = zT_102;
    p2ss = zT_102;
    p2ss = zT_102;
    zT_104 = (unsigned char*)p2sb;
    zT_106 = 19;
    zT_107 = zT_104 + p2ss;
    zT_108 = zT_106 - p2ss;
    zT_109.ptr = zT_107;
    zT_109.len = zT_108;
    zT_103 = zT_109;
    zF_48AC7B3A_markerWrite(zT_103);
    zT_111 = "\n";
    zT_113 = 1;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    p2nl2 = zT_112;
    p2nl2 = zT_112;
    p2nl2 = zT_112;
    zT_114 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_114);
    return tid;
    z_bb_4:
    zT_64 = 1;
    zT_65 = i + zT_64;
    i = zT_65;
    i = zT_65;
    goto z_bb_1;
    z_bb_5:
    zT_48 = it.name_id;
    zT_49 = zT_48 == name_id;
    zT_47 = zT_49;
    goto z_bb_7;
    z_bb_6:
    zT_47 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_47) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_51 = self->fn_items;
    zT_52 = self->types_items;
    zT_53 = zT_52[i];
    zT_54 = zT_53.payload_idx;
    zT_55 = zT_51[zT_54];
    zT_56 = zT_55.module_id;
    zT_57 = zT_56 == module_id;
    zT_50 = zT_57;
    goto z_bb_10;
    z_bb_9:
    zT_50 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_50) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_59 = "H";
    zT_61 = 1;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    p2hm = zT_60;
    p2hm = zT_60;
    p2hm = zT_60;
    zT_62 = p2hm;
    zF_48AC7B3A_markerWrite(zT_62);
    zT_63 = (unsigned int)i;
    return zT_63;
    z_bb_12:
    goto z_bb_4;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_7;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_6 = 1;
    zT_7 = zT_5 | zT_6;
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8 + zT_9;
    zT_10->flags = zT_7;
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_15;
    zT_79FAE712_u64 zT_16;
    zT_79FAE712_u64 zT_17;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_79FAE712_u64 zT_22;
    zT_A4CE86B7_U64ToU32Map* zT_23;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_0B73C507_ErrorSetPayload zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    zT_A4CE86B7_U64ToU32Map* zT_52;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    key = zT_4;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    ki = zT_7;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_8 = ki < tags_count;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_11 = (unsigned int)ki;
    zT_12 = tags_start + zT_11;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    tag = zT_14;
    tag = zT_14;
    zT_15 = (zT_79FAE712_u64)tag;
    zT_16 = key ^ zT_15;
    zT_17 = 1099511628211ULL;
    zT_18 = zT_16 * zT_17;
    key = zT_18;
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_23 = &self->es_cache;
    zT_21 = zT_23;
    zT_22 = key;
    zT_24 = zF_A05A7BE1_u64ToU32MapGet(zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_20 = ki + zT_19;
    ki = zT_20;
    ki = zT_20;
    goto z_bb_1;
    z_bb_5:
    existing = zT_24.value;
    return existing;
    z_bb_6:
    zT_27 = self;
    zT_29.tags_start = tags_start;
    zT_29.tags_count = tags_count;
    zT_28 = zT_29;
    zF_B86143DD_esAppend(zT_27, zT_28);
    zT_31 = self;
    zT_34 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_33.kind = zT_34;
    zT_35 = 2;
    zT_33.state = zT_35;
    zT_36 = 0;
    zT_33.flags = zT_36;
    zT_37 = 0;
    zT_33.is_signed = zT_37;
    zT_38 = 0;
    zT_33.width_bits = zT_38;
    zT_39 = 4;
    zT_33.size = zT_39;
    zT_40 = 4;
    zT_33.alignment = zT_40;
    zT_41 = 0;
    zT_33.name_id = zT_41;
    zT_42 = 0;
    zT_33.c_name_id = zT_42;
    zT_43 = 0;
    zT_33.module_id = zT_43;
    zT_44 = self->es_len;
    zT_45 = 1;
    zT_46 = zT_44 - zT_45;
    zT_47 = (unsigned int)zT_46;
    zT_33.payload_idx = zT_47;
    zT_32 = zT_33;
    zT_48 = zF_D4993F02_typeRegistryAppend(zT_31, zT_32);
    tid = zT_48;
    tid = zT_48;
    tid = zT_48;
    zT_52 = &self->es_cache;
    zT_49 = zT_52;
    zT_50 = key;
    zT_51 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_49, zT_50, zT_51);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    zT_4 = (unsigned int)zT_3;
    zT_5 = es_type_id >= zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 4294967295u;
    return zT_6;
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_11 = ty.kind;
    zT_12 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_13 = zT_11 != zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = 4294967295u;
    return zT_14;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 >= zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = 4294967295u;
    return zT_19;
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    es_payload = zT_24;
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    tags_start = zT_27;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    tags_count = zT_30;
    tags_count = zT_30;
    zT_31 = tags_start + tags_count;
    zT_32 = reg->xn_len;
    zT_33 = zT_31 > zT_32;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = 4294967295u;
    return zT_34;
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    i = zT_37;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    zT_38 = i < tags_count;
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    zT_42 = zT_41 == name_id;
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_46 = 4294967295u;
    return zT_46;
    z_bb_12:
    zT_44 = 1;
    zT_45 = i + zT_44;
    i = zT_45;
    i = zT_45;
    goto z_bb_9;
    z_bb_13:
    zT_43 = (unsigned int)i;
    return zT_43;
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type zT_38;
    unsigned int zT_39 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    it = zT_9;
    it = zT_9;
    zT_10 = it.kind;
    zT_11 = zT_33EF6BFB_TypeKind_module_type;
    zT_12 = zT_10 == zT_11;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = zT_33EF6BFB_TypeKind_module_type;
    zT_20.kind = zT_21;
    zT_22 = 0;
    zT_20.state = zT_22;
    zT_23 = 0;
    zT_20.flags = zT_23;
    zT_24 = 0;
    zT_20.is_signed = zT_24;
    zT_25 = 0;
    zT_20.width_bits = zT_25;
    zT_26 = 0;
    zT_20.size = zT_26;
    zT_27 = 0;
    zT_20.alignment = zT_27;
    zT_28 = 0;
    zT_20.name_id = zT_28;
    zT_29 = 0;
    zT_20.c_name_id = zT_29;
    zT_20.module_id = module_id;
    zT_30 = 0;
    zT_20.payload_idx = zT_30;
    t = zT_20;
    t = zT_20;
    t = zT_20;
    zT_32 = "MC";
    zT_34 = 2;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    mc = zT_33;
    mc = zT_33;
    mc = zT_33;
    zT_35 = mc;
    zF_48AC7B3A_markerWrite(zT_35);
    zT_37 = self;
    zT_38 = t;
    zT_39 = zF_D4993F02_typeRegistryAppend(zT_37, zT_38);
    mcid = zT_39;
    mcid = zT_39;
    mcid = zT_39;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_15 = zT_14 == module_id;
    zT_13 = zT_15;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_16 = (unsigned int)i;
    return zT_16;
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_33EF6BFB_TypeKind zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_33EF6BFB_TypeKind zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_33EF6BFB_TypeKind zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_33EF6BFB_TypeKind zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_33EF6BFB_TypeKind zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_33EF6BFB_TypeKind zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_33EF6BFB_TypeKind zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_33EF6BFB_TypeKind zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_33EF6BFB_TypeKind zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_33EF6BFB_TypeKind zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_33EF6BFB_TypeKind zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_33EF6BFB_TypeKind zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_33EF6BFB_TypeKind zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_33EF6BFB_TypeKind zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_33EF6BFB_TypeKind zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_33EF6BFB_TypeKind zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_33EF6BFB_TypeKind zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_33EF6BFB_TypeKind zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_338B7C76_TypeRegistry* zT_169;
    zT_33EF6BFB_TypeKind zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    zT_33EF6BFB_TypeKind zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned int zT_208;
    char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned int zT_248;
    char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    unsigned int zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned int zT_256;
    char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288;
    char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    unsigned int zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_304;
    char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    unsigned int zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned int zT_312;
    char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320;
    char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    zT_5 = zT_33EF6BFB_TypeKind_none_sentinel;
    zT_2 = zT_5;
    zT_6 = 0;
    zT_3 = zT_6;
    zT_7 = 0;
    zT_4 = zT_7;
    (void)zF_4F84B621_registerPrimitive(zT_1, zT_2, zT_3, zT_4);
    zT_9 = self;
    zT_13 = zT_33EF6BFB_TypeKind_void_type;
    zT_10 = zT_13;
    zT_14 = 0;
    zT_11 = zT_14;
    zT_15 = 0;
    zT_12 = zT_15;
    (void)zF_4F84B621_registerPrimitive(zT_9, zT_10, zT_11, zT_12);
    zT_17 = self;
    zT_21 = zT_33EF6BFB_TypeKind_bool_type;
    zT_18 = zT_21;
    zT_22 = 4;
    zT_19 = zT_22;
    zT_23 = 4;
    zT_20 = zT_23;
    (void)zF_4F84B621_registerPrimitive(zT_17, zT_18, zT_19, zT_20);
    zT_25 = self;
    zT_29 = zT_33EF6BFB_TypeKind_noreturn_type;
    zT_26 = zT_29;
    zT_30 = 0;
    zT_27 = zT_30;
    zT_31 = 0;
    zT_28 = zT_31;
    (void)zF_4F84B621_registerPrimitive(zT_25, zT_26, zT_27, zT_28);
    zT_33 = self;
    zT_37 = zT_33EF6BFB_TypeKind_i8_type;
    zT_34 = zT_37;
    zT_38 = 1;
    zT_35 = zT_38;
    zT_39 = 1;
    zT_36 = zT_39;
    (void)zF_4F84B621_registerPrimitive(zT_33, zT_34, zT_35, zT_36);
    zT_41 = self;
    zT_45 = zT_33EF6BFB_TypeKind_i16_type;
    zT_42 = zT_45;
    zT_46 = 2;
    zT_43 = zT_46;
    zT_47 = 2;
    zT_44 = zT_47;
    (void)zF_4F84B621_registerPrimitive(zT_41, zT_42, zT_43, zT_44);
    zT_49 = self;
    zT_53 = zT_33EF6BFB_TypeKind_i32_type;
    zT_50 = zT_53;
    zT_54 = 4;
    zT_51 = zT_54;
    zT_55 = 4;
    zT_52 = zT_55;
    (void)zF_4F84B621_registerPrimitive(zT_49, zT_50, zT_51, zT_52);
    zT_57 = self;
    zT_61 = zT_33EF6BFB_TypeKind_i64_type;
    zT_58 = zT_61;
    zT_62 = 8;
    zT_59 = zT_62;
    zT_63 = 8;
    zT_60 = zT_63;
    (void)zF_4F84B621_registerPrimitive(zT_57, zT_58, zT_59, zT_60);
    zT_65 = self;
    zT_69 = zT_33EF6BFB_TypeKind_u8_type;
    zT_66 = zT_69;
    zT_70 = 1;
    zT_67 = zT_70;
    zT_71 = 1;
    zT_68 = zT_71;
    (void)zF_4F84B621_registerPrimitive(zT_65, zT_66, zT_67, zT_68);
    zT_73 = self;
    zT_77 = zT_33EF6BFB_TypeKind_u16_type;
    zT_74 = zT_77;
    zT_78 = 2;
    zT_75 = zT_78;
    zT_79 = 2;
    zT_76 = zT_79;
    (void)zF_4F84B621_registerPrimitive(zT_73, zT_74, zT_75, zT_76);
    zT_81 = self;
    zT_85 = zT_33EF6BFB_TypeKind_u32_type;
    zT_82 = zT_85;
    zT_86 = 4;
    zT_83 = zT_86;
    zT_87 = 4;
    zT_84 = zT_87;
    (void)zF_4F84B621_registerPrimitive(zT_81, zT_82, zT_83, zT_84);
    zT_89 = self;
    zT_93 = zT_33EF6BFB_TypeKind_u64_type;
    zT_90 = zT_93;
    zT_94 = 8;
    zT_91 = zT_94;
    zT_95 = 8;
    zT_92 = zT_95;
    (void)zF_4F84B621_registerPrimitive(zT_89, zT_90, zT_91, zT_92);
    zT_97 = self;
    zT_101 = zT_33EF6BFB_TypeKind_isize_type;
    zT_98 = zT_101;
    zT_102 = 4;
    zT_99 = zT_102;
    zT_103 = 4;
    zT_100 = zT_103;
    (void)zF_4F84B621_registerPrimitive(zT_97, zT_98, zT_99, zT_100);
    zT_105 = self;
    zT_109 = zT_33EF6BFB_TypeKind_usize_type;
    zT_106 = zT_109;
    zT_110 = 4;
    zT_107 = zT_110;
    zT_111 = 4;
    zT_108 = zT_111;
    (void)zF_4F84B621_registerPrimitive(zT_105, zT_106, zT_107, zT_108);
    zT_113 = self;
    zT_117 = zT_33EF6BFB_TypeKind_c_char_type;
    zT_114 = zT_117;
    zT_118 = 1;
    zT_115 = zT_118;
    zT_119 = 1;
    zT_116 = zT_119;
    (void)zF_4F84B621_registerPrimitive(zT_113, zT_114, zT_115, zT_116);
    zT_121 = self;
    zT_125 = zT_33EF6BFB_TypeKind_f32_type;
    zT_122 = zT_125;
    zT_126 = 4;
    zT_123 = zT_126;
    zT_127 = 4;
    zT_124 = zT_127;
    (void)zF_4F84B621_registerPrimitive(zT_121, zT_122, zT_123, zT_124);
    zT_129 = self;
    zT_133 = zT_33EF6BFB_TypeKind_f64_type;
    zT_130 = zT_133;
    zT_134 = 8;
    zT_131 = zT_134;
    zT_135 = 8;
    zT_132 = zT_135;
    (void)zF_4F84B621_registerPrimitive(zT_129, zT_130, zT_131, zT_132);
    zT_137 = self;
    zT_141 = zT_33EF6BFB_TypeKind_null_type;
    zT_138 = zT_141;
    zT_142 = 0;
    zT_139 = zT_142;
    zT_143 = 0;
    zT_140 = zT_143;
    (void)zF_4F84B621_registerPrimitive(zT_137, zT_138, zT_139, zT_140);
    zT_145 = self;
    zT_149 = zT_33EF6BFB_TypeKind_undefined_type;
    zT_146 = zT_149;
    zT_150 = 0;
    zT_147 = zT_150;
    zT_151 = 0;
    zT_148 = zT_151;
    (void)zF_4F84B621_registerPrimitive(zT_145, zT_146, zT_147, zT_148);
    zT_153 = self;
    zT_157 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_154 = zT_157;
    zT_158 = 0;
    zT_155 = zT_158;
    zT_159 = 0;
    zT_156 = zT_159;
    (void)zF_4F84B621_registerPrimitive(zT_153, zT_154, zT_155, zT_156);
    zT_161 = self;
    zT_165 = zT_33EF6BFB_TypeKind_type_type;
    zT_162 = zT_165;
    zT_166 = 0;
    zT_163 = zT_166;
    zT_167 = 0;
    zT_164 = zT_167;
    (void)zF_4F84B621_registerPrimitive(zT_161, zT_162, zT_163, zT_164);
    zT_169 = self;
    zT_173 = zT_33EF6BFB_TypeKind_va_list_type;
    zT_170 = zT_173;
    zT_174 = 4;
    zT_171 = zT_174;
    zT_175 = 4;
    zT_172 = zT_175;
    (void)zF_4F84B621_registerPrimitive(zT_169, zT_170, zT_171, zT_172);
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    pn = zT_179;
    pn = zT_179;
    zT_181 = self;
    zT_184 = 1;
    zT_182 = zT_184;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, zT_182, zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    pn_bool = zT_187;
    pn_bool = zT_187;
    zT_189 = self;
    zT_192 = 2;
    zT_190 = zT_192;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, zT_190, zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    pn_i8 = zT_195;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_200 = 4;
    zT_198 = zT_200;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, zT_198, zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    pn_i16 = zT_203;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_208 = 5;
    zT_206 = zT_208;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, zT_206, zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    pn_i32 = zT_211;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_216 = 6;
    zT_214 = zT_216;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, zT_214, zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    pn_i64 = zT_219;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_224 = 7;
    zT_222 = zT_224;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, zT_222, zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    pn_u8 = zT_227;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_232 = 8;
    zT_230 = zT_232;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, zT_230, zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    pn_u16 = zT_235;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_240 = 9;
    zT_238 = zT_240;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, zT_238, zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    pn_u32 = zT_243;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_248 = 10;
    zT_246 = zT_248;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, zT_246, zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    pn_u64 = zT_251;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_256 = 11;
    zT_254 = zT_256;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, zT_254, zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    pn_isize = zT_259;
    pn_isize = zT_259;
    zT_261 = self;
    zT_264 = 12;
    zT_262 = zT_264;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, zT_262, zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    pn_usize = zT_267;
    pn_usize = zT_267;
    zT_269 = self;
    zT_272 = 13;
    zT_270 = zT_272;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, zT_270, zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    pn_c_char = zT_275;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_280 = 14;
    zT_278 = zT_280;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, zT_278, zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    pn_f32 = zT_283;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_288 = 15;
    zT_286 = zT_288;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, zT_286, zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    pn_f64 = zT_291;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_296 = 16;
    zT_294 = zT_296;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, zT_294, zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    pn_null = zT_299;
    pn_null = zT_299;
    zT_301 = self;
    zT_304 = 17;
    zT_302 = zT_304;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, zT_302, zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    pn_undefined = zT_307;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_312 = 18;
    zT_310 = zT_312;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, zT_310, zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    pn_type = zT_315;
    pn_type = zT_315;
    zT_317 = self;
    zT_320 = 20;
    zT_318 = zT_320;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, zT_318, zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    pn_va_list = zT_323;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_328 = 21;
    zT_326 = zT_328;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, zT_326, zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D3EB6303_StringInterner* zT_6;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_79FAE712_u64 zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_17;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_6 = self->interner;
    zT_4 = zT_6;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    nid = zT_7;
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty = zT_11;
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_17 = (zT_79FAE712_u64)nid;
    zT_15 = zT_17;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, zT_15, zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, int* is_unsigned) {
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    int zT_10;
    unsigned char zT_11;
    unsigned char zT_13;
    int zT_14;
    unsigned char zT_16;
    int zT_17;
    int zT_18;
    int zT_19;
    int zT_20;
    unsigned int zT_21;
    int zT_22;
    int zT_23;
    unsigned int zT_25;
    unsigned int zT_27;
    int zT_28;
    unsigned char* zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    int zT_33;
    int zT_34;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned char zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    int zT_51;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    int zT_57;
    int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int nlen;
    unsigned char prefix;
    int is_u;
    int is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    nlen = zT_4;
    nlen = zT_4;
    zT_5 = 2;
    zT_6 = nlen < zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = 0;
    return zT_7;
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = zT_9[zT_10];
    prefix = zT_11;
    prefix = zT_11;
    prefix = zT_11;
    zT_13 = 117;
    zT_14 = prefix == zT_13;
    is_u = zT_14;
    is_u = zT_14;
    is_u = zT_14;
    zT_16 = 105;
    zT_17 = prefix == zT_16;
    is_i = zT_17;
    is_i = zT_17;
    is_i = zT_17;
    zT_18 = !is_u;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = !is_i;
    zT_19 = zT_20;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_21 = 0;
    return zT_21;
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_22 = 1;
    *is_unsigned = zT_22;
    goto z_bb_9;
    z_bb_9:
    zT_25 = 0;
    w = zT_25;
    w = zT_25;
    w = zT_25;
    zT_27 = 1;
    i = zT_27;
    i = zT_27;
    i = zT_27;
    goto z_bb_11;
    z_bb_10:
    zT_23 = 0;
    *is_unsigned = zT_23;
    goto z_bb_9;
    z_bb_11:
    zT_28 = i < nlen;
    if (zT_28) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = name.ptr;
    zT_31 = zT_30[i];
    c = zT_31;
    c = zT_31;
    c = zT_31;
    zT_32 = 48;
    zT_33 = c < zT_32;
    if (zT_33) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_48 = 1;
    zT_49 = i + zT_48;
    i = zT_49;
    i = zT_49;
    goto z_bb_11;
    z_bb_15:
    zT_35 = 57;
    zT_36 = c > zT_35;
    zT_34 = zT_36;
    goto z_bb_17;
    z_bb_16:
    zT_34 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_34) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_37 = 0;
    return zT_37;
    z_bb_19:
    zT_39 = 48;
    zT_40 = c - zT_39;
    zT_41 = (unsigned int)zT_40;
    d = zT_41;
    d = zT_41;
    d = zT_41;
    zT_42 = 10;
    zT_43 = w * zT_42;
    zT_44 = zT_43 + d;
    w = zT_44;
    w = zT_44;
    zT_45 = 64;
    zT_46 = w > zT_45;
    if (zT_46) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_47 = 0;
    return zT_47;
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    zT_50 = 1;
    zT_51 = w < zT_50;
    if (zT_51) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    zT_56 = 1;
    zT_57 = w < zT_56;
    if (zT_57) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_53 = 64;
    zT_54 = w > zT_53;
    zT_52 = zT_54;
    goto z_bb_27;
    z_bb_26:
    zT_52 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_52) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_55 = 0;
    return zT_55;
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_59 = 63;
    zT_60 = w > zT_59;
    zT_58 = zT_60;
    goto z_bb_32;
    z_bb_31:
    zT_58 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_58) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_61 = 0;
    return zT_61;
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int* zT_6;
    int* zT_7;
    unsigned int zT_8 = 0;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_79FAE712_u64 zT_20;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char zT_46;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53 = 0;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    arb_u = zT_3;
    arb_u = zT_3;
    zT_5 = name;
    zT_7 = &arb_u;
    zT_6 = zT_7;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    arb_w = zT_8;
    arb_w = zT_8;
    zT_9 = 0;
    zT_10 = arb_w == zT_9;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = 18;
    return zT_11;
    z_bb_2:
    zT_15 = self->interner;
    zT_13 = zT_15;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    nid = zT_16;
    nid = zT_16;
    zT_18 = self;
    zT_20 = (zT_79FAE712_u64)nid;
    zT_19 = zT_20;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, zT_19);
    ck_existing = zT_21;
    ck_existing = zT_21;
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_25 = zT_26;
    goto z_bb_7;
    z_bb_6:
    zT_27 = zT_33EF6BFB_TypeKind_arb_int_type;
    zT_25 = zT_27;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    kind = zT_25;
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    carrier = zT_29;
    carrier = zT_29;
    zT_30 = 8;
    zT_31 = arb_w > zT_30;
    if (zT_31) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    zT_33 = 16;
    zT_34 = arb_w > zT_33;
    if (zT_34) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    zT_36 = 32;
    zT_37 = arb_w > zT_36;
    if (zT_37) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    if (arb_u) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_46 = 0;
    zT_45 = zT_46;
    goto z_bb_16;
    z_bb_15:
    zT_47 = 1;
    zT_45 = zT_47;
    goto z_bb_16;
    z_bb_16:
    zT_42.is_signed = zT_45;
    zT_48 = __bootstrap_u8_from_u32(arb_w);
    zT_42.width_bits = zT_48;
    zT_42.size = carrier;
    zT_42.alignment = carrier;
    zT_49 = 0;
    zT_42.name_id = zT_49;
    zT_50 = 0;
    zT_42.c_name_id = zT_50;
    zT_51 = 0;
    zT_42.module_id = zT_51;
    zT_52 = 0;
    zT_42.payload_idx = zT_52;
    zT_41 = zT_42;
    zT_53 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_53;
    tid = zT_53;
    tid = zT_53;
    zT_54 = self;
    zT_55 = tid;
    zT_56 = name;
    zF_BA76727A_registerPrimitiveNa(zT_54, zT_55, zT_56);
    return tid;
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    unsigned char zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned char zT_20 = 0;
    zT_D155D06D_Type ty;
    zT_2 = (unsigned int)tid;
    zT_3 = self->types_len;
    zT_4 = zT_2 >= zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    ty = zT_9;
    ty = zT_9;
    zT_10 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_12 = zT_10 == zT_11;
    if (zT_12) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = ty.kind;
    zT_15 = zT_33EF6BFB_TypeKind_arb_int_type;
    zT_16 = zT_14 == zT_15;
    zT_13 = zT_16;
    goto z_bb_5;
    z_bb_4:
    zT_13 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_13) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = ty.width_bits;
    return zT_17;
    z_bb_7:
    zT_19 = ty.kind;
    zT_18 = zT_19;
    zT_20 = zF_534230F8_typeWidthBitsForKin(zT_18);
    return zT_20;
}

/* typeRegistryIntIsSigned */
int zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_20;
    int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    int zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    int zT_32;
    int zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_36;
    int zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_40;
    int zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    int zT_44;
    int zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_48;
    int zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    int zT_52;
    int zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    int zT_56;
    int zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    int zT_60;
    int zT_61;
    int zT_62;
    zT_D155D06D_Type ty;
    zT_2 = (unsigned int)tid;
    zT_3 = self->types_len;
    zT_4 = zT_2 >= zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    ty = zT_9;
    ty = zT_9;
    zT_10 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_arb_int_type;
    zT_12 = zT_10 == zT_11;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 1;
    return zT_13;
    z_bb_4:
    zT_14 = ty.kind;
    zT_15 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_16 = zT_14 == zT_15;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 0;
    return zT_17;
    z_bb_6:
    zT_18 = ty.kind;
    zT_19 = zT_33EF6BFB_TypeKind_u8_type;
    zT_20 = zT_18 == zT_19;
    if (zT_20) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_22 = ty.kind;
    zT_23 = zT_33EF6BFB_TypeKind_u16_type;
    zT_24 = zT_22 == zT_23;
    zT_21 = zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_21 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_21) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_26 = ty.kind;
    zT_27 = zT_33EF6BFB_TypeKind_u32_type;
    zT_28 = zT_26 == zT_27;
    zT_25 = zT_28;
    goto z_bb_12;
    z_bb_11:
    zT_25 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_25) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_30 = ty.kind;
    zT_31 = zT_33EF6BFB_TypeKind_u64_type;
    zT_32 = zT_30 == zT_31;
    zT_29 = zT_32;
    goto z_bb_15;
    z_bb_14:
    zT_29 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_29) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_34 = ty.kind;
    zT_35 = zT_33EF6BFB_TypeKind_usize_type;
    zT_36 = zT_34 == zT_35;
    zT_33 = zT_36;
    goto z_bb_18;
    z_bb_17:
    zT_33 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_33) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_37 = 0;
    return zT_37;
    z_bb_20:
    zT_38 = ty.kind;
    zT_39 = zT_33EF6BFB_TypeKind_i8_type;
    zT_40 = zT_38 == zT_39;
    if (zT_40) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_42 = ty.kind;
    zT_43 = zT_33EF6BFB_TypeKind_i16_type;
    zT_44 = zT_42 == zT_43;
    zT_41 = zT_44;
    goto z_bb_23;
    z_bb_22:
    zT_41 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_41) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_46 = ty.kind;
    zT_47 = zT_33EF6BFB_TypeKind_i32_type;
    zT_48 = zT_46 == zT_47;
    zT_45 = zT_48;
    goto z_bb_26;
    z_bb_25:
    zT_45 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_45) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_50 = ty.kind;
    zT_51 = zT_33EF6BFB_TypeKind_i64_type;
    zT_52 = zT_50 == zT_51;
    zT_49 = zT_52;
    goto z_bb_29;
    z_bb_28:
    zT_49 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_49) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_54 = ty.kind;
    zT_55 = zT_33EF6BFB_TypeKind_isize_type;
    zT_56 = zT_54 == zT_55;
    zT_53 = zT_56;
    goto z_bb_32;
    z_bb_31:
    zT_53 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_53) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_58 = ty.kind;
    zT_59 = zT_33EF6BFB_TypeKind_c_char_type;
    zT_60 = zT_58 == zT_59;
    zT_57 = zT_60;
    goto z_bb_35;
    z_bb_34:
    zT_57 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_57) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_61 = 1;
    return zT_61;
    z_bb_37:
    zT_62 = 0;
    return zT_62;
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27 = 0;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    zT_4028D896_Arr_unsigned_char_2 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_53;
    unsigned int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_4028D896_Arr_unsigned_char_2 zT_60;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_81;
    unsigned int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_4028D896_Arr_unsigned_char_2 zT_88;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_93;
    unsigned int zT_94;
    int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99 = 0;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_110;
    unsigned int zT_112;
    unsigned char* zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_4028D896_Arr_unsigned_char_2 zT_117;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char* zT_121;
    unsigned int zT_122;
    int zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned char* zT_138;
    unsigned int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_5 = (zT_79FAE712_u64)module_id;
    zT_6 = 4294967296ULL;
    zT_7 = zT_5 * zT_6;
    zT_8 = (zT_79FAE712_u64)name_id;
    zT_9 = zT_7 + zT_8;
    key = zT_9;
    key = zT_9;
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18.is_signed = zT_21;
    zT_22 = 0;
    zT_18.width_bits = zT_22;
    zT_23 = 0;
    zT_18.size = zT_23;
    zT_24 = 0;
    zT_18.alignment = zT_24;
    zT_18.name_id = name_id;
    zT_25 = 0;
    zT_18.c_name_id = zT_25;
    zT_18.module_id = module_id;
    zT_26 = 0;
    zT_18.payload_idx = zT_26;
    zT_17 = zT_18;
    zT_27 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_27;
    tid = zT_27;
    tid = zT_27;
    zT_28 = self;
    zT_29 = key;
    zT_30 = tid;
    zF_5E95558D_nameCachePut(zT_28, zT_29, zT_30);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = module_id;
    zT_36 = (unsigned char*)rn_m;
    zT_37 = 20;
    zT_38 = 0;
    zT_39 = zT_36 + zT_38;
    zT_40 = zT_37 - zT_38;
    zT_41.ptr = zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zT_42 = zF_A7504564_itoa(zT_34, zT_35);
    rn_ml = zT_42;
    rn_ml = zT_42;
    rn_ml = zT_42;
    zT_44 = 19;
    zT_45 = (unsigned int)rn_ml;
    zT_46 = zT_44 - zT_45;
    rn_ms = zT_46;
    rn_ms = zT_46;
    rn_ms = zT_46;
    zT_48 = "RN:m";
    zT_50 = 4;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    rnm = zT_49;
    rnm = zT_49;
    rnm = zT_49;
    zT_51 = rnm;
    zF_48AC7B3A_markerWrite(zT_51);
    zT_53 = (unsigned char*)rn_m;
    zT_55 = 19;
    zT_56 = zT_53 + rn_ms;
    zT_57 = zT_55 - rn_ms;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_60[_i];
        _i++;
    }
}
    zT_62 = name_id;
    zT_64 = (unsigned char*)rn_n;
    zT_65 = 20;
    zT_66 = 0;
    zT_67 = zT_64 + zT_66;
    zT_68 = zT_65 - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zT_70 = zF_A7504564_itoa(zT_62, zT_63);
    rn_nl = zT_70;
    rn_nl = zT_70;
    rn_nl = zT_70;
    zT_72 = 19;
    zT_73 = (unsigned int)rn_nl;
    zT_74 = zT_72 - zT_73;
    rn_ns = zT_74;
    rn_ns = zT_74;
    rn_ns = zT_74;
    zT_76 = "n";
    zT_78 = 1;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    rnn = zT_77;
    rnn = zT_77;
    rnn = zT_77;
    zT_79 = rnn;
    zF_48AC7B3A_markerWrite(zT_79);
    zT_81 = (unsigned char*)rn_n;
    zT_83 = 19;
    zT_84 = zT_81 + rn_ns;
    zT_85 = zT_83 - rn_ns;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zF_48AC7B3A_markerWrite(zT_80);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_88[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_88[_i];
        _i++;
    }
}
    zT_92 = (unsigned int)kind;
    zT_90 = zT_92;
    zT_93 = (unsigned char*)rn_k;
    zT_94 = 20;
    zT_95 = 0;
    zT_96 = zT_93 + zT_95;
    zT_97 = zT_94 - zT_95;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_91 = zT_98;
    zT_99 = zF_A7504564_itoa(zT_90, zT_91);
    rn_kl = zT_99;
    rn_kl = zT_99;
    rn_kl = zT_99;
    zT_101 = 19;
    zT_102 = (unsigned int)rn_kl;
    zT_103 = zT_101 - zT_102;
    rn_ks = zT_103;
    rn_ks = zT_103;
    rn_ks = zT_103;
    zT_105 = "k";
    zT_107 = 1;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rnk = zT_106;
    rnk = zT_106;
    rnk = zT_106;
    zT_108 = rnk;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_110 = (unsigned char*)rn_k;
    zT_112 = 19;
    zT_113 = zT_110 + rn_ks;
    zT_114 = zT_112 - rn_ks;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_109 = zT_115;
    zF_48AC7B3A_markerWrite(zT_109);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_117[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_117[_i];
        _i++;
    }
}
    zT_119 = tid;
    zT_121 = (unsigned char*)rn_t;
    zT_122 = 20;
    zT_123 = 0;
    zT_124 = zT_121 + zT_123;
    zT_125 = zT_122 - zT_123;
    zT_126.ptr = zT_124;
    zT_126.len = zT_125;
    zT_120 = zT_126;
    zT_127 = zF_A7504564_itoa(zT_119, zT_120);
    rn_tl = zT_127;
    rn_tl = zT_127;
    rn_tl = zT_127;
    zT_129 = 19;
    zT_130 = (unsigned int)rn_tl;
    zT_131 = zT_129 - zT_130;
    rn_ts = zT_131;
    rn_ts = zT_131;
    rn_ts = zT_131;
    zT_133 = "t";
    zT_135 = 1;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    rnt = zT_134;
    rnt = zT_134;
    rnt = zT_134;
    zT_136 = rnt;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_138 = (unsigned char*)rn_t;
    zT_140 = 19;
    zT_141 = zT_138 + rn_ts;
    zT_142 = zT_140 - rn_ts;
    zT_143.ptr = zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zF_48AC7B3A_markerWrite(zT_137);
    zT_145 = "\n";
    zT_147 = 1;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    rnnl = zT_146;
    rnnl = zT_146;
    rnnl = zT_146;
    zT_148 = rnnl;
    zF_48AC7B3A_markerWrite(zT_148);
    return tid;
}

/* isValueDependency */
int zF_2FA4221F_isValueDependency(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    int zT_2;
    int zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    int zT_5;
    int zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    int zT_8;
    int zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_11;
    int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    int zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_20;
    int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_23;
    int zT_24;
    int zT_25;
    zT_1 = zT_33EF6BFB_TypeKind_struct_type;
    zT_2 = kind == zT_1;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = 1;
    return zT_3;
    z_bb_2:
    zT_4 = zT_33EF6BFB_TypeKind_union_type;
    zT_5 = kind == zT_4;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_6 = 1;
    return zT_6;
    z_bb_4:
    zT_7 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_8 = kind == zT_7;
    if (zT_8) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_9 = 1;
    return zT_9;
    z_bb_6:
    zT_10 = zT_33EF6BFB_TypeKind_array_type;
    zT_11 = kind == zT_10;
    if (zT_11) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_12 = 1;
    return zT_12;
    z_bb_8:
    zT_13 = zT_33EF6BFB_TypeKind_optional_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = 1;
    return zT_15;
    z_bb_10:
    zT_16 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_17 = kind == zT_16;
    if (zT_17) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_18 = 1;
    return zT_18;
    z_bb_12:
    zT_19 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_20 = kind == zT_19;
    if (zT_20) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_21 = 1;
    return zT_21;
    z_bb_14:
    zT_22 = zT_33EF6BFB_TypeKind_unresolved_name;
    zT_23 = kind == zT_22;
    if (zT_23) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_24 = 1;
    return zT_24;
    z_bb_16:
    zT_25 = 0;
    return zT_25;
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
int zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    int zT_25;
    int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    int zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    int zT_31;
    int zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    int zT_37;
    int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_40;
    int zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    int zT_43;
    int zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    int zT_46;
    int zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    int zT_49;
    int zT_50;
    int zT_51;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_i8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_i16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_i32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_i64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_u8_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_u16_type;
    zT_22 = kind == zT_21;
    if (zT_22) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 1;
    return zT_23;
    z_bb_12:
    zT_24 = zT_33EF6BFB_TypeKind_u32_type;
    zT_25 = kind == zT_24;
    if (zT_25) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_26 = 1;
    return zT_26;
    z_bb_14:
    zT_27 = zT_33EF6BFB_TypeKind_u64_type;
    zT_28 = kind == zT_27;
    if (zT_28) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_29 = 1;
    return zT_29;
    z_bb_16:
    zT_30 = zT_33EF6BFB_TypeKind_isize_type;
    zT_31 = kind == zT_30;
    if (zT_31) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_32 = 1;
    return zT_32;
    z_bb_18:
    zT_33 = zT_33EF6BFB_TypeKind_usize_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_35 = 1;
    return zT_35;
    z_bb_20:
    zT_36 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_37 = kind == zT_36;
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_38 = 1;
    return zT_38;
    z_bb_22:
    zT_39 = zT_33EF6BFB_TypeKind_arb_int_type;
    zT_40 = kind == zT_39;
    if (zT_40) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_41 = 1;
    return zT_41;
    z_bb_24:
    zT_42 = zT_33EF6BFB_TypeKind_f32_type;
    zT_43 = kind == zT_42;
    if (zT_43) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_44 = 1;
    return zT_44;
    z_bb_26:
    zT_45 = zT_33EF6BFB_TypeKind_f64_type;
    zT_46 = kind == zT_45;
    if (zT_46) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_47 = 1;
    return zT_47;
    z_bb_28:
    zT_48 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_49 = kind == zT_48;
    if (zT_49) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_50 = 1;
    return zT_50;
    z_bb_30:
    zT_51 = 0;
    return zT_51;
}

/* typeRegistryIsInteger */
int zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    int zT_25;
    int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    int zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    int zT_31;
    int zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    int zT_37;
    int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_40;
    int zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    int zT_43;
    int zT_44;
    int zT_45;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_i8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_i16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_i32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_i64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_u8_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_u16_type;
    zT_22 = kind == zT_21;
    if (zT_22) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 1;
    return zT_23;
    z_bb_12:
    zT_24 = zT_33EF6BFB_TypeKind_u32_type;
    zT_25 = kind == zT_24;
    if (zT_25) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_26 = 1;
    return zT_26;
    z_bb_14:
    zT_27 = zT_33EF6BFB_TypeKind_u64_type;
    zT_28 = kind == zT_27;
    if (zT_28) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_29 = 1;
    return zT_29;
    z_bb_16:
    zT_30 = zT_33EF6BFB_TypeKind_isize_type;
    zT_31 = kind == zT_30;
    if (zT_31) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_32 = 1;
    return zT_32;
    z_bb_18:
    zT_33 = zT_33EF6BFB_TypeKind_usize_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_35 = 1;
    return zT_35;
    z_bb_20:
    zT_36 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_37 = kind == zT_36;
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_38 = 1;
    return zT_38;
    z_bb_22:
    zT_39 = zT_33EF6BFB_TypeKind_arb_int_type;
    zT_40 = kind == zT_39;
    if (zT_40) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_41 = 1;
    return zT_41;
    z_bb_24:
    zT_42 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_43 = kind == zT_42;
    if (zT_43) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_44 = 1;
    return zT_44;
    z_bb_26:
    zT_45 = 0;
    return zT_45;
}

/* typeRegistryIsUnsigned */
int zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    int zT_24;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_u8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_u16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_u32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_u64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_usize_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_arb_uint_type;
    zT_22 = kind == zT_21;
    if (zT_22) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 1;
    return zT_23;
    z_bb_12:
    zT_24 = 0;
    return zT_24;
}

/* typeRegistryIsPointer */
int zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_9 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_10 = kind == zT_9;
    zT_8 = zT_10;
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
int zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_slice_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    ty = zT_4;
    ty = zT_4;
    zT_5 = ty.kind;
    zT_6 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_7 = zT_5 != zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_10 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_11 = zT_9 != zT_10;
    zT_8 = zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    ty = zT_4;
    ty = zT_4;
    zT_5 = ty.kind;
    zT_6 = zT_33EF6BFB_TypeKind_slice_type;
    zT_7 = zT_5 != zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    int zT_8;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_33EF6BFB_TypeKind zT_40;
    int zT_41;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_6 = ty.kind;
    zT_7 = zT_33EF6BFB_TypeKind_array_type;
    zT_8 = zT_6 == zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    zT_15 = zT_33EF6BFB_TypeKind_slice_type;
    zT_16 = zT_14 == zT_15;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    zT_23 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_24 = zT_22 == zT_23;
    if (zT_24) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_27 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_28 = zT_26 == zT_27;
    zT_25 = zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    pointee = zT_34;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    pointee_ty = zT_38;
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    zT_40 = zT_33EF6BFB_TypeKind_array_type;
    zT_41 = zT_39 == zT_40;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_47 = 18;
    return zT_47;
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
int zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_optional_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryIsErrorSet */
int zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    sp = zT_9;
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    fstart = zT_12;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    fcount = zT_15;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = fstart + fcount;
    zT_18 = zT_16 + fstart;
    zT_19 = zT_17 - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsPacked */
int zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    int zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    int zT_18;
    zT_D155D06D_Type ty;
    zT_2 = (unsigned int)tid;
    zT_3 = self->types_len;
    zT_4 = zT_2 >= zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    ty = zT_9;
    ty = zT_9;
    zT_10 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_struct_type;
    zT_12 = zT_10 != zT_11;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.flags;
    zT_15 = 16;
    zT_16 = zT_14 & zT_15;
    zT_17 = 0;
    zT_18 = zT_16 != zT_17;
    return zT_18;
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    int zT_60;
    zT_33EF6BFB_TypeKind zT_61;
    zT_33EF6BFB_TypeKind zT_62;
    int zT_63;
    int zT_64;
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    int zT_69;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_77 = 0;
    unsigned int zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_E276DDD0_PackedBitField zT_80;
    zT_E276DDD0_PackedBitField zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    zT_FA398D58_PackedStructInfo zT_88;
    unsigned int zT_89;
    zT_FA398D58_PackedStructInfo zT_90;
    unsigned short zT_91;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_D155D06D_Type* zT_101;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    idx = zT_3;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    ty = zT_6;
    ty = zT_6;
    zT_7 = ty.kind;
    zT_8 = zT_33EF6BFB_TypeKind_struct_type;
    zT_9 = zT_7 != zT_8;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    zT_11 = 16;
    zT_12 = zT_10 & zT_11;
    zT_13 = 0;
    zT_14 = zT_12 == zT_13;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 >= zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_20 = (unsigned int)zT_19;
    zT_21 = self->pk_struct_len;
    zT_22 = zT_20 >= zT_21;
    if (zT_22) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    sp = zT_27;
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    fstart = zT_30;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    fcount = zT_33;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    pk_start = zT_36;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    total_bits = zT_38;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    fi = zT_41;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    zT_42 = fi < fcount;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = fstart + fi;
    zT_46 = zT_44[zT_45];
    fe = zT_46;
    fe = zT_46;
    fe = zT_46;
    zT_48 = 1;
    w = zT_48;
    w = zT_48;
    w = zT_48;
    zT_49 = fe.type_id;
    zT_50 = self->types_len;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49 < zT_51;
    if (zT_52) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_86 = self;
    zT_89 = ty.payload_idx;
    zT_87 = zT_89;
    zT_90.pk_start = pk_start;
    zT_91 = (unsigned short)fcount;
    zT_90.pk_count = zT_91;
    zT_90.total_bits = total_bits;
    zT_88 = zT_90;
    zF_41767D71_pkSetFields(zT_86, zT_87, zT_88);
    zT_93 = 7;
    zT_94 = total_bits + zT_93;
    zT_95 = 8;
    zT_96 = zT_94 / zT_95;
    sz = zT_96;
    sz = zT_96;
    sz = zT_96;
    zT_97 = 0;
    zT_98 = sz == zT_97;
    if (zT_98) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_84 = 1;
    zT_85 = fi + zT_84;
    fi = zT_85;
    fi = zT_85;
    goto z_bb_9;
    z_bb_13:
    zT_54 = self->types_items;
    zT_55 = fe.type_id;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    ft = zT_57;
    ft = zT_57;
    ft = zT_57;
    zT_58 = ft.kind;
    zT_59 = zT_33EF6BFB_TypeKind_bool_type;
    zT_60 = zT_58 != zT_59;
    if (zT_60) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_81.bit_offset = total_bits;
    zT_82 = (unsigned short)w;
    zT_81.bit_width = zT_82;
    zT_80 = zT_81;
    zF_E48D8B88_pkFieldAppend(zT_79, zT_80);
    zT_83 = total_bits + w;
    total_bits = zT_83;
    total_bits = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_61 = ft.kind;
    zT_62 = zT_33EF6BFB_TypeKind_struct_type;
    zT_63 = zT_61 == zT_62;
    if (zT_63) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_65 = ft.flags;
    zT_66 = 16;
    zT_67 = zT_65 & zT_66;
    zT_68 = 0;
    zT_69 = zT_67 != zT_68;
    zT_64 = zT_69;
    goto z_bb_19;
    z_bb_18:
    zT_64 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_70 = self;
    zT_72 = fe.type_id;
    zT_71 = zT_72;
    zT_73 = zF_CB27DBA4_typeRegistryGetPack(zT_70, zT_71);
    w = zT_73;
    w = zT_73;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_74 = self;
    zT_76 = fe.type_id;
    zT_75 = zT_76;
    zT_77 = zF_655972D5_typeRegistryIntWidt(zT_74, zT_75);
    zT_78 = (unsigned int)zT_77;
    w = zT_78;
    w = zT_78;
    goto z_bb_21;
    z_bb_23:
    zT_99 = 1;
    sz = zT_99;
    sz = zT_99;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    zT_100 = 1;
    ty.alignment = zT_100;
    zT_101 = self->types_items;
    zT_101[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
int zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    int zT_6;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    int zT_44;
    int zT_45;
    zT_E276DDD0_PackedBitField* zT_46;
    unsigned int zT_47;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_50;
    int zT_51;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_3 = (unsigned int)tid;
    zT_4 = self->types_len;
    zT_5 = zT_3 >= zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    return zT_6;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_11 = ty.kind;
    zT_12 = zT_33EF6BFB_TypeKind_struct_type;
    zT_13 = zT_11 != zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = 0;
    return zT_14;
    z_bb_4:
    zT_15 = ty.flags;
    zT_16 = 16;
    zT_17 = zT_15 & zT_16;
    zT_18 = 0;
    zT_19 = zT_17 == zT_18;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 0;
    return zT_20;
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21 >= zT_23;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    return zT_25;
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = self->pk_struct_len;
    zT_29 = zT_27 >= zT_28;
    if (zT_29) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = 0;
    return zT_30;
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    psi = zT_35;
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    pstart = zT_38;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    pcount = zT_41;
    pcount = zT_41;
    zT_42 = pstart + pcount;
    zT_43 = self->pk_len;
    zT_44 = zT_42 > zT_43;
    if (zT_44) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_45 = 0;
    return zT_45;
    z_bb_12:
    zT_46 = self->pk_items;
    zT_47 = pstart + pcount;
    zT_48 = zT_46 + pstart;
    zT_49 = zT_47 - pstart;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    *out = zT_50;
    zT_51 = 1;
    return zT_51;
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_2 = (unsigned int)tid;
    zT_3 = self->types_len;
    zT_4 = zT_2 >= zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    ty = zT_9;
    ty = zT_9;
    zT_10 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_struct_type;
    zT_12 = zT_10 != zT_11;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.flags;
    zT_15 = 16;
    zT_16 = zT_14 & zT_15;
    zT_17 = 0;
    zT_18 = zT_16 == zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = 0;
    return zT_19;
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 >= zT_22;
    if (zT_23) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = 0;
    return zT_24;
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = self->pk_struct_len;
    zT_28 = zT_26 >= zT_27;
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_29 = 0;
    return zT_29;
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    unsigned char zT_7;
    unsigned char zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_6 = ty.flags;
    zT_7 = 16;
    zT_8 = zT_6 | zT_7;
    ty.flags = zT_8;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    int zT_37;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    zT_2DF01B61_FieldEntry zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    int zT_47;
    zT_D155D06D_Type* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D155D06D_Type zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    int zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    zT_33EF6BFB_TypeKind zT_57;
    int zT_58;
    int zT_59;
    unsigned char zT_60;
    unsigned char zT_61;
    unsigned char zT_62;
    unsigned char zT_63;
    int zT_64;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_72 = 0;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_E276DDD0_PackedBitField zT_75;
    zT_E276DDD0_PackedBitField zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    int zT_79;
    int zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    zT_FA398D58_PackedStructInfo zT_84;
    unsigned int zT_85;
    zT_FA398D58_PackedStructInfo zT_86;
    unsigned short zT_87;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_D155D06D_Type* zT_97;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    idx = zT_3;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    ty = zT_6;
    ty = zT_6;
    zT_7 = ty.kind;
    zT_8 = zT_33EF6BFB_TypeKind_packed_union_type;
    zT_9 = zT_7 != zT_8;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    zT_12 = (unsigned int)zT_11;
    zT_13 = zT_10 >= zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = (unsigned int)zT_14;
    zT_16 = self->pk_un_len;
    zT_17 = zT_15 >= zT_16;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    up = zT_22;
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    fstart = zT_25;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    fcount = zT_28;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    pk_start = zT_31;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    max_bits = zT_33;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    fi = zT_36;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = fi < fcount;
    if (zT_37) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = fstart + fi;
    zT_41 = zT_39[zT_40];
    fe = zT_41;
    fe = zT_41;
    fe = zT_41;
    zT_43 = 1;
    w = zT_43;
    w = zT_43;
    w = zT_43;
    zT_44 = fe.type_id;
    zT_45 = self->types_len;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zT_44 < zT_46;
    if (zT_47) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_82 = self;
    zT_85 = ty.payload_idx;
    zT_83 = zT_85;
    zT_86.pk_start = pk_start;
    zT_87 = (unsigned short)fcount;
    zT_86.pk_count = zT_87;
    zT_86.total_bits = max_bits;
    zT_84 = zT_86;
    zF_0213D00C_pkUnSetFields(zT_82, zT_83, zT_84);
    zT_89 = 7;
    zT_90 = max_bits + zT_89;
    zT_91 = 8;
    zT_92 = zT_90 / zT_91;
    sz = zT_92;
    sz = zT_92;
    sz = zT_92;
    zT_93 = 0;
    zT_94 = sz == zT_93;
    if (zT_94) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_80 = 1;
    zT_81 = fi + zT_80;
    fi = zT_81;
    fi = zT_81;
    goto z_bb_7;
    z_bb_11:
    zT_49 = self->types_items;
    zT_50 = fe.type_id;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    ft = zT_52;
    ft = zT_52;
    ft = zT_52;
    zT_53 = ft.kind;
    zT_54 = zT_33EF6BFB_TypeKind_bool_type;
    zT_55 = zT_53 != zT_54;
    if (zT_55) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_74 = self;
    zT_77 = 0;
    zT_76.bit_offset = zT_77;
    zT_78 = (unsigned short)w;
    zT_76.bit_width = zT_78;
    zT_75 = zT_76;
    zF_E48D8B88_pkFieldAppend(zT_74, zT_75);
    zT_79 = w > max_bits;
    if (zT_79) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_56 = ft.kind;
    zT_57 = zT_33EF6BFB_TypeKind_struct_type;
    zT_58 = zT_56 == zT_57;
    if (zT_58) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_60 = ft.flags;
    zT_61 = 16;
    zT_62 = zT_60 & zT_61;
    zT_63 = 0;
    zT_64 = zT_62 != zT_63;
    zT_59 = zT_64;
    goto z_bb_17;
    z_bb_16:
    zT_59 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_59) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_65 = self;
    zT_67 = fe.type_id;
    zT_66 = zT_67;
    zT_68 = zF_CB27DBA4_typeRegistryGetPack(zT_65, zT_66);
    w = zT_68;
    w = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_69 = self;
    zT_71 = fe.type_id;
    zT_70 = zT_71;
    zT_72 = zF_655972D5_typeRegistryIntWidt(zT_69, zT_70);
    zT_73 = (unsigned int)zT_72;
    w = zT_73;
    w = zT_73;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_95 = 1;
    sz = zT_95;
    sz = zT_95;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    zT_96 = 1;
    ty.alignment = zT_96;
    zT_97 = self->types_items;
    zT_97[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
int zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    int zT_6;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    int zT_24;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    int zT_38;
    int zT_39;
    zT_E276DDD0_PackedBitField* zT_40;
    unsigned int zT_41;
    zT_E276DDD0_PackedBitField* zT_42;
    unsigned int zT_43;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_44;
    int zT_45;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_3 = (unsigned int)tid;
    zT_4 = self->types_len;
    zT_5 = zT_3 >= zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    return zT_6;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_11 = ty.kind;
    zT_12 = zT_33EF6BFB_TypeKind_packed_union_type;
    zT_13 = zT_11 != zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = 0;
    return zT_14;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 >= zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = 0;
    return zT_19;
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = self->pk_un_len;
    zT_23 = zT_21 >= zT_22;
    if (zT_23) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = 0;
    return zT_24;
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    psi = zT_29;
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    pstart = zT_32;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    pcount = zT_35;
    pcount = zT_35;
    zT_36 = pstart + pcount;
    zT_37 = self->pk_len;
    zT_38 = zT_36 > zT_37;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_39 = 0;
    return zT_39;
    z_bb_10:
    zT_40 = self->pk_items;
    zT_41 = pstart + pcount;
    zT_42 = zT_40 + pstart;
    zT_43 = zT_41 - pstart;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    *out = zT_44;
    zT_45 = 1;
    return zT_45;
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_2 = (unsigned int)tid;
    zT_3 = self->types_len;
    zT_4 = zT_2 >= zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    ty = zT_9;
    ty = zT_9;
    zT_10 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_packed_union_type;
    zT_12 = zT_10 != zT_11;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zT_14 >= zT_16;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_18 = 0;
    return zT_18;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_20 = (unsigned int)zT_19;
    zT_21 = self->pk_un_len;
    zT_22 = zT_20 >= zT_21;
    if (zT_22) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = 0;
    return zT_23;
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    up = zT_9;
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    fstart = zT_12;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    fcount = zT_15;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = fstart + fcount;
    zT_18 = zT_16 + fstart;
    zT_19 = zT_17 - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsAssignable */
int zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    int zT_3;
    int zT_4;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    int zT_15;
    int zT_16;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    int zT_19 = 0;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_23;
    int zT_24;
    unsigned int zT_25;
    int zT_26;
    int zT_27;
    zT_338B7C76_TypeRegistry* zT_28;
    unsigned int zT_29;
    int zT_30 = 0;
    int zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    int zT_34 = 0;
    int zT_35;
    unsigned int zT_36;
    int zT_37;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    int zT_40 = 0;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    int zT_43 = 0;
    int zT_44;
    int zT_45;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned char zT_48 = 0;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_51 = 0;
    int zT_52;
    int zT_53;
    unsigned int zT_54;
    int zT_55;
    int zT_56;
    unsigned int zT_57;
    int zT_58;
    int zT_59;
    zT_33EF6BFB_TypeKind zT_60;
    zT_33EF6BFB_TypeKind zT_61;
    int zT_62;
    zT_338B7C76_TypeRegistry* zT_63;
    unsigned int zT_64;
    int zT_65 = 0;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_33EF6BFB_TypeKind zT_68;
    int zT_69;
    int zT_70;
    zT_33EF6BFB_TypeKind zT_71;
    zT_33EF6BFB_TypeKind zT_72;
    int zT_73;
    int zT_74;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    int zT_77;
    int zT_78;
    zT_33EF6BFB_TypeKind zT_79;
    zT_33EF6BFB_TypeKind zT_80;
    int zT_81;
    zT_112BF819_PtrPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_112BF819_PtrPayload zT_86;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    zT_33EF6BFB_TypeKind zT_93;
    int zT_94;
    zT_0317B1D5_FnPayload* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_0317B1D5_FnPayload zT_99;
    zT_0317B1D5_FnPayload* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_0317B1D5_FnPayload zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_107;
    int zT_108;
    unsigned short zT_109;
    unsigned short zT_110;
    int zT_111;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    int zT_115;
    int zT_116;
    unsigned char zT_117;
    unsigned char zT_118;
    unsigned char zT_119;
    unsigned char zT_120;
    unsigned char zT_121;
    unsigned char zT_122;
    int zT_123;
    int zT_125;
    int zT_127;
    unsigned short zT_128;
    unsigned short zT_129;
    int zT_130;
    unsigned int* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    int zT_143;
    int zT_144;
    int zT_145;
    unsigned int zT_146;
    int zT_147;
    zT_33EF6BFB_TypeKind zT_148;
    zT_33EF6BFB_TypeKind zT_149;
    int zT_150;
    zT_0B10E8E9_OptionalPayload* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    zT_0B10E8E9_OptionalPayload zT_155;
    zT_338B7C76_TypeRegistry* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    int zT_160 = 0;
    int zT_161;
    zT_33EF6BFB_TypeKind zT_162;
    zT_33EF6BFB_TypeKind zT_163;
    int zT_164;
    int zT_165;
    zT_33EF6BFB_TypeKind zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    int zT_168;
    int zT_169;
    zT_33EF6BFB_TypeKind zT_170;
    zT_33EF6BFB_TypeKind zT_171;
    int zT_172;
    zT_42C2D6BF_EUPayload* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_42C2D6BF_EUPayload zT_177;
    zT_42C2D6BF_EUPayload* zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    zT_42C2D6BF_EUPayload zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    int zT_185;
    zT_338B7C76_TypeRegistry* zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_33EF6BFB_TypeKind zT_192;
    zT_33EF6BFB_TypeKind zT_193;
    int zT_194;
    zT_42C2D6BF_EUPayload* zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_42C2D6BF_EUPayload zT_199;
    zT_338B7C76_TypeRegistry* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    int zT_204 = 0;
    int zT_205;
    zT_33EF6BFB_TypeKind zT_206;
    zT_33EF6BFB_TypeKind zT_207;
    int zT_208;
    int zT_209;
    zT_33EF6BFB_TypeKind zT_210;
    zT_33EF6BFB_TypeKind zT_211;
    int zT_212;
    int zT_213;
    zT_33EF6BFB_TypeKind zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_216;
    int zT_217;
    zT_33EF6BFB_TypeKind zT_218;
    zT_33EF6BFB_TypeKind zT_219;
    int zT_220;
    zT_112BF819_PtrPayload* zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    zT_112BF819_PtrPayload zT_225;
    zT_112BF819_PtrPayload* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_112BF819_PtrPayload zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    int zT_233;
    int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    int zT_237;
    int zT_238;
    unsigned char zT_239;
    unsigned char zT_240;
    unsigned char zT_241;
    unsigned char zT_242;
    int zT_243;
    int zT_244;
    unsigned char zT_245;
    unsigned char zT_246;
    unsigned char zT_247;
    unsigned char zT_248;
    int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    int zT_252;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_33EF6BFB_TypeKind zT_255;
    int zT_256;
    int zT_257;
    zT_33EF6BFB_TypeKind zT_258;
    zT_33EF6BFB_TypeKind zT_259;
    int zT_260;
    unsigned char zT_261;
    unsigned char zT_262;
    unsigned char zT_263;
    unsigned char zT_264;
    int zT_265;
    int zT_266;
    unsigned char zT_267;
    unsigned char zT_268;
    unsigned char zT_269;
    unsigned char zT_270;
    int zT_271;
    zT_0BB2A741_SlicePayload* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_0BB2A741_SlicePayload zT_276;
    zT_0BB2A741_SlicePayload* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    zT_0BB2A741_SlicePayload zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    int zT_284;
    int zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    zT_33EF6BFB_TypeKind zT_287;
    int zT_288;
    int zT_289;
    zT_33EF6BFB_TypeKind zT_290;
    zT_33EF6BFB_TypeKind zT_291;
    int zT_292;
    zT_112BF819_PtrPayload* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_112BF819_PtrPayload zT_297;
    zT_0BB2A741_SlicePayload* zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    zT_0BB2A741_SlicePayload zT_302;
    zT_D155D06D_Type* zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    zT_D155D06D_Type zT_307;
    zT_33EF6BFB_TypeKind zT_308;
    zT_33EF6BFB_TypeKind zT_309;
    int zT_310;
    zT_E834303C_ArrayPayload* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_E834303C_ArrayPayload zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    int zT_318;
    int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    int zT_322;
    int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    int zT_326;
    int zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    int zT_330;
    int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    int zT_334;
    int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    int zT_338;
    int zT_339;
    zT_33EF6BFB_TypeKind zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    int zT_342;
    int zT_343;
    zT_33EF6BFB_TypeKind zT_344;
    zT_33EF6BFB_TypeKind zT_345;
    int zT_346;
    unsigned char zT_347;
    unsigned char zT_348;
    unsigned char zT_349;
    unsigned char zT_350;
    int zT_351;
    int zT_352;
    unsigned char zT_353;
    unsigned char zT_354;
    unsigned char zT_355;
    unsigned char zT_356;
    int zT_357;
    zT_112BF819_PtrPayload* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_112BF819_PtrPayload zT_362;
    zT_112BF819_PtrPayload* zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    zT_112BF819_PtrPayload zT_367;
    unsigned int zT_368;
    unsigned int zT_369;
    int zT_370;
    int zT_371;
    zT_33EF6BFB_TypeKind zT_372;
    zT_33EF6BFB_TypeKind zT_373;
    int zT_374;
    int zT_375;
    zT_33EF6BFB_TypeKind zT_376;
    zT_33EF6BFB_TypeKind zT_377;
    int zT_378;
    zT_112BF819_PtrPayload* zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    zT_112BF819_PtrPayload zT_383;
    zT_0BB2A741_SlicePayload* zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_0BB2A741_SlicePayload zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    int zT_391;
    int zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    int zT_395;
    int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    int zT_399;
    int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    int zT_403;
    int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    int zT_407;
    int zT_408;
    zT_33EF6BFB_TypeKind zT_409;
    zT_33EF6BFB_TypeKind zT_410;
    int zT_411;
    int zT_412;
    zT_33EF6BFB_TypeKind zT_413;
    zT_33EF6BFB_TypeKind zT_414;
    int zT_415;
    zT_E834303C_ArrayPayload* zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    zT_E834303C_ArrayPayload zT_420;
    zT_0BB2A741_SlicePayload* zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    zT_0BB2A741_SlicePayload zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    int zT_428;
    int zT_429;
    unsigned char zT_430;
    unsigned char zT_431;
    unsigned char zT_432;
    unsigned char zT_433;
    int zT_434;
    int zT_435;
    unsigned int zT_436;
    unsigned int zT_437;
    int zT_438;
    int zT_439;
    zT_33EF6BFB_TypeKind zT_440;
    zT_33EF6BFB_TypeKind zT_441;
    int zT_442;
    int zT_443;
    zT_33EF6BFB_TypeKind zT_444;
    zT_33EF6BFB_TypeKind zT_445;
    int zT_446;
    zT_E834303C_ArrayPayload* zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    zT_E834303C_ArrayPayload zT_451;
    zT_112BF819_PtrPayload* zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    zT_112BF819_PtrPayload zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    int zT_459;
    int zT_460;
    zT_33EF6BFB_TypeKind zT_461;
    zT_33EF6BFB_TypeKind zT_462;
    int zT_463;
    int zT_464;
    zT_33EF6BFB_TypeKind zT_465;
    zT_33EF6BFB_TypeKind zT_466;
    int zT_467;
    zT_0BB2A741_SlicePayload* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    zT_0BB2A741_SlicePayload zT_472;
    zT_112BF819_PtrPayload* zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_112BF819_PtrPayload zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    int zT_480;
    int zT_481;
    zT_33EF6BFB_TypeKind zT_482;
    zT_33EF6BFB_TypeKind zT_483;
    int zT_484;
    int zT_485;
    zT_33EF6BFB_TypeKind zT_486;
    zT_33EF6BFB_TypeKind zT_487;
    int zT_488;
    zT_0B10E8E9_OptionalPayload* zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    zT_0B10E8E9_OptionalPayload zT_493;
    zT_D155D06D_Type* zT_495;
    unsigned int zT_496;
    unsigned int zT_497;
    zT_D155D06D_Type zT_498;
    zT_33EF6BFB_TypeKind zT_499;
    zT_33EF6BFB_TypeKind zT_500;
    int zT_501;
    zT_338B7C76_TypeRegistry* zT_502;
    unsigned int zT_503;
    unsigned int zT_504;
    unsigned int zT_505;
    unsigned int zT_507;
    int zT_508;
    int zT_509;
    unsigned int zT_510;
    int zT_511;
    int zT_512;
    unsigned int zT_513;
    int zT_514;
    int zT_515;
    unsigned int zT_516;
    int zT_517;
    int zT_518;
    int zT_519;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0317B1D5_FnPayload src_f;
    zT_0317B1D5_FnPayload tgt_f;
    int ok;
    unsigned short fi;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_112BF819_PtrPayload pp;
    zT_D155D06D_Type opt_ty;
    z_bb_0:
    zT_3 = source == target;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    return zT_4;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    src = zT_8;
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    tgt = zT_12;
    tgt = zT_12;
    zT_13 = src.kind;
    zT_14 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_15 = zT_13 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self;
    zT_18 = target;
    zT_19 = zF_3087E0A5_typeRegistryIsNumer(zT_17, zT_18);
    zT_16 = zT_19;
    goto z_bb_5;
    z_bb_4:
    zT_16 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = 1;
    return zT_20;
    z_bb_7:
    zT_21 = src.kind;
    zT_22 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_23 = zT_21 == zT_22;
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = 14;
    zT_26 = target == zT_25;
    zT_24 = zT_26;
    goto z_bb_10;
    z_bb_9:
    zT_24 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_24) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_27 = 1;
    return zT_27;
    z_bb_12:
    zT_28 = self;
    zT_29 = source;
    zT_30 = zF_3290E9C4_typeRegistryIsInteg(zT_28, zT_29);
    if (zT_30) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_32 = self;
    zT_33 = target;
    zT_34 = zF_3290E9C4_typeRegistryIsInteg(zT_32, zT_33);
    zT_31 = zT_34;
    goto z_bb_15;
    z_bb_14:
    zT_31 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_31) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_36 = 19;
    zT_37 = source != zT_36;
    zT_35 = zT_37;
    goto z_bb_18;
    z_bb_17:
    zT_35 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_35) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_38 = self;
    zT_39 = source;
    zT_40 = zF_B664AC19_typeRegistryIsUnsig(zT_38, zT_39);
    zT_41 = self;
    zT_42 = target;
    zT_43 = zF_B664AC19_typeRegistryIsUnsig(zT_41, zT_42);
    zT_44 = zT_40 == zT_43;
    if (zT_44) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_54 = 15;
    zT_55 = source == zT_54;
    if (zT_55) goto z_bb_26; else goto z_bb_27;
    z_bb_21:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_655972D5_typeRegistryIntWidt(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_655972D5_typeRegistryIntWidt(zT_49, zT_50);
    zT_52 = zT_48 < zT_51;
    zT_45 = zT_52;
    goto z_bb_23;
    z_bb_22:
    zT_45 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_45) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_53 = 1;
    return zT_53;
    z_bb_25:
    goto z_bb_20;
    z_bb_26:
    zT_57 = 16;
    zT_58 = target == zT_57;
    zT_56 = zT_58;
    goto z_bb_28;
    z_bb_27:
    zT_56 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_56) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_59 = 1;
    return zT_59;
    z_bb_30:
    zT_60 = src.kind;
    zT_61 = zT_33EF6BFB_TypeKind_null_type;
    zT_62 = zT_60 == zT_61;
    if (zT_62) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_63 = self;
    zT_64 = target;
    zT_65 = zF_AD61DB1B_typeRegistryIsPoint(zT_63, zT_64);
    if (zT_65) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_75 = src.kind;
    zT_76 = zT_33EF6BFB_TypeKind_fn_type;
    zT_77 = zT_75 == zT_76;
    if (zT_77) goto z_bb_39; else goto z_bb_40;
    z_bb_33:
    zT_66 = 1;
    return zT_66;
    z_bb_34:
    zT_67 = tgt.kind;
    zT_68 = zT_33EF6BFB_TypeKind_optional_type;
    zT_69 = zT_67 == zT_68;
    if (zT_69) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_70 = 1;
    return zT_70;
    z_bb_36:
    zT_71 = tgt.kind;
    zT_72 = zT_33EF6BFB_TypeKind_fn_type;
    zT_73 = zT_71 == zT_72;
    if (zT_73) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_74 = 1;
    return zT_74;
    z_bb_38:
    goto z_bb_32;
    z_bb_39:
    zT_79 = tgt.kind;
    zT_80 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_81 = zT_79 == zT_80;
    zT_78 = zT_81;
    goto z_bb_41;
    z_bb_40:
    zT_78 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_78) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_83 = self->ptr_items;
    zT_84 = tgt.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    tpp = zT_86;
    tpp = zT_86;
    tpp = zT_86;
    zT_88 = self->types_items;
    zT_89 = tpp.base;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    bt = zT_91;
    bt = zT_91;
    bt = zT_91;
    zT_92 = bt.kind;
    zT_93 = zT_33EF6BFB_TypeKind_fn_type;
    zT_94 = zT_92 == zT_93;
    if (zT_94) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_148 = tgt.kind;
    zT_149 = zT_33EF6BFB_TypeKind_optional_type;
    zT_150 = zT_148 == zT_149;
    if (zT_150) goto z_bb_65; else goto z_bb_66;
    z_bb_44:
    zT_96 = self->fn_items;
    zT_97 = src.payload_idx;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    src_f = zT_99;
    src_f = zT_99;
    src_f = zT_99;
    zT_101 = self->fn_items;
    zT_102 = bt.payload_idx;
    zT_103 = (unsigned int)zT_102;
    zT_104 = zT_101[zT_103];
    tgt_f = zT_104;
    tgt_f = zT_104;
    tgt_f = zT_104;
    zT_105 = src_f.return_type;
    zT_106 = tgt_f.return_type;
    zT_107 = zT_105 == zT_106;
    if (zT_107) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_43;
    z_bb_46:
    zT_109 = src_f.params_count;
    zT_110 = tgt_f.params_count;
    zT_111 = zT_109 == zT_110;
    zT_108 = zT_111;
    goto z_bb_48;
    z_bb_47:
    zT_108 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_108) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_113 = src_f.is_extern;
    zT_114 = tgt_f.is_extern;
    zT_115 = zT_113 == zT_114;
    zT_112 = zT_115;
    goto z_bb_51;
    z_bb_50:
    zT_112 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_112) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_117 = src_f.flags_packed;
    zT_118 = 1;
    zT_119 = zT_117 & zT_118;
    zT_120 = tgt_f.flags_packed;
    zT_121 = 1;
    zT_122 = zT_120 & zT_121;
    zT_123 = zT_119 == zT_122;
    zT_116 = zT_123;
    goto z_bb_54;
    z_bb_53:
    zT_116 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_116) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_125 = 1;
    ok = zT_125;
    ok = zT_125;
    ok = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned short)zT_127;
    fi = zT_128;
    fi = zT_128;
    fi = zT_128;
    goto z_bb_57;
    z_bb_56:
    goto z_bb_45;
    z_bb_57:
    zT_129 = src_f.params_count;
    zT_130 = fi < zT_129;
    if (zT_130) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_131 = self->xt_items;
    zT_132 = src_f.params_start;
    zT_133 = (unsigned int)fi;
    zT_134 = zT_132 + zT_133;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zT_131[zT_135];
    zT_137 = self->xt_items;
    zT_138 = tgt_f.params_start;
    zT_139 = (unsigned int)fi;
    zT_140 = zT_138 + zT_139;
    zT_141 = (unsigned int)zT_140;
    zT_142 = zT_137[zT_141];
    zT_143 = zT_136 != zT_142;
    if (zT_143) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    if (ok) goto z_bb_63; else goto z_bb_64;
    z_bb_60:
    zT_145 = 1;
    zT_146 = fi + zT_145;
    fi = zT_146;
    fi = zT_146;
    goto z_bb_57;
    z_bb_61:
    zT_144 = 0;
    ok = zT_144;
    ok = zT_144;
    goto z_bb_59;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_147 = 1;
    return zT_147;
    z_bb_64:
    goto z_bb_56;
    z_bb_65:
    zT_152 = self->opt_items;
    zT_153 = tgt.payload_idx;
    zT_154 = (unsigned int)zT_153;
    zT_155 = zT_152[zT_154];
    opt = zT_155;
    opt = zT_155;
    opt = zT_155;
    zT_156 = self;
    zT_157 = source;
    zT_159 = opt.payload;
    zT_158 = zT_159;
    zT_160 = zF_683AEB7F_typeRegistryIsAssig(zT_156, zT_157, zT_158);
    if (zT_160) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_166 = src.kind;
    zT_167 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_168 = zT_166 == zT_167;
    if (zT_168) goto z_bb_71; else goto z_bb_72;
    z_bb_67:
    zT_161 = 1;
    return zT_161;
    z_bb_68:
    zT_162 = src.kind;
    zT_163 = zT_33EF6BFB_TypeKind_null_type;
    zT_164 = zT_162 == zT_163;
    if (zT_164) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_165 = 1;
    return zT_165;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_170 = tgt.kind;
    zT_171 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_172 = zT_170 == zT_171;
    zT_169 = zT_172;
    goto z_bb_73;
    z_bb_72:
    zT_169 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_169) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_174 = self->eu_items;
    zT_175 = src.payload_idx;
    zT_176 = (unsigned int)zT_175;
    zT_177 = zT_174[zT_176];
    eu_src = zT_177;
    eu_src = zT_177;
    eu_src = zT_177;
    zT_179 = self->eu_items;
    zT_180 = tgt.payload_idx;
    zT_181 = (unsigned int)zT_180;
    zT_182 = zT_179[zT_181];
    eu_tgt = zT_182;
    eu_tgt = zT_182;
    eu_tgt = zT_182;
    zT_183 = eu_src.error_set;
    zT_184 = eu_tgt.error_set;
    zT_185 = zT_183 == zT_184;
    if (zT_185) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_192 = tgt.kind;
    zT_193 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_194 = zT_192 == zT_193;
    if (zT_194) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    zT_186 = self;
    zT_189 = eu_src.payload;
    zT_187 = zT_189;
    zT_190 = eu_tgt.payload;
    zT_188 = zT_190;
    self = zT_186;
    source = zT_187;
    target = zT_188;
    goto z_bb_0;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_196 = self->eu_items;
    zT_197 = tgt.payload_idx;
    zT_198 = (unsigned int)zT_197;
    zT_199 = zT_196[zT_198];
    eu = zT_199;
    eu = zT_199;
    eu = zT_199;
    zT_200 = self;
    zT_201 = source;
    zT_203 = eu.payload;
    zT_202 = zT_203;
    zT_204 = zF_683AEB7F_typeRegistryIsAssig(zT_200, zT_201, zT_202);
    if (zT_204) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_206 = src.kind;
    zT_207 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_208 = zT_206 == zT_207;
    if (zT_208) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_205 = 1;
    return zT_205;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_210 = tgt.kind;
    zT_211 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_212 = zT_210 == zT_211;
    zT_209 = zT_212;
    goto z_bb_84;
    z_bb_83:
    zT_209 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_209) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_213 = 1;
    return zT_213;
    z_bb_86:
    zT_214 = src.kind;
    zT_215 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_216 = zT_214 == zT_215;
    if (zT_216) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_218 = tgt.kind;
    zT_219 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_220 = zT_218 == zT_219;
    zT_217 = zT_220;
    goto z_bb_89;
    z_bb_88:
    zT_217 = 0;
    goto z_bb_89;
    z_bb_89:
    if (zT_217) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_222 = self->ptr_items;
    zT_223 = tgt.payload_idx;
    zT_224 = (unsigned int)zT_223;
    zT_225 = zT_222[zT_224];
    tgt_pp = zT_225;
    tgt_pp = zT_225;
    tgt_pp = zT_225;
    zT_227 = self->ptr_items;
    zT_228 = src.payload_idx;
    zT_229 = (unsigned int)zT_228;
    zT_230 = zT_227[zT_229];
    src_pp = zT_230;
    src_pp = zT_230;
    src_pp = zT_230;
    zT_231 = tgt_pp.base;
    zT_232 = 1;
    zT_233 = zT_231 == zT_232;
    if (zT_233) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    zT_254 = tgt.kind;
    zT_255 = zT_33EF6BFB_TypeKind_slice_type;
    zT_256 = zT_254 == zT_255;
    if (zT_256) goto z_bb_103; else goto z_bb_104;
    z_bb_92:
    zT_234 = 1;
    return zT_234;
    z_bb_93:
    zT_235 = src_pp.base;
    zT_236 = 1;
    zT_237 = zT_235 == zT_236;
    if (zT_237) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_238 = 1;
    return zT_238;
    z_bb_95:
    zT_239 = tgt.flags;
    zT_240 = 1;
    zT_241 = zT_239 & zT_240;
    zT_242 = 0;
    zT_243 = zT_241 != zT_242;
    if (zT_243) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_245 = src.flags;
    zT_246 = 1;
    zT_247 = zT_245 & zT_246;
    zT_248 = 0;
    zT_249 = zT_247 == zT_248;
    zT_244 = zT_249;
    goto z_bb_98;
    z_bb_97:
    zT_244 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_244) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_250 = src_pp.base;
    zT_251 = tgt_pp.base;
    zT_252 = zT_250 == zT_251;
    if (zT_252) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_91;
    z_bb_101:
    zT_253 = 1;
    return zT_253;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_258 = src.kind;
    zT_259 = zT_33EF6BFB_TypeKind_slice_type;
    zT_260 = zT_258 == zT_259;
    zT_257 = zT_260;
    goto z_bb_105;
    z_bb_104:
    zT_257 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_257) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_261 = tgt.flags;
    zT_262 = 1;
    zT_263 = zT_261 & zT_262;
    zT_264 = 0;
    zT_265 = zT_263 != zT_264;
    if (zT_265) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    zT_286 = tgt.kind;
    zT_287 = zT_33EF6BFB_TypeKind_slice_type;
    zT_288 = zT_286 == zT_287;
    if (zT_288) goto z_bb_115; else goto z_bb_116;
    z_bb_108:
    zT_267 = src.flags;
    zT_268 = 1;
    zT_269 = zT_267 & zT_268;
    zT_270 = 0;
    zT_271 = zT_269 == zT_270;
    zT_266 = zT_271;
    goto z_bb_110;
    z_bb_109:
    zT_266 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_266) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_273 = self->slice_items;
    zT_274 = src.payload_idx;
    zT_275 = (unsigned int)zT_274;
    zT_276 = zT_273[zT_275];
    s_sl = zT_276;
    s_sl = zT_276;
    s_sl = zT_276;
    zT_278 = self->slice_items;
    zT_279 = tgt.payload_idx;
    zT_280 = (unsigned int)zT_279;
    zT_281 = zT_278[zT_280];
    t_sl = zT_281;
    t_sl = zT_281;
    t_sl = zT_281;
    zT_282 = s_sl.elem;
    zT_283 = t_sl.elem;
    zT_284 = zT_282 == zT_283;
    if (zT_284) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_107;
    z_bb_113:
    zT_285 = 1;
    return zT_285;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_290 = src.kind;
    zT_291 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_292 = zT_290 == zT_291;
    zT_289 = zT_292;
    goto z_bb_117;
    z_bb_116:
    zT_289 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_289) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_294 = self->ptr_items;
    zT_295 = src.payload_idx;
    zT_296 = (unsigned int)zT_295;
    zT_297 = zT_294[zT_296];
    src_pp = zT_297;
    src_pp = zT_297;
    src_pp = zT_297;
    zT_299 = self->slice_items;
    zT_300 = tgt.payload_idx;
    zT_301 = (unsigned int)zT_300;
    zT_302 = zT_299[zT_301];
    sl = zT_302;
    sl = zT_302;
    sl = zT_302;
    zT_304 = self->types_items;
    zT_305 = src_pp.base;
    zT_306 = (unsigned int)zT_305;
    zT_307 = zT_304[zT_306];
    src_pointee = zT_307;
    src_pointee = zT_307;
    src_pointee = zT_307;
    zT_308 = src_pointee.kind;
    zT_309 = zT_33EF6BFB_TypeKind_array_type;
    zT_310 = zT_308 == zT_309;
    if (zT_310) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_340 = tgt.kind;
    zT_341 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_342 = zT_340 == zT_341;
    if (zT_342) goto z_bb_136; else goto z_bb_137;
    z_bb_120:
    zT_312 = self->array_items;
    zT_313 = src_pointee.payload_idx;
    zT_314 = (unsigned int)zT_313;
    zT_315 = zT_312[zT_314];
    arr = zT_315;
    arr = zT_315;
    arr = zT_315;
    zT_316 = arr.elem;
    zT_317 = sl.elem;
    zT_318 = zT_316 == zT_317;
    if (zT_318) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_320 = src_pp.base;
    zT_321 = sl.elem;
    zT_322 = zT_320 == zT_321;
    if (zT_322) goto z_bb_124; else goto z_bb_125;
    z_bb_122:
    zT_319 = 1;
    return zT_319;
    z_bb_123:
    goto z_bb_121;
    z_bb_124:
    zT_323 = 1;
    return zT_323;
    z_bb_125:
    zT_324 = src_pp.base;
    zT_325 = 14;
    zT_326 = zT_324 == zT_325;
    if (zT_326) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_328 = sl.elem;
    zT_329 = 8;
    zT_330 = zT_328 == zT_329;
    zT_327 = zT_330;
    goto z_bb_128;
    z_bb_127:
    zT_327 = 0;
    goto z_bb_128;
    z_bb_128:
    if (zT_327) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_331 = 1;
    return zT_331;
    z_bb_130:
    zT_332 = src_pp.base;
    zT_333 = 8;
    zT_334 = zT_332 == zT_333;
    if (zT_334) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_336 = sl.elem;
    zT_337 = 14;
    zT_338 = zT_336 == zT_337;
    zT_335 = zT_338;
    goto z_bb_133;
    z_bb_132:
    zT_335 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_335) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    zT_339 = 1;
    return zT_339;
    z_bb_135:
    goto z_bb_119;
    z_bb_136:
    zT_344 = src.kind;
    zT_345 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_346 = zT_344 == zT_345;
    zT_343 = zT_346;
    goto z_bb_138;
    z_bb_137:
    zT_343 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_343) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_347 = tgt.flags;
    zT_348 = 1;
    zT_349 = zT_347 & zT_348;
    zT_350 = 0;
    zT_351 = zT_349 != zT_350;
    if (zT_351) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_372 = src.kind;
    zT_373 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_374 = zT_372 == zT_373;
    if (zT_374) goto z_bb_148; else goto z_bb_149;
    z_bb_141:
    zT_353 = src.flags;
    zT_354 = 1;
    zT_355 = zT_353 & zT_354;
    zT_356 = 0;
    zT_357 = zT_355 == zT_356;
    zT_352 = zT_357;
    goto z_bb_143;
    z_bb_142:
    zT_352 = 0;
    goto z_bb_143;
    z_bb_143:
    if (zT_352) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_359 = self->ptr_items;
    zT_360 = src.payload_idx;
    zT_361 = (unsigned int)zT_360;
    zT_362 = zT_359[zT_361];
    s_pp = zT_362;
    s_pp = zT_362;
    s_pp = zT_362;
    zT_364 = self->ptr_items;
    zT_365 = tgt.payload_idx;
    zT_366 = (unsigned int)zT_365;
    zT_367 = zT_364[zT_366];
    t_pp = zT_367;
    t_pp = zT_367;
    t_pp = zT_367;
    zT_368 = s_pp.base;
    zT_369 = t_pp.base;
    zT_370 = zT_368 == zT_369;
    if (zT_370) goto z_bb_146; else goto z_bb_147;
    z_bb_145:
    goto z_bb_140;
    z_bb_146:
    zT_371 = 1;
    return zT_371;
    z_bb_147:
    goto z_bb_145;
    z_bb_148:
    zT_376 = tgt.kind;
    zT_377 = zT_33EF6BFB_TypeKind_slice_type;
    zT_378 = zT_376 == zT_377;
    zT_375 = zT_378;
    goto z_bb_150;
    z_bb_149:
    zT_375 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_375) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_380 = self->ptr_items;
    zT_381 = src.payload_idx;
    zT_382 = (unsigned int)zT_381;
    zT_383 = zT_380[zT_382];
    sp2 = zT_383;
    sp2 = zT_383;
    sp2 = zT_383;
    zT_385 = self->slice_items;
    zT_386 = tgt.payload_idx;
    zT_387 = (unsigned int)zT_386;
    zT_388 = zT_385[zT_387];
    ts2 = zT_388;
    ts2 = zT_388;
    ts2 = zT_388;
    zT_389 = sp2.base;
    zT_390 = ts2.elem;
    zT_391 = zT_389 == zT_390;
    if (zT_391) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    zT_409 = src.kind;
    zT_410 = zT_33EF6BFB_TypeKind_array_type;
    zT_411 = zT_409 == zT_410;
    if (zT_411) goto z_bb_166; else goto z_bb_167;
    z_bb_153:
    zT_392 = 1;
    return zT_392;
    z_bb_154:
    zT_393 = sp2.base;
    zT_394 = 14;
    zT_395 = zT_393 == zT_394;
    if (zT_395) goto z_bb_155; else goto z_bb_156;
    z_bb_155:
    zT_397 = ts2.elem;
    zT_398 = 8;
    zT_399 = zT_397 == zT_398;
    zT_396 = zT_399;
    goto z_bb_157;
    z_bb_156:
    zT_396 = 0;
    goto z_bb_157;
    z_bb_157:
    if (zT_396) goto z_bb_159; else goto z_bb_158;
    z_bb_158:
    zT_401 = sp2.base;
    zT_402 = 8;
    zT_403 = zT_401 == zT_402;
    if (zT_403) goto z_bb_161; else goto z_bb_162;
    z_bb_159:
    zT_400 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_400) goto z_bb_164; else goto z_bb_165;
    z_bb_161:
    zT_405 = ts2.elem;
    zT_406 = 14;
    zT_407 = zT_405 == zT_406;
    zT_404 = zT_407;
    goto z_bb_163;
    z_bb_162:
    zT_404 = 0;
    goto z_bb_163;
    z_bb_163:
    zT_400 = zT_404;
    goto z_bb_160;
    z_bb_164:
    zT_408 = 1;
    return zT_408;
    z_bb_165:
    goto z_bb_152;
    z_bb_166:
    zT_413 = tgt.kind;
    zT_414 = zT_33EF6BFB_TypeKind_slice_type;
    zT_415 = zT_413 == zT_414;
    zT_412 = zT_415;
    goto z_bb_168;
    z_bb_167:
    zT_412 = 0;
    goto z_bb_168;
    z_bb_168:
    if (zT_412) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_417 = self->array_items;
    zT_418 = src.payload_idx;
    zT_419 = (unsigned int)zT_418;
    zT_420 = zT_417[zT_419];
    arr = zT_420;
    arr = zT_420;
    arr = zT_420;
    zT_422 = self->slice_items;
    zT_423 = tgt.payload_idx;
    zT_424 = (unsigned int)zT_423;
    zT_425 = zT_422[zT_424];
    sl = zT_425;
    sl = zT_425;
    sl = zT_425;
    zT_426 = arr.elem;
    zT_427 = sl.elem;
    zT_428 = zT_426 == zT_427;
    if (zT_428) goto z_bb_171; else goto z_bb_172;
    z_bb_170:
    zT_440 = src.kind;
    zT_441 = zT_33EF6BFB_TypeKind_array_type;
    zT_442 = zT_440 == zT_441;
    if (zT_442) goto z_bb_178; else goto z_bb_179;
    z_bb_171:
    zT_429 = 1;
    return zT_429;
    z_bb_172:
    zT_430 = tgt.flags;
    zT_431 = 1;
    zT_432 = zT_430 & zT_431;
    zT_433 = 0;
    zT_434 = zT_432 != zT_433;
    if (zT_434) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_436 = arr.elem;
    zT_437 = sl.elem;
    zT_438 = zT_436 == zT_437;
    zT_435 = zT_438;
    goto z_bb_175;
    z_bb_174:
    zT_435 = 0;
    goto z_bb_175;
    z_bb_175:
    if (zT_435) goto z_bb_176; else goto z_bb_177;
    z_bb_176:
    zT_439 = 1;
    return zT_439;
    z_bb_177:
    goto z_bb_170;
    z_bb_178:
    zT_444 = tgt.kind;
    zT_445 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_446 = zT_444 == zT_445;
    zT_443 = zT_446;
    goto z_bb_180;
    z_bb_179:
    zT_443 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_443) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    zT_448 = self->array_items;
    zT_449 = src.payload_idx;
    zT_450 = (unsigned int)zT_449;
    zT_451 = zT_448[zT_450];
    arr = zT_451;
    arr = zT_451;
    arr = zT_451;
    zT_453 = self->ptr_items;
    zT_454 = tgt.payload_idx;
    zT_455 = (unsigned int)zT_454;
    zT_456 = zT_453[zT_455];
    pp = zT_456;
    pp = zT_456;
    pp = zT_456;
    zT_457 = arr.elem;
    zT_458 = pp.base;
    zT_459 = zT_457 == zT_458;
    if (zT_459) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    zT_461 = src.kind;
    zT_462 = zT_33EF6BFB_TypeKind_slice_type;
    zT_463 = zT_461 == zT_462;
    if (zT_463) goto z_bb_185; else goto z_bb_186;
    z_bb_183:
    zT_460 = 1;
    return zT_460;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_465 = tgt.kind;
    zT_466 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_467 = zT_465 == zT_466;
    zT_464 = zT_467;
    goto z_bb_187;
    z_bb_186:
    zT_464 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_464) goto z_bb_188; else goto z_bb_189;
    z_bb_188:
    zT_469 = self->slice_items;
    zT_470 = src.payload_idx;
    zT_471 = (unsigned int)zT_470;
    zT_472 = zT_469[zT_471];
    sl = zT_472;
    sl = zT_472;
    sl = zT_472;
    zT_474 = self->ptr_items;
    zT_475 = tgt.payload_idx;
    zT_476 = (unsigned int)zT_475;
    zT_477 = zT_474[zT_476];
    pp = zT_477;
    pp = zT_477;
    pp = zT_477;
    zT_478 = sl.elem;
    zT_479 = pp.base;
    zT_480 = zT_478 == zT_479;
    if (zT_480) goto z_bb_190; else goto z_bb_191;
    z_bb_189:
    zT_482 = src.kind;
    zT_483 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_484 = zT_482 == zT_483;
    if (zT_484) goto z_bb_192; else goto z_bb_193;
    z_bb_190:
    zT_481 = 1;
    return zT_481;
    z_bb_191:
    goto z_bb_189;
    z_bb_192:
    zT_486 = tgt.kind;
    zT_487 = zT_33EF6BFB_TypeKind_optional_type;
    zT_488 = zT_486 == zT_487;
    zT_485 = zT_488;
    goto z_bb_194;
    z_bb_193:
    zT_485 = 0;
    goto z_bb_194;
    z_bb_194:
    if (zT_485) goto z_bb_195; else goto z_bb_196;
    z_bb_195:
    zT_490 = self->opt_items;
    zT_491 = tgt.payload_idx;
    zT_492 = (unsigned int)zT_491;
    zT_493 = zT_490[zT_492];
    opt = zT_493;
    opt = zT_493;
    opt = zT_493;
    zT_495 = self->types_items;
    zT_496 = opt.payload;
    zT_497 = (unsigned int)zT_496;
    zT_498 = zT_495[zT_497];
    opt_ty = zT_498;
    opt_ty = zT_498;
    opt_ty = zT_498;
    zT_499 = opt_ty.kind;
    zT_500 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_501 = zT_499 == zT_500;
    if (zT_501) goto z_bb_197; else goto z_bb_198;
    z_bb_196:
    zT_507 = 8;
    zT_508 = source == zT_507;
    if (zT_508) goto z_bb_199; else goto z_bb_200;
    z_bb_197:
    zT_502 = self;
    zT_503 = source;
    zT_505 = opt.payload;
    zT_504 = zT_505;
    self = zT_502;
    source = zT_503;
    target = zT_504;
    goto z_bb_0;
    z_bb_198:
    goto z_bb_196;
    z_bb_199:
    zT_510 = 14;
    zT_511 = target == zT_510;
    zT_509 = zT_511;
    goto z_bb_201;
    z_bb_200:
    zT_509 = 0;
    goto z_bb_201;
    z_bb_201:
    if (zT_509) goto z_bb_203; else goto z_bb_202;
    z_bb_202:
    zT_513 = 14;
    zT_514 = source == zT_513;
    if (zT_514) goto z_bb_205; else goto z_bb_206;
    z_bb_203:
    zT_512 = 1;
    goto z_bb_204;
    z_bb_204:
    if (zT_512) goto z_bb_208; else goto z_bb_209;
    z_bb_205:
    zT_516 = 8;
    zT_517 = target == zT_516;
    zT_515 = zT_517;
    goto z_bb_207;
    z_bb_206:
    zT_515 = 0;
    goto z_bb_207;
    z_bb_207:
    zT_512 = zT_515;
    goto z_bb_204;
    z_bb_208:
    zT_518 = 1;
    return zT_518;
    z_bb_209:
    zT_519 = 0;
    return zT_519;
}

/* canLiteralFitInType */
int zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    unsigned int zT_2;
    int zT_3;
    zT_C69B2266_i64 zT_4;
    int zT_5;
    int zT_6;
    zT_C69B2266_i64 zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_C69B2266_i64 zT_11;
    int zT_12;
    int zT_13;
    zT_C69B2266_i64 zT_14;
    int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_C69B2266_i64 zT_18;
    zT_C69B2266_i64 zT_19;
    zT_C69B2266_i64 zT_20;
    int zT_21;
    int zT_22;
    zT_C69B2266_i64 zT_23;
    int zT_24;
    unsigned int zT_25;
    int zT_26;
    int zT_27;
    unsigned int zT_28;
    int zT_29;
    zT_C69B2266_i64 zT_30;
    int zT_31;
    int zT_32;
    zT_C69B2266_i64 zT_33;
    int zT_34;
    unsigned int zT_35;
    int zT_36;
    zT_C69B2266_i64 zT_37;
    int zT_38;
    int zT_39;
    zT_C69B2266_i64 zT_40;
    int zT_41;
    unsigned int zT_42;
    int zT_43;
    zT_C69B2266_i64 zT_44;
    int zT_45;
    int zT_46;
    zT_C69B2266_i64 zT_47;
    int zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_C69B2266_i64 zT_51;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    zT_C69B2266_i64 zT_55;
    zT_C69B2266_i64 zT_56;
    zT_C69B2266_i64 zT_57;
    int zT_58;
    int zT_59;
    zT_C69B2266_i64 zT_60;
    int zT_61;
    unsigned int zT_62;
    int zT_63;
    zT_C69B2266_i64 zT_64;
    int zT_65;
    int zT_66;
    zT_C69B2266_i64 zT_67;
    int zT_68;
    unsigned int zT_69;
    int zT_70;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_74;
    int zT_75;
    zT_2 = 4;
    zT_3 = target == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = (zT_C69B2266_i64)-128;
    zT_5 = value >= zT_4;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_9 = 5;
    zT_10 = target == zT_9;
    if (zT_10) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_7 = 127;
    zT_8 = value <= zT_7;
    zT_6 = zT_8;
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    zT_11 = (zT_C69B2266_i64)-32768;
    zT_12 = value >= zT_11;
    if (zT_12) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_16 = 6;
    zT_17 = target == zT_16;
    if (zT_17) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_14 = 32767;
    zT_15 = value <= zT_14;
    zT_13 = zT_15;
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    zT_18 = (zT_C69B2266_i64)-2147483647;
    zT_19 = 1;
    zT_20 = zT_18 - zT_19;
    zT_21 = value >= zT_20;
    if (zT_21) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_25 = 7;
    zT_26 = target == zT_25;
    if (zT_26) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_23 = 2147483647;
    zT_24 = value <= zT_23;
    zT_22 = zT_24;
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    zT_27 = 1;
    return zT_27;
    z_bb_17:
    zT_28 = 8;
    zT_29 = target == zT_28;
    if (zT_29) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_30 = 0;
    zT_31 = value >= zT_30;
    if (zT_31) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_35 = 9;
    zT_36 = target == zT_35;
    if (zT_36) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_33 = 255;
    zT_34 = value <= zT_33;
    zT_32 = zT_34;
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    zT_37 = 0;
    zT_38 = value >= zT_37;
    if (zT_38) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_42 = 10;
    zT_43 = target == zT_42;
    if (zT_43) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_40 = 65535;
    zT_41 = value <= zT_40;
    zT_39 = zT_41;
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    zT_44 = 0;
    zT_45 = value >= zT_44;
    if (zT_45) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_49 = 11;
    zT_50 = target == zT_49;
    if (zT_50) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_47 = 4294967295u;
    zT_48 = value <= zT_47;
    zT_46 = zT_48;
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    zT_51 = 0;
    zT_52 = value >= zT_51;
    return zT_52;
    z_bb_34:
    zT_53 = 12;
    zT_54 = target == zT_53;
    if (zT_54) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_55 = (zT_C69B2266_i64)-2147483647;
    zT_56 = 1;
    zT_57 = zT_55 - zT_56;
    zT_58 = value >= zT_57;
    if (zT_58) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_62 = 13;
    zT_63 = target == zT_62;
    if (zT_63) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_60 = 2147483647;
    zT_61 = value <= zT_60;
    zT_59 = zT_61;
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    zT_64 = 0;
    zT_65 = value >= zT_64;
    if (zT_65) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_69 = 15;
    zT_70 = target == zT_69;
    if (zT_70) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_67 = 4294967295u;
    zT_68 = value <= zT_67;
    zT_66 = zT_68;
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_72 = 16;
    zT_73 = target == zT_72;
    zT_71 = zT_73;
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_74 = 1;
    return zT_74;
    z_bb_49:
    zT_75 = 0;
    return zT_75;
}

/* EOF */
