#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)ubuf) + zT_15;
    zT_17 = (unsigned int)(16) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa((unsigned int)((unsigned int)used), zT_11);
    ulen = zT_19;
    zT_23 = (unsigned int)(15) - (unsigned int)((unsigned int)ulen);
    ustart = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)ubuf) + ustart;
    zT_29 = (unsigned int)(15) - ustart;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)nbuf) + zT_44;
    zT_46 = (unsigned int)(16) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa((unsigned int)((unsigned int)new_bytes), zT_40);
    nlen = zT_48;
    zT_52 = (unsigned int)(15) - (unsigned int)((unsigned int)nlen);
    nstart = zT_52;
    zT_57 = (unsigned char*)((unsigned char*)nbuf) + nstart;
    zT_58 = (unsigned int)(15) - nstart;
    zT_59.ptr = zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_9154F007_EU_232 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_25;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    if ((int)(zT_6 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_15 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)(elem_size * nc), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zF_9091237C_typeDbOom((unsigned int)(zT_25 * elem_size), (unsigned int)(elem_size * nc));
    return;
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    if ((int)(i < (unsigned int)(zT_37 * elem_size))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    if ((int)(new_cap <= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_9154F007_EU_232 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_29;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    if ((int)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    if ((int)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    if ((int)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->types_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(32) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zF_9091237C_typeDbOom((unsigned int)(zT_29 * (unsigned int)(32)), (unsigned int)((unsigned int)(32) * nc));
    return;
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_44)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    zT_49 = i + (unsigned int)(1);
    i = zT_49;
    goto z_bb_10;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_33;
    char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zF_BCE30624_typeRegistryEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    self->types_len = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_25 = 0;
    zT_26 = (unsigned char*)((unsigned char*)dc_k) + zT_25;
    zT_27 = (unsigned int)(20) - zT_25;
    zT_28.ptr = zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_21), zT_20);
    dc_kl = zT_29;
    zT_33 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_kl);
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_43 = (unsigned char*)((unsigned char*)dc_k) + dc_ks;
    zT_44 = (unsigned int)(19) - dc_ks;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_49 = t.name_id;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)dc_n) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_nl);
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_72 = (unsigned char*)((unsigned char*)dc_n) + dc_ns;
    zT_73 = (unsigned int)(19) - dc_ns;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_82 = 0;
    zT_83 = (unsigned char*)((unsigned char*)dc_i) + zT_82;
    zT_84 = (unsigned int)(20) - zT_82;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    zT_90 = (unsigned int)(19) - (unsigned int)((unsigned int)dc_il);
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_100 = (unsigned char*)((unsigned char*)dc_i) + dc_is;
    zT_101 = (unsigned int)(19) - dc_is;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    if ((int)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_112BF819_PtrPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->ptr_items;
    zT_3 = &self->ptr_len;
    zT_4 = &self->ptr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    self->ptr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->array_items;
    zT_3 = &self->array_len;
    zT_4 = &self->array_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->array_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    self->array_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->slice_items;
    zT_3 = &self->slice_len;
    zT_4 = &self->slice_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    self->slice_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->opt_items;
    zT_3 = &self->opt_len;
    zT_4 = &self->opt_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    self->opt_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->eu_items;
    zT_3 = &self->eu_len;
    zT_4 = &self->eu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    self->eu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->es_items;
    zT_3 = &self->es_len;
    zT_4 = &self->es_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->es_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    self->es_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fn_items;
    zT_3 = &self->fn_len;
    zT_4 = &self->fn_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(24), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    self->fn_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_406493CE_StructPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->st_items;
    zT_3 = &self->st_len;
    zT_4 = &self->st_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->st_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    self->st_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_925BA889_pkStructAppend(zT_24, zT_25);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_struct_items;
    zT_3 = &self->pk_struct_len;
    zT_4 = &self->pk_struct_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_struct_items;
    zT_19 = self->pk_struct_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_struct_len;
    zT_21 = 1;
    self->pk_struct_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_E276DDD0_PackedBitField* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_items;
    zT_3 = &self->pk_len;
    zT_4 = &self->pk_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_items;
    zT_19 = self->pk_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_len;
    zT_21 = 1;
    self->pk_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->en_items;
    zT_3 = &self->en_len;
    zT_4 = &self->en_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->en_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    self->en_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_FA398D58_PackedStructInfo zT_25;
    zT_FA398D58_PackedStructInfo zT_26;
    unsigned int zT_27;
    unsigned short zT_28;
    unsigned int zT_29;
    zT_8 = &self->un_items;
    zT_3 = &self->un_len;
    zT_4 = &self->un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    self->un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    zT_24 = self;
    zT_27 = 0;
    zT_26.pk_start = zT_27;
    zT_28 = 0;
    zT_26.pk_count = zT_28;
    zT_29 = 0;
    zT_26.total_bits = zT_29;
    zT_25 = zT_26;
    zF_96B8622A_pkUnStructAppend(zT_24, zT_25);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_FA398D58_PackedStructInfo* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->pk_un_items;
    zT_3 = &self->pk_un_len;
    zT_4 = &self->pk_un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->pk_un_items;
    zT_19 = self->pk_un_len;
    zT_18[zT_19] = v;
    zT_20 = self->pk_un_len;
    zT_21 = 1;
    self->pk_un_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tu_items;
    zT_3 = &self->tu_len;
    zT_4 = &self->tu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    self->tu_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->tup_items;
    zT_3 = &self->tup_len;
    zT_4 = &self->tup_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    self->tup_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->unr_items;
    zT_3 = &self->unr_len;
    zT_4 = &self->unr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    self->unr_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->fe_items;
    zT_3 = &self->fe_len;
    zT_4 = &self->fe_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    self->fe_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned int zT_15;
    int zT_16;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8 = &self->em_items;
    zT_3 = &self->em_len;
    zT_4 = &self->em_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->em_len;
    zT_16 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), (unsigned int)(zT_15 + zT_16));
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    self->em_len = (unsigned int)(zT_20 + (unsigned int)((unsigned int)zT_21));
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xt_items;
    zT_3 = &self->xt_len;
    zT_4 = &self->xt_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    self->xt_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_8 = &self->xn_items;
    zT_3 = &self->xn_len;
    zT_4 = &self->xn_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), (unsigned int)(zT_14 + zT_15));
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    self->xn_len = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    int zT_3;
    int zT_6;
    int zT_12;
    int zT_18;
    int zT_21;
    int zT_24;
    int zT_30;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(8);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(16);
    z_bb_13:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_18 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_21 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(32);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(64);
    z_bb_29:
    return (unsigned char)(0);
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_8;
    int zT_11;
    int zT_14;
    int zT_17;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    unsigned char p_wb;
    unsigned char p_sg;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    zT_8 = 0;
    p_sg = zT_8;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_14 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_17 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_17 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_23 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_15;
    z_bb_14:
    zT_23 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_23) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_26 = 1;
    p_sg = zT_26;
    goto z_bb_17;
    z_bb_17:
    zT_27 = self;
    zT_29.kind = kind;
    zT_30 = 2;
    zT_29.state = zT_30;
    zT_31 = 0;
    zT_29.flags = zT_31;
    zT_29.is_signed = p_sg;
    zT_29.width_bits = p_wb;
    zT_29.size = size;
    zT_29.alignment = alignment;
    zT_32 = 0;
    zT_29.name_id = zT_32;
    zT_33 = 0;
    zT_29.c_name_id = zT_33;
    zT_34 = 0;
    zT_29.module_id = zT_34;
    zT_35 = 0;
    zT_29.payload_idx = zT_35;
    zT_28 = zT_29;
    zT_36 = zF_D4993F02_typeRegistryAppend(zT_27, zT_28);
    return zT_36;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    *len = (unsigned int)(0);
    *cap = (unsigned int)(0);
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68 = {0};
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70 = {0};
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72 = {0};
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74 = {0};
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76 = {0};
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78 = {0};
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = 0;
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zT_61 = 0;
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zT_64 = 0;
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    reg = zT_3;
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_9;
    char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    key_lo = zT_9;
    if ((int)(key_lo == (zT_79FAE712_u64)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_25;
    char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)np_k) + zT_17;
    zT_19 = (unsigned int)(20) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa((unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(65535))), zT_11);
    np_kl = zT_21;
    zT_25 = (unsigned int)(19) - (unsigned int)((unsigned int)np_kl);
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_35 = (unsigned char*)((unsigned char*)np_k) + np_ks;
    zT_36 = (unsigned int)(19) - np_ks;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_45 = 0;
    zT_46 = (unsigned char*)((unsigned char*)np_v) + zT_45;
    zT_47 = (unsigned int)(20) - zT_45;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    zT_53 = (unsigned int)(19) - (unsigned int)((unsigned int)np_vl);
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_63 = (unsigned char*)((unsigned char*)np_v) + np_vs;
    zT_64 = (unsigned int)(19) - np_vs;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_0C0306D6_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (int)(0));
    return zT_8;
}

/* typeRegistryGetOrCreatePtrQ */
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const, int is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_8 = 0;
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_827207A1_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (int)(0));
    return zT_8;
}

/* typeRegistryGetOrCreateManyPtrQ */
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const, int is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_112BF819_PtrPayload zT_22;
    zT_112BF819_PtrPayload zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_D155D06D_Type zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    unsigned int zT_45;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_14 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)base) << (zT_79FAE712_u64)(2)) | q;
    key = zT_14;
    zT_15 = &self->many_ptr_cache;
    zT_16 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    existing = zT_18.value;
    return existing;
    z_bb_7:
    zT_21 = self;
    zT_23.base = base;
    zT_22 = zT_23;
    zF_E5939FBD_ptrAppend(zT_21, zT_22);
    zT_25 = self;
    zT_28 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_27.kind = zT_28;
    zT_29 = 2;
    zT_27.state = zT_29;
    zT_30 = (unsigned char)q;
    zT_27.flags = zT_30;
    zT_31 = 0;
    zT_27.is_signed = zT_31;
    zT_32 = 0;
    zT_27.width_bits = zT_32;
    zT_33 = 4;
    zT_27.size = zT_33;
    zT_34 = 4;
    zT_27.alignment = zT_34;
    zT_35 = 0;
    zT_27.name_id = zT_35;
    zT_36 = 0;
    zT_27.c_name_id = zT_36;
    zT_37 = 0;
    zT_27.module_id = zT_37;
    zT_38 = self->ptr_len;
    zT_41 = (unsigned int)(unsigned int)(zT_38 - (unsigned int)(1));
    zT_27.payload_idx = zT_41;
    zT_26 = zT_27;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_25, zT_26);
    tid = zT_42;
    zT_43 = &self->many_ptr_cache;
    zT_44 = key;
    zT_45 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_43, zT_44, zT_45);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    int zT_112;
    int zT_113;
    int zT_114;
    unsigned char zT_115;
    unsigned char zT_116;
    unsigned char zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_127 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_128;
    zT_79FAE712_u64 zT_129;
    unsigned int zT_130;
    char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_4028D896_Arr_unsigned_char_2 zT_138;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    int zT_144;
    unsigned char* zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned char* zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    zT_4028D896_Arr_unsigned_char_2 zT_166;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    int zT_172;
    unsigned char* zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176 = 0;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned char* zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_4028D896_Arr_unsigned_char_2 zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    int zT_201;
    unsigned char* zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205 = 0;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned char* zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    zT_11 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(1)) | ic;
    key = zT_11;
    zT_12 = &self->slice_cache;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_30 = 0;
    zT_31 = (unsigned char*)((unsigned char*)u2h_eb) + zT_30;
    zT_32 = (unsigned int)(20) - zT_30;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    zT_38 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_el);
    u2h_es = zT_38;
    zT_43 = (unsigned char*)((unsigned char*)u2h_eb) + u2h_es;
    zT_44 = (unsigned int)(19) - u2h_es;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)u2h_rb) + zT_58;
    zT_60 = (unsigned int)(20) - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    zT_66 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_rl);
    u2h_rs = zT_66;
    zT_71 = (unsigned char*)((unsigned char*)u2h_rb) + u2h_rs;
    zT_72 = (unsigned int)(19) - u2h_rs;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_87 = 0;
    zT_88 = (unsigned char*)((unsigned char*)u2h_cb) + zT_87;
    zT_89 = (unsigned int)(20) - zT_87;
    zT_90.ptr = zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_83);
    u2h_cl = zT_91;
    zT_95 = (unsigned int)(19) - (unsigned int)((unsigned int)u2h_cl);
    u2h_cs = zT_95;
    zT_100 = (unsigned char*)((unsigned char*)u2h_cb) + u2h_cs;
    zT_101 = (unsigned int)(19) - u2h_cs;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_114 = 0;
    zT_112 = zT_114;
    goto z_bb_8;
    z_bb_8:
    zT_115 = (unsigned char)zT_112;
    zT_109.flags = zT_115;
    zT_116 = 0;
    zT_109.is_signed = zT_116;
    zT_117 = 0;
    zT_109.width_bits = zT_117;
    zT_118 = 8;
    zT_109.size = zT_118;
    zT_119 = 4;
    zT_109.alignment = zT_119;
    zT_120 = 0;
    zT_109.name_id = zT_120;
    zT_121 = 0;
    zT_109.c_name_id = zT_121;
    zT_122 = 0;
    zT_109.module_id = zT_122;
    zT_123 = self->slice_len;
    zT_126 = (unsigned int)(unsigned int)(zT_123 - (unsigned int)(1));
    zT_109.payload_idx = zT_126;
    zT_108 = zT_109;
    zT_127 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_127;
    zT_128 = &self->slice_cache;
    zT_129 = key;
    zT_130 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_128, zT_129, zT_130);
    zT_133 = "U2N:e";
    zT_135 = 5;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    u2n_m = zT_134;
    zT_136 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_136);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_138[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_138[_i];
        _i++;
    }
}
    zT_140 = elem;
    zT_144 = 0;
    zT_145 = (unsigned char*)((unsigned char*)u2n_eb) + zT_144;
    zT_146 = (unsigned int)(20) - zT_144;
    zT_147.ptr = zT_145;
    zT_147.len = zT_146;
    zT_141 = zT_147;
    zT_148 = zF_A7504564_itoa(zT_140, zT_141);
    u2n_el = zT_148;
    zT_152 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_el);
    u2n_es = zT_152;
    zT_157 = (unsigned char*)((unsigned char*)u2n_eb) + u2n_es;
    zT_158 = (unsigned int)(19) - u2n_es;
    zT_159.ptr = zT_157;
    zT_159.len = zT_158;
    zT_153 = zT_159;
    zF_48AC7B3A_markerWrite(zT_153);
    zT_161 = "r";
    zT_163 = 1;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    u2n_rm = zT_162;
    zT_164 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_164);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_166[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_166[_i];
        _i++;
    }
}
    zT_168 = tid;
    zT_172 = 0;
    zT_173 = (unsigned char*)((unsigned char*)u2n_rb) + zT_172;
    zT_174 = (unsigned int)(20) - zT_172;
    zT_175.ptr = zT_173;
    zT_175.len = zT_174;
    zT_169 = zT_175;
    zT_176 = zF_A7504564_itoa(zT_168, zT_169);
    u2n_rl = zT_176;
    zT_180 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_rl);
    u2n_rs = zT_180;
    zT_185 = (unsigned char*)((unsigned char*)u2n_rb) + u2n_rs;
    zT_186 = (unsigned int)(19) - u2n_rs;
    zT_187.ptr = zT_185;
    zT_187.len = zT_186;
    zT_181 = zT_187;
    zF_48AC7B3A_markerWrite(zT_181);
    zT_189 = "c";
    zT_191 = 1;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    u2n_cm = zT_190;
    zT_192 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_192);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_194[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_194[_i];
        _i++;
    }
}
    zT_201 = 0;
    zT_202 = (unsigned char*)((unsigned char*)u2n_cb) + zT_201;
    zT_203 = (unsigned int)(20) - zT_201;
    zT_204.ptr = zT_202;
    zT_204.len = zT_203;
    zT_197 = zT_204;
    zT_205 = zF_A7504564_itoa((unsigned int)((unsigned int)ic), zT_197);
    u2n_cl = zT_205;
    zT_209 = (unsigned int)(19) - (unsigned int)((unsigned int)u2n_cl);
    u2n_cs = zT_209;
    zT_214 = (unsigned char*)((unsigned char*)u2n_cb) + u2n_cs;
    zT_215 = (unsigned int)(19) - u2n_cs;
    zT_216.ptr = zT_214;
    zT_216.len = zT_215;
    zT_210 = zT_216;
    zF_48AC7B3A_markerWrite(zT_210);
    return tid;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39 = 0;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_0B10E8E9_OptionalPayload zT_42;
    zT_0B10E8E9_OptionalPayload zT_43;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    zT_21D3708C_U32ToU32Map* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_2 = &self->optional_cache;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    return existing;
    z_bb_2:
    zT_9 = self->types_items;
    zT_10 = zT_9[payload];
    pay_type = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    opt_size = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    opt_align = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned char)zT_18;
    opt_state = zT_19;
    zT_20 = pay_type.state;
    if ((int)(zT_20 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = pay_type.alignment;
    if ((int)(zT_24 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_41 = self;
    zT_43.payload = payload;
    zT_42 = zT_43;
    zF_4569340E_optAppend(zT_41, zT_42);
    zT_45 = self;
    zT_48 = zT_33EF6BFB_TypeKind_optional_type;
    zT_47.kind = zT_48;
    zT_47.state = opt_state;
    zT_49 = 0;
    zT_47.flags = zT_49;
    zT_50 = 0;
    zT_47.is_signed = zT_50;
    zT_51 = 0;
    zT_47.width_bits = zT_51;
    zT_47.size = opt_size;
    zT_47.alignment = opt_align;
    zT_52 = 0;
    zT_47.name_id = zT_52;
    zT_53 = 0;
    zT_47.c_name_id = zT_53;
    zT_54 = 0;
    zT_47.module_id = zT_54;
    zT_55 = self->opt_len;
    zT_58 = (unsigned int)(unsigned int)(zT_55 - (unsigned int)(1));
    zT_47.payload_idx = zT_58;
    zT_46 = zT_47;
    zT_59 = zF_D4993F02_typeRegistryAppend(zT_45, zT_46);
    tid = zT_59;
    if ((int)(opt_state == (unsigned char)(2))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_27 = pay_type.alignment;
    goto z_bb_7;
    z_bb_6:
    zT_27 = 4;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_27;
    zT_30 = pay_type.size;
    zT_34 = zF_D2BAC673_alignUp(zT_30, (unsigned int)(4));
    zT_36 = zT_34 + (unsigned int)(4);
    opt_size = zT_36;
    zT_37 = opt_size;
    zT_38 = pay_align;
    zT_39 = zF_D2BAC673_alignUp(zT_37, zT_38);
    opt_size = zT_39;
    opt_align = pay_align;
    zT_40 = 2;
    opt_state = zT_40;
    goto z_bb_4;
    z_bb_8:
    zT_62 = &self->optional_cache;
    zT_63 = payload;
    zT_64 = tid;
    zF_26476265_u32ToU32MapPut(zT_62, zT_63, zT_64);
    goto z_bb_9;
    z_bb_9:
    return tid;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_D155D06D_Type* zT_16;
    zT_D155D06D_Type zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned int zT_31;
    unsigned int zT_34;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_51 = 0;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56 = 0;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_42C2D6BF_EUPayload zT_59;
    zT_42C2D6BF_EUPayload zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type zT_63;
    zT_D155D06D_Type zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned int zT_76 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_79;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_8 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)payload) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)error_set);
    eu_key = zT_8;
    zT_9 = &self->eu_cache;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self->types_items;
    zT_17 = zT_16[payload];
    pay_type = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    eu_size = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    eu_align = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned char)zT_25;
    eu_state = zT_26;
    zT_27 = pay_type.state;
    if ((int)(zT_27 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = pay_type.size;
    if ((int)(zT_31 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_58 = self;
    zT_60.payload = payload;
    zT_60.error_set = error_set;
    zT_59 = zT_60;
    zF_ABBA52E7_euAppend(zT_58, zT_59);
    zT_62 = self;
    zT_65 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_64.kind = zT_65;
    zT_64.state = eu_state;
    zT_66 = 0;
    zT_64.flags = zT_66;
    zT_67 = 0;
    zT_64.is_signed = zT_67;
    zT_68 = 0;
    zT_64.width_bits = zT_68;
    zT_64.size = eu_size;
    zT_64.alignment = eu_align;
    zT_69 = 0;
    zT_64.name_id = zT_69;
    zT_70 = 0;
    zT_64.c_name_id = zT_70;
    zT_71 = 0;
    zT_64.module_id = zT_71;
    zT_72 = self->eu_len;
    zT_75 = (unsigned int)(unsigned int)(zT_72 - (unsigned int)(1));
    zT_64.payload_idx = zT_75;
    zT_63 = zT_64;
    zT_76 = zF_D4993F02_typeRegistryAppend(zT_62, zT_63);
    tid = zT_76;
    zT_77 = &self->eu_cache;
    zT_78 = eu_key;
    zT_79 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_77, zT_78, zT_79);
    return tid;
    z_bb_5:
    zT_34 = pay_type.size;
    goto z_bb_7;
    z_bb_6:
    zT_34 = 4;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_34;
    zT_38 = pay_type.alignment;
    if ((int)(zT_38 > (unsigned int)(4))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_41 = pay_type.alignment;
    goto z_bb_10;
    z_bb_9:
    zT_41 = 4;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_41;
    zT_45 = union_size;
    zT_46 = union_align;
    zT_47 = zF_D2BAC673_alignUp(zT_45, zT_46);
    total = zT_47;
    zT_48 = total;
    zT_51 = zF_D2BAC673_alignUp(zT_48, (unsigned int)(4));
    zT_53 = zT_51 + (unsigned int)(4);
    total = zT_53;
    zT_54 = total;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    eu_size = zT_56;
    eu_align = union_align;
    zT_57 = 2;
    eu_state = zT_57;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_E834303C_ArrayPayload zT_100;
    zT_E834303C_ArrayPayload zT_101;
    zT_D155D06D_Type* zT_103;
    zT_D155D06D_Type zT_104;
    int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_136 = 0;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_4028D896_Arr_unsigned_char_2 zT_143;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    int zT_149;
    unsigned char* zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153 = 0;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned char zT_165;
    zT_A4CE86B7_U64ToU32Map* zT_168;
    zT_79FAE712_u64 zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)o0b) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    zT_23 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l);
    o0s = zT_23;
    zT_28 = (unsigned char*)((unsigned char*)o0b) + o0s;
    zT_29 = (unsigned int)(19) - o0s;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)o0b2) + zT_43;
    zT_45 = (unsigned int)(20) - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    zT_51 = (unsigned int)(19) - (unsigned int)((unsigned int)o0l2);
    o0s2 = zT_51;
    zT_56 = (unsigned char*)((unsigned char*)o0b2) + o0s2;
    zT_57 = (unsigned int)(19) - o0s2;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_64 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)elem) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)length);
    key = zT_64;
    zT_65 = &self->array_cache;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_83 = 0;
    zT_84 = (unsigned char*)((unsigned char*)o1b) + zT_83;
    zT_85 = (unsigned int)(20) - zT_83;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    zT_91 = (unsigned int)(19) - (unsigned int)((unsigned int)o1l);
    o1s = zT_91;
    zT_96 = (unsigned char*)((unsigned char*)o1b) + o1s;
    zT_97 = (unsigned int)(19) - o1s;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    return existing;
    z_bb_2:
    zT_99 = self;
    zT_101.elem = elem;
    zT_101.length = length;
    zT_100 = zT_101;
    zF_4D5CD212_arrayAppend(zT_99, zT_100);
    zT_103 = self->types_items;
    zT_104 = zT_103[elem];
    elem_ty = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    arr_size = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    arr_align = zT_110;
    zT_112 = 0;
    zT_113 = (unsigned char)zT_112;
    arr_state = zT_113;
    zT_114 = elem_ty.state;
    if ((int)(zT_114 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_117 = elem_ty.size;
    zT_118 = zT_117 * length;
    arr_size = zT_118;
    zT_119 = elem_ty.alignment;
    arr_align = zT_119;
    zT_120 = 2;
    arr_state = zT_120;
    goto z_bb_4;
    z_bb_4:
    zT_122 = self;
    zT_125 = zT_33EF6BFB_TypeKind_array_type;
    zT_124.kind = zT_125;
    zT_124.state = arr_state;
    zT_126 = 0;
    zT_124.flags = zT_126;
    zT_127 = 0;
    zT_124.is_signed = zT_127;
    zT_128 = 0;
    zT_124.width_bits = zT_128;
    zT_124.size = arr_size;
    zT_124.alignment = arr_align;
    zT_129 = 0;
    zT_124.name_id = zT_129;
    zT_130 = 0;
    zT_124.c_name_id = zT_130;
    zT_131 = 0;
    zT_124.module_id = zT_131;
    zT_132 = self->array_len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 - (unsigned int)(1));
    zT_124.payload_idx = zT_135;
    zT_123 = zT_124;
    zT_136 = zF_D4993F02_typeRegistryAppend(zT_122, zT_123);
    tid = zT_136;
    zT_138 = "O2N";
    zT_140 = 3;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    o2m = zT_139;
    zT_141 = o2m;
    zF_48AC7B3A_markerWrite(zT_141);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_143[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_143[_i];
        _i++;
    }
}
    zT_145 = tid;
    zT_149 = 0;
    zT_150 = (unsigned char*)((unsigned char*)o2b) + zT_149;
    zT_151 = (unsigned int)(20) - zT_149;
    zT_152.ptr = zT_150;
    zT_152.len = zT_151;
    zT_146 = zT_152;
    zT_153 = zF_A7504564_itoa(zT_145, zT_146);
    o2l = zT_153;
    zT_157 = (unsigned int)(19) - (unsigned int)((unsigned int)o2l);
    o2s = zT_157;
    zT_162 = (unsigned char*)((unsigned char*)o2b) + o2s;
    zT_163 = (unsigned int)(19) - o2s;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_158 = zT_164;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_165 = elem_ty.state;
    if ((int)(zT_165 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_168 = &self->array_cache;
    zT_169 = key;
    zT_170 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_168, zT_169, zT_170);
    goto z_bb_6;
    z_bb_6:
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.is_signed = zT_13;
    zT_14 = 0;
    zT_9.width_bits = zT_14;
    zT_15 = 0;
    zT_9.size = zT_15;
    zT_16 = 1;
    zT_9.alignment = zT_16;
    zT_17 = 0;
    zT_9.name_id = zT_17;
    zT_18 = 0;
    zT_9.c_name_id = zT_18;
    zT_19 = 0;
    zT_9.module_id = zT_19;
    zT_20 = self->tup_len;
    zT_23 = (unsigned int)(unsigned int)(zT_20 - (unsigned int)(1));
    zT_9.payload_idx = zT_23;
    zT_8 = zT_9;
    zT_24 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_24;
    return tid;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type, unsigned char call_conv) {
    char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25 = 0;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned char zT_38;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_53;
    unsigned int zT_54;
    int zT_56;
    zT_0317B1D5_FnPayload* zT_57;
    zT_D155D06D_Type* zT_58;
    zT_D155D06D_Type zT_59;
    unsigned int zT_60;
    zT_0317B1D5_FnPayload zT_61;
    unsigned int zT_62;
    int zT_64;
    zT_0317B1D5_FnPayload* zT_65;
    zT_D155D06D_Type* zT_66;
    zT_D155D06D_Type zT_67;
    unsigned int zT_68;
    zT_0317B1D5_FnPayload zT_69;
    unsigned char zT_70;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    zT_D155D06D_Type* zT_86;
    zT_D155D06D_Type* zT_87;
    int zT_89;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_0317B1D5_FnPayload zT_92;
    zT_0317B1D5_FnPayload zT_93;
    unsigned char zT_94;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_D155D06D_Type zT_97;
    zT_D155D06D_Type zT_98;
    zT_33EF6BFB_TypeKind zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_111;
    unsigned int zT_112 = 0;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    zT_D155D06D_Type zT_117;
    unsigned char zT_118;
    zT_D155D06D_Type* zT_121;
    zT_D155D06D_Type* zT_123;
    zT_4028D896_Arr_unsigned_char_2 zT_125;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    int zT_131;
    unsigned char* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned char conv_bit;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_10 = "P2:n";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    p2m = zT_11;
    zT_13 = p2m;
    zF_48AC7B3A_markerWrite(zT_13);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_15[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = name_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)p2nb) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    p2nl = zT_25;
    zT_29 = (unsigned int)(19) - (unsigned int)((unsigned int)p2nl);
    p2ns = zT_29;
    zT_34 = (unsigned char*)((unsigned char*)p2nb) + p2ns;
    zT_35 = (unsigned int)(19) - p2ns;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_30 = zT_36;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_38 = 0;
    conv_bit = zT_38;
    if ((int)(call_conv == (unsigned char)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_41 = 2;
    conv_bit = zT_41;
    goto z_bb_2;
    z_bb_2:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    i = zT_44;
    goto z_bb_3;
    z_bb_3:
    zT_45 = self->types_len;
    if ((int)(i < zT_45)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_48 = self->types_items;
    zT_49 = zT_48[i];
    it = zT_49;
    zT_50 = it.kind;
    if ((int)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_91 = self;
    zT_93.name_id = name_id;
    zT_93.module_id = module_id;
    zT_93.is_extern = is_extern;
    zT_93.params_start = params_start;
    zT_93.params_count = params_count;
    zT_93.return_type = return_type;
    zT_94 = is_variadic | conv_bit;
    zT_93.flags_packed = zT_94;
    zT_92 = zT_93;
    zF_07DDC351_fnAppend(zT_91, zT_92);
    zT_96 = self;
    zT_99 = zT_33EF6BFB_TypeKind_fn_type;
    zT_98.kind = zT_99;
    zT_100 = 2;
    zT_98.state = zT_100;
    zT_101 = 0;
    zT_98.flags = zT_101;
    zT_102 = 0;
    zT_98.is_signed = zT_102;
    zT_103 = 0;
    zT_98.width_bits = zT_103;
    zT_104 = 4;
    zT_98.size = zT_104;
    zT_105 = 4;
    zT_98.alignment = zT_105;
    zT_98.name_id = name_id;
    zT_106 = 0;
    zT_98.c_name_id = zT_106;
    zT_107 = 0;
    zT_98.module_id = zT_107;
    zT_108 = self->fn_len;
    zT_111 = (unsigned int)(unsigned int)(zT_108 - (unsigned int)(1));
    zT_98.payload_idx = zT_111;
    zT_97 = zT_98;
    zT_112 = zF_D4993F02_typeRegistryAppend(zT_96, zT_97);
    tid = zT_112;
    if ((int)(conv_bit != (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_6:
    zT_89 = 1;
    zT_90 = i + zT_89;
    i = zT_90;
    goto z_bb_3;
    z_bb_7:
    zT_54 = it.name_id;
    zT_53 = zT_54 == name_id;
    goto z_bb_9;
    z_bb_8:
    zT_53 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->fn_items;
    zT_58 = self->types_items;
    zT_59 = zT_58[i];
    zT_60 = zT_59.payload_idx;
    zT_61 = zT_57[zT_60];
    zT_62 = zT_61.module_id;
    zT_56 = zT_62 == module_id;
    goto z_bb_12;
    z_bb_11:
    zT_56 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_56) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_65 = self->fn_items;
    zT_66 = self->types_items;
    zT_67 = zT_66[i];
    zT_68 = zT_67.payload_idx;
    zT_69 = zT_65[zT_68];
    zT_70 = zT_69.flags_packed;
    zT_64 = (unsigned char)(zT_70 & (unsigned int)(2)) == conv_bit;
    goto z_bb_15;
    z_bb_14:
    zT_64 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_64) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_75 = "H";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    p2hm = zT_76;
    zT_78 = p2hm;
    zF_48AC7B3A_markerWrite(zT_78);
    if ((int)(conv_bit != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_81 = self->types_items;
    zT_82 = zT_81[i];
    zT_83 = zT_82.flags;
    zT_86 = self->types_items;
    zT_87 = zT_86 + i;
    zT_87->flags = (unsigned char)(zT_83 | (unsigned char)(1));
    goto z_bb_19;
    z_bb_19:
    return (unsigned int)((unsigned int)i);
    z_bb_20:
    zT_115 = self->types_items;
    zT_116 = (unsigned int)tid;
    zT_117 = zT_115[zT_116];
    zT_118 = zT_117.flags;
    zT_121 = self->types_items;
    zT_123 = zT_121 + (unsigned int)((unsigned int)tid);
    zT_123->flags = (unsigned char)(zT_118 | (unsigned char)(1));
    goto z_bb_21;
    z_bb_21:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_125[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_125[_i];
        _i++;
    }
}
    zT_127 = tid;
    zT_131 = 0;
    zT_132 = (unsigned char*)((unsigned char*)p2sb) + zT_131;
    zT_133 = (unsigned int)(20) - zT_131;
    zT_134.ptr = zT_132;
    zT_134.len = zT_133;
    zT_128 = zT_134;
    zT_135 = zF_A7504564_itoa(zT_127, zT_128);
    p2sl = zT_135;
    zT_139 = (unsigned int)(19) - (unsigned int)((unsigned int)p2sl);
    p2ss = zT_139;
    zT_144 = (unsigned char*)((unsigned char*)p2sb) + p2ss;
    zT_145 = (unsigned int)(19) - p2ss;
    zT_146.ptr = zT_144;
    zT_146.len = zT_145;
    zT_140 = zT_146;
    zF_48AC7B3A_markerWrite(zT_140);
    zT_148 = "\n";
    zT_150 = 1;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    p2nl2 = zT_149;
    zT_151 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_151);
    return tid;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_8 = self->types_items;
    zT_10 = zT_8 + (unsigned int)((unsigned int)tid);
    zT_10->flags = (unsigned char)(zT_5 | (unsigned char)(1));
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    unsigned int* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_79FAE712_u64 zT_22;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_0B73C507_ErrorSetPayload zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_48 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((int)(ki < tags_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_13 = (unsigned int)(unsigned int)(tags_start + (unsigned int)((unsigned int)ki));
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    zT_18 = (zT_79FAE712_u64)(key ^ (zT_79FAE712_u64)((zT_79FAE712_u64)tag)) * (zT_79FAE712_u64)(1099511628211ULL);
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_21 = &self->es_cache;
    zT_22 = key;
    zT_24 = zF_A05A7BE1_u64ToU32MapGet(zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_20 = ki + zT_19;
    ki = zT_20;
    goto z_bb_1;
    z_bb_5:
    existing = zT_24.value;
    return existing;
    z_bb_6:
    zT_27 = self;
    zT_29.tags_start = tags_start;
    zT_29.tags_count = tags_count;
    zT_28 = zT_29;
    zF_B86143DD_esAppend(zT_27, zT_28);
    zT_31 = self;
    zT_34 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_33.kind = zT_34;
    zT_35 = 2;
    zT_33.state = zT_35;
    zT_36 = 0;
    zT_33.flags = zT_36;
    zT_37 = 0;
    zT_33.is_signed = zT_37;
    zT_38 = 0;
    zT_33.width_bits = zT_38;
    zT_39 = 4;
    zT_33.size = zT_39;
    zT_40 = 4;
    zT_33.alignment = zT_40;
    zT_41 = 0;
    zT_33.name_id = zT_41;
    zT_42 = 0;
    zT_33.c_name_id = zT_42;
    zT_43 = 0;
    zT_33.module_id = zT_43;
    zT_44 = self->es_len;
    zT_47 = (unsigned int)(unsigned int)(zT_44 - (unsigned int)(1));
    zT_33.payload_idx = zT_47;
    zT_32 = zT_33;
    zT_48 = zF_D4993F02_typeRegistryAppend(zT_31, zT_32);
    tid = zT_48;
    zT_49 = &self->es_cache;
    zT_50 = key;
    zT_51 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_49, zT_50, zT_51);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_36;
    unsigned int zT_37;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    if ((int)(es_type_id >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    zT_32 = reg->xn_len;
    if ((int)((unsigned int)(tags_start + tags_count) > zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(4294967295u);
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    if ((int)(i < tags_count)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    if ((int)(zT_41 == name_id)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned int)(4294967295u);
    z_bb_12:
    zT_44 = 1;
    zT_45 = i + zT_44;
    i = zT_45;
    goto z_bb_9;
    z_bb_13:
    return (unsigned int)((unsigned int)i);
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_13;
    unsigned int zT_14;
    int zT_17;
    unsigned int zT_18;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type zT_38;
    unsigned int zT_39 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    if ((int)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    zT_10 = it.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = zT_33EF6BFB_TypeKind_module_type;
    zT_20.kind = zT_21;
    zT_22 = 0;
    zT_20.state = zT_22;
    zT_23 = 0;
    zT_20.flags = zT_23;
    zT_24 = 0;
    zT_20.is_signed = zT_24;
    zT_25 = 0;
    zT_20.width_bits = zT_25;
    zT_26 = 0;
    zT_20.size = zT_26;
    zT_27 = 0;
    zT_20.alignment = zT_27;
    zT_28 = 0;
    zT_20.name_id = zT_28;
    zT_29 = 0;
    zT_20.c_name_id = zT_29;
    zT_20.module_id = module_id;
    zT_30 = 0;
    zT_20.payload_idx = zT_30;
    t = zT_20;
    zT_32 = "MC";
    zT_34 = 2;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    mc = zT_33;
    zT_35 = mc;
    zF_48AC7B3A_markerWrite(zT_35);
    zT_37 = self;
    zT_38 = t;
    zT_39 = zF_D4993F02_typeRegistryAppend(zT_37, zT_38);
    mcid = zT_39;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_13 = zT_14 == module_id;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)((unsigned int)i);
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_338B7C76_TypeRegistry* zT_169;
    char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    (void)zF_4F84B621_registerPrimitive(zT_1, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel), (unsigned int)(0), (unsigned int)(0));
    zT_9 = self;
    (void)zF_4F84B621_registerPrimitive(zT_9, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type), (unsigned int)(0), (unsigned int)(0));
    zT_17 = self;
    (void)zF_4F84B621_registerPrimitive(zT_17, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type), (unsigned int)(4), (unsigned int)(4));
    zT_25 = self;
    (void)zF_4F84B621_registerPrimitive(zT_25, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type), (unsigned int)(0), (unsigned int)(0));
    zT_33 = self;
    (void)zF_4F84B621_registerPrimitive(zT_33, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type), (unsigned int)(1), (unsigned int)(1));
    zT_41 = self;
    (void)zF_4F84B621_registerPrimitive(zT_41, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type), (unsigned int)(2), (unsigned int)(2));
    zT_49 = self;
    (void)zF_4F84B621_registerPrimitive(zT_49, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type), (unsigned int)(4), (unsigned int)(4));
    zT_57 = self;
    (void)zF_4F84B621_registerPrimitive(zT_57, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type), (unsigned int)(8), (unsigned int)(8));
    zT_65 = self;
    (void)zF_4F84B621_registerPrimitive(zT_65, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type), (unsigned int)(1), (unsigned int)(1));
    zT_73 = self;
    (void)zF_4F84B621_registerPrimitive(zT_73, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type), (unsigned int)(2), (unsigned int)(2));
    zT_81 = self;
    (void)zF_4F84B621_registerPrimitive(zT_81, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type), (unsigned int)(4), (unsigned int)(4));
    zT_89 = self;
    (void)zF_4F84B621_registerPrimitive(zT_89, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type), (unsigned int)(8), (unsigned int)(8));
    zT_97 = self;
    (void)zF_4F84B621_registerPrimitive(zT_97, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type), (unsigned int)(4), (unsigned int)(4));
    zT_105 = self;
    (void)zF_4F84B621_registerPrimitive(zT_105, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type), (unsigned int)(4), (unsigned int)(4));
    zT_113 = self;
    (void)zF_4F84B621_registerPrimitive(zT_113, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type), (unsigned int)(1), (unsigned int)(1));
    zT_121 = self;
    (void)zF_4F84B621_registerPrimitive(zT_121, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type), (unsigned int)(4), (unsigned int)(4));
    zT_129 = self;
    (void)zF_4F84B621_registerPrimitive(zT_129, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type), (unsigned int)(8), (unsigned int)(8));
    zT_137 = self;
    (void)zF_4F84B621_registerPrimitive(zT_137, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type), (unsigned int)(0), (unsigned int)(0));
    zT_145 = self;
    (void)zF_4F84B621_registerPrimitive(zT_145, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type), (unsigned int)(0), (unsigned int)(0));
    zT_153 = self;
    (void)zF_4F84B621_registerPrimitive(zT_153, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type), (unsigned int)(0), (unsigned int)(0));
    zT_161 = self;
    (void)zF_4F84B621_registerPrimitive(zT_161, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type), (unsigned int)(0), (unsigned int)(0));
    zT_169 = self;
    (void)zF_4F84B621_registerPrimitive(zT_169, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type), (unsigned int)(4), (unsigned int)(4));
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    zT_181 = self;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, (unsigned int)(1), zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    zT_189 = self;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, (unsigned int)(2), zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, (unsigned int)(4), zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, (unsigned int)(5), zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, (unsigned int)(6), zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, (unsigned int)(7), zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, (unsigned int)(8), zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, (unsigned int)(9), zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, (unsigned int)(10), zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, (unsigned int)(11), zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    zT_261 = self;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, (unsigned int)(12), zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    zT_269 = self;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, (unsigned int)(13), zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, (unsigned int)(14), zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, (unsigned int)(15), zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, (unsigned int)(16), zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    zT_301 = self;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, (unsigned int)(17), zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, (unsigned int)(18), zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    zT_317 = self;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, (unsigned int)(20), zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, (unsigned int)(21), zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_16;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_4 = self->interner;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, (zT_79FAE712_u64)((zT_79FAE712_u64)nid), zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, int* is_unsigned) {
    unsigned int zT_4;
    unsigned char* zT_9;
    int zT_10;
    unsigned char zT_11;
    int zT_14;
    int zT_17;
    int zT_19;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_30;
    unsigned char zT_31;
    int zT_34;
    unsigned int zT_41;
    unsigned int zT_44;
    int zT_48;
    unsigned int zT_49;
    int zT_52;
    int zT_58;
    unsigned int nlen;
    unsigned char prefix;
    int is_u;
    int is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    if ((int)(nlen < (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = zT_9[zT_10];
    prefix = zT_11;
    zT_14 = prefix == (unsigned char)(117);
    is_u = zT_14;
    zT_17 = prefix == (unsigned char)(105);
    is_i = zT_17;
    if ((int)(!is_u)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = !is_i;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    *is_unsigned = (int)(1);
    goto z_bb_9;
    z_bb_9:
    zT_25 = 0;
    w = zT_25;
    zT_27 = 1;
    i = zT_27;
    goto z_bb_11;
    z_bb_10:
    *is_unsigned = (int)(0);
    goto z_bb_9;
    z_bb_11:
    if ((int)(i < nlen)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_30 = name.ptr;
    zT_31 = zT_30[i];
    c = zT_31;
    if ((int)(c < (unsigned char)(48))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_48 = 1;
    zT_49 = i + zT_48;
    i = zT_49;
    goto z_bb_11;
    z_bb_15:
    zT_34 = c > (unsigned char)(57);
    goto z_bb_17;
    z_bb_16:
    zT_34 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_34) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned int)(0);
    z_bb_19:
    zT_41 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_41;
    zT_44 = (unsigned int)(w * (unsigned int)(10)) + d;
    w = zT_44;
    if ((int)(w > (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    if ((int)(w < (unsigned int)(1))) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    if ((int)(w < (unsigned int)(1))) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_52 = w > (unsigned int)(64);
    goto z_bb_27;
    z_bb_26:
    zT_52 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_52) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_58 = w > (unsigned int)(63);
    goto z_bb_32;
    z_bb_31:
    zT_58 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_58) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned int)(0);
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int* zT_6;
    unsigned int zT_8 = 0;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53 = 0;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    zT_5 = name;
    zT_6 = &arb_u;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    if ((int)(arb_w == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_13 = self->interner;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    zT_18 = self;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, (zT_79FAE712_u64)((zT_79FAE712_u64)nid));
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = zT_33EF6BFB_TypeKind_arb_uint_type;
    goto z_bb_7;
    z_bb_6:
    zT_25 = zT_33EF6BFB_TypeKind_arb_int_type;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    if ((int)(arb_w > (unsigned int)(8))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    if ((int)(arb_w > (unsigned int)(16))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    if ((int)(arb_w > (unsigned int)(32))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    if (arb_u) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = 0;
    goto z_bb_16;
    z_bb_15:
    zT_45 = 1;
    goto z_bb_16;
    z_bb_16:
    zT_42.is_signed = zT_45;
    zT_48 = (unsigned char)arb_w;
    zT_42.width_bits = zT_48;
    zT_42.size = carrier;
    zT_42.alignment = carrier;
    zT_49 = 0;
    zT_42.name_id = zT_49;
    zT_50 = 0;
    zT_42.c_name_id = zT_50;
    zT_51 = 0;
    zT_42.module_id = zT_51;
    zT_52 = 0;
    zT_42.payload_idx = zT_52;
    zT_41 = zT_42;
    zT_53 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_53;
    zT_54 = self;
    zT_55 = tid;
    zT_56 = name;
    zF_BA76727A_registerPrimitiveNa(zT_54, zT_55, zT_56);
    return tid;
}

/* typeRegistryEnumBackingType */
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(10);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(10);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(10);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.backing_type;
    return zT_24;
}

/* typeRegistryEnumHasExplicitBacking */
int zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned char zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.explicit_backing;
    return (int)(zT_24 != (unsigned char)(0));
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_29 = 0;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_23 = ty.kind;
    zT_22 = zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = ty.width_bits;
    return zT_26;
    z_bb_9:
    zT_27 = ty.kind;
    zT_29 = zF_534230F8_typeWidthBitsForKin(zT_27);
    return zT_29;
}

/* typeRegistryIntIsSigned */
int zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    int zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    int zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_23 = ty.kind;
    if ((int)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_27 = ty.kind;
    if ((int)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = ty.kind;
    zT_30 = zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_30 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_30) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_35 = ty.kind;
    zT_34 = zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_39 = ty.kind;
    zT_38 = zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_20;
    z_bb_19:
    zT_42 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_42) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(0);
    z_bb_22:
    zT_47 = ty.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_25;
    z_bb_24:
    zT_50 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_50) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = ty.kind;
    zT_54 = zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_28;
    z_bb_27:
    zT_54 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_54) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_31;
    z_bb_30:
    zT_58 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_58) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_63 = ty.kind;
    zT_62 = zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_34;
    z_bb_33:
    zT_62 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_62) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_67 = ty.kind;
    zT_66 = zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_37;
    z_bb_36:
    zT_66 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_66) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (int)(1);
    z_bb_39:
    return (int)(0);
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27 = 0;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    zT_4028D896_Arr_unsigned_char_2 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42 = 0;
    unsigned int zT_46;
    char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_4028D896_Arr_unsigned_char_2 zT_60;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_74;
    char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_4028D896_Arr_unsigned_char_2 zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99 = 0;
    unsigned int zT_103;
    char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_4028D896_Arr_unsigned_char_2 zT_117;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    int zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned int zT_131;
    char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_9 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18.is_signed = zT_21;
    zT_22 = 0;
    zT_18.width_bits = zT_22;
    zT_23 = 0;
    zT_18.size = zT_23;
    zT_24 = 0;
    zT_18.alignment = zT_24;
    zT_18.name_id = name_id;
    zT_25 = 0;
    zT_18.c_name_id = zT_25;
    zT_18.module_id = module_id;
    zT_26 = 0;
    zT_18.payload_idx = zT_26;
    zT_17 = zT_18;
    zT_27 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_27;
    zT_28 = self;
    zT_29 = key;
    zT_30 = tid;
    zF_5E95558D_nameCachePut(zT_28, zT_29, zT_30);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = module_id;
    zT_38 = 0;
    zT_39 = (unsigned char*)((unsigned char*)rn_m) + zT_38;
    zT_40 = (unsigned int)(20) - zT_38;
    zT_41.ptr = zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zT_42 = zF_A7504564_itoa(zT_34, zT_35);
    rn_ml = zT_42;
    zT_46 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_ml);
    rn_ms = zT_46;
    zT_48 = "RN:m";
    zT_50 = 4;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    rnm = zT_49;
    zT_51 = rnm;
    zF_48AC7B3A_markerWrite(zT_51);
    zT_56 = (unsigned char*)((unsigned char*)rn_m) + rn_ms;
    zT_57 = (unsigned int)(19) - rn_ms;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_60[_i];
        _i++;
    }
}
    zT_62 = name_id;
    zT_66 = 0;
    zT_67 = (unsigned char*)((unsigned char*)rn_n) + zT_66;
    zT_68 = (unsigned int)(20) - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zT_70 = zF_A7504564_itoa(zT_62, zT_63);
    rn_nl = zT_70;
    zT_74 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_nl);
    rn_ns = zT_74;
    zT_76 = "n";
    zT_78 = 1;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    rnn = zT_77;
    zT_79 = rnn;
    zF_48AC7B3A_markerWrite(zT_79);
    zT_84 = (unsigned char*)((unsigned char*)rn_n) + rn_ns;
    zT_85 = (unsigned int)(19) - rn_ns;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zF_48AC7B3A_markerWrite(zT_80);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_88[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_88[_i];
        _i++;
    }
}
    zT_95 = 0;
    zT_96 = (unsigned char*)((unsigned char*)rn_k) + zT_95;
    zT_97 = (unsigned int)(20) - zT_95;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_91 = zT_98;
    zT_99 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_91);
    rn_kl = zT_99;
    zT_103 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_kl);
    rn_ks = zT_103;
    zT_105 = "k";
    zT_107 = 1;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rnk = zT_106;
    zT_108 = rnk;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_113 = (unsigned char*)((unsigned char*)rn_k) + rn_ks;
    zT_114 = (unsigned int)(19) - rn_ks;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_109 = zT_115;
    zF_48AC7B3A_markerWrite(zT_109);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_117[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_117[_i];
        _i++;
    }
}
    zT_119 = tid;
    zT_123 = 0;
    zT_124 = (unsigned char*)((unsigned char*)rn_t) + zT_123;
    zT_125 = (unsigned int)(20) - zT_123;
    zT_126.ptr = zT_124;
    zT_126.len = zT_125;
    zT_120 = zT_126;
    zT_127 = zF_A7504564_itoa(zT_119, zT_120);
    rn_tl = zT_127;
    zT_131 = (unsigned int)(19) - (unsigned int)((unsigned int)rn_tl);
    rn_ts = zT_131;
    zT_133 = "t";
    zT_135 = 1;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    rnt = zT_134;
    zT_136 = rnt;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_141 = (unsigned char*)((unsigned char*)rn_t) + rn_ts;
    zT_142 = (unsigned int)(19) - rn_ts;
    zT_143.ptr = zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zF_48AC7B3A_markerWrite(zT_137);
    zT_145 = "\n";
    zT_147 = 1;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    rnnl = zT_146;
    zT_148 = rnnl;
    zF_48AC7B3A_markerWrite(zT_148);
    return tid;
}

/* isValueDependency */
int zF_2FA4221F_isValueDependency(zT_33EF6BFB_TypeKind kind) {
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
int zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    return (int)(0);
}

/* typeRegistryIsInteger */
int zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    return (int)(0);
}

/* typeRegistryIsUnsigned */
int zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    return (int)(0);
}

/* typeRegistryIsPointer */
int zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_8;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
int zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type));
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((int)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_8 = zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((int)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((int)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    if ((int)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    if ((int)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    if ((int)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
int zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type));
}

/* typeRegistryIsErrorSet */
int zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (int)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsPacked */
int zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    return (int)((unsigned char)(zT_14 & (unsigned char)(16)) != (unsigned char)(0));
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_10;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    zT_33EF6BFB_TypeKind zT_61;
    int zT_64;
    unsigned char zT_65;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    unsigned int zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_E276DDD0_PackedBitField zT_80;
    zT_E276DDD0_PackedBitField zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    zT_FA398D58_PackedStructInfo zT_88;
    zT_FA398D58_PackedStructInfo zT_90;
    unsigned short zT_91;
    unsigned int zT_96;
    unsigned int zT_99;
    zT_D155D06D_Type* zT_101;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((int)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    if ((int)((unsigned char)(zT_10 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    if ((int)(fi < fcount)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = fstart + fi;
    zT_46 = zT_44[zT_45];
    fe = zT_46;
    zT_48 = 1;
    w = zT_48;
    zT_49 = fe.type_id;
    zT_50 = self->types_len;
    if ((int)(zT_49 < (unsigned int)((unsigned int)zT_50))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_86 = self;
    zT_87 = ty.payload_idx;
    zT_90.pk_start = pk_start;
    zT_91 = (unsigned short)fcount;
    zT_90.pk_count = zT_91;
    zT_90.total_bits = total_bits;
    zT_88 = zT_90;
    zF_41767D71_pkSetFields(zT_86, zT_87, zT_88);
    zT_96 = (unsigned int)(total_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_96;
    if ((int)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_84 = 1;
    zT_85 = fi + zT_84;
    fi = zT_85;
    goto z_bb_9;
    z_bb_13:
    zT_54 = self->types_items;
    zT_55 = fe.type_id;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    ft = zT_57;
    zT_58 = ft.kind;
    if ((int)(zT_58 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_79 = self;
    zT_81.bit_offset = total_bits;
    zT_82 = (unsigned short)w;
    zT_81.bit_width = zT_82;
    zT_80 = zT_81;
    zF_E48D8B88_pkFieldAppend(zT_79, zT_80);
    zT_83 = total_bits + w;
    total_bits = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_61 = ft.kind;
    if ((int)(zT_61 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_65 = ft.flags;
    zT_64 = (unsigned char)(zT_65 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_19;
    z_bb_18:
    zT_64 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_70 = self;
    zT_71 = fe.type_id;
    zT_73 = zF_CB27DBA4_typeRegistryGetPack(zT_70, zT_71);
    w = zT_73;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_74 = self;
    zT_75 = fe.type_id;
    zT_77 = zF_655972D5_typeRegistryIntWidt(zT_74, zT_75);
    zT_78 = (unsigned int)zT_77;
    w = zT_78;
    goto z_bb_21;
    z_bb_23:
    zT_99 = 1;
    sz = zT_99;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_101 = self->types_items;
    zT_101[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
int zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_E276DDD0_PackedBitField* zT_46;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_50;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_15 = ty.flags;
    if ((int)((unsigned char)(zT_15 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    if ((int)(zT_21 >= (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_28 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_26) >= zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    zT_43 = self->pk_len;
    if ((int)((unsigned int)(pstart + pcount) > zT_43)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_46 = self->pk_items;
    zT_48 = zT_46 + pstart;
    zT_49 = (unsigned int)(pstart + pcount) - pstart;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    *out = zT_50;
    return (int)(1);
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    if ((int)((unsigned char)(zT_14 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    if ((int)(zT_20 >= (unsigned int)((unsigned int)zT_21))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_27 = self->pk_struct_len;
    if ((int)((unsigned int)((unsigned int)zT_25) >= zT_27)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(0);
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.flags;
    ty.flags = (unsigned char)(zT_6 | (unsigned char)(16));
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    zT_2DF01B61_FieldEntry zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D155D06D_Type zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    zT_33EF6BFB_TypeKind zT_56;
    int zT_59;
    unsigned char zT_60;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_E276DDD0_PackedBitField zT_75;
    zT_E276DDD0_PackedBitField zT_76;
    unsigned int zT_77;
    unsigned short zT_78;
    int zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    zT_FA398D58_PackedStructInfo zT_84;
    zT_FA398D58_PackedStructInfo zT_86;
    unsigned short zT_87;
    unsigned int zT_92;
    unsigned int zT_95;
    zT_D155D06D_Type* zT_97;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((int)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    if ((int)(zT_10 >= (unsigned int)((unsigned int)zT_11))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    if ((int)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = fstart + fi;
    zT_41 = zT_39[zT_40];
    fe = zT_41;
    zT_43 = 1;
    w = zT_43;
    zT_44 = fe.type_id;
    zT_45 = self->types_len;
    if ((int)(zT_44 < (unsigned int)((unsigned int)zT_45))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_82 = self;
    zT_83 = ty.payload_idx;
    zT_86.pk_start = pk_start;
    zT_87 = (unsigned short)fcount;
    zT_86.pk_count = zT_87;
    zT_86.total_bits = max_bits;
    zT_84 = zT_86;
    zF_0213D00C_pkUnSetFields(zT_82, zT_83, zT_84);
    zT_92 = (unsigned int)(max_bits + (unsigned int)(7)) / (unsigned int)(8);
    sz = zT_92;
    if ((int)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_80 = 1;
    zT_81 = fi + zT_80;
    fi = zT_81;
    goto z_bb_7;
    z_bb_11:
    zT_49 = self->types_items;
    zT_50 = fe.type_id;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    ft = zT_52;
    zT_53 = ft.kind;
    if ((int)(zT_53 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_74 = self;
    zT_77 = 0;
    zT_76.bit_offset = zT_77;
    zT_78 = (unsigned short)w;
    zT_76.bit_width = zT_78;
    zT_75 = zT_76;
    zF_E48D8B88_pkFieldAppend(zT_74, zT_75);
    if ((int)(w > max_bits)) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_56 = ft.kind;
    if ((int)(zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_60 = ft.flags;
    zT_59 = (unsigned char)(zT_60 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_17;
    z_bb_16:
    zT_59 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_59) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_65 = self;
    zT_66 = fe.type_id;
    zT_68 = zF_CB27DBA4_typeRegistryGetPack(zT_65, zT_66);
    w = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_69 = self;
    zT_70 = fe.type_id;
    zT_72 = zF_655972D5_typeRegistryIntWidt(zT_69, zT_70);
    zT_73 = (unsigned int)zT_72;
    w = zT_73;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_95 = 1;
    sz = zT_95;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned int)(1);
    zT_97 = self->types_items;
    zT_97[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
int zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_E276DDD0_PackedBitField* zT_40;
    zT_E276DDD0_PackedBitField* zT_42;
    unsigned int zT_43;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_44;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    if ((int)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_22 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_20) >= zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    zT_37 = self->pk_len;
    if ((int)((unsigned int)(pstart + pcount) > zT_37)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_40 = self->pk_items;
    zT_42 = zT_40 + pstart;
    zT_43 = (unsigned int)(pstart + pcount) - pstart;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    *out = zT_44;
    return (int)(1);
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    if ((int)(zT_14 >= (unsigned int)((unsigned int)zT_15))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_un_len;
    if ((int)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_18 = zT_16 + fstart;
    zT_19 = (unsigned int)(fstart + fcount) - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* pointerQualifiersMonotone */
int zF_08C13644_pointerQualifiersMo(unsigned char src_flags, unsigned char tgt_flags, unsigned char mask) {
    return (int)((unsigned char)((unsigned char)(src_flags & mask) & (unsigned char)(~(unsigned char)(tgt_flags & mask))) == (unsigned char)(0));
}

/* typeRegistryIsAssignable */
int zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_16;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    int zT_19 = 0;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    unsigned int zT_29;
    int zT_30 = 0;
    int zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    int zT_34 = 0;
    int zT_35;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    int zT_40 = 0;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    int zT_43 = 0;
    int zT_45;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned char zT_48 = 0;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_51 = 0;
    int zT_56;
    zT_33EF6BFB_TypeKind zT_60;
    zT_338B7C76_TypeRegistry* zT_63;
    unsigned int zT_64;
    int zT_65 = 0;
    zT_33EF6BFB_TypeKind zT_67;
    zT_33EF6BFB_TypeKind zT_71;
    zT_33EF6BFB_TypeKind zT_75;
    int zT_78;
    zT_33EF6BFB_TypeKind zT_79;
    zT_112BF819_PtrPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_112BF819_PtrPayload zT_86;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    zT_0317B1D5_FnPayload* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_0317B1D5_FnPayload zT_99;
    zT_0317B1D5_FnPayload* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_0317B1D5_FnPayload zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_108;
    unsigned short zT_109;
    unsigned short zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    int zT_116;
    unsigned char zT_117;
    unsigned char zT_120;
    int zT_124;
    unsigned char zT_125;
    unsigned char zT_128;
    int zT_133;
    int zT_135;
    unsigned short zT_136;
    unsigned short zT_137;
    unsigned int* zT_139;
    unsigned int zT_140;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int* zT_145;
    unsigned int zT_146;
    unsigned int zT_149;
    unsigned int zT_150;
    int zT_152;
    int zT_153;
    unsigned int zT_154;
    zT_33EF6BFB_TypeKind zT_156;
    zT_0B10E8E9_OptionalPayload* zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    zT_0B10E8E9_OptionalPayload zT_163;
    zT_338B7C76_TypeRegistry* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    int zT_168 = 0;
    zT_33EF6BFB_TypeKind zT_170;
    zT_33EF6BFB_TypeKind zT_174;
    int zT_177;
    zT_33EF6BFB_TypeKind zT_178;
    zT_42C2D6BF_EUPayload* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_42C2D6BF_EUPayload zT_185;
    zT_42C2D6BF_EUPayload* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_42C2D6BF_EUPayload zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    zT_338B7C76_TypeRegistry* zT_194;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_33EF6BFB_TypeKind zT_200;
    zT_42C2D6BF_EUPayload* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    zT_42C2D6BF_EUPayload zT_207;
    zT_338B7C76_TypeRegistry* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    int zT_212 = 0;
    zT_33EF6BFB_TypeKind zT_214;
    int zT_217;
    zT_33EF6BFB_TypeKind zT_218;
    zT_33EF6BFB_TypeKind zT_222;
    int zT_225;
    zT_33EF6BFB_TypeKind zT_226;
    zT_112BF819_PtrPayload* zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    zT_112BF819_PtrPayload zT_233;
    zT_112BF819_PtrPayload* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_112BF819_PtrPayload zT_238;
    unsigned char zT_240;
    unsigned char zT_241;
    unsigned char zT_242;
    unsigned int zT_245;
    int zT_246 = 0;
    unsigned int zT_247;
    unsigned int zT_250;
    unsigned char zT_253;
    int zT_258;
    unsigned char zT_259;
    unsigned int zT_264;
    unsigned int zT_265;
    int zT_267;
    unsigned char zT_269;
    int zT_274;
    unsigned char zT_275;
    unsigned int zT_280;
    unsigned int zT_281;
    int zT_283;
    unsigned char zT_284;
    int zT_289;
    unsigned char zT_290;
    zT_33EF6BFB_TypeKind zT_296;
    int zT_299;
    zT_33EF6BFB_TypeKind zT_300;
    unsigned char zT_304;
    unsigned char zT_305;
    unsigned char zT_306;
    unsigned int zT_309;
    int zT_310 = 0;
    unsigned char zT_311;
    int zT_316;
    unsigned char zT_317;
    zT_0BB2A741_SlicePayload* zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    zT_0BB2A741_SlicePayload zT_326;
    zT_0BB2A741_SlicePayload* zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    zT_0BB2A741_SlicePayload zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    int zT_335;
    unsigned char zT_337;
    int zT_342;
    unsigned char zT_343;
    zT_0BB2A741_SlicePayload* zT_349;
    unsigned int zT_350;
    unsigned int zT_351;
    zT_0BB2A741_SlicePayload zT_352;
    zT_0BB2A741_SlicePayload* zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    zT_0BB2A741_SlicePayload zT_357;
    unsigned int zT_358;
    unsigned int zT_359;
    int zT_361;
    unsigned char zT_362;
    int zT_367;
    unsigned char zT_368;
    zT_33EF6BFB_TypeKind zT_374;
    int zT_377;
    zT_33EF6BFB_TypeKind zT_378;
    unsigned char zT_382;
    unsigned char zT_383;
    unsigned char zT_384;
    unsigned int zT_387;
    int zT_388 = 0;
    zT_112BF819_PtrPayload* zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    zT_112BF819_PtrPayload zT_393;
    zT_0BB2A741_SlicePayload* zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    zT_0BB2A741_SlicePayload zT_398;
    zT_D155D06D_Type* zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    zT_D155D06D_Type zT_403;
    zT_33EF6BFB_TypeKind zT_404;
    zT_E834303C_ArrayPayload* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_E834303C_ArrayPayload zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    int zT_415;
    unsigned int zT_417;
    unsigned int zT_418;
    int zT_420;
    unsigned int zT_422;
    int zT_425;
    unsigned int zT_426;
    int zT_429;
    unsigned int zT_431;
    int zT_434;
    unsigned int zT_435;
    int zT_438;
    zT_33EF6BFB_TypeKind zT_440;
    int zT_443;
    zT_33EF6BFB_TypeKind zT_444;
    unsigned char zT_448;
    unsigned char zT_449;
    unsigned char zT_450;
    unsigned int zT_453;
    int zT_454 = 0;
    unsigned char zT_455;
    int zT_460;
    unsigned char zT_461;
    zT_112BF819_PtrPayload* zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_112BF819_PtrPayload zT_470;
    zT_112BF819_PtrPayload* zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    zT_112BF819_PtrPayload zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    int zT_479;
    unsigned char zT_481;
    int zT_486;
    unsigned char zT_487;
    zT_112BF819_PtrPayload* zT_493;
    unsigned int zT_494;
    unsigned int zT_495;
    zT_112BF819_PtrPayload zT_496;
    zT_112BF819_PtrPayload* zT_498;
    unsigned int zT_499;
    unsigned int zT_500;
    zT_112BF819_PtrPayload zT_501;
    unsigned int zT_502;
    unsigned int zT_503;
    int zT_505;
    unsigned char zT_506;
    int zT_511;
    unsigned char zT_512;
    zT_33EF6BFB_TypeKind zT_518;
    int zT_521;
    zT_33EF6BFB_TypeKind zT_522;
    unsigned char zT_526;
    unsigned char zT_527;
    unsigned char zT_528;
    unsigned int zT_531;
    int zT_532 = 0;
    zT_112BF819_PtrPayload* zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    zT_112BF819_PtrPayload zT_537;
    zT_0BB2A741_SlicePayload* zT_539;
    unsigned int zT_540;
    unsigned int zT_541;
    zT_0BB2A741_SlicePayload zT_542;
    unsigned int zT_543;
    unsigned int zT_544;
    int zT_546;
    unsigned int zT_548;
    int zT_551;
    unsigned int zT_552;
    int zT_555;
    int zT_556;
    unsigned int zT_557;
    int zT_560;
    unsigned int zT_561;
    int zT_564;
    zT_33EF6BFB_TypeKind zT_566;
    int zT_569;
    zT_33EF6BFB_TypeKind zT_570;
    unsigned char zT_574;
    unsigned char zT_575;
    unsigned char zT_576;
    unsigned int zT_579;
    int zT_580 = 0;
    zT_E834303C_ArrayPayload* zT_582;
    unsigned int zT_583;
    unsigned int zT_584;
    zT_E834303C_ArrayPayload zT_585;
    zT_0BB2A741_SlicePayload* zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    zT_0BB2A741_SlicePayload zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    int zT_594;
    unsigned char zT_596;
    int zT_601;
    unsigned int zT_602;
    unsigned int zT_603;
    int zT_605;
    zT_33EF6BFB_TypeKind zT_607;
    int zT_610;
    zT_33EF6BFB_TypeKind zT_611;
    unsigned char zT_615;
    unsigned char zT_616;
    unsigned char zT_617;
    unsigned int zT_620;
    int zT_621 = 0;
    zT_E834303C_ArrayPayload* zT_623;
    unsigned int zT_624;
    unsigned int zT_625;
    zT_E834303C_ArrayPayload zT_626;
    zT_112BF819_PtrPayload* zT_628;
    unsigned int zT_629;
    unsigned int zT_630;
    zT_112BF819_PtrPayload zT_631;
    unsigned int zT_632;
    unsigned int zT_633;
    int zT_635;
    zT_33EF6BFB_TypeKind zT_637;
    int zT_640;
    zT_33EF6BFB_TypeKind zT_641;
    unsigned char zT_645;
    unsigned char zT_646;
    unsigned char zT_647;
    unsigned int zT_650;
    int zT_651 = 0;
    zT_112BF819_PtrPayload* zT_653;
    unsigned int zT_654;
    unsigned int zT_655;
    zT_112BF819_PtrPayload zT_656;
    zT_112BF819_PtrPayload* zT_658;
    unsigned int zT_659;
    unsigned int zT_660;
    zT_112BF819_PtrPayload zT_661;
    zT_D155D06D_Type* zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    zT_D155D06D_Type zT_666;
    zT_33EF6BFB_TypeKind zT_667;
    zT_E834303C_ArrayPayload* zT_671;
    unsigned int zT_672;
    unsigned int zT_673;
    zT_E834303C_ArrayPayload zT_674;
    unsigned int zT_675;
    unsigned int zT_676;
    int zT_678;
    zT_33EF6BFB_TypeKind zT_680;
    int zT_683;
    zT_33EF6BFB_TypeKind zT_684;
    zT_E834303C_ArrayPayload* zT_688;
    unsigned int zT_689;
    unsigned int zT_690;
    zT_E834303C_ArrayPayload zT_691;
    zT_E834303C_ArrayPayload* zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    zT_E834303C_ArrayPayload zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    int zT_700;
    unsigned int zT_701;
    unsigned int zT_702;
    zT_33EF6BFB_TypeKind zT_705;
    int zT_708;
    zT_33EF6BFB_TypeKind zT_709;
    unsigned char zT_713;
    unsigned char zT_714;
    unsigned char zT_715;
    unsigned int zT_718;
    int zT_719 = 0;
    zT_0BB2A741_SlicePayload* zT_721;
    unsigned int zT_722;
    unsigned int zT_723;
    zT_0BB2A741_SlicePayload zT_724;
    zT_112BF819_PtrPayload* zT_726;
    unsigned int zT_727;
    unsigned int zT_728;
    zT_112BF819_PtrPayload zT_729;
    unsigned int zT_730;
    unsigned int zT_731;
    int zT_733;
    zT_33EF6BFB_TypeKind zT_735;
    int zT_738;
    zT_33EF6BFB_TypeKind zT_739;
    zT_0B10E8E9_OptionalPayload* zT_743;
    unsigned int zT_744;
    unsigned int zT_745;
    zT_0B10E8E9_OptionalPayload zT_746;
    zT_D155D06D_Type* zT_748;
    unsigned int zT_749;
    unsigned int zT_750;
    zT_D155D06D_Type zT_751;
    zT_33EF6BFB_TypeKind zT_752;
    zT_338B7C76_TypeRegistry* zT_755;
    unsigned int zT_756;
    unsigned int zT_758;
    int zT_762;
    int zT_765;
    int zT_768;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0317B1D5_FnPayload src_f;
    zT_0317B1D5_FnPayload tgt_f;
    int ok;
    unsigned short fi;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    int qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload s_sl2;
    zT_0BB2A741_SlicePayload t_sl2;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload s_pp2;
    zT_112BF819_PtrPayload t_pp2;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_112BF819_PtrPayload pp;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_D155D06D_Type opt_ty;
    z_bb_0:
    if ((int)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self;
    zT_18 = target;
    zT_19 = zF_3087E0A5_typeRegistryIsNumer(zT_17, zT_18);
    zT_16 = zT_19;
    goto z_bb_5;
    z_bb_4:
    zT_16 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (int)(1);
    z_bb_7:
    zT_21 = src.kind;
    if ((int)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = target == (unsigned int)(14);
    goto z_bb_10;
    z_bb_9:
    zT_24 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_24) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_28 = self;
    zT_29 = source;
    zT_30 = zF_3290E9C4_typeRegistryIsInteg(zT_28, zT_29);
    if (zT_30) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_32 = self;
    zT_33 = target;
    zT_34 = zF_3290E9C4_typeRegistryIsInteg(zT_32, zT_33);
    zT_31 = zT_34;
    goto z_bb_15;
    z_bb_14:
    zT_31 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_31) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_35 = source != (unsigned int)(19);
    goto z_bb_18;
    z_bb_17:
    zT_35 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_35) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_38 = self;
    zT_39 = source;
    zT_40 = zF_B664AC19_typeRegistryIsUnsig(zT_38, zT_39);
    zT_41 = self;
    zT_42 = target;
    zT_43 = zF_B664AC19_typeRegistryIsUnsig(zT_41, zT_42);
    if ((int)(zT_40 == zT_43)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    if ((int)(source == (unsigned int)(15))) goto z_bb_26; else goto z_bb_27;
    z_bb_21:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_655972D5_typeRegistryIntWidt(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_655972D5_typeRegistryIntWidt(zT_49, zT_50);
    zT_45 = zT_48 < zT_51;
    goto z_bb_23;
    z_bb_22:
    zT_45 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_45) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (int)(1);
    z_bb_25:
    goto z_bb_20;
    z_bb_26:
    zT_56 = target == (unsigned int)(16);
    goto z_bb_28;
    z_bb_27:
    zT_56 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_56) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    zT_60 = src.kind;
    if ((int)(zT_60 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_63 = self;
    zT_64 = target;
    zT_65 = zF_AD61DB1B_typeRegistryIsPoint(zT_63, zT_64);
    if (zT_65) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_75 = src.kind;
    if ((int)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_33:
    return (int)(1);
    z_bb_34:
    zT_67 = tgt.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (int)(1);
    z_bb_36:
    zT_71 = tgt.kind;
    if ((int)(zT_71 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    goto z_bb_32;
    z_bb_39:
    zT_79 = tgt.kind;
    zT_78 = zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_41;
    z_bb_40:
    zT_78 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_78) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_83 = self->ptr_items;
    zT_84 = tgt.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    tpp = zT_86;
    zT_88 = self->types_items;
    zT_89 = tpp.base;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    bt = zT_91;
    zT_92 = bt.kind;
    if ((int)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_156 = tgt.kind;
    if ((int)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_68; else goto z_bb_69;
    z_bb_44:
    zT_96 = self->fn_items;
    zT_97 = src.payload_idx;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    src_f = zT_99;
    zT_101 = self->fn_items;
    zT_102 = bt.payload_idx;
    zT_103 = (unsigned int)zT_102;
    zT_104 = zT_101[zT_103];
    tgt_f = zT_104;
    zT_105 = src_f.return_type;
    zT_106 = tgt_f.return_type;
    if ((int)(zT_105 == zT_106)) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_43;
    z_bb_46:
    zT_109 = src_f.params_count;
    zT_110 = tgt_f.params_count;
    zT_108 = zT_109 == zT_110;
    goto z_bb_48;
    z_bb_47:
    zT_108 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_108) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_113 = src_f.is_extern;
    zT_114 = tgt_f.is_extern;
    zT_112 = zT_113 == zT_114;
    goto z_bb_51;
    z_bb_50:
    zT_112 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_112) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_117 = src_f.flags_packed;
    zT_120 = tgt_f.flags_packed;
    zT_116 = (unsigned char)(zT_117 & (unsigned char)(1)) == (unsigned char)(zT_120 & (unsigned char)(1));
    goto z_bb_54;
    z_bb_53:
    zT_116 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_116) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_125 = src_f.flags_packed;
    zT_128 = tgt_f.flags_packed;
    zT_124 = (unsigned char)(zT_125 & (unsigned char)(2)) == (unsigned char)(zT_128 & (unsigned char)(2));
    goto z_bb_57;
    z_bb_56:
    zT_124 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_124) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_133 = 1;
    ok = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned short)zT_135;
    fi = zT_136;
    goto z_bb_60;
    z_bb_59:
    goto z_bb_45;
    z_bb_60:
    zT_137 = src_f.params_count;
    if ((int)(fi < zT_137)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_139 = self->xt_items;
    zT_140 = src_f.params_start;
    zT_143 = (unsigned int)(unsigned int)(zT_140 + (unsigned int)((unsigned int)fi));
    zT_144 = zT_139[zT_143];
    zT_145 = self->xt_items;
    zT_146 = tgt_f.params_start;
    zT_149 = (unsigned int)(unsigned int)(zT_146 + (unsigned int)((unsigned int)fi));
    zT_150 = zT_145[zT_149];
    if ((int)(zT_144 != zT_150)) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    if (ok) goto z_bb_66; else goto z_bb_67;
    z_bb_63:
    zT_153 = 1;
    zT_154 = fi + zT_153;
    fi = zT_154;
    goto z_bb_60;
    z_bb_64:
    zT_152 = 0;
    ok = zT_152;
    goto z_bb_62;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    return (int)(1);
    z_bb_67:
    goto z_bb_59;
    z_bb_68:
    zT_160 = self->opt_items;
    zT_161 = tgt.payload_idx;
    zT_162 = (unsigned int)zT_161;
    zT_163 = zT_160[zT_162];
    opt = zT_163;
    zT_164 = self;
    zT_165 = source;
    zT_166 = opt.payload;
    zT_168 = zF_683AEB7F_typeRegistryIsAssig(zT_164, zT_165, zT_166);
    if (zT_168) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    zT_174 = src.kind;
    if ((int)(zT_174 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_74; else goto z_bb_75;
    z_bb_70:
    return (int)(1);
    z_bb_71:
    zT_170 = src.kind;
    if ((int)(zT_170 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    return (int)(1);
    z_bb_73:
    goto z_bb_69;
    z_bb_74:
    zT_178 = tgt.kind;
    zT_177 = zT_178 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_76;
    z_bb_75:
    zT_177 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_177) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_182 = self->eu_items;
    zT_183 = src.payload_idx;
    zT_184 = (unsigned int)zT_183;
    zT_185 = zT_182[zT_184];
    eu_src = zT_185;
    zT_187 = self->eu_items;
    zT_188 = tgt.payload_idx;
    zT_189 = (unsigned int)zT_188;
    zT_190 = zT_187[zT_189];
    eu_tgt = zT_190;
    zT_191 = eu_src.error_set;
    zT_192 = eu_tgt.error_set;
    if ((int)(zT_191 == zT_192)) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    zT_200 = tgt.kind;
    if ((int)(zT_200 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_81; else goto z_bb_82;
    z_bb_79:
    zT_194 = self;
    zT_197 = eu_src.payload;
    zT_198 = eu_tgt.payload;
    self = zT_194;
    source = zT_197;
    target = zT_198;
    goto z_bb_0;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    zT_204 = self->eu_items;
    zT_205 = tgt.payload_idx;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_204[zT_206];
    eu = zT_207;
    zT_208 = self;
    zT_209 = source;
    zT_210 = eu.payload;
    zT_212 = zF_683AEB7F_typeRegistryIsAssig(zT_208, zT_209, zT_210);
    if (zT_212) goto z_bb_83; else goto z_bb_84;
    z_bb_82:
    zT_214 = src.kind;
    if ((int)(zT_214 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_85; else goto z_bb_86;
    z_bb_83:
    return (int)(1);
    z_bb_84:
    goto z_bb_82;
    z_bb_85:
    zT_218 = tgt.kind;
    zT_217 = zT_218 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_87;
    z_bb_86:
    zT_217 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_217) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    return (int)(1);
    z_bb_89:
    zT_222 = src.kind;
    if ((int)(zT_222 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_226 = tgt.kind;
    zT_225 = zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_92;
    z_bb_91:
    zT_225 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_225) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_230 = self->ptr_items;
    zT_231 = tgt.payload_idx;
    zT_232 = (unsigned int)zT_231;
    zT_233 = zT_230[zT_232];
    tgt_pp = zT_233;
    zT_235 = self->ptr_items;
    zT_236 = src.payload_idx;
    zT_237 = (unsigned int)zT_236;
    zT_238 = zT_235[zT_237];
    src_pp = zT_238;
    zT_240 = src.flags;
    zT_241 = tgt.flags;
    zT_245 = 2;
    zT_242 = zT_245;
    zT_246 = zF_08C13644_pointerQualifiersMo(zT_240, zT_241, zT_242);
    qok = zT_246;
    zT_247 = tgt_pp.base;
    if ((int)(zT_247 == (unsigned int)(1))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    zT_296 = tgt.kind;
    if ((int)(zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_122; else goto z_bb_123;
    z_bb_95:
    return qok;
    z_bb_96:
    zT_250 = src_pp.base;
    if ((int)(zT_250 == (unsigned int)(1))) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    return qok;
    z_bb_98:
    zT_253 = tgt.flags;
    if ((int)((unsigned char)(zT_253 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_259 = src.flags;
    zT_258 = (unsigned char)(zT_259 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_101;
    z_bb_100:
    zT_258 = 0;
    goto z_bb_101;
    z_bb_101:
    if (zT_258) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_264 = src_pp.base;
    zT_265 = tgt_pp.base;
    if ((int)(zT_264 == zT_265)) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    zT_269 = tgt.flags;
    if ((int)((unsigned char)(zT_269 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_104:
    zT_267 = qok;
    goto z_bb_106;
    z_bb_105:
    zT_267 = 0;
    goto z_bb_106;
    z_bb_106:
    if (zT_267) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    return (int)(1);
    z_bb_108:
    goto z_bb_103;
    z_bb_109:
    zT_275 = src.flags;
    zT_274 = (unsigned char)(zT_275 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_111;
    z_bb_110:
    zT_274 = 0;
    goto z_bb_111;
    z_bb_111:
    if (zT_274) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_280 = src_pp.base;
    zT_281 = tgt_pp.base;
    if ((int)(zT_280 == zT_281)) goto z_bb_114; else goto z_bb_115;
    z_bb_113:
    goto z_bb_94;
    z_bb_114:
    zT_284 = src.flags;
    if ((int)((unsigned char)(zT_284 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_118; else goto z_bb_117;
    z_bb_115:
    zT_283 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_283) goto z_bb_120; else goto z_bb_121;
    z_bb_117:
    zT_290 = tgt.flags;
    zT_289 = (unsigned char)(zT_290 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_119;
    z_bb_118:
    zT_289 = 1;
    goto z_bb_119;
    z_bb_119:
    zT_283 = zT_289;
    goto z_bb_116;
    z_bb_120:
    return (int)(1);
    z_bb_121:
    goto z_bb_113;
    z_bb_122:
    zT_300 = src.kind;
    zT_299 = zT_300 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_124;
    z_bb_123:
    zT_299 = 0;
    goto z_bb_124;
    z_bb_124:
    if (zT_299) goto z_bb_125; else goto z_bb_126;
    z_bb_125:
    zT_304 = src.flags;
    zT_305 = tgt.flags;
    zT_309 = 2;
    zT_306 = zT_309;
    zT_310 = zF_08C13644_pointerQualifiersMo(zT_304, zT_305, zT_306);
    qok = zT_310;
    zT_311 = tgt.flags;
    if ((int)((unsigned char)(zT_311 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_127; else goto z_bb_128;
    z_bb_126:
    zT_374 = tgt.kind;
    if ((int)(zT_374 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_150; else goto z_bb_151;
    z_bb_127:
    zT_317 = src.flags;
    zT_316 = (unsigned char)(zT_317 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_129;
    z_bb_128:
    zT_316 = 0;
    goto z_bb_129;
    z_bb_129:
    if (zT_316) goto z_bb_130; else goto z_bb_131;
    z_bb_130:
    zT_323 = self->slice_items;
    zT_324 = src.payload_idx;
    zT_325 = (unsigned int)zT_324;
    zT_326 = zT_323[zT_325];
    s_sl = zT_326;
    zT_328 = self->slice_items;
    zT_329 = tgt.payload_idx;
    zT_330 = (unsigned int)zT_329;
    zT_331 = zT_328[zT_330];
    t_sl = zT_331;
    zT_332 = s_sl.elem;
    zT_333 = t_sl.elem;
    if ((int)(zT_332 == zT_333)) goto z_bb_132; else goto z_bb_133;
    z_bb_131:
    zT_337 = tgt.flags;
    if ((int)((unsigned char)(zT_337 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_137; else goto z_bb_138;
    z_bb_132:
    zT_335 = qok;
    goto z_bb_134;
    z_bb_133:
    zT_335 = 0;
    goto z_bb_134;
    z_bb_134:
    if (zT_335) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    return (int)(1);
    z_bb_136:
    goto z_bb_131;
    z_bb_137:
    zT_343 = src.flags;
    zT_342 = (unsigned char)(zT_343 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_139;
    z_bb_138:
    zT_342 = 0;
    goto z_bb_139;
    z_bb_139:
    if (zT_342) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    zT_349 = self->slice_items;
    zT_350 = src.payload_idx;
    zT_351 = (unsigned int)zT_350;
    zT_352 = zT_349[zT_351];
    s_sl2 = zT_352;
    zT_354 = self->slice_items;
    zT_355 = tgt.payload_idx;
    zT_356 = (unsigned int)zT_355;
    zT_357 = zT_354[zT_356];
    t_sl2 = zT_357;
    zT_358 = s_sl2.elem;
    zT_359 = t_sl2.elem;
    if ((int)(zT_358 == zT_359)) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_126;
    z_bb_142:
    zT_362 = src.flags;
    if ((int)((unsigned char)(zT_362 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_146; else goto z_bb_145;
    z_bb_143:
    zT_361 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_361) goto z_bb_148; else goto z_bb_149;
    z_bb_145:
    zT_368 = tgt.flags;
    zT_367 = (unsigned char)(zT_368 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_147;
    z_bb_146:
    zT_367 = 1;
    goto z_bb_147;
    z_bb_147:
    zT_361 = zT_367;
    goto z_bb_144;
    z_bb_148:
    return (int)(1);
    z_bb_149:
    goto z_bb_141;
    z_bb_150:
    zT_378 = src.kind;
    zT_377 = zT_378 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_152;
    z_bb_151:
    zT_377 = 0;
    goto z_bb_152;
    z_bb_152:
    if (zT_377) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_382 = src.flags;
    zT_383 = tgt.flags;
    zT_387 = 2;
    zT_384 = zT_387;
    zT_388 = zF_08C13644_pointerQualifiersMo(zT_382, zT_383, zT_384);
    qok = zT_388;
    zT_390 = self->ptr_items;
    zT_391 = src.payload_idx;
    zT_392 = (unsigned int)zT_391;
    zT_393 = zT_390[zT_392];
    src_pp = zT_393;
    zT_395 = self->slice_items;
    zT_396 = tgt.payload_idx;
    zT_397 = (unsigned int)zT_396;
    zT_398 = zT_395[zT_397];
    sl = zT_398;
    zT_400 = self->types_items;
    zT_401 = src_pp.base;
    zT_402 = (unsigned int)zT_401;
    zT_403 = zT_400[zT_402];
    src_pointee = zT_403;
    zT_404 = src_pointee.kind;
    if ((int)(zT_404 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_155; else goto z_bb_156;
    z_bb_154:
    zT_440 = tgt.kind;
    if ((int)(zT_440 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_183; else goto z_bb_184;
    z_bb_155:
    zT_408 = self->array_items;
    zT_409 = src_pointee.payload_idx;
    zT_410 = (unsigned int)zT_409;
    zT_411 = zT_408[zT_410];
    arr = zT_411;
    zT_412 = arr.elem;
    zT_413 = sl.elem;
    if ((int)(zT_412 == zT_413)) goto z_bb_157; else goto z_bb_158;
    z_bb_156:
    zT_417 = src_pp.base;
    zT_418 = sl.elem;
    if ((int)(zT_417 == zT_418)) goto z_bb_162; else goto z_bb_163;
    z_bb_157:
    zT_415 = qok;
    goto z_bb_159;
    z_bb_158:
    zT_415 = 0;
    goto z_bb_159;
    z_bb_159:
    if (zT_415) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    return (int)(1);
    z_bb_161:
    goto z_bb_156;
    z_bb_162:
    zT_420 = qok;
    goto z_bb_164;
    z_bb_163:
    zT_420 = 0;
    goto z_bb_164;
    z_bb_164:
    if (zT_420) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    return (int)(1);
    z_bb_166:
    zT_422 = src_pp.base;
    if ((int)(zT_422 == (unsigned int)(14))) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_426 = sl.elem;
    zT_425 = zT_426 == (unsigned int)(8);
    goto z_bb_169;
    z_bb_168:
    zT_425 = 0;
    goto z_bb_169;
    z_bb_169:
    if (zT_425) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    zT_429 = qok;
    goto z_bb_172;
    z_bb_171:
    zT_429 = 0;
    goto z_bb_172;
    z_bb_172:
    if (zT_429) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    return (int)(1);
    z_bb_174:
    zT_431 = src_pp.base;
    if ((int)(zT_431 == (unsigned int)(8))) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    zT_435 = sl.elem;
    zT_434 = zT_435 == (unsigned int)(14);
    goto z_bb_177;
    z_bb_176:
    zT_434 = 0;
    goto z_bb_177;
    z_bb_177:
    if (zT_434) goto z_bb_178; else goto z_bb_179;
    z_bb_178:
    zT_438 = qok;
    goto z_bb_180;
    z_bb_179:
    zT_438 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_438) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    return (int)(1);
    z_bb_182:
    goto z_bb_154;
    z_bb_183:
    zT_444 = src.kind;
    zT_443 = zT_444 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_185;
    z_bb_184:
    zT_443 = 0;
    goto z_bb_185;
    z_bb_185:
    if (zT_443) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_448 = src.flags;
    zT_449 = tgt.flags;
    zT_453 = 2;
    zT_450 = zT_453;
    zT_454 = zF_08C13644_pointerQualifiersMo(zT_448, zT_449, zT_450);
    qok = zT_454;
    zT_455 = tgt.flags;
    if ((int)((unsigned char)(zT_455 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_188; else goto z_bb_189;
    z_bb_187:
    zT_518 = src.kind;
    if ((int)(zT_518 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_211; else goto z_bb_212;
    z_bb_188:
    zT_461 = src.flags;
    zT_460 = (unsigned char)(zT_461 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_190;
    z_bb_189:
    zT_460 = 0;
    goto z_bb_190;
    z_bb_190:
    if (zT_460) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_467 = self->ptr_items;
    zT_468 = src.payload_idx;
    zT_469 = (unsigned int)zT_468;
    zT_470 = zT_467[zT_469];
    s_pp = zT_470;
    zT_472 = self->ptr_items;
    zT_473 = tgt.payload_idx;
    zT_474 = (unsigned int)zT_473;
    zT_475 = zT_472[zT_474];
    t_pp = zT_475;
    zT_476 = s_pp.base;
    zT_477 = t_pp.base;
    if ((int)(zT_476 == zT_477)) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    zT_481 = tgt.flags;
    if ((int)((unsigned char)(zT_481 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_198; else goto z_bb_199;
    z_bb_193:
    zT_479 = qok;
    goto z_bb_195;
    z_bb_194:
    zT_479 = 0;
    goto z_bb_195;
    z_bb_195:
    if (zT_479) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    return (int)(1);
    z_bb_197:
    goto z_bb_192;
    z_bb_198:
    zT_487 = src.flags;
    zT_486 = (unsigned char)(zT_487 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_200;
    z_bb_199:
    zT_486 = 0;
    goto z_bb_200;
    z_bb_200:
    if (zT_486) goto z_bb_201; else goto z_bb_202;
    z_bb_201:
    zT_493 = self->ptr_items;
    zT_494 = src.payload_idx;
    zT_495 = (unsigned int)zT_494;
    zT_496 = zT_493[zT_495];
    s_pp2 = zT_496;
    zT_498 = self->ptr_items;
    zT_499 = tgt.payload_idx;
    zT_500 = (unsigned int)zT_499;
    zT_501 = zT_498[zT_500];
    t_pp2 = zT_501;
    zT_502 = s_pp2.base;
    zT_503 = t_pp2.base;
    if ((int)(zT_502 == zT_503)) goto z_bb_203; else goto z_bb_204;
    z_bb_202:
    goto z_bb_187;
    z_bb_203:
    zT_506 = src.flags;
    if ((int)((unsigned char)(zT_506 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_207; else goto z_bb_206;
    z_bb_204:
    zT_505 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_505) goto z_bb_209; else goto z_bb_210;
    z_bb_206:
    zT_512 = tgt.flags;
    zT_511 = (unsigned char)(zT_512 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_208;
    z_bb_207:
    zT_511 = 1;
    goto z_bb_208;
    z_bb_208:
    zT_505 = zT_511;
    goto z_bb_205;
    z_bb_209:
    return (int)(1);
    z_bb_210:
    goto z_bb_202;
    z_bb_211:
    zT_522 = tgt.kind;
    zT_521 = zT_522 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_213;
    z_bb_212:
    zT_521 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_521) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    zT_526 = src.flags;
    zT_527 = tgt.flags;
    zT_531 = 2;
    zT_528 = zT_531;
    zT_532 = zF_08C13644_pointerQualifiersMo(zT_526, zT_527, zT_528);
    qok = zT_532;
    zT_534 = self->ptr_items;
    zT_535 = src.payload_idx;
    zT_536 = (unsigned int)zT_535;
    zT_537 = zT_534[zT_536];
    sp2 = zT_537;
    zT_539 = self->slice_items;
    zT_540 = tgt.payload_idx;
    zT_541 = (unsigned int)zT_540;
    zT_542 = zT_539[zT_541];
    ts2 = zT_542;
    zT_543 = sp2.base;
    zT_544 = ts2.elem;
    if ((int)(zT_543 == zT_544)) goto z_bb_216; else goto z_bb_217;
    z_bb_215:
    zT_566 = src.kind;
    if ((int)(zT_566 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_238; else goto z_bb_239;
    z_bb_216:
    zT_546 = qok;
    goto z_bb_218;
    z_bb_217:
    zT_546 = 0;
    goto z_bb_218;
    z_bb_218:
    if (zT_546) goto z_bb_219; else goto z_bb_220;
    z_bb_219:
    return (int)(1);
    z_bb_220:
    zT_548 = sp2.base;
    if ((int)(zT_548 == (unsigned int)(14))) goto z_bb_221; else goto z_bb_222;
    z_bb_221:
    zT_552 = ts2.elem;
    zT_551 = zT_552 == (unsigned int)(8);
    goto z_bb_223;
    z_bb_222:
    zT_551 = 0;
    goto z_bb_223;
    z_bb_223:
    if (zT_551) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    zT_555 = qok;
    goto z_bb_226;
    z_bb_225:
    zT_555 = 0;
    goto z_bb_226;
    z_bb_226:
    if (zT_555) goto z_bb_228; else goto z_bb_227;
    z_bb_227:
    zT_557 = sp2.base;
    if ((int)(zT_557 == (unsigned int)(8))) goto z_bb_230; else goto z_bb_231;
    z_bb_228:
    zT_556 = 1;
    goto z_bb_229;
    z_bb_229:
    if (zT_556) goto z_bb_236; else goto z_bb_237;
    z_bb_230:
    zT_561 = ts2.elem;
    zT_560 = zT_561 == (unsigned int)(14);
    goto z_bb_232;
    z_bb_231:
    zT_560 = 0;
    goto z_bb_232;
    z_bb_232:
    if (zT_560) goto z_bb_233; else goto z_bb_234;
    z_bb_233:
    zT_564 = qok;
    goto z_bb_235;
    z_bb_234:
    zT_564 = 0;
    goto z_bb_235;
    z_bb_235:
    zT_556 = zT_564;
    goto z_bb_229;
    z_bb_236:
    return (int)(1);
    z_bb_237:
    goto z_bb_215;
    z_bb_238:
    zT_570 = tgt.kind;
    zT_569 = zT_570 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_240;
    z_bb_239:
    zT_569 = 0;
    goto z_bb_240;
    z_bb_240:
    if (zT_569) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    zT_574 = src.flags;
    zT_575 = tgt.flags;
    zT_579 = 2;
    zT_576 = zT_579;
    zT_580 = zF_08C13644_pointerQualifiersMo(zT_574, zT_575, zT_576);
    qok = zT_580;
    zT_582 = self->array_items;
    zT_583 = src.payload_idx;
    zT_584 = (unsigned int)zT_583;
    zT_585 = zT_582[zT_584];
    arr = zT_585;
    zT_587 = self->slice_items;
    zT_588 = tgt.payload_idx;
    zT_589 = (unsigned int)zT_588;
    zT_590 = zT_587[zT_589];
    sl = zT_590;
    zT_591 = arr.elem;
    zT_592 = sl.elem;
    if ((int)(zT_591 == zT_592)) goto z_bb_243; else goto z_bb_244;
    z_bb_242:
    zT_607 = src.kind;
    if ((int)(zT_607 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_256; else goto z_bb_257;
    z_bb_243:
    zT_594 = qok;
    goto z_bb_245;
    z_bb_244:
    zT_594 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_594) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    return (int)(1);
    z_bb_247:
    zT_596 = tgt.flags;
    if ((int)((unsigned char)(zT_596 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_248; else goto z_bb_249;
    z_bb_248:
    zT_602 = arr.elem;
    zT_603 = sl.elem;
    zT_601 = zT_602 == zT_603;
    goto z_bb_250;
    z_bb_249:
    zT_601 = 0;
    goto z_bb_250;
    z_bb_250:
    if (zT_601) goto z_bb_251; else goto z_bb_252;
    z_bb_251:
    zT_605 = qok;
    goto z_bb_253;
    z_bb_252:
    zT_605 = 0;
    goto z_bb_253;
    z_bb_253:
    if (zT_605) goto z_bb_254; else goto z_bb_255;
    z_bb_254:
    return (int)(1);
    z_bb_255:
    goto z_bb_242;
    z_bb_256:
    zT_611 = tgt.kind;
    zT_610 = zT_611 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_258;
    z_bb_257:
    zT_610 = 0;
    goto z_bb_258;
    z_bb_258:
    if (zT_610) goto z_bb_259; else goto z_bb_260;
    z_bb_259:
    zT_615 = src.flags;
    zT_616 = tgt.flags;
    zT_620 = 2;
    zT_617 = zT_620;
    zT_621 = zF_08C13644_pointerQualifiersMo(zT_615, zT_616, zT_617);
    qok = zT_621;
    zT_623 = self->array_items;
    zT_624 = src.payload_idx;
    zT_625 = (unsigned int)zT_624;
    zT_626 = zT_623[zT_625];
    arr = zT_626;
    zT_628 = self->ptr_items;
    zT_629 = tgt.payload_idx;
    zT_630 = (unsigned int)zT_629;
    zT_631 = zT_628[zT_630];
    pp = zT_631;
    zT_632 = arr.elem;
    zT_633 = pp.base;
    if ((int)(zT_632 == zT_633)) goto z_bb_261; else goto z_bb_262;
    z_bb_260:
    zT_637 = src.kind;
    if ((int)(zT_637 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_266; else goto z_bb_267;
    z_bb_261:
    zT_635 = qok;
    goto z_bb_263;
    z_bb_262:
    zT_635 = 0;
    goto z_bb_263;
    z_bb_263:
    if (zT_635) goto z_bb_264; else goto z_bb_265;
    z_bb_264:
    return (int)(1);
    z_bb_265:
    goto z_bb_260;
    z_bb_266:
    zT_641 = tgt.kind;
    zT_640 = zT_641 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_268;
    z_bb_267:
    zT_640 = 0;
    goto z_bb_268;
    z_bb_268:
    if (zT_640) goto z_bb_269; else goto z_bb_270;
    z_bb_269:
    zT_645 = src.flags;
    zT_646 = tgt.flags;
    zT_650 = 2;
    zT_647 = zT_650;
    zT_651 = zF_08C13644_pointerQualifiersMo(zT_645, zT_646, zT_647);
    qok = zT_651;
    zT_653 = self->ptr_items;
    zT_654 = src.payload_idx;
    zT_655 = (unsigned int)zT_654;
    zT_656 = zT_653[zT_655];
    sp = zT_656;
    zT_658 = self->ptr_items;
    zT_659 = tgt.payload_idx;
    zT_660 = (unsigned int)zT_659;
    zT_661 = zT_658[zT_660];
    tp = zT_661;
    zT_663 = self->types_items;
    zT_664 = sp.base;
    zT_665 = (unsigned int)zT_664;
    zT_666 = zT_663[zT_665];
    spo = zT_666;
    zT_667 = spo.kind;
    if ((int)(zT_667 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_271; else goto z_bb_272;
    z_bb_270:
    zT_680 = src.kind;
    if ((int)(zT_680 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_278; else goto z_bb_279;
    z_bb_271:
    zT_671 = self->array_items;
    zT_672 = spo.payload_idx;
    zT_673 = (unsigned int)zT_672;
    zT_674 = zT_671[zT_673];
    arr = zT_674;
    zT_675 = arr.elem;
    zT_676 = tp.base;
    if ((int)(zT_675 == zT_676)) goto z_bb_273; else goto z_bb_274;
    z_bb_272:
    goto z_bb_270;
    z_bb_273:
    zT_678 = qok;
    goto z_bb_275;
    z_bb_274:
    zT_678 = 0;
    goto z_bb_275;
    z_bb_275:
    if (zT_678) goto z_bb_276; else goto z_bb_277;
    z_bb_276:
    return (int)(1);
    z_bb_277:
    goto z_bb_272;
    z_bb_278:
    zT_684 = tgt.kind;
    zT_683 = zT_684 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_280;
    z_bb_279:
    zT_683 = 0;
    goto z_bb_280;
    z_bb_280:
    if (zT_683) goto z_bb_281; else goto z_bb_282;
    z_bb_281:
    zT_688 = self->array_items;
    zT_689 = src.payload_idx;
    zT_690 = (unsigned int)zT_689;
    zT_691 = zT_688[zT_690];
    s_arr = zT_691;
    zT_693 = self->array_items;
    zT_694 = tgt.payload_idx;
    zT_695 = (unsigned int)zT_694;
    zT_696 = zT_693[zT_695];
    t_arr = zT_696;
    zT_697 = s_arr.elem;
    zT_698 = t_arr.elem;
    if ((int)(zT_697 == zT_698)) goto z_bb_283; else goto z_bb_284;
    z_bb_282:
    zT_705 = src.kind;
    if ((int)(zT_705 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_288; else goto z_bb_289;
    z_bb_283:
    zT_701 = s_arr.length;
    zT_702 = t_arr.length;
    zT_700 = zT_701 == zT_702;
    goto z_bb_285;
    z_bb_284:
    zT_700 = 0;
    goto z_bb_285;
    z_bb_285:
    if (zT_700) goto z_bb_286; else goto z_bb_287;
    z_bb_286:
    return (int)(1);
    z_bb_287:
    goto z_bb_282;
    z_bb_288:
    zT_709 = tgt.kind;
    zT_708 = zT_709 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_290;
    z_bb_289:
    zT_708 = 0;
    goto z_bb_290;
    z_bb_290:
    if (zT_708) goto z_bb_291; else goto z_bb_292;
    z_bb_291:
    zT_713 = src.flags;
    zT_714 = tgt.flags;
    zT_718 = 2;
    zT_715 = zT_718;
    zT_719 = zF_08C13644_pointerQualifiersMo(zT_713, zT_714, zT_715);
    qok = zT_719;
    zT_721 = self->slice_items;
    zT_722 = src.payload_idx;
    zT_723 = (unsigned int)zT_722;
    zT_724 = zT_721[zT_723];
    sl = zT_724;
    zT_726 = self->ptr_items;
    zT_727 = tgt.payload_idx;
    zT_728 = (unsigned int)zT_727;
    zT_729 = zT_726[zT_728];
    pp = zT_729;
    zT_730 = sl.elem;
    zT_731 = pp.base;
    if ((int)(zT_730 == zT_731)) goto z_bb_293; else goto z_bb_294;
    z_bb_292:
    zT_735 = src.kind;
    if ((int)(zT_735 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_298; else goto z_bb_299;
    z_bb_293:
    zT_733 = qok;
    goto z_bb_295;
    z_bb_294:
    zT_733 = 0;
    goto z_bb_295;
    z_bb_295:
    if (zT_733) goto z_bb_296; else goto z_bb_297;
    z_bb_296:
    return (int)(1);
    z_bb_297:
    goto z_bb_292;
    z_bb_298:
    zT_739 = tgt.kind;
    zT_738 = zT_739 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_300;
    z_bb_299:
    zT_738 = 0;
    goto z_bb_300;
    z_bb_300:
    if (zT_738) goto z_bb_301; else goto z_bb_302;
    z_bb_301:
    zT_743 = self->opt_items;
    zT_744 = tgt.payload_idx;
    zT_745 = (unsigned int)zT_744;
    zT_746 = zT_743[zT_745];
    opt = zT_746;
    zT_748 = self->types_items;
    zT_749 = opt.payload;
    zT_750 = (unsigned int)zT_749;
    zT_751 = zT_748[zT_750];
    opt_ty = zT_751;
    zT_752 = opt_ty.kind;
    if ((int)(zT_752 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_303; else goto z_bb_304;
    z_bb_302:
    if ((int)(source == (unsigned int)(8))) goto z_bb_305; else goto z_bb_306;
    z_bb_303:
    zT_755 = self;
    zT_756 = source;
    zT_758 = opt.payload;
    self = zT_755;
    source = zT_756;
    target = zT_758;
    goto z_bb_0;
    z_bb_304:
    goto z_bb_302;
    z_bb_305:
    zT_762 = target == (unsigned int)(14);
    goto z_bb_307;
    z_bb_306:
    zT_762 = 0;
    goto z_bb_307;
    z_bb_307:
    if (zT_762) goto z_bb_309; else goto z_bb_308;
    z_bb_308:
    if ((int)(source == (unsigned int)(14))) goto z_bb_311; else goto z_bb_312;
    z_bb_309:
    zT_765 = 1;
    goto z_bb_310;
    z_bb_310:
    if (zT_765) goto z_bb_314; else goto z_bb_315;
    z_bb_311:
    zT_768 = target == (unsigned int)(8);
    goto z_bb_313;
    z_bb_312:
    zT_768 = 0;
    goto z_bb_313;
    z_bb_313:
    zT_765 = zT_768;
    goto z_bb_310;
    z_bb_314:
    return (int)(1);
    z_bb_315:
    return (int)(0);
}

/* canLiteralFitInType */
int zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    int zT_6;
    int zT_13;
    int zT_22;
    int zT_32;
    int zT_39;
    int zT_46;
    int zT_59;
    int zT_66;
    int zT_71;
    if ((int)(target == (unsigned int)(4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-128))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((int)(target == (unsigned int)(5))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_6 = value <= (zT_C69B2266_i64)(127);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-32768))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((int)(target == (unsigned int)(6))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_13 = value <= (zT_C69B2266_i64)(32767);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    if ((int)(target == (unsigned int)(7))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_22 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    if ((int)(target == (unsigned int)(8))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((int)(target == (unsigned int)(9))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_32 = value <= (zT_C69B2266_i64)(255);
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((int)(target == (unsigned int)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_39 = value <= (zT_C69B2266_i64)(65535);
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    if ((int)(target == (unsigned int)(11))) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_46 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    return (int)(value >= (zT_C69B2266_i64)(0));
    z_bb_34:
    if ((int)(target == (unsigned int)(12))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    if ((int)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-2147483648LL))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((int)(target == (unsigned int)(13))) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_59 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    if ((int)(value >= (zT_C69B2266_i64)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    if ((int)(target == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_66 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_71 = target == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return (int)(1);
    z_bb_49:
    return (int)(0);
}

/* EOF */
