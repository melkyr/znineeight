#ifndef ZIG_MODULE_SYMBOL_REGISTRATOR_757C4BC5_H
#define ZIG_MODULE_SYMBOL_REGISTRATOR_757C4BC5_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "symbol_table_74081C75.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"
#include "type_registry_8EE489B8.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"
#include "type_resolver_7446D285.h"

#ifndef ZIG_STRUCT_zT_52CDA6EF_DepEdge
#define ZIG_STRUCT_zT_52CDA6EF_DepEdge
struct zT_52CDA6EF_DepEdge {
	unsigned int from;
	unsigned int to;
};
#endif /* ZIG_STRUCT_zT_52CDA6EF_DepEdge */
#ifndef ZIG_STRUCT_zT_4D61441E_DepGraph
#define ZIG_STRUCT_zT_4D61441E_DepGraph
struct zT_4D61441E_DepGraph {
	zT_52CDA6EF_DepEdge* items;
	unsigned int len;
	unsigned int cap;
	zT_3E40CD83_Sand* alloc;
	unsigned int* in_degree_items;
	unsigned int in_degree_cap;
};
#endif /* ZIG_STRUCT_zT_4D61441E_DepGraph */

/* Forward declarations */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand*);
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph*);
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph*, unsigned int, unsigned int);
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph*, unsigned int);
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore*, unsigned int, unsigned int, zT_4D61441E_DepGraph*);
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, zT_8143F551_AstKind, unsigned int, zT_3D7259E2_SymbolRegistry*);
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry*, zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, zT_4D61441E_DepGraph*, zT_072B53A6_ModuleRegistry*, int);
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry*, zT_3D7259E2_SymbolRegistry*, zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, unsigned int, zT_4D61441E_DepGraph*, int);
void zF_780653D2___module_init_17(void);
/* Storage globals (extern decls) */
extern zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;

#endif /* ZIG_MODULE_SYMBOL_REGISTRATOR_757C4BC5_H */
