#ifndef ZIG_MODULE_TOKEN_76C7CBBF_H
#define ZIG_MODULE_TOKEN_76C7CBBF_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "mem_19CC4C40.h"
#include "allocator_E75B7A0B.h"

#ifndef ZIG_ENUM_zT_EEFF4F05_SyncContext
#define ZIG_ENUM_zT_EEFF4F05_SyncContext
typedef unsigned char zT_EEFF4F05_SyncContext;
#define zT_EEFF4F05_SyncContext_stmt_list 0
#define zT_EEFF4F05_SyncContext_expression 1
#define zT_EEFF4F05_SyncContext_switch_prong 2
#define zT_EEFF4F05_SyncContext_fn_body 3
#define zT_EEFF4F05_SyncContext_module_root 4

#endif /* ZIG_ENUM_zT_EEFF4F05_SyncContext */

/* Forward declarations */
void zF_DAFC3CA2_initKeywordTable(zT_3E40CD83_Sand*);
zT_AFDCBEBC_Opt_81 zF_6FF3ED46_lookupKeyword(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_780653D2___module_init_4(void);
/* Storage globals (extern decls) */
extern zT_3A355BD2_Token zG_3A355BD2_Token;
extern zT_EAC3E484_TokenKind zG_EAC3E484_TokenKind;
extern zT_F4F52502_Slice_zT_C1009AE8_K zG_7FD21B9B_keyword_table;
extern unsigned int zG_BC751038_keyword_count;
extern zT_85CBA4DB_TokenValue zG_85CBA4DB_TokenValue;

#endif /* ZIG_MODULE_TOKEN_76C7CBBF_H */
