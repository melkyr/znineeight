#ifndef ZIG_MODULE_MEM_19CC4C40_H
#define ZIG_MODULE_MEM_19CC4C40_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
int zF_B7662C9F_mem_eql(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_1457D8A5_binary_search(zT_3CB0179A_Slice_zT_05F374B1_u, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_MEM_19CC4C40_H */
