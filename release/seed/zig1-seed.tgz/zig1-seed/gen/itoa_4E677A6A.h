#ifndef ZIG_MODULE_ITOA_4E677A6A_H
#define ZIG_MODULE_ITOA_4E677A6A_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
unsigned int zF_A7504564_itoa(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_A3999586_itoa64(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_ITOA_4E677A6A_H */
