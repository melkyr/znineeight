#ifndef ZIG_MODULE_FORMAT_0AEF880C_H
#define ZIG_MODULE_FORMAT_0AEF880C_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int*, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_350AF0DD_fmtBnMulSmall(zT_5DB33A8A_Arr_unsigned_int_12*, unsigned int*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_11ACB4EF_fmtCopyOut(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(double, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_FORMAT_0AEF880C_H */
