SEED v0 — zig1 bootstrap seed (zig0-independent rebuild path)
================================================================

Pinned HEAD: 1079d90a (branch zig1_improvements)
Capture date: 2026-09-07
Spec: docs/superpowers/specs/2026-09-07-seed-bootstrap-migration-design.md

Purpose: rebuild zig1 with ONLY gcc, never zig0. zig0 stays in-tree and active;
this archive is the committed safety net, rotated once per completed plan.

Contents
--------
zig1-seed/zig1        seed binary = the zig0-built reference compiler
zig1-seed/gen/        the seed's own self-emission C89 (41 .c + 42 .h incl.
                      zig_special_types.h) emitted from sf/src/main.zig at HEAD
zig1-seed/c_exit.c    link source (sf/src/c_exit.c, 58 B)
zig1-seed/runtime/    link/include sources needed to compile gen/:
                      zig_compat.h, zig_runtime.h, zig_special_types.h (canonical
                      87-B copy), zig_runtime.c, zig_pal.c
zig1-seed/lib/        the 4 std .zig (std.zig, std_arena.zig, std_io.zig,
                      std_net.zig)
zig1-seed/SEED_README.txt  this file

(net_prelude.h / net_runtime.h / net_runtime.c / optstar_repro.h are NOT included:
0 references in any emitted gen/*.c|*.h for a linux -osl gcc-only rebuild.)
sf/src .zig sources are NOT duplicated in the archive — the pinned HEAD sha in
release/seed/CHANGELOG.md identifies the source; the source lives in git.

Binary vs fixed point (provenance)
----------------------------------
Two byte-distinct artifacts represent the SAME compiler state at HEAD 1079d90a:

  - The archived binary md5 3707d33bd1d3779c4a98aab9d5be1841 is the zig0-BUILT
    reference (/tmp/fx_subfolder/zig1): bootstrap via src/bootstrap (g++ zig0)
    -> dump -> gcc link. It is the seed used for the primary rebuild recipe.
  - gcc of the archived self-emission C reproduces the self-emission FIXED POINT
    md5 24da89b9d6398ff24f4baecfe2e23f77 (two-hop closure; hop1==hop2). This is
    NOT the zig0-built reference md5; both are the same compiler state.

Neither is "more correct"; they are the two valid rebuild targets of this seed.

Rebuild recipe 1 (primary, forward path) — from the seed binary
--------------------------------------------------------------
From the repo root (current sf/src), with current sf/src:

  timeout 120 ./zig1-seed/zig1 --dump-c89 --output-dir <fresh-dir> sf/src/main.zig

  (--output-dir must already exist; note the self-emission dump logs 41 .c,
   0 error[, 0 PANIC for sf/src/main.zig at HEAD 1079d90a. Exclude the
   .zig1_*.tmp CWD-spill scratch the dump writes next to the output.)

  cd <fresh-dir>
  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign \
      -Wno-implicit-function-declaration -I <repo>/sf/src/include -c *.c
  gcc -m32 -O0 *.o <repo>/sf/src/include/zig_runtime.c \
      <repo>/sf/src/include/zig_pal.c <repo>/sf/src/c_exit.c -o zig1_next

Verify two-hop fixed-point closure: dump sf/src/main.zig with zig1_next into a
fresh dir, gcc the same way, link -> binary md5 must equal the fixed point
24da89b9d6398ff24f4baecfe2e23f77.

Rebuild recipe 2 (fallback) — seed binary lost, rebuild from C only
------------------------------------------------------------------
Self-contained; no repo include path, no zig0. From a dir holding the unpacked
archive as zig1-seed/:

  cd zig1-seed
  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign \
      -Wno-implicit-function-declaration -I zig1-seed/runtime -c zig1-seed/gen/*.c
  gcc -m32 -O0 *.o zig1-seed/runtime/zig_runtime.c zig1-seed/runtime/zig_pal.c \
      zig1-seed/c_exit.c -o zig1_fromC

Binary md5 must equal the fixed point 24da89b9d6398ff24f4baecfe2e23f77.

  NOTE: run the compile from a scratch copy of the tree (or cd elsewhere); gcc -c
  writes *.o next to the sources and pollutes the unpacked archive dir.

std install: the produced binary needs the std lib next to it (lib/ with the 4
std .zig) — copied from zig1-seed/lib/ or the binary's lib-dir.

CRITICAL FLAG SET RULE (operator amendment 2026-09-07)
------------------------------------------------------
Every gcc -c command MUST carry the FULL canonical flag set, INCLUDING -Wall:

  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign \
      -Wno-implicit-function-declaration -I <inc> -c ...

The fixed point 24da89b9d6398ff24f4baecfe2e23f77 reproduces ONLY with -Wall
present. Without -Wall the deterministic result is 0696756c4e920af5f546b7b98aea21e5
— a cosmetic difference only (assembler local-label numbering, .text
instruction-identical, one object affected of 41), not a code difference.

Link rule: self-emission C89 links zig_runtime.c + zig_pal.c + c_exit.c.
zig_pal.c alone is insufficient (undefined std_panic + c_exit).

Runtime include minimal set: zig_compat.h (base; includes nothing), zig_runtime.h
(-> zig_compat.h), gen/zig_special_types.h (emitted, 184,976 B, -> zig_compat.h +
zig_runtime.h). Link C: zig_runtime.c -> zig_compat.h; zig_pal.c -> zig_compat.h +
system headers; c_exit.c -> <stdlib.h> only. c_exit.c is kept at archive top level
(separate from runtime/), per spec layout.

Archive inventory (sizes, Task-1 record):
  zig_compat.h 799, zig_runtime.h 4836, zig_special_types.h 87 (canonical copy;
  during a from-gen rebuild the emitted gen/zig_special_types.h 184,976 B shadows
  it), zig_runtime.c 7176, zig_pal.c 6159, c_exit.c 58 (top level).
  Emitted gen set: 41 .c + 42 .h = 8,026,653 bytes.

Smoke (Task-1 record): dumping examples/z98/hello/main.zig with the C-rebuilt
binary (std from a lib/ copy) and gcc-linking the emitted C against the runtime
trio runs rc=0 with stdout "Hello, world!".
