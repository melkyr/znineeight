SEED - zig1 bootstrap seed (zig0-independent rebuild path)
==========================================================

Pinned HEAD: c599b00e
Capture date: 2026-09-10
Spec: docs/superpowers/specs/2026-09-07-seed-bootstrap-migration-design.md

Purpose: rebuild zig1 with ONLY gcc, never zig0. zig0 stays in-tree and active;
this archive is the committed safety net, rotated once per completed plan.

Contents
--------
zig1-seed/zig1        seed binary (md5 4da59bb11270e3c85638bcbb120afc2d)
zig1-seed/gen/        the seed's own self-emission C89 (42 .c + 43
                      .h incl. zig_special_types.h, emitted from sf/src/main.zig
                      at HEAD c599b00e; 7462585 bytes)
zig1-seed/c_exit.c    link source (sf/src/c_exit.c, top level per spec layout)
zig1-seed/runtime/    link/include sources needed to compile gen/:
                      zig_compat.h, zig_runtime.h, zig_special_types.h
                      (canonical 87-B copy), zig_runtime.c, zig_pal.c
zig1-seed/lib/        the 8 std .zig (std.zig, std_io.zig, std_arena.zig,
                      std_net.zig, std_str.zig, std_mem.zig, std_math.zig,
                      std_debug.zig)
zig1-seed/SEED_README.txt  this file

(net_prelude.h / net_runtime.h / net_runtime.c / optstar_repro.h are NOT
included: 0 references in any emitted gen/*.c|*.h for a linux -osl gcc-only
rebuild.) sf/src .zig sources are NOT duplicated in the archive - the pinned
HEAD sha in release/seed/CHANGELOG.md identifies the source; the source lives
in git.

Binary vs fixed point (provenance)
----------------------------------
The archived binary md5 4da59bb11270e3c85638bcbb120afc2d and the self-emission fixed point 4da59bb11270e3c85638bcbb120afc2d
(gcc of the archive's gen/ C, verified at creation) represent the SAME compiler
state at HEAD c599b00e. A gcc-only rebuild of the archive's C must reproduce
4da59bb11270e3c85638bcbb120afc2d.

Rebuild recipe 1 (primary, forward path) - from the seed binary
----------------------------------------------------------------
From the repo root (current sf/src):

  timeout 120 ./zig1-seed/zig1 --dump-c89 --output-dir <fresh-dir> sf/src/main.zig

  (run from the repo root with the RELATIVE sf/src/main.zig path: module
  basename-hash tokens depend on the resolved source path; --output-dir must
  already exist. Exclude the .zig1_*.tmp spill scratch the dump writes into the
  output dir.)

  cd <fresh-dir>
  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign       -Wno-implicit-function-declaration -I <repo>/sf/src/include -c *.c
  gcc -m32 -O0 *.o <repo>/sf/src/include/zig_runtime.c       <repo>/sf/src/include/zig_pal.c <repo>/sf/src/c_exit.c -o zig1_next

Verify two-hop fixed-point closure: dump sf/src/main.zig with zig1_next into a
fresh dir, gcc the same way, link -> binary md5 must equal the fixed point
4da59bb11270e3c85638bcbb120afc2d. (scripts/seed/build_from_seed.sh automates this.)

Rebuild recipe 2 (fallback) - seed binary lost, rebuild from C only
-------------------------------------------------------------------
Self-contained; no repo include path, no zig0. Run from a scratch copy of the
unpacked archive (gcc -c writes *.o next to the sources):

  cd zig1-seed
  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign       -Wno-implicit-function-declaration -I zig1-seed/runtime -c zig1-seed/gen/*.c
  gcc -m32 -O0 *.o zig1-seed/runtime/zig_runtime.c zig1-seed/runtime/zig_pal.c       zig1-seed/c_exit.c -o zig1_fromC

Binary md5 must equal the fixed point 4da59bb11270e3c85638bcbb120afc2d.

std install: the produced binary needs the std lib next to it (lib/ with the 8
std .zig) - copied from zig1-seed/lib/ or the binary's lib-dir.

CRITICAL FLAG SET RULE (operator amendment 2026-09-07)
------------------------------------------------------
Every gcc -c command MUST carry the FULL canonical flag set, INCLUDING -Wall:

  gcc -m32 -std=c89 -O0 -Wall -Wno-long-long -Wno-pointer-sign       -Wno-implicit-function-declaration -I <inc> -c ...

The fixed point reproduces ONLY with -Wall present. Without -Wall the
deterministic result differs (cosmetic only: assembler local-label numbering,
.text instruction-identical), so the recorded fixed point is not reproduced.

Link rule: self-emission C89 links zig_runtime.c + zig_pal.c + c_exit.c.
zig_pal.c alone is insufficient (undefined std_panic + c_exit).

Archive inventory (sizes from sf/src at HEAD c599b00e):
  runtime/: zig_compat.h, zig_runtime.h, zig_special_types.h (canonical 87-B
  copy; during a from-gen rebuild the emitted gen/zig_special_types.h shadows
  it), zig_runtime.c, zig_pal.c. c_exit.c is at archive top level (separate
  from runtime/), per spec layout. Emitted gen set: 42 .c + 43 .h
  = 7462585 bytes.
