// std_cipher.zig — Z98 std lib L5: ChaCha20, Poly1305, ChaCha20-Poly1305,
// AES-128, AES-128-GCM.
//
// Contract: alloc no | errors only on AEAD auth/length failure | coroutine no.
// Pure (no imports). Caller-provided state throughout. ChaCha20 follows
// RFC 8439 with all 20 rounds unrolled. Poly1305 is the donna 5x26-bit limb
// form with wrap (`+%`/`*%`) arithmetic and no data-dependent branches or
// table indices. AES-128 uses 4 KiB of file-scope `const` T-tables (static
// storage); GCM's GHASH uses 16-entry 4-bit tables per SP800-38D/BearSSL
// practice.

fn mask(bits: u32) u32 {
    if (bits == 0) return 0;
    if (bits >= 32) return ~@intCast(u32, 0);
    var one: u32 = 1;
    return (one << bits) - 1;
}

fn rotl32(x: u32, n: u32) u32 {
    var s: u32 = n % 32;
    if (s == 0) return x;
    var keep: u32 = x & mask(32 - s);
    return (keep << s) | (x >> (32 - s));
}

fn load32le(p: []const u8, off: usize) u32 {
    return @intCast(u32, p[off]) |
        (@intCast(u32, p[off + 1]) << 8) |
        (@intCast(u32, p[off + 2]) << 16) |
        (@intCast(u32, p[off + 3]) << 24);
}

fn load32be(p: []const u8, off: usize) u32 {
    return (@intCast(u32, p[off]) << 24) |
        (@intCast(u32, p[off + 1]) << 16) |
        (@intCast(u32, p[off + 2]) << 8) |
        @intCast(u32, p[off + 3]);
}

fn store32le(dst: []u8, off: usize, v: u32) void {
    dst[off] = @intCast(u8, v & 0xFF);
    dst[off + 1] = @intCast(u8, (v >> 8) & 0xFF);
    dst[off + 2] = @intCast(u8, (v >> 16) & 0xFF);
    dst[off + 3] = @intCast(u8, v >> 24);
}

fn store32be(dst: []u8, off: usize, v: u32) void {
    dst[off] = @intCast(u8, v >> 24);
    dst[off + 1] = @intCast(u8, (v >> 16) & 0xFF);
    dst[off + 2] = @intCast(u8, (v >> 8) & 0xFF);
    dst[off + 3] = @intCast(u8, v & 0xFF);
}

fn store64le(dst: []u8, off: usize, v: u64) void {
    var i: usize = 0;
    while (i < 8) : (i += 1) {
        dst[off + i] = @intCast(u8, (v >> @intCast(u6, i * 8)) & 0xFF);
    }
}

fn store64be(dst: []u8, off: usize, v: u64) void {
    var i: usize = 0;
    while (i < 8) : (i += 1) {
        dst[off + i] = @intCast(u8, (v >> @intCast(u6, (7 - i) * 8)) & 0xFF);
    }
}

fn xor16(dst: []u8, src: []const u8, off: usize) void {
    var i: usize = 0;
    while (i < 16) : (i += 1) dst[i] = dst[i] ^ src[off + i];
}

// ---------------------------------------------------------------------------
// ChaCha20 (RFC 8439)
// ---------------------------------------------------------------------------

pub const ChaCha20 = struct {
    state: [16]u32,
};

fn chacha20Block(state: *const [16]u32, out: *[64]u8) void {
    var x: [16]u32 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) x[i] = state[i];

    var t: u32 = 0;
    var round: usize = 0;
    while (round < 10) : (round += 1) {

        x[0] = x[0] +% x[4];
        t = x[12] ^ x[0]; x[12] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[8] = x[8] +% x[12];
        t = x[4] ^ x[8]; x[4] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[0] = x[0] +% x[4];
        t = x[12] ^ x[0]; x[12] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[8] = x[8] +% x[12];
        t = x[4] ^ x[8]; x[4] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[1] = x[1] +% x[5];
        t = x[13] ^ x[1]; x[13] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[9] = x[9] +% x[13];
        t = x[5] ^ x[9]; x[5] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[1] = x[1] +% x[5];
        t = x[13] ^ x[1]; x[13] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[9] = x[9] +% x[13];
        t = x[5] ^ x[9]; x[5] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[2] = x[2] +% x[6];
        t = x[14] ^ x[2]; x[14] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[10] = x[10] +% x[14];
        t = x[6] ^ x[10]; x[6] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[2] = x[2] +% x[6];
        t = x[14] ^ x[2]; x[14] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[10] = x[10] +% x[14];
        t = x[6] ^ x[10]; x[6] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[3] = x[3] +% x[7];
        t = x[15] ^ x[3]; x[15] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[11] = x[11] +% x[15];
        t = x[7] ^ x[11]; x[7] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[3] = x[3] +% x[7];
        t = x[15] ^ x[3]; x[15] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[11] = x[11] +% x[15];
        t = x[7] ^ x[11]; x[7] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[0] = x[0] +% x[5];
        t = x[15] ^ x[0]; x[15] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[10] = x[10] +% x[15];
        t = x[5] ^ x[10]; x[5] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[0] = x[0] +% x[5];
        t = x[15] ^ x[0]; x[15] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[10] = x[10] +% x[15];
        t = x[5] ^ x[10]; x[5] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[1] = x[1] +% x[6];
        t = x[12] ^ x[1]; x[12] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[11] = x[11] +% x[12];
        t = x[6] ^ x[11]; x[6] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[1] = x[1] +% x[6];
        t = x[12] ^ x[1]; x[12] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[11] = x[11] +% x[12];
        t = x[6] ^ x[11]; x[6] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[2] = x[2] +% x[7];
        t = x[13] ^ x[2]; x[13] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[8] = x[8] +% x[13];
        t = x[7] ^ x[8]; x[7] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[2] = x[2] +% x[7];
        t = x[13] ^ x[2]; x[13] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[8] = x[8] +% x[13];
        t = x[7] ^ x[8]; x[7] = ((t & 0x1FFFFFF) << 7) | (t >> 25);

        x[3] = x[3] +% x[4];
        t = x[14] ^ x[3]; x[14] = ((t & 0xFFFF) << 16) | (t >> 16);
        x[9] = x[9] +% x[14];
        t = x[4] ^ x[9]; x[4] = ((t & 0xFFFFF) << 12) | (t >> 20);
        x[3] = x[3] +% x[4];
        t = x[14] ^ x[3]; x[14] = ((t & 0xFFFFFF) << 8) | (t >> 24);
        x[9] = x[9] +% x[14];
        t = x[4] ^ x[9]; x[4] = ((t & 0x1FFFFFF) << 7) | (t >> 25);
    }

    i = 0;
    while (i < 16) : (i += 1) {
        store32le(out[0..], i * 4, x[i] +% state[i]);
    }
}


pub fn chacha20Init(key: *const [32]u8, nonce: *const [12]u8, counter: u32) ChaCha20 {
    var s: ChaCha20 = undefined;
    s.state[0] = 0x61707865;
    s.state[1] = 0x3320646e;
    s.state[2] = 0x79622d32;
    s.state[3] = 0x6b206574;
    var i: usize = 0;
    while (i < 8) : (i += 1) s.state[4 + i] = load32le(key[0..], i * 4);
    s.state[12] = counter;
    i = 0;
    while (i < 3) : (i += 1) s.state[13 + i] = load32le(nonce[0..], i * 4);
    return s;
}

pub fn chacha20Xor(s: *ChaCha20, dst: []u8, src: []const u8) void {
    if (dst.len < src.len) return;
    var off: usize = 0;
    while (off < src.len) {
        var block: [64]u8 = undefined;
        chacha20Block(&s.state, &block);
        s.state[12] = s.state[12] +% 1;
        var take: usize = src.len - off;
        if (take > 64) take = 64;
        var j: usize = 0;
        while (j < take) : (j += 1) dst[off + j] = src[off + j] ^ block[j];
        off += take;
    }
}

// ---------------------------------------------------------------------------
// Poly1305 (donna 5x26-bit limbs)
// ---------------------------------------------------------------------------

pub const Poly1305 = struct {
    r: [5]u32,
    h: [5]u32,
    pad: [4]u32,
    buf: [16]u8,
    left: usize,
};

pub fn poly1305Init(key: *const [32]u8) Poly1305 {
    var s: Poly1305 = undefined;
    s.r[0] = load32le(key[0..], 0) & 0x3ffffff;
    s.r[1] = (load32le(key[0..], 3) >> 2) & 0x3ffff03;
    s.r[2] = (load32le(key[0..], 6) >> 4) & 0x3ffc0ff;
    s.r[3] = (load32le(key[0..], 9) >> 6) & 0x3f03fff;
    s.r[4] = (load32le(key[0..], 12) >> 8) & 0x00fffff;
    s.h[0] = 0;
    s.h[1] = 0;
    s.h[2] = 0;
    s.h[3] = 0;
    s.h[4] = 0;
    s.pad[0] = load32le(key[0..], 16);
    s.pad[1] = load32le(key[0..], 20);
    s.pad[2] = load32le(key[0..], 24);
    s.pad[3] = load32le(key[0..], 28);
    s.left = 0;
    return s;
}

fn poly1305Block(s: *Poly1305, block: []const u8, hibit: u32) void {
    var h0: u64 = @intCast(u64, s.h[0]);
    var h1: u64 = @intCast(u64, s.h[1]);
    var h2: u64 = @intCast(u64, s.h[2]);
    var h3: u64 = @intCast(u64, s.h[3]);
    var h4: u64 = @intCast(u64, s.h[4]);
    var r0: u64 = @intCast(u64, s.r[0]);
    var r1: u64 = @intCast(u64, s.r[1]);
    var r2: u64 = @intCast(u64, s.r[2]);
    var r3: u64 = @intCast(u64, s.r[3]);
    var r4: u64 = @intCast(u64, s.r[4]);
    var s1: u64 = r1 *% 5;
    var s2: u64 = r2 *% 5;
    var s3: u64 = r3 *% 5;
    var s4: u64 = r4 *% 5;

    h0 = h0 +% @intCast(u64, load32le(block, 0) & 0x3ffffff);
    h1 = h1 +% @intCast(u64, (load32le(block, 3) >> 2) & 0x3ffffff);
    h2 = h2 +% @intCast(u64, (load32le(block, 6) >> 4) & 0x3ffffff);
    h3 = h3 +% @intCast(u64, (load32le(block, 9) >> 6) & 0x3ffffff);
    h4 = h4 +% @intCast(u64, (load32le(block, 12) >> 8) | hibit);

    var d0: u64 = (h0 *% r0) +% (h1 *% s4) +% (h2 *% s3) +% (h3 *% s2) +% (h4 *% s1);
    var d1: u64 = (h0 *% r1) +% (h1 *% r0) +% (h2 *% s4) +% (h3 *% s3) +% (h4 *% s2);
    var d2: u64 = (h0 *% r2) +% (h1 *% r1) +% (h2 *% r0) +% (h3 *% s4) +% (h4 *% s3);
    var d3: u64 = (h0 *% r3) +% (h1 *% r2) +% (h2 *% r1) +% (h3 *% r0) +% (h4 *% s4);
    var d4: u64 = (h0 *% r4) +% (h1 *% r3) +% (h2 *% r2) +% (h3 *% r1) +% (h4 *% r0);

    var c: u64 = d0 >> 26;
    h0 = d0 & 0x3ffffff;
    d1 = d1 +% c;
    c = d1 >> 26;
    h1 = d1 & 0x3ffffff;
    d2 = d2 +% c;
    c = d2 >> 26;
    h2 = d2 & 0x3ffffff;
    d3 = d3 +% c;
    c = d3 >> 26;
    h3 = d3 & 0x3ffffff;
    d4 = d4 +% c;
    c = d4 >> 26;
    h4 = d4 & 0x3ffffff;
    h0 = h0 +% (c *% 5);
    c = h0 >> 26;
    h0 = h0 & 0x3ffffff;
    h1 = h1 +% c;

    s.h[0] = @intCast(u32, h0);
    s.h[1] = @intCast(u32, h1);
    s.h[2] = @intCast(u32, h2);
    s.h[3] = @intCast(u32, h3);
    s.h[4] = @intCast(u32, h4);
}

pub fn poly1305Update(s: *Poly1305, data: []const u8) void {
    var i: usize = 0;
    if (s.left > 0) {
        while (i < data.len and s.left < 16) {
            s.buf[s.left] = data[i];
            s.left += 1;
            i += 1;
        }
        if (s.left == 16) {
            poly1305Block(s, s.buf[0..], 1 << 24);
            s.left = 0;
        }
    }
    while (i + 16 <= data.len) {
        poly1305Block(s, data[i .. i + 16], 1 << 24);
        i += 16;
    }
    while (i < data.len) {
        s.buf[s.left] = data[i];
        s.left += 1;
        i += 1;
    }
}

pub fn poly1305Final(s: *Poly1305, out: *[16]u8) void {
    if (s.left > 0) {
        var block: [16]u8 = undefined;
        var i: usize = 0;
        while (i < 16) : (i += 1) block[i] = 0;
        i = 0;
        while (i < s.left) : (i += 1) block[i] = s.buf[i];
        block[s.left] = 1;
        poly1305Block(s, block[0..], 0);
        s.left = 0;
    }

    var h0: u64 = @intCast(u64, s.h[0]);
    var h1: u64 = @intCast(u64, s.h[1]);
    var h2: u64 = @intCast(u64, s.h[2]);
    var h3: u64 = @intCast(u64, s.h[3]);
    var h4: u64 = @intCast(u64, s.h[4]);

    var c: u64 = h1 >> 26;
    h1 = h1 & 0x3ffffff;
    h2 = h2 +% c;
    c = h2 >> 26;
    h2 = h2 & 0x3ffffff;
    h3 = h3 +% c;
    c = h3 >> 26;
    h3 = h3 & 0x3ffffff;
    h4 = h4 +% c;
    c = h4 >> 26;
    h4 = h4 & 0x3ffffff;
    h0 = h0 +% (c *% 5);
    c = h0 >> 26;
    h0 = h0 & 0x3ffffff;
    h1 = h1 +% c;

    var g0: u64 = h0 +% 5;
    c = g0 >> 26;
    g0 = g0 & 0x3ffffff;
    var g1: u64 = h1 +% c;
    c = g1 >> 26;
    g1 = g1 & 0x3ffffff;
    var g2: u64 = h2 +% c;
    c = g2 >> 26;
    g2 = g2 & 0x3ffffff;
    var g3: u64 = h3 +% c;
    c = g3 >> 26;
    g3 = g3 & 0x3ffffff;
    var g4: u64 = h4 +% c;
    var carry: u64 = g4 >> 26;
    g4 = g4 & 0x3ffffff;

    var cmask: u64 = 0 -% carry;
    h0 = (h0 & ~cmask) | (g0 & cmask);
    h1 = (h1 & ~cmask) | (g1 & cmask);
    h2 = (h2 & ~cmask) | (g2 & cmask);
    h3 = (h3 & ~cmask) | (g3 & cmask);
    h4 = (h4 & ~cmask) | (g4 & cmask);

    var w0: u64 = (h0 | (h1 << 26)) & 0xffffffff;
    var w1: u64 = ((h1 >> 6) | (h2 << 20)) & 0xffffffff;
    var w2: u64 = ((h2 >> 12) | (h3 << 14)) & 0xffffffff;
    var w3: u64 = ((h3 >> 18) | (h4 << 8)) & 0xffffffff;

    var f: u64 = w0 +% @intCast(u64, s.pad[0]);
    store32le(out[0..], 0, @intCast(u32, f & 0xffffffff));
    f = (f >> 32) +% w1 +% @intCast(u64, s.pad[1]);
    store32le(out[0..], 4, @intCast(u32, f & 0xffffffff));
    f = (f >> 32) +% w2 +% @intCast(u64, s.pad[2]);
    store32le(out[0..], 8, @intCast(u32, f & 0xffffffff));
    f = (f >> 32) +% w3 +% @intCast(u64, s.pad[3]);
    store32le(out[0..], 12, @intCast(u32, f & 0xffffffff));
}

// ---------------------------------------------------------------------------
// ChaCha20-Poly1305 AEAD (RFC 8439 §2.8)
// ---------------------------------------------------------------------------

fn poly1305Pad(s: *Poly1305, n: usize) void {
    var rem: usize = n % 16;
    if (rem == 0) return;
    var z: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) z[i] = 0;
    poly1305Update(s, z[0 .. 16 - rem]);
}

fn aeadTag(key: *const [32]u8, nonce: *const [12]u8, ad: []const u8, ct: []const u8, tag: *[16]u8) void {
    var c = chacha20Init(key, nonce, 0);
    var block: [64]u8 = undefined;
    chacha20Block(&c.state, &block);
    var pkey: [32]u8 = undefined;
    var i: usize = 0;
    while (i < 32) : (i += 1) pkey[i] = block[i];

    var p = poly1305Init(&pkey);
    poly1305Update(&p, ad);
    poly1305Pad(&p, ad.len);
    poly1305Update(&p, ct);
    poly1305Pad(&p, ct.len);
    var lens: [16]u8 = undefined;
    store64le(lens[0..], 0, @intCast(u64, ad.len));
    store64le(lens[0..], 8, @intCast(u64, ct.len));
    poly1305Update(&p, lens[0..]);
    poly1305Final(&p, tag);
}

fn ctEq16(a: []const u8, b: []const u8) bool {
    var diff: u8 = 0;
    var i: usize = 0;
    while (i < 16) : (i += 1) diff = diff | (a[i] ^ b[i]);
    return diff == 0;
}

pub fn chacha20Poly1305Seal(key: *const [32]u8, nonce: *const [12]u8, ad: []const u8, pt: []const u8, ct: []u8, tag: *[16]u8) !void {
    if (ct.len != pt.len) return error.Corrupt;
    var s = chacha20Init(key, nonce, 1);
    chacha20Xor(&s, ct, pt);
    aeadTag(key, nonce, ad, ct, tag);
}

pub fn chacha20Poly1305Open(key: *const [32]u8, nonce: *const [12]u8, ad: []const u8, ct: []const u8, tag: *const [16]u8, pt: []u8) !void {
    if (pt.len != ct.len) return error.Corrupt;
    var want: [16]u8 = undefined;
    aeadTag(key, nonce, ad, ct, &want);
    if (!ctEq16(want[0..], tag[0..])) return error.AuthenticationFailed;
    var s = chacha20Init(key, nonce, 1);
    chacha20Xor(&s, pt, ct);
}

// ---------------------------------------------------------------------------
// AES-128 (FIPS-197), const T-tables (4 x 256 x u32 = 4 KiB)
// ---------------------------------------------------------------------------

pub const Aes128 = struct {
    rk: [44]u32,
};

const RCON = [_]u32{ 1, 2, 4, 8, 16, 32, 64, 128, 27, 54 };

const SBOX = [_]u8{
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
};

const Te0 = [_]u32{
    0xc66363a5, 0xf87c7c84, 0xee777799, 0xf67b7b8d, 0xfff2f20d, 0xd66b6bbd, 0xde6f6fb1, 0x91c5c554,
    0x60303050, 0x02010103, 0xce6767a9, 0x562b2b7d, 0xe7fefe19, 0xb5d7d762, 0x4dababe6, 0xec76769a,
    0x8fcaca45, 0x1f82829d, 0x89c9c940, 0xfa7d7d87, 0xeffafa15, 0xb25959eb, 0x8e4747c9, 0xfbf0f00b,
    0x41adadec, 0xb3d4d467, 0x5fa2a2fd, 0x45afafea, 0x239c9cbf, 0x53a4a4f7, 0xe4727296, 0x9bc0c05b,
    0x75b7b7c2, 0xe1fdfd1c, 0x3d9393ae, 0x4c26266a, 0x6c36365a, 0x7e3f3f41, 0xf5f7f702, 0x83cccc4f,
    0x6834345c, 0x51a5a5f4, 0xd1e5e534, 0xf9f1f108, 0xe2717193, 0xabd8d873, 0x62313153, 0x2a15153f,
    0x0804040c, 0x95c7c752, 0x46232365, 0x9dc3c35e, 0x30181828, 0x379696a1, 0x0a05050f, 0x2f9a9ab5,
    0x0e070709, 0x24121236, 0x1b80809b, 0xdfe2e23d, 0xcdebeb26, 0x4e272769, 0x7fb2b2cd, 0xea75759f,
    0x1209091b, 0x1d83839e, 0x582c2c74, 0x341a1a2e, 0x361b1b2d, 0xdc6e6eb2, 0xb45a5aee, 0x5ba0a0fb,
    0xa45252f6, 0x763b3b4d, 0xb7d6d661, 0x7db3b3ce, 0x5229297b, 0xdde3e33e, 0x5e2f2f71, 0x13848497,
    0xa65353f5, 0xb9d1d168, 0x00000000, 0xc1eded2c, 0x40202060, 0xe3fcfc1f, 0x79b1b1c8, 0xb65b5bed,
    0xd46a6abe, 0x8dcbcb46, 0x67bebed9, 0x7239394b, 0x944a4ade, 0x984c4cd4, 0xb05858e8, 0x85cfcf4a,
    0xbbd0d06b, 0xc5efef2a, 0x4faaaae5, 0xedfbfb16, 0x864343c5, 0x9a4d4dd7, 0x66333355, 0x11858594,
    0x8a4545cf, 0xe9f9f910, 0x04020206, 0xfe7f7f81, 0xa05050f0, 0x783c3c44, 0x259f9fba, 0x4ba8a8e3,
    0xa25151f3, 0x5da3a3fe, 0x804040c0, 0x058f8f8a, 0x3f9292ad, 0x219d9dbc, 0x70383848, 0xf1f5f504,
    0x63bcbcdf, 0x77b6b6c1, 0xafdada75, 0x42212163, 0x20101030, 0xe5ffff1a, 0xfdf3f30e, 0xbfd2d26d,
    0x81cdcd4c, 0x180c0c14, 0x26131335, 0xc3ecec2f, 0xbe5f5fe1, 0x359797a2, 0x884444cc, 0x2e171739,
    0x93c4c457, 0x55a7a7f2, 0xfc7e7e82, 0x7a3d3d47, 0xc86464ac, 0xba5d5de7, 0x3219192b, 0xe6737395,
    0xc06060a0, 0x19818198, 0x9e4f4fd1, 0xa3dcdc7f, 0x44222266, 0x542a2a7e, 0x3b9090ab, 0x0b888883,
    0x8c4646ca, 0xc7eeee29, 0x6bb8b8d3, 0x2814143c, 0xa7dede79, 0xbc5e5ee2, 0x160b0b1d, 0xaddbdb76,
    0xdbe0e03b, 0x64323256, 0x743a3a4e, 0x140a0a1e, 0x924949db, 0x0c06060a, 0x4824246c, 0xb85c5ce4,
    0x9fc2c25d, 0xbdd3d36e, 0x43acacef, 0xc46262a6, 0x399191a8, 0x319595a4, 0xd3e4e437, 0xf279798b,
    0xd5e7e732, 0x8bc8c843, 0x6e373759, 0xda6d6db7, 0x018d8d8c, 0xb1d5d564, 0x9c4e4ed2, 0x49a9a9e0,
    0xd86c6cb4, 0xac5656fa, 0xf3f4f407, 0xcfeaea25, 0xca6565af, 0xf47a7a8e, 0x47aeaee9, 0x10080818,
    0x6fbabad5, 0xf0787888, 0x4a25256f, 0x5c2e2e72, 0x381c1c24, 0x57a6a6f1, 0x73b4b4c7, 0x97c6c651,
    0xcbe8e823, 0xa1dddd7c, 0xe874749c, 0x3e1f1f21, 0x964b4bdd, 0x61bdbddc, 0x0d8b8b86, 0x0f8a8a85,
    0xe0707090, 0x7c3e3e42, 0x71b5b5c4, 0xcc6666aa, 0x904848d8, 0x06030305, 0xf7f6f601, 0x1c0e0e12,
    0xc26161a3, 0x6a35355f, 0xae5757f9, 0x69b9b9d0, 0x17868691, 0x99c1c158, 0x3a1d1d27, 0x279e9eb9,
    0xd9e1e138, 0xebf8f813, 0x2b9898b3, 0x22111133, 0xd26969bb, 0xa9d9d970, 0x078e8e89, 0x339494a7,
    0x2d9b9bb6, 0x3c1e1e22, 0x15878792, 0xc9e9e920, 0x87cece49, 0xaa5555ff, 0x50282878, 0xa5dfdf7a,
    0x038c8c8f, 0x59a1a1f8, 0x09898980, 0x1a0d0d17, 0x65bfbfda, 0xd7e6e631, 0x844242c6, 0xd06868b8,
    0x824141c3, 0x299999b0, 0x5a2d2d77, 0x1e0f0f11, 0x7bb0b0cb, 0xa85454fc, 0x6dbbbbd6, 0x2c16163a,
};

const Te3 = [_]u32{
    0x6363a5c6, 0x7c7c84f8, 0x777799ee, 0x7b7b8df6, 0xf2f20dff, 0x6b6bbdd6, 0x6f6fb1de, 0xc5c55491,
    0x30305060, 0x01010302, 0x6767a9ce, 0x2b2b7d56, 0xfefe19e7, 0xd7d762b5, 0xababe64d, 0x76769aec,
    0xcaca458f, 0x82829d1f, 0xc9c94089, 0x7d7d87fa, 0xfafa15ef, 0x5959ebb2, 0x4747c98e, 0xf0f00bfb,
    0xadadec41, 0xd4d467b3, 0xa2a2fd5f, 0xafafea45, 0x9c9cbf23, 0xa4a4f753, 0x727296e4, 0xc0c05b9b,
    0xb7b7c275, 0xfdfd1ce1, 0x9393ae3d, 0x26266a4c, 0x36365a6c, 0x3f3f417e, 0xf7f702f5, 0xcccc4f83,
    0x34345c68, 0xa5a5f451, 0xe5e534d1, 0xf1f108f9, 0x717193e2, 0xd8d873ab, 0x31315362, 0x15153f2a,
    0x04040c08, 0xc7c75295, 0x23236546, 0xc3c35e9d, 0x18182830, 0x9696a137, 0x05050f0a, 0x9a9ab52f,
    0x0707090e, 0x12123624, 0x80809b1b, 0xe2e23ddf, 0xebeb26cd, 0x2727694e, 0xb2b2cd7f, 0x75759fea,
    0x09091b12, 0x83839e1d, 0x2c2c7458, 0x1a1a2e34, 0x1b1b2d36, 0x6e6eb2dc, 0x5a5aeeb4, 0xa0a0fb5b,
    0x5252f6a4, 0x3b3b4d76, 0xd6d661b7, 0xb3b3ce7d, 0x29297b52, 0xe3e33edd, 0x2f2f715e, 0x84849713,
    0x5353f5a6, 0xd1d168b9, 0x00000000, 0xeded2cc1, 0x20206040, 0xfcfc1fe3, 0xb1b1c879, 0x5b5bedb6,
    0x6a6abed4, 0xcbcb468d, 0xbebed967, 0x39394b72, 0x4a4ade94, 0x4c4cd498, 0x5858e8b0, 0xcfcf4a85,
    0xd0d06bbb, 0xefef2ac5, 0xaaaae54f, 0xfbfb16ed, 0x4343c586, 0x4d4dd79a, 0x33335566, 0x85859411,
    0x4545cf8a, 0xf9f910e9, 0x02020604, 0x7f7f81fe, 0x5050f0a0, 0x3c3c4478, 0x9f9fba25, 0xa8a8e34b,
    0x5151f3a2, 0xa3a3fe5d, 0x4040c080, 0x8f8f8a05, 0x9292ad3f, 0x9d9dbc21, 0x38384870, 0xf5f504f1,
    0xbcbcdf63, 0xb6b6c177, 0xdada75af, 0x21216342, 0x10103020, 0xffff1ae5, 0xf3f30efd, 0xd2d26dbf,
    0xcdcd4c81, 0x0c0c1418, 0x13133526, 0xecec2fc3, 0x5f5fe1be, 0x9797a235, 0x4444cc88, 0x1717392e,
    0xc4c45793, 0xa7a7f255, 0x7e7e82fc, 0x3d3d477a, 0x6464acc8, 0x5d5de7ba, 0x19192b32, 0x737395e6,
    0x6060a0c0, 0x81819819, 0x4f4fd19e, 0xdcdc7fa3, 0x22226644, 0x2a2a7e54, 0x9090ab3b, 0x8888830b,
    0x4646ca8c, 0xeeee29c7, 0xb8b8d36b, 0x14143c28, 0xdede79a7, 0x5e5ee2bc, 0x0b0b1d16, 0xdbdb76ad,
    0xe0e03bdb, 0x32325664, 0x3a3a4e74, 0x0a0a1e14, 0x4949db92, 0x06060a0c, 0x24246c48, 0x5c5ce4b8,
    0xc2c25d9f, 0xd3d36ebd, 0xacacef43, 0x6262a6c4, 0x9191a839, 0x9595a431, 0xe4e437d3, 0x79798bf2,
    0xe7e732d5, 0xc8c8438b, 0x3737596e, 0x6d6db7da, 0x8d8d8c01, 0xd5d564b1, 0x4e4ed29c, 0xa9a9e049,
    0x6c6cb4d8, 0x5656faac, 0xf4f407f3, 0xeaea25cf, 0x6565afca, 0x7a7a8ef4, 0xaeaee947, 0x08081810,
    0xbabad56f, 0x787888f0, 0x25256f4a, 0x2e2e725c, 0x1c1c2438, 0xa6a6f157, 0xb4b4c773, 0xc6c65197,
    0xe8e823cb, 0xdddd7ca1, 0x74749ce8, 0x1f1f213e, 0x4b4bdd96, 0xbdbddc61, 0x8b8b860d, 0x8a8a850f,
    0x707090e0, 0x3e3e427c, 0xb5b5c471, 0x6666aacc, 0x4848d890, 0x03030506, 0xf6f601f7, 0x0e0e121c,
    0x6161a3c2, 0x35355f6a, 0x5757f9ae, 0xb9b9d069, 0x86869117, 0xc1c15899, 0x1d1d273a, 0x9e9eb927,
    0xe1e138d9, 0xf8f813eb, 0x9898b32b, 0x11113322, 0x6969bbd2, 0xd9d970a9, 0x8e8e8907, 0x9494a733,
    0x9b9bb62d, 0x1e1e223c, 0x87879215, 0xe9e920c9, 0xcece4987, 0x5555ffaa, 0x28287850, 0xdfdf7aa5,
    0x8c8c8f03, 0xa1a1f859, 0x89898009, 0x0d0d171a, 0xbfbfda65, 0xe6e631d7, 0x4242c684, 0x6868b8d0,
    0x4141c382, 0x9999b029, 0x2d2d775a, 0x0f0f111e, 0xb0b0cb7b, 0x5454fca8, 0xbbbbd66d, 0x16163a2c,
};

const Te2 = [_]u32{
    0x63a5c663, 0x7c84f87c, 0x7799ee77, 0x7b8df67b, 0xf20dfff2, 0x6bbdd66b, 0x6fb1de6f, 0xc55491c5,
    0x30506030, 0x01030201, 0x67a9ce67, 0x2b7d562b, 0xfe19e7fe, 0xd762b5d7, 0xabe64dab, 0x769aec76,
    0xca458fca, 0x829d1f82, 0xc94089c9, 0x7d87fa7d, 0xfa15effa, 0x59ebb259, 0x47c98e47, 0xf00bfbf0,
    0xadec41ad, 0xd467b3d4, 0xa2fd5fa2, 0xafea45af, 0x9cbf239c, 0xa4f753a4, 0x7296e472, 0xc05b9bc0,
    0xb7c275b7, 0xfd1ce1fd, 0x93ae3d93, 0x266a4c26, 0x365a6c36, 0x3f417e3f, 0xf702f5f7, 0xcc4f83cc,
    0x345c6834, 0xa5f451a5, 0xe534d1e5, 0xf108f9f1, 0x7193e271, 0xd873abd8, 0x31536231, 0x153f2a15,
    0x040c0804, 0xc75295c7, 0x23654623, 0xc35e9dc3, 0x18283018, 0x96a13796, 0x050f0a05, 0x9ab52f9a,
    0x07090e07, 0x12362412, 0x809b1b80, 0xe23ddfe2, 0xeb26cdeb, 0x27694e27, 0xb2cd7fb2, 0x759fea75,
    0x091b1209, 0x839e1d83, 0x2c74582c, 0x1a2e341a, 0x1b2d361b, 0x6eb2dc6e, 0x5aeeb45a, 0xa0fb5ba0,
    0x52f6a452, 0x3b4d763b, 0xd661b7d6, 0xb3ce7db3, 0x297b5229, 0xe33edde3, 0x2f715e2f, 0x84971384,
    0x53f5a653, 0xd168b9d1, 0x00000000, 0xed2cc1ed, 0x20604020, 0xfc1fe3fc, 0xb1c879b1, 0x5bedb65b,
    0x6abed46a, 0xcb468dcb, 0xbed967be, 0x394b7239, 0x4ade944a, 0x4cd4984c, 0x58e8b058, 0xcf4a85cf,
    0xd06bbbd0, 0xef2ac5ef, 0xaae54faa, 0xfb16edfb, 0x43c58643, 0x4dd79a4d, 0x33556633, 0x85941185,
    0x45cf8a45, 0xf910e9f9, 0x02060402, 0x7f81fe7f, 0x50f0a050, 0x3c44783c, 0x9fba259f, 0xa8e34ba8,
    0x51f3a251, 0xa3fe5da3, 0x40c08040, 0x8f8a058f, 0x92ad3f92, 0x9dbc219d, 0x38487038, 0xf504f1f5,
    0xbcdf63bc, 0xb6c177b6, 0xda75afda, 0x21634221, 0x10302010, 0xff1ae5ff, 0xf30efdf3, 0xd26dbfd2,
    0xcd4c81cd, 0x0c14180c, 0x13352613, 0xec2fc3ec, 0x5fe1be5f, 0x97a23597, 0x44cc8844, 0x17392e17,
    0xc45793c4, 0xa7f255a7, 0x7e82fc7e, 0x3d477a3d, 0x64acc864, 0x5de7ba5d, 0x192b3219, 0x7395e673,
    0x60a0c060, 0x81981981, 0x4fd19e4f, 0xdc7fa3dc, 0x22664422, 0x2a7e542a, 0x90ab3b90, 0x88830b88,
    0x46ca8c46, 0xee29c7ee, 0xb8d36bb8, 0x143c2814, 0xde79a7de, 0x5ee2bc5e, 0x0b1d160b, 0xdb76addb,
    0xe03bdbe0, 0x32566432, 0x3a4e743a, 0x0a1e140a, 0x49db9249, 0x060a0c06, 0x246c4824, 0x5ce4b85c,
    0xc25d9fc2, 0xd36ebdd3, 0xacef43ac, 0x62a6c462, 0x91a83991, 0x95a43195, 0xe437d3e4, 0x798bf279,
    0xe732d5e7, 0xc8438bc8, 0x37596e37, 0x6db7da6d, 0x8d8c018d, 0xd564b1d5, 0x4ed29c4e, 0xa9e049a9,
    0x6cb4d86c, 0x56faac56, 0xf407f3f4, 0xea25cfea, 0x65afca65, 0x7a8ef47a, 0xaee947ae, 0x08181008,
    0xbad56fba, 0x7888f078, 0x256f4a25, 0x2e725c2e, 0x1c24381c, 0xa6f157a6, 0xb4c773b4, 0xc65197c6,
    0xe823cbe8, 0xdd7ca1dd, 0x749ce874, 0x1f213e1f, 0x4bdd964b, 0xbddc61bd, 0x8b860d8b, 0x8a850f8a,
    0x7090e070, 0x3e427c3e, 0xb5c471b5, 0x66aacc66, 0x48d89048, 0x03050603, 0xf601f7f6, 0x0e121c0e,
    0x61a3c261, 0x355f6a35, 0x57f9ae57, 0xb9d069b9, 0x86911786, 0xc15899c1, 0x1d273a1d, 0x9eb9279e,
    0xe138d9e1, 0xf813ebf8, 0x98b32b98, 0x11332211, 0x69bbd269, 0xd970a9d9, 0x8e89078e, 0x94a73394,
    0x9bb62d9b, 0x1e223c1e, 0x87921587, 0xe920c9e9, 0xce4987ce, 0x55ffaa55, 0x28785028, 0xdf7aa5df,
    0x8c8f038c, 0xa1f859a1, 0x89800989, 0x0d171a0d, 0xbfda65bf, 0xe631d7e6, 0x42c68442, 0x68b8d068,
    0x41c38241, 0x99b02999, 0x2d775a2d, 0x0f111e0f, 0xb0cb7bb0, 0x54fca854, 0xbbd66dbb, 0x163a2c16,
};

const Te1 = [_]u32{
    0xa5c66363, 0x84f87c7c, 0x99ee7777, 0x8df67b7b, 0x0dfff2f2, 0xbdd66b6b, 0xb1de6f6f, 0x5491c5c5,
    0x50603030, 0x03020101, 0xa9ce6767, 0x7d562b2b, 0x19e7fefe, 0x62b5d7d7, 0xe64dabab, 0x9aec7676,
    0x458fcaca, 0x9d1f8282, 0x4089c9c9, 0x87fa7d7d, 0x15effafa, 0xebb25959, 0xc98e4747, 0x0bfbf0f0,
    0xec41adad, 0x67b3d4d4, 0xfd5fa2a2, 0xea45afaf, 0xbf239c9c, 0xf753a4a4, 0x96e47272, 0x5b9bc0c0,
    0xc275b7b7, 0x1ce1fdfd, 0xae3d9393, 0x6a4c2626, 0x5a6c3636, 0x417e3f3f, 0x02f5f7f7, 0x4f83cccc,
    0x5c683434, 0xf451a5a5, 0x34d1e5e5, 0x08f9f1f1, 0x93e27171, 0x73abd8d8, 0x53623131, 0x3f2a1515,
    0x0c080404, 0x5295c7c7, 0x65462323, 0x5e9dc3c3, 0x28301818, 0xa1379696, 0x0f0a0505, 0xb52f9a9a,
    0x090e0707, 0x36241212, 0x9b1b8080, 0x3ddfe2e2, 0x26cdebeb, 0x694e2727, 0xcd7fb2b2, 0x9fea7575,
    0x1b120909, 0x9e1d8383, 0x74582c2c, 0x2e341a1a, 0x2d361b1b, 0xb2dc6e6e, 0xeeb45a5a, 0xfb5ba0a0,
    0xf6a45252, 0x4d763b3b, 0x61b7d6d6, 0xce7db3b3, 0x7b522929, 0x3edde3e3, 0x715e2f2f, 0x97138484,
    0xf5a65353, 0x68b9d1d1, 0x00000000, 0x2cc1eded, 0x60402020, 0x1fe3fcfc, 0xc879b1b1, 0xedb65b5b,
    0xbed46a6a, 0x468dcbcb, 0xd967bebe, 0x4b723939, 0xde944a4a, 0xd4984c4c, 0xe8b05858, 0x4a85cfcf,
    0x6bbbd0d0, 0x2ac5efef, 0xe54faaaa, 0x16edfbfb, 0xc5864343, 0xd79a4d4d, 0x55663333, 0x94118585,
    0xcf8a4545, 0x10e9f9f9, 0x06040202, 0x81fe7f7f, 0xf0a05050, 0x44783c3c, 0xba259f9f, 0xe34ba8a8,
    0xf3a25151, 0xfe5da3a3, 0xc0804040, 0x8a058f8f, 0xad3f9292, 0xbc219d9d, 0x48703838, 0x04f1f5f5,
    0xdf63bcbc, 0xc177b6b6, 0x75afdada, 0x63422121, 0x30201010, 0x1ae5ffff, 0x0efdf3f3, 0x6dbfd2d2,
    0x4c81cdcd, 0x14180c0c, 0x35261313, 0x2fc3ecec, 0xe1be5f5f, 0xa2359797, 0xcc884444, 0x392e1717,
    0x5793c4c4, 0xf255a7a7, 0x82fc7e7e, 0x477a3d3d, 0xacc86464, 0xe7ba5d5d, 0x2b321919, 0x95e67373,
    0xa0c06060, 0x98198181, 0xd19e4f4f, 0x7fa3dcdc, 0x66442222, 0x7e542a2a, 0xab3b9090, 0x830b8888,
    0xca8c4646, 0x29c7eeee, 0xd36bb8b8, 0x3c281414, 0x79a7dede, 0xe2bc5e5e, 0x1d160b0b, 0x76addbdb,
    0x3bdbe0e0, 0x56643232, 0x4e743a3a, 0x1e140a0a, 0xdb924949, 0x0a0c0606, 0x6c482424, 0xe4b85c5c,
    0x5d9fc2c2, 0x6ebdd3d3, 0xef43acac, 0xa6c46262, 0xa8399191, 0xa4319595, 0x37d3e4e4, 0x8bf27979,
    0x32d5e7e7, 0x438bc8c8, 0x596e3737, 0xb7da6d6d, 0x8c018d8d, 0x64b1d5d5, 0xd29c4e4e, 0xe049a9a9,
    0xb4d86c6c, 0xfaac5656, 0x07f3f4f4, 0x25cfeaea, 0xafca6565, 0x8ef47a7a, 0xe947aeae, 0x18100808,
    0xd56fbaba, 0x88f07878, 0x6f4a2525, 0x725c2e2e, 0x24381c1c, 0xf157a6a6, 0xc773b4b4, 0x5197c6c6,
    0x23cbe8e8, 0x7ca1dddd, 0x9ce87474, 0x213e1f1f, 0xdd964b4b, 0xdc61bdbd, 0x860d8b8b, 0x850f8a8a,
    0x90e07070, 0x427c3e3e, 0xc471b5b5, 0xaacc6666, 0xd8904848, 0x05060303, 0x01f7f6f6, 0x121c0e0e,
    0xa3c26161, 0x5f6a3535, 0xf9ae5757, 0xd069b9b9, 0x91178686, 0x5899c1c1, 0x273a1d1d, 0xb9279e9e,
    0x38d9e1e1, 0x13ebf8f8, 0xb32b9898, 0x33221111, 0xbbd26969, 0x70a9d9d9, 0x89078e8e, 0xa7339494,
    0xb62d9b9b, 0x223c1e1e, 0x92158787, 0x20c9e9e9, 0x4987cece, 0xffaa5555, 0x78502828, 0x7aa5dfdf,
    0x8f038c8c, 0xf859a1a1, 0x80098989, 0x171a0d0d, 0xda65bfbf, 0x31d7e6e6, 0xc6844242, 0xb8d06868,
    0xc3824141, 0xb0299999, 0x775a2d2d, 0x111e0f0f, 0xcb7bb0b0, 0xfca85454, 0xd66dbbbb, 0x3a2c1616,
};

fn subWord(x: u32) u32 {
    return (@intCast(u32, SBOX[@intCast(usize, (x >> 24) & 0xFF)]) << 24) |
        (@intCast(u32, SBOX[@intCast(usize, (x >> 16) & 0xFF)]) << 16) |
        (@intCast(u32, SBOX[@intCast(usize, (x >> 8) & 0xFF)]) << 8) |
        @intCast(u32, SBOX[@intCast(usize, x & 0xFF)]);
}

pub fn aes128Init(key: *const [16]u8) Aes128 {
    var a: Aes128 = undefined;
    a.rk[0] = load32be(key[0..], 0);
    a.rk[1] = load32be(key[0..], 4);
    a.rk[2] = load32be(key[0..], 8);
    a.rk[3] = load32be(key[0..], 12);
    var i: usize = 4;
    while (i < 44) : (i += 1) {
        var t: u32 = a.rk[i - 1];
        if (i % 4 == 0) {
            t = rotl32(t, 8);
            t = subWord(t);
            t = t ^ (RCON[i / 4 - 1] << 24);
        }
        a.rk[i] = a.rk[i - 4] ^ t;
    }
    return a;
}

pub fn aes128EncryptBlock(a: *const Aes128, in: *const [16]u8, out: *[16]u8) void {
    var s0: u32 = load32be(in[0..], 0) ^ a.rk[0];
    var s1: u32 = load32be(in[0..], 4) ^ a.rk[1];
    var s2: u32 = load32be(in[0..], 8) ^ a.rk[2];
    var s3: u32 = load32be(in[0..], 12) ^ a.rk[3];

    var r: usize = 1;
    while (r < 10) : (r += 1) {
        var t0: u32 = Te0[@intCast(usize, s0 >> 24)] ^
            Te1[@intCast(usize, (s1 >> 16) & 0xFF)] ^
            Te2[@intCast(usize, (s2 >> 8) & 0xFF)] ^
            Te3[@intCast(usize, s3 & 0xFF)] ^
            a.rk[r * 4];
        var t1: u32 = Te0[@intCast(usize, s1 >> 24)] ^
            Te1[@intCast(usize, (s2 >> 16) & 0xFF)] ^
            Te2[@intCast(usize, (s3 >> 8) & 0xFF)] ^
            Te3[@intCast(usize, s0 & 0xFF)] ^
            a.rk[r * 4 + 1];
        var t2: u32 = Te0[@intCast(usize, s2 >> 24)] ^
            Te1[@intCast(usize, (s3 >> 16) & 0xFF)] ^
            Te2[@intCast(usize, (s0 >> 8) & 0xFF)] ^
            Te3[@intCast(usize, s1 & 0xFF)] ^
            a.rk[r * 4 + 2];
        var t3: u32 = Te0[@intCast(usize, s3 >> 24)] ^
            Te1[@intCast(usize, (s0 >> 16) & 0xFF)] ^
            Te2[@intCast(usize, (s1 >> 8) & 0xFF)] ^
            Te3[@intCast(usize, s2 & 0xFF)] ^
            a.rk[r * 4 + 3];
        s0 = t0;
        s1 = t1;
        s2 = t2;
        s3 = t3;
    }

    var t0: u32 = (@intCast(u32, SBOX[@intCast(usize, s0 >> 24)]) << 24) |
        (@intCast(u32, SBOX[@intCast(usize, (s1 >> 16) & 0xFF)]) << 16) |
        (@intCast(u32, SBOX[@intCast(usize, (s2 >> 8) & 0xFF)]) << 8) |
        @intCast(u32, SBOX[@intCast(usize, s3 & 0xFF)]);
    var t1: u32 = (@intCast(u32, SBOX[@intCast(usize, s1 >> 24)]) << 24) |
        (@intCast(u32, SBOX[@intCast(usize, (s2 >> 16) & 0xFF)]) << 16) |
        (@intCast(u32, SBOX[@intCast(usize, (s3 >> 8) & 0xFF)]) << 8) |
        @intCast(u32, SBOX[@intCast(usize, s0 & 0xFF)]);
    var t2: u32 = (@intCast(u32, SBOX[@intCast(usize, s2 >> 24)]) << 24) |
        (@intCast(u32, SBOX[@intCast(usize, (s3 >> 16) & 0xFF)]) << 16) |
        (@intCast(u32, SBOX[@intCast(usize, (s0 >> 8) & 0xFF)]) << 8) |
        @intCast(u32, SBOX[@intCast(usize, s1 & 0xFF)]);
    var t3: u32 = (@intCast(u32, SBOX[@intCast(usize, s3 >> 24)]) << 24) |
        (@intCast(u32, SBOX[@intCast(usize, (s0 >> 16) & 0xFF)]) << 16) |
        (@intCast(u32, SBOX[@intCast(usize, (s1 >> 8) & 0xFF)]) << 8) |
        @intCast(u32, SBOX[@intCast(usize, s2 & 0xFF)]);

    store32be(out[0..], 0, t0 ^ a.rk[40]);
    store32be(out[0..], 4, t1 ^ a.rk[41]);
    store32be(out[0..], 8, t2 ^ a.rk[42]);
    store32be(out[0..], 12, t3 ^ a.rk[43]);
}

// ---------------------------------------------------------------------------
// GHASH (4-bit tables) and AES-128-GCM (SP800-38D)
// ---------------------------------------------------------------------------

const GHash = struct {
    tab: [256]u8,
};

fn ghashMulX(x: []const u8, out: []u8) void {
    var y: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) y[i] = x[i];
    var lsb: u8 = y[15] & 1;
    i = 15;
    while (i > 0) : (i -= 1) {
        y[i] = (y[i] >> 1) | ((y[i - 1] & 1) << 7);
    }
    y[0] = y[0] >> 1;
    var lsb32: u32 = @intCast(u32, lsb);
    var m: u8 = @intCast(u8, (0 -% lsb32) & 0xFF);
    y[0] = y[0] ^ (0xe1 & m);
    i = 0;
    while (i < 16) : (i += 1) out[i] = y[i];
}

// Reduction constants for a 4-bit right shift of a 128-bit GHASH value:
// index = low nibble shifted out, values = the two high bytes to XOR back.
const GHASH_RED0 = [16]u8{
    0x00, 0x1c, 0x38, 0x24, 0x70, 0x6c, 0x48, 0x54,
    0xe1, 0xfd, 0xd9, 0xc5, 0x91, 0x8d, 0xa9, 0xb5,
};
const GHASH_RED1 = [16]u8{
    0x00, 0x20, 0x40, 0x60, 0x80, 0xa0, 0xc0, 0xe0,
    0x00, 0x20, 0x40, 0x60, 0x80, 0xa0, 0xc0, 0xe0,
};

// r = (r * x^4) ^ tab[nib], fused so the hot path is one 4-bit shift and one
// table XOR per nibble rather than four bit-at-a-time ghashMulX walks.
fn ghashMulNib(g: *const GHash, r: []u8, nib: usize) void {
    const lo: u8 = r[15] & 0x0F;
    var i: usize = 15;
    while (i > 0) : (i -= 1) {
        r[i] = (r[i] >> 4) | ((r[i - 1] & 0x0F) << 4);
    }
    r[0] = (r[0] >> 4) ^ GHASH_RED0[lo] ^ g.tab[nib * 16];
    r[1] = r[1] ^ GHASH_RED1[lo] ^ g.tab[nib * 16 + 1];
    i = 2;
    while (i < 16) : (i += 1) {
        r[i] = r[i] ^ g.tab[nib * 16 + i];
    }
}

fn ghashInit(g: *GHash, h: []const u8) void {
    var powers: [64]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) powers[i] = h[i];
    var j: usize = 1;
    while (j < 4) : (j += 1) {
        var prev: [16]u8 = undefined;
        var nx: [16]u8 = undefined;
        i = 0;
        while (i < 16) : (i += 1) prev[i] = powers[(j - 1) * 16 + i];
        ghashMulX(prev[0..], nx[0..]);
        i = 0;
        while (i < 16) : (i += 1) powers[j * 16 + i] = nx[i];
    }

    var v: usize = 0;
    while (v < 16) : (v += 1) {
        i = 0;
        while (i < 16) : (i += 1) g.tab[v * 16 + i] = 0;
        var bit: usize = 0;
        while (bit < 4) : (bit += 1) {
            var bitval: u32 = 0;
            if ((v & (8 >> bit)) != 0) bitval = 1;
            var msk: u8 = @intCast(u8, (0 -% bitval) & 0xFF);
            i = 0;
            while (i < 16) : (i += 1) {
                g.tab[v * 16 + i] = g.tab[v * 16 + i] ^ (powers[bit * 16 + i] & msk);
            }
        }
    }
}

fn ghashMulH(g: *const GHash, x: []const u8, out: []u8) void {
    var r: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) r[i] = 0;
    var bi: usize = 16;
    while (bi > 0) {
        bi -= 1;
        const b: u8 = x[bi];
        ghashMulNib(g, r[0..], @intCast(usize, b & 0x0F));
        ghashMulNib(g, r[0..], @intCast(usize, (b >> 4) & 0x0F));
    }
    i = 0;
    while (i < 16) : (i += 1) out[i] = r[i];
}

fn ghashUpdate(g: *const GHash, y: []u8, data: []const u8) void {
    var i: usize = 0;
    while (i + 16 <= data.len) {
        xor16(y, data, i);
        var t: [16]u8 = undefined;
        ghashMulH(g, y, t[0..]);
        var j: usize = 0;
        while (j < 16) : (j += 1) y[j] = t[j];
        i += 16;
    }
    if (i < data.len) {
        var block: [16]u8 = undefined;
        var j: usize = 0;
        while (j < 16) : (j += 1) block[j] = 0;
        j = 0;
        while (i + j < data.len) : (j += 1) block[j] = data[i + j];
        xor16(y, block[0..], 0);
        var t: [16]u8 = undefined;
        ghashMulH(g, y, t[0..]);
        j = 0;
        while (j < 16) : (j += 1) y[j] = t[j];
    }
}

fn inc32(ctr: []u8) void {
    var i: usize = 16;
    var carry: u32 = 1;
    while (i > 12) {
        i -= 1;
        var v: u32 = @intCast(u32, ctr[i]) + carry;
        ctr[i] = @intCast(u8, v & 0xFF);
        carry = v >> 8;
    }
}

fn gcmJ0(iv: []const u8, j0: []u8) void {
    var i: usize = 0;
    while (i < 12) : (i += 1) j0[i] = iv[i];
    j0[12] = 0;
    j0[13] = 0;
    j0[14] = 0;
    j0[15] = 1;
}

fn gcmCtr(a: *const Aes128, j0: []const u8, in: []const u8, out: []u8) void {
    var ctr: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) ctr[i] = j0[i];
    var off: usize = 0;
    while (off < in.len) {
        inc32(ctr[0..]);
        var ks: [16]u8 = undefined;
        aes128EncryptBlock(a, &ctr, &ks);
        var take: usize = in.len - off;
        if (take > 16) take = 16;
        var j: usize = 0;
        while (j < take) : (j += 1) out[off + j] = in[off + j] ^ ks[j];
        off += take;
    }
}

fn gcmTag(a: *const Aes128, g: *const GHash, j0: []const u8, ad: []const u8, ct: []const u8, tag: []u8) void {
    var y: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) y[i] = 0;
    ghashUpdate(g, y[0..], ad);
    ghashUpdate(g, y[0..], ct);
    var lens: [16]u8 = undefined;
    store64be(lens[0..], 0, @intCast(u64, ad.len) *% 8);
    store64be(lens[0..], 8, @intCast(u64, ct.len) *% 8);
    xor16(y[0..], lens[0..], 0);
    var t: [16]u8 = undefined;
    ghashMulH(g, y[0..], t[0..]);
    var jj: [16]u8 = undefined;
    i = 0;
    while (i < 16) : (i += 1) jj[i] = j0[i];
    var ek: [16]u8 = undefined;
    aes128EncryptBlock(a, &jj, &ek);
    i = 0;
    while (i < 16) : (i += 1) tag[i] = t[i] ^ ek[i];
}

pub fn aes128GcmSeal(key: *const [16]u8, iv: *const [12]u8, ad: []const u8, pt: []const u8, ct: []u8, tag: *[16]u8) !void {
    if (ct.len != pt.len) return error.Corrupt;
    var a = aes128Init(key);
    var h: [16]u8 = undefined;
    var zero: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) zero[i] = 0;
    aes128EncryptBlock(&a, &zero, &h);
    var g: GHash = undefined;
    ghashInit(&g, h[0..]);
    var j0: [16]u8 = undefined;
    gcmJ0(iv[0..], j0[0..]);
    gcmCtr(&a, j0[0..], pt, ct);
    gcmTag(&a, &g, j0[0..], ad, ct, tag[0..]);
}

pub fn aes128GcmOpen(key: *const [16]u8, iv: *const [12]u8, ad: []const u8, ct: []const u8, tag: *const [16]u8, pt: []u8) !void {
    if (pt.len != ct.len) return error.Corrupt;
    var a = aes128Init(key);
    var h: [16]u8 = undefined;
    var zero: [16]u8 = undefined;
    var i: usize = 0;
    while (i < 16) : (i += 1) zero[i] = 0;
    aes128EncryptBlock(&a, &zero, &h);
    var g: GHash = undefined;
    ghashInit(&g, h[0..]);
    var j0: [16]u8 = undefined;
    gcmJ0(iv[0..], j0[0..]);
    var want: [16]u8 = undefined;
    gcmTag(&a, &g, j0[0..], ad, ct, want[0..]);
    if (!ctEq16(want[0..], tag[0..])) return error.AuthenticationFailed;
    gcmCtr(&a, j0[0..], ct, pt);
}
