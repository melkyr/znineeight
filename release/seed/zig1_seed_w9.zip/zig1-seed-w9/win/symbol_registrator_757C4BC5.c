#include "symbol_registrator_757C4BC5.h"
zT_52CDA6EF_DepEdge zG_52CDA6EF_DepEdge;
/* depGraphInit */
zT_4D61441E_DepGraph zF_7F194604_depGraphInit(zT_3E40CD83_Sand* alloc) {
    zT_4D61441E_DepGraph zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_52CDA6EF_DepEdge*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.cap = zT_4;
    zT_1.alloc = alloc;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_1.in_degree_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.in_degree_cap = zT_6;
    return zT_1;
}

/* depGraphEnsureCapacity */
void zF_1729FC9C_depGraphEnsureCapac(zT_4D61441E_DepGraph* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_52CDA6EF_DepEdge* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    zT_DD2B0E80_Opt_263 zT_40;
    unsigned char zT_41;
    zT_3E40CD83_Sand* zT_43;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_FDFD82FD_EU_362 zT_53;
    unsigned char zT_54;
    unsigned char* zT_55;
    zT_52CDA6EF_DepEdge* zT_58;
    zT_52CDA6EF_DepEdge* zT_59;
    unsigned int zT_60;
    int zT_61;
    zT_52CDA6EF_DepEdge* zT_62;
    unsigned int zT_63;
    unsigned char zT_64;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_65;
    zT_52CDA6EF_DepEdge* zT_66;
    unsigned int zT_67;
    unsigned int zT_72;
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    unsigned int nc;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->len;
    zT_2 = self->cap;
    if ((unsigned char)(zT_1 < zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->cap;
    zT_6 = 8;
    if ((unsigned char)(zT_5 < (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 8;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->cap;
    zT_11 = 2;
    zT_12 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_8 = zT_12;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    zT_16 = self->cap;
    zT_17 = 0;
    if ((unsigned char)(zT_16 > (unsigned int)zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = self->alloc;
    zT_26 = self->items;
    zT_28 = self->cap;
    zT_29 = 8;
    zT_30 = zig_wrap_mul_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_mul_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_22 = zT_30;
    zT_34 = 8;
    zT_35 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    zT_23 = zT_35;
    zT_40 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), zT_22, zT_23, (unsigned int)(4));
    grown = zT_40;
    zT_41 = grown.has_value;
    if (zT_41) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_43 = self->alloc;
    zT_47 = 8;
    zT_48 = zig_wrap_mul_u(((zu64)(zT_47)), ((zu64)(nc)), 32u);
    zT_49 = zig_overflow_flag_mul_u(((zu64)(zT_47)), ((zu64)(nc)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_44 = zT_48;
    zT_53 = zF_1395EB68_sandAlloc(zT_43, zT_44, (unsigned int)(4));
    zT_54 = zT_53.is_error;
    if (zT_54) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_55 = zT_53.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_55;
    zT_58 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_58;
    zT_59 = self->items;
    zT_60 = self->len;
    zT_61 = 0;
    zT_62 = zT_59 + zT_61;
    zT_63 = zT_60 - zT_61;
    zT_64 = (unsigned int)zT_61 <= zT_60;
    if (!(zT_64)) { pal_trap(); }
    zT_65.ptr = (zT_52CDA6EF_DepEdge*)zT_62;
    zT_65.len = zT_63;
    zT_66 = zT_65.ptr;
    zT_67 = zT_65.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(i < zT_67)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_66[i];
    new_items[i] = item;
    goto z_bb_16;
    z_bb_15:
    self->items = new_items;
    self->cap = nc;
    return;
    z_bb_16:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_13;
}

/* depGraphAddEdge */
void zF_AA751A34_depGraphAddEdge(zT_4D61441E_DepGraph* self, unsigned int from, unsigned int to) {
    zT_4D61441E_DepGraph* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zT_3 = self;
    zF_1729FC9C_depGraphEnsureCapac(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->items;
    zT_6 = self->len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->len;
    zT_8 = 1;
    zT_9 = (unsigned int)zT_8;
    zT_10 = zig_wrap_add_u(((zu64)(zT_7)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_add_u(((zu64)(zT_7)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    self->len = zT_10;
    return;
}

/* depGraphFinalize */
void zF_371BD384_depGraphFinalize(zT_4D61441E_DepGraph* self, unsigned int max_type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned char zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_FDFD82FD_EU_362 zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned int* zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int* zT_43;
    zT_52CDA6EF_DepEdge* zT_44;
    zT_52CDA6EF_DepEdge zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned int* zT_54;
    zT_52CDA6EF_DepEdge* zT_55;
    zT_52CDA6EF_DepEdge zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    unsigned int count;
    unsigned char* raw;
    unsigned int i;
    zT_3 = 1;
    zT_4 = zig_wrap_add_u(((zu64)(max_type_id)), ((zu64)(zT_3)), 32u);
    zT_5 = zig_overflow_flag_add_u(((zu64)(max_type_id)), ((zu64)(zT_3)), 32u);
    zT_7 = zT_5 == (unsigned int)(0);
    if (!(zT_7)) { pal_trap(); }
    zT_8 = (unsigned int)zT_4;
    count = zT_8;
    zT_9 = self->in_degree_cap;
    if ((unsigned char)(count > zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self->alloc;
    zT_16 = 4;
    zT_17 = zig_wrap_mul_u(((zu64)(zT_16)), ((zu64)(count)), 32u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(zT_16)), ((zu64)(count)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_13 = zT_17;
    zT_22 = zF_1395EB68_sandAlloc(zT_12, zT_13, (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    i = zT_29;
    goto z_bb_6;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_24 = zT_22.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_24;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = count;
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_31 = 0;
    zT_32 = self->in_degree_items;
    zT_32[i] = zT_31;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    i = zT_35;
    goto z_bb_9;
    z_bb_8:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_41 = self->len;
    if ((unsigned char)(i < zT_41)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = self->in_degree_items;
    zT_44 = self->items;
    zT_45 = zT_44[i];
    zT_46 = zT_45.to;
    zT_47 = zT_43[zT_46];
    zT_48 = 1;
    zT_49 = (unsigned int)zT_48;
    zT_50 = zig_wrap_add_u(((zu64)(zT_47)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(zT_47)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = self->in_degree_items;
    zT_55 = self->items;
    zT_56 = zT_55[i];
    zT_57 = zT_56.to;
    zT_54[zT_57] = zT_50;
    zT_58 = 1;
    zT_59 = (unsigned int)zT_58;
    zT_60 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    i = zT_60;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    goto z_bb_10;
}

/* addTypeDependencies */
void zF_4976C319_addTypeDependencies(zT_6B0A7D14_AstStore* store, unsigned int decl_idx, unsigned int tid, zT_4D61441E_DepGraph* g) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_28;
    zT_22A7C88B_AstNode zT_29;
    zT_8143F551_AstKind zT_30;
    zT_4D61441E_DepGraph* zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    unsigned int children_n;
    unsigned int i;
    zT_22A7C88B_AstNode field_node;
    zT_5 = store;
    zT_6 = decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    zT_8 = store;
    zT_9 = decl_idx;
    zT_10 = zF_8BA26B9E_astStoreNodePayload(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = store;
    zT_15 = decl_idx;
    zT_16 = zF_152E19CB_astStoreNodeExtraCh(zT_14, zT_15);
    children_n = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < children_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = store;
    zT_24 = store;
    zT_25 = decl_idx;
    zT_28 = zF_B10B1BC1_astStoreNodeExtraCh(zT_24, zT_25, (unsigned int)((unsigned int)i));
    zT_23 = zT_28;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    field_node = zT_29;
    zT_30 = field_node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_34 = g;
    zT_36 = tid;
    zF_AA751A34_depGraphAddEdge(zT_34, (unsigned int)(0), zT_36);
    goto z_bb_8;
    z_bb_8:
    zT_38 = 1;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    i = zT_40;
    goto z_bb_6;
}

/* populateTypePayload */
void zF_020995FB_populateTypePayload(zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind decl_kind, unsigned int decl_idx, unsigned int tid, zT_3D7259E2_SymbolRegistry* sym_reg) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_9;
    unsigned char zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    unsigned char zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    int zT_39;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_55;
    unsigned int zT_56;
    int zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int zT_68;
    zT_22A7C88B_AstNode zT_69;
    zT_8143F551_AstKind zT_70;
    zT_338B7C76_TypeRegistry* zT_74;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    int zT_89;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_666DC2E1_TuplePayload zT_92;
    zT_666DC2E1_TuplePayload zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    unsigned int zT_103;
    zT_D155D06D_Type* zT_105;
    unsigned int zT_106;
    zT_D155D06D_Type zT_107;
    zT_D155D06D_Type* zT_108;
    unsigned int zT_109;
    unsigned int zT_114;
    unsigned int zT_115;
    int zT_117;
    unsigned int zT_118;
    int zT_120;
    unsigned int zT_121;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    unsigned int zT_130;
    zT_22A7C88B_AstNode zT_131;
    zT_8143F551_AstKind zT_132;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_2DF01B61_FieldEntry zT_137;
    zT_2DF01B61_FieldEntry zT_138;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned char zT_154;
    int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned char zT_160;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_406493CE_StructPayload zT_162;
    zT_406493CE_StructPayload zT_163;
    unsigned int zT_164;
    unsigned short zT_165;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_172;
    unsigned int zT_174;
    zT_D155D06D_Type* zT_176;
    unsigned int zT_177;
    zT_D155D06D_Type zT_178;
    zT_D155D06D_Type* zT_179;
    unsigned int zT_180;
    unsigned int zT_185;
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_189;
    int zT_191;
    unsigned int zT_192;
    zT_6B0A7D14_AstStore* zT_195;
    unsigned int zT_196;
    zT_6B0A7D14_AstStore* zT_197;
    unsigned int zT_198;
    unsigned int zT_201;
    zT_22A7C88B_AstNode zT_202;
    zT_8143F551_AstKind zT_203;
    zT_338B7C76_TypeRegistry* zT_207;
    zT_2DF01B61_FieldEntry zT_208;
    zT_2DF01B61_FieldEntry zT_209;
    zT_6B0A7D14_AstStore* zT_210;
    unsigned int zT_211;
    zT_6B0A7D14_AstStore* zT_212;
    unsigned int zT_213;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned char zT_231;
    unsigned char zT_232;
    int zT_234;
    int zT_236;
    zT_338B7C76_TypeRegistry* zT_238;
    zT_54FF90FA_TaggedUnionPayload zT_239;
    zT_54FF90FA_TaggedUnionPayload zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned short zT_243;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned char zT_250;
    unsigned int zT_252;
    zT_D155D06D_Type* zT_254;
    unsigned int zT_255;
    zT_D155D06D_Type zT_256;
    zT_D155D06D_Type* zT_257;
    unsigned int zT_258;
    zT_338B7C76_TypeRegistry* zT_259;
    zT_AF9231A2_UnionPayload zT_260;
    zT_AF9231A2_UnionPayload zT_261;
    unsigned int zT_262;
    unsigned short zT_263;
    unsigned int zT_264;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned char zT_271;
    unsigned int zT_273;
    zT_D155D06D_Type* zT_275;
    unsigned int zT_276;
    zT_D155D06D_Type zT_277;
    zT_D155D06D_Type* zT_278;
    unsigned int zT_279;
    zT_ABC1EBBE_TypeResolveEnv zT_284;
    zT_D3EB6303_StringInterner* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    zT_622E1E76_Opt_254 zT_288;
    zT_9BD83C17_Opt_442 zT_289;
    zT_99D838F1_Opt_444 zT_290;
    zT_939EE900_Arr_unsigned_int_1 zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    int zT_296;
    unsigned char zT_298;
    unsigned char zT_300;
    unsigned int zT_301;
    int zT_302;
    zT_ABC1EBBE_TypeResolveEnv* zT_305;
    unsigned int zT_306;
    unsigned int zT_311;
    unsigned char zT_314;
    int zT_317;
    unsigned char zT_319;
    unsigned char zT_320;
    unsigned int zT_322;
    unsigned int zT_323;
    int zT_325;
    unsigned int zT_326;
    int zT_328;
    unsigned int zT_329;
    int zT_331;
    unsigned int zT_332;
    zT_ABC1EBBE_TypeResolveEnv* zT_333;
    unsigned int zT_334;
    unsigned int* zT_339;
    unsigned int* zT_340;
    unsigned int* zT_341;
    unsigned char zT_350;
    zT_338B7C76_TypeRegistry* zT_351;
    zT_457ECFEE_EnumPayload zT_352;
    zT_457ECFEE_EnumPayload zT_353;
    unsigned int zT_354;
    unsigned short zT_355;
    int zT_356;
    unsigned char zT_358;
    unsigned int zT_359;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    unsigned char zT_366;
    unsigned int zT_368;
    zT_D155D06D_Type* zT_370;
    unsigned int zT_371;
    zT_D155D06D_Type zT_372;
    zT_D155D06D_Type* zT_373;
    unsigned int zT_374;
    unsigned int zT_379;
    unsigned int zT_380;
    int zT_382;
    unsigned int zT_383;
    zT_338B7C76_TypeRegistry* zT_385;
    unsigned int zT_386;
    zT_6B0A7D14_AstStore* zT_387;
    unsigned int zT_388;
    unsigned int zT_391;
    int zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned char zT_397;
    zT_338B7C76_TypeRegistry* zT_398;
    zT_0B73C507_ErrorSetPayload zT_399;
    zT_0B73C507_ErrorSetPayload zT_400;
    unsigned short zT_401;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    unsigned char zT_408;
    unsigned int zT_410;
    zT_D155D06D_Type* zT_412;
    unsigned int zT_413;
    zT_D155D06D_Type zT_414;
    zT_D155D06D_Type* zT_415;
    unsigned int zT_416;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_201, (unsigned int)sizeof zT_201);
    zig_poison_fill((void*)&zT_202, (unsigned int)sizeof zT_202);
    zig_poison_fill((void*)&zT_216, (unsigned int)sizeof zT_216);
    zig_poison_fill((void*)&zT_217, (unsigned int)sizeof zT_217);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zig_poison_fill((void*)&zT_289, (unsigned int)sizeof zT_289);
    zig_poison_fill((void*)&zT_290, (unsigned int)sizeof zT_290);
    zig_poison_fill((void*)&zT_311, (unsigned int)sizeof zT_311);
    zig_poison_fill((void*)&zT_350, (unsigned int)sizeof zT_350);
    zig_poison_fill((void*)&zT_391, (unsigned int)sizeof zT_391);
    zT_22A7C88B_AstNode node;
    unsigned char is_container;
    unsigned int children_n;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ti;
    zT_22A7C88B_AstNode efd;
    unsigned int tup_last;
    unsigned int tup_idx;
    zT_D155D06D_Type tty;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int i;
    zT_22A7C88B_AstNode fd;
    unsigned int st_last;
    unsigned int st_idx;
    zT_D155D06D_Type ty;
    unsigned int tu_last;
    unsigned int tu_idx;
    unsigned int un_last;
    unsigned int un_idx;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_939EE900_Arr_unsigned_int_1 backing_box;
    unsigned char expl_flag;
    unsigned int bt;
    unsigned int mstart;
    unsigned int mcount;
    unsigned int fail_node;
    unsigned int fail_kind;
    unsigned int en_last;
    unsigned int en_idx;
    unsigned int tags_start_idx;
    unsigned int es_last;
    unsigned int es_idx;
    zT_7 = store;
    zT_8 = decl_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_9;
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_18 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_22 = decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_22 = 1;
    goto z_bb_9;
    z_bb_9:
    is_container = zT_22;
    if ((unsigned char)(!is_container)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_28 = store;
    zT_29 = decl_idx;
    zT_30 = zF_8BA26B9E_astStoreNodePayload(zT_28, zT_29);
    zT_27 = zT_30 == (unsigned int)(0);
    goto z_bb_12;
    z_bb_11:
    zT_27 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_27) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return;
    z_bb_14:
    zT_34 = store;
    zT_35 = decl_idx;
    zT_36 = zF_152E19CB_astStoreNodeExtraCh(zT_34, zT_35);
    children_n = zT_36;
    if ((unsigned char)(!is_container)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_39 = 0;
    zT_38 = children_n == (unsigned int)zT_39;
    goto z_bb_17;
    z_bb_16:
    zT_38 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return;
    z_bb_19:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_45 = node.flags;
    zT_44 = (unsigned short)((unsigned short)((unsigned short)zT_45) & (unsigned short)(32)) != (unsigned short)(0);
    goto z_bb_22;
    z_bb_21:
    zT_44 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_44) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_52 = type_reg->xt_len;
    zT_53 = (unsigned int)zT_52;
    estart = zT_53;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    ecount = zT_56;
    zT_58 = 0;
    zT_59 = (unsigned int)zT_58;
    ti = zT_59;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_33; else goto z_bb_34;
    z_bb_25:
    if ((unsigned char)(ti < children_n)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_62 = store;
    zT_64 = store;
    zT_65 = decl_idx;
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_64, zT_65, (unsigned int)((unsigned int)ti));
    zT_63 = zT_68;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_62, zT_63);
    efd = zT_69;
    zT_70 = efd.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_89 = 0;
    if ((unsigned char)(ecount > (unsigned int)zT_89)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_83 = 1;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    ti = zT_85;
    goto z_bb_25;
    z_bb_29:
    zT_74 = type_reg;
    zF_4C03AE3D_xtAppend(zT_74, (unsigned int)(1));
    zT_77 = 1;
    zT_78 = (unsigned int)zT_77;
    zT_79 = zig_wrap_add_u(((zu64)(ecount)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_add_u(((zu64)(ecount)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    ecount = zT_79;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_91 = type_reg;
    zT_93.elems_start = estart;
    zT_94 = (unsigned short)zig_cast_checked_u((zu64)ecount, 32u, 0u, 16u);
    zT_93.elems_count = zT_94;
    zT_92 = zT_93;
    zF_C94DF842_tupAppend(zT_91, zT_92);
    zT_96 = type_reg->tup_len;
    zT_97 = 1;
    zT_98 = zig_wrap_sub_u(((zu64)(zT_96)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_sub_u(((zu64)(zT_96)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    tup_last = zT_98;
    zT_103 = (unsigned int)tup_last;
    tup_idx = zT_103;
    zT_105 = type_reg->types_items;
    zT_106 = (unsigned int)tid;
    zT_107 = zT_105[zT_106];
    tty = zT_107;
    tty.payload_idx = tup_idx;
    zT_108 = type_reg->types_items;
    zT_109 = (unsigned int)tid;
    zT_108[zT_109] = tty;
    goto z_bb_32;
    z_bb_32:
    return;
    z_bb_33:
    zT_114 = type_reg->fe_len;
    zT_115 = (unsigned int)zT_114;
    fstart = zT_115;
    zT_117 = 0;
    zT_118 = (unsigned int)zT_117;
    fcount = zT_118;
    zT_120 = 0;
    zT_121 = (unsigned int)zT_120;
    i = zT_121;
    goto z_bb_35;
    z_bb_34:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_35:
    if ((unsigned char)(i < children_n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_124 = store;
    zT_126 = store;
    zT_127 = decl_idx;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_126, zT_127, (unsigned int)((unsigned int)i));
    zT_125 = zT_130;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_124, zT_125);
    fd = zT_131;
    zT_132 = fd.kind;
    if ((unsigned char)(zT_132 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_161 = type_reg;
    zT_164 = (unsigned int)fstart;
    zT_163.fields_start = zT_164;
    zT_165 = (unsigned short)zig_cast_checked_u((zu64)fcount, 32u, 0u, 16u);
    zT_163.fields_count = zT_165;
    zT_162 = zT_163;
    zF_CF849366_stAppend(zT_161, zT_162);
    zT_167 = type_reg->st_len;
    zT_168 = 1;
    zT_169 = zig_wrap_sub_u(((zu64)(zT_167)), ((zu64)(zT_168)), 32u);
    zT_170 = zig_overflow_flag_sub_u(((zu64)(zT_167)), ((zu64)(zT_168)), 32u);
    zT_172 = zT_170 == (unsigned int)(0);
    if (!(zT_172)) { pal_trap(); }
    st_last = zT_169;
    zT_174 = (unsigned int)st_last;
    st_idx = zT_174;
    zT_176 = type_reg->types_items;
    zT_177 = (unsigned int)tid;
    zT_178 = zT_176[zT_177];
    ty = zT_178;
    ty.payload_idx = st_idx;
    zT_179 = type_reg->types_items;
    zT_180 = (unsigned int)tid;
    zT_179[zT_180] = ty;
    goto z_bb_34;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_136 = type_reg;
    zT_139 = store;
    zT_141 = store;
    zT_142 = decl_idx;
    zT_145 = zF_B10B1BC1_astStoreNodeExtraCh(zT_141, zT_142, (unsigned int)((unsigned int)i));
    zT_140 = zT_145;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_139, zT_140);
    zT_138.name_id = zT_146;
    zT_147 = 1;
    zT_138.type_id = zT_147;
    zT_148 = 0;
    zT_138.offset = zT_148;
    zT_137 = zT_138;
    zF_701DF154_feAppend(zT_136, zT_137);
    zT_149 = 1;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zig_wrap_add_u(((zu64)(fcount)), ((zu64)(zT_150)), 32u);
    zT_152 = zig_overflow_flag_add_u(((zu64)(fcount)), ((zu64)(zT_150)), 32u);
    zT_154 = zT_152 == (unsigned int)(0);
    if (!(zT_154)) { pal_trap(); }
    fcount = zT_151;
    goto z_bb_40;
    z_bb_40:
    zT_155 = 1;
    zT_156 = (unsigned int)zT_155;
    zT_157 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_156)), 32u);
    zT_158 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_156)), 32u);
    zT_160 = zT_158 == (unsigned int)(0);
    if (!(zT_160)) { pal_trap(); }
    i = zT_157;
    goto z_bb_38;
    z_bb_41:
    zT_185 = type_reg->fe_len;
    zT_186 = (unsigned int)zT_185;
    fstart = zT_186;
    zT_188 = 0;
    zT_189 = (unsigned int)zT_188;
    fcount = zT_189;
    zT_191 = 0;
    zT_192 = (unsigned int)zT_191;
    i = zT_192;
    goto z_bb_43;
    z_bb_42:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_52; else goto z_bb_53;
    z_bb_43:
    if ((unsigned char)(i < children_n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_195 = store;
    zT_197 = store;
    zT_198 = decl_idx;
    zT_201 = zF_B10B1BC1_astStoreNodeExtraCh(zT_197, zT_198, (unsigned int)((unsigned int)i));
    zT_196 = zT_201;
    zT_202 = zF_FCDD1D35_astStoreNodeAt(zT_195, zT_196);
    fd = zT_202;
    zT_203 = fd.kind;
    if ((unsigned char)(zT_203 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    zT_232 = node.flags;
    zT_234 = 1;
    zT_236 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_232) & zT_234) != zT_236)) goto z_bb_49; else goto z_bb_51;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_207 = type_reg;
    zT_210 = store;
    zT_212 = store;
    zT_213 = decl_idx;
    zT_216 = zF_B10B1BC1_astStoreNodeExtraCh(zT_212, zT_213, (unsigned int)((unsigned int)i));
    zT_211 = zT_216;
    zT_217 = zF_8BA26B9E_astStoreNodePayload(zT_210, zT_211);
    zT_209.name_id = zT_217;
    zT_218 = 1;
    zT_209.type_id = zT_218;
    zT_219 = 0;
    zT_209.offset = zT_219;
    zT_208 = zT_209;
    zF_701DF154_feAppend(zT_207, zT_208);
    zT_220 = 1;
    zT_221 = (unsigned int)zT_220;
    zT_222 = zig_wrap_add_u(((zu64)(fcount)), ((zu64)(zT_221)), 32u);
    zT_223 = zig_overflow_flag_add_u(((zu64)(fcount)), ((zu64)(zT_221)), 32u);
    zT_225 = zT_223 == (unsigned int)(0);
    if (!(zT_225)) { pal_trap(); }
    fcount = zT_222;
    goto z_bb_48;
    z_bb_48:
    zT_226 = 1;
    zT_227 = (unsigned int)zT_226;
    zT_228 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_227)), 32u);
    zT_229 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_227)), 32u);
    zT_231 = zT_229 == (unsigned int)(0);
    if (!(zT_231)) { pal_trap(); }
    i = zT_228;
    goto z_bb_46;
    z_bb_49:
    zT_238 = type_reg;
    zT_241 = 10;
    zT_240.tag_type = zT_241;
    zT_242 = (unsigned int)fstart;
    zT_240.fields_start = zT_242;
    zT_243 = (unsigned short)zig_cast_checked_u((zu64)fcount, 32u, 0u, 16u);
    zT_240.fields_count = zT_243;
    zT_239 = zT_240;
    zF_FB6B57C6_tuAppend(zT_238, zT_239);
    zT_245 = type_reg->tu_len;
    zT_246 = 1;
    zT_247 = zig_wrap_sub_u(((zu64)(zT_245)), ((zu64)(zT_246)), 32u);
    zT_248 = zig_overflow_flag_sub_u(((zu64)(zT_245)), ((zu64)(zT_246)), 32u);
    zT_250 = zT_248 == (unsigned int)(0);
    if (!(zT_250)) { pal_trap(); }
    tu_last = zT_247;
    zT_252 = (unsigned int)tu_last;
    tu_idx = zT_252;
    zT_254 = type_reg->types_items;
    zT_255 = (unsigned int)tid;
    zT_256 = zT_254[zT_255];
    ty = zT_256;
    ty.payload_idx = tu_idx;
    zT_257 = type_reg->types_items;
    zT_258 = (unsigned int)tid;
    zT_257[zT_258] = ty;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_42;
    z_bb_51:
    zT_259 = type_reg;
    zT_262 = (unsigned int)fstart;
    zT_261.fields_start = zT_262;
    zT_263 = (unsigned short)zig_cast_checked_u((zu64)fcount, 32u, 0u, 16u);
    zT_261.fields_count = zT_263;
    zT_264 = 1;
    zT_261.tag_type = zT_264;
    zT_260 = zT_261;
    zF_1718422E_unAppend(zT_259, zT_260);
    zT_266 = type_reg->un_len;
    zT_267 = 1;
    zT_268 = zig_wrap_sub_u(((zu64)(zT_266)), ((zu64)(zT_267)), 32u);
    zT_269 = zig_overflow_flag_sub_u(((zu64)(zT_266)), ((zu64)(zT_267)), 32u);
    zT_271 = zT_269 == (unsigned int)(0);
    if (!(zT_271)) { pal_trap(); }
    un_last = zT_268;
    zT_273 = (unsigned int)un_last;
    un_idx = zT_273;
    zT_275 = type_reg->types_items;
    zT_276 = (unsigned int)tid;
    zT_277 = zT_275[zT_276];
    ty = zT_277;
    ty.payload_idx = un_idx;
    zT_278 = type_reg->types_items;
    zT_279 = (unsigned int)tid;
    zT_278[zT_279] = ty;
    goto z_bb_50;
    z_bb_52:
    zT_284.store = store;
    zT_284.typereg = type_reg;
    zT_284.symbol_reg = sym_reg;
    zT_285 = type_reg->interner;
    zT_284.interner = zT_285;
    zT_286 = 4294967295u;
    zT_284.module_id = zT_286;
    zT_287 = 0;
    zT_284.source_file_id = zT_287;
    zT_288.has_value = 0;
    zT_284.diag = zT_288;
    zT_289.has_value = 0;
    zT_284.local_consts = zT_289;
    zT_290.has_value = 0;
    zT_284.local_types = zT_290;
    tre_env = zT_284;
    zT_293 = 0;
    zT_294 = 0;
    zT_292[zT_294] = zT_293;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        backing_box[_i] = zT_292[_i];
        _i++;
    }
}
    zT_295 = 10;
    zT_296 = 0;
    zT_298 = (unsigned int)zT_296 < (unsigned int)(1);
    if (!(zT_298)) { pal_trap(); }
    backing_box[zT_296] = zT_295;
    zT_300 = 0;
    expl_flag = zT_300;
    zT_301 = node.child_0;
    zT_302 = 0;
    if ((unsigned char)(zT_301 != (unsigned int)zT_302)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    if ((unsigned char)(decl_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_61; else goto z_bb_62;
    z_bb_54:
    zT_305 = (zT_ABC1EBBE_TypeResolveEnv*)&tre_env;
    zT_306 = node.child_0;
    zT_311 = zF_F2107C15_resolveTypeExprFull(zT_305, zT_306, (unsigned int)(0));
    bt = zT_311;
    if ((unsigned char)(bt != (unsigned int)(18))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_322 = type_reg->em_len;
    zT_323 = (unsigned int)zT_322;
    mstart = zT_323;
    zT_325 = 0;
    zT_326 = (unsigned int)zT_325;
    mcount = zT_326;
    zT_328 = 0;
    zT_329 = (unsigned int)zT_328;
    fail_node = zT_329;
    zT_331 = 0;
    zT_332 = (unsigned int)zT_331;
    fail_kind = zT_332;
    zT_333 = (zT_ABC1EBBE_TypeResolveEnv*)&tre_env;
    zT_334 = decl_idx;
    zT_339 = (unsigned int*)&mcount;
    zT_340 = (unsigned int*)&fail_node;
    zT_341 = (unsigned int*)&fail_kind;
    zT_350 = zF_0FFDEDBD_enumMembersResolve(zT_333, zT_334, (unsigned char)(1), (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), zT_339, zT_340, zT_341);
    (void)zT_350;
    zT_351 = type_reg;
    zT_354 = (unsigned int)mstart;
    zT_353.members_start = zT_354;
    zT_355 = (unsigned short)zig_cast_checked_u((zu64)mcount, 32u, 0u, 16u);
    zT_353.members_count = zT_355;
    zT_356 = 0;
    zT_358 = (unsigned int)zT_356 < (unsigned int)(1);
    if (!(zT_358)) { pal_trap(); }
    zT_359 = backing_box[zT_356];
    zT_353.backing_type = zT_359;
    zT_353.explicit_backing = expl_flag;
    zT_352 = zT_353;
    zF_298371DE_enAppend(zT_351, zT_352);
    zT_361 = type_reg->en_len;
    zT_362 = 1;
    zT_363 = zig_wrap_sub_u(((zu64)(zT_361)), ((zu64)(zT_362)), 32u);
    zT_364 = zig_overflow_flag_sub_u(((zu64)(zT_361)), ((zu64)(zT_362)), 32u);
    zT_366 = zT_364 == (unsigned int)(0);
    if (!(zT_366)) { pal_trap(); }
    en_last = zT_363;
    zT_368 = (unsigned int)en_last;
    en_idx = zT_368;
    zT_370 = type_reg->types_items;
    zT_371 = (unsigned int)tid;
    zT_372 = zT_370[zT_371];
    ty = zT_372;
    ty.payload_idx = en_idx;
    zT_373 = type_reg->types_items;
    zT_374 = (unsigned int)tid;
    zT_373[zT_374] = ty;
    goto z_bb_53;
    z_bb_56:
    zT_314 = bt != (unsigned int)(1);
    goto z_bb_58;
    z_bb_57:
    zT_314 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_314) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_317 = 0;
    zT_319 = (unsigned int)zT_317 < (unsigned int)(1);
    if (!(zT_319)) { pal_trap(); }
    backing_box[zT_317] = bt;
    goto z_bb_60;
    z_bb_60:
    zT_320 = 1;
    expl_flag = zT_320;
    goto z_bb_55;
    z_bb_61:
    zT_379 = type_reg->xn_len;
    zT_380 = (unsigned int)zT_379;
    tags_start_idx = zT_380;
    zT_382 = 0;
    zT_383 = (unsigned int)zT_382;
    i = zT_383;
    goto z_bb_63;
    z_bb_62:
    return;
    z_bb_63:
    if ((unsigned char)(i < children_n)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_385 = type_reg;
    zT_387 = store;
    zT_388 = decl_idx;
    zT_391 = zF_B10B1BC1_astStoreNodeExtraCh(zT_387, zT_388, (unsigned int)((unsigned int)i));
    zT_386 = zT_391;
    zF_A648B1CB_xnAppend(zT_385, zT_386);
    goto z_bb_66;
    z_bb_65:
    zT_398 = type_reg;
    zT_400.tags_start = tags_start_idx;
    zT_401 = (unsigned short)zig_cast_checked_u((zu64)children_n, 32u, 0u, 16u);
    zT_400.tags_count = zT_401;
    zT_399 = zT_400;
    zF_B86143DD_esAppend(zT_398, zT_399);
    zT_403 = type_reg->es_len;
    zT_404 = 1;
    zT_405 = zig_wrap_sub_u(((zu64)(zT_403)), ((zu64)(zT_404)), 32u);
    zT_406 = zig_overflow_flag_sub_u(((zu64)(zT_403)), ((zu64)(zT_404)), 32u);
    zT_408 = zT_406 == (unsigned int)(0);
    if (!(zT_408)) { pal_trap(); }
    es_last = zT_405;
    zT_410 = (unsigned int)es_last;
    es_idx = zT_410;
    zT_412 = type_reg->types_items;
    zT_413 = (unsigned int)tid;
    zT_414 = zT_412[zT_413];
    ty = zT_414;
    ty.payload_idx = es_idx;
    zT_415 = type_reg->types_items;
    zT_416 = (unsigned int)tid;
    zT_415[zT_416] = ty;
    goto z_bb_62;
    z_bb_66:
    zT_392 = 1;
    zT_393 = (unsigned int)zT_392;
    zT_394 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_393)), 32u);
    zT_395 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_393)), 32u);
    zT_397 = zT_395 == (unsigned int)(0);
    if (!(zT_397)) { pal_trap(); }
    i = zT_394;
    goto z_bb_63;
}

/* registerDecl */
void zF_CBEB26BC_registerDecl(zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int mod_id, unsigned int decl_idx, zT_4D61441E_DepGraph* g, zT_072B53A6_ModuleRegistry* reg, unsigned char populate) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_11;
    zT_8143F551_AstKind zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_4028D896_Arr_unsigned_char_2 zT_28;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_49;
    unsigned char* zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_3C598AEF_SymbolKind zT_61;
    unsigned int zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode zT_72;
    zT_8143F551_AstKind zT_73;
    zT_072B53A6_ModuleRegistry* zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_83;
    zT_BAEE192E_Opt_10 zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_4028D896_Arr_unsigned_char_2 zT_91;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    unsigned int zT_98;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_116;
    unsigned char* zT_117;
    unsigned int zT_118;
    unsigned char zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char zT_121;
    unsigned char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    zT_3C598AEF_SymbolKind zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_136;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_157;
    unsigned char* zT_158;
    unsigned int zT_159;
    unsigned char zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_168;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    int zT_174;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_189;
    unsigned char* zT_190;
    unsigned int zT_191;
    unsigned char zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_200;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    int zT_206;
    unsigned char* zT_207;
    unsigned int zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned char zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_221;
    unsigned char* zT_222;
    unsigned int zT_223;
    unsigned char zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    zT_338B7C76_TypeRegistry* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned char* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_8143F551_AstKind zT_234;
    unsigned char zT_238;
    zT_8143F551_AstKind zT_239;
    unsigned char zT_243;
    zT_8143F551_AstKind zT_244;
    unsigned char zT_248;
    zT_8143F551_AstKind zT_249;
    zT_8143F551_AstKind zT_254;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char zT_256;
    int zT_260;
    zT_33EF6BFB_TypeKind zT_262;
    unsigned char zT_269;
    int zT_273;
    zT_33EF6BFB_TypeKind zT_275;
    unsigned char zT_278;
    int zT_280;
    int zT_282;
    zT_33EF6BFB_TypeKind zT_284;
    zT_338B7C76_TypeRegistry* zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    unsigned int zT_297;
    zT_8143F551_AstKind zT_298;
    unsigned char zT_302;
    zT_8143F551_AstKind zT_303;
    unsigned char zT_307;
    unsigned char zT_308;
    zT_338B7C76_TypeRegistry* zT_314;
    unsigned int zT_315;
    zT_338B7C76_TypeRegistry* zT_316;
    zT_6B0A7D14_AstStore* zT_317;
    zT_8143F551_AstKind zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    zT_3D7259E2_SymbolRegistry* zT_321;
    zT_6B0A7D14_AstStore* zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    zT_4D61441E_DepGraph* zT_327;
    zT_3C598AEF_SymbolKind zT_330;
    zT_8143F551_AstKind zT_331;
    unsigned char* zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    zT_6B0A7D14_AstStore* zT_341;
    unsigned int zT_342;
    unsigned int zT_344;
    zT_6B0A7D14_AstStore* zT_346;
    unsigned int zT_347;
    unsigned int zT_349;
    unsigned char* zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_79FAE712_u64 zT_358;
    zT_79FAE712_u64 zT_359;
    zT_79FAE712_u64 zT_360;
    zT_79FAE712_u64 zT_361;
    unsigned int zT_362;
    unsigned char zT_364;
    zT_79FAE712_u64 zT_365;
    zT_79FAE712_u64 zT_366;
    unsigned int zT_367;
    unsigned char zT_369;
    zT_BAEE192E_Opt_10 zT_370;
    unsigned char zT_371;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_BAEE192E_Opt_10 zT_376;
    unsigned char zT_377;
    unsigned char* zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned int zT_382;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_383;
    unsigned int zT_384;
    zT_79FAE712_u64 zT_386;
    zT_79FAE712_u64 zT_387;
    zT_79FAE712_u64 zT_388;
    unsigned int zT_389;
    unsigned char zT_391;
    zT_79FAE712_u64 zT_392;
    zT_79FAE712_u64 zT_393;
    unsigned int zT_394;
    unsigned char zT_396;
    zT_338B7C76_TypeRegistry* zT_397;
    zT_79FAE712_u64 zT_398;
    unsigned int zT_399;
    zT_3C598AEF_SymbolKind zT_401;
    unsigned char zT_403;
    zT_D3EB6303_StringInterner* zT_405;
    unsigned int zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_409;
    unsigned char* zT_410;
    unsigned int zT_412;
    zT_338B7C76_TypeRegistry* zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    unsigned int zT_418;
    zT_79FAE712_u64 zT_422;
    zT_79FAE712_u64 zT_423;
    zT_79FAE712_u64 zT_424;
    unsigned int zT_425;
    unsigned char zT_427;
    zT_79FAE712_u64 zT_428;
    zT_79FAE712_u64 zT_429;
    unsigned int zT_430;
    unsigned char zT_432;
    zT_338B7C76_TypeRegistry* zT_433;
    zT_79FAE712_u64 zT_434;
    unsigned int zT_435;
    zT_3C598AEF_SymbolKind zT_437;
    zT_8143F551_AstKind zT_438;
    unsigned char zT_442;
    zT_8143F551_AstKind zT_443;
    unsigned char zT_447;
    zT_8143F551_AstKind zT_448;
    unsigned char zT_452;
    zT_8143F551_AstKind zT_453;
    unsigned char zT_457;
    zT_8143F551_AstKind zT_458;
    unsigned char zT_462;
    zT_8143F551_AstKind zT_463;
    unsigned char zT_467;
    zT_8143F551_AstKind zT_468;
    unsigned char* zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned int zT_477;
    zT_338B7C76_TypeRegistry* zT_479;
    zT_79FAE712_u64 zT_480;
    zT_79FAE712_u64 zT_481;
    zT_79FAE712_u64 zT_482;
    zT_79FAE712_u64 zT_483;
    unsigned int zT_484;
    unsigned char zT_486;
    zT_79FAE712_u64 zT_487;
    zT_79FAE712_u64 zT_488;
    unsigned int zT_489;
    unsigned char zT_491;
    zT_BAEE192E_Opt_10 zT_492;
    unsigned char zT_493;
    zT_338B7C76_TypeRegistry* zT_495;
    zT_BAEE192E_Opt_10 zT_498;
    unsigned char zT_499;
    zT_3C598AEF_SymbolKind zT_502;
    zT_3A105EF1_Symbol zT_504;
    unsigned char zT_505;
    unsigned short zT_506;
    zT_E41AEC18_ModuleEntryArrayLis zT_507;
    zT_6E8D187B_ModuleEntry* zT_508;
    unsigned int zT_509;
    zT_6E8D187B_ModuleEntry zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    zT_3D7259E2_SymbolRegistry* zT_514;
    unsigned int zT_515;
    zT_060CD1EB_SymbolTable* zT_516;
    zT_060CD1EB_SymbolTable* zT_518;
    zT_3A105EF1_Symbol zT_519;
    unsigned char zT_520;
    unsigned char* zT_523;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_524;
    unsigned int zT_525;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_526;
    unsigned char* zT_528;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_529;
    unsigned int zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_531;
    zT_4028D896_Arr_unsigned_char_2 zT_533;
    unsigned int zT_535;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    int zT_539;
    unsigned char* zT_540;
    unsigned int zT_541;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_542;
    unsigned int zT_543;
    unsigned int zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    unsigned char zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    unsigned int zT_553;
    unsigned char zT_555;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_556;
    unsigned int zT_559;
    unsigned char* zT_560;
    unsigned int zT_561;
    unsigned char zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    unsigned char* zT_565;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_566;
    unsigned int zT_567;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_568;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_571;
    int zT_575;
    unsigned char* zT_576;
    unsigned int zT_577;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_578;
    unsigned int zT_579;
    unsigned int zT_581;
    unsigned int zT_582;
    unsigned int zT_583;
    unsigned int zT_584;
    unsigned char zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned char zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    unsigned int zT_595;
    unsigned char* zT_596;
    unsigned int zT_597;
    unsigned char zT_598;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_599;
    unsigned char* zT_601;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_602;
    unsigned int zT_603;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_604;
    unsigned char* zT_606;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_607;
    unsigned int zT_608;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_609;
    zT_4EF476FD_anon_318191 zT_611;
    zT_243D6A41_FnProto* zT_612;
    zT_6B0A7D14_AstStore* zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_616;
    zT_243D6A41_FnProto zT_617;
    zT_3A105EF1_Symbol zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    zT_3C598AEF_SymbolKind zT_623;
    unsigned char zT_624;
    unsigned short zT_625;
    zT_E41AEC18_ModuleEntryArrayLis zT_626;
    zT_6E8D187B_ModuleEntry* zT_627;
    unsigned int zT_628;
    zT_6E8D187B_ModuleEntry zT_629;
    unsigned int zT_630;
    unsigned int zT_631;
    zT_3D7259E2_SymbolRegistry* zT_633;
    unsigned int zT_634;
    zT_060CD1EB_SymbolTable* zT_635;
    zT_060CD1EB_SymbolTable* zT_636;
    zT_3A105EF1_Symbol zT_637;
    unsigned char zT_638;
    zT_6B0A7D14_AstStore* zT_639;
    unsigned int zT_640;
    unsigned int zT_641;
    zT_3A105EF1_Symbol zT_645;
    zT_6B0A7D14_AstStore* zT_646;
    unsigned int zT_647;
    unsigned int zT_648;
    unsigned int zT_649;
    zT_3C598AEF_SymbolKind zT_651;
    unsigned char zT_652;
    unsigned short zT_653;
    zT_E41AEC18_ModuleEntryArrayLis zT_654;
    zT_6E8D187B_ModuleEntry* zT_655;
    unsigned int zT_656;
    zT_6E8D187B_ModuleEntry zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_3D7259E2_SymbolRegistry* zT_661;
    unsigned int zT_662;
    zT_060CD1EB_SymbolTable* zT_663;
    zT_060CD1EB_SymbolTable* zT_664;
    zT_3A105EF1_Symbol zT_665;
    unsigned char zT_666;
    zT_6B0A7D14_AstStore* zT_668;
    unsigned int zT_669;
    zT_8143F551_AstKind zT_670;
    zT_79FAE712_u64 zT_672;
    zT_79FAE712_u64 zT_674;
    unsigned int zT_675;
    zT_8143F551_AstKind zT_677;
    zT_33EF6BFB_TypeKind zT_678;
    unsigned char zT_679;
    int zT_683;
    zT_33EF6BFB_TypeKind zT_685;
    unsigned char zT_692;
    int zT_696;
    zT_33EF6BFB_TypeKind zT_698;
    unsigned char zT_701;
    int zT_703;
    int zT_705;
    zT_33EF6BFB_TypeKind zT_707;
    zT_338B7C76_TypeRegistry* zT_715;
    unsigned int zT_716;
    unsigned int zT_717;
    zT_33EF6BFB_TypeKind zT_718;
    unsigned int zT_719;
    zT_8143F551_AstKind zT_720;
    unsigned char zT_724;
    zT_8143F551_AstKind zT_725;
    unsigned char zT_729;
    unsigned char zT_730;
    zT_338B7C76_TypeRegistry* zT_736;
    unsigned int zT_737;
    zT_338B7C76_TypeRegistry* zT_738;
    zT_6B0A7D14_AstStore* zT_739;
    zT_8143F551_AstKind zT_740;
    unsigned int zT_741;
    unsigned int zT_742;
    zT_3D7259E2_SymbolRegistry* zT_743;
    zT_6B0A7D14_AstStore* zT_745;
    unsigned int zT_746;
    unsigned int zT_747;
    zT_4D61441E_DepGraph* zT_748;
    zT_3A105EF1_Symbol zT_750;
    zT_3C598AEF_SymbolKind zT_752;
    unsigned char zT_753;
    unsigned short zT_754;
    zT_E41AEC18_ModuleEntryArrayLis zT_755;
    zT_6E8D187B_ModuleEntry* zT_756;
    unsigned int zT_757;
    zT_6E8D187B_ModuleEntry zT_758;
    unsigned int zT_759;
    unsigned int zT_760;
    zT_3D7259E2_SymbolRegistry* zT_762;
    unsigned int zT_763;
    zT_060CD1EB_SymbolTable* zT_764;
    zT_060CD1EB_SymbolTable* zT_765;
    zT_3A105EF1_Symbol zT_766;
    unsigned char zT_767;
    zT_6B0A7D14_AstStore* zT_769;
    unsigned int zT_770;
    zT_8143F551_AstKind zT_771;
    zT_79FAE712_u64 zT_773;
    zT_79FAE712_u64 zT_775;
    unsigned int zT_776;
    zT_338B7C76_TypeRegistry* zT_778;
    unsigned int zT_779;
    unsigned int zT_780;
    unsigned int zT_784;
    zT_338B7C76_TypeRegistry* zT_785;
    zT_6B0A7D14_AstStore* zT_786;
    zT_8143F551_AstKind zT_787;
    unsigned int zT_788;
    unsigned int zT_789;
    zT_3D7259E2_SymbolRegistry* zT_790;
    zT_3A105EF1_Symbol zT_793;
    zT_3C598AEF_SymbolKind zT_795;
    unsigned char zT_796;
    unsigned short zT_797;
    zT_E41AEC18_ModuleEntryArrayLis zT_798;
    zT_6E8D187B_ModuleEntry* zT_799;
    unsigned int zT_800;
    zT_6E8D187B_ModuleEntry zT_801;
    unsigned int zT_802;
    unsigned int zT_803;
    zT_3D7259E2_SymbolRegistry* zT_805;
    unsigned int zT_806;
    zT_060CD1EB_SymbolTable* zT_807;
    zT_060CD1EB_SymbolTable* zT_808;
    zT_3A105EF1_Symbol zT_809;
    unsigned char zT_810;
    zT_6B0A7D14_AstStore* zT_812;
    unsigned int zT_813;
    unsigned int zT_814;
    zT_072B53A6_ModuleRegistry* zT_816;
    unsigned int zT_817;
    zT_BAEE192E_Opt_10 zT_818;
    unsigned char zT_819;
    zT_3A105EF1_Symbol zT_822;
    zT_338B7C76_TypeRegistry* zT_823;
    unsigned int zT_824;
    unsigned int zT_825;
    zT_3C598AEF_SymbolKind zT_827;
    unsigned short zT_828;
    zT_E41AEC18_ModuleEntryArrayLis zT_829;
    zT_6E8D187B_ModuleEntry* zT_830;
    unsigned int zT_831;
    zT_6E8D187B_ModuleEntry zT_832;
    unsigned int zT_833;
    unsigned int zT_834;
    zT_3D7259E2_SymbolRegistry* zT_836;
    unsigned int zT_837;
    zT_060CD1EB_SymbolTable* zT_838;
    zT_060CD1EB_SymbolTable* zT_839;
    zT_3A105EF1_Symbol zT_840;
    unsigned char zT_841;
    unsigned char* zT_843;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_844;
    unsigned int zT_845;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_846;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_848;
    unsigned int zT_850;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_851;
    int zT_854;
    unsigned char* zT_855;
    unsigned int zT_856;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_857;
    unsigned int zT_858;
    unsigned int zT_860;
    unsigned int zT_861;
    unsigned int zT_862;
    unsigned int zT_863;
    unsigned char zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_866;
    unsigned int zT_869;
    unsigned char* zT_870;
    unsigned int zT_871;
    unsigned char zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_873;
    unsigned char* zT_875;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_876;
    unsigned int zT_877;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_878;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_880;
    unsigned int zT_882;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_883;
    int zT_886;
    unsigned char* zT_887;
    unsigned int zT_888;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_889;
    unsigned int zT_890;
    unsigned int zT_892;
    unsigned int zT_893;
    unsigned int zT_894;
    unsigned int zT_895;
    unsigned char zT_897;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_898;
    unsigned int zT_901;
    unsigned char* zT_902;
    unsigned int zT_903;
    unsigned char zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_905;
    unsigned char* zT_907;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_908;
    unsigned int zT_909;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_910;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_105, (unsigned int)sizeof zT_105);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zig_poison_fill((void*)&zT_210, (unsigned int)sizeof zT_210);
    zig_poison_fill((void*)&zT_228, (unsigned int)sizeof zT_228);
    zig_poison_fill((void*)&zT_297, (unsigned int)sizeof zT_297);
    zig_poison_fill((void*)&zT_344, (unsigned int)sizeof zT_344);
    zig_poison_fill((void*)&zT_349, (unsigned int)sizeof zT_349);
    zig_poison_fill((void*)&zT_370, (unsigned int)sizeof zT_370);
    zig_poison_fill((void*)&zT_376, (unsigned int)sizeof zT_376);
    zig_poison_fill((void*)&zT_408, (unsigned int)sizeof zT_408);
    zig_poison_fill((void*)&zT_412, (unsigned int)sizeof zT_412);
    zig_poison_fill((void*)&zT_418, (unsigned int)sizeof zT_418);
    zig_poison_fill((void*)&zT_492, (unsigned int)sizeof zT_492);
    zig_poison_fill((void*)&zT_498, (unsigned int)sizeof zT_498);
    zig_poison_fill((void*)&zT_516, (unsigned int)sizeof zT_516);
    zig_poison_fill((void*)&zT_520, (unsigned int)sizeof zT_520);
    zig_poison_fill((void*)&zT_543, (unsigned int)sizeof zT_543);
    zig_poison_fill((void*)&zT_579, (unsigned int)sizeof zT_579);
    zig_poison_fill((void*)&zT_615, (unsigned int)sizeof zT_615);
    zig_poison_fill((void*)&zT_635, (unsigned int)sizeof zT_635);
    zig_poison_fill((void*)&zT_638, (unsigned int)sizeof zT_638);
    zig_poison_fill((void*)&zT_641, (unsigned int)sizeof zT_641);
    zig_poison_fill((void*)&zT_648, (unsigned int)sizeof zT_648);
    zig_poison_fill((void*)&zT_663, (unsigned int)sizeof zT_663);
    zig_poison_fill((void*)&zT_666, (unsigned int)sizeof zT_666);
    zig_poison_fill((void*)&zT_672, (unsigned int)sizeof zT_672);
    zig_poison_fill((void*)&zT_719, (unsigned int)sizeof zT_719);
    zig_poison_fill((void*)&zT_764, (unsigned int)sizeof zT_764);
    zig_poison_fill((void*)&zT_767, (unsigned int)sizeof zT_767);
    zig_poison_fill((void*)&zT_773, (unsigned int)sizeof zT_773);
    zig_poison_fill((void*)&zT_784, (unsigned int)sizeof zT_784);
    zig_poison_fill((void*)&zT_807, (unsigned int)sizeof zT_807);
    zig_poison_fill((void*)&zT_810, (unsigned int)sizeof zT_810);
    zig_poison_fill((void*)&zT_814, (unsigned int)sizeof zT_814);
    zig_poison_fill((void*)&zT_818, (unsigned int)sizeof zT_818);
    zig_poison_fill((void*)&zT_825, (unsigned int)sizeof zT_825);
    zig_poison_fill((void*)&zT_838, (unsigned int)sizeof zT_838);
    zig_poison_fill((void*)&zT_841, (unsigned int)sizeof zT_841);
    zig_poison_fill((void*)&zT_858, (unsigned int)sizeof zT_858);
    zig_poison_fill((void*)&zT_890, (unsigned int)sizeof zT_890);
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ra_msg;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12m;
    zT_4028D896_Arr_unsigned_char_2 d12b;
    unsigned int d12l;
    unsigned int d12s;
    zT_8F083A69_Slice_zT_0B42B2F8_u d12nl;
    zT_3C598AEF_SymbolKind sym_kind;
    unsigned int sym_mod_id;
    unsigned int sym_type_id;
    zT_243D6A41_FnProto proto;
    zT_3A105EF1_Symbol sym;
    zT_060CD1EB_SymbolTable* table;
    zT_33EF6BFB_TypeKind type_kind;
    unsigned int tid;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target_mod_id;
    zT_22A7C88B_AstNode init_node;
    unsigned char inserted;
    zT_BAEE192E_Opt_10 target;
    zT_8F083A69_Slice_zT_0B42B2F8_u m5m;
    zT_4028D896_Arr_unsigned_char_2 m5pb;
    unsigned int m5pl;
    unsigned int m5ps;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_m;
    zT_5A26C2ED_Arr_unsigned_char_1 di_mb;
    unsigned int di_ml;
    unsigned int di_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_t;
    zT_5A26C2ED_Arr_unsigned_char_1 di_tb;
    unsigned int di_tl;
    unsigned int di_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u di_n;
    zT_5A26C2ED_Arr_unsigned_char_1 di_nb;
    unsigned int di_nl;
    unsigned int di_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rf_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_m;
    unsigned int ident_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_i;
    zT_BAEE192E_Opt_10 cached;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rca_h;
    zT_79FAE712_u64 ck;
    unsigned char arb_u;
    zT_8F083A69_Slice_zT_0B42B2F8_u ident_text;
    unsigned int arb_tid;
    zT_79FAE712_u64 atk;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_m;
    zT_BAEE192E_Opt_10 acached;
    unsigned int act;
    zT_8F083A69_Slice_zT_0B42B2F8_u vr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd;
    zT_4028D896_Arr_unsigned_char_2 vb;
    unsigned int vn;
    unsigned int vns;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc;
    unsigned int vk;
    unsigned int vks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ven;
    zT_8F083A69_Slice_zT_0B42B2F8_u vi_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u imr;
    zT_5A26C2ED_Arr_unsigned_char_1 imb;
    unsigned int iml;
    unsigned int ims;
    zT_8F083A69_Slice_zT_0B42B2F8_u imm;
    zT_5A26C2ED_Arr_unsigned_char_1 immb;
    unsigned int imml;
    unsigned int imms;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsnl;
    zT_9 = store;
    zT_10 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_11;
    zT_12 = node.kind;
switch (zT_12) {
case 1: goto z_bb_1;
case 2: goto z_bb_2;
case 8: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
case 9: goto z_bb_5;
case 91: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    zT_14 = "Ra";
    zT_16 = 2;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    ra_msg = zT_15;
    zT_17 = ra_msg;
    zF_B5478454_measureMarkerWrite(zT_17);
    zT_19 = store;
    zT_20 = decl_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    name_id = zT_21;
    zT_23 = "D12:n";
    zT_25 = 5;
    zT_24.ptr = (unsigned char*)zT_23;
    zT_24.len = zT_25;
    d12m = zT_24;
    zT_26 = d12m;
    zF_B5478454_measureMarkerWrite(zT_26);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d12b[_i] = zT_28[_i];
        _i++;
    }
}
    zT_30 = name_id;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)d12b) + zT_34;
    zT_36 = (unsigned int)(20) - zT_34;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zT_38 = zF_A7504564_itoa(zT_30, zT_31);
    d12l = zT_38;
    zT_40 = 19;
    zT_41 = (unsigned int)d12l;
    zT_42 = zig_wrap_sub_u(((zu64)(zT_40)), ((zu64)(zT_41)), 32u);
    zT_43 = zig_overflow_flag_sub_u(((zu64)(zT_40)), ((zu64)(zT_41)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    d12s = zT_42;
    zT_49 = 19;
    zT_50 = (unsigned char*)((unsigned char*)d12b) + d12s;
    zT_51 = zT_49 - d12s;
    zT_52 = d12s <= zT_49;
    if (!(zT_52)) { pal_trap(); }
    zT_53.ptr = (unsigned char*)zT_50;
    zT_53.len = zT_51;
    zT_46 = zT_53;
    zF_B5478454_measureMarkerWrite(zT_46);
    zT_55 = "\n";
    zT_57 = 1;
    zT_56.ptr = (unsigned char*)zT_55;
    zT_56.len = zT_57;
    d12nl = zT_56;
    zT_58 = d12nl;
    zF_B5478454_measureMarkerWrite(zT_58);
    zT_61 = zT_3C598AEF_SymbolKind_global;
    sym_kind = zT_61;
    sym_mod_id = mod_id;
    zT_64 = 0;
    sym_type_id = zT_64;
    zT_65 = node.child_1;
    zT_66 = 0;
    if ((unsigned char)(zT_65 != (unsigned int)zT_66)) goto z_bb_10; else goto z_bb_11;
    z_bb_2:
    zT_611 = store->fn_protos;
    zT_612 = zT_611.items;
    zT_613 = store;
    zT_614 = decl_idx;
    zT_615 = zF_8BA26B9E_astStoreNodePayload(zT_613, zT_614);
    zT_616 = (unsigned int)zT_615;
    zT_617 = zT_612[zT_616];
    proto = zT_617;
    zT_620 = proto.name_id;
    zT_619.name_id = zT_620;
    zT_621 = 0;
    zT_619.type_id = zT_621;
    zT_623 = zT_3C598AEF_SymbolKind_function;
    zT_619.kind = zT_623;
    zT_624 = node.flags;
    zT_625 = (unsigned short)zT_624;
    zT_619.flags = zT_625;
    zT_619.decl_node = decl_idx;
    zT_619.module_id = mod_id;
    zT_626 = reg->modules;
    zT_627 = zT_626.items;
    zT_628 = (unsigned int)mod_id;
    zT_629 = zT_627[zT_628];
    zT_630 = zT_629.source_file_id;
    zT_619.file_id = zT_630;
    zT_631 = 0;
    zT_619.scope_level = zT_631;
    sym = zT_619;
    zT_633 = sym_reg;
    zT_634 = mod_id;
    zT_635 = zF_9B36C202_symbolRegistryGetTa(zT_633, zT_634);
    table = zT_635;
    zT_636 = table;
    zT_637 = sym;
    zT_638 = zF_D0156DDA_symbolTableInsert(zT_636, zT_637);
    (void)zT_638;
    goto z_bb_9;
    z_bb_3:
    zT_639 = store;
    zT_640 = decl_idx;
    zT_641 = zF_8BA26B9E_astStoreNodePayload(zT_639, zT_640);
    if ((unsigned char)(zT_641 != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_4:
    zT_668 = store;
    zT_669 = decl_idx;
    zT_670 = node.kind;
    zT_672 = zF_0E4E10C6_astStoreNodePayload(zT_668, zT_669, zT_670);
    zT_674 = zT_672 & (zT_79FAE712_u64)(4294967295u);
    zT_675 = (unsigned int)zig_cast_checked_u((zu64)zT_674, 64u, 0u, 32u);
    name_id = zT_675;
    zT_677 = node.kind;
switch (zT_677) {
case 3: goto z_bb_95;
case 4: goto z_bb_96;
case 5: goto z_bb_97;
default: goto z_bb_98;
}
    z_bb_5:
    zT_769 = store;
    zT_770 = decl_idx;
    zT_771 = node.kind;
    zT_773 = zF_0E4E10C6_astStoreNodePayload(zT_769, zT_770, zT_771);
    zT_775 = zT_773 & (zT_79FAE712_u64)(4294967295u);
    zT_776 = (unsigned int)zig_cast_checked_u((zu64)zT_775, 64u, 0u, 32u);
    name_id = zT_776;
    zT_778 = type_reg;
    zT_779 = mod_id;
    zT_780 = name_id;
    zT_784 = zF_3A64E2E0_typeRegistryRegiste(zT_778, zT_779, zT_780, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
    tid = zT_784;
    if (populate) goto z_bb_120; else goto z_bb_121;
    z_bb_6:
    zT_812 = store;
    zT_813 = decl_idx;
    zT_814 = zF_8BA26B9E_astStoreNodePayload(zT_812, zT_813);
    path_id = zT_814;
    zT_816 = reg;
    zT_817 = path_id;
    zT_818 = zF_A258E183_moduleRegistryPathT(zT_816, zT_817);
    target_mod_id = zT_818;
    zT_819 = target_mod_id.has_value;
    if (zT_819) goto z_bb_122; else goto z_bb_123;
    z_bb_7:
    goto z_bb_9;
    z_bb_9:
    return;
    z_bb_10:
    zT_69 = store;
    zT_70 = node.child_1;
    zT_72 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    init_node = zT_72;
    zT_73 = init_node.kind;
    if ((unsigned char)(zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_504.name_id = name_id;
    zT_504.type_id = sym_type_id;
    zT_504.kind = sym_kind;
    zT_505 = node.flags;
    zT_506 = (unsigned short)zT_505;
    zT_504.flags = zT_506;
    zT_504.decl_node = decl_idx;
    zT_504.module_id = sym_mod_id;
    zT_507 = reg->modules;
    zT_508 = zT_507.items;
    zT_509 = (unsigned int)mod_id;
    zT_510 = zT_508[zT_509];
    zT_511 = zT_510.source_file_id;
    zT_504.file_id = zT_511;
    zT_512 = 0;
    zT_504.scope_level = zT_512;
    sym = zT_504;
    zT_514 = sym_reg;
    zT_515 = mod_id;
    zT_516 = zF_9B36C202_symbolRegistryGetTa(zT_514, zT_515);
    table = zT_516;
    zT_518 = table;
    zT_519 = sym;
    zT_520 = zF_D0156DDA_symbolTableInsert(zT_518, zT_519);
    inserted = zT_520;
    if ((unsigned char)(!inserted)) goto z_bb_91; else goto z_bb_92;
    z_bb_12:
    zT_78 = reg;
    zT_80 = store;
    zT_81 = node.child_1;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_80, zT_81);
    zT_79 = zT_83;
    zT_84 = zF_A258E183_moduleRegistryPathT(zT_78, zT_79);
    target = zT_84;
    zT_86 = "M5:p";
    zT_88 = 4;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    m5m = zT_87;
    zT_89 = m5m;
    zF_48AC7B3A_markerWrite(zT_89);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        m5pb[_i] = zT_91[_i];
        _i++;
    }
}
    zT_95 = store;
    zT_96 = node.child_1;
    zT_98 = zF_8BA26B9E_astStoreNodePayload(zT_95, zT_96);
    zT_93 = zT_98;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)m5pb) + zT_101;
    zT_103 = (unsigned int)(20) - zT_101;
    zT_104.ptr = (unsigned char*)zT_102;
    zT_104.len = zT_103;
    zT_94 = zT_104;
    zT_105 = zF_A7504564_itoa(zT_93, zT_94);
    m5pl = zT_105;
    zT_107 = 19;
    zT_108 = (unsigned int)m5pl;
    zT_109 = zig_wrap_sub_u(((zu64)(zT_107)), ((zu64)(zT_108)), 32u);
    zT_110 = zig_overflow_flag_sub_u(((zu64)(zT_107)), ((zu64)(zT_108)), 32u);
    zT_112 = zT_110 == (unsigned int)(0);
    if (!(zT_112)) { pal_trap(); }
    m5ps = zT_109;
    zT_116 = 19;
    zT_117 = (unsigned char*)((unsigned char*)m5pb) + m5ps;
    zT_118 = zT_116 - m5ps;
    zT_119 = m5ps <= zT_116;
    if (!(zT_119)) { pal_trap(); }
    zT_120.ptr = (unsigned char*)zT_117;
    zT_120.len = zT_118;
    zT_113 = zT_120;
    zF_48AC7B3A_markerWrite(zT_113);
    zT_121 = target.has_value;
    if (zT_121) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_234 = init_node.kind;
    if ((unsigned char)(zT_234 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_18; else goto z_bb_17;
    z_bb_14:
    if (!(target.has_value)) { pal_trap(); }
    mtid = target.value;
    zT_124 = "Rs";
    zT_126 = 2;
    zT_125.ptr = (unsigned char*)zT_124;
    zT_125.len = zT_126;
    rs_msg = zT_125;
    zT_127 = rs_msg;
    zF_48AC7B3A_markerWrite(zT_127);
    zT_129 = zT_3C598AEF_SymbolKind_module;
    sym_kind = zT_129;
    sym_mod_id = mtid;
    zT_131 = "FIX1:mid=";
    zT_133 = 9;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    di_m = zT_132;
    zT_134 = di_m;
    zF_48AC7B3A_markerWrite(zT_134);
    zig_poison_fill((void*)&zT_136, (unsigned int)sizeof zT_136);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_mb[_i] = zT_136[_i];
        _i++;
    }
}
    zT_138 = sym_mod_id;
    zT_142 = 0;
    zT_143 = (unsigned char*)((unsigned char*)di_mb) + zT_142;
    zT_144 = (unsigned int)(10) - zT_142;
    zT_145.ptr = (unsigned char*)zT_143;
    zT_145.len = zT_144;
    zT_139 = zT_145;
    zT_146 = zF_A7504564_itoa(zT_138, zT_139);
    di_ml = zT_146;
    zT_148 = 9;
    zT_149 = (unsigned int)di_ml;
    zT_150 = zig_wrap_sub_u(((zu64)(zT_148)), ((zu64)(zT_149)), 32u);
    zT_151 = zig_overflow_flag_sub_u(((zu64)(zT_148)), ((zu64)(zT_149)), 32u);
    zT_153 = zT_151 == (unsigned int)(0);
    if (!(zT_153)) { pal_trap(); }
    di_ms = zT_150;
    zT_157 = 9;
    zT_158 = (unsigned char*)((unsigned char*)di_mb) + di_ms;
    zT_159 = zT_157 - di_ms;
    zT_160 = di_ms <= zT_157;
    if (!(zT_160)) { pal_trap(); }
    zT_161.ptr = (unsigned char*)zT_158;
    zT_161.len = zT_159;
    zT_154 = zT_161;
    zF_48AC7B3A_markerWrite(zT_154);
    zT_163 = "t";
    zT_165 = 1;
    zT_164.ptr = (unsigned char*)zT_163;
    zT_164.len = zT_165;
    di_t = zT_164;
    zT_166 = di_t;
    zF_48AC7B3A_markerWrite(zT_166);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_tb[_i] = zT_168[_i];
        _i++;
    }
}
    zT_170 = mtid;
    zT_174 = 0;
    zT_175 = (unsigned char*)((unsigned char*)di_tb) + zT_174;
    zT_176 = (unsigned int)(10) - zT_174;
    zT_177.ptr = (unsigned char*)zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zT_178 = zF_A7504564_itoa(zT_170, zT_171);
    di_tl = zT_178;
    zT_180 = 9;
    zT_181 = (unsigned int)di_tl;
    zT_182 = zig_wrap_sub_u(((zu64)(zT_180)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_sub_u(((zu64)(zT_180)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    di_ts = zT_182;
    zT_189 = 9;
    zT_190 = (unsigned char*)((unsigned char*)di_tb) + di_ts;
    zT_191 = zT_189 - di_ts;
    zT_192 = di_ts <= zT_189;
    if (!(zT_192)) { pal_trap(); }
    zT_193.ptr = (unsigned char*)zT_190;
    zT_193.len = zT_191;
    zT_186 = zT_193;
    zF_48AC7B3A_markerWrite(zT_186);
    zT_195 = "n";
    zT_197 = 1;
    zT_196.ptr = (unsigned char*)zT_195;
    zT_196.len = zT_197;
    di_n = zT_196;
    zT_198 = di_n;
    zF_48AC7B3A_markerWrite(zT_198);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        di_nb[_i] = zT_200[_i];
        _i++;
    }
}
    zT_202 = mod_id;
    zT_206 = 0;
    zT_207 = (unsigned char*)((unsigned char*)di_nb) + zT_206;
    zT_208 = (unsigned int)(10) - zT_206;
    zT_209.ptr = (unsigned char*)zT_207;
    zT_209.len = zT_208;
    zT_203 = zT_209;
    zT_210 = zF_A7504564_itoa(zT_202, zT_203);
    di_nl = zT_210;
    zT_212 = 9;
    zT_213 = (unsigned int)di_nl;
    zT_214 = zig_wrap_sub_u(((zu64)(zT_212)), ((zu64)(zT_213)), 32u);
    zT_215 = zig_overflow_flag_sub_u(((zu64)(zT_212)), ((zu64)(zT_213)), 32u);
    zT_217 = zT_215 == (unsigned int)(0);
    if (!(zT_217)) { pal_trap(); }
    di_ns = zT_214;
    zT_221 = 9;
    zT_222 = (unsigned char*)((unsigned char*)di_nb) + di_ns;
    zT_223 = zT_221 - di_ns;
    zT_224 = di_ns <= zT_221;
    if (!(zT_224)) { pal_trap(); }
    zT_225.ptr = (unsigned char*)zT_222;
    zT_225.len = zT_223;
    zT_218 = zT_225;
    zF_48AC7B3A_markerWrite(zT_218);
    zT_226 = type_reg;
    zT_227 = mtid;
    zT_228 = zF_2ECA9F93_typeRegistryGetOrCr(zT_226, zT_227);
    sym_type_id = zT_228;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_230 = "Rf";
    zT_232 = 2;
    zT_231.ptr = (unsigned char*)zT_230;
    zT_231.len = zT_232;
    rf_msg = zT_231;
    zT_233 = rf_msg;
    zF_48AC7B3A_markerWrite(zT_233);
    goto z_bb_15;
    z_bb_17:
    zT_239 = init_node.kind;
    zT_238 = zT_239 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_19;
    z_bb_18:
    zT_238 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_238) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_244 = init_node.kind;
    zT_243 = zT_244 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_22;
    z_bb_21:
    zT_243 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_243) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_249 = init_node.kind;
    zT_248 = zT_249 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_25;
    z_bb_24:
    zT_248 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_248) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_254 = init_node.kind;
switch (zT_254) {
case 3: goto z_bb_29;
case 4: goto z_bb_30;
case 5: goto z_bb_31;
case 9: goto z_bb_32;
default: goto z_bb_33;
}
    z_bb_27:
    goto z_bb_11;
    z_bb_28:
    zT_331 = init_node.kind;
    if ((unsigned char)(zT_331 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_55; else goto z_bb_57;
    z_bb_29:
    zT_256 = init_node.flags;
    zT_260 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_256) & (unsigned short)(32)) != zT_260)) goto z_bb_36; else goto z_bb_37;
    z_bb_30:
    zT_255 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_35;
    z_bb_31:
    zT_269 = init_node.flags;
    zT_273 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_269) & (unsigned short)(16)) != zT_273)) goto z_bb_39; else goto z_bb_40;
    z_bb_32:
    zT_255 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_35;
    z_bb_33:
    zT_255 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_35;
    z_bb_35:
    type_kind = zT_255;
    zT_293 = type_reg;
    zT_294 = mod_id;
    zT_295 = name_id;
    zT_296 = type_kind;
    zT_297 = zF_3A64E2E0_typeRegistryRegiste(zT_293, zT_294, zT_295, zT_296);
    sym_type_id = zT_297;
    zT_298 = init_node.kind;
    if ((unsigned char)(zT_298 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_46; else goto z_bb_45;
    z_bb_36:
    zT_262 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_38;
    z_bb_37:
    zT_262 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_38;
    z_bb_38:
    zT_255 = zT_262;
    goto z_bb_35;
    z_bb_39:
    zT_275 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_41;
    z_bb_40:
    zT_278 = init_node.flags;
    zT_280 = 1;
    zT_282 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_278) & zT_280) != zT_282)) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_255 = zT_275;
    goto z_bb_35;
    z_bb_42:
    zT_284 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_44;
    z_bb_43:
    zT_284 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_44;
    z_bb_44:
    zT_275 = zT_284;
    goto z_bb_41;
    z_bb_45:
    zT_303 = init_node.kind;
    zT_302 = zT_303 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_47;
    z_bb_46:
    zT_302 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_302) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_308 = init_node.flags;
    zT_307 = (unsigned short)((unsigned short)((unsigned short)zT_308) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_50;
    z_bb_49:
    zT_307 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_307) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_314 = type_reg;
    zT_315 = sym_type_id;
    zF_52816016_typeRegistrySetPack(zT_314, zT_315);
    goto z_bb_52;
    z_bb_52:
    if (populate) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_316 = type_reg;
    zT_317 = store;
    zT_318 = init_node.kind;
    zT_319 = node.child_1;
    zT_320 = sym_type_id;
    zT_321 = sym_reg;
    zF_020995FB_populateTypePayload(zT_316, zT_317, zT_318, zT_319, zT_320, zT_321);
    goto z_bb_54;
    z_bb_54:
    zT_324 = store;
    zT_325 = node.child_1;
    zT_326 = sym_type_id;
    zT_327 = g;
    zF_4976C319_addTypeDependencies(zT_324, zT_325, zT_326, zT_327);
    zT_330 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_330;
    sym_mod_id = mod_id;
    goto z_bb_27;
    z_bb_55:
    zT_336 = "RCA:p";
    zT_338 = 5;
    zT_337.ptr = (unsigned char*)zT_336;
    zT_337.len = zT_338;
    rca_m = zT_337;
    zT_339 = rca_m;
    zT_341 = store;
    zT_342 = node.child_1;
    zT_344 = zF_8BA26B9E_astStoreNodePayload(zT_341, zT_342);
    zT_340 = zT_344;
    zF_C914CB83_markerWriteInt(zT_339, zT_340);
    zT_346 = store;
    zT_347 = node.child_1;
    zT_349 = zF_53458827_astStoreIdentifier(zT_346, zT_347);
    ident_name_id = zT_349;
    zT_351 = "RCA:i";
    zT_353 = 5;
    zT_352.ptr = (unsigned char*)zT_351;
    zT_352.len = zT_353;
    rca_i = zT_352;
    zT_354 = rca_i;
    zT_355 = ident_name_id;
    zF_C914CB83_markerWriteInt(zT_354, zT_355);
    zT_357 = type_reg;
    zT_359 = (zT_79FAE712_u64)mod_id;
    zT_360 = Z98_U64_C(4294967296);
    zT_361 = zig_wrap_mul_u(((zu64)(zT_359)), ((zu64)(zT_360)), 64u);
    zT_362 = zig_overflow_flag_mul_u(((zu64)(zT_359)), ((zu64)(zT_360)), 64u);
    zT_364 = zT_362 == (unsigned int)(0);
    if (!(zT_364)) { pal_trap(); }
    zT_365 = (zT_79FAE712_u64)ident_name_id;
    zT_366 = zig_wrap_add_u(((zu64)(zT_361)), ((zu64)(zT_365)), 64u);
    zT_367 = zig_overflow_flag_add_u(((zu64)(zT_361)), ((zu64)(zT_365)), 64u);
    zT_369 = zT_367 == (unsigned int)(0);
    if (!(zT_369)) { pal_trap(); }
    zT_358 = zT_366;
    zT_370 = zF_0EB68360_nameCacheGet(zT_357, zT_358);
    cached = zT_370;
    zT_371 = cached.has_value;
    if ((unsigned char)(!zT_371)) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_27;
    z_bb_57:
    zT_438 = init_node.kind;
    if ((unsigned char)(zT_438 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_68; else goto z_bb_67;
    z_bb_58:
    zT_373 = type_reg;
    zT_376 = zF_0EB68360_nameCacheGet(zT_373, (zT_79FAE712_u64)((zT_79FAE712_u64)ident_name_id));
    cached = zT_376;
    goto z_bb_59;
    z_bb_59:
    zT_377 = cached.has_value;
    if (zT_377) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    if (!(cached.has_value)) { pal_trap(); }
    ct = cached.value;
    zT_380 = "RCA:H";
    zT_382 = 5;
    zT_381.ptr = (unsigned char*)zT_380;
    zT_381.len = zT_382;
    rca_h = zT_381;
    zT_383 = rca_h;
    zT_384 = ct;
    zF_C914CB83_markerWriteInt(zT_383, zT_384);
    zT_386 = (zT_79FAE712_u64)mod_id;
    zT_387 = Z98_U64_C(4294967296);
    zT_388 = zig_wrap_mul_u(((zu64)(zT_386)), ((zu64)(zT_387)), 64u);
    zT_389 = zig_overflow_flag_mul_u(((zu64)(zT_386)), ((zu64)(zT_387)), 64u);
    zT_391 = zT_389 == (unsigned int)(0);
    if (!(zT_391)) { pal_trap(); }
    zT_392 = (zT_79FAE712_u64)name_id;
    zT_393 = zig_wrap_add_u(((zu64)(zT_388)), ((zu64)(zT_392)), 64u);
    zT_394 = zig_overflow_flag_add_u(((zu64)(zT_388)), ((zu64)(zT_392)), 64u);
    zT_396 = zT_394 == (unsigned int)(0);
    if (!(zT_396)) { pal_trap(); }
    ck = zT_393;
    zT_397 = type_reg;
    zT_398 = ck;
    zT_399 = ct;
    zF_5E95558D_nameCachePut(zT_397, zT_398, zT_399);
    sym_type_id = ct;
    zT_401 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_401;
    sym_mod_id = mod_id;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_56;
    z_bb_62:
    zT_403 = 0;
    arb_u = zT_403;
    zT_405 = type_reg->interner;
    zT_406 = ident_name_id;
    zT_408 = zF_9134020D_stringInternerGet(zT_405, zT_406);
    ident_text = zT_408;
    zT_409 = ident_text;
    zT_410 = (unsigned char*)&arb_u;
    zT_412 = zF_741B5264_parseArbIntWidth(zT_409, zT_410);
    if ((unsigned char)(zT_412 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_416 = type_reg;
    zT_417 = ident_text;
    zT_418 = zF_B8CF3697_typeRegistryGetOrCr(zT_416, zT_417);
    arb_tid = zT_418;
    if ((unsigned char)(arb_tid != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_422 = (zT_79FAE712_u64)mod_id;
    zT_423 = Z98_U64_C(4294967296);
    zT_424 = zig_wrap_mul_u(((zu64)(zT_422)), ((zu64)(zT_423)), 64u);
    zT_425 = zig_overflow_flag_mul_u(((zu64)(zT_422)), ((zu64)(zT_423)), 64u);
    zT_427 = zT_425 == (unsigned int)(0);
    if (!(zT_427)) { pal_trap(); }
    zT_428 = (zT_79FAE712_u64)name_id;
    zT_429 = zig_wrap_add_u(((zu64)(zT_424)), ((zu64)(zT_428)), 64u);
    zT_430 = zig_overflow_flag_add_u(((zu64)(zT_424)), ((zu64)(zT_428)), 64u);
    zT_432 = zT_430 == (unsigned int)(0);
    if (!(zT_432)) { pal_trap(); }
    atk = zT_429;
    zT_433 = type_reg;
    zT_434 = atk;
    zT_435 = arb_tid;
    zF_5E95558D_nameCachePut(zT_433, zT_434, zT_435);
    sym_type_id = arb_tid;
    zT_437 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_437;
    sym_mod_id = mod_id;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_443 = init_node.kind;
    zT_442 = zT_443 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_69;
    z_bb_68:
    zT_442 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_442) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_448 = init_node.kind;
    zT_447 = zT_448 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_72;
    z_bb_71:
    zT_447 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_447) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_453 = init_node.kind;
    zT_452 = zT_453 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_452 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_452) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_458 = init_node.kind;
    zT_457 = zT_458 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_457 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_457) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_463 = init_node.kind;
    zT_462 = zT_463 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_462 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_462) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_468 = init_node.kind;
    zT_467 = zT_468 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_84;
    z_bb_83:
    zT_467 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_467) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_473 = "AT:p";
    zT_475 = 4;
    zT_474.ptr = (unsigned char*)zT_473;
    zT_474.len = zT_475;
    at_m = zT_474;
    zT_476 = at_m;
    zT_477 = name_id;
    zF_C914CB83_markerWriteInt(zT_476, zT_477);
    zT_479 = type_reg;
    zT_481 = (zT_79FAE712_u64)mod_id;
    zT_482 = Z98_U64_C(4294967296);
    zT_483 = zig_wrap_mul_u(((zu64)(zT_481)), ((zu64)(zT_482)), 64u);
    zT_484 = zig_overflow_flag_mul_u(((zu64)(zT_481)), ((zu64)(zT_482)), 64u);
    zT_486 = zT_484 == (unsigned int)(0);
    if (!(zT_486)) { pal_trap(); }
    zT_487 = (zT_79FAE712_u64)name_id;
    zT_488 = zig_wrap_add_u(((zu64)(zT_483)), ((zu64)(zT_487)), 64u);
    zT_489 = zig_overflow_flag_add_u(((zu64)(zT_483)), ((zu64)(zT_487)), 64u);
    zT_491 = zT_489 == (unsigned int)(0);
    if (!(zT_491)) { pal_trap(); }
    zT_480 = zT_488;
    zT_492 = zF_0EB68360_nameCacheGet(zT_479, zT_480);
    acached = zT_492;
    zT_493 = acached.has_value;
    if ((unsigned char)(!zT_493)) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    goto z_bb_56;
    z_bb_87:
    zT_495 = type_reg;
    zT_498 = zF_0EB68360_nameCacheGet(zT_495, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    acached = zT_498;
    goto z_bb_88;
    z_bb_88:
    zT_499 = acached.has_value;
    if (zT_499) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    if (!(acached.has_value)) { pal_trap(); }
    act = acached.value;
    sym_type_id = act;
    goto z_bb_90;
    z_bb_90:
    zT_502 = zT_3C598AEF_SymbolKind_type_alias;
    sym_kind = zT_502;
    sym_mod_id = mod_id;
    goto z_bb_86;
    z_bb_91:
    zT_523 = "VR";
    zT_525 = 2;
    zT_524.ptr = (unsigned char*)zT_523;
    zT_524.len = zT_525;
    vr = zT_524;
    zT_526 = vr;
    zF_48AC7B3A_markerWrite(zT_526);
    goto z_bb_92;
    z_bb_92:
    zT_528 = "VD";
    zT_530 = 2;
    zT_529.ptr = (unsigned char*)zT_528;
    zT_529.len = zT_530;
    vd = zT_529;
    zT_531 = vd;
    zF_48AC7B3A_markerWrite(zT_531);
    zig_poison_fill((void*)&zT_533, (unsigned int)sizeof zT_533);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        vb[_i] = zT_533[_i];
        _i++;
    }
}
    zT_535 = name_id;
    zT_539 = 0;
    zT_540 = (unsigned char*)((unsigned char*)vb) + zT_539;
    zT_541 = (unsigned int)(20) - zT_539;
    zT_542.ptr = (unsigned char*)zT_540;
    zT_542.len = zT_541;
    zT_536 = zT_542;
    zT_543 = zF_A7504564_itoa(zT_535, zT_536);
    vn = zT_543;
    zT_545 = 20;
    zT_546 = 1;
    zT_547 = zig_wrap_sub_u(((zu64)(zT_545)), ((zu64)(zT_546)), 32u);
    zT_548 = zig_overflow_flag_sub_u(((zu64)(zT_545)), ((zu64)(zT_546)), 32u);
    zT_550 = zT_548 == (unsigned int)(0);
    if (!(zT_550)) { pal_trap(); }
    zT_551 = (unsigned int)vn;
    zT_552 = zig_wrap_sub_u(((zu64)(zT_547)), ((zu64)(zT_551)), 32u);
    zT_553 = zig_overflow_flag_sub_u(((zu64)(zT_547)), ((zu64)(zT_551)), 32u);
    zT_555 = zT_553 == (unsigned int)(0);
    if (!(zT_555)) { pal_trap(); }
    vns = zT_552;
    zT_559 = 20;
    zT_560 = (unsigned char*)((unsigned char*)vb) + vns;
    zT_561 = zT_559 - vns;
    zT_562 = vns <= zT_559;
    if (!(zT_562)) { pal_trap(); }
    zT_563.ptr = (unsigned char*)zT_560;
    zT_563.len = zT_561;
    zT_556 = zT_563;
    zF_48AC7B3A_markerWrite(zT_556);
    zT_565 = ":";
    zT_567 = 1;
    zT_566.ptr = (unsigned char*)zT_565;
    zT_566.len = zT_567;
    vc = zT_566;
    zT_568 = vc;
    zF_48AC7B3A_markerWrite(zT_568);
    zT_575 = 0;
    zT_576 = (unsigned char*)((unsigned char*)vb) + zT_575;
    zT_577 = (unsigned int)(20) - zT_575;
    zT_578.ptr = (unsigned char*)zT_576;
    zT_578.len = zT_577;
    zT_571 = zT_578;
    zT_579 = zF_A7504564_itoa((unsigned int)((unsigned int)sym_kind), zT_571);
    vk = zT_579;
    zT_581 = 20;
    zT_582 = 1;
    zT_583 = zig_wrap_sub_u(((zu64)(zT_581)), ((zu64)(zT_582)), 32u);
    zT_584 = zig_overflow_flag_sub_u(((zu64)(zT_581)), ((zu64)(zT_582)), 32u);
    zT_586 = zT_584 == (unsigned int)(0);
    if (!(zT_586)) { pal_trap(); }
    zT_587 = (unsigned int)vk;
    zT_588 = zig_wrap_sub_u(((zu64)(zT_583)), ((zu64)(zT_587)), 32u);
    zT_589 = zig_overflow_flag_sub_u(((zu64)(zT_583)), ((zu64)(zT_587)), 32u);
    zT_591 = zT_589 == (unsigned int)(0);
    if (!(zT_591)) { pal_trap(); }
    vks = zT_588;
    zT_595 = 20;
    zT_596 = (unsigned char*)((unsigned char*)vb) + vks;
    zT_597 = zT_595 - vks;
    zT_598 = vks <= zT_595;
    if (!(zT_598)) { pal_trap(); }
    zT_599.ptr = (unsigned char*)zT_596;
    zT_599.len = zT_597;
    zT_592 = zT_599;
    zF_48AC7B3A_markerWrite(zT_592);
    zT_601 = "\n";
    zT_603 = 1;
    zT_602.ptr = (unsigned char*)zT_601;
    zT_602.len = zT_603;
    ven = zT_602;
    zT_604 = ven;
    zF_48AC7B3A_markerWrite(zT_604);
    zT_606 = "Vi";
    zT_608 = 2;
    zT_607.ptr = (unsigned char*)zT_606;
    zT_607.len = zT_608;
    vi_msg = zT_607;
    zT_609 = vi_msg;
    zF_48AC7B3A_markerWrite(zT_609);
    goto z_bb_9;
    z_bb_93:
    zT_646 = store;
    zT_647 = decl_idx;
    zT_648 = zF_8BA26B9E_astStoreNodePayload(zT_646, zT_647);
    zT_645.name_id = zT_648;
    zT_649 = 0;
    zT_645.type_id = zT_649;
    zT_651 = zT_3C598AEF_SymbolKind_test_sym;
    zT_645.kind = zT_651;
    zT_652 = node.flags;
    zT_653 = (unsigned short)zT_652;
    zT_645.flags = zT_653;
    zT_645.decl_node = decl_idx;
    zT_645.module_id = mod_id;
    zT_654 = reg->modules;
    zT_655 = zT_654.items;
    zT_656 = (unsigned int)mod_id;
    zT_657 = zT_655[zT_656];
    zT_658 = zT_657.source_file_id;
    zT_645.file_id = zT_658;
    zT_659 = 0;
    zT_645.scope_level = zT_659;
    sym = zT_645;
    zT_661 = sym_reg;
    zT_662 = mod_id;
    zT_663 = zF_9B36C202_symbolRegistryGetTa(zT_661, zT_662);
    table = zT_663;
    zT_664 = table;
    zT_665 = sym;
    zT_666 = zF_D0156DDA_symbolTableInsert(zT_664, zT_665);
    (void)zT_666;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_9;
    z_bb_95:
    zT_679 = node.flags;
    zT_683 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_679) & (unsigned short)(32)) != zT_683)) goto z_bb_101; else goto z_bb_102;
    z_bb_96:
    zT_678 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_100;
    z_bb_97:
    zT_692 = node.flags;
    zT_696 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_692) & (unsigned short)(16)) != zT_696)) goto z_bb_104; else goto z_bb_105;
    z_bb_98:
    zT_678 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_100;
    z_bb_100:
    type_kind = zT_678;
    zT_715 = type_reg;
    zT_716 = mod_id;
    zT_717 = name_id;
    zT_718 = type_kind;
    zT_719 = zF_3A64E2E0_typeRegistryRegiste(zT_715, zT_716, zT_717, zT_718);
    tid = zT_719;
    zT_720 = node.kind;
    if ((unsigned char)(zT_720 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_111; else goto z_bb_110;
    z_bb_101:
    zT_685 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_103;
    z_bb_102:
    zT_685 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_103;
    z_bb_103:
    zT_678 = zT_685;
    goto z_bb_100;
    z_bb_104:
    zT_698 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_106;
    z_bb_105:
    zT_701 = node.flags;
    zT_703 = 1;
    zT_705 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_701) & zT_703) != zT_705)) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_678 = zT_698;
    goto z_bb_100;
    z_bb_107:
    zT_707 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_109;
    z_bb_108:
    zT_707 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_109;
    z_bb_109:
    zT_698 = zT_707;
    goto z_bb_106;
    z_bb_110:
    zT_725 = node.kind;
    zT_724 = zT_725 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_112;
    z_bb_111:
    zT_724 = 1;
    goto z_bb_112;
    z_bb_112:
    if (zT_724) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_730 = node.flags;
    zT_729 = (unsigned short)((unsigned short)((unsigned short)zT_730) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_115;
    z_bb_114:
    zT_729 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_729) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_736 = type_reg;
    zT_737 = tid;
    zF_52816016_typeRegistrySetPack(zT_736, zT_737);
    goto z_bb_117;
    z_bb_117:
    if (populate) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_738 = type_reg;
    zT_739 = store;
    zT_740 = node.kind;
    zT_741 = decl_idx;
    zT_742 = tid;
    zT_743 = sym_reg;
    zF_020995FB_populateTypePayload(zT_738, zT_739, zT_740, zT_741, zT_742, zT_743);
    goto z_bb_119;
    z_bb_119:
    zT_745 = store;
    zT_746 = decl_idx;
    zT_747 = tid;
    zT_748 = g;
    zF_4976C319_addTypeDependencies(zT_745, zT_746, zT_747, zT_748);
    zT_750.name_id = name_id;
    zT_750.type_id = tid;
    zT_752 = zT_3C598AEF_SymbolKind_type_alias;
    zT_750.kind = zT_752;
    zT_753 = node.flags;
    zT_754 = (unsigned short)zT_753;
    zT_750.flags = zT_754;
    zT_750.decl_node = decl_idx;
    zT_750.module_id = mod_id;
    zT_755 = reg->modules;
    zT_756 = zT_755.items;
    zT_757 = (unsigned int)mod_id;
    zT_758 = zT_756[zT_757];
    zT_759 = zT_758.source_file_id;
    zT_750.file_id = zT_759;
    zT_760 = 0;
    zT_750.scope_level = zT_760;
    sym = zT_750;
    zT_762 = sym_reg;
    zT_763 = mod_id;
    zT_764 = zF_9B36C202_symbolRegistryGetTa(zT_762, zT_763);
    table = zT_764;
    zT_765 = table;
    zT_766 = sym;
    zT_767 = zF_D0156DDA_symbolTableInsert(zT_765, zT_766);
    (void)zT_767;
    goto z_bb_9;
    z_bb_120:
    zT_785 = type_reg;
    zT_786 = store;
    zT_787 = node.kind;
    zT_788 = decl_idx;
    zT_789 = tid;
    zT_790 = sym_reg;
    zF_020995FB_populateTypePayload(zT_785, zT_786, zT_787, zT_788, zT_789, zT_790);
    goto z_bb_121;
    z_bb_121:
    zT_793.name_id = name_id;
    zT_793.type_id = tid;
    zT_795 = zT_3C598AEF_SymbolKind_type_alias;
    zT_793.kind = zT_795;
    zT_796 = node.flags;
    zT_797 = (unsigned short)zT_796;
    zT_793.flags = zT_797;
    zT_793.decl_node = decl_idx;
    zT_793.module_id = mod_id;
    zT_798 = reg->modules;
    zT_799 = zT_798.items;
    zT_800 = (unsigned int)mod_id;
    zT_801 = zT_799[zT_800];
    zT_802 = zT_801.source_file_id;
    zT_793.file_id = zT_802;
    zT_803 = 0;
    zT_793.scope_level = zT_803;
    sym = zT_793;
    zT_805 = sym_reg;
    zT_806 = mod_id;
    zT_807 = zF_9B36C202_symbolRegistryGetTa(zT_805, zT_806);
    table = zT_807;
    zT_808 = table;
    zT_809 = sym;
    zT_810 = zF_D0156DDA_symbolTableInsert(zT_808, zT_809);
    (void)zT_810;
    goto z_bb_9;
    z_bb_122:
    if (!(target_mod_id.has_value)) { pal_trap(); }
    tid = target_mod_id.value;
    zT_822.name_id = path_id;
    zT_823 = type_reg;
    zT_824 = tid;
    zT_825 = zF_2ECA9F93_typeRegistryGetOrCr(zT_823, zT_824);
    zT_822.type_id = zT_825;
    zT_827 = zT_3C598AEF_SymbolKind_module;
    zT_822.kind = zT_827;
    zT_828 = 0;
    zT_822.flags = zT_828;
    zT_822.decl_node = decl_idx;
    zT_822.module_id = tid;
    zT_829 = reg->modules;
    zT_830 = zT_829.items;
    zT_831 = (unsigned int)mod_id;
    zT_832 = zT_830[zT_831];
    zT_833 = zT_832.source_file_id;
    zT_822.file_id = zT_833;
    zT_834 = 0;
    zT_822.scope_level = zT_834;
    sym = zT_822;
    zT_836 = sym_reg;
    zT_837 = mod_id;
    zT_838 = zF_9B36C202_symbolRegistryGetTa(zT_836, zT_837);
    table = zT_838;
    zT_839 = table;
    zT_840 = sym;
    zT_841 = zF_D0156DDA_symbolTableInsert(zT_839, zT_840);
    (void)zT_841;
    zT_843 = "IMR:n";
    zT_845 = 5;
    zT_844.ptr = (unsigned char*)zT_843;
    zT_844.len = zT_845;
    imr = zT_844;
    zT_846 = imr;
    zF_48AC7B3A_markerWrite(zT_846);
    zig_poison_fill((void*)&zT_848, (unsigned int)sizeof zT_848);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        imb[_i] = zT_848[_i];
        _i++;
    }
}
    zT_850 = path_id;
    zT_854 = 0;
    zT_855 = (unsigned char*)((unsigned char*)imb) + zT_854;
    zT_856 = (unsigned int)(10) - zT_854;
    zT_857.ptr = (unsigned char*)zT_855;
    zT_857.len = zT_856;
    zT_851 = zT_857;
    zT_858 = zF_A7504564_itoa(zT_850, zT_851);
    iml = zT_858;
    zT_860 = 9;
    zT_861 = (unsigned int)iml;
    zT_862 = zig_wrap_sub_u(((zu64)(zT_860)), ((zu64)(zT_861)), 32u);
    zT_863 = zig_overflow_flag_sub_u(((zu64)(zT_860)), ((zu64)(zT_861)), 32u);
    zT_865 = zT_863 == (unsigned int)(0);
    if (!(zT_865)) { pal_trap(); }
    ims = zT_862;
    zT_869 = 9;
    zT_870 = (unsigned char*)((unsigned char*)imb) + ims;
    zT_871 = zT_869 - ims;
    zT_872 = ims <= zT_869;
    if (!(zT_872)) { pal_trap(); }
    zT_873.ptr = (unsigned char*)zT_870;
    zT_873.len = zT_871;
    zT_866 = zT_873;
    zF_48AC7B3A_markerWrite(zT_866);
    zT_875 = "m";
    zT_877 = 1;
    zT_876.ptr = (unsigned char*)zT_875;
    zT_876.len = zT_877;
    imm = zT_876;
    zT_878 = imm;
    zF_48AC7B3A_markerWrite(zT_878);
    zig_poison_fill((void*)&zT_880, (unsigned int)sizeof zT_880);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        immb[_i] = zT_880[_i];
        _i++;
    }
}
    zT_882 = tid;
    zT_886 = 0;
    zT_887 = (unsigned char*)((unsigned char*)immb) + zT_886;
    zT_888 = (unsigned int)(10) - zT_886;
    zT_889.ptr = (unsigned char*)zT_887;
    zT_889.len = zT_888;
    zT_883 = zT_889;
    zT_890 = zF_A7504564_itoa(zT_882, zT_883);
    imml = zT_890;
    zT_892 = 9;
    zT_893 = (unsigned int)imml;
    zT_894 = zig_wrap_sub_u(((zu64)(zT_892)), ((zu64)(zT_893)), 32u);
    zT_895 = zig_overflow_flag_sub_u(((zu64)(zT_892)), ((zu64)(zT_893)), 32u);
    zT_897 = zT_895 == (unsigned int)(0);
    if (!(zT_897)) { pal_trap(); }
    imms = zT_894;
    zT_901 = 9;
    zT_902 = (unsigned char*)((unsigned char*)immb) + imms;
    zT_903 = zT_901 - imms;
    zT_904 = imms <= zT_901;
    if (!(zT_904)) { pal_trap(); }
    zT_905.ptr = (unsigned char*)zT_902;
    zT_905.len = zT_903;
    zT_898 = zT_905;
    zF_48AC7B3A_markerWrite(zT_898);
    zT_907 = " ";
    zT_909 = 1;
    zT_908.ptr = (unsigned char*)zT_907;
    zT_908.len = zT_909;
    imsnl = zT_908;
    zT_910 = imsnl;
    zF_48AC7B3A_markerWrite(zT_910);
    goto z_bb_123;
    z_bb_123:
    goto z_bb_9;
}

/* registerModuleSymbols */
void zF_16302C7D_registerModuleSymbo(zT_072B53A6_ModuleRegistry* reg, zT_3D7259E2_SymbolRegistry* sym_reg, zT_338B7C76_TypeRegistry* type_reg, zT_6B0A7D14_AstStore* store, unsigned int module_id, zT_4D61441E_DepGraph* g, unsigned char populate) {
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned char zT_16;
    zT_9FE1BFFE_ModuleState zT_17;
    unsigned char zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_29;
    zT_8143F551_AstKind zT_30;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    zT_79FAE712_u64 zT_56;
    zT_79FAE712_u64 zT_58;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_77;
    unsigned char* zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_4028D896_Arr_unsigned_char_2 zT_93;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_98;
    unsigned int zT_102;
    int zT_105;
    unsigned char* zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_120;
    unsigned char* zT_121;
    unsigned int zT_122;
    unsigned char zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_6B0A7D14_AstStore* zT_131;
    unsigned int zT_132;
    zT_6B0A7D14_AstStore* zT_133;
    unsigned int zT_134;
    unsigned int zT_138;
    zT_22A7C88B_AstNode zT_139;
    zT_8143F551_AstKind zT_141;
    unsigned int zT_142;
    zT_4028D896_Arr_unsigned_char_2 zT_144;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    int zT_150;
    unsigned char* zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned char zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_165;
    unsigned char* zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned char zT_180;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    int zT_187;
    unsigned int zT_188;
    zT_3D7259E2_SymbolRegistry* zT_191;
    zT_338B7C76_TypeRegistry* zT_192;
    zT_6B0A7D14_AstStore* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_4D61441E_DepGraph* zT_196;
    zT_072B53A6_ModuleRegistry* zT_197;
    unsigned char zT_198;
    zT_6B0A7D14_AstStore* zT_199;
    unsigned int zT_200;
    unsigned int zT_204;
    int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned char zT_210;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_138, (unsigned int)sizeof zT_138);
    zig_poison_fill((void*)&zT_139, (unsigned int)sizeof zT_139);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_204, (unsigned int)sizeof zT_204);
    zT_6E8D187B_ModuleEntry entry;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u dg;
    zT_4028D896_Arr_unsigned_char_2 pb;
    unsigned int pl;
    unsigned int ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u sc;
    unsigned int i2;
    unsigned int i;
    zT_4028D896_Arr_unsigned_char_2 ii_buf;
    unsigned int ii_len;
    unsigned int ii_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u ss;
    zT_22A7C88B_AstNode dc;
    unsigned int dk;
    zT_4028D896_Arr_unsigned_char_2 db;
    unsigned int dl;
    unsigned int ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u dsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8 = reg->modules;
    zT_9 = zT_8.items;
    zT_10 = (unsigned int)module_id;
    zT_11 = zT_9[zT_10];
    entry = zT_11;
    zT_12 = entry.state;
    if ((unsigned char)(zT_12 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_parsed))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = entry.state;
    zT_16 = zT_17 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = entry.ast_root;
    zT_23 = 0;
    zT_21 = zT_22 == (unsigned int)zT_23;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = store;
    zT_27 = entry.ast_root;
    zT_29 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    root = zT_29;
    zT_30 = root.kind;
    if ((unsigned char)(zT_30 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_35 = store;
    zT_36 = entry.ast_root;
    zT_38 = zF_152E19CB_astStoreNodeExtraCh(zT_35, zT_36);
    decls_n = zT_38;
    if ((unsigned char)(module_id == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = "RS";
    zT_44 = 2;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    dg = zT_43;
    zT_45 = dg;
    zF_48AC7B3A_markerWrite(zT_45);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        pb[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = store;
    zT_52 = entry.ast_root;
    zT_53 = root.kind;
    zT_56 = zF_0E4E10C6_astStoreNodePayload(zT_51, zT_52, zT_53);
    zT_58 = zT_56 & (zT_79FAE712_u64)(4294967295u);
    zT_49 = (unsigned int)zig_cast_checked_u((zu64)zT_58, 64u, 0u, 32u);
    zT_62 = 0;
    zT_63 = (unsigned char*)((unsigned char*)pb) + zT_62;
    zT_64 = (unsigned int)(20) - zT_62;
    zT_65.ptr = (unsigned char*)zT_63;
    zT_65.len = zT_64;
    zT_50 = zT_65;
    zT_66 = zF_A7504564_itoa(zT_49, zT_50);
    pl = zT_66;
    zT_68 = 19;
    zT_69 = (unsigned int)pl;
    zT_70 = zig_wrap_sub_u(((zu64)(zT_68)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_sub_u(((zu64)(zT_68)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    ps = zT_70;
    zT_77 = 19;
    zT_78 = (unsigned char*)((unsigned char*)pb) + ps;
    zT_79 = zT_77 - ps;
    zT_80 = ps <= zT_77;
    if (!(zT_80)) { pal_trap(); }
    zT_81.ptr = (unsigned char*)zT_78;
    zT_81.len = zT_79;
    zT_74 = zT_81;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_83 = ":";
    zT_85 = 1;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    sc = zT_84;
    zT_86 = sc;
    zF_48AC7B3A_markerWrite(zT_86);
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    i2 = zT_89;
    goto z_bb_13;
    z_bb_12:
    zT_187 = 0;
    zT_188 = (unsigned int)zT_187;
    i = zT_188;
    goto z_bb_17;
    z_bb_13:
    if ((unsigned char)(i2 < (unsigned int)((unsigned int)decls_n))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ii_buf[_i] = zT_93[_i];
        _i++;
    }
}
    zT_97 = store;
    zT_98 = entry.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_97, zT_98, (unsigned int)((unsigned int)i2));
    zT_95 = zT_102;
    zT_105 = 0;
    zT_106 = (unsigned char*)((unsigned char*)ii_buf) + zT_105;
    zT_107 = (unsigned int)(20) - zT_105;
    zT_108.ptr = (unsigned char*)zT_106;
    zT_108.len = zT_107;
    zT_96 = zT_108;
    zT_109 = zF_A7504564_itoa(zT_95, zT_96);
    ii_len = zT_109;
    zT_111 = 19;
    zT_112 = (unsigned int)ii_len;
    zT_113 = zig_wrap_sub_u(((zu64)(zT_111)), ((zu64)(zT_112)), 32u);
    zT_114 = zig_overflow_flag_sub_u(((zu64)(zT_111)), ((zu64)(zT_112)), 32u);
    zT_116 = zT_114 == (unsigned int)(0);
    if (!(zT_116)) { pal_trap(); }
    ii_start = zT_113;
    zT_120 = 19;
    zT_121 = (unsigned char*)((unsigned char*)ii_buf) + ii_start;
    zT_122 = zT_120 - ii_start;
    zT_123 = ii_start <= zT_120;
    if (!(zT_123)) { pal_trap(); }
    zT_124.ptr = (unsigned char*)zT_121;
    zT_124.len = zT_122;
    zT_117 = zT_124;
    zF_48AC7B3A_markerWrite(zT_117);
    zT_126 = "=";
    zT_128 = 1;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    ss = zT_127;
    zT_129 = ss;
    zF_48AC7B3A_markerWrite(zT_129);
    zT_131 = store;
    zT_133 = store;
    zT_134 = entry.ast_root;
    zT_138 = zF_B10B1BC1_astStoreNodeExtraCh(zT_133, zT_134, (unsigned int)((unsigned int)i2));
    zT_132 = zT_138;
    zT_139 = zF_FCDD1D35_astStoreNodeAt(zT_131, zT_132);
    dc = zT_139;
    zT_141 = dc.kind;
    zT_142 = (unsigned int)zT_141;
    dk = zT_142;
    zig_poison_fill((void*)&zT_144, (unsigned int)sizeof zT_144);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        db[_i] = zT_144[_i];
        _i++;
    }
}
    zT_146 = dk;
    zT_150 = 0;
    zT_151 = (unsigned char*)((unsigned char*)db) + zT_150;
    zT_152 = (unsigned int)(20) - zT_150;
    zT_153.ptr = (unsigned char*)zT_151;
    zT_153.len = zT_152;
    zT_147 = zT_153;
    zT_154 = zF_A7504564_itoa(zT_146, zT_147);
    dl = zT_154;
    zT_156 = 19;
    zT_157 = (unsigned int)dl;
    zT_158 = zig_wrap_sub_u(((zu64)(zT_156)), ((zu64)(zT_157)), 32u);
    zT_159 = zig_overflow_flag_sub_u(((zu64)(zT_156)), ((zu64)(zT_157)), 32u);
    zT_161 = zT_159 == (unsigned int)(0);
    if (!(zT_161)) { pal_trap(); }
    ds = zT_158;
    zT_165 = 19;
    zT_166 = (unsigned char*)((unsigned char*)db) + ds;
    zT_167 = zT_165 - ds;
    zT_168 = ds <= zT_165;
    if (!(zT_168)) { pal_trap(); }
    zT_169.ptr = (unsigned char*)zT_166;
    zT_169.len = zT_167;
    zT_162 = zT_169;
    zF_48AC7B3A_markerWrite(zT_162);
    zT_171 = " ";
    zT_173 = 1;
    zT_172.ptr = (unsigned char*)zT_171;
    zT_172.len = zT_173;
    dsp = zT_172;
    zT_174 = dsp;
    zF_48AC7B3A_markerWrite(zT_174);
    goto z_bb_16;
    z_bb_15:
    zT_182 = "\n";
    zT_184 = 1;
    zT_183.ptr = (unsigned char*)zT_182;
    zT_183.len = zT_184;
    dn = zT_183;
    zT_185 = dn;
    zF_48AC7B3A_markerWrite(zT_185);
    goto z_bb_12;
    z_bb_16:
    zT_175 = 1;
    zT_176 = (unsigned int)zT_175;
    zT_177 = zig_wrap_add_u(((zu64)(i2)), ((zu64)(zT_176)), 32u);
    zT_178 = zig_overflow_flag_add_u(((zu64)(i2)), ((zu64)(zT_176)), 32u);
    zT_180 = zT_178 == (unsigned int)(0);
    if (!(zT_180)) { pal_trap(); }
    i2 = zT_177;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(i < (unsigned int)((unsigned int)decls_n))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_191 = sym_reg;
    zT_192 = type_reg;
    zT_193 = store;
    zT_194 = module_id;
    zT_199 = store;
    zT_200 = entry.ast_root;
    zT_204 = zF_B10B1BC1_astStoreNodeExtraCh(zT_199, zT_200, (unsigned int)((unsigned int)i));
    zT_195 = zT_204;
    zT_196 = g;
    zT_197 = reg;
    zT_198 = populate;
    zF_CBEB26BC_registerDecl(zT_191, zT_192, zT_193, zT_194, zT_195, zT_196, zT_197, zT_198);
    zT_205 = 1;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_206)), 32u);
    zT_208 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_206)), 32u);
    zT_210 = zT_208 == (unsigned int)(0);
    if (!(zT_210)) { pal_trap(); }
    i = zT_207;
    goto z_bb_20;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
}

/* __module_init */
void zF_780653D2___module_init_14(void) {
    zT_3D7259E2_SymbolRegistry zT_0;
    zT_33EF6BFB_TypeKind zT_1;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_33EF6BFB_TypeKind = zT_1;
    return;
}

/* EOF */
