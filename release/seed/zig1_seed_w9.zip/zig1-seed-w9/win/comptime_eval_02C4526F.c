#include "comptime_eval_02C4526F.h"
unsigned char const zG_BA1EF59F_COMPTIME_INT_LIMBS = (unsigned char)(8);
unsigned char const zG_B0774A4D_KIND_INT = (unsigned char)(0);
unsigned char const zG_88BF088C_KIND_BOOL = (unsigned char)(1);
unsigned char const zG_279B1FC6_KIND_FLOAT = (unsigned char)(2);
unsigned int const zG_6928D1F5_F32_SIGNIFICAND_BIT = (unsigned int)(24);
unsigned int const zG_98770B14_F64_SIGNIFICAND_BIT = (unsigned int)(53);
/* foldCapFromHint */
unsigned int zF_9369138B_foldCapFromHint(unsigned int hint) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned int cap;
    zT_2 = 16;
    cap = zT_2;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(cap < hint)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_4 = 2;
    zT_5 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    cap = zT_5;
    goto z_bb_4;
    z_bb_3:
    return cap;
    z_bb_4:
    goto z_bb_1;
}

/* comptimeFoldTableInit */
zT_77F6F59C_ComptimeFoldTable zF_9BB9958E_comptimeFoldTableIn(zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_1;
    zT_77F6F59C_ComptimeFoldTable zT_4;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1 = alloc;
    zT_4 = zF_125E6ED1_comptimeFoldTableIn(zT_1, (unsigned int)(0));
    return zT_4;
}

/* comptimeFoldTableInitSized */
zT_77F6F59C_ComptimeFoldTable zF_125E6ED1_comptimeFoldTableIn(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    zT_77F6F59C_ComptimeFoldTable zT_3;
    zT_3E40CD83_Sand* zT_4;
    zT_21D3708C_U32ToU32Map zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_3E40CD83_Sand* zT_17;
    unsigned int zT_18;
    zT_21D3708C_U32ToU32Map zT_19;
    zT_3E40CD83_Sand* zT_21;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_FDFD82FD_EU_362 zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zT_77F6F59C_ComptimeFoldTable t;
    unsigned int cap;
    unsigned char* raw;
    zT_4 = alloc;
    zT_5 = zF_58BDA2DE_u32ToU32MapInit(zT_4);
    zT_3.slots = zT_5;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_3.vals = (zT_6081A199_FoldVal*)zT_6;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_3.wide_ints = (zT_0163D9A4_ComptimeInt*)zT_7;
    zT_8 = 0;
    zT_3.wide_len = zT_8;
    zT_9 = 0;
    zT_3.wide_cap = zT_9;
    zT_10 = 0;
    zT_3.len = zT_10;
    zT_11 = 0;
    zT_3.capacity = zT_11;
    zT_3.alloc = alloc;
    t = zT_3;
    if ((unsigned char)(hint > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = hint;
    zT_16 = zF_9369138B_foldCapFromHint(zT_15);
    cap = zT_16;
    zT_17 = alloc;
    zT_18 = hint;
    zT_19 = zF_619D56E6_u32ToU32MapInitCap(zT_17, zT_18);
    t.slots = zT_19;
    zT_21 = alloc;
    zT_24 = 16;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_24)), ((zu64)(cap)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_24)), ((zu64)(cap)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_22 = zT_25;
    zT_30 = zF_1395EB68_sandAlloc(zT_21, zT_22, (unsigned int)(8));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return t;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_32 = zT_30.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_32;
    t.vals = (zT_6081A199_FoldVal*)((zT_6081A199_FoldVal*)raw);
    t.capacity = cap;
    goto z_bb_2;
}

/* comptimeFoldTableGrow */
void zF_82A38CDF_comptimeFoldTableGr(zT_77F6F59C_ComptimeFoldTable* self) {
    unsigned int zT_2;
    zT_6081A199_FoldVal* zT_4;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zT_3E40CD83_Sand* zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_FDFD82FD_EU_362 zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    zT_6081A199_FoldVal* zT_30;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_6081A199_FoldVal zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    unsigned int old_cap;
    zT_6081A199_FoldVal* old_vals;
    unsigned int new_cap;
    unsigned char* raw;
    zT_6081A199_FoldVal* new_vals;
    unsigned int i;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->vals;
    old_vals = zT_4;
    zT_6 = 16;
    new_cap = zT_6;
    if ((unsigned char)(old_cap >= (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 2;
    zT_10 = zig_wrap_mul_u(((zu64)(old_cap)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_mul_u(((zu64)(old_cap)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    new_cap = zT_10;
    goto z_bb_2;
    z_bb_2:
    zT_15 = self->alloc;
    zT_19 = 16;
    zT_20 = zig_wrap_mul_u(((zu64)(zT_19)), ((zu64)(new_cap)), 32u);
    zT_21 = zig_overflow_flag_mul_u(((zu64)(zT_19)), ((zu64)(new_cap)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    zT_16 = zT_20;
    zT_25 = zF_1395EB68_sandAlloc(zT_15, zT_16, (unsigned int)(8));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_27 = zT_25.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_27;
    zT_30 = (zT_6081A199_FoldVal*)raw;
    new_vals = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    i = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_34 = self->len;
    if ((unsigned char)(i < zT_34)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_36 = old_vals[i];
    new_vals[i] = zT_36;
    goto z_bb_9;
    z_bb_8:
    self->vals = new_vals;
    self->capacity = new_cap;
    return;
    z_bb_9:
    zT_37 = 1;
    zT_38 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    i = zT_38;
    goto z_bb_6;
}

/* comptimeFoldTableGrowWide */
void zF_2422B3A0_comptimeFoldTableGr(zT_77F6F59C_ComptimeFoldTable* self) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_3E40CD83_Sand* zT_13;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_FDFD82FD_EU_362 zT_23;
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_0163D9A4_ComptimeInt* zT_28;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_0163D9A4_ComptimeInt* zT_34;
    zT_0163D9A4_ComptimeInt zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* raw;
    zT_0163D9A4_ComptimeInt* new_ints;
    unsigned int i;
    zT_2 = self->wide_cap;
    old_cap = zT_2;
    zT_4 = 16;
    new_cap = zT_4;
    if ((unsigned char)(old_cap >= (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = 2;
    zT_8 = zig_wrap_mul_u(((zu64)(old_cap)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_mul_u(((zu64)(old_cap)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    new_cap = zT_8;
    goto z_bb_2;
    z_bb_2:
    zT_13 = self->alloc;
    zT_17 = 36;
    zT_18 = zig_wrap_mul_u(((zu64)(zT_17)), ((zu64)(new_cap)), 32u);
    zT_19 = zig_overflow_flag_mul_u(((zu64)(zT_17)), ((zu64)(new_cap)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    zT_14 = zT_18;
    zT_23 = zF_1395EB68_sandAlloc(zT_13, zT_14, (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_25 = zT_23.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_25;
    zT_28 = (zT_0163D9A4_ComptimeInt*)raw;
    new_ints = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_6;
    z_bb_6:
    zT_32 = self->wide_len;
    if ((unsigned char)(i < zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = self->wide_ints;
    zT_35 = zT_34[i];
    new_ints[i] = zT_35;
    goto z_bb_9;
    z_bb_8:
    self->wide_ints = new_ints;
    self->wide_cap = new_cap;
    return;
    z_bb_9:
    zT_36 = 1;
    zT_37 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    i = zT_37;
    goto z_bb_6;
}

/* foldValEncode */
zT_6081A199_FoldVal zF_61A1AAB3_foldValEncode(zT_77F6F59C_ComptimeFoldTable* self, zT_89B1DDDA_ComptimeVal v) {
    zT_6081A199_FoldVal zT_3;
    unsigned char zT_4;
    unsigned char zT_5;
    zT_79FAE712_u64 zT_8;
    zT_0163D9A4_ComptimeInt zT_11;
    unsigned char zT_12;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_77F6F59C_ComptimeFoldTable* zT_18;
    unsigned int zT_20;
    zT_0163D9A4_ComptimeInt zT_21;
    zT_0163D9A4_ComptimeInt* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_79FAE712_u64 zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    unsigned char zT_34;
    zT_0163D9A4_ComptimeInt zT_37;
    unsigned int* zT_38;
    int zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    zT_79FAE712_u64 zT_43;
    zT_0163D9A4_ComptimeInt zT_44;
    unsigned char zT_45;
    zT_0163D9A4_ComptimeInt zT_48;
    unsigned int* zT_49;
    int zT_50;
    unsigned char zT_52;
    unsigned int zT_53;
    zT_79FAE712_u64 zT_54;
    zT_79FAE712_u64 zT_55;
    zT_79FAE712_u64 zT_56;
    unsigned char zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zT_79FAE712_u64 zT_62;
    zT_0163D9A4_ComptimeInt zT_64;
    unsigned char zT_65;
    unsigned char zT_66;
    zT_6081A199_FoldVal fv;
    zT_79FAE712_u64 mag;
    unsigned int idx;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    fv = zT_3;
    zT_4 = v.kind;
    fv.kind = zT_4;
    zT_5 = v.kind;
    if ((unsigned char)(zT_5 == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = v.float_bits;
    fv.small = zT_8;
    fv.neg = (unsigned char)(0);
    fv.wide = (unsigned char)(0);
    return fv;
    z_bb_2:
    zT_11 = v.v;
    zT_12 = zT_11.len;
    if ((unsigned char)(zT_12 > (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->wide_len;
    zT_16 = self->wide_cap;
    if ((unsigned char)(zT_15 >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_32 = 0;
    mag = zT_32;
    zT_33 = v.v;
    zT_34 = zT_33.len;
    if ((unsigned char)(zT_34 > (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_18 = self;
    zF_2422B3A0_comptimeFoldTableGr(zT_18);
    goto z_bb_6;
    z_bb_6:
    zT_20 = self->wide_len;
    idx = zT_20;
    zT_21 = v.v;
    zT_22 = self->wide_ints;
    zT_22[idx] = zT_21;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    self->wide_len = zT_24;
    fv.small = (zT_79FAE712_u64)((zT_79FAE712_u64)idx);
    fv.neg = (unsigned char)(0);
    fv.wide = (unsigned char)(1);
    return fv;
    z_bb_7:
    zT_37 = v.v;
    zT_38 = zT_37.mag;
    zT_39 = 0;
    zT_41 = (unsigned int)zT_39 < (unsigned int)(8);
    if (!(zT_41)) { pal_trap(); }
    zT_42 = zT_38[zT_39];
    zT_43 = (zT_79FAE712_u64)zT_42;
    mag = zT_43;
    goto z_bb_8;
    z_bb_8:
    zT_44 = v.v;
    zT_45 = zT_44.len;
    if ((unsigned char)(zT_45 > (unsigned char)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_48 = v.v;
    zT_49 = zT_48.mag;
    zT_50 = 1;
    zT_52 = (unsigned int)zT_50 < (unsigned int)(8);
    if (!(zT_52)) { pal_trap(); }
    zT_53 = zT_49[zT_50];
    zT_54 = (zT_79FAE712_u64)zT_53;
    zT_55 = 32;
    zT_58 = zT_55 < (unsigned int)(64);
    if (!(zT_58)) { pal_trap(); }
    zT_56 = zig_wrap_shl_u(((zu64)(zT_54)), ((zu64)(zT_55)), 64u);
    zT_59 = zig_overflow_flag_shl_u(((zu64)(zT_54)), ((zu64)(zT_55)), 64u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zT_62 = mag | zT_56;
    mag = zT_62;
    goto z_bb_10;
    z_bb_10:
    fv.small = mag;
    fv.neg = (unsigned char)(0);
    zT_64 = v.v;
    zT_65 = zT_64.neg;
    if (zT_65) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_66 = mag != (zT_79FAE712_u64)(0);
    goto z_bb_13;
    z_bb_12:
    zT_66 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_66) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    fv.neg = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    fv.wide = (unsigned char)(0);
    return fv;
}

/* foldValDecode */
zT_89B1DDDA_ComptimeVal zF_93A1879B_foldValDecode(zT_77F6F59C_ComptimeFoldTable* self, zT_6081A199_FoldVal fv) {
    unsigned char zT_2;
    zT_89B1DDDA_ComptimeVal zT_5;
    zT_0163D9A4_ComptimeInt zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8;
    unsigned char zT_9;
    zT_89B1DDDA_ComptimeVal zT_12;
    zT_0163D9A4_ComptimeInt* zT_13;
    zT_79FAE712_u64 zT_14;
    unsigned int zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    unsigned char zT_17;
    zT_79FAE712_u64 zT_18;
    zT_79FAE712_u64 zT_20;
    zT_0163D9A4_ComptimeInt zT_22;
    unsigned char zT_23;
    unsigned char zT_26;
    zT_0163D9A4_ComptimeInt zT_27;
    unsigned char zT_28;
    zT_89B1DDDA_ComptimeVal zT_31;
    unsigned char zT_32;
    zT_79FAE712_u64 zT_33;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zT_0163D9A4_ComptimeInt ci;
    zT_2 = fv.kind;
    if ((unsigned char)(zT_2 == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = zF_DC9B7BC0_ciZeroInt();
    zT_5.v = zT_6;
    zT_7 = 2;
    zT_5.kind = zT_7;
    zT_8 = fv.small;
    zT_5.float_bits = zT_8;
    return zT_5;
    z_bb_2:
    zT_9 = fv.wide;
    if ((unsigned char)(zT_9 == (unsigned char)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self->wide_ints;
    zT_14 = fv.small;
    zT_15 = (unsigned int)zig_cast_checked_u((zu64)zT_14, 64u, 0u, 32u);
    zT_16 = zT_13[zT_15];
    zT_12.v = zT_16;
    zT_17 = fv.kind;
    zT_12.kind = zT_17;
    zT_18 = 0;
    zT_12.float_bits = zT_18;
    return zT_12;
    z_bb_4:
    zT_20 = fv.small;
    zT_22 = zF_1EAA44E6_ciFromU64(zT_20);
    ci = zT_22;
    zT_23 = fv.neg;
    if ((unsigned char)(zT_23 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = ci;
    zT_28 = zF_0F5FA15F_ciIsZero(zT_27);
    zT_26 = !zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_26 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_26) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    ci.neg = (unsigned char)(1);
    goto z_bb_9;
    z_bb_9:
    zT_31.v = ci;
    zT_32 = fv.kind;
    zT_31.kind = zT_32;
    zT_33 = 0;
    zT_31.float_bits = zT_33;
    return zT_31;
}

/* comptimeFoldTablePut */
void zF_376429F5_comptimeFoldTablePu(zT_77F6F59C_ComptimeFoldTable* self, unsigned int node_idx, zT_89B1DDDA_ComptimeVal v) {
    zT_77F6F59C_ComptimeFoldTable* zT_4;
    zT_89B1DDDA_ComptimeVal zT_5;
    zT_6081A199_FoldVal zT_6;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_BAEE192E_Opt_10 zT_10;
    unsigned char zT_11;
    zT_6081A199_FoldVal* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_77F6F59C_ComptimeFoldTable* zT_18;
    zT_6081A199_FoldVal* zT_19;
    unsigned int zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_6081A199_FoldVal fv;
    unsigned int slot;
    zT_4 = self;
    zT_5 = v;
    zT_6 = zF_61A1AAB3_foldValEncode(zT_4, zT_5);
    fv = zT_6;
    zT_7 = &self->slots;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    zT_11 = zT_10.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_10.has_value)) { pal_trap(); }
    slot = zT_10.value;
    zT_13 = self->vals;
    zT_14 = (unsigned int)slot;
    zT_13[zT_14] = fv;
    return;
    z_bb_2:
    zT_15 = self->len;
    zT_16 = self->capacity;
    if ((unsigned char)(zT_15 >= zT_16)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zF_82A38CDF_comptimeFoldTableGr(zT_18);
    goto z_bb_4;
    z_bb_4:
    zT_19 = self->vals;
    zT_20 = self->len;
    zT_19[zT_20] = fv;
    zT_21 = &self->slots;
    zT_22 = node_idx;
    zT_25 = self->len;
    zF_26476265_u32ToU32MapPut(zT_21, zT_22, (unsigned int)((unsigned int)zT_25));
    zT_27 = self->len;
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zig_wrap_add_u(((zu64)(zT_27)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(zT_27)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    self->len = zT_30;
    return;
}

/* comptimeFoldTableGet */
zT_7534F824_Opt_223 zF_A230D7A8_comptimeFoldTableGe(zT_77F6F59C_ComptimeFoldTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned char zT_6;
    unsigned int zT_9;
    zT_77F6F59C_ComptimeFoldTable* zT_11;
    zT_6081A199_FoldVal zT_12;
    zT_6081A199_FoldVal* zT_13;
    unsigned int zT_14;
    zT_6081A199_FoldVal zT_15;
    zT_89B1DDDA_ComptimeVal zT_16;
    zT_7534F824_Opt_223 zT_17;
    zT_7534F824_Opt_223 zT_18;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned int slot;
    zT_2 = &self->slots;
    zT_3 = node_idx;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_5.has_value)) { pal_trap(); }
    slot = zT_5.value;
    zT_9 = self->len;
    if ((unsigned char)((unsigned int)((unsigned int)slot) < zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_18.has_value = 0;
    return zT_18;
    z_bb_3:
    zT_11 = self;
    zT_13 = self->vals;
    zT_14 = (unsigned int)slot;
    zT_15 = zT_13[zT_14];
    zT_12 = zT_15;
    zT_16 = zF_93A1879B_foldValDecode(zT_11, zT_12);
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
    z_bb_4:
    goto z_bb_2;
}

/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_D3EB6303_StringInterner* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_D3EB6303_StringInterner* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_DA663F79_ComptimeEval zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    zT_9BD83C17_Opt_442 zT_87;
    zT_622E1E76_Opt_254 zT_88;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fc;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_itf;
    unsigned int itf_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = (unsigned char*)zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    zT_21 = "@as";
    zT_23 = 3;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    s_as = zT_22;
    zT_25 = interner;
    zT_26 = s_as;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    as_id = zT_27;
    zT_29 = "@floatCast";
    zT_31 = 10;
    zT_30.ptr = (unsigned char*)zT_29;
    zT_30.len = zT_31;
    s_fc = zT_30;
    zT_33 = interner;
    zT_34 = s_fc;
    zT_35 = zF_50C274AF_stringInternerInter(zT_33, zT_34);
    fc_id = zT_35;
    zT_37 = "@intToFloat";
    zT_39 = 11;
    zT_38.ptr = (unsigned char*)zT_37;
    zT_38.len = zT_39;
    s_itf = zT_38;
    zT_41 = interner;
    zT_42 = s_itf;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    itf_id = zT_43;
    zT_45 = interner;
    zT_46 = s_size;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    size_id = zT_47;
    zT_49 = interner;
    zT_50 = s_align;
    zT_51 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    align_id = zT_51;
    zT_53 = "@offsetOf";
    zT_55 = 9;
    zT_54.ptr = (unsigned char*)zT_53;
    zT_54.len = zT_55;
    s_off = zT_54;
    zT_57 = "@bitSizeOf";
    zT_59 = 10;
    zT_58.ptr = (unsigned char*)zT_57;
    zT_58.len = zT_59;
    s_bitsz = zT_58;
    zT_61 = "@bitOffsetOf";
    zT_63 = 12;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    s_bitoff = zT_62;
    zT_65 = interner;
    zT_66 = s_off;
    zT_67 = zF_50C274AF_stringInternerInter(zT_65, zT_66);
    off_id = zT_67;
    zT_69 = interner;
    zT_70 = s_bitsz;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    bitsz_id = zT_71;
    zT_73 = interner;
    zT_74 = s_bitoff;
    zT_75 = zF_50C274AF_stringInternerInter(zT_73, zT_74);
    bitoff_id = zT_75;
    zT_77 = "@isWindows";
    zT_79 = 10;
    zT_78.ptr = (unsigned char*)zT_77;
    zT_78.len = zT_79;
    s_iw = zT_78;
    zT_81 = interner;
    zT_82 = s_iw;
    zT_83 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    iw_id = zT_83;
    zT_84.registry = registry;
    zT_84.store = store;
    zT_84.interner = interner;
    zT_84.symbol_reg = symbol_reg;
    zT_85 = 4294967295u;
    zT_84.module_id = zT_85;
    zT_84.size_of_id = size_id;
    zT_84.align_of_id = align_id;
    zT_84.int_cast_id = intc_id;
    zT_84.as_id = as_id;
    zT_84.float_cast_id = fc_id;
    zT_84.int_to_float_id = itf_id;
    zT_84.offset_of_id = off_id;
    zT_84.bit_size_of_id = bitsz_id;
    zT_84.bit_offset_of_id = bitoff_id;
    zT_84.is_windows_id = iw_id;
    zT_86 = 0;
    zT_84.host_is_windows = zT_86;
    zT_87.has_value = 0;
    zT_84.local_consts = zT_87;
    zT_88.has_value = 0;
    zT_84.diag = zT_88;
    return zT_84;
}

/* ciZeroInt */
zT_0163D9A4_ComptimeInt zF_DC9B7BC0_ciZeroInt(void) {
    zT_0163D9A4_ComptimeInt zT_0;
    zT_9C9EF72B_Arr_unsigned_int_8 zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    zT_2 = 0;
    zT_3 = 0;
    zT_1[zT_3] = zT_2;
    zT_4 = 0;
    zT_5 = 1;
    zT_1[zT_5] = zT_4;
    zT_6 = 0;
    zT_7 = 2;
    zT_1[zT_7] = zT_6;
    zT_8 = 0;
    zT_9 = 3;
    zT_1[zT_9] = zT_8;
    zT_10 = 0;
    zT_11 = 4;
    zT_1[zT_11] = zT_10;
    zT_12 = 0;
    zT_13 = 5;
    zT_1[zT_13] = zT_12;
    zT_14 = 0;
    zT_15 = 6;
    zT_1[zT_15] = zT_14;
    zT_16 = 0;
    zT_17 = 7;
    zT_1[zT_17] = zT_16;
    (void)zT_0.mag;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_0.mag)) {
        ((unsigned char*)&zT_0.mag)[_j] = ((unsigned char*)&zT_1)[_j];
        _j++;
    }
}
    zT_18 = 0;
    zT_0.len = zT_18;
    zT_19 = 0;
    zT_0.neg = zT_19;
    return zT_0;
}

/* ciFromU64 */
zT_0163D9A4_ComptimeInt zF_1EAA44E6_ciFromU64(zT_79FAE712_u64 x) {
    zT_0163D9A4_ComptimeInt zT_2;
    zT_79FAE712_u64 zT_6;
    unsigned int zT_7;
    unsigned int* zT_8;
    int zT_9;
    unsigned char zT_11;
    zT_79FAE712_u64 zT_12;
    unsigned char zT_15;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    int zT_20;
    unsigned char zT_22;
    unsigned int* zT_24;
    int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_0163D9A4_ComptimeInt v;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    if ((unsigned char)(x == (zT_79FAE712_u64)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return v;
    z_bb_2:
    zT_6 = x & (zT_79FAE712_u64)(4294967295u);
    zT_7 = (unsigned int)zig_cast_checked_u((zu64)zT_6, 64u, 0u, 32u);
    zT_8 = v.mag;
    zT_9 = 0;
    zT_11 = (unsigned int)zT_9 < (unsigned int)(8);
    if (!(zT_11)) { pal_trap(); }
    zT_8[zT_9] = zT_7;
    zT_12 = 32;
    zT_15 = zT_12 < (unsigned int)(64);
    if (!(zT_15)) { pal_trap(); }
    zT_17 = (zT_79FAE712_u64)(x >> zT_12) & (zT_79FAE712_u64)(4294967295u);
    zT_18 = (unsigned int)zig_cast_checked_u((zu64)zT_17, 64u, 0u, 32u);
    zT_19 = v.mag;
    zT_20 = 1;
    zT_22 = (unsigned int)zT_20 < (unsigned int)(8);
    if (!(zT_22)) { pal_trap(); }
    zT_19[zT_20] = zT_18;
    v.len = (unsigned char)(1);
    zT_24 = v.mag;
    zT_25 = 1;
    zT_27 = (unsigned int)zT_25 < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_24[zT_25];
    if ((unsigned char)(zT_28 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    v.len = (unsigned char)(2);
    goto z_bb_4;
    z_bb_4:
    return v;
}

/* ciPow2 */
zT_0163D9A4_ComptimeInt zF_8F225501_ciPow2(unsigned int k) {
    zT_0163D9A4_ComptimeInt zT_2;
    unsigned char zT_7;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned int* zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned char zT_30;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_0163D9A4_ComptimeInt v;
    unsigned int word;
    unsigned int bit;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    zT_7 = 1;
    if (!(zT_7)) { pal_trap(); }
    zT_8 = (unsigned int)(unsigned int)(k / (unsigned int)(32));
    word = zT_8;
    zT_13 = 1;
    if (!(zT_13)) { pal_trap(); }
    zT_11 = k % (unsigned int)(32);
    bit = zT_11;
    zT_14 = 1;
    zT_15 = (unsigned int)bit;
    zT_18 = zT_15 < (unsigned int)(32);
    if (!(zT_18)) { pal_trap(); }
    zT_16 = zig_wrap_shl_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zig_overflow_flag_shl_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    zT_22 = v.mag;
    zT_24 = word < (unsigned int)(8);
    if (!(zT_24)) { pal_trap(); }
    zT_22[word] = zT_16;
    zT_25 = 1;
    zT_26 = zig_wrap_add_u(((zu64)(word)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(word)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    zT_30 = (unsigned char)zig_cast_checked_u((zu64)zT_26, 32u, 0u, 8u);
    v.len = zT_30;
    return v;
}

/* ciSet */
void zF_45C2B9E7_ciSet(zT_0163D9A4_ComptimeInt* out, zT_0163D9A4_ComptimeInt src) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int* zT_11;
    unsigned char zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = src.mag;
    zT_9 = i < (unsigned int)(8);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_7[i];
    zT_11 = out->mag;
    zT_13 = i < (unsigned int)(8);
    if (!(zT_13)) { pal_trap(); }
    zT_11[i] = zT_10;
    goto z_bb_4;
    z_bb_3:
    zT_20 = src.len;
    out->len = zT_20;
    zT_21 = src.neg;
    out->neg = zT_21;
    return;
    z_bb_4:
    zT_14 = 1;
    zT_15 = (unsigned int)zT_14;
    zT_16 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    i = zT_16;
    goto z_bb_1;
}

/* ciNormalize */
void zF_390E9E58_ciNormalize(zT_0163D9A4_ComptimeInt* v) {
    unsigned char zT_2;
    unsigned int zT_3;
    unsigned char zT_5;
    int zT_7;
    unsigned char zT_9;
    unsigned int* zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    int zT_29;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int* zT_38;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int l;
    unsigned char done;
    unsigned int i;
    zT_2 = v->len;
    zT_3 = (unsigned int)zT_2;
    l = zT_3;
    zT_5 = 0;
    done = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(!done)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 0;
    if ((unsigned char)(l == (unsigned int)zT_7)) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_28 = (unsigned char)zig_cast_checked_u((zu64)l, 32u, 0u, 8u);
    v->len = zT_28;
    zT_29 = 0;
    if ((unsigned char)(l == (unsigned int)zT_29)) goto z_bb_11; else goto z_bb_12;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_9 = 1;
    done = zT_9;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_10 = v->mag;
    zT_11 = 1;
    zT_12 = zig_wrap_sub_u(((zu64)(l)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_sub_u(((zu64)(l)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_17 = zT_12 < (unsigned int)(8);
    if (!(zT_17)) { pal_trap(); }
    zT_18 = zT_10[zT_12];
    if ((unsigned char)(zT_18 == (unsigned int)(0))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zig_wrap_sub_u(((zu64)(l)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(l)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    l = zT_23;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_27 = 1;
    done = zT_27;
    goto z_bb_9;
    z_bb_11:
    v->neg = (unsigned char)(0);
    zT_33 = 0;
    zT_34 = (unsigned int)zT_33;
    i = zT_34;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_37 = 0;
    zT_38 = v->mag;
    zT_40 = i < (unsigned int)(8);
    if (!(zT_40)) { pal_trap(); }
    zT_38[i] = zT_37;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    zT_43 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    i = zT_43;
    goto z_bb_13;
}

/* ciIsZero */
unsigned char zF_0F5FA15F_ciIsZero(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_1 = v.len;
    return (unsigned char)(zT_1 == (unsigned char)(0));
}

/* ciMagCmp */
int zF_0B19E30C_ciMagCmp(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b) {
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_11;
    unsigned int zT_12;
    int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int* zT_21;
    unsigned char zT_23;
    unsigned int zT_24;
    unsigned int* zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned int* zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int* zT_34;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned int i;
    zT_2 = a.len;
    zT_3 = b.len;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a.len;
    zT_6 = b.len;
    if ((unsigned char)(zT_5 < zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_11 = a.len;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_5;
    z_bb_3:
    return (int)((int)-1);
    z_bb_4:
    return (int)(1);
    z_bb_5:
    zT_13 = 0;
    if ((unsigned char)(i > (unsigned int)zT_13)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    i = zT_17;
    zT_21 = a.mag;
    zT_23 = i < (unsigned int)(8);
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[i];
    zT_25 = b.mag;
    zT_27 = i < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    if ((unsigned char)(zT_24 != zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_30 = a.mag;
    zT_32 = i < (unsigned int)(8);
    if (!(zT_32)) { pal_trap(); }
    zT_33 = zT_30[i];
    zT_34 = b.mag;
    zT_36 = i < (unsigned int)(8);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = zT_34[i];
    if ((unsigned char)(zT_33 < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    return (int)((int)-1);
    z_bb_12:
    return (int)(1);
}

/* ciCmp */
int zF_6408F093_ciCmp(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b) {
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    int zT_11;
    unsigned char zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    int m;
    zT_2 = a.neg;
    zT_3 = b.neg;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a.neg;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_9 = a;
    zT_10 = b;
    zT_11 = zF_0B19E30C_ciMagCmp(zT_9, zT_10);
    m = zT_11;
    zT_12 = a.neg;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)((int)-1);
    z_bb_4:
    return (int)(1);
    z_bb_5:
    zT_13 = 0;
    zT_14 = zig_wrap_sub_s(((z64)(zT_13)), ((z64)(m)), 32u);
    zT_15 = zig_overflow_flag_sub_s(((z64)(zT_13)), ((z64)(m)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    m = zT_14;
    goto z_bb_6;
    z_bb_6:
    return m;
}

/* ciToU64 */
zT_79FAE712_u64 zF_4F2C9C5D_ciToU64(zT_0163D9A4_ComptimeInt v) {
    zT_79FAE712_u64 zT_2;
    unsigned char zT_3;
    unsigned int* zT_6;
    int zT_7;
    unsigned char zT_9;
    unsigned int zT_10;
    zT_79FAE712_u64 zT_11;
    unsigned char zT_12;
    unsigned int* zT_15;
    int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_79FAE712_u64 zT_20;
    zT_79FAE712_u64 zT_21;
    zT_79FAE712_u64 zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_79FAE712_u64 zT_28;
    unsigned char zT_29;
    zT_79FAE712_u64 zT_31;
    zT_79FAE712_u64 m;
    zT_2 = 0;
    m = zT_2;
    zT_3 = v.len;
    if ((unsigned char)(zT_3 > (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = v.mag;
    zT_7 = 0;
    zT_9 = (unsigned int)zT_7 < (unsigned int)(8);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_6[zT_7];
    zT_11 = (zT_79FAE712_u64)zT_10;
    m = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_12 = v.len;
    if ((unsigned char)(zT_12 > (unsigned char)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = v.mag;
    zT_16 = 1;
    zT_18 = (unsigned int)zT_16 < (unsigned int)(8);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_15[zT_16];
    zT_20 = (zT_79FAE712_u64)zT_19;
    zT_21 = 32;
    zT_24 = zT_21 < (unsigned int)(64);
    if (!(zT_24)) { pal_trap(); }
    zT_22 = zig_wrap_shl_u(((zu64)(zT_20)), ((zu64)(zT_21)), 64u);
    zT_25 = zig_overflow_flag_shl_u(((zu64)(zT_20)), ((zu64)(zT_21)), 64u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = m | zT_22;
    m = zT_28;
    goto z_bb_4;
    z_bb_4:
    zT_29 = v.neg;
    if (zT_29) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_31 = (zT_79FAE712_u64)(0) - m;
    m = zT_31;
    goto z_bb_6;
    z_bb_6:
    return m;
}

/* ciToF64 */
zT_00435AEB_f64 zF_E6CE9168_ciToF64(zT_0163D9A4_ComptimeInt v) {
    zT_00435AEB_f64 zT_2;
    unsigned char zT_4;
    unsigned int zT_5;
    int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int* zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_00435AEB_f64 zT_21;
    unsigned char zT_22;
    zT_00435AEB_f64 zT_23;
    zT_00435AEB_f64 fv;
    unsigned int i;
    zT_2 = 0;
    fv = zT_2;
    zT_4 = v.len;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = 0;
    if ((unsigned char)(i > (unsigned int)zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    zT_9 = (unsigned int)zT_8;
    zT_10 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    i = zT_10;
    zT_16 = v.mag;
    zT_18 = i < (unsigned int)(8);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[i];
    zT_21 = (zT_00435AEB_f64)(fv * (zT_00435AEB_f64)(4.294967296e+9)) + (zT_00435AEB_f64)((zT_00435AEB_f64)zT_19);
    fv = zT_21;
    goto z_bb_4;
    z_bb_3:
    zT_22 = v.neg;
    if (zT_22) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = -fv;
    fv = zT_23;
    goto z_bb_6;
    z_bb_6:
    return fv;
}

/* ciIntVal */
zT_89B1DDDA_ComptimeVal zF_237A4571_ciIntVal(zT_0163D9A4_ComptimeInt v) {
    zT_89B1DDDA_ComptimeVal zT_1;
    unsigned int zT_2;
    zT_79FAE712_u64 zT_3;
    zT_1.v = v;
    zT_2 = 0;
    zT_1.kind = zT_2;
    zT_3 = 0;
    zT_1.float_bits = zT_3;
    return zT_1;
}

/* ciBoolVal */
zT_89B1DDDA_ComptimeVal zF_E867E750_ciBoolVal(unsigned char b) {
    zT_0163D9A4_ComptimeInt zT_2;
    zT_0163D9A4_ComptimeInt zT_5;
    zT_89B1DDDA_ComptimeVal zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_0163D9A4_ComptimeInt v;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    if (b) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    v = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_6.v = v;
    zT_7 = 1;
    zT_6.kind = zT_7;
    zT_8 = 0;
    zT_6.float_bits = zT_8;
    return zT_6;
}

/* ciMagAnd */
void zF_51463AE1_ciMagAnd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned char zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_0163D9A4_ComptimeInt* zT_28;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_10 = i < (unsigned int)(8);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = zT_8[i];
    zT_12 = b.mag;
    zT_14 = i < (unsigned int)(8);
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    zT_16 = zT_11 & zT_15;
    zT_17 = out->mag;
    zT_19 = i < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_17[i] = zT_16;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_28 = out;
    zF_390E9E58_ciNormalize(zT_28);
    return;
    z_bb_4:
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    i = zT_22;
    goto z_bb_1;
}

/* ciMagOr */
void zF_5F410015_ciMagOr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned char zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_0163D9A4_ComptimeInt* zT_28;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_10 = i < (unsigned int)(8);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = zT_8[i];
    zT_12 = b.mag;
    zT_14 = i < (unsigned int)(8);
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    zT_16 = zT_11 | zT_15;
    zT_17 = out->mag;
    zT_19 = i < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_17[i] = zT_16;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_28 = out;
    zF_390E9E58_ciNormalize(zT_28);
    return;
    z_bb_4:
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    i = zT_22;
    goto z_bb_1;
}

/* ciMagXor */
void zF_3DC94F2D_ciMagXor(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned char zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned char zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_0163D9A4_ComptimeInt* zT_28;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_10 = i < (unsigned int)(8);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = zT_8[i];
    zT_12 = b.mag;
    zT_14 = i < (unsigned int)(8);
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    zT_16 = zT_11 ^ zT_15;
    zT_17 = out->mag;
    zT_19 = i < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_17[i] = zT_16;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_28 = out;
    zF_390E9E58_ciNormalize(zT_28);
    return;
    z_bb_4:
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    i = zT_22;
    goto z_bb_1;
}

/* ciMagNot */
void zF_EBF92AE9_ciMagNot(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_0163D9A4_ComptimeInt* zT_23;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = a.mag;
    zT_9 = i < (unsigned int)(8);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_7[i];
    zT_11 = ~zT_10;
    zT_12 = out->mag;
    zT_14 = i < (unsigned int)(8);
    if (!(zT_14)) { pal_trap(); }
    zT_12[i] = zT_11;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_23 = out;
    zF_390E9E58_ciNormalize(zT_23);
    return;
    z_bb_4:
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    i = zT_17;
    goto z_bb_1;
}

/* ciMagAddInto */
unsigned char zF_29F86241_ciMagAddInto(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned char zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_21;
    unsigned char zT_22;
    unsigned int* zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    zT_79FAE712_u64 zT_29;
    zT_79FAE712_u64 zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    zT_79FAE712_u64 zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    zT_79FAE712_u64 zT_40;
    unsigned int zT_41;
    unsigned int* zT_42;
    unsigned char zT_44;
    zT_79FAE712_u64 zT_45;
    zT_79FAE712_u64 zT_46;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    zT_0163D9A4_ComptimeInt* zT_60;
    zT_79FAE712_u64 carry;
    unsigned int i;
    zT_79FAE712_u64 av;
    zT_79FAE712_u64 bv;
    zT_79FAE712_u64 s;
    zT_4 = 0;
    carry = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    av = zT_11;
    zT_13 = 0;
    bv = zT_13;
    zT_14 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_4:
    zT_49 = 1;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    i = zT_51;
    goto z_bb_1;
    z_bb_5:
    zT_17 = a.mag;
    zT_19 = i < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[i];
    zT_21 = (zT_79FAE712_u64)zT_20;
    av = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = b.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = b.mag;
    zT_27 = i < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    zT_29 = (zT_79FAE712_u64)zT_28;
    bv = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_31 = zig_wrap_add_u(((zu64)(av)), ((zu64)(bv)), 64u);
    zT_32 = zig_overflow_flag_add_u(((zu64)(av)), ((zu64)(bv)), 64u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = zig_wrap_add_u(((zu64)(zT_31)), ((zu64)(carry)), 64u);
    zT_36 = zig_overflow_flag_add_u(((zu64)(zT_31)), ((zu64)(carry)), 64u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    s = zT_35;
    zT_40 = s & (zT_79FAE712_u64)(4294967295u);
    zT_41 = (unsigned int)zig_cast_checked_u((zu64)zT_40, 64u, 0u, 32u);
    zT_42 = out->mag;
    zT_44 = i < (unsigned int)(8);
    if (!(zT_44)) { pal_trap(); }
    zT_42[i] = zT_41;
    zT_45 = 32;
    zT_48 = zT_45 < (unsigned int)(64);
    if (!(zT_48)) { pal_trap(); }
    zT_46 = s >> zT_45;
    carry = zT_46;
    goto z_bb_4;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_60 = out;
    zF_390E9E58_ciNormalize(zT_60);
    return (unsigned char)(1);
}

/* ciMagSubInto */
unsigned char zF_965473A4_ciMagSubInto(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned char zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_21;
    unsigned char zT_22;
    unsigned int* zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    zT_79FAE712_u64 zT_29;
    zT_79FAE712_u64 zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    zT_79FAE712_u64 zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    zT_79FAE712_u64 zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_46;
    unsigned int* zT_47;
    unsigned char zT_49;
    zT_79FAE712_u64 zT_52;
    zT_79FAE712_u64 zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_0163D9A4_ComptimeInt* zT_62;
    zT_79FAE712_u64 borrow;
    unsigned int i;
    zT_79FAE712_u64 av;
    zT_79FAE712_u64 bv;
    zT_79FAE712_u64 d;
    zT_4 = 0;
    borrow = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    av = zT_11;
    zT_13 = 0;
    bv = zT_13;
    zT_14 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_62 = out;
    zF_390E9E58_ciNormalize(zT_62);
    return (unsigned char)(1);
    z_bb_4:
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    i = zT_56;
    goto z_bb_1;
    z_bb_5:
    zT_17 = a.mag;
    zT_19 = i < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[i];
    zT_21 = (zT_79FAE712_u64)zT_20;
    av = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = b.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = b.mag;
    zT_27 = i < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    zT_29 = (zT_79FAE712_u64)zT_28;
    bv = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_31 = Z98_U64_C(4294967296);
    zT_32 = zig_wrap_add_u(((zu64)(av)), ((zu64)(zT_31)), 64u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(av)), ((zu64)(zT_31)), 64u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_36 = zig_wrap_sub_u(((zu64)(zT_32)), ((zu64)(bv)), 64u);
    zT_37 = zig_overflow_flag_sub_u(((zu64)(zT_32)), ((zu64)(bv)), 64u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = zig_wrap_sub_u(((zu64)(zT_36)), ((zu64)(borrow)), 64u);
    zT_41 = zig_overflow_flag_sub_u(((zu64)(zT_36)), ((zu64)(borrow)), 64u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    d = zT_40;
    zT_45 = d & (zT_79FAE712_u64)(4294967295u);
    zT_46 = (unsigned int)zig_cast_checked_u((zu64)zT_45, 64u, 0u, 32u);
    zT_47 = out->mag;
    zT_49 = i < (unsigned int)(8);
    if (!(zT_49)) { pal_trap(); }
    zT_47[i] = zT_46;
    if ((unsigned char)(d >= (zT_79FAE712_u64)(Z98_U64_C(4294967296)))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_52 = 0;
    borrow = zT_52;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_4;
    z_bb_11:
    zT_53 = 1;
    borrow = zT_53;
    goto z_bb_10;
}

/* ciMagAddOne */
unsigned char zF_962947A9_ciMagAddOne(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_5;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt* zT_8;
    unsigned char zT_9;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_0163D9A4_ComptimeInt one;
    zT_5 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    one = zT_5;
    zT_6 = a;
    zT_7 = one;
    zT_8 = out;
    zT_9 = zF_29F86241_ciMagAddInto(zT_6, zT_7, zT_8);
    return zT_9;
}

/* ciMagSubOne */
unsigned char zF_CBDA30A2_ciMagSubOne(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int* zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned char zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_0163D9A4_ComptimeInt* zT_30;
    unsigned int borrow;
    unsigned int i;
    unsigned int av;
    unsigned int d;
    zT_3 = 1;
    borrow = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = a.mag;
    zT_12 = i < (unsigned int)(8);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[i];
    av = zT_13;
    zT_15 = av - borrow;
    d = zT_15;
    if ((unsigned char)(av < borrow)) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_30 = out;
    zF_390E9E58_ciNormalize(zT_30);
    return (unsigned char)(1);
    z_bb_4:
    zT_22 = 1;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    i = zT_24;
    goto z_bb_1;
    z_bb_5:
    zT_17 = 1;
    borrow = zT_17;
    goto z_bb_6;
    z_bb_6:
    zT_19 = out->mag;
    zT_21 = i < (unsigned int)(8);
    if (!(zT_21)) { pal_trap(); }
    zT_19[i] = d;
    goto z_bb_4;
    z_bb_7:
    zT_18 = 0;
    borrow = zT_18;
    goto z_bb_6;
}

/* ciAdd */
unsigned char zF_8A5DB878_ciAdd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt* zT_8;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char zT_13;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt zT_20;
    int zT_21;
    int zT_22;
    zT_0163D9A4_ComptimeInt* zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26;
    int zT_28;
    zT_0163D9A4_ComptimeInt zT_30;
    zT_0163D9A4_ComptimeInt zT_31;
    zT_0163D9A4_ComptimeInt* zT_32;
    unsigned char zT_33;
    unsigned char zT_36;
    zT_0163D9A4_ComptimeInt zT_38;
    zT_0163D9A4_ComptimeInt zT_39;
    zT_0163D9A4_ComptimeInt* zT_40;
    unsigned char zT_41;
    unsigned char zT_44;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    int m;
    zT_3 = a.neg;
    zT_4 = b.neg;
    if ((unsigned char)(zT_3 == zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = a;
    zT_7 = b;
    zT_8 = out;
    zT_9 = zF_29F86241_ciMagAddInto(zT_6, zT_7, zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_19 = a;
    zT_20 = b;
    zT_21 = zF_0B19E30C_ciMagCmp(zT_19, zT_20);
    m = zT_21;
    zT_22 = 0;
    if ((unsigned char)(m == zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = a.neg;
    out->neg = zT_12;
    zT_13 = out->len;
    if ((unsigned char)(zT_13 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    out->neg = (unsigned char)(0);
    goto z_bb_6;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    zT_24 = out;
    zT_26 = zF_DC9B7BC0_ciZeroInt();
    zT_25 = zT_26;
    zF_45C2B9E7_ciSet(zT_24, zT_25);
    return (unsigned char)(1);
    z_bb_8:
    zT_28 = 0;
    if ((unsigned char)(m > zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = a;
    zT_31 = b;
    zT_32 = out;
    zT_33 = zF_965473A4_ciMagSubInto(zT_30, zT_31, zT_32);
    if ((unsigned char)(!zT_33)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_38 = b;
    zT_39 = a;
    zT_40 = out;
    zT_41 = zF_965473A4_ciMagSubInto(zT_38, zT_39, zT_40);
    if ((unsigned char)(!zT_41)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_36 = a.neg;
    out->neg = zT_36;
    return (unsigned char)(1);
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_44 = b.neg;
    out->neg = zT_44;
    return (unsigned char)(1);
}

/* ciSub */
unsigned char zF_539A2D81_ciSub(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5;
    unsigned char zT_7;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt* zT_12;
    unsigned char zT_13;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zT_0163D9A4_ComptimeInt nb;
    nb = b;
    zT_4 = nb;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = nb.neg;
    nb.neg = (unsigned char)(!zT_7);
    goto z_bb_2;
    z_bb_2:
    zT_10 = a;
    zT_11 = nb;
    zT_12 = out;
    zT_13 = zF_8A5DB878_ciAdd(zT_10, zT_11, zT_12);
    return zT_13;
    z_bb_3:
    nb.neg = (unsigned char)(0);
    goto z_bb_2;
}

/* ciNeg */
unsigned char zF_EECBFD7D_ciNeg(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt* zT_2;
    zT_0163D9A4_ComptimeInt zT_3;
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5;
    unsigned char zT_7;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = out;
    zT_3 = a;
    zF_45C2B9E7_ciSet(zT_2, zT_3);
    zT_4 = a;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = a.neg;
    out->neg = (unsigned char)(!zT_7);
    goto z_bb_2;
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    out->neg = (unsigned char)(0);
    goto z_bb_2;
}

/* ciMul */
unsigned char zF_A3E385DD_ciMul(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_3;
    unsigned char zT_4;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_6;
    unsigned char zT_7;
    zT_0163D9A4_ComptimeInt* zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_B0635956_Arr_zT_79FAE712_u64 zT_13;
    int zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_19;
    unsigned char zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_79FAE712_u64 zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int* zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    zT_79FAE712_u64 zT_49;
    unsigned int* zT_50;
    unsigned char zT_52;
    unsigned int zT_53;
    zT_79FAE712_u64 zT_54;
    zT_79FAE712_u64 zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned char zT_64;
    zT_79FAE712_u64 zT_65;
    zT_79FAE712_u64 zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_79FAE712_u64 zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    zT_79FAE712_u64 zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned char zT_81;
    zT_79FAE712_u64 zT_82;
    zT_79FAE712_u64 zT_83;
    unsigned char zT_85;
    int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned char zT_96;
    unsigned char zT_105;
    zT_79FAE712_u64 zT_106;
    zT_79FAE712_u64 zT_107;
    unsigned int zT_108;
    unsigned char zT_110;
    zT_79FAE712_u64 zT_112;
    unsigned char zT_114;
    zT_79FAE712_u64 zT_115;
    zT_79FAE712_u64 zT_116;
    unsigned char zT_118;
    int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    unsigned int zT_132;
    unsigned char zT_136;
    zT_79FAE712_u64 zT_137;
    int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned char zT_146;
    int zT_147;
    unsigned int zT_148;
    unsigned char zT_152;
    zT_79FAE712_u64 zT_153;
    unsigned int zT_154;
    unsigned int* zT_155;
    unsigned char zT_157;
    int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned char zT_163;
    zT_0163D9A4_ComptimeInt* zT_166;
    unsigned char zT_167;
    unsigned char zT_168;
    unsigned char zT_170;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_B0635956_Arr_zT_79FAE712_u64 acc;
    unsigned int zi;
    unsigned int alen;
    unsigned int blen;
    unsigned int i;
    zT_79FAE712_u64 carry;
    unsigned int j;
    unsigned int oi;
    zT_79FAE712_u64 p;
    unsigned int k;
    zT_79FAE712_u64 c2;
    zT_79FAE712_u64 s;
    zT_3 = a;
    zT_4 = zF_0F5FA15F_ciIsZero(zT_3);
    if (zT_4) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = b;
    zT_7 = zF_0F5FA15F_ciIsZero(zT_6);
    zT_5 = zT_7;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = out;
    zT_10 = zF_DC9B7BC0_ciZeroInt();
    zT_9 = zT_10;
    zF_45C2B9E7_ciSet(zT_8, zT_9);
    return (unsigned char)(1);
    z_bb_5:
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        acc[_i] = zT_13[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    zi = zT_16;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(zi < (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_19 = 0;
    zT_21 = zi < (unsigned int)(16);
    if (!(zT_21)) { pal_trap(); }
    acc[zi] = zT_19;
    goto z_bb_9;
    z_bb_8:
    zT_29 = a.len;
    zT_30 = (unsigned int)zT_29;
    alen = zT_30;
    zT_32 = b.len;
    zT_33 = (unsigned int)zT_32;
    blen = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    goto z_bb_10;
    z_bb_9:
    zT_22 = 1;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zi = zT_24;
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(i < alen)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = 0;
    carry = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    j = zT_42;
    goto z_bb_14;
    z_bb_12:
    zT_132 = 8;
    oi = zT_132;
    goto z_bb_24;
    z_bb_13:
    zT_125 = 1;
    zT_126 = (unsigned int)zT_125;
    zT_127 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_126)), 32u);
    zT_128 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_126)), 32u);
    zT_130 = zT_128 == (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    i = zT_127;
    goto z_bb_10;
    z_bb_14:
    if ((unsigned char)(j < blen)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_45 = a.mag;
    zT_47 = i < (unsigned int)(8);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_45[i];
    zT_49 = (zT_79FAE712_u64)zT_48;
    zT_50 = b.mag;
    zT_52 = j < (unsigned int)(8);
    if (!(zT_52)) { pal_trap(); }
    zT_53 = zT_50[j];
    zT_54 = (zT_79FAE712_u64)zT_53;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_49)), ((zu64)(zT_54)), 64u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_49)), ((zu64)(zT_54)), 64u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_59 = zig_wrap_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    zT_64 = zT_59 < (unsigned int)(16);
    if (!(zT_64)) { pal_trap(); }
    zT_65 = acc[zT_59];
    zT_66 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(zT_65)), 64u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(zT_65)), 64u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = zig_wrap_add_u(((zu64)(zT_66)), ((zu64)(carry)), 64u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(zT_66)), ((zu64)(carry)), 64u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    p = zT_70;
    zT_75 = p & (zT_79FAE712_u64)(4294967295u);
    zT_76 = zig_wrap_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    zT_81 = zT_76 < (unsigned int)(16);
    if (!(zT_81)) { pal_trap(); }
    acc[zT_76] = zT_75;
    zT_82 = 32;
    zT_85 = zT_82 < (unsigned int)(64);
    if (!(zT_85)) { pal_trap(); }
    zT_83 = p >> zT_82;
    carry = zT_83;
    goto z_bb_17;
    z_bb_16:
    zT_93 = zig_wrap_add_u(((zu64)(i)), ((zu64)(blen)), 32u);
    zT_94 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(blen)), 32u);
    zT_96 = zT_94 == (unsigned int)(0);
    if (!(zT_96)) { pal_trap(); }
    k = zT_93;
    c2 = carry;
    goto z_bb_18;
    z_bb_17:
    zT_86 = 1;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    j = zT_88;
    goto z_bb_14;
    z_bb_18:
    if ((unsigned char)(c2 != (zT_79FAE712_u64)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    if ((unsigned char)(k >= (unsigned int)(16))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_13;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_105 = k < (unsigned int)(16);
    if (!(zT_105)) { pal_trap(); }
    zT_106 = acc[k];
    zT_107 = zig_wrap_add_u(((zu64)(zT_106)), ((zu64)(c2)), 64u);
    zT_108 = zig_overflow_flag_add_u(((zu64)(zT_106)), ((zu64)(c2)), 64u);
    zT_110 = zT_108 == (unsigned int)(0);
    if (!(zT_110)) { pal_trap(); }
    s = zT_107;
    zT_112 = s & (zT_79FAE712_u64)(4294967295u);
    zT_114 = k < (unsigned int)(16);
    if (!(zT_114)) { pal_trap(); }
    acc[k] = zT_112;
    zT_115 = 32;
    zT_118 = zT_115 < (unsigned int)(64);
    if (!(zT_118)) { pal_trap(); }
    zT_116 = s >> zT_115;
    c2 = zT_116;
    zT_119 = 1;
    zT_120 = (unsigned int)zT_119;
    zT_121 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_120)), 32u);
    zT_122 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_120)), 32u);
    zT_124 = zT_122 == (unsigned int)(0);
    if (!(zT_124)) { pal_trap(); }
    k = zT_121;
    goto z_bb_21;
    z_bb_24:
    if ((unsigned char)(oi < (unsigned int)(16))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_136 = oi < (unsigned int)(16);
    if (!(zT_136)) { pal_trap(); }
    zT_137 = acc[oi];
    if ((unsigned char)(zT_137 != (zT_79FAE712_u64)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_147 = 0;
    zT_148 = (unsigned int)zT_147;
    i = zT_148;
    goto z_bb_30;
    z_bb_27:
    zT_141 = 1;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zig_wrap_add_u(((zu64)(oi)), ((zu64)(zT_142)), 32u);
    zT_144 = zig_overflow_flag_add_u(((zu64)(oi)), ((zu64)(zT_142)), 32u);
    zT_146 = zT_144 == (unsigned int)(0);
    if (!(zT_146)) { pal_trap(); }
    oi = zT_143;
    goto z_bb_24;
    z_bb_28:
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_152 = i < (unsigned int)(16);
    if (!(zT_152)) { pal_trap(); }
    zT_153 = acc[i];
    zT_154 = (unsigned int)zig_cast_checked_u((zu64)zT_153, 64u, 0u, 32u);
    zT_155 = out->mag;
    zT_157 = i < (unsigned int)(8);
    if (!(zT_157)) { pal_trap(); }
    zT_155[i] = zT_154;
    goto z_bb_33;
    z_bb_32:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_166 = out;
    zF_390E9E58_ciNormalize(zT_166);
    zT_167 = a.neg;
    zT_168 = b.neg;
    out->neg = (unsigned char)(zT_167 != zT_168);
    zT_170 = out->len;
    if ((unsigned char)(zT_170 == (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_158 = 1;
    zT_159 = (unsigned int)zT_158;
    zT_160 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_159)), 32u);
    zT_161 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_159)), 32u);
    zT_163 = zT_161 == (unsigned int)(0);
    if (!(zT_163)) { pal_trap(); }
    i = zT_160;
    goto z_bb_30;
    z_bb_34:
    out->neg = (unsigned char)(0);
    goto z_bb_35;
    z_bb_35:
    return (unsigned char)(1);
}

/* ciDivMod */
unsigned char zF_25A0EEC0_ciDivMod(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* q, zT_0163D9A4_ComptimeInt* r) {
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_7;
    unsigned char zT_8;
    zT_0163D9A4_ComptimeInt* zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt* zT_12;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_0163D9A4_ComptimeInt zT_14;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    int zT_18;
    int zT_19;
    zT_0163D9A4_ComptimeInt* zT_21;
    zT_0163D9A4_ComptimeInt zT_22;
    zT_0163D9A4_ComptimeInt zT_23;
    zT_0163D9A4_ComptimeInt* zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    unsigned char zT_26;
    zT_9B9EF598_Arr_unsigned_int_9 zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    int zT_48;
    unsigned int zT_49;
    zT_0163D9A4_ComptimeInt zT_51;
    int zT_53;
    unsigned int zT_54;
    int zT_55;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned int zT_78;
    int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned char zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    int zT_97;
    unsigned char zT_100;
    unsigned int zT_101;
    int zT_102;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned int* zT_109;
    unsigned char zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_116;
    unsigned int zT_118;
    int zT_119;
    unsigned char zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    int zT_124;
    unsigned char zT_126;
    int zT_127;
    unsigned char zT_129;
    unsigned char zT_131;
    unsigned int zT_132;
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    unsigned char zT_142;
    int zT_143;
    unsigned char zT_145;
    unsigned char zT_146;
    unsigned char zT_149;
    unsigned char zT_150;
    unsigned char zT_154;
    unsigned char zT_156;
    unsigned int zT_157;
    int zT_158;
    unsigned char zT_160;
    int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char zT_169;
    unsigned int zT_170;
    unsigned int* zT_171;
    unsigned char zT_173;
    unsigned int zT_174;
    unsigned char zT_176;
    unsigned char zT_178;
    unsigned int zT_179;
    unsigned int* zT_180;
    unsigned char zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    unsigned char zT_186;
    unsigned char zT_188;
    unsigned int zT_190;
    int zT_192;
    unsigned int zT_193;
    unsigned int zT_197;
    unsigned char zT_198;
    unsigned int* zT_201;
    unsigned char zT_203;
    unsigned int zT_204;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned char zT_209;
    unsigned char zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned char zT_217;
    unsigned char zT_219;
    unsigned int zT_220;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned char zT_231;
    int zT_232;
    unsigned int zT_233;
    unsigned char zT_235;
    int zT_236;
    unsigned char zT_238;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned char zT_244;
    unsigned char zT_246;
    unsigned int zT_247;
    unsigned char zT_250;
    int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned char zT_256;
    int zT_258;
    unsigned int zT_259;
    unsigned char zT_261;
    int zT_263;
    unsigned char zT_266;
    unsigned int zT_267;
    unsigned int* zT_268;
    unsigned char zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned char zT_276;
    unsigned int zT_277;
    unsigned char zT_279;
    unsigned int zT_280;
    unsigned int* zT_281;
    unsigned char zT_283;
    zT_0163D9A4_ComptimeInt* zT_284;
    zT_0163D9A4_ComptimeInt zT_285;
    zT_0163D9A4_ComptimeInt* zT_287;
    unsigned char zT_288;
    unsigned char zT_289;
    unsigned char zT_291;
    int zT_296;
    unsigned int zT_297;
    unsigned char zT_301;
    unsigned int zT_302;
    unsigned int* zT_303;
    unsigned char zT_305;
    int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned char zT_311;
    unsigned char zT_313;
    zT_0163D9A4_ComptimeInt* zT_314;
    unsigned char zT_315;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zT_9B9EF598_Arr_unsigned_int_9 rem;
    unsigned int k;
    unsigned int rem_len;
    zT_0163D9A4_ComptimeInt qm;
    unsigned int bit;
    unsigned int carry;
    unsigned int nv;
    unsigned int word;
    unsigned int pos;
    unsigned int abit;
    unsigned char ge;
    unsigned char diff_found;
    unsigned int m;
    unsigned int borrow;
    unsigned int m2;
    unsigned int bv;
    unsigned char found;
    unsigned int sub;
    unsigned int diff;
    unsigned int qword;
    unsigned int qpos;
    unsigned int ri;
    zT_4 = b;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = a;
    zT_8 = zF_0F5FA15F_ciIsZero(zT_7);
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = q;
    zT_11 = zF_DC9B7BC0_ciZeroInt();
    zT_10 = zT_11;
    zF_45C2B9E7_ciSet(zT_9, zT_10);
    zT_12 = r;
    zT_14 = zF_DC9B7BC0_ciZeroInt();
    zT_13 = zT_14;
    zF_45C2B9E7_ciSet(zT_12, zT_13);
    return (unsigned char)(1);
    z_bb_4:
    zT_16 = a;
    zT_17 = b;
    zT_18 = zF_0B19E30C_ciMagCmp(zT_16, zT_17);
    zT_19 = 0;
    if ((unsigned char)(zT_18 < zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_21 = q;
    zT_23 = zF_DC9B7BC0_ciZeroInt();
    zT_22 = zT_23;
    zF_45C2B9E7_ciSet(zT_21, zT_22);
    zT_24 = r;
    zT_25 = a;
    zF_45C2B9E7_ciSet(zT_24, zT_25);
    zT_26 = r->len;
    if ((unsigned char)(zT_26 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    {
    unsigned int _i = 0;
    while (_i < 9) {
        rem[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    k = zT_35;
    goto z_bb_9;
    z_bb_7:
    r->neg = (unsigned char)(0);
    goto z_bb_8;
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    if ((unsigned char)(k < (unsigned int)(9))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_38 = 0;
    zT_40 = k < (unsigned int)(9);
    if (!(zT_40)) { pal_trap(); }
    rem[k] = zT_38;
    goto z_bb_12;
    z_bb_11:
    zT_48 = 0;
    zT_49 = (unsigned int)zT_48;
    rem_len = zT_49;
    zT_51 = zF_DC9B7BC0_ciZeroInt();
    qm = zT_51;
    zT_53 = 256;
    zT_54 = (unsigned int)zT_53;
    bit = zT_54;
    goto z_bb_13;
    z_bb_12:
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    zT_43 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    k = zT_43;
    goto z_bb_9;
    z_bb_13:
    zT_55 = 0;
    if ((unsigned char)(bit > (unsigned int)zT_55)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = 1;
    zT_58 = (unsigned int)zT_57;
    zT_59 = zig_wrap_sub_u(((zu64)(bit)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_sub_u(((zu64)(bit)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    bit = zT_59;
    zT_64 = 0;
    carry = zT_64;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    k = zT_66;
    goto z_bb_17;
    z_bb_15:
    zT_284 = q;
    zT_285 = qm;
    zF_45C2B9E7_ciSet(zT_284, zT_285);
    q->len = (unsigned char)(8);
    zT_287 = q;
    zF_390E9E58_ciNormalize(zT_287);
    zT_288 = a.neg;
    zT_289 = b.neg;
    q->neg = (unsigned char)(zT_288 != zT_289);
    zT_291 = q->len;
    if ((unsigned char)(zT_291 == (unsigned char)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(k < (unsigned int)(9))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_71 = k < (unsigned int)(9);
    if (!(zT_71)) { pal_trap(); }
    zT_72 = rem[k];
    zT_75 = (unsigned int)(zT_72 * (unsigned int)(2)) | carry;
    nv = zT_75;
    zT_77 = k < (unsigned int)(9);
    if (!(zT_77)) { pal_trap(); }
    zT_78 = rem[k];
    zT_79 = 31;
    zT_82 = (unsigned int)zT_79 < (unsigned int)(32);
    if (!(zT_82)) { pal_trap(); }
    zT_80 = zT_78 >> zT_79;
    carry = zT_80;
    zT_84 = k < (unsigned int)(9);
    if (!(zT_84)) { pal_trap(); }
    rem[k] = nv;
    goto z_bb_20;
    z_bb_19:
    zT_92 = 32;
    zT_95 = (unsigned int)zT_92 != (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    zT_93 = bit / zT_92;
    word = zT_93;
    zT_97 = 32;
    zT_100 = (unsigned int)zT_97 != (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    zT_101 = (unsigned int)(unsigned int)(bit % zT_97);
    pos = zT_101;
    zT_102 = 8;
    if ((unsigned char)(word < (unsigned int)zT_102)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_85 = 1;
    zT_86 = (unsigned int)zT_85;
    zT_87 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_86)), 32u);
    zT_88 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_86)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    k = zT_87;
    goto z_bb_17;
    z_bb_21:
    zT_105 = a.len;
    zT_104 = word < (unsigned int)((unsigned int)zT_105);
    goto z_bb_23;
    z_bb_22:
    zT_104 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_104) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_109 = a.mag;
    zT_111 = word < (unsigned int)(8);
    if (!(zT_111)) { pal_trap(); }
    zT_112 = zT_109[word];
    zT_113 = (unsigned int)pos;
    zT_116 = zT_113 < (unsigned int)(32);
    if (!(zT_116)) { pal_trap(); }
    zT_118 = (unsigned int)(zT_112 >> zT_113) & (unsigned int)(1);
    abit = zT_118;
    zT_119 = 0;
    zT_121 = (unsigned int)zT_119 < (unsigned int)(9);
    if (!(zT_121)) { pal_trap(); }
    zT_122 = rem[zT_119];
    zT_123 = zT_122 | abit;
    zT_124 = 0;
    zT_126 = (unsigned int)zT_124 < (unsigned int)(9);
    if (!(zT_126)) { pal_trap(); }
    rem[zT_124] = zT_123;
    goto z_bb_25;
    z_bb_25:
    zT_127 = 9;
    if ((unsigned char)(rem_len < (unsigned int)zT_127)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_131 = rem_len < (unsigned int)(9);
    if (!(zT_131)) { pal_trap(); }
    zT_132 = rem[rem_len];
    zT_129 = zT_132 != (unsigned int)(0);
    goto z_bb_28;
    z_bb_27:
    zT_129 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_129) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_135 = 1;
    zT_136 = (unsigned int)zT_135;
    zT_137 = zig_wrap_add_u(((zu64)(rem_len)), ((zu64)(zT_136)), 32u);
    zT_138 = zig_overflow_flag_add_u(((zu64)(rem_len)), ((zu64)(zT_136)), 32u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    rem_len = zT_137;
    goto z_bb_30;
    z_bb_30:
    zT_142 = 0;
    ge = zT_142;
    zT_143 = 9;
    if ((unsigned char)(rem_len == (unsigned int)zT_143)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_145 = 1;
    ge = zT_145;
    goto z_bb_32;
    z_bb_32:
    if (ge) goto z_bb_53; else goto z_bb_54;
    z_bb_33:
    zT_146 = b.len;
    if ((unsigned char)(rem_len > (unsigned int)((unsigned int)zT_146))) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_149 = 1;
    ge = zT_149;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_150 = b.len;
    if ((unsigned char)(rem_len == (unsigned int)((unsigned int)zT_150))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_154 = 0;
    diff_found = zT_154;
    zT_156 = b.len;
    zT_157 = (unsigned int)zT_156;
    m = zT_157;
    goto z_bb_39;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_158 = 0;
    if ((unsigned char)(m > (unsigned int)zT_158)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_162 = 1;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zig_wrap_sub_u(((zu64)(m)), ((zu64)(zT_163)), 32u);
    zT_165 = zig_overflow_flag_sub_u(((zu64)(m)), ((zu64)(zT_163)), 32u);
    zT_167 = zT_165 == (unsigned int)(0);
    if (!(zT_167)) { pal_trap(); }
    m = zT_164;
    zT_169 = m < (unsigned int)(9);
    if (!(zT_169)) { pal_trap(); }
    zT_170 = rem[m];
    zT_171 = b.mag;
    zT_173 = m < (unsigned int)(8);
    if (!(zT_173)) { pal_trap(); }
    zT_174 = zT_171[m];
    if ((unsigned char)(zT_170 != zT_174)) goto z_bb_46; else goto z_bb_47;
    z_bb_41:
    if ((unsigned char)(!diff_found)) goto z_bb_51; else goto z_bb_52;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_160 = !diff_found;
    goto z_bb_45;
    z_bb_44:
    zT_160 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_160) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    zT_176 = 1;
    diff_found = zT_176;
    zT_178 = m < (unsigned int)(9);
    if (!(zT_178)) { pal_trap(); }
    zT_179 = rem[m];
    zT_180 = b.mag;
    zT_182 = m < (unsigned int)(8);
    if (!(zT_182)) { pal_trap(); }
    zT_183 = zT_180[m];
    if ((unsigned char)(zT_179 < zT_183)) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_42;
    z_bb_48:
    zT_185 = 0;
    ge = zT_185;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_186 = 1;
    ge = zT_186;
    goto z_bb_49;
    z_bb_51:
    zT_188 = 1;
    ge = zT_188;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_38;
    z_bb_53:
    zT_190 = 0;
    borrow = zT_190;
    zT_192 = 0;
    zT_193 = (unsigned int)zT_192;
    m2 = zT_193;
    goto z_bb_55;
    z_bb_54:
    goto z_bb_16;
    z_bb_55:
    if ((unsigned char)(m2 < (unsigned int)(9))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_197 = 0;
    bv = zT_197;
    zT_198 = b.len;
    if ((unsigned char)(m2 < (unsigned int)((unsigned int)zT_198))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_232 = 9;
    zT_233 = (unsigned int)zT_232;
    rem_len = zT_233;
    zT_235 = 0;
    found = zT_235;
    goto z_bb_64;
    z_bb_58:
    zT_226 = 1;
    zT_227 = (unsigned int)zT_226;
    zT_228 = zig_wrap_add_u(((zu64)(m2)), ((zu64)(zT_227)), 32u);
    zT_229 = zig_overflow_flag_add_u(((zu64)(m2)), ((zu64)(zT_227)), 32u);
    zT_231 = zT_229 == (unsigned int)(0);
    if (!(zT_231)) { pal_trap(); }
    m2 = zT_228;
    goto z_bb_55;
    z_bb_59:
    zT_201 = b.mag;
    zT_203 = m2 < (unsigned int)(8);
    if (!(zT_203)) { pal_trap(); }
    zT_204 = zT_201[m2];
    bv = zT_204;
    goto z_bb_60;
    z_bb_60:
    zT_206 = zig_wrap_add_u(((zu64)(bv)), ((zu64)(borrow)), 32u);
    zT_207 = zig_overflow_flag_add_u(((zu64)(bv)), ((zu64)(borrow)), 32u);
    zT_209 = zT_207 == (unsigned int)(0);
    if (!(zT_209)) { pal_trap(); }
    sub = zT_206;
    zT_212 = m2 < (unsigned int)(9);
    if (!(zT_212)) { pal_trap(); }
    zT_213 = rem[m2];
    zT_214 = zig_wrap_sub_u(((zu64)(zT_213)), ((zu64)(sub)), 32u);
    zT_215 = zig_overflow_flag_sub_u(((zu64)(zT_213)), ((zu64)(sub)), 32u);
    zT_217 = zT_215 == (unsigned int)(0);
    if (!(zT_217)) { pal_trap(); }
    diff = zT_214;
    zT_219 = m2 < (unsigned int)(9);
    if (!(zT_219)) { pal_trap(); }
    zT_220 = rem[m2];
    if ((unsigned char)(zT_220 < sub)) goto z_bb_61; else goto z_bb_63;
    z_bb_61:
    zT_222 = 1;
    borrow = zT_222;
    goto z_bb_62;
    z_bb_62:
    zT_225 = m2 < (unsigned int)(9);
    if (!(zT_225)) { pal_trap(); }
    rem[m2] = diff;
    goto z_bb_58;
    z_bb_63:
    zT_223 = 0;
    borrow = zT_223;
    goto z_bb_62;
    z_bb_64:
    zT_236 = 0;
    if ((unsigned char)(rem_len > (unsigned int)zT_236)) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_240 = 1;
    zT_241 = zig_wrap_sub_u(((zu64)(rem_len)), ((zu64)(zT_240)), 32u);
    zT_242 = zig_overflow_flag_sub_u(((zu64)(rem_len)), ((zu64)(zT_240)), 32u);
    zT_244 = zT_242 == (unsigned int)(0);
    if (!(zT_244)) { pal_trap(); }
    zT_246 = zT_241 < (unsigned int)(9);
    if (!(zT_246)) { pal_trap(); }
    zT_247 = rem[zT_241];
    if ((unsigned char)(zT_247 != (unsigned int)(0))) goto z_bb_71; else goto z_bb_73;
    z_bb_66:
    zT_258 = 32;
    zT_261 = (unsigned int)zT_258 != (unsigned int)(0);
    if (!(zT_261)) { pal_trap(); }
    zT_259 = bit / zT_258;
    qword = zT_259;
    zT_263 = 32;
    zT_266 = (unsigned int)zT_263 != (unsigned int)(0);
    if (!(zT_266)) { pal_trap(); }
    zT_267 = (unsigned int)(unsigned int)(bit % zT_263);
    qpos = zT_267;
    zT_268 = qm.mag;
    zT_270 = qword < (unsigned int)(8);
    if (!(zT_270)) { pal_trap(); }
    zT_271 = zT_268[qword];
    zT_272 = 1;
    zT_273 = (unsigned int)qpos;
    zT_276 = zT_273 < (unsigned int)(32);
    if (!(zT_276)) { pal_trap(); }
    zT_274 = zig_wrap_shl_u(((zu64)(zT_272)), ((zu64)(zT_273)), 32u);
    zT_277 = zig_overflow_flag_shl_u(((zu64)(zT_272)), ((zu64)(zT_273)), 32u);
    zT_279 = zT_277 == (unsigned int)(0);
    if (!(zT_279)) { pal_trap(); }
    zT_280 = zT_271 | zT_274;
    zT_281 = qm.mag;
    zT_283 = qword < (unsigned int)(8);
    if (!(zT_283)) { pal_trap(); }
    zT_281[qword] = zT_280;
    goto z_bb_54;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_238 = !found;
    goto z_bb_70;
    z_bb_69:
    zT_238 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_238) goto z_bb_65; else goto z_bb_66;
    z_bb_71:
    zT_250 = 1;
    found = zT_250;
    goto z_bb_72;
    z_bb_72:
    goto z_bb_67;
    z_bb_73:
    zT_251 = 1;
    zT_252 = (unsigned int)zT_251;
    zT_253 = zig_wrap_sub_u(((zu64)(rem_len)), ((zu64)(zT_252)), 32u);
    zT_254 = zig_overflow_flag_sub_u(((zu64)(rem_len)), ((zu64)(zT_252)), 32u);
    zT_256 = zT_254 == (unsigned int)(0);
    if (!(zT_256)) { pal_trap(); }
    rem_len = zT_253;
    goto z_bb_72;
    z_bb_74:
    q->neg = (unsigned char)(0);
    goto z_bb_75;
    z_bb_75:
    zT_296 = 0;
    zT_297 = (unsigned int)zT_296;
    ri = zT_297;
    goto z_bb_76;
    z_bb_76:
    if ((unsigned char)(ri < (unsigned int)(8))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_301 = ri < (unsigned int)(9);
    if (!(zT_301)) { pal_trap(); }
    zT_302 = rem[ri];
    zT_303 = r->mag;
    zT_305 = ri < (unsigned int)(8);
    if (!(zT_305)) { pal_trap(); }
    zT_303[ri] = zT_302;
    goto z_bb_79;
    z_bb_78:
    r->len = (unsigned char)(8);
    zT_313 = a.neg;
    r->neg = zT_313;
    zT_314 = r;
    zF_390E9E58_ciNormalize(zT_314);
    zT_315 = r->len;
    if ((unsigned char)(zT_315 == (unsigned char)(0))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_306 = 1;
    zT_307 = (unsigned int)zT_306;
    zT_308 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_307)), 32u);
    zT_309 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_307)), 32u);
    zT_311 = zT_309 == (unsigned int)(0);
    if (!(zT_311)) { pal_trap(); }
    ri = zT_308;
    goto z_bb_76;
    z_bb_80:
    r->neg = (unsigned char)(0);
    goto z_bb_81;
    z_bb_81:
    return (unsigned char)(1);
}

/* ciBitAnd */
unsigned char zF_E15DE14D_ciBitAnd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    unsigned char zT_12;
    unsigned char zT_13;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_18;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28;
    zT_0163D9A4_ComptimeInt zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt* zT_35;
    zT_0163D9A4_ComptimeInt zT_37;
    zT_0163D9A4_ComptimeInt* zT_38;
    unsigned char zT_39;
    zT_0163D9A4_ComptimeInt zT_45;
    zT_0163D9A4_ComptimeInt zT_47;
    unsigned char zT_48;
    zT_0163D9A4_ComptimeInt zT_49;
    zT_0163D9A4_ComptimeInt* zT_50;
    unsigned char zT_52;
    zT_0163D9A4_ComptimeInt* zT_55;
    zT_0163D9A4_ComptimeInt zT_56;
    zT_0163D9A4_ComptimeInt zT_58;
    zT_0163D9A4_ComptimeInt* zT_59;
    unsigned char zT_61;
    zT_0163D9A4_ComptimeInt* zT_64;
    zT_0163D9A4_ComptimeInt zT_65;
    zT_0163D9A4_ComptimeInt zT_68;
    zT_0163D9A4_ComptimeInt zT_69;
    zT_0163D9A4_ComptimeInt* zT_70;
    zT_0163D9A4_ComptimeInt zT_72;
    zT_0163D9A4_ComptimeInt zT_73;
    zT_0163D9A4_ComptimeInt* zT_74;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zT_0163D9A4_ComptimeInt am;
    zT_0163D9A4_ComptimeInt bm;
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_0163D9A4_ComptimeInt notm;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_51463AE1_ciMagAnd(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_12 = a.neg;
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_13 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_13 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_13) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_16 = zF_DC9B7BC0_ciZeroInt();
    am = zT_16;
    zT_18 = zF_DC9B7BC0_ciZeroInt();
    bm = zT_18;
    zT_19 = a;
    zT_20 = (zT_0163D9A4_ComptimeInt*)&am;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_45 = zF_DC9B7BC0_ciZeroInt();
    m = zT_45;
    zT_47 = zF_DC9B7BC0_ciZeroInt();
    n = zT_47;
    zT_48 = a.neg;
    if (zT_48) goto z_bb_17; else goto z_bb_19;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = (zT_0163D9A4_ComptimeInt*)&bm;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_32 = zF_DC9B7BC0_ciZeroInt();
    t = zT_32;
    zT_33 = am;
    zT_34 = bm;
    zT_35 = (zT_0163D9A4_ComptimeInt*)&t;
    zF_5F410015_ciMagOr(zT_33, zT_34, zT_35);
    zT_37 = t;
    zT_38 = out;
    zT_39 = zF_962947A9_ciMagAddOne(zT_37, zT_38);
    if ((unsigned char)(!zT_39)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_17:
    zT_49 = a;
    zT_50 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_52 = zF_CBDA30A2_ciMagSubOne(zT_49, zT_50);
    if ((unsigned char)(!zT_52)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_68 = zF_DC9B7BC0_ciZeroInt();
    notm = zT_68;
    zT_69 = m;
    zT_70 = (zT_0163D9A4_ComptimeInt*)&notm;
    zF_EBF92AE9_ciMagNot(zT_69, zT_70);
    zT_72 = notm;
    zT_73 = n;
    zT_74 = out;
    zF_51463AE1_ciMagAnd(zT_72, zT_73, zT_74);
    return (unsigned char)(1);
    z_bb_19:
    zT_58 = b;
    zT_59 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_61 = zF_CBDA30A2_ciMagSubOne(zT_58, zT_59);
    if ((unsigned char)(!zT_61)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_55 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_56 = b;
    zF_45C2B9E7_ciSet(zT_55, zT_56);
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_64 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_65 = a;
    zF_45C2B9E7_ciSet(zT_64, zT_65);
    goto z_bb_18;
}

/* ciBitOr */
unsigned char zF_93823331_ciBitOr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_0163D9A4_ComptimeInt zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28;
    zT_0163D9A4_ComptimeInt zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt* zT_35;
    zT_0163D9A4_ComptimeInt zT_37;
    zT_0163D9A4_ComptimeInt* zT_38;
    unsigned char zT_39;
    unsigned char zT_44;
    zT_0163D9A4_ComptimeInt zT_45;
    zT_0163D9A4_ComptimeInt* zT_46;
    unsigned char zT_48;
    zT_0163D9A4_ComptimeInt* zT_51;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_54;
    zT_0163D9A4_ComptimeInt* zT_55;
    unsigned char zT_57;
    zT_0163D9A4_ComptimeInt* zT_60;
    zT_0163D9A4_ComptimeInt zT_61;
    zT_0163D9A4_ComptimeInt zT_64;
    zT_0163D9A4_ComptimeInt zT_65;
    zT_0163D9A4_ComptimeInt* zT_66;
    zT_0163D9A4_ComptimeInt zT_69;
    zT_0163D9A4_ComptimeInt zT_70;
    zT_0163D9A4_ComptimeInt zT_71;
    zT_0163D9A4_ComptimeInt* zT_72;
    zT_0163D9A4_ComptimeInt zT_74;
    zT_0163D9A4_ComptimeInt* zT_75;
    unsigned char zT_76;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_0163D9A4_ComptimeInt notn;
    zT_0163D9A4_ComptimeInt t2;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_5F410015_ciMagOr(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_13 = zF_DC9B7BC0_ciZeroInt();
    m = zT_13;
    zT_15 = zF_DC9B7BC0_ciZeroInt();
    n = zT_15;
    zT_16 = a.neg;
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = a;
    zT_20 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_44 = a.neg;
    if (zT_44) goto z_bb_17; else goto z_bb_19;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_32 = zF_DC9B7BC0_ciZeroInt();
    t = zT_32;
    zT_33 = m;
    zT_34 = n;
    zT_35 = (zT_0163D9A4_ComptimeInt*)&t;
    zF_51463AE1_ciMagAnd(zT_33, zT_34, zT_35);
    zT_37 = t;
    zT_38 = out;
    zT_39 = zF_962947A9_ciMagAddOne(zT_37, zT_38);
    if ((unsigned char)(!zT_39)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_17:
    zT_45 = a;
    zT_46 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_48 = zF_CBDA30A2_ciMagSubOne(zT_45, zT_46);
    if ((unsigned char)(!zT_48)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_64 = zF_DC9B7BC0_ciZeroInt();
    notn = zT_64;
    zT_65 = n;
    zT_66 = (zT_0163D9A4_ComptimeInt*)&notn;
    zF_EBF92AE9_ciMagNot(zT_65, zT_66);
    zT_69 = zF_DC9B7BC0_ciZeroInt();
    t2 = zT_69;
    zT_70 = m;
    zT_71 = notn;
    zT_72 = (zT_0163D9A4_ComptimeInt*)&t2;
    zF_51463AE1_ciMagAnd(zT_70, zT_71, zT_72);
    zT_74 = t2;
    zT_75 = out;
    zT_76 = zF_962947A9_ciMagAddOne(zT_74, zT_75);
    if ((unsigned char)(!zT_76)) goto z_bb_24; else goto z_bb_25;
    z_bb_19:
    zT_54 = b;
    zT_55 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_57 = zF_CBDA30A2_ciMagSubOne(zT_54, zT_55);
    if ((unsigned char)(!zT_57)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_51 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_52 = b;
    zF_45C2B9E7_ciSet(zT_51, zT_52);
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_60 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_61 = a;
    zF_45C2B9E7_ciSet(zT_60, zT_61);
    goto z_bb_18;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciBitXor */
unsigned char zF_C592CA21_ciBitXor(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_0163D9A4_ComptimeInt zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28;
    zT_0163D9A4_ComptimeInt zT_31;
    zT_0163D9A4_ComptimeInt zT_32;
    zT_0163D9A4_ComptimeInt* zT_33;
    unsigned char zT_35;
    zT_0163D9A4_ComptimeInt zT_36;
    zT_0163D9A4_ComptimeInt* zT_37;
    unsigned char zT_39;
    zT_0163D9A4_ComptimeInt* zT_42;
    zT_0163D9A4_ComptimeInt zT_43;
    zT_0163D9A4_ComptimeInt zT_45;
    zT_0163D9A4_ComptimeInt* zT_46;
    unsigned char zT_48;
    zT_0163D9A4_ComptimeInt* zT_51;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_55;
    zT_0163D9A4_ComptimeInt zT_56;
    zT_0163D9A4_ComptimeInt zT_57;
    zT_0163D9A4_ComptimeInt* zT_58;
    zT_0163D9A4_ComptimeInt zT_60;
    zT_0163D9A4_ComptimeInt* zT_61;
    unsigned char zT_62;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_3DC94F2D_ciMagXor(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_13 = zF_DC9B7BC0_ciZeroInt();
    m = zT_13;
    zT_15 = zF_DC9B7BC0_ciZeroInt();
    n = zT_15;
    zT_16 = a.neg;
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = a;
    zT_20 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_35 = a.neg;
    if (zT_35) goto z_bb_15; else goto z_bb_17;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_31 = m;
    zT_32 = n;
    zT_33 = out;
    zF_3DC94F2D_ciMagXor(zT_31, zT_32, zT_33);
    return (unsigned char)(1);
    z_bb_15:
    zT_36 = a;
    zT_37 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_39 = zF_CBDA30A2_ciMagSubOne(zT_36, zT_37);
    if ((unsigned char)(!zT_39)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    zT_55 = zF_DC9B7BC0_ciZeroInt();
    t = zT_55;
    zT_56 = m;
    zT_57 = n;
    zT_58 = (zT_0163D9A4_ComptimeInt*)&t;
    zF_3DC94F2D_ciMagXor(zT_56, zT_57, zT_58);
    zT_60 = t;
    zT_61 = out;
    zT_62 = zF_962947A9_ciMagAddOne(zT_60, zT_61);
    if ((unsigned char)(!zT_62)) goto z_bb_22; else goto z_bb_23;
    z_bb_17:
    zT_45 = b;
    zT_46 = (zT_0163D9A4_ComptimeInt*)&m;
    zT_48 = zF_CBDA30A2_ciMagSubOne(zT_45, zT_46);
    if ((unsigned char)(!zT_48)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    return (unsigned char)(0);
    z_bb_19:
    zT_42 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_43 = b;
    zF_45C2B9E7_ciSet(zT_42, zT_43);
    goto z_bb_16;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_51 = (zT_0163D9A4_ComptimeInt*)&n;
    zT_52 = a;
    zF_45C2B9E7_ciSet(zT_51, zT_52);
    goto z_bb_16;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciBitNot */
unsigned char zF_223ABA6D_ciBitNot(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_2;
    zT_0163D9A4_ComptimeInt zT_3;
    zT_0163D9A4_ComptimeInt* zT_4;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt* zT_11;
    unsigned char zT_12;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_2 = a.neg;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = a;
    zT_4 = out;
    zT_5 = zF_CBDA30A2_ciMagSubOne(zT_3, zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_10 = a;
    zT_11 = out;
    zT_12 = zF_962947A9_ciMagAddOne(zT_10, zT_11);
    if ((unsigned char)(!zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    out->neg = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciShl */
unsigned char zF_4FDD0D22_ciShl(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_5;
    unsigned char zT_6;
    unsigned char zT_9;
    zT_0163D9A4_ComptimeInt zT_13;
    unsigned char zT_14;
    zT_0163D9A4_ComptimeInt* zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned int* zT_24;
    int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned int zT_40;
    unsigned char zT_42;
    zT_6749E41F_Arr_zT_79FAE712_u64 zT_44;
    int zT_46;
    unsigned int zT_47;
    zT_79FAE712_u64 zT_51;
    unsigned char zT_52;
    unsigned int* zT_55;
    unsigned char zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_59;
    zT_79FAE712_u64 zT_60;
    zT_79FAE712_u64 zT_61;
    unsigned char zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned char zT_68;
    unsigned char zT_70;
    zT_79FAE712_u64 zT_71;
    unsigned char zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    zT_79FAE712_u64 zT_89;
    int zT_90;
    unsigned int zT_91;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned char zT_104;
    zT_79FAE712_u64 zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned char zT_109;
    zT_79FAE712_u64 zT_111;
    unsigned int zT_112;
    unsigned int* zT_113;
    unsigned char zT_115;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_117;
    unsigned char zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned char zT_125;
    zT_0163D9A4_ComptimeInt* zT_131;
    unsigned char zT_132;
    unsigned char zT_133;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned int sh;
    unsigned int word;
    unsigned int bits;
    zT_6749E41F_Arr_zT_79FAE712_u64 tmp;
    unsigned int i;
    zT_79FAE712_u64 src;
    zT_79FAE712_u64 carry;
    zT_79FAE712_u64 val;
    unsigned int si;
    zT_3 = b.neg;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = b;
    zT_6 = zF_0F5FA15F_ciIsZero(zT_5);
    zT_4 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_9 = b.len;
    if ((unsigned char)(zT_9 > (unsigned char)(1))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_13 = a;
    zT_14 = zF_0F5FA15F_ciIsZero(zT_13);
    if (zT_14) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = out;
    zT_17 = zF_DC9B7BC0_ciZeroInt();
    zT_16 = zT_17;
    zF_45C2B9E7_ciSet(zT_15, zT_16);
    return (unsigned char)(1);
    z_bb_9:
    zT_20 = 0;
    sh = zT_20;
    zT_21 = b.len;
    if ((unsigned char)(zT_21 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = b.mag;
    zT_25 = 0;
    zT_27 = (unsigned int)zT_25 < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_24[zT_25];
    sh = zT_28;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(sh >= (unsigned int)(256))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(0);
    z_bb_13:
    zT_36 = 1;
    if (!(zT_36)) { pal_trap(); }
    zT_37 = (unsigned int)(unsigned int)(sh / (unsigned int)(32));
    word = zT_37;
    zT_42 = 1;
    if (!(zT_42)) { pal_trap(); }
    zT_40 = sh % (unsigned int)(32);
    bits = zT_40;
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        tmp[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    i = zT_47;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_51 = 0;
    src = zT_51;
    zT_52 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_52))) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    zT_89 = 0;
    carry = zT_89;
    zT_90 = 0;
    zT_91 = (unsigned int)zT_90;
    i = zT_91;
    goto z_bb_25;
    z_bb_17:
    zT_82 = 1;
    zT_83 = (unsigned int)zT_82;
    zT_84 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_83)), 32u);
    zT_85 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_83)), 32u);
    zT_87 = zT_85 == (unsigned int)(0);
    if (!(zT_87)) { pal_trap(); }
    i = zT_84;
    goto z_bb_14;
    z_bb_18:
    zT_55 = a.mag;
    zT_57 = i < (unsigned int)(8);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = zT_55[i];
    zT_59 = (zT_79FAE712_u64)zT_58;
    src = zT_59;
    goto z_bb_19;
    z_bb_19:
    zT_60 = (zT_79FAE712_u64)bits;
    zT_63 = zT_60 < (unsigned int)(64);
    if (!(zT_63)) { pal_trap(); }
    zT_61 = zig_wrap_shl_u(((zu64)(src)), ((zu64)(zT_60)), 64u);
    zT_64 = zig_overflow_flag_shl_u(((zu64)(src)), ((zu64)(zT_60)), 64u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    zT_68 = i < (unsigned int)(8);
    if (!(zT_68)) { pal_trap(); }
    tmp[i] = zT_61;
    zT_70 = i < (unsigned int)(8);
    if (!(zT_70)) { pal_trap(); }
    zT_71 = tmp[i];
    if ((unsigned char)(zT_71 != (zT_79FAE712_u64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_75 = zig_wrap_add_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_76 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    zT_74 = zT_75 >= (unsigned int)(8);
    goto z_bb_22;
    z_bb_21:
    zT_74 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_74) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    goto z_bb_17;
    z_bb_25:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    val = carry;
    if ((unsigned char)(i >= word)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_28:
    zT_120 = 1;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_121)), 32u);
    zT_123 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_121)), 32u);
    zT_125 = zT_123 == (unsigned int)(0);
    if (!(zT_125)) { pal_trap(); }
    i = zT_122;
    goto z_bb_25;
    z_bb_29:
    zT_97 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_98 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    si = zT_97;
    if ((unsigned char)(si < (unsigned int)(8))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_111 = val & (zT_79FAE712_u64)(4294967295u);
    zT_112 = (unsigned int)zig_cast_checked_u((zu64)zT_111, 64u, 0u, 32u);
    zT_113 = out->mag;
    zT_115 = i < (unsigned int)(8);
    if (!(zT_115)) { pal_trap(); }
    zT_113[i] = zT_112;
    zT_116 = 32;
    zT_119 = zT_116 < (unsigned int)(64);
    if (!(zT_119)) { pal_trap(); }
    zT_117 = val >> zT_116;
    carry = zT_117;
    goto z_bb_28;
    z_bb_31:
    zT_104 = si < (unsigned int)(8);
    if (!(zT_104)) { pal_trap(); }
    zT_105 = tmp[si];
    zT_106 = zig_wrap_add_u(((zu64)(val)), ((zu64)(zT_105)), 64u);
    zT_107 = zig_overflow_flag_add_u(((zu64)(val)), ((zu64)(zT_105)), 64u);
    zT_109 = zT_107 == (unsigned int)(0);
    if (!(zT_109)) { pal_trap(); }
    val = zT_106;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_131 = out;
    zF_390E9E58_ciNormalize(zT_131);
    zT_132 = a.neg;
    out->neg = zT_132;
    zT_133 = out->len;
    if ((unsigned char)(zT_133 == (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    out->neg = (unsigned char)(0);
    goto z_bb_36;
    z_bb_36:
    return (unsigned char)(1);
}

/* ciShr */
unsigned char zF_41DCF718_ciShr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_5;
    unsigned char zT_6;
    unsigned char zT_9;
    zT_0163D9A4_ComptimeInt zT_13;
    unsigned char zT_14;
    zT_0163D9A4_ComptimeInt* zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned int* zT_24;
    int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_31;
    zT_0163D9A4_ComptimeInt* zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_36;
    zT_0163D9A4_ComptimeInt* zT_38;
    zT_0163D9A4_ComptimeInt zT_39;
    zT_0163D9A4_ComptimeInt zT_40;
    unsigned char zT_46;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned char zT_52;
    unsigned char zT_54;
    int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_62;
    unsigned int* zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned char zT_69;
    int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    unsigned char zT_78;
    unsigned char zT_79;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned int* zT_96;
    unsigned char zT_98;
    unsigned int zT_99;
    unsigned char zT_103;
    int zT_104;
    unsigned int zT_105;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    zT_79FAE712_u64 zT_114;
    unsigned char zT_115;
    unsigned int* zT_118;
    unsigned char zT_120;
    unsigned int zT_121;
    zT_79FAE712_u64 zT_123;
    zT_79FAE712_u64 zT_124;
    unsigned char zT_126;
    zT_79FAE712_u64 zT_128;
    unsigned char zT_131;
    int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    unsigned char zT_137;
    unsigned int* zT_140;
    int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_145;
    unsigned char zT_147;
    unsigned int zT_148;
    zT_79FAE712_u64 zT_149;
    int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned char zT_154;
    zT_79FAE712_u64 zT_155;
    zT_79FAE712_u64 zT_156;
    unsigned char zT_158;
    unsigned int zT_159;
    unsigned char zT_161;
    zT_79FAE712_u64 zT_164;
    unsigned int zT_165;
    unsigned int* zT_166;
    unsigned char zT_168;
    int zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned char zT_174;
    zT_0163D9A4_ComptimeInt* zT_177;
    unsigned char zT_178;
    zT_79FAE712_u64 zT_180;
    int zT_182;
    unsigned int zT_183;
    unsigned int* zT_187;
    unsigned char zT_189;
    unsigned int zT_190;
    zT_79FAE712_u64 zT_191;
    zT_79FAE712_u64 zT_192;
    unsigned int zT_193;
    unsigned char zT_195;
    zT_79FAE712_u64 zT_197;
    unsigned int zT_198;
    unsigned int* zT_199;
    unsigned char zT_201;
    zT_79FAE712_u64 zT_202;
    zT_79FAE712_u64 zT_203;
    unsigned char zT_205;
    unsigned int zT_208;
    int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    zT_0163D9A4_ComptimeInt* zT_219;
    unsigned char zT_220;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    unsigned int sh;
    unsigned int word;
    unsigned int bits;
    unsigned char sticky;
    unsigned int i;
    unsigned int mask;
    unsigned int idx;
    zT_79FAE712_u64 lo;
    zT_79FAE712_u64 hi;
    zT_79FAE712_u64 carry;
    unsigned int k2;
    zT_79FAE712_u64 s;
    zT_3 = b.neg;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = b;
    zT_6 = zF_0F5FA15F_ciIsZero(zT_5);
    zT_4 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_9 = b.len;
    if ((unsigned char)(zT_9 > (unsigned char)(1))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_13 = a;
    zT_14 = zF_0F5FA15F_ciIsZero(zT_13);
    if (zT_14) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = out;
    zT_17 = zF_DC9B7BC0_ciZeroInt();
    zT_16 = zT_17;
    zF_45C2B9E7_ciSet(zT_15, zT_16);
    return (unsigned char)(1);
    z_bb_9:
    zT_20 = 0;
    sh = zT_20;
    zT_21 = b.len;
    if ((unsigned char)(zT_21 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = b.mag;
    zT_25 = 0;
    zT_27 = (unsigned int)zT_25 < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_24[zT_25];
    sh = zT_28;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(sh >= (unsigned int)(256))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_31 = a.neg;
    if (zT_31) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_46 = 1;
    if (!(zT_46)) { pal_trap(); }
    zT_47 = (unsigned int)(unsigned int)(sh / (unsigned int)(32));
    word = zT_47;
    zT_52 = 1;
    if (!(zT_52)) { pal_trap(); }
    zT_50 = sh % (unsigned int)(32);
    bits = zT_50;
    zT_54 = 0;
    sticky = zT_54;
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    i = zT_57;
    goto z_bb_17;
    z_bb_14:
    zT_32 = out;
    zT_36 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    zT_33 = zT_36;
    zF_45C2B9E7_ciSet(zT_32, zT_33);
    out->neg = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_38 = out;
    zT_40 = zF_DC9B7BC0_ciZeroInt();
    zT_39 = zT_40;
    zF_45C2B9E7_ciSet(zT_38, zT_39);
    goto z_bb_15;
    z_bb_17:
    if ((unsigned char)(i < word)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_59 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_59))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    if ((unsigned char)(bits > (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_20:
    zT_70 = 1;
    zT_71 = (unsigned int)zT_70;
    zT_72 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_71)), 32u);
    zT_73 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_71)), 32u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    i = zT_72;
    goto z_bb_17;
    z_bb_21:
    zT_63 = a.mag;
    zT_65 = i < (unsigned int)(8);
    if (!(zT_65)) { pal_trap(); }
    zT_66 = zT_63[i];
    zT_62 = zT_66 != (unsigned int)(0);
    goto z_bb_23;
    z_bb_22:
    zT_62 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_62) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_69 = 1;
    sticky = zT_69;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_20;
    z_bb_26:
    zT_79 = a.len;
    zT_78 = word < (unsigned int)((unsigned int)zT_79);
    goto z_bb_28;
    z_bb_27:
    zT_78 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_78) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_83 = 1;
    zT_84 = (unsigned int)bits;
    zT_87 = zT_84 < (unsigned int)(32);
    if (!(zT_87)) { pal_trap(); }
    zT_85 = zig_wrap_shl_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_88 = zig_overflow_flag_shl_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    zT_91 = 1;
    zT_92 = zig_wrap_sub_u(((zu64)(zT_85)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_sub_u(((zu64)(zT_85)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    mask = zT_92;
    zT_96 = a.mag;
    zT_98 = word < (unsigned int)(8);
    if (!(zT_98)) { pal_trap(); }
    zT_99 = zT_96[word];
    if ((unsigned char)((unsigned int)(zT_99 & mask) != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    i = zT_105;
    goto z_bb_33;
    z_bb_31:
    zT_103 = 1;
    sticky = zT_103;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_109 = zig_wrap_add_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_110 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(word)), 32u);
    zT_112 = zT_110 == (unsigned int)(0);
    if (!(zT_112)) { pal_trap(); }
    idx = zT_109;
    zT_114 = 0;
    lo = zT_114;
    zT_115 = a.len;
    if ((unsigned char)(idx < (unsigned int)((unsigned int)zT_115))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_177 = out;
    zF_390E9E58_ciNormalize(zT_177);
    zT_178 = a.neg;
    if (zT_178) goto z_bb_44; else goto z_bb_45;
    z_bb_36:
    zT_169 = 1;
    zT_170 = (unsigned int)zT_169;
    zT_171 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_170)), 32u);
    zT_172 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_170)), 32u);
    zT_174 = zT_172 == (unsigned int)(0);
    if (!(zT_174)) { pal_trap(); }
    i = zT_171;
    goto z_bb_33;
    z_bb_37:
    zT_118 = a.mag;
    zT_120 = idx < (unsigned int)(8);
    if (!(zT_120)) { pal_trap(); }
    zT_121 = zT_118[idx];
    zT_123 = (zT_79FAE712_u64)bits;
    zT_126 = zT_123 < (unsigned int)(64);
    if (!(zT_126)) { pal_trap(); }
    zT_124 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_121) >> zT_123;
    lo = zT_124;
    goto z_bb_38;
    z_bb_38:
    zT_128 = 0;
    hi = zT_128;
    if ((unsigned char)(bits > (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_132 = 1;
    zT_133 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_132)), 32u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_132)), 32u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    zT_137 = a.len;
    zT_131 = zT_133 < (unsigned int)((unsigned int)zT_137);
    goto z_bb_41;
    z_bb_40:
    zT_131 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_131) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_140 = a.mag;
    zT_141 = 1;
    zT_142 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_141)), 32u);
    zT_143 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_141)), 32u);
    zT_145 = zT_143 == (unsigned int)(0);
    if (!(zT_145)) { pal_trap(); }
    zT_147 = zT_142 < (unsigned int)(8);
    if (!(zT_147)) { pal_trap(); }
    zT_148 = zT_140[zT_142];
    zT_149 = (zT_79FAE712_u64)zT_148;
    zT_150 = 32;
    zT_151 = zig_wrap_sub_u(((zu64)(zT_150)), ((zu64)(bits)), 32u);
    zT_152 = zig_overflow_flag_sub_u(((zu64)(zT_150)), ((zu64)(bits)), 32u);
    zT_154 = zT_152 == (unsigned int)(0);
    if (!(zT_154)) { pal_trap(); }
    zT_155 = (zT_79FAE712_u64)zT_151;
    zT_158 = zT_155 < (unsigned int)(64);
    if (!(zT_158)) { pal_trap(); }
    zT_156 = zig_wrap_shl_u(((zu64)(zT_149)), ((zu64)(zT_155)), 64u);
    zT_159 = zig_overflow_flag_shl_u(((zu64)(zT_149)), ((zu64)(zT_155)), 64u);
    zT_161 = zT_159 == (unsigned int)(0);
    if (!(zT_161)) { pal_trap(); }
    hi = zT_156;
    goto z_bb_43;
    z_bb_43:
    zT_164 = (zT_79FAE712_u64)(lo | hi) & (zT_79FAE712_u64)(4294967295u);
    zT_165 = (unsigned int)zig_cast_checked_u((zu64)zT_164, 64u, 0u, 32u);
    zT_166 = out->mag;
    zT_168 = i < (unsigned int)(8);
    if (!(zT_168)) { pal_trap(); }
    zT_166[i] = zT_165;
    goto z_bb_36;
    z_bb_44:
    if (sticky) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    zT_180 = 1;
    carry = zT_180;
    zT_182 = 0;
    zT_183 = (unsigned int)zT_182;
    k2 = zT_183;
    goto z_bb_48;
    z_bb_47:
    zT_220 = out->len;
    if ((unsigned char)(zT_220 != (unsigned char)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_48:
    if ((unsigned char)(k2 < (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_187 = out->mag;
    zT_189 = k2 < (unsigned int)(8);
    if (!(zT_189)) { pal_trap(); }
    zT_190 = zT_187[k2];
    zT_191 = (zT_79FAE712_u64)zT_190;
    zT_192 = zig_wrap_add_u(((zu64)(zT_191)), ((zu64)(carry)), 64u);
    zT_193 = zig_overflow_flag_add_u(((zu64)(zT_191)), ((zu64)(carry)), 64u);
    zT_195 = zT_193 == (unsigned int)(0);
    if (!(zT_195)) { pal_trap(); }
    s = zT_192;
    zT_197 = s & (zT_79FAE712_u64)(4294967295u);
    zT_198 = (unsigned int)zig_cast_checked_u((zu64)zT_197, 64u, 0u, 32u);
    zT_199 = out->mag;
    zT_201 = k2 < (unsigned int)(8);
    if (!(zT_201)) { pal_trap(); }
    zT_199[k2] = zT_198;
    zT_202 = 32;
    zT_205 = zT_202 < (unsigned int)(64);
    if (!(zT_205)) { pal_trap(); }
    zT_203 = s >> zT_202;
    carry = zT_203;
    if ((unsigned char)(carry == (zT_79FAE712_u64)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_51:
    zT_209 = 1;
    zT_210 = (unsigned int)zT_209;
    zT_211 = zig_wrap_add_u(((zu64)(k2)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_add_u(((zu64)(k2)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    k2 = zT_211;
    goto z_bb_48;
    z_bb_52:
    zT_208 = 8;
    k2 = zT_208;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    return (unsigned char)(0);
    z_bb_55:
    out->len = (unsigned char)(8);
    zT_219 = out;
    zF_390E9E58_ciNormalize(zT_219);
    goto z_bb_47;
    z_bb_56:
    out->neg = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_45;
}

/* comptimeEvalBinOp */
zT_7534F824_Opt_223 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7534F824_Opt_223 zT_14;
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_7534F824_Opt_223 zT_20;
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_7534F824_Opt_223 zT_32;
    unsigned int zT_34;
    zT_DA663F79_ComptimeEval* zT_36;
    unsigned int zT_37;
    zT_BAEE192E_Opt_10 zT_39;
    zT_DA663F79_ComptimeEval* zT_41;
    unsigned int zT_42;
    zT_BAEE192E_Opt_10 zT_44;
    unsigned char zT_45;
    unsigned char zT_47;
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_53;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_0163D9A4_ComptimeInt zT_60;
    unsigned int zT_61;
    zT_0163D9A4_ComptimeInt zT_63;
    unsigned char zT_64;
    zT_7534F824_Opt_223 zT_66;
    unsigned char zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_0163D9A4_ComptimeInt zT_70;
    unsigned int zT_71;
    zT_0163D9A4_ComptimeInt zT_73;
    unsigned char zT_74;
    zT_7534F824_Opt_223 zT_76;
    zT_0163D9A4_ComptimeInt zT_78;
    zT_0163D9A4_ComptimeInt zT_82;
    zT_0163D9A4_ComptimeInt zT_83;
    zT_0163D9A4_ComptimeInt* zT_84;
    zT_0163D9A4_ComptimeInt zT_85;
    zT_0163D9A4_ComptimeInt zT_86;
    unsigned char zT_88;
    zT_7534F824_Opt_223 zT_90;
    zT_0163D9A4_ComptimeInt zT_94;
    zT_0163D9A4_ComptimeInt zT_95;
    zT_0163D9A4_ComptimeInt* zT_96;
    zT_0163D9A4_ComptimeInt zT_97;
    zT_0163D9A4_ComptimeInt zT_98;
    unsigned char zT_100;
    zT_7534F824_Opt_223 zT_102;
    zT_0163D9A4_ComptimeInt zT_106;
    zT_0163D9A4_ComptimeInt zT_107;
    zT_0163D9A4_ComptimeInt* zT_108;
    zT_0163D9A4_ComptimeInt zT_109;
    zT_0163D9A4_ComptimeInt zT_110;
    unsigned char zT_112;
    zT_7534F824_Opt_223 zT_114;
    zT_0163D9A4_ComptimeInt zT_119;
    zT_0163D9A4_ComptimeInt zT_120;
    zT_0163D9A4_ComptimeInt zT_121;
    zT_0163D9A4_ComptimeInt* zT_122;
    zT_0163D9A4_ComptimeInt* zT_123;
    zT_0163D9A4_ComptimeInt zT_124;
    zT_0163D9A4_ComptimeInt zT_125;
    unsigned char zT_128;
    zT_7534F824_Opt_223 zT_130;
    zT_0163D9A4_ComptimeInt zT_135;
    zT_0163D9A4_ComptimeInt zT_136;
    zT_0163D9A4_ComptimeInt zT_137;
    zT_0163D9A4_ComptimeInt* zT_138;
    zT_0163D9A4_ComptimeInt* zT_139;
    zT_0163D9A4_ComptimeInt zT_140;
    zT_0163D9A4_ComptimeInt zT_141;
    unsigned char zT_144;
    zT_7534F824_Opt_223 zT_146;
    zT_0163D9A4_ComptimeInt zT_150;
    zT_0163D9A4_ComptimeInt zT_151;
    zT_0163D9A4_ComptimeInt* zT_152;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    unsigned char zT_156;
    zT_7534F824_Opt_223 zT_158;
    zT_0163D9A4_ComptimeInt zT_162;
    zT_0163D9A4_ComptimeInt zT_163;
    zT_0163D9A4_ComptimeInt* zT_164;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    unsigned char zT_168;
    zT_7534F824_Opt_223 zT_170;
    zT_0163D9A4_ComptimeInt zT_174;
    zT_0163D9A4_ComptimeInt zT_175;
    zT_0163D9A4_ComptimeInt* zT_176;
    zT_0163D9A4_ComptimeInt zT_177;
    zT_0163D9A4_ComptimeInt zT_178;
    unsigned char zT_180;
    zT_7534F824_Opt_223 zT_182;
    zT_0163D9A4_ComptimeInt zT_186;
    zT_0163D9A4_ComptimeInt zT_187;
    zT_0163D9A4_ComptimeInt* zT_188;
    zT_0163D9A4_ComptimeInt zT_189;
    zT_0163D9A4_ComptimeInt zT_190;
    unsigned char zT_192;
    zT_7534F824_Opt_223 zT_194;
    zT_0163D9A4_ComptimeInt zT_198;
    zT_0163D9A4_ComptimeInt zT_199;
    zT_0163D9A4_ComptimeInt* zT_200;
    zT_0163D9A4_ComptimeInt zT_201;
    zT_0163D9A4_ComptimeInt zT_202;
    unsigned char zT_204;
    zT_7534F824_Opt_223 zT_206;
    zT_7534F824_Opt_223 zT_207;
    zT_338B7C76_TypeRegistry* zT_210;
    zT_0163D9A4_ComptimeInt zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    zT_7534F824_Opt_223 zT_216;
    zT_0163D9A4_ComptimeInt zT_217;
    zT_89B1DDDA_ComptimeVal zT_218;
    zT_7534F824_Opt_223 zT_219;
    zT_7534F824_Opt_223 zT_220;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_114, (unsigned int)sizeof zT_114);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_128, (unsigned int)sizeof zT_128);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    zig_poison_fill((void*)&zT_144, (unsigned int)sizeof zT_144);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_156, (unsigned int)sizeof zT_156);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_170, (unsigned int)sizeof zT_170);
    zig_poison_fill((void*)&zT_180, (unsigned int)sizeof zT_180);
    zig_poison_fill((void*)&zT_182, (unsigned int)sizeof zT_182);
    zig_poison_fill((void*)&zT_192, (unsigned int)sizeof zT_192);
    zig_poison_fill((void*)&zT_194, (unsigned int)sizeof zT_194);
    zig_poison_fill((void*)&zT_204, (unsigned int)sizeof zT_204);
    zig_poison_fill((void*)&zT_206, (unsigned int)sizeof zT_206);
    zig_poison_fill((void*)&zT_207, (unsigned int)sizeof zT_207);
    zig_poison_fill((void*)&zT_214, (unsigned int)sizeof zT_214);
    zig_poison_fill((void*)&zT_216, (unsigned int)sizeof zT_216);
    zig_poison_fill((void*)&zT_218, (unsigned int)sizeof zT_218);
    zig_poison_fill((void*)&zT_220, (unsigned int)sizeof zT_220);
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 lhs;
    zT_7534F824_Opt_223 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    unsigned int peer_tid;
    zT_BAEE192E_Opt_10 lt;
    zT_BAEE192E_Opt_10 rt;
    unsigned int lti;
    unsigned int rti;
    unsigned int rti2;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q2;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(lhs.has_value)) { pal_trap(); }
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_220.has_value = 0;
    return zT_220;
    z_bb_3:
    if (!(rhs.has_value)) { pal_trap(); }
    r = rhs.value;
    zT_25 = l.kind;
    if ((unsigned char)(zT_25 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.kind;
    zT_28 = zT_29 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_9:
    zT_34 = 0;
    peer_tid = zT_34;
    zT_36 = self;
    zT_37 = node.child_0;
    zT_39 = zF_6B810D4A_comptimeEvalOperand(zT_36, zT_37);
    lt = zT_39;
    zT_41 = self;
    zT_42 = node.child_1;
    zT_44 = zF_6B810D4A_comptimeEvalOperand(zT_41, zT_42);
    rt = zT_44;
    zT_45 = lt.has_value;
    if (zT_45) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    if (!(lt.has_value)) { pal_trap(); }
    lti = lt.value;
    zT_47 = rt.has_value;
    if (zT_47) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    if ((unsigned char)(peer_tid != (unsigned int)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_12:
    zT_53 = rt.has_value;
    if (zT_53) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    if (!(rt.has_value)) { pal_trap(); }
    rti = rt.value;
    zT_49 = self;
    zT_50 = lti;
    zT_51 = rti;
    zT_52 = zF_CE5A812D_comptimeEvalWiderIn(zT_49, zT_50, zT_51);
    peer_tid = zT_52;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    peer_tid = lti;
    goto z_bb_14;
    z_bb_16:
    if (!(rt.has_value)) { pal_trap(); }
    rti2 = rt.value;
    peer_tid = rti2;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_11;
    z_bb_18:
    zT_57 = lt.has_value;
    if ((unsigned char)(!zT_57)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_78 = zF_DC9B7BC0_ciZeroInt();
    res = zT_78;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_28; else goto z_bb_30;
    z_bb_20:
    zT_59 = self->registry;
    zT_63 = l.v;
    zT_60 = zT_63;
    zT_61 = peer_tid;
    zT_64 = zF_B28C4720_comptimeIntFitsType(zT_59, zT_60, zT_61);
    if ((unsigned char)(!zT_64)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_67 = rt.has_value;
    if ((unsigned char)(!zT_67)) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_69 = self->registry;
    zT_73 = r.v;
    zT_70 = zT_73;
    zT_71 = peer_tid;
    zT_74 = zF_B28C4720_comptimeIntFitsType(zT_69, zT_70, zT_71);
    if ((unsigned char)(!zT_74)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_19;
    z_bb_26:
    zT_76.has_value = 0;
    return zT_76;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_85 = l.v;
    zT_82 = zT_85;
    zT_86 = r.v;
    zT_83 = zT_86;
    zT_84 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_88 = zF_8A5DB878_ciAdd(zT_82, zT_83, zT_84);
    if ((unsigned char)(!zT_88)) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    if ((unsigned char)(peer_tid != (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_30:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_33; else goto z_bb_35;
    z_bb_31:
    zT_90.has_value = 0;
    return zT_90;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_97 = l.v;
    zT_94 = zT_97;
    zT_98 = r.v;
    zT_95 = zT_98;
    zT_96 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_100 = zF_539A2D81_ciSub(zT_94, zT_95, zT_96);
    if ((unsigned char)(!zT_100)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_29;
    z_bb_35:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_38; else goto z_bb_40;
    z_bb_36:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_109 = l.v;
    zT_106 = zT_109;
    zT_110 = r.v;
    zT_107 = zT_110;
    zT_108 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_112 = zF_A3E385DD_ciMul(zT_106, zT_107, zT_108);
    if ((unsigned char)(!zT_112)) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_34;
    z_bb_40:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_43; else goto z_bb_45;
    z_bb_41:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_119 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_119;
    zT_124 = l.v;
    zT_120 = zT_124;
    zT_125 = r.v;
    zT_121 = zT_125;
    zT_122 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_123 = (zT_0163D9A4_ComptimeInt*)&rem;
    zT_128 = zF_25A0EEC0_ciDivMod(zT_120, zT_121, zT_122, zT_123);
    if ((unsigned char)(!zT_128)) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_39;
    z_bb_45:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_48; else goto z_bb_50;
    z_bb_46:
    zT_130.has_value = 0;
    return zT_130;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_135 = zF_DC9B7BC0_ciZeroInt();
    q2 = zT_135;
    zT_140 = l.v;
    zT_136 = zT_140;
    zT_141 = r.v;
    zT_137 = zT_141;
    zT_138 = (zT_0163D9A4_ComptimeInt*)&q2;
    zT_139 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_144 = zF_25A0EEC0_ciDivMod(zT_136, zT_137, zT_138, zT_139);
    if ((unsigned char)(!zT_144)) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_44;
    z_bb_50:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_53; else goto z_bb_55;
    z_bb_51:
    zT_146.has_value = 0;
    return zT_146;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_153 = l.v;
    zT_150 = zT_153;
    zT_154 = r.v;
    zT_151 = zT_154;
    zT_152 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_156 = zF_E15DE14D_ciBitAnd(zT_150, zT_151, zT_152);
    if ((unsigned char)(!zT_156)) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    goto z_bb_49;
    z_bb_55:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_58; else goto z_bb_60;
    z_bb_56:
    zT_158.has_value = 0;
    return zT_158;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_165 = l.v;
    zT_162 = zT_165;
    zT_166 = r.v;
    zT_163 = zT_166;
    zT_164 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_168 = zF_93823331_ciBitOr(zT_162, zT_163, zT_164);
    if ((unsigned char)(!zT_168)) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_54;
    z_bb_60:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_63; else goto z_bb_65;
    z_bb_61:
    zT_170.has_value = 0;
    return zT_170;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    zT_177 = l.v;
    zT_174 = zT_177;
    zT_178 = r.v;
    zT_175 = zT_178;
    zT_176 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_180 = zF_C592CA21_ciBitXor(zT_174, zT_175, zT_176);
    if ((unsigned char)(!zT_180)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_59;
    z_bb_65:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_68; else goto z_bb_70;
    z_bb_66:
    zT_182.has_value = 0;
    return zT_182;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_189 = l.v;
    zT_186 = zT_189;
    zT_190 = r.v;
    zT_187 = zT_190;
    zT_188 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_192 = zF_4FDD0D22_ciShl(zT_186, zT_187, zT_188);
    if ((unsigned char)(!zT_192)) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    goto z_bb_64;
    z_bb_70:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr))) goto z_bb_73; else goto z_bb_75;
    z_bb_71:
    zT_194.has_value = 0;
    return zT_194;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_201 = l.v;
    zT_198 = zT_201;
    zT_202 = r.v;
    zT_199 = zT_202;
    zT_200 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_204 = zF_41DCF718_ciShr(zT_198, zT_199, zT_200);
    if ((unsigned char)(!zT_204)) goto z_bb_76; else goto z_bb_77;
    z_bb_74:
    goto z_bb_69;
    z_bb_75:
    zT_207.has_value = 0;
    return zT_207;
    z_bb_76:
    zT_206.has_value = 0;
    return zT_206;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_210 = self->registry;
    zT_211 = res;
    zT_212 = peer_tid;
    zT_214 = zF_B28C4720_comptimeIntFitsType(zT_210, zT_211, zT_212);
    if ((unsigned char)(!zT_214)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_217 = res;
    zT_218 = zF_237A4571_ciIntVal(zT_217);
    zT_219.has_value = 1;
    zT_219.value = zT_218;
    return zT_219;
    z_bb_80:
    zT_216.has_value = 0;
    return zT_216;
    z_bb_81:
    goto z_bb_79;
}

/* comptimeEvalCompare */
zT_7534F824_Opt_223 zF_CD4BD838_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7534F824_Opt_223 zT_14;
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_7534F824_Opt_223 zT_20;
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt zT_35;
    zT_0163D9A4_ComptimeInt zT_36;
    int zT_37;
    unsigned char zT_39;
    unsigned char zT_44;
    unsigned char zT_49;
    unsigned char zT_54;
    unsigned char zT_59;
    unsigned char zT_64;
    unsigned char zT_69;
    unsigned char zT_70;
    zT_89B1DDDA_ComptimeVal zT_71;
    zT_7534F824_Opt_223 zT_72;
    zT_DA663F79_ComptimeEval* zT_73;
    unsigned int zT_74;
    zT_8143F551_AstKind zT_75;
    unsigned int zT_76;
    zT_7534F824_Opt_223 zT_77;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_77, (unsigned int)sizeof zT_77);
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 lhs;
    zT_7534F824_Opt_223 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    int c;
    unsigned char res;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(lhs.has_value)) { pal_trap(); }
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_73 = self;
    zT_74 = node_idx;
    zT_75 = op_kind;
    zT_76 = depth;
    zT_77 = zF_2B224602_comptimeEvalCompare(zT_73, zT_74, zT_75, zT_76);
    return zT_77;
    z_bb_3:
    if (!(rhs.has_value)) { pal_trap(); }
    r = rhs.value;
    zT_25 = l.kind;
    if ((unsigned char)(zT_25 != (unsigned int)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.kind;
    zT_28 = zT_29 != (unsigned int)(2);
    goto z_bb_7;
    z_bb_6:
    zT_28 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = l.v;
    zT_33 = zT_35;
    zT_36 = r.v;
    zT_34 = zT_36;
    zT_37 = zF_6408F093_ciCmp(zT_33, zT_34);
    c = zT_37;
    zT_39 = 0;
    res = zT_39;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_44 = c == (int)(0);
    res = zT_44;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = c != (int)(0);
    res = zT_49;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = c < (int)(0);
    res = zT_54;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_59 = c <= (int)(0);
    res = zT_59;
    goto z_bb_17;
    z_bb_17:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_64 = c > (int)(0);
    res = zT_64;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_69 = c >= (int)(0);
    res = zT_69;
    goto z_bb_21;
    z_bb_21:
    zT_70 = res;
    zT_71 = zF_E867E750_ciBoolVal(zT_70);
    zT_72.has_value = 1;
    zT_72.value = zT_71;
    return zT_72;
}

/* comptimeEvalCompareFloat */
zT_7534F824_Opt_223 zF_2B224602_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7134F1D8_Opt_227 zT_14;
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_7134F1D8_Opt_227 zT_20;
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_27;
    unsigned char zT_28;
    zT_7534F824_Opt_223 zT_30;
    unsigned char zT_31;
    unsigned char zT_33;
    unsigned char zT_34;
    zT_7534F824_Opt_223 zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    zT_7534F824_Opt_223 zT_40;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned char zT_49;
    unsigned int zT_50;
    unsigned char zT_54;
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned char zT_59;
    unsigned char zT_60;
    unsigned char zT_61;
    unsigned int zT_62;
    unsigned char zT_65;
    unsigned char zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    zT_7534F824_Opt_223 zT_73;
    unsigned char zT_74;
    unsigned char zT_76;
    unsigned int zT_77;
    zT_7534F824_Opt_223 zT_80;
    unsigned char zT_81;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned char zT_86;
    zT_00435AEB_f64 zT_87;
    unsigned char zT_89;
    zT_7534F824_Opt_223 zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    unsigned int zT_94;
    unsigned char zT_97;
    zT_00435AEB_f64 zT_98;
    unsigned char zT_100;
    zT_7534F824_Opt_223 zT_102;
    unsigned char zT_103;
    unsigned char zT_105;
    unsigned int zT_106;
    zT_7534F824_Opt_223 zT_109;
    unsigned char zT_110;
    unsigned char zT_112;
    unsigned int zT_113;
    zT_7534F824_Opt_223 zT_116;
    zT_00435AEB_f64 zT_118;
    zT_00435AEB_f64 zT_120;
    unsigned char zT_122;
    unsigned char zT_126;
    unsigned char zT_130;
    unsigned char zT_134;
    unsigned char zT_138;
    unsigned char zT_142;
    unsigned char zT_146;
    unsigned char zT_147;
    zT_89B1DDDA_ComptimeVal zT_148;
    zT_7534F824_Opt_223 zT_149;
    zT_7534F824_Opt_223 zT_150;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zT_22A7C88B_AstNode node;
    zT_7134F1D8_Opt_227 lop;
    zT_7134F1D8_Opt_227 rop;
    zT_FCC4E7FC_CmpFloatOperand l;
    zT_FCC4E7FC_CmpFloatOperand r;
    unsigned char has_f64;
    unsigned char has_f32;
    zT_00435AEB_f64 lv;
    zT_00435AEB_f64 rv;
    unsigned char res;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_9324B6D5_comptimeEvalCompare(zT_10, zT_11, zT_12);
    lop = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_9324B6D5_comptimeEvalCompare(zT_16, zT_17, zT_18);
    rop = zT_20;
    zT_21 = lop.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(lop.has_value)) { pal_trap(); }
    l = lop.value;
    zT_23 = rop.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_150.has_value = 0;
    return zT_150;
    z_bb_3:
    if (!(rop.has_value)) { pal_trap(); }
    r = rop.value;
    zT_25 = l.ok;
    if ((unsigned char)(!zT_25)) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_28 = r.ok;
    zT_27 = !zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_27 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30.has_value = 0;
    return zT_30;
    z_bb_9:
    zT_31 = l.is_float;
    if ((unsigned char)(!zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = r.is_float;
    zT_33 = !zT_34;
    goto z_bb_12;
    z_bb_11:
    zT_33 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_33) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36.has_value = 0;
    return zT_36;
    z_bb_14:
    zT_37 = l.is_bool;
    if (zT_37) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_38 = r.is_bool;
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_19:
    zT_42 = l.is_float;
    if (zT_42) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_44 = l.ftype;
    zT_43 = zT_44 == (unsigned int)(16);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_48 = r.is_float;
    if (zT_48) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    zT_47 = 1;
    goto z_bb_25;
    z_bb_25:
    has_f64 = zT_47;
    zT_54 = l.is_float;
    if (zT_54) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_50 = r.ftype;
    zT_49 = zT_50 == (unsigned int)(16);
    goto z_bb_28;
    z_bb_27:
    zT_49 = 0;
    goto z_bb_28;
    z_bb_28:
    zT_47 = zT_49;
    goto z_bb_25;
    z_bb_29:
    zT_56 = l.ftype;
    zT_55 = zT_56 == (unsigned int)(15);
    goto z_bb_31;
    z_bb_30:
    zT_55 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_55) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_60 = r.is_float;
    if (zT_60) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    zT_59 = 1;
    goto z_bb_34;
    z_bb_34:
    has_f32 = zT_59;
    if (has_f64) goto z_bb_39; else goto z_bb_38;
    z_bb_35:
    zT_62 = r.ftype;
    zT_61 = zT_62 == (unsigned int)(15);
    goto z_bb_37;
    z_bb_36:
    zT_61 = 0;
    goto z_bb_37;
    z_bb_37:
    zT_59 = zT_61;
    goto z_bb_34;
    z_bb_38:
    zT_65 = !has_f32;
    goto z_bb_40;
    z_bb_39:
    zT_65 = 1;
    goto z_bb_40;
    z_bb_40:
    if (zT_65) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_67 = l.is_float;
    if ((unsigned char)(!zT_67)) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    zT_118 = l.fval;
    lv = zT_118;
    zT_120 = r.fval;
    rv = zT_120;
    zT_122 = 0;
    res = zT_122;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_80; else goto z_bb_81;
    z_bb_43:
    zT_81 = l.is_float;
    if (zT_81) goto z_bb_54; else goto z_bb_55;
    z_bb_44:
    zT_70 = l.sig_bits;
    zT_69 = zT_70 > (unsigned int)(53);
    goto z_bb_46;
    z_bb_45:
    zT_69 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_69) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_48:
    zT_74 = r.is_float;
    if ((unsigned char)(!zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_77 = r.sig_bits;
    zT_76 = zT_77 > (unsigned int)(53);
    goto z_bb_51;
    z_bb_50:
    zT_76 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_76) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_80.has_value = 0;
    return zT_80;
    z_bb_53:
    goto z_bb_42;
    z_bb_54:
    zT_83 = l.ftype;
    zT_82 = zT_83 == (unsigned int)(0);
    goto z_bb_56;
    z_bb_55:
    zT_82 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_82) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_87 = l.fval;
    zT_89 = zF_173AF805_comptimeEvalF64IsF3(zT_87);
    zT_86 = !zT_89;
    goto z_bb_59;
    z_bb_58:
    zT_86 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_86) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_91.has_value = 0;
    return zT_91;
    z_bb_61:
    zT_92 = r.is_float;
    if (zT_92) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_94 = r.ftype;
    zT_93 = zT_94 == (unsigned int)(0);
    goto z_bb_64;
    z_bb_63:
    zT_93 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_93) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_98 = r.fval;
    zT_100 = zF_173AF805_comptimeEvalF64IsF3(zT_98);
    zT_97 = !zT_100;
    goto z_bb_67;
    z_bb_66:
    zT_97 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_97) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_69:
    zT_103 = l.is_float;
    if ((unsigned char)(!zT_103)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_106 = l.sig_bits;
    zT_105 = zT_106 > (unsigned int)(24);
    goto z_bb_72;
    z_bb_71:
    zT_105 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_105) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_109.has_value = 0;
    return zT_109;
    z_bb_74:
    zT_110 = r.is_float;
    if ((unsigned char)(!zT_110)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_113 = r.sig_bits;
    zT_112 = zT_113 > (unsigned int)(24);
    goto z_bb_77;
    z_bb_76:
    zT_112 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_112) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_116.has_value = 0;
    return zT_116;
    z_bb_79:
    goto z_bb_42;
    z_bb_80:
    zT_126 = lv == rv;
    res = zT_126;
    goto z_bb_81;
    z_bb_81:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_130 = lv != rv;
    res = zT_130;
    goto z_bb_83;
    z_bb_83:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_134 = lv < rv;
    res = zT_134;
    goto z_bb_85;
    z_bb_85:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le))) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_138 = lv <= rv;
    res = zT_138;
    goto z_bb_87;
    z_bb_87:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt))) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_142 = lv > rv;
    res = zT_142;
    goto z_bb_89;
    z_bb_89:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_146 = lv >= rv;
    res = zT_146;
    goto z_bb_91;
    z_bb_91:
    zT_147 = res;
    zT_148 = zF_E867E750_ciBoolVal(zT_147);
    zT_149.has_value = 1;
    zT_149.value = zT_148;
    return zT_149;
}

/* comptimeEvalCompareOperand */
zT_7134F1D8_Opt_227 zF_9324B6D5_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_FCC4E7FC_CmpFloatOperand zT_4;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_00435AEB_f64 zT_9;
    unsigned int zT_10;
    zT_DA663F79_ComptimeEval* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_7534F824_Opt_223 zT_14;
    unsigned char zT_15;
    unsigned char zT_17;
    zT_DA663F79_ComptimeEval* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_89B1DDDA_ComptimeVal zT_25;
    zT_00435AEB_f64 zT_26;
    zT_7134F1D8_Opt_227 zT_27;
    unsigned char zT_28;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    unsigned char zT_35;
    zT_7134F1D8_Opt_227 zT_38;
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    unsigned int zT_42;
    zT_0163D9A4_ComptimeInt zT_43;
    zT_0163D9A4_ComptimeInt zT_44;
    zT_00435AEB_f64 zT_45;
    zT_7134F1D8_Opt_227 zT_46;
    zT_DA663F79_ComptimeEval* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_BCEE1C54_Opt_16 zT_50;
    unsigned char zT_51;
    zT_DA663F79_ComptimeEval* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_7134F1D8_Opt_227 zT_58;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zT_FCC4E7FC_CmpFloatOperand op;
    zT_89B1DDDA_ComptimeVal cv;
    zT_00435AEB_f64 fv;
    zT_5 = 0;
    zT_4.ok = zT_5;
    zT_6 = 0;
    zT_4.is_float = zT_6;
    zT_7 = 0;
    zT_4.is_bool = zT_7;
    zT_8 = 0;
    zT_4.ftype = zT_8;
    zT_9 = 0;
    zT_4.fval = zT_9;
    zT_10 = 0;
    zT_4.sig_bits = zT_10;
    op = zT_4;
    zT_11 = self;
    zT_12 = node_idx;
    zT_13 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_11, zT_12, zT_13);
    zT_15 = zT_14.has_value;
    if (zT_15) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_14.has_value)) { pal_trap(); }
    cv = zT_14.value;
    zT_17 = cv.kind;
    if ((unsigned char)(zT_17 == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_47 = self;
    zT_48 = node_idx;
    zT_49 = depth;
    zT_50 = zF_B719EB81_comptimeEvalFloat(zT_47, zT_48, zT_49);
    zT_51 = zT_50.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    op.ok = (unsigned char)(1);
    op.is_float = (unsigned char)(1);
    zT_22 = self;
    zT_23 = node_idx;
    zT_24 = zF_70E6C6F2_comptimeEvalFloatOp(zT_22, zT_23);
    op.ftype = zT_24;
    zT_25 = cv;
    zT_26 = zF_9DD4606D_comptimeEvalFloatBi(zT_25);
    op.fval = zT_26;
    zT_27.has_value = 1;
    zT_27.value = op;
    return zT_27;
    z_bb_4:
    zT_28 = cv.kind;
    if ((unsigned char)(zT_28 == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    op.ok = (unsigned char)(1);
    op.is_bool = (unsigned char)(1);
    zT_34 = cv.v;
    zT_33 = zT_34;
    zT_35 = zF_0F5FA15F_ciIsZero(zT_33);
    if ((unsigned char)(!zT_35)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    op.ok = (unsigned char)(1);
    zT_41 = cv.v;
    zT_40 = zT_41;
    zT_42 = zF_4372148C_ciSignificantBits(zT_40);
    op.sig_bits = zT_42;
    zT_44 = cv.v;
    zT_43 = zT_44;
    zT_45 = zF_E6CE9168_ciToF64(zT_43);
    op.fval = zT_45;
    zT_46.has_value = 1;
    zT_46.value = op;
    return zT_46;
    z_bb_7:
    op.fval = (zT_00435AEB_f64)(1e+0);
    goto z_bb_8;
    z_bb_8:
    zT_38.has_value = 1;
    zT_38.value = op;
    return zT_38;
    z_bb_9:
    if (!(zT_50.has_value)) { pal_trap(); }
    fv = zT_50.value;
    op.ok = (unsigned char)(1);
    op.is_float = (unsigned char)(1);
    zT_55 = self;
    zT_56 = node_idx;
    zT_57 = zF_70E6C6F2_comptimeEvalFloatOp(zT_55, zT_56);
    op.ftype = zT_57;
    op.fval = fv;
    goto z_bb_10;
    z_bb_10:
    zT_58.has_value = 1;
    zT_58.value = op;
    return zT_58;
}

/* comptimeEvalFloatBits */
zT_00435AEB_f64 zF_9DD4606D_comptimeEvalFloatBi(zT_89B1DDDA_ComptimeVal cv) {
    zT_79FAE712_u64 zT_2;
    zT_79FAE712_u64* zT_4;
    zT_00435AEB_f64* zT_5;
    zT_00435AEB_f64 zT_6;
    zT_79FAE712_u64 fb;
    zT_00435AEB_f64* fp;
    zT_2 = cv.float_bits;
    fb = zT_2;
    zT_4 = (zT_79FAE712_u64*)&fb;
    zT_5 = (zT_00435AEB_f64*)zT_4;
    fp = zT_5;
    zT_6 = *fp;
    return zT_6;
}

/* ciSignificantBits */
unsigned int zF_4372148C_ciSignificantBits(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    unsigned char zT_6;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int* zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    unsigned char zT_77;
    unsigned char zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned char zT_85;
    unsigned int bits;
    unsigned int top;
    unsigned int tz;
    unsigned char i;
    unsigned int limb;
    zT_1 = v.len;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = v.len;
    zT_7 = 1;
    zT_8 = zig_wrap_sub_u(((zu64)(zT_6)), ((zu64)(zT_7)), 8u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(zT_6)), ((zu64)(zT_7)), 8u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_12 = (unsigned int)zT_8;
    zT_13 = 32;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    bits = zT_14;
    zT_19 = v.mag;
    zT_20 = v.len;
    zT_21 = 1;
    zT_22 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 8u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 8u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = (unsigned int)zT_22;
    zT_28 = zT_26 < (unsigned int)(8);
    if (!(zT_28)) { pal_trap(); }
    zT_29 = zT_19[zT_26];
    top = zT_29;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(top != (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_32 = 1;
    zT_33 = zig_wrap_add_u(((zu64)(bits)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_add_u(((zu64)(bits)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    bits = zT_33;
    zT_40 = 1;
    if (!(zT_40)) { pal_trap(); }
    zT_38 = top >> (unsigned int)(1);
    top = zT_38;
    goto z_bb_6;
    z_bb_5:
    zT_42 = 0;
    tz = zT_42;
    zT_44 = 0;
    i = zT_44;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_45 = v.len;
    if ((unsigned char)(i < zT_45)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_48 = v.mag;
    zT_49 = (unsigned int)i;
    zT_51 = zT_49 < (unsigned int)(8);
    if (!(zT_51)) { pal_trap(); }
    zT_52 = zT_48[zT_49];
    limb = zT_52;
    if ((unsigned char)(limb == (unsigned int)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_82 = zig_wrap_sub_u(((zu64)(bits)), ((zu64)(tz)), 32u);
    zT_83 = zig_overflow_flag_sub_u(((zu64)(bits)), ((zu64)(tz)), 32u);
    zT_85 = zT_83 == (unsigned int)(0);
    if (!(zT_85)) { pal_trap(); }
    return zT_82;
    z_bb_10:
    zT_77 = 1;
    zT_78 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_77)), 8u);
    zT_79 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_77)), 8u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    i = zT_78;
    goto z_bb_7;
    z_bb_11:
    zT_55 = 32;
    zT_56 = zig_wrap_add_u(((zu64)(tz)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(tz)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    tz = zT_56;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)((unsigned int)(limb & (unsigned int)(1)) == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_64 = 1;
    zT_65 = zig_wrap_add_u(((zu64)(tz)), ((zu64)(zT_64)), 32u);
    zT_66 = zig_overflow_flag_add_u(((zu64)(tz)), ((zu64)(zT_64)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    tz = zT_65;
    zT_72 = 1;
    if (!(zT_72)) { pal_trap(); }
    zT_70 = limb >> (unsigned int)(1);
    limb = zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_73 = zig_wrap_sub_u(((zu64)(bits)), ((zu64)(tz)), 32u);
    zT_74 = zig_overflow_flag_sub_u(((zu64)(bits)), ((zu64)(tz)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    return zT_73;
    z_bb_17:
    goto z_bb_14;
}

/* comptimeEvalF64IsF32Exact */
unsigned char zF_173AF805_comptimeEvalF64IsF3(zT_00435AEB_f64 x) {
    float zT_2;
    zT_00435AEB_f64 zT_4;
    float x32;
    zT_00435AEB_f64 back;
    zT_2 = (float)x;
    x32 = zT_2;
    zT_4 = (zT_00435AEB_f64)x32;
    back = zT_4;
    return (unsigned char)(back == x);
}

/* comptimeIntF32Exact */
unsigned char zF_60F34F76_comptimeIntF32Exact(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_1;
    unsigned int zT_2;
    zT_00435AEB_f64 zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_00435AEB_f64 zT_8;
    unsigned char zT_9;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_1 = v;
    zT_2 = zF_4372148C_ciSignificantBits(zT_1);
    if ((unsigned char)(zT_2 > (unsigned int)(24))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = v;
    zT_8 = zF_E6CE9168_ciToF64(zT_7);
    zT_6 = zT_8;
    zT_9 = zF_173AF805_comptimeEvalF64IsF3(zT_6);
    return zT_9;
}

/* comptimeEvalFloatOperandType */
unsigned int zF_70E6C6F2_comptimeEvalFloatOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_82243BAB_comptimeEvalFloatOp(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalFloatOperandTypeDepth */
unsigned int zF_82243BAB_comptimeEvalFloatOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_22A7C88B_AstNode zT_18;
    zT_8143F551_AstKind zT_19;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_33;
    zT_8143F551_AstKind zT_34;
    zT_8143F551_AstKind zT_39;
    zT_DA663F79_ComptimeEval* zT_43;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_8143F551_AstKind zT_53;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    zT_9BD83C17_Opt_442 zT_62;
    unsigned char zT_63;
    zT_E2DF2801_LocalConstScope* zT_65;
    unsigned int zT_66;
    zT_BAEE192E_Opt_10 zT_67;
    unsigned char zT_68;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_74;
    unsigned int zT_75;
    zT_DA663F79_ComptimeEval* zT_78;
    unsigned int zT_79;
    zT_BAEE192E_Opt_10 zT_81;
    unsigned char zT_82;
    unsigned char zT_86;
    unsigned int zT_90;
    zT_DA663F79_ComptimeEval* zT_93;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    int zT_105;
    unsigned int zT_106;
    zT_3D7259E2_SymbolRegistry* zT_107;
    unsigned int zT_108;
    zT_3D7259E2_SymbolRegistry* zT_112;
    unsigned int zT_114;
    zT_77F031D4_Opt_960 zT_117;
    unsigned char zT_118;
    unsigned short zT_120;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_22A7C88B_AstNode zT_130;
    unsigned int zT_131;
    zT_DA663F79_ComptimeEval* zT_134;
    unsigned int zT_135;
    zT_BAEE192E_Opt_10 zT_137;
    unsigned char zT_138;
    unsigned char zT_142;
    unsigned int zT_146;
    zT_DA663F79_ComptimeEval* zT_149;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned char zT_157;
    int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned char zT_164;
    zT_8143F551_AstKind zT_166;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned char zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_DA663F79_ComptimeEval* zT_177;
    unsigned int zT_178;
    zT_6B0A7D14_AstStore* zT_179;
    unsigned int zT_180;
    unsigned int zT_184;
    zT_BAEE192E_Opt_10 zT_185;
    unsigned char zT_186;
    unsigned char zT_190;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    zig_poison_fill((void*)&zT_184, (unsigned int)sizeof zT_184);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    unsigned int lt;
    zT_77F031D4_Opt_960 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int t;
    unsigned int t2;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    idx = node_idx;
    zT_11 = 0;
    guard = zT_11;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = self->store;
    zT_16 = idx;
    zT_18 = zF_FCDD1D35_astStoreNodeAt(zT_15, zT_16);
    wn = zT_18;
    zT_19 = wn.kind;
    if ((unsigned char)(zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_30 = self->store;
    zT_31 = idx;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    node = zT_33;
    zT_34 = node.kind;
    if ((unsigned char)(zT_34 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_24 = 1;
    zT_25 = zig_wrap_add_u(((zu64)(guard)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(guard)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    guard = zT_25;
    goto z_bb_5;
    z_bb_9:
    zT_23 = wn.child_0;
    idx = zT_23;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    return (unsigned int)(0);
    z_bb_13:
    zT_39 = node.kind;
    if ((unsigned char)(zT_39 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_43 = self;
    zT_46 = node.child_0;
    zT_47 = 1;
    zT_48 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    self = zT_43;
    node_idx = zT_46;
    depth = zT_48;
    goto z_bb_0;
    z_bb_15:
    zT_53 = node.kind;
    if ((unsigned char)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_58 = self->store;
    zT_59 = idx;
    zT_61 = zF_53458827_astStoreIdentifier(zT_58, zT_59);
    name_id = zT_61;
    zT_62 = self->local_consts;
    zT_63 = zT_62.has_value;
    if (zT_63) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_166 = node.kind;
    if ((unsigned char)(zT_166 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_52; else goto z_bb_53;
    z_bb_18:
    if (!(zT_62.has_value)) { pal_trap(); }
    lcs = zT_62.value;
    zT_65 = lcs;
    zT_66 = name_id;
    zT_67 = zF_6532C387_localConstScopeLook(zT_65, zT_66);
    zT_68 = zT_67.has_value;
    if (zT_68) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_105 = 0;
    zT_106 = (unsigned int)zT_105;
    mi = zT_106;
    goto z_bb_33;
    z_bb_20:
    if (!(zT_67.has_value)) { pal_trap(); }
    l_decl_node = zT_67.value;
    zT_71 = self->store;
    zT_72 = l_decl_node;
    zT_74 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    l_decl = zT_74;
    zT_75 = l_decl.child_0;
    if ((unsigned char)(zT_75 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_78 = self;
    zT_79 = l_decl.child_0;
    zT_81 = zF_BAD6BA5D_comptimeEvalResolve(zT_78, zT_79);
    zT_82 = zT_81.has_value;
    if (zT_82) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_90 = l_decl.child_1;
    if ((unsigned char)(zT_90 != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_24:
    if (!(zT_81.has_value)) { pal_trap(); }
    lt = zT_81.value;
    if ((unsigned char)(lt == (unsigned int)(15))) goto z_bb_27; else goto z_bb_26;
    z_bb_25:
    return (unsigned int)(0);
    z_bb_26:
    zT_86 = lt == (unsigned int)(16);
    goto z_bb_28;
    z_bb_27:
    zT_86 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_86) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return lt;
    z_bb_30:
    goto z_bb_25;
    z_bb_31:
    zT_93 = self;
    zT_96 = l_decl.child_1;
    zT_97 = 1;
    zT_98 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    self = zT_93;
    node_idx = zT_96;
    depth = zT_98;
    goto z_bb_0;
    z_bb_32:
    return (unsigned int)(0);
    z_bb_33:
    zT_107 = self->symbol_reg;
    zT_108 = zT_107->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_108))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_112 = self->symbol_reg;
    zT_114 = name_id;
    zT_117 = zF_A398987E_symbolRegistryQuali(zT_112, (unsigned int)((unsigned int)mi), zT_114);
    c_sym = zT_117;
    zT_118 = c_sym.has_value;
    if (zT_118) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_159 = 1;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_160)), 32u);
    zT_162 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_160)), 32u);
    zT_164 = zT_162 == (unsigned int)(0);
    if (!(zT_164)) { pal_trap(); }
    mi = zT_161;
    goto z_bb_33;
    z_bb_37:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_120 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_120 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_126 = self->store;
    zT_127 = cs->decl_node;
    zT_130 = zF_FCDD1D35_astStoreNodeAt(zT_126, zT_127);
    c_decl = zT_130;
    zT_131 = c_decl.child_0;
    if ((unsigned char)(zT_131 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_134 = self;
    zT_135 = c_decl.child_0;
    zT_137 = zF_BAD6BA5D_comptimeEvalResolve(zT_134, zT_135);
    zT_138 = zT_137.has_value;
    if (zT_138) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_146 = c_decl.child_1;
    if ((unsigned char)(zT_146 != (unsigned int)(0))) goto z_bb_50; else goto z_bb_51;
    z_bb_43:
    if (!(zT_137.has_value)) { pal_trap(); }
    t = zT_137.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_44:
    return (unsigned int)(0);
    z_bb_45:
    zT_142 = t == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_142 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_142) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return t;
    z_bb_49:
    goto z_bb_44;
    z_bb_50:
    zT_149 = self;
    zT_152 = c_decl.child_1;
    zT_153 = 1;
    zT_154 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_153)), 32u);
    zT_155 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_153)), 32u);
    zT_157 = zT_155 == (unsigned int)(0);
    if (!(zT_157)) { pal_trap(); }
    self = zT_149;
    node_idx = zT_152;
    depth = zT_154;
    goto z_bb_0;
    z_bb_51:
    goto z_bb_40;
    z_bb_52:
    zT_170 = node.child_0;
    zT_171 = self->int_to_float_id;
    if ((unsigned char)(zT_170 == zT_171)) goto z_bb_55; else goto z_bb_54;
    z_bb_53:
    return (unsigned int)(0);
    z_bb_54:
    zT_174 = node.child_0;
    zT_175 = self->float_cast_id;
    zT_173 = zT_174 == zT_175;
    goto z_bb_56;
    z_bb_55:
    zT_173 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_173) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_177 = self;
    zT_179 = self->store;
    zT_180 = idx;
    zT_184 = zF_B10B1BC1_astStoreNodeExtraCh(zT_179, zT_180, (unsigned int)(0));
    zT_178 = zT_184;
    zT_185 = zF_BAD6BA5D_comptimeEvalResolve(zT_177, zT_178);
    zT_186 = zT_185.has_value;
    if (zT_186) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    return (unsigned int)(0);
    z_bb_59:
    if (!(zT_185.has_value)) { pal_trap(); }
    t2 = zT_185.value;
    if ((unsigned char)(t2 == (unsigned int)(15))) goto z_bb_62; else goto z_bb_61;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_190 = t2 == (unsigned int)(16);
    goto z_bb_63;
    z_bb_62:
    zT_190 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_190) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return t2;
    z_bb_65:
    goto z_bb_60;
}

/* comptimeEvalLogical */
zT_7534F824_Opt_223 zF_40F99F20_comptimeEvalLogical(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7534F824_Opt_223 zT_14;
    unsigned char zT_18;
    unsigned char zT_20;
    zT_7534F824_Opt_223 zT_23;
    unsigned char zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26;
    unsigned char zT_27;
    zT_89B1DDDA_ComptimeVal zT_28;
    zT_7534F824_Opt_223 zT_29;
    zT_7534F824_Opt_223 zT_30;
    unsigned char zT_34;
    unsigned char zT_36;
    zT_7534F824_Opt_223 zT_39;
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    unsigned char zT_42;
    zT_89B1DDDA_ComptimeVal zT_45;
    zT_7534F824_Opt_223 zT_46;
    zT_DA663F79_ComptimeEval* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_7534F824_Opt_223 zT_52;
    unsigned char zT_53;
    unsigned char zT_55;
    zT_7534F824_Opt_223 zT_58;
    zT_0163D9A4_ComptimeInt zT_60;
    zT_0163D9A4_ComptimeInt zT_61;
    unsigned char zT_62;
    zT_89B1DDDA_ComptimeVal zT_64;
    zT_7534F824_Opt_223 zT_65;
    zT_7534F824_Opt_223 zT_66;
    zT_DA663F79_ComptimeEval* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_7534F824_Opt_223 zT_71;
    unsigned char zT_72;
    unsigned char zT_74;
    zT_7534F824_Opt_223 zT_77;
    zT_0163D9A4_ComptimeInt zT_78;
    zT_0163D9A4_ComptimeInt zT_79;
    unsigned char zT_80;
    zT_89B1DDDA_ComptimeVal zT_83;
    zT_7534F824_Opt_223 zT_84;
    zT_7534F824_Opt_223 zT_85;
    unsigned char zT_89;
    unsigned char zT_91;
    zT_7534F824_Opt_223 zT_94;
    zT_0163D9A4_ComptimeInt zT_95;
    zT_0163D9A4_ComptimeInt zT_96;
    unsigned char zT_97;
    zT_89B1DDDA_ComptimeVal zT_101;
    zT_7534F824_Opt_223 zT_102;
    zT_DA663F79_ComptimeEval* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_7534F824_Opt_223 zT_108;
    unsigned char zT_109;
    unsigned char zT_111;
    zT_7534F824_Opt_223 zT_114;
    zT_0163D9A4_ComptimeInt zT_116;
    zT_0163D9A4_ComptimeInt zT_117;
    unsigned char zT_118;
    zT_89B1DDDA_ComptimeVal zT_120;
    zT_7534F824_Opt_223 zT_121;
    zT_7534F824_Opt_223 zT_122;
    zT_DA663F79_ComptimeEval* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_7534F824_Opt_223 zT_127;
    unsigned char zT_128;
    unsigned char zT_130;
    zT_7534F824_Opt_223 zT_133;
    zT_0163D9A4_ComptimeInt zT_134;
    zT_0163D9A4_ComptimeInt zT_135;
    unsigned char zT_136;
    zT_89B1DDDA_ComptimeVal zT_140;
    zT_7534F824_Opt_223 zT_141;
    zT_7534F824_Opt_223 zT_142;
    zT_7534F824_Opt_223 zT_143;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_77, (unsigned int)sizeof zT_77);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_101, (unsigned int)sizeof zT_101);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_114, (unsigned int)sizeof zT_114);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_120, (unsigned int)sizeof zT_120);
    zig_poison_fill((void*)&zT_122, (unsigned int)sizeof zT_122);
    zig_poison_fill((void*)&zT_127, (unsigned int)sizeof zT_127);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_136, (unsigned int)sizeof zT_136);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_142, (unsigned int)sizeof zT_142);
    zig_poison_fill((void*)&zT_143, (unsigned int)sizeof zT_143);
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 lhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_7534F824_Opt_223 rhs_a;
    zT_89B1DDDA_ComptimeVal ra;
    zT_89B1DDDA_ComptimeVal ra2;
    zT_7534F824_Opt_223 rhs_o;
    zT_89B1DDDA_ComptimeVal ro;
    zT_89B1DDDA_ComptimeVal ro2;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = lhs.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    if (!(lhs.has_value)) { pal_trap(); }
    l = lhs.value;
    zT_20 = l.kind;
    if ((unsigned char)(zT_20 != (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_30.has_value = 0;
    return zT_30;
    z_bb_5:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_6:
    zT_26 = l.v;
    zT_25 = zT_26;
    zT_27 = zF_0F5FA15F_ciIsZero(zT_25);
    zT_24 = zT_27;
    zT_28 = zF_E867E750_ciBoolVal(zT_24);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_7:
    zT_34 = lhs.has_value;
    if (zT_34) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or))) goto z_bb_25; else goto z_bb_26;
    z_bb_9:
    if (!(lhs.has_value)) { pal_trap(); }
    l = lhs.value;
    zT_36 = l.kind;
    if ((unsigned char)(zT_36 != (unsigned int)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_67 = self;
    zT_68 = node.child_1;
    zT_69 = depth;
    zT_71 = zF_4EE17137_comptimeEvalEvaluat(zT_67, zT_68, zT_69);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_19; else goto z_bb_20;
    z_bb_11:
    zT_39.has_value = 0;
    return zT_39;
    z_bb_12:
    zT_41 = l.v;
    zT_40 = zT_41;
    zT_42 = zF_0F5FA15F_ciIsZero(zT_40);
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_46.has_value = 1;
    zT_46.value = zT_45;
    return zT_46;
    z_bb_14:
    zT_48 = self;
    zT_49 = node.child_1;
    zT_50 = depth;
    zT_52 = zF_4EE17137_comptimeEvalEvaluat(zT_48, zT_49, zT_50);
    rhs_a = zT_52;
    zT_53 = rhs_a.has_value;
    if (zT_53) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    if (!(rhs_a.has_value)) { pal_trap(); }
    ra = rhs_a.value;
    zT_55 = ra.kind;
    if ((unsigned char)(zT_55 != (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_17:
    zT_58.has_value = 0;
    return zT_58;
    z_bb_18:
    zT_61 = ra.v;
    zT_60 = zT_61;
    zT_62 = zF_0F5FA15F_ciIsZero(zT_60);
    zT_64 = zF_E867E750_ciBoolVal((unsigned char)(!zT_62));
    zT_65.has_value = 1;
    zT_65.value = zT_64;
    return zT_65;
    z_bb_19:
    if (!(zT_71.has_value)) { pal_trap(); }
    ra2 = zT_71.value;
    zT_74 = ra2.kind;
    if ((unsigned char)(zT_74 != (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_85.has_value = 0;
    return zT_85;
    z_bb_21:
    zT_77.has_value = 0;
    return zT_77;
    z_bb_22:
    zT_79 = ra2.v;
    zT_78 = zT_79;
    zT_80 = zF_0F5FA15F_ciIsZero(zT_78);
    if (zT_80) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_83 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_84.has_value = 1;
    zT_84.value = zT_83;
    return zT_84;
    z_bb_24:
    goto z_bb_20;
    z_bb_25:
    zT_89 = lhs.has_value;
    if (zT_89) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_143.has_value = 0;
    return zT_143;
    z_bb_27:
    if (!(lhs.has_value)) { pal_trap(); }
    l = lhs.value;
    zT_91 = l.kind;
    if ((unsigned char)(zT_91 != (unsigned int)(1))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_123 = self;
    zT_124 = node.child_1;
    zT_125 = depth;
    zT_127 = zF_4EE17137_comptimeEvalEvaluat(zT_123, zT_124, zT_125);
    zT_128 = zT_127.has_value;
    if (zT_128) goto z_bb_37; else goto z_bb_38;
    z_bb_29:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_30:
    zT_96 = l.v;
    zT_95 = zT_96;
    zT_97 = zF_0F5FA15F_ciIsZero(zT_95);
    if ((unsigned char)(!zT_97)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_101 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_102.has_value = 1;
    zT_102.value = zT_101;
    return zT_102;
    z_bb_32:
    zT_104 = self;
    zT_105 = node.child_1;
    zT_106 = depth;
    zT_108 = zF_4EE17137_comptimeEvalEvaluat(zT_104, zT_105, zT_106);
    rhs_o = zT_108;
    zT_109 = rhs_o.has_value;
    if (zT_109) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    if (!(rhs_o.has_value)) { pal_trap(); }
    ro = rhs_o.value;
    zT_111 = ro.kind;
    if ((unsigned char)(zT_111 != (unsigned int)(1))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_122.has_value = 0;
    return zT_122;
    z_bb_35:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_36:
    zT_117 = ro.v;
    zT_116 = zT_117;
    zT_118 = zF_0F5FA15F_ciIsZero(zT_116);
    zT_120 = zF_E867E750_ciBoolVal((unsigned char)(!zT_118));
    zT_121.has_value = 1;
    zT_121.value = zT_120;
    return zT_121;
    z_bb_37:
    if (!(zT_127.has_value)) { pal_trap(); }
    ro2 = zT_127.value;
    zT_130 = ro2.kind;
    if ((unsigned char)(zT_130 != (unsigned int)(1))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_142.has_value = 0;
    return zT_142;
    z_bb_39:
    zT_133.has_value = 0;
    return zT_133;
    z_bb_40:
    zT_135 = ro2.v;
    zT_134 = zT_135;
    zT_136 = zF_0F5FA15F_ciIsZero(zT_134);
    if ((unsigned char)(!zT_136)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_140 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_141.has_value = 1;
    zT_141.value = zT_140;
    return zT_141;
    z_bb_42:
    goto z_bb_38;
}

/* comptimeEvalOperandType */
zT_BAEE192E_Opt_10 zF_6B810D4A_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_F60B0343_comptimeEvalOperand(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalOperandTypeDepth */
zT_BAEE192E_Opt_10 zF_F60B0343_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_5;
    zT_BAEE192E_Opt_10 zT_8;
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35;
    zT_8143F551_AstKind zT_36;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_44;
    zT_9BD83C17_Opt_442 zT_45;
    unsigned char zT_46;
    zT_E2DF2801_LocalConstScope* zT_48;
    unsigned int zT_49;
    zT_BAEE192E_Opt_10 zT_50;
    unsigned char zT_51;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_22A7C88B_AstNode zT_57;
    unsigned int zT_58;
    zT_DA663F79_ComptimeEval* zT_61;
    unsigned int zT_62;
    zT_BAEE192E_Opt_10 zT_64;
    unsigned char zT_65;
    zT_338B7C76_TypeRegistry* zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    zT_BAEE192E_Opt_10 zT_71;
    unsigned int zT_72;
    zT_DA663F79_ComptimeEval* zT_75;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned char zT_83;
    int zT_86;
    unsigned int zT_87;
    zT_3D7259E2_SymbolRegistry* zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_93;
    unsigned int zT_95;
    zT_77F031D4_Opt_960 zT_98;
    unsigned char zT_99;
    unsigned short zT_101;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    zT_22A7C88B_AstNode zT_111;
    unsigned int zT_112;
    zT_DA663F79_ComptimeEval* zT_115;
    unsigned int zT_116;
    zT_BAEE192E_Opt_10 zT_118;
    unsigned char zT_119;
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    zT_BAEE192E_Opt_10 zT_125;
    unsigned int zT_126;
    zT_DA663F79_ComptimeEval* zT_129;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned char zT_137;
    int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_144;
    zT_BAEE192E_Opt_10 zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_DA663F79_ComptimeEval* zT_157;
    unsigned int zT_158;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    unsigned int zT_164;
    zT_BAEE192E_Opt_10 zT_165;
    unsigned char zT_166;
    zT_338B7C76_TypeRegistry* zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    zT_BAEE192E_Opt_10 zT_172;
    zT_BAEE192E_Opt_10 zT_173;
    zT_8143F551_AstKind zT_174;
    unsigned char zT_178;
    zT_8143F551_AstKind zT_179;
    zT_DA663F79_ComptimeEval* zT_183;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned char zT_191;
    zT_8143F551_AstKind zT_193;
    unsigned char zT_197;
    zT_8143F551_AstKind zT_198;
    unsigned char zT_202;
    zT_8143F551_AstKind zT_203;
    unsigned char zT_207;
    zT_8143F551_AstKind zT_208;
    unsigned char zT_212;
    zT_8143F551_AstKind zT_213;
    unsigned char zT_217;
    zT_8143F551_AstKind zT_218;
    unsigned char zT_222;
    zT_8143F551_AstKind zT_223;
    unsigned char zT_227;
    zT_8143F551_AstKind zT_228;
    unsigned char zT_232;
    zT_8143F551_AstKind zT_233;
    unsigned char zT_237;
    zT_8143F551_AstKind zT_238;
    zT_DA663F79_ComptimeEval* zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned char zT_251;
    zT_BAEE192E_Opt_10 zT_252;
    zT_DA663F79_ComptimeEval* zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned char zT_262;
    zT_BAEE192E_Opt_10 zT_263;
    unsigned char zT_264;
    unsigned char zT_266;
    zT_DA663F79_ComptimeEval* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    zT_BAEE192E_Opt_10 zT_272;
    zT_BAEE192E_Opt_10 zT_273;
    zT_BAEE192E_Opt_10 zT_274;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_111, (unsigned int)sizeof zT_111);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_165, (unsigned int)sizeof zT_165);
    zig_poison_fill((void*)&zT_171, (unsigned int)sizeof zT_171);
    zig_poison_fill((void*)&zT_173, (unsigned int)sizeof zT_173);
    zig_poison_fill((void*)&zT_252, (unsigned int)sizeof zT_252);
    zig_poison_fill((void*)&zT_263, (unsigned int)sizeof zT_263);
    zig_poison_fill((void*)&zT_271, (unsigned int)sizeof zT_271);
    zig_poison_fill((void*)&zT_274, (unsigned int)sizeof zT_274);
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    unsigned int lt;
    zT_77F031D4_Opt_960 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int t;
    unsigned int t2;
    zT_BAEE192E_Opt_10 lt_1;
    zT_BAEE192E_Opt_10 rt;
    unsigned int ltv;
    unsigned int rtv;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    idx = node_idx;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    guard = zT_12;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_16 = self->store;
    zT_17 = idx;
    zT_19 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    wn = zT_19;
    zT_20 = wn.kind;
    if ((unsigned char)(zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_32 = self->store;
    zT_33 = idx;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    node = zT_35;
    zT_36 = node.kind;
    if ((unsigned char)(zT_36 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(guard)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(guard)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    guard = zT_27;
    goto z_bb_5;
    z_bb_9:
    zT_24 = wn.child_0;
    idx = zT_24;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    zT_41 = self->store;
    zT_42 = idx;
    zT_44 = zF_53458827_astStoreIdentifier(zT_41, zT_42);
    name_id = zT_44;
    zT_45 = self->local_consts;
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_146 = node.kind;
    if ((unsigned char)(zT_146 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_44; else goto z_bb_45;
    z_bb_14:
    if (!(zT_45.has_value)) { pal_trap(); }
    lcs = zT_45.value;
    zT_48 = lcs;
    zT_49 = name_id;
    zT_50 = zF_6532C387_localConstScopeLook(zT_48, zT_49);
    zT_51 = zT_50.has_value;
    if (zT_51) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_86 = 0;
    zT_87 = (unsigned int)zT_86;
    mi = zT_87;
    goto z_bb_27;
    z_bb_16:
    if (!(zT_50.has_value)) { pal_trap(); }
    l_decl_node = zT_50.value;
    zT_54 = self->store;
    zT_55 = l_decl_node;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    l_decl = zT_57;
    zT_58 = l_decl.child_0;
    if ((unsigned char)(zT_58 != (unsigned int)(0))) goto z_bb_18; else goto z_bb_20;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_61 = self;
    zT_62 = l_decl.child_0;
    zT_64 = zF_BAD6BA5D_comptimeEvalResolve(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    zT_72 = l_decl.child_1;
    if ((unsigned char)(zT_72 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_21:
    if (!(zT_64.has_value)) { pal_trap(); }
    lt = zT_64.value;
    zT_67 = self->registry;
    zT_68 = lt;
    zT_70 = zF_3290E9C4_typeRegistryIsInteg(zT_67, zT_68);
    if (zT_70) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_71.has_value = 1;
    zT_71.value = lt;
    return zT_71;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_75 = self;
    zT_78 = l_decl.child_1;
    zT_79 = 1;
    zT_80 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_79)), 32u);
    zT_81 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_79)), 32u);
    zT_83 = zT_81 == (unsigned int)(0);
    if (!(zT_83)) { pal_trap(); }
    self = zT_75;
    node_idx = zT_78;
    depth = zT_80;
    goto z_bb_0;
    z_bb_26:
    goto z_bb_19;
    z_bb_27:
    zT_88 = self->symbol_reg;
    zT_89 = zT_88->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_89))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_93 = self->symbol_reg;
    zT_95 = name_id;
    zT_98 = zF_A398987E_symbolRegistryQuali(zT_93, (unsigned int)((unsigned int)mi), zT_95);
    c_sym = zT_98;
    zT_99 = c_sym.has_value;
    if (zT_99) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_145.has_value = 0;
    return zT_145;
    z_bb_30:
    zT_139 = 1;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_140)), 32u);
    zT_142 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_140)), 32u);
    zT_144 = zT_142 == (unsigned int)(0);
    if (!(zT_144)) { pal_trap(); }
    mi = zT_141;
    goto z_bb_27;
    z_bb_31:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_101 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_101 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_107 = self->store;
    zT_108 = cs->decl_node;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_107, zT_108);
    c_decl = zT_111;
    zT_112 = c_decl.child_0;
    if ((unsigned char)(zT_112 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_115 = self;
    zT_116 = c_decl.child_0;
    zT_118 = zF_BAD6BA5D_comptimeEvalResolve(zT_115, zT_116);
    zT_119 = zT_118.has_value;
    if (zT_119) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_126 = c_decl.child_1;
    if ((unsigned char)(zT_126 != (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_38:
    if (!(zT_118.has_value)) { pal_trap(); }
    t = zT_118.value;
    zT_121 = self->registry;
    zT_122 = t;
    zT_124 = zF_3290E9C4_typeRegistryIsInteg(zT_121, zT_122);
    if (zT_124) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_125.has_value = 1;
    zT_125.value = t;
    return zT_125;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_129 = self;
    zT_132 = c_decl.child_1;
    zT_133 = 1;
    zT_134 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_133)), 32u);
    zT_135 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_133)), 32u);
    zT_137 = zT_135 == (unsigned int)(0);
    if (!(zT_137)) { pal_trap(); }
    self = zT_129;
    node_idx = zT_132;
    depth = zT_134;
    goto z_bb_0;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_150 = node.child_0;
    zT_151 = self->int_cast_id;
    if ((unsigned char)(zT_150 == zT_151)) goto z_bb_47; else goto z_bb_46;
    z_bb_45:
    zT_174 = node.kind;
    if ((unsigned char)(zT_174 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_56; else goto z_bb_55;
    z_bb_46:
    zT_154 = node.child_0;
    zT_155 = self->as_id;
    zT_153 = zT_154 == zT_155;
    goto z_bb_48;
    z_bb_47:
    zT_153 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_153) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_157 = self;
    zT_159 = self->store;
    zT_160 = idx;
    zT_164 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)(0));
    zT_158 = zT_164;
    zT_165 = zF_BAD6BA5D_comptimeEvalResolve(zT_157, zT_158);
    zT_166 = zT_165.has_value;
    if (zT_166) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_173.has_value = 0;
    return zT_173;
    z_bb_51:
    if (!(zT_165.has_value)) { pal_trap(); }
    t2 = zT_165.value;
    zT_168 = self->registry;
    zT_169 = t2;
    zT_171 = zF_3290E9C4_typeRegistryIsInteg(zT_168, zT_169);
    if (zT_171) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_172.has_value = 1;
    zT_172.value = t2;
    return zT_172;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_179 = node.kind;
    zT_178 = zT_179 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not);
    goto z_bb_57;
    z_bb_56:
    zT_178 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_178) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_183 = self;
    zT_186 = node.child_0;
    zT_187 = 1;
    zT_188 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_187)), 32u);
    zT_189 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_187)), 32u);
    zT_191 = zT_189 == (unsigned int)(0);
    if (!(zT_191)) { pal_trap(); }
    self = zT_183;
    node_idx = zT_186;
    depth = zT_188;
    goto z_bb_0;
    z_bb_59:
    zT_193 = node.kind;
    if ((unsigned char)(zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_198 = node.kind;
    zT_197 = zT_198 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_62;
    z_bb_61:
    zT_197 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_197) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_203 = node.kind;
    zT_202 = zT_203 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_65;
    z_bb_64:
    zT_202 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_202) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_208 = node.kind;
    zT_207 = zT_208 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_68;
    z_bb_67:
    zT_207 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_207) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_213 = node.kind;
    zT_212 = zT_213 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_71;
    z_bb_70:
    zT_212 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_212) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_218 = node.kind;
    zT_217 = zT_218 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_74;
    z_bb_73:
    zT_217 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_217) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_223 = node.kind;
    zT_222 = zT_223 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_77;
    z_bb_76:
    zT_222 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_222) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_228 = node.kind;
    zT_227 = zT_228 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_80;
    z_bb_79:
    zT_227 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_227) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_233 = node.kind;
    zT_232 = zT_233 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_83;
    z_bb_82:
    zT_232 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_232) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_238 = node.kind;
    zT_237 = zT_238 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_86;
    z_bb_85:
    zT_237 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_237) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_243 = self;
    zT_244 = node.child_0;
    zT_247 = 1;
    zT_248 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_247)), 32u);
    zT_249 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_247)), 32u);
    zT_251 = zT_249 == (unsigned int)(0);
    if (!(zT_251)) { pal_trap(); }
    zT_245 = zT_248;
    zT_252 = zF_F60B0343_comptimeEvalOperand(zT_243, zT_244, zT_245);
    lt_1 = zT_252;
    zT_254 = self;
    zT_255 = node.child_1;
    zT_258 = 1;
    zT_259 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_258)), 32u);
    zT_260 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_258)), 32u);
    zT_262 = zT_260 == (unsigned int)(0);
    if (!(zT_262)) { pal_trap(); }
    zT_256 = zT_259;
    zT_263 = zF_F60B0343_comptimeEvalOperand(zT_254, zT_255, zT_256);
    rt = zT_263;
    zT_264 = lt_1.has_value;
    if (zT_264) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_274.has_value = 0;
    return zT_274;
    z_bb_89:
    if (!(lt_1.has_value)) { pal_trap(); }
    ltv = lt_1.value;
    zT_266 = rt.has_value;
    if (zT_266) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    return rt;
    z_bb_91:
    if (!(rt.has_value)) { pal_trap(); }
    rtv = rt.value;
    zT_268 = self;
    zT_269 = ltv;
    zT_270 = rtv;
    zT_271 = zF_CE5A812D_comptimeEvalWiderIn(zT_268, zT_269, zT_270);
    zT_272.has_value = 1;
    zT_272.value = zT_271;
    return zT_272;
    z_bb_92:
    zT_273.has_value = 1;
    zT_273.value = ltv;
    return zT_273;
}

/* comptimeEvalWiderIntType */
unsigned int zF_CE5A812D_comptimeEvalWiderIn(zT_DA663F79_ComptimeEval* self, unsigned int lt, unsigned int rt) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    unsigned char lw;
    unsigned char rw;
    if ((unsigned char)(lt == rt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return lt;
    z_bb_2:
    zT_5 = self->registry;
    zT_6 = lt;
    zT_8 = zF_655972D5_typeRegistryIntWidt(zT_5, zT_6);
    lw = zT_8;
    zT_10 = self->registry;
    zT_11 = rt;
    zT_13 = zF_655972D5_typeRegistryIntWidt(zT_10, zT_11);
    rw = zT_13;
    if ((unsigned char)(lw >= rw)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return lt;
    z_bb_4:
    return rt;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_BAEE192E_Opt_10 zT_4;
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_622E1E76_Opt_254 zT_13;
    zT_9BD83C17_Opt_442 zT_14;
    zT_99D838F1_Opt_444 zT_15;
    zT_ABC1EBBE_TypeResolveEnv* zT_17;
    unsigned int zT_18;
    unsigned int zT_22;
    zT_BAEE192E_Opt_10 zT_25;
    zT_BAEE192E_Opt_10 zT_26;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_11 = self->module_id;
    zT_6.module_id = zT_11;
    zT_12 = 0;
    zT_6.source_file_id = zT_12;
    zT_13.has_value = 0;
    zT_6.diag = zT_13;
    zT_14.has_value = 0;
    zT_6.local_consts = zT_14;
    zT_15.has_value = 0;
    zT_6.local_types = zT_15;
    env = zT_6;
    zT_17 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_18 = node_idx;
    zT_22 = zF_F2107C15_resolveTypeExprFull(zT_17, zT_18, (unsigned int)(0));
    tid = zT_22;
    if ((unsigned char)(tid == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_4:
    zT_26.has_value = 1;
    zT_26.value = tid;
    return zT_26;
}

/* comptimeIntFitsType */
unsigned char zF_B28C4720_comptimeIntFitsType(zT_338B7C76_TypeRegistry* registry, zT_0163D9A4_ComptimeInt v, unsigned int t) {
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_7;
    unsigned int zT_8;
    unsigned char zT_9;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned int zT_16;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt zT_35;
    zT_0163D9A4_ComptimeInt zT_36;
    int zT_37;
    int zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_0163D9A4_ComptimeInt zT_47;
    zT_0163D9A4_ComptimeInt zT_48;
    zT_0163D9A4_ComptimeInt zT_49;
    int zT_50;
    int zT_51;
    unsigned int zT_54;
    zT_0163D9A4_ComptimeInt zT_55;
    zT_0163D9A4_ComptimeInt zT_56;
    zT_0163D9A4_ComptimeInt zT_57;
    int zT_58;
    int zT_59;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    unsigned int wb;
    unsigned char tsig;
    zT_0163D9A4_ComptimeInt lim;
    zT_0163D9A4_ComptimeInt lim2;
    zT_0163D9A4_ComptimeInt lim3;
    zT_4 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)t) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry;
    zT_8 = t;
    zT_9 = zF_3290E9C4_typeRegistryIsInteg(zT_7, zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_13 = registry;
    zT_14 = t;
    zT_15 = zF_655972D5_typeRegistryIntWidt(zT_13, zT_14);
    zT_16 = (unsigned int)zT_15;
    wb = zT_16;
    if ((unsigned char)(wb == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = registry;
    zT_22 = t;
    zT_23 = zF_01ED6537_typeRegistryIntIsSi(zT_21, zT_22);
    tsig = zT_23;
    zT_24 = v.neg;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    if ((unsigned char)(!tsig)) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if (tsig) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_29 = 1;
    zT_30 = zig_wrap_sub_u(((zu64)(wb)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(wb)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_28 = zT_30;
    zT_34 = zF_8F225501_ciPow2(zT_28);
    lim = zT_34;
    zT_35 = v;
    zT_36 = lim;
    zT_37 = zF_0B19E30C_ciMagCmp(zT_35, zT_36);
    zT_38 = 0;
    return (unsigned char)(zT_37 <= zT_38);
    z_bb_11:
    zT_42 = 1;
    zT_43 = zig_wrap_sub_u(((zu64)(wb)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_sub_u(((zu64)(wb)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_41 = zT_43;
    zT_47 = zF_8F225501_ciPow2(zT_41);
    lim2 = zT_47;
    zT_48 = v;
    zT_49 = lim2;
    zT_50 = zF_0B19E30C_ciMagCmp(zT_48, zT_49);
    zT_51 = 0;
    return (unsigned char)(zT_50 < zT_51);
    z_bb_12:
    zT_54 = wb;
    zT_55 = zF_8F225501_ciPow2(zT_54);
    lim3 = zT_55;
    zT_56 = v;
    zT_57 = lim3;
    zT_58 = zF_0B19E30C_ciMagCmp(zT_56, zT_57);
    zT_59 = 0;
    return (unsigned char)(zT_58 < zT_59);
}

/* comptimeIntMaterialize */
zT_79FAE712_u64 zF_FB88E1A5_comptimeIntMaterial(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_1;
    zT_79FAE712_u64 zT_2;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = v;
    zT_2 = zF_4F2C9C5D_ciToU64(zT_1);
    return zT_2;
}

/* comptimeIntFits64 */
unsigned char zF_EF3A264A_comptimeIntFits64(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_5;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    int zT_8;
    int zT_9;
    zT_0163D9A4_ComptimeInt zT_14;
    zT_0163D9A4_ComptimeInt zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    int zT_17;
    int zT_18;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_0163D9A4_ComptimeInt lim;
    zT_0163D9A4_ComptimeInt lim2;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = zF_8F225501_ciPow2((unsigned int)(63));
    lim = zT_5;
    zT_6 = v;
    zT_7 = lim;
    zT_8 = zF_0B19E30C_ciMagCmp(zT_6, zT_7);
    zT_9 = 0;
    return (unsigned char)(zT_8 <= zT_9);
    z_bb_2:
    zT_14 = zF_8F225501_ciPow2((unsigned int)(64));
    lim2 = zT_14;
    zT_15 = v;
    zT_16 = lim2;
    zT_17 = zF_0B19E30C_ciMagCmp(zT_15, zT_16);
    zT_18 = 0;
    return (unsigned char)(zT_17 < zT_18);
}

/* comptimeIntUntypedType */
zT_BAEE192E_Opt_10 zF_42B163B9_comptimeIntUntypedT(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_4;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_12;
    zT_0163D9A4_ComptimeInt zT_16;
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_18;
    zT_0163D9A4_ComptimeInt zT_19;
    int zT_20;
    int zT_21;
    unsigned int zT_23;
    zT_BAEE192E_Opt_10 zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26;
    int zT_27;
    int zT_28;
    unsigned int zT_30;
    zT_BAEE192E_Opt_10 zT_31;
    zT_BAEE192E_Opt_10 zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    int zT_35;
    int zT_36;
    unsigned int zT_38;
    zT_BAEE192E_Opt_10 zT_39;
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    int zT_42;
    int zT_43;
    unsigned int zT_45;
    zT_BAEE192E_Opt_10 zT_46;
    zT_0163D9A4_ComptimeInt zT_47;
    zT_0163D9A4_ComptimeInt zT_48;
    int zT_49;
    int zT_50;
    unsigned int zT_52;
    zT_BAEE192E_Opt_10 zT_53;
    zT_0163D9A4_ComptimeInt zT_54;
    zT_0163D9A4_ComptimeInt zT_55;
    int zT_56;
    int zT_57;
    unsigned int zT_59;
    zT_BAEE192E_Opt_10 zT_60;
    zT_BAEE192E_Opt_10 zT_61;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zT_0163D9A4_ComptimeInt b31;
    zT_0163D9A4_ComptimeInt b32;
    zT_0163D9A4_ComptimeInt b63;
    zT_0163D9A4_ComptimeInt b64;
    zT_4 = zF_8F225501_ciPow2((unsigned int)(31));
    b31 = zT_4;
    zT_8 = zF_8F225501_ciPow2((unsigned int)(32));
    b32 = zT_8;
    zT_12 = zF_8F225501_ciPow2((unsigned int)(63));
    b63 = zT_12;
    zT_16 = zF_8F225501_ciPow2((unsigned int)(64));
    b64 = zT_16;
    zT_17 = v.neg;
    if (zT_17) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = v;
    zT_19 = b31;
    zT_20 = zF_0B19E30C_ciMagCmp(zT_18, zT_19);
    zT_21 = 0;
    if ((unsigned char)(zT_20 <= zT_21)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_33 = v;
    zT_34 = b31;
    zT_35 = zF_0B19E30C_ciMagCmp(zT_33, zT_34);
    zT_36 = 0;
    if ((unsigned char)(zT_35 < zT_36)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_23 = 6;
    zT_24.has_value = 1;
    zT_24.value = zT_23;
    return zT_24;
    z_bb_4:
    zT_25 = v;
    zT_26 = b63;
    zT_27 = zF_0B19E30C_ciMagCmp(zT_25, zT_26);
    zT_28 = 0;
    if ((unsigned char)(zT_27 <= zT_28)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = 7;
    zT_31.has_value = 1;
    zT_31.value = zT_30;
    return zT_31;
    z_bb_6:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_7:
    zT_38 = 6;
    zT_39.has_value = 1;
    zT_39.value = zT_38;
    return zT_39;
    z_bb_8:
    zT_40 = v;
    zT_41 = b32;
    zT_42 = zF_0B19E30C_ciMagCmp(zT_40, zT_41);
    zT_43 = 0;
    if ((unsigned char)(zT_42 < zT_43)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_45 = 10;
    zT_46.has_value = 1;
    zT_46.value = zT_45;
    return zT_46;
    z_bb_10:
    zT_47 = v;
    zT_48 = b63;
    zT_49 = zF_0B19E30C_ciMagCmp(zT_47, zT_48);
    zT_50 = 0;
    if ((unsigned char)(zT_49 < zT_50)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_52 = 7;
    zT_53.has_value = 1;
    zT_53.value = zT_52;
    return zT_53;
    z_bb_12:
    zT_54 = v;
    zT_55 = b64;
    zT_56 = zF_0B19E30C_ciMagCmp(zT_54, zT_55);
    zT_57 = 0;
    if ((unsigned char)(zT_56 < zT_57)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_59 = 11;
    zT_60.has_value = 1;
    zT_60.value = zT_59;
    return zT_60;
    z_bb_14:
    zT_61.has_value = 0;
    return zT_61;
}

/* comptimeValStoreU64 */
zT_BBEE1AC1_Opt_11 zF_E3420380_comptimeValStoreU64(zT_89B1DDDA_ComptimeVal cv) {
    unsigned char zT_1;
    zT_79FAE712_u64 zT_4;
    zT_BBEE1AC1_Opt_11 zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    unsigned char zT_11;
    zT_79FAE712_u64 zT_12;
    zT_BBEE1AC1_Opt_11 zT_13;
    zT_79FAE712_u64 zT_14;
    zT_BBEE1AC1_Opt_11 zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    unsigned char zT_18;
    zT_BBEE1AC1_Opt_11 zT_20;
    zT_0163D9A4_ComptimeInt zT_21;
    zT_0163D9A4_ComptimeInt zT_22;
    zT_79FAE712_u64 zT_23;
    zT_BBEE1AC1_Opt_11 zT_24;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zT_1 = cv.kind;
    if ((unsigned char)(zT_1 == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = cv.float_bits;
    zT_5.has_value = 1;
    zT_5.value = zT_4;
    return zT_5;
    z_bb_2:
    zT_6 = cv.kind;
    if ((unsigned char)(zT_6 == (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = cv.v;
    zT_9 = zT_10;
    zT_11 = zF_0F5FA15F_ciIsZero(zT_9);
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_17 = cv.v;
    zT_16 = zT_17;
    zT_18 = zF_EF3A264A_comptimeIntFits64(zT_16);
    if ((unsigned char)(!zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_12 = 0;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    zT_14 = 1;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
    z_bb_7:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_8:
    zT_22 = cv.v;
    zT_21 = zT_22;
    zT_23 = zF_4F2C9C5D_ciToU64(zT_21);
    zT_24.has_value = 1;
    zT_24.value = zT_23;
    return zT_24;
}

/* comptimeEvalBuiltin */
zT_7534F824_Opt_223 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_7534F824_Opt_223 zT_17;
    zT_DA663F79_ComptimeEval* zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    zT_BAEE192E_Opt_10 zT_27;
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    unsigned char zT_35;
    zT_0163D9A4_ComptimeInt zT_38;
    unsigned int zT_40;
    zT_0163D9A4_ComptimeInt zT_42;
    zT_89B1DDDA_ComptimeVal zT_43;
    zT_7534F824_Opt_223 zT_44;
    zT_7534F824_Opt_223 zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    zT_7534F824_Opt_223 zT_55;
    zT_DA663F79_ComptimeEval* zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_64;
    zT_BAEE192E_Opt_10 zT_65;
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_D155D06D_Type* zT_70;
    unsigned int zT_71;
    zT_D155D06D_Type zT_72;
    unsigned char zT_73;
    zT_0163D9A4_ComptimeInt zT_76;
    unsigned short zT_78;
    zT_0163D9A4_ComptimeInt zT_80;
    zT_89B1DDDA_ComptimeVal zT_81;
    zT_7534F824_Opt_223 zT_82;
    zT_7534F824_Opt_223 zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_DA663F79_ComptimeEval* zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    unsigned int zT_106;
    zT_BAEE192E_Opt_10 zT_107;
    unsigned char zT_108;
    zT_338B7C76_TypeRegistry* zT_111;
    zT_D155D06D_Type* zT_112;
    unsigned int zT_113;
    zT_D155D06D_Type zT_114;
    unsigned char zT_115;
    unsigned char zT_118;
    zT_33EF6BFB_TypeKind zT_119;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_124;
    zT_338B7C76_TypeRegistry* zT_125;
    unsigned int zT_126;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_127;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_131;
    zT_338B7C76_TypeRegistry* zT_133;
    unsigned int zT_134;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_135;
    unsigned char zT_138;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_148;
    zT_22A7C88B_AstNode zT_149;
    zT_8143F551_AstKind zT_150;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_166;
    zT_5138F1F5_anon_324000 zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    int zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    zT_2DF01B61_FieldEntry* zT_177;
    unsigned int zT_178;
    unsigned char zT_179;
    zT_2DF01B61_FieldEntry zT_180;
    unsigned int zT_181;
    zT_2DF01B61_FieldEntry* zT_184;
    unsigned int zT_185;
    unsigned char zT_186;
    zT_2DF01B61_FieldEntry zT_187;
    unsigned int zT_188;
    zT_79FAE712_u64 zT_189;
    zT_79FAE712_u64 zT_191;
    unsigned int zT_193;
    zT_E276DDD0_PackedBitField* zT_195;
    unsigned int zT_196;
    unsigned char zT_197;
    zT_E276DDD0_PackedBitField zT_198;
    unsigned int zT_199;
    zT_79FAE712_u64 zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_79FAE712_u64 zT_204;
    zT_79FAE712_u64 zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_79FAE712_u64 zT_211;
    zT_79FAE712_u64 zT_212;
    unsigned int zT_213;
    unsigned char zT_215;
    zT_0163D9A4_ComptimeInt zT_216;
    zT_79FAE712_u64 zT_217;
    zT_0163D9A4_ComptimeInt zT_218;
    zT_89B1DDDA_ComptimeVal zT_219;
    zT_7534F824_Opt_223 zT_220;
    int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned char zT_226;
    zT_7534F824_Opt_223 zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int zT_235;
    zT_DA663F79_ComptimeEval* zT_239;
    unsigned int zT_240;
    zT_6B0A7D14_AstStore* zT_241;
    unsigned int zT_242;
    unsigned int zT_246;
    zT_BAEE192E_Opt_10 zT_247;
    unsigned char zT_248;
    zT_338B7C76_TypeRegistry* zT_251;
    zT_D155D06D_Type* zT_252;
    unsigned int zT_253;
    zT_D155D06D_Type zT_254;
    unsigned char zT_255;
    unsigned int zT_259;
    zT_79FAE712_u64 zT_260;
    zT_79FAE712_u64 zT_261;
    zT_79FAE712_u64 zT_262;
    unsigned int zT_263;
    unsigned char zT_265;
    zT_33EF6BFB_TypeKind zT_266;
    unsigned char zT_270;
    unsigned char zT_271;
    zT_338B7C76_TypeRegistry* zT_276;
    unsigned int zT_277;
    unsigned int zT_279;
    zT_79FAE712_u64 zT_280;
    zT_33EF6BFB_TypeKind zT_281;
    zT_338B7C76_TypeRegistry* zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    zT_79FAE712_u64 zT_289;
    zT_338B7C76_TypeRegistry* zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    unsigned char zT_297;
    zT_79FAE712_u64 zT_298;
    zT_33EF6BFB_TypeKind zT_299;
    zT_338B7C76_TypeRegistry* zT_304;
    unsigned int zT_305;
    unsigned int zT_307;
    zT_338B7C76_TypeRegistry* zT_308;
    unsigned int zT_309;
    unsigned char zT_311;
    zT_79FAE712_u64 zT_312;
    zT_33EF6BFB_TypeKind zT_313;
    zT_79FAE712_u64 zT_317;
    zT_0163D9A4_ComptimeInt zT_318;
    zT_79FAE712_u64 zT_319;
    zT_0163D9A4_ComptimeInt zT_320;
    zT_89B1DDDA_ComptimeVal zT_321;
    zT_7534F824_Opt_223 zT_322;
    zT_7534F824_Opt_223 zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned char zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    zT_DA663F79_ComptimeEval* zT_332;
    unsigned int zT_333;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_339;
    zT_BAEE192E_Opt_10 zT_340;
    zT_DA663F79_ComptimeEval* zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    zT_6B0A7D14_AstStore* zT_345;
    unsigned int zT_346;
    unsigned int zT_350;
    zT_7534F824_Opt_223 zT_351;
    unsigned char zT_352;
    unsigned char zT_354;
    unsigned char zT_356;
    zT_7534F824_Opt_223 zT_359;
    zT_338B7C76_TypeRegistry* zT_361;
    unsigned int zT_362;
    unsigned char zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned char zT_368;
    zT_7534F824_Opt_223 zT_370;
    unsigned char zT_371;
    zT_338B7C76_TypeRegistry* zT_372;
    zT_0163D9A4_ComptimeInt zT_373;
    unsigned int zT_374;
    zT_0163D9A4_ComptimeInt zT_376;
    unsigned char zT_377;
    zT_622E1E76_Opt_254 zT_379;
    unsigned char zT_380;
    zT_F85C5DED_DiagnosticCollector* zT_382;
    unsigned int zT_383;
    unsigned char zT_384;
    unsigned char* zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned char* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_394;
    zT_F85C5DED_DiagnosticCollector* zT_395;
    unsigned int zT_399;
    unsigned int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned char zT_412;
    unsigned int zT_413;
    zT_7534F824_Opt_223 zT_414;
    zT_338B7C76_TypeRegistry* zT_417;
    zT_D155D06D_Type* zT_418;
    unsigned int zT_419;
    zT_D155D06D_Type zT_420;
    unsigned int zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    unsigned char zT_428;
    int zT_429;
    zT_0163D9A4_ComptimeInt zT_432;
    zT_0163D9A4_ComptimeInt zT_433;
    zT_89B1DDDA_ComptimeVal zT_434;
    zT_7534F824_Opt_223 zT_435;
    zT_0163D9A4_ComptimeInt zT_439;
    zT_0163D9A4_ComptimeInt zT_440;
    zT_79FAE712_u64 zT_441;
    zT_79FAE712_u64 zT_443;
    zT_79FAE712_u64 zT_444;
    zT_79FAE712_u64 zT_445;
    unsigned char zT_447;
    unsigned int zT_448;
    unsigned char zT_450;
    zT_79FAE712_u64 zT_451;
    zT_79FAE712_u64 zT_452;
    unsigned int zT_453;
    unsigned char zT_455;
    zT_79FAE712_u64 zT_456;
    zT_0163D9A4_ComptimeInt zT_457;
    zT_79FAE712_u64 zT_458;
    zT_0163D9A4_ComptimeInt zT_459;
    zT_89B1DDDA_ComptimeVal zT_460;
    zT_7534F824_Opt_223 zT_461;
    zT_7534F824_Opt_223 zT_464;
    zT_7534F824_Opt_223 zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned char zT_469;
    zT_89B1DDDA_ComptimeVal zT_472;
    zT_7534F824_Opt_223 zT_473;
    zT_89B1DDDA_ComptimeVal zT_476;
    zT_7534F824_Opt_223 zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned char zT_481;
    unsigned int zT_482;
    unsigned int zT_483;
    zT_DA663F79_ComptimeEval* zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    zT_BCEE1C54_Opt_16 zT_489;
    unsigned char zT_490;
    zT_00435AEB_f64* zT_494;
    zT_79FAE712_u64* zT_495;
    zT_89B1DDDA_ComptimeVal zT_496;
    zT_0163D9A4_ComptimeInt zT_497;
    unsigned int zT_498;
    zT_79FAE712_u64 zT_499;
    zT_7534F824_Opt_223 zT_500;
    zT_7534F824_Opt_223 zT_501;
    zT_7534F824_Opt_223 zT_502;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_95, (unsigned int)sizeof zT_95);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_107, (unsigned int)sizeof zT_107);
    zig_poison_fill((void*)&zT_138, (unsigned int)sizeof zT_138);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_163, (unsigned int)sizeof zT_163);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_218, (unsigned int)sizeof zT_218);
    zig_poison_fill((void*)&zT_219, (unsigned int)sizeof zT_219);
    zig_poison_fill((void*)&zT_227, (unsigned int)sizeof zT_227);
    zig_poison_fill((void*)&zT_235, (unsigned int)sizeof zT_235);
    zig_poison_fill((void*)&zT_246, (unsigned int)sizeof zT_246);
    zig_poison_fill((void*)&zT_247, (unsigned int)sizeof zT_247);
    zig_poison_fill((void*)&zT_279, (unsigned int)sizeof zT_279);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zig_poison_fill((void*)&zT_293, (unsigned int)sizeof zT_293);
    zig_poison_fill((void*)&zT_297, (unsigned int)sizeof zT_297);
    zig_poison_fill((void*)&zT_307, (unsigned int)sizeof zT_307);
    zig_poison_fill((void*)&zT_311, (unsigned int)sizeof zT_311);
    zig_poison_fill((void*)&zT_320, (unsigned int)sizeof zT_320);
    zig_poison_fill((void*)&zT_321, (unsigned int)sizeof zT_321);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    zig_poison_fill((void*)&zT_339, (unsigned int)sizeof zT_339);
    zig_poison_fill((void*)&zT_340, (unsigned int)sizeof zT_340);
    zig_poison_fill((void*)&zT_350, (unsigned int)sizeof zT_350);
    zig_poison_fill((void*)&zT_351, (unsigned int)sizeof zT_351);
    zig_poison_fill((void*)&zT_359, (unsigned int)sizeof zT_359);
    zig_poison_fill((void*)&zT_364, (unsigned int)sizeof zT_364);
    zig_poison_fill((void*)&zT_370, (unsigned int)sizeof zT_370);
    zig_poison_fill((void*)&zT_377, (unsigned int)sizeof zT_377);
    zig_poison_fill((void*)&zT_384, (unsigned int)sizeof zT_384);
    zig_poison_fill((void*)&zT_413, (unsigned int)sizeof zT_413);
    zig_poison_fill((void*)&zT_414, (unsigned int)sizeof zT_414);
    zig_poison_fill((void*)&zT_432, (unsigned int)sizeof zT_432);
    zig_poison_fill((void*)&zT_434, (unsigned int)sizeof zT_434);
    zig_poison_fill((void*)&zT_441, (unsigned int)sizeof zT_441);
    zig_poison_fill((void*)&zT_459, (unsigned int)sizeof zT_459);
    zig_poison_fill((void*)&zT_460, (unsigned int)sizeof zT_460);
    zig_poison_fill((void*)&zT_465, (unsigned int)sizeof zT_465);
    zig_poison_fill((void*)&zT_472, (unsigned int)sizeof zT_472);
    zig_poison_fill((void*)&zT_476, (unsigned int)sizeof zT_476);
    zig_poison_fill((void*)&zT_489, (unsigned int)sizeof zT_489);
    zig_poison_fill((void*)&zT_497, (unsigned int)sizeof zT_497);
    zig_poison_fill((void*)&zT_501, (unsigned int)sizeof zT_501);
    zig_poison_fill((void*)&zT_502, (unsigned int)sizeof zT_502);
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    unsigned int ec2_n;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    unsigned int ec3_n;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    unsigned int ebt;
    zT_7534F824_Opt_223 inner;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned char is_int_t;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    zT_D155D06D_Type nty;
    unsigned int nwb;
    zT_89B1DDDA_ComptimeVal outv;
    zT_0163D9A4_ComptimeInt zm;
    zT_79FAE712_u64 npat;
    zT_79FAE712_u64 nmask;
    zT_BCEE1C54_Opt_16 fv;
    zT_00435AEB_f64 v;
    zT_00435AEB_f64 fb;
    zT_79FAE712_u64* fbp;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    if ((unsigned char)(zT_8 == zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_152E19CB_astStoreNodeExtraCh(zT_11, zT_12);
    if ((unsigned char)(zT_14 != (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_46 = node.child_0;
    zT_47 = self->align_of_id;
    if ((unsigned char)(zT_46 == zT_47)) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_17.has_value = 0;
    return zT_17;
    z_bb_4:
    zT_19 = self;
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_26 = zF_B10B1BC1_astStoreNodeExtraCh(zT_21, zT_22, (unsigned int)(0));
    zT_20 = zT_26;
    zT_27 = zF_BAD6BA5D_comptimeEvalResolve(zT_19, zT_20);
    tid = zT_27;
    zT_28 = tid.has_value;
    if (zT_28) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)t;
    zT_34 = zT_32[zT_33];
    ty = zT_34;
    zT_35 = ty.state;
    if ((unsigned char)(zT_35 == (unsigned char)(2))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_45.has_value = 0;
    return zT_45;
    z_bb_7:
    zT_40 = ty.size;
    zT_42 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_40));
    zT_38 = zT_42;
    zT_43 = zF_237A4571_ciIntVal(zT_38);
    zT_44.has_value = 1;
    zT_44.value = zT_43;
    return zT_44;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_49 = self->store;
    zT_50 = node_idx;
    zT_52 = zF_152E19CB_astStoreNodeExtraCh(zT_49, zT_50);
    if ((unsigned char)(zT_52 != (unsigned int)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_84 = node.child_0;
    zT_85 = self->offset_of_id;
    if ((unsigned char)(zT_84 == zT_85)) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_55.has_value = 0;
    return zT_55;
    z_bb_12:
    zT_57 = self;
    zT_59 = self->store;
    zT_60 = node_idx;
    zT_64 = zF_B10B1BC1_astStoreNodeExtraCh(zT_59, zT_60, (unsigned int)(0));
    zT_58 = zT_64;
    zT_65 = zF_BAD6BA5D_comptimeEvalResolve(zT_57, zT_58);
    tid = zT_65;
    zT_66 = tid.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    zT_69 = self->registry;
    zT_70 = zT_69->types_items;
    zT_71 = (unsigned int)t;
    zT_72 = zT_70[zT_71];
    ty = zT_72;
    zT_73 = ty.state;
    if ((unsigned char)(zT_73 == (unsigned char)(2))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_83.has_value = 0;
    return zT_83;
    z_bb_15:
    zT_78 = ty.alignment;
    zT_80 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_78));
    zT_76 = zT_80;
    zT_81 = zF_237A4571_ciIntVal(zT_76);
    zT_82.has_value = 1;
    zT_82.value = zT_81;
    return zT_82;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_88 = node.child_0;
    zT_89 = self->bit_offset_of_id;
    zT_87 = zT_88 == zT_89;
    goto z_bb_19;
    z_bb_18:
    zT_87 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_87) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_92 = self->store;
    zT_93 = node_idx;
    zT_95 = zF_152E19CB_astStoreNodeExtraCh(zT_92, zT_93);
    ec2_n = zT_95;
    if ((unsigned char)(ec2_n == (unsigned int)(2))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_228 = node.child_0;
    zT_229 = self->bit_size_of_id;
    if ((unsigned char)(zT_228 == zT_229)) goto z_bb_49; else goto z_bb_50;
    z_bb_22:
    zT_99 = self;
    zT_101 = self->store;
    zT_102 = node_idx;
    zT_106 = zF_B10B1BC1_astStoreNodeExtraCh(zT_101, zT_102, (unsigned int)(0));
    zT_100 = zT_106;
    zT_107 = zF_BAD6BA5D_comptimeEvalResolve(zT_99, zT_100);
    tid = zT_107;
    zT_108 = tid.has_value;
    if (zT_108) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_227.has_value = 0;
    return zT_227;
    z_bb_24:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    zT_111 = self->registry;
    zT_112 = zT_111->types_items;
    zT_113 = (unsigned int)t;
    zT_114 = zT_112[zT_113];
    ty = zT_114;
    zT_115 = ty.state;
    if ((unsigned char)(zT_115 == (unsigned char)(2))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_119 = ty.kind;
    zT_118 = zT_119 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_28;
    z_bb_27:
    zT_118 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_118) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    fields = zT_124;
    zT_125 = self->registry;
    zT_126 = t;
    zT_127 = (zT_BF2E90D8_Slice_zT_2DF01B61_F*)&fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_125, zT_126, zT_127);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    packed_fields = zT_131;
    zT_133 = self->registry;
    zT_134 = t;
    zT_135 = (zT_BCF34E4D_Slice_zT_E276DDD0_P*)&packed_fields;
    zT_138 = zF_7D87247C_typeRegistryGetPack(zT_133, zT_134, zT_135);
    has_pk = zT_138;
    zT_140 = self->store;
    zT_143 = self->store;
    zT_144 = node_idx;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_143, zT_144, (unsigned int)(1));
    zT_141 = zT_148;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_140, zT_141);
    fname_node = zT_149;
    zT_150 = fname_node.kind;
    if ((unsigned char)(zT_150 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_25;
    z_bb_31:
    zT_155 = self->store;
    zT_158 = self->store;
    zT_159 = node_idx;
    zT_163 = zF_B10B1BC1_astStoreNodeExtraCh(zT_158, zT_159, (unsigned int)(1));
    zT_156 = zT_163;
    zT_164 = zF_8BA26B9E_astStoreNodePayload(zT_155, zT_156);
    sv_idx = zT_164;
    zT_166 = self->store;
    zT_167 = zT_166->string_values;
    zT_168 = zT_167.items;
    zT_169 = (unsigned int)sv_idx;
    zT_170 = zT_168[zT_169];
    want_id = zT_170;
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    fi = zT_173;
    goto z_bb_33;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_175 = fields.len;
    if ((unsigned char)(fi < zT_175)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_177 = fields.ptr;
    zT_178 = fields.len;
    zT_179 = fi < zT_178;
    if (!(zT_179)) { pal_trap(); }
    zT_180 = zT_177[fi];
    zT_181 = zT_180.name_id;
    if ((unsigned char)(zT_181 == want_id)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_221 = 1;
    zT_222 = (unsigned int)zT_221;
    zT_223 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_222)), 32u);
    zT_224 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_222)), 32u);
    zT_226 = zT_224 == (unsigned int)(0);
    if (!(zT_226)) { pal_trap(); }
    fi = zT_223;
    goto z_bb_33;
    z_bb_37:
    zT_184 = fields.ptr;
    zT_185 = fields.len;
    zT_186 = fi < zT_185;
    if (!(zT_186)) { pal_trap(); }
    zT_187 = zT_184[fi];
    zT_188 = zT_187.offset;
    zT_189 = (zT_79FAE712_u64)zT_188;
    bo = zT_189;
    if (has_pk) goto z_bb_39; else goto z_bb_41;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_191 = 0;
    pk_bo = zT_191;
    zT_193 = packed_fields.len;
    if ((unsigned char)(fi < zT_193)) goto z_bb_42; else goto z_bb_43;
    z_bb_40:
    zT_217 = bo;
    zT_218 = zF_1EAA44E6_ciFromU64(zT_217);
    zT_216 = zT_218;
    zT_219 = zF_237A4571_ciIntVal(zT_216);
    zT_220.has_value = 1;
    zT_220.value = zT_219;
    return zT_220;
    z_bb_41:
    zT_208 = node.child_0;
    zT_209 = self->bit_offset_of_id;
    if ((unsigned char)(zT_208 == zT_209)) goto z_bb_47; else goto z_bb_48;
    z_bb_42:
    zT_195 = packed_fields.ptr;
    zT_196 = packed_fields.len;
    zT_197 = fi < zT_196;
    if (!(zT_197)) { pal_trap(); }
    zT_198 = zT_195[fi];
    zT_199 = zT_198.bit_offset;
    zT_200 = (zT_79FAE712_u64)zT_199;
    pk_bo = zT_200;
    goto z_bb_43;
    z_bb_43:
    zT_201 = node.child_0;
    zT_202 = self->bit_offset_of_id;
    if ((unsigned char)(zT_201 == zT_202)) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    bo = pk_bo;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_40;
    z_bb_46:
    zT_204 = 8;
    zT_207 = zT_204 != (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    zT_205 = pk_bo / zT_204;
    bo = zT_205;
    goto z_bb_45;
    z_bb_47:
    zT_211 = 8;
    zT_212 = zig_wrap_mul_u(((zu64)(bo)), ((zu64)(zT_211)), 64u);
    zT_213 = zig_overflow_flag_mul_u(((zu64)(bo)), ((zu64)(zT_211)), 64u);
    zT_215 = zT_213 == (unsigned int)(0);
    if (!(zT_215)) { pal_trap(); }
    bo = zT_212;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_40;
    z_bb_49:
    zT_232 = self->store;
    zT_233 = node_idx;
    zT_235 = zF_152E19CB_astStoreNodeExtraCh(zT_232, zT_233);
    ec3_n = zT_235;
    if ((unsigned char)(ec3_n >= (unsigned int)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_324 = node.child_0;
    zT_325 = self->int_cast_id;
    if ((unsigned char)(zT_324 == zT_325)) goto z_bb_71; else goto z_bb_70;
    z_bb_51:
    zT_239 = self;
    zT_241 = self->store;
    zT_242 = node_idx;
    zT_246 = zF_B10B1BC1_astStoreNodeExtraCh(zT_241, zT_242, (unsigned int)(0));
    zT_240 = zT_246;
    zT_247 = zF_BAD6BA5D_comptimeEvalResolve(zT_239, zT_240);
    tid2 = zT_247;
    zT_248 = tid2.has_value;
    if (zT_248) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_323.has_value = 0;
    return zT_323;
    z_bb_53:
    if (!(tid2.has_value)) { pal_trap(); }
    t2 = tid2.value;
    zT_251 = self->registry;
    zT_252 = zT_251->types_items;
    zT_253 = (unsigned int)t2;
    zT_254 = zT_252[zT_253];
    ty2 = zT_254;
    zT_255 = ty2.state;
    if ((unsigned char)(zT_255 == (unsigned char)(2))) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_259 = ty2.size;
    zT_260 = (zT_79FAE712_u64)zT_259;
    zT_261 = 8;
    zT_262 = zig_wrap_mul_u(((zu64)(zT_260)), ((zu64)(zT_261)), 64u);
    zT_263 = zig_overflow_flag_mul_u(((zu64)(zT_260)), ((zu64)(zT_261)), 64u);
    zT_265 = zT_263 == (unsigned int)(0);
    if (!(zT_265)) { pal_trap(); }
    bsz = zT_262;
    zT_266 = ty2.kind;
    if ((unsigned char)(zT_266 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    goto z_bb_54;
    z_bb_57:
    zT_271 = ty2.flags;
    zT_270 = (unsigned char)(zT_271 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_59;
    z_bb_58:
    zT_270 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_270) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_276 = self->registry;
    zT_277 = t2;
    zT_279 = zF_CB27DBA4_typeRegistryGetPack(zT_276, zT_277);
    zT_280 = (zT_79FAE712_u64)zT_279;
    bsz = zT_280;
    goto z_bb_61;
    z_bb_61:
    zT_281 = ty2.kind;
    if ((unsigned char)(zT_281 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_285 = self->registry;
    zT_286 = t2;
    zT_288 = zF_B80C4365_typeRegistryGetPack(zT_285, zT_286);
    zT_289 = (zT_79FAE712_u64)zT_288;
    bsz = zT_289;
    goto z_bb_63;
    z_bb_63:
    zT_290 = self->registry;
    zT_291 = t2;
    zT_293 = zF_3290E9C4_typeRegistryIsInteg(zT_290, zT_291);
    if (zT_293) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_294 = self->registry;
    zT_295 = t2;
    zT_297 = zF_655972D5_typeRegistryIntWidt(zT_294, zT_295);
    zT_298 = (zT_79FAE712_u64)zT_297;
    bsz = zT_298;
    goto z_bb_65;
    z_bb_65:
    zT_299 = ty2.kind;
    if ((unsigned char)(zT_299 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_304 = self->registry;
    zT_305 = t2;
    zT_307 = zF_014D7530_typeRegistryEnumBac(zT_304, zT_305);
    ebt = zT_307;
    zT_308 = self->registry;
    zT_309 = ebt;
    zT_311 = zF_655972D5_typeRegistryIntWidt(zT_308, zT_309);
    zT_312 = (zT_79FAE712_u64)zT_311;
    bsz = zT_312;
    goto z_bb_67;
    z_bb_67:
    zT_313 = ty2.kind;
    if ((unsigned char)(zT_313 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_317 = 1;
    bsz = zT_317;
    goto z_bb_69;
    z_bb_69:
    zT_319 = bsz;
    zT_320 = zF_1EAA44E6_ciFromU64(zT_319);
    zT_318 = zT_320;
    zT_321 = zF_237A4571_ciIntVal(zT_318);
    zT_322.has_value = 1;
    zT_322.value = zT_321;
    return zT_322;
    z_bb_70:
    zT_328 = node.child_0;
    zT_329 = self->as_id;
    zT_327 = zT_328 == zT_329;
    goto z_bb_72;
    z_bb_71:
    zT_327 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_327) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_332 = self;
    zT_334 = self->store;
    zT_335 = node_idx;
    zT_339 = zF_B10B1BC1_astStoreNodeExtraCh(zT_334, zT_335, (unsigned int)(0));
    zT_333 = zT_339;
    zT_340 = zF_BAD6BA5D_comptimeEvalResolve(zT_332, zT_333);
    tid = zT_340;
    zT_342 = self;
    zT_345 = self->store;
    zT_346 = node_idx;
    zT_350 = zF_B10B1BC1_astStoreNodeExtraCh(zT_345, zT_346, (unsigned int)(1));
    zT_343 = zT_350;
    zT_344 = depth;
    zT_351 = zF_4EE17137_comptimeEvalEvaluat(zT_342, zT_343, zT_344);
    inner = zT_351;
    zT_352 = tid.has_value;
    if (zT_352) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_466 = node.child_0;
    zT_467 = self->is_windows_id;
    if ((unsigned char)(zT_466 == zT_467)) goto z_bb_103; else goto z_bb_104;
    z_bb_75:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    zT_354 = inner.has_value;
    if (zT_354) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_465.has_value = 0;
    return zT_465;
    z_bb_77:
    if (!(inner.has_value)) { pal_trap(); }
    cv = inner.value;
    zT_356 = cv.kind;
    if ((unsigned char)(zT_356 == (unsigned int)(2))) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    zT_359.has_value = 0;
    return zT_359;
    z_bb_80:
    zT_361 = self->registry;
    zT_362 = t;
    zT_364 = zF_3290E9C4_typeRegistryIsInteg(zT_361, zT_362);
    is_int_t = zT_364;
    zT_365 = node.child_0;
    zT_366 = self->as_id;
    if ((unsigned char)(zT_365 == zT_366)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_368 = !is_int_t;
    goto z_bb_83;
    z_bb_82:
    zT_368 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_368) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_370.has_value = 0;
    return zT_370;
    z_bb_85:
    if (is_int_t) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_372 = self->registry;
    zT_376 = cv.v;
    zT_373 = zT_376;
    zT_374 = t;
    zT_377 = zF_B28C4720_comptimeIntFitsType(zT_372, zT_373, zT_374);
    zT_371 = !zT_377;
    goto z_bb_88;
    z_bb_87:
    zT_371 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_371) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_379 = self->diag;
    zT_380 = zT_379.has_value;
    if (zT_380) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    if ((unsigned char)(!is_int_t)) goto z_bb_97; else goto z_bb_98;
    z_bb_91:
    if (!(zT_379.has_value)) { pal_trap(); }
    dg = zT_379.value;
    zT_382 = dg;
    zT_383 = node_idx;
    zT_384 = zF_4DD9DB2D_diagnosticCollector(zT_382, zT_383);
    if (zT_384) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_414.has_value = 0;
    return zT_414;
    z_bb_93:
    zT_386 = "@intCast value does not fit the target type";
    zT_388 = 43;
    zT_387.ptr = (unsigned char*)zT_386;
    zT_387.len = zT_388;
    ic_msg = zT_387;
    zT_389 = node.child_0;
    zT_390 = self->as_id;
    if ((unsigned char)(zT_389 == zT_390)) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_392 = "@as value does not fit the target type";
    zT_394 = 38;
    zT_393.ptr = (unsigned char*)zT_392;
    zT_393.len = zT_394;
    ic_msg = zT_393;
    goto z_bb_96;
    z_bb_96:
    zT_395 = dg;
    zT_399 = node.span_start;
    zT_406 = node.span_start;
    zT_407 = node.span_len;
    zT_408 = (unsigned int)zT_407;
    zT_409 = zig_wrap_add_u(((zu64)(zT_406)), ((zu64)(zT_408)), 32u);
    zT_410 = zig_overflow_flag_add_u(((zu64)(zT_406)), ((zu64)(zT_408)), 32u);
    zT_412 = zT_410 == (unsigned int)(0);
    if (!(zT_412)) { pal_trap(); }
    zT_400 = zT_409;
    zT_401 = ic_msg;
    zT_413 = zF_C82559AC_diagnosticCollector(zT_395, (unsigned char)(0), (unsigned short)(3000), (unsigned int)(0), zT_399, zT_400, zT_401);
    (void)zT_413;
    goto z_bb_94;
    z_bb_97:
    zT_417 = self->registry;
    zT_418 = zT_417->types_items;
    zT_419 = (unsigned int)t;
    zT_420 = zT_418[zT_419];
    nty = zT_420;
    zT_422 = nty.size;
    zT_423 = (unsigned int)zT_422;
    zT_424 = 8;
    zT_425 = zig_wrap_mul_u(((zu64)(zT_423)), ((zu64)(zT_424)), 32u);
    zT_426 = zig_overflow_flag_mul_u(((zu64)(zT_423)), ((zu64)(zT_424)), 32u);
    zT_428 = zT_426 == (unsigned int)(0);
    if (!(zT_428)) { pal_trap(); }
    nwb = zT_425;
    zT_429 = 0;
    if ((unsigned char)(nwb == (unsigned int)zT_429)) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    outv = cv;
    outv.kind = (unsigned int)(0);
    zT_464.has_value = 1;
    zT_464.value = outv;
    return zT_464;
    z_bb_99:
    zT_432 = zF_DC9B7BC0_ciZeroInt();
    zm = zT_432;
    zT_433 = zm;
    zT_434 = zF_237A4571_ciIntVal(zT_433);
    zT_435.has_value = 1;
    zT_435.value = zT_434;
    return zT_435;
    z_bb_100:
    if ((unsigned char)(nwb < (unsigned int)(64))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_440 = cv.v;
    zT_439 = zT_440;
    zT_441 = zF_4F2C9C5D_ciToU64(zT_439);
    npat = zT_441;
    zT_443 = 1;
    zT_444 = (zT_79FAE712_u64)nwb;
    zT_447 = zT_444 < (unsigned int)(64);
    if (!(zT_447)) { pal_trap(); }
    zT_445 = zig_wrap_shl_u(((zu64)(zT_443)), ((zu64)(zT_444)), 64u);
    zT_448 = zig_overflow_flag_shl_u(((zu64)(zT_443)), ((zu64)(zT_444)), 64u);
    zT_450 = zT_448 == (unsigned int)(0);
    if (!(zT_450)) { pal_trap(); }
    zT_451 = 1;
    zT_452 = zig_wrap_sub_u(((zu64)(zT_445)), ((zu64)(zT_451)), 64u);
    zT_453 = zig_overflow_flag_sub_u(((zu64)(zT_445)), ((zu64)(zT_451)), 64u);
    zT_455 = zT_453 == (unsigned int)(0);
    if (!(zT_455)) { pal_trap(); }
    nmask = zT_452;
    zT_456 = npat & nmask;
    npat = zT_456;
    zT_458 = npat;
    zT_459 = zF_1EAA44E6_ciFromU64(zT_458);
    zT_457 = zT_459;
    zT_460 = zF_237A4571_ciIntVal(zT_457);
    zT_461.has_value = 1;
    zT_461.value = zT_460;
    return zT_461;
    z_bb_102:
    goto z_bb_98;
    z_bb_103:
    zT_469 = self->host_is_windows;
    if (zT_469) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_478 = node.child_0;
    zT_479 = self->int_to_float_id;
    if ((unsigned char)(zT_478 == zT_479)) goto z_bb_108; else goto z_bb_107;
    z_bb_105:
    zT_472 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_473.has_value = 1;
    zT_473.value = zT_472;
    return zT_473;
    z_bb_106:
    zT_476 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_477.has_value = 1;
    zT_477.value = zT_476;
    return zT_477;
    z_bb_107:
    zT_482 = node.child_0;
    zT_483 = self->float_cast_id;
    zT_481 = zT_482 == zT_483;
    goto z_bb_109;
    z_bb_108:
    zT_481 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_481) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_486 = self;
    zT_487 = node_idx;
    zT_488 = depth;
    zT_489 = zF_8C4B1954_comptimeEvalFloatBu(zT_486, zT_487, zT_488);
    fv = zT_489;
    zT_490 = fv.has_value;
    if (zT_490) goto z_bb_112; else goto z_bb_113;
    z_bb_111:
    zT_502.has_value = 0;
    return zT_502;
    z_bb_112:
    if (!(fv.has_value)) { pal_trap(); }
    v = fv.value;
    fb = v;
    zT_494 = (zT_00435AEB_f64*)&fb;
    zT_495 = (zT_79FAE712_u64*)zT_494;
    fbp = zT_495;
    zT_497 = zF_DC9B7BC0_ciZeroInt();
    zT_496.v = zT_497;
    zT_498 = 2;
    zT_496.kind = zT_498;
    zT_499 = *fbp;
    zT_496.float_bits = zT_499;
    zT_500.has_value = 1;
    zT_500.value = zT_496;
    return zT_500;
    z_bb_113:
    zT_501.has_value = 0;
    return zT_501;
}

/* comptimeEvalFloat */
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BCEE1C54_Opt_16 zT_5;
    zT_BCEE1C54_Opt_16 zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    zT_E494E487_anon_323991 zT_19;
    zT_00435AEB_f64* zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_00435AEB_f64 zT_26;
    zT_BCEE1C54_Opt_16 zT_27;
    zT_8143F551_AstKind zT_28;
    zT_DA663F79_ComptimeEval* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zT_BCEE1C54_Opt_16 zT_42;
    unsigned char zT_43;
    zT_00435AEB_f64 zT_45;
    zT_BCEE1C54_Opt_16 zT_46;
    zT_BCEE1C54_Opt_16 zT_47;
    zT_8143F551_AstKind zT_48;
    zT_DA663F79_ComptimeEval* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_8143F551_AstKind zT_62;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_DA663F79_ComptimeEval* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    zT_BCEE1C54_Opt_16 zT_81;
    zT_BCEE1C54_Opt_16 zT_82;
    zT_8143F551_AstKind zT_83;
    zT_6B0A7D14_AstStore* zT_88;
    unsigned int zT_89;
    unsigned int zT_91;
    zT_9BD83C17_Opt_442 zT_92;
    unsigned char zT_93;
    zT_E2DF2801_LocalConstScope* zT_95;
    unsigned int zT_96;
    zT_BAEE192E_Opt_10 zT_97;
    unsigned char zT_98;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    zT_22A7C88B_AstNode zT_104;
    unsigned int zT_105;
    zT_DA663F79_ComptimeEval* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned char zT_117;
    zT_BCEE1C54_Opt_16 zT_118;
    unsigned char zT_119;
    zT_DA663F79_ComptimeEval* zT_122;
    unsigned int zT_123;
    zT_BAEE192E_Opt_10 zT_125;
    unsigned char zT_126;
    float zT_131;
    zT_00435AEB_f64 zT_132;
    zT_BCEE1C54_Opt_16 zT_133;
    zT_BCEE1C54_Opt_16 zT_134;
    zT_BCEE1C54_Opt_16 zT_135;
    int zT_137;
    unsigned int zT_138;
    zT_3D7259E2_SymbolRegistry* zT_139;
    unsigned int zT_140;
    zT_3D7259E2_SymbolRegistry* zT_144;
    unsigned int zT_146;
    zT_77F031D4_Opt_960 zT_149;
    unsigned char zT_150;
    unsigned short zT_152;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    zT_22A7C88B_AstNode zT_162;
    unsigned int zT_163;
    zT_DA663F79_ComptimeEval* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char zT_175;
    zT_BCEE1C54_Opt_16 zT_176;
    unsigned char zT_177;
    zT_DA663F79_ComptimeEval* zT_180;
    unsigned int zT_181;
    zT_BAEE192E_Opt_10 zT_183;
    unsigned char zT_184;
    float zT_189;
    zT_00435AEB_f64 zT_190;
    zT_BCEE1C54_Opt_16 zT_191;
    zT_BCEE1C54_Opt_16 zT_192;
    zT_BCEE1C54_Opt_16 zT_193;
    int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    zT_BCEE1C54_Opt_16 zT_200;
    zT_BCEE1C54_Opt_16 zT_201;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_82, (unsigned int)sizeof zT_82);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_162, (unsigned int)sizeof zT_162);
    zig_poison_fill((void*)&zT_176, (unsigned int)sizeof zT_176);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_193, (unsigned int)sizeof zT_193);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zig_poison_fill((void*)&zT_201, (unsigned int)sizeof zT_201);
    zT_22A7C88B_AstNode node;
    zT_BCEE1C54_Opt_16 inner;
    zT_00435AEB_f64 fv;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_BCEE1C54_Opt_16 lin;
    zT_00435AEB_f64 lfv;
    zT_BAEE192E_Opt_10 ldt;
    unsigned int lt;
    float lf32;
    zT_77F031D4_Opt_960 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    float f32v;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_18 = self->store;
    zT_19 = zT_18->float_values;
    zT_20 = zT_19.items;
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_20[zT_25];
    zT_27.has_value = 1;
    zT_27.value = zT_26;
    return zT_27;
    z_bb_6:
    { zT_BCEE1C54_Opt_16 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_7:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_33 = self;
    zT_34 = node.child_0;
    zT_37 = 1;
    zT_38 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_35 = zT_38;
    zT_42 = zF_B719EB81_comptimeEvalFloat(zT_33, zT_34, zT_35);
    inner = zT_42;
    zT_43 = inner.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_48 = node.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    if (!(inner.has_value)) { pal_trap(); }
    fv = inner.value;
    zT_45 = -fv;
    zT_46.has_value = 1;
    zT_46.value = zT_45;
    return zT_46;
    z_bb_12:
    zT_47.has_value = 0;
    return zT_47;
    z_bb_13:
    zT_52 = self;
    zT_55 = node.child_0;
    zT_56 = 1;
    zT_57 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    self = zT_52;
    node_idx = zT_55;
    depth = zT_57;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_62 = node.kind;
    if ((unsigned char)(zT_62 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_66 = node.child_0;
    zT_67 = self->int_to_float_id;
    if ((unsigned char)(zT_66 == zT_67)) goto z_bb_20; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_83 = node.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_24; else goto z_bb_26;
    z_bb_19:
    zT_70 = node.child_0;
    zT_71 = self->float_cast_id;
    zT_69 = zT_70 == zT_71;
    goto z_bb_21;
    z_bb_20:
    zT_69 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_69) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_73 = self;
    zT_74 = node_idx;
    zT_76 = 1;
    zT_77 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_76)), 32u);
    zT_78 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_76)), 32u);
    zT_80 = zT_78 == (unsigned int)(0);
    if (!(zT_80)) { pal_trap(); }
    zT_75 = zT_77;
    zT_81 = zF_8C4B1954_comptimeEvalFloatBu(zT_73, zT_74, zT_75);
    return zT_81;
    z_bb_23:
    zT_82.has_value = 0;
    return zT_82;
    z_bb_24:
    zT_88 = self->store;
    zT_89 = node_idx;
    zT_91 = zF_53458827_astStoreIdentifier(zT_88, zT_89);
    name_id = zT_91;
    zT_92 = self->local_consts;
    zT_93 = zT_92.has_value;
    if (zT_93) goto z_bb_27; else goto z_bb_28;
    goto z_bb_17;
    z_bb_26:
    zT_201.has_value = 0;
    return zT_201;
    z_bb_27:
    if (!(zT_92.has_value)) { pal_trap(); }
    lcs = zT_92.value;
    zT_95 = lcs;
    zT_96 = name_id;
    zT_97 = zF_6532C387_localConstScopeLook(zT_95, zT_96);
    zT_98 = zT_97.has_value;
    if (zT_98) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_137 = 0;
    zT_138 = (unsigned int)zT_137;
    mi = zT_138;
    goto z_bb_39;
    z_bb_29:
    if (!(zT_97.has_value)) { pal_trap(); }
    l_decl_node = zT_97.value;
    zT_101 = self->store;
    zT_102 = l_decl_node;
    zT_104 = zF_FCDD1D35_astStoreNodeAt(zT_101, zT_102);
    l_decl = zT_104;
    zT_105 = l_decl.child_1;
    if ((unsigned char)(zT_105 != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_109 = self;
    zT_110 = l_decl.child_1;
    zT_113 = 1;
    zT_114 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_113)), 32u);
    zT_115 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_113)), 32u);
    zT_117 = zT_115 == (unsigned int)(0);
    if (!(zT_117)) { pal_trap(); }
    zT_111 = zT_114;
    zT_118 = zF_B719EB81_comptimeEvalFloat(zT_109, zT_110, zT_111);
    lin = zT_118;
    zT_119 = lin.has_value;
    if (zT_119) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    if (!(lin.has_value)) { pal_trap(); }
    lfv = lin.value;
    zT_122 = self;
    zT_123 = l_decl.child_0;
    zT_125 = zF_BAD6BA5D_comptimeEvalResolve(zT_122, zT_123);
    ldt = zT_125;
    zT_126 = ldt.has_value;
    if (zT_126) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_135.has_value = 0;
    return zT_135;
    z_bb_35:
    if (!(ldt.has_value)) { pal_trap(); }
    lt = ldt.value;
    if ((unsigned char)(lt == (unsigned int)(15))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_134.has_value = 1;
    zT_134.value = lfv;
    return zT_134;
    z_bb_37:
    zT_131 = (float)lfv;
    lf32 = zT_131;
    zT_132 = (zT_00435AEB_f64)lf32;
    zT_133.has_value = 1;
    zT_133.value = zT_132;
    return zT_133;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_139 = self->symbol_reg;
    zT_140 = zT_139->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_140))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_144 = self->symbol_reg;
    zT_146 = name_id;
    zT_149 = zF_A398987E_symbolRegistryQuali(zT_144, (unsigned int)((unsigned int)mi), zT_146);
    c_sym = zT_149;
    zT_150 = c_sym.has_value;
    if (zT_150) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_200.has_value = 0;
    return zT_200;
    z_bb_42:
    zT_194 = 1;
    zT_195 = (unsigned int)zT_194;
    zT_196 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_195)), 32u);
    zT_197 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_195)), 32u);
    zT_199 = zT_197 == (unsigned int)(0);
    if (!(zT_199)) { pal_trap(); }
    mi = zT_196;
    goto z_bb_39;
    z_bb_43:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_152 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_152 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_158 = self->store;
    zT_159 = cs->decl_node;
    zT_162 = zF_FCDD1D35_astStoreNodeAt(zT_158, zT_159);
    c_decl = zT_162;
    zT_163 = c_decl.child_1;
    if ((unsigned char)(zT_163 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    zT_167 = self;
    zT_168 = c_decl.child_1;
    zT_171 = 1;
    zT_172 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_171)), 32u);
    zT_173 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_171)), 32u);
    zT_175 = zT_173 == (unsigned int)(0);
    if (!(zT_175)) { pal_trap(); }
    zT_169 = zT_172;
    zT_176 = zF_B719EB81_comptimeEvalFloat(zT_167, zT_168, zT_169);
    inner = zT_176;
    zT_177 = inner.has_value;
    if (zT_177) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    if (!(inner.has_value)) { pal_trap(); }
    fv = inner.value;
    zT_180 = self;
    zT_181 = c_decl.child_0;
    zT_183 = zF_BAD6BA5D_comptimeEvalResolve(zT_180, zT_181);
    dt = zT_183;
    zT_184 = dt.has_value;
    if (zT_184) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_193.has_value = 0;
    return zT_193;
    z_bb_51:
    if (!(dt.has_value)) { pal_trap(); }
    t = dt.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_192.has_value = 1;
    zT_192.value = fv;
    return zT_192;
    z_bb_53:
    zT_189 = (float)fv;
    f32v = zT_189;
    zT_190 = (zT_00435AEB_f64)f32v;
    zT_191.has_value = 1;
    zT_191.value = zT_190;
    return zT_191;
    z_bb_54:
    goto z_bb_52;
}

/* comptimeEvalFloatBuiltin */
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    zT_DA663F79_ComptimeEval* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    unsigned char zT_18;
    unsigned char zT_22;
    zT_BCEE1C54_Opt_16 zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_32;
    zT_00435AEB_f64 zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_DA663F79_ComptimeEval* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_7534F824_Opt_223 zT_42;
    unsigned char zT_43;
    unsigned char zT_45;
    zT_BCEE1C54_Opt_16 zT_48;
    unsigned char zT_49;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_53;
    unsigned char zT_54;
    zT_00435AEB_f64 zT_55;
    zT_00435AEB_f64 zT_56;
    zT_0163D9A4_ComptimeInt zT_57;
    zT_0163D9A4_ComptimeInt zT_58;
    zT_00435AEB_f64 zT_59;
    zT_BCEE1C54_Opt_16 zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_DA663F79_ComptimeEval* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    zT_BCEE1C54_Opt_16 zT_68;
    unsigned char zT_69;
    zT_BCEE1C54_Opt_16 zT_71;
    zT_BCEE1C54_Opt_16 zT_72;
    float zT_76;
    zT_00435AEB_f64 zT_77;
    zT_BCEE1C54_Opt_16 zT_78;
    zT_BCEE1C54_Opt_16 zT_79;
    zT_BCEE1C54_Opt_16 zT_80;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    unsigned int inner_idx;
    zT_00435AEB_f64 fv;
    zT_7534F824_Opt_223 iv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_BCEE1C54_Opt_16 xv;
    zT_00435AEB_f64 x;
    float f32v;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_11, zT_12, (unsigned int)(0));
    zT_10 = zT_16;
    zT_17 = zF_BAD6BA5D_comptimeEvalResolve(zT_9, zT_10);
    tid = zT_17;
    zT_18 = tid.has_value;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_80.has_value = 0;
    return zT_80;
    z_bb_3:
    zT_22 = t != (unsigned int)(16);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_7:
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_32 = zF_B10B1BC1_astStoreNodeExtraCh(zT_27, zT_28, (unsigned int)(1));
    inner_idx = zT_32;
    zT_34 = 0;
    fv = zT_34;
    zT_35 = node.child_0;
    zT_36 = self->int_to_float_id;
    if ((unsigned char)(zT_35 == zT_36)) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_39 = self;
    zT_40 = inner_idx;
    zT_41 = depth;
    zT_42 = zF_4EE17137_comptimeEvalEvaluat(zT_39, zT_40, zT_41);
    iv = zT_42;
    zT_43 = iv.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_28; else goto z_bb_29;
    z_bb_10:
    zT_61 = node.child_0;
    zT_62 = self->float_cast_id;
    if ((unsigned char)(zT_61 == zT_62)) goto z_bb_22; else goto z_bb_24;
    z_bb_11:
    if (!(iv.has_value)) { pal_trap(); }
    cv = iv.value;
    zT_45 = cv.kind;
    if ((unsigned char)(zT_45 == (unsigned int)(2))) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_60.has_value = 0;
    return zT_60;
    z_bb_14:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_15:
    zT_49 = cv.kind;
    if ((unsigned char)(zT_49 == (unsigned int)(1))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_53 = cv.v;
    zT_52 = zT_53;
    zT_54 = zF_0F5FA15F_ciIsZero(zT_52);
    if (zT_54) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_58 = cv.v;
    zT_57 = zT_58;
    zT_59 = zF_E6CE9168_ciToF64(zT_57);
    fv = zT_59;
    goto z_bb_17;
    z_bb_19:
    zT_55 = 0;
    fv = zT_55;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_56 = 1e+0;
    fv = zT_56;
    goto z_bb_20;
    z_bb_22:
    zT_65 = self;
    zT_66 = inner_idx;
    zT_67 = depth;
    zT_68 = zF_B719EB81_comptimeEvalFloat(zT_65, zT_66, zT_67);
    xv = zT_68;
    zT_69 = xv.has_value;
    if (zT_69) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_9;
    z_bb_24:
    zT_72.has_value = 0;
    return zT_72;
    z_bb_25:
    if (!(xv.has_value)) { pal_trap(); }
    x = xv.value;
    fv = x;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_28:
    zT_76 = (float)fv;
    f32v = zT_76;
    zT_77 = (zT_00435AEB_f64)f32v;
    zT_78.has_value = 1;
    zT_78.value = zT_77;
    return zT_78;
    z_bb_29:
    zT_79.has_value = 1;
    zT_79.value = fv;
    return zT_79;
}

/* floatNarrowNone */
zT_66B68F69_FloatNarrowVal zF_6AEE4E20_floatNarrowNone(void) {
    zT_66B68F69_FloatNarrowVal zT_0;
    unsigned char zT_1;
    unsigned char zT_2;
    zT_00435AEB_f64 zT_3;
    zT_1 = 0;
    zT_0.ok = zT_1;
    zT_2 = 0;
    zT_0.typed = zT_2;
    zT_3 = 0;
    zT_0.v = zT_3;
    return zT_0;
}

/* comptimeEvalFloatNarrow */
zT_66B68F69_FloatNarrowVal zF_213A0C7E_comptimeEvalFloatNa(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_66B68F69_FloatNarrowVal zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_0DB56784_floatNarrowProbe(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* floatNarrowProbe */
zT_66B68F69_FloatNarrowVal zF_0DB56784_floatNarrowProbe(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_66B68F69_FloatNarrowVal zT_4;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    zT_E494E487_anon_323991 zT_20;
    zT_00435AEB_f64* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_00435AEB_f64 zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    zT_8143F551_AstKind zT_33;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_79FAE712_u64 zT_41;
    zT_8143F551_AstKind zT_43;
    unsigned char zT_47;
    zT_8143F551_AstKind zT_48;
    zT_DA663F79_ComptimeEval* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_66B68F69_FloatNarrowVal zT_61;
    unsigned char zT_62;
    zT_8143F551_AstKind zT_64;
    zT_00435AEB_f64 zT_68;
    zT_8143F551_AstKind zT_70;
    unsigned char zT_74;
    zT_8143F551_AstKind zT_75;
    unsigned char zT_79;
    zT_8143F551_AstKind zT_80;
    unsigned char zT_84;
    zT_8143F551_AstKind zT_85;
    zT_DA663F79_ComptimeEval* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zT_66B68F69_FloatNarrowVal zT_99;
    unsigned char zT_100;
    zT_DA663F79_ComptimeEval* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned char zT_111;
    zT_66B68F69_FloatNarrowVal zT_112;
    unsigned char zT_113;
    unsigned char zT_116;
    unsigned char zT_117;
    zT_8143F551_AstKind zT_119;
    zT_00435AEB_f64 zT_123;
    zT_00435AEB_f64 zT_124;
    zT_8143F551_AstKind zT_126;
    zT_00435AEB_f64 zT_130;
    zT_00435AEB_f64 zT_131;
    zT_8143F551_AstKind zT_133;
    zT_00435AEB_f64 zT_137;
    zT_00435AEB_f64 zT_138;
    zT_8143F551_AstKind zT_140;
    zT_00435AEB_f64 zT_144;
    zT_66B68F69_FloatNarrowVal zT_147;
    zT_00435AEB_f64 zT_148;
    zT_00435AEB_f64 zT_149;
    unsigned char zT_152;
    zT_8143F551_AstKind zT_153;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_161;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned char zT_167;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned char zT_175;
    unsigned char zT_177;
    unsigned char zT_179;
    unsigned char zT_181;
    zT_DA663F79_ComptimeEval* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned char zT_189;
    zT_BCEE1C54_Opt_16 zT_190;
    unsigned char zT_191;
    zT_DA663F79_ComptimeEval* zT_196;
    unsigned int zT_197;
    zT_6B0A7D14_AstStore* zT_198;
    unsigned int zT_199;
    unsigned int zT_203;
    zT_BAEE192E_Opt_10 zT_204;
    unsigned char zT_205;
    unsigned char zT_209;
    zT_6B0A7D14_AstStore* zT_215;
    unsigned int zT_216;
    unsigned int zT_220;
    zT_00435AEB_f64 zT_222;
    zT_DA663F79_ComptimeEval* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned char zT_230;
    zT_7534F824_Opt_223 zT_231;
    unsigned char zT_232;
    unsigned char zT_234;
    zT_89B1DDDA_ComptimeVal zT_237;
    zT_00435AEB_f64 zT_238;
    unsigned char zT_239;
    zT_0163D9A4_ComptimeInt zT_242;
    zT_0163D9A4_ComptimeInt zT_243;
    zT_00435AEB_f64 zT_244;
    unsigned char zT_245;
    zT_0163D9A4_ComptimeInt zT_248;
    zT_0163D9A4_ComptimeInt zT_249;
    unsigned char zT_250;
    zT_00435AEB_f64 zT_252;
    zT_DA663F79_ComptimeEval* zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned char zT_261;
    zT_66B68F69_FloatNarrowVal zT_262;
    unsigned char zT_263;
    zT_00435AEB_f64 zT_265;
    float zT_269;
    zT_00435AEB_f64 zT_270;
    zT_8143F551_AstKind zT_273;
    zT_6B0A7D14_AstStore* zT_278;
    unsigned int zT_279;
    unsigned int zT_281;
    zT_9BD83C17_Opt_442 zT_282;
    unsigned char zT_283;
    zT_E2DF2801_LocalConstScope* zT_285;
    unsigned int zT_286;
    zT_BAEE192E_Opt_10 zT_287;
    unsigned char zT_288;
    zT_DA663F79_ComptimeEval* zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned char zT_297;
    zT_66B68F69_FloatNarrowVal zT_298;
    int zT_300;
    unsigned int zT_301;
    zT_3D7259E2_SymbolRegistry* zT_302;
    unsigned int zT_303;
    zT_3D7259E2_SymbolRegistry* zT_307;
    unsigned int zT_309;
    zT_77F031D4_Opt_960 zT_312;
    unsigned char zT_313;
    unsigned short zT_315;
    zT_DA663F79_ComptimeEval* zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned char zT_328;
    zT_66B68F69_FloatNarrowVal zT_329;
    int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned char zT_335;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_147, (unsigned int)sizeof zT_147);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_203, (unsigned int)sizeof zT_203);
    zig_poison_fill((void*)&zT_204, (unsigned int)sizeof zT_204);
    zig_poison_fill((void*)&zT_220, (unsigned int)sizeof zT_220);
    zig_poison_fill((void*)&zT_231, (unsigned int)sizeof zT_231);
    zig_poison_fill((void*)&zT_238, (unsigned int)sizeof zT_238);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_250, (unsigned int)sizeof zT_250);
    zig_poison_fill((void*)&zT_262, (unsigned int)sizeof zT_262);
    zig_poison_fill((void*)&zT_281, (unsigned int)sizeof zT_281);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    zig_poison_fill((void*)&zT_298, (unsigned int)sizeof zT_298);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_329, (unsigned int)sizeof zT_329);
    zT_66B68F69_FloatNarrowVal r;
    zT_22A7C88B_AstNode node;
    zT_66B68F69_FloatNarrowVal l;
    zT_66B68F69_FloatNarrowVal rt;
    unsigned int bc_n;
    unsigned char is_as;
    unsigned char is_fc;
    unsigned char is_itf;
    zT_BAEE192E_Opt_10 tid;
    zT_00435AEB_f64 bv;
    unsigned int t;
    unsigned int inner_idx;
    zT_00435AEB_f64 fv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_66B68F69_FloatNarrowVal iv;
    float f32v;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_77F031D4_Opt_960 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_4 = zF_6AEE4E20_floatNarrowNone();
    r = zT_4;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return r;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(20))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return r;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    r.ok = (unsigned char)(1);
    zT_19 = self->store;
    zT_20 = zT_19->float_values;
    zT_21 = zT_20.items;
    zT_22 = self->store;
    zT_23 = node_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    r.v = zT_27;
    return r;
    z_bb_6:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_33 = node.kind;
    zT_32 = zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_9;
    z_bb_8:
    zT_32 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_32) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    r.ok = (unsigned char)(1);
    zT_38 = self->store;
    zT_39 = node_idx;
    zT_41 = zF_678B9A72_astStoreIntValue(zT_38, zT_39);
    r.v = (zT_00435AEB_f64)((zT_00435AEB_f64)zT_41);
    return r;
    z_bb_11:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_48 = node.kind;
    zT_47 = zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr);
    goto z_bb_14;
    z_bb_13:
    zT_47 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_47) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_52 = self;
    zT_53 = node.child_0;
    zT_56 = 1;
    zT_57 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_54 = zT_57;
    zT_61 = zF_0DB56784_floatNarrowProbe(zT_52, zT_53, zT_54);
    r = zT_61;
    zT_62 = r.ok;
    if ((unsigned char)(!zT_62)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_70 = node.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_22; else goto z_bb_21;
    z_bb_17:
    return r;
    z_bb_18:
    zT_64 = node.kind;
    if ((unsigned char)(zT_64 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_68 = r.v;
    r.v = (zT_00435AEB_f64)(-zT_68);
    goto z_bb_20;
    z_bb_20:
    return r;
    z_bb_21:
    zT_75 = node.kind;
    zT_74 = zT_75 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_23;
    z_bb_22:
    zT_74 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_74) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_80 = node.kind;
    zT_79 = zT_80 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_26;
    z_bb_25:
    zT_79 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_79) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_85 = node.kind;
    zT_84 = zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_29;
    z_bb_28:
    zT_84 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_84) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_90 = self;
    zT_91 = node.child_0;
    zT_94 = 1;
    zT_95 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    zT_92 = zT_95;
    zT_99 = zF_0DB56784_floatNarrowProbe(zT_90, zT_91, zT_92);
    l = zT_99;
    zT_100 = l.ok;
    if ((unsigned char)(!zT_100)) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_153 = node.kind;
    if ((unsigned char)(zT_153 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_49; else goto z_bb_50;
    z_bb_32:
    return r;
    z_bb_33:
    zT_103 = self;
    zT_104 = node.child_1;
    zT_107 = 1;
    zT_108 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_107)), 32u);
    zT_109 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_107)), 32u);
    zT_111 = zT_109 == (unsigned int)(0);
    if (!(zT_111)) { pal_trap(); }
    zT_105 = zT_108;
    zT_112 = zF_0DB56784_floatNarrowProbe(zT_103, zT_104, zT_105);
    rt = zT_112;
    zT_113 = rt.ok;
    if ((unsigned char)(!zT_113)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return r;
    z_bb_35:
    r.ok = (unsigned char)(1);
    zT_116 = l.typed;
    if (zT_116) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_117 = rt.typed;
    goto z_bb_38;
    z_bb_37:
    zT_117 = 1;
    goto z_bb_38;
    z_bb_38:
    r.typed = zT_117;
    zT_119 = node.kind;
    if ((unsigned char)(zT_119 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_123 = l.v;
    zT_124 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_123 + zT_124);
    goto z_bb_40;
    z_bb_40:
    zT_126 = node.kind;
    if ((unsigned char)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_130 = l.v;
    zT_131 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_130 - zT_131);
    goto z_bb_42;
    z_bb_42:
    zT_133 = node.kind;
    if ((unsigned char)(zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_137 = l.v;
    zT_138 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_137 * zT_138);
    goto z_bb_44;
    z_bb_44:
    zT_140 = node.kind;
    if ((unsigned char)(zT_140 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_144 = rt.v;
    if ((unsigned char)(zT_144 == (zT_00435AEB_f64)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    return r;
    z_bb_47:
    zT_147 = zF_6AEE4E20_floatNarrowNone();
    return zT_147;
    z_bb_48:
    zT_148 = l.v;
    zT_149 = rt.v;
    zT_152 = zT_149 != (unsigned int)(0);
    if (!(zT_152)) { pal_trap(); }
    r.v = (zT_00435AEB_f64)(zT_148 / zT_149);
    goto z_bb_46;
    z_bb_49:
    zT_158 = self->store;
    zT_159 = node_idx;
    zT_161 = zF_152E19CB_astStoreNodeExtraCh(zT_158, zT_159);
    bc_n = zT_161;
    if ((unsigned char)(bc_n < (unsigned int)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_273 = node.kind;
    if ((unsigned char)(zT_273 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_95; else goto z_bb_96;
    z_bb_51:
    return r;
    z_bb_52:
    zT_165 = node.child_0;
    zT_166 = self->as_id;
    zT_167 = zT_165 == zT_166;
    is_as = zT_167;
    zT_169 = node.child_0;
    zT_170 = self->float_cast_id;
    zT_171 = zT_169 == zT_170;
    is_fc = zT_171;
    zT_173 = node.child_0;
    zT_174 = self->int_to_float_id;
    zT_175 = zT_173 == zT_174;
    is_itf = zT_175;
    if ((unsigned char)(!is_as)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_177 = !is_fc;
    goto z_bb_55;
    z_bb_54:
    zT_177 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_177) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_179 = !is_itf;
    goto z_bb_58;
    z_bb_57:
    zT_179 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_179) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return r;
    z_bb_60:
    if (is_fc) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_181 = is_itf;
    goto z_bb_63;
    z_bb_62:
    zT_181 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_181) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_182 = self;
    zT_183 = node_idx;
    zT_185 = 1;
    zT_186 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_185)), 32u);
    zT_187 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_185)), 32u);
    zT_189 = zT_187 == (unsigned int)(0);
    if (!(zT_189)) { pal_trap(); }
    zT_184 = zT_186;
    zT_190 = zF_8C4B1954_comptimeEvalFloatBu(zT_182, zT_183, zT_184);
    zT_191 = zT_190.has_value;
    if (zT_191) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_196 = self;
    zT_198 = self->store;
    zT_199 = node_idx;
    zT_203 = zF_B10B1BC1_astStoreNodeExtraCh(zT_198, zT_199, (unsigned int)(0));
    zT_197 = zT_203;
    zT_204 = zF_BAD6BA5D_comptimeEvalResolve(zT_196, zT_197);
    tid = zT_204;
    zT_205 = tid.has_value;
    if (zT_205) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    if (!(zT_190.has_value)) { pal_trap(); }
    bv = zT_190.value;
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    r.v = bv;
    goto z_bb_67;
    z_bb_67:
    return r;
    z_bb_68:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    return r;
    z_bb_70:
    zT_209 = t != (unsigned int)(16);
    goto z_bb_72;
    z_bb_71:
    zT_209 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_209) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return r;
    z_bb_74:
    if ((unsigned char)(bc_n < (unsigned int)(2))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    return r;
    z_bb_76:
    zT_215 = self->store;
    zT_216 = node_idx;
    zT_220 = zF_B10B1BC1_astStoreNodeExtraCh(zT_215, zT_216, (unsigned int)(1));
    inner_idx = zT_220;
    zT_222 = 0;
    fv = zT_222;
    zT_223 = self;
    zT_224 = inner_idx;
    zT_226 = 1;
    zT_227 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_226)), 32u);
    zT_228 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_226)), 32u);
    zT_230 = zT_228 == (unsigned int)(0);
    if (!(zT_230)) { pal_trap(); }
    zT_225 = zT_227;
    zT_231 = zF_4EE17137_comptimeEvalEvaluat(zT_223, zT_224, zT_225);
    zT_232 = zT_231.has_value;
    if (zT_232) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    if (!(zT_231.has_value)) { pal_trap(); }
    cv = zT_231.value;
    zT_234 = cv.kind;
    if ((unsigned char)(zT_234 == (unsigned int)(2))) goto z_bb_80; else goto z_bb_82;
    z_bb_78:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_93; else goto z_bb_94;
    z_bb_79:
    zT_254 = self;
    zT_255 = inner_idx;
    zT_257 = 1;
    zT_258 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_257)), 32u);
    zT_259 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_257)), 32u);
    zT_261 = zT_259 == (unsigned int)(0);
    if (!(zT_261)) { pal_trap(); }
    zT_256 = zT_258;
    zT_262 = zF_0DB56784_floatNarrowProbe(zT_254, zT_255, zT_256);
    iv = zT_262;
    zT_263 = iv.ok;
    if ((unsigned char)(!zT_263)) goto z_bb_91; else goto z_bb_92;
    z_bb_80:
    zT_237 = cv;
    zT_238 = zF_9DD4606D_comptimeEvalFloatBi(zT_237);
    fv = zT_238;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    zT_239 = cv.kind;
    if ((unsigned char)(zT_239 == (unsigned int)(0))) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_243 = cv.v;
    zT_242 = zT_243;
    zT_244 = zF_E6CE9168_ciToF64(zT_242);
    fv = zT_244;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    zT_245 = cv.kind;
    if ((unsigned char)(zT_245 == (unsigned int)(1))) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    zT_249 = cv.v;
    zT_248 = zT_249;
    zT_250 = zF_0F5FA15F_ciIsZero(zT_248);
    if ((unsigned char)(!zT_250)) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    return r;
    z_bb_89:
    zT_252 = 1e+0;
    fv = zT_252;
    goto z_bb_90;
    z_bb_90:
    goto z_bb_87;
    z_bb_91:
    return r;
    z_bb_92:
    zT_265 = iv.v;
    fv = zT_265;
    goto z_bb_78;
    z_bb_93:
    zT_269 = (float)fv;
    f32v = zT_269;
    zT_270 = (zT_00435AEB_f64)f32v;
    fv = zT_270;
    goto z_bb_94;
    z_bb_94:
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    r.v = fv;
    return r;
    z_bb_95:
    zT_278 = self->store;
    zT_279 = node_idx;
    zT_281 = zF_53458827_astStoreIdentifier(zT_278, zT_279);
    name_id = zT_281;
    zT_282 = self->local_consts;
    zT_283 = zT_282.has_value;
    if (zT_283) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    return r;
    z_bb_97:
    if (!(zT_282.has_value)) { pal_trap(); }
    lcs = zT_282.value;
    zT_285 = lcs;
    zT_286 = name_id;
    zT_287 = zF_6532C387_localConstScopeLook(zT_285, zT_286);
    zT_288 = zT_287.has_value;
    if (zT_288) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_300 = 0;
    zT_301 = (unsigned int)zT_300;
    mi = zT_301;
    goto z_bb_101;
    z_bb_99:
    if (!(zT_287.has_value)) { pal_trap(); }
    l_decl_node = zT_287.value;
    zT_290 = self;
    zT_291 = l_decl_node;
    zT_293 = 1;
    zT_294 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_293)), 32u);
    zT_295 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_293)), 32u);
    zT_297 = zT_295 == (unsigned int)(0);
    if (!(zT_297)) { pal_trap(); }
    zT_292 = zT_294;
    zT_298 = zF_25831332_floatNarrowDecl(zT_290, zT_291, zT_292);
    return zT_298;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_302 = self->symbol_reg;
    zT_303 = zT_302->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_303))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_307 = self->symbol_reg;
    zT_309 = name_id;
    zT_312 = zF_A398987E_symbolRegistryQuali(zT_307, (unsigned int)((unsigned int)mi), zT_309);
    c_sym = zT_312;
    zT_313 = c_sym.has_value;
    if (zT_313) goto z_bb_105; else goto z_bb_106;
    z_bb_103:
    return r;
    z_bb_104:
    zT_330 = 1;
    zT_331 = (unsigned int)zT_330;
    zT_332 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_331)), 32u);
    zT_333 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_331)), 32u);
    zT_335 = zT_333 == (unsigned int)(0);
    if (!(zT_335)) { pal_trap(); }
    mi = zT_332;
    goto z_bb_101;
    z_bb_105:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_315 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_315 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    goto z_bb_104;
    z_bb_107:
    zT_320 = self;
    zT_321 = cs->decl_node;
    zT_324 = 1;
    zT_325 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_324)), 32u);
    zT_326 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_324)), 32u);
    zT_328 = zT_326 == (unsigned int)(0);
    if (!(zT_328)) { pal_trap(); }
    zT_322 = zT_325;
    zT_329 = zF_25831332_floatNarrowDecl(zT_320, zT_321, zT_322);
    return zT_329;
    z_bb_108:
    goto z_bb_106;
}

/* floatNarrowDecl */
zT_66B68F69_FloatNarrowVal zF_25831332_floatNarrowDecl(zT_DA663F79_ComptimeEval* self, unsigned int decl_node, unsigned int depth) {
    zT_66B68F69_FloatNarrowVal zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    unsigned int zT_10;
    zT_DA663F79_ComptimeEval* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_66B68F69_FloatNarrowVal zT_22;
    unsigned char zT_23;
    zT_DA663F79_ComptimeEval* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_7534F824_Opt_223 zT_34;
    unsigned char zT_35;
    unsigned char zT_37;
    zT_89B1DDDA_ComptimeVal zT_42;
    zT_00435AEB_f64 zT_43;
    unsigned char zT_44;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned int zT_52;
    unsigned char zT_55;
    zT_0163D9A4_ComptimeInt zT_58;
    zT_0163D9A4_ComptimeInt zT_59;
    zT_00435AEB_f64 zT_60;
    zT_0163D9A4_ComptimeInt zT_61;
    zT_0163D9A4_ComptimeInt zT_62;
    unsigned char zT_63;
    zT_66B68F69_FloatNarrowVal zT_66;
    zT_66B68F69_FloatNarrowVal zT_67;
    unsigned int zT_68;
    zT_DA663F79_ComptimeEval* zT_71;
    unsigned int zT_72;
    zT_BAEE192E_Opt_10 zT_74;
    unsigned char zT_75;
    zT_00435AEB_f64 zT_80;
    float zT_81;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zT_66B68F69_FloatNarrowVal r;
    zT_22A7C88B_AstNode d;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned int t;
    float f32v;
    zT_4 = zF_6AEE4E20_floatNarrowNone();
    r = zT_4;
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    d = zT_9;
    zT_10 = d.child_1;
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return r;
    z_bb_2:
    zT_13 = self;
    zT_14 = d.child_1;
    zT_17 = 1;
    zT_18 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    zT_15 = zT_18;
    zT_22 = zF_0DB56784_floatNarrowProbe(zT_13, zT_14, zT_15);
    r = zT_22;
    zT_23 = r.ok;
    if ((unsigned char)(!zT_23)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25 = self;
    zT_26 = d.child_1;
    zT_29 = 1;
    zT_30 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_27 = zT_30;
    zT_34 = zF_4EE17137_comptimeEvalEvaluat(zT_25, zT_26, zT_27);
    zT_35 = zT_34.has_value;
    if (zT_35) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_68 = d.child_0;
    if ((unsigned char)(zT_68 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_5:
    if (!(zT_34.has_value)) { pal_trap(); }
    cv = zT_34.value;
    zT_37 = cv.kind;
    if ((unsigned char)(zT_37 == (unsigned int)(2))) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_67 = zF_6AEE4E20_floatNarrowNone();
    return zT_67;
    z_bb_8:
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    zT_42 = cv;
    zT_43 = zF_9DD4606D_comptimeEvalFloatBi(zT_42);
    r.v = zT_43;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_44 = cv.kind;
    if ((unsigned char)(zT_44 == (unsigned int)(0))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_48 = cv.kind;
    zT_47 = zT_48 == (unsigned int)(1);
    goto z_bb_13;
    z_bb_12:
    zT_47 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_47) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    r.ok = (unsigned char)(1);
    zT_52 = d.child_0;
    r.typed = (unsigned char)(zT_52 != (unsigned int)(0));
    zT_55 = cv.kind;
    if ((unsigned char)(zT_55 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_66 = zF_6AEE4E20_floatNarrowNone();
    return zT_66;
    z_bb_17:
    zT_59 = cv.v;
    zT_58 = zT_59;
    zT_60 = zF_E6CE9168_ciToF64(zT_58);
    r.v = zT_60;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_62 = cv.v;
    zT_61 = zT_62;
    zT_63 = zF_0F5FA15F_ciIsZero(zT_61);
    if ((unsigned char)(!zT_63)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    r.v = (zT_00435AEB_f64)(1e+0);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_71 = self;
    zT_72 = d.child_0;
    zT_74 = zF_BAD6BA5D_comptimeEvalResolve(zT_71, zT_72);
    zT_75 = zT_74.has_value;
    if (zT_75) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return r;
    z_bb_24:
    if (!(zT_74.has_value)) { pal_trap(); }
    t = zT_74.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_26; else goto z_bb_28;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_80 = r.v;
    zT_81 = (float)zT_80;
    f32v = zT_81;
    r.v = (zT_00435AEB_f64)((zT_00435AEB_f64)f32v);
    r.typed = (unsigned char)(1);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    if ((unsigned char)(t == (unsigned int)(16))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    r.typed = (unsigned char)(1);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->registry;
    zT_88 = t;
    zT_90 = zF_3290E9C4_typeRegistryIsInteg(zT_87, zT_88);
    if (zT_90) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    r.typed = (unsigned char)(1);
    goto z_bb_33;
    z_bb_33:
    goto z_bb_30;
}

/* comptimeEvalEvaluate */
zT_7534F824_Opt_223 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_7534F824_Opt_223 zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_7534F824_Opt_223 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_7534F824_Opt_223 zT_5;
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10;
    zT_8143F551_AstKind zT_11;
    zT_0163D9A4_ComptimeInt zT_15;
    zT_79FAE712_u64 zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64 zT_20;
    zT_0163D9A4_ComptimeInt zT_21;
    zT_89B1DDDA_ComptimeVal zT_22;
    zT_7534F824_Opt_223 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_0163D9A4_ComptimeInt zT_28;
    zT_79FAE712_u64 zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_89B1DDDA_ComptimeVal zT_35;
    zT_7534F824_Opt_223 zT_36;
    zT_8143F551_AstKind zT_37;
    unsigned char zT_41;
    zT_89B1DDDA_ComptimeVal zT_48;
    zT_7534F824_Opt_223 zT_49;
    zT_89B1DDDA_ComptimeVal zT_52;
    zT_7534F824_Opt_223 zT_53;
    zT_8143F551_AstKind zT_54;
    zT_DA663F79_ComptimeEval* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_7534F824_Opt_223 zT_63;
    unsigned char zT_64;
    unsigned char zT_66;
    zT_7534F824_Opt_223 zT_69;
    zT_0163D9A4_ComptimeInt zT_71;
    zT_0163D9A4_ComptimeInt zT_72;
    zT_0163D9A4_ComptimeInt* zT_73;
    zT_0163D9A4_ComptimeInt zT_74;
    unsigned char zT_76;
    zT_DA663F79_ComptimeEval* zT_78;
    unsigned int zT_79;
    zT_BAEE192E_Opt_10 zT_81;
    unsigned char zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_0163D9A4_ComptimeInt zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_7534F824_Opt_223 zT_90;
    zT_0163D9A4_ComptimeInt zT_91;
    zT_89B1DDDA_ComptimeVal zT_92;
    zT_7534F824_Opt_223 zT_93;
    zT_7534F824_Opt_223 zT_94;
    zT_8143F551_AstKind zT_95;
    zT_DA663F79_ComptimeEval* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_7534F824_Opt_223 zT_104;
    unsigned char zT_105;
    unsigned char zT_107;
    zT_7534F824_Opt_223 zT_110;
    zT_0163D9A4_ComptimeInt zT_112;
    zT_0163D9A4_ComptimeInt zT_113;
    zT_0163D9A4_ComptimeInt* zT_114;
    zT_0163D9A4_ComptimeInt zT_115;
    unsigned char zT_117;
    zT_7534F824_Opt_223 zT_119;
    zT_0163D9A4_ComptimeInt zT_120;
    zT_89B1DDDA_ComptimeVal zT_121;
    zT_7534F824_Opt_223 zT_122;
    zT_7534F824_Opt_223 zT_123;
    zT_8143F551_AstKind zT_124;
    zT_DA663F79_ComptimeEval* zT_128;
    unsigned int zT_129;
    zT_8143F551_AstKind zT_130;
    unsigned int zT_131;
    zT_7534F824_Opt_223 zT_133;
    zT_8143F551_AstKind zT_134;
    unsigned char zT_138;
    zT_8143F551_AstKind zT_139;
    unsigned char zT_143;
    zT_8143F551_AstKind zT_144;
    unsigned char zT_148;
    zT_8143F551_AstKind zT_149;
    unsigned char zT_153;
    zT_8143F551_AstKind zT_154;
    unsigned char zT_158;
    zT_8143F551_AstKind zT_159;
    unsigned char zT_163;
    zT_8143F551_AstKind zT_164;
    unsigned char zT_168;
    zT_8143F551_AstKind zT_169;
    unsigned char zT_173;
    zT_8143F551_AstKind zT_174;
    unsigned char zT_178;
    zT_8143F551_AstKind zT_179;
    zT_DA663F79_ComptimeEval* zT_183;
    unsigned int zT_184;
    zT_8143F551_AstKind zT_185;
    unsigned int zT_186;
    zT_7534F824_Opt_223 zT_188;
    zT_8143F551_AstKind zT_189;
    unsigned char zT_193;
    zT_8143F551_AstKind zT_194;
    unsigned char zT_198;
    zT_8143F551_AstKind zT_199;
    unsigned char zT_203;
    zT_8143F551_AstKind zT_204;
    unsigned char zT_208;
    zT_8143F551_AstKind zT_209;
    unsigned char zT_213;
    zT_8143F551_AstKind zT_214;
    zT_DA663F79_ComptimeEval* zT_218;
    unsigned int zT_219;
    zT_8143F551_AstKind zT_220;
    unsigned int zT_221;
    zT_7534F824_Opt_223 zT_223;
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    zT_8143F551_AstKind zT_229;
    zT_DA663F79_ComptimeEval* zT_233;
    unsigned int zT_234;
    zT_8143F551_AstKind zT_235;
    unsigned int zT_236;
    zT_7534F824_Opt_223 zT_238;
    zT_8143F551_AstKind zT_239;
    zT_DA663F79_ComptimeEval* zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    zT_7534F824_Opt_223 zT_246;
    zT_8143F551_AstKind zT_247;
    zT_DA663F79_ComptimeEval* zT_251;
    unsigned int zT_253;
    unsigned int zT_254;
    zT_8143F551_AstKind zT_256;
    zT_7534F824_Opt_223 zT_262;
    zT_6B0A7D14_AstStore* zT_264;
    unsigned int zT_265;
    unsigned int zT_267;
    zT_9BD83C17_Opt_442 zT_268;
    unsigned char zT_269;
    zT_E2DF2801_LocalConstScope* zT_271;
    unsigned int zT_272;
    zT_BAEE192E_Opt_10 zT_273;
    unsigned char zT_274;
    zT_6B0A7D14_AstStore* zT_277;
    unsigned int zT_278;
    zT_22A7C88B_AstNode zT_280;
    unsigned int zT_281;
    zT_DA663F79_ComptimeEval* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    zT_7534F824_Opt_223 zT_294;
    unsigned char zT_295;
    zT_DA663F79_ComptimeEval* zT_297;
    unsigned int zT_298;
    zT_89B1DDDA_ComptimeVal zT_299;
    unsigned char zT_300;
    zT_7534F824_Opt_223 zT_302;
    int zT_304;
    unsigned int zT_305;
    zT_3D7259E2_SymbolRegistry* zT_306;
    unsigned int zT_307;
    zT_3D7259E2_SymbolRegistry* zT_311;
    unsigned int zT_313;
    zT_77F031D4_Opt_960 zT_316;
    unsigned char zT_317;
    unsigned short zT_319;
    zT_6B0A7D14_AstStore* zT_325;
    unsigned int zT_326;
    zT_22A7C88B_AstNode zT_329;
    unsigned int zT_330;
    zT_DA663F79_ComptimeEval* zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned char zT_342;
    zT_7534F824_Opt_223 zT_343;
    unsigned char zT_344;
    zT_DA663F79_ComptimeEval* zT_346;
    unsigned int zT_347;
    zT_89B1DDDA_ComptimeVal zT_348;
    unsigned char zT_350;
    zT_7534F824_Opt_223 zT_352;
    int zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    unsigned char zT_358;
    zT_7534F824_Opt_223 zT_359;
    zT_7534F824_Opt_223 zT_360;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_110, (unsigned int)sizeof zT_110);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_188, (unsigned int)sizeof zT_188);
    zig_poison_fill((void*)&zT_223, (unsigned int)sizeof zT_223);
    zig_poison_fill((void*)&zT_238, (unsigned int)sizeof zT_238);
    zig_poison_fill((void*)&zT_246, (unsigned int)sizeof zT_246);
    zig_poison_fill((void*)&zT_262, (unsigned int)sizeof zT_262);
    zig_poison_fill((void*)&zT_267, (unsigned int)sizeof zT_267);
    zig_poison_fill((void*)&zT_273, (unsigned int)sizeof zT_273);
    zig_poison_fill((void*)&zT_280, (unsigned int)sizeof zT_280);
    zig_poison_fill((void*)&zT_294, (unsigned int)sizeof zT_294);
    zig_poison_fill((void*)&zT_300, (unsigned int)sizeof zT_300);
    zig_poison_fill((void*)&zT_302, (unsigned int)sizeof zT_302);
    zig_poison_fill((void*)&zT_316, (unsigned int)sizeof zT_316);
    zig_poison_fill((void*)&zT_329, (unsigned int)sizeof zT_329);
    zig_poison_fill((void*)&zT_343, (unsigned int)sizeof zT_343);
    zig_poison_fill((void*)&zT_350, (unsigned int)sizeof zT_350);
    zig_poison_fill((void*)&zT_352, (unsigned int)sizeof zT_352);
    zig_poison_fill((void*)&zT_359, (unsigned int)sizeof zT_359);
    zig_poison_fill((void*)&zT_360, (unsigned int)sizeof zT_360);
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_0163D9A4_ComptimeInt nv;
    zT_BAEE192E_Opt_10 pt;
    unsigned int ptid;
    zT_7534F824_Opt_223 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_0163D9A4_ComptimeInt bnb;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_7534F824_Opt_223 lv;
    zT_89B1DDDA_ComptimeVal lvv;
    zT_77F031D4_Opt_960 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_7534F824_Opt_223 cv_1;
    zT_89B1DDDA_ComptimeVal cvv;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_17 = self->store;
    zT_18 = node_idx;
    zT_20 = zF_678B9A72_astStoreIntValue(zT_17, zT_18);
    zT_16 = zT_20;
    zT_21 = zF_1EAA44E6_ciFromU64(zT_16);
    zT_15 = zT_21;
    zT_22 = zF_237A4571_ciIntVal(zT_15);
    zT_23.has_value = 1;
    zT_23.value = zT_22;
    return zT_23;
    z_bb_4:
    { zT_7534F824_Opt_223 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_24 = node.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_30 = self->store;
    zT_31 = node_idx;
    zT_33 = zF_678B9A72_astStoreIntValue(zT_30, zT_31);
    zT_29 = zT_33;
    zT_34 = zF_1EAA44E6_ciFromU64(zT_29);
    zT_28 = zT_34;
    zT_35 = zF_237A4571_ciIntVal(zT_28);
    zT_36.has_value = 1;
    zT_36.value = zT_35;
    return zT_36;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_41 = node.flags;
    if ((unsigned char)((unsigned char)(zT_41 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_54 = node.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_48 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_49.has_value = 1;
    zT_49.value = zT_48;
    return zT_49;
    z_bb_13:
    zT_52 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_53.has_value = 1;
    zT_53.value = zT_52;
    return zT_53;
    z_bb_14:
    zT_59 = self;
    zT_60 = node.child_0;
    zT_61 = depth;
    zT_63 = zF_4EE17137_comptimeEvalEvaluat(zT_59, zT_60, zT_61);
    inner = zT_63;
    zT_64 = inner.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_95 = node.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_25; else goto z_bb_27;
    z_bb_17:
    if (!(inner.has_value)) { pal_trap(); }
    cv = inner.value;
    zT_66 = cv.kind;
    if ((unsigned char)(zT_66 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_19:
    zT_69.has_value = 0;
    return zT_69;
    z_bb_20:
    zT_71 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_71;
    zT_74 = cv.v;
    zT_72 = zT_74;
    zT_73 = (zT_0163D9A4_ComptimeInt*)&nv;
    zT_76 = zF_EECBFD7D_ciNeg(zT_72, zT_73);
    (void)zT_76;
    zT_78 = self;
    zT_79 = node.child_0;
    zT_81 = zF_6B810D4A_comptimeEvalOperand(zT_78, zT_79);
    pt = zT_81;
    zT_82 = pt.has_value;
    if (zT_82) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    if (!(pt.has_value)) { pal_trap(); }
    ptid = pt.value;
    zT_84 = self->registry;
    zT_85 = nv;
    zT_86 = ptid;
    zT_88 = zF_B28C4720_comptimeIntFitsType(zT_84, zT_85, zT_86);
    if ((unsigned char)(!zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_91 = nv;
    zT_92 = zF_237A4571_ciIntVal(zT_91);
    zT_93.has_value = 1;
    zT_93.value = zT_92;
    return zT_93;
    z_bb_23:
    zT_90.has_value = 0;
    return zT_90;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_100 = self;
    zT_101 = node.child_0;
    zT_102 = depth;
    zT_104 = zF_4EE17137_comptimeEvalEvaluat(zT_100, zT_101, zT_102);
    bnv = zT_104;
    zT_105 = bnv.has_value;
    if (zT_105) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    goto z_bb_15;
    z_bb_27:
    zT_124 = node.kind;
    if ((unsigned char)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_34; else goto z_bb_36;
    z_bb_28:
    if (!(bnv.has_value)) { pal_trap(); }
    bv = bnv.value;
    zT_107 = bv.kind;
    if ((unsigned char)(zT_107 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_123.has_value = 0;
    return zT_123;
    z_bb_30:
    zT_110.has_value = 0;
    return zT_110;
    z_bb_31:
    zT_112 = zF_DC9B7BC0_ciZeroInt();
    bnb = zT_112;
    zT_115 = bv.v;
    zT_113 = zT_115;
    zT_114 = (zT_0163D9A4_ComptimeInt*)&bnb;
    zT_117 = zF_223ABA6D_ciBitNot(zT_113, zT_114);
    if ((unsigned char)(!zT_117)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_119.has_value = 0;
    return zT_119;
    z_bb_33:
    zT_120 = bnb;
    zT_121 = zF_237A4571_ciIntVal(zT_120);
    zT_122.has_value = 1;
    zT_122.value = zT_121;
    return zT_122;
    z_bb_34:
    zT_128 = self;
    zT_129 = node_idx;
    zT_130 = node.kind;
    zT_131 = depth;
    zT_133 = zF_40F99F20_comptimeEvalLogical(zT_128, zT_129, zT_130, zT_131);
    return zT_133;
    z_bb_35:
    goto z_bb_26;
    z_bb_36:
    zT_134 = node.kind;
    if ((unsigned char)(zT_134 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_139 = node.kind;
    zT_138 = zT_139 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_39;
    z_bb_38:
    zT_138 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_138) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_144 = node.kind;
    zT_143 = zT_144 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_42;
    z_bb_41:
    zT_143 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_143) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_149 = node.kind;
    zT_148 = zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_45;
    z_bb_44:
    zT_148 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_148) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_154 = node.kind;
    zT_153 = zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_48;
    z_bb_47:
    zT_153 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_153) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_159 = node.kind;
    zT_158 = zT_159 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_51;
    z_bb_50:
    zT_158 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_158) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_164 = node.kind;
    zT_163 = zT_164 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_54;
    z_bb_53:
    zT_163 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_163) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_169 = node.kind;
    zT_168 = zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_57;
    z_bb_56:
    zT_168 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_168) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_174 = node.kind;
    zT_173 = zT_174 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_60;
    z_bb_59:
    zT_173 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_173) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_179 = node.kind;
    zT_178 = zT_179 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_63;
    z_bb_62:
    zT_178 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_178) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_183 = self;
    zT_184 = node_idx;
    zT_185 = node.kind;
    zT_186 = depth;
    zT_188 = zF_B36A4A25_comptimeEvalBinOp(zT_183, zT_184, zT_185, zT_186);
    return zT_188;
    z_bb_65:
    goto z_bb_35;
    z_bb_66:
    zT_189 = node.kind;
    if ((unsigned char)(zT_189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_194 = node.kind;
    zT_193 = zT_194 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_69;
    z_bb_68:
    zT_193 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_193) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_199 = node.kind;
    zT_198 = zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_72;
    z_bb_71:
    zT_198 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_198) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_204 = node.kind;
    zT_203 = zT_204 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_75;
    z_bb_74:
    zT_203 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_203) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_209 = node.kind;
    zT_208 = zT_209 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_78;
    z_bb_77:
    zT_208 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_208) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_214 = node.kind;
    zT_213 = zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_81;
    z_bb_80:
    zT_213 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_213) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    zT_218 = self;
    zT_219 = node_idx;
    zT_220 = node.kind;
    zT_221 = depth;
    zT_223 = zF_CD4BD838_comptimeEvalCompare(zT_218, zT_219, zT_220, zT_221);
    return zT_223;
    z_bb_83:
    goto z_bb_65;
    z_bb_84:
    zT_224 = node.kind;
    if ((unsigned char)(zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_229 = node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_87;
    z_bb_86:
    zT_228 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_228) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_233 = self;
    zT_234 = node_idx;
    zT_235 = node.kind;
    zT_236 = depth;
    zT_238 = zF_40F99F20_comptimeEvalLogical(zT_233, zT_234, zT_235, zT_236);
    return zT_238;
    z_bb_89:
    goto z_bb_83;
    z_bb_90:
    zT_239 = node.kind;
    if ((unsigned char)(zT_239 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_243 = self;
    zT_244 = node_idx;
    zT_245 = depth;
    zT_246 = zF_C37A1F7C_comptimeEvalBuiltin(zT_243, zT_244, zT_245);
    return zT_246;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_247 = node.kind;
    if ((unsigned char)(zT_247 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_94; else goto z_bb_96;
    z_bb_94:
    zT_251 = self;
    zT_254 = node.child_0;
    zT_253 = depth;
    self = zT_251;
    node_idx = zT_254;
    depth = zT_253;
    goto z_bb_0;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_256 = node.kind;
    if ((unsigned char)(zT_256 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_97; else goto z_bb_99;
    z_bb_97:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_100; else goto z_bb_101;
    goto z_bb_95;
    z_bb_99:
    zT_360.has_value = 0;
    return zT_360;
    z_bb_100:
    zT_262.has_value = 0;
    return zT_262;
    z_bb_101:
    zT_264 = self->store;
    zT_265 = node_idx;
    zT_267 = zF_53458827_astStoreIdentifier(zT_264, zT_265);
    name_id = zT_267;
    zT_268 = self->local_consts;
    zT_269 = zT_268.has_value;
    if (zT_269) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    if (!(zT_268.has_value)) { pal_trap(); }
    lcs = zT_268.value;
    zT_271 = lcs;
    zT_272 = name_id;
    zT_273 = zF_6532C387_localConstScopeLook(zT_271, zT_272);
    zT_274 = zT_273.has_value;
    if (zT_274) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    zT_304 = 0;
    zT_305 = (unsigned int)zT_304;
    mi = zT_305;
    goto z_bb_112;
    z_bb_104:
    if (!(zT_273.has_value)) { pal_trap(); }
    l_decl_node = zT_273.value;
    zT_277 = self->store;
    zT_278 = l_decl_node;
    zT_280 = zF_FCDD1D35_astStoreNodeAt(zT_277, zT_278);
    l_decl = zT_280;
    zT_281 = l_decl.child_1;
    if ((unsigned char)(zT_281 != (unsigned int)(0))) goto z_bb_106; else goto z_bb_107;
    z_bb_105:
    goto z_bb_103;
    z_bb_106:
    zT_285 = self;
    zT_286 = l_decl.child_1;
    zT_289 = 1;
    zT_290 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_289)), 32u);
    zT_291 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_289)), 32u);
    zT_293 = zT_291 == (unsigned int)(0);
    if (!(zT_293)) { pal_trap(); }
    zT_287 = zT_290;
    zT_294 = zF_4EE17137_comptimeEvalEvaluat(zT_285, zT_286, zT_287);
    lv = zT_294;
    zT_295 = lv.has_value;
    if (zT_295) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    if (!(lv.has_value)) { pal_trap(); }
    lvv = lv.value;
    zT_297 = self;
    zT_298 = l_decl_node;
    zT_299 = lvv;
    zT_300 = zF_EFA97F51_comptimeEvalDeclFit(zT_297, zT_298, zT_299);
    if ((unsigned char)(!zT_300)) goto z_bb_110; else goto z_bb_111;
    z_bb_109:
    return lv;
    z_bb_110:
    zT_302.has_value = 0;
    return zT_302;
    z_bb_111:
    goto z_bb_109;
    z_bb_112:
    zT_306 = self->symbol_reg;
    zT_307 = zT_306->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_307))) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_311 = self->symbol_reg;
    zT_313 = name_id;
    zT_316 = zF_A398987E_symbolRegistryQuali(zT_311, (unsigned int)((unsigned int)mi), zT_313);
    c_sym = zT_316;
    zT_317 = c_sym.has_value;
    if (zT_317) goto z_bb_116; else goto z_bb_117;
    z_bb_114:
    zT_359.has_value = 0;
    return zT_359;
    z_bb_115:
    zT_353 = 1;
    zT_354 = (unsigned int)zT_353;
    zT_355 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_354)), 32u);
    zT_356 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_354)), 32u);
    zT_358 = zT_356 == (unsigned int)(0);
    if (!(zT_358)) { pal_trap(); }
    mi = zT_355;
    goto z_bb_112;
    z_bb_116:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_319 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_319 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_118; else goto z_bb_119;
    z_bb_117:
    goto z_bb_115;
    z_bb_118:
    zT_325 = self->store;
    zT_326 = cs->decl_node;
    zT_329 = zF_FCDD1D35_astStoreNodeAt(zT_325, zT_326);
    c_decl = zT_329;
    zT_330 = c_decl.child_1;
    if ((unsigned char)(zT_330 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    goto z_bb_117;
    z_bb_120:
    zT_334 = self;
    zT_335 = c_decl.child_1;
    zT_338 = 1;
    zT_339 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_338)), 32u);
    zT_340 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_338)), 32u);
    zT_342 = zT_340 == (unsigned int)(0);
    if (!(zT_342)) { pal_trap(); }
    zT_336 = zT_339;
    zT_343 = zF_4EE17137_comptimeEvalEvaluat(zT_334, zT_335, zT_336);
    cv_1 = zT_343;
    zT_344 = cv_1.has_value;
    if (zT_344) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    if (!(cv_1.has_value)) { pal_trap(); }
    cvv = cv_1.value;
    zT_346 = self;
    zT_347 = cs->decl_node;
    zT_348 = cvv;
    zT_350 = zF_EFA97F51_comptimeEvalDeclFit(zT_346, zT_347, zT_348);
    if ((unsigned char)(!zT_350)) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    return cv_1;
    z_bb_124:
    zT_352.has_value = 0;
    return zT_352;
    z_bb_125:
    goto z_bb_123;
}

/* comptimeEvalDeclFits */
unsigned char zF_EFA97F51_comptimeEvalDeclFit(zT_DA663F79_ComptimeEval* self, unsigned int decl_node, zT_89B1DDDA_ComptimeVal v) {
    unsigned char zT_3;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11;
    unsigned int zT_12;
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    zT_BAEE192E_Opt_10 zT_19;
    unsigned char zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_0163D9A4_ComptimeInt zT_27;
    unsigned int zT_28;
    zT_0163D9A4_ComptimeInt zT_30;
    unsigned char zT_31;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zT_22A7C88B_AstNode d;
    unsigned int t;
    zT_3 = v.kind;
    if ((unsigned char)(zT_3 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = self->store;
    zT_9 = decl_node;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    d = zT_11;
    zT_12 = d.child_0;
    if ((unsigned char)(zT_12 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_16 = self;
    zT_17 = d.child_0;
    zT_19 = zF_BAD6BA5D_comptimeEvalResolve(zT_16, zT_17);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    if (!(zT_19.has_value)) { pal_trap(); }
    t = zT_19.value;
    zT_22 = self->registry;
    zT_23 = t;
    zT_25 = zF_3290E9C4_typeRegistryIsInteg(zT_22, zT_23);
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    zT_26 = self->registry;
    zT_30 = v.v;
    zT_27 = zT_30;
    zT_28 = t;
    zT_31 = zF_B28C4720_comptimeIntFitsType(zT_26, zT_27, zT_28);
    return zT_31;
    z_bb_8:
    goto z_bb_6;
}

/* EOF */
