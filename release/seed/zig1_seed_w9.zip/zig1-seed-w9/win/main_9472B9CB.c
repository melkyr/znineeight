#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char zT_38;
    zT_69057089_CompilerAlloc zT_40;
    zT_3E40CD83_Sand* zT_42;
    zT_69057089_CompilerAlloc* zT_44;
    int zT_46;
    zT_D3EB6303_StringInterner zT_48;
    zT_3E40CD83_Sand* zT_50;
    zT_69057089_CompilerAlloc* zT_51;
    zT_227EDE07_SourceManager zT_53;
    zT_3E40CD83_Sand* zT_55;
    zT_227EDE07_SourceManager* zT_56;
    zT_D3EB6303_StringInterner* zT_57;
    zT_69057089_CompilerAlloc* zT_58;
    zT_3E40CD83_Sand* zT_63;
    zT_69057089_CompilerAlloc* zT_64;
    unsigned char zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_77;
    int zT_78;
    unsigned char zT_80;
    unsigned char zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char zT_84;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned char zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_69057089_CompilerAlloc zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_3E40CD83_Sand* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    zT_69057089_CompilerAlloc* zT_126;
    zT_13E1F35B_Opt_482 zT_128;
    unsigned char zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_145;
    unsigned char zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned char zT_154;
    unsigned int zT_157;
    unsigned int zT_160;
    unsigned char zT_164;
    unsigned int zT_165;
    unsigned int zT_168;
    unsigned int zT_171;
    unsigned char zT_175;
    unsigned int zT_176;
    unsigned int zT_179;
    unsigned int zT_182;
    unsigned char zT_186;
    unsigned int zT_187;
    unsigned int zT_190;
    zT_3E40CD83_Sand* zT_192;
    unsigned int zT_193;
    zT_69057089_CompilerAlloc* zT_194;
    zT_D3EB6303_StringInterner zT_196;
    zT_3E40CD83_Sand* zT_198;
    zT_69057089_CompilerAlloc* zT_199;
    zT_227EDE07_SourceManager zT_201;
    zT_3E40CD83_Sand* zT_203;
    zT_227EDE07_SourceManager* zT_204;
    zT_D3EB6303_StringInterner* zT_205;
    zT_69057089_CompilerAlloc* zT_206;
    zT_F85C5DED_DiagnosticCollector zT_210;
    unsigned int zT_211;
    zT_3E40CD83_Sand* zT_213;
    zT_69057089_CompilerAlloc* zT_214;
    zT_3E40CD83_Sand* zT_217;
    zT_D3EB6303_StringInterner* zT_218;
    zT_F85C5DED_DiagnosticCollector* zT_219;
    zT_69057089_CompilerAlloc* zT_220;
    zT_072B53A6_ModuleRegistry zT_224;
    zT_072B53A6_ModuleRegistry* zT_225;
    zT_227EDE07_SourceManager* zT_226;
    zT_072B53A6_ModuleRegistry* zT_229;
    unsigned char zT_230;
    zT_7D82FE60_GrowableSand zT_234;
    unsigned char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_7D82FE60_GrowableSand* zT_239;
    zT_3E40CD83_Sand* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    zT_3E40CD83_Sand* zT_244;
    int zT_245;
    zT_3E40CD83_Sand* zT_248;
    zT_D3EB6303_StringInterner* zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_7D82FE60_GrowableSand* zT_252;
    zT_338B7C76_TypeRegistry zT_255;
    zT_338B7C76_TypeRegistry* zT_256;
    zT_3E40CD83_Sand* zT_259;
    zT_69057089_CompilerAlloc* zT_260;
    zT_6B0A7D14_AstStore zT_262;
    zT_846744CC_Arr_unsigned_char_5 zT_264;
    unsigned int zT_266;
    unsigned char zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_271;
    unsigned int zT_273;
    unsigned char zT_275;
    unsigned char* zT_278;
    unsigned int zT_279;
    unsigned char zT_280;
    unsigned char zT_281;
    unsigned char zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned char zT_288;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    unsigned char zT_294;
    unsigned char zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    unsigned char zT_301;
    unsigned char zT_302;
    unsigned char zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned char zT_309;
    unsigned char zT_310;
    unsigned char zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned char zT_317;
    unsigned char* zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned int zT_321;
    unsigned int zT_323;
    unsigned int zT_325;
    unsigned char zT_327;
    unsigned char* zT_330;
    unsigned int zT_331;
    unsigned char zT_332;
    unsigned char zT_333;
    unsigned char zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned char zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    unsigned char zT_345;
    zT_6B0A7D14_AstStore* zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    int zT_351;
    unsigned char* zT_352;
    unsigned int zT_353;
    unsigned char zT_354;
    unsigned char zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    zT_846744CC_Arr_unsigned_char_5 zT_358;
    unsigned int zT_360;
    unsigned char zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    unsigned int zT_365;
    unsigned int zT_367;
    unsigned char zT_369;
    unsigned char* zT_372;
    unsigned int zT_373;
    unsigned char zT_374;
    unsigned char zT_375;
    unsigned char zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned char zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned char zT_387;
    unsigned char zT_388;
    unsigned char zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    unsigned int zT_393;
    unsigned char zT_395;
    unsigned char zT_396;
    unsigned char zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    unsigned char zT_403;
    unsigned char zT_404;
    unsigned char zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned char zT_411;
    unsigned char* zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_415;
    unsigned int zT_417;
    unsigned int zT_419;
    unsigned char zT_421;
    unsigned char* zT_424;
    unsigned int zT_425;
    unsigned char zT_426;
    unsigned char zT_427;
    unsigned char zT_429;
    unsigned int zT_430;
    unsigned int zT_431;
    unsigned int zT_432;
    unsigned char zT_434;
    unsigned int zT_435;
    unsigned int zT_436;
    unsigned int zT_437;
    unsigned char zT_439;
    zT_6B0A7D14_AstStore* zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_442;
    int zT_447;
    unsigned char* zT_448;
    unsigned int zT_449;
    unsigned char zT_450;
    unsigned char zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    zT_846744CC_Arr_unsigned_char_5 zT_454;
    unsigned int zT_456;
    unsigned char zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_461;
    unsigned int zT_463;
    unsigned char zT_465;
    unsigned char* zT_468;
    unsigned int zT_469;
    unsigned char zT_470;
    unsigned char zT_471;
    unsigned char zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    unsigned char zT_478;
    unsigned int zT_479;
    unsigned int zT_480;
    unsigned int zT_481;
    unsigned char zT_483;
    unsigned char zT_484;
    unsigned char zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned int zT_489;
    unsigned char zT_491;
    unsigned char zT_492;
    unsigned char zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    unsigned int zT_497;
    unsigned char zT_499;
    unsigned char zT_500;
    unsigned char zT_502;
    unsigned int zT_503;
    unsigned int zT_504;
    unsigned int zT_505;
    unsigned char zT_507;
    unsigned char* zT_509;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_510;
    unsigned int zT_511;
    unsigned int zT_513;
    unsigned int zT_515;
    unsigned char zT_517;
    unsigned char* zT_520;
    unsigned int zT_521;
    unsigned char zT_522;
    unsigned char zT_523;
    unsigned char zT_525;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned char zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned char zT_535;
    zT_6B0A7D14_AstStore* zT_536;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    int zT_543;
    unsigned char* zT_544;
    unsigned int zT_545;
    unsigned char zT_546;
    unsigned char zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    zT_846744CC_Arr_unsigned_char_5 zT_550;
    unsigned int zT_552;
    unsigned char zT_553;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_557;
    unsigned int zT_559;
    unsigned char zT_561;
    unsigned char* zT_564;
    unsigned int zT_565;
    unsigned char zT_566;
    unsigned char zT_567;
    unsigned char zT_569;
    unsigned int zT_570;
    unsigned int zT_571;
    unsigned int zT_572;
    unsigned char zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    unsigned char zT_579;
    unsigned char zT_580;
    unsigned char zT_582;
    unsigned int zT_583;
    unsigned int zT_584;
    unsigned int zT_585;
    unsigned char zT_587;
    unsigned char zT_588;
    unsigned char zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned char zT_595;
    unsigned char zT_596;
    unsigned char zT_598;
    unsigned int zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned char zT_603;
    unsigned char* zT_605;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_606;
    unsigned int zT_607;
    unsigned int zT_609;
    unsigned int zT_611;
    unsigned char zT_613;
    unsigned char* zT_616;
    unsigned int zT_617;
    unsigned char zT_618;
    unsigned char zT_619;
    unsigned char zT_621;
    unsigned int zT_622;
    unsigned int zT_623;
    unsigned int zT_624;
    unsigned char zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    unsigned char zT_631;
    zT_6B0A7D14_AstStore* zT_632;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_634;
    int zT_639;
    unsigned char* zT_640;
    unsigned int zT_641;
    unsigned char zT_642;
    unsigned char zT_643;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_644;
    zT_846744CC_Arr_unsigned_char_5 zT_646;
    unsigned int zT_648;
    unsigned char zT_649;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_651;
    unsigned int zT_653;
    unsigned int zT_655;
    unsigned char zT_657;
    unsigned char* zT_660;
    unsigned int zT_661;
    unsigned char zT_662;
    unsigned char zT_663;
    unsigned char zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    unsigned int zT_668;
    unsigned char zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    unsigned int zT_673;
    unsigned char zT_675;
    unsigned char zT_676;
    unsigned char zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    unsigned int zT_681;
    unsigned char zT_683;
    unsigned char zT_684;
    unsigned char zT_686;
    unsigned int zT_687;
    unsigned int zT_688;
    unsigned int zT_689;
    unsigned char zT_691;
    unsigned char zT_692;
    unsigned char zT_694;
    unsigned int zT_695;
    unsigned int zT_696;
    unsigned int zT_697;
    unsigned char zT_699;
    unsigned char* zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    unsigned int zT_703;
    unsigned int zT_705;
    unsigned int zT_707;
    unsigned char zT_709;
    unsigned char* zT_712;
    unsigned int zT_713;
    unsigned char zT_714;
    unsigned char zT_715;
    unsigned char zT_717;
    unsigned int zT_718;
    unsigned int zT_719;
    unsigned int zT_720;
    unsigned char zT_722;
    unsigned int zT_723;
    unsigned int zT_724;
    unsigned int zT_725;
    unsigned char zT_727;
    zT_6B0A7D14_AstStore* zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_730;
    int zT_735;
    unsigned char* zT_736;
    unsigned int zT_737;
    unsigned char zT_738;
    unsigned char zT_739;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_740;
    zT_3E40CD83_Sand* zT_742;
    zT_69057089_CompilerAlloc* zT_743;
    zT_3D7259E2_SymbolRegistry zT_745;
    zT_3E40CD83_Sand* zT_747;
    zT_69057089_CompilerAlloc* zT_748;
    zT_8EED1867_ResolvedTypeTable zT_750;
    zT_846744CC_Arr_unsigned_char_5 zT_752;
    unsigned int zT_754;
    unsigned char zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_759;
    unsigned int zT_761;
    unsigned char zT_763;
    unsigned char* zT_766;
    unsigned int zT_767;
    unsigned char zT_768;
    unsigned char zT_769;
    unsigned char zT_771;
    unsigned int zT_772;
    unsigned int zT_773;
    unsigned int zT_774;
    unsigned char zT_776;
    unsigned int zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    unsigned char zT_781;
    unsigned char zT_782;
    unsigned char zT_784;
    unsigned int zT_785;
    unsigned int zT_786;
    unsigned int zT_787;
    unsigned char zT_789;
    unsigned char zT_790;
    unsigned char zT_792;
    unsigned int zT_793;
    unsigned int zT_794;
    unsigned int zT_795;
    unsigned char zT_797;
    unsigned char zT_798;
    unsigned char zT_800;
    unsigned int zT_801;
    unsigned int zT_802;
    unsigned int zT_803;
    unsigned char zT_805;
    unsigned char* zT_807;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_808;
    unsigned int zT_809;
    unsigned int zT_811;
    unsigned int zT_813;
    unsigned char zT_815;
    unsigned char* zT_818;
    unsigned int zT_819;
    unsigned char zT_820;
    unsigned char zT_821;
    unsigned char zT_823;
    unsigned int zT_824;
    unsigned int zT_825;
    unsigned int zT_826;
    unsigned char zT_828;
    unsigned int zT_829;
    unsigned int zT_830;
    unsigned int zT_831;
    unsigned char zT_833;
    zT_8EED1867_ResolvedTypeTable* zT_834;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_835;
    int zT_839;
    unsigned char* zT_840;
    unsigned int zT_841;
    unsigned char zT_842;
    unsigned char zT_843;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_844;
    zT_3E40CD83_Sand* zT_846;
    zT_69057089_CompilerAlloc* zT_847;
    zT_66E7D2EF_CoercionTable zT_849;
    zT_3E40CD83_Sand* zT_851;
    zT_69057089_CompilerAlloc* zT_852;
    zT_CA01C129_LirSlotArrayList zT_854;
    zT_3E40CD83_Sand* zT_856;
    zT_69057089_CompilerAlloc* zT_857;
    zT_4D61441E_DepGraph zT_859;
    zT_3E40CD83_Sand* zT_861;
    zT_69057089_CompilerAlloc* zT_862;
    zT_21D3708C_U32ToU32Map zT_864;
    zT_3E40CD83_Sand* zT_866;
    zT_69057089_CompilerAlloc* zT_867;
    zT_21D3708C_U32ToU32Map zT_869;
    zT_3E40CD83_Sand* zT_871;
    zT_69057089_CompilerAlloc* zT_872;
    zT_21D3708C_U32ToU32Map zT_874;
    zT_3E40CD83_Sand* zT_876;
    zT_69057089_CompilerAlloc* zT_877;
    zT_21D3708C_U32ToU32Map zT_879;
    zT_3E40CD83_Sand* zT_881;
    zT_69057089_CompilerAlloc* zT_882;
    zT_21D3708C_U32ToU32Map zT_884;
    zT_3E40CD83_Sand* zT_886;
    zT_69057089_CompilerAlloc* zT_888;
    zT_77F6F59C_ComptimeFoldTable zT_891;
    zT_3E40CD83_Sand* zT_893;
    zT_69057089_CompilerAlloc* zT_894;
    zT_4065182A_ConstInitTable zT_896;
    zT_786E6CF2_EmissionClassificat zT_898;
    zT_3E40CD83_Sand* zT_899;
    zT_69057089_CompilerAlloc* zT_900;
    zT_21D3708C_U32ToU32Map zT_902;
    zT_3E40CD83_Sand* zT_903;
    zT_69057089_CompilerAlloc* zT_904;
    zT_21D3708C_U32ToU32Map zT_906;
    zT_3E40CD83_Sand* zT_907;
    zT_69057089_CompilerAlloc* zT_908;
    zT_21D3708C_U32ToU32Map zT_910;
    zT_3E40CD83_Sand* zT_911;
    zT_69057089_CompilerAlloc* zT_912;
    zT_21D3708C_U32ToU32Map zT_914;
    zT_1317DCD6_C89SpellPlan zT_916;
    zT_3E40CD83_Sand* zT_918;
    zT_69057089_CompilerAlloc* zT_919;
    zT_A4CE86B7_U64ToU32Map zT_921;
    zT_3E40CD83_Sand* zT_923;
    zT_69057089_CompilerAlloc* zT_924;
    zT_A4CE86B7_U64ToU32Map zT_926;
    zT_3E40CD83_Sand* zT_928;
    zT_69057089_CompilerAlloc* zT_929;
    zT_A4CE86B7_U64ToU32Map zT_931;
    zT_3E40CD83_Sand* zT_933;
    zT_69057089_CompilerAlloc* zT_934;
    zT_A4CE86B7_U64ToU32Map zT_936;
    zT_3E40CD83_Sand* zT_938;
    zT_69057089_CompilerAlloc* zT_939;
    zT_A4CE86B7_U64ToU32Map zT_941;
    zT_3E40CD83_Sand* zT_943;
    zT_69057089_CompilerAlloc* zT_944;
    zT_A4CE86B7_U64ToU32Map zT_946;
    zT_3E40CD83_Sand* zT_948;
    zT_69057089_CompilerAlloc* zT_949;
    zT_A4CE86B7_U64ToU32Map zT_951;
    zT_3E40CD83_Sand* zT_953;
    zT_69057089_CompilerAlloc* zT_954;
    zT_B687BB96_U32ArrayList zT_956;
    zT_3E40CD83_Sand* zT_958;
    zT_69057089_CompilerAlloc* zT_959;
    zT_A4CE86B7_U64ToU32Map zT_961;
    zT_3E40CD83_Sand* zT_963;
    zT_69057089_CompilerAlloc* zT_964;
    zT_A4CE86B7_U64ToU32Map zT_966;
    zT_3E40CD83_Sand* zT_968;
    zT_69057089_CompilerAlloc* zT_969;
    zT_A4CE86B7_U64ToU32Map zT_971;
    zT_5AB29387_CompilerContext zT_973;
    zT_69057089_CompilerAlloc* zT_974;
    zT_D3EB6303_StringInterner* zT_975;
    zT_F85C5DED_DiagnosticCollector* zT_976;
    zT_227EDE07_SourceManager* zT_977;
    zT_072B53A6_ModuleRegistry* zT_978;
    zT_338B7C76_TypeRegistry* zT_979;
    zT_6B0A7D14_AstStore* zT_980;
    zT_3D7259E2_SymbolRegistry* zT_981;
    zT_8EED1867_ResolvedTypeTable* zT_982;
    zT_66E7D2EF_CoercionTable* zT_983;
    zT_4D61441E_DepGraph* zT_984;
    zT_7E7544E4_LirStream zT_985;
    zT_3E40CD83_Sand* zT_986;
    zT_69057089_CompilerAlloc* zT_987;
    zT_E1A783EF_GlobalDeclArrayList zT_989;
    zT_3E40CD83_Sand* zT_990;
    zT_69057089_CompilerAlloc* zT_991;
    zT_A4CE86B7_U64ToU32Map zT_993;
    zT_3E40CD83_Sand* zT_994;
    zT_69057089_CompilerAlloc* zT_995;
    zT_B687BB96_U32ArrayList zT_997;
    zT_C615AE29_DebugSpanStore zT_998;
    zT_3E40CD83_Sand* zT_999;
    zT_69057089_CompilerAlloc* zT_1000;
    zT_8B83E3B4_DebugSymbolList zT_1002;
    zT_DEDDFC41_DebugMapWriter zT_1003;
    zT_3E40CD83_Sand* zT_1004;
    zT_69057089_CompilerAlloc* zT_1005;
    zT_1F328BC1_DebugSpanArrayList zT_1007;
    zT_5AB29387_CompilerContext* zT_1008;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_128, (unsigned int)sizeof zT_128);
    zig_poison_fill((void*)&zT_196, (unsigned int)sizeof zT_196);
    zig_poison_fill((void*)&zT_201, (unsigned int)sizeof zT_201);
    zig_poison_fill((void*)&zT_210, (unsigned int)sizeof zT_210);
    zig_poison_fill((void*)&zT_224, (unsigned int)sizeof zT_224);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_255, (unsigned int)sizeof zT_255);
    zig_poison_fill((void*)&zT_262, (unsigned int)sizeof zT_262);
    zig_poison_fill((void*)&zT_745, (unsigned int)sizeof zT_745);
    zig_poison_fill((void*)&zT_750, (unsigned int)sizeof zT_750);
    zig_poison_fill((void*)&zT_849, (unsigned int)sizeof zT_849);
    zig_poison_fill((void*)&zT_854, (unsigned int)sizeof zT_854);
    zig_poison_fill((void*)&zT_859, (unsigned int)sizeof zT_859);
    zig_poison_fill((void*)&zT_864, (unsigned int)sizeof zT_864);
    zig_poison_fill((void*)&zT_869, (unsigned int)sizeof zT_869);
    zig_poison_fill((void*)&zT_874, (unsigned int)sizeof zT_874);
    zig_poison_fill((void*)&zT_879, (unsigned int)sizeof zT_879);
    zig_poison_fill((void*)&zT_884, (unsigned int)sizeof zT_884);
    zig_poison_fill((void*)&zT_891, (unsigned int)sizeof zT_891);
    zig_poison_fill((void*)&zT_896, (unsigned int)sizeof zT_896);
    zig_poison_fill((void*)&zT_902, (unsigned int)sizeof zT_902);
    zig_poison_fill((void*)&zT_906, (unsigned int)sizeof zT_906);
    zig_poison_fill((void*)&zT_910, (unsigned int)sizeof zT_910);
    zig_poison_fill((void*)&zT_914, (unsigned int)sizeof zT_914);
    zig_poison_fill((void*)&zT_921, (unsigned int)sizeof zT_921);
    zig_poison_fill((void*)&zT_926, (unsigned int)sizeof zT_926);
    zig_poison_fill((void*)&zT_931, (unsigned int)sizeof zT_931);
    zig_poison_fill((void*)&zT_936, (unsigned int)sizeof zT_936);
    zig_poison_fill((void*)&zT_941, (unsigned int)sizeof zT_941);
    zig_poison_fill((void*)&zT_946, (unsigned int)sizeof zT_946);
    zig_poison_fill((void*)&zT_951, (unsigned int)sizeof zT_951);
    zig_poison_fill((void*)&zT_956, (unsigned int)sizeof zT_956);
    zig_poison_fill((void*)&zT_961, (unsigned int)sizeof zT_961);
    zig_poison_fill((void*)&zT_966, (unsigned int)sizeof zT_966);
    zig_poison_fill((void*)&zT_971, (unsigned int)sizeof zT_971);
    zig_poison_fill((void*)&zT_985, (unsigned int)sizeof zT_985);
    zig_poison_fill((void*)&zT_989, (unsigned int)sizeof zT_989);
    zig_poison_fill((void*)&zT_993, (unsigned int)sizeof zT_993);
    zig_poison_fill((void*)&zT_997, (unsigned int)sizeof zT_997);
    zig_poison_fill((void*)&zT_998, (unsigned int)sizeof zT_998);
    zig_poison_fill((void*)&zT_1002, (unsigned int)sizeof zT_1002);
    zig_poison_fill((void*)&zT_1003, (unsigned int)sizeof zT_1003);
    zig_poison_fill((void*)&zT_1007, (unsigned int)sizeof zT_1007);
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_8F083A69_Slice_zT_0B42B2F8_u bon;
    zT_8F083A69_Slice_zT_0B42B2F8_u boff;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    unsigned int type_hint;
    unsigned int name_hint;
    unsigned int fold_hint;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map tuple_index_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_4065182A_ConstInitTable const_inits;
    zT_786E6CF2_EmissionClassificat emission_classif;
    zT_1317DCD6_C89SpellPlan spell_plan_ph;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.quiet;
    if ((unsigned char)(!zT_14)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = cli.debug;
    if (zT_16) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_27 = cli.debug;
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_18 = "Z98 Compiler 2026 (map: on)\n";
    zT_20 = 28;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    bon = zT_19;
    zT_21 = bon;
    zF_E4B2EF19_stderr_write(zT_21);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_23 = "Z98 Compiler 2026 (map: off)\n";
    zT_25 = 29;
    zT_24.ptr = (unsigned char*)zT_23;
    zT_24.len = zT_25;
    boff = zT_24;
    zT_26 = boff;
    zF_E4B2EF19_stderr_write(zT_26);
    goto z_bb_6;
    z_bb_8:
    zT_29 = cli.output_dir_set;
    zT_28 = !zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_28 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_28) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = "error: --debug/-d requires --output-dir\n";
    zT_34 = 40;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    dmsg = zT_33;
    zT_35 = dmsg;
    zF_E4B2EF19_stderr_write(zT_35);
    zF_CDED1A85_exit((unsigned char)(2));
    return;
    z_bb_12:
    zT_38 = cli.sanity_test_mode;
    if (zT_38) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_40 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_40;
    zT_44 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_42 = &zT_44->permanent;
    zT_46 = 4;
    zT_48 = zF_FB2E811D_stringInternerInit(zT_42, (unsigned int)((unsigned int)zT_46));
    interner = zT_48;
    zT_51 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_50 = &zT_51->permanent;
    zT_53 = zF_01351F51_sourceManagerInit(zT_50);
    source_man = zT_53;
    zT_58 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_55 = &zT_58->permanent;
    zT_56 = (zT_227EDE07_SourceManager*)&source_man;
    zT_57 = (zT_D3EB6303_StringInterner*)&interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_55, zT_56, zT_57);
    zT_64 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_63 = &zT_64->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_63);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_14:
    zT_66 = cli.test_mode;
    if (zT_66) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_68 = "error: use test_main.zig for test mode\n";
    zT_70 = 39;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    msg = zT_69;
    zT_71 = msg;
    zF_48AC7B3A_markerWrite(zT_71);
    zT_73 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_73));
    return;
    z_bb_16:
    zT_75 = cli.input_file;
    zT_77 = zT_75.len;
    zT_78 = 0;
    if ((unsigned char)(zT_77 == (unsigned int)zT_78)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_18:
    zT_80 = cli.output_dir_set;
    if (zT_80) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_83 = cli.output_dir;
    zT_82 = zT_83;
    zT_84 = zF_8CC05F84_dirExists(zT_82);
    zT_81 = !zT_84;
    goto z_bb_21;
    z_bb_20:
    zT_81 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_81) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_87 = "error: output directory does not exist: ";
    zT_89 = 40;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    msg = zT_88;
    zT_90 = msg;
    zF_E4B2EF19_stderr_write(zT_90);
    zT_92 = cli.output_dir;
    zT_91 = zT_92;
    zF_E4B2EF19_stderr_write(zT_91);
    zT_94 = "\n";
    zT_96 = 1;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    nl = zT_95;
    zT_97 = nl;
    zF_E4B2EF19_stderr_write(zT_97);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_23:
    zT_101 = cli.input_file;
    zT_100 = zT_101;
    zT_102 = zF_5FF93310_isReservedDosDevice(zT_100);
    if (zT_102) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_104 = "error: reserved DOS device name in input file path: ";
    zT_106 = 52;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    msg = zT_105;
    zT_107 = msg;
    zF_E4B2EF19_stderr_write(zT_107);
    zT_109 = cli.input_file;
    zT_108 = zT_109;
    zF_E4B2EF19_stderr_write(zT_108);
    zT_111 = "\n";
    zT_113 = 1;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    nl = zT_112;
    zT_114 = nl;
    zF_E4B2EF19_stderr_write(zT_114);
    zF_CDED1A85_exit((unsigned char)(2));
    return;
    z_bb_25:
    zT_118 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_118;
    zT_119 = cli.max_mem;
    compiler_alloc.max_mem = zT_119;
    zT_120 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_120);
    zT_125 = cli.input_file;
    zT_123 = zT_125;
    zT_126 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_124 = &zT_126->scratch;
    zT_128 = zF_5B859C63_readFile(zT_123, zT_124);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_133 = "error: could not read input file\n";
    zT_135 = 33;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    msg = zT_134;
    zT_136 = msg;
    zF_E4B2EF19_stderr_write(zT_136);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_27:
    if (!(zT_128.has_value)) { pal_trap(); }
    zT_139 = zT_128.value;
    zT_130 = zT_139;
    goto z_bb_28;
    z_bb_28:
    source = zT_130;
    zT_142 = source.len;
    zT_143 = (unsigned int)zT_142;
    zT_145 = source.len;
    zT_149 = 1;
    if (!(zT_149)) { pal_trap(); }
    zT_150 = (unsigned int)(unsigned int)(zT_145 / (unsigned int)(4));
    zT_151 = zig_wrap_add_u(((zu64)(zT_143)), ((zu64)(zT_150)), 32u);
    zT_152 = zig_overflow_flag_add_u(((zu64)(zT_143)), ((zu64)(zT_150)), 32u);
    zT_154 = zT_152 == (unsigned int)(0);
    if (!(zT_154)) { pal_trap(); }
    interner_bc = zT_151;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_157 = 4096;
    interner_bc = zT_157;
    goto z_bb_30;
    z_bb_30:
    zT_160 = source.len;
    zT_164 = 1;
    if (!(zT_164)) { pal_trap(); }
    zT_165 = (unsigned int)(unsigned int)(zT_160 / (unsigned int)(32));
    type_hint = zT_165;
    if ((unsigned char)(type_hint < (unsigned int)(4096))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_168 = 4096;
    type_hint = zT_168;
    goto z_bb_32;
    z_bb_32:
    zT_171 = source.len;
    zT_175 = 1;
    if (!(zT_175)) { pal_trap(); }
    zT_176 = (unsigned int)(unsigned int)(zT_171 / (unsigned int)(10));
    name_hint = zT_176;
    if ((unsigned char)(name_hint < (unsigned int)(2048))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_179 = 2048;
    name_hint = zT_179;
    goto z_bb_34;
    z_bb_34:
    zT_182 = source.len;
    zT_186 = 1;
    if (!(zT_186)) { pal_trap(); }
    zT_187 = (unsigned int)(unsigned int)(zT_182 / (unsigned int)(9));
    fold_hint = zT_187;
    if ((unsigned char)(fold_hint < (unsigned int)(16))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_190 = 16;
    fold_hint = zT_190;
    goto z_bb_36;
    z_bb_36:
    zT_194 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_192 = &zT_194->permanent;
    zT_193 = interner_bc;
    zT_196 = zF_FB2E811D_stringInternerInit(zT_192, zT_193);
    interner = zT_196;
    zT_199 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_198 = &zT_199->permanent;
    zT_201 = zF_01351F51_sourceManagerInit(zT_198);
    source_man = zT_201;
    zT_206 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_203 = &zT_206->permanent;
    zT_204 = (zT_227EDE07_SourceManager*)&source_man;
    zT_205 = (zT_D3EB6303_StringInterner*)&interner;
    zT_210 = zF_C7BA7DAB_diagnosticCollector(zT_203, zT_204, zT_205);
    diag = zT_210;
    zT_211 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_211);
    zT_214 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_213 = &zT_214->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_213);
    zT_220 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_217 = &zT_220->permanent;
    zT_218 = (zT_D3EB6303_StringInterner*)&interner;
    zT_219 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_224 = zF_896FAF3C_moduleRegistryInit(zT_217, zT_218, zT_219);
    mr = zT_224;
    zT_225 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_226 = (zT_227EDE07_SourceManager*)&source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_225, zT_226);
    zT_229 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_230 = cli.target_is_windows;
    zF_849BBF28_moduleRegistrySetTa(zT_229, zT_230);
    zig_poison_fill((void*)&zT_234, (unsigned int)sizeof zT_234);
    type_db_arena = zT_234;
    zT_236 = "type_db";
    zT_238 = 7;
    zT_237.ptr = (unsigned char*)zT_236;
    zT_237.len = zT_238;
    type_db_name = zT_237;
    zT_239 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_244 = zF_8C23960F_poolPtr();
    zT_240 = zT_244;
    zT_245 = 4096;
    zT_242 = type_db_name;
    zF_07B11742_growableSandInit(zT_239, zT_240, (unsigned int)((unsigned int)zT_245), zT_242);
    zT_252 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_248 = &zT_252->view;
    zT_249 = (zT_D3EB6303_StringInterner*)&interner;
    zT_250 = type_hint;
    zT_251 = name_hint;
    zT_255 = zF_28AE6613_typeRegistryInitSiz(zT_248, zT_249, zT_250, zT_251);
    typereg = zT_255;
    zT_256 = (zT_338B7C76_TypeRegistry*)&typereg;
    zF_541737A5_typeRegistryRegiste(zT_256);
    zT_260 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_259 = &zT_260->module;
    zT_262 = zF_D9F91436_astStoreInit(zT_259);
    store = zT_262;
    zig_poison_fill((void*)&zT_264, (unsigned int)sizeof zT_264);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_264[_i];
        _i++;
    }
}
    zT_266 = 0;
    asp_len = zT_266;
    zT_267 = cli.output_dir_set;
    if (zT_267) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_269 = cli.output_dir;
    od2 = zT_269;
    zT_271 = 0;
    oi2 = zT_271;
    goto z_bb_40;
    z_bb_38:
    zT_319 = ".zig1_ast.tmp";
    zT_321 = 13;
    zT_320.ptr = (unsigned char*)zT_319;
    zT_320.len = zT_321;
    ast_tmp_name = zT_320;
    zT_323 = 0;
    ati = zT_323;
    goto z_bb_47;
    z_bb_39:
    zT_302 = 46;
    zT_304 = asp_len < (unsigned int)(512);
    if (!(zT_304)) { pal_trap(); }
    ast_spill_path[asp_len] = zT_302;
    zT_305 = 1;
    zT_306 = zig_wrap_add_u(((zu64)(asp_len)), ((zu64)(zT_305)), 32u);
    zT_307 = zig_overflow_flag_add_u(((zu64)(asp_len)), ((zu64)(zT_305)), 32u);
    zT_309 = zT_307 == (unsigned int)(0);
    if (!(zT_309)) { pal_trap(); }
    asp_len = zT_306;
    zT_310 = 47;
    zT_312 = asp_len < (unsigned int)(512);
    if (!(zT_312)) { pal_trap(); }
    ast_spill_path[asp_len] = zT_310;
    zT_313 = 1;
    zT_314 = zig_wrap_add_u(((zu64)(asp_len)), ((zu64)(zT_313)), 32u);
    zT_315 = zig_overflow_flag_add_u(((zu64)(asp_len)), ((zu64)(zT_313)), 32u);
    zT_317 = zT_315 == (unsigned int)(0);
    if (!(zT_317)) { pal_trap(); }
    asp_len = zT_314;
    goto z_bb_38;
    z_bb_40:
    zT_273 = od2.len;
    if ((unsigned char)(oi2 < zT_273)) goto z_bb_44; else goto z_bb_45;
    z_bb_41:
    zT_278 = od2.ptr;
    zT_279 = od2.len;
    zT_280 = oi2 < zT_279;
    if (!(zT_280)) { pal_trap(); }
    zT_281 = zT_278[oi2];
    zT_283 = asp_len < (unsigned int)(512);
    if (!(zT_283)) { pal_trap(); }
    ast_spill_path[asp_len] = zT_281;
    zT_284 = 1;
    zT_285 = zig_wrap_add_u(((zu64)(asp_len)), ((zu64)(zT_284)), 32u);
    zT_286 = zig_overflow_flag_add_u(((zu64)(asp_len)), ((zu64)(zT_284)), 32u);
    zT_288 = zT_286 == (unsigned int)(0);
    if (!(zT_288)) { pal_trap(); }
    asp_len = zT_285;
    goto z_bb_43;
    z_bb_42:
    zT_294 = 47;
    zT_296 = asp_len < (unsigned int)(512);
    if (!(zT_296)) { pal_trap(); }
    ast_spill_path[asp_len] = zT_294;
    zT_297 = 1;
    zT_298 = zig_wrap_add_u(((zu64)(asp_len)), ((zu64)(zT_297)), 32u);
    zT_299 = zig_overflow_flag_add_u(((zu64)(asp_len)), ((zu64)(zT_297)), 32u);
    zT_301 = zT_299 == (unsigned int)(0);
    if (!(zT_301)) { pal_trap(); }
    asp_len = zT_298;
    goto z_bb_38;
    z_bb_43:
    zT_289 = 1;
    zT_290 = zig_wrap_add_u(((zu64)(oi2)), ((zu64)(zT_289)), 32u);
    zT_291 = zig_overflow_flag_add_u(((zu64)(oi2)), ((zu64)(zT_289)), 32u);
    zT_293 = zT_291 == (unsigned int)(0);
    if (!(zT_293)) { pal_trap(); }
    oi2 = zT_290;
    goto z_bb_40;
    z_bb_44:
    zT_275 = asp_len < (unsigned int)(511);
    goto z_bb_46;
    z_bb_45:
    zT_275 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_275) goto z_bb_41; else goto z_bb_42;
    z_bb_47:
    zT_325 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_325)) goto z_bb_51; else goto z_bb_52;
    z_bb_48:
    zT_330 = ast_tmp_name.ptr;
    zT_331 = ast_tmp_name.len;
    zT_332 = ati < zT_331;
    if (!(zT_332)) { pal_trap(); }
    zT_333 = zT_330[ati];
    zT_335 = asp_len < (unsigned int)(512);
    if (!(zT_335)) { pal_trap(); }
    ast_spill_path[asp_len] = zT_333;
    zT_336 = 1;
    zT_337 = zig_wrap_add_u(((zu64)(asp_len)), ((zu64)(zT_336)), 32u);
    zT_338 = zig_overflow_flag_add_u(((zu64)(asp_len)), ((zu64)(zT_336)), 32u);
    zT_340 = zT_338 == (unsigned int)(0);
    if (!(zT_340)) { pal_trap(); }
    asp_len = zT_337;
    goto z_bb_50;
    z_bb_49:
    zT_346 = (zT_6B0A7D14_AstStore*)&store;
    zT_351 = 0;
    zT_352 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_351;
    zT_353 = asp_len - zT_351;
    zT_354 = (unsigned int)zT_351 <= asp_len;
    if (!(zT_354)) { pal_trap(); }
    zT_355 = asp_len <= (unsigned int)(512);
    if (!(zT_355)) { pal_trap(); }
    zT_356.ptr = (unsigned char*)zT_352;
    zT_356.len = zT_353;
    zT_347 = zT_356;
    zF_2A507339_astStoreSetSpillPat(zT_346, zT_347);
    zig_poison_fill((void*)&zT_358, (unsigned int)sizeof zT_358);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_358[_i];
        _i++;
    }
}
    zT_360 = 0;
    idp_len = zT_360;
    zT_361 = cli.output_dir_set;
    if (zT_361) goto z_bb_54; else goto z_bb_56;
    z_bb_50:
    zT_341 = 1;
    zT_342 = zig_wrap_add_u(((zu64)(ati)), ((zu64)(zT_341)), 32u);
    zT_343 = zig_overflow_flag_add_u(((zu64)(ati)), ((zu64)(zT_341)), 32u);
    zT_345 = zT_343 == (unsigned int)(0);
    if (!(zT_345)) { pal_trap(); }
    ati = zT_342;
    goto z_bb_47;
    z_bb_51:
    zT_327 = asp_len < (unsigned int)(511);
    goto z_bb_53;
    z_bb_52:
    zT_327 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_327) goto z_bb_48; else goto z_bb_49;
    z_bb_54:
    zT_363 = cli.output_dir;
    od3 = zT_363;
    zT_365 = 0;
    oi3 = zT_365;
    goto z_bb_57;
    z_bb_55:
    zT_413 = ".zig1_side.tmp";
    zT_415 = 14;
    zT_414.ptr = (unsigned char*)zT_413;
    zT_414.len = zT_415;
    id_tmp_name = zT_414;
    zT_417 = 0;
    iti = zT_417;
    goto z_bb_64;
    z_bb_56:
    zT_396 = 46;
    zT_398 = idp_len < (unsigned int)(512);
    if (!(zT_398)) { pal_trap(); }
    id_spill_path[idp_len] = zT_396;
    zT_399 = 1;
    zT_400 = zig_wrap_add_u(((zu64)(idp_len)), ((zu64)(zT_399)), 32u);
    zT_401 = zig_overflow_flag_add_u(((zu64)(idp_len)), ((zu64)(zT_399)), 32u);
    zT_403 = zT_401 == (unsigned int)(0);
    if (!(zT_403)) { pal_trap(); }
    idp_len = zT_400;
    zT_404 = 47;
    zT_406 = idp_len < (unsigned int)(512);
    if (!(zT_406)) { pal_trap(); }
    id_spill_path[idp_len] = zT_404;
    zT_407 = 1;
    zT_408 = zig_wrap_add_u(((zu64)(idp_len)), ((zu64)(zT_407)), 32u);
    zT_409 = zig_overflow_flag_add_u(((zu64)(idp_len)), ((zu64)(zT_407)), 32u);
    zT_411 = zT_409 == (unsigned int)(0);
    if (!(zT_411)) { pal_trap(); }
    idp_len = zT_408;
    goto z_bb_55;
    z_bb_57:
    zT_367 = od3.len;
    if ((unsigned char)(oi3 < zT_367)) goto z_bb_61; else goto z_bb_62;
    z_bb_58:
    zT_372 = od3.ptr;
    zT_373 = od3.len;
    zT_374 = oi3 < zT_373;
    if (!(zT_374)) { pal_trap(); }
    zT_375 = zT_372[oi3];
    zT_377 = idp_len < (unsigned int)(512);
    if (!(zT_377)) { pal_trap(); }
    id_spill_path[idp_len] = zT_375;
    zT_378 = 1;
    zT_379 = zig_wrap_add_u(((zu64)(idp_len)), ((zu64)(zT_378)), 32u);
    zT_380 = zig_overflow_flag_add_u(((zu64)(idp_len)), ((zu64)(zT_378)), 32u);
    zT_382 = zT_380 == (unsigned int)(0);
    if (!(zT_382)) { pal_trap(); }
    idp_len = zT_379;
    goto z_bb_60;
    z_bb_59:
    zT_388 = 47;
    zT_390 = idp_len < (unsigned int)(512);
    if (!(zT_390)) { pal_trap(); }
    id_spill_path[idp_len] = zT_388;
    zT_391 = 1;
    zT_392 = zig_wrap_add_u(((zu64)(idp_len)), ((zu64)(zT_391)), 32u);
    zT_393 = zig_overflow_flag_add_u(((zu64)(idp_len)), ((zu64)(zT_391)), 32u);
    zT_395 = zT_393 == (unsigned int)(0);
    if (!(zT_395)) { pal_trap(); }
    idp_len = zT_392;
    goto z_bb_55;
    z_bb_60:
    zT_383 = 1;
    zT_384 = zig_wrap_add_u(((zu64)(oi3)), ((zu64)(zT_383)), 32u);
    zT_385 = zig_overflow_flag_add_u(((zu64)(oi3)), ((zu64)(zT_383)), 32u);
    zT_387 = zT_385 == (unsigned int)(0);
    if (!(zT_387)) { pal_trap(); }
    oi3 = zT_384;
    goto z_bb_57;
    z_bb_61:
    zT_369 = idp_len < (unsigned int)(511);
    goto z_bb_63;
    z_bb_62:
    zT_369 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_369) goto z_bb_58; else goto z_bb_59;
    z_bb_64:
    zT_419 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_419)) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_424 = id_tmp_name.ptr;
    zT_425 = id_tmp_name.len;
    zT_426 = iti < zT_425;
    if (!(zT_426)) { pal_trap(); }
    zT_427 = zT_424[iti];
    zT_429 = idp_len < (unsigned int)(512);
    if (!(zT_429)) { pal_trap(); }
    id_spill_path[idp_len] = zT_427;
    zT_430 = 1;
    zT_431 = zig_wrap_add_u(((zu64)(idp_len)), ((zu64)(zT_430)), 32u);
    zT_432 = zig_overflow_flag_add_u(((zu64)(idp_len)), ((zu64)(zT_430)), 32u);
    zT_434 = zT_432 == (unsigned int)(0);
    if (!(zT_434)) { pal_trap(); }
    idp_len = zT_431;
    goto z_bb_67;
    z_bb_66:
    zT_440 = (zT_6B0A7D14_AstStore*)&store;
    zT_447 = 0;
    zT_448 = (unsigned char*)((unsigned char*)id_spill_path) + zT_447;
    zT_449 = idp_len - zT_447;
    zT_450 = (unsigned int)zT_447 <= idp_len;
    if (!(zT_450)) { pal_trap(); }
    zT_451 = idp_len <= (unsigned int)(512);
    if (!(zT_451)) { pal_trap(); }
    zT_452.ptr = (unsigned char*)zT_448;
    zT_452.len = zT_449;
    zT_442 = zT_452;
    zF_35B9B6EC_astStoreSetValuePoo(zT_440, (unsigned int)(0), zT_442);
    zig_poison_fill((void*)&zT_454, (unsigned int)sizeof zT_454);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_454[_i];
        _i++;
    }
}
    zT_456 = 0;
    ivp_len = zT_456;
    zT_457 = cli.output_dir_set;
    if (zT_457) goto z_bb_71; else goto z_bb_73;
    z_bb_67:
    zT_435 = 1;
    zT_436 = zig_wrap_add_u(((zu64)(iti)), ((zu64)(zT_435)), 32u);
    zT_437 = zig_overflow_flag_add_u(((zu64)(iti)), ((zu64)(zT_435)), 32u);
    zT_439 = zT_437 == (unsigned int)(0);
    if (!(zT_439)) { pal_trap(); }
    iti = zT_436;
    goto z_bb_64;
    z_bb_68:
    zT_421 = idp_len < (unsigned int)(511);
    goto z_bb_70;
    z_bb_69:
    zT_421 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_421) goto z_bb_65; else goto z_bb_66;
    z_bb_71:
    zT_459 = cli.output_dir;
    od5 = zT_459;
    zT_461 = 0;
    oi5 = zT_461;
    goto z_bb_74;
    z_bb_72:
    zT_509 = ".zig1_side_iv.tmp";
    zT_511 = 17;
    zT_510.ptr = (unsigned char*)zT_509;
    zT_510.len = zT_511;
    iv_tmp_name = zT_510;
    zT_513 = 0;
    ivi = zT_513;
    goto z_bb_81;
    z_bb_73:
    zT_492 = 46;
    zT_494 = ivp_len < (unsigned int)(512);
    if (!(zT_494)) { pal_trap(); }
    iv_spill_path[ivp_len] = zT_492;
    zT_495 = 1;
    zT_496 = zig_wrap_add_u(((zu64)(ivp_len)), ((zu64)(zT_495)), 32u);
    zT_497 = zig_overflow_flag_add_u(((zu64)(ivp_len)), ((zu64)(zT_495)), 32u);
    zT_499 = zT_497 == (unsigned int)(0);
    if (!(zT_499)) { pal_trap(); }
    ivp_len = zT_496;
    zT_500 = 47;
    zT_502 = ivp_len < (unsigned int)(512);
    if (!(zT_502)) { pal_trap(); }
    iv_spill_path[ivp_len] = zT_500;
    zT_503 = 1;
    zT_504 = zig_wrap_add_u(((zu64)(ivp_len)), ((zu64)(zT_503)), 32u);
    zT_505 = zig_overflow_flag_add_u(((zu64)(ivp_len)), ((zu64)(zT_503)), 32u);
    zT_507 = zT_505 == (unsigned int)(0);
    if (!(zT_507)) { pal_trap(); }
    ivp_len = zT_504;
    goto z_bb_72;
    z_bb_74:
    zT_463 = od5.len;
    if ((unsigned char)(oi5 < zT_463)) goto z_bb_78; else goto z_bb_79;
    z_bb_75:
    zT_468 = od5.ptr;
    zT_469 = od5.len;
    zT_470 = oi5 < zT_469;
    if (!(zT_470)) { pal_trap(); }
    zT_471 = zT_468[oi5];
    zT_473 = ivp_len < (unsigned int)(512);
    if (!(zT_473)) { pal_trap(); }
    iv_spill_path[ivp_len] = zT_471;
    zT_474 = 1;
    zT_475 = zig_wrap_add_u(((zu64)(ivp_len)), ((zu64)(zT_474)), 32u);
    zT_476 = zig_overflow_flag_add_u(((zu64)(ivp_len)), ((zu64)(zT_474)), 32u);
    zT_478 = zT_476 == (unsigned int)(0);
    if (!(zT_478)) { pal_trap(); }
    ivp_len = zT_475;
    goto z_bb_77;
    z_bb_76:
    zT_484 = 47;
    zT_486 = ivp_len < (unsigned int)(512);
    if (!(zT_486)) { pal_trap(); }
    iv_spill_path[ivp_len] = zT_484;
    zT_487 = 1;
    zT_488 = zig_wrap_add_u(((zu64)(ivp_len)), ((zu64)(zT_487)), 32u);
    zT_489 = zig_overflow_flag_add_u(((zu64)(ivp_len)), ((zu64)(zT_487)), 32u);
    zT_491 = zT_489 == (unsigned int)(0);
    if (!(zT_491)) { pal_trap(); }
    ivp_len = zT_488;
    goto z_bb_72;
    z_bb_77:
    zT_479 = 1;
    zT_480 = zig_wrap_add_u(((zu64)(oi5)), ((zu64)(zT_479)), 32u);
    zT_481 = zig_overflow_flag_add_u(((zu64)(oi5)), ((zu64)(zT_479)), 32u);
    zT_483 = zT_481 == (unsigned int)(0);
    if (!(zT_483)) { pal_trap(); }
    oi5 = zT_480;
    goto z_bb_74;
    z_bb_78:
    zT_465 = ivp_len < (unsigned int)(511);
    goto z_bb_80;
    z_bb_79:
    zT_465 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_465) goto z_bb_75; else goto z_bb_76;
    z_bb_81:
    zT_515 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_515)) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_520 = iv_tmp_name.ptr;
    zT_521 = iv_tmp_name.len;
    zT_522 = ivi < zT_521;
    if (!(zT_522)) { pal_trap(); }
    zT_523 = zT_520[ivi];
    zT_525 = ivp_len < (unsigned int)(512);
    if (!(zT_525)) { pal_trap(); }
    iv_spill_path[ivp_len] = zT_523;
    zT_526 = 1;
    zT_527 = zig_wrap_add_u(((zu64)(ivp_len)), ((zu64)(zT_526)), 32u);
    zT_528 = zig_overflow_flag_add_u(((zu64)(ivp_len)), ((zu64)(zT_526)), 32u);
    zT_530 = zT_528 == (unsigned int)(0);
    if (!(zT_530)) { pal_trap(); }
    ivp_len = zT_527;
    goto z_bb_84;
    z_bb_83:
    zT_536 = (zT_6B0A7D14_AstStore*)&store;
    zT_543 = 0;
    zT_544 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_543;
    zT_545 = ivp_len - zT_543;
    zT_546 = (unsigned int)zT_543 <= ivp_len;
    if (!(zT_546)) { pal_trap(); }
    zT_547 = ivp_len <= (unsigned int)(512);
    if (!(zT_547)) { pal_trap(); }
    zT_548.ptr = (unsigned char*)zT_544;
    zT_548.len = zT_545;
    zT_538 = zT_548;
    zF_35B9B6EC_astStoreSetValuePoo(zT_536, (unsigned int)(1), zT_538);
    zig_poison_fill((void*)&zT_550, (unsigned int)sizeof zT_550);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_550[_i];
        _i++;
    }
}
    zT_552 = 0;
    ecp_len = zT_552;
    zT_553 = cli.output_dir_set;
    if (zT_553) goto z_bb_88; else goto z_bb_90;
    z_bb_84:
    zT_531 = 1;
    zT_532 = zig_wrap_add_u(((zu64)(ivi)), ((zu64)(zT_531)), 32u);
    zT_533 = zig_overflow_flag_add_u(((zu64)(ivi)), ((zu64)(zT_531)), 32u);
    zT_535 = zT_533 == (unsigned int)(0);
    if (!(zT_535)) { pal_trap(); }
    ivi = zT_532;
    goto z_bb_81;
    z_bb_85:
    zT_517 = ivp_len < (unsigned int)(511);
    goto z_bb_87;
    z_bb_86:
    zT_517 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_517) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_555 = cli.output_dir;
    od6 = zT_555;
    zT_557 = 0;
    oi6 = zT_557;
    goto z_bb_91;
    z_bb_89:
    zT_605 = ".zig1_extra_ec.tmp";
    zT_607 = 18;
    zT_606.ptr = (unsigned char*)zT_605;
    zT_606.len = zT_607;
    ec_tmp_name = zT_606;
    zT_609 = 0;
    eci = zT_609;
    goto z_bb_98;
    z_bb_90:
    zT_588 = 46;
    zT_590 = ecp_len < (unsigned int)(512);
    if (!(zT_590)) { pal_trap(); }
    ec_spill_path[ecp_len] = zT_588;
    zT_591 = 1;
    zT_592 = zig_wrap_add_u(((zu64)(ecp_len)), ((zu64)(zT_591)), 32u);
    zT_593 = zig_overflow_flag_add_u(((zu64)(ecp_len)), ((zu64)(zT_591)), 32u);
    zT_595 = zT_593 == (unsigned int)(0);
    if (!(zT_595)) { pal_trap(); }
    ecp_len = zT_592;
    zT_596 = 47;
    zT_598 = ecp_len < (unsigned int)(512);
    if (!(zT_598)) { pal_trap(); }
    ec_spill_path[ecp_len] = zT_596;
    zT_599 = 1;
    zT_600 = zig_wrap_add_u(((zu64)(ecp_len)), ((zu64)(zT_599)), 32u);
    zT_601 = zig_overflow_flag_add_u(((zu64)(ecp_len)), ((zu64)(zT_599)), 32u);
    zT_603 = zT_601 == (unsigned int)(0);
    if (!(zT_603)) { pal_trap(); }
    ecp_len = zT_600;
    goto z_bb_89;
    z_bb_91:
    zT_559 = od6.len;
    if ((unsigned char)(oi6 < zT_559)) goto z_bb_95; else goto z_bb_96;
    z_bb_92:
    zT_564 = od6.ptr;
    zT_565 = od6.len;
    zT_566 = oi6 < zT_565;
    if (!(zT_566)) { pal_trap(); }
    zT_567 = zT_564[oi6];
    zT_569 = ecp_len < (unsigned int)(512);
    if (!(zT_569)) { pal_trap(); }
    ec_spill_path[ecp_len] = zT_567;
    zT_570 = 1;
    zT_571 = zig_wrap_add_u(((zu64)(ecp_len)), ((zu64)(zT_570)), 32u);
    zT_572 = zig_overflow_flag_add_u(((zu64)(ecp_len)), ((zu64)(zT_570)), 32u);
    zT_574 = zT_572 == (unsigned int)(0);
    if (!(zT_574)) { pal_trap(); }
    ecp_len = zT_571;
    goto z_bb_94;
    z_bb_93:
    zT_580 = 47;
    zT_582 = ecp_len < (unsigned int)(512);
    if (!(zT_582)) { pal_trap(); }
    ec_spill_path[ecp_len] = zT_580;
    zT_583 = 1;
    zT_584 = zig_wrap_add_u(((zu64)(ecp_len)), ((zu64)(zT_583)), 32u);
    zT_585 = zig_overflow_flag_add_u(((zu64)(ecp_len)), ((zu64)(zT_583)), 32u);
    zT_587 = zT_585 == (unsigned int)(0);
    if (!(zT_587)) { pal_trap(); }
    ecp_len = zT_584;
    goto z_bb_89;
    z_bb_94:
    zT_575 = 1;
    zT_576 = zig_wrap_add_u(((zu64)(oi6)), ((zu64)(zT_575)), 32u);
    zT_577 = zig_overflow_flag_add_u(((zu64)(oi6)), ((zu64)(zT_575)), 32u);
    zT_579 = zT_577 == (unsigned int)(0);
    if (!(zT_579)) { pal_trap(); }
    oi6 = zT_576;
    goto z_bb_91;
    z_bb_95:
    zT_561 = ecp_len < (unsigned int)(511);
    goto z_bb_97;
    z_bb_96:
    zT_561 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_561) goto z_bb_92; else goto z_bb_93;
    z_bb_98:
    zT_611 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_611)) goto z_bb_102; else goto z_bb_103;
    z_bb_99:
    zT_616 = ec_tmp_name.ptr;
    zT_617 = ec_tmp_name.len;
    zT_618 = eci < zT_617;
    if (!(zT_618)) { pal_trap(); }
    zT_619 = zT_616[eci];
    zT_621 = ecp_len < (unsigned int)(512);
    if (!(zT_621)) { pal_trap(); }
    ec_spill_path[ecp_len] = zT_619;
    zT_622 = 1;
    zT_623 = zig_wrap_add_u(((zu64)(ecp_len)), ((zu64)(zT_622)), 32u);
    zT_624 = zig_overflow_flag_add_u(((zu64)(ecp_len)), ((zu64)(zT_622)), 32u);
    zT_626 = zT_624 == (unsigned int)(0);
    if (!(zT_626)) { pal_trap(); }
    ecp_len = zT_623;
    goto z_bb_101;
    z_bb_100:
    zT_632 = (zT_6B0A7D14_AstStore*)&store;
    zT_639 = 0;
    zT_640 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_639;
    zT_641 = ecp_len - zT_639;
    zT_642 = (unsigned int)zT_639 <= ecp_len;
    if (!(zT_642)) { pal_trap(); }
    zT_643 = ecp_len <= (unsigned int)(512);
    if (!(zT_643)) { pal_trap(); }
    zT_644.ptr = (unsigned char*)zT_640;
    zT_644.len = zT_641;
    zT_634 = zT_644;
    zF_35B9B6EC_astStoreSetValuePoo(zT_632, (unsigned int)(2), zT_634);
    zig_poison_fill((void*)&zT_646, (unsigned int)sizeof zT_646);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_646[_i];
        _i++;
    }
}
    zT_648 = 0;
    erp_len = zT_648;
    zT_649 = cli.output_dir_set;
    if (zT_649) goto z_bb_105; else goto z_bb_107;
    z_bb_101:
    zT_627 = 1;
    zT_628 = zig_wrap_add_u(((zu64)(eci)), ((zu64)(zT_627)), 32u);
    zT_629 = zig_overflow_flag_add_u(((zu64)(eci)), ((zu64)(zT_627)), 32u);
    zT_631 = zT_629 == (unsigned int)(0);
    if (!(zT_631)) { pal_trap(); }
    eci = zT_628;
    goto z_bb_98;
    z_bb_102:
    zT_613 = ecp_len < (unsigned int)(511);
    goto z_bb_104;
    z_bb_103:
    zT_613 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_613) goto z_bb_99; else goto z_bb_100;
    z_bb_105:
    zT_651 = cli.output_dir;
    od7 = zT_651;
    zT_653 = 0;
    oi7 = zT_653;
    goto z_bb_108;
    z_bb_106:
    zT_701 = ".zig1_extra_er.tmp";
    zT_703 = 18;
    zT_702.ptr = (unsigned char*)zT_701;
    zT_702.len = zT_703;
    er_tmp_name = zT_702;
    zT_705 = 0;
    eri = zT_705;
    goto z_bb_115;
    z_bb_107:
    zT_684 = 46;
    zT_686 = erp_len < (unsigned int)(512);
    if (!(zT_686)) { pal_trap(); }
    er_spill_path[erp_len] = zT_684;
    zT_687 = 1;
    zT_688 = zig_wrap_add_u(((zu64)(erp_len)), ((zu64)(zT_687)), 32u);
    zT_689 = zig_overflow_flag_add_u(((zu64)(erp_len)), ((zu64)(zT_687)), 32u);
    zT_691 = zT_689 == (unsigned int)(0);
    if (!(zT_691)) { pal_trap(); }
    erp_len = zT_688;
    zT_692 = 47;
    zT_694 = erp_len < (unsigned int)(512);
    if (!(zT_694)) { pal_trap(); }
    er_spill_path[erp_len] = zT_692;
    zT_695 = 1;
    zT_696 = zig_wrap_add_u(((zu64)(erp_len)), ((zu64)(zT_695)), 32u);
    zT_697 = zig_overflow_flag_add_u(((zu64)(erp_len)), ((zu64)(zT_695)), 32u);
    zT_699 = zT_697 == (unsigned int)(0);
    if (!(zT_699)) { pal_trap(); }
    erp_len = zT_696;
    goto z_bb_106;
    z_bb_108:
    zT_655 = od7.len;
    if ((unsigned char)(oi7 < zT_655)) goto z_bb_112; else goto z_bb_113;
    z_bb_109:
    zT_660 = od7.ptr;
    zT_661 = od7.len;
    zT_662 = oi7 < zT_661;
    if (!(zT_662)) { pal_trap(); }
    zT_663 = zT_660[oi7];
    zT_665 = erp_len < (unsigned int)(512);
    if (!(zT_665)) { pal_trap(); }
    er_spill_path[erp_len] = zT_663;
    zT_666 = 1;
    zT_667 = zig_wrap_add_u(((zu64)(erp_len)), ((zu64)(zT_666)), 32u);
    zT_668 = zig_overflow_flag_add_u(((zu64)(erp_len)), ((zu64)(zT_666)), 32u);
    zT_670 = zT_668 == (unsigned int)(0);
    if (!(zT_670)) { pal_trap(); }
    erp_len = zT_667;
    goto z_bb_111;
    z_bb_110:
    zT_676 = 47;
    zT_678 = erp_len < (unsigned int)(512);
    if (!(zT_678)) { pal_trap(); }
    er_spill_path[erp_len] = zT_676;
    zT_679 = 1;
    zT_680 = zig_wrap_add_u(((zu64)(erp_len)), ((zu64)(zT_679)), 32u);
    zT_681 = zig_overflow_flag_add_u(((zu64)(erp_len)), ((zu64)(zT_679)), 32u);
    zT_683 = zT_681 == (unsigned int)(0);
    if (!(zT_683)) { pal_trap(); }
    erp_len = zT_680;
    goto z_bb_106;
    z_bb_111:
    zT_671 = 1;
    zT_672 = zig_wrap_add_u(((zu64)(oi7)), ((zu64)(zT_671)), 32u);
    zT_673 = zig_overflow_flag_add_u(((zu64)(oi7)), ((zu64)(zT_671)), 32u);
    zT_675 = zT_673 == (unsigned int)(0);
    if (!(zT_675)) { pal_trap(); }
    oi7 = zT_672;
    goto z_bb_108;
    z_bb_112:
    zT_657 = erp_len < (unsigned int)(511);
    goto z_bb_114;
    z_bb_113:
    zT_657 = 0;
    goto z_bb_114;
    z_bb_114:
    if (zT_657) goto z_bb_109; else goto z_bb_110;
    z_bb_115:
    zT_707 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_707)) goto z_bb_119; else goto z_bb_120;
    z_bb_116:
    zT_712 = er_tmp_name.ptr;
    zT_713 = er_tmp_name.len;
    zT_714 = eri < zT_713;
    if (!(zT_714)) { pal_trap(); }
    zT_715 = zT_712[eri];
    zT_717 = erp_len < (unsigned int)(512);
    if (!(zT_717)) { pal_trap(); }
    er_spill_path[erp_len] = zT_715;
    zT_718 = 1;
    zT_719 = zig_wrap_add_u(((zu64)(erp_len)), ((zu64)(zT_718)), 32u);
    zT_720 = zig_overflow_flag_add_u(((zu64)(erp_len)), ((zu64)(zT_718)), 32u);
    zT_722 = zT_720 == (unsigned int)(0);
    if (!(zT_722)) { pal_trap(); }
    erp_len = zT_719;
    goto z_bb_118;
    z_bb_117:
    zT_728 = (zT_6B0A7D14_AstStore*)&store;
    zT_735 = 0;
    zT_736 = (unsigned char*)((unsigned char*)er_spill_path) + zT_735;
    zT_737 = erp_len - zT_735;
    zT_738 = (unsigned int)zT_735 <= erp_len;
    if (!(zT_738)) { pal_trap(); }
    zT_739 = erp_len <= (unsigned int)(512);
    if (!(zT_739)) { pal_trap(); }
    zT_740.ptr = (unsigned char*)zT_736;
    zT_740.len = zT_737;
    zT_730 = zT_740;
    zF_35B9B6EC_astStoreSetValuePoo(zT_728, (unsigned int)(3), zT_730);
    zT_743 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_742 = &zT_743->permanent;
    zT_745 = zF_09A884A8_symbolRegistryInit(zT_742);
    symbol_reg = zT_745;
    zT_748 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_747 = &zT_748->module;
    zT_750 = zF_8D0F00B1_resolvedTypeTableIn(zT_747);
    resolved_types = zT_750;
    zig_poison_fill((void*)&zT_752, (unsigned int)sizeof zT_752);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_752[_i];
        _i++;
    }
}
    zT_754 = 0;
    rsp_len = zT_754;
    zT_755 = cli.output_dir_set;
    if (zT_755) goto z_bb_122; else goto z_bb_124;
    z_bb_118:
    zT_723 = 1;
    zT_724 = zig_wrap_add_u(((zu64)(eri)), ((zu64)(zT_723)), 32u);
    zT_725 = zig_overflow_flag_add_u(((zu64)(eri)), ((zu64)(zT_723)), 32u);
    zT_727 = zT_725 == (unsigned int)(0);
    if (!(zT_727)) { pal_trap(); }
    eri = zT_724;
    goto z_bb_115;
    z_bb_119:
    zT_709 = erp_len < (unsigned int)(511);
    goto z_bb_121;
    z_bb_120:
    zT_709 = 0;
    goto z_bb_121;
    z_bb_121:
    if (zT_709) goto z_bb_116; else goto z_bb_117;
    z_bb_122:
    zT_757 = cli.output_dir;
    od4 = zT_757;
    zT_759 = 0;
    oi4 = zT_759;
    goto z_bb_125;
    z_bb_123:
    zT_807 = ".zig1_res.tmp";
    zT_809 = 13;
    zT_808.ptr = (unsigned char*)zT_807;
    zT_808.len = zT_809;
    rtt_tmp_name = zT_808;
    zT_811 = 0;
    rti2 = zT_811;
    goto z_bb_132;
    z_bb_124:
    zT_790 = 46;
    zT_792 = rsp_len < (unsigned int)(512);
    if (!(zT_792)) { pal_trap(); }
    rtt_spill_path[rsp_len] = zT_790;
    zT_793 = 1;
    zT_794 = zig_wrap_add_u(((zu64)(rsp_len)), ((zu64)(zT_793)), 32u);
    zT_795 = zig_overflow_flag_add_u(((zu64)(rsp_len)), ((zu64)(zT_793)), 32u);
    zT_797 = zT_795 == (unsigned int)(0);
    if (!(zT_797)) { pal_trap(); }
    rsp_len = zT_794;
    zT_798 = 47;
    zT_800 = rsp_len < (unsigned int)(512);
    if (!(zT_800)) { pal_trap(); }
    rtt_spill_path[rsp_len] = zT_798;
    zT_801 = 1;
    zT_802 = zig_wrap_add_u(((zu64)(rsp_len)), ((zu64)(zT_801)), 32u);
    zT_803 = zig_overflow_flag_add_u(((zu64)(rsp_len)), ((zu64)(zT_801)), 32u);
    zT_805 = zT_803 == (unsigned int)(0);
    if (!(zT_805)) { pal_trap(); }
    rsp_len = zT_802;
    goto z_bb_123;
    z_bb_125:
    zT_761 = od4.len;
    if ((unsigned char)(oi4 < zT_761)) goto z_bb_129; else goto z_bb_130;
    z_bb_126:
    zT_766 = od4.ptr;
    zT_767 = od4.len;
    zT_768 = oi4 < zT_767;
    if (!(zT_768)) { pal_trap(); }
    zT_769 = zT_766[oi4];
    zT_771 = rsp_len < (unsigned int)(512);
    if (!(zT_771)) { pal_trap(); }
    rtt_spill_path[rsp_len] = zT_769;
    zT_772 = 1;
    zT_773 = zig_wrap_add_u(((zu64)(rsp_len)), ((zu64)(zT_772)), 32u);
    zT_774 = zig_overflow_flag_add_u(((zu64)(rsp_len)), ((zu64)(zT_772)), 32u);
    zT_776 = zT_774 == (unsigned int)(0);
    if (!(zT_776)) { pal_trap(); }
    rsp_len = zT_773;
    goto z_bb_128;
    z_bb_127:
    zT_782 = 47;
    zT_784 = rsp_len < (unsigned int)(512);
    if (!(zT_784)) { pal_trap(); }
    rtt_spill_path[rsp_len] = zT_782;
    zT_785 = 1;
    zT_786 = zig_wrap_add_u(((zu64)(rsp_len)), ((zu64)(zT_785)), 32u);
    zT_787 = zig_overflow_flag_add_u(((zu64)(rsp_len)), ((zu64)(zT_785)), 32u);
    zT_789 = zT_787 == (unsigned int)(0);
    if (!(zT_789)) { pal_trap(); }
    rsp_len = zT_786;
    goto z_bb_123;
    z_bb_128:
    zT_777 = 1;
    zT_778 = zig_wrap_add_u(((zu64)(oi4)), ((zu64)(zT_777)), 32u);
    zT_779 = zig_overflow_flag_add_u(((zu64)(oi4)), ((zu64)(zT_777)), 32u);
    zT_781 = zT_779 == (unsigned int)(0);
    if (!(zT_781)) { pal_trap(); }
    oi4 = zT_778;
    goto z_bb_125;
    z_bb_129:
    zT_763 = rsp_len < (unsigned int)(511);
    goto z_bb_131;
    z_bb_130:
    zT_763 = 0;
    goto z_bb_131;
    z_bb_131:
    if (zT_763) goto z_bb_126; else goto z_bb_127;
    z_bb_132:
    zT_813 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_813)) goto z_bb_136; else goto z_bb_137;
    z_bb_133:
    zT_818 = rtt_tmp_name.ptr;
    zT_819 = rtt_tmp_name.len;
    zT_820 = rti2 < zT_819;
    if (!(zT_820)) { pal_trap(); }
    zT_821 = zT_818[rti2];
    zT_823 = rsp_len < (unsigned int)(512);
    if (!(zT_823)) { pal_trap(); }
    rtt_spill_path[rsp_len] = zT_821;
    zT_824 = 1;
    zT_825 = zig_wrap_add_u(((zu64)(rsp_len)), ((zu64)(zT_824)), 32u);
    zT_826 = zig_overflow_flag_add_u(((zu64)(rsp_len)), ((zu64)(zT_824)), 32u);
    zT_828 = zT_826 == (unsigned int)(0);
    if (!(zT_828)) { pal_trap(); }
    rsp_len = zT_825;
    goto z_bb_135;
    z_bb_134:
    zT_834 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_839 = 0;
    zT_840 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_839;
    zT_841 = rsp_len - zT_839;
    zT_842 = (unsigned int)zT_839 <= rsp_len;
    if (!(zT_842)) { pal_trap(); }
    zT_843 = rsp_len <= (unsigned int)(512);
    if (!(zT_843)) { pal_trap(); }
    zT_844.ptr = (unsigned char*)zT_840;
    zT_844.len = zT_841;
    zT_835 = zT_844;
    zF_7238A436_resolvedTypeTableSe(zT_834, zT_835);
    zT_847 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_846 = &zT_847->module;
    zT_849 = zF_26B6D809_coercionTableInit(zT_846);
    coercion_table = zT_849;
    zT_852 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_851 = &zT_852->emission;
    zT_854 = zF_F91F6677_lirSlotArrayListIni(zT_851);
    lir_slots = zT_854;
    zT_857 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_856 = &zT_857->module;
    zT_859 = zF_7F194604_depGraphInit(zT_856);
    dep_graph = zT_859;
    zT_862 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_861 = &zT_862->module;
    zT_864 = zF_58BDA2DE_u32ToU32MapInit(zT_861);
    enum_value_table = zT_864;
    zT_867 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_866 = &zT_867->module;
    zT_869 = zF_58BDA2DE_u32ToU32MapInit(zT_866);
    tuple_index_table = zT_869;
    zT_872 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_871 = &zT_872->emission;
    zT_874 = zF_58BDA2DE_u32ToU32MapInit(zT_871);
    error_code_registry = zT_874;
    zT_877 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_876 = &zT_877->module;
    zT_879 = zF_58BDA2DE_u32ToU32MapInit(zT_876);
    call_arg_types = zT_879;
    zT_882 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_881 = &zT_882->module;
    zT_884 = zF_58BDA2DE_u32ToU32MapInit(zT_881);
    call_param_map = zT_884;
    zT_888 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_886 = &zT_888->module;
    zT_891 = zF_125E6ED1_comptimeFoldTableIn(zT_886, (unsigned int)((unsigned int)fold_hint));
    comptime_folds = zT_891;
    zT_894 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_893 = &zT_894->emission;
    zT_896 = zF_046B7660_constInitTableInit(zT_893);
    const_inits = zT_896;
    zT_900 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_899 = &zT_900->permanent;
    zT_902 = zF_58BDA2DE_u32ToU32MapInit(zT_899);
    zT_898.shared_set = zT_902;
    zT_904 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_903 = &zT_904->permanent;
    zT_906 = zF_58BDA2DE_u32ToU32MapInit(zT_903);
    zT_898.pointer_only_map = zT_906;
    zT_908 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_907 = &zT_908->permanent;
    zT_910 = zF_58BDA2DE_u32ToU32MapInit(zT_907);
    zT_898.needs_def_map = zT_910;
    zT_912 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_911 = &zT_912->permanent;
    zT_914 = zF_58BDA2DE_u32ToU32MapInit(zT_911);
    zT_898.needed_tuple_set = zT_914;
    emission_classif = zT_898;
    zig_poison_fill((void*)&zT_916, (unsigned int)sizeof zT_916);
    spell_plan_ph = zT_916;
    zT_919 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_918 = &zT_919->emission;
    zT_921 = zF_986226E1_u64ToU32MapInit(zT_918);
    exported = zT_921;
    zT_924 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_923 = &zT_924->module;
    zT_926 = zF_986226E1_u64ToU32MapInit(zT_923);
    suspending_fns = zT_926;
    zT_929 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_928 = &zT_929->module;
    zT_931 = zF_986226E1_u64ToU32MapInit(zT_928);
    frame_sizes = zT_931;
    zT_934 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_933 = &zT_934->module;
    zT_936 = zF_986226E1_u64ToU32MapInit(zT_933);
    state_widths = zT_936;
    zT_939 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_938 = &zT_939->module;
    zT_941 = zF_986226E1_u64ToU32MapInit(zT_938);
    awaited_fns = zT_941;
    zT_944 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_943 = &zT_944->module;
    zT_946 = zF_986226E1_u64ToU32MapInit(zT_943);
    async_hidden_fns = zT_946;
    zT_949 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_948 = &zT_949->module;
    zT_951 = zF_986226E1_u64ToU32MapInit(zT_948);
    driver_targets = zT_951;
    zT_954 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_953 = &zT_954->module;
    zT_956 = zF_8E537D0C_u32ArrayListInit(zT_953);
    parent_result_type_list = zT_956;
    zT_959 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_958 = &zT_959->module;
    zT_961 = zF_986226E1_u64ToU32MapInit(zT_958);
    parent_result_start = zT_961;
    zT_964 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_963 = &zT_964->module;
    zT_966 = zF_986226E1_u64ToU32MapInit(zT_963);
    parent_result_count = zT_966;
    zT_969 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_968 = &zT_969->module;
    zT_971 = zF_986226E1_u64ToU32MapInit(zT_968);
    async_layouts = zT_971;
    zT_973.cli = cli;
    zT_974 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_973.alloc = zT_974;
    zT_975 = (zT_D3EB6303_StringInterner*)&interner;
    zT_973.interner = zT_975;
    zT_976 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_973.diag = zT_976;
    zT_977 = (zT_227EDE07_SourceManager*)&source_man;
    zT_973.source_man = zT_977;
    zT_978 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_973.module_reg = zT_978;
    zT_979 = (zT_338B7C76_TypeRegistry*)&typereg;
    zT_973.typereg = zT_979;
    zT_980 = (zT_6B0A7D14_AstStore*)&store;
    zT_973.store = zT_980;
    zT_981 = (zT_3D7259E2_SymbolRegistry*)&symbol_reg;
    zT_973.symbol_reg = zT_981;
    zT_982 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_973.resolved_types = zT_982;
    zT_983 = (zT_66E7D2EF_CoercionTable*)&coercion_table;
    zT_973.coercion_table = zT_983;
    zT_984 = (zT_4D61441E_DepGraph*)&dep_graph;
    zT_973.dep_graph = zT_984;
    zT_973.lir_slots = lir_slots;
    zT_985 = zF_E9CBFCA6_lirStreamInit();
    zT_973.lir_stream = zT_985;
    zT_973.enum_value_table = enum_value_table;
    zT_973.tuple_index_table = tuple_index_table;
    zT_973.error_code_registry = error_code_registry;
    zT_973.call_arg_types = call_arg_types;
    zT_973.call_param_map = call_param_map;
    zT_973.comptime_folds = comptime_folds;
    zT_973.const_inits = const_inits;
    zT_973.exported = exported;
    zT_973.suspending_fns = suspending_fns;
    zT_973.frame_sizes = frame_sizes;
    zT_973.state_widths = state_widths;
    zT_973.awaited_fns = awaited_fns;
    zT_973.async_hidden_fns = async_hidden_fns;
    zT_973.driver_targets = driver_targets;
    zT_973.parent_result_type_list = parent_result_type_list;
    zT_973.parent_result_start = parent_result_start;
    zT_973.parent_result_count = parent_result_count;
    zT_973.async_layouts = async_layouts;
    zT_973.emission_classif = emission_classif;
    zT_973.spell_plan = spell_plan_ph;
    zT_987 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_986 = &zT_987->emission;
    zT_989 = zF_EB0B1609_globalDeclArrayList(zT_986);
    zT_973.global_decls = zT_989;
    zT_991 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_990 = &zT_991->module;
    zT_993 = zF_986226E1_u64ToU32MapInit(zT_990);
    zT_973.module_init_deps = zT_993;
    zT_995 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_994 = &zT_995->emission;
    zT_997 = zF_8E537D0C_u32ArrayListInit(zT_994);
    zT_973.module_init_order = zT_997;
    zT_998 = zF_A1EED937_debugSpanStoreInit();
    zT_973.debug_spans = zT_998;
    zT_1000 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_999 = &zT_1000->emission;
    zT_1002 = zF_5779AF56_debugSymbolListInit(zT_999);
    zT_973.debug_symbols = zT_1002;
    zT_1003 = zF_CCB1E6BF_debugMapWriterInit();
    zT_973.debug_map = zT_1003;
    zT_1005 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_1004 = &zT_1005->emission;
    zT_1007 = zF_48A72C7F_debugSpanArrayListI(zT_1004);
    zT_973.debug_span_buf = zT_1007;
    ctx = zT_973;
    zT_1008 = (zT_5AB29387_CompilerContext*)&ctx;
    zF_74055C03_runCompiler(zT_1008);
    return;
    z_bb_135:
    zT_829 = 1;
    zT_830 = zig_wrap_add_u(((zu64)(rti2)), ((zu64)(zT_829)), 32u);
    zT_831 = zig_overflow_flag_add_u(((zu64)(rti2)), ((zu64)(zT_829)), 32u);
    zT_833 = zT_831 == (unsigned int)(0);
    if (!(zT_833)) { pal_trap(); }
    rti2 = zT_830;
    goto z_bb_132;
    z_bb_136:
    zT_815 = rsp_len < (unsigned int)(511);
    goto z_bb_138;
    z_bb_137:
    zT_815 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_815) goto z_bb_133; else goto z_bb_134;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_5AB29387_CompilerContext* zT_87;
    zT_69057089_CompilerAlloc* zT_88;
    zT_F85C5DED_DiagnosticCollector* zT_90;
    unsigned char zT_92;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_98;
    zT_3E40CD83_Sand* zT_100;
    zT_69057089_CompilerAlloc* zT_101;
    zT_5AB29387_CompilerContext* zT_103;
    zT_5AB29387_CompilerContext* zT_104;
    zT_69057089_CompilerAlloc* zT_105;
    zT_C98AF326_CompilerCli zT_107;
    unsigned char zT_108;
    unsigned char zT_109;
    zT_C98AF326_CompilerCli zT_110;
    unsigned char zT_112;
    zT_F85C5DED_DiagnosticCollector* zT_113;
    unsigned int zT_115;
    int zT_116;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    int zT_121;
    zT_C98AF326_CompilerCli zT_123;
    unsigned char zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_3E40CD83_Sand zT_127;
    unsigned int zT_128;
    unsigned char zT_132;
    unsigned int zT_133;
    zT_69057089_CompilerAlloc* zT_135;
    zT_3E40CD83_Sand zT_136;
    unsigned int zT_137;
    unsigned char zT_141;
    unsigned int zT_142;
    zT_69057089_CompilerAlloc* zT_144;
    zT_3E40CD83_Sand zT_145;
    unsigned int zT_146;
    unsigned char zT_150;
    unsigned int zT_151;
    unsigned int zT_153;
    unsigned char zT_157;
    unsigned int zT_158;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_3E40CD83_Sand* zT_161;
    unsigned int zT_162;
    unsigned char zT_166;
    unsigned int zT_167;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned char zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    unsigned char* zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    zT_F85C5DED_DiagnosticCollector* zT_218;
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = (unsigned char*)zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = (unsigned char*)zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_A6065296_phase_ConstInit(zT_86);
    zT_87 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_87);
    zT_88 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_88);
    zT_90 = ctx->diag;
    zT_92 = zF_8F770780_diagnosticCollector(zT_90);
    if (zT_92) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_93 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_93);
    zT_96 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_96));
    goto z_bb_8;
    z_bb_8:
    zT_98 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_98);
    zT_101 = ctx->alloc;
    zT_100 = &zT_101->module;
    zF_F1B3F8C2_sandReset(zT_100);
    zT_103 = ctx;
    zF_2682C512_phase_EmissionClass(zT_103);
    zT_104 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_104);
    zT_105 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_105);
    zT_107 = ctx->cli;
    zT_108 = zT_107.warnings_as_errors;
    if (zT_108) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_110 = ctx->cli;
    zT_109 = zT_110.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_109 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_109) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_113 = ctx->diag;
    zT_115 = zF_4AF2092E_diagnosticCollector(zT_113);
    zT_116 = 0;
    zT_112 = zT_115 > (unsigned int)zT_116;
    goto z_bb_14;
    z_bb_13:
    zT_112 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_112) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_118 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_118);
    zT_121 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_121));
    goto z_bb_16;
    z_bb_16:
    zT_123 = ctx->cli;
    zT_124 = zT_123.track_memory;
    if (zT_124) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_126 = ctx->alloc;
    zT_127 = zT_126->permanent;
    zT_128 = zT_127.peak;
    zT_132 = 1;
    if (!(zT_132)) { pal_trap(); }
    zT_133 = (unsigned int)(unsigned int)(zT_128 / (unsigned int)(1024));
    perm_kb = zT_133;
    zT_135 = ctx->alloc;
    zT_136 = zT_135->module;
    zT_137 = zT_136.peak;
    zT_141 = 1;
    if (!(zT_141)) { pal_trap(); }
    zT_142 = (unsigned int)(unsigned int)(zT_137 / (unsigned int)(1024));
    mod_kb = zT_142;
    zT_144 = ctx->alloc;
    zT_145 = zT_144->scratch;
    zT_146 = zT_145.peak;
    zT_150 = 1;
    if (!(zT_150)) { pal_trap(); }
    zT_151 = (unsigned int)(unsigned int)(zT_146 / (unsigned int)(1024));
    scr_kb = zT_151;
    zT_153 = zF_E5D0D49C_poolPeak();
    zT_157 = 1;
    if (!(zT_157)) { pal_trap(); }
    zT_158 = (unsigned int)(unsigned int)(zT_153 / (unsigned int)(1024));
    pool_kb = zT_158;
    zT_160 = ctx->typereg;
    zT_161 = zT_160->types_alloc;
    zT_162 = zT_161->peak;
    zT_166 = 1;
    if (!(zT_166)) { pal_trap(); }
    zT_167 = (unsigned int)(unsigned int)(zT_162 / (unsigned int)(1024));
    type_db_kb = zT_167;
    zT_169 = zig_wrap_add_u(((zu64)(perm_kb)), ((zu64)(mod_kb)), 32u);
    zT_170 = zig_overflow_flag_add_u(((zu64)(perm_kb)), ((zu64)(mod_kb)), 32u);
    zT_172 = zT_170 == (unsigned int)(0);
    if (!(zT_172)) { pal_trap(); }
    zT_173 = zig_wrap_add_u(((zu64)(zT_169)), ((zu64)(scr_kb)), 32u);
    zT_174 = zig_overflow_flag_add_u(((zu64)(zT_169)), ((zu64)(scr_kb)), 32u);
    zT_176 = zT_174 == (unsigned int)(0);
    if (!(zT_176)) { pal_trap(); }
    total = zT_173;
    zT_178 = "track-memory: perm=";
    zT_180 = 19;
    zT_179.ptr = (unsigned char*)zT_178;
    zT_179.len = zT_180;
    msg1 = zT_179;
    zT_181 = msg1;
    zF_B5478454_measureMarkerWrite(zT_181);
    zT_182 = perm_kb;
    zF_266B1B8E_writeU32(zT_182);
    zT_184 = "K mod=";
    zT_186 = 6;
    zT_185.ptr = (unsigned char*)zT_184;
    zT_185.len = zT_186;
    msg2 = zT_185;
    zT_187 = msg2;
    zF_B5478454_measureMarkerWrite(zT_187);
    zT_188 = mod_kb;
    zF_266B1B8E_writeU32(zT_188);
    zT_190 = "K scr=";
    zT_192 = 6;
    zT_191.ptr = (unsigned char*)zT_190;
    zT_191.len = zT_192;
    msg3 = zT_191;
    zT_193 = msg3;
    zF_B5478454_measureMarkerWrite(zT_193);
    zT_194 = scr_kb;
    zF_266B1B8E_writeU32(zT_194);
    zT_196 = "K pool=";
    zT_198 = 7;
    zT_197.ptr = (unsigned char*)zT_196;
    zT_197.len = zT_198;
    msg3b = zT_197;
    zT_199 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_199);
    zT_200 = pool_kb;
    zF_266B1B8E_writeU32(zT_200);
    zT_202 = "K type_db=";
    zT_204 = 10;
    zT_203.ptr = (unsigned char*)zT_202;
    zT_203.len = zT_204;
    msg3c = zT_203;
    zT_205 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_205);
    zT_206 = type_db_kb;
    zF_266B1B8E_writeU32(zT_206);
    zT_208 = "K total=";
    zT_210 = 8;
    zT_209.ptr = (unsigned char*)zT_208;
    zT_209.len = zT_210;
    msg4 = zT_209;
    zT_211 = msg4;
    zF_B5478454_measureMarkerWrite(zT_211);
    zT_212 = total;
    zF_266B1B8E_writeU32(zT_212);
    zT_214 = "K\n";
    zT_216 = 2;
    zT_215.ptr = (unsigned char*)zT_214;
    zT_215.len = zT_216;
    msg5 = zT_215;
    zT_217 = msg5;
    zF_B5478454_measureMarkerWrite(zT_217);
    goto z_bb_18;
    z_bb_18:
    zT_218 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_218);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_61A320D8_anon_323976 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11;
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_27 = 1;
    zT_28 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_846744CC_Arr_unsigned_char_5 zT_32;
    unsigned char* zT_34;
    int zT_36;
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_41;
    int zT_42;
    unsigned int zT_47;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    unsigned char zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char zT_55;
    zT_4DB1475B_ModuleResolver* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_072B53A6_ModuleRegistry* zT_58;
    zT_846744CC_Arr_unsigned_char_5 zT_61;
    zT_C98AF326_CompilerCli zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_68;
    int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_C98AF326_CompilerCli zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_79;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    unsigned char zT_83;
    unsigned char zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_C98AF326_CompilerCli zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zT_662E24C2_Opt_250 zT_88;
    unsigned char zT_89;
    zT_D3EB6303_StringInterner* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_95;
    zT_072B53A6_ModuleRegistry* zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    zT_47A5CDFB_ImportQueue* zT_101;
    unsigned int zT_102;
    zT_072B53A6_ModuleRegistry* zT_103;
    zT_072B53A6_ModuleRegistry* zT_105;
    zT_3E40CD83_Sand* zT_106;
    zT_3E40CD83_Sand* zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    zT_69057089_CompilerAlloc* zT_110;
    zT_69057089_CompilerAlloc* zT_112;
    zT_D3EB6303_StringInterner* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_4DB1475B_ModuleResolver* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    zT_3E40CD83_Sand* zT_134;
    zT_072B53A6_ModuleRegistry* zT_135;
    zT_69057089_CompilerAlloc* zT_137;
    zT_BAEE192E_Opt_10 zT_139;
    unsigned char zT_140;
    zT_D3EB6303_StringInterner* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_145;
    zT_072B53A6_ModuleRegistry* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_3E40CD83_Sand* zT_149;
    zT_69057089_CompilerAlloc* zT_151;
    zT_BAEE192E_Opt_10 zT_153;
    zT_072B53A6_ModuleRegistry* zT_154;
    zT_3E40CD83_Sand* zT_155;
    zT_3E40CD83_Sand* zT_156;
    zT_6B0A7D14_AstStore* zT_157;
    zT_69057089_CompilerAlloc* zT_159;
    zT_69057089_CompilerAlloc* zT_161;
    zT_846744CC_Arr_unsigned_char_5 zT_165;
    unsigned int zT_167;
    zT_C98AF326_CompilerCli zT_168;
    unsigned char zT_169;
    zT_C98AF326_CompilerCli zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_174;
    unsigned int zT_176;
    unsigned char zT_178;
    unsigned char* zT_181;
    unsigned int zT_182;
    unsigned char zT_183;
    unsigned char zT_184;
    unsigned char zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned char zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned char zT_196;
    unsigned char zT_197;
    unsigned char zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned char zT_204;
    unsigned char zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_212;
    unsigned char zT_213;
    unsigned char zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned char zT_220;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    unsigned int zT_226;
    unsigned int zT_228;
    unsigned char zT_230;
    unsigned char* zT_233;
    unsigned int zT_234;
    unsigned char zT_235;
    unsigned char zT_236;
    unsigned char zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned char zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned char zT_248;
    zT_072B53A6_ModuleRegistry* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    int zT_254;
    unsigned char* zT_255;
    unsigned int zT_256;
    unsigned char zT_257;
    unsigned char zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_95, (unsigned int)sizeof zT_95);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_122, (unsigned int)sizeof zT_122);
    zig_poison_fill((void*)&zT_126, (unsigned int)sizeof zT_126);
    zig_poison_fill((void*)&zT_139, (unsigned int)sizeof zT_139);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_662E24C2_Opt_250 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_23 = zT_21 < (unsigned int)(16);
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_20[zT_21];
    zT_16 = zT_24;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_32[_i];
        _i++;
    }
}
    zT_36 = 0;
    zT_38 = (unsigned int)zT_36 < (unsigned int)(512);
    if (!(zT_38)) { pal_trap(); }
    zT_39 = lib_buf + zT_36;
    zT_34 = zT_39;
    zT_41 = zF_BEB0BFA8_getDefaultLibPath(zT_34, (int)(512));
    lib_len = zT_41;
    zT_42 = 0;
    if ((unsigned char)(lib_len > zT_42)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    si = zT_27;
    goto z_bb_1;
    z_bb_5:
    zT_47 = (unsigned int)zig_cast_checked_u((zu64)lib_len, 32u, 1u, 32u);
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)lib_buf) + zT_48;
    zT_50 = zT_47 - zT_48;
    zT_51 = (unsigned int)zT_48 <= zT_47;
    if (!(zT_51)) { pal_trap(); }
    zT_52 = zT_47 <= (unsigned int)(512);
    if (!(zT_52)) { pal_trap(); }
    zT_53.ptr = (unsigned char*)zT_49;
    zT_53.len = zT_50;
    lib_path = zT_53;
    zT_54 = lib_path;
    zT_55 = zF_8CC05F84_dirExists(zT_54);
    if (zT_55) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_61[_i];
        _i++;
    }
}
    zT_63 = ctx->cli;
    zT_64 = zT_63.input_file;
    root_path = zT_64;
    zT_65 = ctx->cli;
    zT_66 = zT_65.input_file;
    zT_68 = zT_66.len;
    zT_69 = 512;
    if ((unsigned char)(zT_68 <= (unsigned int)zT_69)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_58 = ctx->module_reg;
    zT_56 = &zT_58->resolver;
    zT_57 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_56, zT_57);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_76 = ctx->cli;
    zT_77 = zT_76.input_file;
    zT_79 = zT_77.len;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)root_buf) + zT_80;
    zT_82 = zT_79 - zT_80;
    zT_83 = (unsigned int)zT_80 <= zT_79;
    if (!(zT_83)) { pal_trap(); }
    zT_84 = zT_79 <= (unsigned int)(512);
    if (!(zT_84)) { pal_trap(); }
    zT_85.ptr = (unsigned char*)zT_81;
    zT_85.len = zT_82;
    zT_72 = zT_85;
    zT_86 = ctx->cli;
    zT_87 = zT_86.input_file;
    zT_73 = zT_87;
    zT_88 = zF_36F0DB6B_normalizePath(zT_72, zT_73);
    norm = zT_88;
    zT_89 = norm.has_value;
    if (zT_89) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_92 = ctx->interner;
    zT_93 = root_path;
    zT_95 = zF_50C274AF_stringInternerInter(zT_92, zT_93);
    path_id = zT_95;
    zT_97 = ctx->module_reg;
    zT_98 = path_id;
    zT_100 = zF_E4DCE20D_moduleRegistryAddMo(zT_97, zT_98);
    mod_id = zT_100;
    zT_103 = ctx->module_reg;
    zT_101 = &zT_103->import_queue;
    zT_102 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_101, zT_102);
    zT_105 = ctx->module_reg;
    zT_110 = ctx->alloc;
    zT_106 = &zT_110->module;
    zT_112 = ctx->alloc;
    zT_107 = &zT_112->scratch;
    zT_108 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_105, zT_106, zT_107, zT_108);
    zT_116 = ctx->interner;
    zT_119 = "print";
    zT_121 = 5;
    zT_120.ptr = (unsigned char*)zT_119;
    zT_120.len = zT_121;
    zT_117 = zT_120;
    zT_122 = zF_50C274AF_stringInternerInter(zT_116, zT_117);
    print_name_id = zT_122;
    zT_123 = ctx->store;
    zT_124 = print_name_id;
    zT_126 = zF_A42B6E3C_astStoreHasPrintRef(zT_123, zT_124);
    if (zT_126) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    if (!(norm.has_value)) { pal_trap(); }
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_128 = "std_fmt.zig";
    zT_130 = 11;
    zT_129.ptr = (unsigned char*)zT_128;
    zT_129.len = zT_130;
    fmt_name = zT_129;
    zT_135 = ctx->module_reg;
    zT_131 = &zT_135->resolver;
    zT_132 = root_path;
    zT_133 = fmt_name;
    zT_137 = ctx->alloc;
    zT_134 = &zT_137->scratch;
    zT_139 = zF_6F148E15_moduleResolverResol(zT_131, zT_132, zT_133, zT_134);
    zT_140 = zT_139.has_value;
    if (zT_140) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zig_poison_fill((void*)&zT_165, (unsigned int)sizeof zT_165);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_165[_i];
        _i++;
    }
}
    zT_167 = 0;
    hsp_len = zT_167;
    zT_168 = ctx->cli;
    zT_169 = zT_168.output_dir_set;
    if (zT_169) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_142 = ctx->interner;
    zT_143 = fmt_name;
    zT_145 = zF_50C274AF_stringInternerInter(zT_142, zT_143);
    fmt_path_id = zT_145;
    zT_146 = ctx->module_reg;
    zT_147 = fmt_path_id;
    zT_148 = mod_id;
    zT_151 = ctx->alloc;
    zT_149 = &zT_151->scratch;
    zT_153 = zF_620E3E3B_moduleRegistryResol(zT_146, zT_147, zT_148, zT_149);
    (void)zT_153;
    zT_154 = ctx->module_reg;
    zT_159 = ctx->alloc;
    zT_155 = &zT_159->module;
    zT_161 = ctx->alloc;
    zT_156 = &zT_161->scratch;
    zT_157 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_154, zT_155, zT_156, zT_157);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_171 = ctx->cli;
    zT_172 = zT_171.output_dir;
    od = zT_172;
    zT_174 = 0;
    oi = zT_174;
    goto z_bb_20;
    z_bb_18:
    zT_222 = ".zig1_hash.tmp";
    zT_224 = 14;
    zT_223.ptr = (unsigned char*)zT_222;
    zT_223.len = zT_224;
    hash_tmp_name = zT_223;
    zT_226 = 0;
    hi = zT_226;
    goto z_bb_27;
    z_bb_19:
    zT_205 = 46;
    zT_207 = hsp_len < (unsigned int)(512);
    if (!(zT_207)) { pal_trap(); }
    hash_spill_path[hsp_len] = zT_205;
    zT_208 = 1;
    zT_209 = zig_wrap_add_u(((zu64)(hsp_len)), ((zu64)(zT_208)), 32u);
    zT_210 = zig_overflow_flag_add_u(((zu64)(hsp_len)), ((zu64)(zT_208)), 32u);
    zT_212 = zT_210 == (unsigned int)(0);
    if (!(zT_212)) { pal_trap(); }
    hsp_len = zT_209;
    zT_213 = 47;
    zT_215 = hsp_len < (unsigned int)(512);
    if (!(zT_215)) { pal_trap(); }
    hash_spill_path[hsp_len] = zT_213;
    zT_216 = 1;
    zT_217 = zig_wrap_add_u(((zu64)(hsp_len)), ((zu64)(zT_216)), 32u);
    zT_218 = zig_overflow_flag_add_u(((zu64)(hsp_len)), ((zu64)(zT_216)), 32u);
    zT_220 = zT_218 == (unsigned int)(0);
    if (!(zT_220)) { pal_trap(); }
    hsp_len = zT_217;
    goto z_bb_18;
    z_bb_20:
    zT_176 = od.len;
    if ((unsigned char)(oi < zT_176)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_181 = od.ptr;
    zT_182 = od.len;
    zT_183 = oi < zT_182;
    if (!(zT_183)) { pal_trap(); }
    zT_184 = zT_181[oi];
    zT_186 = hsp_len < (unsigned int)(512);
    if (!(zT_186)) { pal_trap(); }
    hash_spill_path[hsp_len] = zT_184;
    zT_187 = 1;
    zT_188 = zig_wrap_add_u(((zu64)(hsp_len)), ((zu64)(zT_187)), 32u);
    zT_189 = zig_overflow_flag_add_u(((zu64)(hsp_len)), ((zu64)(zT_187)), 32u);
    zT_191 = zT_189 == (unsigned int)(0);
    if (!(zT_191)) { pal_trap(); }
    hsp_len = zT_188;
    goto z_bb_23;
    z_bb_22:
    zT_197 = 47;
    zT_199 = hsp_len < (unsigned int)(512);
    if (!(zT_199)) { pal_trap(); }
    hash_spill_path[hsp_len] = zT_197;
    zT_200 = 1;
    zT_201 = zig_wrap_add_u(((zu64)(hsp_len)), ((zu64)(zT_200)), 32u);
    zT_202 = zig_overflow_flag_add_u(((zu64)(hsp_len)), ((zu64)(zT_200)), 32u);
    zT_204 = zT_202 == (unsigned int)(0);
    if (!(zT_204)) { pal_trap(); }
    hsp_len = zT_201;
    goto z_bb_18;
    z_bb_23:
    zT_192 = 1;
    zT_193 = zig_wrap_add_u(((zu64)(oi)), ((zu64)(zT_192)), 32u);
    zT_194 = zig_overflow_flag_add_u(((zu64)(oi)), ((zu64)(zT_192)), 32u);
    zT_196 = zT_194 == (unsigned int)(0);
    if (!(zT_196)) { pal_trap(); }
    oi = zT_193;
    goto z_bb_20;
    z_bb_24:
    zT_178 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_178 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_178) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_228 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_228)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_233 = hash_tmp_name.ptr;
    zT_234 = hash_tmp_name.len;
    zT_235 = hi < zT_234;
    if (!(zT_235)) { pal_trap(); }
    zT_236 = zT_233[hi];
    zT_238 = hsp_len < (unsigned int)(512);
    if (!(zT_238)) { pal_trap(); }
    hash_spill_path[hsp_len] = zT_236;
    zT_239 = 1;
    zT_240 = zig_wrap_add_u(((zu64)(hsp_len)), ((zu64)(zT_239)), 32u);
    zT_241 = zig_overflow_flag_add_u(((zu64)(hsp_len)), ((zu64)(zT_239)), 32u);
    zT_243 = zT_241 == (unsigned int)(0);
    if (!(zT_243)) { pal_trap(); }
    hsp_len = zT_240;
    goto z_bb_30;
    z_bb_29:
    zT_249 = ctx->module_reg;
    zT_254 = 0;
    zT_255 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_254;
    zT_256 = hsp_len - zT_254;
    zT_257 = (unsigned int)zT_254 <= hsp_len;
    if (!(zT_257)) { pal_trap(); }
    zT_258 = hsp_len <= (unsigned int)(512);
    if (!(zT_258)) { pal_trap(); }
    zT_259.ptr = (unsigned char*)zT_255;
    zT_259.len = zT_256;
    zT_250 = zT_259;
    zF_8767909B_moduleRegistrySpill(zT_249, zT_250);
    zT_261 = "Z\n";
    zT_263 = 2;
    zT_262.ptr = (unsigned char*)zT_261;
    zT_262.len = zT_263;
    z_msg = zT_262;
    zT_264 = z_msg;
    zF_48AC7B3A_markerWrite(zT_264);
    return;
    z_bb_30:
    zT_244 = 1;
    zT_245 = zig_wrap_add_u(((zu64)(hi)), ((zu64)(zT_244)), 32u);
    zT_246 = zig_overflow_flag_add_u(((zu64)(hi)), ((zu64)(zT_244)), 32u);
    zT_248 = zT_246 == (unsigned int)(0);
    if (!(zT_248)) { pal_trap(); }
    hi = zT_245;
    goto z_bb_27;
    z_bb_31:
    zT_230 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_230 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_230) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    unsigned int zT_36;
    unsigned char zT_37;
    zT_6E8D187B_ModuleEntry zT_38;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_51;
    unsigned int zT_53;
    unsigned char zT_56;
    zT_6E8D187B_ModuleEntry* zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned char zT_60;
    zT_6E8D187B_ModuleEntry zT_61;
    unsigned int zT_62;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_6E8D187B_ModuleEntry* zT_69;
    int zT_70;
    unsigned int zT_71;
    unsigned char zT_72;
    zT_6E8D187B_ModuleEntry zT_73;
    zT_22A7C88B_AstNode zT_75;
    zT_8143F551_AstKind zT_76;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    zT_6E8D187B_ModuleEntry* zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    zT_6E8D187B_ModuleEntry zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    zT_6E8D187B_ModuleEntry* zT_108;
    int zT_109;
    unsigned int zT_110;
    unsigned char zT_111;
    zT_6E8D187B_ModuleEntry zT_112;
    unsigned int zT_115;
    zT_22A7C88B_AstNode zT_116;
    zT_8143F551_AstKind zT_118;
    unsigned int zT_119;
    zT_4028D896_Arr_unsigned_char_2 zT_121;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    int zT_127;
    unsigned char* zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    unsigned char zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = mods.len;
    zT_37 = mi < zT_36;
    if (!(zT_37)) { pal_trap(); }
    zT_38 = zT_35[mi];
    zT_28 = zT_38.id;
    zT_29 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->module_reg;
    zT_51 = zF_3452C137_moduleRegistryGetMo(zT_49);
    smods = zT_51;
    zT_53 = smods.len;
    if ((unsigned char)(zT_53 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    mi = zT_44;
    goto z_bb_1;
    z_bb_5:
    zT_57 = smods.ptr;
    zT_58 = 0;
    zT_59 = smods.len;
    zT_60 = (unsigned int)zT_58 < zT_59;
    if (!(zT_60)) { pal_trap(); }
    zT_61 = zT_57[zT_58];
    zT_62 = zT_61.ast_root;
    zT_56 = zT_62 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_56 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_56) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_66 = ctx->store;
    zT_69 = smods.ptr;
    zT_70 = 0;
    zT_71 = smods.len;
    zT_72 = (unsigned int)zT_70 < zT_71;
    if (!(zT_72)) { pal_trap(); }
    zT_73 = zT_69[zT_70];
    zT_67 = zT_73.ast_root;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    sr = zT_75;
    zT_76 = sr.kind;
    if ((unsigned char)(zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_81 = ctx->store;
    zT_84 = smods.ptr;
    zT_85 = 0;
    zT_86 = smods.len;
    zT_87 = (unsigned int)zT_85 < zT_86;
    if (!(zT_87)) { pal_trap(); }
    zT_88 = zT_84[zT_85];
    zT_82 = zT_88.ast_root;
    zT_90 = zF_152E19CB_astStoreNodeExtraCh(zT_81, zT_82);
    sdl_n = zT_90;
    zT_92 = 0;
    sdi = zT_92;
    zT_94 = "S0";
    zT_96 = 2;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    sl = zT_95;
    zT_97 = sl;
    zF_48AC7B3A_markerWrite(zT_97);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_101 = ctx->store;
    zT_104 = ctx->store;
    zT_108 = smods.ptr;
    zT_109 = 0;
    zT_110 = smods.len;
    zT_111 = (unsigned int)zT_109 < zT_110;
    if (!(zT_111)) { pal_trap(); }
    zT_112 = zT_108[zT_109];
    zT_105 = zT_112.ast_root;
    zT_115 = zF_B10B1BC1_astStoreNodeExtraCh(zT_104, zT_105, (unsigned int)((unsigned int)sdi));
    zT_102 = zT_115;
    zT_116 = zF_FCDD1D35_astStoreNodeAt(zT_101, zT_102);
    sd = zT_116;
    zT_118 = sd.kind;
    zT_119 = (unsigned int)zT_118;
    sk = zT_119;
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_121[_i];
        _i++;
    }
}
    zT_123 = sk;
    zT_127 = 0;
    zT_128 = (unsigned char*)((unsigned char*)sb) + zT_127;
    zT_129 = (unsigned int)(20) - zT_127;
    zT_130.ptr = (unsigned char*)zT_128;
    zT_130.len = zT_129;
    zT_124 = zT_130;
    zT_131 = zF_A7504564_itoa(zT_123, zT_124);
    slen = zT_131;
    zT_133 = 19;
    zT_134 = (unsigned int)slen;
    zT_135 = zig_wrap_sub_u(((zu64)(zT_133)), ((zu64)(zT_134)), 32u);
    zT_136 = zig_overflow_flag_sub_u(((zu64)(zT_133)), ((zu64)(zT_134)), 32u);
    zT_138 = zT_136 == (unsigned int)(0);
    if (!(zT_138)) { pal_trap(); }
    sst = zT_135;
    zT_142 = 19;
    zT_143 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_144 = zT_142 - sst;
    zT_145 = sst <= zT_142;
    if (!(zT_145)) { pal_trap(); }
    zT_146.ptr = (unsigned char*)zT_143;
    zT_146.len = zT_144;
    zT_139 = zT_146;
    zF_48AC7B3A_markerWrite(zT_139);
    zT_148 = " ";
    zT_150 = 1;
    zT_149.ptr = (unsigned char*)zT_148;
    zT_149.len = zT_150;
    ssp = zT_149;
    zT_151 = ssp;
    zF_48AC7B3A_markerWrite(zT_151);
    goto z_bb_15;
    z_bb_14:
    zT_158 = "\n";
    zT_160 = 1;
    zT_159.ptr = (unsigned char*)zT_158;
    zT_159.len = zT_160;
    sn = zT_159;
    zT_161 = sn;
    zF_48AC7B3A_markerWrite(zT_161);
    goto z_bb_11;
    z_bb_15:
    zT_152 = 1;
    zT_153 = zig_wrap_add_u(((zu64)(sdi)), ((zu64)(zT_152)), 32u);
    zT_154 = zig_overflow_flag_add_u(((zu64)(sdi)), ((zu64)(zT_152)), 32u);
    zT_156 = zT_154 == (unsigned int)(0);
    if (!(zT_156)) { pal_trap(); }
    sdi = zT_153;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_61A320D8_anon_323976 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19;
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    zT_3D7259E2_SymbolRegistry* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_D3EB6303_StringInterner* zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_3E40CD83_Sand* zT_58;
    zT_69057089_CompilerAlloc* zT_63;
    zT_6B0A7D14_AstStore* zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_3D7259E2_SymbolRegistry* zT_67;
    zT_D3EB6303_StringInterner* zT_68;
    zT_8EED1867_ResolvedTypeTable* zT_69;
    zT_072B53A6_ModuleRegistry* zT_70;
    zT_F85C5DED_DiagnosticCollector* zT_71;
    zT_3E40CD83_Sand* zT_72;
    zT_69057089_CompilerAlloc* zT_80;
    zT_338B7C76_TypeRegistry* zT_83;
    zT_F85C5DED_DiagnosticCollector* zT_84;
    zT_3E40CD83_Sand* zT_85;
    zT_69057089_CompilerAlloc* zT_88;
    zT_C890C8CB_TypeResolver zT_90;
    zT_C890C8CB_TypeResolver* zT_91;
    zT_C890C8CB_TypeResolver* zT_93;
    zT_4D61441E_DepGraph* zT_94;
    zT_C890C8CB_TypeResolver* zT_97;
    zT_6B0A7D14_AstStore* zT_99;
    zT_338B7C76_TypeRegistry* zT_100;
    zT_3D7259E2_SymbolRegistry* zT_101;
    zT_D3EB6303_StringInterner* zT_102;
    zT_072B53A6_ModuleRegistry* zT_103;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    zT_C890C8CB_TypeResolver* zT_111;
    zT_786E6CF2_EmissionClassificat* zT_112;
    zT_3E40CD83_Sand* zT_113;
    zT_69057089_CompilerAlloc* zT_116;
    unsigned int zT_119;
    unsigned char zT_122;
    zT_6E8D187B_ModuleEntry* zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned char zT_126;
    zT_6E8D187B_ModuleEntry zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    zT_6E8D187B_ModuleEntry* zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned char zT_138;
    zT_6E8D187B_ModuleEntry zT_139;
    zT_22A7C88B_AstNode zT_141;
    zT_8143F551_AstKind zT_142;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    zT_6E8D187B_ModuleEntry* zT_150;
    int zT_151;
    unsigned int zT_152;
    unsigned char zT_153;
    zT_6E8D187B_ModuleEntry zT_154;
    unsigned int zT_156;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_6B0A7D14_AstStore* zT_167;
    unsigned int zT_168;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    zT_6E8D187B_ModuleEntry* zT_174;
    int zT_175;
    unsigned int zT_176;
    unsigned char zT_177;
    zT_6E8D187B_ModuleEntry zT_178;
    unsigned int zT_181;
    zT_22A7C88B_AstNode zT_182;
    zT_8143F551_AstKind zT_184;
    unsigned int zT_185;
    zT_4028D896_Arr_unsigned_char_2 zT_187;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    int zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    unsigned int zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned char zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    unsigned char zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned char zT_222;
    unsigned char* zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zig_poison_fill((void*)&zT_156, (unsigned int)sizeof zT_156);
    zig_poison_fill((void*)&zT_181, (unsigned int)sizeof zT_181);
    zig_poison_fill((void*)&zT_182, (unsigned int)sizeof zT_182);
    zig_poison_fill((void*)&zT_197, (unsigned int)sizeof zT_197);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = mods.len;
    zT_43 = mi < zT_42;
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_41[mi];
    zT_34 = zT_44.id;
    zT_35 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_54 = ctx->symbol_reg;
    zT_55 = ctx->typereg;
    zT_56 = ctx->interner;
    zT_57 = ctx->store;
    zT_63 = ctx->alloc;
    zT_58 = &zT_63->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_54, zT_55, zT_56, zT_57, zT_58);
    zT_65 = ctx->store;
    zT_66 = ctx->typereg;
    zT_67 = ctx->symbol_reg;
    zT_68 = ctx->interner;
    zT_69 = ctx->resolved_types;
    zT_70 = ctx->module_reg;
    zT_71 = ctx->diag;
    zT_80 = ctx->alloc;
    zT_72 = &zT_80->permanent;
    zF_373A7BEF_typeResolverResolve(zT_65, zT_66, zT_67, zT_68, zT_69, zT_70, zT_71, zT_72);
    zT_83 = ctx->typereg;
    zT_84 = ctx->diag;
    zT_88 = ctx->alloc;
    zT_85 = &zT_88->scratch;
    zT_90 = zF_5BFAC855_typeResolverInit(zT_83, zT_84, zT_85);
    tr = zT_90;
    zT_91 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_D5C4530C_typeResolverBuildDe(zT_91);
    zT_93 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_94 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_33272F41_typeResolverBuild(zT_93, zT_94);
    zT_97 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_30BE7185_typeResolverResolve(zT_97);
    zT_99 = ctx->store;
    zT_100 = ctx->typereg;
    zT_101 = ctx->symbol_reg;
    zT_102 = ctx->interner;
    zT_103 = ctx->module_reg;
    zT_104 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_99, zT_100, zT_101, zT_102, zT_103, zT_104);
    zT_111 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_112 = &ctx->emission_classif;
    zT_116 = ctx->alloc;
    zT_113 = &zT_116->permanent;
    zF_ACC002C8_classifyTypeEmissio(zT_111, zT_112, zT_113);
    zT_119 = mods.len;
    if ((unsigned char)(zT_119 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_48 = 1;
    zT_49 = (unsigned int)zT_48;
    zT_50 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    mi = zT_50;
    goto z_bb_1;
    z_bb_5:
    zT_123 = mods.ptr;
    zT_124 = 0;
    zT_125 = mods.len;
    zT_126 = (unsigned int)zT_124 < zT_125;
    if (!(zT_126)) { pal_trap(); }
    zT_127 = zT_123[zT_124];
    zT_128 = zT_127.ast_root;
    zT_122 = zT_128 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_122 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_122) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_132 = ctx->store;
    zT_135 = mods.ptr;
    zT_136 = 0;
    zT_137 = mods.len;
    zT_138 = (unsigned int)zT_136 < zT_137;
    if (!(zT_138)) { pal_trap(); }
    zT_139 = zT_135[zT_136];
    zT_133 = zT_139.ast_root;
    zT_141 = zF_FCDD1D35_astStoreNodeAt(zT_132, zT_133);
    tr2 = zT_141;
    zT_142 = tr2.kind;
    if ((unsigned char)(zT_142 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_147 = ctx->store;
    zT_150 = mods.ptr;
    zT_151 = 0;
    zT_152 = mods.len;
    zT_153 = (unsigned int)zT_151 < zT_152;
    if (!(zT_153)) { pal_trap(); }
    zT_154 = zT_150[zT_151];
    zT_148 = zT_154.ast_root;
    zT_156 = zF_152E19CB_astStoreNodeExtraCh(zT_147, zT_148);
    tdl_n = zT_156;
    zT_158 = 0;
    tdi = zT_158;
    zT_160 = "T0";
    zT_162 = 2;
    zT_161.ptr = (unsigned char*)zT_160;
    zT_161.len = zT_162;
    tl = zT_161;
    zT_163 = tl;
    zF_48AC7B3A_markerWrite(zT_163);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_167 = ctx->store;
    zT_170 = ctx->store;
    zT_174 = mods.ptr;
    zT_175 = 0;
    zT_176 = mods.len;
    zT_177 = (unsigned int)zT_175 < zT_176;
    if (!(zT_177)) { pal_trap(); }
    zT_178 = zT_174[zT_175];
    zT_171 = zT_178.ast_root;
    zT_181 = zF_B10B1BC1_astStoreNodeExtraCh(zT_170, zT_171, (unsigned int)((unsigned int)tdi));
    zT_168 = zT_181;
    zT_182 = zF_FCDD1D35_astStoreNodeAt(zT_167, zT_168);
    td = zT_182;
    zT_184 = td.kind;
    zT_185 = (unsigned int)zT_184;
    tk = zT_185;
    zig_poison_fill((void*)&zT_187, (unsigned int)sizeof zT_187);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_187[_i];
        _i++;
    }
}
    zT_189 = tk;
    zT_193 = 0;
    zT_194 = (unsigned char*)((unsigned char*)tb) + zT_193;
    zT_195 = (unsigned int)(20) - zT_193;
    zT_196.ptr = (unsigned char*)zT_194;
    zT_196.len = zT_195;
    zT_190 = zT_196;
    zT_197 = zF_A7504564_itoa(zT_189, zT_190);
    tlen = zT_197;
    zT_199 = 19;
    zT_200 = (unsigned int)tlen;
    zT_201 = zig_wrap_sub_u(((zu64)(zT_199)), ((zu64)(zT_200)), 32u);
    zT_202 = zig_overflow_flag_sub_u(((zu64)(zT_199)), ((zu64)(zT_200)), 32u);
    zT_204 = zT_202 == (unsigned int)(0);
    if (!(zT_204)) { pal_trap(); }
    tst = zT_201;
    zT_208 = 19;
    zT_209 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_210 = zT_208 - tst;
    zT_211 = tst <= zT_208;
    if (!(zT_211)) { pal_trap(); }
    zT_212.ptr = (unsigned char*)zT_209;
    zT_212.len = zT_210;
    zT_205 = zT_212;
    zF_48AC7B3A_markerWrite(zT_205);
    zT_214 = " ";
    zT_216 = 1;
    zT_215.ptr = (unsigned char*)zT_214;
    zT_215.len = zT_216;
    tsp = zT_215;
    zT_217 = tsp;
    zF_48AC7B3A_markerWrite(zT_217);
    goto z_bb_15;
    z_bb_14:
    zT_224 = "\n";
    zT_226 = 1;
    zT_225.ptr = (unsigned char*)zT_224;
    zT_225.len = zT_226;
    tn = zT_225;
    zT_227 = tn;
    zF_48AC7B3A_markerWrite(zT_227);
    goto z_bb_11;
    z_bb_15:
    zT_218 = 1;
    zT_219 = zig_wrap_add_u(((zu64)(tdi)), ((zu64)(zT_218)), 32u);
    zT_220 = zig_overflow_flag_add_u(((zu64)(tdi)), ((zu64)(zT_218)), 32u);
    zT_222 = zT_220 == (unsigned int)(0);
    if (!(zT_222)) { pal_trap(); }
    tdi = zT_219;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_19;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->tuple_index_table;
    zT_2.tuple_index_table = zT_14;
    zT_15 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_15;
    zT_16 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_16;
    zT_17 = &ctx->call_param_map;
    zT_2.call_param_map = zT_17;
    zT_18 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_18;
    frc = zT_2;
    zT_19 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zF_8A0E7747_frontResolveModuleI(zT_19);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15;
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_622E1E76_Opt_254 zT_19;
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23;
    int zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    zT_61A320D8_anon_323976 zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_39;
    zT_6E8D187B_ModuleEntry* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_6E8D187B_ModuleEntry zT_45;
    unsigned int zT_46;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    zT_6B0A7D14_AstStore* zT_65;
    zT_22A7C88B_AstNode zT_69;
    zT_8143F551_AstKind zT_70;
    zT_DA663F79_ComptimeEval* zT_75;
    zT_7534F824_Opt_223 zT_79;
    unsigned char zT_80;
    zT_77F6F59C_ComptimeFoldTable* zT_82;
    zT_89B1DDDA_ComptimeVal zT_84;
    zT_8143F551_AstKind zT_87;
    unsigned char zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned char zT_95;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    zT_22A7C88B_AstNode zT_105;
    zT_8143F551_AstKind zT_107;
    unsigned int zT_108;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char zT_117;
    zT_DA663F79_ComptimeEval* zT_121;
    unsigned int zT_122;
    zT_7534F824_Opt_223 zT_125;
    unsigned char zT_126;
    zT_77F6F59C_ComptimeFoldTable* zT_128;
    unsigned int zT_129;
    zT_89B1DDDA_ComptimeVal zT_130;
    zT_8143F551_AstKind zT_133;
    unsigned char zT_137;
    zT_8143F551_AstKind zT_138;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_146;
    zT_DA663F79_ComptimeEval* zT_150;
    unsigned int zT_151;
    zT_7534F824_Opt_223 zT_154;
    unsigned char zT_155;
    unsigned char zT_157;
    zT_77F6F59C_ComptimeFoldTable* zT_160;
    unsigned int zT_161;
    zT_89B1DDDA_ComptimeVal zT_162;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_105, (unsigned int)sizeof zT_105);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    zT_DDCD424B_Slice_zT_6E8D187B_M p7_mods;
    unsigned int ni;
    unsigned int p7_best_root;
    unsigned int p7_best_id;
    unsigned int p7_si;
    unsigned int p7_r;
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_7534F824_Opt_223 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_7534F824_Opt_223 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    p7_mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    ni = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_27 = ctx->store;
    zT_28 = zT_27->nodes;
    zT_29 = zT_28.len;
    if ((unsigned char)(ni < zT_29)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_32 = 4294967295u;
    p7_best_root = zT_32;
    zT_34 = 4294967295u;
    p7_best_id = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    p7_si = zT_37;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_165 = 1;
    zT_166 = zig_wrap_add_u(((zu64)(ni)), ((zu64)(zT_165)), 32u);
    zT_167 = zig_overflow_flag_add_u(((zu64)(ni)), ((zu64)(zT_165)), 32u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    ni = zT_166;
    goto z_bb_1;
    z_bb_5:
    zT_39 = p7_mods.len;
    if ((unsigned char)(p7_si < zT_39)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = p7_mods.ptr;
    zT_43 = p7_mods.len;
    zT_44 = p7_si < zT_43;
    if (!(zT_44)) { pal_trap(); }
    zT_45 = zT_42[p7_si];
    zT_46 = zT_45.ast_root;
    p7_r = zT_46;
    if ((unsigned char)(p7_r == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    ce.module_id = p7_best_id;
    zT_65 = ctx->store;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_65, (unsigned int)((unsigned int)ni));
    node = zT_69;
    zT_70 = node.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_8:
    zT_58 = 1;
    zT_59 = (unsigned int)zT_58;
    zT_60 = zig_wrap_add_u(((zu64)(p7_si)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(p7_si)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    p7_si = zT_60;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)((unsigned int)((unsigned int)p7_r) >= ni)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_51 = p7_r < p7_best_root;
    goto z_bb_13;
    z_bb_12:
    zT_51 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_51) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    p7_best_root = p7_r;
    zT_53 = p7_mods.ptr;
    zT_54 = p7_mods.len;
    zT_55 = p7_si < zT_54;
    if (!(zT_55)) { pal_trap(); }
    zT_56 = zT_53[p7_si];
    zT_57 = zT_56.id;
    p7_best_id = zT_57;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_75 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_79 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_75, (unsigned int)((unsigned int)ni));
    val = zT_79;
    zT_80 = val.has_value;
    if (zT_80) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_4;
    z_bb_18:
    zT_87 = node.kind;
    if ((unsigned char)(zT_87 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    if (!(val.has_value)) { pal_trap(); }
    v = val.value;
    zT_82 = &ctx->comptime_folds;
    zT_84 = v;
    zF_376429F5_comptimeFoldTablePu(zT_82, (unsigned int)((unsigned int)ni), zT_84);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_92 = node.child_1;
    zT_93 = 0;
    zT_91 = zT_92 != (unsigned int)zT_93;
    goto z_bb_23;
    z_bb_22:
    zT_91 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_91) goto z_bb_24; else goto z_bb_26;
    z_bb_24:
    zT_95 = node.flags;
    if ((unsigned char)((unsigned char)(zT_95 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    goto z_bb_17;
    z_bb_26:
    zT_133 = node.kind;
    if ((unsigned char)(zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_43; else goto z_bb_42;
    z_bb_27:
    zT_101 = ctx->store;
    zT_102 = node.child_1;
    zT_105 = zF_FCDD1D35_astStoreNodeAt(zT_101, zT_102);
    init_n = zT_105;
    zT_107 = init_n.kind;
    zT_108 = (unsigned int)zT_107;
    ik = zT_108;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_111 = ik <= (unsigned int)(42);
    goto z_bb_31;
    z_bb_30:
    zT_111 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_111) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_114 = ik == (unsigned int)(62);
    goto z_bb_34;
    z_bb_33:
    zT_114 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_114) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_117 = ik == (unsigned int)(64);
    goto z_bb_37;
    z_bb_36:
    zT_117 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_117) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_121 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_122 = node.child_1;
    zT_125 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_121, zT_122);
    val2 = zT_125;
    zT_126 = val2.has_value;
    if (zT_126) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_28;
    z_bb_40:
    if (!(val2.has_value)) { pal_trap(); }
    v2 = val2.value;
    zT_128 = &ctx->comptime_folds;
    zT_129 = node.child_1;
    zT_130 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_128, zT_129, zT_130);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_138 = node.kind;
    zT_137 = zT_138 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt);
    goto z_bb_44;
    z_bb_43:
    zT_137 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_137) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_142 = ctx->store;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_142, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_146 == (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_25;
    z_bb_47:
    zT_150 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_151 = node.child_0;
    zT_154 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_150, zT_151);
    cval = zT_154;
    zT_155 = cval.has_value;
    if (zT_155) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    if (!(cval.has_value)) { pal_trap(); }
    cv = cval.value;
    zT_157 = cv.kind;
    if ((unsigned char)(zT_157 == (unsigned char)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_160 = &ctx->comptime_folds;
    zT_161 = node.child_0;
    zT_162 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_160, zT_161, zT_162);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_50;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_21D3708C_U32ToU32Map* zT_25;
    zT_A4CE86B7_U64ToU32Map* zT_26;
    zT_072B53A6_ModuleRegistry* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_30;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_69057089_CompilerAlloc* zT_38;
    zT_6E8D187B_ModuleEntry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zT_6E8D187B_ModuleEntry* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_78;
    zT_3E40CD83_Sand* zT_80;
    zT_8EED1867_ResolvedTypeTable* zT_81;
    zT_F85C5DED_DiagnosticCollector* zT_82;
    zT_338B7C76_TypeRegistry* zT_83;
    zT_3D7259E2_SymbolRegistry* zT_84;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_66E7D2EF_CoercionTable* zT_88;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_21D3708C_U32ToU32Map* zT_90;
    zT_21D3708C_U32ToU32Map* zT_91;
    zT_D3EB6303_StringInterner* zT_92;
    zT_21D3708C_U32ToU32Map* zT_93;
    zT_21D3708C_U32ToU32Map* zT_94;
    zT_072B53A6_ModuleRegistry* zT_95;
    zT_A4CE86B7_U64ToU32Map* zT_96;
    zT_69057089_CompilerAlloc* zT_97;
    zT_6E8D187B_ModuleEntry* zT_104;
    unsigned int zT_105;
    unsigned char zT_106;
    zT_6E8D187B_ModuleEntry zT_107;
    zT_38C12417_SemanticAnalyzer zT_118;
    zT_77F6F59C_ComptimeFoldTable* zT_119;
    zT_F3991012_Opt_346 zT_120;
    int zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    unsigned int zT_132;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    zT_22A7C88B_AstNode zT_137;
    unsigned char* zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    zT_8143F551_AstKind zT_143;
    unsigned int zT_147;
    int zT_148;
    zT_6DCFC8DB_FrontResCtx* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_154;
    zT_6E8D187B_ModuleEntry* zT_156;
    unsigned int zT_157;
    unsigned char zT_158;
    zT_6E8D187B_ModuleEntry zT_159;
    zT_6E8D187B_ModuleEntry* zT_163;
    unsigned int zT_164;
    unsigned char zT_165;
    zT_6E8D187B_ModuleEntry zT_166;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    zT_38C12417_SemanticAnalyzer* zT_173;
    unsigned int zT_174;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned char zT_185;
    unsigned int zT_186;
    zT_6B0A7D14_AstStore* zT_190;
    unsigned int zT_191;
    zT_22A7C88B_AstNode zT_194;
    zT_8143F551_AstKind zT_195;
    zT_38C12417_SemanticAnalyzer* zT_199;
    unsigned int zT_200;
    zT_8143F551_AstKind zT_202;
    unsigned char zT_206;
    unsigned char zT_207;
    zT_38C12417_SemanticAnalyzer* zT_212;
    unsigned int zT_213;
    zT_8143F551_AstKind zT_215;
    zT_38C12417_SemanticAnalyzer* zT_219;
    unsigned int zT_220;
    zT_8143F551_AstKind zT_222;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_227;
    int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned char zT_234;
    int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned char zT_240;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_132, (unsigned int)sizeof zT_132);
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    zig_poison_fill((void*)&zT_194, (unsigned int)sizeof zT_194);
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->tuple_index_table;
    zT_10.tuple_index_table = zT_22;
    zT_23 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_23;
    zT_24 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_24;
    zT_25 = &ctx->call_param_map;
    zT_10.call_param_map = zT_25;
    zT_26 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_26;
    frc = zT_10;
    zT_28 = ctx->module_reg;
    zT_30 = zF_3452C137_moduleRegistryGetMo(zT_28);
    mods = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    mi = zT_33;
    goto z_bb_1;
    z_bb_1:
    zT_35 = mods.len;
    if ((unsigned char)(mi < zT_35)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = ctx->alloc;
    zT_37 = &zT_38->scratch;
    zF_F1B3F8C2_sandReset(zT_37);
    zT_41 = mods.ptr;
    zT_42 = mods.len;
    zT_43 = mi < zT_42;
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_41[mi];
    zT_45 = zT_44.ast_root;
    ast_root = zT_45;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_235 = 1;
    zT_236 = (unsigned int)zT_235;
    zT_237 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_236)), 32u);
    zT_238 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_236)), 32u);
    zT_240 = zT_238 == (unsigned int)(0);
    if (!(zT_240)) { pal_trap(); }
    mi = zT_237;
    goto z_bb_1;
    z_bb_5:
    zT_49 = "MZ";
    zT_51 = 2;
    zT_50.ptr = (unsigned char*)zT_49;
    zT_50.len = zT_51;
    mz = zT_50;
    zT_52 = mz;
    zF_48AC7B3A_markerWrite(zT_52);
    goto z_bb_4;
    z_bb_6:
    zT_54 = ctx->store;
    zT_55 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    zT_59 = ctx->store;
    zT_60 = ast_root;
    zT_62 = zF_152E19CB_astStoreNodeExtraCh(zT_59, zT_60);
    decls_n = zT_62;
    zT_64 = "AD";
    zT_66 = 2;
    zT_65.ptr = (unsigned char*)zT_64;
    zT_65.len = zT_66;
    ad = zT_65;
    zT_67 = ad;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_69 = "DSE\n";
    zT_71 = 4;
    zT_70.ptr = (unsigned char*)zT_69;
    zT_70.len = zT_71;
    dse_m = zT_70;
    zT_72 = dse_m;
    zF_48AC7B3A_markerWrite(zT_72);
    zT_74 = mods.ptr;
    zT_75 = mods.len;
    zT_76 = mi < zT_75;
    if (!(zT_76)) { pal_trap(); }
    zT_77 = zT_74[mi];
    zT_78 = zT_77.source_file_id;
    src_fid = zT_78;
    zT_97 = ctx->alloc;
    zT_80 = &zT_97->scratch;
    zT_81 = ctx->resolved_types;
    zT_82 = ctx->diag;
    zT_83 = ctx->typereg;
    zT_84 = ctx->symbol_reg;
    zT_85 = ctx->store;
    zT_104 = mods.ptr;
    zT_105 = mods.len;
    zT_106 = mi < zT_105;
    if (!(zT_106)) { pal_trap(); }
    zT_107 = zT_104[mi];
    zT_86 = zT_107.id;
    zT_87 = src_fid;
    zT_88 = ctx->coercion_table;
    zT_89 = &ctx->enum_value_table;
    zT_90 = &ctx->tuple_index_table;
    zT_91 = &ctx->error_code_registry;
    zT_92 = ctx->interner;
    zT_93 = &ctx->call_arg_types;
    zT_94 = &ctx->call_param_map;
    zT_95 = ctx->module_reg;
    zT_96 = &ctx->suspending_fns;
    zT_118 = zF_84ADA681_semanticAnalyzerIni(zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90, zT_91, zT_92, zT_93, zT_94, zT_95, zT_96);
    sa = zT_118;
    zT_119 = &ctx->comptime_folds;
    zT_120.has_value = 1;
    zT_120.value = zT_119;
    sa.comptime_folds = zT_120;
    zT_122 = 0;
    zT_123 = (unsigned int)zT_122;
    di = zT_123;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_127 = ctx->store;
    zT_128 = ast_root;
    zT_132 = zF_B10B1BC1_astStoreNodeExtraCh(zT_127, zT_128, (unsigned int)((unsigned int)di));
    decl_idx = zT_132;
    zT_134 = ctx->store;
    zT_135 = decl_idx;
    zT_137 = zF_FCDD1D35_astStoreNodeAt(zT_134, zT_135);
    decl = zT_137;
    zT_139 = "DN";
    zT_141 = 2;
    zT_140.ptr = (unsigned char*)zT_139;
    zT_140.len = zT_141;
    dn = zT_140;
    zT_142 = dn;
    zF_48AC7B3A_markerWrite(zT_142);
    zT_143 = decl.kind;
    if ((unsigned char)(zT_143 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_229 = 1;
    zT_230 = (unsigned int)zT_229;
    zT_231 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_230)), 32u);
    zT_232 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_230)), 32u);
    zT_234 = zT_232 == (unsigned int)(0);
    if (!(zT_234)) { pal_trap(); }
    di = zT_231;
    goto z_bb_7;
    z_bb_11:
    zT_147 = decl.child_0;
    zT_148 = 0;
    if ((unsigned char)(zT_147 != (unsigned int)zT_148)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_181 = decl.kind;
    if ((unsigned char)(zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_150 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zT_156 = mods.ptr;
    zT_157 = mods.len;
    zT_158 = mi < zT_157;
    if (!(zT_158)) { pal_trap(); }
    zT_159 = zT_156[mi];
    zT_151 = zT_159.id;
    zT_152 = decl.child_0;
    zT_163 = mods.ptr;
    zT_164 = mods.len;
    zT_165 = mi < zT_164;
    if (!(zT_165)) { pal_trap(); }
    zT_166 = zT_163[mi];
    zT_154 = zT_166.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_150, zT_151, zT_152, (unsigned int)(0), zT_154);
    goto z_bb_15;
    z_bb_15:
    zT_169 = "SA";
    zT_171 = 2;
    zT_170.ptr = (unsigned char*)zT_169;
    zT_170.len = zT_171;
    sa0 = zT_170;
    zT_172 = sa0;
    zF_48AC7B3A_markerWrite(zT_172);
    zT_173 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_174 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_173, zT_174);
    zT_177 = "sA";
    zT_179 = 2;
    zT_178.ptr = (unsigned char*)zT_177;
    zT_178.len = zT_179;
    sa1 = zT_178;
    zT_180 = sa1;
    zF_48AC7B3A_markerWrite(zT_180);
    goto z_bb_12;
    z_bb_16:
    zT_186 = decl.child_1;
    zT_185 = zT_186 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_185 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_185) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_190 = ctx->store;
    zT_191 = decl.child_1;
    zT_194 = zF_FCDD1D35_astStoreNodeAt(zT_190, zT_191);
    di_inn = zT_194;
    zT_195 = di_inn.kind;
    if ((unsigned char)(zT_195 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_222 = decl.kind;
    if ((unsigned char)(zT_222 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_199 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_200 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_199, zT_200);
    goto z_bb_23;
    z_bb_23:
    zT_202 = di_inn.kind;
    if ((unsigned char)(zT_202 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_207 = di_inn.flags;
    zT_206 = (unsigned char)(zT_207 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_206 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_206) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_212 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_213 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_212, zT_213);
    goto z_bb_28;
    z_bb_28:
    zT_215 = di_inn.kind;
    if ((unsigned char)(zT_215 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_219 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_220 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_219, zT_220);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_226 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_227 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_226, zT_227);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    unsigned int zT_44;
    zT_3D7259E2_SymbolRegistry* zT_48;
    zT_060CD1EB_SymbolTable* zT_52;
    zT_7E2F335A_AnalyzerContext zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    zT_338B7C76_TypeRegistry* zT_56;
    zT_D3EB6303_StringInterner* zT_57;
    zT_F85C5DED_DiagnosticCollector* zT_58;
    zT_69057089_CompilerAlloc* zT_59;
    zT_3E40CD83_Sand* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_69057089_CompilerAlloc* zT_65;
    zT_3E40CD83_Sand* zT_66;
    unsigned int zT_67;
    unsigned char zT_68;
    zT_C98AF326_CompilerCli zT_69;
    unsigned char zT_70;
    unsigned char zT_71;
    int zT_72;
    int zT_74;
    unsigned char zT_76;
    zT_C98AF326_CompilerCli zT_77;
    unsigned char zT_78;
    unsigned char zT_79;
    int zT_80;
    int zT_82;
    unsigned char zT_84;
    zT_C98AF326_CompilerCli zT_85;
    unsigned char zT_86;
    unsigned char zT_87;
    int zT_88;
    int zT_90;
    unsigned char zT_92;
    zT_C98AF326_CompilerCli zT_93;
    unsigned char zT_94;
    unsigned char zT_95;
    int zT_96;
    int zT_98;
    unsigned char zT_100;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned char zT_104;
    zT_6E8D187B_ModuleEntry* zT_105;
    unsigned int zT_106;
    unsigned char zT_107;
    zT_6E8D187B_ModuleEntry zT_108;
    unsigned int zT_109;
    zT_7E2F335A_AnalyzerContext* zT_110;
    unsigned int zT_111;
    zT_227EDE07_SourceManager* zT_113;
    int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = mods.len;
    zT_42 = mi < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_40[mi];
    zT_44 = zT_43.ast_root;
    ast_root = zT_44;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_115 = 1;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    mi = zT_117;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_48 = ctx->symbol_reg;
    zT_52 = zF_9B36C202_symbolRegistryGetTa(zT_48, (unsigned int)((unsigned int)mi));
    sym_table = zT_52;
    zT_55 = ctx->store;
    zT_54.store = zT_55;
    zT_56 = ctx->typereg;
    zT_54.registry = zT_56;
    zT_57 = ctx->interner;
    zT_54.interner = zT_57;
    zT_58 = ctx->diag;
    zT_54.diag = zT_58;
    zT_54.symbols = sym_table;
    zT_59 = ctx->alloc;
    zT_60 = &zT_59->scratch;
    zT_54.alloc = zT_60;
    zT_61 = 0;
    zT_54.current_fn_name = zT_61;
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zT_54.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_62;
    zT_63 = 0;
    zT_54.defer_queue_len = zT_63;
    zT_64 = 0;
    zT_54.defer_queue_cap = zT_64;
    zT_65 = ctx->alloc;
    zT_66 = &zT_65->scratch;
    zT_54.defer_queue_alloc = zT_66;
    zT_67 = 0;
    zT_54.current_depth = zT_67;
    zT_68 = 0;
    zT_54.null_analysis_mode = zT_68;
    zT_69 = ctx->cli;
    zT_70 = zT_69.no_null_check;
    if (zT_70) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_72 = 1;
    zT_71 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_16:
    zT_74 = 0;
    zT_71 = (unsigned char)zT_74;
    goto z_bb_17;
    z_bb_17:
    zT_76 = (unsigned char)zT_71;
    zT_54.skip_null_check = zT_76;
    zT_77 = ctx->cli;
    zT_78 = zT_77.no_lifetime_check;
    if (zT_78) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_80 = 1;
    zT_79 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_19:
    zT_82 = 0;
    zT_79 = (unsigned char)zT_82;
    goto z_bb_20;
    z_bb_20:
    zT_84 = (unsigned char)zT_79;
    zT_54.skip_lifetime_check = zT_84;
    zT_85 = ctx->cli;
    zT_86 = zT_85.no_leak_check;
    if (zT_86) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_88 = 1;
    zT_87 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_22:
    zT_90 = 0;
    zT_87 = (unsigned char)zT_90;
    goto z_bb_23;
    z_bb_23:
    zT_92 = (unsigned char)zT_87;
    zT_54.skip_doublefree_check = zT_92;
    zT_93 = ctx->cli;
    zT_94 = zT_93.warn_all;
    if (zT_94) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_96 = 1;
    zT_95 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_25:
    zT_98 = 0;
    zT_95 = (unsigned char)zT_98;
    goto z_bb_26;
    z_bb_26:
    zT_100 = (unsigned char)zT_95;
    zT_54.warn_all = zT_100;
    zT_101 = zF_43C99FB3_onNullStmt;
    zT_54.on_stmt_cb = zT_101;
    zT_102 = 0;
    zT_54.in_defer_exec = zT_102;
    zT_103 = 0;
    zT_54.lifetime_analysis_mode = zT_103;
    zT_104 = 0;
    zT_54.doublefree_analysis_mode = zT_104;
    zT_105 = mods.ptr;
    zT_106 = mods.len;
    zT_107 = mi < zT_106;
    if (!(zT_107)) { pal_trap(); }
    zT_108 = zT_105[mi];
    zT_109 = zT_108.source_file_id;
    zT_54.source_file_id = zT_109;
    ac = zT_54;
    zT_110 = (zT_7E2F335A_AnalyzerContext*)&ac;
    zT_111 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_110, zT_111);
    zT_113 = ctx->source_man;
    zF_196FDF3B_sourceManagerResetF(zT_113);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_ConstInit */
void zF_A6065296_phase_ConstInit(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15;
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_622E1E76_Opt_254 zT_19;
    zT_4D150975_ConstInitEvalCtx zT_21;
    zT_4065182A_ConstInitTable* zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_8EED1867_ResolvedTypeTable* zT_26;
    zT_DA663F79_ComptimeEval* zT_27;
    zT_21D3708C_U32ToU32Map* zT_28;
    zT_072B53A6_ModuleRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_31;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_33;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    unsigned int zT_44;
    zT_6E8D187B_ModuleEntry* zT_47;
    unsigned int zT_48;
    unsigned char zT_49;
    zT_6E8D187B_ModuleEntry zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode zT_72;
    zT_8143F551_AstKind zT_73;
    unsigned char zT_77;
    unsigned char zT_83;
    unsigned int zT_89;
    zT_4D150975_ConstInitEvalCtx* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_96;
    unsigned int zT_97;
    unsigned char zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    zT_BAEE192E_Opt_10 zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned char zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned char zT_111;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_101, (unsigned int)sizeof zT_101);
    zT_8F083A69_Slice_zT_0B42B2F8_u ci_m;
    zT_DA663F79_ComptimeEval ci_ce;
    zT_4D150975_ConstInitEvalCtx cic;
    zT_DDCD424B_Slice_zT_6E8D187B_M cmods;
    unsigned int cmi;
    unsigned int croot;
    unsigned int cdn;
    unsigned int cdi;
    unsigned int cdecl_idx;
    zT_22A7C88B_AstNode cdecl;
    zT_2 = "CIE\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    ci_m = zT_3;
    zT_5 = ci_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ci_ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ci_ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ci_ce.diag = zT_19;
    zT_22 = &ctx->const_inits;
    zT_21.tbl = zT_22;
    zT_23 = ctx->store;
    zT_21.store = zT_23;
    zT_24 = ctx->typereg;
    zT_21.registry = zT_24;
    zT_25 = ctx->symbol_reg;
    zT_21.symbol_reg = zT_25;
    zT_26 = ctx->resolved_types;
    zT_21.resolved = zT_26;
    zT_27 = (zT_DA663F79_ComptimeEval*)&ci_ce;
    zT_21.ce = zT_27;
    zT_28 = &ctx->enum_value_table;
    zT_21.enum_values = zT_28;
    zT_29 = ctx->module_reg;
    zT_21.module_reg = zT_29;
    cic = zT_21;
    zT_31 = ctx->module_reg;
    zT_33 = zF_3452C137_moduleRegistryGetMo(zT_31);
    cmods = zT_33;
    zT_35 = 0;
    cmi = zT_35;
    goto z_bb_1;
    z_bb_1:
    zT_37 = cmods.len;
    if ((unsigned char)(cmi < zT_37)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_40 = cmods.ptr;
    zT_41 = cmods.len;
    zT_42 = cmi < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_40[cmi];
    zT_44 = zT_43.ast_root;
    croot = zT_44;
    if ((unsigned char)(croot == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_107 = 1;
    zT_108 = zig_wrap_add_u(((zu64)(cmi)), ((zu64)(zT_107)), 32u);
    zT_109 = zig_overflow_flag_add_u(((zu64)(cmi)), ((zu64)(zT_107)), 32u);
    zT_111 = zT_109 == (unsigned int)(0);
    if (!(zT_111)) { pal_trap(); }
    cmi = zT_108;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_47 = cmods.ptr;
    zT_48 = cmods.len;
    zT_49 = cmi < zT_48;
    if (!(zT_49)) { pal_trap(); }
    zT_50 = zT_47[cmi];
    zT_51 = zT_50.id;
    ci_ce.module_id = zT_51;
    zT_53 = ctx->store;
    zT_54 = croot;
    zT_56 = zF_152E19CB_astStoreNodeExtraCh(zT_53, zT_54);
    cdn = zT_56;
    zT_58 = 0;
    cdi = zT_58;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cdn))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_62 = ctx->store;
    zT_63 = croot;
    zT_67 = zF_B10B1BC1_astStoreNodeExtraCh(zT_62, zT_63, (unsigned int)((unsigned int)cdi));
    cdecl_idx = zT_67;
    zT_69 = ctx->store;
    zT_70 = cdecl_idx;
    zT_72 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    cdecl = zT_72;
    zT_73 = cdecl.kind;
    if ((unsigned char)(zT_73 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_102 = 1;
    zT_103 = zig_wrap_add_u(((zu64)(cdi)), ((zu64)(zT_102)), 32u);
    zT_104 = zig_overflow_flag_add_u(((zu64)(cdi)), ((zu64)(zT_102)), 32u);
    zT_106 = zT_104 == (unsigned int)(0);
    if (!(zT_106)) { pal_trap(); }
    cdi = zT_103;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_77 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_77) & (unsigned short)(4)) != (unsigned short)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_83 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_83) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_89 = cdecl.child_1;
    if ((unsigned char)(zT_89 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_92 = (zT_4D150975_ConstInitEvalCtx*)&cic;
    zT_96 = cmods.ptr;
    zT_97 = cmods.len;
    zT_98 = cmi < zT_97;
    if (!(zT_98)) { pal_trap(); }
    zT_99 = zT_96[cmi];
    zT_93 = zT_99.id;
    zT_94 = cdecl_idx;
    zT_101 = zF_2B750645_constInitEvaluate(zT_92, zT_93, zT_94);
    (void)zT_101;
    goto z_bb_10;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_61A320D8_anon_323976 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned char zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_4028D896_Arr_unsigned_char_2 zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_01BE9D46_AstValuePool zT_53;
    unsigned int zT_54;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_69057089_CompilerAlloc* zT_84;
    zT_CA01C129_LirSlotArrayList* zT_87;
    zT_846744CC_Arr_unsigned_char_5 zT_89;
    unsigned int zT_91;
    zT_C98AF326_CompilerCli zT_92;
    unsigned char zT_93;
    zT_C98AF326_CompilerCli zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_98;
    unsigned int zT_100;
    unsigned char zT_102;
    unsigned char* zT_105;
    unsigned int zT_106;
    unsigned char zT_107;
    unsigned char zT_108;
    unsigned char zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    unsigned char zT_121;
    unsigned char zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned char zT_129;
    unsigned char zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    unsigned char zT_137;
    unsigned char zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_144;
    unsigned char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned int zT_150;
    unsigned int zT_152;
    unsigned char zT_154;
    unsigned char* zT_157;
    unsigned int zT_158;
    unsigned char zT_159;
    unsigned char zT_160;
    unsigned char zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_172;
    zT_7E7544E4_LirStream* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    zT_3E40CD83_Sand* zT_175;
    int zT_179;
    unsigned char* zT_180;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned char zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    zT_69057089_CompilerAlloc* zT_185;
    zT_C98AF326_CompilerCli zT_187;
    unsigned char zT_188;
    zT_846744CC_Arr_unsigned_char_5 zT_190;
    unsigned int zT_192;
    zT_C98AF326_CompilerCli zT_193;
    unsigned char zT_194;
    zT_C98AF326_CompilerCli zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_199;
    unsigned int zT_201;
    unsigned char zT_203;
    unsigned char* zT_206;
    unsigned int zT_207;
    unsigned char zT_208;
    unsigned char zT_209;
    unsigned char zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned char zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned char zT_221;
    unsigned char zT_222;
    unsigned char zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned char zT_229;
    unsigned char zT_230;
    unsigned char zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned char zT_237;
    unsigned char zT_238;
    unsigned char zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned char zT_245;
    unsigned char* zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    unsigned int zT_249;
    unsigned int zT_251;
    unsigned int zT_253;
    unsigned char zT_255;
    unsigned char* zT_258;
    unsigned int zT_259;
    unsigned char zT_260;
    unsigned char zT_261;
    unsigned char zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned char zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned char zT_273;
    zT_C615AE29_DebugSpanStore* zT_274;
    zT_3E40CD83_Sand* zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    zT_69057089_CompilerAlloc* zT_278;
    int zT_282;
    unsigned char* zT_283;
    unsigned int zT_284;
    unsigned char zT_285;
    unsigned char zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    zT_6B356268_SemanticContext zT_289;
    zT_6B0A7D14_AstStore* zT_290;
    zT_338B7C76_TypeRegistry* zT_291;
    zT_3D7259E2_SymbolRegistry* zT_292;
    zT_8EED1867_ResolvedTypeTable* zT_293;
    zT_66E7D2EF_CoercionTable* zT_294;
    zT_F85C5DED_DiagnosticCollector* zT_295;
    unsigned char zT_296;
    zT_21D3708C_U32ToU32Map* zT_297;
    zT_21D3708C_U32ToU32Map* zT_298;
    zT_21D3708C_U32ToU32Map* zT_299;
    zT_21D3708C_U32ToU32Map* zT_300;
    zT_77F6F59C_ComptimeFoldTable* zT_301;
    zT_4065182A_ConstInitTable* zT_302;
    unsigned int zT_303;
    zT_C98AF326_CompilerCli zT_304;
    unsigned char zT_305;
    zT_A4CE86B7_U64ToU32Map* zT_306;
    zT_A4CE86B7_U64ToU32Map* zT_307;
    zT_A4CE86B7_U64ToU32Map* zT_308;
    unsigned char zT_309;
    zT_072B53A6_ModuleRegistry* zT_311;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_313;
    zT_3E40CD83_Sand* zT_315;
    zT_69057089_CompilerAlloc* zT_316;
    zT_B687BB96_U32ArrayList zT_318;
    unsigned char zT_320;
    int zT_322;
    unsigned int zT_323;
    unsigned int zT_325;
    zT_6E8D187B_ModuleEntry* zT_327;
    unsigned int zT_328;
    unsigned char zT_329;
    zT_6E8D187B_ModuleEntry zT_330;
    unsigned int zT_331;
    unsigned char* zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    unsigned int zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    zT_4028D896_Arr_unsigned_char_2 zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    int zT_345;
    unsigned char* zT_346;
    unsigned int zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned int zT_349;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned char zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_360;
    unsigned char* zT_361;
    unsigned int zT_362;
    unsigned char zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    unsigned char* zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned int zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    zT_6E8D187B_ModuleEntry* zT_370;
    unsigned int zT_371;
    unsigned char zT_372;
    zT_6E8D187B_ModuleEntry zT_373;
    unsigned int zT_374;
    zT_4028D896_Arr_unsigned_char_2 zT_378;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    zT_6E8D187B_ModuleEntry* zT_382;
    unsigned int zT_383;
    unsigned char zT_384;
    zT_6E8D187B_ModuleEntry zT_385;
    int zT_389;
    unsigned char* zT_390;
    unsigned int zT_391;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    unsigned int zT_393;
    unsigned int zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned char zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_404;
    unsigned char* zT_405;
    unsigned int zT_406;
    unsigned char zT_407;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_409;
    zT_6B0A7D14_AstStore* zT_411;
    unsigned int zT_412;
    zT_6E8D187B_ModuleEntry* zT_414;
    unsigned int zT_415;
    unsigned char zT_416;
    zT_6E8D187B_ModuleEntry zT_417;
    zT_22A7C88B_AstNode zT_419;
    zT_8143F551_AstKind zT_420;
    unsigned char* zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    unsigned int zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428;
    zT_6B0A7D14_AstStore* zT_430;
    unsigned int zT_431;
    zT_6E8D187B_ModuleEntry* zT_433;
    unsigned int zT_434;
    unsigned char zT_435;
    zT_6E8D187B_ModuleEntry zT_436;
    unsigned int zT_438;
    unsigned int zT_440;
    zT_4028D896_Arr_unsigned_char_2 zT_442;
    unsigned int zT_444;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_445;
    int zT_448;
    unsigned char* zT_449;
    unsigned int zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned int zT_452;
    unsigned int zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    unsigned int zT_457;
    unsigned char zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    unsigned int zT_463;
    unsigned char* zT_464;
    unsigned int zT_465;
    unsigned char zT_466;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    zT_6B0A7D14_AstStore* zT_469;
    unsigned int zT_470;
    zT_B687BB96_U32ArrayList* zT_471;
    zT_6E8D187B_ModuleEntry* zT_473;
    unsigned int zT_474;
    unsigned char zT_475;
    zT_6E8D187B_ModuleEntry zT_476;
    zT_6E8D187B_ModuleEntry* zT_478;
    unsigned int zT_479;
    unsigned char zT_480;
    zT_6E8D187B_ModuleEntry* zT_481;
    unsigned char zT_484;
    unsigned int zT_486;
    zT_6B0A7D14_AstStore* zT_490;
    unsigned int zT_491;
    zT_6E8D187B_ModuleEntry* zT_494;
    unsigned int zT_495;
    unsigned char zT_496;
    zT_6E8D187B_ModuleEntry zT_497;
    unsigned int zT_500;
    zT_6B0A7D14_AstStore* zT_502;
    unsigned int zT_503;
    zT_22A7C88B_AstNode zT_505;
    zT_8143F551_AstKind zT_507;
    unsigned int zT_508;
    zT_4028D896_Arr_unsigned_char_2 zT_510;
    unsigned int zT_512;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_513;
    int zT_516;
    unsigned char* zT_517;
    unsigned int zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned int zT_520;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_525;
    unsigned char zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_531;
    unsigned char* zT_532;
    unsigned int zT_533;
    unsigned char zT_534;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_535;
    unsigned char* zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    unsigned int zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    zT_8143F551_AstKind zT_541;
    unsigned char* zT_546;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_547;
    unsigned int zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    unsigned char zT_550;
    zT_6B0A7D14_AstStore* zT_557;
    zT_5838FCFA_anon_324009 zT_558;
    zT_243D6A41_FnProto* zT_559;
    zT_6B0A7D14_AstStore* zT_560;
    unsigned int zT_561;
    unsigned int zT_563;
    unsigned int zT_564;
    zT_243D6A41_FnProto zT_565;
    zT_6E8D187B_ModuleEntry* zT_567;
    unsigned int zT_568;
    unsigned char zT_569;
    zT_6E8D187B_ModuleEntry zT_570;
    unsigned int zT_571;
    zT_79FAE712_u64 zT_572;
    zT_79FAE712_u64 zT_573;
    zT_79FAE712_u64 zT_574;
    unsigned char zT_576;
    unsigned int zT_577;
    unsigned char zT_579;
    zT_79FAE712_u64 zT_580;
    zT_79FAE712_u64 zT_581;
    zT_79FAE712_u64 zT_582;
    unsigned char zT_584;
    unsigned int zT_585;
    unsigned char zT_587;
    unsigned int zT_589;
    zT_79FAE712_u64 zT_591;
    zT_A4CE86B7_U64ToU32Map* zT_592;
    zT_79FAE712_u64 zT_593;
    zT_6B356268_SemanticContext* zT_598;
    zT_3E40CD83_Sand* zT_599;
    zT_69057089_CompilerAlloc* zT_601;
    zT_02EB57B2_LirLowerer zT_603;
    zT_6E8D187B_ModuleEntry* zT_604;
    unsigned int zT_605;
    unsigned char zT_606;
    zT_6E8D187B_ModuleEntry zT_607;
    unsigned int zT_608;
    zT_072B53A6_ModuleRegistry* zT_609;
    zT_C98AF326_CompilerCli zT_610;
    unsigned char zT_611;
    unsigned char zT_612;
    int zT_613;
    int zT_615;
    zT_C98AF326_CompilerCli zT_618;
    unsigned char zT_619;
    zT_6B0A7D14_AstStore* zT_621;
    zT_5838FCFA_anon_324009 zT_622;
    zT_243D6A41_FnProto* zT_623;
    zT_6B0A7D14_AstStore* zT_624;
    unsigned int zT_625;
    unsigned int zT_627;
    unsigned int zT_628;
    zT_243D6A41_FnProto zT_629;
    zT_227EDE07_SourceManager* zT_631;
    unsigned int zT_632;
    unsigned int zT_633;
    zT_6E8D187B_ModuleEntry* zT_635;
    unsigned int zT_636;
    unsigned char zT_637;
    zT_6E8D187B_ModuleEntry zT_638;
    zT_5BC08DC6_Location zT_641;
    zT_8B83E3B4_DebugSymbolList* zT_642;
    zT_1001656C_DebugSymbol zT_643;
    zT_8B83E3B4_DebugSymbolList* zT_644;
    zT_1001656C_DebugSymbol zT_645;
    unsigned char zT_646;
    unsigned char zT_647;
    unsigned char zT_653;
    int zT_654;
    int zT_656;
    unsigned char zT_658;
    unsigned int zT_659;
    zT_6E8D187B_ModuleEntry* zT_660;
    unsigned int zT_661;
    unsigned char zT_662;
    zT_6E8D187B_ModuleEntry zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    zT_6E8D187B_ModuleEntry* zT_667;
    unsigned int zT_668;
    unsigned char zT_669;
    zT_6E8D187B_ModuleEntry zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    zT_C98AF326_CompilerCli zT_673;
    unsigned char zT_674;
    zT_1F328BC1_DebugSpanArrayList zT_675;
    int zT_676;
    zT_02EB57B2_LirLowerer* zT_678;
    zT_1F328BC1_DebugSpanArrayList* zT_679;
    zT_02EB57B2_LirLowerer* zT_681;
    unsigned int zT_682;
    zT_BBC23664_LirFunction zT_684;
    zT_A4CE86B7_U64ToU32Map* zT_685;
    unsigned int zT_686;
    unsigned int zT_687;
    unsigned char zT_691;
    zT_3E40CD83_Sand* zT_693;
    zT_338B7C76_TypeRegistry* zT_694;
    zT_BBC23664_LirFunction* zT_695;
    zT_A4CE86B7_U64ToU32Map* zT_696;
    zT_A4CE86B7_U64ToU32Map* zT_697;
    zT_A4CE86B7_U64ToU32Map* zT_698;
    zT_A4CE86B7_U64ToU32Map* zT_699;
    zT_A4CE86B7_U64ToU32Map* zT_700;
    zT_A4CE86B7_U64ToU32Map* zT_701;
    zT_B687BB96_U32ArrayList* zT_702;
    zT_A4CE86B7_U64ToU32Map* zT_703;
    zT_A4CE86B7_U64ToU32Map* zT_704;
    zT_69057089_CompilerAlloc* zT_705;
    zT_3F3BF87A_AsyncFrameLayout zT_718;
    zT_3E40CD83_Sand* zT_719;
    zT_A4CE86B7_U64ToU32Map* zT_720;
    unsigned int zT_721;
    unsigned int zT_722;
    zT_3F3BF87A_AsyncFrameLayout zT_723;
    zT_69057089_CompilerAlloc* zT_724;
    zT_3E40CD83_Sand* zT_730;
    zT_69057089_CompilerAlloc* zT_733;
    zT_FDFD82FD_EU_362 zT_737;
    unsigned char zT_738;
    unsigned char* zT_739;
    zT_BBC23664_LirFunction* zT_742;
    zT_B687BB96_U32ArrayList* zT_743;
    unsigned char zT_748;
    zT_7E7544E4_LirStream* zT_750;
    zT_BBC23664_LirFunction zT_751;
    zT_E7714190_LirSlot zT_753;
    zT_CA01C129_LirSlotArrayList* zT_754;
    zT_E7714190_LirSlot zT_755;
    zT_C98AF326_CompilerCli zT_757;
    unsigned char zT_758;
    zT_C615AE29_DebugSpanStore* zT_759;
    unsigned int zT_760;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_761;
    zT_1F328BC1_DebugSpanArrayList zT_764;
    zT_10BDA76C_DebugSpanEntry* zT_765;
    zT_1F328BC1_DebugSpanArrayList zT_766;
    unsigned int zT_767;
    int zT_768;
    zT_10BDA76C_DebugSpanEntry* zT_769;
    unsigned int zT_770;
    unsigned char zT_771;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_772;
    zT_3E40CD83_Sand* zT_774;
    zT_69057089_CompilerAlloc* zT_775;
    zT_C98AF326_CompilerCli zT_777;
    unsigned char zT_778;
    zT_1F328BC1_DebugSpanArrayList zT_779;
    int zT_780;
    zT_1F328BC1_DebugSpanArrayList* zT_782;
    zT_8143F551_AstKind zT_783;
    unsigned char zT_787;
    zT_6B0A7D14_AstStore* zT_794;
    unsigned int zT_795;
    unsigned int zT_797;
    zT_3D7259E2_SymbolRegistry* zT_799;
    unsigned int zT_800;
    unsigned int zT_801;
    zT_6E8D187B_ModuleEntry* zT_803;
    unsigned int zT_804;
    unsigned char zT_805;
    zT_6E8D187B_ModuleEntry zT_806;
    zT_77F031D4_Opt_960 zT_808;
    unsigned char zT_809;
    zT_3C598AEF_SymbolKind zT_811;
    unsigned int zT_816;
    unsigned char zT_817;
    unsigned char zT_823;
    unsigned int zT_824;
    zT_6B0A7D14_AstStore* zT_828;
    unsigned int zT_829;
    zT_22A7C88B_AstNode zT_832;
    unsigned char zT_834;
    zT_8143F551_AstKind zT_835;
    unsigned char zT_839;
    zT_8143F551_AstKind zT_840;
    zT_6B0A7D14_AstStore* zT_845;
    unsigned int zT_846;
    zT_22A7C88B_AstNode zT_849;
    zT_8143F551_AstKind zT_850;
    unsigned char zT_854;
    zT_21D3708C_U32ToU32Map* zT_857;
    unsigned int zT_858;
    zT_4065182A_ConstInitTable* zT_859;
    zT_BAEE192E_Opt_10 zT_861;
    unsigned char zT_862;
    unsigned char zT_868;
    zT_6E8D187B_ModuleEntry* zT_875;
    unsigned int zT_876;
    unsigned char zT_877;
    zT_6E8D187B_ModuleEntry zT_878;
    unsigned int zT_879;
    zT_79FAE712_u64 zT_880;
    zT_79FAE712_u64 zT_881;
    zT_79FAE712_u64 zT_882;
    unsigned char zT_884;
    unsigned int zT_885;
    unsigned char zT_887;
    zT_79FAE712_u64 zT_888;
    zT_79FAE712_u64 zT_889;
    zT_79FAE712_u64 zT_890;
    unsigned char zT_892;
    unsigned int zT_893;
    unsigned char zT_895;
    zT_79FAE712_u64 zT_898;
    zT_A4CE86B7_U64ToU32Map* zT_899;
    zT_79FAE712_u64 zT_900;
    zT_8EED1867_ResolvedTypeTable* zT_905;
    unsigned int zT_906;
    zT_BAEE192E_Opt_10 zT_908;
    unsigned char zT_910;
    unsigned int zT_911;
    unsigned char zT_916;
    unsigned char zT_919;
    zT_4065182A_ConstInitTable* zT_923;
    unsigned int zT_924;
    zT_49DE1C22_ConstInitNode zT_926;
    unsigned char zT_927;
    unsigned char zT_930;
    unsigned char zT_931;
    unsigned int zT_934;
    unsigned int zT_935;
    unsigned int zT_940;
    zT_79FAE712_u64 zT_941;
    unsigned int zT_944;
    unsigned char zT_945;
    unsigned int zT_948;
    unsigned char zT_949;
    unsigned int zT_952;
    unsigned char zT_954;
    unsigned char zT_955;
    unsigned char zT_961;
    zT_E1A783EF_GlobalDeclArrayList* zT_962;
    zT_54906056_ModuleGlobalDecl zT_963;
    zT_54906056_ModuleGlobalDecl zT_965;
    zT_6E8D187B_ModuleEntry* zT_966;
    unsigned int zT_967;
    unsigned char zT_968;
    zT_6E8D187B_ModuleEntry zT_969;
    unsigned int zT_970;
    unsigned char zT_971;
    zT_C98AF326_CompilerCli zT_972;
    unsigned char zT_973;
    zT_227EDE07_SourceManager* zT_975;
    unsigned int zT_976;
    unsigned int zT_977;
    zT_6E8D187B_ModuleEntry* zT_979;
    unsigned int zT_980;
    unsigned char zT_981;
    zT_6E8D187B_ModuleEntry zT_982;
    zT_5BC08DC6_Location zT_985;
    zT_8B83E3B4_DebugSymbolList* zT_986;
    zT_1001656C_DebugSymbol zT_987;
    zT_1001656C_DebugSymbol zT_989;
    unsigned char zT_990;
    unsigned char zT_991;
    zT_6E8D187B_ModuleEntry* zT_992;
    unsigned int zT_993;
    unsigned char zT_994;
    zT_6E8D187B_ModuleEntry zT_995;
    unsigned int zT_996;
    unsigned int zT_997;
    zT_6E8D187B_ModuleEntry* zT_998;
    unsigned int zT_999;
    unsigned char zT_1000;
    zT_6E8D187B_ModuleEntry zT_1001;
    unsigned int zT_1002;
    unsigned int zT_1003;
    unsigned char zT_1005;
    unsigned char zT_1006;
    unsigned char zT_1012;
    unsigned int zT_1013;
    zT_6B0A7D14_AstStore* zT_1017;
    unsigned int zT_1018;
    zT_22A7C88B_AstNode zT_1021;
    zT_8143F551_AstKind zT_1022;
    unsigned char zT_1026;
    zT_8143F551_AstKind zT_1027;
    unsigned char zT_1031;
    zT_8143F551_AstKind zT_1032;
    unsigned char zT_1036;
    unsigned int zT_1039;
    zT_6B0A7D14_AstStore* zT_1043;
    unsigned int zT_1044;
    zT_22A7C88B_AstNode zT_1047;
    zT_8143F551_AstKind zT_1048;
    unsigned char zT_1052;
    zT_8143F551_AstKind zT_1053;
    zT_6B0A7D14_AstStore* zT_1058;
    unsigned int zT_1059;
    zT_22A7C88B_AstNode zT_1062;
    zT_8143F551_AstKind zT_1063;
    unsigned char zT_1067;
    unsigned char zT_1070;
    zT_6E8D187B_ModuleEntry* zT_1077;
    unsigned int zT_1078;
    unsigned char zT_1079;
    zT_6E8D187B_ModuleEntry zT_1080;
    unsigned int zT_1081;
    zT_79FAE712_u64 zT_1082;
    zT_79FAE712_u64 zT_1083;
    zT_79FAE712_u64 zT_1084;
    unsigned char zT_1086;
    unsigned int zT_1087;
    unsigned char zT_1089;
    zT_79FAE712_u64 zT_1090;
    zT_79FAE712_u64 zT_1091;
    zT_79FAE712_u64 zT_1092;
    unsigned char zT_1094;
    unsigned int zT_1095;
    unsigned char zT_1097;
    zT_79FAE712_u64 zT_1100;
    zT_A4CE86B7_U64ToU32Map* zT_1101;
    zT_79FAE712_u64 zT_1102;
    unsigned char zT_1107;
    unsigned int zT_1108;
    zT_6B0A7D14_AstStore* zT_1112;
    unsigned int zT_1113;
    zT_22A7C88B_AstNode zT_1116;
    zT_8143F551_AstKind zT_1117;
    unsigned char zT_1121;
    unsigned char zT_1124;
    zT_8EED1867_ResolvedTypeTable* zT_1126;
    unsigned int zT_1127;
    zT_BAEE192E_Opt_10 zT_1129;
    unsigned char zT_1131;
    unsigned int zT_1132;
    unsigned char zT_1136;
    unsigned char zT_1137;
    unsigned char zT_1143;
    zT_E1A783EF_GlobalDeclArrayList* zT_1144;
    zT_54906056_ModuleGlobalDecl zT_1145;
    zT_54906056_ModuleGlobalDecl zT_1147;
    zT_6E8D187B_ModuleEntry* zT_1148;
    unsigned int zT_1149;
    unsigned char zT_1150;
    zT_6E8D187B_ModuleEntry zT_1151;
    unsigned int zT_1152;
    unsigned int zT_1153;
    zT_C98AF326_CompilerCli zT_1154;
    unsigned char zT_1155;
    zT_227EDE07_SourceManager* zT_1157;
    unsigned int zT_1158;
    unsigned int zT_1159;
    zT_6E8D187B_ModuleEntry* zT_1161;
    unsigned int zT_1162;
    unsigned char zT_1163;
    zT_6E8D187B_ModuleEntry zT_1164;
    zT_5BC08DC6_Location zT_1167;
    zT_8B83E3B4_DebugSymbolList* zT_1168;
    zT_1001656C_DebugSymbol zT_1169;
    zT_1001656C_DebugSymbol zT_1171;
    unsigned char zT_1172;
    unsigned char zT_1173;
    zT_6E8D187B_ModuleEntry* zT_1174;
    unsigned int zT_1175;
    unsigned char zT_1176;
    zT_6E8D187B_ModuleEntry zT_1177;
    unsigned int zT_1178;
    unsigned int zT_1179;
    zT_6E8D187B_ModuleEntry* zT_1180;
    unsigned int zT_1181;
    unsigned char zT_1182;
    zT_6E8D187B_ModuleEntry zT_1183;
    unsigned int zT_1184;
    unsigned int zT_1185;
    unsigned int zT_1186;
    unsigned int zT_1187;
    unsigned int zT_1188;
    unsigned char zT_1190;
    zT_6B356268_SemanticContext* zT_1194;
    zT_3E40CD83_Sand* zT_1195;
    zT_69057089_CompilerAlloc* zT_1197;
    zT_02EB57B2_LirLowerer zT_1199;
    zT_6E8D187B_ModuleEntry* zT_1200;
    unsigned int zT_1201;
    unsigned char zT_1202;
    zT_6E8D187B_ModuleEntry zT_1203;
    unsigned int zT_1204;
    zT_072B53A6_ModuleRegistry* zT_1205;
    zT_C98AF326_CompilerCli zT_1206;
    unsigned char zT_1207;
    unsigned char zT_1208;
    int zT_1209;
    int zT_1211;
    zT_C98AF326_CompilerCli zT_1214;
    unsigned char zT_1215;
    zT_1F328BC1_DebugSpanArrayList zT_1216;
    int zT_1217;
    zT_02EB57B2_LirLowerer* zT_1219;
    zT_1F328BC1_DebugSpanArrayList* zT_1220;
    zT_02EB57B2_LirLowerer* zT_1222;
    unsigned int zT_1223;
    unsigned int zT_1224;
    zT_A4CE86B7_U64ToU32Map* zT_1225;
    zT_6E8D187B_ModuleEntry* zT_1227;
    unsigned int zT_1228;
    unsigned char zT_1229;
    zT_6E8D187B_ModuleEntry zT_1230;
    zT_6E8D187B_ModuleEntry* zT_1232;
    unsigned int zT_1233;
    unsigned char zT_1234;
    zT_6E8D187B_ModuleEntry zT_1235;
    zT_BBC23664_LirFunction zT_1238;
    zT_7E7544E4_LirStream* zT_1240;
    zT_BBC23664_LirFunction zT_1241;
    zT_E7714190_LirSlot zT_1243;
    zT_CA01C129_LirSlotArrayList* zT_1244;
    zT_E7714190_LirSlot zT_1245;
    zT_C98AF326_CompilerCli zT_1247;
    unsigned char zT_1248;
    zT_C615AE29_DebugSpanStore* zT_1249;
    unsigned int zT_1250;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_1251;
    zT_1F328BC1_DebugSpanArrayList zT_1254;
    zT_10BDA76C_DebugSpanEntry* zT_1255;
    zT_1F328BC1_DebugSpanArrayList zT_1256;
    unsigned int zT_1257;
    int zT_1258;
    zT_10BDA76C_DebugSpanEntry* zT_1259;
    unsigned int zT_1260;
    unsigned char zT_1261;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_1262;
    zT_1F328BC1_DebugSpanArrayList zT_1263;
    int zT_1264;
    zT_1F328BC1_DebugSpanArrayList* zT_1266;
    zT_3E40CD83_Sand* zT_1268;
    zT_69057089_CompilerAlloc* zT_1269;
    zT_072B53A6_ModuleRegistry* zT_1272;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1274;
    unsigned int zT_1276;
    unsigned char zT_1279;
    zT_6E8D187B_ModuleEntry* zT_1280;
    int zT_1281;
    unsigned int zT_1282;
    unsigned char zT_1283;
    zT_6E8D187B_ModuleEntry zT_1284;
    unsigned int zT_1285;
    zT_6B0A7D14_AstStore* zT_1289;
    unsigned int zT_1290;
    zT_6E8D187B_ModuleEntry* zT_1292;
    int zT_1293;
    unsigned int zT_1294;
    unsigned char zT_1295;
    zT_6E8D187B_ModuleEntry zT_1296;
    zT_22A7C88B_AstNode zT_1298;
    zT_8143F551_AstKind zT_1299;
    zT_6B0A7D14_AstStore* zT_1304;
    unsigned int zT_1305;
    zT_6E8D187B_ModuleEntry* zT_1307;
    int zT_1308;
    unsigned int zT_1309;
    unsigned char zT_1310;
    zT_6E8D187B_ModuleEntry zT_1311;
    unsigned int zT_1313;
    unsigned int zT_1315;
    unsigned char* zT_1317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1318;
    unsigned int zT_1319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1320;
    zT_6B0A7D14_AstStore* zT_1324;
    unsigned int zT_1325;
    zT_6B0A7D14_AstStore* zT_1327;
    unsigned int zT_1328;
    zT_6E8D187B_ModuleEntry* zT_1331;
    int zT_1332;
    unsigned int zT_1333;
    unsigned char zT_1334;
    zT_6E8D187B_ModuleEntry zT_1335;
    unsigned int zT_1338;
    zT_22A7C88B_AstNode zT_1339;
    zT_8143F551_AstKind zT_1341;
    unsigned int zT_1342;
    zT_4028D896_Arr_unsigned_char_2 zT_1344;
    unsigned int zT_1346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1347;
    int zT_1350;
    unsigned char* zT_1351;
    unsigned int zT_1352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1353;
    unsigned int zT_1354;
    unsigned int zT_1356;
    unsigned int zT_1357;
    unsigned int zT_1358;
    unsigned int zT_1359;
    unsigned char zT_1361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1362;
    unsigned int zT_1365;
    unsigned char* zT_1366;
    unsigned int zT_1367;
    unsigned char zT_1368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1369;
    unsigned char* zT_1371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1372;
    unsigned int zT_1373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1374;
    unsigned int zT_1375;
    unsigned int zT_1376;
    unsigned int zT_1377;
    unsigned char zT_1379;
    unsigned char* zT_1381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1382;
    unsigned int zT_1383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1384;
    int zT_1385;
    unsigned int zT_1386;
    unsigned int zT_1387;
    unsigned int zT_1388;
    unsigned char zT_1390;
    unsigned int zT_1392;
    unsigned int zT_1393;
    unsigned int* zT_1396;
    unsigned int zT_1397;
    zT_BBC23664_LirFunction* zT_1399;
    zT_A4CE86B7_U64ToU32Map* zT_1400;
    unsigned int zT_1401;
    unsigned int zT_1402;
    zT_9AD5FBED_Opt_453 zT_1406;
    unsigned char zT_1407;
    zT_5839647A_AsyncTransformCtx zT_1410;
    zT_69057089_CompilerAlloc* zT_1411;
    zT_3E40CD83_Sand* zT_1412;
    zT_338B7C76_TypeRegistry* zT_1413;
    zT_D3EB6303_StringInterner* zT_1414;
    zT_7E7544E4_LirStream* zT_1415;
    zT_CA01C129_LirSlotArrayList* zT_1416;
    zT_A4CE86B7_U64ToU32Map* zT_1417;
    zT_C98AF326_CompilerCli zT_1418;
    unsigned char zT_1419;
    zT_A4CE86B7_U64ToU32Map* zT_1420;
    zT_A4CE86B7_U64ToU32Map* zT_1421;
    zT_F85C5DED_DiagnosticCollector* zT_1422;
    zT_BBC23664_LirFunction* zT_1423;
    zT_5839647A_AsyncTransformCtx* zT_1424;
    unsigned char zT_1426;
    unsigned int zT_1427;
    unsigned int zT_1428;
    unsigned int zT_1429;
    unsigned char zT_1431;
    zT_3E40CD83_Sand* zT_1432;
    zT_69057089_CompilerAlloc* zT_1433;
    zT_5AB29387_CompilerContext* zT_1435;
    zT_7E7544E4_LirStream* zT_1436;
    unsigned char zT_1438;
    unsigned char* zT_1442;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1443;
    unsigned int zT_1444;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1445;
    zT_D3EB6303_StringInterner* zT_1446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1447;
    zT_072B53A6_ModuleRegistry* zT_1448;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1450;
    unsigned int zT_1452;
    unsigned char* zT_1456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1457;
    unsigned int zT_1458;
    unsigned char* zT_1460;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1461;
    unsigned int zT_1462;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_1464;
    unsigned int zT_1465;
    unsigned int zT_1466;
    unsigned int zT_1467;
    zT_D3EB6303_StringInterner* zT_1469;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1470;
    int zT_1473;
    unsigned char zT_1475;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1478;
    zT_F85C5DED_DiagnosticCollector* zT_1479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1485;
    unsigned int zT_1494;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_313, (unsigned int)sizeof zT_313);
    zig_poison_fill((void*)&zT_318, (unsigned int)sizeof zT_318);
    zig_poison_fill((void*)&zT_349, (unsigned int)sizeof zT_349);
    zig_poison_fill((void*)&zT_393, (unsigned int)sizeof zT_393);
    zig_poison_fill((void*)&zT_419, (unsigned int)sizeof zT_419);
    zig_poison_fill((void*)&zT_438, (unsigned int)sizeof zT_438);
    zig_poison_fill((void*)&zT_452, (unsigned int)sizeof zT_452);
    zig_poison_fill((void*)&zT_500, (unsigned int)sizeof zT_500);
    zig_poison_fill((void*)&zT_505, (unsigned int)sizeof zT_505);
    zig_poison_fill((void*)&zT_520, (unsigned int)sizeof zT_520);
    zig_poison_fill((void*)&zT_563, (unsigned int)sizeof zT_563);
    zig_poison_fill((void*)&zT_603, (unsigned int)sizeof zT_603);
    zig_poison_fill((void*)&zT_627, (unsigned int)sizeof zT_627);
    zig_poison_fill((void*)&zT_641, (unsigned int)sizeof zT_641);
    zig_poison_fill((void*)&zT_684, (unsigned int)sizeof zT_684);
    zig_poison_fill((void*)&zT_691, (unsigned int)sizeof zT_691);
    zig_poison_fill((void*)&zT_718, (unsigned int)sizeof zT_718);
    zig_poison_fill((void*)&zT_737, (unsigned int)sizeof zT_737);
    zig_poison_fill((void*)&zT_753, (unsigned int)sizeof zT_753);
    zig_poison_fill((void*)&zT_797, (unsigned int)sizeof zT_797);
    zig_poison_fill((void*)&zT_808, (unsigned int)sizeof zT_808);
    zig_poison_fill((void*)&zT_832, (unsigned int)sizeof zT_832);
    zig_poison_fill((void*)&zT_849, (unsigned int)sizeof zT_849);
    zig_poison_fill((void*)&zT_861, (unsigned int)sizeof zT_861);
    zig_poison_fill((void*)&zT_908, (unsigned int)sizeof zT_908);
    zig_poison_fill((void*)&zT_926, (unsigned int)sizeof zT_926);
    zig_poison_fill((void*)&zT_985, (unsigned int)sizeof zT_985);
    zig_poison_fill((void*)&zT_1021, (unsigned int)sizeof zT_1021);
    zig_poison_fill((void*)&zT_1047, (unsigned int)sizeof zT_1047);
    zig_poison_fill((void*)&zT_1062, (unsigned int)sizeof zT_1062);
    zig_poison_fill((void*)&zT_1116, (unsigned int)sizeof zT_1116);
    zig_poison_fill((void*)&zT_1129, (unsigned int)sizeof zT_1129);
    zig_poison_fill((void*)&zT_1167, (unsigned int)sizeof zT_1167);
    zig_poison_fill((void*)&zT_1199, (unsigned int)sizeof zT_1199);
    zig_poison_fill((void*)&zT_1238, (unsigned int)sizeof zT_1238);
    zig_poison_fill((void*)&zT_1243, (unsigned int)sizeof zT_1243);
    zig_poison_fill((void*)&zT_1274, (unsigned int)sizeof zT_1274);
    zig_poison_fill((void*)&zT_1298, (unsigned int)sizeof zT_1298);
    zig_poison_fill((void*)&zT_1313, (unsigned int)sizeof zT_1313);
    zig_poison_fill((void*)&zT_1338, (unsigned int)sizeof zT_1338);
    zig_poison_fill((void*)&zT_1339, (unsigned int)sizeof zT_1339);
    zig_poison_fill((void*)&zT_1354, (unsigned int)sizeof zT_1354);
    zig_poison_fill((void*)&zT_1406, (unsigned int)sizeof zT_1406);
    zig_poison_fill((void*)&zT_1426, (unsigned int)sizeof zT_1426);
    zig_poison_fill((void*)&zT_1450, (unsigned int)sizeof zT_1450);
    zig_poison_fill((void*)&zT_1452, (unsigned int)sizeof zT_1452);
    zig_poison_fill((void*)&zT_1478, (unsigned int)sizeof zT_1478);
    zig_poison_fill((void*)&zT_1494, (unsigned int)sizeof zT_1494);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_846744CC_Arr_unsigned_char_5 dbg_path;
    unsigned int dp;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u odb;
    unsigned int oib;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_name;
    unsigned int dni;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_243D6A41_FnProto f_sym_proto;
    zT_5BC08DC6_Location f_sym_loc;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_77F031D4_Opt_960 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned int gv_ctree;
    zT_22A7C88B_AstNode gv_i0;
    unsigned char gv_alias;
    zT_22A7C88B_AstNode gv_fb0;
    unsigned int croot;
    unsigned char gv_is_storage;
    zT_79FAE712_u64 gexp_key;
    zT_BAEE192E_Opt_10 gv_rt2;
    unsigned int gv_tid2;
    unsigned int grt2;
    zT_49DE1C22_ConstInitNode gv_rn;
    unsigned char gv_lv;
    zT_5BC08DC6_Location g_sym_loc;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    unsigned char gv_lv2;
    zT_5BC08DC6_Location g2_sym_loc;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = (unsigned char*)zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_28 = 19;
    zT_29 = (unsigned int)ln_len;
    zT_30 = zig_wrap_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    ln_start = zT_30;
    zT_37 = 19;
    zT_38 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_39 = zT_37 - ln_start;
    zT_40 = ln_start <= zT_37;
    if (!(zT_40)) { pal_trap(); }
    zT_41.ptr = (unsigned char*)zT_38;
    zT_41.len = zT_39;
    zT_34 = zT_41;
    zF_48AC7B3A_markerWrite(zT_34);
    zT_43 = " extra=";
    zT_45 = 7;
    zT_44.ptr = (unsigned char*)zT_43;
    zT_44.len = zT_45;
    lemsg = zT_44;
    zT_46 = lemsg;
    zF_48AC7B3A_markerWrite(zT_46);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_48[_i];
        _i++;
    }
}
    zT_52 = ctx->store;
    zT_53 = zT_52->extra_children;
    zT_54 = zT_53.len;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)le_buf) + zT_58;
    zT_60 = (unsigned int)(20) - zT_58;
    zT_61.ptr = (unsigned char*)zT_59;
    zT_61.len = zT_60;
    zT_51 = zT_61;
    zT_62 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_54), zT_51);
    le_len = zT_62;
    zT_64 = 19;
    zT_65 = (unsigned int)le_len;
    zT_66 = zig_wrap_sub_u(((zu64)(zT_64)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_sub_u(((zu64)(zT_64)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    le_start = zT_66;
    zT_73 = 19;
    zT_74 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_75 = zT_73 - le_start;
    zT_76 = le_start <= zT_73;
    if (!(zT_76)) { pal_trap(); }
    zT_77.ptr = (unsigned char*)zT_74;
    zT_77.len = zT_75;
    zT_70 = zT_77;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_79 = "\n";
    zT_81 = 1;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    lnl = zT_80;
    zT_82 = lnl;
    zF_48AC7B3A_markerWrite(zT_82);
    zT_84 = ctx->alloc;
    zT_83 = &zT_84->scratch;
    zF_F1B3F8C2_sandReset(zT_83);
    zT_87 = &ctx->lir_slots;
    zT_87->len = (unsigned int)(0);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_89[_i];
        _i++;
    }
}
    zT_91 = 0;
    sp_len = zT_91;
    zT_92 = ctx->cli;
    zT_93 = zT_92.output_dir_set;
    if (zT_93) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_95 = ctx->cli;
    zT_96 = zT_95.output_dir;
    od = zT_96;
    zT_98 = 0;
    oi = zT_98;
    goto z_bb_4;
    z_bb_2:
    zT_146 = ".zig1_lir.tmp";
    zT_148 = 13;
    zT_147.ptr = (unsigned char*)zT_146;
    zT_147.len = zT_148;
    tmp_name = zT_147;
    zT_150 = 0;
    ti = zT_150;
    goto z_bb_11;
    z_bb_3:
    zT_129 = 46;
    zT_131 = sp_len < (unsigned int)(512);
    if (!(zT_131)) { pal_trap(); }
    spill_path[sp_len] = zT_129;
    zT_132 = 1;
    zT_133 = zig_wrap_add_u(((zu64)(sp_len)), ((zu64)(zT_132)), 32u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(sp_len)), ((zu64)(zT_132)), 32u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    sp_len = zT_133;
    zT_137 = 47;
    zT_139 = sp_len < (unsigned int)(512);
    if (!(zT_139)) { pal_trap(); }
    spill_path[sp_len] = zT_137;
    zT_140 = 1;
    zT_141 = zig_wrap_add_u(((zu64)(sp_len)), ((zu64)(zT_140)), 32u);
    zT_142 = zig_overflow_flag_add_u(((zu64)(sp_len)), ((zu64)(zT_140)), 32u);
    zT_144 = zT_142 == (unsigned int)(0);
    if (!(zT_144)) { pal_trap(); }
    sp_len = zT_141;
    goto z_bb_2;
    z_bb_4:
    zT_100 = od.len;
    if ((unsigned char)(oi < zT_100)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_105 = od.ptr;
    zT_106 = od.len;
    zT_107 = oi < zT_106;
    if (!(zT_107)) { pal_trap(); }
    zT_108 = zT_105[oi];
    zT_110 = sp_len < (unsigned int)(512);
    if (!(zT_110)) { pal_trap(); }
    spill_path[sp_len] = zT_108;
    zT_111 = 1;
    zT_112 = zig_wrap_add_u(((zu64)(sp_len)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(sp_len)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    sp_len = zT_112;
    goto z_bb_7;
    z_bb_6:
    zT_121 = 47;
    zT_123 = sp_len < (unsigned int)(512);
    if (!(zT_123)) { pal_trap(); }
    spill_path[sp_len] = zT_121;
    zT_124 = 1;
    zT_125 = zig_wrap_add_u(((zu64)(sp_len)), ((zu64)(zT_124)), 32u);
    zT_126 = zig_overflow_flag_add_u(((zu64)(sp_len)), ((zu64)(zT_124)), 32u);
    zT_128 = zT_126 == (unsigned int)(0);
    if (!(zT_128)) { pal_trap(); }
    sp_len = zT_125;
    goto z_bb_2;
    z_bb_7:
    zT_116 = 1;
    zT_117 = zig_wrap_add_u(((zu64)(oi)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(oi)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    oi = zT_117;
    goto z_bb_4;
    z_bb_8:
    zT_102 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_102 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_102) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_152 = tmp_name.len;
    if ((unsigned char)(ti < zT_152)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_157 = tmp_name.ptr;
    zT_158 = tmp_name.len;
    zT_159 = ti < zT_158;
    if (!(zT_159)) { pal_trap(); }
    zT_160 = zT_157[ti];
    zT_162 = sp_len < (unsigned int)(512);
    if (!(zT_162)) { pal_trap(); }
    spill_path[sp_len] = zT_160;
    zT_163 = 1;
    zT_164 = zig_wrap_add_u(((zu64)(sp_len)), ((zu64)(zT_163)), 32u);
    zT_165 = zig_overflow_flag_add_u(((zu64)(sp_len)), ((zu64)(zT_163)), 32u);
    zT_167 = zT_165 == (unsigned int)(0);
    if (!(zT_167)) { pal_trap(); }
    sp_len = zT_164;
    goto z_bb_14;
    z_bb_13:
    zT_173 = &ctx->lir_stream;
    zT_179 = 0;
    zT_180 = (unsigned char*)((unsigned char*)spill_path) + zT_179;
    zT_181 = sp_len - zT_179;
    zT_182 = (unsigned int)zT_179 <= sp_len;
    if (!(zT_182)) { pal_trap(); }
    zT_183 = sp_len <= (unsigned int)(512);
    if (!(zT_183)) { pal_trap(); }
    zT_184.ptr = (unsigned char*)zT_180;
    zT_184.len = zT_181;
    zT_174 = zT_184;
    zT_185 = ctx->alloc;
    zT_175 = &zT_185->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_173, zT_174, zT_175);
    zT_187 = ctx->cli;
    zT_188 = zT_187.debug;
    if (zT_188) goto z_bb_18; else goto z_bb_19;
    z_bb_14:
    zT_168 = 1;
    zT_169 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_168)), 32u);
    zT_170 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_168)), 32u);
    zT_172 = zT_170 == (unsigned int)(0);
    if (!(zT_172)) { pal_trap(); }
    ti = zT_169;
    goto z_bb_11;
    z_bb_15:
    zT_154 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_154 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_154) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_path[_i] = zT_190[_i];
        _i++;
    }
}
    zT_192 = 0;
    dp = zT_192;
    zT_193 = ctx->cli;
    zT_194 = zT_193.output_dir_set;
    if (zT_194) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_290 = ctx->store;
    zT_289.store = zT_290;
    zT_291 = ctx->typereg;
    zT_289.registry = zT_291;
    zT_292 = ctx->symbol_reg;
    zT_289.symbol_tables = zT_292;
    zT_293 = ctx->resolved_types;
    zT_289.resolved_types = zT_293;
    zT_294 = ctx->coercion_table;
    zT_289.coercions = zT_294;
    zT_295 = ctx->diag;
    zT_289.diag = zT_295;
    zT_296 = 1;
    zT_289.has_symbols = zT_296;
    zT_297 = &ctx->enum_value_table;
    zT_289.enum_value_table = zT_297;
    zT_298 = &ctx->tuple_index_table;
    zT_289.tuple_index_table = zT_298;
    zT_299 = &ctx->error_code_registry;
    zT_289.error_code_registry = zT_299;
    zT_300 = &ctx->call_arg_types;
    zT_289.call_arg_types = zT_300;
    zT_301 = &ctx->comptime_folds;
    zT_289.comptime_folds = zT_301;
    zT_302 = &ctx->const_inits;
    zT_289.const_inits = zT_302;
    zT_303 = 0;
    zT_289.source_file_id = zT_303;
    zT_304 = ctx->cli;
    zT_305 = zT_304.safe_checks;
    zT_289.safe_checks = zT_305;
    zT_306 = &ctx->suspending_fns;
    zT_289.suspending_fns = zT_306;
    zT_307 = &ctx->frame_sizes;
    zT_289.frame_sizes = zT_307;
    zT_308 = &ctx->state_widths;
    zT_289.state_widths = zT_308;
    zT_309 = 0;
    zT_289.print_value_lowered = zT_309;
    sem_ctx = zT_289;
    zT_311 = ctx->module_reg;
    zT_313 = zF_3452C137_moduleRegistryGetMo(zT_311);
    mods = zT_313;
    zT_316 = ctx->alloc;
    zT_315 = &zT_316->module;
    zT_318 = zF_8E537D0C_u32ArrayListInit(zT_315);
    async_retained = zT_318;
    zT_320 = 0;
    async_pending = zT_320;
    zT_322 = 0;
    zT_323 = (unsigned int)zT_322;
    mi = zT_323;
    goto z_bb_37;
    z_bb_20:
    zT_196 = ctx->cli;
    zT_197 = zT_196.output_dir;
    odb = zT_197;
    zT_199 = 0;
    oib = zT_199;
    goto z_bb_23;
    z_bb_21:
    zT_247 = ".zig1_dbg.tmp";
    zT_249 = 13;
    zT_248.ptr = (unsigned char*)zT_247;
    zT_248.len = zT_249;
    dbg_name = zT_248;
    zT_251 = 0;
    dni = zT_251;
    goto z_bb_30;
    z_bb_22:
    zT_230 = 46;
    zT_232 = dp < (unsigned int)(512);
    if (!(zT_232)) { pal_trap(); }
    dbg_path[dp] = zT_230;
    zT_233 = 1;
    zT_234 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_233)), 32u);
    zT_235 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_233)), 32u);
    zT_237 = zT_235 == (unsigned int)(0);
    if (!(zT_237)) { pal_trap(); }
    dp = zT_234;
    zT_238 = 47;
    zT_240 = dp < (unsigned int)(512);
    if (!(zT_240)) { pal_trap(); }
    dbg_path[dp] = zT_238;
    zT_241 = 1;
    zT_242 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_241)), 32u);
    zT_243 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_241)), 32u);
    zT_245 = zT_243 == (unsigned int)(0);
    if (!(zT_245)) { pal_trap(); }
    dp = zT_242;
    goto z_bb_21;
    z_bb_23:
    zT_201 = odb.len;
    if ((unsigned char)(oib < zT_201)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_206 = odb.ptr;
    zT_207 = odb.len;
    zT_208 = oib < zT_207;
    if (!(zT_208)) { pal_trap(); }
    zT_209 = zT_206[oib];
    zT_211 = dp < (unsigned int)(512);
    if (!(zT_211)) { pal_trap(); }
    dbg_path[dp] = zT_209;
    zT_212 = 1;
    zT_213 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_212)), 32u);
    zT_214 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_212)), 32u);
    zT_216 = zT_214 == (unsigned int)(0);
    if (!(zT_216)) { pal_trap(); }
    dp = zT_213;
    goto z_bb_26;
    z_bb_25:
    zT_222 = 47;
    zT_224 = dp < (unsigned int)(512);
    if (!(zT_224)) { pal_trap(); }
    dbg_path[dp] = zT_222;
    zT_225 = 1;
    zT_226 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_225)), 32u);
    zT_227 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_225)), 32u);
    zT_229 = zT_227 == (unsigned int)(0);
    if (!(zT_229)) { pal_trap(); }
    dp = zT_226;
    goto z_bb_21;
    z_bb_26:
    zT_217 = 1;
    zT_218 = zig_wrap_add_u(((zu64)(oib)), ((zu64)(zT_217)), 32u);
    zT_219 = zig_overflow_flag_add_u(((zu64)(oib)), ((zu64)(zT_217)), 32u);
    zT_221 = zT_219 == (unsigned int)(0);
    if (!(zT_221)) { pal_trap(); }
    oib = zT_218;
    goto z_bb_23;
    z_bb_27:
    zT_203 = dp < (unsigned int)(511);
    goto z_bb_29;
    z_bb_28:
    zT_203 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_203) goto z_bb_24; else goto z_bb_25;
    z_bb_30:
    zT_253 = dbg_name.len;
    if ((unsigned char)(dni < zT_253)) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_258 = dbg_name.ptr;
    zT_259 = dbg_name.len;
    zT_260 = dni < zT_259;
    if (!(zT_260)) { pal_trap(); }
    zT_261 = zT_258[dni];
    zT_263 = dp < (unsigned int)(512);
    if (!(zT_263)) { pal_trap(); }
    dbg_path[dp] = zT_261;
    zT_264 = 1;
    zT_265 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_264)), 32u);
    zT_266 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_264)), 32u);
    zT_268 = zT_266 == (unsigned int)(0);
    if (!(zT_268)) { pal_trap(); }
    dp = zT_265;
    goto z_bb_33;
    z_bb_32:
    zT_274 = &ctx->debug_spans;
    zT_278 = ctx->alloc;
    zT_275 = &zT_278->emission;
    zT_282 = 0;
    zT_283 = (unsigned char*)((unsigned char*)dbg_path) + zT_282;
    zT_284 = dp - zT_282;
    zT_285 = (unsigned int)zT_282 <= dp;
    if (!(zT_285)) { pal_trap(); }
    zT_286 = dp <= (unsigned int)(512);
    if (!(zT_286)) { pal_trap(); }
    zT_287.ptr = (unsigned char*)zT_283;
    zT_287.len = zT_284;
    zT_276 = zT_287;
    zF_7FA61CF5_debugSpanStoreOpen(zT_274, zT_275, zT_276);
    goto z_bb_19;
    z_bb_33:
    zT_269 = 1;
    zT_270 = zig_wrap_add_u(((zu64)(dni)), ((zu64)(zT_269)), 32u);
    zT_271 = zig_overflow_flag_add_u(((zu64)(dni)), ((zu64)(zT_269)), 32u);
    zT_273 = zT_271 == (unsigned int)(0);
    if (!(zT_273)) { pal_trap(); }
    dni = zT_270;
    goto z_bb_30;
    z_bb_34:
    zT_255 = dp < (unsigned int)(511);
    goto z_bb_36;
    z_bb_35:
    zT_255 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_255) goto z_bb_31; else goto z_bb_32;
    z_bb_37:
    zT_325 = mods.len;
    if ((unsigned char)(mi < zT_325)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_327 = mods.ptr;
    zT_328 = mods.len;
    zT_329 = mi < zT_328;
    if (!(zT_329)) { pal_trap(); }
    zT_330 = zT_327[mi];
    zT_331 = zT_330.source_file_id;
    sem_ctx.source_file_id = zT_331;
    zT_333 = "M";
    zT_335 = 1;
    zT_334.ptr = (unsigned char*)zT_333;
    zT_334.len = zT_335;
    mm = zT_334;
    zT_336 = mm;
    zF_48AC7B3A_markerWrite(zT_336);
    zig_poison_fill((void*)&zT_338, (unsigned int)sizeof zT_338);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_338[_i];
        _i++;
    }
}
    zT_345 = 0;
    zT_346 = (unsigned char*)((unsigned char*)mi_buf) + zT_345;
    zT_347 = (unsigned int)(20) - zT_345;
    zT_348.ptr = (unsigned char*)zT_346;
    zT_348.len = zT_347;
    zT_341 = zT_348;
    zT_349 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_341);
    mi_len = zT_349;
    zT_351 = 19;
    zT_352 = (unsigned int)mi_len;
    zT_353 = zig_wrap_sub_u(((zu64)(zT_351)), ((zu64)(zT_352)), 32u);
    zT_354 = zig_overflow_flag_sub_u(((zu64)(zT_351)), ((zu64)(zT_352)), 32u);
    zT_356 = zT_354 == (unsigned int)(0);
    if (!(zT_356)) { pal_trap(); }
    mi2_start = zT_353;
    zT_360 = 19;
    zT_361 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_362 = zT_360 - mi2_start;
    zT_363 = mi2_start <= zT_360;
    if (!(zT_363)) { pal_trap(); }
    zT_364.ptr = (unsigned char*)zT_361;
    zT_364.len = zT_362;
    zT_357 = zT_364;
    zF_48AC7B3A_markerWrite(zT_357);
    zT_366 = ":";
    zT_368 = 1;
    zT_367.ptr = (unsigned char*)zT_366;
    zT_367.len = zT_368;
    msep = zT_367;
    zT_369 = msep;
    zF_48AC7B3A_markerWrite(zT_369);
    zT_370 = mods.ptr;
    zT_371 = mods.len;
    zT_372 = mi < zT_371;
    if (!(zT_372)) { pal_trap(); }
    zT_373 = zT_370[mi];
    zT_374 = zT_373.ast_root;
    if ((unsigned char)(zT_374 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    zT_1392 = 0;
    arl_i = zT_1392;
    goto z_bb_199;
    z_bb_40:
    zT_1385 = 1;
    zT_1386 = (unsigned int)zT_1385;
    zT_1387 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_1386)), 32u);
    zT_1388 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_1386)), 32u);
    zT_1390 = zT_1388 == (unsigned int)(0);
    if (!(zT_1390)) { pal_trap(); }
    mi = zT_1387;
    goto z_bb_37;
    z_bb_41:
    zig_poison_fill((void*)&zT_378, (unsigned int)sizeof zT_378);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_378[_i];
        _i++;
    }
}
    zT_382 = mods.ptr;
    zT_383 = mods.len;
    zT_384 = mi < zT_383;
    if (!(zT_384)) { pal_trap(); }
    zT_385 = zT_382[mi];
    zT_380 = zT_385.ast_root;
    zT_389 = 0;
    zT_390 = (unsigned char*)((unsigned char*)ar_buf) + zT_389;
    zT_391 = (unsigned int)(20) - zT_389;
    zT_392.ptr = (unsigned char*)zT_390;
    zT_392.len = zT_391;
    zT_381 = zT_392;
    zT_393 = zF_A7504564_itoa(zT_380, zT_381);
    ar_len = zT_393;
    zT_395 = 19;
    zT_396 = (unsigned int)ar_len;
    zT_397 = zig_wrap_sub_u(((zu64)(zT_395)), ((zu64)(zT_396)), 32u);
    zT_398 = zig_overflow_flag_sub_u(((zu64)(zT_395)), ((zu64)(zT_396)), 32u);
    zT_400 = zT_398 == (unsigned int)(0);
    if (!(zT_400)) { pal_trap(); }
    ar_start = zT_397;
    zT_404 = 19;
    zT_405 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_406 = zT_404 - ar_start;
    zT_407 = ar_start <= zT_404;
    if (!(zT_407)) { pal_trap(); }
    zT_408.ptr = (unsigned char*)zT_405;
    zT_408.len = zT_406;
    zT_401 = zT_408;
    zF_48AC7B3A_markerWrite(zT_401);
    zT_409 = msep;
    zF_48AC7B3A_markerWrite(zT_409);
    zT_411 = ctx->store;
    zT_414 = mods.ptr;
    zT_415 = mods.len;
    zT_416 = mi < zT_415;
    if (!(zT_416)) { pal_trap(); }
    zT_417 = zT_414[mi];
    zT_412 = zT_417.ast_root;
    zT_419 = zF_FCDD1D35_astStoreNodeAt(zT_411, zT_412);
    root = zT_419;
    zT_420 = root.kind;
    if ((unsigned char)(zT_420 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_425 = "R";
    zT_427 = 1;
    zT_426.ptr = (unsigned char*)zT_425;
    zT_426.len = zT_427;
    mr = zT_426;
    zT_428 = mr;
    zF_48AC7B3A_markerWrite(zT_428);
    zT_430 = ctx->store;
    zT_433 = mods.ptr;
    zT_434 = mods.len;
    zT_435 = mi < zT_434;
    if (!(zT_435)) { pal_trap(); }
    zT_436 = zT_433[mi];
    zT_431 = zT_436.ast_root;
    zT_438 = zF_152E19CB_astStoreNodeExtraCh(zT_430, zT_431);
    decls_n = zT_438;
    zT_440 = (unsigned int)decls_n;
    decl_len = zT_440;
    zig_poison_fill((void*)&zT_442, (unsigned int)sizeof zT_442);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_442[_i];
        _i++;
    }
}
    zT_444 = decl_len;
    zT_448 = 0;
    zT_449 = (unsigned char*)((unsigned char*)dcount_buf) + zT_448;
    zT_450 = (unsigned int)(20) - zT_448;
    zT_451.ptr = (unsigned char*)zT_449;
    zT_451.len = zT_450;
    zT_445 = zT_451;
    zT_452 = zF_A7504564_itoa(zT_444, zT_445);
    dcount_len = zT_452;
    zT_454 = 19;
    zT_455 = (unsigned int)dcount_len;
    zT_456 = zig_wrap_sub_u(((zu64)(zT_454)), ((zu64)(zT_455)), 32u);
    zT_457 = zig_overflow_flag_sub_u(((zu64)(zT_454)), ((zu64)(zT_455)), 32u);
    zT_459 = zT_457 == (unsigned int)(0);
    if (!(zT_459)) { pal_trap(); }
    dstart = zT_456;
    zT_463 = 19;
    zT_464 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_465 = zT_463 - dstart;
    zT_466 = dstart <= zT_463;
    if (!(zT_466)) { pal_trap(); }
    zT_467.ptr = (unsigned char*)zT_464;
    zT_467.len = zT_465;
    zT_460 = zT_467;
    zF_48AC7B3A_markerWrite(zT_460);
    zT_468 = msep;
    zF_48AC7B3A_markerWrite(zT_468);
    zT_469 = ctx->store;
    zT_473 = mods.ptr;
    zT_474 = mods.len;
    zT_475 = mi < zT_474;
    if (!(zT_475)) { pal_trap(); }
    zT_476 = zT_473[mi];
    zT_470 = zT_476.ast_root;
    zT_478 = mods.ptr;
    zT_479 = mods.len;
    zT_480 = mi < zT_479;
    if (!(zT_480)) { pal_trap(); }
    zT_481 = zT_478 + mi;
    zT_471 = &zT_481->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_469, zT_470, zT_471);
    zT_484 = 0;
    mod_has_ri = zT_484;
    zT_486 = 0;
    di = zT_486;
    goto z_bb_45;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_490 = ctx->store;
    zT_494 = mods.ptr;
    zT_495 = mods.len;
    zT_496 = mi < zT_495;
    if (!(zT_496)) { pal_trap(); }
    zT_497 = zT_494[mi];
    zT_491 = zT_497.ast_root;
    zT_500 = zF_B10B1BC1_astStoreNodeExtraCh(zT_490, zT_491, (unsigned int)((unsigned int)di));
    decl_idx = zT_500;
    zT_502 = ctx->store;
    zT_503 = decl_idx;
    zT_505 = zF_FCDD1D35_astStoreNodeAt(zT_502, zT_503);
    decl = zT_505;
    zT_507 = decl.kind;
    zT_508 = (unsigned int)zT_507;
    raw_k = zT_508;
    zig_poison_fill((void*)&zT_510, (unsigned int)sizeof zT_510);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_510[_i];
        _i++;
    }
}
    zT_512 = raw_k;
    zT_516 = 0;
    zT_517 = (unsigned char*)((unsigned char*)rbuf) + zT_516;
    zT_518 = (unsigned int)(20) - zT_516;
    zT_519.ptr = (unsigned char*)zT_517;
    zT_519.len = zT_518;
    zT_513 = zT_519;
    zT_520 = zF_A7504564_itoa(zT_512, zT_513);
    rlen = zT_520;
    zT_522 = 19;
    zT_523 = (unsigned int)rlen;
    zT_524 = zig_wrap_sub_u(((zu64)(zT_522)), ((zu64)(zT_523)), 32u);
    zT_525 = zig_overflow_flag_sub_u(((zu64)(zT_522)), ((zu64)(zT_523)), 32u);
    zT_527 = zT_525 == (unsigned int)(0);
    if (!(zT_527)) { pal_trap(); }
    rstart = zT_524;
    zT_531 = 19;
    zT_532 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_533 = zT_531 - rstart;
    zT_534 = rstart <= zT_531;
    if (!(zT_534)) { pal_trap(); }
    zT_535.ptr = (unsigned char*)zT_532;
    zT_535.len = zT_533;
    zT_528 = zT_535;
    zF_48AC7B3A_markerWrite(zT_528);
    zT_537 = " ";
    zT_539 = 1;
    zT_538.ptr = (unsigned char*)zT_537;
    zT_538.len = zT_539;
    sp2 = zT_538;
    zT_540 = sp2;
    zF_48AC7B3A_markerWrite(zT_540);
    zT_541 = decl.kind;
    if ((unsigned char)(zT_541 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_177; else goto z_bb_178;
    z_bb_48:
    zT_1186 = 1;
    zT_1187 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_1186)), 32u);
    zT_1188 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_1186)), 32u);
    zT_1190 = zT_1188 == (unsigned int)(0);
    if (!(zT_1190)) { pal_trap(); }
    di = zT_1187;
    goto z_bb_45;
    z_bb_49:
    zT_546 = "F";
    zT_548 = 1;
    zT_547.ptr = (unsigned char*)zT_546;
    zT_547.len = zT_548;
    mf = zT_547;
    zT_549 = mf;
    zF_48AC7B3A_markerWrite(zT_549);
    zT_550 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_550) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_783 = decl.kind;
    if ((unsigned char)(zT_783 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_76; else goto z_bb_77;
    z_bb_52:
    zT_557 = ctx->store;
    zT_558 = zT_557->fn_protos;
    zT_559 = zT_558.items;
    zT_560 = ctx->store;
    zT_561 = decl_idx;
    zT_563 = zF_8BA26B9E_astStoreNodePayload(zT_560, zT_561);
    zT_564 = (unsigned int)zT_563;
    zT_565 = zT_559[zT_564];
    fexp_proto = zT_565;
    zT_567 = mods.ptr;
    zT_568 = mods.len;
    zT_569 = mi < zT_568;
    if (!(zT_569)) { pal_trap(); }
    zT_570 = zT_567[mi];
    zT_571 = zT_570.id;
    zT_572 = (zT_79FAE712_u64)zT_571;
    zT_573 = 35;
    zT_576 = zT_573 < (unsigned int)(64);
    if (!(zT_576)) { pal_trap(); }
    zT_574 = zig_wrap_shl_u(((zu64)(zT_572)), ((zu64)(zT_573)), 64u);
    zT_577 = zig_overflow_flag_shl_u(((zu64)(zT_572)), ((zu64)(zT_573)), 64u);
    zT_579 = zT_577 == (unsigned int)(0);
    if (!(zT_579)) { pal_trap(); }
    zT_580 = 0;
    zT_581 = 32;
    zT_584 = zT_581 < (unsigned int)(64);
    if (!(zT_584)) { pal_trap(); }
    zT_582 = zig_wrap_shl_u(((zu64)(zT_580)), ((zu64)(zT_581)), 64u);
    zT_585 = zig_overflow_flag_shl_u(((zu64)(zT_580)), ((zu64)(zT_581)), 64u);
    zT_587 = zT_585 == (unsigned int)(0);
    if (!(zT_587)) { pal_trap(); }
    zT_589 = fexp_proto.name_id;
    zT_591 = (zT_79FAE712_u64)(zT_574 | zT_582) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_589);
    fexp_key = zT_591;
    zT_592 = &ctx->exported;
    zT_593 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_592, zT_593, (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    zT_598 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_601 = ctx->alloc;
    zT_599 = &zT_601->scratch;
    zT_603 = zF_ADD4254B_lowererInit(zT_598, zT_599);
    lowerer = zT_603;
    zT_604 = mods.ptr;
    zT_605 = mods.len;
    zT_606 = mi < zT_605;
    if (!(zT_606)) { pal_trap(); }
    zT_607 = zT_604[mi];
    zT_608 = zT_607.id;
    lowerer.module_id = zT_608;
    zT_609 = ctx->module_reg;
    lowerer.module_reg = zT_609;
    zT_610 = ctx->cli;
    zT_611 = zT_610.debug;
    if (zT_611) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_613 = 1;
    zT_612 = (unsigned char)zT_613;
    goto z_bb_56;
    z_bb_55:
    zT_615 = 0;
    zT_612 = (unsigned char)zT_615;
    goto z_bb_56;
    z_bb_56:
    lowerer.debug_enabled = (unsigned char)((unsigned char)zT_612);
    zT_618 = ctx->cli;
    zT_619 = zT_618.debug;
    if (zT_619) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_621 = ctx->store;
    zT_622 = zT_621->fn_protos;
    zT_623 = zT_622.items;
    zT_624 = ctx->store;
    zT_625 = decl_idx;
    zT_627 = zF_8BA26B9E_astStoreNodePayload(zT_624, zT_625);
    zT_628 = (unsigned int)zT_627;
    zT_629 = zT_623[zT_628];
    f_sym_proto = zT_629;
    zT_631 = ctx->source_man;
    zT_635 = mods.ptr;
    zT_636 = mods.len;
    zT_637 = mi < zT_636;
    if (!(zT_637)) { pal_trap(); }
    zT_638 = zT_635[mi];
    zT_632 = zT_638.source_file_id;
    zT_633 = decl.span_start;
    zT_641 = zF_4966CE4A_sourceManagerGetLoc(zT_631, zT_632, zT_633);
    f_sym_loc = zT_641;
    zT_644 = &ctx->debug_symbols;
    zT_642 = zT_644;
    zT_646 = 0;
    zT_645.kind = zT_646;
    zT_647 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_647) & (unsigned short)(4)) != (unsigned short)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    zT_673 = ctx->cli;
    zT_674 = zT_673.debug;
    if (zT_674) goto z_bb_62; else goto z_bb_63;
    z_bb_59:
    zT_654 = 1;
    zT_653 = (unsigned char)zT_654;
    goto z_bb_61;
    z_bb_60:
    zT_656 = 0;
    zT_653 = (unsigned char)zT_656;
    goto z_bb_61;
    z_bb_61:
    zT_658 = (unsigned char)zT_653;
    zT_645.is_extern = zT_658;
    zT_659 = f_sym_proto.name_id;
    zT_645.name_id = zT_659;
    zT_660 = mods.ptr;
    zT_661 = mods.len;
    zT_662 = mi < zT_661;
    if (!(zT_662)) { pal_trap(); }
    zT_663 = zT_660[mi];
    zT_664 = zT_663.id;
    zT_645.module_id = zT_664;
    zT_665 = 0;
    zT_645.type_id = zT_665;
    zT_666 = f_sym_loc.line;
    zT_645.src_line = zT_666;
    zT_667 = mods.ptr;
    zT_668 = mods.len;
    zT_669 = mi < zT_668;
    if (!(zT_669)) { pal_trap(); }
    zT_670 = zT_667[mi];
    zT_671 = zT_670.source_file_id;
    zT_645.src_file_id = zT_671;
    zT_672 = decl.span_start;
    zT_645.decl_span = zT_672;
    zT_643 = zT_645;
    zF_3CC05A74_debugSymbolListAppe(zT_642, zT_643);
    goto z_bb_58;
    z_bb_62:
    zT_675 = ctx->debug_span_buf;
    lowerer.debug_spans = zT_675;
    zT_676 = 0;
    zT_678 = (zT_02EB57B2_LirLowerer*)&lowerer;
    zT_679 = &zT_678->debug_spans;
    zT_679->len = (unsigned int)((unsigned int)zT_676);
    goto z_bb_63;
    z_bb_63:
    zT_681 = (zT_02EB57B2_LirLowerer*)&lowerer;
    zT_682 = decl_idx;
    zT_684 = zF_B53F5F2E_lowerFn(zT_681, zT_682);
    lf = zT_684;
    zT_685 = &ctx->suspending_fns;
    zT_686 = lf.module_id;
    zT_687 = lf.name_id;
    zT_691 = zF_7C7E43BF_asyncIsSuspending(zT_685, zT_686, zT_687);
    if (zT_691) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_705 = ctx->alloc;
    zT_693 = &zT_705->scratch;
    zT_694 = ctx->typereg;
    zT_695 = (zT_BBC23664_LirFunction*)&lf;
    zT_696 = &ctx->suspending_fns;
    zT_697 = &ctx->frame_sizes;
    zT_698 = &ctx->state_widths;
    zT_699 = &ctx->awaited_fns;
    zT_700 = &ctx->async_hidden_fns;
    zT_701 = &ctx->driver_targets;
    zT_702 = &ctx->parent_result_type_list;
    zT_703 = &ctx->parent_result_start;
    zT_704 = &ctx->parent_result_count;
    zT_718 = zF_28031796_asyncLayoutFrame(zT_693, zT_694, zT_695, zT_696, zT_697, zT_698, zT_699, zT_700, zT_701, zT_702, zT_703, zT_704);
    async_layout = zT_718;
    zT_724 = ctx->alloc;
    zT_719 = &zT_724->scratch;
    zT_720 = &ctx->async_layouts;
    zT_721 = lf.module_id;
    zT_722 = lf.name_id;
    zT_723 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_719, zT_720, zT_721, zT_722, zT_723);
    zT_733 = ctx->alloc;
    zT_730 = &zT_733->scratch;
    zT_737 = zF_1395EB68_sandAlloc(zT_730, (unsigned int)(124), (unsigned int)(4));
    zT_738 = zT_737.is_error;
    if (zT_738) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_777 = ctx->cli;
    zT_778 = zT_777.debug;
    if (zT_778) goto z_bb_74; else goto z_bb_75;
    z_bb_66:
    zT_750 = &ctx->lir_stream;
    zT_751 = lf;
    zT_753 = zF_9F47D5E4_lirStreamAppend(zT_750, zT_751);
    slot = zT_753;
    zT_754 = &ctx->lir_slots;
    zT_755 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_754, zT_755);
    zT_757 = ctx->cli;
    zT_758 = zT_757.debug;
    if (zT_758) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    pal_trap();
    z_bb_68:
    zT_739 = zT_737.data.payload;
    goto z_bb_69;
    z_bb_69:
    lf_raw = zT_739;
    zT_742 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_742;
    *lf_ptr = lf;
    zT_743 = (zT_B687BB96_U32ArrayList*)&async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_743, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_748 = 1;
    async_pending = zT_748;
    goto z_bb_65;
    z_bb_70:
    zT_759 = &ctx->debug_spans;
    zT_760 = slot.disk_offset;
    zT_764 = lowerer.debug_spans;
    zT_765 = zT_764.items;
    zT_766 = lowerer.debug_spans;
    zT_767 = zT_766.len;
    zT_768 = 0;
    zT_769 = zT_765 + zT_768;
    zT_770 = zT_767 - zT_768;
    zT_771 = (unsigned int)zT_768 <= zT_767;
    if (!(zT_771)) { pal_trap(); }
    zT_772.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_769;
    zT_772.len = zT_770;
    zT_761 = zT_772;
    zF_BB256CBD_debugSpanStoreAppen(zT_759, zT_760, zT_761);
    goto z_bb_71;
    z_bb_71:
    if ((unsigned char)(!async_pending)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_775 = ctx->alloc;
    zT_774 = &zT_775->scratch;
    zF_F1B3F8C2_sandReset(zT_774);
    goto z_bb_73;
    z_bb_73:
    goto z_bb_65;
    z_bb_74:
    zT_779 = lowerer.debug_spans;
    ctx->debug_span_buf = zT_779;
    zT_780 = 0;
    zT_782 = &ctx->debug_span_buf;
    zT_782->len = (unsigned int)((unsigned int)zT_780);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_50;
    z_bb_76:
    zT_787 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_787) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    goto z_bb_50;
    z_bb_78:
    zT_794 = ctx->store;
    zT_795 = decl_idx;
    zT_797 = zF_8BA26B9E_astStoreNodePayload(zT_794, zT_795);
    gv_name = zT_797;
    zT_799 = ctx->symbol_reg;
    zT_803 = mods.ptr;
    zT_804 = mods.len;
    zT_805 = mi < zT_804;
    if (!(zT_805)) { pal_trap(); }
    zT_806 = zT_803[mi];
    zT_800 = zT_806.id;
    zT_801 = gv_name;
    zT_808 = zF_A398987E_symbolRegistryQuali(zT_799, zT_800, zT_801);
    gv_sym = zT_808;
    zT_809 = gv_sym.has_value;
    if (zT_809) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    if (!(gv_sym.has_value)) { pal_trap(); }
    gvs = gv_sym.value;
    zT_811 = gvs->kind;
    if ((unsigned char)(zT_811 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_816 = 4294967295u;
    gv_ctree = zT_816;
    zT_817 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_817) & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_824 = decl.child_1;
    zT_823 = zT_824 != (unsigned int)(0);
    goto z_bb_86;
    z_bb_85:
    zT_823 = 0;
    goto z_bb_86;
    z_bb_86:
    if (zT_823) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_828 = ctx->store;
    zT_829 = decl.child_1;
    zT_832 = zF_FCDD1D35_astStoreNodeAt(zT_828, zT_829);
    gv_i0 = zT_832;
    zT_834 = 0;
    gv_alias = zT_834;
    zT_835 = gv_i0.kind;
    if ((unsigned char)(zT_835 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    if ((unsigned char)(gv_ctree != (unsigned int)(4294967295u))) goto z_bb_101; else goto z_bb_103;
    z_bb_89:
    zT_839 = 1;
    gv_alias = zT_839;
    goto z_bb_90;
    z_bb_90:
    zT_840 = gv_i0.kind;
    if ((unsigned char)(zT_840 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_845 = ctx->store;
    zT_846 = gv_i0.child_0;
    zT_849 = zF_FCDD1D35_astStoreNodeAt(zT_845, zT_846);
    gv_fb0 = zT_849;
    zT_850 = gv_fb0.kind;
    if ((unsigned char)(zT_850 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    if ((unsigned char)(gv_alias == (unsigned char)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    zT_854 = 1;
    gv_alias = zT_854;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_859 = &ctx->const_inits;
    zT_857 = &zT_859->roots;
    zT_858 = decl_idx;
    zT_861 = zF_F3EE5998_u32ToU32MapGet(zT_857, zT_858);
    zT_862 = zT_861.has_value;
    if (zT_862) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    goto z_bb_88;
    z_bb_97:
    if (!(zT_861.has_value)) { pal_trap(); }
    croot = zT_861.value;
    if ((unsigned char)(croot != (unsigned int)(4294967295u))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    goto z_bb_96;
    z_bb_99:
    gv_ctree = croot;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_868 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_868) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_104; else goto z_bb_105;
    z_bb_102:
    goto z_bb_83;
    z_bb_103:
    zT_1005 = 0;
    gv_is_storage = zT_1005;
    zT_1006 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_1006) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_137; else goto z_bb_139;
    z_bb_104:
    zT_875 = mods.ptr;
    zT_876 = mods.len;
    zT_877 = mi < zT_876;
    if (!(zT_877)) { pal_trap(); }
    zT_878 = zT_875[mi];
    zT_879 = zT_878.id;
    zT_880 = (zT_79FAE712_u64)zT_879;
    zT_881 = 35;
    zT_884 = zT_881 < (unsigned int)(64);
    if (!(zT_884)) { pal_trap(); }
    zT_882 = zig_wrap_shl_u(((zu64)(zT_880)), ((zu64)(zT_881)), 64u);
    zT_885 = zig_overflow_flag_shl_u(((zu64)(zT_880)), ((zu64)(zT_881)), 64u);
    zT_887 = zT_885 == (unsigned int)(0);
    if (!(zT_887)) { pal_trap(); }
    zT_888 = 1;
    zT_889 = 32;
    zT_892 = zT_889 < (unsigned int)(64);
    if (!(zT_892)) { pal_trap(); }
    zT_890 = zig_wrap_shl_u(((zu64)(zT_888)), ((zu64)(zT_889)), 64u);
    zT_893 = zig_overflow_flag_shl_u(((zu64)(zT_888)), ((zu64)(zT_889)), 64u);
    zT_895 = zT_893 == (unsigned int)(0);
    if (!(zT_895)) { pal_trap(); }
    zT_898 = (zT_79FAE712_u64)(zT_882 | zT_890) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_898;
    zT_899 = &ctx->exported;
    zT_900 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_899, zT_900, (unsigned int)(1));
    goto z_bb_105;
    z_bb_105:
    zT_905 = ctx->resolved_types;
    zT_906 = decl_idx;
    zT_908 = zF_999DCF51_resolvedTypeTableGe(zT_905, zT_906);
    gv_rt2 = zT_908;
    zT_910 = gv_rt2.has_value;
    if (zT_910) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    if (!(gv_rt2.has_value)) { pal_trap(); }
    grt2 = gv_rt2.value;
    zT_911 = grt2;
    goto z_bb_108;
    z_bb_107:
    zT_911 = 18;
    goto z_bb_108;
    z_bb_108:
    gv_tid2 = zT_911;
    if ((unsigned char)(gv_tid2 == (unsigned int)(19))) goto z_bb_110; else goto z_bb_109;
    z_bb_109:
    zT_916 = gv_tid2 == (unsigned int)(18);
    goto z_bb_111;
    z_bb_110:
    zT_916 = 1;
    goto z_bb_111;
    z_bb_111:
    if (zT_916) goto z_bb_113; else goto z_bb_112;
    z_bb_112:
    zT_919 = gv_tid2 == (unsigned int)(0);
    goto z_bb_114;
    z_bb_113:
    zT_919 = 1;
    goto z_bb_114;
    z_bb_114:
    if (zT_919) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_923 = &ctx->const_inits;
    zT_924 = gv_ctree;
    zT_926 = zF_C30CDA77_constInitNodeAt(zT_923, zT_924);
    gv_rn = zT_926;
    zT_927 = gv_rn.kind;
    if ((unsigned char)(zT_927 == (unsigned char)(1))) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_954 = 0;
    gv_lv = zT_954;
    zT_955 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_955) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_133; else goto z_bb_134;
    z_bb_117:
    zT_931 = gv_rn.kind;
    zT_930 = zT_931 == (unsigned char)(4);
    goto z_bb_119;
    z_bb_118:
    zT_930 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_930) goto z_bb_120; else goto z_bb_122;
    z_bb_120:
    zT_934 = 10;
    gv_tid2 = zT_934;
    zT_935 = gv_rn.b;
    if ((unsigned char)((unsigned int)(zT_935 & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_123; else goto z_bb_125;
    z_bb_121:
    goto z_bb_116;
    z_bb_122:
    zT_945 = gv_rn.kind;
    if ((unsigned char)(zT_945 == (unsigned char)(3))) goto z_bb_128; else goto z_bb_130;
    z_bb_123:
    zT_940 = 7;
    gv_tid2 = zT_940;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_941 = gv_rn.a;
    if ((unsigned char)(zT_941 > (zT_79FAE712_u64)(4294967295u))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_944 = 11;
    gv_tid2 = zT_944;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_948 = 2;
    gv_tid2 = zT_948;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_121;
    z_bb_130:
    zT_949 = gv_rn.kind;
    if ((unsigned char)(zT_949 == (unsigned char)(2))) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_952 = 16;
    gv_tid2 = zT_952;
    goto z_bb_132;
    z_bb_132:
    goto z_bb_129;
    z_bb_133:
    zT_961 = 1;
    gv_lv = zT_961;
    goto z_bb_134;
    z_bb_134:
    zT_962 = &ctx->global_decls;
    zT_965.name_id = gv_name;
    zT_966 = mods.ptr;
    zT_967 = mods.len;
    zT_968 = mi < zT_967;
    if (!(zT_968)) { pal_trap(); }
    zT_969 = zT_966[mi];
    zT_970 = zT_969.id;
    zT_965.module_id = zT_970;
    zT_965.type_id = gv_tid2;
    zT_971 = 0;
    zT_965.has_runtime_init = zT_971;
    zT_965.const_init = gv_ctree;
    zT_965.link_visible = gv_lv;
    zT_963 = zT_965;
    zF_F2C82CE7_globalDeclArrayList(zT_962, zT_963);
    zT_972 = ctx->cli;
    zT_973 = zT_972.debug;
    if (zT_973) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_975 = ctx->source_man;
    zT_979 = mods.ptr;
    zT_980 = mods.len;
    zT_981 = mi < zT_980;
    if (!(zT_981)) { pal_trap(); }
    zT_982 = zT_979[mi];
    zT_976 = zT_982.source_file_id;
    zT_977 = decl.span_start;
    zT_985 = zF_4966CE4A_sourceManagerGetLoc(zT_975, zT_976, zT_977);
    g_sym_loc = zT_985;
    zT_986 = &ctx->debug_symbols;
    zT_990 = 1;
    zT_989.kind = zT_990;
    zT_991 = 0;
    zT_989.is_extern = zT_991;
    zT_989.name_id = gv_name;
    zT_992 = mods.ptr;
    zT_993 = mods.len;
    zT_994 = mi < zT_993;
    if (!(zT_994)) { pal_trap(); }
    zT_995 = zT_992[mi];
    zT_996 = zT_995.id;
    zT_989.module_id = zT_996;
    zT_989.type_id = gv_tid2;
    zT_997 = g_sym_loc.line;
    zT_989.src_line = zT_997;
    zT_998 = mods.ptr;
    zT_999 = mods.len;
    zT_1000 = mi < zT_999;
    if (!(zT_1000)) { pal_trap(); }
    zT_1001 = zT_998[mi];
    zT_1002 = zT_1001.source_file_id;
    zT_989.src_file_id = zT_1002;
    zT_1003 = decl.span_start;
    zT_989.decl_span = zT_1003;
    zT_987 = zT_989;
    zF_3CC05A74_debugSymbolListAppe(zT_986, zT_987);
    goto z_bb_136;
    z_bb_136:
    goto z_bb_102;
    z_bb_137:
    zT_1012 = 1;
    gv_is_storage = zT_1012;
    goto z_bb_138;
    z_bb_138:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_150; else goto z_bb_151;
    z_bb_139:
    zT_1013 = decl.child_1;
    if ((unsigned char)(zT_1013 != (unsigned int)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    zT_1017 = ctx->store;
    zT_1018 = decl.child_1;
    zT_1021 = zF_FCDD1D35_astStoreNodeAt(zT_1017, zT_1018);
    gv_init = zT_1021;
    zT_1022 = gv_init.kind;
    if ((unsigned char)(zT_1022 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    zT_1027 = gv_init.kind;
    zT_1026 = zT_1027 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_144;
    z_bb_143:
    zT_1026 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_1026) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_1032 = gv_init.kind;
    zT_1031 = zT_1032 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_147;
    z_bb_146:
    zT_1031 = 0;
    goto z_bb_147;
    z_bb_147:
    if (zT_1031) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    zT_1036 = 1;
    gv_is_storage = zT_1036;
    goto z_bb_149;
    z_bb_149:
    goto z_bb_141;
    z_bb_150:
    zT_1039 = decl.child_1;
    if ((unsigned char)(zT_1039 != (unsigned int)(0))) goto z_bb_152; else goto z_bb_153;
    z_bb_151:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_160; else goto z_bb_161;
    z_bb_152:
    zT_1043 = ctx->store;
    zT_1044 = decl.child_1;
    zT_1047 = zF_FCDD1D35_astStoreNodeAt(zT_1043, zT_1044);
    gv_init3 = zT_1047;
    zT_1048 = gv_init3.kind;
    if ((unsigned char)(zT_1048 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_151;
    z_bb_154:
    zT_1052 = 0;
    gv_is_storage = zT_1052;
    goto z_bb_155;
    z_bb_155:
    zT_1053 = gv_init3.kind;
    if ((unsigned char)(zT_1053 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_1058 = ctx->store;
    zT_1059 = gv_init3.child_0;
    zT_1062 = zF_FCDD1D35_astStoreNodeAt(zT_1058, zT_1059);
    gv_fb = zT_1062;
    zT_1063 = gv_fb.kind;
    if ((unsigned char)(zT_1063 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    goto z_bb_153;
    z_bb_158:
    zT_1067 = 0;
    gv_is_storage = zT_1067;
    goto z_bb_159;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    zT_1070 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_1070) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_162; else goto z_bb_163;
    z_bb_161:
    goto z_bb_102;
    z_bb_162:
    zT_1077 = mods.ptr;
    zT_1078 = mods.len;
    zT_1079 = mi < zT_1078;
    if (!(zT_1079)) { pal_trap(); }
    zT_1080 = zT_1077[mi];
    zT_1081 = zT_1080.id;
    zT_1082 = (zT_79FAE712_u64)zT_1081;
    zT_1083 = 35;
    zT_1086 = zT_1083 < (unsigned int)(64);
    if (!(zT_1086)) { pal_trap(); }
    zT_1084 = zig_wrap_shl_u(((zu64)(zT_1082)), ((zu64)(zT_1083)), 64u);
    zT_1087 = zig_overflow_flag_shl_u(((zu64)(zT_1082)), ((zu64)(zT_1083)), 64u);
    zT_1089 = zT_1087 == (unsigned int)(0);
    if (!(zT_1089)) { pal_trap(); }
    zT_1090 = 1;
    zT_1091 = 32;
    zT_1094 = zT_1091 < (unsigned int)(64);
    if (!(zT_1094)) { pal_trap(); }
    zT_1092 = zig_wrap_shl_u(((zu64)(zT_1090)), ((zu64)(zT_1091)), 64u);
    zT_1095 = zig_overflow_flag_shl_u(((zu64)(zT_1090)), ((zu64)(zT_1091)), 64u);
    zT_1097 = zT_1095 == (unsigned int)(0);
    if (!(zT_1097)) { pal_trap(); }
    zT_1100 = (zT_79FAE712_u64)(zT_1084 | zT_1092) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_1100;
    zT_1101 = &ctx->exported;
    zT_1102 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_1101, zT_1102, (unsigned int)(1));
    goto z_bb_163;
    z_bb_163:
    zT_1107 = 0;
    gv_has_ri = zT_1107;
    zT_1108 = decl.child_1;
    if ((unsigned char)(zT_1108 != (unsigned int)(0))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_1112 = ctx->store;
    zT_1113 = decl.child_1;
    zT_1116 = zF_FCDD1D35_astStoreNodeAt(zT_1112, zT_1113);
    gv_init2 = zT_1116;
    zT_1117 = gv_init2.kind;
    if ((unsigned char)(zT_1117 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_166; else goto z_bb_167;
    z_bb_165:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_168; else goto z_bb_169;
    z_bb_166:
    zT_1121 = 1;
    gv_has_ri = zT_1121;
    goto z_bb_167;
    z_bb_167:
    goto z_bb_165;
    z_bb_168:
    zT_1124 = 1;
    mod_has_ri = zT_1124;
    goto z_bb_169;
    z_bb_169:
    zT_1126 = ctx->resolved_types;
    zT_1127 = decl_idx;
    zT_1129 = zF_999DCF51_resolvedTypeTableGe(zT_1126, zT_1127);
    gv_rt = zT_1129;
    zT_1131 = gv_rt.has_value;
    if (zT_1131) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    if (!(gv_rt.has_value)) { pal_trap(); }
    grt = gv_rt.value;
    zT_1132 = grt;
    goto z_bb_172;
    z_bb_171:
    zT_1132 = 18;
    goto z_bb_172;
    z_bb_172:
    gv_tid = zT_1132;
    zT_1136 = 0;
    gv_lv2 = zT_1136;
    zT_1137 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_1137) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_1143 = 1;
    gv_lv2 = zT_1143;
    goto z_bb_174;
    z_bb_174:
    zT_1144 = &ctx->global_decls;
    zT_1147.name_id = gv_name;
    zT_1148 = mods.ptr;
    zT_1149 = mods.len;
    zT_1150 = mi < zT_1149;
    if (!(zT_1150)) { pal_trap(); }
    zT_1151 = zT_1148[mi];
    zT_1152 = zT_1151.id;
    zT_1147.module_id = zT_1152;
    zT_1147.type_id = gv_tid;
    zT_1147.has_runtime_init = gv_has_ri;
    zT_1153 = 4294967295u;
    zT_1147.const_init = zT_1153;
    zT_1147.link_visible = gv_lv2;
    zT_1145 = zT_1147;
    zF_F2C82CE7_globalDeclArrayList(zT_1144, zT_1145);
    zT_1154 = ctx->cli;
    zT_1155 = zT_1154.debug;
    if (zT_1155) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    zT_1157 = ctx->source_man;
    zT_1161 = mods.ptr;
    zT_1162 = mods.len;
    zT_1163 = mi < zT_1162;
    if (!(zT_1163)) { pal_trap(); }
    zT_1164 = zT_1161[mi];
    zT_1158 = zT_1164.source_file_id;
    zT_1159 = decl.span_start;
    zT_1167 = zF_4966CE4A_sourceManagerGetLoc(zT_1157, zT_1158, zT_1159);
    g2_sym_loc = zT_1167;
    zT_1168 = &ctx->debug_symbols;
    zT_1172 = 1;
    zT_1171.kind = zT_1172;
    zT_1173 = 0;
    zT_1171.is_extern = zT_1173;
    zT_1171.name_id = gv_name;
    zT_1174 = mods.ptr;
    zT_1175 = mods.len;
    zT_1176 = mi < zT_1175;
    if (!(zT_1176)) { pal_trap(); }
    zT_1177 = zT_1174[mi];
    zT_1178 = zT_1177.id;
    zT_1171.module_id = zT_1178;
    zT_1171.type_id = gv_tid;
    zT_1179 = g2_sym_loc.line;
    zT_1171.src_line = zT_1179;
    zT_1180 = mods.ptr;
    zT_1181 = mods.len;
    zT_1182 = mi < zT_1181;
    if (!(zT_1182)) { pal_trap(); }
    zT_1183 = zT_1180[mi];
    zT_1184 = zT_1183.source_file_id;
    zT_1171.src_file_id = zT_1184;
    zT_1185 = decl.span_start;
    zT_1171.decl_span = zT_1185;
    zT_1169 = zT_1171;
    zF_3CC05A74_debugSymbolListAppe(zT_1168, zT_1169);
    goto z_bb_176;
    z_bb_176:
    goto z_bb_161;
    z_bb_177:
    zT_1194 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_1197 = ctx->alloc;
    zT_1195 = &zT_1197->scratch;
    zT_1199 = zF_ADD4254B_lowererInit(zT_1194, zT_1195);
    ilowerer = zT_1199;
    zT_1200 = mods.ptr;
    zT_1201 = mods.len;
    zT_1202 = mi < zT_1201;
    if (!(zT_1202)) { pal_trap(); }
    zT_1203 = zT_1200[mi];
    zT_1204 = zT_1203.id;
    ilowerer.module_id = zT_1204;
    zT_1205 = ctx->module_reg;
    ilowerer.module_reg = zT_1205;
    zT_1206 = ctx->cli;
    zT_1207 = zT_1206.debug;
    if (zT_1207) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    zT_1272 = ctx->module_reg;
    zT_1274 = zF_3452C137_moduleRegistryGetMo(zT_1272);
    amods = zT_1274;
    zT_1276 = amods.len;
    if ((unsigned char)(zT_1276 > (unsigned int)(0))) goto z_bb_188; else goto z_bb_189;
    z_bb_179:
    zT_1209 = 1;
    zT_1208 = (unsigned char)zT_1209;
    goto z_bb_181;
    z_bb_180:
    zT_1211 = 0;
    zT_1208 = (unsigned char)zT_1211;
    goto z_bb_181;
    z_bb_181:
    ilowerer.debug_enabled = (unsigned char)((unsigned char)zT_1208);
    zT_1214 = ctx->cli;
    zT_1215 = zT_1214.debug;
    if (zT_1215) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_1216 = ctx->debug_span_buf;
    ilowerer.debug_spans = zT_1216;
    zT_1217 = 0;
    zT_1219 = (zT_02EB57B2_LirLowerer*)&ilowerer;
    zT_1220 = &zT_1219->debug_spans;
    zT_1220->len = (unsigned int)((unsigned int)zT_1217);
    goto z_bb_183;
    z_bb_183:
    zT_1222 = (zT_02EB57B2_LirLowerer*)&ilowerer;
    zT_1227 = mods.ptr;
    zT_1228 = mods.len;
    zT_1229 = mi < zT_1228;
    if (!(zT_1229)) { pal_trap(); }
    zT_1230 = zT_1227[mi];
    zT_1223 = zT_1230.ast_root;
    zT_1232 = mods.ptr;
    zT_1233 = mods.len;
    zT_1234 = mi < zT_1233;
    if (!(zT_1234)) { pal_trap(); }
    zT_1235 = zT_1232[mi];
    zT_1224 = zT_1235.id;
    zT_1225 = &ctx->module_init_deps;
    zT_1238 = zF_552B231C_lowerModuleInit(zT_1222, zT_1223, zT_1224, zT_1225);
    imf = zT_1238;
    zT_1240 = &ctx->lir_stream;
    zT_1241 = imf;
    zT_1243 = zF_9F47D5E4_lirStreamAppend(zT_1240, zT_1241);
    islot = zT_1243;
    zT_1244 = &ctx->lir_slots;
    zT_1245 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_1244, zT_1245);
    zT_1247 = ctx->cli;
    zT_1248 = zT_1247.debug;
    if (zT_1248) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_1249 = &ctx->debug_spans;
    zT_1250 = islot.disk_offset;
    zT_1254 = ilowerer.debug_spans;
    zT_1255 = zT_1254.items;
    zT_1256 = ilowerer.debug_spans;
    zT_1257 = zT_1256.len;
    zT_1258 = 0;
    zT_1259 = zT_1255 + zT_1258;
    zT_1260 = zT_1257 - zT_1258;
    zT_1261 = (unsigned int)zT_1258 <= zT_1257;
    if (!(zT_1261)) { pal_trap(); }
    zT_1262.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_1259;
    zT_1262.len = zT_1260;
    zT_1251 = zT_1262;
    zF_BB256CBD_debugSpanStoreAppen(zT_1249, zT_1250, zT_1251);
    zT_1263 = ilowerer.debug_spans;
    ctx->debug_span_buf = zT_1263;
    zT_1264 = 0;
    zT_1266 = &ctx->debug_span_buf;
    zT_1266->len = (unsigned int)((unsigned int)zT_1264);
    goto z_bb_185;
    z_bb_185:
    if ((unsigned char)(!async_pending)) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_1269 = ctx->alloc;
    zT_1268 = &zT_1269->scratch;
    zF_F1B3F8C2_sandReset(zT_1268);
    goto z_bb_187;
    z_bb_187:
    goto z_bb_178;
    z_bb_188:
    zT_1280 = amods.ptr;
    zT_1281 = 0;
    zT_1282 = amods.len;
    zT_1283 = (unsigned int)zT_1281 < zT_1282;
    if (!(zT_1283)) { pal_trap(); }
    zT_1284 = zT_1280[zT_1281];
    zT_1285 = zT_1284.ast_root;
    zT_1279 = zT_1285 != (unsigned int)(0);
    goto z_bb_190;
    z_bb_189:
    zT_1279 = 0;
    goto z_bb_190;
    z_bb_190:
    if (zT_1279) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_1289 = ctx->store;
    zT_1292 = amods.ptr;
    zT_1293 = 0;
    zT_1294 = amods.len;
    zT_1295 = (unsigned int)zT_1293 < zT_1294;
    if (!(zT_1295)) { pal_trap(); }
    zT_1296 = zT_1292[zT_1293];
    zT_1290 = zT_1296.ast_root;
    zT_1298 = zF_FCDD1D35_astStoreNodeAt(zT_1289, zT_1290);
    ar = zT_1298;
    zT_1299 = ar.kind;
    if ((unsigned char)(zT_1299 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    goto z_bb_44;
    z_bb_193:
    zT_1304 = ctx->store;
    zT_1307 = amods.ptr;
    zT_1308 = 0;
    zT_1309 = amods.len;
    zT_1310 = (unsigned int)zT_1308 < zT_1309;
    if (!(zT_1310)) { pal_trap(); }
    zT_1311 = zT_1307[zT_1308];
    zT_1305 = zT_1311.ast_root;
    zT_1313 = zF_152E19CB_astStoreNodeExtraCh(zT_1304, zT_1305);
    adl_n = zT_1313;
    zT_1315 = 0;
    adi = zT_1315;
    zT_1317 = "A0";
    zT_1319 = 2;
    zT_1318.ptr = (unsigned char*)zT_1317;
    zT_1318.len = zT_1319;
    al = zT_1318;
    zT_1320 = al;
    zF_48AC7B3A_markerWrite(zT_1320);
    goto z_bb_195;
    z_bb_194:
    goto z_bb_192;
    z_bb_195:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    zT_1324 = ctx->store;
    zT_1327 = ctx->store;
    zT_1331 = amods.ptr;
    zT_1332 = 0;
    zT_1333 = amods.len;
    zT_1334 = (unsigned int)zT_1332 < zT_1333;
    if (!(zT_1334)) { pal_trap(); }
    zT_1335 = zT_1331[zT_1332];
    zT_1328 = zT_1335.ast_root;
    zT_1338 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1327, zT_1328, (unsigned int)((unsigned int)adi));
    zT_1325 = zT_1338;
    zT_1339 = zF_FCDD1D35_astStoreNodeAt(zT_1324, zT_1325);
    ad = zT_1339;
    zT_1341 = ad.kind;
    zT_1342 = (unsigned int)zT_1341;
    ak = zT_1342;
    zig_poison_fill((void*)&zT_1344, (unsigned int)sizeof zT_1344);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_1344[_i];
        _i++;
    }
}
    zT_1346 = ak;
    zT_1350 = 0;
    zT_1351 = (unsigned char*)((unsigned char*)ab) + zT_1350;
    zT_1352 = (unsigned int)(20) - zT_1350;
    zT_1353.ptr = (unsigned char*)zT_1351;
    zT_1353.len = zT_1352;
    zT_1347 = zT_1353;
    zT_1354 = zF_A7504564_itoa(zT_1346, zT_1347);
    alen = zT_1354;
    zT_1356 = 19;
    zT_1357 = (unsigned int)alen;
    zT_1358 = zig_wrap_sub_u(((zu64)(zT_1356)), ((zu64)(zT_1357)), 32u);
    zT_1359 = zig_overflow_flag_sub_u(((zu64)(zT_1356)), ((zu64)(zT_1357)), 32u);
    zT_1361 = zT_1359 == (unsigned int)(0);
    if (!(zT_1361)) { pal_trap(); }
    ast = zT_1358;
    zT_1365 = 19;
    zT_1366 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_1367 = zT_1365 - ast;
    zT_1368 = ast <= zT_1365;
    if (!(zT_1368)) { pal_trap(); }
    zT_1369.ptr = (unsigned char*)zT_1366;
    zT_1369.len = zT_1367;
    zT_1362 = zT_1369;
    zF_48AC7B3A_markerWrite(zT_1362);
    zT_1371 = " ";
    zT_1373 = 1;
    zT_1372.ptr = (unsigned char*)zT_1371;
    zT_1372.len = zT_1373;
    asp = zT_1372;
    zT_1374 = asp;
    zF_48AC7B3A_markerWrite(zT_1374);
    goto z_bb_198;
    z_bb_197:
    zT_1381 = "\n";
    zT_1383 = 1;
    zT_1382.ptr = (unsigned char*)zT_1381;
    zT_1382.len = zT_1383;
    an = zT_1382;
    zT_1384 = an;
    zF_48AC7B3A_markerWrite(zT_1384);
    goto z_bb_194;
    z_bb_198:
    zT_1375 = 1;
    zT_1376 = zig_wrap_add_u(((zu64)(adi)), ((zu64)(zT_1375)), 32u);
    zT_1377 = zig_overflow_flag_add_u(((zu64)(adi)), ((zu64)(zT_1375)), 32u);
    zT_1379 = zT_1377 == (unsigned int)(0);
    if (!(zT_1379)) { pal_trap(); }
    adi = zT_1376;
    goto z_bb_195;
    z_bb_199:
    zT_1393 = async_retained.len;
    if ((unsigned char)(arl_i < zT_1393)) goto z_bb_200; else goto z_bb_201;
    z_bb_200:
    zT_1396 = async_retained.items;
    zT_1397 = zT_1396[arl_i];
    zT_1399 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_1397);
    lf2 = zT_1399;
    zT_1400 = &ctx->async_layouts;
    zT_1401 = lf2->module_id;
    zT_1402 = lf2->name_id;
    zT_1406 = zF_A1F56FFB_asyncLayoutLookup(zT_1400, zT_1401, zT_1402);
    zT_1407 = zT_1406.has_value;
    if (zT_1407) goto z_bb_203; else goto z_bb_204;
    z_bb_201:
    if (async_pending) goto z_bb_205; else goto z_bb_206;
    z_bb_202:
    zT_1427 = 1;
    zT_1428 = zig_wrap_add_u(((zu64)(arl_i)), ((zu64)(zT_1427)), 32u);
    zT_1429 = zig_overflow_flag_add_u(((zu64)(arl_i)), ((zu64)(zT_1427)), 32u);
    zT_1431 = zT_1429 == (unsigned int)(0);
    if (!(zT_1431)) { pal_trap(); }
    arl_i = zT_1428;
    goto z_bb_199;
    z_bb_203:
    if (!(zT_1406.has_value)) { pal_trap(); }
    lay2 = zT_1406.value;
    zT_1411 = ctx->alloc;
    zT_1412 = &zT_1411->scratch;
    zT_1410.alloc = zT_1412;
    zT_1413 = ctx->typereg;
    zT_1410.registry = zT_1413;
    zT_1414 = ctx->interner;
    zT_1410.interner = zT_1414;
    zT_1415 = &ctx->lir_stream;
    zT_1410.lir_stream = zT_1415;
    zT_1416 = &ctx->lir_slots;
    zT_1410.lir_slots = zT_1416;
    zT_1417 = &ctx->suspending_fns;
    zT_1410.suspending_fns = zT_1417;
    zT_1410.layout = lay2;
    zT_1418 = ctx->cli;
    zT_1419 = zT_1418.safe_checks;
    zT_1410.safe_checks = zT_1419;
    zT_1420 = &ctx->frame_sizes;
    zT_1410.frame_sizes = zT_1420;
    zT_1421 = &ctx->async_layouts;
    zT_1410.async_layouts = zT_1421;
    zT_1422 = ctx->diag;
    zT_1410.diag = zT_1422;
    async_ctx2 = zT_1410;
    zT_1423 = lf2;
    zT_1424 = (zT_5839647A_AsyncTransformCtx*)&async_ctx2;
    zT_1426 = zF_7C1ED6D1_asyncTransform(zT_1423, zT_1424);
    (void)zT_1426;
    goto z_bb_204;
    z_bb_204:
    goto z_bb_202;
    z_bb_205:
    zT_1433 = ctx->alloc;
    zT_1432 = &zT_1433->scratch;
    zF_F1B3F8C2_sandReset(zT_1432);
    goto z_bb_206;
    z_bb_206:
    zT_1435 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_1435);
    zT_1436 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_1436);
    zT_1438 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_1438 != (unsigned char)(0))) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_1442 = "std_fmt.zig";
    zT_1444 = 11;
    zT_1443.ptr = (unsigned char*)zT_1442;
    zT_1443.len = zT_1444;
    c89_fmt_base = zT_1443;
    zT_1448 = ctx->module_reg;
    zT_1450 = zF_3452C137_moduleRegistryGetMo(zT_1448);
    zT_1445 = zT_1450;
    zT_1446 = ctx->interner;
    zT_1447 = c89_fmt_base;
    zT_1452 = zF_D27A4A01_moduleIdForBasename(zT_1445, zT_1446, zT_1447);
    if ((unsigned char)(zT_1452 == (unsigned int)(4294967295u))) goto z_bb_209; else goto z_bb_210;
    z_bb_208:
    return;
    z_bb_209:
    zT_1456 = "could not resolve imported file '";
    zT_1458 = 33;
    zT_1457.ptr = (unsigned char*)zT_1456;
    zT_1457.len = zT_1458;
    p1 = zT_1457;
    zT_1460 = "'";
    zT_1462 = 1;
    zT_1461.ptr = (unsigned char*)zT_1460;
    zT_1461.len = zT_1462;
    p2 = zT_1461;
    zT_1465 = 0;
    zT_1464[zT_1465] = p1;
    zT_1466 = 1;
    zT_1464[zT_1466] = c89_fmt_base;
    zT_1467 = 2;
    zT_1464[zT_1467] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_1464[_i];
        _i++;
    }
}
    zT_1469 = ctx->interner;
    zT_1473 = 0;
    zT_1475 = (unsigned int)zT_1473 < (unsigned int)(3);
    if (!(zT_1475)) { pal_trap(); }
    zT_1476 = parts + zT_1473;
    zT_1470 = zT_1476;
    zT_1478 = zF_8C4BFF7C_diagnosticBuilderMa(zT_1469, zT_1470, (unsigned int)(3));
    msg = zT_1478;
    zT_1479 = ctx->diag;
    zT_1485 = msg;
    zT_1494 = zF_C82559AC_diagnosticCollector(zT_1479, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_1485);
    (void)zT_1494;
    goto z_bb_210;
    z_bb_210:
    goto z_bb_208;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4;
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_69057089_CompilerAlloc* zT_14;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_FDFD82FD_EU_362 zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned char* zT_26;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned char zT_44;
    unsigned char zT_48;
    unsigned int zT_50;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    unsigned int zT_57;
    unsigned char zT_58;
    zT_6E8D187B_ModuleEntry zT_59;
    unsigned int zT_60;
    zT_79FAE712_u64 zT_61;
    zT_79FAE712_u64 zT_62;
    zT_79FAE712_u64 zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_6E8D187B_ModuleEntry* zT_69;
    unsigned int zT_70;
    unsigned char zT_71;
    zT_6E8D187B_ModuleEntry zT_72;
    unsigned int zT_73;
    zT_79FAE712_u64 zT_75;
    zT_A4CE86B7_U64ToU32Map* zT_76;
    zT_79FAE712_u64 zT_77;
    zT_BAEE192E_Opt_10 zT_79;
    unsigned char zT_80;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned int zT_96;
    unsigned char zT_98;
    unsigned char zT_100;
    unsigned char zT_103;
    unsigned int zT_107;
    unsigned char zT_109;
    zT_6E8D187B_ModuleEntry* zT_113;
    unsigned int zT_114;
    unsigned char zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_79FAE712_u64 zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    unsigned char zT_122;
    unsigned int zT_123;
    unsigned char zT_125;
    zT_6E8D187B_ModuleEntry* zT_126;
    unsigned int zT_127;
    unsigned char zT_128;
    zT_6E8D187B_ModuleEntry zT_129;
    unsigned int zT_130;
    zT_79FAE712_u64 zT_132;
    zT_A4CE86B7_U64ToU32Map* zT_133;
    zT_79FAE712_u64 zT_134;
    zT_BAEE192E_Opt_10 zT_136;
    unsigned char zT_137;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_22A7C88B_AstNode zT_143;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_F85C5DED_DiagnosticCollector* zT_148;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_6E8D187B_ModuleEntry* zT_160;
    unsigned int zT_161;
    unsigned char zT_162;
    zT_6E8D187B_ModuleEntry zT_163;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_172;
    unsigned int zT_173;
    unsigned char zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned char zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned char zT_184;
    unsigned char zT_185;
    zT_B687BB96_U32ArrayList* zT_186;
    unsigned int zT_187;
    zT_6E8D187B_ModuleEntry* zT_189;
    unsigned int zT_190;
    unsigned char zT_191;
    zT_6E8D187B_ModuleEntry zT_192;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned char zT_198;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_136, (unsigned int)sizeof zT_136);
    zig_poison_fill((void*)&zT_143, (unsigned int)sizeof zT_143);
    zig_poison_fill((void*)&zT_173, (unsigned int)sizeof zT_173);
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_12 = zT_17;
    zT_22 = zF_1395EB68_sandAlloc(zT_11, zT_12, (unsigned int)(1));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_24 = zT_22.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_26 = (unsigned char*)zT_24;
    placed = zT_26;
    zT_28 = 0;
    i = zT_28;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = 0;
    placed[i] = zT_30;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_31 = 1;
    zT_32 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    i = zT_32;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_40 = 0;
    i = zT_40;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_44 = placed[i];
    if ((unsigned char)(zT_44 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_89 = 1;
    zT_90 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    i = zT_90;
    goto z_bb_12;
    z_bb_16:
    zT_42 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_42 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_48 = 1;
    ok = zT_48;
    zT_50 = 0;
    j = zT_50;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_52 = placed[j];
    if ((unsigned char)(zT_52 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_82 = 1;
    zT_83 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    j = zT_83;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_56 = mods.ptr;
    zT_57 = mods.len;
    zT_58 = i < zT_57;
    if (!(zT_58)) { pal_trap(); }
    zT_59 = zT_56[i];
    zT_60 = zT_59.id;
    zT_61 = (zT_79FAE712_u64)zT_60;
    zT_62 = 32;
    zT_65 = zT_62 < (unsigned int)(64);
    if (!(zT_65)) { pal_trap(); }
    zT_63 = zig_wrap_shl_u(((zu64)(zT_61)), ((zu64)(zT_62)), 64u);
    zT_66 = zig_overflow_flag_shl_u(((zu64)(zT_61)), ((zu64)(zT_62)), 64u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_69 = mods.ptr;
    zT_70 = mods.len;
    zT_71 = j < zT_70;
    if (!(zT_71)) { pal_trap(); }
    zT_72 = zT_69[j];
    zT_73 = zT_72.id;
    zT_75 = zT_63 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_73);
    dep_key = zT_75;
    zT_76 = &ctx->module_init_deps;
    zT_77 = dep_key;
    zT_79 = zF_A05A7BE1_u64ToU32MapGet(zT_76, zT_77);
    zT_80 = zT_79.has_value;
    if (zT_80) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_81 = 0;
    ok = zT_81;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_96 = 0;
    ri = zT_96;
    zT_98 = 0;
    reported = zT_98;
    goto z_bb_33;
    z_bb_32:
    zT_185 = 1;
    placed[pick] = zT_185;
    zT_186 = &ctx->module_init_order;
    zT_189 = mods.ptr;
    zT_190 = mods.len;
    zT_191 = pick < zT_190;
    if (!(zT_191)) { pal_trap(); }
    zT_192 = zT_189[pick];
    zT_187 = zT_192.id;
    zF_62F717A2_u32ArrayListAppend(zT_186, zT_187);
    zT_194 = 1;
    zT_195 = zig_wrap_sub_u(((zu64)(remaining)), ((zu64)(zT_194)), 32u);
    zT_196 = zig_overflow_flag_sub_u(((zu64)(remaining)), ((zu64)(zT_194)), 32u);
    zT_198 = zT_196 == (unsigned int)(0);
    if (!(zT_198)) { pal_trap(); }
    remaining = zT_195;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_103 = placed[ri];
    if ((unsigned char)(zT_103 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_180 = 1;
    zT_181 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_180)), 32u);
    zT_182 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_180)), 32u);
    zT_184 = zT_182 == (unsigned int)(0);
    if (!(zT_184)) { pal_trap(); }
    ri = zT_181;
    goto z_bb_33;
    z_bb_37:
    zT_100 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_100 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_100) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_107 = 0;
    rj = zT_107;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_109 = placed[rj];
    if ((unsigned char)(zT_109 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_175 = 1;
    zT_176 = zig_wrap_add_u(((zu64)(rj)), ((zu64)(zT_175)), 32u);
    zT_177 = zig_overflow_flag_add_u(((zu64)(rj)), ((zu64)(zT_175)), 32u);
    zT_179 = zT_177 == (unsigned int)(0);
    if (!(zT_179)) { pal_trap(); }
    rj = zT_176;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_113 = mods.ptr;
    zT_114 = mods.len;
    zT_115 = ri < zT_114;
    if (!(zT_115)) { pal_trap(); }
    zT_116 = zT_113[ri];
    zT_117 = zT_116.id;
    zT_118 = (zT_79FAE712_u64)zT_117;
    zT_119 = 32;
    zT_122 = zT_119 < (unsigned int)(64);
    if (!(zT_122)) { pal_trap(); }
    zT_120 = zig_wrap_shl_u(((zu64)(zT_118)), ((zu64)(zT_119)), 64u);
    zT_123 = zig_overflow_flag_shl_u(((zu64)(zT_118)), ((zu64)(zT_119)), 64u);
    zT_125 = zT_123 == (unsigned int)(0);
    if (!(zT_125)) { pal_trap(); }
    zT_126 = mods.ptr;
    zT_127 = mods.len;
    zT_128 = rj < zT_127;
    if (!(zT_128)) { pal_trap(); }
    zT_129 = zT_126[rj];
    zT_130 = zT_129.id;
    zT_132 = zT_120 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_130);
    cyc_key = zT_132;
    zT_133 = &ctx->module_init_deps;
    zT_134 = cyc_key;
    zT_136 = zF_A05A7BE1_u64ToU32MapGet(zT_133, zT_134);
    zT_137 = zT_136.has_value;
    if (zT_137) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    if (!(zT_136.has_value)) { pal_trap(); }
    ref_decl = zT_136.value;
    zT_140 = ctx->store;
    zT_141 = ref_decl;
    zT_143 = zF_FCDD1D35_astStoreNodeAt(zT_140, zT_141);
    cyc_dcl = zT_143;
    zT_145 = "cyclic global initializer dependency";
    zT_147 = 36;
    zT_146.ptr = (unsigned char*)zT_145;
    zT_146.len = zT_147;
    cyc_msg = zT_146;
    zT_148 = ctx->diag;
    zT_160 = mods.ptr;
    zT_161 = mods.len;
    zT_162 = ri < zT_161;
    if (!(zT_162)) { pal_trap(); }
    zT_163 = zT_160[ri];
    zT_151 = zT_163.source_file_id;
    zT_152 = cyc_dcl.span_start;
    zT_166 = cyc_dcl.span_start;
    zT_167 = cyc_dcl.span_len;
    zT_168 = (unsigned int)zT_167;
    zT_169 = zig_wrap_add_u(((zu64)(zT_166)), ((zu64)(zT_168)), 32u);
    zT_170 = zig_overflow_flag_add_u(((zu64)(zT_166)), ((zu64)(zT_168)), 32u);
    zT_172 = zT_170 == (unsigned int)(0);
    if (!(zT_172)) { pal_trap(); }
    zT_153 = zT_169;
    zT_154 = cyc_msg;
    zT_173 = zF_C82559AC_diagnosticCollector(zT_148, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_151, zT_152, zT_153, zT_154);
    (void)zT_173;
    zT_174 = 1;
    reported = zT_174;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_41;
    zT_21D3708C_U32ToU32Map* zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_52 = 1;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    ti = zT_54;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_36 = (unsigned int)zT_35;
    zT_37 = zig_wrap_add_u(((zu64)(zT_36)), ((zu64)(ei)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(zT_36)), ((zu64)(ei)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_41 = zT_34[zT_37];
    mname_id = zT_41;
    zT_42 = &ctx->error_code_registry;
    zT_43 = mname_id;
    zT_45 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_42, zT_43);
    (void)zT_45;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    ei = zT_48;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_79FAE712_u64 zT_18;
    zT_A4CE86B7_U64ToU32Map* zT_19;
    zT_79FAE712_u64 zT_20;
    zT_BAEE192E_Opt_10 zT_21;
    unsigned char zT_22;
    zT_A4CE86B7_U64ToU32Map* zT_23;
    zT_79FAE712_u64 zT_24;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    unsigned short zT_31;
    unsigned char zT_34;
    unsigned short zT_35;
    zT_21D3708C_U32ToU32Map* zT_37;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned short zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    zT_33EF6BFB_TypeKind zT_51;
    zT_406493CE_StructPayload* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_406493CE_StructPayload zT_59;
    unsigned int zT_61;
    unsigned short zT_62;
    zT_21D3708C_U32ToU32Map* zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_A4CE86B7_U64ToU32Map* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_2DF01B61_FieldEntry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    zT_2DF01B61_FieldEntry zT_77;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned char zT_83;
    zT_33EF6BFB_TypeKind zT_84;
    zT_54FF90FA_TaggedUnionPayload* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_54FF90FA_TaggedUnionPayload zT_92;
    zT_21D3708C_U32ToU32Map* zT_93;
    zT_338B7C76_TypeRegistry* zT_94;
    zT_A4CE86B7_U64ToU32Map* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_100;
    unsigned short zT_101;
    zT_21D3708C_U32ToU32Map* zT_104;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_A4CE86B7_U64ToU32Map* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_2DF01B61_FieldEntry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    zT_2DF01B61_FieldEntry zT_116;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    zT_33EF6BFB_TypeKind zT_123;
    unsigned char zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    zT_AF9231A2_UnionPayload* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_AF9231A2_UnionPayload zT_136;
    zT_21D3708C_U32ToU32Map* zT_137;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_A4CE86B7_U64ToU32Map* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_144;
    unsigned short zT_145;
    zT_21D3708C_U32ToU32Map* zT_148;
    zT_338B7C76_TypeRegistry* zT_149;
    zT_A4CE86B7_U64ToU32Map* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_2DF01B61_FieldEntry* zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char zT_159;
    zT_2DF01B61_FieldEntry zT_160;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned char zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    zT_457ECFEE_EnumPayload* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_457ECFEE_EnumPayload zT_175;
    zT_21D3708C_U32ToU32Map* zT_176;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_A4CE86B7_U64ToU32Map* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_33EF6BFB_TypeKind zT_182;
    zT_E834303C_ArrayPayload* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_E834303C_ArrayPayload zT_190;
    zT_21D3708C_U32ToU32Map* zT_191;
    zT_338B7C76_TypeRegistry* zT_192;
    zT_A4CE86B7_U64ToU32Map* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_33EF6BFB_TypeKind zT_197;
    zT_666DC2E1_TuplePayload* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_666DC2E1_TuplePayload zT_205;
    unsigned int zT_207;
    unsigned short zT_208;
    zT_21D3708C_U32ToU32Map* zT_211;
    zT_338B7C76_TypeRegistry* zT_212;
    zT_A4CE86B7_U64ToU32Map* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned char zT_222;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned char zT_228;
    zT_33EF6BFB_TypeKind zT_229;
    zT_0B10E8E9_OptionalPayload* zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_0B10E8E9_OptionalPayload zT_237;
    zT_21D3708C_U32ToU32Map* zT_238;
    zT_338B7C76_TypeRegistry* zT_239;
    zT_A4CE86B7_U64ToU32Map* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    zT_33EF6BFB_TypeKind zT_244;
    zT_42C2D6BF_EUPayload* zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_42C2D6BF_EUPayload zT_252;
    zT_21D3708C_U32ToU32Map* zT_253;
    zT_338B7C76_TypeRegistry* zT_254;
    zT_A4CE86B7_U64ToU32Map* zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    zT_21D3708C_U32ToU32Map* zT_259;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_A4CE86B7_U64ToU32Map* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = (zT_79FAE712_u64)src_mid;
    zT_10 = 32;
    zT_13 = zT_10 < (unsigned int)(64);
    if (!(zT_13)) { pal_trap(); }
    zT_11 = zig_wrap_shl_u(((zu64)(zT_9)), ((zu64)(zT_10)), 64u);
    zT_14 = zig_overflow_flag_shl_u(((zu64)(zT_9)), ((zu64)(zT_10)), 64u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_18 = zT_11 | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_18;
    zT_19 = visited;
    zT_20 = vkey;
    zT_21 = zF_A05A7BE1_u64ToU32MapGet(zT_19, zT_20);
    zT_22 = zT_21.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_23 = visited;
    zT_24 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_23, zT_24, (unsigned int)(1));
    zT_28 = reg->types_items;
    zT_29 = (unsigned int)tid;
    zT_30 = zT_28[zT_29];
    ty = zT_30;
    zT_31 = ty.module_id;
    if ((unsigned char)(zT_31 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = ty.module_id;
    zT_34 = zT_35 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_34 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_34) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = ref_edges;
    zT_40 = 65536;
    zT_41 = zig_wrap_mul_u(((zu64)(src_mid)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(src_mid)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_45 = ty.module_id;
    zT_46 = zig_wrap_add_u(((zu64)(zT_41)), ((zu64)(zT_45)), 32u);
    zT_47 = zig_overflow_flag_add_u(((zu64)(zT_41)), ((zu64)(zT_45)), 32u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    zT_38 = zT_46;
    zF_26476265_u32ToU32MapPut(zT_37, zT_38, (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_51 = ty.kind;
    if ((unsigned char)(zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_56 = reg->st_items;
    zT_57 = ty.payload_idx;
    zT_58 = (unsigned int)zT_57;
    zT_59 = zT_56[zT_58];
    p = zT_59;
    zT_61 = 0;
    fi = zT_61;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_84 = ty.kind;
    if ((unsigned char)(zT_84 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_62 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_62))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_65 = ref_edges;
    zT_66 = reg;
    zT_67 = visited;
    zT_68 = src_mid;
    zT_70 = reg->fe_items;
    zT_71 = p.fields_start;
    zT_72 = (unsigned int)zT_71;
    zT_73 = zig_wrap_add_u(((zu64)(zT_72)), ((zu64)(fi)), 32u);
    zT_74 = zig_overflow_flag_add_u(((zu64)(zT_72)), ((zu64)(fi)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    zT_77 = zT_70[zT_73];
    zT_69 = zT_77.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_65, zT_66, zT_67, zT_68, zT_69);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_79 = 1;
    zT_80 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_79)), 32u);
    zT_81 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_79)), 32u);
    zT_83 = zT_81 == (unsigned int)(0);
    if (!(zT_83)) { pal_trap(); }
    fi = zT_80;
    goto z_bb_13;
    z_bb_17:
    zT_89 = reg->tu_items;
    zT_90 = ty.payload_idx;
    zT_91 = (unsigned int)zT_90;
    zT_92 = zT_89[zT_91];
    p_1 = zT_92;
    zT_93 = ref_edges;
    zT_94 = reg;
    zT_95 = visited;
    zT_96 = src_mid;
    zT_97 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_93, zT_94, zT_95, zT_96, zT_97);
    zT_100 = 0;
    fi = zT_100;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_123 = ty.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_101 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_101))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_104 = ref_edges;
    zT_105 = reg;
    zT_106 = visited;
    zT_107 = src_mid;
    zT_109 = reg->fe_items;
    zT_110 = p_1.fields_start;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zig_wrap_add_u(((zu64)(zT_111)), ((zu64)(fi)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(zT_111)), ((zu64)(fi)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    zT_116 = zT_109[zT_112];
    zT_108 = zT_116.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_104, zT_105, zT_106, zT_107, zT_108);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_118 = 1;
    zT_119 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_118)), 32u);
    zT_120 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_118)), 32u);
    zT_122 = zT_120 == (unsigned int)(0);
    if (!(zT_122)) { pal_trap(); }
    fi = zT_119;
    goto z_bb_20;
    z_bb_24:
    zT_128 = ty.kind;
    zT_127 = zT_128 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_127 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_127) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_133 = reg->un_items;
    zT_134 = ty.payload_idx;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zT_133[zT_135];
    p_2 = zT_136;
    zT_137 = ref_edges;
    zT_138 = reg;
    zT_139 = visited;
    zT_140 = src_mid;
    zT_141 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_137, zT_138, zT_139, zT_140, zT_141);
    zT_144 = 0;
    fi = zT_144;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_167 = ty.kind;
    if ((unsigned char)(zT_167 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_145 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_145))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_148 = ref_edges;
    zT_149 = reg;
    zT_150 = visited;
    zT_151 = src_mid;
    zT_153 = reg->fe_items;
    zT_154 = p_2.fields_start;
    zT_155 = (unsigned int)zT_154;
    zT_156 = zig_wrap_add_u(((zu64)(zT_155)), ((zu64)(fi)), 32u);
    zT_157 = zig_overflow_flag_add_u(((zu64)(zT_155)), ((zu64)(fi)), 32u);
    zT_159 = zT_157 == (unsigned int)(0);
    if (!(zT_159)) { pal_trap(); }
    zT_160 = zT_153[zT_156];
    zT_152 = zT_160.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_148, zT_149, zT_150, zT_151, zT_152);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_162 = 1;
    zT_163 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_162)), 32u);
    zT_164 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_162)), 32u);
    zT_166 = zT_164 == (unsigned int)(0);
    if (!(zT_166)) { pal_trap(); }
    fi = zT_163;
    goto z_bb_30;
    z_bb_34:
    zT_172 = reg->en_items;
    zT_173 = ty.payload_idx;
    zT_174 = (unsigned int)zT_173;
    zT_175 = zT_172[zT_174];
    p_3 = zT_175;
    zT_176 = ref_edges;
    zT_177 = reg;
    zT_178 = visited;
    zT_179 = src_mid;
    zT_180 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_176, zT_177, zT_178, zT_179, zT_180);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_182 = ty.kind;
    if ((unsigned char)(zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_187 = reg->array_items;
    zT_188 = ty.payload_idx;
    zT_189 = (unsigned int)zT_188;
    zT_190 = zT_187[zT_189];
    p_4 = zT_190;
    zT_191 = ref_edges;
    zT_192 = reg;
    zT_193 = visited;
    zT_194 = src_mid;
    zT_195 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_191, zT_192, zT_193, zT_194, zT_195);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_197 = ty.kind;
    if ((unsigned char)(zT_197 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_202 = reg->tup_items;
    zT_203 = ty.payload_idx;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zT_202[zT_204];
    p_5 = zT_205;
    zT_207 = 0;
    ei = zT_207;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_229 = ty.kind;
    if ((unsigned char)(zT_229 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_208 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_208))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_211 = ref_edges;
    zT_212 = reg;
    zT_213 = visited;
    zT_214 = src_mid;
    zT_216 = reg->xt_items;
    zT_217 = p_5.elems_start;
    zT_218 = (unsigned int)zT_217;
    zT_219 = zig_wrap_add_u(((zu64)(zT_218)), ((zu64)(ei)), 32u);
    zT_220 = zig_overflow_flag_add_u(((zu64)(zT_218)), ((zu64)(ei)), 32u);
    zT_222 = zT_220 == (unsigned int)(0);
    if (!(zT_222)) { pal_trap(); }
    zT_215 = zT_216[zT_219];
    zF_BC6C7740_pruneTypeMarkByValu(zT_211, zT_212, zT_213, zT_214, zT_215);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_224 = 1;
    zT_225 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_224)), 32u);
    zT_226 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_224)), 32u);
    zT_228 = zT_226 == (unsigned int)(0);
    if (!(zT_228)) { pal_trap(); }
    ei = zT_225;
    goto z_bb_43;
    z_bb_47:
    zT_234 = reg->opt_items;
    zT_235 = ty.payload_idx;
    zT_236 = (unsigned int)zT_235;
    zT_237 = zT_234[zT_236];
    p_6 = zT_237;
    zT_238 = ref_edges;
    zT_239 = reg;
    zT_240 = visited;
    zT_241 = src_mid;
    zT_242 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_238, zT_239, zT_240, zT_241, zT_242);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_244 = ty.kind;
    if ((unsigned char)(zT_244 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_249 = reg->eu_items;
    zT_250 = ty.payload_idx;
    zT_251 = (unsigned int)zT_250;
    zT_252 = zT_249[zT_251];
    p_7 = zT_252;
    zT_253 = ref_edges;
    zT_254 = reg;
    zT_255 = visited;
    zT_256 = src_mid;
    zT_257 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_253, zT_254, zT_255, zT_256, zT_257);
    zT_259 = ref_edges;
    zT_260 = reg;
    zT_261 = visited;
    zT_262 = src_mid;
    zT_263 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_259, zT_260, zT_261, zT_262, zT_263);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_6E8D187B_ModuleEntry zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned char zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    unsigned char zT_48;
    unsigned char zT_49;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_6E8D187B_ModuleEntry* zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    unsigned int zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned char zT_74;
    zT_6E8D187B_ModuleEntry* zT_77;
    unsigned int zT_78;
    unsigned char zT_79;
    zT_6E8D187B_ModuleEntry zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = mods.len;
    zT_13 = i < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[i];
    zT_10 = zT_14.path_id;
    zT_16 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_16;
    zT_18 = p.len;
    zT_20 = base.len;
    if ((unsigned char)(zT_18 >= zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_82 = 1;
    zT_83 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    i = zT_83;
    goto z_bb_1;
    z_bb_5:
    zT_24 = p.len;
    zT_26 = base.len;
    zT_27 = zig_wrap_sub_u(((zu64)(zT_24)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_sub_u(((zu64)(zT_24)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    off = zT_27;
    zT_32 = 1;
    eq = zT_32;
    zT_34 = 0;
    j = zT_34;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_36 = base.len;
    if ((unsigned char)(j < zT_36)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_38 = p.ptr;
    zT_39 = zig_wrap_add_u(((zu64)(off)), ((zu64)(j)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(j)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_43 = p.len;
    zT_44 = zT_39 < zT_43;
    if (!(zT_44)) { pal_trap(); }
    zT_45 = zT_38[zT_39];
    zT_46 = base.ptr;
    zT_47 = base.len;
    zT_48 = j < zT_47;
    if (!(zT_48)) { pal_trap(); }
    zT_49 = zT_46[j];
    if ((unsigned char)(zT_45 != zT_49)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_52 = 1;
    zT_53 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    j = zT_53;
    goto z_bb_7;
    z_bb_11:
    zT_51 = 0;
    eq = zT_51;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_61 = mods.ptr;
    zT_62 = mods.len;
    zT_63 = i < zT_62;
    if (!(zT_63)) { pal_trap(); }
    zT_64 = zT_61[i];
    zT_65 = zT_64.id;
    return zT_65;
    z_bb_16:
    zT_66 = p.ptr;
    zT_67 = 1;
    zT_68 = zig_wrap_sub_u(((zu64)(off)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_sub_u(((zu64)(off)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    zT_72 = p.len;
    zT_73 = zT_68 < zT_72;
    if (!(zT_73)) { pal_trap(); }
    zT_74 = zT_66[zT_68];
    if ((unsigned char)(zT_74 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_77 = mods.ptr;
    zT_78 = mods.len;
    zT_79 = i < zT_78;
    if (!(zT_79)) { pal_trap(); }
    zT_80 = zT_77[i];
    zT_81 = zT_80.id;
    return zT_81;
    z_bb_18:
    goto z_bb_14;
}

/* phase_EmissionClassification */
void zF_2682C512_phase_EmissionClass(zT_5AB29387_CompilerContext* ctx) {
    zT_1317DCD6_C89SpellPlan* zT_1;
    zT_3E40CD83_Sand* zT_2;
    unsigned int zT_3;
    zT_69057089_CompilerAlloc* zT_5;
    zT_CA01C129_LirSlotArrayList zT_7;
    zT_7E7544E4_LirStream* zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_12;
    unsigned int zT_15;
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_7E7544E4_LirStream* zT_20;
    zT_E7714190_LirSlot zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_CA01C129_LirSlotArrayList zT_24;
    zT_E7714190_LirSlot* zT_25;
    zT_E7714190_LirSlot zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_BBC23664_LirFunction zT_29;
    unsigned int zT_31;
    zT_5D72FBF8_TempDeclArrayList zT_32;
    unsigned int zT_33;
    zT_338B7C76_TypeRegistry* zT_35;
    zT_21D3708C_U32ToU32Map* zT_36;
    unsigned int zT_37;
    zT_786E6CF2_EmissionClassificat* zT_39;
    zT_5D72FBF8_TempDeclArrayList zT_41;
    zT_1937645B_TempDecl* zT_42;
    zT_1937645B_TempDecl zT_43;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    zT_1317DCD6_C89SpellPlan* zT_50;
    zT_3E40CD83_Sand* zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    zT_BBC23664_LirFunction* zT_54;
    zT_69057089_CompilerAlloc* zT_56;
    zT_CA01C129_LirSlotArrayList zT_59;
    zT_E7714190_LirSlot* zT_60;
    zT_E7714190_LirSlot zT_61;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_7E7544E4_LirStream* zT_69;
    unsigned int zT_72;
    zT_E1A783EF_GlobalDeclArrayList zT_73;
    unsigned int zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_21D3708C_U32ToU32Map* zT_77;
    unsigned int zT_78;
    zT_786E6CF2_EmissionClassificat* zT_80;
    zT_E1A783EF_GlobalDeclArrayList zT_82;
    zT_54906056_ModuleGlobalDecl* zT_83;
    zT_54906056_ModuleGlobalDecl zT_84;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_786E6CF2_EmissionClassificat* zT_92;
    zT_1317DCD6_C89SpellPlan* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    unsigned int ec_fi;
    zT_BBC23664_LirFunction ec_fn;
    unsigned int ec_hi;
    unsigned int ec_gi;
    zT_1 = &ctx->spell_plan;
    zT_5 = ctx->alloc;
    zT_2 = &zT_5->permanent;
    zT_7 = ctx->lir_slots;
    zT_3 = zT_7.len;
    zF_D67A348C_spellPlanInit(zT_1, zT_2, zT_3);
    zT_9 = &ctx->lir_stream;
    zT_12 = ctx->alloc;
    zT_10 = &zT_12->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_9, zT_10);
    zT_15 = 0;
    ec_fi = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    if ((unsigned char)(ec_fi < zT_17)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_20 = &ctx->lir_stream;
    zT_24 = ctx->lir_slots;
    zT_25 = zT_24.items;
    zT_26 = zT_25[ec_fi];
    zT_21 = zT_26;
    zT_27 = ctx->alloc;
    zT_22 = &zT_27->lir_read;
    zT_29 = zF_1B7118E0_lirStreamReadFuncti(zT_20, zT_21, zT_22);
    ec_fn = zT_29;
    zT_31 = 0;
    ec_hi = zT_31;
    goto z_bb_5;
    z_bb_3:
    zT_69 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_69);
    zT_72 = 0;
    ec_gi = zT_72;
    goto z_bb_9;
    z_bb_4:
    zT_64 = 1;
    zT_65 = zig_wrap_add_u(((zu64)(ec_fi)), ((zu64)(zT_64)), 32u);
    zT_66 = zig_overflow_flag_add_u(((zu64)(ec_fi)), ((zu64)(zT_64)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    ec_fi = zT_65;
    goto z_bb_1;
    z_bb_5:
    zT_32 = ec_fn.hoisted_temps;
    zT_33 = zT_32.len;
    if ((unsigned char)(ec_hi < zT_33)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = ctx->typereg;
    zT_39 = &ctx->emission_classif;
    zT_36 = &zT_39->needed_tuple_set;
    zT_41 = ec_fn.hoisted_temps;
    zT_42 = zT_41.items;
    zT_43 = zT_42[ec_hi];
    zT_37 = zT_43.type_id;
    zF_7845A68F_collectNeededTuples(zT_35, zT_36, zT_37);
    goto z_bb_8;
    z_bb_7:
    zT_50 = &ctx->spell_plan;
    zT_56 = ctx->alloc;
    zT_51 = &zT_56->permanent;
    zT_52 = ctx->typereg;
    zT_59 = ctx->lir_slots;
    zT_60 = zT_59.items;
    zT_61 = zT_60[ec_fi];
    zT_53 = zT_61.disk_offset;
    zT_54 = (zT_BBC23664_LirFunction*)&ec_fn;
    zF_72205F3D_spellPlanPlanFn(zT_50, zT_51, zT_52, zT_53, zT_54);
    goto z_bb_4;
    z_bb_8:
    zT_45 = 1;
    zT_46 = zig_wrap_add_u(((zu64)(ec_hi)), ((zu64)(zT_45)), 32u);
    zT_47 = zig_overflow_flag_add_u(((zu64)(ec_hi)), ((zu64)(zT_45)), 32u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    ec_hi = zT_46;
    goto z_bb_5;
    z_bb_9:
    zT_73 = ctx->global_decls;
    zT_74 = zT_73.len;
    if ((unsigned char)(ec_gi < zT_74)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_76 = ctx->typereg;
    zT_80 = &ctx->emission_classif;
    zT_77 = &zT_80->needed_tuple_set;
    zT_82 = ctx->global_decls;
    zT_83 = zT_82.items;
    zT_84 = zT_83[ec_gi];
    zT_78 = zT_84.type_id;
    zF_7845A68F_collectNeededTuples(zT_76, zT_77, zT_78);
    goto z_bb_12;
    z_bb_11:
    zT_91 = ctx->typereg;
    zT_92 = &ctx->emission_classif;
    zF_0DE160E2_classifyTypeEmissio(zT_91, zT_92);
    zT_95 = &ctx->spell_plan;
    zT_99 = ctx->alloc;
    zT_96 = &zT_99->permanent;
    zT_97 = ctx->typereg;
    zF_869C84A7_spellPlanPlanTypeOr(zT_95, zT_96, zT_97);
    return;
    z_bb_12:
    zT_86 = 1;
    zT_87 = zig_wrap_add_u(((zu64)(ec_gi)), ((zu64)(zT_86)), 32u);
    zT_88 = zig_overflow_flag_add_u(((zu64)(ec_gi)), ((zu64)(zT_86)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    ec_gi = zT_87;
    goto z_bb_9;
}

/* buildDebugMapPath */
unsigned int zF_5E17F383_buildDebugMapPath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u od, zT_8F083A69_Slice_zT_0B42B2F8_u stem, zT_8F083A69_Slice_zT_0B42B2F8_u ext) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned char* zT_51;
    unsigned int zT_52;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned char* zT_75;
    unsigned int zT_76;
    unsigned char zT_77;
    unsigned char zT_78;
    unsigned char* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    unsigned int zT_92;
    unsigned int zT_94;
    unsigned char zT_96;
    unsigned char* zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    unsigned char* zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned char zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    unsigned int p;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u es;
    zT_5 = 0;
    p = zT_5;
    zT_7 = 0;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = od.len;
    if ((unsigned char)(i < zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_14 = od.ptr;
    zT_15 = od.len;
    zT_16 = i < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[i];
    zT_18 = buf.ptr;
    zT_19 = buf.len;
    zT_20 = p < zT_19;
    if (!(zT_20)) { pal_trap(); }
    zT_18[p] = zT_17;
    zT_21 = 1;
    zT_22 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    p = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_31 = 47;
    zT_32 = buf.ptr;
    zT_33 = buf.len;
    zT_34 = p < zT_33;
    if (!(zT_34)) { pal_trap(); }
    zT_32[p] = zT_31;
    zT_35 = 1;
    zT_36 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    p = zT_36;
    zT_40 = 0;
    i = zT_40;
    zT_42 = ".z98dbg.";
    zT_44 = 8;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    es = zT_43;
    goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    goto z_bb_1;
    z_bb_5:
    zT_11 = p < (unsigned int)(510);
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_46 = stem.len;
    if ((unsigned char)(i < zT_46)) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_51 = stem.ptr;
    zT_52 = stem.len;
    zT_53 = i < zT_52;
    if (!(zT_53)) { pal_trap(); }
    zT_54 = zT_51[i];
    zT_55 = buf.ptr;
    zT_56 = buf.len;
    zT_57 = p < zT_56;
    if (!(zT_57)) { pal_trap(); }
    zT_55[p] = zT_54;
    zT_58 = 1;
    zT_59 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    p = zT_59;
    goto z_bb_11;
    z_bb_10:
    zT_68 = 0;
    i = zT_68;
    goto z_bb_15;
    z_bb_11:
    zT_63 = 1;
    zT_64 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    i = zT_64;
    goto z_bb_8;
    z_bb_12:
    zT_48 = p < (unsigned int)(510);
    goto z_bb_14;
    z_bb_13:
    zT_48 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_48) goto z_bb_9; else goto z_bb_10;
    z_bb_15:
    zT_70 = es.len;
    if ((unsigned char)(i < zT_70)) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_75 = es.ptr;
    zT_76 = es.len;
    zT_77 = i < zT_76;
    if (!(zT_77)) { pal_trap(); }
    zT_78 = zT_75[i];
    zT_79 = buf.ptr;
    zT_80 = buf.len;
    zT_81 = p < zT_80;
    if (!(zT_81)) { pal_trap(); }
    zT_79[p] = zT_78;
    zT_82 = 1;
    zT_83 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    p = zT_83;
    goto z_bb_18;
    z_bb_17:
    zT_92 = 0;
    i = zT_92;
    goto z_bb_22;
    z_bb_18:
    zT_87 = 1;
    zT_88 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    i = zT_88;
    goto z_bb_15;
    z_bb_19:
    zT_72 = p < (unsigned int)(511);
    goto z_bb_21;
    z_bb_20:
    zT_72 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_72) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_94 = ext.len;
    if ((unsigned char)(i < zT_94)) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    zT_99 = ext.ptr;
    zT_100 = ext.len;
    zT_101 = i < zT_100;
    if (!(zT_101)) { pal_trap(); }
    zT_102 = zT_99[i];
    zT_103 = buf.ptr;
    zT_104 = buf.len;
    zT_105 = p < zT_104;
    if (!(zT_105)) { pal_trap(); }
    zT_103[p] = zT_102;
    zT_106 = 1;
    zT_107 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_106)), 32u);
    zT_108 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_106)), 32u);
    zT_110 = zT_108 == (unsigned int)(0);
    if (!(zT_110)) { pal_trap(); }
    p = zT_107;
    goto z_bb_25;
    z_bb_24:
    return p;
    z_bb_25:
    zT_111 = 1;
    zT_112 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    i = zT_112;
    goto z_bb_22;
    z_bb_26:
    zT_96 = p < (unsigned int)(511);
    goto z_bb_28;
    z_bb_27:
    zT_96 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_96) goto z_bb_23; else goto z_bb_24;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler zT_14;
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_786E6CF2_EmissionClassificat zT_24;
    zT_21D3708C_U32ToU32Map zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    zT_D3EB6303_StringInterner* zT_36;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    zT_69057089_CompilerAlloc* zT_40;
    zT_CEC2984A_NameMangler zT_42;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_F49911A5_Opt_347 zT_44;
    zT_72C4E2ED_C89Emitter zT_46;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D3EB6303_StringInterner* zT_48;
    zT_CEC2984A_NameMangler* zT_49;
    zT_F85C5DED_DiagnosticCollector* zT_50;
    zT_9F514E82_SwitchCaseArrayList* zT_51;
    zT_B687BB96_U32ArrayList* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_3E40CD83_Sand* zT_54;
    zT_21D3708C_U32ToU32Map* zT_55;
    zT_786E6CF2_EmissionClassificat* zT_56;
    zT_1317DCD6_C89SpellPlan* zT_57;
    unsigned char zT_58;
    int zT_63;
    int zT_64;
    zT_69057089_CompilerAlloc* zT_65;
    zT_69057089_CompilerAlloc* zT_67;
    zT_C98AF326_CompilerCli zT_72;
    zT_72C4E2ED_C89Emitter zT_74;
    zT_072B53A6_ModuleRegistry* zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_80;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_072B53A6_ModuleRegistry* zT_83;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_85;
    unsigned int zT_87;
    zT_5AB29387_CompilerContext* zT_88;
    zT_E1A783EF_GlobalDeclArrayList* zT_90;
    zT_23133B1E_Slice_zT_54906056_M zT_92;
    zT_54906056_ModuleGlobalDecl* zT_94;
    unsigned int zT_96;
    zT_4065182A_ConstInitTable* zT_98;
    zT_B687BB96_U32ArrayList zT_99;
    unsigned int* zT_100;
    zT_B687BB96_U32ArrayList zT_101;
    unsigned int zT_102;
    zT_7E7544E4_LirStream* zT_103;
    zT_CA01C129_LirSlotArrayList zT_104;
    zT_E7714190_LirSlot* zT_105;
    zT_CA01C129_LirSlotArrayList zT_107;
    unsigned int zT_108;
    zT_69057089_CompilerAlloc* zT_109;
    zT_3E40CD83_Sand* zT_110;
    zT_C98AF326_CompilerCli zT_111;
    unsigned char zT_112;
    zT_DEDDFC41_DebugMapWriter* zT_113;
    zT_FFAA6C17_Opt_338 zT_114;
    zT_C615AE29_DebugSpanStore* zT_115;
    zT_ED9906A0_Opt_340 zT_116;
    zT_8B83E3B4_DebugSymbolList* zT_117;
    zT_EF9909C6_Opt_342 zT_118;
    zT_7E7544E4_LirStream* zT_119;
    zT_3E40CD83_Sand* zT_120;
    zT_69057089_CompilerAlloc* zT_122;
    unsigned char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    zT_3E40CD83_Sand* zT_129;
    zT_69057089_CompilerAlloc* zT_130;
    zT_21D3708C_U32ToU32Map zT_132;
    zT_3E40CD83_Sand* zT_134;
    unsigned int zT_135;
    zT_69057089_CompilerAlloc* zT_136;
    zT_CA01C129_LirSlotArrayList zT_138;
    zT_21D3708C_U32ToU32Map zT_140;
    zT_3E40CD83_Sand* zT_142;
    zT_69057089_CompilerAlloc* zT_143;
    zT_A4CE86B7_U64ToU32Map zT_145;
    unsigned int zT_147;
    zT_CA01C129_LirSlotArrayList zT_148;
    unsigned int zT_149;
    zT_7E7544E4_LirStream* zT_152;
    zT_E7714190_LirSlot zT_153;
    zT_3E40CD83_Sand* zT_154;
    zT_CA01C129_LirSlotArrayList zT_156;
    zT_E7714190_LirSlot* zT_157;
    zT_E7714190_LirSlot zT_158;
    zT_69057089_CompilerAlloc* zT_159;
    zT_BBC23664_LirFunction zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    zT_5D72FBF8_TempDeclArrayList zT_166;
    unsigned int zT_167;
    zT_5D72FBF8_TempDeclArrayList zT_170;
    zT_1937645B_TempDecl* zT_171;
    zT_1937645B_TempDecl zT_172;
    zT_21D3708C_U32ToU32Map* zT_173;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_A4CE86B7_U64ToU32Map* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned char zT_186;
    unsigned int zT_187;
    zT_338B7C76_TypeRegistry* zT_188;
    unsigned int zT_189;
    zT_21D3708C_U32ToU32Map* zT_192;
    zT_338B7C76_TypeRegistry* zT_193;
    zT_A4CE86B7_U64ToU32Map* zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_202;
    zT_CFE23D0A_LirParamArrayList zT_203;
    unsigned int zT_204;
    zT_CFE23D0A_LirParamArrayList zT_207;
    zT_8779209D_LirParam* zT_208;
    zT_8779209D_LirParam zT_209;
    zT_21D3708C_U32ToU32Map* zT_210;
    zT_338B7C76_TypeRegistry* zT_211;
    zT_A4CE86B7_U64ToU32Map* zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned char zT_223;
    unsigned int zT_225;
    zT_1CF28CA3_BasicBlockArrayList zT_226;
    unsigned int zT_227;
    zT_1CF28CA3_BasicBlockArrayList zT_230;
    zT_88A68B1A_BasicBlock* zT_231;
    zT_88A68B1A_BasicBlock zT_232;
    unsigned int zT_234;
    zT_DAE4631D_LirInstArrayList zT_235;
    unsigned int zT_236;
    zT_DAE4631D_LirInstArrayList zT_239;
    zT_6BA597BC_LirInst* zT_240;
    zT_6BA597BC_LirInst zT_241;
    unsigned int zT_243;
    unsigned char zT_245;
    unsigned int zT_247;
    zT_6BA597BC_LirInst zT_250;
    zT_BBC23664_LirFunction* zT_253;
    unsigned int zT_254;
    zT_3BFB1E70_CallDirectData zT_258;
    unsigned int zT_259;
    unsigned char zT_260;
    zT_6BA597BC_LirInst zT_263;
    zT_BBC23664_LirFunction* zT_266;
    unsigned int zT_267;
    zT_0624AC1B_TailCallData zT_271;
    unsigned int zT_272;
    unsigned char zT_273;
    zT_6BA597BC_LirInst zT_276;
    zT_6C58DB1B_anon_116953 zT_279;
    unsigned int zT_280;
    unsigned char zT_281;
    zT_6BA597BC_LirInst zT_284;
    zT_4E52D78E_anon_117135 zT_287;
    unsigned int zT_288;
    unsigned char zT_289;
    zT_6BA597BC_LirInst zT_292;
    zT_C04B3C3F_anon_117143 zT_295;
    unsigned int zT_296;
    unsigned char zT_297;
    unsigned char zT_300;
    zT_21D3708C_U32ToU32Map* zT_302;
    unsigned int zT_303;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned char zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned char zT_314;
    zT_6BA597BC_LirInst zT_318;
    unsigned char zT_320;
    unsigned int zT_321;
    unsigned int zT_324;
    zT_21D3708C_U32ToU32Map* zT_326;
    unsigned int zT_327;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned char zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned char zT_339;
    zT_6BA597BC_LirInst zT_343;
    unsigned char zT_345;
    zT_6BA597BC_LirInst zT_348;
    unsigned int zT_351;
    unsigned int zT_353;
    zT_6BA597BC_LirInst zT_356;
    zT_4E52D78E_anon_117135 zT_359;
    unsigned int zT_360;
    zT_4E52D78E_anon_117135 zT_362;
    unsigned int zT_363;
    zT_C04B3C3F_anon_117143 zT_365;
    unsigned int zT_366;
    zT_C04B3C3F_anon_117143 zT_368;
    unsigned int zT_369;
    unsigned int zT_371;
    unsigned int zT_373;
    zT_5D72FBF8_TempDeclArrayList zT_374;
    unsigned int zT_375;
    zT_5D72FBF8_TempDeclArrayList zT_378;
    zT_1937645B_TempDecl* zT_379;
    zT_1937645B_TempDecl zT_380;
    unsigned int zT_381;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned char zT_388;
    zT_338B7C76_TypeRegistry* zT_389;
    unsigned int zT_390;
    zT_338B7C76_TypeRegistry* zT_394;
    zT_D155D06D_Type* zT_395;
    unsigned int zT_396;
    zT_D155D06D_Type zT_397;
    unsigned int zT_398;
    unsigned char zT_401;
    unsigned int zT_402;
    zT_21D3708C_U32ToU32Map* zT_404;
    unsigned int zT_405;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned char zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    unsigned int zT_416;
    unsigned char zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned char zT_423;
    zT_072B53A6_ModuleRegistry* zT_425;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_427;
    unsigned int zT_429;
    zT_E1A783EF_GlobalDeclArrayList zT_430;
    unsigned int zT_431;
    zT_E1A783EF_GlobalDeclArrayList zT_434;
    zT_54906056_ModuleGlobalDecl* zT_435;
    zT_54906056_ModuleGlobalDecl zT_436;
    unsigned int zT_437;
    zT_338B7C76_TypeRegistry* zT_438;
    unsigned int zT_439;
    zT_338B7C76_TypeRegistry* zT_443;
    zT_D155D06D_Type* zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    zT_D155D06D_Type zT_447;
    unsigned int zT_448;
    unsigned char zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_21D3708C_U32ToU32Map* zT_455;
    zT_338B7C76_TypeRegistry* zT_456;
    zT_A4CE86B7_U64ToU32Map* zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned char zT_469;
    zT_3E40CD83_Sand* zT_471;
    unsigned int zT_472;
    zT_69057089_CompilerAlloc* zT_473;
    zT_21D3708C_U32ToU32Map zT_477;
    zT_21D3708C_U32ToU32Map* zT_478;
    unsigned char zT_485;
    unsigned char zT_488;
    unsigned int zT_490;
    unsigned int zT_492;
    zT_6E8D187B_ModuleEntry* zT_495;
    unsigned int zT_496;
    unsigned char zT_497;
    zT_6E8D187B_ModuleEntry zT_498;
    unsigned int zT_499;
    zT_21D3708C_U32ToU32Map* zT_500;
    unsigned int zT_501;
    zT_BAEE192E_Opt_10 zT_503;
    unsigned char zT_504;
    unsigned int zT_507;
    unsigned int zT_509;
    zT_6E8D187B_ModuleEntry* zT_512;
    unsigned int zT_513;
    unsigned char zT_514;
    zT_6E8D187B_ModuleEntry zT_515;
    unsigned int zT_516;
    zT_21D3708C_U32ToU32Map* zT_518;
    unsigned int zT_519;
    zT_BAEE192E_Opt_10 zT_521;
    unsigned char zT_522;
    zT_21D3708C_U32ToU32Map* zT_523;
    unsigned int zT_524;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned char zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned char zT_534;
    zT_BAEE192E_Opt_10 zT_535;
    unsigned char zT_536;
    zT_21D3708C_U32ToU32Map* zT_537;
    unsigned int zT_538;
    unsigned char zT_542;
    unsigned int zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned char zT_547;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned char zT_552;
    unsigned int zT_554;
    unsigned int zT_556;
    zT_6E8D187B_ModuleEntry* zT_558;
    unsigned int zT_559;
    unsigned char zT_560;
    zT_6E8D187B_ModuleEntry zT_561;
    unsigned int zT_562;
    zT_21D3708C_U32ToU32Map* zT_565;
    unsigned int zT_566;
    zT_6E8D187B_ModuleEntry* zT_568;
    unsigned int zT_569;
    unsigned char zT_570;
    zT_6E8D187B_ModuleEntry zT_571;
    zT_BAEE192E_Opt_10 zT_573;
    unsigned char zT_574;
    unsigned char zT_577;
    unsigned int zT_579;
    zT_E1A783EF_GlobalDeclArrayList zT_580;
    unsigned int zT_581;
    zT_E1A783EF_GlobalDeclArrayList zT_584;
    zT_54906056_ModuleGlobalDecl* zT_585;
    zT_54906056_ModuleGlobalDecl zT_586;
    unsigned int zT_587;
    zT_6E8D187B_ModuleEntry* zT_588;
    unsigned int zT_589;
    unsigned char zT_590;
    zT_6E8D187B_ModuleEntry zT_591;
    unsigned int zT_592;
    unsigned char zT_594;
    unsigned char zT_595;
    unsigned char zT_598;
    unsigned int zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned char zT_603;
    zT_21D3708C_U32ToU32Map* zT_606;
    unsigned int zT_607;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned char zT_615;
    zT_6E8D187B_ModuleEntry* zT_616;
    unsigned int zT_617;
    unsigned char zT_618;
    zT_6E8D187B_ModuleEntry zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned int zT_622;
    unsigned char zT_624;
    unsigned int zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned char zT_630;
    zT_C98AF326_CompilerCli zT_631;
    unsigned char zT_632;
    zT_C98AF326_CompilerCli zT_633;
    unsigned char zT_634;
    zT_72C4E2ED_C89Emitter* zT_636;
    int zT_639;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_641;
    zT_846744CC_Arr_unsigned_char_5 zT_643;
    zT_846744CC_Arr_unsigned_char_5 zT_645;
    zT_846744CC_Arr_unsigned_char_5 zT_647;
    unsigned char* zT_649;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_650;
    unsigned int zT_651;
    unsigned char* zT_653;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_654;
    unsigned int zT_655;
    unsigned char* zT_657;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_658;
    unsigned int zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_661;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_664;
    int zT_667;
    unsigned char* zT_668;
    unsigned int zT_669;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_670;
    zT_C98AF326_CompilerCli zT_671;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_672;
    unsigned int zT_673;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_676;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_677;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_678;
    int zT_681;
    unsigned char* zT_682;
    unsigned int zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_684;
    zT_C98AF326_CompilerCli zT_685;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_686;
    unsigned int zT_687;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_689;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_690;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_691;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_692;
    int zT_695;
    unsigned char* zT_696;
    unsigned int zT_697;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_698;
    zT_C98AF326_CompilerCli zT_699;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_700;
    unsigned int zT_701;
    zT_DEDDFC41_DebugMapWriter* zT_702;
    zT_3E40CD83_Sand* zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_706;
    zT_69057089_CompilerAlloc* zT_708;
    int zT_712;
    unsigned char* zT_713;
    unsigned int zT_714;
    unsigned char zT_715;
    unsigned char zT_716;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_717;
    int zT_720;
    unsigned char* zT_721;
    unsigned int zT_722;
    unsigned char zT_723;
    unsigned char zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_725;
    int zT_728;
    unsigned char* zT_729;
    unsigned int zT_730;
    unsigned char zT_731;
    unsigned char zT_732;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_733;
    zT_1317DCD6_C89SpellPlan zT_735;
    unsigned int* zT_736;
    zT_846744CC_Arr_unsigned_char_5 zT_738;
    unsigned int zT_740;
    zT_C98AF326_CompilerCli zT_742;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_743;
    zT_72C4E2ED_C89Emitter* zT_744;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_745;
    unsigned int zT_748;
    unsigned int zT_750;
    unsigned char zT_752;
    unsigned char* zT_755;
    unsigned int zT_756;
    unsigned char zT_757;
    unsigned char zT_758;
    unsigned char zT_760;
    int zT_761;
    unsigned int zT_762;
    unsigned int zT_763;
    unsigned int zT_764;
    unsigned char zT_766;
    int zT_767;
    unsigned int zT_768;
    unsigned int zT_769;
    unsigned int zT_770;
    unsigned char zT_772;
    unsigned char zT_773;
    unsigned char zT_775;
    int zT_776;
    unsigned int zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    unsigned char zT_781;
    unsigned char* zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    unsigned int zT_785;
    unsigned int zT_787;
    unsigned int zT_789;
    unsigned char zT_791;
    unsigned char* zT_794;
    unsigned int zT_795;
    unsigned char zT_796;
    unsigned char zT_797;
    unsigned char zT_799;
    int zT_800;
    unsigned int zT_801;
    unsigned int zT_802;
    unsigned int zT_803;
    unsigned char zT_805;
    int zT_806;
    unsigned int zT_807;
    unsigned int zT_808;
    unsigned int zT_809;
    unsigned char zT_811;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_813;
    int zT_817;
    unsigned char* zT_818;
    unsigned int zT_819;
    unsigned char zT_820;
    unsigned char zT_821;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_822;
    unsigned int zT_824;
    unsigned char* zT_828;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_829;
    unsigned int zT_830;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_831;
    zT_63BE4FF5_BufferedWriter zT_835;
    unsigned int zT_836;
    zT_63BE4FF5_BufferedWriter zT_837;
    zT_72C4E2ED_C89Emitter* zT_838;
    zT_338B7C76_TypeRegistry* zT_839;
    unsigned int* zT_840;
    zT_63BE4FF5_BufferedWriter* zT_843;
    zT_72C4E2ED_C89Emitter* zT_844;
    unsigned int zT_846;
    zT_072B53A6_ModuleRegistry* zT_848;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_850;
    zT_CA01C129_LirSlotArrayList zT_853;
    unsigned int zT_854;
    int zT_855;
    zT_3E40CD83_Sand* zT_858;
    unsigned int zT_859;
    zT_69057089_CompilerAlloc* zT_861;
    unsigned int zT_863;
    unsigned int zT_865;
    unsigned int zT_866;
    unsigned int zT_867;
    unsigned char zT_869;
    zT_FDFD82FD_EU_362 zT_871;
    unsigned char zT_872;
    unsigned char* zT_873;
    unsigned int* zT_875;
    zT_3E40CD83_Sand* zT_877;
    unsigned int zT_878;
    zT_69057089_CompilerAlloc* zT_880;
    unsigned int zT_882;
    unsigned int zT_884;
    unsigned int zT_885;
    unsigned int zT_886;
    unsigned char zT_888;
    zT_FDFD82FD_EU_362 zT_890;
    unsigned char zT_891;
    unsigned char* zT_892;
    unsigned int* zT_894;
    unsigned int zT_896;
    unsigned int zT_898;
    unsigned int zT_900;
    int zT_901;
    unsigned int zT_902;
    unsigned int zT_903;
    unsigned int zT_904;
    unsigned char zT_906;
    unsigned int zT_908;
    zT_CA01C129_LirSlotArrayList zT_911;
    zT_E7714190_LirSlot* zT_912;
    zT_E7714190_LirSlot zT_913;
    unsigned int zT_914;
    unsigned int zT_917;
    unsigned int zT_919;
    unsigned int zT_920;
    unsigned int zT_921;
    unsigned int zT_922;
    unsigned int zT_923;
    unsigned char zT_925;
    unsigned int zT_926;
    int zT_927;
    unsigned int zT_928;
    unsigned int zT_929;
    unsigned int zT_930;
    unsigned char zT_932;
    unsigned int zT_934;
    unsigned int zT_935;
    unsigned int zT_937;
    unsigned int zT_939;
    unsigned int zT_940;
    unsigned int zT_941;
    unsigned char zT_943;
    int zT_944;
    unsigned int zT_945;
    unsigned int zT_946;
    unsigned int zT_947;
    unsigned char zT_949;
    zT_3E40CD83_Sand* zT_951;
    unsigned int zT_952;
    zT_69057089_CompilerAlloc* zT_954;
    unsigned int zT_956;
    unsigned int zT_957;
    unsigned int zT_958;
    unsigned char zT_960;
    zT_FDFD82FD_EU_362 zT_962;
    unsigned char zT_963;
    unsigned char* zT_964;
    zT_E7714190_LirSlot* zT_966;
    unsigned int zT_967;
    zT_CA01C129_LirSlotArrayList zT_970;
    zT_E7714190_LirSlot* zT_971;
    zT_E7714190_LirSlot zT_972;
    unsigned int zT_974;
    unsigned int zT_977;
    unsigned int zT_980;
    unsigned int zT_981;
    unsigned int zT_982;
    unsigned int zT_983;
    unsigned int zT_984;
    unsigned int zT_985;
    unsigned char zT_987;
    unsigned int zT_988;
    int zT_989;
    unsigned int zT_990;
    unsigned int zT_991;
    unsigned int zT_992;
    unsigned char zT_994;
    zT_CA01C129_LirSlotArrayList* zT_995;
    zT_CA01C129_LirSlotArrayList* zT_997;
    unsigned int zT_999;
    unsigned int zT_1001;
    unsigned int zT_1003;
    zT_6E8D187B_ModuleEntry* zT_1006;
    unsigned int zT_1007;
    unsigned char zT_1008;
    zT_6E8D187B_ModuleEntry zT_1009;
    zT_CA01C129_LirSlotArrayList zT_1011;
    unsigned int zT_1012;
    unsigned char zT_1014;
    zT_CA01C129_LirSlotArrayList zT_1015;
    zT_E7714190_LirSlot* zT_1016;
    zT_E7714190_LirSlot zT_1017;
    unsigned int zT_1018;
    unsigned int zT_1019;
    unsigned int zT_1021;
    unsigned int zT_1022;
    unsigned int zT_1023;
    unsigned char zT_1025;
    zT_21D3708C_U32ToU32Map* zT_1026;
    unsigned int zT_1027;
    zT_BAEE192E_Opt_10 zT_1030;
    unsigned char zT_1031;
    unsigned int zT_1033;
    unsigned int zT_1034;
    unsigned char zT_1036;
    zT_72C4E2ED_C89Emitter* zT_1038;
    unsigned int zT_1039;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1042;
    unsigned int zT_1044;
    unsigned int zT_1045;
    unsigned int zT_1046;
    unsigned int zT_1047;
    unsigned char zT_1049;
    unsigned int zT_1051;
    unsigned int zT_1052;
    unsigned int zT_1053;
    unsigned char zT_1055;
    unsigned int zT_1056;
    unsigned int zT_1057;
    unsigned int zT_1058;
    unsigned char zT_1060;
    unsigned char* zT_1064;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1065;
    unsigned int zT_1066;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1067;
    unsigned int zT_1071;
    unsigned int zT_1073;
    unsigned int zT_1075;
    unsigned char zT_1077;
    unsigned char* zT_1080;
    unsigned int zT_1081;
    unsigned char zT_1082;
    unsigned char zT_1083;
    unsigned char zT_1085;
    int zT_1086;
    unsigned int zT_1087;
    unsigned int zT_1088;
    unsigned int zT_1089;
    unsigned char zT_1091;
    int zT_1092;
    unsigned int zT_1093;
    unsigned int zT_1094;
    unsigned int zT_1095;
    unsigned char zT_1097;
    unsigned char zT_1098;
    unsigned char zT_1100;
    int zT_1101;
    unsigned int zT_1102;
    unsigned int zT_1103;
    unsigned int zT_1104;
    unsigned char zT_1106;
    unsigned int zT_1108;
    unsigned int zT_1110;
    unsigned char zT_1112;
    unsigned char* zT_1115;
    unsigned int zT_1116;
    unsigned char zT_1117;
    unsigned char zT_1118;
    unsigned char zT_1120;
    int zT_1121;
    unsigned int zT_1122;
    unsigned int zT_1123;
    unsigned int zT_1124;
    unsigned char zT_1126;
    int zT_1127;
    unsigned int zT_1128;
    unsigned int zT_1129;
    unsigned int zT_1130;
    unsigned char zT_1132;
    unsigned char* zT_1134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1135;
    unsigned int zT_1136;
    unsigned int zT_1138;
    unsigned int zT_1140;
    unsigned char zT_1142;
    unsigned char* zT_1145;
    unsigned int zT_1146;
    unsigned char zT_1147;
    unsigned char zT_1148;
    unsigned char zT_1150;
    int zT_1151;
    unsigned int zT_1152;
    unsigned int zT_1153;
    unsigned int zT_1154;
    unsigned char zT_1156;
    int zT_1157;
    unsigned int zT_1158;
    unsigned int zT_1159;
    unsigned int zT_1160;
    unsigned char zT_1162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1164;
    int zT_1168;
    unsigned char* zT_1169;
    unsigned int zT_1170;
    unsigned char zT_1171;
    unsigned char zT_1172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1173;
    unsigned int zT_1175;
    unsigned char* zT_1179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1180;
    unsigned int zT_1181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1182;
    zT_63BE4FF5_BufferedWriter zT_1186;
    unsigned int zT_1187;
    zT_63BE4FF5_BufferedWriter zT_1188;
    unsigned int zT_1190;
    unsigned int zT_1191;
    unsigned int zT_1193;
    unsigned int zT_1194;
    unsigned int zT_1195;
    unsigned int zT_1196;
    unsigned char zT_1198;
    zT_072B53A6_ModuleRegistry* zT_1200;
    unsigned int* zT_1201;
    unsigned int* zT_1202;
    unsigned int zT_1203;
    unsigned char zT_1204;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1205;
    zT_B687BB96_U32ArrayList zT_1207;
    unsigned int* zT_1208;
    zT_B687BB96_U32ArrayList zT_1209;
    unsigned int zT_1210;
    int zT_1211;
    unsigned int* zT_1212;
    unsigned int zT_1213;
    unsigned char zT_1214;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1215;
    zT_3E40CD83_Sand* zT_1217;
    unsigned int zT_1218;
    zT_69057089_CompilerAlloc* zT_1220;
    unsigned int zT_1222;
    unsigned int zT_1224;
    unsigned int zT_1225;
    unsigned int zT_1226;
    unsigned char zT_1228;
    zT_FDFD82FD_EU_362 zT_1230;
    unsigned char zT_1231;
    unsigned char* zT_1232;
    unsigned int* zT_1235;
    unsigned int zT_1237;
    unsigned int zT_1239;
    unsigned int zT_1241;
    unsigned int* zT_1244;
    unsigned int zT_1245;
    unsigned char zT_1246;
    unsigned int zT_1247;
    unsigned int zT_1248;
    zT_21D3708C_U32ToU32Map* zT_1250;
    unsigned int zT_1251;
    zT_BAEE192E_Opt_10 zT_1253;
    unsigned char zT_1254;
    unsigned char zT_1257;
    unsigned int zT_1259;
    unsigned int zT_1261;
    unsigned char zT_1263;
    unsigned int zT_1264;
    unsigned int zT_1265;
    unsigned int zT_1266;
    unsigned char zT_1268;
    unsigned int zT_1271;
    unsigned int zT_1272;
    unsigned int zT_1273;
    unsigned char zT_1275;
    unsigned int zT_1276;
    unsigned int zT_1277;
    unsigned int zT_1278;
    unsigned char zT_1280;
    unsigned int zT_1282;
    unsigned int zT_1284;
    zT_6E8D187B_ModuleEntry* zT_1287;
    unsigned int zT_1288;
    unsigned char zT_1289;
    zT_6E8D187B_ModuleEntry zT_1290;
    unsigned int zT_1291;
    unsigned int zT_1292;
    zT_21D3708C_U32ToU32Map* zT_1294;
    unsigned int zT_1295;
    zT_BAEE192E_Opt_10 zT_1297;
    unsigned char zT_1298;
    zT_21D3708C_U32ToU32Map* zT_1300;
    unsigned int zT_1301;
    unsigned int zT_1303;
    unsigned int zT_1304;
    unsigned int zT_1305;
    unsigned int zT_1306;
    unsigned char zT_1308;
    unsigned int zT_1309;
    unsigned int zT_1310;
    unsigned char zT_1312;
    zT_BAEE192E_Opt_10 zT_1313;
    unsigned char zT_1314;
    unsigned char zT_1317;
    unsigned int zT_1319;
    unsigned int zT_1321;
    unsigned char zT_1323;
    unsigned int zT_1324;
    unsigned int zT_1325;
    unsigned int zT_1326;
    unsigned char zT_1328;
    unsigned int zT_1331;
    unsigned int zT_1332;
    unsigned int zT_1333;
    unsigned char zT_1335;
    unsigned int zT_1336;
    unsigned int zT_1337;
    unsigned int zT_1338;
    unsigned char zT_1340;
    int zT_1342;
    unsigned int* zT_1343;
    unsigned int zT_1344;
    unsigned char zT_1345;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1346;
    zT_72C4E2ED_C89Emitter* zT_1347;
    unsigned int zT_1348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1349;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1350;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1351;
    unsigned int* zT_1352;
    zT_63BE4FF5_BufferedWriter* zT_1355;
    zT_72C4E2ED_C89Emitter* zT_1356;
    unsigned int zT_1358;
    unsigned char* zT_1360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1361;
    unsigned int zT_1362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1363;
    zT_846744CC_Arr_unsigned_char_5 zT_1365;
    unsigned int zT_1367;
    unsigned int zT_1369;
    unsigned int zT_1371;
    unsigned char zT_1373;
    unsigned char* zT_1376;
    unsigned int zT_1377;
    unsigned char zT_1378;
    unsigned char zT_1379;
    unsigned char zT_1381;
    int zT_1382;
    unsigned int zT_1383;
    unsigned int zT_1384;
    unsigned int zT_1385;
    unsigned char zT_1387;
    int zT_1388;
    unsigned int zT_1389;
    unsigned int zT_1390;
    unsigned int zT_1391;
    unsigned char zT_1393;
    unsigned char zT_1394;
    unsigned char zT_1396;
    int zT_1397;
    unsigned int zT_1398;
    unsigned int zT_1399;
    unsigned int zT_1400;
    unsigned char zT_1402;
    unsigned int zT_1404;
    unsigned int zT_1406;
    unsigned char zT_1408;
    unsigned char* zT_1411;
    unsigned int zT_1412;
    unsigned char zT_1413;
    unsigned char zT_1414;
    unsigned char zT_1416;
    int zT_1417;
    unsigned int zT_1418;
    unsigned int zT_1419;
    unsigned int zT_1420;
    unsigned char zT_1422;
    int zT_1423;
    unsigned int zT_1424;
    unsigned int zT_1425;
    unsigned int zT_1426;
    unsigned char zT_1428;
    unsigned char* zT_1430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1431;
    unsigned int zT_1432;
    unsigned int zT_1434;
    unsigned int zT_1436;
    unsigned char zT_1438;
    unsigned char* zT_1441;
    unsigned int zT_1442;
    unsigned char zT_1443;
    unsigned char zT_1444;
    unsigned char zT_1446;
    int zT_1447;
    unsigned int zT_1448;
    unsigned int zT_1449;
    unsigned int zT_1450;
    unsigned char zT_1452;
    int zT_1453;
    unsigned int zT_1454;
    unsigned int zT_1455;
    unsigned int zT_1456;
    unsigned char zT_1458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1460;
    int zT_1464;
    unsigned char* zT_1465;
    unsigned int zT_1466;
    unsigned char zT_1467;
    unsigned char zT_1468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1469;
    unsigned int zT_1471;
    unsigned char* zT_1475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1476;
    unsigned int zT_1477;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1478;
    zT_63BE4FF5_BufferedWriter zT_1482;
    unsigned int zT_1483;
    zT_63BE4FF5_BufferedWriter zT_1484;
    zT_C98AF326_CompilerCli zT_1485;
    unsigned char zT_1486;
    zT_227EDE07_SourceManager* zT_1488;
    unsigned int zT_1489;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1492;
    zT_DEDDFC41_DebugMapWriter* zT_1493;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1494;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1495;
    zT_72C4E2ED_C89Emitter* zT_1497;
    unsigned int zT_1498;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1499;
    zT_C98AF326_CompilerCli zT_1502;
    unsigned char zT_1503;
    zT_DEDDFC41_DebugMapWriter* zT_1504;
    zT_63BE4FF5_BufferedWriter* zT_1506;
    zT_72C4E2ED_C89Emitter* zT_1507;
    unsigned int zT_1509;
    unsigned char* zT_1511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1512;
    unsigned int zT_1513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1514;
    int zT_1515;
    unsigned int zT_1516;
    unsigned int zT_1517;
    unsigned int zT_1518;
    unsigned char zT_1520;
    zT_C98AF326_CompilerCli zT_1521;
    unsigned char zT_1522;
    zT_DEDDFC41_DebugMapWriter* zT_1523;
    zT_3E40CD83_Sand* zT_1524;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_1525;
    zT_227EDE07_SourceManager* zT_1526;
    zT_CEC2984A_NameMangler* zT_1527;
    zT_D3EB6303_StringInterner* zT_1528;
    zT_072B53A6_ModuleRegistry* zT_1529;
    zT_338B7C76_TypeRegistry* zT_1530;
    zT_69057089_CompilerAlloc* zT_1532;
    zT_8B83E3B4_DebugSymbolList zT_1534;
    zT_1001656C_DebugSymbol* zT_1535;
    zT_8B83E3B4_DebugSymbolList zT_1536;
    unsigned int zT_1537;
    int zT_1538;
    zT_1001656C_DebugSymbol* zT_1539;
    unsigned int zT_1540;
    unsigned char zT_1541;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_1542;
    zT_C615AE29_DebugSpanStore* zT_1548;
    zT_72C4E2ED_C89Emitter* zT_1550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1551;
    unsigned char zT_1552;
    zT_074080EA_WinProfile zT_1553;
    zT_C98AF326_CompilerCli zT_1555;
    zT_C98AF326_CompilerCli zT_1557;
    zT_7E7544E4_LirStream* zT_1559;
    zT_6B0A7D14_AstStore* zT_1561;
    zT_63BE4FF5_BufferedWriter zT_1564;
    zT_63BE4FF5_BufferedWriter zT_1565;
    zT_63BE4FF5_BufferedWriter* zT_1566;
    zT_63BE4FF5_BufferedWriter* zT_1568;
    zT_072B53A6_ModuleRegistry* zT_1571;
    zT_3E40CD83_Sand* zT_1572;
    zT_69057089_CompilerAlloc* zT_1574;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1576;
    zT_72C4E2ED_C89Emitter* zT_1577;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1578;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1579;
    unsigned char* zT_1582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1583;
    unsigned int zT_1584;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1585;
    zT_63BE4FF5_BufferedWriter* zT_1586;
    zT_72C4E2ED_C89Emitter* zT_1587;
    zT_7E7544E4_LirStream* zT_1589;
    zT_6B0A7D14_AstStore* zT_1591;
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_132, (unsigned int)sizeof zT_132);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_258, (unsigned int)sizeof zT_258);
    zig_poison_fill((void*)&zT_271, (unsigned int)sizeof zT_271);
    zig_poison_fill((void*)&zT_427, (unsigned int)sizeof zT_427);
    zig_poison_fill((void*)&zT_477, (unsigned int)sizeof zT_477);
    zig_poison_fill((void*)&zT_503, (unsigned int)sizeof zT_503);
    zig_poison_fill((void*)&zT_521, (unsigned int)sizeof zT_521);
    zig_poison_fill((void*)&zT_535, (unsigned int)sizeof zT_535);
    zig_poison_fill((void*)&zT_573, (unsigned int)sizeof zT_573);
    zig_poison_fill((void*)&zT_641, (unsigned int)sizeof zT_641);
    zig_poison_fill((void*)&zT_673, (unsigned int)sizeof zT_673);
    zig_poison_fill((void*)&zT_687, (unsigned int)sizeof zT_687);
    zig_poison_fill((void*)&zT_701, (unsigned int)sizeof zT_701);
    zig_poison_fill((void*)&zT_824, (unsigned int)sizeof zT_824);
    zig_poison_fill((void*)&zT_837, (unsigned int)sizeof zT_837);
    zig_poison_fill((void*)&zT_850, (unsigned int)sizeof zT_850);
    zig_poison_fill((void*)&zT_871, (unsigned int)sizeof zT_871);
    zig_poison_fill((void*)&zT_890, (unsigned int)sizeof zT_890);
    zig_poison_fill((void*)&zT_962, (unsigned int)sizeof zT_962);
    zig_poison_fill((void*)&zT_1030, (unsigned int)sizeof zT_1030);
    zig_poison_fill((void*)&zT_1042, (unsigned int)sizeof zT_1042);
    zig_poison_fill((void*)&zT_1175, (unsigned int)sizeof zT_1175);
    zig_poison_fill((void*)&zT_1188, (unsigned int)sizeof zT_1188);
    zig_poison_fill((void*)&zT_1230, (unsigned int)sizeof zT_1230);
    zig_poison_fill((void*)&zT_1253, (unsigned int)sizeof zT_1253);
    zig_poison_fill((void*)&zT_1297, (unsigned int)sizeof zT_1297);
    zig_poison_fill((void*)&zT_1313, (unsigned int)sizeof zT_1313);
    zig_poison_fill((void*)&zT_1471, (unsigned int)sizeof zT_1471);
    zig_poison_fill((void*)&zT_1484, (unsigned int)sizeof zT_1484);
    zig_poison_fill((void*)&zT_1492, (unsigned int)sizeof zT_1492);
    zig_poison_fill((void*)&zT_1565, (unsigned int)sizeof zT_1565);
    zig_poison_fill((void*)&zT_1576, (unsigned int)sizeof zT_1576);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int gt_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int ri_i;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_root_stem;
    zT_846744CC_Arr_unsigned_char_5 dbg_p1;
    zT_846744CC_Arr_unsigned_char_5 dbg_p2;
    zT_846744CC_Arr_unsigned_char_5 dbg_p3;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e2;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e3;
    unsigned int dbg_n1;
    unsigned int dbg_n2;
    unsigned int dbg_n3;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_src_file;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_20 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    zT_24 = ctx->emission_classif;
    zT_25 = zT_24.pointer_only_map;
    zT_26 = zT_25.count;
    zT_27 = zig_wrap_add_u(((zu64)(zT_20)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(zT_20)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_31 = 32;
    zT_32 = zig_wrap_add_u(((zu64)(zT_27)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(zT_27)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    mangler_hint = zT_32;
    zT_36 = ctx->interner;
    zT_40 = ctx->alloc;
    zT_37 = &zT_40->emission;
    zT_38 = mangler_hint;
    zT_42 = zF_27DA3900_nameManglerInit(zT_36, zT_37, zT_38);
    mangler = zT_42;
    zT_43 = &ctx->exported;
    zT_44.has_value = 1;
    zT_44.value = zT_43;
    mangler.exported = zT_44;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    emitter = zT_46;
    zT_47 = ctx->typereg;
    zT_48 = ctx->interner;
    zT_49 = (zT_CEC2984A_NameMangler*)&mangler;
    zT_50 = ctx->diag;
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zT_51 = (zT_9F514E82_SwitchCaseArrayList*)zT_63;
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zT_52 = (zT_B687BB96_U32ArrayList*)zT_64;
    zT_65 = ctx->alloc;
    zT_53 = &zT_65->scratch;
    zT_67 = ctx->alloc;
    zT_54 = &zT_67->emission;
    zT_55 = &ctx->error_code_registry;
    zT_56 = &ctx->emission_classif;
    zT_57 = &ctx->spell_plan;
    zT_72 = ctx->cli;
    zT_58 = zT_72.safe_checks;
    zT_74 = zF_63D58A2B_c89EmitterInit(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58);
    emitter = zT_74;
    zT_75 = ctx->module_reg;
    emitter.module_reg = zT_75;
    zT_77 = "std_fmt.zig";
    zT_79 = 11;
    zT_78.ptr = (unsigned char*)zT_77;
    zT_78.len = zT_79;
    c89_fmt_base = zT_78;
    zT_83 = ctx->module_reg;
    zT_85 = zF_3452C137_moduleRegistryGetMo(zT_83);
    zT_80 = zT_85;
    zT_81 = ctx->interner;
    zT_82 = c89_fmt_base;
    zT_87 = zF_D27A4A01_moduleIdForBasename(zT_80, zT_81, zT_82);
    emitter.std_fmt_module_id = zT_87;
    zT_88 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_88);
    zT_90 = &ctx->global_decls;
    zT_92 = zF_6ACCE52D_globalDeclArrayList(zT_90);
    gd_slice = zT_92;
    zT_94 = gd_slice.ptr;
    emitter.global_decls = zT_94;
    zT_96 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_96);
    zT_98 = &ctx->const_inits;
    emitter.const_inits = zT_98;
    zT_99 = ctx->module_init_order;
    zT_100 = zT_99.items;
    emitter.module_init_order = zT_100;
    zT_101 = ctx->module_init_order;
    zT_102 = zT_101.len;
    emitter.module_init_order_len = zT_102;
    zT_103 = &ctx->lir_stream;
    emitter.spill = zT_103;
    zT_104 = ctx->lir_slots;
    zT_105 = zT_104.items;
    emitter.fn_slots = zT_105;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_107 = ctx->lir_slots;
    zT_108 = zT_107.len;
    emitter.fn_slots_len = zT_108;
    zT_109 = ctx->alloc;
    zT_110 = &zT_109->lir_read;
    emitter.spill_arena = zT_110;
    zT_111 = ctx->cli;
    zT_112 = zT_111.debug;
    if (zT_112) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = &ctx->debug_map;
    zT_114.has_value = 1;
    zT_114.value = zT_113;
    emitter.debug_map = zT_114;
    zT_115 = &ctx->debug_spans;
    zT_116.has_value = 1;
    zT_116.value = zT_115;
    emitter.debug_store = zT_116;
    zT_117 = &ctx->debug_symbols;
    zT_118.has_value = 1;
    zT_118.value = zT_117;
    emitter.debug_symbols = zT_118;
    goto z_bb_7;
    z_bb_7:
    zT_119 = &ctx->lir_stream;
    zT_122 = ctx->alloc;
    zT_120 = &zT_122->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_119, zT_120);
    zT_125 = "output";
    zT_127 = 6;
    zT_126.ptr = (unsigned char*)zT_125;
    zT_126.len = zT_127;
    module_name = zT_126;
    zT_130 = ctx->alloc;
    zT_129 = &zT_130->emission;
    zT_132 = zF_58BDA2DE_u32ToU32MapInit(zT_129);
    ts_ref_set = zT_132;
    zT_136 = ctx->alloc;
    zT_134 = &zT_136->emission;
    zT_138 = ctx->lir_slots;
    zT_135 = zT_138.len;
    zT_140 = zF_619D56E6_u32ToU32MapInitCap(zT_134, zT_135);
    ref_edges = zT_140;
    zT_143 = ctx->alloc;
    zT_142 = &zT_143->emission;
    zT_145 = zF_986226E1_u64ToU32MapInit(zT_142);
    type_visited = zT_145;
    zT_147 = 0;
    ts_fi = zT_147;
    goto z_bb_8;
    z_bb_8:
    zT_148 = ctx->lir_slots;
    zT_149 = zT_148.len;
    if ((unsigned char)(ts_fi < zT_149)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_152 = &ctx->lir_stream;
    zT_156 = ctx->lir_slots;
    zT_157 = zT_156.items;
    zT_158 = zT_157[ts_fi];
    zT_153 = zT_158;
    zT_159 = ctx->alloc;
    zT_154 = &zT_159->lir_read;
    zT_161 = zF_1B7118E0_lirStreamReadFuncti(zT_152, zT_153, zT_154);
    ts_fn = zT_161;
    zT_163 = ts_fn.module_id;
    ts_src = zT_163;
    zT_165 = 0;
    ts_tti = zT_165;
    goto z_bb_12;
    z_bb_10:
    emitter.ts_ref_set = ts_ref_set;
    zT_425 = ctx->module_reg;
    zT_427 = zF_3452C137_moduleRegistryGetMo(zT_425);
    ri_mods = zT_427;
    zT_429 = 0;
    gt_i = zT_429;
    goto z_bb_77;
    z_bb_11:
    zT_419 = 1;
    zT_420 = zig_wrap_add_u(((zu64)(ts_fi)), ((zu64)(zT_419)), 32u);
    zT_421 = zig_overflow_flag_add_u(((zu64)(ts_fi)), ((zu64)(zT_419)), 32u);
    zT_423 = zT_421 == (unsigned int)(0);
    if (!(zT_423)) { pal_trap(); }
    ts_fi = zT_420;
    goto z_bb_8;
    z_bb_12:
    zT_166 = ts_fn.hoisted_temps;
    zT_167 = zT_166.len;
    if ((unsigned char)(ts_tti < zT_167)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_170 = ts_fn.hoisted_temps;
    zT_171 = zT_170.items;
    zT_172 = zT_171[ts_tti];
    ts_hty = zT_172;
    zT_173 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_174 = ctx->typereg;
    zT_175 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_176 = ts_src;
    zT_177 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_173, zT_174, zT_175, zT_176, zT_177);
    goto z_bb_15;
    z_bb_14:
    zT_187 = ts_fn.return_type;
    zT_188 = ctx->typereg;
    zT_189 = zT_188->types_len;
    if ((unsigned char)(zT_187 < (unsigned int)((unsigned int)zT_189))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_182 = 1;
    zT_183 = zig_wrap_add_u(((zu64)(ts_tti)), ((zu64)(zT_182)), 32u);
    zT_184 = zig_overflow_flag_add_u(((zu64)(ts_tti)), ((zu64)(zT_182)), 32u);
    zT_186 = zT_184 == (unsigned int)(0);
    if (!(zT_186)) { pal_trap(); }
    ts_tti = zT_183;
    goto z_bb_12;
    z_bb_16:
    zT_192 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_193 = ctx->typereg;
    zT_194 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_195 = ts_src;
    zT_196 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_192, zT_193, zT_194, zT_195, zT_196);
    goto z_bb_17;
    z_bb_17:
    zT_202 = 0;
    ts_pi = zT_202;
    goto z_bb_18;
    z_bb_18:
    zT_203 = ts_fn.params;
    zT_204 = zT_203.len;
    if ((unsigned char)(ts_pi < zT_204)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_207 = ts_fn.params;
    zT_208 = zT_207.items;
    zT_209 = zT_208[ts_pi];
    ts_pt = zT_209;
    zT_210 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_211 = ctx->typereg;
    zT_212 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_213 = ts_src;
    zT_214 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_210, zT_211, zT_212, zT_213, zT_214);
    goto z_bb_21;
    z_bb_20:
    zT_225 = 0;
    ts_bi = zT_225;
    goto z_bb_22;
    z_bb_21:
    zT_219 = 1;
    zT_220 = zig_wrap_add_u(((zu64)(ts_pi)), ((zu64)(zT_219)), 32u);
    zT_221 = zig_overflow_flag_add_u(((zu64)(ts_pi)), ((zu64)(zT_219)), 32u);
    zT_223 = zT_221 == (unsigned int)(0);
    if (!(zT_223)) { pal_trap(); }
    ts_pi = zT_220;
    goto z_bb_18;
    z_bb_22:
    zT_226 = ts_fn.blocks;
    zT_227 = zT_226.len;
    if ((unsigned char)(ts_bi < zT_227)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_230 = ts_fn.blocks;
    zT_231 = zT_230.items;
    zT_232 = zT_231[ts_bi];
    ts_blk = zT_232;
    zT_234 = 0;
    ts_ii = zT_234;
    goto z_bb_26;
    z_bb_24:
    goto z_bb_11;
    z_bb_25:
    zT_414 = 1;
    zT_415 = zig_wrap_add_u(((zu64)(ts_bi)), ((zu64)(zT_414)), 32u);
    zT_416 = zig_overflow_flag_add_u(((zu64)(ts_bi)), ((zu64)(zT_414)), 32u);
    zT_418 = zT_416 == (unsigned int)(0);
    if (!(zT_418)) { pal_trap(); }
    ts_bi = zT_415;
    goto z_bb_22;
    z_bb_26:
    zT_235 = ts_blk.insts;
    zT_236 = zT_235.len;
    if ((unsigned char)(ts_ii < zT_236)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_239 = ts_blk.insts;
    zT_240 = zT_239.items;
    zT_241 = zT_240[ts_ii];
    ts_inst = zT_241;
    zT_243 = ts_inst.tag;
    ts_tg = zT_243;
    zT_245 = 0;
    ts_edge_has = zT_245;
    zT_247 = 0;
    ts_edge_dst = zT_247;
    zT_250.tag = 23;
    if ((unsigned char)(ts_tg == zT_250.tag)) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_409 = 1;
    zT_410 = zig_wrap_add_u(((zu64)(ts_ii)), ((zu64)(zT_409)), 32u);
    zT_411 = zig_overflow_flag_add_u(((zu64)(ts_ii)), ((zu64)(zT_409)), 32u);
    zT_413 = zT_411 == (unsigned int)(0);
    if (!(zT_413)) { pal_trap(); }
    ts_ii = zT_410;
    goto z_bb_26;
    z_bb_30:
    zT_253 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_254 = ts_inst.payload.jump._0;
    zT_258 = zF_75DE985C_lirSideGetCallDirec(zT_253, zT_254);
    ts_cd = zT_258;
    zT_259 = ts_cd.module_id;
    ts_edge_dst = zT_259;
    zT_260 = 1;
    ts_edge_has = zT_260;
    goto z_bb_31;
    z_bb_31:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_32:
    zT_263.tag = 27;
    if ((unsigned char)(ts_tg == zT_263.tag)) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_266 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_267 = ts_inst.payload.jump._0;
    zT_271 = zF_1AB3807F_lirSideGetTailCall(zT_266, zT_267);
    ts_tc = zT_271;
    zT_272 = ts_tc.module_id;
    ts_edge_dst = zT_272;
    zT_273 = 1;
    ts_edge_has = zT_273;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_276.tag = 28;
    if ((unsigned char)(ts_tg == zT_276.tag)) goto z_bb_36; else goto z_bb_38;
    z_bb_36:
    zT_279 = ts_inst.payload.func_ref._0;
    zT_280 = zT_279.module_id;
    ts_edge_dst = zT_280;
    zT_281 = 1;
    ts_edge_has = zT_281;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_284.tag = 54;
    if ((unsigned char)(ts_tg == zT_284.tag)) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_287 = ts_inst.payload.load_global._0;
    zT_288 = zT_287.module_id;
    ts_edge_dst = zT_288;
    zT_289 = 1;
    ts_edge_has = zT_289;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_292.tag = 55;
    if ((unsigned char)(ts_tg == zT_292.tag)) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_295 = ts_inst.payload.store_global._0;
    zT_296 = zT_295.module_id;
    ts_edge_dst = zT_296;
    zT_297 = 1;
    ts_edge_has = zT_297;
    goto z_bb_43;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_300 = ts_edge_dst != ts_src;
    goto z_bb_46;
    z_bb_45:
    zT_300 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_300) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_302 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_306 = 65536;
    zT_307 = zig_wrap_mul_u(((zu64)(ts_src)), ((zu64)(zT_306)), 32u);
    zT_308 = zig_overflow_flag_mul_u(((zu64)(ts_src)), ((zu64)(zT_306)), 32u);
    zT_310 = zT_308 == (unsigned int)(0);
    if (!(zT_310)) { pal_trap(); }
    zT_311 = zig_wrap_add_u(((zu64)(zT_307)), ((zu64)(ts_edge_dst)), 32u);
    zT_312 = zig_overflow_flag_add_u(((zu64)(zT_307)), ((zu64)(ts_edge_dst)), 32u);
    zT_314 = zT_312 == (unsigned int)(0);
    if (!(zT_314)) { pal_trap(); }
    zT_303 = zT_311;
    zF_26476265_u32ToU32MapPut(zT_302, zT_303, (unsigned int)(1));
    goto z_bb_48;
    z_bb_48:
    zT_318.tag = 57;
    if ((unsigned char)(ts_tg == zT_318.tag)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_321 = emitter.std_fmt_module_id;
    zT_320 = zT_321 != (unsigned int)(4294967295u);
    goto z_bb_51;
    z_bb_50:
    zT_320 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_320) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_324 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_324 != ts_src)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_343.tag = 54;
    if ((unsigned char)(ts_tg != zT_343.tag)) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_326 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_330 = 65536;
    zT_331 = zig_wrap_mul_u(((zu64)(ts_src)), ((zu64)(zT_330)), 32u);
    zT_332 = zig_overflow_flag_mul_u(((zu64)(ts_src)), ((zu64)(zT_330)), 32u);
    zT_334 = zT_332 == (unsigned int)(0);
    if (!(zT_334)) { pal_trap(); }
    zT_335 = emitter.std_fmt_module_id;
    zT_336 = zig_wrap_add_u(((zu64)(zT_331)), ((zu64)(zT_335)), 32u);
    zT_337 = zig_overflow_flag_add_u(((zu64)(zT_331)), ((zu64)(zT_335)), 32u);
    zT_339 = zT_337 == (unsigned int)(0);
    if (!(zT_339)) { pal_trap(); }
    zT_327 = zT_336;
    zF_26476265_u32ToU32MapPut(zT_326, zT_327, (unsigned int)(1));
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_348.tag = 55;
    zT_345 = ts_tg != zT_348.tag;
    goto z_bb_58;
    z_bb_57:
    zT_345 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_345) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    goto z_bb_29;
    z_bb_60:
    zT_351 = 0;
    ts_name_id = zT_351;
    zT_353 = 0;
    ts_tmp = zT_353;
    zT_356.tag = 54;
    if ((unsigned char)(ts_tg == zT_356.tag)) goto z_bb_61; else goto z_bb_63;
    z_bb_61:
    zT_359 = ts_inst.payload.load_global._0;
    zT_360 = zT_359.name_id;
    ts_name_id = zT_360;
    zT_362 = ts_inst.payload.load_global._0;
    zT_363 = zT_362.result;
    ts_tmp = zT_363;
    goto z_bb_62;
    z_bb_62:
    zT_371 = 0;
    ts_tid = zT_371;
    zT_373 = 0;
    ts_tj = zT_373;
    goto z_bb_64;
    z_bb_63:
    zT_365 = ts_inst.payload.store_global._0;
    zT_366 = zT_365.name_id;
    ts_name_id = zT_366;
    zT_368 = ts_inst.payload.store_global._0;
    zT_369 = zT_368.value;
    ts_tmp = zT_369;
    goto z_bb_62;
    z_bb_64:
    zT_374 = ts_fn.hoisted_temps;
    zT_375 = zT_374.len;
    if ((unsigned char)(ts_tj < zT_375)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_378 = ts_fn.hoisted_temps;
    zT_379 = zT_378.items;
    zT_380 = zT_379[ts_tj];
    ts_ht = zT_380;
    zT_381 = ts_ht.temp_id;
    if ((unsigned char)(zT_381 == ts_tmp)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    zT_389 = ctx->typereg;
    zT_390 = zT_389->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_390))) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    zT_384 = 1;
    zT_385 = zig_wrap_add_u(((zu64)(ts_tj)), ((zu64)(zT_384)), 32u);
    zT_386 = zig_overflow_flag_add_u(((zu64)(ts_tj)), ((zu64)(zT_384)), 32u);
    zT_388 = zT_386 == (unsigned int)(0);
    if (!(zT_388)) { pal_trap(); }
    ts_tj = zT_385;
    goto z_bb_64;
    z_bb_68:
    zT_383 = ts_ht.type_id;
    ts_tid = zT_383;
    goto z_bb_66;
    z_bb_69:
    goto z_bb_67;
    z_bb_70:
    goto z_bb_29;
    z_bb_71:
    zT_394 = ctx->typereg;
    zT_395 = zT_394->types_items;
    zT_396 = (unsigned int)ts_tid;
    zT_397 = zT_395[zT_396];
    ts_ty = zT_397;
    zT_398 = ts_ty.name_id;
    if ((unsigned char)(zT_398 != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_402 = ts_ty.name_id;
    zT_401 = zT_402 == ts_name_id;
    goto z_bb_74;
    z_bb_73:
    zT_401 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_401) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_404 = (zT_21D3708C_U32ToU32Map*)&ts_ref_set;
    zT_405 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_404, zT_405, (unsigned int)(1));
    goto z_bb_76;
    z_bb_76:
    goto z_bb_29;
    z_bb_77:
    zT_430 = ctx->global_decls;
    zT_431 = zT_430.len;
    if ((unsigned char)(gt_i < zT_431)) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_434 = ctx->global_decls;
    zT_435 = zT_434.items;
    zT_436 = zT_435[gt_i];
    gt_g = zT_436;
    zT_437 = gt_g.type_id;
    zT_438 = ctx->typereg;
    zT_439 = zT_438->types_len;
    if ((unsigned char)(zT_437 >= (unsigned int)((unsigned int)zT_439))) goto z_bb_81; else goto z_bb_82;
    z_bb_79:
    zT_473 = ctx->alloc;
    zT_471 = &zT_473->emission;
    zT_472 = ri_mods.len;
    zT_477 = zF_619D56E6_u32ToU32MapInitCap(zT_471, zT_472);
    reachable = zT_477;
    zT_478 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zF_26476265_u32ToU32MapPut(zT_478, (unsigned int)(0), (unsigned int)(1));
    zT_485 = 1;
    rf_changed = zT_485;
    goto z_bb_88;
    z_bb_80:
    zT_465 = 1;
    zT_466 = zig_wrap_add_u(((zu64)(gt_i)), ((zu64)(zT_465)), 32u);
    zT_467 = zig_overflow_flag_add_u(((zu64)(gt_i)), ((zu64)(zT_465)), 32u);
    zT_469 = zT_467 == (unsigned int)(0);
    if (!(zT_469)) { pal_trap(); }
    gt_i = zT_466;
    goto z_bb_77;
    z_bb_81:
    goto z_bb_80;
    z_bb_82:
    zT_443 = ctx->typereg;
    zT_444 = zT_443->types_items;
    zT_445 = gt_g.type_id;
    zT_446 = (unsigned int)zT_445;
    zT_447 = zT_444[zT_446];
    gt_ty = zT_447;
    zT_448 = gt_ty.name_id;
    if ((unsigned char)(zT_448 != (unsigned int)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_452 = gt_ty.name_id;
    zT_453 = gt_g.name_id;
    zT_451 = zT_452 == zT_453;
    goto z_bb_85;
    z_bb_84:
    zT_451 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_451) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    goto z_bb_80;
    z_bb_87:
    zT_455 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_456 = ctx->typereg;
    zT_457 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_458 = gt_g.module_id;
    zT_459 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_455, zT_456, zT_457, zT_458, zT_459);
    goto z_bb_80;
    z_bb_88:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_488 = 0;
    rf_changed = zT_488;
    zT_490 = 0;
    rf_s = zT_490;
    goto z_bb_92;
    z_bb_90:
    zT_554 = 0;
    ri_i = zT_554;
    goto z_bb_108;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_492 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_492)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_495 = ri_mods.ptr;
    zT_496 = ri_mods.len;
    zT_497 = rf_s < zT_496;
    if (!(zT_497)) { pal_trap(); }
    zT_498 = zT_495[rf_s];
    zT_499 = zT_498.id;
    rf_src = zT_499;
    zT_500 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_501 = rf_src;
    zT_503 = zF_F3EE5998_u32ToU32MapGet(zT_500, zT_501);
    zT_504 = zT_503.has_value;
    if ((unsigned char)(!zT_504)) goto z_bb_96; else goto z_bb_97;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_548 = 1;
    zT_549 = zig_wrap_add_u(((zu64)(rf_s)), ((zu64)(zT_548)), 32u);
    zT_550 = zig_overflow_flag_add_u(((zu64)(rf_s)), ((zu64)(zT_548)), 32u);
    zT_552 = zT_550 == (unsigned int)(0);
    if (!(zT_552)) { pal_trap(); }
    rf_s = zT_549;
    goto z_bb_92;
    z_bb_96:
    goto z_bb_95;
    z_bb_97:
    zT_507 = 0;
    rf_d = zT_507;
    goto z_bb_98;
    z_bb_98:
    zT_509 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_509)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_512 = ri_mods.ptr;
    zT_513 = ri_mods.len;
    zT_514 = rf_d < zT_513;
    if (!(zT_514)) { pal_trap(); }
    zT_515 = zT_512[rf_d];
    zT_516 = zT_515.id;
    rf_dst = zT_516;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_95;
    z_bb_101:
    zT_543 = 1;
    zT_544 = zig_wrap_add_u(((zu64)(rf_d)), ((zu64)(zT_543)), 32u);
    zT_545 = zig_overflow_flag_add_u(((zu64)(rf_d)), ((zu64)(zT_543)), 32u);
    zT_547 = zT_545 == (unsigned int)(0);
    if (!(zT_547)) { pal_trap(); }
    rf_d = zT_544;
    goto z_bb_98;
    z_bb_102:
    goto z_bb_101;
    z_bb_103:
    zT_518 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_519 = rf_dst;
    zT_521 = zF_F3EE5998_u32ToU32MapGet(zT_518, zT_519);
    zT_522 = zT_521.has_value;
    if (zT_522) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    goto z_bb_101;
    z_bb_105:
    zT_523 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_526 = 65536;
    zT_527 = zig_wrap_mul_u(((zu64)(rf_src)), ((zu64)(zT_526)), 32u);
    zT_528 = zig_overflow_flag_mul_u(((zu64)(rf_src)), ((zu64)(zT_526)), 32u);
    zT_530 = zT_528 == (unsigned int)(0);
    if (!(zT_530)) { pal_trap(); }
    zT_531 = zig_wrap_add_u(((zu64)(zT_527)), ((zu64)(rf_dst)), 32u);
    zT_532 = zig_overflow_flag_add_u(((zu64)(zT_527)), ((zu64)(rf_dst)), 32u);
    zT_534 = zT_532 == (unsigned int)(0);
    if (!(zT_534)) { pal_trap(); }
    zT_524 = zT_531;
    zT_535 = zF_F3EE5998_u32ToU32MapGet(zT_523, zT_524);
    zT_536 = zT_535.has_value;
    if (zT_536) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_537 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_538 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_537, zT_538, (unsigned int)(1));
    zT_542 = 1;
    rf_changed = zT_542;
    goto z_bb_107;
    z_bb_107:
    goto z_bb_101;
    z_bb_108:
    zT_556 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_556)) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_558 = ri_mods.ptr;
    zT_559 = ri_mods.len;
    zT_560 = ri_i < zT_559;
    if (!(zT_560)) { pal_trap(); }
    zT_561 = zT_558[ri_i];
    zT_562 = zT_561.id;
    if ((unsigned char)(zT_562 == (unsigned int)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_110:
    emitter.reachable = reachable;
    zT_631 = ctx->cli;
    zT_632 = zT_631.output_dir_set;
    if (zT_632) goto z_bb_127; else goto z_bb_128;
    z_bb_111:
    zT_626 = 1;
    zT_627 = zig_wrap_add_u(((zu64)(ri_i)), ((zu64)(zT_626)), 32u);
    zT_628 = zig_overflow_flag_add_u(((zu64)(ri_i)), ((zu64)(zT_626)), 32u);
    zT_630 = zT_628 == (unsigned int)(0);
    if (!(zT_630)) { pal_trap(); }
    ri_i = zT_627;
    goto z_bb_108;
    z_bb_112:
    goto z_bb_111;
    z_bb_113:
    zT_565 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_568 = ri_mods.ptr;
    zT_569 = ri_mods.len;
    zT_570 = ri_i < zT_569;
    if (!(zT_570)) { pal_trap(); }
    zT_571 = zT_568[ri_i];
    zT_566 = zT_571.id;
    zT_573 = zF_F3EE5998_u32ToU32MapGet(zT_565, zT_566);
    zT_574 = zT_573.has_value;
    if ((unsigned char)(!zT_574)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_577 = 0;
    ri_has = zT_577;
    zT_579 = 0;
    gd_ri = zT_579;
    goto z_bb_116;
    z_bb_116:
    zT_580 = ctx->global_decls;
    zT_581 = zT_580.len;
    if ((unsigned char)(gd_ri < zT_581)) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_584 = ctx->global_decls;
    zT_585 = zT_584.items;
    zT_586 = zT_585[gd_ri];
    gd_g = zT_586;
    zT_587 = gd_g.module_id;
    zT_588 = ri_mods.ptr;
    zT_589 = ri_mods.len;
    zT_590 = ri_i < zT_589;
    if (!(zT_590)) { pal_trap(); }
    zT_591 = zT_588[ri_i];
    zT_592 = zT_591.id;
    if ((unsigned char)(zT_587 == zT_592)) goto z_bb_120; else goto z_bb_121;
    z_bb_118:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_125; else goto z_bb_126;
    z_bb_119:
    zT_599 = 1;
    zT_600 = zig_wrap_add_u(((zu64)(gd_ri)), ((zu64)(zT_599)), 32u);
    zT_601 = zig_overflow_flag_add_u(((zu64)(gd_ri)), ((zu64)(zT_599)), 32u);
    zT_603 = zT_601 == (unsigned int)(0);
    if (!(zT_603)) { pal_trap(); }
    gd_ri = zT_600;
    goto z_bb_116;
    z_bb_120:
    zT_595 = gd_g.has_runtime_init;
    zT_594 = zT_595 != (unsigned char)(0);
    goto z_bb_122;
    z_bb_121:
    zT_594 = 0;
    goto z_bb_122;
    z_bb_122:
    if (zT_594) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    zT_598 = 1;
    ri_has = zT_598;
    goto z_bb_118;
    z_bb_124:
    goto z_bb_119;
    z_bb_125:
    zT_606 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_610 = 0;
    zT_611 = 65536;
    zT_612 = zig_wrap_mul_u(((zu64)(zT_610)), ((zu64)(zT_611)), 32u);
    zT_613 = zig_overflow_flag_mul_u(((zu64)(zT_610)), ((zu64)(zT_611)), 32u);
    zT_615 = zT_613 == (unsigned int)(0);
    if (!(zT_615)) { pal_trap(); }
    zT_616 = ri_mods.ptr;
    zT_617 = ri_mods.len;
    zT_618 = ri_i < zT_617;
    if (!(zT_618)) { pal_trap(); }
    zT_619 = zT_616[ri_i];
    zT_620 = zT_619.id;
    zT_621 = zig_wrap_add_u(((zu64)(zT_612)), ((zu64)(zT_620)), 32u);
    zT_622 = zig_overflow_flag_add_u(((zu64)(zT_612)), ((zu64)(zT_620)), 32u);
    zT_624 = zT_622 == (unsigned int)(0);
    if (!(zT_624)) { pal_trap(); }
    zT_607 = zT_621;
    zF_26476265_u32ToU32MapPut(zT_606, zT_607, (unsigned int)(1));
    goto z_bb_126;
    z_bb_126:
    goto z_bb_111;
    z_bb_127:
    zT_633 = ctx->cli;
    zT_634 = zT_633.debug;
    if (zT_634) goto z_bb_129; else goto z_bb_130;
    z_bb_128:
    zig_poison_fill((void*)&zT_1564, (unsigned int)sizeof zT_1564);
    cwriter = zT_1564;
    zT_1565 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1565;
    zT_1566 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_225796FB_emitIncludes(zT_1566);
    zT_1568 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1568);
    zT_1571 = ctx->module_reg;
    zT_1574 = ctx->alloc;
    zT_1572 = &zT_1574->emission;
    zT_1576 = zF_1E2E8788_cincludeUnionAll(zT_1571, zT_1572);
    c_incs = zT_1576;
    zT_1577 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1578 = module_name;
    zT_1579 = c_incs;
    zF_503E3056_emitModule(zT_1577, zT_1578, zT_1579);
    zT_1582 = "FINAL_FLUSH\n";
    zT_1584 = 12;
    zT_1583.ptr = (unsigned char*)zT_1582;
    zT_1583.len = zT_1584;
    ff_m = zT_1583;
    zT_1585 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1585);
    zT_1587 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1586 = &zT_1587->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1586);
    zT_1589 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1589);
    zT_1591 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1591);
    return;
    z_bb_129:
    zT_636 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_639 = 0;
    zT_641 = zF_E295413A_moduleQualifiedName(zT_636, (unsigned int)((unsigned int)zT_639));
    dbg_root_stem = zT_641;
    zig_poison_fill((void*)&zT_643, (unsigned int)sizeof zT_643);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p1[_i] = zT_643[_i];
        _i++;
    }
}
    zig_poison_fill((void*)&zT_645, (unsigned int)sizeof zT_645);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p2[_i] = zT_645[_i];
        _i++;
    }
}
    zig_poison_fill((void*)&zT_647, (unsigned int)sizeof zT_647);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p3[_i] = zT_647[_i];
        _i++;
    }
}
    zT_649 = "syms";
    zT_651 = 4;
    zT_650.ptr = (unsigned char*)zT_649;
    zT_650.len = zT_651;
    dbg_e1 = zT_650;
    zT_653 = "lines";
    zT_655 = 5;
    zT_654.ptr = (unsigned char*)zT_653;
    zT_654.len = zT_655;
    dbg_e2 = zT_654;
    zT_657 = "cnames";
    zT_659 = 6;
    zT_658.ptr = (unsigned char*)zT_657;
    zT_658.len = zT_659;
    dbg_e3 = zT_658;
    zT_667 = 0;
    zT_668 = (unsigned char*)((unsigned char*)dbg_p1) + zT_667;
    zT_669 = (unsigned int)(512) - zT_667;
    zT_670.ptr = (unsigned char*)zT_668;
    zT_670.len = zT_669;
    zT_661 = zT_670;
    zT_671 = ctx->cli;
    zT_672 = zT_671.output_dir;
    zT_662 = zT_672;
    zT_663 = dbg_root_stem;
    zT_664 = dbg_e1;
    zT_673 = zF_5E17F383_buildDebugMapPath(zT_661, zT_662, zT_663, zT_664);
    dbg_n1 = zT_673;
    zT_681 = 0;
    zT_682 = (unsigned char*)((unsigned char*)dbg_p2) + zT_681;
    zT_683 = (unsigned int)(512) - zT_681;
    zT_684.ptr = (unsigned char*)zT_682;
    zT_684.len = zT_683;
    zT_675 = zT_684;
    zT_685 = ctx->cli;
    zT_686 = zT_685.output_dir;
    zT_676 = zT_686;
    zT_677 = dbg_root_stem;
    zT_678 = dbg_e2;
    zT_687 = zF_5E17F383_buildDebugMapPath(zT_675, zT_676, zT_677, zT_678);
    dbg_n2 = zT_687;
    zT_695 = 0;
    zT_696 = (unsigned char*)((unsigned char*)dbg_p3) + zT_695;
    zT_697 = (unsigned int)(512) - zT_695;
    zT_698.ptr = (unsigned char*)zT_696;
    zT_698.len = zT_697;
    zT_689 = zT_698;
    zT_699 = ctx->cli;
    zT_700 = zT_699.output_dir;
    zT_690 = zT_700;
    zT_691 = dbg_root_stem;
    zT_692 = dbg_e3;
    zT_701 = zF_5E17F383_buildDebugMapPath(zT_689, zT_690, zT_691, zT_692);
    dbg_n3 = zT_701;
    zT_702 = &ctx->debug_map;
    zT_708 = ctx->alloc;
    zT_703 = &zT_708->emission;
    zT_712 = 0;
    zT_713 = (unsigned char*)((unsigned char*)dbg_p1) + zT_712;
    zT_714 = dbg_n1 - zT_712;
    zT_715 = (unsigned int)zT_712 <= dbg_n1;
    if (!(zT_715)) { pal_trap(); }
    zT_716 = dbg_n1 <= (unsigned int)(512);
    if (!(zT_716)) { pal_trap(); }
    zT_717.ptr = (unsigned char*)zT_713;
    zT_717.len = zT_714;
    zT_704 = zT_717;
    zT_720 = 0;
    zT_721 = (unsigned char*)((unsigned char*)dbg_p2) + zT_720;
    zT_722 = dbg_n2 - zT_720;
    zT_723 = (unsigned int)zT_720 <= dbg_n2;
    if (!(zT_723)) { pal_trap(); }
    zT_724 = dbg_n2 <= (unsigned int)(512);
    if (!(zT_724)) { pal_trap(); }
    zT_725.ptr = (unsigned char*)zT_721;
    zT_725.len = zT_722;
    zT_705 = zT_725;
    zT_728 = 0;
    zT_729 = (unsigned char*)((unsigned char*)dbg_p3) + zT_728;
    zT_730 = dbg_n3 - zT_728;
    zT_731 = (unsigned int)zT_728 <= dbg_n3;
    if (!(zT_731)) { pal_trap(); }
    zT_732 = dbg_n3 <= (unsigned int)(512);
    if (!(zT_732)) { pal_trap(); }
    zT_733.ptr = (unsigned char*)zT_729;
    zT_733.len = zT_730;
    zT_706 = zT_733;
    zF_ED14666D_debugMapWriterOpen(zT_702, zT_703, zT_704, zT_705, zT_706);
    goto z_bb_130;
    z_bb_130:
    zT_735 = ctx->spell_plan;
    zT_736 = zT_735.typedef_order;
    sorted = zT_736;
    zig_poison_fill((void*)&zT_738, (unsigned int)sizeof zT_738);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_738[_i];
        _i++;
    }
}
    zT_740 = 0;
    hp = zT_740;
    zT_742 = ctx->cli;
    zT_743 = zT_742.output_dir;
    od = zT_743;
    zT_744 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_745 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_744, zT_745);
    zT_748 = 0;
    hi = zT_748;
    goto z_bb_131;
    z_bb_131:
    zT_750 = od.len;
    if ((unsigned char)(hi < zT_750)) goto z_bb_135; else goto z_bb_136;
    z_bb_132:
    zT_755 = od.ptr;
    zT_756 = od.len;
    zT_757 = hi < zT_756;
    if (!(zT_757)) { pal_trap(); }
    zT_758 = zT_755[hi];
    zT_760 = hp < (unsigned int)(512);
    if (!(zT_760)) { pal_trap(); }
    hpath[hp] = zT_758;
    zT_761 = 1;
    zT_762 = (unsigned int)zT_761;
    zT_763 = zig_wrap_add_u(((zu64)(hp)), ((zu64)(zT_762)), 32u);
    zT_764 = zig_overflow_flag_add_u(((zu64)(hp)), ((zu64)(zT_762)), 32u);
    zT_766 = zT_764 == (unsigned int)(0);
    if (!(zT_766)) { pal_trap(); }
    hp = zT_763;
    goto z_bb_134;
    z_bb_133:
    zT_773 = 47;
    zT_775 = hp < (unsigned int)(512);
    if (!(zT_775)) { pal_trap(); }
    hpath[hp] = zT_773;
    zT_776 = 1;
    zT_777 = (unsigned int)zT_776;
    zT_778 = zig_wrap_add_u(((zu64)(hp)), ((zu64)(zT_777)), 32u);
    zT_779 = zig_overflow_flag_add_u(((zu64)(hp)), ((zu64)(zT_777)), 32u);
    zT_781 = zT_779 == (unsigned int)(0);
    if (!(zT_781)) { pal_trap(); }
    hp = zT_778;
    zT_783 = "zig_special_types.h";
    zT_785 = 19;
    zT_784.ptr = (unsigned char*)zT_783;
    zT_784.len = zT_785;
    hfn = zT_784;
    zT_787 = 0;
    hfi = zT_787;
    goto z_bb_138;
    z_bb_134:
    zT_767 = 1;
    zT_768 = (unsigned int)zT_767;
    zT_769 = zig_wrap_add_u(((zu64)(hi)), ((zu64)(zT_768)), 32u);
    zT_770 = zig_overflow_flag_add_u(((zu64)(hi)), ((zu64)(zT_768)), 32u);
    zT_772 = zT_770 == (unsigned int)(0);
    if (!(zT_772)) { pal_trap(); }
    hi = zT_769;
    goto z_bb_131;
    z_bb_135:
    zT_752 = hp < (unsigned int)(510);
    goto z_bb_137;
    z_bb_136:
    zT_752 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_752) goto z_bb_132; else goto z_bb_133;
    z_bb_138:
    zT_789 = hfn.len;
    if ((unsigned char)(hfi < zT_789)) goto z_bb_142; else goto z_bb_143;
    z_bb_139:
    zT_794 = hfn.ptr;
    zT_795 = hfn.len;
    zT_796 = hfi < zT_795;
    if (!(zT_796)) { pal_trap(); }
    zT_797 = zT_794[hfi];
    zT_799 = hp < (unsigned int)(512);
    if (!(zT_799)) { pal_trap(); }
    hpath[hp] = zT_797;
    zT_800 = 1;
    zT_801 = (unsigned int)zT_800;
    zT_802 = zig_wrap_add_u(((zu64)(hp)), ((zu64)(zT_801)), 32u);
    zT_803 = zig_overflow_flag_add_u(((zu64)(hp)), ((zu64)(zT_801)), 32u);
    zT_805 = zT_803 == (unsigned int)(0);
    if (!(zT_805)) { pal_trap(); }
    hp = zT_802;
    goto z_bb_141;
    z_bb_140:
    zT_817 = 0;
    zT_818 = (unsigned char*)((unsigned char*)hpath) + zT_817;
    zT_819 = hp - zT_817;
    zT_820 = (unsigned int)zT_817 <= hp;
    if (!(zT_820)) { pal_trap(); }
    zT_821 = hp <= (unsigned int)(512);
    if (!(zT_821)) { pal_trap(); }
    zT_822.ptr = (unsigned char*)zT_818;
    zT_822.len = zT_819;
    zT_813 = zT_822;
    zT_824 = zF_39FE21EF_fileOpen(zT_813, (int)(0));
    fd = zT_824;
    if ((unsigned char)(fd == (unsigned int)(4294967295u))) goto z_bb_145; else goto z_bb_146;
    z_bb_141:
    zT_806 = 1;
    zT_807 = (unsigned int)zT_806;
    zT_808 = zig_wrap_add_u(((zu64)(hfi)), ((zu64)(zT_807)), 32u);
    zT_809 = zig_overflow_flag_add_u(((zu64)(hfi)), ((zu64)(zT_807)), 32u);
    zT_811 = zT_809 == (unsigned int)(0);
    if (!(zT_811)) { pal_trap(); }
    hfi = zT_808;
    goto z_bb_138;
    z_bb_142:
    zT_791 = hp < (unsigned int)(511);
    goto z_bb_144;
    z_bb_143:
    zT_791 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_791) goto z_bb_139; else goto z_bb_140;
    z_bb_145:
    zT_828 = "error: cannot open output file\n";
    zT_830 = 31;
    zT_829.ptr = (unsigned char*)zT_828;
    zT_829.len = zT_830;
    emsg = zT_829;
    zT_831 = emsg;
    zF_E4B2EF19_stderr_write(zT_831);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_146;
    z_bb_146:
    zig_poison_fill((void*)&zT_835, (unsigned int)sizeof zT_835);
    hw = zT_835;
    zT_836 = fd;
    zT_837 = zF_E00097E1_bufferedWriterInitF(zT_836);
    hw = zT_837;
    emitter.writer = hw;
    zT_838 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_839 = ctx->typereg;
    zT_840 = sorted;
    zF_62841416_emitSharedHeader(zT_838, zT_839, zT_840);
    zT_844 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_843 = &zT_844->writer;
    zF_B35650AD_bufferedWriterFlush(zT_843);
    zT_846 = fd;
    zF_B30B1D79_fileClose(zT_846);
    zT_848 = ctx->module_reg;
    zT_850 = zF_3452C137_moduleRegistryGetMo(zT_848);
    mods = zT_850;
    emitter.prune_active = (unsigned char)(1);
    zT_853 = ctx->lir_slots;
    zT_854 = zT_853.len;
    slot_count = zT_854;
    zT_855 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_855)) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_861 = ctx->alloc;
    zT_858 = &zT_861->emission;
    zT_863 = 4;
    zT_865 = mods.len;
    zT_866 = zig_wrap_mul_u(((zu64)(zT_863)), ((zu64)(zT_865)), 32u);
    zT_867 = zig_overflow_flag_mul_u(((zu64)(zT_863)), ((zu64)(zT_865)), 32u);
    zT_869 = zT_867 == (unsigned int)(0);
    if (!(zT_869)) { pal_trap(); }
    zT_859 = zT_866;
    zT_871 = zF_1395EB68_sandAlloc(zT_858, zT_859, (unsigned int)(4));
    zT_872 = zT_871.is_error;
    if (zT_872) goto z_bb_149; else goto z_bb_150;
    z_bb_148:
    zT_999 = 0;
    fn_cursor = zT_999;
    zT_1001 = 0;
    mi = zT_1001;
    goto z_bb_178;
    z_bb_149:
    pal_trap();
    z_bb_150:
    zT_873 = zT_871.data.payload;
    goto z_bb_151;
    z_bb_151:
    zT_875 = (unsigned int*)zT_873;
    grp_counts = zT_875;
    zT_880 = ctx->alloc;
    zT_877 = &zT_880->emission;
    zT_882 = 4;
    zT_884 = mods.len;
    zT_885 = zig_wrap_mul_u(((zu64)(zT_882)), ((zu64)(zT_884)), 32u);
    zT_886 = zig_overflow_flag_mul_u(((zu64)(zT_882)), ((zu64)(zT_884)), 32u);
    zT_888 = zT_886 == (unsigned int)(0);
    if (!(zT_888)) { pal_trap(); }
    zT_878 = zT_885;
    zT_890 = zF_1395EB68_sandAlloc(zT_877, zT_878, (unsigned int)(4));
    zT_891 = zT_890.is_error;
    if (zT_891) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    pal_trap();
    z_bb_153:
    zT_892 = zT_890.data.payload;
    goto z_bb_154;
    z_bb_154:
    zT_894 = (unsigned int*)zT_892;
    grp_cursor = zT_894;
    zT_896 = 0;
    gci = zT_896;
    goto z_bb_155;
    z_bb_155:
    zT_898 = mods.len;
    if ((unsigned char)(gci < zT_898)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_900 = 0;
    grp_counts[gci] = zT_900;
    goto z_bb_158;
    z_bb_157:
    zT_908 = 0;
    gsi = zT_908;
    goto z_bb_159;
    z_bb_158:
    zT_901 = 1;
    zT_902 = (unsigned int)zT_901;
    zT_903 = zig_wrap_add_u(((zu64)(gci)), ((zu64)(zT_902)), 32u);
    zT_904 = zig_overflow_flag_add_u(((zu64)(gci)), ((zu64)(zT_902)), 32u);
    zT_906 = zT_904 == (unsigned int)(0);
    if (!(zT_906)) { pal_trap(); }
    gci = zT_903;
    goto z_bb_155;
    z_bb_159:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_911 = ctx->lir_slots;
    zT_912 = zT_911.items;
    zT_913 = zT_912[gsi];
    zT_914 = zT_913.module_id;
    gsmid = zT_914;
    zT_917 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_917)) goto z_bb_163; else goto z_bb_164;
    z_bb_161:
    zT_934 = 0;
    gacc = zT_934;
    zT_935 = 0;
    gci = zT_935;
    goto z_bb_165;
    z_bb_162:
    zT_927 = 1;
    zT_928 = (unsigned int)zT_927;
    zT_929 = zig_wrap_add_u(((zu64)(gsi)), ((zu64)(zT_928)), 32u);
    zT_930 = zig_overflow_flag_add_u(((zu64)(gsi)), ((zu64)(zT_928)), 32u);
    zT_932 = zT_930 == (unsigned int)(0);
    if (!(zT_932)) { pal_trap(); }
    gsi = zT_929;
    goto z_bb_159;
    z_bb_163:
    zT_919 = (unsigned int)gsmid;
    zT_920 = grp_counts[zT_919];
    zT_921 = 1;
    zT_922 = zig_wrap_add_u(((zu64)(zT_920)), ((zu64)(zT_921)), 32u);
    zT_923 = zig_overflow_flag_add_u(((zu64)(zT_920)), ((zu64)(zT_921)), 32u);
    zT_925 = zT_923 == (unsigned int)(0);
    if (!(zT_925)) { pal_trap(); }
    zT_926 = (unsigned int)gsmid;
    grp_counts[zT_926] = zT_922;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_162;
    z_bb_165:
    zT_937 = mods.len;
    if ((unsigned char)(gci < zT_937)) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    grp_cursor[gci] = gacc;
    zT_939 = grp_counts[gci];
    zT_940 = zig_wrap_add_u(((zu64)(gacc)), ((zu64)(zT_939)), 32u);
    zT_941 = zig_overflow_flag_add_u(((zu64)(gacc)), ((zu64)(zT_939)), 32u);
    zT_943 = zT_941 == (unsigned int)(0);
    if (!(zT_943)) { pal_trap(); }
    gacc = zT_940;
    goto z_bb_168;
    z_bb_167:
    zT_954 = ctx->alloc;
    zT_951 = &zT_954->emission;
    zT_956 = 12;
    zT_957 = zig_wrap_mul_u(((zu64)(zT_956)), ((zu64)(slot_count)), 32u);
    zT_958 = zig_overflow_flag_mul_u(((zu64)(zT_956)), ((zu64)(slot_count)), 32u);
    zT_960 = zT_958 == (unsigned int)(0);
    if (!(zT_960)) { pal_trap(); }
    zT_952 = zT_957;
    zT_962 = zF_1395EB68_sandAlloc(zT_951, zT_952, (unsigned int)(4));
    zT_963 = zT_962.is_error;
    if (zT_963) goto z_bb_169; else goto z_bb_170;
    z_bb_168:
    zT_944 = 1;
    zT_945 = (unsigned int)zT_944;
    zT_946 = zig_wrap_add_u(((zu64)(gci)), ((zu64)(zT_945)), 32u);
    zT_947 = zig_overflow_flag_add_u(((zu64)(gci)), ((zu64)(zT_945)), 32u);
    zT_949 = zT_947 == (unsigned int)(0);
    if (!(zT_949)) { pal_trap(); }
    gci = zT_946;
    goto z_bb_165;
    z_bb_169:
    pal_trap();
    z_bb_170:
    zT_964 = zT_962.data.payload;
    goto z_bb_171;
    z_bb_171:
    zT_966 = (zT_E7714190_LirSlot*)zT_964;
    grouped = zT_966;
    zT_967 = 0;
    gsi = zT_967;
    goto z_bb_172;
    z_bb_172:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_970 = ctx->lir_slots;
    zT_971 = zT_970.items;
    zT_972 = zT_971[gsi];
    gslot = zT_972;
    zT_974 = gslot.module_id;
    gsmid = zT_974;
    zT_977 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_977)) goto z_bb_176; else goto z_bb_177;
    z_bb_174:
    zT_995 = &ctx->lir_slots;
    zT_995->items = grouped;
    zT_997 = &ctx->lir_slots;
    zT_997->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_148;
    z_bb_175:
    zT_989 = 1;
    zT_990 = (unsigned int)zT_989;
    zT_991 = zig_wrap_add_u(((zu64)(gsi)), ((zu64)(zT_990)), 32u);
    zT_992 = zig_overflow_flag_add_u(((zu64)(gsi)), ((zu64)(zT_990)), 32u);
    zT_994 = zT_992 == (unsigned int)(0);
    if (!(zT_994)) { pal_trap(); }
    gsi = zT_991;
    goto z_bb_172;
    z_bb_176:
    goto z_bb_175;
    z_bb_177:
    zT_980 = (unsigned int)gsmid;
    zT_981 = grp_cursor[zT_980];
    gdst = zT_981;
    zT_982 = (unsigned int)gdst;
    grouped[zT_982] = gslot;
    zT_983 = 1;
    zT_984 = zig_wrap_add_u(((zu64)(gdst)), ((zu64)(zT_983)), 32u);
    zT_985 = zig_overflow_flag_add_u(((zu64)(gdst)), ((zu64)(zT_983)), 32u);
    zT_987 = zT_985 == (unsigned int)(0);
    if (!(zT_987)) { pal_trap(); }
    zT_988 = (unsigned int)gsmid;
    grp_cursor[zT_988] = zT_984;
    goto z_bb_175;
    z_bb_178:
    zT_1003 = mods.len;
    if ((unsigned char)(mi < zT_1003)) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_1006 = mods.ptr;
    zT_1007 = mods.len;
    zT_1008 = mi < zT_1007;
    if (!(zT_1008)) { pal_trap(); }
    zT_1009 = zT_1006[mi];
    m = zT_1009;
    fn_start = fn_cursor;
    goto z_bb_182;
    z_bb_180:
    zT_1521 = ctx->cli;
    zT_1522 = zT_1521.debug;
    if (zT_1522) goto z_bb_280; else goto z_bb_281;
    z_bb_181:
    zT_1515 = 1;
    zT_1516 = (unsigned int)zT_1515;
    zT_1517 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_1516)), 32u);
    zT_1518 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_1516)), 32u);
    zT_1520 = zT_1518 == (unsigned int)(0);
    if (!(zT_1520)) { pal_trap(); }
    mi = zT_1517;
    goto z_bb_178;
    z_bb_182:
    zT_1011 = ctx->lir_slots;
    zT_1012 = zT_1011.len;
    if ((unsigned char)(fn_cursor < zT_1012)) goto z_bb_186; else goto z_bb_187;
    z_bb_183:
    goto z_bb_185;
    z_bb_184:
    zT_1026 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_1027 = m.id;
    zT_1030 = zF_F3EE5998_u32ToU32MapGet(zT_1026, zT_1027);
    zT_1031 = zT_1030.has_value;
    if ((unsigned char)(!zT_1031)) goto z_bb_189; else goto z_bb_190;
    z_bb_185:
    zT_1021 = 1;
    zT_1022 = zig_wrap_add_u(((zu64)(fn_cursor)), ((zu64)(zT_1021)), 32u);
    zT_1023 = zig_overflow_flag_add_u(((zu64)(fn_cursor)), ((zu64)(zT_1021)), 32u);
    zT_1025 = zT_1023 == (unsigned int)(0);
    if (!(zT_1025)) { pal_trap(); }
    fn_cursor = zT_1022;
    goto z_bb_182;
    z_bb_186:
    zT_1015 = ctx->lir_slots;
    zT_1016 = zT_1015.items;
    zT_1017 = zT_1016[fn_cursor];
    zT_1018 = zT_1017.module_id;
    zT_1019 = m.id;
    zT_1014 = zT_1018 == zT_1019;
    goto z_bb_188;
    z_bb_187:
    zT_1014 = 0;
    goto z_bb_188;
    z_bb_188:
    if (zT_1014) goto z_bb_183; else goto z_bb_184;
    z_bb_189:
    goto z_bb_181;
    z_bb_190:
    emitter.fn_slots_start = fn_start;
    zT_1033 = zig_wrap_sub_u(((zu64)(fn_cursor)), ((zu64)(fn_start)), 32u);
    zT_1034 = zig_overflow_flag_sub_u(((zu64)(fn_cursor)), ((zu64)(fn_start)), 32u);
    zT_1036 = zT_1034 == (unsigned int)(0);
    if (!(zT_1036)) { pal_trap(); }
    emitter.fn_slots_len = zT_1033;
    zT_1038 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1039 = m.id;
    zT_1042 = zF_E295413A_moduleQualifiedName(zT_1038, zT_1039);
    base = zT_1042;
    zT_1044 = od.len;
    zT_1045 = 1;
    zT_1046 = zig_wrap_add_u(((zu64)(zT_1044)), ((zu64)(zT_1045)), 32u);
    zT_1047 = zig_overflow_flag_add_u(((zu64)(zT_1044)), ((zu64)(zT_1045)), 32u);
    zT_1049 = zT_1047 == (unsigned int)(0);
    if (!(zT_1049)) { pal_trap(); }
    zT_1051 = base.len;
    zT_1052 = zig_wrap_add_u(((zu64)(zT_1046)), ((zu64)(zT_1051)), 32u);
    zT_1053 = zig_overflow_flag_add_u(((zu64)(zT_1046)), ((zu64)(zT_1051)), 32u);
    zT_1055 = zT_1053 == (unsigned int)(0);
    if (!(zT_1055)) { pal_trap(); }
    zT_1056 = 3;
    zT_1057 = zig_wrap_add_u(((zu64)(zT_1052)), ((zu64)(zT_1056)), 32u);
    zT_1058 = zig_overflow_flag_add_u(((zu64)(zT_1052)), ((zu64)(zT_1056)), 32u);
    zT_1060 = zT_1058 == (unsigned int)(0);
    if (!(zT_1060)) { pal_trap(); }
    if ((unsigned char)(zT_1057 > (unsigned int)(511))) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_1064 = "error: output filename too long\n";
    zT_1066 = 32;
    zT_1065.ptr = (unsigned char*)zT_1064;
    zT_1065.len = zT_1066;
    lmsg = zT_1065;
    zT_1067 = lmsg;
    zF_E4B2EF19_stderr_write(zT_1067);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_192;
    z_bb_192:
    zT_1071 = 0;
    hp2 = zT_1071;
    zT_1073 = 0;
    hi2 = zT_1073;
    goto z_bb_193;
    z_bb_193:
    zT_1075 = od.len;
    if ((unsigned char)(hi2 < zT_1075)) goto z_bb_197; else goto z_bb_198;
    z_bb_194:
    zT_1080 = od.ptr;
    zT_1081 = od.len;
    zT_1082 = hi2 < zT_1081;
    if (!(zT_1082)) { pal_trap(); }
    zT_1083 = zT_1080[hi2];
    zT_1085 = hp2 < (unsigned int)(512);
    if (!(zT_1085)) { pal_trap(); }
    hpath[hp2] = zT_1083;
    zT_1086 = 1;
    zT_1087 = (unsigned int)zT_1086;
    zT_1088 = zig_wrap_add_u(((zu64)(hp2)), ((zu64)(zT_1087)), 32u);
    zT_1089 = zig_overflow_flag_add_u(((zu64)(hp2)), ((zu64)(zT_1087)), 32u);
    zT_1091 = zT_1089 == (unsigned int)(0);
    if (!(zT_1091)) { pal_trap(); }
    hp2 = zT_1088;
    goto z_bb_196;
    z_bb_195:
    zT_1098 = 47;
    zT_1100 = hp2 < (unsigned int)(512);
    if (!(zT_1100)) { pal_trap(); }
    hpath[hp2] = zT_1098;
    zT_1101 = 1;
    zT_1102 = (unsigned int)zT_1101;
    zT_1103 = zig_wrap_add_u(((zu64)(hp2)), ((zu64)(zT_1102)), 32u);
    zT_1104 = zig_overflow_flag_add_u(((zu64)(hp2)), ((zu64)(zT_1102)), 32u);
    zT_1106 = zT_1104 == (unsigned int)(0);
    if (!(zT_1106)) { pal_trap(); }
    hp2 = zT_1103;
    zT_1108 = 0;
    bi = zT_1108;
    goto z_bb_200;
    z_bb_196:
    zT_1092 = 1;
    zT_1093 = (unsigned int)zT_1092;
    zT_1094 = zig_wrap_add_u(((zu64)(hi2)), ((zu64)(zT_1093)), 32u);
    zT_1095 = zig_overflow_flag_add_u(((zu64)(hi2)), ((zu64)(zT_1093)), 32u);
    zT_1097 = zT_1095 == (unsigned int)(0);
    if (!(zT_1097)) { pal_trap(); }
    hi2 = zT_1094;
    goto z_bb_193;
    z_bb_197:
    zT_1077 = hp2 < (unsigned int)(510);
    goto z_bb_199;
    z_bb_198:
    zT_1077 = 0;
    goto z_bb_199;
    z_bb_199:
    if (zT_1077) goto z_bb_194; else goto z_bb_195;
    z_bb_200:
    zT_1110 = base.len;
    if ((unsigned char)(bi < zT_1110)) goto z_bb_204; else goto z_bb_205;
    z_bb_201:
    zT_1115 = base.ptr;
    zT_1116 = base.len;
    zT_1117 = bi < zT_1116;
    if (!(zT_1117)) { pal_trap(); }
    zT_1118 = zT_1115[bi];
    zT_1120 = hp2 < (unsigned int)(512);
    if (!(zT_1120)) { pal_trap(); }
    hpath[hp2] = zT_1118;
    zT_1121 = 1;
    zT_1122 = (unsigned int)zT_1121;
    zT_1123 = zig_wrap_add_u(((zu64)(hp2)), ((zu64)(zT_1122)), 32u);
    zT_1124 = zig_overflow_flag_add_u(((zu64)(hp2)), ((zu64)(zT_1122)), 32u);
    zT_1126 = zT_1124 == (unsigned int)(0);
    if (!(zT_1126)) { pal_trap(); }
    hp2 = zT_1123;
    goto z_bb_203;
    z_bb_202:
    zT_1134 = ".h";
    zT_1136 = 2;
    zT_1135.ptr = (unsigned char*)zT_1134;
    zT_1135.len = zT_1136;
    hext = zT_1135;
    zT_1138 = 0;
    hx = zT_1138;
    goto z_bb_207;
    z_bb_203:
    zT_1127 = 1;
    zT_1128 = (unsigned int)zT_1127;
    zT_1129 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_1128)), 32u);
    zT_1130 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_1128)), 32u);
    zT_1132 = zT_1130 == (unsigned int)(0);
    if (!(zT_1132)) { pal_trap(); }
    bi = zT_1129;
    goto z_bb_200;
    z_bb_204:
    zT_1112 = hp2 < (unsigned int)(510);
    goto z_bb_206;
    z_bb_205:
    zT_1112 = 0;
    goto z_bb_206;
    z_bb_206:
    if (zT_1112) goto z_bb_201; else goto z_bb_202;
    z_bb_207:
    zT_1140 = hext.len;
    if ((unsigned char)(hx < zT_1140)) goto z_bb_211; else goto z_bb_212;
    z_bb_208:
    zT_1145 = hext.ptr;
    zT_1146 = hext.len;
    zT_1147 = hx < zT_1146;
    if (!(zT_1147)) { pal_trap(); }
    zT_1148 = zT_1145[hx];
    zT_1150 = hp2 < (unsigned int)(512);
    if (!(zT_1150)) { pal_trap(); }
    hpath[hp2] = zT_1148;
    zT_1151 = 1;
    zT_1152 = (unsigned int)zT_1151;
    zT_1153 = zig_wrap_add_u(((zu64)(hp2)), ((zu64)(zT_1152)), 32u);
    zT_1154 = zig_overflow_flag_add_u(((zu64)(hp2)), ((zu64)(zT_1152)), 32u);
    zT_1156 = zT_1154 == (unsigned int)(0);
    if (!(zT_1156)) { pal_trap(); }
    hp2 = zT_1153;
    goto z_bb_210;
    z_bb_209:
    zT_1168 = 0;
    zT_1169 = (unsigned char*)((unsigned char*)hpath) + zT_1168;
    zT_1170 = hp2 - zT_1168;
    zT_1171 = (unsigned int)zT_1168 <= hp2;
    if (!(zT_1171)) { pal_trap(); }
    zT_1172 = hp2 <= (unsigned int)(512);
    if (!(zT_1172)) { pal_trap(); }
    zT_1173.ptr = (unsigned char*)zT_1169;
    zT_1173.len = zT_1170;
    zT_1164 = zT_1173;
    zT_1175 = zF_39FE21EF_fileOpen(zT_1164, (int)(0));
    fd2 = zT_1175;
    if ((unsigned char)(fd2 == (unsigned int)(4294967295u))) goto z_bb_214; else goto z_bb_215;
    z_bb_210:
    zT_1157 = 1;
    zT_1158 = (unsigned int)zT_1157;
    zT_1159 = zig_wrap_add_u(((zu64)(hx)), ((zu64)(zT_1158)), 32u);
    zT_1160 = zig_overflow_flag_add_u(((zu64)(hx)), ((zu64)(zT_1158)), 32u);
    zT_1162 = zT_1160 == (unsigned int)(0);
    if (!(zT_1162)) { pal_trap(); }
    hx = zT_1159;
    goto z_bb_207;
    z_bb_211:
    zT_1142 = hp2 < (unsigned int)(511);
    goto z_bb_213;
    z_bb_212:
    zT_1142 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_1142) goto z_bb_208; else goto z_bb_209;
    z_bb_214:
    zT_1179 = "error: cannot open output file\n";
    zT_1181 = 31;
    zT_1180.ptr = (unsigned char*)zT_1179;
    zT_1180.len = zT_1181;
    emsg2 = zT_1180;
    zT_1182 = emsg2;
    zF_E4B2EF19_stderr_write(zT_1182);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_215;
    z_bb_215:
    zig_poison_fill((void*)&zT_1186, (unsigned int)sizeof zT_1186);
    hw2 = zT_1186;
    zT_1187 = fd2;
    zT_1188 = zF_E00097E1_bufferedWriterInitF(zT_1187);
    hw2 = zT_1188;
    emitter.writer = hw2;
    zT_1190 = m.imports_start;
    zT_1191 = (unsigned int)zT_1190;
    dep_start = zT_1191;
    zT_1193 = m.import_count;
    zT_1194 = (unsigned int)zT_1193;
    zT_1195 = zig_wrap_add_u(((zu64)(dep_start)), ((zu64)(zT_1194)), 32u);
    zT_1196 = zig_overflow_flag_add_u(((zu64)(dep_start)), ((zu64)(zT_1194)), 32u);
    zT_1198 = zT_1196 == (unsigned int)(0);
    if (!(zT_1198)) { pal_trap(); }
    dep_end = zT_1195;
    zT_1200 = ctx->module_reg;
    zT_1201 = zT_1200->import_edges_items;
    zT_1202 = zT_1201 + dep_start;
    zT_1203 = dep_end - dep_start;
    zT_1204 = dep_start <= dep_end;
    if (!(zT_1204)) { pal_trap(); }
    zT_1205.ptr = (unsigned int*)zT_1202;
    zT_1205.len = zT_1203;
    dep_ids = zT_1205;
    zT_1207 = m.c_includes;
    zT_1208 = zT_1207.items;
    zT_1209 = m.c_includes;
    zT_1210 = zT_1209.len;
    zT_1211 = 0;
    zT_1212 = zT_1208 + zT_1211;
    zT_1213 = zT_1210 - zT_1211;
    zT_1214 = (unsigned int)zT_1211 <= zT_1210;
    if (!(zT_1214)) { pal_trap(); }
    zT_1215.ptr = (unsigned int*)zT_1212;
    zT_1215.len = zT_1213;
    m_c_incs = zT_1215;
    zT_1220 = ctx->alloc;
    zT_1217 = &zT_1220->emission;
    zT_1222 = 4;
    zT_1224 = mods.len;
    zT_1225 = zig_wrap_mul_u(((zu64)(zT_1222)), ((zu64)(zT_1224)), 32u);
    zT_1226 = zig_overflow_flag_mul_u(((zu64)(zT_1222)), ((zu64)(zT_1224)), 32u);
    zT_1228 = zT_1226 == (unsigned int)(0);
    if (!(zT_1228)) { pal_trap(); }
    zT_1218 = zT_1225;
    zT_1230 = zF_1395EB68_sandAlloc(zT_1217, zT_1218, (unsigned int)(4));
    zT_1231 = zT_1230.is_error;
    if (zT_1231) goto z_bb_216; else goto z_bb_217;
    z_bb_216:
    pal_trap();
    z_bb_217:
    zT_1232 = zT_1230.data.payload;
    goto z_bb_218;
    z_bb_218:
    inc_raw = zT_1232;
    zT_1235 = (unsigned int*)inc_raw;
    inc_arr = zT_1235;
    zT_1237 = 0;
    inc_n = zT_1237;
    zT_1239 = 0;
    di0 = zT_1239;
    goto z_bb_219;
    z_bb_219:
    zT_1241 = dep_ids.len;
    if ((unsigned char)(di0 < zT_1241)) goto z_bb_220; else goto z_bb_221;
    z_bb_220:
    zT_1244 = dep_ids.ptr;
    zT_1245 = dep_ids.len;
    zT_1246 = di0 < zT_1245;
    if (!(zT_1246)) { pal_trap(); }
    zT_1247 = zT_1244[di0];
    dd0 = zT_1247;
    zT_1248 = m.id;
    if ((unsigned char)(dd0 == zT_1248)) goto z_bb_223; else goto z_bb_224;
    z_bb_221:
    zT_1282 = 0;
    vd0 = zT_1282;
    goto z_bb_235;
    z_bb_222:
    zT_1276 = 1;
    zT_1277 = zig_wrap_add_u(((zu64)(di0)), ((zu64)(zT_1276)), 32u);
    zT_1278 = zig_overflow_flag_add_u(((zu64)(di0)), ((zu64)(zT_1276)), 32u);
    zT_1280 = zT_1278 == (unsigned int)(0);
    if (!(zT_1280)) { pal_trap(); }
    di0 = zT_1277;
    goto z_bb_219;
    z_bb_223:
    goto z_bb_222;
    z_bb_224:
    zT_1250 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_1251 = dd0;
    zT_1253 = zF_F3EE5998_u32ToU32MapGet(zT_1250, zT_1251);
    zT_1254 = zT_1253.has_value;
    if ((unsigned char)(!zT_1254)) goto z_bb_225; else goto z_bb_226;
    z_bb_225:
    goto z_bb_222;
    z_bb_226:
    zT_1257 = 0;
    dup0 = zT_1257;
    zT_1259 = 0;
    dj0 = zT_1259;
    goto z_bb_227;
    z_bb_227:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_228; else goto z_bb_229;
    z_bb_228:
    zT_1261 = inc_arr[dj0];
    if ((unsigned char)(zT_1261 == dd0)) goto z_bb_231; else goto z_bb_232;
    z_bb_229:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_233; else goto z_bb_234;
    z_bb_230:
    zT_1264 = 1;
    zT_1265 = zig_wrap_add_u(((zu64)(dj0)), ((zu64)(zT_1264)), 32u);
    zT_1266 = zig_overflow_flag_add_u(((zu64)(dj0)), ((zu64)(zT_1264)), 32u);
    zT_1268 = zT_1266 == (unsigned int)(0);
    if (!(zT_1268)) { pal_trap(); }
    dj0 = zT_1265;
    goto z_bb_227;
    z_bb_231:
    zT_1263 = 1;
    dup0 = zT_1263;
    goto z_bb_229;
    z_bb_232:
    goto z_bb_230;
    z_bb_233:
    goto z_bb_222;
    z_bb_234:
    inc_arr[inc_n] = dd0;
    zT_1271 = 1;
    zT_1272 = zig_wrap_add_u(((zu64)(inc_n)), ((zu64)(zT_1271)), 32u);
    zT_1273 = zig_overflow_flag_add_u(((zu64)(inc_n)), ((zu64)(zT_1271)), 32u);
    zT_1275 = zT_1273 == (unsigned int)(0);
    if (!(zT_1275)) { pal_trap(); }
    inc_n = zT_1272;
    goto z_bb_222;
    z_bb_235:
    zT_1284 = mods.len;
    if ((unsigned char)(vd0 < zT_1284)) goto z_bb_236; else goto z_bb_237;
    z_bb_236:
    zT_1287 = mods.ptr;
    zT_1288 = mods.len;
    zT_1289 = vd0 < zT_1288;
    if (!(zT_1289)) { pal_trap(); }
    zT_1290 = zT_1287[vd0];
    zT_1291 = zT_1290.id;
    vdd0 = zT_1291;
    zT_1292 = m.id;
    if ((unsigned char)(vdd0 == zT_1292)) goto z_bb_239; else goto z_bb_240;
    z_bb_237:
    zT_1342 = 0;
    zT_1343 = inc_arr + zT_1342;
    zT_1344 = inc_n - zT_1342;
    zT_1345 = (unsigned int)zT_1342 <= inc_n;
    if (!(zT_1345)) { pal_trap(); }
    zT_1346.ptr = (unsigned int*)zT_1343;
    zT_1346.len = zT_1344;
    inc_slice = zT_1346;
    zT_1347 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1348 = m.id;
    zT_1349 = base;
    zT_1350 = m_c_incs;
    zT_1351 = inc_slice;
    zT_1352 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1347, zT_1348, zT_1349, zT_1350, zT_1351, zT_1352);
    zT_1356 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1355 = &zT_1356->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1355);
    zT_1358 = fd2;
    zF_B30B1D79_fileClose(zT_1358);
    zT_1360 = "FINAL_FLUSH\n";
    zT_1362 = 12;
    zT_1361.ptr = (unsigned char*)zT_1360;
    zT_1361.len = zT_1362;
    ff_m = zT_1361;
    zT_1363 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1363);
    zig_poison_fill((void*)&zT_1365, (unsigned int)sizeof zT_1365);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1365[_i];
        _i++;
    }
}
    zT_1367 = 0;
    cp2 = zT_1367;
    zT_1369 = 0;
    ci2 = zT_1369;
    goto z_bb_253;
    z_bb_238:
    zT_1336 = 1;
    zT_1337 = zig_wrap_add_u(((zu64)(vd0)), ((zu64)(zT_1336)), 32u);
    zT_1338 = zig_overflow_flag_add_u(((zu64)(vd0)), ((zu64)(zT_1336)), 32u);
    zT_1340 = zT_1338 == (unsigned int)(0);
    if (!(zT_1340)) { pal_trap(); }
    vd0 = zT_1337;
    goto z_bb_235;
    z_bb_239:
    goto z_bb_238;
    z_bb_240:
    zT_1294 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_1295 = vdd0;
    zT_1297 = zF_F3EE5998_u32ToU32MapGet(zT_1294, zT_1295);
    zT_1298 = zT_1297.has_value;
    if ((unsigned char)(!zT_1298)) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    goto z_bb_238;
    z_bb_242:
    zT_1300 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_1303 = m.id;
    zT_1304 = 65536;
    zT_1305 = zig_wrap_mul_u(((zu64)(zT_1303)), ((zu64)(zT_1304)), 32u);
    zT_1306 = zig_overflow_flag_mul_u(((zu64)(zT_1303)), ((zu64)(zT_1304)), 32u);
    zT_1308 = zT_1306 == (unsigned int)(0);
    if (!(zT_1308)) { pal_trap(); }
    zT_1309 = zig_wrap_add_u(((zu64)(zT_1305)), ((zu64)(vdd0)), 32u);
    zT_1310 = zig_overflow_flag_add_u(((zu64)(zT_1305)), ((zu64)(vdd0)), 32u);
    zT_1312 = zT_1310 == (unsigned int)(0);
    if (!(zT_1312)) { pal_trap(); }
    zT_1301 = zT_1309;
    zT_1313 = zF_F3EE5998_u32ToU32MapGet(zT_1300, zT_1301);
    zT_1314 = zT_1313.has_value;
    if ((unsigned char)(!zT_1314)) goto z_bb_243; else goto z_bb_244;
    z_bb_243:
    goto z_bb_238;
    z_bb_244:
    zT_1317 = 0;
    dup1 = zT_1317;
    zT_1319 = 0;
    dj1 = zT_1319;
    goto z_bb_245;
    z_bb_245:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_1321 = inc_arr[dj1];
    if ((unsigned char)(zT_1321 == vdd0)) goto z_bb_249; else goto z_bb_250;
    z_bb_247:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_251; else goto z_bb_252;
    z_bb_248:
    zT_1324 = 1;
    zT_1325 = zig_wrap_add_u(((zu64)(dj1)), ((zu64)(zT_1324)), 32u);
    zT_1326 = zig_overflow_flag_add_u(((zu64)(dj1)), ((zu64)(zT_1324)), 32u);
    zT_1328 = zT_1326 == (unsigned int)(0);
    if (!(zT_1328)) { pal_trap(); }
    dj1 = zT_1325;
    goto z_bb_245;
    z_bb_249:
    zT_1323 = 1;
    dup1 = zT_1323;
    goto z_bb_247;
    z_bb_250:
    goto z_bb_248;
    z_bb_251:
    goto z_bb_238;
    z_bb_252:
    inc_arr[inc_n] = vdd0;
    zT_1331 = 1;
    zT_1332 = zig_wrap_add_u(((zu64)(inc_n)), ((zu64)(zT_1331)), 32u);
    zT_1333 = zig_overflow_flag_add_u(((zu64)(inc_n)), ((zu64)(zT_1331)), 32u);
    zT_1335 = zT_1333 == (unsigned int)(0);
    if (!(zT_1335)) { pal_trap(); }
    inc_n = zT_1332;
    goto z_bb_238;
    z_bb_253:
    zT_1371 = od.len;
    if ((unsigned char)(ci2 < zT_1371)) goto z_bb_257; else goto z_bb_258;
    z_bb_254:
    zT_1376 = od.ptr;
    zT_1377 = od.len;
    zT_1378 = ci2 < zT_1377;
    if (!(zT_1378)) { pal_trap(); }
    zT_1379 = zT_1376[ci2];
    zT_1381 = cp2 < (unsigned int)(512);
    if (!(zT_1381)) { pal_trap(); }
    cpath[cp2] = zT_1379;
    zT_1382 = 1;
    zT_1383 = (unsigned int)zT_1382;
    zT_1384 = zig_wrap_add_u(((zu64)(cp2)), ((zu64)(zT_1383)), 32u);
    zT_1385 = zig_overflow_flag_add_u(((zu64)(cp2)), ((zu64)(zT_1383)), 32u);
    zT_1387 = zT_1385 == (unsigned int)(0);
    if (!(zT_1387)) { pal_trap(); }
    cp2 = zT_1384;
    goto z_bb_256;
    z_bb_255:
    zT_1394 = 47;
    zT_1396 = cp2 < (unsigned int)(512);
    if (!(zT_1396)) { pal_trap(); }
    cpath[cp2] = zT_1394;
    zT_1397 = 1;
    zT_1398 = (unsigned int)zT_1397;
    zT_1399 = zig_wrap_add_u(((zu64)(cp2)), ((zu64)(zT_1398)), 32u);
    zT_1400 = zig_overflow_flag_add_u(((zu64)(cp2)), ((zu64)(zT_1398)), 32u);
    zT_1402 = zT_1400 == (unsigned int)(0);
    if (!(zT_1402)) { pal_trap(); }
    cp2 = zT_1399;
    zT_1404 = 0;
    cbi = zT_1404;
    goto z_bb_260;
    z_bb_256:
    zT_1388 = 1;
    zT_1389 = (unsigned int)zT_1388;
    zT_1390 = zig_wrap_add_u(((zu64)(ci2)), ((zu64)(zT_1389)), 32u);
    zT_1391 = zig_overflow_flag_add_u(((zu64)(ci2)), ((zu64)(zT_1389)), 32u);
    zT_1393 = zT_1391 == (unsigned int)(0);
    if (!(zT_1393)) { pal_trap(); }
    ci2 = zT_1390;
    goto z_bb_253;
    z_bb_257:
    zT_1373 = cp2 < (unsigned int)(510);
    goto z_bb_259;
    z_bb_258:
    zT_1373 = 0;
    goto z_bb_259;
    z_bb_259:
    if (zT_1373) goto z_bb_254; else goto z_bb_255;
    z_bb_260:
    zT_1406 = base.len;
    if ((unsigned char)(cbi < zT_1406)) goto z_bb_264; else goto z_bb_265;
    z_bb_261:
    zT_1411 = base.ptr;
    zT_1412 = base.len;
    zT_1413 = cbi < zT_1412;
    if (!(zT_1413)) { pal_trap(); }
    zT_1414 = zT_1411[cbi];
    zT_1416 = cp2 < (unsigned int)(512);
    if (!(zT_1416)) { pal_trap(); }
    cpath[cp2] = zT_1414;
    zT_1417 = 1;
    zT_1418 = (unsigned int)zT_1417;
    zT_1419 = zig_wrap_add_u(((zu64)(cp2)), ((zu64)(zT_1418)), 32u);
    zT_1420 = zig_overflow_flag_add_u(((zu64)(cp2)), ((zu64)(zT_1418)), 32u);
    zT_1422 = zT_1420 == (unsigned int)(0);
    if (!(zT_1422)) { pal_trap(); }
    cp2 = zT_1419;
    goto z_bb_263;
    z_bb_262:
    zT_1430 = ".c";
    zT_1432 = 2;
    zT_1431.ptr = (unsigned char*)zT_1430;
    zT_1431.len = zT_1432;
    cext = zT_1431;
    zT_1434 = 0;
    cx = zT_1434;
    goto z_bb_267;
    z_bb_263:
    zT_1423 = 1;
    zT_1424 = (unsigned int)zT_1423;
    zT_1425 = zig_wrap_add_u(((zu64)(cbi)), ((zu64)(zT_1424)), 32u);
    zT_1426 = zig_overflow_flag_add_u(((zu64)(cbi)), ((zu64)(zT_1424)), 32u);
    zT_1428 = zT_1426 == (unsigned int)(0);
    if (!(zT_1428)) { pal_trap(); }
    cbi = zT_1425;
    goto z_bb_260;
    z_bb_264:
    zT_1408 = cp2 < (unsigned int)(510);
    goto z_bb_266;
    z_bb_265:
    zT_1408 = 0;
    goto z_bb_266;
    z_bb_266:
    if (zT_1408) goto z_bb_261; else goto z_bb_262;
    z_bb_267:
    zT_1436 = cext.len;
    if ((unsigned char)(cx < zT_1436)) goto z_bb_271; else goto z_bb_272;
    z_bb_268:
    zT_1441 = cext.ptr;
    zT_1442 = cext.len;
    zT_1443 = cx < zT_1442;
    if (!(zT_1443)) { pal_trap(); }
    zT_1444 = zT_1441[cx];
    zT_1446 = cp2 < (unsigned int)(512);
    if (!(zT_1446)) { pal_trap(); }
    cpath[cp2] = zT_1444;
    zT_1447 = 1;
    zT_1448 = (unsigned int)zT_1447;
    zT_1449 = zig_wrap_add_u(((zu64)(cp2)), ((zu64)(zT_1448)), 32u);
    zT_1450 = zig_overflow_flag_add_u(((zu64)(cp2)), ((zu64)(zT_1448)), 32u);
    zT_1452 = zT_1450 == (unsigned int)(0);
    if (!(zT_1452)) { pal_trap(); }
    cp2 = zT_1449;
    goto z_bb_270;
    z_bb_269:
    zT_1464 = 0;
    zT_1465 = (unsigned char*)((unsigned char*)cpath) + zT_1464;
    zT_1466 = cp2 - zT_1464;
    zT_1467 = (unsigned int)zT_1464 <= cp2;
    if (!(zT_1467)) { pal_trap(); }
    zT_1468 = cp2 <= (unsigned int)(512);
    if (!(zT_1468)) { pal_trap(); }
    zT_1469.ptr = (unsigned char*)zT_1465;
    zT_1469.len = zT_1466;
    zT_1460 = zT_1469;
    zT_1471 = zF_39FE21EF_fileOpen(zT_1460, (int)(0));
    cfd = zT_1471;
    if ((unsigned char)(cfd == (unsigned int)(4294967295u))) goto z_bb_274; else goto z_bb_275;
    z_bb_270:
    zT_1453 = 1;
    zT_1454 = (unsigned int)zT_1453;
    zT_1455 = zig_wrap_add_u(((zu64)(cx)), ((zu64)(zT_1454)), 32u);
    zT_1456 = zig_overflow_flag_add_u(((zu64)(cx)), ((zu64)(zT_1454)), 32u);
    zT_1458 = zT_1456 == (unsigned int)(0);
    if (!(zT_1458)) { pal_trap(); }
    cx = zT_1455;
    goto z_bb_267;
    z_bb_271:
    zT_1438 = cp2 < (unsigned int)(511);
    goto z_bb_273;
    z_bb_272:
    zT_1438 = 0;
    goto z_bb_273;
    z_bb_273:
    if (zT_1438) goto z_bb_268; else goto z_bb_269;
    z_bb_274:
    zT_1475 = "error: cannot open output file\n";
    zT_1477 = 31;
    zT_1476.ptr = (unsigned char*)zT_1475;
    zT_1476.len = zT_1477;
    emsg3 = zT_1476;
    zT_1478 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1478);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_275;
    z_bb_275:
    zig_poison_fill((void*)&zT_1482, (unsigned int)sizeof zT_1482);
    cw = zT_1482;
    zT_1483 = cfd;
    zT_1484 = zF_E00097E1_bufferedWriterInitF(zT_1483);
    cw = zT_1484;
    emitter.writer = cw;
    zT_1485 = ctx->cli;
    zT_1486 = zT_1485.debug;
    if (zT_1486) goto z_bb_276; else goto z_bb_277;
    z_bb_276:
    zT_1488 = ctx->source_man;
    zT_1489 = m.source_file_id;
    zT_1492 = zF_B7076474_sourceManagerGetFil(zT_1488, zT_1489);
    dbg_src_file = zT_1492;
    zT_1493 = &ctx->debug_map;
    zT_1494 = dbg_src_file;
    zT_1495 = base;
    zF_FFA3F32B_debugMapWriterBegin(zT_1493, zT_1494, zT_1495);
    goto z_bb_277;
    z_bb_277:
    zT_1497 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1498 = m.id;
    zT_1499 = base;
    zF_7B8B9B90_emitModuleFile(zT_1497, zT_1498, zT_1499);
    zT_1502 = ctx->cli;
    zT_1503 = zT_1502.debug;
    if (zT_1503) goto z_bb_278; else goto z_bb_279;
    z_bb_278:
    zT_1504 = &ctx->debug_map;
    zF_B7665FFF_debugMapWriterEndLi(zT_1504);
    goto z_bb_279;
    z_bb_279:
    zT_1507 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1506 = &zT_1507->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1506);
    zT_1509 = cfd;
    zF_B30B1D79_fileClose(zT_1509);
    zT_1511 = "FINAL_FLUSH\n";
    zT_1513 = 12;
    zT_1512.ptr = (unsigned char*)zT_1511;
    zT_1512.len = zT_1513;
    ff2_m = zT_1512;
    zT_1514 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1514);
    goto z_bb_181;
    z_bb_280:
    zT_1523 = &ctx->debug_map;
    zT_1532 = ctx->alloc;
    zT_1524 = &zT_1532->emission;
    zT_1534 = ctx->debug_symbols;
    zT_1535 = zT_1534.items;
    zT_1536 = ctx->debug_symbols;
    zT_1537 = zT_1536.len;
    zT_1538 = 0;
    zT_1539 = zT_1535 + zT_1538;
    zT_1540 = zT_1537 - zT_1538;
    zT_1541 = (unsigned int)zT_1538 <= zT_1537;
    if (!(zT_1541)) { pal_trap(); }
    zT_1542.ptr = (zT_1001656C_DebugSymbol*)zT_1539;
    zT_1542.len = zT_1540;
    zT_1525 = zT_1542;
    zT_1526 = ctx->source_man;
    zT_1527 = (zT_CEC2984A_NameMangler*)&mangler;
    zT_1528 = ctx->interner;
    zT_1529 = ctx->module_reg;
    zT_1530 = ctx->typereg;
    zF_48EEEA4F_debugMapWriterClose(zT_1523, zT_1524, zT_1525, zT_1526, zT_1527, zT_1528, zT_1529, zT_1530);
    zT_1548 = &ctx->debug_spans;
    zF_BE98E387_debugSpanStoreClose(zT_1548);
    goto z_bb_281;
    z_bb_281:
    zT_1550 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1551 = od;
    zT_1555 = ctx->cli;
    zT_1552 = zT_1555.target_is_windows;
    zT_1557 = ctx->cli;
    zT_1553 = zT_1557.target_win_profile;
    zF_A62DB57E_emitBuildScripts(zT_1550, zT_1551, zT_1552, zT_1553);
    zT_1559 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1559);
    zT_1561 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1561);
    return;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_074080EA_WinProfile zT_36;
    int zT_38;
    int zT_40;
    int zT_41;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    unsigned char* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    unsigned char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    unsigned char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    int zT_204;
    unsigned char* zT_205;
    unsigned char* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_210;
    int zT_211;
    unsigned char zT_213;
    unsigned char* zT_214;
    int zT_215;
    unsigned int zT_216;
    unsigned char zT_217;
    unsigned char zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned char zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned char zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char zT_232;
    unsigned char zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned char zT_236;
    int zT_237;
    int zT_238;
    int zT_239;
    unsigned int zT_240;
    unsigned char zT_242;
    unsigned char* zT_244;
    int zT_245;
    unsigned char* zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    unsigned char zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned char* zT_251;
    unsigned int zT_252;
    int zT_253;
    unsigned char* zT_254;
    unsigned char zT_255;
    unsigned int zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    unsigned int zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned char* zT_262;
    unsigned int zT_263;
    int zT_264;
    unsigned char* zT_265;
    unsigned char zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char zT_272;
    unsigned char zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned char zT_276;
    int zT_277;
    int zT_278;
    int zT_279;
    unsigned int zT_280;
    unsigned char zT_282;
    unsigned char* zT_284;
    int zT_285;
    unsigned char* zT_286;
    unsigned int zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    unsigned char zT_290;
    unsigned char zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned char zT_294;
    int zT_295;
    int zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned char zT_300;
    unsigned char* zT_302;
    int zT_303;
    unsigned char* zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned char zT_309;
    unsigned char zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned char zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    unsigned char zT_317;
    unsigned char zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned char zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned char zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned char zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned char zT_333;
    unsigned char zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned char zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned char zT_341;
    int zT_342;
    int zT_343;
    int zT_344;
    unsigned int zT_345;
    unsigned char zT_347;
    unsigned char* zT_349;
    int zT_350;
    unsigned char* zT_351;
    zT_CAF40AAB_ColorMode zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned char zT_355;
    int zT_356;
    int zT_357;
    int zT_358;
    unsigned int zT_359;
    unsigned char zT_361;
    unsigned char* zT_363;
    int zT_364;
    unsigned char* zT_365;
    zT_A4FB690E_ErrorFormat zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned char zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned char zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned char zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned char zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned char zT_385;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_388;
    unsigned char zT_389;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned char zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned char zT_398;
    unsigned char zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned char zT_402;
    int zT_403;
    int zT_404;
    int zT_405;
    unsigned int zT_406;
    unsigned char zT_408;
    unsigned char zT_410;
    unsigned int zT_411;
    int zT_412;
    unsigned char* zT_414;
    int zT_415;
    unsigned char* zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned char zT_422;
    unsigned int zT_423;
    int zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    unsigned char zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_431;
    unsigned char zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned char zT_436;
    int zT_440;
    int zT_441;
    unsigned int zT_442;
    unsigned char zT_444;
    unsigned char* zT_447;
    int zT_448;
    int zT_449;
    int zT_450;
    unsigned int zT_451;
    unsigned char zT_453;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_457;
    int zT_458;
    unsigned char zT_460;
    unsigned char* zT_461;
    int zT_462;
    unsigned int zT_463;
    unsigned char zT_464;
    unsigned char zT_465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_469;
    unsigned char zT_470;
    int zT_473;
    int zT_474;
    int zT_475;
    unsigned int zT_476;
    unsigned char zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_480;
    unsigned char zT_481;
    int zT_484;
    int zT_485;
    int zT_486;
    unsigned int zT_487;
    unsigned char zT_489;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned char zT_492;
    int zT_493;
    int zT_494;
    int zT_495;
    unsigned int zT_496;
    unsigned char zT_498;
    unsigned char* zT_500;
    int zT_501;
    unsigned char* zT_502;
    unsigned char zT_503;
    unsigned char zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_507;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_508;
    unsigned char zT_509;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned char zT_513;
    unsigned char* zT_515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_516;
    unsigned char* zT_517;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_518;
    int zT_519;
    int zT_520;
    int zT_521;
    unsigned int zT_522;
    unsigned char zT_524;
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_205, (unsigned int)sizeof zT_205);
    zig_poison_fill((void*)&zT_208, (unsigned int)sizeof zT_208);
    zig_poison_fill((void*)&zT_223, (unsigned int)sizeof zT_223);
    zig_poison_fill((void*)&zT_228, (unsigned int)sizeof zT_228);
    zig_poison_fill((void*)&zT_232, (unsigned int)sizeof zT_232);
    zig_poison_fill((void*)&zT_236, (unsigned int)sizeof zT_236);
    zig_poison_fill((void*)&zT_246, (unsigned int)sizeof zT_246);
    zig_poison_fill((void*)&zT_247, (unsigned int)sizeof zT_247);
    zig_poison_fill((void*)&zT_249, (unsigned int)sizeof zT_249);
    zig_poison_fill((void*)&zT_258, (unsigned int)sizeof zT_258);
    zig_poison_fill((void*)&zT_260, (unsigned int)sizeof zT_260);
    zig_poison_fill((void*)&zT_269, (unsigned int)sizeof zT_269);
    zig_poison_fill((void*)&zT_272, (unsigned int)sizeof zT_272);
    zig_poison_fill((void*)&zT_276, (unsigned int)sizeof zT_276);
    zig_poison_fill((void*)&zT_286, (unsigned int)sizeof zT_286);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    zig_poison_fill((void*)&zT_290, (unsigned int)sizeof zT_290);
    zig_poison_fill((void*)&zT_294, (unsigned int)sizeof zT_294);
    zig_poison_fill((void*)&zT_304, (unsigned int)sizeof zT_304);
    zig_poison_fill((void*)&zT_305, (unsigned int)sizeof zT_305);
    zig_poison_fill((void*)&zT_309, (unsigned int)sizeof zT_309);
    zig_poison_fill((void*)&zT_313, (unsigned int)sizeof zT_313);
    zig_poison_fill((void*)&zT_317, (unsigned int)sizeof zT_317);
    zig_poison_fill((void*)&zT_321, (unsigned int)sizeof zT_321);
    zig_poison_fill((void*)&zT_325, (unsigned int)sizeof zT_325);
    zig_poison_fill((void*)&zT_329, (unsigned int)sizeof zT_329);
    zig_poison_fill((void*)&zT_333, (unsigned int)sizeof zT_333);
    zig_poison_fill((void*)&zT_337, (unsigned int)sizeof zT_337);
    zig_poison_fill((void*)&zT_341, (unsigned int)sizeof zT_341);
    zig_poison_fill((void*)&zT_351, (unsigned int)sizeof zT_351);
    zig_poison_fill((void*)&zT_352, (unsigned int)sizeof zT_352);
    zig_poison_fill((void*)&zT_355, (unsigned int)sizeof zT_355);
    zig_poison_fill((void*)&zT_365, (unsigned int)sizeof zT_365);
    zig_poison_fill((void*)&zT_366, (unsigned int)sizeof zT_366);
    zig_poison_fill((void*)&zT_369, (unsigned int)sizeof zT_369);
    zig_poison_fill((void*)&zT_373, (unsigned int)sizeof zT_373);
    zig_poison_fill((void*)&zT_377, (unsigned int)sizeof zT_377);
    zig_poison_fill((void*)&zT_381, (unsigned int)sizeof zT_381);
    zig_poison_fill((void*)&zT_385, (unsigned int)sizeof zT_385);
    zig_poison_fill((void*)&zT_389, (unsigned int)sizeof zT_389);
    zig_poison_fill((void*)&zT_394, (unsigned int)sizeof zT_394);
    zig_poison_fill((void*)&zT_398, (unsigned int)sizeof zT_398);
    zig_poison_fill((void*)&zT_402, (unsigned int)sizeof zT_402);
    zig_poison_fill((void*)&zT_416, (unsigned int)sizeof zT_416);
    zig_poison_fill((void*)&zT_417, (unsigned int)sizeof zT_417);
    zig_poison_fill((void*)&zT_432, (unsigned int)sizeof zT_432);
    zig_poison_fill((void*)&zT_436, (unsigned int)sizeof zT_436);
    zig_poison_fill((void*)&zT_454, (unsigned int)sizeof zT_454);
    zig_poison_fill((void*)&zT_455, (unsigned int)sizeof zT_455);
    zig_poison_fill((void*)&zT_470, (unsigned int)sizeof zT_470);
    zig_poison_fill((void*)&zT_481, (unsigned int)sizeof zT_481);
    zig_poison_fill((void*)&zT_492, (unsigned int)sizeof zT_492);
    zig_poison_fill((void*)&zT_502, (unsigned int)sizeof zT_502);
    zig_poison_fill((void*)&zT_503, (unsigned int)sizeof zT_503);
    zig_poison_fill((void*)&zT_509, (unsigned int)sizeof zT_509);
    zig_poison_fill((void*)&zT_513, (unsigned int)sizeof zT_513);
    zig_poison_fill((void*)&zT_516, (unsigned int)sizeof zT_516);
    zig_poison_fill((void*)&zT_518, (unsigned int)sizeof zT_518);
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_debug;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_d;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_9x;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nxt;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = 65536;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.debug = zT_22;
    zT_23 = 0;
    zT_9.test_mode = zT_23;
    zT_24 = 0;
    zT_9.sanity_test_mode = zT_24;
    zT_25 = 0;
    zT_9.track_memory = zT_25;
    zT_26 = 0;
    zT_9.no_null_check = zT_26;
    zT_27 = 0;
    zT_9.no_lifetime_check = zT_27;
    zT_28 = 0;
    zT_9.no_leak_check = zT_28;
    zT_29 = 1;
    zT_9.safe_checks = zT_29;
    zT_30 = 0;
    zT_9.warn_all = zT_30;
    zT_31 = 0;
    zT_9.warn_error = zT_31;
    zT_32 = 0;
    zT_9.show_markers = zT_32;
    zT_33 = 0;
    zT_9.include_count = zT_33;
    zT_34 = 0;
    zT_9.target_is_windows = zT_34;
    zT_36 = zT_074080EA_WinProfile_win9x;
    zT_9.target_win_profile = zT_36;
    cli = zT_9;
    zT_38 = zF_EEF840BE_argCount();
    argc = zT_38;
    zT_40 = 1;
    zT_41 = (int)zT_40;
    i = zT_41;
    zT_51 = "--dump-c89";
    zT_53 = 10;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    s_dump_c89 = zT_52;
    zT_55 = "--help";
    zT_57 = 6;
    zT_56.ptr = (unsigned char*)zT_55;
    zT_56.len = zT_57;
    s_help = zT_56;
    zT_59 = "--max-mem";
    zT_61 = 9;
    zT_60.ptr = (unsigned char*)zT_59;
    zT_60.len = zT_61;
    s_max_mem = zT_60;
    zT_63 = "--max-errors";
    zT_65 = 12;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    s_max_errors = zT_64;
    zT_67 = "--output-dir";
    zT_69 = 12;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    s_output_dir = zT_68;
    zT_71 = "--quiet";
    zT_73 = 7;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    s_quiet = zT_72;
    zT_75 = "--debug";
    zT_77 = 7;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    s_debug = zT_76;
    zT_79 = "-d";
    zT_81 = 2;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    s_d = zT_80;
    zT_83 = "--test";
    zT_85 = 6;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    s_test = zT_84;
    zT_87 = "--sanity-test";
    zT_89 = 13;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    s_sanity_test = zT_88;
    zT_91 = "--warnings-as-errors";
    zT_93 = 20;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    s_warnings = zT_92;
    zT_95 = "--color";
    zT_97 = 7;
    zT_96.ptr = (unsigned char*)zT_95;
    zT_96.len = zT_97;
    s_color = zT_96;
    zT_99 = "--error-format";
    zT_101 = 14;
    zT_100.ptr = (unsigned char*)zT_99;
    zT_100.len = zT_101;
    s_error_format = zT_100;
    zT_103 = "--track-memory";
    zT_105 = 14;
    zT_104.ptr = (unsigned char*)zT_103;
    zT_104.len = zT_105;
    s_track_memory = zT_104;
    zT_107 = "--no-null-check";
    zT_109 = 15;
    zT_108.ptr = (unsigned char*)zT_107;
    zT_108.len = zT_109;
    s_no_null = zT_108;
    zT_111 = "--no-lifetime-check";
    zT_113 = 19;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    s_no_lifetime = zT_112;
    zT_115 = "--no-leak-check";
    zT_117 = 15;
    zT_116.ptr = (unsigned char*)zT_115;
    zT_116.len = zT_117;
    s_no_leak = zT_116;
    zT_119 = "--warn-all";
    zT_121 = 10;
    zT_120.ptr = (unsigned char*)zT_119;
    zT_120.len = zT_121;
    s_warn_all = zT_120;
    zT_123 = "--warn-error";
    zT_125 = 12;
    zT_124.ptr = (unsigned char*)zT_123;
    zT_124.len = zT_125;
    s_warn_error = zT_124;
    zT_127 = "--markers";
    zT_129 = 9;
    zT_128.ptr = (unsigned char*)zT_127;
    zT_128.len = zT_129;
    s_markers = zT_128;
    zT_131 = "-I";
    zT_133 = 2;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    s_include = zT_132;
    zT_135 = "--lib-dir";
    zT_137 = 9;
    zT_136.ptr = (unsigned char*)zT_135;
    zT_136.len = zT_137;
    s_lib_dir = zT_136;
    zT_155 = "-m";
    zT_157 = 2;
    zT_156.ptr = (unsigned char*)zT_155;
    zT_156.len = zT_157;
    s_m = zT_156;
    zT_159 = "-e";
    zT_161 = 2;
    zT_160.ptr = (unsigned char*)zT_159;
    zT_160.len = zT_161;
    s_e = zT_160;
    zT_163 = "-o";
    zT_165 = 2;
    zT_164.ptr = (unsigned char*)zT_163;
    zT_164.len = zT_165;
    s_o = zT_164;
    zT_167 = "-q";
    zT_169 = 2;
    zT_168.ptr = (unsigned char*)zT_167;
    zT_168.len = zT_169;
    s_q = zT_168;
    zT_171 = "-W";
    zT_173 = 2;
    zT_172.ptr = (unsigned char*)zT_171;
    zT_172.len = zT_173;
    s_W = zT_172;
    zT_175 = "-osl";
    zT_177 = 4;
    zT_176.ptr = (unsigned char*)zT_175;
    zT_176.len = zT_177;
    s_osl = zT_176;
    zT_179 = "-osw";
    zT_181 = 4;
    zT_180.ptr = (unsigned char*)zT_179;
    zT_180.len = zT_181;
    s_osw = zT_180;
    zT_183 = "9x";
    zT_185 = 2;
    zT_184.ptr = (unsigned char*)zT_183;
    zT_184.len = zT_185;
    s_profile_9x = zT_184;
    zT_187 = "nt";
    zT_189 = 2;
    zT_188.ptr = (unsigned char*)zT_187;
    zT_188.len = zT_189;
    s_profile_nt = zT_188;
    zT_191 = "--target";
    zT_193 = 8;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    s_target = zT_192;
    zT_195 = "-fsafe";
    zT_197 = 6;
    zT_196.ptr = (unsigned char*)zT_195;
    zT_196.len = zT_197;
    s_fsafe = zT_196;
    zT_199 = "-ffast";
    zT_201 = 6;
    zT_200.ptr = (unsigned char*)zT_199;
    zT_200.len = zT_201;
    s_ffast = zT_200;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_204 = i;
    zT_205 = zF_70B5BFF1_argGet(zT_204);
    arg_ptr = zT_205;
    zT_207 = arg_ptr;
    zT_208 = zF_22D0470E_cstrToSlice(zT_207);
    arg = zT_208;
    zT_210 = arg.len;
    zT_211 = 0;
    if ((unsigned char)(zT_210 > (unsigned int)zT_211)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_214 = arg.ptr;
    zT_215 = 0;
    zT_216 = arg.len;
    zT_217 = (unsigned int)zT_215 < zT_216;
    if (!(zT_217)) { pal_trap(); }
    zT_218 = zT_214[zT_215];
    zT_213 = zT_218 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_213 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_213) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_221 = arg;
    zT_222 = s_help;
    zT_223 = zF_5FE51158_matchFlag(zT_221, zT_222);
    if (zT_223) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_519 = 1;
    zT_520 = (int)zT_519;
    zT_521 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_520)), 32u);
    zT_522 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_520)), 32u);
    zT_524 = zT_522 == (unsigned int)(0);
    if (!(zT_524)) { pal_trap(); }
    i = zT_521;
    goto z_bb_4;
    z_bb_10:
    zT_517 = arg_ptr;
    zT_518 = zF_22D0470E_cstrToSlice(zT_517);
    cli.input_file = zT_518;
    goto z_bb_9;
    z_bb_11:
    zF_9D45DFBF_printUsage();
    zF_CDED1A85_exit((unsigned char)(0));
    return cli;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_226 = arg;
    zT_227 = s_dump_c89;
    zT_228 = zF_5FE51158_matchFlag(zT_226, zT_227);
    if (zT_228) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_230 = arg;
    zT_231 = s_max_mem;
    zT_232 = zF_5FE51158_matchFlag(zT_230, zT_231);
    if (zT_232) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_234 = arg;
    zT_235 = s_m;
    zT_236 = zF_5FE51158_matchFlag(zT_234, zT_235);
    zT_233 = zT_236;
    goto z_bb_19;
    z_bb_18:
    zT_233 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_233) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_237 = 1;
    zT_238 = (int)zT_237;
    zT_239 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_238)), 32u);
    zT_240 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_238)), 32u);
    zT_242 = zT_240 == (unsigned int)(0);
    if (!(zT_242)) { pal_trap(); }
    i = zT_239;
    if ((unsigned char)(i < argc)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_248 = arg;
    zT_249 = zF_FBF91F7E_matchMMFlag(zT_248);
    if (zT_249) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    zT_245 = i;
    zT_246 = zF_70B5BFF1_argGet(zT_245);
    zT_244 = zT_246;
    zT_247 = zF_6CF11065_parseSize(zT_244);
    cli.max_mem = zT_247;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_251 = arg.ptr;
    zT_252 = arg.len;
    zT_253 = 3;
    zT_254 = zT_251 + zT_253;
    zT_255 = (unsigned int)zT_253 <= zT_252;
    if (!(zT_255)) { pal_trap(); }
    zT_256 = zT_252 - zT_253;
    zT_257.ptr = (unsigned char*)zT_254;
    zT_257.len = zT_256;
    zT_250 = zT_257;
    zT_258 = zF_B9231BB9_parseMMBytes(zT_250);
    cli.max_mem = zT_258;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_259 = arg;
    zT_260 = zF_C4E3C361_matchSFlag(zT_259);
    if (zT_260) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_262 = arg.ptr;
    zT_263 = arg.len;
    zT_264 = 2;
    zT_265 = zT_262 + zT_264;
    zT_266 = (unsigned int)zT_264 <= zT_263;
    if (!(zT_266)) { pal_trap(); }
    zT_267 = zT_263 - zT_264;
    zT_268.ptr = (unsigned char*)zT_265;
    zT_268.len = zT_267;
    zT_261 = zT_268;
    zT_269 = zF_153C3795_parseSLevel(zT_261);
    cli.spill_level = zT_269;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_270 = arg;
    zT_271 = s_max_errors;
    zT_272 = zF_5FE51158_matchFlag(zT_270, zT_271);
    if (zT_272) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_274 = arg;
    zT_275 = s_e;
    zT_276 = zF_5FE51158_matchFlag(zT_274, zT_275);
    zT_273 = zT_276;
    goto z_bb_33;
    z_bb_32:
    zT_273 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_273) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_277 = 1;
    zT_278 = (int)zT_277;
    zT_279 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_278)), 32u);
    zT_280 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_278)), 32u);
    zT_282 = zT_280 == (unsigned int)(0);
    if (!(zT_282)) { pal_trap(); }
    i = zT_279;
    if ((unsigned char)(i < argc)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_29;
    z_bb_36:
    zT_288 = arg;
    zT_289 = s_output_dir;
    zT_290 = zF_5FE51158_matchFlag(zT_288, zT_289);
    if (zT_290) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    zT_285 = i;
    zT_286 = zF_70B5BFF1_argGet(zT_285);
    zT_284 = zT_286;
    zT_287 = zF_16BBA09E_parseU32(zT_284);
    cli.max_errors = zT_287;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_292 = arg;
    zT_293 = s_o;
    zT_294 = zF_5FE51158_matchFlag(zT_292, zT_293);
    zT_291 = zT_294;
    goto z_bb_41;
    z_bb_40:
    zT_291 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_291) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_295 = 1;
    zT_296 = (int)zT_295;
    zT_297 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_296)), 32u);
    zT_298 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_296)), 32u);
    zT_300 = zT_298 == (unsigned int)(0);
    if (!(zT_300)) { pal_trap(); }
    i = zT_297;
    if ((unsigned char)(i < argc)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_35;
    z_bb_44:
    zT_307 = arg;
    zT_308 = s_quiet;
    zT_309 = zF_5FE51158_matchFlag(zT_307, zT_308);
    if (zT_309) goto z_bb_48; else goto z_bb_47;
    z_bb_45:
    zT_303 = i;
    zT_304 = zF_70B5BFF1_argGet(zT_303);
    zT_302 = zT_304;
    zT_305 = zF_22D0470E_cstrToSlice(zT_302);
    cli.output_dir = zT_305;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_46;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_311 = arg;
    zT_312 = s_q;
    zT_313 = zF_5FE51158_matchFlag(zT_311, zT_312);
    zT_310 = zT_313;
    goto z_bb_49;
    z_bb_48:
    zT_310 = 1;
    goto z_bb_49;
    z_bb_49:
    if (zT_310) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.quiet = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_43;
    z_bb_52:
    zT_315 = arg;
    zT_316 = s_debug;
    zT_317 = zF_5FE51158_matchFlag(zT_315, zT_316);
    if (zT_317) goto z_bb_54; else goto z_bb_53;
    z_bb_53:
    zT_319 = arg;
    zT_320 = s_d;
    zT_321 = zF_5FE51158_matchFlag(zT_319, zT_320);
    zT_318 = zT_321;
    goto z_bb_55;
    z_bb_54:
    zT_318 = 1;
    goto z_bb_55;
    z_bb_55:
    if (zT_318) goto z_bb_56; else goto z_bb_58;
    z_bb_56:
    cli.debug = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_51;
    z_bb_58:
    zT_323 = arg;
    zT_324 = s_test;
    zT_325 = zF_5FE51158_matchFlag(zT_323, zT_324);
    if (zT_325) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_57;
    z_bb_61:
    zT_327 = arg;
    zT_328 = s_sanity_test;
    zT_329 = zF_5FE51158_matchFlag(zT_327, zT_328);
    if (zT_329) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_331 = arg;
    zT_332 = s_warnings;
    zT_333 = zF_5FE51158_matchFlag(zT_331, zT_332);
    if (zT_333) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_335 = arg;
    zT_336 = s_W;
    zT_337 = zF_5FE51158_matchFlag(zT_335, zT_336);
    zT_334 = zT_337;
    goto z_bb_67;
    z_bb_66:
    zT_334 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_334) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_69;
    z_bb_69:
    goto z_bb_63;
    z_bb_70:
    zT_339 = arg;
    zT_340 = s_color;
    zT_341 = zF_5FE51158_matchFlag(zT_339, zT_340);
    if (zT_341) goto z_bb_71; else goto z_bb_73;
    z_bb_71:
    zT_342 = 1;
    zT_343 = (int)zT_342;
    zT_344 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_343)), 32u);
    zT_345 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_343)), 32u);
    zT_347 = zT_345 == (unsigned int)(0);
    if (!(zT_347)) { pal_trap(); }
    i = zT_344;
    if ((unsigned char)(i < argc)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_353 = arg;
    zT_354 = s_error_format;
    zT_355 = zF_5FE51158_matchFlag(zT_353, zT_354);
    if (zT_355) goto z_bb_76; else goto z_bb_78;
    z_bb_74:
    zT_350 = i;
    zT_351 = zF_70B5BFF1_argGet(zT_350);
    zT_349 = zT_351;
    zT_352 = zF_05AD3AFC_parseColorMode(zT_349);
    cli.color = zT_352;
    goto z_bb_75;
    z_bb_75:
    goto z_bb_72;
    z_bb_76:
    zT_356 = 1;
    zT_357 = (int)zT_356;
    zT_358 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_357)), 32u);
    zT_359 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_357)), 32u);
    zT_361 = zT_359 == (unsigned int)(0);
    if (!(zT_361)) { pal_trap(); }
    i = zT_358;
    if ((unsigned char)(i < argc)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_367 = arg;
    zT_368 = s_track_memory;
    zT_369 = zF_5FE51158_matchFlag(zT_367, zT_368);
    if (zT_369) goto z_bb_81; else goto z_bb_83;
    z_bb_79:
    zT_364 = i;
    zT_365 = zF_70B5BFF1_argGet(zT_364);
    zT_363 = zT_365;
    zT_366 = zF_A4602959_parseErrorFormat(zT_363);
    cli.error_format = zT_366;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_77;
    z_bb_83:
    zT_371 = arg;
    zT_372 = s_no_null;
    zT_373 = zF_5FE51158_matchFlag(zT_371, zT_372);
    if (zT_373) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_375 = arg;
    zT_376 = s_no_lifetime;
    zT_377 = zF_5FE51158_matchFlag(zT_375, zT_376);
    if (zT_377) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_379 = arg;
    zT_380 = s_no_leak;
    zT_381 = zF_5FE51158_matchFlag(zT_379, zT_380);
    if (zT_381) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_383 = arg;
    zT_384 = s_warn_all;
    zT_385 = zF_5FE51158_matchFlag(zT_383, zT_384);
    if (zT_385) goto z_bb_93; else goto z_bb_95;
    z_bb_93:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_94;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_387 = arg;
    zT_388 = s_warn_error;
    zT_389 = zF_5FE51158_matchFlag(zT_387, zT_388);
    if (zT_389) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_97;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_392 = arg;
    zT_393 = s_markers;
    zT_394 = zF_5FE51158_matchFlag(zT_392, zT_393);
    if (zT_394) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_396 = arg;
    zT_397 = s_include;
    zT_398 = zF_5FE51158_matchFlag(zT_396, zT_397);
    if (zT_398) goto z_bb_103; else goto z_bb_102;
    z_bb_102:
    zT_400 = arg;
    zT_401 = s_lib_dir;
    zT_402 = zF_5FE51158_matchFlag(zT_400, zT_401);
    zT_399 = zT_402;
    goto z_bb_104;
    z_bb_103:
    zT_399 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_399) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_403 = 1;
    zT_404 = (int)zT_403;
    zT_405 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_404)), 32u);
    zT_406 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_404)), 32u);
    zT_408 = zT_406 == (unsigned int)(0);
    if (!(zT_408)) { pal_trap(); }
    i = zT_405;
    if ((unsigned char)(i < argc)) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    goto z_bb_100;
    z_bb_107:
    zT_430 = arg;
    zT_431 = s_osl;
    zT_432 = zF_5FE51158_matchFlag(zT_430, zT_431);
    if (zT_432) goto z_bb_113; else goto z_bb_115;
    z_bb_108:
    zT_411 = cli.include_count;
    zT_412 = 16;
    zT_410 = zT_411 < (unsigned int)zT_412;
    goto z_bb_110;
    z_bb_109:
    zT_410 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_410) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_415 = i;
    zT_416 = zF_70B5BFF1_argGet(zT_415);
    zT_414 = zT_416;
    zT_417 = zF_22D0470E_cstrToSlice(zT_414);
    zT_418 = cli.include_dirs;
    zT_419 = cli.include_count;
    zT_420 = (unsigned int)zT_419;
    zT_422 = zT_420 < (unsigned int)(16);
    if (!(zT_422)) { pal_trap(); }
    zT_418[zT_420] = zT_417;
    zT_423 = cli.include_count;
    zT_424 = 1;
    zT_425 = (unsigned int)zT_424;
    zT_426 = zig_wrap_add_u(((zu64)(zT_423)), ((zu64)(zT_425)), 32u);
    zT_427 = zig_overflow_flag_add_u(((zu64)(zT_423)), ((zu64)(zT_425)), 32u);
    zT_429 = zT_427 == (unsigned int)(0);
    if (!(zT_429)) { pal_trap(); }
    cli.include_count = zT_426;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_106;
    z_bb_113:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_114;
    z_bb_114:
    goto z_bb_106;
    z_bb_115:
    zT_434 = arg;
    zT_435 = s_osw;
    zT_436 = zF_5FE51158_matchFlag(zT_434, zT_435);
    if (zT_436) goto z_bb_116; else goto z_bb_118;
    z_bb_116:
    cli.target_is_windows = (unsigned char)(1);
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_440 = 1;
    zT_441 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_440)), 32u);
    zT_442 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_440)), 32u);
    zT_444 = zT_442 == (unsigned int)(0);
    if (!(zT_444)) { pal_trap(); }
    if ((unsigned char)(zT_441 < argc)) goto z_bb_119; else goto z_bb_120;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_490 = arg;
    zT_491 = s_target;
    zT_492 = zF_5FE51158_matchFlag(zT_490, zT_491);
    if (zT_492) goto z_bb_131; else goto z_bb_133;
    z_bb_119:
    zT_449 = 1;
    zT_450 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_449)), 32u);
    zT_451 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_449)), 32u);
    zT_453 = zT_451 == (unsigned int)(0);
    if (!(zT_453)) { pal_trap(); }
    zT_448 = zT_450;
    zT_454 = zF_70B5BFF1_argGet(zT_448);
    zT_447 = zT_454;
    zT_455 = zF_22D0470E_cstrToSlice(zT_447);
    nxt = zT_455;
    zT_457 = nxt.len;
    zT_458 = 0;
    if ((unsigned char)(zT_457 > (unsigned int)zT_458)) goto z_bb_121; else goto z_bb_122;
    z_bb_120:
    goto z_bb_117;
    z_bb_121:
    zT_461 = nxt.ptr;
    zT_462 = 0;
    zT_463 = nxt.len;
    zT_464 = (unsigned int)zT_462 < zT_463;
    if (!(zT_464)) { pal_trap(); }
    zT_465 = zT_461[zT_462];
    zT_460 = zT_465 != (unsigned char)(45);
    goto z_bb_123;
    z_bb_122:
    zT_460 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_460) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_468 = nxt;
    zT_469 = s_profile_9x;
    zT_470 = zF_5FE51158_matchFlag(zT_468, zT_469);
    if (zT_470) goto z_bb_126; else goto z_bb_128;
    z_bb_125:
    goto z_bb_120;
    z_bb_126:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_473 = 1;
    zT_474 = (int)zT_473;
    zT_475 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_474)), 32u);
    zT_476 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_474)), 32u);
    zT_478 = zT_476 == (unsigned int)(0);
    if (!(zT_478)) { pal_trap(); }
    i = zT_475;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_479 = nxt;
    zT_480 = s_profile_nt;
    zT_481 = zF_5FE51158_matchFlag(zT_479, zT_480);
    if (zT_481) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_nt);
    zT_484 = 1;
    zT_485 = (int)zT_484;
    zT_486 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_485)), 32u);
    zT_487 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_485)), 32u);
    zT_489 = zT_487 == (unsigned int)(0);
    if (!(zT_489)) { pal_trap(); }
    i = zT_486;
    goto z_bb_130;
    z_bb_130:
    goto z_bb_127;
    z_bb_131:
    zT_493 = 1;
    zT_494 = (int)zT_493;
    zT_495 = zig_wrap_add_s(((z64)(i)), ((z64)(zT_494)), 32u);
    zT_496 = zig_overflow_flag_add_s(((z64)(i)), ((z64)(zT_494)), 32u);
    zT_498 = zT_496 == (unsigned int)(0);
    if (!(zT_498)) { pal_trap(); }
    i = zT_495;
    if ((unsigned char)(i < argc)) goto z_bb_134; else goto z_bb_135;
    z_bb_132:
    goto z_bb_117;
    z_bb_133:
    zT_507 = arg;
    zT_508 = s_ffast;
    zT_509 = zF_5FE51158_matchFlag(zT_507, zT_508);
    if (zT_509) goto z_bb_138; else goto z_bb_140;
    z_bb_134:
    zT_501 = i;
    zT_502 = zF_70B5BFF1_argGet(zT_501);
    zT_500 = zT_502;
    zT_503 = zF_06CC17EA_parseTargetIsWindow(zT_500);
    cli.target_is_windows = zT_503;
    zT_504 = cli.target_is_windows;
    if (zT_504) goto z_bb_136; else goto z_bb_137;
    z_bb_135:
    goto z_bb_132;
    z_bb_136:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    goto z_bb_137;
    z_bb_137:
    goto z_bb_135;
    z_bb_138:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_139;
    z_bb_139:
    goto z_bb_132;
    z_bb_140:
    zT_511 = arg;
    zT_512 = s_fsafe;
    zT_513 = zF_5FE51158_matchFlag(zT_511, zT_512);
    if (zT_513) goto z_bb_141; else goto z_bb_143;
    z_bb_141:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_142;
    z_bb_142:
    goto z_bb_139;
    z_bb_143:
    zT_515 = arg_ptr;
    zT_516 = zF_22D0470E_cstrToSlice(zT_515);
    cli.input_file = zT_516;
    goto z_bb_142;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = arg.len;
    zT_16 = j < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[j];
    zT_18 = flag.ptr;
    zT_19 = flag.len;
    zT_20 = j < zT_19;
    if (!(zT_20)) { pal_trap(); }
    zT_21 = zT_18[j];
    if ((unsigned char)(zT_17 != zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    j = zT_26;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = arg.len;
    zT_19 = j < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[j];
    zT_21 = s_mm.ptr;
    zT_22 = s_mm.len;
    zT_23 = j < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[j];
    if ((unsigned char)(zT_20 != zT_24)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    j = zT_29;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    int zT_13;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_8 = (unsigned int)zT_7;
    zT_9 = zig_wrap_add_u(((zu64)(len)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(len)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_13 = 0;
    zT_14 = ptr + zT_13;
    zT_15 = len - zT_13;
    zT_16 = (unsigned int)zT_13 <= len;
    if (!(zT_16)) { pal_trap(); }
    zT_17.ptr = (unsigned char*)zT_14;
    zT_17.len = zT_15;
    return zT_17;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned char zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned char zT_50;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned char zT_65;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_77;
    int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = s.len;
    zT_16 = i < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[i];
    c = zT_17;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_20 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_20) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_23 = 10;
    zT_24 = zig_wrap_mul_u(((zu64)(val)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_mul_u(((zu64)(val)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = 48;
    zT_29 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_28)), 8u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_28)), 8u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_33 = (unsigned int)zT_29;
    zT_34 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    val = zT_34;
    goto z_bb_9;
    z_bb_9:
    zT_83 = 1;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    i = zT_85;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_40 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_40 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_40) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_43 = 1024;
    zT_44 = zig_wrap_mul_u(((zu64)(val)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(val)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    val = zT_44;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_50 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_50 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_50) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_53 = 1024;
    zT_54 = zig_wrap_mul_u(((zu64)(val)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(val)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = 1024;
    zT_59 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    val = zT_59;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_65 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_65 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_65) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_68 = 1024;
    zT_69 = zig_wrap_mul_u(((zu64)(val)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_mul_u(((zu64)(val)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    zT_73 = 1024;
    zT_74 = zig_wrap_mul_u(((zu64)(zT_69)), ((zu64)(zT_73)), 32u);
    zT_75 = zig_overflow_flag_mul_u(((zu64)(zT_69)), ((zu64)(zT_73)), 32u);
    zT_77 = zT_75 == (unsigned int)(0);
    if (!(zT_77)) { pal_trap(); }
    zT_78 = 1024;
    zT_79 = zig_wrap_mul_u(((zu64)(zT_74)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_mul_u(((zu64)(zT_74)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    val = zT_79;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = s.len;
    zT_16 = i < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[i];
    c = zT_17;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_20 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_20) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_23 = 10;
    zT_24 = zig_wrap_mul_u(((zu64)(val)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_mul_u(((zu64)(val)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = 48;
    zT_29 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_28)), 8u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_28)), 8u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_33 = (unsigned int)zT_29;
    zT_34 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    val = zT_34;
    goto z_bb_9;
    z_bb_9:
    zT_38 = 1;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    i = zT_40;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned char zT_6;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_27;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    int zT_59;
    unsigned char zT_61;
    unsigned int zT_63;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_6 = 1;
    if (!(zT_6)) { pal_trap(); }
    zT_7 = (unsigned int)(unsigned int)(256);
    max_mb = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    i = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    n = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    mb = zT_16;
    goto z_bb_1;
    z_bb_1:
    zT_18 = rest.len;
    if ((unsigned char)(i < zT_18)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_21 = rest.ptr;
    zT_22 = rest.len;
    zT_23 = i < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[i];
    c = zT_24;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_59 = 0;
    if ((unsigned char)(n == (unsigned int)zT_59)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_27 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_27 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_30 = 1;
    zT_31 = (unsigned int)zT_30;
    zT_32 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    n = zT_32;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = 10;
    zT_38 = zig_wrap_mul_u(((zu64)(mb)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_mul_u(((zu64)(mb)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_42 = 48;
    zT_43 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_42)), 8u);
    zT_44 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_42)), 8u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = (unsigned int)zT_43;
    zT_48 = zig_wrap_add_u(((zu64)(zT_38)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(zT_38)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    mb = zT_48;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    i = zT_55;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_63 = rest.len;
    zT_61 = i != zT_63;
    goto z_bb_16;
    z_bb_15:
    zT_61 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_61) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_66 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_68 = 54;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    em = zT_67;
    zT_69 = em;
    zF_E4B2EF19_stderr_write(zT_69);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    zT_73 = 1024;
    zT_74 = zig_wrap_mul_u(((zu64)(mb)), ((zu64)(zT_73)), 32u);
    zT_75 = zig_overflow_flag_mul_u(((zu64)(mb)), ((zu64)(zT_73)), 32u);
    zT_77 = zT_75 == (unsigned int)(0);
    if (!(zT_77)) { pal_trap(); }
    return zT_74;
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = arg.len;
    zT_19 = j < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[j];
    zT_21 = s_s.ptr;
    zT_22 = s_s.len;
    zT_23 = j < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[j];
    if ((unsigned char)(zT_20 != zT_24)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    j = zT_29;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    int zT_32;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_61;
    unsigned char zT_63;
    unsigned int zT_65;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    int zT_75;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = rest.len;
    zT_19 = i < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_61 = 0;
    if ((unsigned char)(n == (unsigned int)zT_61)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    n = zT_28;
    zT_32 = 0;
    if ((unsigned char)(over == (unsigned int)zT_32)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 48;
    zT_36 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_35)), 8u);
    zT_37 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_35)), 8u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = (unsigned int)zT_36;
    d = zT_40;
    zT_42 = 10;
    zT_43 = zig_wrap_mul_u(((zu64)(level)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_mul_u(((zu64)(level)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = zig_wrap_add_u(((zu64)(zT_43)), ((zu64)(d)), 32u);
    zT_48 = zig_overflow_flag_add_u(((zu64)(zT_43)), ((zu64)(d)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    nl = zT_47;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_55 = 1;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    i = zT_57;
    goto z_bb_4;
    z_bb_12:
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    over = zT_54;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_65 = rest.len;
    zT_63 = i != zT_65;
    goto z_bb_17;
    z_bb_16:
    zT_63 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_63) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_68 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_70 = 82;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    em = zT_69;
    zT_71 = em;
    zF_E4B2EF19_stderr_write(zT_71);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_75 = 0;
    if ((unsigned char)(over != (unsigned int)zT_75)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_78 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_80 = 78;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    em = zT_79;
    zT_81 = em;
    zF_E4B2EF19_stderr_write(zT_81);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    unsigned char zT_13;
    int zT_17;
    int zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned char zT_25;
    int zT_26;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    int zT_34;
    int zT_35;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    unsigned char zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    zT_13 = (unsigned int)zT_11 < (unsigned int)(16);
    if (!(zT_13)) { pal_trap(); }
    buf[zT_11] = zT_10;
    zT_17 = 16;
    zT_18 = 15;
    zT_19 = (unsigned char*)((unsigned char*)buf) + zT_18;
    zT_20 = zT_17 - zT_18;
    zT_21.ptr = (unsigned char*)zT_19;
    zT_21.len = zT_20;
    s = zT_21;
    zT_22 = s;
    zF_B5478454_measureMarkerWrite(zT_22);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_23 = 0;
    if ((unsigned char)(v > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    i = zT_30;
    zT_34 = 48;
    zT_35 = 10;
    zT_38 = (unsigned int)zT_35 != (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    zT_39 = (unsigned int)(unsigned int)(v % zT_35);
    zT_40 = zig_wrap_add_u(((zu64)(zT_34)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(zT_34)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = (unsigned int)zT_40;
    zT_45 = (unsigned char)zig_cast_checked_u((zu64)zT_44, 32u, 0u, 8u);
    zT_47 = i < (unsigned int)(16);
    if (!(zT_47)) { pal_trap(); }
    buf[i] = zT_45;
    zT_48 = 10;
    zT_51 = (unsigned int)zT_48 != (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_49 = v / zT_48;
    v = zT_49;
    goto z_bb_6;
    z_bb_5:
    zT_55 = 16;
    zT_56 = (unsigned char*)((unsigned char*)buf) + i;
    zT_57 = zT_55 - i;
    zT_58 = i <= (unsigned int)zT_55;
    if (!(zT_58)) { pal_trap(); }
    zT_59.ptr = (unsigned char*)zT_56;
    zT_59.len = zT_57;
    s = zT_59;
    zT_60 = s;
    zF_B5478454_measureMarkerWrite(zT_60);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_26 = 0;
    zT_25 = i > (unsigned int)zT_26;
    goto z_bb_9;
    z_bb_8:
    zT_25 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_25) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u osw_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u io_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mem_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u quiet_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mode_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_all_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u diag_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u track_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u checks_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u markers_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u inc_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u safe_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fast_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u help_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = (unsigned char*)zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl      compile target = linux (default)\n";
    zT_28 = 45;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  -osw [9x|nt]  compile target = windows (default 9x = Win9x; nt = NT/XP profile)\n";
    zT_33 = 82;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    osw_help = zT_32;
    zT_34 = osw_help;
    zF_E4B2EF19_stderr_write(zT_34);
    zT_36 = "  --target <linux|windows>  long-form target alias for -osl/-osw (windows = 9x default)\n";
    zT_38 = 88;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    tgt_help = zT_37;
    zT_39 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_39);
    zT_41 = "  -o, --output-dir <dir>    output directory (default .)\n";
    zT_43 = 57;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    io_help = zT_42;
    zT_44 = io_help;
    zF_E4B2EF19_stderr_write(zT_44);
    zT_46 = "  -m, --max-mem <size>      hard pool budget with k/m/g suffix (same as -mm<N>)\n";
    zT_48 = 80;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    mem_help = zT_47;
    zT_49 = mem_help;
    zF_E4B2EF19_stderr_write(zT_49);
    zT_51 = "  -e, --max-errors <n>      max diagnostics (default 256)\n";
    zT_53 = 58;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    err_help = zT_52;
    zT_54 = err_help;
    zF_E4B2EF19_stderr_write(zT_54);
    zT_56 = "  -q, --quiet               suppress non-error output\n";
    zT_58 = 54;
    zT_57.ptr = (unsigned char*)zT_56;
    zT_57.len = zT_58;
    quiet_help = zT_57;
    zT_59 = quiet_help;
    zF_E4B2EF19_stderr_write(zT_59);
    zT_61 = "  --test                    run test blocks\n  --sanity-test             lexer sanity test\n";
    zT_63 = 90;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    mode_help = zT_62;
    zT_64 = mode_help;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = "  -W, --warnings-as-errors  treat warnings as errors; --warn-error also sets warn_error\n";
    zT_68 = 88;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    warn_help = zT_67;
    zT_69 = warn_help;
    zF_E4B2EF19_stderr_write(zT_69);
    zT_71 = "  --warn-all                enable all warnings\n";
    zT_73 = 48;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    warn_all_help = zT_72;
    zT_74 = warn_all_help;
    zF_E4B2EF19_stderr_write(zT_74);
    zT_76 = "  --color <auto|always|never>  diagnostic color mode (default auto)\n";
    zT_78 = 68;
    zT_77.ptr = (unsigned char*)zT_76;
    zT_77.len = zT_78;
    diag_help = zT_77;
    zT_79 = diag_help;
    zF_E4B2EF19_stderr_write(zT_79);
    zT_81 = "  --error-format <human|json|sarif>  diagnostic format (default human)\n";
    zT_83 = 71;
    zT_82.ptr = (unsigned char*)zT_81;
    zT_82.len = zT_83;
    fmt_help = zT_82;
    zT_84 = fmt_help;
    zF_E4B2EF19_stderr_write(zT_84);
    zT_86 = "  --track-memory            report peak memory\n";
    zT_88 = 47;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    track_help = zT_87;
    zT_89 = track_help;
    zF_E4B2EF19_stderr_write(zT_89);
    zT_91 = "  --no-null-check | --no-lifetime-check | --no-leak-check  disable those checks\n";
    zT_93 = 80;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    checks_help = zT_92;
    zT_94 = checks_help;
    zF_E4B2EF19_stderr_write(zT_94);
    zT_96 = "  --markers                 emit phase markers\n";
    zT_98 = 47;
    zT_97.ptr = (unsigned char*)zT_96;
    zT_97.len = zT_98;
    markers_help = zT_97;
    zT_99 = markers_help;
    zF_E4B2EF19_stderr_write(zT_99);
    zT_101 = "  -I <dir>, --lib-dir <dir> add an include/library directory (max 16)\n";
    zT_103 = 70;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    inc_help = zT_102;
    zT_104 = inc_help;
    zF_E4B2EF19_stderr_write(zT_104);
    zT_106 = "  -fsafe                    enable runtime checks + undefined poison (default)\n";
    zT_108 = 79;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    safe_help = zT_107;
    zT_109 = safe_help;
    zF_E4B2EF19_stderr_write(zT_109);
    zT_111 = "  -ffast                    disable runtime checks + undefined poison\n";
    zT_113 = 70;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    fast_help = zT_112;
    zT_114 = fast_help;
    zF_E4B2EF19_stderr_write(zT_114);
    zT_116 = "  --dump-c89                emit C89 into the output directory\n";
    zT_118 = 63;
    zT_117.ptr = (unsigned char*)zT_116;
    zT_117.len = zT_118;
    c89_help = zT_117;
    zT_119 = c89_help;
    zF_E4B2EF19_stderr_write(zT_119);
    zT_121 = "  -d, --debug               emit <stem>.z98dbg.{syms,lines,cnames} (requires --output-dir)\n";
    zT_123 = 91;
    zT_122.ptr = (unsigned char*)zT_121;
    zT_122.len = zT_123;
    dbg_help = zT_122;
    zT_124 = dbg_help;
    zF_E4B2EF19_stderr_write(zT_124);
    zT_126 = "  --help                    show this help\n";
    zT_128 = 43;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    help_help = zT_127;
    zT_129 = help_help;
    zF_E4B2EF19_stderr_write(zT_129);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0;
    zT_69057089_CompilerAlloc zT_1;
    zT_D3EB6303_StringInterner zT_2;
    zT_227EDE07_SourceManager zT_3;
    zT_F85C5DED_DiagnosticCollector zT_4;
    zT_3A355BD2_Token zT_5;
    zT_EAC3E484_TokenKind zT_6;
    zT_072B53A6_ModuleRegistry zT_7;
    zT_338B7C76_TypeRegistry zT_8;
    zT_6B356268_SemanticContext zT_9;
    zT_02EB57B2_LirLowerer zT_10;
    zT_CA01C129_LirSlotArrayList zT_11;
    zT_8EED1867_ResolvedTypeTable zT_12;
    zT_66E7D2EF_CoercionTable zT_13;
    zT_3D7259E2_SymbolRegistry zT_14;
    zT_8143F551_AstKind zT_15;
    zT_6B0A7D14_AstStore zT_16;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_3A355BD2_Token = zT_5;
    zG_EAC3E484_TokenKind = zT_6;
    zG_072B53A6_ModuleRegistry = zT_7;
    zG_338B7C76_TypeRegistry = zT_8;
    zG_6B356268_SemanticContext = zT_9;
    zG_02EB57B2_LirLowerer = zT_10;
    zG_CA01C129_LirSlotArrayList = zT_11;
    zG_8EED1867_ResolvedTypeTable = zT_12;
    zG_66E7D2EF_CoercionTable = zT_13;
    zG_3D7259E2_SymbolRegistry = zT_14;
    zG_8143F551_AstKind = zT_15;
    zG_6B0A7D14_AstStore = zT_16;
    return;
}

/* EOF */
