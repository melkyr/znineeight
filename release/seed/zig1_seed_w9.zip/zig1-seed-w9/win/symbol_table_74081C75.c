#include "symbol_table_74081C75.h"
zT_3D7259E2_SymbolRegistry zG_3D7259E2_SymbolRegistry;
zT_060CD1EB_SymbolTable zG_060CD1EB_SymbolTable;
zT_3C598AEF_SymbolKind zG_3C598AEF_SymbolKind;
/* symbolTableInit */
zT_060CD1EB_SymbolTable zF_26192335_symbolTableInit(zT_3E40CD83_Sand* allocator) {
    zT_060CD1EB_SymbolTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_3A105EF1_Symbol*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* symbolTableEnsureCapacity */
void zF_896A798D_symbolTableEnsureCa(zT_060CD1EB_SymbolTable* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_3A105EF1_Symbol* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_6F2E32ED_Opt_259 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_81AD2998_EU_952 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    zT_3A105EF1_Symbol* zT_64;
    zT_3A105EF1_Symbol* zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_3A105EF1_Symbol* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_E0618270_Slice_zT_3A105EF1_S zT_71;
    zT_3A105EF1_Symbol* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int nc;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    zT_3A105EF1_Symbol* new_items;
    zT_3A105EF1_Symbol item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(nc < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    nc = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->allocator;
    zT_32 = self->items;
    zT_34 = self->capacity;
    zT_35 = 28;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 28;
    zT_41 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->allocator;
    zT_53 = 28;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(nc)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(nc)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (zT_3A105EF1_Symbol*)raw;
    new_items = zT_64;
    zT_65 = self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (zT_3A105EF1_Symbol*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = nc;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* symbolTableInsert */
unsigned char zF_D0156DDA_symbolTableInsert(zT_060CD1EB_SymbolTable* self, zT_3A105EF1_Symbol sym) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_7;
    zT_3A105EF1_Symbol zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_060CD1EB_SymbolTable* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_3A105EF1_Symbol* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->items;
    zT_8 = zT_7[i];
    zT_9 = zT_8.name_id;
    zT_10 = sym.name_id;
    if ((unsigned char)(zT_9 == zT_10)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_19 = self;
    zT_21 = self->len;
    zT_22 = 1;
    zT_23 = zig_wrap_add_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    zT_20 = zT_23;
    zF_896A798D_symbolTableEnsureCa(zT_19, zT_20);
    zT_27 = self->items;
    zT_28 = self->len;
    zT_27[zT_28] = sym;
    zT_29 = self->len;
    zT_30 = 1;
    zT_31 = (unsigned int)zT_30;
    zT_32 = zig_wrap_add_u(((zu64)(zT_29)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(zT_29)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    self->len = zT_32;
    return (unsigned char)(1);
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    i = zT_15;
    goto z_bb_4;
}

/* symbolTableLookup */
zT_EAF7A2A2_Opt_953 zF_893B79A5_symbolTableLookup(zT_060CD1EB_SymbolTable* self, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_7;
    zT_3A105EF1_Symbol zT_8;
    unsigned int zT_9;
    zT_3A105EF1_Symbol* zT_11;
    zT_3A105EF1_Symbol* zT_12;
    zT_EAF7A2A2_Opt_953 zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    zT_EAF7A2A2_Opt_953 zT_20;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->items;
    zT_8 = zT_7[i];
    zT_9 = zT_8.name_id;
    if ((unsigned char)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self->items;
    zT_12 = zT_11 + i;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    zT_14 = 1;
    zT_15 = (unsigned int)zT_14;
    zT_16 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    i = zT_16;
    goto z_bb_4;
}

/* symbolRegistryEnsureCapacity */
void zF_BCFEB408_symbolRegistryEnsur(zT_3D7259E2_SymbolRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_060CD1EB_SymbolTable* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_6F2E32ED_Opt_259 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_81AD2998_EU_952 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    zT_060CD1EB_SymbolTable* zT_64;
    zT_060CD1EB_SymbolTable* zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_060CD1EB_SymbolTable* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_DD67D991_Slice_zT_060CD1EB_S zT_71;
    zT_060CD1EB_SymbolTable* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int nc;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    zT_060CD1EB_SymbolTable* new_items;
    zT_060CD1EB_SymbolTable item;
    unsigned int i;
    zT_2 = self->tables_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->tables_cap;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(nc < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->tables_cap;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    nc = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->tables_cap;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->tables_alloc;
    zT_32 = self->tables_items;
    zT_34 = self->tables_cap;
    zT_35 = 16;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 16;
    zT_41 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->tables_alloc;
    zT_53 = 16;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(nc)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(nc)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->tables_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (zT_060CD1EB_SymbolTable*)raw;
    new_items = zT_64;
    zT_65 = self->tables_items;
    zT_66 = self->tables_len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (zT_060CD1EB_SymbolTable*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->tables_items = new_items;
    self->tables_cap = nc;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* symbolRegistryInit */
zT_3D7259E2_SymbolRegistry zF_09A884A8_symbolRegistryInit(zT_3E40CD83_Sand* alloc) {
    zT_3D7259E2_SymbolRegistry zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.tables_items = (zT_060CD1EB_SymbolTable*)zT_2;
    zT_3 = 0;
    zT_1.tables_len = zT_3;
    zT_4 = 0;
    zT_1.tables_cap = zT_4;
    zT_1.tables_alloc = alloc;
    return zT_1;
}

/* symbolRegistryGetTable */
zT_060CD1EB_SymbolTable* zF_9B36C202_symbolRegistryGetTa(zT_3D7259E2_SymbolRegistry* self, unsigned int module_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_060CD1EB_SymbolTable zT_18;
    zT_060CD1EB_SymbolTable* zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_060CD1EB_SymbolTable* zT_31;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned int idx;
    unsigned int zi;
    zT_3 = (unsigned int)module_id;
    idx = zT_3;
    zT_4 = self->tables_len;
    if ((unsigned char)(idx >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zT_8 = 1;
    zT_9 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_7 = zT_9;
    zF_BCFEB408_symbolRegistryEnsur(zT_6, zT_7);
    zT_14 = self->tables_len;
    zi = zT_14;
    goto z_bb_3;
    z_bb_2:
    zT_31 = self->tables_items;
    return (zT_060CD1EB_SymbolTable*)(zT_31 + idx);
    z_bb_3:
    if ((unsigned char)(zi <= idx)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = self->tables_alloc;
    zT_18 = zF_26192335_symbolTableInit(zT_16);
    zT_19 = self->tables_items;
    zT_19[zi] = zT_18;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zi = zT_22;
    goto z_bb_6;
    z_bb_5:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    self->tables_len = zT_27;
    goto z_bb_2;
    z_bb_6:
    goto z_bb_3;
}

/* symbolIsPublic */
unsigned char zF_C08C479C_symbolIsPublic(zT_3A105EF1_Symbol* sym) {
    unsigned short zT_1;
    int zT_4;
    zT_1 = sym->flags;
    zT_4 = 0;
    return (unsigned char)((unsigned short)(zT_1 & (unsigned short)(2)) != zT_4);
}

/* symbolRegistryQualifiedLookup */
zT_EAF7A2A2_Opt_953 zF_A398987E_symbolRegistryQuali(zT_3D7259E2_SymbolRegistry* reg, unsigned int mod_id, unsigned int name_id) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    zT_060CD1EB_SymbolTable* zT_6;
    zT_060CD1EB_SymbolTable* zT_7;
    unsigned int zT_8;
    zT_EAF7A2A2_Opt_953 zT_9;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_060CD1EB_SymbolTable* table;
    zT_4 = reg;
    zT_5 = mod_id;
    zT_6 = zF_9B36C202_symbolRegistryGetTa(zT_4, zT_5);
    table = zT_6;
    zT_7 = table;
    zT_8 = name_id;
    zT_9 = zF_893B79A5_symbolTableLookup(zT_7, zT_8);
    return zT_9;
}

/* EOF */
