#include "cinclude_6B99020D.h"
/* cincludeUnionAll */
zT_3CB0179A_Slice_zT_05F374B1_u zF_1E2E8788_cincludeUnionAll(zT_072B53A6_ModuleRegistry* module_reg, zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_3;
    zT_B687BB96_U32ArrayList zT_4;
    zT_072B53A6_ModuleRegistry* zT_6;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_B687BB96_U32ArrayList* zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    zT_6E8D187B_ModuleEntry* zT_20;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    zT_21D3708C_U32ToU32Map zT_37;
    unsigned int zT_39;
    unsigned int zT_41;
    zT_B687BB96_U32ArrayList* zT_44;
    zT_6E8D187B_ModuleEntry* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_6E8D187B_ModuleEntry* zT_48;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    unsigned int zT_60;
    zT_21D3708C_U32ToU32Map* zT_61;
    unsigned int zT_62;
    zT_BAEE192E_Opt_10 zT_64;
    unsigned char zT_65;
    zT_21D3708C_U32ToU32Map* zT_67;
    unsigned int zT_68;
    zT_B687BB96_U32ArrayList* zT_72;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_B687BB96_U32ArrayList* zT_85;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_87;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zT_B687BB96_U32ArrayList temp;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int hint;
    unsigned int hi;
    zT_3CB0179A_Slice_zT_05F374B1_u m_incs_h;
    zT_21D3708C_U32ToU32Map seen;
    unsigned int mi;
    zT_3CB0179A_Slice_zT_05F374B1_u m_incs;
    unsigned int ci;
    unsigned int name_id;
    zT_3 = alloc;
    zT_4 = zF_8E537D0C_u32ArrayListInit(zT_3);
    temp = zT_4;
    zT_6 = module_reg;
    zT_7 = zF_3452C137_moduleRegistryGetMo(zT_6);
    mods = zT_7;
    zT_9 = 0;
    hint = zT_9;
    zT_11 = 0;
    hi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    if ((unsigned char)(hi < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = mods.ptr;
    zT_18 = mods.len;
    zT_19 = hi < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17 + hi;
    zT_16 = &zT_20->c_includes;
    zT_22 = zF_281E4968_u32ArrayListGetSlic(zT_16);
    m_incs_h = zT_22;
    zT_24 = m_incs_h.len;
    zT_25 = zig_wrap_add_u(((zu64)(hint)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(hint)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    hint = zT_25;
    goto z_bb_4;
    z_bb_3:
    zT_35 = alloc;
    zT_36 = hint;
    zT_37 = zF_619D56E6_u32ToU32MapInitCap(zT_35, zT_36);
    seen = zT_37;
    zT_39 = 0;
    mi = zT_39;
    goto z_bb_5;
    z_bb_4:
    zT_29 = 1;
    zT_30 = zig_wrap_add_u(((zu64)(hi)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(hi)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    hi = zT_30;
    goto z_bb_1;
    z_bb_5:
    zT_41 = mods.len;
    if ((unsigned char)(mi < zT_41)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_45 = mods.ptr;
    zT_46 = mods.len;
    zT_47 = mi < zT_46;
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_45 + mi;
    zT_44 = &zT_48->c_includes;
    zT_50 = zF_281E4968_u32ArrayListGetSlic(zT_44);
    m_incs = zT_50;
    zT_52 = 0;
    ci = zT_52;
    goto z_bb_9;
    z_bb_7:
    zT_85 = (zT_B687BB96_U32ArrayList*)&temp;
    zT_87 = zF_281E4968_u32ArrayListGetSlic(zT_85);
    return zT_87;
    z_bb_8:
    zT_80 = 1;
    zT_81 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    mi = zT_81;
    goto z_bb_5;
    z_bb_9:
    zT_54 = m_incs.len;
    if ((unsigned char)(ci < zT_54)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = m_incs.ptr;
    zT_58 = m_incs.len;
    zT_59 = ci < zT_58;
    if (!(zT_59)) { pal_trap(); }
    zT_60 = zT_57[ci];
    name_id = zT_60;
    zT_61 = (zT_21D3708C_U32ToU32Map*)&seen;
    zT_62 = name_id;
    zT_64 = zF_F3EE5998_u32ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_75 = 1;
    zT_76 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    ci = zT_76;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_67 = (zT_21D3708C_U32ToU32Map*)&seen;
    zT_68 = name_id;
    zF_26476265_u32ToU32MapPut(zT_67, zT_68, (unsigned int)(1));
    zT_72 = (zT_B687BB96_U32ArrayList*)&temp;
    zT_73 = name_id;
    zF_62F717A2_u32ArrayListAppend(zT_72, zT_73);
    goto z_bb_14;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_072B53A6_ModuleRegistry zT_0;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_072B53A6_ModuleRegistry = zT_0;
    return;
}

/* EOF */
