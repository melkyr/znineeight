#include "async_frame_layout_08B81337.h"
#include <stdio.h>
static unsigned int const zG_61A58C50_INVALID = (unsigned int)(4294967295u);
unsigned char const zG_954AE082_ASYNC_FIELD_CTX = (unsigned char)(0);
unsigned char const zG_F148439A_ASYNC_FIELD_STATE = (unsigned char)(1);
unsigned char const zG_3F71CB56_ASYNC_FIELD_PARAM = (unsigned char)(2);
unsigned char const zG_45DE8DAB_ASYNC_FIELD_LIVE = (unsigned char)(3);
unsigned char const zG_488329A3_ASYNC_FIELD_STEP = (unsigned char)(4);
unsigned char const zG_F6A886E9_ASYNC_FIELD_CHILD = (unsigned char)(5);
unsigned char const zG_0BE94A38_ASYNC_FIELD_RESULT = (unsigned char)(6);
unsigned char const zG_739BC61B_ASYNC_FIELD_PARENT_ = (unsigned char)(7);
zT_3F3BF87A_AsyncFrameLayout zG_3F3BF87A_AsyncFrameLayout;
/* fieldArrayListInit */
zT_2CF63CE1_AsyncFrameFieldArra zF_1BFB52BE_fieldArrayListInit(zT_3E40CD83_Sand* alloc, unsigned int capacity) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_FDFD82FD_EU_362 zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    zT_2CF63CE1_AsyncFrameFieldArra zT_20;
    zT_902E38E8_AsyncFrameField* zT_21;
    unsigned int zT_22;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned int cap;
    unsigned char* raw;
    cap = capacity;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    cap = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_10 = 28;
    zT_11 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_8 = zT_11;
    zT_16 = zF_1395EB68_sandAlloc(zT_7, zT_8, (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    zT_21 = (zT_902E38E8_AsyncFrameField*)raw;
    zT_20.items = zT_21;
    zT_22 = 0;
    zT_20.len = zT_22;
    zT_20.capacity = cap;
    zT_20.allocator = alloc;
    return zT_20;
}

/* fieldArrayListEnsureCapacity */
void zF_FB5EC98E_fieldArrayListEnsur(zT_2CF63CE1_AsyncFrameFieldArra* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_902E38E8_AsyncFrameField* zT_37;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_902E38E8_AsyncFrameField* zT_42;
    zT_902E38E8_AsyncFrameField zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    unsigned int new_cap;
    unsigned char* raw;
    zT_902E38E8_AsyncFrameField* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->allocator;
    zT_26 = 28;
    zT_27 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_34;
    zT_37 = (zT_902E38E8_AsyncFrameField*)raw;
    new_items = zT_37;
    zT_39 = 0;
    i = zT_39;
    goto z_bb_10;
    z_bb_10:
    zT_40 = self->len;
    if ((unsigned char)(i < zT_40)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_42 = self->items;
    zT_43 = zT_42[i];
    new_items[i] = zT_43;
    goto z_bb_13;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13:
    zT_44 = 1;
    zT_45 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    i = zT_45;
    goto z_bb_10;
}

/* fieldArrayListAppend */
void zF_92FA7DBC_fieldArrayListAppen(zT_2CF63CE1_AsyncFrameFieldArra* self, zT_902E38E8_AsyncFrameField value) {
    zT_2CF63CE1_AsyncFrameFieldArra* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_902E38E8_AsyncFrameField* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_FB5EC98E_fieldArrayListEnsur(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    self->len = zT_14;
    return;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_FDFD82FD_EU_362 zT_18;
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned int count;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_11 = (unsigned int)count;
    zT_12 = 4;
    zT_13 = zig_wrap_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_9 = zT_13;
    zT_18 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_20 = zT_18.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    a = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = (unsigned int)i;
    a[zT_27] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_28 = 1;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_6;
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_FDFD82FD_EU_362 zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned int count;
    unsigned char* raw;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    count = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_10 = (unsigned int)count;
    zT_11 = 1;
    zT_12 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_8 = zT_12;
    zT_17 = zF_1395EB68_sandAlloc(zT_7, zT_8, (unsigned int)(1));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_19 = zT_17.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_19;
    return (unsigned char*)((unsigned char*)raw);
}

/* allocU8With */
unsigned char* zF_9C85B07B_allocU8With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned char fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_FDFD82FD_EU_362 zT_18;
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned int count;
    unsigned char* raw;
    unsigned char* a;
    unsigned int i;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_11 = (unsigned int)count;
    zT_12 = 1;
    zT_13 = zig_wrap_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_9 = zT_13;
    zT_18 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(1));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_20 = zT_18.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_20;
    zT_23 = (unsigned char*)raw;
    a = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = (unsigned int)i;
    a[zT_27] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_28 = 1;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_6;
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    zT_12 = td.temp_id;
    if ((unsigned char)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_20 = 1;
    zT_21 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    i = zT_21;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_15 = 1;
    zT_16 = zig_wrap_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_BBC23664_LirFunction* zT_91;
    unsigned int zT_92;
    zT_3BFB1E70_CallDirectData zT_94;
    unsigned int zT_95;
    zT_BBC23664_LirFunction* zT_98;
    unsigned int zT_99;
    zT_0624AC1B_TailCallData zT_101;
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_101, (unsigned int)sizeof zT_101);
    zT_03BF58FB_anon_116827 b;
    zT_F1C17B3C_anon_116835 u;
    zT_B6F925A1_anon_117071 ic;
    zT_B8F928C7_anon_117077 fc;
    zT_A4D8B5A0_anon_117083 sc;
    zT_A8D8BBEC_anon_117087 nc;
    zT_A4D67709_anon_117093 sn;
    zT_AAD6807B_anon_117099 bc;
    zT_3E54FCF5_anon_117105 uc;
    zT_652AE679_anon_117325 pi;
    zT_3A573540_anon_117115 ec;
    zT_24F18406_anon_117023 ic_1;
    zT_F5304657_anon_117341 ic_2;
    zT_F7328814_anon_117353 ww;
    zT_BEEEA4DD_anon_117031 fc_3;
    zT_B6EE9845_anon_117039 pc;
    zT_28F60780_anon_117047 itf;
    zT_BAFB6A84_anon_117061 itp;
    zT_2CF3CF35_anon_117053 pti;
    zT_B6EA1B17_anon_117015 ms;
    zT_DC513CA6_anon_116903 a;
    zT_F24F20B1_anon_116915 a_4;
    zT_6C58DB1B_anon_116953 fr;
    zT_EC4CD8A8_anon_116923 w;
    zT_6A545AC7_anon_116979 w_5;
    zT_F03DD46A_anon_116987 w_6;
    zT_6658D1A9_anon_116959 u_7;
    zT_692AECC5_anon_117321 u_8;
    zT_62568CC6_anon_116965 u_9;
    zT_62544E2F_anon_116971 ch;
    zT_E43B82EF_anon_116993 u_10;
    zT_EE3B92AD_anon_116999 u_11;
    zT_BAEC5FFA_anon_117005 ch_12;
    zT_71A8ACD6_anon_116891 l;
    zT_81C6DB1A_anon_116859 lf;
    zT_D3BB77AF_anon_117213 lb;
    zT_71A66E3F_anon_116885 li;
    zT_CE4FCF77_anon_117121 ll;
    zT_4E52D78E_anon_117135 lg;
    zT_87D97B7B_anon_116759 a_13;
    zT_89DDFBCF_anon_116773 a_14;
    zT_09F908CC_anon_116783 a_15;
    zT_F1C3B9D3_anon_116845 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_0624AC1B_TailCallData tc;
    zT_6249C0D3_anon_116939 va;
    zT_BC48F75C_anon_117177 bgc;
    zT_4DC770B0_anon_117245 o;
    zT_55C53EB1_anon_117259 o_16;
    zT_E3C00E0D_anon_117273 o_17;
    zT_CFD137B2_anon_117287 o_18;
    zT_DDCF0F25_anon_117299 o_19;
    zT_6528A7E2_anon_117315 o_20;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 79: goto z_bb_10;
case 51: goto z_bb_11;
case 38: goto z_bb_12;
case 80: goto z_bb_13;
case 81: goto z_bb_14;
case 39: goto z_bb_15;
case 40: goto z_bb_16;
case 41: goto z_bb_17;
case 43: goto z_bb_18;
case 42: goto z_bb_19;
case 37: goto z_bb_20;
case 20: goto z_bb_21;
case 21: goto z_bb_22;
case 28: goto z_bb_23;
case 22: goto z_bb_24;
case 32: goto z_bb_25;
case 33: goto z_bb_26;
case 29: goto z_bb_27;
case 78: goto z_bb_28;
case 30: goto z_bb_29;
case 31: goto z_bb_30;
case 34: goto z_bb_31;
case 35: goto z_bb_32;
case 36: goto z_bb_33;
case 18: goto z_bb_34;
case 15: goto z_bb_35;
case 68: goto z_bb_36;
case 17: goto z_bb_37;
case 52: goto z_bb_38;
case 54: goto z_bb_39;
case 2: goto z_bb_40;
case 3: goto z_bb_41;
case 4: goto z_bb_42;
case 14: goto z_bb_43;
case 23: goto z_bb_44;
case 27: goto z_bb_45;
case 25: goto z_bb_46;
case 61: goto z_bb_47;
case 72: goto z_bb_48;
case 73: goto z_bb_49;
case 74: goto z_bb_50;
case 75: goto z_bb_51;
case 76: goto z_bb_52;
case 77: goto z_bb_53;
default: goto z_bb_54;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    pi = inst.payload.poison_init._0;
    zT_22 = pi.result;
    return zT_22;
    z_bb_11:
    ec = inst.payload.enum_const._0;
    zT_24 = ec.result;
    return zT_24;
    z_bb_12:
    ic_1 = inst.payload.int_cast._0;
    zT_26 = ic_1.result;
    return zT_26;
    z_bb_13:
    ic_2 = inst.payload.int_cast_checked._0;
    zT_28 = ic_2.result;
    return zT_28;
    z_bb_14:
    ww = inst.payload.width_wrap._0;
    zT_30 = ww.result;
    return zT_30;
    z_bb_15:
    fc_3 = inst.payload.float_cast._0;
    zT_32 = fc_3.result;
    return zT_32;
    z_bb_16:
    pc = inst.payload.ptr_cast._0;
    zT_34 = pc.result;
    return zT_34;
    z_bb_17:
    itf = inst.payload.int_to_float._0;
    zT_36 = itf.result;
    return zT_36;
    z_bb_18:
    itp = inst.payload.int_to_ptr._0;
    zT_38 = itp.result;
    return zT_38;
    z_bb_19:
    pti = inst.payload.ptr_to_int._0;
    zT_40 = pti.result;
    return zT_40;
    z_bb_20:
    ms = inst.payload.make_slice._0;
    zT_42 = ms.result;
    return zT_42;
    z_bb_21:
    a = inst.payload.addr_of._0;
    zT_44 = a.result;
    return zT_44;
    z_bb_22:
    a_4 = inst.payload.addr_of_field._0;
    zT_46 = a_4.result;
    return zT_46;
    z_bb_23:
    fr = inst.payload.func_ref._0;
    zT_48 = fr.result;
    return zT_48;
    z_bb_24:
    w = inst.payload.wrap_optional._0;
    zT_50 = w.result;
    return zT_50;
    z_bb_25:
    w_5 = inst.payload.wrap_error_ok._0;
    zT_52 = w_5.result;
    return zT_52;
    z_bb_26:
    w_6 = inst.payload.wrap_error_err._0;
    zT_54 = w_6.result;
    return zT_54;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_56 = u_7.result;
    return zT_56;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_checked._0;
    zT_58 = u_8.result;
    return zT_58;
    z_bb_29:
    u_9 = inst.payload.unwrap_optional_abi._0;
    zT_60 = u_9.result;
    return zT_60;
    z_bb_30:
    ch = inst.payload.check_optional._0;
    zT_62 = ch.result;
    return zT_62;
    z_bb_31:
    u_10 = inst.payload.unwrap_error_payload._0;
    zT_64 = u_10.result;
    return zT_64;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_code._0;
    zT_66 = u_11.result;
    return zT_66;
    z_bb_33:
    ch_12 = inst.payload.check_error._0;
    zT_68 = ch_12.result;
    return zT_68;
    z_bb_34:
    l = inst.payload.load._0;
    zT_70 = l.result;
    return zT_70;
    z_bb_35:
    lf = inst.payload.load_field._0;
    zT_72 = lf.result;
    return zT_72;
    z_bb_36:
    lb = inst.payload.load_bitfield._0;
    zT_74 = lb.result;
    return zT_74;
    z_bb_37:
    li = inst.payload.load_index._0;
    zT_76 = li.result;
    return zT_76;
    z_bb_38:
    ll = inst.payload.load_local._0;
    zT_78 = ll.result;
    return zT_78;
    z_bb_39:
    lg = inst.payload.load_global._0;
    zT_80 = lg.result;
    return zT_80;
    z_bb_40:
    a_13 = inst.payload.assign._0;
    zT_82 = a_13.dst;
    return zT_82;
    z_bb_41:
    a_14 = inst.payload.assign_field._0;
    zT_84 = a_14.base;
    return zT_84;
    z_bb_42:
    a_15 = inst.payload.assign_index._0;
    zT_86 = a_15.base;
    return zT_86;
    z_bb_43:
    cl = inst.payload.call._0;
    zT_88 = cl.result;
    return zT_88;
    z_bb_44:
    slot = inst.payload.jump._0;
    zT_91 = c->lir_fn;
    zT_92 = slot;
    zT_94 = zF_75DE985C_lirSideGetCallDirec(zT_91, zT_92);
    cd = zT_94;
    zT_95 = cd.result;
    return zT_95;
    z_bb_45:
    slot = inst.payload.jump._0;
    zT_98 = c->lir_fn;
    zT_99 = slot;
    zT_101 = zF_1AB3807F_lirSideGetTailCall(zT_98, zT_99);
    tc = zT_101;
    zT_102 = tc.result;
    return zT_102;
    z_bb_46:
    va = inst.payload.va_arg._0;
    zT_104 = va.result;
    return zT_104;
    z_bb_47:
    bgc = inst.payload.builtin_get_char._0;
    zT_106 = bgc.result;
    return zT_106;
    z_bb_48:
    o = inst.payload.add_with_overflow._0;
    zT_108 = o.result;
    return zT_108;
    z_bb_49:
    o_16 = inst.payload.sub_with_overflow._0;
    zT_110 = o_16.result;
    return zT_110;
    z_bb_50:
    o_17 = inst.payload.mul_with_overflow._0;
    zT_112 = o_17.result;
    return zT_112;
    z_bb_51:
    o_18 = inst.payload.shl_with_overflow._0;
    zT_114 = o_18.result;
    return zT_114;
    z_bb_52:
    o_19 = inst.payload.neg_with_overflow._0;
    zT_116 = o_19.result;
    return zT_116;
    z_bb_53:
    o_20 = inst.payload.overflow_flag._0;
    zT_118 = o_20.result;
    return zT_118;
    z_bb_54:
    return (unsigned int)(4294967295u);
    return 0;
}

/* localStorage */
unsigned int zF_CD424A09_localStorage(zT_6D148508_Scan* c, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8;
    unsigned char zT_9;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    unsigned int t;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_5 = c->locals;
    zT_6 = name_id;
    zT_8 = zF_F3EE5998_u32ToU32MapGet(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(zT_8.has_value)) { pal_trap(); }
    t = zT_8.value;
    return t;
    z_bb_4:
    return (unsigned int)(4294967295u);
}

/* instDefsTemp */
unsigned char zF_1FF90D33_instDefsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    zT_6D148508_Scan* zT_3;
    zT_6BA597BC_LirInst zT_4;
    unsigned int zT_5;
    unsigned int zT_8;
    zT_6D148508_Scan* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zT_CC4FCC51_anon_117127 sl;
    zT_3 = c;
    zT_4 = inst;
    zT_5 = zF_CFED20F7_defResultTemp(zT_3, zT_4);
    if ((unsigned char)(zT_5 == v)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = inst.tag;
switch (zT_8) {
case 53: goto z_bb_3;
case 55: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_3:
    sl = inst.payload.store_local._0;
    zT_10 = c;
    zT_11 = sl.name_id;
    zT_13 = zF_CD424A09_localStorage(zT_10, zT_11);
    if ((unsigned char)(zT_13 == v)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_7;
    z_bb_5:
    goto z_bb_7;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    goto z_bb_7;
}

/* instReadsTemp */
unsigned char zF_E4C3429C_instReadsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_30;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned int zT_65;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_76;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    unsigned int zT_90;
    unsigned char zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    unsigned int zT_102;
    unsigned int zT_106;
    unsigned int zT_110;
    unsigned char zT_112;
    unsigned int zT_113;
    unsigned int zT_117;
    unsigned char zT_119;
    unsigned int zT_120;
    unsigned int zT_124;
    unsigned char zT_126;
    unsigned int zT_127;
    unsigned int zT_131;
    unsigned int zT_135;
    unsigned char zT_137;
    unsigned int zT_138;
    unsigned int zT_142;
    unsigned int zT_146;
    unsigned int zT_150;
    zT_BBC23664_LirFunction* zT_155;
    unsigned int zT_156;
    zT_3BFB1E70_CallDirectData zT_158;
    unsigned int zT_159;
    unsigned char zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned int zT_171;
    unsigned char zT_173;
    unsigned int zT_174;
    unsigned int zT_178;
    unsigned int zT_182;
    zT_BBC23664_LirFunction* zT_187;
    unsigned int zT_188;
    zT_0624AC1B_TailCallData zT_190;
    unsigned char zT_191;
    unsigned char zT_194;
    unsigned int zT_195;
    unsigned int zT_198;
    unsigned char zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned char zT_206;
    unsigned int zT_210;
    unsigned int zT_214;
    unsigned int zT_218;
    unsigned int zT_222;
    unsigned int zT_226;
    unsigned int zT_230;
    unsigned int zT_234;
    unsigned int zT_238;
    unsigned int zT_242;
    unsigned int zT_246;
    unsigned char zT_248;
    unsigned int zT_249;
    unsigned int zT_253;
    unsigned int zT_257;
    unsigned int zT_261;
    unsigned int zT_265;
    unsigned int zT_269;
    unsigned int zT_273;
    unsigned int zT_277;
    unsigned int zT_281;
    zT_6D148508_Scan* zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    unsigned int zT_292;
    unsigned int zT_296;
    unsigned int zT_300;
    unsigned int zT_304;
    unsigned int zT_308;
    unsigned char zT_310;
    unsigned int zT_311;
    unsigned int zT_315;
    unsigned char zT_317;
    unsigned int zT_318;
    unsigned int zT_322;
    unsigned int zT_326;
    unsigned int zT_330;
    unsigned char zT_332;
    unsigned int zT_333;
    unsigned int zT_337;
    unsigned char zT_339;
    unsigned int zT_340;
    unsigned int zT_344;
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zT_87D97B7B_anon_116759 a;
    zT_89DDFBCF_anon_116773 a_1;
    zT_09F908CC_anon_116783 a_2;
    zT_09F6CA35_anon_116793 b;
    zT_7FBA0C01_anon_116803 s;
    unsigned int r;
    zT_03BF58FB_anon_116827 b_3;
    zT_F1C17B3C_anon_116835 u;
    zT_4DC770B0_anon_117245 o;
    zT_55C53EB1_anon_117259 o_4;
    zT_E3C00E0D_anon_117273 o_5;
    zT_CFD137B2_anon_117287 o_6;
    zT_DDCF0F25_anon_117299 o_7;
    zT_6528A7E2_anon_117315 o_8;
    zT_F1C3B9D3_anon_116845 cl;
    zT_81C6DB1A_anon_116859 lf;
    zT_D3BB77AF_anon_117213 lb;
    zT_87CB61BA_anon_116873 sf;
    zT_4BB86300_anon_117223 sb;
    zT_71A66E3F_anon_116885 li;
    zT_71A8ACD6_anon_116891 l;
    zT_73A8AFFC_anon_116897 st;
    zT_DC513CA6_anon_116903 a_9;
    zT_F24F20B1_anon_116915 a_10;
    zT_EC4CD8A8_anon_116923 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_6A49CD6B_anon_116931 vs;
    zT_6249C0D3_anon_116939 va;
    zT_745B264A_anon_116943 ve;
    zT_0624AC1B_TailCallData tc;
    zT_6658D1A9_anon_116959 u_11;
    zT_692AECC5_anon_117321 u_12;
    zT_62568CC6_anon_116965 u_13;
    zT_62544E2F_anon_116971 ch;
    zT_6A545AC7_anon_116979 w_14;
    zT_F03DD46A_anon_116987 w_15;
    zT_E43B82EF_anon_116993 u_16;
    zT_EE3B92AD_anon_116999 u_17;
    zT_BAEC5FFA_anon_117005 ch_18;
    zT_B6EA1B17_anon_117015 ms;
    zT_24F18406_anon_117023 ic;
    zT_F5304657_anon_117341 ic_19;
    zT_F7328814_anon_117353 ww;
    zT_BEEEA4DD_anon_117031 fc;
    zT_B6EE9845_anon_117039 pc;
    zT_28F60780_anon_117047 itf;
    zT_2CF3CF35_anon_117053 pti;
    zT_BAFB6A84_anon_117061 itp;
    zT_CE4FCF77_anon_117121 ll;
    zT_CC4FCC51_anon_117127 sl;
    zT_C04B3C3F_anon_117143 sg;
    zT_CC4D8DBA_anon_117157 pv;
    zT_3645E5D3_anon_117161 bpc;
    zT_3C45EF45_anon_117167 b_20;
    zT_B848F110_anon_117173 b_21;
    zT_4A689791_anon_117181 be;
    zT_4E689DDD_anon_117185 bsm;
    zT_D06BA91A_anon_117193 bcg;
    zT_C66B995C_anon_117199 bcc;
    zT_49B62143_anon_117231 ct;
    zT_3 = inst.tag;
switch (zT_3) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 72: goto z_bb_9;
case 73: goto z_bb_10;
case 74: goto z_bb_11;
case 75: goto z_bb_12;
case 76: goto z_bb_13;
case 77: goto z_bb_14;
case 14: goto z_bb_15;
case 15: goto z_bb_16;
case 68: goto z_bb_17;
case 16: goto z_bb_18;
case 69: goto z_bb_19;
case 17: goto z_bb_20;
case 18: goto z_bb_21;
case 19: goto z_bb_22;
case 20: goto z_bb_23;
case 21: goto z_bb_24;
case 22: goto z_bb_25;
case 23: goto z_bb_26;
case 24: goto z_bb_27;
case 25: goto z_bb_28;
case 26: goto z_bb_29;
case 27: goto z_bb_30;
case 29: goto z_bb_31;
case 78: goto z_bb_32;
case 30: goto z_bb_33;
case 31: goto z_bb_34;
case 32: goto z_bb_35;
case 33: goto z_bb_36;
case 34: goto z_bb_37;
case 35: goto z_bb_38;
case 36: goto z_bb_39;
case 37: goto z_bb_40;
case 38: goto z_bb_41;
case 80: goto z_bb_42;
case 81: goto z_bb_43;
case 39: goto z_bb_44;
case 40: goto z_bb_45;
case 41: goto z_bb_46;
case 42: goto z_bb_47;
case 43: goto z_bb_48;
case 52: goto z_bb_49;
case 53: goto z_bb_50;
case 55: goto z_bb_51;
case 57: goto z_bb_52;
case 58: goto z_bb_53;
case 59: goto z_bb_54;
case 60: goto z_bb_55;
case 62: goto z_bb_56;
case 63: goto z_bb_57;
case 65: goto z_bb_58;
case 66: goto z_bb_59;
case 71: goto z_bb_60;
default: goto z_bb_61;
}
    z_bb_1:
    a = inst.payload.assign._0;
    zT_5 = a.src;
    if ((unsigned char)(zT_5 == v)) goto z_bb_64; else goto z_bb_65;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    zT_9 = a_1.base;
    if ((unsigned char)(zT_9 == v)) goto z_bb_67; else goto z_bb_66;
    z_bb_3:
    a_2 = inst.payload.assign_index._0;
    zT_16 = a_2.base;
    if ((unsigned char)(zT_16 == v)) goto z_bb_72; else goto z_bb_71;
    z_bb_4:
    b = inst.payload.branch._0;
    zT_26 = b.cond;
    if ((unsigned char)(zT_26 == v)) goto z_bb_79; else goto z_bb_80;
    z_bb_5:
    s = inst.payload.switch_br._0;
    zT_30 = s.cond;
    if ((unsigned char)(zT_30 == v)) goto z_bb_81; else goto z_bb_82;
    z_bb_6:
    r = inst.payload.jump._0;
    if ((unsigned char)(r == v)) goto z_bb_83; else goto z_bb_84;
    z_bb_7:
    b_3 = inst.payload.binary._0;
    zT_37 = b_3.lhs;
    if ((unsigned char)(zT_37 == v)) goto z_bb_86; else goto z_bb_85;
    z_bb_8:
    u = inst.payload.unary._0;
    zT_44 = u.operand;
    if ((unsigned char)(zT_44 == v)) goto z_bb_90; else goto z_bb_91;
    z_bb_9:
    o = inst.payload.add_with_overflow._0;
    zT_48 = o.lhs;
    if ((unsigned char)(zT_48 == v)) goto z_bb_93; else goto z_bb_92;
    z_bb_10:
    o_4 = inst.payload.sub_with_overflow._0;
    zT_55 = o_4.lhs;
    if ((unsigned char)(zT_55 == v)) goto z_bb_98; else goto z_bb_97;
    z_bb_11:
    o_5 = inst.payload.mul_with_overflow._0;
    zT_62 = o_5.lhs;
    if ((unsigned char)(zT_62 == v)) goto z_bb_103; else goto z_bb_102;
    z_bb_12:
    o_6 = inst.payload.shl_with_overflow._0;
    zT_69 = o_6.lhs;
    if ((unsigned char)(zT_69 == v)) goto z_bb_108; else goto z_bb_107;
    z_bb_13:
    o_7 = inst.payload.neg_with_overflow._0;
    zT_76 = o_7.value;
    if ((unsigned char)(zT_76 == v)) goto z_bb_112; else goto z_bb_113;
    z_bb_14:
    o_8 = inst.payload.overflow_flag._0;
    zT_80 = o_8.lhs;
    if ((unsigned char)(zT_80 == v)) goto z_bb_115; else goto z_bb_114;
    z_bb_15:
    cl = inst.payload.call._0;
    zT_87 = cl.callee;
    if ((unsigned char)(zT_87 == v)) goto z_bb_119; else goto z_bb_120;
    z_bb_16:
    lf = inst.payload.load_field._0;
    zT_102 = lf.base;
    if ((unsigned char)(zT_102 == v)) goto z_bb_126; else goto z_bb_127;
    z_bb_17:
    lb = inst.payload.load_bitfield._0;
    zT_106 = lb.base;
    if ((unsigned char)(zT_106 == v)) goto z_bb_128; else goto z_bb_129;
    z_bb_18:
    sf = inst.payload.store_field._0;
    zT_110 = sf.base;
    if ((unsigned char)(zT_110 == v)) goto z_bb_131; else goto z_bb_130;
    z_bb_19:
    sb = inst.payload.store_bitfield._0;
    zT_117 = sb.base;
    if ((unsigned char)(zT_117 == v)) goto z_bb_136; else goto z_bb_135;
    z_bb_20:
    li = inst.payload.load_index._0;
    zT_124 = li.base;
    if ((unsigned char)(zT_124 == v)) goto z_bb_141; else goto z_bb_140;
    z_bb_21:
    l = inst.payload.load._0;
    zT_131 = l.ptr;
    if ((unsigned char)(zT_131 == v)) goto z_bb_145; else goto z_bb_146;
    z_bb_22:
    st = inst.payload.store._0;
    zT_135 = st.ptr;
    if ((unsigned char)(zT_135 == v)) goto z_bb_148; else goto z_bb_147;
    z_bb_23:
    a_9 = inst.payload.addr_of._0;
    zT_142 = a_9.operand;
    if ((unsigned char)(zT_142 == v)) goto z_bb_152; else goto z_bb_153;
    z_bb_24:
    a_10 = inst.payload.addr_of_field._0;
    zT_146 = a_10.base;
    if ((unsigned char)(zT_146 == v)) goto z_bb_154; else goto z_bb_155;
    z_bb_25:
    w = inst.payload.wrap_optional._0;
    zT_150 = w.value;
    if ((unsigned char)(zT_150 == v)) goto z_bb_156; else goto z_bb_157;
    z_bb_26:
    slot = inst.payload.jump._0;
    zT_155 = c->lir_fn;
    zT_156 = slot;
    zT_158 = zF_75DE985C_lirSideGetCallDirec(zT_155, zT_156);
    cd = zT_158;
    zT_159 = cd.args_start;
    if ((unsigned char)(v >= zT_159)) goto z_bb_158; else goto z_bb_159;
    z_bb_27:
    vs = inst.payload.va_start._0;
    zT_171 = vs.va_list_temp;
    if ((unsigned char)(zT_171 == v)) goto z_bb_164; else goto z_bb_163;
    z_bb_28:
    va = inst.payload.va_arg._0;
    zT_178 = va.va_list_temp;
    if ((unsigned char)(zT_178 == v)) goto z_bb_168; else goto z_bb_169;
    z_bb_29:
    ve = inst.payload.va_end._0;
    zT_182 = ve.va_list_temp;
    if ((unsigned char)(zT_182 == v)) goto z_bb_170; else goto z_bb_171;
    z_bb_30:
    slot = inst.payload.jump._0;
    zT_187 = c->lir_fn;
    zT_188 = slot;
    zT_190 = zF_1AB3807F_lirSideGetTailCall(zT_187, zT_188);
    tc = zT_190;
    zT_191 = tc.is_indirect;
    if ((unsigned char)(zT_191 != (unsigned char)(0))) goto z_bb_172; else goto z_bb_173;
    z_bb_31:
    u_11 = inst.payload.unwrap_optional._0;
    zT_210 = u_11.value;
    if ((unsigned char)(zT_210 == v)) goto z_bb_182; else goto z_bb_183;
    z_bb_32:
    u_12 = inst.payload.unwrap_optional_checked._0;
    zT_214 = u_12.value;
    if ((unsigned char)(zT_214 == v)) goto z_bb_184; else goto z_bb_185;
    z_bb_33:
    u_13 = inst.payload.unwrap_optional_abi._0;
    zT_218 = u_13.value;
    if ((unsigned char)(zT_218 == v)) goto z_bb_186; else goto z_bb_187;
    z_bb_34:
    ch = inst.payload.check_optional._0;
    zT_222 = ch.value;
    if ((unsigned char)(zT_222 == v)) goto z_bb_188; else goto z_bb_189;
    z_bb_35:
    w_14 = inst.payload.wrap_error_ok._0;
    zT_226 = w_14.value;
    if ((unsigned char)(zT_226 == v)) goto z_bb_190; else goto z_bb_191;
    z_bb_36:
    w_15 = inst.payload.wrap_error_err._0;
    zT_230 = w_15.value;
    if ((unsigned char)(zT_230 == v)) goto z_bb_192; else goto z_bb_193;
    z_bb_37:
    u_16 = inst.payload.unwrap_error_payload._0;
    zT_234 = u_16.value;
    if ((unsigned char)(zT_234 == v)) goto z_bb_194; else goto z_bb_195;
    z_bb_38:
    u_17 = inst.payload.unwrap_error_code._0;
    zT_238 = u_17.value;
    if ((unsigned char)(zT_238 == v)) goto z_bb_196; else goto z_bb_197;
    z_bb_39:
    ch_18 = inst.payload.check_error._0;
    zT_242 = ch_18.value;
    if ((unsigned char)(zT_242 == v)) goto z_bb_198; else goto z_bb_199;
    z_bb_40:
    ms = inst.payload.make_slice._0;
    zT_246 = ms.ptr;
    if ((unsigned char)(zT_246 == v)) goto z_bb_201; else goto z_bb_200;
    z_bb_41:
    ic = inst.payload.int_cast._0;
    zT_253 = ic.value;
    if ((unsigned char)(zT_253 == v)) goto z_bb_205; else goto z_bb_206;
    z_bb_42:
    ic_19 = inst.payload.int_cast_checked._0;
    zT_257 = ic_19.value;
    if ((unsigned char)(zT_257 == v)) goto z_bb_207; else goto z_bb_208;
    z_bb_43:
    ww = inst.payload.width_wrap._0;
    zT_261 = ww.value;
    if ((unsigned char)(zT_261 == v)) goto z_bb_209; else goto z_bb_210;
    z_bb_44:
    fc = inst.payload.float_cast._0;
    zT_265 = fc.value;
    if ((unsigned char)(zT_265 == v)) goto z_bb_211; else goto z_bb_212;
    z_bb_45:
    pc = inst.payload.ptr_cast._0;
    zT_269 = pc.value;
    if ((unsigned char)(zT_269 == v)) goto z_bb_213; else goto z_bb_214;
    z_bb_46:
    itf = inst.payload.int_to_float._0;
    zT_273 = itf.value;
    if ((unsigned char)(zT_273 == v)) goto z_bb_215; else goto z_bb_216;
    z_bb_47:
    pti = inst.payload.ptr_to_int._0;
    zT_277 = pti.value;
    if ((unsigned char)(zT_277 == v)) goto z_bb_217; else goto z_bb_218;
    z_bb_48:
    itp = inst.payload.int_to_ptr._0;
    zT_281 = itp.value;
    if ((unsigned char)(zT_281 == v)) goto z_bb_219; else goto z_bb_220;
    z_bb_49:
    ll = inst.payload.load_local._0;
    zT_285 = c;
    zT_286 = ll.name_id;
    zT_288 = zF_CD424A09_localStorage(zT_285, zT_286);
    if ((unsigned char)(zT_288 == v)) goto z_bb_221; else goto z_bb_222;
    z_bb_50:
    sl = inst.payload.store_local._0;
    zT_292 = sl.value;
    if ((unsigned char)(zT_292 == v)) goto z_bb_223; else goto z_bb_224;
    z_bb_51:
    sg = inst.payload.store_global._0;
    zT_296 = sg.value;
    if ((unsigned char)(zT_296 == v)) goto z_bb_225; else goto z_bb_226;
    z_bb_52:
    pv = inst.payload.print_val._0;
    zT_300 = pv.value;
    if ((unsigned char)(zT_300 == v)) goto z_bb_227; else goto z_bb_228;
    z_bb_53:
    bpc = inst.payload.builtin_put_char._0;
    zT_304 = bpc.value;
    if ((unsigned char)(zT_304 == v)) goto z_bb_229; else goto z_bb_230;
    z_bb_54:
    b_20 = inst.payload.builtin_stdout_write._0;
    zT_308 = b_20.ptr;
    if ((unsigned char)(zT_308 == v)) goto z_bb_232; else goto z_bb_231;
    z_bb_55:
    b_21 = inst.payload.builtin_stderr_write._0;
    zT_315 = b_21.ptr;
    if ((unsigned char)(zT_315 == v)) goto z_bb_237; else goto z_bb_236;
    z_bb_56:
    be = inst.payload.builtin_exit._0;
    zT_322 = be.value;
    if ((unsigned char)(zT_322 == v)) goto z_bb_241; else goto z_bb_242;
    z_bb_57:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_326 = bsm.value;
    if ((unsigned char)(zT_326 == v)) goto z_bb_243; else goto z_bb_244;
    z_bb_58:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_330 = bcg.x;
    if ((unsigned char)(zT_330 == v)) goto z_bb_246; else goto z_bb_245;
    z_bb_59:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_337 = bcc.fg;
    if ((unsigned char)(zT_337 == v)) goto z_bb_251; else goto z_bb_250;
    z_bb_60:
    ct = inst.payload.check_trap._0;
    zT_344 = ct.cond;
    if ((unsigned char)(zT_344 == v)) goto z_bb_255; else goto z_bb_256;
    z_bb_61:
    goto z_bb_63;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    return (unsigned char)(1);
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_12 = a_1.src;
    zT_11 = zT_12 == v;
    goto z_bb_68;
    z_bb_67:
    zT_11 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_11) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    goto z_bb_63;
    z_bb_71:
    zT_19 = a_2.index;
    zT_18 = zT_19 == v;
    goto z_bb_73;
    z_bb_72:
    zT_18 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_18) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_22 = a_2.src;
    zT_21 = zT_22 == v;
    goto z_bb_76;
    z_bb_75:
    zT_21 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_21) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    return (unsigned char)(1);
    z_bb_78:
    goto z_bb_63;
    z_bb_79:
    return (unsigned char)(1);
    z_bb_80:
    goto z_bb_63;
    z_bb_81:
    return (unsigned char)(1);
    z_bb_82:
    goto z_bb_63;
    z_bb_83:
    return (unsigned char)(1);
    z_bb_84:
    goto z_bb_63;
    z_bb_85:
    zT_40 = b_3.rhs;
    zT_39 = zT_40 == v;
    goto z_bb_87;
    z_bb_86:
    zT_39 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_39) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    return (unsigned char)(1);
    z_bb_89:
    goto z_bb_63;
    z_bb_90:
    return (unsigned char)(1);
    z_bb_91:
    goto z_bb_63;
    z_bb_92:
    zT_51 = o.rhs;
    zT_50 = zT_51 == v;
    goto z_bb_94;
    z_bb_93:
    zT_50 = 1;
    goto z_bb_94;
    z_bb_94:
    if (zT_50) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    return (unsigned char)(1);
    z_bb_96:
    goto z_bb_63;
    z_bb_97:
    zT_58 = o_4.rhs;
    zT_57 = zT_58 == v;
    goto z_bb_99;
    z_bb_98:
    zT_57 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_57) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (unsigned char)(1);
    z_bb_101:
    goto z_bb_63;
    z_bb_102:
    zT_65 = o_5.rhs;
    zT_64 = zT_65 == v;
    goto z_bb_104;
    z_bb_103:
    zT_64 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_64) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    return (unsigned char)(1);
    z_bb_106:
    goto z_bb_63;
    z_bb_107:
    zT_72 = o_6.rhs;
    zT_71 = zT_72 == v;
    goto z_bb_109;
    z_bb_108:
    zT_71 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_71) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (unsigned char)(1);
    z_bb_111:
    goto z_bb_63;
    z_bb_112:
    return (unsigned char)(1);
    z_bb_113:
    goto z_bb_63;
    z_bb_114:
    zT_83 = o_8.rhs;
    zT_82 = zT_83 == v;
    goto z_bb_116;
    z_bb_115:
    zT_82 = 1;
    goto z_bb_116;
    z_bb_116:
    if (zT_82) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    return (unsigned char)(1);
    z_bb_118:
    goto z_bb_63;
    z_bb_119:
    return (unsigned char)(1);
    z_bb_120:
    zT_90 = cl.args_start;
    if ((unsigned char)(v >= zT_90)) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_93 = cl.args_start;
    zT_94 = cl.args_count;
    zT_95 = zig_wrap_add_u(((zu64)(zT_93)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(zT_93)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    zT_92 = v < zT_95;
    goto z_bb_123;
    z_bb_122:
    zT_92 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_92) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (unsigned char)(1);
    z_bb_125:
    goto z_bb_63;
    z_bb_126:
    return (unsigned char)(1);
    z_bb_127:
    goto z_bb_63;
    z_bb_128:
    return (unsigned char)(1);
    z_bb_129:
    goto z_bb_63;
    z_bb_130:
    zT_113 = sf.value;
    zT_112 = zT_113 == v;
    goto z_bb_132;
    z_bb_131:
    zT_112 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_112) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    return (unsigned char)(1);
    z_bb_134:
    goto z_bb_63;
    z_bb_135:
    zT_120 = sb.value;
    zT_119 = zT_120 == v;
    goto z_bb_137;
    z_bb_136:
    zT_119 = 1;
    goto z_bb_137;
    z_bb_137:
    if (zT_119) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (unsigned char)(1);
    z_bb_139:
    goto z_bb_63;
    z_bb_140:
    zT_127 = li.index;
    zT_126 = zT_127 == v;
    goto z_bb_142;
    z_bb_141:
    zT_126 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_126) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    return (unsigned char)(1);
    z_bb_144:
    goto z_bb_63;
    z_bb_145:
    return (unsigned char)(1);
    z_bb_146:
    goto z_bb_63;
    z_bb_147:
    zT_138 = st.value;
    zT_137 = zT_138 == v;
    goto z_bb_149;
    z_bb_148:
    zT_137 = 1;
    goto z_bb_149;
    z_bb_149:
    if (zT_137) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (unsigned char)(1);
    z_bb_151:
    goto z_bb_63;
    z_bb_152:
    return (unsigned char)(1);
    z_bb_153:
    goto z_bb_63;
    z_bb_154:
    return (unsigned char)(1);
    z_bb_155:
    goto z_bb_63;
    z_bb_156:
    return (unsigned char)(1);
    z_bb_157:
    goto z_bb_63;
    z_bb_158:
    zT_162 = cd.args_start;
    zT_163 = cd.args_count;
    zT_164 = zig_wrap_add_u(((zu64)(zT_162)), ((zu64)(zT_163)), 32u);
    zT_165 = zig_overflow_flag_add_u(((zu64)(zT_162)), ((zu64)(zT_163)), 32u);
    zT_167 = zT_165 == (unsigned int)(0);
    if (!(zT_167)) { pal_trap(); }
    zT_161 = v < zT_164;
    goto z_bb_160;
    z_bb_159:
    zT_161 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_161) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (unsigned char)(1);
    z_bb_162:
    goto z_bb_63;
    z_bb_163:
    zT_174 = vs.last_param_temp;
    zT_173 = zT_174 == v;
    goto z_bb_165;
    z_bb_164:
    zT_173 = 1;
    goto z_bb_165;
    z_bb_165:
    if (zT_173) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (unsigned char)(1);
    z_bb_167:
    goto z_bb_63;
    z_bb_168:
    return (unsigned char)(1);
    z_bb_169:
    goto z_bb_63;
    z_bb_170:
    return (unsigned char)(1);
    z_bb_171:
    goto z_bb_63;
    z_bb_172:
    zT_195 = tc.callee;
    zT_194 = zT_195 == v;
    goto z_bb_174;
    z_bb_173:
    zT_194 = 0;
    goto z_bb_174;
    z_bb_174:
    if (zT_194) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    return (unsigned char)(1);
    z_bb_176:
    zT_198 = tc.args_start;
    if ((unsigned char)(v >= zT_198)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_201 = tc.args_start;
    zT_202 = tc.args_count;
    zT_203 = zig_wrap_add_u(((zu64)(zT_201)), ((zu64)(zT_202)), 32u);
    zT_204 = zig_overflow_flag_add_u(((zu64)(zT_201)), ((zu64)(zT_202)), 32u);
    zT_206 = zT_204 == (unsigned int)(0);
    if (!(zT_206)) { pal_trap(); }
    zT_200 = v < zT_203;
    goto z_bb_179;
    z_bb_178:
    zT_200 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_200) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    return (unsigned char)(1);
    z_bb_181:
    goto z_bb_63;
    z_bb_182:
    return (unsigned char)(1);
    z_bb_183:
    goto z_bb_63;
    z_bb_184:
    return (unsigned char)(1);
    z_bb_185:
    goto z_bb_63;
    z_bb_186:
    return (unsigned char)(1);
    z_bb_187:
    goto z_bb_63;
    z_bb_188:
    return (unsigned char)(1);
    z_bb_189:
    goto z_bb_63;
    z_bb_190:
    return (unsigned char)(1);
    z_bb_191:
    goto z_bb_63;
    z_bb_192:
    return (unsigned char)(1);
    z_bb_193:
    goto z_bb_63;
    z_bb_194:
    return (unsigned char)(1);
    z_bb_195:
    goto z_bb_63;
    z_bb_196:
    return (unsigned char)(1);
    z_bb_197:
    goto z_bb_63;
    z_bb_198:
    return (unsigned char)(1);
    z_bb_199:
    goto z_bb_63;
    z_bb_200:
    zT_249 = ms.len;
    zT_248 = zT_249 == v;
    goto z_bb_202;
    z_bb_201:
    zT_248 = 1;
    goto z_bb_202;
    z_bb_202:
    if (zT_248) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    return (unsigned char)(1);
    z_bb_204:
    goto z_bb_63;
    z_bb_205:
    return (unsigned char)(1);
    z_bb_206:
    goto z_bb_63;
    z_bb_207:
    return (unsigned char)(1);
    z_bb_208:
    goto z_bb_63;
    z_bb_209:
    return (unsigned char)(1);
    z_bb_210:
    goto z_bb_63;
    z_bb_211:
    return (unsigned char)(1);
    z_bb_212:
    goto z_bb_63;
    z_bb_213:
    return (unsigned char)(1);
    z_bb_214:
    goto z_bb_63;
    z_bb_215:
    return (unsigned char)(1);
    z_bb_216:
    goto z_bb_63;
    z_bb_217:
    return (unsigned char)(1);
    z_bb_218:
    goto z_bb_63;
    z_bb_219:
    return (unsigned char)(1);
    z_bb_220:
    goto z_bb_63;
    z_bb_221:
    return (unsigned char)(1);
    z_bb_222:
    goto z_bb_63;
    z_bb_223:
    return (unsigned char)(1);
    z_bb_224:
    goto z_bb_63;
    z_bb_225:
    return (unsigned char)(1);
    z_bb_226:
    goto z_bb_63;
    z_bb_227:
    return (unsigned char)(1);
    z_bb_228:
    goto z_bb_63;
    z_bb_229:
    return (unsigned char)(1);
    z_bb_230:
    goto z_bb_63;
    z_bb_231:
    zT_311 = b_20.len;
    zT_310 = zT_311 == v;
    goto z_bb_233;
    z_bb_232:
    zT_310 = 1;
    goto z_bb_233;
    z_bb_233:
    if (zT_310) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (unsigned char)(1);
    z_bb_235:
    goto z_bb_63;
    z_bb_236:
    zT_318 = b_21.len;
    zT_317 = zT_318 == v;
    goto z_bb_238;
    z_bb_237:
    zT_317 = 1;
    goto z_bb_238;
    z_bb_238:
    if (zT_317) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    return (unsigned char)(1);
    z_bb_240:
    goto z_bb_63;
    z_bb_241:
    return (unsigned char)(1);
    z_bb_242:
    goto z_bb_63;
    z_bb_243:
    return (unsigned char)(1);
    z_bb_244:
    goto z_bb_63;
    z_bb_245:
    zT_333 = bcg.y;
    zT_332 = zT_333 == v;
    goto z_bb_247;
    z_bb_246:
    zT_332 = 1;
    goto z_bb_247;
    z_bb_247:
    if (zT_332) goto z_bb_248; else goto z_bb_249;
    z_bb_248:
    return (unsigned char)(1);
    z_bb_249:
    goto z_bb_63;
    z_bb_250:
    zT_340 = bcc.bg;
    zT_339 = zT_340 == v;
    goto z_bb_252;
    z_bb_251:
    zT_339 = 1;
    goto z_bb_252;
    z_bb_252:
    if (zT_339) goto z_bb_253; else goto z_bb_254;
    z_bb_253:
    return (unsigned char)(1);
    z_bb_254:
    goto z_bb_63;
    z_bb_255:
    return (unsigned char)(1);
    z_bb_256:
    goto z_bb_63;
}

/* instIsSuspendPoint */
unsigned char zF_1AAC25A7_instIsSuspendPoint(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_6;
    unsigned int zT_7;
    zT_3BFB1E70_CallDirectData zT_9;
    zT_A4CE86B7_U64ToU32Map* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_15;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_B6F925A1_anon_117071 ic;
    zT_3 = inst.tag;
switch (zT_3) {
case 23: goto z_bb_1;
case 44: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    slot = inst.payload.jump._0;
    zT_6 = c->lir_fn;
    zT_7 = slot;
    zT_9 = zF_75DE985C_lirSideGetCallDirec(zT_6, zT_7);
    cd = zT_9;
    zT_10 = suspending_fns;
    zT_11 = cd.module_id;
    zT_12 = cd.name_id;
    zT_15 = zF_7C7E43BF_asyncIsSuspending(zT_10, zT_11, zT_12);
    return zT_15;
    z_bb_2:
    ic = inst.payload.int_const._0;
    zT_17 = ic.value;
    if ((unsigned char)(zT_17 != (zT_79FAE712_u64)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    return (unsigned char)(0);
    return 0;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_21 = ic.result;
    zT_22 = c->max_temp;
    if ((unsigned char)(zT_21 >= zT_22)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_25 = c->reg;
    zT_28 = c->ttype;
    zT_29 = ic.result;
    zT_30 = (unsigned int)zT_29;
    zT_26 = zT_28[zT_30];
    zT_32 = zF_5049D2D3_typeIsPtrVoid(zT_25, zT_26);
    return zT_32;
}

/* hasDefBefore */
unsigned char zF_93E9604D_hasDefBefore(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_13;
    zT_1CF28CA3_BasicBlockArrayList zT_14;
    zT_88A68B1A_BasicBlock* zT_15;
    zT_88A68B1A_BasicBlock* zT_16;
    unsigned int zT_18;
    zT_DAE4631D_LirInstArrayList zT_19;
    unsigned int zT_20;
    unsigned char zT_24;
    zT_6D148508_Scan* zT_27;
    zT_6BA597BC_LirInst zT_28;
    unsigned int zT_29;
    zT_DAE4631D_LirInstArrayList zT_30;
    zT_6BA597BC_LirInst* zT_31;
    zT_6BA597BC_LirInst zT_32;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = 0;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((unsigned char)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    if ((unsigned char)((unsigned int)((unsigned int)bi) > sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_40 = 1;
    zT_41 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    bi = zT_41;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_13 = c->lir_fn;
    zT_14 = zT_13->blocks;
    zT_15 = zT_14.items;
    zT_16 = zT_15 + bi;
    bb = zT_16;
    zT_18 = 0;
    ii = zT_18;
    goto z_bb_7;
    z_bb_7:
    zT_19 = bb->insts;
    zT_20 = zT_19.len;
    if ((unsigned char)(ii < zT_20)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    if ((unsigned char)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_35 = 1;
    zT_36 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    ii = zT_36;
    goto z_bb_7;
    z_bb_11:
    zT_24 = (unsigned int)((unsigned int)ii) >= sii;
    goto z_bb_13;
    z_bb_12:
    zT_24 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_24) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_27 = c;
    zT_30 = bb->insts;
    zT_31 = zT_30.items;
    zT_32 = zT_31[ii];
    zT_28 = zT_32;
    zT_29 = v;
    zT_33 = zF_1FF90D33_instDefsTemp(zT_27, zT_28, zT_29);
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    goto z_bb_10;
}

/* cfgPushSuccessors */
void zF_D7490A6E_cfgPushSuccessors(zT_6D148508_Scan* c, unsigned int b, unsigned int* sp) {
    zT_BBC23664_LirFunction* zT_4;
    zT_1CF28CA3_BasicBlockArrayList zT_5;
    zT_88A68B1A_BasicBlock* zT_6;
    zT_88A68B1A_BasicBlock* zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    zT_DAE4631D_LirInstArrayList zT_13;
    unsigned int zT_14;
    zT_DAE4631D_LirInstArrayList zT_16;
    zT_6BA597BC_LirInst* zT_17;
    zT_6BA597BC_LirInst zT_18;
    unsigned int zT_19;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned int zT_32;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned int* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned char zT_52;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_BBC23664_LirFunction* zT_65;
    zT_9F514E82_SwitchCaseArrayList zT_66;
    zT_4BD97095_SwitchCase* zT_67;
    unsigned int zT_68;
    zT_4BD97095_SwitchCase zT_69;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned char zT_109;
    unsigned int zT_110;
    unsigned int* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    zT_88A68B1A_BasicBlock* bb;
    unsigned char terminated;
    unsigned int ii;
    unsigned int jb;
    zT_09F6CA35_anon_116793 br;
    zT_7FBA0C01_anon_116803 sw;
    unsigned int si;
    unsigned int se;
    zT_4BD97095_SwitchCase sc;
    unsigned int nxt;
    zT_4 = c->lir_fn;
    zT_5 = zT_4->blocks;
    zT_6 = zT_5.items;
    zT_8 = zT_6 + (unsigned int)((unsigned int)b);
    bb = zT_8;
    zT_10 = bb->is_terminated;
    terminated = zT_10;
    zT_12 = 0;
    ii = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_13 = bb->insts;
    zT_14 = zT_13.len;
    if ((unsigned char)(ii < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = bb->insts;
    zT_17 = zT_16.items;
    zT_18 = zT_17[ii];
    zT_19 = zT_18.tag;
switch (zT_19) {
case 5: goto z_bb_5;
case 6: goto z_bb_6;
case 7: goto z_bb_7;
case 9: goto z_bb_8;
case 10: goto z_bb_8;
case 70: goto z_bb_8;
default: goto z_bb_9;
}
    z_bb_3:
    if ((unsigned char)(terminated == (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    zT_97 = 1;
    zT_98 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    ii = zT_98;
    goto z_bb_1;
    z_bb_5:
    jb = zT_18.payload.jump._0;
    zT_21 = c->work;
    zT_22 = *sp;
    zT_23 = (unsigned int)zT_22;
    zT_21[zT_23] = jb;
    zT_24 = *sp;
    zT_25 = 1;
    zT_26 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    *sp = zT_26;
    zT_30 = 1;
    terminated = zT_30;
    goto z_bb_11;
    z_bb_6:
    br = zT_18.payload.branch._0;
    zT_32 = br.then_bb;
    zT_33 = c->work;
    zT_34 = *sp;
    zT_35 = (unsigned int)zT_34;
    zT_33[zT_35] = zT_32;
    zT_36 = *sp;
    zT_37 = 1;
    zT_38 = zig_wrap_add_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    *sp = zT_38;
    zT_42 = br.else_bb;
    zT_43 = c->work;
    zT_44 = *sp;
    zT_45 = (unsigned int)zT_44;
    zT_43[zT_45] = zT_42;
    zT_46 = *sp;
    zT_47 = 1;
    zT_48 = zig_wrap_add_u(((zu64)(zT_46)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(zT_46)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    *sp = zT_48;
    zT_52 = 1;
    terminated = zT_52;
    goto z_bb_11;
    z_bb_7:
    sw = zT_18.payload.switch_br._0;
    zT_55 = sw.cases_start;
    si = zT_55;
    zT_57 = sw.cases_start;
    zT_58 = sw.cases_count;
    zT_59 = zig_wrap_add_u(((zu64)(zT_57)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(zT_57)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    se = zT_59;
    goto z_bb_12;
    z_bb_8:
    zT_96 = 1;
    terminated = zT_96;
    goto z_bb_11;
    z_bb_9:
    goto z_bb_11;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    if ((unsigned char)(si < se)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_65 = c->lir_fn;
    zT_66 = zT_65->switch_cases;
    zT_67 = zT_66.items;
    zT_68 = (unsigned int)si;
    zT_69 = zT_67[zT_68];
    sc = zT_69;
    zT_70 = sc.target_bb;
    zT_71 = c->work;
    zT_72 = *sp;
    zT_73 = (unsigned int)zT_72;
    zT_71[zT_73] = zT_70;
    zT_74 = *sp;
    zT_75 = 1;
    zT_76 = zig_wrap_add_u(((zu64)(zT_74)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(zT_74)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    *sp = zT_76;
    goto z_bb_15;
    z_bb_14:
    zT_85 = sw.else_bb;
    zT_86 = c->work;
    zT_87 = *sp;
    zT_88 = (unsigned int)zT_87;
    zT_86[zT_88] = zT_85;
    zT_89 = *sp;
    zT_90 = 1;
    zT_91 = zig_wrap_add_u(((zu64)(zT_89)), ((zu64)(zT_90)), 32u);
    zT_92 = zig_overflow_flag_add_u(((zu64)(zT_89)), ((zu64)(zT_90)), 32u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    *sp = zT_91;
    zT_95 = 1;
    terminated = zT_95;
    goto z_bb_11;
    z_bb_15:
    zT_80 = 1;
    zT_81 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    si = zT_81;
    goto z_bb_12;
    z_bb_16:
    zT_105 = 1;
    zT_106 = zig_wrap_add_u(((zu64)(b)), ((zu64)(zT_105)), 32u);
    zT_107 = zig_overflow_flag_add_u(((zu64)(b)), ((zu64)(zT_105)), 32u);
    zT_109 = zT_107 == (unsigned int)(0);
    if (!(zT_109)) { pal_trap(); }
    nxt = zT_106;
    zT_110 = c->nblocks;
    if ((unsigned char)(nxt < zT_110)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return;
    z_bb_18:
    zT_112 = c->work;
    zT_113 = *sp;
    zT_114 = (unsigned int)zT_113;
    zT_112[zT_114] = nxt;
    zT_115 = *sp;
    zT_116 = 1;
    zT_117 = zig_wrap_add_u(((zu64)(zT_115)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(zT_115)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    *sp = zT_117;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_17;
}

/* hasReadAfter */
unsigned char zF_4CED5DFF_hasReadAfter(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_11;
    zT_1CF28CA3_BasicBlockArrayList zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    zT_88A68B1A_BasicBlock* zT_14;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_DAE4631D_LirInstArrayList zT_25;
    unsigned int zT_26;
    zT_6D148508_Scan* zT_28;
    zT_6BA597BC_LirInst zT_29;
    unsigned int zT_30;
    zT_DAE4631D_LirInstArrayList zT_31;
    zT_6BA597BC_LirInst* zT_32;
    zT_6BA597BC_LirInst zT_33;
    unsigned char zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned int zT_59;
    zT_6D148508_Scan* zT_60;
    unsigned int zT_61;
    unsigned int* zT_62;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    unsigned int* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char* zT_77;
    unsigned int zT_78;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_BBC23664_LirFunction* zT_86;
    zT_1CF28CA3_BasicBlockArrayList zT_87;
    zT_88A68B1A_BasicBlock* zT_88;
    zT_88A68B1A_BasicBlock* zT_90;
    unsigned int zT_92;
    zT_DAE4631D_LirInstArrayList zT_93;
    unsigned int zT_94;
    unsigned char zT_97;
    zT_6D148508_Scan* zT_100;
    zT_6BA597BC_LirInst zT_101;
    unsigned int zT_102;
    zT_DAE4631D_LirInstArrayList zT_103;
    zT_6BA597BC_LirInst* zT_104;
    zT_6BA597BC_LirInst zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    zT_6D148508_Scan* zT_113;
    unsigned int zT_114;
    unsigned int* zT_115;
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned int z;
    unsigned int sp;
    unsigned int b;
    zT_88A68B1A_BasicBlock* bb2;
    unsigned int ii2;
    zT_5 = (unsigned int)sbb;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((unsigned char)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = c->lir_fn;
    zT_12 = zT_11->blocks;
    zT_13 = zT_12.items;
    zT_14 = zT_13 + bi;
    bb = zT_14;
    zT_16 = 0;
    ii = zT_16;
    if ((unsigned char)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_47 = 0;
    z = zT_47;
    goto z_bb_13;
    z_bb_4:
    zT_41 = 1;
    zT_42 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_41)), 32u);
    zT_43 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_41)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    bi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_19 = (unsigned int)sii;
    zT_20 = 1;
    zT_21 = zig_wrap_add_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    ii = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_25 = bb->insts;
    zT_26 = zT_25.len;
    if ((unsigned char)(ii < zT_26)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_28 = c;
    zT_31 = bb->insts;
    zT_32 = zT_31.items;
    zT_33 = zT_32[ii];
    zT_29 = zT_33;
    zT_30 = v;
    zT_34 = zF_E4C3429C_instReadsTemp(zT_28, zT_29, zT_30);
    if (zT_34) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_36 = 1;
    zT_37 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_36)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_36)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    ii = zT_37;
    goto z_bb_7;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_48 = c->nblocks;
    if ((unsigned char)(z < zT_48)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_50 = 0;
    zT_51 = c->visited;
    zT_52 = (unsigned int)z;
    zT_51[zT_52] = zT_50;
    goto z_bb_16;
    z_bb_15:
    zT_59 = 0;
    sp = zT_59;
    zT_60 = c;
    zT_61 = sbb;
    zT_62 = (unsigned int*)&sp;
    zF_D7490A6E_cfgPushSuccessors(zT_60, zT_61, zT_62);
    goto z_bb_17;
    z_bb_16:
    zT_53 = 1;
    zT_54 = zig_wrap_add_u(((zu64)(z)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(z)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    z = zT_54;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(sp > (unsigned int)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_66 = 1;
    zT_67 = zig_wrap_sub_u(((zu64)(sp)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_sub_u(((zu64)(sp)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    sp = zT_67;
    zT_72 = c->work;
    zT_73 = (unsigned int)sp;
    zT_74 = zT_72[zT_73];
    b = zT_74;
    zT_75 = c->nblocks;
    if ((unsigned char)(b >= zT_75)) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_77 = c->visited;
    zT_78 = (unsigned int)b;
    zT_79 = zT_77[zT_78];
    if ((unsigned char)(zT_79 != (unsigned char)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_82 = 1;
    zT_83 = c->visited;
    zT_84 = (unsigned int)b;
    zT_83[zT_84] = zT_82;
    zT_86 = c->lir_fn;
    zT_87 = zT_86->blocks;
    zT_88 = zT_87.items;
    zT_90 = zT_88 + (unsigned int)((unsigned int)b);
    bb2 = zT_90;
    zT_92 = 0;
    ii2 = zT_92;
    goto z_bb_25;
    z_bb_25:
    zT_93 = bb2->insts;
    zT_94 = zT_93.len;
    if ((unsigned char)(ii2 < zT_94)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    if ((unsigned char)(b == sbb)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_113 = c;
    zT_114 = b;
    zT_115 = (unsigned int*)&sp;
    zF_D7490A6E_cfgPushSuccessors(zT_113, zT_114, zT_115);
    goto z_bb_20;
    z_bb_28:
    zT_108 = 1;
    zT_109 = zig_wrap_add_u(((zu64)(ii2)), ((zu64)(zT_108)), 32u);
    zT_110 = zig_overflow_flag_add_u(((zu64)(ii2)), ((zu64)(zT_108)), 32u);
    zT_112 = zT_110 == (unsigned int)(0);
    if (!(zT_112)) { pal_trap(); }
    ii2 = zT_109;
    goto z_bb_25;
    z_bb_29:
    zT_97 = (unsigned int)((unsigned int)ii2) == sii;
    goto z_bb_31;
    z_bb_30:
    zT_97 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_97) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    goto z_bb_33;
    z_bb_33:
    goto z_bb_28;
    z_bb_34:
    zT_100 = c;
    zT_103 = bb2->insts;
    zT_104 = zT_103.items;
    zT_105 = zT_104[ii2];
    zT_101 = zT_105;
    zT_102 = v;
    zT_106 = zF_E4C3429C_instReadsTemp(zT_100, zT_101, zT_102);
    if (zT_106) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    goto z_bb_33;
}

/* addField */
void zF_F2801F08_addField(zT_2CF63CE1_AsyncFrameFieldArra* fields, zT_338B7C76_TypeRegistry* reg, unsigned char kind, unsigned int name_id, unsigned int temp_id, unsigned int type_id, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_9;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int* zT_15;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned int zT_23;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_24;
    zT_902E38E8_AsyncFrameField zT_25;
    zT_902E38E8_AsyncFrameField zT_26;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    unsigned int size;
    unsigned int alignment;
    unsigned int at;
    zT_9 = 0;
    size = zT_9;
    zT_11 = 0;
    alignment = zT_11;
    zT_12 = reg;
    zT_13 = type_id;
    zT_14 = (unsigned int*)&size;
    zT_15 = (unsigned int*)&alignment;
    zF_816D1610_frameFieldSizeAlign(zT_12, zT_13, zT_14, zT_15);
    zT_19 = reg;
    zT_20 = type_id;
    zT_21 = offset;
    zT_22 = max_align;
    zT_23 = zF_769CB99B_addFrameField(zT_19, zT_20, zT_21, zT_22);
    at = zT_23;
    zT_24 = fields;
    zT_26.kind = kind;
    zT_26.name_id = name_id;
    zT_26.temp_id = temp_id;
    zT_26.type_id = type_id;
    zT_26.offset = at;
    zT_26.size = size;
    zT_26.alignment = alignment;
    zT_25 = zT_26;
    zF_92FA7DBC_fieldArrayListAppen(zT_24, zT_25);
    return;
}

/* emitLayoutMarker */
void zF_2B302EFE_emitLayoutMarker(unsigned int module_id, unsigned int name_id, unsigned int size) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_5826BFC7_Arr_unsigned_char_1 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_5826BFC7_Arr_unsigned_char_1 zT_42;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    unsigned char zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_5826BFC7_Arr_unsigned_char_1 zT_75;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    int zT_81;
    unsigned char* zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    unsigned int zT_87;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_4 = "LAYOUT:m";
    zT_6 = 8;
    zT_5.ptr = (unsigned char*)zT_4;
    zT_5.len = zT_6;
    m1 = zT_5;
    zT_7 = m1;
    zF_48AC7B3A_markerWrite(zT_7);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = module_id;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)b1) + zT_15;
    zT_17 = (unsigned int)(12) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    l1 = zT_19;
    zT_21 = 11;
    zT_23 = (unsigned int)(unsigned int)((unsigned int)l1);
    zT_24 = zig_wrap_sub_u(((zu64)(zT_21)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_sub_u(((zu64)(zT_21)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    s1 = zT_24;
    zT_31 = 11;
    zT_32 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_33 = zT_31 - s1;
    zT_34 = s1 <= zT_31;
    if (!(zT_34)) { pal_trap(); }
    zT_35.ptr = (unsigned char*)zT_32;
    zT_35.len = zT_33;
    zT_28 = zT_35;
    zF_48AC7B3A_markerWrite(zT_28);
    zT_37 = ":n";
    zT_39 = 2;
    zT_38.ptr = (unsigned char*)zT_37;
    zT_38.len = zT_39;
    m2 = zT_38;
    zT_40 = m2;
    zF_48AC7B3A_markerWrite(zT_40);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_42[_i];
        _i++;
    }
}
    zT_44 = name_id;
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)b2) + zT_48;
    zT_50 = (unsigned int)(12) - zT_48;
    zT_51.ptr = (unsigned char*)zT_49;
    zT_51.len = zT_50;
    zT_45 = zT_51;
    zT_52 = zF_A7504564_itoa(zT_44, zT_45);
    l2 = zT_52;
    zT_54 = 11;
    zT_56 = (unsigned int)(unsigned int)((unsigned int)l2);
    zT_57 = zig_wrap_sub_u(((zu64)(zT_54)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_sub_u(((zu64)(zT_54)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    s2 = zT_57;
    zT_64 = 11;
    zT_65 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_66 = zT_64 - s2;
    zT_67 = s2 <= zT_64;
    if (!(zT_67)) { pal_trap(); }
    zT_68.ptr = (unsigned char*)zT_65;
    zT_68.len = zT_66;
    zT_61 = zT_68;
    zF_48AC7B3A_markerWrite(zT_61);
    zT_70 = ":s";
    zT_72 = 2;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    m3 = zT_71;
    zT_73 = m3;
    zF_48AC7B3A_markerWrite(zT_73);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_75[_i];
        _i++;
    }
}
    zT_77 = size;
    zT_81 = 0;
    zT_82 = (unsigned char*)((unsigned char*)b3) + zT_81;
    zT_83 = (unsigned int)(12) - zT_81;
    zT_84.ptr = (unsigned char*)zT_82;
    zT_84.len = zT_83;
    zT_78 = zT_84;
    zT_85 = zF_A7504564_itoa(zT_77, zT_78);
    l3 = zT_85;
    zT_87 = 11;
    zT_89 = (unsigned int)(unsigned int)((unsigned int)l3);
    zT_90 = zig_wrap_sub_u(((zu64)(zT_87)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_sub_u(((zu64)(zT_87)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    s3 = zT_90;
    zT_97 = 11;
    zT_98 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_99 = zT_97 - s3;
    zT_100 = s3 <= zT_97;
    if (!(zT_100)) { pal_trap(); }
    zT_101.ptr = (unsigned char*)zT_98;
    zT_101.len = zT_99;
    zT_94 = zT_101;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_103 = "\n";
    zT_105 = 1;
    zT_104.ptr = (unsigned char*)zT_103;
    zT_104.len = zT_105;
    m4 = zT_104;
    zT_106 = m4;
    zF_48AC7B3A_markerWrite(zT_106);
    return;
}

/* asyncTempIsGlobalAlias */
unsigned char zF_C2E0979E_asyncTempIsGlobalAl(unsigned char* alias_flags, unsigned int alias_len, unsigned int temp) {
    unsigned int zT_5;
    unsigned char zT_6;
    if ((unsigned char)(temp >= alias_len)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_5 = (unsigned int)temp;
    zT_6 = alias_flags[zT_5];
    return (unsigned char)(zT_6 != (unsigned char)(0));
}

/* asyncLayoutFrame */
zT_3F3BF87A_AsyncFrameLayout zF_28031796_asyncLayoutFrame(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    zT_BBC23664_LirFunction* zT_13;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    zT_CFE23D0A_LirParamArrayList zT_18;
    unsigned int zT_19;
    zT_5D72FBF8_TempDeclArrayList zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_2CF63CE1_AsyncFrameFieldArra zT_31;
    zT_3E40CD83_Sand* zT_33;
    zT_21D3708C_U32ToU32Map zT_34;
    zT_1CF28CA3_BasicBlockArrayList zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned char* zT_42;
    zT_3E40CD83_Sand* zT_44;
    unsigned int zT_45;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_9F514E82_SwitchCaseArrayList zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned int* zT_65;
    zT_6D148508_Scan zT_67;
    zT_3E40CD83_Sand* zT_68;
    unsigned int zT_69;
    unsigned int* zT_72;
    zT_21D3708C_U32ToU32Map* zT_73;
    unsigned int zT_75;
    zT_5D72FBF8_TempDeclArrayList zT_76;
    unsigned int zT_77;
    zT_5D72FBF8_TempDeclArrayList zT_80;
    zT_1937645B_TempDecl* zT_81;
    zT_1937645B_TempDecl zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned int zT_95;
    zT_CFE23D0A_LirParamArrayList zT_96;
    unsigned int zT_97;
    zT_CFE23D0A_LirParamArrayList zT_100;
    zT_8779209D_LirParam* zT_101;
    zT_8779209D_LirParam zT_102;
    zT_21D3708C_U32ToU32Map* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    unsigned int zT_115;
    zT_1CF28CA3_BasicBlockArrayList zT_116;
    unsigned int zT_117;
    zT_1CF28CA3_BasicBlockArrayList zT_120;
    zT_88A68B1A_BasicBlock* zT_121;
    zT_88A68B1A_BasicBlock* zT_122;
    unsigned int zT_124;
    zT_DAE4631D_LirInstArrayList zT_125;
    unsigned int zT_126;
    zT_DAE4631D_LirInstArrayList zT_128;
    zT_6BA597BC_LirInst* zT_129;
    zT_6BA597BC_LirInst zT_130;
    unsigned int zT_131;
    zT_21D3708C_U32ToU32Map* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned char zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned char zT_148;
    zT_3E40CD83_Sand* zT_150;
    unsigned int zT_151;
    unsigned char* zT_154;
    unsigned int zT_155;
    zT_CFE23D0A_LirParamArrayList zT_156;
    unsigned int zT_157;
    zT_CFE23D0A_LirParamArrayList zT_160;
    zT_8779209D_LirParam* zT_161;
    zT_8779209D_LirParam zT_162;
    unsigned int zT_163;
    unsigned char zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    zT_3E40CD83_Sand* zT_173;
    unsigned int zT_174;
    unsigned char* zT_175;
    unsigned int zT_177;
    unsigned char zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    unsigned int zT_186;
    zT_1CF28CA3_BasicBlockArrayList zT_187;
    unsigned int zT_188;
    zT_1CF28CA3_BasicBlockArrayList zT_191;
    zT_88A68B1A_BasicBlock* zT_192;
    zT_88A68B1A_BasicBlock* zT_193;
    unsigned int zT_195;
    zT_DAE4631D_LirInstArrayList zT_196;
    unsigned int zT_197;
    zT_DAE4631D_LirInstArrayList zT_200;
    zT_6BA597BC_LirInst* zT_201;
    zT_6BA597BC_LirInst zT_202;
    zT_6D148508_Scan* zT_203;
    zT_6BA597BC_LirInst zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    unsigned int zT_211;
    unsigned char zT_212;
    zT_6D148508_Scan* zT_215;
    unsigned int zT_216;
    unsigned char zT_222;
    zT_6D148508_Scan* zT_224;
    unsigned int zT_225;
    unsigned char zT_231;
    unsigned char zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned char zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned char zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned char zT_247;
    unsigned int zT_249;
    unsigned int zT_251;
    unsigned int zT_253;
    zT_A4CE86B7_U64ToU32Map* zT_254;
    zT_79FAE712_u64 zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    zT_79FAE712_u64 zT_260;
    zT_BAEE192E_Opt_10 zT_261;
    unsigned char zT_262;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_264;
    zT_338B7C76_TypeRegistry* zT_265;
    unsigned char zT_266;
    unsigned int* zT_270;
    unsigned int* zT_271;
    unsigned int zT_273;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_279;
    zT_338B7C76_TypeRegistry* zT_280;
    unsigned char zT_281;
    unsigned int* zT_285;
    unsigned int* zT_286;
    unsigned int zT_288;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_294;
    zT_338B7C76_TypeRegistry* zT_295;
    unsigned char zT_296;
    unsigned int zT_299;
    unsigned int* zT_300;
    unsigned int* zT_301;
    unsigned int zT_303;
    unsigned int zT_308;
    zT_CFE23D0A_LirParamArrayList zT_309;
    unsigned int zT_310;
    zT_CFE23D0A_LirParamArrayList zT_313;
    zT_8779209D_LirParam* zT_314;
    zT_8779209D_LirParam zT_315;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    unsigned char zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    unsigned int* zT_322;
    unsigned int* zT_323;
    unsigned int zT_325;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned char zT_335;
    zT_3E40CD83_Sand* zT_337;
    unsigned int zT_338;
    unsigned char* zT_341;
    unsigned int zT_343;
    zT_1CF28CA3_BasicBlockArrayList zT_344;
    unsigned int zT_345;
    zT_1CF28CA3_BasicBlockArrayList zT_348;
    zT_88A68B1A_BasicBlock* zT_349;
    zT_88A68B1A_BasicBlock* zT_350;
    unsigned int zT_352;
    zT_DAE4631D_LirInstArrayList zT_353;
    unsigned int zT_354;
    zT_DAE4631D_LirInstArrayList zT_356;
    zT_6BA597BC_LirInst* zT_357;
    zT_6BA597BC_LirInst zT_358;
    unsigned int zT_359;
    unsigned int zT_361;
    unsigned char zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned char zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned char zT_375;
    unsigned int zT_376;
    unsigned int zT_379;
    unsigned char zT_380;
    unsigned char zT_383;
    unsigned char zT_384;
    unsigned char* zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned char zT_390;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_391;
    zT_338B7C76_TypeRegistry* zT_392;
    unsigned char zT_393;
    unsigned int zT_395;
    unsigned int zT_396;
    unsigned int* zT_397;
    unsigned int* zT_398;
    unsigned int zT_400;
    unsigned int* zT_402;
    unsigned int zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned char zT_410;
    unsigned int zT_412;
    unsigned int zT_414;
    unsigned int zT_415;
    zT_79FAE712_u64 zT_418;
    zT_A4CE86B7_U64ToU32Map* zT_419;
    zT_79FAE712_u64 zT_420;
    zT_BAEE192E_Opt_10 zT_421;
    unsigned char zT_422;
    zT_338B7C76_TypeRegistry* zT_425;
    unsigned int zT_430;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_435;
    zT_338B7C76_TypeRegistry* zT_436;
    unsigned char zT_437;
    unsigned int zT_440;
    unsigned int* zT_441;
    unsigned int* zT_442;
    unsigned int zT_444;
    zT_A4CE86B7_U64ToU32Map* zT_449;
    zT_79FAE712_u64 zT_450;
    zT_BAEE192E_Opt_10 zT_451;
    unsigned char zT_452;
    unsigned char zT_453;
    zT_A4CE86B7_U64ToU32Map* zT_454;
    zT_79FAE712_u64 zT_455;
    zT_BAEE192E_Opt_10 zT_456;
    unsigned char zT_457;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_458;
    zT_338B7C76_TypeRegistry* zT_459;
    unsigned char zT_460;
    unsigned int zT_463;
    unsigned int* zT_464;
    unsigned int* zT_465;
    unsigned int zT_467;
    unsigned int zT_477;
    zT_A4CE86B7_U64ToU32Map* zT_478;
    zT_79FAE712_u64 zT_479;
    zT_BAEE192E_Opt_10 zT_480;
    unsigned char zT_481;
    unsigned int zT_484;
    zT_A4CE86B7_U64ToU32Map* zT_485;
    zT_79FAE712_u64 zT_486;
    zT_BAEE192E_Opt_10 zT_487;
    unsigned char zT_488;
    unsigned int zT_491;
    unsigned int* zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    unsigned char zT_498;
    unsigned int zT_499;
    unsigned int zT_500;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_501;
    zT_338B7C76_TypeRegistry* zT_502;
    unsigned char zT_503;
    unsigned int zT_506;
    unsigned int* zT_507;
    unsigned int* zT_508;
    unsigned int zT_510;
    unsigned int zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    unsigned char zT_519;
    unsigned int zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_530;
    zT_A4CE86B7_U64ToU32Map* zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    zT_BAEE192E_Opt_10 zT_537;
    unsigned char zT_539;
    char* zT_542;
    unsigned int zT_543;
    char* zT_544;
    unsigned int zT_545;
    char* zT_546;
    unsigned int zT_547;
    char* zT_549;
    unsigned int zT_550;
    char* zT_551;
    unsigned int zT_552;
    char* zT_553;
    unsigned int zT_554;
    unsigned int zT_556;
    unsigned int zT_557;
    unsigned int zT_558;
    zT_3F3BF87A_AsyncFrameLayout zT_561;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_175, (unsigned int)sizeof zT_175);
    zig_poison_fill((void*)&zT_207, (unsigned int)sizeof zT_207);
    zig_poison_fill((void*)&zT_222, (unsigned int)sizeof zT_222);
    zig_poison_fill((void*)&zT_231, (unsigned int)sizeof zT_231);
    zig_poison_fill((void*)&zT_260, (unsigned int)sizeof zT_260);
    zig_poison_fill((void*)&zT_261, (unsigned int)sizeof zT_261);
    zig_poison_fill((void*)&zT_341, (unsigned int)sizeof zT_341);
    zig_poison_fill((void*)&zT_390, (unsigned int)sizeof zT_390);
    zig_poison_fill((void*)&zT_418, (unsigned int)sizeof zT_418);
    zig_poison_fill((void*)&zT_421, (unsigned int)sizeof zT_421);
    zig_poison_fill((void*)&zT_430, (unsigned int)sizeof zT_430);
    zig_poison_fill((void*)&zT_451, (unsigned int)sizeof zT_451);
    zig_poison_fill((void*)&zT_456, (unsigned int)sizeof zT_456);
    zig_poison_fill((void*)&zT_480, (unsigned int)sizeof zT_480);
    zig_poison_fill((void*)&zT_487, (unsigned int)sizeof zT_487);
    zig_poison_fill((void*)&zT_523, (unsigned int)sizeof zT_523);
    zig_poison_fill((void*)&zT_530, (unsigned int)sizeof zT_530);
    zig_poison_fill((void*)&zT_537, (unsigned int)sizeof zT_537);
    unsigned int max_temp;
    zT_2CF63CE1_AsyncFrameFieldArra fields;
    zT_21D3708C_U32ToU32Map locals;
    unsigned int nblocks;
    unsigned char* visited;
    unsigned int* work;
    zT_6D148508_Scan c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    unsigned int pi;
    zT_8779209D_LirParam p;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned char* is_param;
    zT_7FD96EE3_anon_116751 dl;
    unsigned int pt;
    unsigned char* live;
    unsigned int t;
    unsigned int offset;
    unsigned int max_align;
    unsigned int state_type;
    zT_6BA597BC_LirInst inst;
    unsigned int tu;
    unsigned int sw;
    unsigned char* alias_flags;
    unsigned int abi;
    zT_88A68B1A_BasicBlock* abb;
    unsigned int aii;
    zT_4E52D78E_anon_117135 lg;
    unsigned int hid;
    zT_79FAE712_u64 lay_key;
    unsigned int h;
    unsigned int lay_ptr_void;
    unsigned int pstart;
    unsigned int precise;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_BAEE192E_Opt_10 frame_size;
    unsigned int padded;
    unsigned int fs;
    zT_13 = lir_fn;
    zT_14 = zF_005F8966_maxTempOf(zT_13);
    max_temp = zT_14;
    zT_16 = alloc;
    zT_18 = lir_fn->params;
    zT_19 = zT_18.len;
    zT_20 = lir_fn->hoisted_temps;
    zT_21 = zT_20.len;
    zT_22 = zig_wrap_add_u(((zu64)(zT_19)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(zT_19)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = 2;
    zT_27 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_17 = zT_27;
    zT_31 = zF_1BFB52BE_fieldArrayListInit(zT_16, zT_17);
    fields = zT_31;
    zT_33 = alloc;
    zT_34 = zF_58BDA2DE_u32ToU32MapInit(zT_33);
    locals = zT_34;
    zT_36 = lir_fn->blocks;
    zT_37 = zT_36.len;
    zT_38 = (unsigned int)zT_37;
    nblocks = zT_38;
    zT_40 = alloc;
    zT_41 = nblocks;
    zT_42 = zF_F15DB413_allocU8Raw(zT_40, zT_41);
    visited = zT_42;
    zT_44 = alloc;
    zT_47 = 2;
    zT_48 = zig_wrap_mul_u(((zu64)(nblocks)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_mul_u(((zu64)(nblocks)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_52 = lir_fn->switch_cases;
    zT_53 = zT_52.len;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(zT_48)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(zT_48)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_59 = 4;
    zT_60 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    zT_45 = zT_60;
    zT_65 = zF_82E88BBC_allocU32With(zT_44, zT_45, (unsigned int)(0));
    work = zT_65;
    zT_67.lir_fn = lir_fn;
    zT_67.reg = reg;
    zT_67.max_temp = max_temp;
    zT_68 = alloc;
    zT_69 = max_temp;
    zT_72 = zF_82E88BBC_allocU32With(zT_68, zT_69, (unsigned int)(18));
    zT_67.ttype = zT_72;
    zT_73 = (zT_21D3708C_U32ToU32Map*)&locals;
    zT_67.locals = zT_73;
    zT_67.alloc = alloc;
    zT_67.nblocks = nblocks;
    zT_67.visited = visited;
    zT_67.work = work;
    c = zT_67;
    zT_75 = 0;
    hti = zT_75;
    goto z_bb_1;
    z_bb_1:
    zT_76 = lir_fn->hoisted_temps;
    zT_77 = zT_76.len;
    if ((unsigned char)(hti < zT_77)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_80 = lir_fn->hoisted_temps;
    zT_81 = zT_80.items;
    zT_82 = zT_81[hti];
    td = zT_82;
    zT_83 = td.temp_id;
    if ((unsigned char)(zT_83 < max_temp)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_95 = 0;
    pi = zT_95;
    goto z_bb_7;
    z_bb_4:
    zT_89 = 1;
    zT_90 = zig_wrap_add_u(((zu64)(hti)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(hti)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    hti = zT_90;
    goto z_bb_1;
    z_bb_5:
    zT_85 = td.type_id;
    zT_86 = c.ttype;
    zT_87 = td.temp_id;
    zT_88 = (unsigned int)zT_87;
    zT_86[zT_88] = zT_85;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_96 = lir_fn->params;
    zT_97 = zT_96.len;
    if ((unsigned char)(pi < zT_97)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_100 = lir_fn->params;
    zT_101 = zT_100.items;
    zT_102 = zT_101[pi];
    p = zT_102;
    zT_103 = (zT_21D3708C_U32ToU32Map*)&locals;
    zT_104 = p.name_id;
    zT_105 = p.temp_id;
    zF_26476265_u32ToU32MapPut(zT_103, zT_104, zT_105);
    goto z_bb_10;
    z_bb_9:
    zT_115 = 0;
    bi = zT_115;
    goto z_bb_11;
    z_bb_10:
    zT_109 = 1;
    zT_110 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_109)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_109)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    pi = zT_110;
    goto z_bb_7;
    z_bb_11:
    zT_116 = lir_fn->blocks;
    zT_117 = zT_116.len;
    if ((unsigned char)(bi < zT_117)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_120 = lir_fn->blocks;
    zT_121 = zT_120.items;
    zT_122 = zT_121 + bi;
    bb = zT_122;
    zT_124 = 0;
    ii = zT_124;
    goto z_bb_15;
    z_bb_13:
    zT_150 = alloc;
    zT_151 = max_temp;
    zT_154 = zF_9C85B07B_allocU8With(zT_150, zT_151, (unsigned char)(0));
    is_param = zT_154;
    zT_155 = 0;
    pi = zT_155;
    goto z_bb_23;
    z_bb_14:
    zT_144 = 1;
    zT_145 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_144)), 32u);
    zT_146 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_144)), 32u);
    zT_148 = zT_146 == (unsigned int)(0);
    if (!(zT_148)) { pal_trap(); }
    bi = zT_145;
    goto z_bb_11;
    z_bb_15:
    zT_125 = bb->insts;
    zT_126 = zT_125.len;
    if ((unsigned char)(ii < zT_126)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_128 = bb->insts;
    zT_129 = zT_128.items;
    zT_130 = zT_129[ii];
    zT_131 = zT_130.tag;
switch (zT_131) {
case 1: goto z_bb_19;
default: goto z_bb_20;
}
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_139 = 1;
    zT_140 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_139)), 32u);
    zT_141 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_139)), 32u);
    zT_143 = zT_141 == (unsigned int)(0);
    if (!(zT_143)) { pal_trap(); }
    ii = zT_140;
    goto z_bb_15;
    z_bb_19:
    dl = zT_130.payload.decl_local._0;
    zT_133 = (zT_21D3708C_U32ToU32Map*)&locals;
    zT_134 = dl.name_id;
    zT_135 = dl.temp;
    zF_26476265_u32ToU32MapPut(zT_133, zT_134, zT_135);
    goto z_bb_22;
    z_bb_20:
    goto z_bb_22;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_156 = lir_fn->params;
    zT_157 = zT_156.len;
    if ((unsigned char)(pi < zT_157)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_160 = lir_fn->params;
    zT_161 = zT_160.items;
    zT_162 = zT_161[pi];
    zT_163 = zT_162.temp_id;
    pt = zT_163;
    if ((unsigned char)(pt < max_temp)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_173 = alloc;
    zT_174 = max_temp;
    zT_175 = zF_F15DB413_allocU8Raw(zT_173, zT_174);
    live = zT_175;
    zT_177 = 0;
    t = zT_177;
    goto z_bb_29;
    z_bb_26:
    zT_167 = 1;
    zT_168 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_167)), 32u);
    zT_169 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_167)), 32u);
    zT_171 = zT_169 == (unsigned int)(0);
    if (!(zT_171)) { pal_trap(); }
    pi = zT_168;
    goto z_bb_23;
    z_bb_27:
    zT_165 = 1;
    zT_166 = (unsigned int)pt;
    is_param[zT_166] = zT_165;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    if ((unsigned char)(t < max_temp)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_179 = 0;
    zT_180 = (unsigned int)t;
    live[zT_180] = zT_179;
    goto z_bb_32;
    z_bb_31:
    zT_186 = 0;
    bi = zT_186;
    goto z_bb_33;
    z_bb_32:
    zT_181 = 1;
    zT_182 = zig_wrap_add_u(((zu64)(t)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_add_u(((zu64)(t)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    t = zT_182;
    goto z_bb_29;
    z_bb_33:
    zT_187 = lir_fn->blocks;
    zT_188 = zT_187.len;
    if ((unsigned char)(bi < zT_188)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_191 = lir_fn->blocks;
    zT_192 = zT_191.items;
    zT_193 = zT_192 + bi;
    bb = zT_193;
    zT_195 = 0;
    ii = zT_195;
    goto z_bb_37;
    z_bb_35:
    zT_249 = 0;
    offset = zT_249;
    zT_251 = 1;
    max_align = zT_251;
    zT_253 = 8;
    state_type = zT_253;
    zT_254 = state_widths;
    zT_256 = lir_fn->module_id;
    zT_257 = lir_fn->name_id;
    zT_260 = zF_9D041EB6_asyncKey(zT_256, zT_257);
    zT_255 = zT_260;
    zT_261 = zF_A05A7BE1_u64ToU32MapGet(zT_254, zT_255);
    zT_262 = zT_261.has_value;
    if (zT_262) goto z_bb_53; else goto z_bb_54;
    z_bb_36:
    zT_243 = 1;
    zT_244 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_243)), 32u);
    zT_245 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_243)), 32u);
    zT_247 = zT_245 == (unsigned int)(0);
    if (!(zT_247)) { pal_trap(); }
    bi = zT_244;
    goto z_bb_33;
    z_bb_37:
    zT_196 = bb->insts;
    zT_197 = zT_196.len;
    if ((unsigned char)(ii < zT_197)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_200 = bb->insts;
    zT_201 = zT_200.items;
    zT_202 = zT_201[ii];
    inst = zT_202;
    zT_203 = (zT_6D148508_Scan*)&c;
    zT_204 = inst;
    zT_205 = suspending_fns;
    zT_207 = zF_1AAC25A7_instIsSuspendPoint(zT_203, zT_204, zT_205);
    if (zT_207) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_238 = 1;
    zT_239 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_238)), 32u);
    zT_240 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_238)), 32u);
    zT_242 = zT_240 == (unsigned int)(0);
    if (!(zT_242)) { pal_trap(); }
    ii = zT_239;
    goto z_bb_37;
    z_bb_41:
    zT_208 = 0;
    t = zT_208;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    if ((unsigned char)(t < max_temp)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_211 = (unsigned int)t;
    tu = zT_211;
    zT_212 = is_param[tu];
    if ((unsigned char)(zT_212 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_233 = 1;
    zT_234 = zig_wrap_add_u(((zu64)(t)), ((zu64)(zT_233)), 32u);
    zT_235 = zig_overflow_flag_add_u(((zu64)(t)), ((zu64)(zT_233)), 32u);
    zT_237 = zT_235 == (unsigned int)(0);
    if (!(zT_237)) { pal_trap(); }
    t = zT_234;
    goto z_bb_43;
    z_bb_47:
    goto z_bb_46;
    z_bb_48:
    zT_215 = (zT_6D148508_Scan*)&c;
    zT_216 = t;
    zT_222 = zF_93E9604D_hasDefBefore(zT_215, zT_216, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if ((unsigned char)(!zT_222)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_224 = (zT_6D148508_Scan*)&c;
    zT_225 = t;
    zT_231 = zF_4CED5DFF_hasReadAfter(zT_224, zT_225, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if (zT_231) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_232 = 1;
    live[tu] = zT_232;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    if (!(zT_261.has_value)) { pal_trap(); }
    sw = zT_261.value;
    state_type = sw;
    goto z_bb_54;
    z_bb_54:
    zT_264 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_265 = reg;
    zT_273 = 4;
    zT_266 = zT_273;
    zT_270 = (unsigned int*)&offset;
    zT_271 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_264, zT_265, zT_266, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_270, zT_271);
    zT_279 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_280 = reg;
    zT_288 = 0;
    zT_281 = zT_288;
    zT_285 = (unsigned int*)&offset;
    zT_286 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_279, zT_280, zT_281, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_285, zT_286);
    zT_294 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_295 = reg;
    zT_303 = 1;
    zT_296 = zT_303;
    zT_299 = state_type;
    zT_300 = (unsigned int*)&offset;
    zT_301 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_294, zT_295, zT_296, (unsigned int)(0), (unsigned int)(0), zT_299, zT_300, zT_301);
    zT_308 = 0;
    pi = zT_308;
    goto z_bb_55;
    z_bb_55:
    zT_309 = lir_fn->params;
    zT_310 = zT_309.len;
    if ((unsigned char)(pi < zT_310)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_313 = lir_fn->params;
    zT_314 = zT_313.items;
    zT_315 = zT_314[pi];
    p = zT_315;
    zT_316 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_317 = reg;
    zT_325 = 2;
    zT_318 = zT_325;
    zT_319 = p.name_id;
    zT_320 = p.temp_id;
    zT_321 = p.type_id;
    zT_322 = (unsigned int*)&offset;
    zT_323 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_316, zT_317, zT_318, zT_319, zT_320, zT_321, zT_322, zT_323);
    goto z_bb_58;
    z_bb_57:
    zT_337 = alloc;
    zT_338 = max_temp;
    zT_341 = zF_9C85B07B_allocU8With(zT_337, zT_338, (unsigned char)(0));
    alias_flags = zT_341;
    zT_343 = 0;
    abi = zT_343;
    goto z_bb_59;
    z_bb_58:
    zT_331 = 1;
    zT_332 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_331)), 32u);
    zT_333 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_331)), 32u);
    zT_335 = zT_333 == (unsigned int)(0);
    if (!(zT_335)) { pal_trap(); }
    pi = zT_332;
    goto z_bb_55;
    z_bb_59:
    zT_344 = lir_fn->blocks;
    zT_345 = zT_344.len;
    if ((unsigned char)(abi < zT_345)) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_348 = lir_fn->blocks;
    zT_349 = zT_348.items;
    zT_350 = zT_349 + abi;
    abb = zT_350;
    zT_352 = 0;
    aii = zT_352;
    goto z_bb_63;
    z_bb_61:
    zT_376 = 0;
    t = zT_376;
    goto z_bb_73;
    z_bb_62:
    zT_371 = 1;
    zT_372 = zig_wrap_add_u(((zu64)(abi)), ((zu64)(zT_371)), 32u);
    zT_373 = zig_overflow_flag_add_u(((zu64)(abi)), ((zu64)(zT_371)), 32u);
    zT_375 = zT_373 == (unsigned int)(0);
    if (!(zT_375)) { pal_trap(); }
    abi = zT_372;
    goto z_bb_59;
    z_bb_63:
    zT_353 = abb->insts;
    zT_354 = zT_353.len;
    if ((unsigned char)(aii < zT_354)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_356 = abb->insts;
    zT_357 = zT_356.items;
    zT_358 = zT_357[aii];
    zT_359 = zT_358.tag;
switch (zT_359) {
case 54: goto z_bb_67;
default: goto z_bb_68;
}
    z_bb_65:
    goto z_bb_62;
    z_bb_66:
    zT_366 = 1;
    zT_367 = zig_wrap_add_u(((zu64)(aii)), ((zu64)(zT_366)), 32u);
    zT_368 = zig_overflow_flag_add_u(((zu64)(aii)), ((zu64)(zT_366)), 32u);
    zT_370 = zT_368 == (unsigned int)(0);
    if (!(zT_370)) { pal_trap(); }
    aii = zT_367;
    goto z_bb_63;
    z_bb_67:
    lg = zT_358.payload.load_global._0;
    zT_361 = lg.result;
    if ((unsigned char)(zT_361 < max_temp)) goto z_bb_71; else goto z_bb_72;
    z_bb_68:
    goto z_bb_70;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_363 = 1;
    zT_364 = lg.result;
    zT_365 = (unsigned int)zT_364;
    alias_flags[zT_365] = zT_363;
    goto z_bb_72;
    z_bb_72:
    goto z_bb_70;
    z_bb_73:
    if ((unsigned char)(t < max_temp)) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_379 = (unsigned int)t;
    tu = zT_379;
    zT_380 = live[tu];
    if ((unsigned char)(zT_380 != (unsigned char)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_75:
    zT_412 = 0;
    hid = zT_412;
    zT_414 = lir_fn->module_id;
    zT_415 = lir_fn->name_id;
    zT_418 = zF_9D041EB6_asyncKey(zT_414, zT_415);
    lay_key = zT_418;
    zT_419 = async_hidden_fns;
    zT_420 = lay_key;
    zT_421 = zF_A05A7BE1_u64ToU32MapGet(zT_419, zT_420);
    zT_422 = zT_421.has_value;
    if (zT_422) goto z_bb_84; else goto z_bb_85;
    z_bb_76:
    zT_406 = 1;
    zT_407 = zig_wrap_add_u(((zu64)(t)), ((zu64)(zT_406)), 32u);
    zT_408 = zig_overflow_flag_add_u(((zu64)(t)), ((zu64)(zT_406)), 32u);
    zT_410 = zT_408 == (unsigned int)(0);
    if (!(zT_410)) { pal_trap(); }
    t = zT_407;
    goto z_bb_73;
    z_bb_77:
    zT_384 = is_param[tu];
    zT_383 = zT_384 == (unsigned char)(0);
    goto z_bb_79;
    z_bb_78:
    zT_383 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_383) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_387 = alias_flags;
    zT_388 = max_temp;
    zT_389 = t;
    zT_390 = zF_C2E0979E_asyncTempIsGlobalAl(zT_387, zT_388, zT_389);
    if (zT_390) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_76;
    z_bb_82:
    goto z_bb_76;
    z_bb_83:
    zT_391 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_392 = reg;
    zT_400 = 3;
    zT_393 = zT_400;
    zT_395 = t;
    zT_402 = c.ttype;
    zT_396 = zT_402[tu];
    zT_397 = (unsigned int*)&offset;
    zT_398 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_391, zT_392, zT_393, (unsigned int)(0), zT_395, zT_396, zT_397, zT_398);
    goto z_bb_81;
    z_bb_84:
    if (!(zT_421.has_value)) { pal_trap(); }
    h = zT_421.value;
    hid = h;
    goto z_bb_85;
    z_bb_85:
    zT_425 = reg;
    zT_430 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_425, (unsigned int)(1), (unsigned char)(0));
    lay_ptr_void = zT_430;
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_435 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_436 = reg;
    zT_444 = 5;
    zT_437 = zT_444;
    zT_440 = lay_ptr_void;
    zT_441 = (unsigned int*)&offset;
    zT_442 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_435, zT_436, zT_437, (unsigned int)(0), (unsigned int)(0), zT_440, zT_441, zT_442);
    goto z_bb_87;
    z_bb_87:
    zT_449 = awaited_fns;
    zT_450 = lay_key;
    zT_451 = zF_A05A7BE1_u64ToU32MapGet(zT_449, zT_450);
    zT_452 = zT_451.has_value;
    if (zT_452) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_454 = driver_targets;
    zT_455 = lay_key;
    zT_456 = zF_A05A7BE1_u64ToU32MapGet(zT_454, zT_455);
    zT_457 = zT_456.has_value;
    zT_453 = zT_457;
    goto z_bb_90;
    z_bb_89:
    zT_453 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_453) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_458 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_459 = reg;
    zT_467 = 6;
    zT_460 = zT_467;
    zT_463 = lay_ptr_void;
    zT_464 = (unsigned int*)&offset;
    zT_465 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_458, zT_459, zT_460, (unsigned int)(0), (unsigned int)(0), zT_463, zT_464, zT_465);
    goto z_bb_92;
    z_bb_92:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_477 = 0;
    pstart = zT_477;
    zT_478 = parent_result_start;
    zT_479 = lay_key;
    zT_480 = zF_A05A7BE1_u64ToU32MapGet(zT_478, zT_479);
    zT_481 = zT_480.has_value;
    if (zT_481) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    zT_521 = offset;
    zT_522 = max_align;
    zT_523 = zF_978D7C93_alignUpU32(zT_521, zT_522);
    precise = zT_523;
    if ((unsigned char)(precise == (unsigned int)(0))) goto z_bb_103; else goto z_bb_104;
    z_bb_95:
    if (!(zT_480.has_value)) { pal_trap(); }
    ps = zT_480.value;
    pstart = ps;
    goto z_bb_96;
    z_bb_96:
    zT_484 = 0;
    pcount = zT_484;
    zT_485 = parent_result_count;
    zT_486 = lay_key;
    zT_487 = zF_A05A7BE1_u64ToU32MapGet(zT_485, zT_486);
    zT_488 = zT_487.has_value;
    if (zT_488) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    if (!(zT_487.has_value)) { pal_trap(); }
    pc = zT_487.value;
    pcount = pc;
    goto z_bb_98;
    z_bb_98:
    zT_491 = 0;
    pk = zT_491;
    goto z_bb_99;
    z_bb_99:
    if ((unsigned char)(pk < pcount)) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_494 = parent_result_type_list->items;
    zT_495 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pk)), 32u);
    zT_496 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pk)), 32u);
    zT_498 = zT_496 == (unsigned int)(0);
    if (!(zT_498)) { pal_trap(); }
    zT_499 = (unsigned int)zT_495;
    zT_500 = zT_494[zT_499];
    prt = zT_500;
    zT_501 = (zT_2CF63CE1_AsyncFrameFieldArra*)&fields;
    zT_502 = reg;
    zT_510 = 7;
    zT_503 = zT_510;
    zT_506 = prt;
    zT_507 = (unsigned int*)&offset;
    zT_508 = (unsigned int*)&max_align;
    zF_F2801F08_addField(zT_501, zT_502, zT_503, (unsigned int)(0), (unsigned int)(0), zT_506, zT_507, zT_508);
    goto z_bb_102;
    z_bb_101:
    goto z_bb_94;
    z_bb_102:
    zT_515 = 1;
    zT_516 = zig_wrap_add_u(((zu64)(pk)), ((zu64)(zT_515)), 32u);
    zT_517 = zig_overflow_flag_add_u(((zu64)(pk)), ((zu64)(zT_515)), 32u);
    zT_519 = zT_517 == (unsigned int)(0);
    if (!(zT_519)) { pal_trap(); }
    pk = zT_516;
    goto z_bb_99;
    z_bb_103:
    zT_526 = 1;
    precise = zT_526;
    goto z_bb_104;
    z_bb_104:
    zT_527 = precise;
    zT_530 = zF_978D7C93_alignUpU32(zT_527, (unsigned int)(8));
    precise = zT_530;
    zT_532 = frame_sizes;
    zT_533 = lir_fn->module_id;
    zT_534 = lir_fn->name_id;
    zT_537 = zF_D3D61AC0_asyncFrameSizeOf(zT_532, zT_533, zT_534);
    frame_size = zT_537;
    padded = precise;
    zT_539 = frame_size.has_value;
    if (zT_539) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    if (!(frame_size.has_value)) { pal_trap(); }
    fs = frame_size.value;
    if ((unsigned char)(precise > fs)) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    zT_556 = lir_fn->module_id;
    zT_557 = lir_fn->name_id;
    zT_558 = padded;
    zF_2B302EFE_emitLayoutMarker(zT_556, zT_557, zT_558);
    zT_561.fields = fields;
    zT_561.layout_size = padded;
    zT_561.alias_flags = alias_flags;
    zT_561.alias_len = max_temp;
    return zT_561;
    z_bb_107:
    zT_549 = "panic: ";
    zT_550 = 7;
    fwrite(zT_549, 1, zT_550, stderr);
    zT_551 = "async frame layout: missing authoritative frame size";
    zT_552 = 52;
    fwrite(zT_551, 1, zT_552, stderr);
    zT_553 = "\n";
    zT_554 = 1;
    fwrite(zT_553, 1, zT_554, stderr);
    pal_trap();
    z_bb_108:
    zT_542 = "panic: ";
    zT_543 = 7;
    fwrite(zT_542, 1, zT_543, stderr);
    zT_544 = "async frame layout exceeds authoritative frame size";
    zT_545 = 51;
    fwrite(zT_544, 1, zT_545, stderr);
    zT_546 = "\n";
    zT_547 = 1;
    fwrite(zT_546, 1, zT_547, stderr);
    pal_trap();
    z_bb_109:
    padded = fs;
    goto z_bb_106;
}

/* asyncLayoutPublish */
void zF_17324878_asyncLayoutPublish(zT_3E40CD83_Sand* alloc, zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id, zT_3F3BF87A_AsyncFrameLayout layout) {
    zT_3E40CD83_Sand* zT_6;
    zT_FDFD82FD_EU_362 zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_3F3BF87A_AsyncFrameLayout* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_79FAE712_u64 zT_22;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    unsigned char* raw;
    zT_3F3BF87A_AsyncFrameLayout* p;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(28), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    zT_16 = (zT_3F3BF87A_AsyncFrameLayout*)raw;
    p = zT_16;
    *p = layout;
    zT_17 = map;
    zT_20 = module_id;
    zT_21 = name_id;
    zT_22 = zF_9D041EB6_asyncKey(zT_20, zT_21);
    zT_18 = zT_22;
    zF_B6EB812C_u64ToU32MapPut(zT_17, zT_18, (unsigned int)((unsigned int)(unsigned int)((unsigned int)p)));
    return;
}

/* asyncLayoutLookup */
zT_9AD5FBED_Opt_453 zF_A1F56FFB_asyncLayoutLookup(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7;
    zT_BAEE192E_Opt_10 zT_8;
    unsigned char zT_9;
    zT_3F3BF87A_AsyncFrameLayout* zT_12;
    zT_9AD5FBED_Opt_453 zT_13;
    zT_9AD5FBED_Opt_453 zT_14;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    unsigned int v;
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_8.has_value)) { pal_trap(); }
    v = zT_8.value;
    zT_12 = (zT_3F3BF87A_AsyncFrameLayout*)(unsigned int)(unsigned int)((unsigned int)v);
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_2:
    zT_14.has_value = 0;
    return zT_14;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zT_3E40CD83_Sand zT_0;
    zT_BBC23664_LirFunction zT_1;
    zT_6BA597BC_LirInst zT_2;
    zT_338B7C76_TypeRegistry zT_3;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_6BA597BC_LirInst = zT_2;
    zG_338B7C76_TypeRegistry = zT_3;
    return;
}

/* EOF */
