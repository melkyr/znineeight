#ifndef ZIG_MODULE_PATH_8DCF959C_H
#define ZIG_MODULE_PATH_8DCF959C_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
zT_6E2E315A_Opt_258 zF_36F0DB6B_normalizePath(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_5FF93310_isReservedDosDevice(zT_8F083A69_Slice_zT_0B42B2F8_u);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_PATH_8DCF959C_H */
