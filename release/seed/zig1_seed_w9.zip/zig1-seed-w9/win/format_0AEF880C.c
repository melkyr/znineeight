#include "format_0AEF880C.h"
static unsigned int const zG_346F9833_FMT_BN_LIMBS = (unsigned int)(128);
/* copyStr */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* idx, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = s.len;
    if ((unsigned char)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = s.ptr;
    zT_10 = s.len;
    zT_11 = i < zT_10;
    if (!(zT_11)) { pal_trap(); }
    zT_12 = zT_9[i];
    zT_13 = buf.ptr;
    zT_14 = *idx;
    zT_15 = buf.len;
    zT_16 = zT_14 < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_13[zT_14] = zT_12;
    zT_17 = *idx;
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    *idx = zT_20;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    i = zT_26;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    int zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned char zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    idx = zT_5;
    v = val;
    zT_10 = 0;
    zT_11 = (unsigned char)zT_10;
    zT_12 = buf.ptr;
    zT_13 = buf.len;
    zT_14 = idx < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_12[idx] = zT_11;
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    idx = zT_17;
    zT_21 = 0;
    if ((unsigned char)(v == (unsigned int)zT_21)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_23 = 48;
    zT_24 = buf.ptr;
    zT_25 = buf.len;
    zT_26 = idx < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_24[idx] = zT_23;
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    idx = zT_29;
    goto z_bb_2;
    z_bb_2:
    zT_59 = 1;
    zT_60 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    start = zT_60;
    zT_64 = buf.ptr;
    zT_65 = buf.len;
    zT_66 = 1;
    zT_67 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    zT_71 = zT_64 + start;
    zT_72 = zT_67 - start;
    zT_73 = start <= zT_67;
    if (!(zT_73)) { pal_trap(); }
    zT_74 = zT_67 <= zT_65;
    if (!(zT_74)) { pal_trap(); }
    zT_75.ptr = (unsigned char*)zT_71;
    zT_75.len = zT_72;
    return zT_75;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_33 = 0;
    if ((unsigned char)(v > (unsigned int)zT_33)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = 48;
    zT_36 = 10;
    zT_39 = (unsigned int)zT_36 != (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_37 = v % zT_36;
    zT_40 = zig_wrap_add_u(((zu64)(zT_35)), ((zu64)(zT_37)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(zT_35)), ((zu64)(zT_37)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = (unsigned char)zig_cast_checked_u((zu64)zT_40, 32u, 0u, 8u);
    zT_45 = buf.ptr;
    zT_46 = buf.len;
    zT_47 = idx < zT_46;
    if (!(zT_47)) { pal_trap(); }
    zT_45[idx] = zT_44;
    zT_48 = 10;
    zT_51 = (unsigned int)zT_48 != (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_49 = v / zT_48;
    v = zT_49;
    zT_52 = 1;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    idx = zT_54;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* formatU64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    int zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_35;
    int zT_36;
    zT_79FAE712_u64 zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    unsigned char zT_48;
    int zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned char zT_52;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    unsigned char zT_74;
    unsigned char zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int idx;
    zT_79FAE712_u64 v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    idx = zT_5;
    v = val;
    zT_10 = 0;
    zT_11 = (unsigned char)zT_10;
    zT_12 = buf.ptr;
    zT_13 = buf.len;
    zT_14 = idx < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_12[idx] = zT_11;
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    idx = zT_17;
    zT_21 = 0;
    if ((unsigned char)(v == (zT_79FAE712_u64)zT_21)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_23 = 48;
    zT_24 = buf.ptr;
    zT_25 = buf.len;
    zT_26 = idx < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_24[idx] = zT_23;
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    idx = zT_29;
    goto z_bb_2;
    z_bb_2:
    zT_60 = 1;
    zT_61 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_60)), 32u);
    zT_62 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_60)), 32u);
    zT_64 = zT_62 == (unsigned int)(0);
    if (!(zT_64)) { pal_trap(); }
    start = zT_61;
    zT_65 = buf.ptr;
    zT_66 = buf.len;
    zT_67 = 1;
    zT_68 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    zT_72 = zT_65 + start;
    zT_73 = zT_68 - start;
    zT_74 = start <= zT_68;
    if (!(zT_74)) { pal_trap(); }
    zT_75 = zT_68 <= zT_66;
    if (!(zT_75)) { pal_trap(); }
    zT_76.ptr = (unsigned char*)zT_72;
    zT_76.len = zT_73;
    return zT_76;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_33 = 0;
    if ((unsigned char)(v > (zT_79FAE712_u64)zT_33)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = 48;
    zT_36 = 10;
    zT_39 = (unsigned int)zT_36 != (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_37 = v % zT_36;
    zT_40 = (unsigned int)zig_cast_checked_u((zu64)zT_37, 64u, 0u, 32u);
    zT_41 = zig_wrap_add_u(((zu64)(zT_35)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(zT_35)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_45 = (unsigned char)zig_cast_checked_u((zu64)zT_41, 32u, 0u, 8u);
    zT_46 = buf.ptr;
    zT_47 = buf.len;
    zT_48 = idx < zT_47;
    if (!(zT_48)) { pal_trap(); }
    zT_46[idx] = zT_45;
    zT_49 = 10;
    zT_52 = (unsigned int)zT_49 != (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    zT_50 = v / zT_49;
    v = zT_50;
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    idx = zT_55;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* fmtBnMulSmall */
void zF_350AF0DD_fmtBnMulSmall(zT_5DB33A8A_Arr_unsigned_int_12* a, unsigned int* nlimbs, unsigned int mul) {
    int zT_4;
    zT_79FAE712_u64 zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_15;
    zT_79FAE712_u64 zT_16;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_79FAE712_u64 zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    int zT_25;
    zT_79FAE712_u64 zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    int zT_32;
    zT_79FAE712_u64 zT_33;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    int zT_42;
    int zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_52;
    zT_79FAE712_u64 zT_53;
    unsigned char zT_55;
    unsigned int zT_56;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_79FAE712_u64 carry;
    unsigned int i;
    zT_79FAE712_u64 p;
    zT_4 = 0;
    zT_5 = (zT_79FAE712_u64)zT_4;
    carry = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_9 = *nlimbs;
    if ((unsigned char)(i < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = i < (unsigned int)(128);
    if (!(zT_13)) { pal_trap(); }
    zT_14 = (*a)[i];
    zT_15 = (zT_79FAE712_u64)zT_14;
    zT_16 = (zT_79FAE712_u64)mul;
    zT_17 = zig_wrap_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 64u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 64u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(carry)), 64u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(carry)), 64u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    p = zT_21;
    zT_25 = 1000000000;
    zT_28 = (unsigned int)zT_25 != (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_26 = p % zT_25;
    zT_29 = (unsigned int)zig_cast_checked_u((zu64)zT_26, 64u, 0u, 32u);
    zT_31 = i < (unsigned int)(128);
    if (!(zT_31)) { pal_trap(); }
    (*a)[i] = zT_29;
    zT_32 = 1000000000;
    zT_35 = (unsigned int)zT_32 != (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_33 = p / zT_32;
    carry = zT_33;
    zT_36 = 1;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    i = zT_38;
    goto z_bb_4;
    z_bb_3:
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_42 = 0;
    if ((unsigned char)(carry > (zT_79FAE712_u64)zT_42)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_44 = 1000000000;
    zT_47 = (unsigned int)zT_44 != (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_45 = carry % zT_44;
    zT_48 = (unsigned int)zig_cast_checked_u((zu64)zT_45, 64u, 0u, 32u);
    zT_49 = *nlimbs;
    zT_51 = zT_49 < (unsigned int)(128);
    if (!(zT_51)) { pal_trap(); }
    (*a)[zT_49] = zT_48;
    zT_52 = 1000000000;
    zT_55 = (unsigned int)zT_52 != (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    zT_53 = carry / zT_52;
    carry = zT_53;
    zT_56 = *nlimbs;
    zT_57 = 1;
    zT_58 = (unsigned int)zT_57;
    zT_59 = zig_wrap_add_u(((zu64)(zT_56)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(zT_56)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    *nlimbs = zT_59;
    goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    goto z_bb_5;
}

/* fmtCopyOut */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_11ACB4EF_fmtCopyOut(zT_8F083A69_Slice_zT_0B42B2F8_u src, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int cap) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    int zT_18;
    unsigned int zT_19;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int n;
    unsigned int i;
    zT_5 = src.len;
    n = zT_5;
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(cap)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(cap)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(n > zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 1;
    zT_13 = zig_wrap_sub_u(((zu64)(cap)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_sub_u(((zu64)(cap)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    n = zT_13;
    goto z_bb_2;
    z_bb_2:
    zT_18 = 0;
    zT_19 = (unsigned int)zT_18;
    i = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_21 = src.ptr;
    zT_22 = src.len;
    zT_23 = i < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[i];
    zT_25 = buf.ptr;
    zT_26 = buf.len;
    zT_27 = i < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_25[i] = zT_24;
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    i = zT_30;
    goto z_bb_6;
    z_bb_5:
    zT_34 = 0;
    zT_35 = (unsigned char)zT_34;
    zT_36 = buf.ptr;
    zT_37 = buf.len;
    zT_38 = n < zT_37;
    if (!(zT_38)) { pal_trap(); }
    zT_36[n] = zT_35;
    zT_39 = buf.ptr;
    zT_40 = buf.len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = n - zT_41;
    zT_44 = (unsigned int)zT_41 <= n;
    if (!(zT_44)) { pal_trap(); }
    zT_45 = n <= zT_40;
    if (!(zT_45)) { pal_trap(); }
    zT_46.ptr = (unsigned char*)zT_42;
    zT_46.len = zT_43;
    return zT_46;
    z_bb_6:
    goto z_bb_3;
}

/* formatF64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(zT_00435AEB_f64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned char* zT_11;
    unsigned int zT_12;
    int zT_13;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_C41F1B06_Arr_unsigned_char_6 zT_20;
    int zT_22;
    unsigned int zT_23;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    int zT_35;
    int zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    int zT_69;
    unsigned char zT_70;
    int zT_74;
    unsigned char zT_75;
    zT_00435AEB_f64 zT_76;
    int zT_78;
    int zT_79;
    zT_00435AEB_f64 zT_82;
    zT_00435AEB_f64 zT_83;
    unsigned char zT_85;
    int zT_86;
    int zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    zT_00435AEB_f64 zT_95;
    int zT_96;
    int zT_97;
    int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    zT_79FAE712_u64 zT_105;
    int zT_107;
    int zT_108;
    unsigned int zT_109;
    unsigned char zT_111;
    zT_5DB33A8A_Arr_unsigned_int_12 zT_113;
    int zT_115;
    unsigned int zT_116;
    int zT_118;
    int zT_120;
    zT_79FAE712_u64 zT_121;
    unsigned char zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    int zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned char zT_130;
    int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    int zT_138;
    int zT_139;
    int zT_140;
    int zT_143;
    int zT_144;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_146;
    unsigned int* zT_147;
    int zT_151;
    int zT_153;
    int zT_154;
    int zT_155;
    unsigned int zT_156;
    unsigned char zT_158;
    int zT_159;
    int zT_160;
    int zT_162;
    int zT_163;
    unsigned int zT_164;
    unsigned char zT_166;
    int zT_168;
    int zT_169;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_171;
    unsigned int* zT_172;
    int zT_176;
    int zT_178;
    int zT_179;
    int zT_180;
    unsigned int zT_181;
    unsigned char zT_183;
    int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned char zT_189;
    unsigned char zT_192;
    unsigned int zT_193;
    int zT_195;
    unsigned int zT_196;
    int zT_197;
    int zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned char zT_204;
    int zT_205;
    unsigned int zT_206;
    unsigned char zT_208;
    int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    int zT_215;
    int zT_216;
    int zT_217;
    unsigned int zT_218;
    unsigned char zT_220;
    int zT_222;
    int zT_223;
    unsigned int zT_224;
    unsigned char zT_226;
    int zT_227;
    unsigned int zT_228;
    unsigned char zT_230;
    int zT_232;
    zT_79FAE712_u64 zT_233;
    int zT_235;
    unsigned int zT_236;
    int zT_238;
    unsigned int zT_239;
    int zT_241;
    int zT_242;
    unsigned int zT_245;
    unsigned char zT_247;
    unsigned int zT_248;
    int zT_250;
    unsigned int zT_251;
    int zT_252;
    zT_C2AB05E7_Arr_unsigned_char_9 zT_255;
    int zT_258;
    int zT_259;
    int zT_260;
    unsigned int zT_262;
    int zT_263;
    unsigned int zT_264;
    unsigned char zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned char zT_270;
    unsigned char zT_271;
    unsigned int zT_272;
    unsigned char zT_274;
    int zT_275;
    unsigned int zT_276;
    unsigned char zT_278;
    int zT_279;
    int zT_280;
    int zT_281;
    unsigned int zT_282;
    unsigned char zT_284;
    int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned char zT_291;
    int zT_293;
    unsigned char zT_297;
    unsigned char zT_298;
    unsigned char zT_299;
    unsigned char zT_300;
    unsigned int zT_301;
    unsigned char zT_303;
    unsigned int zT_304;
    int zT_305;
    int zT_307;
    zT_79FAE712_u64 zT_308;
    unsigned int zT_309;
    unsigned char zT_311;
    zT_79FAE712_u64 zT_312;
    zT_79FAE712_u64 zT_313;
    unsigned int zT_314;
    unsigned char zT_316;
    int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned char zT_322;
    int zT_323;
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned char zT_330;
    int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned char zT_336;
    int zT_337;
    int zT_338;
    int zT_339;
    unsigned int zT_340;
    unsigned char zT_342;
    int zT_343;
    int zT_345;
    zT_79FAE712_u64 zT_346;
    unsigned int zT_347;
    unsigned char zT_349;
    int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned char zT_355;
    int zT_356;
    int zT_358;
    zT_79FAE712_u64 zT_359;
    zT_79FAE712_u64 zT_360;
    unsigned int zT_361;
    unsigned char zT_363;
    zT_79FAE712_u64 zT_364;
    int zT_366;
    zT_79FAE712_u64 zT_367;
    unsigned char zT_369;
    int zT_370;
    int zT_371;
    int zT_372;
    unsigned int zT_373;
    unsigned char zT_375;
    int zT_376;
    unsigned char zT_378;
    unsigned char zT_380;
    int zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned char zT_386;
    zT_79FAE712_u64 zT_388;
    zT_79FAE712_u64 zT_389;
    unsigned char zT_391;
    zT_79FAE712_u64 zT_393;
    zT_79FAE712_u64 zT_394;
    unsigned char zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned char zT_402;
    unsigned char zT_403;
    unsigned char zT_405;
    int zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned char zT_411;
    zT_5426B97B_Arr_unsigned_char_1 zT_413;
    int zT_415;
    int zT_416;
    int zT_417;
    unsigned int zT_419;
    int zT_420;
    zT_79FAE712_u64 zT_421;
    unsigned char zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    unsigned char zT_428;
    unsigned char zT_429;
    unsigned int zT_430;
    unsigned char zT_432;
    int zT_433;
    zT_79FAE712_u64 zT_434;
    unsigned char zT_436;
    int zT_437;
    int zT_438;
    int zT_439;
    unsigned int zT_440;
    unsigned char zT_442;
    int zT_444;
    unsigned int zT_445;
    int zT_446;
    unsigned char zT_448;
    int zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned char zT_453;
    unsigned char zT_455;
    unsigned char zT_456;
    int zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned char zT_464;
    int zT_465;
    unsigned char zT_467;
    unsigned char zT_469;
    int zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned char zT_475;
    int zT_477;
    unsigned int zT_478;
    unsigned char zT_481;
    unsigned char zT_482;
    unsigned char zT_484;
    int zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned char zT_490;
    int zT_491;
    unsigned int zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    unsigned char zT_496;
    unsigned char zT_497;
    unsigned char zT_499;
    int zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    unsigned int zT_503;
    unsigned char zT_505;
    int zT_507;
    unsigned char zT_509;
    unsigned char zT_511;
    int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned char zT_517;
    int zT_518;
    int zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    unsigned char zT_523;
    unsigned char zT_525;
    int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned char zT_531;
    int zT_532;
    unsigned char zT_534;
    unsigned char zT_536;
    int zT_537;
    unsigned int zT_538;
    unsigned int zT_539;
    unsigned int zT_540;
    unsigned char zT_542;
    zT_C1AB0454_Arr_unsigned_char_8 zT_544;
    int zT_546;
    unsigned int zT_547;
    int zT_549;
    unsigned int zT_551;
    int zT_552;
    int zT_553;
    zT_79FAE712_u64 zT_558;
    unsigned char zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    unsigned int zT_564;
    unsigned char zT_566;
    unsigned char zT_567;
    unsigned char zT_569;
    int zT_570;
    int zT_571;
    zT_79FAE712_u64 zT_576;
    unsigned char zT_579;
    int zT_580;
    unsigned int zT_581;
    unsigned int zT_582;
    unsigned int zT_583;
    unsigned char zT_585;
    int zT_586;
    int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned char zT_593;
    unsigned char zT_595;
    unsigned char zT_596;
    unsigned char zT_598;
    int zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned int zT_602;
    unsigned char zT_604;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_605;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_606;
    unsigned int zT_607;
    int zT_610;
    unsigned char* zT_611;
    unsigned int zT_612;
    unsigned char zT_613;
    unsigned char zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_616;
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_616, (unsigned int)sizeof zT_616);
    unsigned int cap;
    zT_C41F1B06_Arr_unsigned_char_6 sb;
    unsigned int bi;
    unsigned char neg;
    zT_00435AEB_f64 v;
    int e2;
    zT_79FAE712_u64 m;
    int e;
    zT_5DB33A8A_Arr_unsigned_int_12 a;
    unsigned int nlimbs;
    zT_79FAE712_u64 mm;
    int offset;
    int k;
    unsigned int top;
    unsigned int tv;
    unsigned int topdig;
    int f;
    int k2;
    int nd;
    int dexp;
    zT_79FAE712_u64 q;
    unsigned int collected;
    unsigned int d18;
    int li;
    unsigned int limb;
    unsigned int dcnt;
    zT_C2AB05E7_Arr_unsigned_char_9 tmp;
    unsigned int tt;
    int k3;
    unsigned int start;
    unsigned int j;
    unsigned int dg;
    zT_79FAE712_u64 d1;
    zT_79FAE712_u64 rest;
    zT_5426B97B_Arr_unsigned_char_1 fdig;
    int fi;
    unsigned int flen;
    unsigned int fj;
    int ae;
    zT_C1AB0454_Arr_unsigned_char_8 eb;
    unsigned int en;
    int av;
    cap = buf_len;
    zT_5 = buf.len;
    if ((unsigned char)(cap > zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = buf.len;
    cap = zT_8;
    goto z_bb_2;
    z_bb_2:
    zT_9 = 0;
    if ((unsigned char)(cap == (unsigned int)zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = buf.ptr;
    zT_12 = buf.len;
    zT_13 = 0;
    zT_14 = 0;
    zT_15 = zT_11 + zT_14;
    zT_16 = zT_13 - zT_14;
    zT_17 = (unsigned int)zT_13 <= zT_12;
    if (!(zT_17)) { pal_trap(); }
    zT_18.ptr = (unsigned char*)zT_15;
    zT_18.len = zT_16;
    return zT_18;
    z_bb_4:
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        sb[_i] = zT_20[_i];
        _i++;
    }
}
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    bi = zT_23;
    if ((unsigned char)(val == (zT_00435AEB_f64)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = 48;
    zT_27 = 0;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(64);
    if (!(zT_29)) { pal_trap(); }
    sb[zT_27] = zT_26;
    zT_35 = 1;
    zT_36 = 0;
    zT_37 = (unsigned char*)((unsigned char*)sb) + zT_36;
    zT_38 = zT_35 - zT_36;
    zT_39.ptr = (unsigned char*)zT_37;
    zT_39.len = zT_38;
    zT_30 = zT_39;
    zT_31 = buf;
    zT_32 = cap;
    zT_40 = zF_11ACB4EF_fmtCopyOut(zT_30, zT_31, zT_32);
    return zT_40;
    z_bb_6:
    if ((unsigned char)(val != val)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_45 = "Z98_NAN";
    zT_47 = 7;
    zT_46.ptr = (unsigned char*)zT_45;
    zT_46.len = zT_47;
    zT_42 = zT_46;
    zT_43 = buf;
    zT_44 = cap;
    zT_48 = zF_11ACB4EF_fmtCopyOut(zT_42, zT_43, zT_44);
    return zT_48;
    z_bb_8:
    if ((unsigned char)((zT_00435AEB_f64)(val * (zT_00435AEB_f64)(2e+0)) == val)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    if ((unsigned char)(val > (zT_00435AEB_f64)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_69 = 0;
    zT_70 = (unsigned char)zT_69;
    neg = zT_70;
    v = val;
    if ((unsigned char)(v < (zT_00435AEB_f64)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_57 = "Z98_INF";
    zT_59 = 7;
    zT_58.ptr = (unsigned char*)zT_57;
    zT_58.len = zT_59;
    zT_54 = zT_58;
    zT_55 = buf;
    zT_56 = cap;
    zT_60 = zF_11ACB4EF_fmtCopyOut(zT_54, zT_55, zT_56);
    return zT_60;
    z_bb_12:
    zT_64 = "Z98_NEGINF";
    zT_66 = 10;
    zT_65.ptr = (unsigned char*)zT_64;
    zT_65.len = zT_66;
    zT_61 = zT_65;
    zT_62 = buf;
    zT_63 = cap;
    zT_67 = zF_11ACB4EF_fmtCopyOut(zT_61, zT_62, zT_63);
    return zT_67;
    z_bb_13:
    zT_74 = 1;
    zT_75 = (unsigned char)zT_74;
    neg = zT_75;
    zT_76 = -v;
    v = zT_76;
    goto z_bb_14;
    z_bb_14:
    zT_78 = 0;
    zT_79 = (int)zT_78;
    e2 = zT_79;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(v >= (zT_00435AEB_f64)(2e+0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_82 = 2e+0;
    zT_85 = zT_82 != (unsigned int)(0);
    if (!(zT_85)) { pal_trap(); }
    zT_83 = v / zT_82;
    v = zT_83;
    zT_86 = 1;
    zT_87 = (int)zT_86;
    zT_88 = zig_wrap_add_s(((z64)(e2)), ((z64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_s(((z64)(e2)), ((z64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    e2 = zT_88;
    goto z_bb_18;
    z_bb_17:
    goto z_bb_19;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    if ((unsigned char)(v < (zT_00435AEB_f64)(1e+0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_95 = v * (zT_00435AEB_f64)(2e+0);
    v = zT_95;
    zT_96 = 1;
    zT_97 = (int)zT_96;
    zT_98 = zig_wrap_sub_s(((z64)(e2)), ((z64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_sub_s(((z64)(e2)), ((z64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    e2 = zT_98;
    goto z_bb_22;
    z_bb_21:
    zT_105 = (zT_79FAE712_u64)(zT_00435AEB_f64)(v * (zT_00435AEB_f64)(4.503599627370496e+15));
    m = zT_105;
    zT_107 = 52;
    zT_108 = zig_wrap_sub_s(((z64)(e2)), ((z64)(zT_107)), 32u);
    zT_109 = zig_overflow_flag_sub_s(((z64)(e2)), ((z64)(zT_107)), 32u);
    zT_111 = zT_109 == (unsigned int)(0);
    if (!(zT_111)) { pal_trap(); }
    e = zT_108;
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    {
    unsigned int _i = 0;
    while (_i < 128) {
        a[_i] = zT_113[_i];
        _i++;
    }
}
    zT_115 = 0;
    zT_116 = (unsigned int)zT_115;
    nlimbs = zT_116;
    mm = m;
    goto z_bb_23;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_118 = 0;
    if ((unsigned char)(mm > (zT_79FAE712_u64)zT_118)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_120 = 1000000000;
    zT_123 = (unsigned int)zT_120 != (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    zT_121 = mm % zT_120;
    zT_124 = (unsigned int)zig_cast_checked_u((zu64)zT_121, 64u, 0u, 32u);
    zT_126 = nlimbs < (unsigned int)(128);
    if (!(zT_126)) { pal_trap(); }
    a[nlimbs] = zT_124;
    zT_127 = 1000000000;
    zT_130 = (unsigned int)zT_127 != (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    zT_128 = mm / zT_127;
    mm = zT_128;
    zT_131 = 1;
    zT_132 = (unsigned int)zT_131;
    zT_133 = zig_wrap_add_u(((zu64)(nlimbs)), ((zu64)(zT_132)), 32u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(nlimbs)), ((zu64)(zT_132)), 32u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    nlimbs = zT_133;
    goto z_bb_26;
    z_bb_25:
    zT_138 = 0;
    zT_139 = (int)zT_138;
    offset = zT_139;
    zT_140 = 0;
    if ((unsigned char)(e >= zT_140)) goto z_bb_27; else goto z_bb_29;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_143 = 0;
    zT_144 = (int)zT_143;
    k = zT_144;
    goto z_bb_30;
    z_bb_28:
    zT_185 = 1;
    zT_186 = zig_wrap_sub_u(((zu64)(nlimbs)), ((zu64)(zT_185)), 32u);
    zT_187 = zig_overflow_flag_sub_u(((zu64)(nlimbs)), ((zu64)(zT_185)), 32u);
    zT_189 = zT_187 == (unsigned int)(0);
    if (!(zT_189)) { pal_trap(); }
    top = zT_186;
    zT_192 = top < (unsigned int)(128);
    if (!(zT_192)) { pal_trap(); }
    zT_193 = a[top];
    tv = zT_193;
    zT_195 = 0;
    zT_196 = (unsigned int)zT_195;
    topdig = zT_196;
    goto z_bb_38;
    z_bb_29:
    zT_162 = 0;
    zT_163 = zig_wrap_sub_s(((z64)(zT_162)), ((z64)(e)), 32u);
    zT_164 = zig_overflow_flag_sub_s(((z64)(zT_162)), ((z64)(e)), 32u);
    zT_166 = zT_164 == (unsigned int)(0);
    if (!(zT_166)) { pal_trap(); }
    f = zT_163;
    zT_168 = 0;
    zT_169 = (int)zT_168;
    k2 = zT_169;
    goto z_bb_34;
    z_bb_30:
    if ((unsigned char)(k < e)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_146 = (zT_5DB33A8A_Arr_unsigned_int_12*)&a;
    zT_147 = (unsigned int*)&nlimbs;
    zT_151 = 2;
    zF_350AF0DD_fmtBnMulSmall(zT_146, zT_147, (unsigned int)((unsigned int)zT_151));
    zT_153 = 1;
    zT_154 = (int)zT_153;
    zT_155 = zig_wrap_add_s(((z64)(k)), ((z64)(zT_154)), 32u);
    zT_156 = zig_overflow_flag_add_s(((z64)(k)), ((z64)(zT_154)), 32u);
    zT_158 = zT_156 == (unsigned int)(0);
    if (!(zT_158)) { pal_trap(); }
    k = zT_155;
    goto z_bb_33;
    z_bb_32:
    zT_159 = 0;
    zT_160 = (int)zT_159;
    offset = zT_160;
    goto z_bb_28;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    if ((unsigned char)(k2 < f)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_171 = (zT_5DB33A8A_Arr_unsigned_int_12*)&a;
    zT_172 = (unsigned int*)&nlimbs;
    zT_176 = 5;
    zF_350AF0DD_fmtBnMulSmall(zT_171, zT_172, (unsigned int)((unsigned int)zT_176));
    zT_178 = 1;
    zT_179 = (int)zT_178;
    zT_180 = zig_wrap_add_s(((z64)(k2)), ((z64)(zT_179)), 32u);
    zT_181 = zig_overflow_flag_add_s(((z64)(k2)), ((z64)(zT_179)), 32u);
    zT_183 = zT_181 == (unsigned int)(0);
    if (!(zT_183)) { pal_trap(); }
    k2 = zT_180;
    goto z_bb_37;
    z_bb_36:
    offset = e;
    goto z_bb_28;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_197 = 0;
    if ((unsigned char)(tv > (unsigned int)zT_197)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_199 = 1;
    zT_200 = (unsigned int)zT_199;
    zT_201 = zig_wrap_add_u(((zu64)(topdig)), ((zu64)(zT_200)), 32u);
    zT_202 = zig_overflow_flag_add_u(((zu64)(topdig)), ((zu64)(zT_200)), 32u);
    zT_204 = zT_202 == (unsigned int)(0);
    if (!(zT_204)) { pal_trap(); }
    topdig = zT_201;
    zT_205 = 10;
    zT_208 = (unsigned int)zT_205 != (unsigned int)(0);
    if (!(zT_208)) { pal_trap(); }
    zT_206 = tv / zT_205;
    tv = zT_206;
    goto z_bb_41;
    z_bb_40:
    zT_210 = 9;
    zT_211 = zig_wrap_mul_u(((zu64)(top)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_mul_u(((zu64)(top)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    zT_215 = (int)zig_cast_checked_s((zu64)zT_211, 32u, 0u, 32u);
    zT_216 = (int)zig_cast_checked_s((zu64)topdig, 32u, 0u, 32u);
    zT_217 = zig_wrap_add_s(((z64)(zT_215)), ((z64)(zT_216)), 32u);
    zT_218 = zig_overflow_flag_add_s(((z64)(zT_215)), ((z64)(zT_216)), 32u);
    zT_220 = zT_218 == (unsigned int)(0);
    if (!(zT_220)) { pal_trap(); }
    nd = zT_217;
    zT_222 = 1;
    zT_223 = zig_wrap_sub_s(((z64)(nd)), ((z64)(zT_222)), 32u);
    zT_224 = zig_overflow_flag_sub_s(((z64)(nd)), ((z64)(zT_222)), 32u);
    zT_226 = zT_224 == (unsigned int)(0);
    if (!(zT_226)) { pal_trap(); }
    zT_227 = zig_wrap_add_s(((z64)(zT_223)), ((z64)(offset)), 32u);
    zT_228 = zig_overflow_flag_add_s(((z64)(zT_223)), ((z64)(offset)), 32u);
    zT_230 = zT_228 == (unsigned int)(0);
    if (!(zT_230)) { pal_trap(); }
    dexp = zT_227;
    zT_232 = 0;
    zT_233 = (zT_79FAE712_u64)zT_232;
    q = zT_233;
    zT_235 = 0;
    zT_236 = (unsigned int)zT_235;
    collected = zT_236;
    zT_238 = 0;
    zT_239 = (unsigned int)zT_238;
    d18 = zT_239;
    zT_241 = (int)zig_cast_checked_s((zu64)top, 32u, 0u, 32u);
    li = zT_241;
    goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_242 = 0;
    if ((unsigned char)(li >= zT_242)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_245 = (unsigned int)zig_cast_checked_u((zu64)li, 32u, 1u, 32u);
    zT_247 = zT_245 < (unsigned int)(128);
    if (!(zT_247)) { pal_trap(); }
    zT_248 = a[zT_245];
    limb = zT_248;
    zT_250 = 9;
    zT_251 = (unsigned int)zT_250;
    dcnt = zT_251;
    zT_252 = (int)zig_cast_checked_s((zu64)top, 32u, 0u, 32u);
    if ((unsigned char)(li == zT_252)) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_61;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    dcnt = topdig;
    goto z_bb_47;
    z_bb_47:
    zig_poison_fill((void*)&zT_255, (unsigned int)sizeof zT_255);
    {
    unsigned int _i = 0;
    while (_i < 9) {
        tmp[_i] = zT_255[_i];
        _i++;
    }
}
    tt = limb;
    zT_258 = 8;
    zT_259 = (int)zT_258;
    k3 = zT_259;
    goto z_bb_48;
    z_bb_48:
    zT_260 = 0;
    if ((unsigned char)(k3 >= zT_260)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_262 = 48;
    zT_263 = 10;
    zT_266 = (unsigned int)zT_263 != (unsigned int)(0);
    if (!(zT_266)) { pal_trap(); }
    zT_264 = tt % zT_263;
    zT_267 = zig_wrap_add_u(((zu64)(zT_262)), ((zu64)(zT_264)), 32u);
    zT_268 = zig_overflow_flag_add_u(((zu64)(zT_262)), ((zu64)(zT_264)), 32u);
    zT_270 = zT_268 == (unsigned int)(0);
    if (!(zT_270)) { pal_trap(); }
    zT_271 = (unsigned char)zig_cast_checked_u((zu64)zT_267, 32u, 0u, 8u);
    zT_272 = (unsigned int)zig_cast_checked_u((zu64)k3, 32u, 1u, 32u);
    zT_274 = zT_272 < (unsigned int)(9);
    if (!(zT_274)) { pal_trap(); }
    tmp[zT_272] = zT_271;
    zT_275 = 10;
    zT_278 = (unsigned int)zT_275 != (unsigned int)(0);
    if (!(zT_278)) { pal_trap(); }
    zT_276 = tt / zT_275;
    tt = zT_276;
    zT_279 = 1;
    zT_280 = (int)zT_279;
    zT_281 = zig_wrap_sub_s(((z64)(k3)), ((z64)(zT_280)), 32u);
    zT_282 = zig_overflow_flag_sub_s(((z64)(k3)), ((z64)(zT_280)), 32u);
    zT_284 = zT_282 == (unsigned int)(0);
    if (!(zT_284)) { pal_trap(); }
    k3 = zT_281;
    goto z_bb_51;
    z_bb_50:
    zT_286 = 9;
    zT_287 = (unsigned int)dcnt;
    zT_288 = zig_wrap_sub_u(((zu64)(zT_286)), ((zu64)(zT_287)), 32u);
    zT_289 = zig_overflow_flag_sub_u(((zu64)(zT_286)), ((zu64)(zT_287)), 32u);
    zT_291 = zT_289 == (unsigned int)(0);
    if (!(zT_291)) { pal_trap(); }
    start = zT_288;
    j = start;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_48;
    z_bb_52:
    zT_293 = 9;
    if ((unsigned char)(j < (unsigned int)zT_293)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_297 = j < (unsigned int)(9);
    if (!(zT_297)) { pal_trap(); }
    zT_298 = tmp[j];
    zT_299 = 48;
    zT_300 = zig_wrap_sub_u(((zu64)(zT_298)), ((zu64)(zT_299)), 8u);
    zT_301 = zig_overflow_flag_sub_u(((zu64)(zT_298)), ((zu64)(zT_299)), 8u);
    zT_303 = zT_301 == (unsigned int)(0);
    if (!(zT_303)) { pal_trap(); }
    zT_304 = (unsigned int)zT_300;
    dg = zT_304;
    zT_305 = 17;
    if ((unsigned char)(collected < (unsigned int)zT_305)) goto z_bb_56; else goto z_bb_58;
    z_bb_54:
    zT_337 = 1;
    zT_338 = (int)zT_337;
    zT_339 = zig_wrap_sub_s(((z64)(li)), ((z64)(zT_338)), 32u);
    zT_340 = zig_overflow_flag_sub_s(((z64)(li)), ((z64)(zT_338)), 32u);
    zT_342 = zT_340 == (unsigned int)(0);
    if (!(zT_342)) { pal_trap(); }
    li = zT_339;
    goto z_bb_45;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_307 = 10;
    zT_308 = zig_wrap_mul_u(((zu64)(q)), ((zu64)(zT_307)), 64u);
    zT_309 = zig_overflow_flag_mul_u(((zu64)(q)), ((zu64)(zT_307)), 64u);
    zT_311 = zT_309 == (unsigned int)(0);
    if (!(zT_311)) { pal_trap(); }
    zT_312 = (zT_79FAE712_u64)dg;
    zT_313 = zig_wrap_add_u(((zu64)(zT_308)), ((zu64)(zT_312)), 64u);
    zT_314 = zig_overflow_flag_add_u(((zu64)(zT_308)), ((zu64)(zT_312)), 64u);
    zT_316 = zT_314 == (unsigned int)(0);
    if (!(zT_316)) { pal_trap(); }
    q = zT_313;
    zT_317 = 1;
    zT_318 = (unsigned int)zT_317;
    zT_319 = zig_wrap_add_u(((zu64)(collected)), ((zu64)(zT_318)), 32u);
    zT_320 = zig_overflow_flag_add_u(((zu64)(collected)), ((zu64)(zT_318)), 32u);
    zT_322 = zT_320 == (unsigned int)(0);
    if (!(zT_322)) { pal_trap(); }
    collected = zT_319;
    goto z_bb_57;
    z_bb_57:
    zT_331 = 1;
    zT_332 = (unsigned int)zT_331;
    zT_333 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_332)), 32u);
    zT_334 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_332)), 32u);
    zT_336 = zT_334 == (unsigned int)(0);
    if (!(zT_336)) { pal_trap(); }
    j = zT_333;
    goto z_bb_55;
    z_bb_58:
    zT_323 = 17;
    if ((unsigned char)(collected == (unsigned int)zT_323)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    d18 = dg;
    zT_325 = 1;
    zT_326 = (unsigned int)zT_325;
    zT_327 = zig_wrap_add_u(((zu64)(collected)), ((zu64)(zT_326)), 32u);
    zT_328 = zig_overflow_flag_add_u(((zu64)(collected)), ((zu64)(zT_326)), 32u);
    zT_330 = zT_328 == (unsigned int)(0);
    if (!(zT_330)) { pal_trap(); }
    collected = zT_327;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_57;
    z_bb_61:
    zT_343 = 17;
    if ((unsigned char)(collected < (unsigned int)zT_343)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_345 = 10;
    zT_346 = zig_wrap_mul_u(((zu64)(q)), ((zu64)(zT_345)), 64u);
    zT_347 = zig_overflow_flag_mul_u(((zu64)(q)), ((zu64)(zT_345)), 64u);
    zT_349 = zT_347 == (unsigned int)(0);
    if (!(zT_349)) { pal_trap(); }
    q = zT_346;
    zT_350 = 1;
    zT_351 = (unsigned int)zT_350;
    zT_352 = zig_wrap_add_u(((zu64)(collected)), ((zu64)(zT_351)), 32u);
    zT_353 = zig_overflow_flag_add_u(((zu64)(collected)), ((zu64)(zT_351)), 32u);
    zT_355 = zT_353 == (unsigned int)(0);
    if (!(zT_355)) { pal_trap(); }
    collected = zT_352;
    goto z_bb_64;
    z_bb_63:
    zT_356 = 5;
    if ((unsigned char)(d18 >= (unsigned int)zT_356)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_358 = 1;
    zT_359 = (zT_79FAE712_u64)zT_358;
    zT_360 = zig_wrap_add_u(((zu64)(q)), ((zu64)(zT_359)), 64u);
    zT_361 = zig_overflow_flag_add_u(((zu64)(q)), ((zu64)(zT_359)), 64u);
    zT_363 = zT_361 == (unsigned int)(0);
    if (!(zT_363)) { pal_trap(); }
    q = zT_360;
    goto z_bb_66;
    z_bb_66:
    zT_364 = Z98_U64_C(100000000000000000);
    if ((unsigned char)(q >= (zT_79FAE712_u64)zT_364)) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_366 = 10;
    zT_369 = (unsigned int)zT_366 != (unsigned int)(0);
    if (!(zT_369)) { pal_trap(); }
    zT_367 = q / zT_366;
    q = zT_367;
    zT_370 = 1;
    zT_371 = (int)zT_370;
    zT_372 = zig_wrap_add_s(((z64)(dexp)), ((z64)(zT_371)), 32u);
    zT_373 = zig_overflow_flag_add_s(((z64)(dexp)), ((z64)(zT_371)), 32u);
    zT_375 = zT_373 == (unsigned int)(0);
    if (!(zT_375)) { pal_trap(); }
    dexp = zT_372;
    goto z_bb_68;
    z_bb_68:
    zT_376 = 0;
    if ((unsigned char)(neg != zT_376)) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_378 = 45;
    zT_380 = bi < (unsigned int)(64);
    if (!(zT_380)) { pal_trap(); }
    sb[bi] = zT_378;
    zT_381 = 1;
    zT_382 = (unsigned int)zT_381;
    zT_383 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_382)), 32u);
    zT_384 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_382)), 32u);
    zT_386 = zT_384 == (unsigned int)(0);
    if (!(zT_386)) { pal_trap(); }
    bi = zT_383;
    goto z_bb_70;
    z_bb_70:
    zT_388 = Z98_U64_C(10000000000000000);
    zT_391 = (unsigned int)zT_388 != (unsigned int)(0);
    if (!(zT_391)) { pal_trap(); }
    zT_389 = q / zT_388;
    d1 = zT_389;
    zT_393 = Z98_U64_C(10000000000000000);
    zT_396 = (unsigned int)zT_393 != (unsigned int)(0);
    if (!(zT_396)) { pal_trap(); }
    zT_394 = q % zT_393;
    rest = zT_394;
    zT_397 = 48;
    zT_398 = (unsigned int)zig_cast_checked_u((zu64)d1, 64u, 0u, 32u);
    zT_399 = zig_wrap_add_u(((zu64)(zT_397)), ((zu64)(zT_398)), 32u);
    zT_400 = zig_overflow_flag_add_u(((zu64)(zT_397)), ((zu64)(zT_398)), 32u);
    zT_402 = zT_400 == (unsigned int)(0);
    if (!(zT_402)) { pal_trap(); }
    zT_403 = (unsigned char)zig_cast_checked_u((zu64)zT_399, 32u, 0u, 8u);
    zT_405 = bi < (unsigned int)(64);
    if (!(zT_405)) { pal_trap(); }
    sb[bi] = zT_403;
    zT_406 = 1;
    zT_407 = (unsigned int)zT_406;
    zT_408 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_407)), 32u);
    zT_409 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_407)), 32u);
    zT_411 = zT_409 == (unsigned int)(0);
    if (!(zT_411)) { pal_trap(); }
    bi = zT_408;
    zig_poison_fill((void*)&zT_413, (unsigned int)sizeof zT_413);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fdig[_i] = zT_413[_i];
        _i++;
    }
}
    zT_415 = 15;
    zT_416 = (int)zT_415;
    fi = zT_416;
    goto z_bb_71;
    z_bb_71:
    zT_417 = 0;
    if ((unsigned char)(fi >= zT_417)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_419 = 48;
    zT_420 = 10;
    zT_423 = (unsigned int)zT_420 != (unsigned int)(0);
    if (!(zT_423)) { pal_trap(); }
    zT_421 = rest % zT_420;
    zT_424 = (unsigned int)zig_cast_checked_u((zu64)zT_421, 64u, 0u, 32u);
    zT_425 = zig_wrap_add_u(((zu64)(zT_419)), ((zu64)(zT_424)), 32u);
    zT_426 = zig_overflow_flag_add_u(((zu64)(zT_419)), ((zu64)(zT_424)), 32u);
    zT_428 = zT_426 == (unsigned int)(0);
    if (!(zT_428)) { pal_trap(); }
    zT_429 = (unsigned char)zig_cast_checked_u((zu64)zT_425, 32u, 0u, 8u);
    zT_430 = (unsigned int)zig_cast_checked_u((zu64)fi, 32u, 1u, 32u);
    zT_432 = zT_430 < (unsigned int)(16);
    if (!(zT_432)) { pal_trap(); }
    fdig[zT_430] = zT_429;
    zT_433 = 10;
    zT_436 = (unsigned int)zT_433 != (unsigned int)(0);
    if (!(zT_436)) { pal_trap(); }
    zT_434 = rest / zT_433;
    rest = zT_434;
    zT_437 = 1;
    zT_438 = (int)zT_437;
    zT_439 = zig_wrap_sub_s(((z64)(fi)), ((z64)(zT_438)), 32u);
    zT_440 = zig_overflow_flag_sub_s(((z64)(fi)), ((z64)(zT_438)), 32u);
    zT_442 = zT_440 == (unsigned int)(0);
    if (!(zT_442)) { pal_trap(); }
    fi = zT_439;
    goto z_bb_74;
    z_bb_73:
    zT_444 = 16;
    zT_445 = (unsigned int)zT_444;
    flen = zT_445;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_446 = 0;
    if ((unsigned char)(flen > (unsigned int)zT_446)) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_459 = 1;
    zT_460 = (unsigned int)zT_459;
    zT_461 = zig_wrap_sub_u(((zu64)(flen)), ((zu64)(zT_460)), 32u);
    zT_462 = zig_overflow_flag_sub_u(((zu64)(flen)), ((zu64)(zT_460)), 32u);
    zT_464 = zT_462 == (unsigned int)(0);
    if (!(zT_464)) { pal_trap(); }
    flen = zT_461;
    goto z_bb_78;
    z_bb_77:
    zT_465 = 0;
    if ((unsigned char)(flen > (unsigned int)zT_465)) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_449 = 1;
    zT_450 = zig_wrap_sub_u(((zu64)(flen)), ((zu64)(zT_449)), 32u);
    zT_451 = zig_overflow_flag_sub_u(((zu64)(flen)), ((zu64)(zT_449)), 32u);
    zT_453 = zT_451 == (unsigned int)(0);
    if (!(zT_453)) { pal_trap(); }
    zT_455 = zT_450 < (unsigned int)(16);
    if (!(zT_455)) { pal_trap(); }
    zT_456 = fdig[zT_450];
    zT_448 = zT_456 == (unsigned char)(48);
    goto z_bb_81;
    z_bb_80:
    zT_448 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_448) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_467 = 46;
    zT_469 = bi < (unsigned int)(64);
    if (!(zT_469)) { pal_trap(); }
    sb[bi] = zT_467;
    zT_470 = 1;
    zT_471 = (unsigned int)zT_470;
    zT_472 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_471)), 32u);
    zT_473 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_471)), 32u);
    zT_475 = zT_473 == (unsigned int)(0);
    if (!(zT_475)) { pal_trap(); }
    bi = zT_472;
    zT_477 = 0;
    zT_478 = (unsigned int)zT_477;
    fj = zT_478;
    goto z_bb_84;
    z_bb_83:
    zT_497 = 101;
    zT_499 = bi < (unsigned int)(64);
    if (!(zT_499)) { pal_trap(); }
    sb[bi] = zT_497;
    zT_500 = 1;
    zT_501 = (unsigned int)zT_500;
    zT_502 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_501)), 32u);
    zT_503 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_501)), 32u);
    zT_505 = zT_503 == (unsigned int)(0);
    if (!(zT_505)) { pal_trap(); }
    bi = zT_502;
    ae = dexp;
    zT_507 = 0;
    if ((unsigned char)(ae < zT_507)) goto z_bb_88; else goto z_bb_90;
    z_bb_84:
    if ((unsigned char)(fj < flen)) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_481 = fj < (unsigned int)(16);
    if (!(zT_481)) { pal_trap(); }
    zT_482 = fdig[fj];
    zT_484 = bi < (unsigned int)(64);
    if (!(zT_484)) { pal_trap(); }
    sb[bi] = zT_482;
    zT_485 = 1;
    zT_486 = (unsigned int)zT_485;
    zT_487 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_486)), 32u);
    zT_488 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_486)), 32u);
    zT_490 = zT_488 == (unsigned int)(0);
    if (!(zT_490)) { pal_trap(); }
    bi = zT_487;
    zT_491 = 1;
    zT_492 = (unsigned int)zT_491;
    zT_493 = zig_wrap_add_u(((zu64)(fj)), ((zu64)(zT_492)), 32u);
    zT_494 = zig_overflow_flag_add_u(((zu64)(fj)), ((zu64)(zT_492)), 32u);
    zT_496 = zT_494 == (unsigned int)(0);
    if (!(zT_496)) { pal_trap(); }
    fj = zT_493;
    goto z_bb_87;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    zT_509 = 45;
    zT_511 = bi < (unsigned int)(64);
    if (!(zT_511)) { pal_trap(); }
    sb[bi] = zT_509;
    zT_512 = 1;
    zT_513 = (unsigned int)zT_512;
    zT_514 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_513)), 32u);
    zT_515 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_513)), 32u);
    zT_517 = zT_515 == (unsigned int)(0);
    if (!(zT_517)) { pal_trap(); }
    bi = zT_514;
    zT_518 = 0;
    zT_519 = zig_wrap_sub_s(((z64)(zT_518)), ((z64)(ae)), 32u);
    zT_520 = zig_overflow_flag_sub_s(((z64)(zT_518)), ((z64)(ae)), 32u);
    zT_522 = zT_520 == (unsigned int)(0);
    if (!(zT_522)) { pal_trap(); }
    ae = zT_519;
    goto z_bb_89;
    z_bb_89:
    zT_532 = 0;
    if ((unsigned char)(ae == zT_532)) goto z_bb_91; else goto z_bb_93;
    z_bb_90:
    zT_523 = 43;
    zT_525 = bi < (unsigned int)(64);
    if (!(zT_525)) { pal_trap(); }
    sb[bi] = zT_523;
    zT_526 = 1;
    zT_527 = (unsigned int)zT_526;
    zT_528 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_527)), 32u);
    zT_529 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_527)), 32u);
    zT_531 = zT_529 == (unsigned int)(0);
    if (!(zT_531)) { pal_trap(); }
    bi = zT_528;
    goto z_bb_89;
    z_bb_91:
    zT_534 = 48;
    zT_536 = bi < (unsigned int)(64);
    if (!(zT_536)) { pal_trap(); }
    sb[bi] = zT_534;
    zT_537 = 1;
    zT_538 = (unsigned int)zT_537;
    zT_539 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_538)), 32u);
    zT_540 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_538)), 32u);
    zT_542 = zT_540 == (unsigned int)(0);
    if (!(zT_542)) { pal_trap(); }
    bi = zT_539;
    goto z_bb_92;
    z_bb_92:
    zT_610 = 0;
    zT_611 = (unsigned char*)((unsigned char*)sb) + zT_610;
    zT_612 = bi - zT_610;
    zT_613 = (unsigned int)zT_610 <= bi;
    if (!(zT_613)) { pal_trap(); }
    zT_614 = bi <= (unsigned int)(64);
    if (!(zT_614)) { pal_trap(); }
    zT_615.ptr = (unsigned char*)zT_611;
    zT_615.len = zT_612;
    zT_605 = zT_615;
    zT_606 = buf;
    zT_607 = cap;
    zT_616 = zF_11ACB4EF_fmtCopyOut(zT_605, zT_606, zT_607);
    return zT_616;
    z_bb_93:
    zig_poison_fill((void*)&zT_544, (unsigned int)sizeof zT_544);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        eb[_i] = zT_544[_i];
        _i++;
    }
}
    zT_546 = 0;
    zT_547 = (unsigned int)zT_546;
    en = zT_547;
    av = ae;
    goto z_bb_94;
    z_bb_94:
    zT_549 = 0;
    if ((unsigned char)(av > zT_549)) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_551 = 48;
    zT_552 = 10;
    zT_558 = Z98_U64_C(18446744073709551615);
    zT_561 = (unsigned char)((unsigned int)zT_552 != (unsigned int)(0)) & (unsigned char)((unsigned char)(av != (int)((int)(-2147483647 - 1))) | (unsigned char)(zT_552 != zT_558));
    if (!(zT_561)) { pal_trap(); }
    zT_553 = av % zT_552;
    zT_562 = (unsigned int)zig_cast_checked_u((zu64)zT_553, 32u, 1u, 32u);
    zT_563 = zig_wrap_add_u(((zu64)(zT_551)), ((zu64)(zT_562)), 32u);
    zT_564 = zig_overflow_flag_add_u(((zu64)(zT_551)), ((zu64)(zT_562)), 32u);
    zT_566 = zT_564 == (unsigned int)(0);
    if (!(zT_566)) { pal_trap(); }
    zT_567 = (unsigned char)zig_cast_checked_u((zu64)zT_563, 32u, 0u, 8u);
    zT_569 = en < (unsigned int)(8);
    if (!(zT_569)) { pal_trap(); }
    eb[en] = zT_567;
    zT_570 = 10;
    zT_576 = Z98_U64_C(18446744073709551615);
    zT_579 = (unsigned char)((unsigned int)zT_570 != (unsigned int)(0)) & (unsigned char)((unsigned char)(av != (int)((int)(-2147483647 - 1))) | (unsigned char)(zT_570 != zT_576));
    if (!(zT_579)) { pal_trap(); }
    zT_571 = av / zT_570;
    av = zT_571;
    zT_580 = 1;
    zT_581 = (unsigned int)zT_580;
    zT_582 = zig_wrap_add_u(((zu64)(en)), ((zu64)(zT_581)), 32u);
    zT_583 = zig_overflow_flag_add_u(((zu64)(en)), ((zu64)(zT_581)), 32u);
    zT_585 = zT_583 == (unsigned int)(0);
    if (!(zT_585)) { pal_trap(); }
    en = zT_582;
    goto z_bb_97;
    z_bb_96:
    goto z_bb_98;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_586 = 0;
    if ((unsigned char)(en > (unsigned int)zT_586)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_588 = 1;
    zT_589 = (unsigned int)zT_588;
    zT_590 = zig_wrap_sub_u(((zu64)(en)), ((zu64)(zT_589)), 32u);
    zT_591 = zig_overflow_flag_sub_u(((zu64)(en)), ((zu64)(zT_589)), 32u);
    zT_593 = zT_591 == (unsigned int)(0);
    if (!(zT_593)) { pal_trap(); }
    en = zT_590;
    zT_595 = en < (unsigned int)(8);
    if (!(zT_595)) { pal_trap(); }
    zT_596 = eb[en];
    zT_598 = bi < (unsigned int)(64);
    if (!(zT_598)) { pal_trap(); }
    sb[bi] = zT_596;
    zT_599 = 1;
    zT_600 = (unsigned int)zT_599;
    zT_601 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_600)), 32u);
    zT_602 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_600)), 32u);
    zT_604 = zT_602 == (unsigned int)(0);
    if (!(zT_604)) { pal_trap(); }
    bi = zT_601;
    goto z_bb_101;
    z_bb_100:
    goto z_bb_92;
    z_bb_101:
    goto z_bb_98;
}

/* EOF */
