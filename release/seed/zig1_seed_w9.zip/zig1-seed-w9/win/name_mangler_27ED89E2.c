#include "name_mangler_27ED89E2.h"
zT_CEC2984A_NameMangler zG_CEC2984A_NameMangler;
/* writeHex */
void zF_8F8DE819_writeHex(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* pos, unsigned int value) {
    zT_C1AB0454_Arr_unsigned_char_8 zT_5;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned int zT_17;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char zT_52;
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned int zT_61;
    unsigned char zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    unsigned int v;
    zT_C1AB0454_Arr_unsigned_char_8 hex_buf;
    unsigned int i;
    unsigned int nibble;
    unsigned int j;
    v = value;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        hex_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = 8;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    zT_11 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    i = zT_11;
    zT_17 = v & (unsigned int)(15);
    nibble = zT_17;
    if ((unsigned char)(nibble < (unsigned int)(10))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_48 = 0;
    j = zT_48;
    goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = 48;
    zT_21 = (unsigned char)zig_cast_checked_u((zu64)nibble, 32u, 0u, 8u);
    zT_22 = zig_wrap_add_u(((zu64)(zT_20)), ((zu64)(zT_21)), 8u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(zT_20)), ((zu64)(zT_21)), 8u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = (unsigned int)i;
    zT_28 = zT_26 < (unsigned int)(8);
    if (!(zT_28)) { pal_trap(); }
    hex_buf[zT_26] = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_46 = 1;
    if (!(zT_46)) { pal_trap(); }
    zT_44 = v >> (unsigned int)(4);
    v = zT_44;
    goto z_bb_4;
    z_bb_7:
    zT_29 = 65;
    zT_30 = 10;
    zT_31 = zig_wrap_sub_u(((zu64)(nibble)), ((zu64)(zT_30)), 32u);
    zT_32 = zig_overflow_flag_sub_u(((zu64)(nibble)), ((zu64)(zT_30)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = (unsigned char)zig_cast_checked_u((zu64)zT_31, 32u, 0u, 8u);
    zT_36 = zig_wrap_add_u(((zu64)(zT_29)), ((zu64)(zT_35)), 8u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(zT_29)), ((zu64)(zT_35)), 8u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = (unsigned int)i;
    zT_42 = zT_40 < (unsigned int)(8);
    if (!(zT_42)) { pal_trap(); }
    hex_buf[zT_40] = zT_36;
    goto z_bb_6;
    z_bb_8:
    if ((unsigned char)(j < (unsigned int)(8))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_52 = j < (unsigned int)(8);
    if (!(zT_52)) { pal_trap(); }
    zT_53 = hex_buf[j];
    zT_54 = buf.ptr;
    zT_55 = *pos;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zig_wrap_add_u(((zu64)(zT_56)), ((zu64)(j)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_56)), ((zu64)(j)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_61 = buf.len;
    zT_62 = zT_57 < zT_61;
    if (!(zT_62)) { pal_trap(); }
    zT_54[zT_57] = zT_53;
    goto z_bb_11;
    z_bb_10:
    zT_68 = *pos;
    zT_69 = 8;
    zT_70 = zig_wrap_add_u(((zu64)(zT_68)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(zT_68)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    *pos = zT_70;
    return;
    z_bb_11:
    zT_63 = 1;
    zT_64 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    j = zT_64;
    goto z_bb_8;
}

/* isTempOrBuiltin */
unsigned char zF_F2F86D29_isTempOrBuiltin(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    unsigned char* zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned char zT_9;
    unsigned char zT_10;
    unsigned char zT_13;
    unsigned char* zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char* zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned char* zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    unsigned char zT_34;
    unsigned char zT_37;
    unsigned char* zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned char zT_42;
    unsigned char* zT_46;
    int zT_47;
    unsigned int zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned char zT_53;
    unsigned char* zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    unsigned char zT_58;
    unsigned char zT_61;
    unsigned char* zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_71;
    unsigned char zT_74;
    unsigned char* zT_75;
    int zT_76;
    unsigned int zT_77;
    unsigned char zT_78;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    unsigned char* zT_91;
    int zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    unsigned char zT_95;
    unsigned char zT_98;
    unsigned char* zT_99;
    int zT_100;
    unsigned int zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned char zT_106;
    unsigned char* zT_107;
    int zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char* zT_115;
    int zT_116;
    unsigned int zT_117;
    unsigned char zT_118;
    unsigned char zT_119;
    unsigned char zT_122;
    unsigned char* zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_130;
    unsigned char* zT_131;
    int zT_132;
    unsigned int zT_133;
    unsigned char zT_134;
    unsigned char zT_135;
    unsigned char zT_138;
    unsigned char* zT_139;
    int zT_140;
    unsigned int zT_141;
    unsigned char zT_142;
    unsigned char zT_143;
    zT_2 = name.len;
    if ((unsigned char)(zT_2 < (unsigned int)(5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = name.ptr;
    zT_7 = 0;
    zT_8 = name.len;
    zT_9 = (unsigned int)zT_7 < zT_8;
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_6[zT_7];
    if ((unsigned char)(zT_10 != (unsigned char)(95))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = name.ptr;
    zT_15 = 1;
    zT_16 = name.len;
    zT_17 = (unsigned int)zT_15 < zT_16;
    if (!(zT_17)) { pal_trap(); }
    zT_18 = zT_14[zT_15];
    zT_13 = zT_18 != (unsigned char)(95);
    goto z_bb_5;
    z_bb_4:
    zT_13 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_13) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_22 = name.ptr;
    zT_23 = 2;
    zT_24 = name.len;
    zT_25 = (unsigned int)zT_23 < zT_24;
    if (!(zT_25)) { pal_trap(); }
    zT_26 = zT_22[zT_23];
    if ((unsigned char)(zT_26 == (unsigned char)(116))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = name.ptr;
    zT_31 = 3;
    zT_32 = name.len;
    zT_33 = (unsigned int)zT_31 < zT_32;
    if (!(zT_33)) { pal_trap(); }
    zT_34 = zT_30[zT_31];
    zT_29 = zT_34 == (unsigned char)(109);
    goto z_bb_10;
    z_bb_9:
    zT_29 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = name.ptr;
    zT_39 = 4;
    zT_40 = name.len;
    zT_41 = (unsigned int)zT_39 < zT_40;
    if (!(zT_41)) { pal_trap(); }
    zT_42 = zT_38[zT_39];
    zT_37 = zT_42 == (unsigned char)(112);
    goto z_bb_13;
    z_bb_12:
    zT_37 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_37) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    zT_46 = name.ptr;
    zT_47 = 2;
    zT_48 = name.len;
    zT_49 = (unsigned int)zT_47 < zT_48;
    if (!(zT_49)) { pal_trap(); }
    zT_50 = zT_46[zT_47];
    if ((unsigned char)(zT_50 == (unsigned char)(114))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = name.ptr;
    zT_55 = 3;
    zT_56 = name.len;
    zT_57 = (unsigned int)zT_55 < zT_56;
    if (!(zT_57)) { pal_trap(); }
    zT_58 = zT_54[zT_55];
    zT_53 = zT_58 == (unsigned char)(101);
    goto z_bb_18;
    z_bb_17:
    zT_53 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_53) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_62 = name.ptr;
    zT_63 = 4;
    zT_64 = name.len;
    zT_65 = (unsigned int)zT_63 < zT_64;
    if (!(zT_65)) { pal_trap(); }
    zT_66 = zT_62[zT_63];
    zT_61 = zT_66 == (unsigned char)(116);
    goto z_bb_21;
    z_bb_20:
    zT_61 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_61) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    zT_71 = name.len;
    if ((unsigned char)(zT_71 >= (unsigned int)(11))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_75 = name.ptr;
    zT_76 = 2;
    zT_77 = name.len;
    zT_78 = (unsigned int)zT_76 < zT_77;
    if (!(zT_78)) { pal_trap(); }
    zT_79 = zT_75[zT_76];
    zT_74 = zT_79 == (unsigned char)(98);
    goto z_bb_26;
    z_bb_25:
    zT_74 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_74) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_83 = name.ptr;
    zT_84 = 3;
    zT_85 = name.len;
    zT_86 = (unsigned int)zT_84 < zT_85;
    if (!(zT_86)) { pal_trap(); }
    zT_87 = zT_83[zT_84];
    zT_82 = zT_87 == (unsigned char)(111);
    goto z_bb_29;
    z_bb_28:
    zT_82 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_82) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_91 = name.ptr;
    zT_92 = 4;
    zT_93 = name.len;
    zT_94 = (unsigned int)zT_92 < zT_93;
    if (!(zT_94)) { pal_trap(); }
    zT_95 = zT_91[zT_92];
    zT_90 = zT_95 == (unsigned char)(111);
    goto z_bb_32;
    z_bb_31:
    zT_90 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_90) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_99 = name.ptr;
    zT_100 = 5;
    zT_101 = name.len;
    zT_102 = (unsigned int)zT_100 < zT_101;
    if (!(zT_102)) { pal_trap(); }
    zT_103 = zT_99[zT_100];
    zT_98 = zT_103 == (unsigned char)(116);
    goto z_bb_35;
    z_bb_34:
    zT_98 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_98) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_107 = name.ptr;
    zT_108 = 6;
    zT_109 = name.len;
    zT_110 = (unsigned int)zT_108 < zT_109;
    if (!(zT_110)) { pal_trap(); }
    zT_111 = zT_107[zT_108];
    zT_106 = zT_111 == (unsigned char)(115);
    goto z_bb_38;
    z_bb_37:
    zT_106 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_106) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_115 = name.ptr;
    zT_116 = 7;
    zT_117 = name.len;
    zT_118 = (unsigned int)zT_116 < zT_117;
    if (!(zT_118)) { pal_trap(); }
    zT_119 = zT_115[zT_116];
    zT_114 = zT_119 == (unsigned char)(116);
    goto z_bb_41;
    z_bb_40:
    zT_114 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_114) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_123 = name.ptr;
    zT_124 = 8;
    zT_125 = name.len;
    zT_126 = (unsigned int)zT_124 < zT_125;
    if (!(zT_126)) { pal_trap(); }
    zT_127 = zT_123[zT_124];
    zT_122 = zT_127 == (unsigned char)(114);
    goto z_bb_44;
    z_bb_43:
    zT_122 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_122) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_131 = name.ptr;
    zT_132 = 9;
    zT_133 = name.len;
    zT_134 = (unsigned int)zT_132 < zT_133;
    if (!(zT_134)) { pal_trap(); }
    zT_135 = zT_131[zT_132];
    zT_130 = zT_135 == (unsigned char)(97);
    goto z_bb_47;
    z_bb_46:
    zT_130 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_130) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_139 = name.ptr;
    zT_140 = 10;
    zT_141 = name.len;
    zT_142 = (unsigned int)zT_140 < zT_141;
    if (!(zT_142)) { pal_trap(); }
    zT_143 = zT_139[zT_140];
    zT_138 = zT_143 == (unsigned char)(112);
    goto z_bb_50;
    z_bb_49:
    zT_138 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_138) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    return (unsigned char)(0);
}

/* isC89Keyword */
unsigned char zF_5412D014_isC89Keyword(zT_CEC2984A_NameMangler* self, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned char zT_6;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = &self->keyword_set;
    zT_3 = name_id;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(0);
}

/* mangleC89Keyword */
unsigned int zF_C3DD2126_mangleC89Keyword(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_472B2232_Arr_unsigned_char_3 zT_3;
    unsigned char zT_4;
    int zT_5;
    unsigned char zT_7;
    unsigned char zT_8;
    int zT_9;
    unsigned char zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned char zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    unsigned char zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zT_472B2232_Arr_unsigned_char_3 buf;
    unsigned int i;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 33) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 122;
    zT_5 = 0;
    zT_7 = (unsigned int)zT_5 < (unsigned int)(33);
    if (!(zT_7)) { pal_trap(); }
    buf[zT_5] = zT_4;
    zT_8 = 95;
    zT_9 = 1;
    zT_11 = (unsigned int)zT_9 < (unsigned int)(33);
    if (!(zT_11)) { pal_trap(); }
    buf[zT_9] = zT_8;
    zT_13 = 0;
    i = zT_13;
    goto z_bb_1;
    z_bb_1:
    zT_15 = name.len;
    if ((unsigned char)(i < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_25 = name.ptr;
    zT_26 = name.len;
    zT_27 = i < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    zT_29 = 2;
    zT_30 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_35 = zT_30 < (unsigned int)(33);
    if (!(zT_35)) { pal_trap(); }
    buf[zT_30] = zT_28;
    goto z_bb_4;
    z_bb_3:
    zT_41 = self->interner;
    zT_46 = 2;
    zT_47 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)buf) + zT_51;
    zT_53 = zT_47 - zT_51;
    zT_54 = (unsigned int)zT_51 <= zT_47;
    if (!(zT_54)) { pal_trap(); }
    zT_55 = zT_47 <= (unsigned int)(33);
    if (!(zT_55)) { pal_trap(); }
    zT_56.ptr = (unsigned char*)zT_52;
    zT_56.len = zT_53;
    zT_42 = zT_56;
    zT_57 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    return zT_57;
    z_bb_4:
    zT_36 = 1;
    zT_37 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    i = zT_37;
    goto z_bb_1;
    z_bb_5:
    zT_18 = 2;
    zT_19 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    zT_17 = zT_19 < (unsigned int)(33);
    goto z_bb_7;
    z_bb_6:
    zT_17 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_17) goto z_bb_2; else goto z_bb_3;
}

/* nameManglerPopulateKeywords */
void zF_F82AFAD8_nameManglerPopulate(zT_CEC2984A_NameMangler* self) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_B470B754_Arr_zT_8F083A69_Sli zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_164;
    zT_21D3708C_U32ToU32Map* zT_168;
    unsigned int zT_169;
    zT_D3EB6303_StringInterner* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned char zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned char zT_184;
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zT_8F083A69_Slice_zT_0B42B2F8_u k0;
    zT_8F083A69_Slice_zT_0B42B2F8_u k1;
    zT_8F083A69_Slice_zT_0B42B2F8_u k2;
    zT_8F083A69_Slice_zT_0B42B2F8_u k3;
    zT_8F083A69_Slice_zT_0B42B2F8_u k4;
    zT_8F083A69_Slice_zT_0B42B2F8_u k5;
    zT_8F083A69_Slice_zT_0B42B2F8_u k6;
    zT_8F083A69_Slice_zT_0B42B2F8_u k7;
    zT_8F083A69_Slice_zT_0B42B2F8_u k8;
    zT_8F083A69_Slice_zT_0B42B2F8_u k9;
    zT_8F083A69_Slice_zT_0B42B2F8_u k10;
    zT_8F083A69_Slice_zT_0B42B2F8_u k11;
    zT_8F083A69_Slice_zT_0B42B2F8_u k12;
    zT_8F083A69_Slice_zT_0B42B2F8_u k13;
    zT_8F083A69_Slice_zT_0B42B2F8_u k14;
    zT_8F083A69_Slice_zT_0B42B2F8_u k15;
    zT_8F083A69_Slice_zT_0B42B2F8_u k16;
    zT_8F083A69_Slice_zT_0B42B2F8_u k17;
    zT_8F083A69_Slice_zT_0B42B2F8_u k18;
    zT_8F083A69_Slice_zT_0B42B2F8_u k19;
    zT_8F083A69_Slice_zT_0B42B2F8_u k20;
    zT_8F083A69_Slice_zT_0B42B2F8_u k21;
    zT_8F083A69_Slice_zT_0B42B2F8_u k22;
    zT_8F083A69_Slice_zT_0B42B2F8_u k23;
    zT_8F083A69_Slice_zT_0B42B2F8_u k24;
    zT_8F083A69_Slice_zT_0B42B2F8_u k25;
    zT_8F083A69_Slice_zT_0B42B2F8_u k26;
    zT_8F083A69_Slice_zT_0B42B2F8_u k27;
    zT_8F083A69_Slice_zT_0B42B2F8_u k28;
    zT_8F083A69_Slice_zT_0B42B2F8_u k29;
    zT_8F083A69_Slice_zT_0B42B2F8_u k30;
    zT_8F083A69_Slice_zT_0B42B2F8_u k31;
    zT_B470B754_Arr_zT_8F083A69_Sli keywords;
    unsigned int ki;
    zT_2 = "auto";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    k0 = zT_3;
    zT_6 = "break";
    zT_8 = 5;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    k1 = zT_7;
    zT_10 = "case";
    zT_12 = 4;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    k2 = zT_11;
    zT_14 = "char";
    zT_16 = 4;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    k3 = zT_15;
    zT_18 = "const";
    zT_20 = 5;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    k4 = zT_19;
    zT_22 = "continue";
    zT_24 = 8;
    zT_23.ptr = (unsigned char*)zT_22;
    zT_23.len = zT_24;
    k5 = zT_23;
    zT_26 = "default";
    zT_28 = 7;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    k6 = zT_27;
    zT_30 = "do";
    zT_32 = 2;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    k7 = zT_31;
    zT_34 = "double";
    zT_36 = 6;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    k8 = zT_35;
    zT_38 = "else";
    zT_40 = 4;
    zT_39.ptr = (unsigned char*)zT_38;
    zT_39.len = zT_40;
    k9 = zT_39;
    zT_42 = "enum";
    zT_44 = 4;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    k10 = zT_43;
    zT_46 = "extern";
    zT_48 = 6;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    k11 = zT_47;
    zT_50 = "float";
    zT_52 = 5;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    k12 = zT_51;
    zT_54 = "for";
    zT_56 = 3;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    k13 = zT_55;
    zT_58 = "goto";
    zT_60 = 4;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    k14 = zT_59;
    zT_62 = "if";
    zT_64 = 2;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    k15 = zT_63;
    zT_66 = "int";
    zT_68 = 3;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    k16 = zT_67;
    zT_70 = "long";
    zT_72 = 4;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    k17 = zT_71;
    zT_74 = "register";
    zT_76 = 8;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    k18 = zT_75;
    zT_78 = "return";
    zT_80 = 6;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    k19 = zT_79;
    zT_82 = "short";
    zT_84 = 5;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    k20 = zT_83;
    zT_86 = "signed";
    zT_88 = 6;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    k21 = zT_87;
    zT_90 = "sizeof";
    zT_92 = 6;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    k22 = zT_91;
    zT_94 = "static";
    zT_96 = 6;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    k23 = zT_95;
    zT_98 = "struct";
    zT_100 = 6;
    zT_99.ptr = (unsigned char*)zT_98;
    zT_99.len = zT_100;
    k24 = zT_99;
    zT_102 = "switch";
    zT_104 = 6;
    zT_103.ptr = (unsigned char*)zT_102;
    zT_103.len = zT_104;
    k25 = zT_103;
    zT_106 = "typedef";
    zT_108 = 7;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    k26 = zT_107;
    zT_110 = "union";
    zT_112 = 5;
    zT_111.ptr = (unsigned char*)zT_110;
    zT_111.len = zT_112;
    k27 = zT_111;
    zT_114 = "unsigned";
    zT_116 = 8;
    zT_115.ptr = (unsigned char*)zT_114;
    zT_115.len = zT_116;
    k28 = zT_115;
    zT_118 = "void";
    zT_120 = 4;
    zT_119.ptr = (unsigned char*)zT_118;
    zT_119.len = zT_120;
    k29 = zT_119;
    zT_122 = "volatile";
    zT_124 = 8;
    zT_123.ptr = (unsigned char*)zT_122;
    zT_123.len = zT_124;
    k30 = zT_123;
    zT_126 = "while";
    zT_128 = 5;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    k31 = zT_127;
    zT_131 = 0;
    zT_130[zT_131] = k0;
    zT_132 = 1;
    zT_130[zT_132] = k1;
    zT_133 = 2;
    zT_130[zT_133] = k2;
    zT_134 = 3;
    zT_130[zT_134] = k3;
    zT_135 = 4;
    zT_130[zT_135] = k4;
    zT_136 = 5;
    zT_130[zT_136] = k5;
    zT_137 = 6;
    zT_130[zT_137] = k6;
    zT_138 = 7;
    zT_130[zT_138] = k7;
    zT_139 = 8;
    zT_130[zT_139] = k8;
    zT_140 = 9;
    zT_130[zT_140] = k9;
    zT_141 = 10;
    zT_130[zT_141] = k10;
    zT_142 = 11;
    zT_130[zT_142] = k11;
    zT_143 = 12;
    zT_130[zT_143] = k12;
    zT_144 = 13;
    zT_130[zT_144] = k13;
    zT_145 = 14;
    zT_130[zT_145] = k14;
    zT_146 = 15;
    zT_130[zT_146] = k15;
    zT_147 = 16;
    zT_130[zT_147] = k16;
    zT_148 = 17;
    zT_130[zT_148] = k17;
    zT_149 = 18;
    zT_130[zT_149] = k18;
    zT_150 = 19;
    zT_130[zT_150] = k19;
    zT_151 = 20;
    zT_130[zT_151] = k20;
    zT_152 = 21;
    zT_130[zT_152] = k21;
    zT_153 = 22;
    zT_130[zT_153] = k22;
    zT_154 = 23;
    zT_130[zT_154] = k23;
    zT_155 = 24;
    zT_130[zT_155] = k24;
    zT_156 = 25;
    zT_130[zT_156] = k25;
    zT_157 = 26;
    zT_130[zT_157] = k26;
    zT_158 = 27;
    zT_130[zT_158] = k27;
    zT_159 = 28;
    zT_130[zT_159] = k28;
    zT_160 = 29;
    zT_130[zT_160] = k29;
    zT_161 = 30;
    zT_130[zT_161] = k30;
    zT_162 = 31;
    zT_130[zT_162] = k31;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        keywords[_i] = zT_130[_i];
        _i++;
    }
}
    zT_164 = 0;
    ki = zT_164;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ki < (unsigned int)(32))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_168 = &self->keyword_set;
    zT_172 = self->interner;
    zT_176 = ki < (unsigned int)(32);
    if (!(zT_176)) { pal_trap(); }
    zT_177 = keywords[ki];
    zT_173 = zT_177;
    zT_178 = zF_50C274AF_stringInternerInter(zT_172, zT_173);
    zT_169 = zT_178;
    zF_26476265_u32ToU32MapPut(zT_168, zT_169, (unsigned int)(1));
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_180 = 1;
    zT_181 = zig_wrap_add_u(((zu64)(ki)), ((zu64)(zT_180)), 32u);
    zT_182 = zig_overflow_flag_add_u(((zu64)(ki)), ((zu64)(zT_180)), 32u);
    zT_184 = zT_182 == (unsigned int)(0);
    if (!(zT_184)) { pal_trap(); }
    ki = zT_181;
    goto z_bb_1;
}

/* nameManglerInit */
zT_CEC2984A_NameMangler zF_27DA3900_nameManglerInit_1(zT_D3EB6303_StringInterner* interner, zT_3E40CD83_Sand* alloc, unsigned int cache_hint) {
    zT_CEC2984A_NameMangler zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    zT_A4CE86B7_U64ToU32Map zT_8;
    zT_3E40CD83_Sand* zT_9;
    zT_21D3708C_U32ToU32Map zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_21D3708C_U32ToU32Map zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16;
    zT_F0990B59_Opt_343 zT_17;
    zT_3E40CD83_Sand* zT_18;
    zT_A4CE86B7_U64ToU32Map zT_19;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_A4CE86B7_U64ToU32Map zT_23;
    zT_3E40CD83_Sand* zT_24;
    zT_A4CE86B7_U64ToU32Map zT_25;
    zT_3E40CD83_Sand* zT_26;
    zT_A4CE86B7_U64ToU32Map zT_27;
    zT_3E40CD83_Sand* zT_28;
    zT_A4CE86B7_U64ToU32Map zT_29;
    zT_CEC2984A_NameMangler* zT_30;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zT_CEC2984A_NameMangler mangler;
    zT_5 = 0;
    zT_4.hash_seed = zT_5;
    zT_6 = alloc;
    zT_7 = cache_hint;
    zT_8 = zF_CE4144CF_u64ToU32MapInitCap(zT_6, zT_7);
    zT_4.cache = zT_8;
    zT_9 = alloc;
    zT_12 = zF_619D56E6_u32ToU32MapInitCap(zT_9, (unsigned int)(32));
    zT_4.keyword_set = zT_12;
    zT_13 = alloc;
    zT_14 = zF_58BDA2DE_u32ToU32MapInit(zT_13);
    zT_4.collision_mod = zT_14;
    zT_15 = alloc;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_4.collision_name = zT_16;
    zT_4.interner = interner;
    zT_17.has_value = 0;
    zT_4.exported = zT_17;
    zT_18 = alloc;
    zT_19 = zF_986226E1_u64ToU32MapInit(zT_18);
    zT_4.raw_cache_local = zT_19;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    zT_4.raw_taken_local = zT_21;
    zT_22 = alloc;
    zT_23 = zF_986226E1_u64ToU32MapInit(zT_22);
    zT_4.raw_cache_field = zT_23;
    zT_24 = alloc;
    zT_25 = zF_986226E1_u64ToU32MapInit(zT_24);
    zT_4.raw_taken_field = zT_25;
    zT_26 = alloc;
    zT_27 = zF_986226E1_u64ToU32MapInit(zT_26);
    zT_4.raw_cache_member = zT_27;
    zT_28 = alloc;
    zT_29 = zF_986226E1_u64ToU32MapInit(zT_28);
    zT_4.raw_taken_member = zT_29;
    mangler = zT_4;
    zT_30 = (zT_CEC2984A_NameMangler*)&mangler;
    zF_F82AFAD8_nameManglerPopulate(zT_30);
    return mangler;
}

/* nameManglerMangle */
unsigned int zF_713D1938_nameManglerMangle(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned char kind, unsigned int module_id) {
    zT_D3EB6303_StringInterner* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char zT_10;
    zT_CEC2984A_NameMangler* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zT_CEC2984A_NameMangler* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_22;
    zT_79FAE712_u64 zT_23;
    zT_79FAE712_u64 zT_24;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_79FAE712_u64 zT_30;
    zT_79FAE712_u64 zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned char zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    zT_79FAE712_u64 zT_40;
    zT_F0990B59_Opt_343 zT_41;
    unsigned char zT_42;
    zT_A4CE86B7_U64ToU32Map* zT_44;
    zT_79FAE712_u64 zT_45;
    zT_BAEE192E_Opt_10 zT_46;
    unsigned char zT_47;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    zT_BAEE192E_Opt_10 zT_52;
    unsigned char zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_62;
    unsigned char zT_65;
    unsigned char zT_68;
    zT_482B23C5_Arr_unsigned_char_3 zT_70;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned char zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    unsigned char zT_88;
    unsigned char zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int* zT_97;
    unsigned int zT_98;
    int zT_101;
    unsigned char* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char zT_106;
    unsigned char zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    unsigned int zT_116;
    unsigned int zT_118;
    unsigned char zT_120;
    unsigned char* zT_123;
    unsigned int zT_124;
    unsigned char zT_125;
    unsigned char zT_126;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    unsigned int zT_141;
    zT_D3EB6303_StringInterner* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    int zT_148;
    unsigned char* zT_149;
    unsigned int zT_150;
    unsigned char zT_151;
    unsigned char zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_21D3708C_U32ToU32Map* zT_159;
    unsigned int zT_160;
    zT_BAEE192E_Opt_10 zT_162;
    unsigned char zT_163;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    unsigned int zT_172;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_183;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned char zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    unsigned int zT_201;
    unsigned int zT_203;
    unsigned char zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned char zT_209;
    unsigned char* zT_211;
    unsigned int zT_212;
    unsigned char zT_213;
    unsigned char zT_214;
    unsigned char zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned char zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned char zT_226;
    unsigned char zT_227;
    unsigned char zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned char zT_234;
    zT_B5AAF170_Arr_unsigned_char_4 zT_237;
    unsigned int zT_239;
    unsigned char zT_242;
    unsigned int zT_244;
    unsigned char zT_246;
    unsigned char zT_247;
    unsigned char zT_248;
    unsigned int zT_249;
    unsigned char zT_251;
    unsigned int zT_252;
    unsigned char zT_254;
    unsigned int zT_256;
    unsigned char zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned char zT_263;
    unsigned char zT_266;
    unsigned char zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned char zT_273;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned char zT_281;
    unsigned int zT_282;
    unsigned char zT_284;
    unsigned char zT_285;
    unsigned char zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned char zT_292;
    unsigned int zT_295;
    zT_D3EB6303_StringInterner* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    int zT_301;
    unsigned char* zT_302;
    unsigned int zT_303;
    unsigned char zT_304;
    unsigned char zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned int zT_307;
    zT_21D3708C_U32ToU32Map* zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    zT_21D3708C_U32ToU32Map* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_A4CE86B7_U64ToU32Map* zT_316;
    zT_79FAE712_u64 zT_317;
    unsigned int zT_318;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_162, (unsigned int)sizeof zT_162);
    zig_poison_fill((void*)&zT_307, (unsigned int)sizeof zT_307);
    zT_8F083A69_Slice_zT_0B42B2F8_u name;
    zT_79FAE712_u64 key;
    zT_A4CE86B7_U64ToU32Map* exp_map;
    unsigned int cached;
    unsigned int hash;
    unsigned char kind_char;
    zT_482B23C5_Arr_unsigned_char_3 buf;
    unsigned int p;
    unsigned int prefix_end;
    unsigned int idx;
    unsigned int mangled_id;
    unsigned int counter;
    zT_BAEE192E_Opt_10 existing_mod;
    unsigned int cnt;
    unsigned int dc;
    unsigned int max_nc;
    unsigned int ci;
    unsigned int cv;
    zT_B5AAF170_Arr_unsigned_char_4 cd;
    unsigned int di;
    unsigned int dk;
    zT_5 = self->interner;
    zT_6 = name_id;
    zT_8 = zF_9134020D_stringInternerGet(zT_5, zT_6);
    name = zT_8;
    zT_9 = name;
    zT_10 = zF_F2F86D29_isTempOrBuiltin(zT_9);
    if ((unsigned char)(zT_10 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return name_id;
    z_bb_2:
    zT_13 = self;
    zT_14 = name_id;
    zT_15 = zF_5412D014_isC89Keyword(zT_13, zT_14);
    if ((unsigned char)(zT_15 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = name;
    zT_20 = zF_C3DD2126_mangleC89Keyword(zT_18, zT_19);
    return zT_20;
    z_bb_4:
    zT_22 = (zT_79FAE712_u64)module_id;
    zT_23 = 35;
    zT_26 = zT_23 < (unsigned int)(64);
    if (!(zT_26)) { pal_trap(); }
    zT_24 = zig_wrap_shl_u(((zu64)(zT_22)), ((zu64)(zT_23)), 64u);
    zT_27 = zig_overflow_flag_shl_u(((zu64)(zT_22)), ((zu64)(zT_23)), 64u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    zT_30 = (zT_79FAE712_u64)kind;
    zT_31 = 32;
    zT_34 = zT_31 < (unsigned int)(64);
    if (!(zT_34)) { pal_trap(); }
    zT_32 = zig_wrap_shl_u(((zu64)(zT_30)), ((zu64)(zT_31)), 64u);
    zT_35 = zig_overflow_flag_shl_u(((zu64)(zT_30)), ((zu64)(zT_31)), 64u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_40 = (zT_79FAE712_u64)(zT_24 | zT_32) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_40;
    zT_41 = self->exported;
    zT_42 = zT_41.has_value;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    if (!(zT_41.has_value)) { pal_trap(); }
    exp_map = zT_41.value;
    zT_44 = exp_map;
    zT_45 = key;
    zT_46 = zF_A05A7BE1_u64ToU32MapGet(zT_44, zT_45);
    zT_47 = zT_46.has_value;
    if (zT_47) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_49 = &self->cache;
    zT_50 = key;
    zT_52 = zF_A05A7BE1_u64ToU32MapGet(zT_49, zT_50);
    zT_53 = zT_52.has_value;
    if (zT_53) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return name_id;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    if (!(zT_52.has_value)) { pal_trap(); }
    cached = zT_52.value;
    return cached;
    z_bb_10:
    zT_56 = name;
    zT_57 = zF_B22E025B_fnv1a(zT_56);
    hash = zT_57;
    zT_59 = 76;
    kind_char = zT_59;
    if ((unsigned char)(kind == (unsigned char)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_62 = 70;
    kind_char = zT_62;
    goto z_bb_12;
    z_bb_12:
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        buf[_i] = zT_70[_i];
        _i++;
    }
}
    zT_72 = 0;
    p = zT_72;
    zT_73 = 122;
    zT_75 = p < (unsigned int)(32);
    if (!(zT_75)) { pal_trap(); }
    buf[p] = zT_73;
    zT_76 = 1;
    zT_77 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_76)), 32u);
    zT_78 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_76)), 32u);
    zT_80 = zT_78 == (unsigned int)(0);
    if (!(zT_80)) { pal_trap(); }
    p = zT_77;
    zT_82 = p < (unsigned int)(32);
    if (!(zT_82)) { pal_trap(); }
    buf[p] = kind_char;
    zT_83 = 1;
    zT_84 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_83)), 32u);
    zT_85 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_83)), 32u);
    zT_87 = zT_85 == (unsigned int)(0);
    if (!(zT_87)) { pal_trap(); }
    p = zT_84;
    zT_88 = 95;
    zT_90 = p < (unsigned int)(32);
    if (!(zT_90)) { pal_trap(); }
    buf[p] = zT_88;
    zT_91 = 1;
    zT_92 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    p = zT_92;
    zT_101 = 0;
    zT_102 = (unsigned char*)((unsigned char*)buf) + zT_101;
    zT_103 = (unsigned int)(32) - zT_101;
    zT_104.ptr = (unsigned char*)zT_102;
    zT_104.len = zT_103;
    zT_96 = zT_104;
    zT_97 = (unsigned int*)&p;
    zT_98 = hash;
    zF_8F8DE819_writeHex(zT_96, zT_97, zT_98);
    zT_106 = 95;
    zT_108 = p < (unsigned int)(32);
    if (!(zT_108)) { pal_trap(); }
    buf[p] = zT_106;
    zT_109 = 1;
    zT_110 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_109)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_109)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    p = zT_110;
    prefix_end = p;
    zT_116 = 0;
    idx = zT_116;
    goto z_bb_19;
    z_bb_13:
    if ((unsigned char)(kind == (unsigned char)(1))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_65 = 71;
    kind_char = zT_65;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    if ((unsigned char)(kind == (unsigned char)(2))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_68 = 84;
    kind_char = zT_68;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_118 = name.len;
    if ((unsigned char)(idx < zT_118)) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_123 = name.ptr;
    zT_124 = name.len;
    zT_125 = idx < zT_124;
    if (!(zT_125)) { pal_trap(); }
    zT_126 = zT_123[idx];
    zT_128 = p < (unsigned int)(32);
    if (!(zT_128)) { pal_trap(); }
    buf[p] = zT_126;
    zT_129 = 1;
    zT_130 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_129)), 32u);
    zT_131 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_129)), 32u);
    zT_133 = zT_131 == (unsigned int)(0);
    if (!(zT_133)) { pal_trap(); }
    p = zT_130;
    goto z_bb_22;
    z_bb_21:
    if ((unsigned char)(p > (unsigned int)(31))) goto z_bb_26; else goto z_bb_27;
    z_bb_22:
    zT_134 = 1;
    zT_135 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_134)), 32u);
    zT_136 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_134)), 32u);
    zT_138 = zT_136 == (unsigned int)(0);
    if (!(zT_138)) { pal_trap(); }
    idx = zT_135;
    goto z_bb_19;
    z_bb_23:
    zT_120 = p < (unsigned int)(31);
    goto z_bb_25;
    z_bb_24:
    zT_120 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_120) goto z_bb_20; else goto z_bb_21;
    z_bb_26:
    zT_141 = 31;
    p = zT_141;
    goto z_bb_27;
    z_bb_27:
    zT_143 = self->interner;
    zT_148 = 0;
    zT_149 = (unsigned char*)((unsigned char*)buf) + zT_148;
    zT_150 = p - zT_148;
    zT_151 = (unsigned int)zT_148 <= p;
    if (!(zT_151)) { pal_trap(); }
    zT_152 = p <= (unsigned int)(32);
    if (!(zT_152)) { pal_trap(); }
    zT_153.ptr = (unsigned char*)zT_149;
    zT_153.len = zT_150;
    zT_144 = zT_153;
    zT_154 = zF_50C274AF_stringInternerInter(zT_143, zT_144);
    mangled_id = zT_154;
    zT_156 = 0;
    counter = zT_156;
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(1)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_159 = &self->collision_mod;
    zT_160 = mangled_id;
    zT_162 = zF_F3EE5998_u32ToU32MapGet(zT_159, zT_160);
    existing_mod = zT_162;
    zT_163 = existing_mod.has_value;
    if (zT_163) goto z_bb_32; else goto z_bb_34;
    z_bb_30:
    zT_308 = &self->collision_mod;
    zT_309 = mangled_id;
    zT_310 = module_id;
    zF_26476265_u32ToU32MapPut(zT_308, zT_309, zT_310);
    zT_312 = &self->collision_name;
    zT_313 = mangled_id;
    zT_314 = name_id;
    zF_26476265_u32ToU32MapPut(zT_312, zT_313, zT_314);
    zT_316 = &self->cache;
    zT_317 = key;
    zT_318 = mangled_id;
    zF_B6EB812C_u64ToU32MapPut(zT_316, zT_317, zT_318);
    return mangled_id;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_165 = 1;
    zT_166 = zig_wrap_add_u(((zu64)(counter)), ((zu64)(zT_165)), 32u);
    zT_167 = zig_overflow_flag_add_u(((zu64)(counter)), ((zu64)(zT_165)), 32u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    counter = zT_166;
    p = prefix_end;
    cnt = counter;
    zT_172 = 1;
    dc = zT_172;
    goto z_bb_35;
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    if ((unsigned char)(cnt >= (unsigned int)(10))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_175 = 1;
    zT_176 = zig_wrap_add_u(((zu64)(dc)), ((zu64)(zT_175)), 32u);
    zT_177 = zig_overflow_flag_add_u(((zu64)(dc)), ((zu64)(zT_175)), 32u);
    zT_179 = zT_177 == (unsigned int)(0);
    if (!(zT_179)) { pal_trap(); }
    dc = zT_176;
    goto z_bb_38;
    z_bb_37:
    zT_185 = 31;
    zT_186 = zig_wrap_sub_u(((zu64)(zT_185)), ((zu64)(prefix_end)), 32u);
    zT_187 = zig_overflow_flag_sub_u(((zu64)(zT_185)), ((zu64)(prefix_end)), 32u);
    zT_189 = zT_187 == (unsigned int)(0);
    if (!(zT_189)) { pal_trap(); }
    zT_190 = 1;
    zT_191 = zig_wrap_sub_u(((zu64)(zT_186)), ((zu64)(zT_190)), 32u);
    zT_192 = zig_overflow_flag_sub_u(((zu64)(zT_186)), ((zu64)(zT_190)), 32u);
    zT_194 = zT_192 == (unsigned int)(0);
    if (!(zT_194)) { pal_trap(); }
    zT_195 = (unsigned int)dc;
    zT_196 = zig_wrap_sub_u(((zu64)(zT_191)), ((zu64)(zT_195)), 32u);
    zT_197 = zig_overflow_flag_sub_u(((zu64)(zT_191)), ((zu64)(zT_195)), 32u);
    zT_199 = zT_197 == (unsigned int)(0);
    if (!(zT_199)) { pal_trap(); }
    max_nc = zT_196;
    zT_201 = 0;
    ci = zT_201;
    goto z_bb_39;
    z_bb_38:
    zT_183 = 1;
    if (!(zT_183)) { pal_trap(); }
    zT_181 = cnt / (unsigned int)(10);
    cnt = zT_181;
    goto z_bb_35;
    z_bb_39:
    zT_203 = name.len;
    if ((unsigned char)(ci < zT_203)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_211 = name.ptr;
    zT_212 = name.len;
    zT_213 = ci < zT_212;
    if (!(zT_213)) { pal_trap(); }
    zT_214 = zT_211[ci];
    zT_216 = p < (unsigned int)(32);
    if (!(zT_216)) { pal_trap(); }
    buf[p] = zT_214;
    zT_217 = 1;
    zT_218 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_217)), 32u);
    zT_219 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_217)), 32u);
    zT_221 = zT_219 == (unsigned int)(0);
    if (!(zT_221)) { pal_trap(); }
    p = zT_218;
    goto z_bb_42;
    z_bb_41:
    zT_227 = 95;
    zT_229 = p < (unsigned int)(32);
    if (!(zT_229)) { pal_trap(); }
    buf[p] = zT_227;
    zT_230 = 1;
    zT_231 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_230)), 32u);
    zT_232 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_230)), 32u);
    zT_234 = zT_232 == (unsigned int)(0);
    if (!(zT_234)) { pal_trap(); }
    p = zT_231;
    cv = counter;
    zig_poison_fill((void*)&zT_237, (unsigned int)sizeof zT_237);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        cd[_i] = zT_237[_i];
        _i++;
    }
}
    zT_239 = 0;
    di = zT_239;
    goto z_bb_46;
    z_bb_42:
    zT_222 = 1;
    zT_223 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_222)), 32u);
    zT_224 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_222)), 32u);
    zT_226 = zT_224 == (unsigned int)(0);
    if (!(zT_226)) { pal_trap(); }
    ci = zT_223;
    goto z_bb_39;
    z_bb_43:
    zT_206 = zig_wrap_add_u(((zu64)(prefix_end)), ((zu64)(max_nc)), 32u);
    zT_207 = zig_overflow_flag_add_u(((zu64)(prefix_end)), ((zu64)(max_nc)), 32u);
    zT_209 = zT_207 == (unsigned int)(0);
    if (!(zT_209)) { pal_trap(); }
    zT_205 = p < zT_206;
    goto z_bb_45;
    z_bb_44:
    zT_205 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_205) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    if ((unsigned char)(cv > (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_242 = 48;
    zT_246 = 1;
    if (!(zT_246)) { pal_trap(); }
    zT_244 = cv % (unsigned int)(10);
    zT_247 = (unsigned char)zig_cast_checked_u((zu64)zT_244, 32u, 0u, 8u);
    zT_248 = zig_wrap_add_u(((zu64)(zT_242)), ((zu64)(zT_247)), 8u);
    zT_249 = zig_overflow_flag_add_u(((zu64)(zT_242)), ((zu64)(zT_247)), 8u);
    zT_251 = zT_249 == (unsigned int)(0);
    if (!(zT_251)) { pal_trap(); }
    zT_252 = (unsigned int)di;
    zT_254 = zT_252 < (unsigned int)(4);
    if (!(zT_254)) { pal_trap(); }
    cd[zT_252] = zT_248;
    zT_258 = 1;
    if (!(zT_258)) { pal_trap(); }
    zT_256 = cv / (unsigned int)(10);
    cv = zT_256;
    zT_259 = 1;
    zT_260 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_259)), 32u);
    zT_261 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_259)), 32u);
    zT_263 = zT_261 == (unsigned int)(0);
    if (!(zT_263)) { pal_trap(); }
    di = zT_260;
    goto z_bb_49;
    z_bb_48:
    if ((unsigned char)(di == (unsigned int)(0))) goto z_bb_50; else goto z_bb_52;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_266 = 48;
    zT_268 = p < (unsigned int)(32);
    if (!(zT_268)) { pal_trap(); }
    buf[p] = zT_266;
    zT_269 = 1;
    zT_270 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_269)), 32u);
    zT_271 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_269)), 32u);
    zT_273 = zT_271 == (unsigned int)(0);
    if (!(zT_273)) { pal_trap(); }
    p = zT_270;
    goto z_bb_51;
    z_bb_51:
    if ((unsigned char)(p > (unsigned int)(31))) goto z_bb_57; else goto z_bb_58;
    z_bb_52:
    dk = di;
    goto z_bb_53;
    z_bb_53:
    if ((unsigned char)(dk > (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_277 = 1;
    zT_278 = zig_wrap_sub_u(((zu64)(dk)), ((zu64)(zT_277)), 32u);
    zT_279 = zig_overflow_flag_sub_u(((zu64)(dk)), ((zu64)(zT_277)), 32u);
    zT_281 = zT_279 == (unsigned int)(0);
    if (!(zT_281)) { pal_trap(); }
    dk = zT_278;
    zT_282 = (unsigned int)dk;
    zT_284 = zT_282 < (unsigned int)(4);
    if (!(zT_284)) { pal_trap(); }
    zT_285 = cd[zT_282];
    zT_287 = p < (unsigned int)(32);
    if (!(zT_287)) { pal_trap(); }
    buf[p] = zT_285;
    zT_288 = 1;
    zT_289 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_288)), 32u);
    zT_290 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_288)), 32u);
    zT_292 = zT_290 == (unsigned int)(0);
    if (!(zT_292)) { pal_trap(); }
    p = zT_289;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_51;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_295 = 31;
    p = zT_295;
    goto z_bb_58;
    z_bb_58:
    zT_296 = self->interner;
    zT_301 = 0;
    zT_302 = (unsigned char*)((unsigned char*)buf) + zT_301;
    zT_303 = p - zT_301;
    zT_304 = (unsigned int)zT_301 <= p;
    if (!(zT_304)) { pal_trap(); }
    zT_305 = p <= (unsigned int)(32);
    if (!(zT_305)) { pal_trap(); }
    zT_306.ptr = (unsigned char*)zT_302;
    zT_306.len = zT_303;
    zT_297 = zT_306;
    zT_307 = zF_50C274AF_stringInternerInter(zT_296, zT_297);
    mangled_id = zT_307;
    goto z_bb_33;
}

/* nameManglerMangleGlobal */
unsigned int zF_027E7C4F_nameManglerMangle_1(zT_CEC2984A_NameMangler* self, zT_338B7C76_TypeRegistry* registry, unsigned int name_id, unsigned int module_id, unsigned int type_id) {
    unsigned int zT_5;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    unsigned int zT_12;
    unsigned char zT_15;
    unsigned int zT_16;
    zT_CEC2984A_NameMangler* zT_18;
    unsigned int zT_19;
    unsigned short zT_24;
    unsigned int zT_26;
    zT_CEC2984A_NameMangler* zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_D155D06D_Type ty;
    zT_5 = registry->types_len;
    if ((unsigned char)(type_id < (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = registry->types_items;
    zT_10 = (unsigned int)type_id;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    zT_12 = ty.name_id;
    if ((unsigned char)(zT_12 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_27 = self;
    zT_28 = name_id;
    zT_30 = module_id;
    zT_32 = zF_713D1938_nameManglerMangle(zT_27, zT_28, (unsigned char)(1), zT_30);
    return zT_32;
    z_bb_3:
    zT_16 = ty.name_id;
    zT_15 = zT_16 == name_id;
    goto z_bb_5;
    z_bb_4:
    zT_15 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = self;
    zT_19 = ty.name_id;
    zT_24 = ty.module_id;
    zT_26 = zF_713D1938_nameManglerMangle(zT_18, zT_19, (unsigned char)(1), (unsigned int)((unsigned int)zT_24));
    return zT_26;
    z_bb_7:
    goto z_bb_2;
}

/* nameManglerMintRaw */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_571F0158_nameManglerMintRaw(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope, zT_A4CE86B7_U64ToU32Map* cache, zT_A4CE86B7_U64ToU32Map* taken) {
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zT_79FAE712_u64 zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_79FAE712_u64 zT_17;
    zT_BAEE192E_Opt_10 zT_18;
    unsigned char zT_19;
    zT_D3EB6303_StringInterner* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    zT_CEC2984A_NameMangler* zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_CEC2984A_NameMangler* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    unsigned int zT_40;
    zT_79FAE712_u64 zT_43;
    zT_79FAE712_u64 zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    zT_79FAE712_u64 zT_52;
    zT_A4CE86B7_U64ToU32Map* zT_53;
    zT_79FAE712_u64 zT_54;
    zT_BAEE192E_Opt_10 zT_55;
    unsigned char zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_C4003E6D_Arr_unsigned_char_1 zT_69;
    unsigned int zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char* zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    unsigned char zT_83;
    unsigned char zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned char zT_103;
    zT_5426B97B_Arr_unsigned_char_1 zT_105;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    unsigned char zT_126;
    unsigned char zT_130;
    unsigned char zT_131;
    unsigned char zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned char zT_143;
    zT_D3EB6303_StringInterner* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    int zT_149;
    unsigned char* zT_150;
    unsigned int zT_151;
    unsigned char zT_152;
    unsigned char zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_A4CE86B7_U64ToU32Map* zT_156;
    zT_79FAE712_u64 zT_157;
    unsigned int zT_158;
    zT_79FAE712_u64 zT_160;
    zT_79FAE712_u64 zT_161;
    zT_79FAE712_u64 zT_162;
    unsigned char zT_164;
    unsigned int zT_165;
    unsigned char zT_167;
    zT_79FAE712_u64 zT_169;
    zT_A4CE86B7_U64ToU32Map* zT_170;
    zT_79FAE712_u64 zT_171;
    zT_D3EB6303_StringInterner* zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_155, (unsigned int)sizeof zT_155);
    zig_poison_fill((void*)&zT_177, (unsigned int)sizeof zT_177);
    zT_79FAE712_u64 key;
    unsigned int cached;
    zT_8F083A69_Slice_zT_0B42B2F8_u name;
    unsigned int cand_id;
    unsigned int counter;
    zT_79FAE712_u64 tkey;
    zT_79FAE712_u64 done_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u cand;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int p;
    unsigned int ci;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int di;
    zT_6 = (zT_79FAE712_u64)scope;
    zT_7 = 32;
    zT_10 = zT_7 < (unsigned int)(64);
    if (!(zT_10)) { pal_trap(); }
    zT_8 = zig_wrap_shl_u(((zu64)(zT_6)), ((zu64)(zT_7)), 64u);
    zT_11 = zig_overflow_flag_shl_u(((zu64)(zT_6)), ((zu64)(zT_7)), 64u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    zT_15 = zT_8 | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_15;
    zT_16 = cache;
    zT_17 = key;
    zT_18 = zF_A05A7BE1_u64ToU32MapGet(zT_16, zT_17);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_18.has_value)) { pal_trap(); }
    cached = zT_18.value;
    zT_21 = self->interner;
    zT_22 = cached;
    zT_24 = zF_9134020D_stringInternerGet(zT_21, zT_22);
    return zT_24;
    z_bb_2:
    zT_26 = self->interner;
    zT_27 = name_id;
    zT_29 = zF_9134020D_stringInternerGet(zT_26, zT_27);
    name = zT_29;
    cand_id = name_id;
    zT_31 = self;
    zT_32 = name_id;
    zT_33 = zF_5412D014_isC89Keyword(zT_31, zT_32);
    if ((unsigned char)(zT_33 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_36 = self;
    zT_37 = name;
    zT_38 = zF_C3DD2126_mangleC89Keyword(zT_36, zT_37);
    cand_id = zT_38;
    goto z_bb_4;
    z_bb_4:
    zT_40 = 0;
    counter = zT_40;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(1)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_43 = (zT_79FAE712_u64)scope;
    zT_44 = 32;
    zT_47 = zT_44 < (unsigned int)(64);
    if (!(zT_47)) { pal_trap(); }
    zT_45 = zig_wrap_shl_u(((zu64)(zT_43)), ((zu64)(zT_44)), 64u);
    zT_48 = zig_overflow_flag_shl_u(((zu64)(zT_43)), ((zu64)(zT_44)), 64u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_52 = zT_45 | (zT_79FAE712_u64)((zT_79FAE712_u64)cand_id);
    tkey = zT_52;
    zT_53 = taken;
    zT_54 = tkey;
    zT_55 = zF_A05A7BE1_u64ToU32MapGet(zT_53, zT_54);
    zT_56 = zT_55.has_value;
    if (zT_56) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_156 = cache;
    zT_157 = key;
    zT_158 = cand_id;
    zF_B6EB812C_u64ToU32MapPut(zT_156, zT_157, zT_158);
    zT_160 = (zT_79FAE712_u64)scope;
    zT_161 = 32;
    zT_164 = zT_161 < (unsigned int)(64);
    if (!(zT_164)) { pal_trap(); }
    zT_162 = zig_wrap_shl_u(((zu64)(zT_160)), ((zu64)(zT_161)), 64u);
    zT_165 = zig_overflow_flag_shl_u(((zu64)(zT_160)), ((zu64)(zT_161)), 64u);
    zT_167 = zT_165 == (unsigned int)(0);
    if (!(zT_167)) { pal_trap(); }
    zT_169 = zT_162 | (zT_79FAE712_u64)((zT_79FAE712_u64)cand_id);
    done_key = zT_169;
    zT_170 = taken;
    zT_171 = done_key;
    zF_B6EB812C_u64ToU32MapPut(zT_170, zT_171, (unsigned int)(1));
    zT_174 = self->interner;
    zT_175 = cand_id;
    zT_177 = zF_9134020D_stringInternerGet(zT_174, zT_175);
    return zT_177;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_58 = 1;
    zT_59 = zig_wrap_add_u(((zu64)(counter)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(counter)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    counter = zT_59;
    zT_64 = self->interner;
    zT_65 = cand_id;
    zT_67 = zF_9134020D_stringInternerGet(zT_64, zT_65);
    cand = zT_67;
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_69[_i];
        _i++;
    }
}
    zT_71 = 0;
    p = zT_71;
    zT_73 = 0;
    ci = zT_73;
    goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    zT_75 = cand.len;
    if ((unsigned char)(ci < zT_75)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_80 = cand.ptr;
    zT_81 = cand.len;
    zT_82 = ci < zT_81;
    if (!(zT_82)) { pal_trap(); }
    zT_83 = zT_80[ci];
    zT_85 = p < (unsigned int)(128);
    if (!(zT_85)) { pal_trap(); }
    buf[p] = zT_83;
    zT_86 = 1;
    zT_87 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_86)), 32u);
    zT_88 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_86)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    p = zT_87;
    goto z_bb_15;
    z_bb_14:
    zT_96 = 95;
    zT_98 = p < (unsigned int)(128);
    if (!(zT_98)) { pal_trap(); }
    buf[p] = zT_96;
    zT_99 = 1;
    zT_100 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_99)), 32u);
    zT_101 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_99)), 32u);
    zT_103 = zT_101 == (unsigned int)(0);
    if (!(zT_103)) { pal_trap(); }
    p = zT_100;
    zig_poison_fill((void*)&zT_105, (unsigned int)sizeof zT_105);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_105[_i];
        _i++;
    }
}
    zT_107 = counter;
    zT_111 = 0;
    zT_112 = (unsigned char*)((unsigned char*)db) + zT_111;
    zT_113 = (unsigned int)(16) - zT_111;
    zT_114.ptr = (unsigned char*)zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zT_115 = zF_A7504564_itoa(zT_107, zT_108);
    dl = zT_115;
    zT_117 = 15;
    zT_118 = (unsigned int)dl;
    zT_119 = zig_wrap_sub_u(((zu64)(zT_117)), ((zu64)(zT_118)), 32u);
    zT_120 = zig_overflow_flag_sub_u(((zu64)(zT_117)), ((zu64)(zT_118)), 32u);
    zT_122 = zT_120 == (unsigned int)(0);
    if (!(zT_122)) { pal_trap(); }
    ds = zT_119;
    di = ds;
    goto z_bb_19;
    z_bb_15:
    zT_91 = 1;
    zT_92 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    ci = zT_92;
    goto z_bb_12;
    z_bb_16:
    zT_77 = p < (unsigned int)(118);
    goto z_bb_18;
    z_bb_17:
    zT_77 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_77) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    if ((unsigned char)(di < (unsigned int)(15))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_130 = di < (unsigned int)(16);
    if (!(zT_130)) { pal_trap(); }
    zT_131 = db[di];
    zT_133 = p < (unsigned int)(128);
    if (!(zT_133)) { pal_trap(); }
    buf[p] = zT_131;
    zT_134 = 1;
    zT_135 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_134)), 32u);
    zT_136 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_134)), 32u);
    zT_138 = zT_136 == (unsigned int)(0);
    if (!(zT_138)) { pal_trap(); }
    p = zT_135;
    goto z_bb_22;
    z_bb_21:
    zT_144 = self->interner;
    zT_149 = 0;
    zT_150 = (unsigned char*)((unsigned char*)buf) + zT_149;
    zT_151 = p - zT_149;
    zT_152 = (unsigned int)zT_149 <= p;
    if (!(zT_152)) { pal_trap(); }
    zT_153 = p <= (unsigned int)(128);
    if (!(zT_153)) { pal_trap(); }
    zT_154.ptr = (unsigned char*)zT_150;
    zT_154.len = zT_151;
    zT_145 = zT_154;
    zT_155 = zF_50C274AF_stringInternerInter(zT_144, zT_145);
    cand_id = zT_155;
    goto z_bb_10;
    z_bb_22:
    zT_139 = 1;
    zT_140 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_139)), 32u);
    zT_141 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_139)), 32u);
    zT_143 = zT_141 == (unsigned int)(0);
    if (!(zT_143)) { pal_trap(); }
    di = zT_140;
    goto z_bb_19;
    z_bb_23:
    zT_126 = p < (unsigned int)(127);
    goto z_bb_25;
    z_bb_24:
    zT_126 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_126) goto z_bb_20; else goto z_bb_21;
}

/* nameManglerMintLocal */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8D2701C5_nameManglerMintLoca(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_local;
    zT_7 = &self->raw_taken_local;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerMintField */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_455DE5CA_nameManglerMintFiel(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_field;
    zT_7 = &self->raw_taken_field;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerMintMember */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_5EF2DC48_nameManglerMintMemb(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_member;
    zT_7 = &self->raw_taken_member;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerFnScope */
unsigned int zF_79CB4DDA_nameManglerFnScope(zT_CEC2984A_NameMangler* self, unsigned int fn_name_id, unsigned int fn_module_id) {
    zT_4428DEE2_Arr_unsigned_char_2 zT_4;
    unsigned int zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned char zT_34;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned char zT_47;
    unsigned char zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    int zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned char zT_74;
    unsigned char zT_78;
    unsigned char zT_79;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    zT_D3EB6303_StringInterner* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zT_4428DEE2_Arr_unsigned_char_2 buf;
    unsigned int p;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int i;
    unsigned int dl2;
    unsigned int ds2;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    {
    unsigned int _i = 0;
    while (_i < 24) {
        buf[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    p = zT_6;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = fn_module_id;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)db) + zT_14;
    zT_16 = (unsigned int)(16) - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A7504564_itoa(zT_10, zT_11);
    dl = zT_18;
    zT_20 = 15;
    zT_21 = (unsigned int)dl;
    zT_22 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    ds = zT_22;
    i = ds;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(15))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_33 = i < (unsigned int)(16);
    if (!(zT_33)) { pal_trap(); }
    zT_34 = db[i];
    zT_36 = p < (unsigned int)(24);
    if (!(zT_36)) { pal_trap(); }
    buf[p] = zT_34;
    zT_37 = 1;
    zT_38 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    p = zT_38;
    goto z_bb_4;
    z_bb_3:
    zT_47 = 95;
    zT_49 = p < (unsigned int)(24);
    if (!(zT_49)) { pal_trap(); }
    buf[p] = zT_47;
    zT_50 = 1;
    zT_51 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    p = zT_51;
    zT_56 = fn_name_id;
    zT_60 = 0;
    zT_61 = (unsigned char*)((unsigned char*)db) + zT_60;
    zT_62 = (unsigned int)(16) - zT_60;
    zT_63.ptr = (unsigned char*)zT_61;
    zT_63.len = zT_62;
    zT_57 = zT_63;
    zT_64 = zF_A7504564_itoa(zT_56, zT_57);
    dl2 = zT_64;
    zT_66 = 15;
    zT_67 = (unsigned int)dl2;
    zT_68 = zig_wrap_sub_u(((zu64)(zT_66)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_sub_u(((zu64)(zT_66)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    ds2 = zT_68;
    i = ds2;
    goto z_bb_8;
    z_bb_4:
    zT_42 = 1;
    zT_43 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    i = zT_43;
    goto z_bb_1;
    z_bb_5:
    zT_29 = p < (unsigned int)(10);
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    if ((unsigned char)(i < (unsigned int)(15))) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_78 = i < (unsigned int)(16);
    if (!(zT_78)) { pal_trap(); }
    zT_79 = db[i];
    zT_81 = p < (unsigned int)(24);
    if (!(zT_81)) { pal_trap(); }
    buf[p] = zT_79;
    zT_82 = 1;
    zT_83 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    p = zT_83;
    goto z_bb_11;
    z_bb_10:
    zT_92 = self->interner;
    zT_97 = 0;
    zT_98 = (unsigned char*)((unsigned char*)buf) + zT_97;
    zT_99 = p - zT_97;
    zT_100 = (unsigned int)zT_97 <= p;
    if (!(zT_100)) { pal_trap(); }
    zT_101 = p <= (unsigned int)(24);
    if (!(zT_101)) { pal_trap(); }
    zT_102.ptr = (unsigned char*)zT_98;
    zT_102.len = zT_99;
    zT_93 = zT_102;
    zT_103 = zF_50C274AF_stringInternerInter(zT_92, zT_93);
    return zT_103;
    z_bb_11:
    zT_87 = 1;
    zT_88 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    i = zT_88;
    goto z_bb_8;
    z_bb_12:
    zT_74 = p < (unsigned int)(23);
    goto z_bb_14;
    z_bb_13:
    zT_74 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_74) goto z_bb_9; else goto z_bb_10;
}

/* nameManglerMintTemp */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_918A053C_nameManglerMintTemp(zT_CEC2984A_NameMangler* self, unsigned int temp_id) {
    zT_4028D896_Arr_unsigned_char_2 zT_3;
    unsigned char zT_4;
    int zT_5;
    unsigned char zT_7;
    unsigned char zT_8;
    int zT_9;
    unsigned char zT_11;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    int zT_69;
    unsigned char* zT_70;
    unsigned int zT_71;
    unsigned char zT_72;
    unsigned char zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_D3EB6303_StringInterner* zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zT_4028D896_Arr_unsigned_char_2 buf;
    unsigned int len;
    unsigned int dig_start;
    unsigned int di;
    unsigned int i;
    unsigned int end;
    unsigned int mid;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 122;
    zT_5 = 0;
    zT_7 = (unsigned int)zT_5 < (unsigned int)(20);
    if (!(zT_7)) { pal_trap(); }
    buf[zT_5] = zT_4;
    zT_8 = 84;
    zT_9 = 1;
    zT_11 = (unsigned int)zT_9 < (unsigned int)(20);
    if (!(zT_11)) { pal_trap(); }
    buf[zT_9] = zT_8;
    zT_12 = 95;
    zT_13 = 2;
    zT_15 = (unsigned int)zT_13 < (unsigned int)(20);
    if (!(zT_15)) { pal_trap(); }
    buf[zT_13] = zT_12;
    zT_17 = temp_id;
    zT_21 = 3;
    zT_22 = (unsigned char*)((unsigned char*)buf) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = (unsigned char*)zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    len = zT_25;
    zT_27 = 19;
    zT_28 = (unsigned int)len;
    zT_29 = zig_wrap_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    dig_start = zT_29;
    zT_34 = 3;
    di = zT_34;
    zT_36 = 0;
    i = zT_36;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)len))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_39 = zig_wrap_add_u(((zu64)(dig_start)), ((zu64)(i)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(dig_start)), ((zu64)(i)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_44 = zT_39 < (unsigned int)(20);
    if (!(zT_44)) { pal_trap(); }
    zT_45 = buf[zT_39];
    zT_46 = zig_wrap_add_u(((zu64)(di)), ((zu64)(i)), 32u);
    zT_47 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(i)), 32u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    zT_51 = zT_46 < (unsigned int)(20);
    if (!(zT_51)) { pal_trap(); }
    buf[zT_46] = zT_45;
    goto z_bb_4;
    z_bb_3:
    zT_58 = (unsigned int)len;
    zT_59 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    end = zT_59;
    zT_64 = self->interner;
    zT_69 = 0;
    zT_70 = (unsigned char*)((unsigned char*)buf) + zT_69;
    zT_71 = end - zT_69;
    zT_72 = (unsigned int)zT_69 <= end;
    if (!(zT_72)) { pal_trap(); }
    zT_73 = end <= (unsigned int)(20);
    if (!(zT_73)) { pal_trap(); }
    zT_74.ptr = (unsigned char*)zT_70;
    zT_74.len = zT_71;
    zT_65 = zT_74;
    zT_75 = zF_50C274AF_stringInternerInter(zT_64, zT_65);
    mid = zT_75;
    zT_76 = self->interner;
    zT_77 = mid;
    zT_79 = zF_9134020D_stringInternerGet(zT_76, zT_77);
    return zT_79;
    z_bb_4:
    zT_52 = 1;
    zT_53 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    i = zT_53;
    goto z_bb_1;
}

/* nameManglerMintSyntheticType */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9DABAED9_nameManglerMintSynt(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_8F083A69_Slice_zT_0B42B2F8_u elem_name, zT_8F083A69_Slice_zT_0B42B2F8_u len_text, unsigned int cap) {
    zT_C4003E6D_Arr_unsigned_char_1 zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned char* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned char zT_42;
    unsigned char zT_45;
    unsigned char zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned int zT_62;
    unsigned int zT_66;
    unsigned char zT_69;
    unsigned char zT_71;
    unsigned char zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    unsigned int zT_79;
    unsigned int zT_81;
    unsigned char zT_83;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    unsigned char zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    zT_D3EB6303_StringInterner* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    int zT_107;
    unsigned char* zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    unsigned char zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_CEC2984A_NameMangler* zT_115;
    unsigned int zT_116;
    unsigned int zT_121;
    zT_D3EB6303_StringInterner* zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int p;
    unsigned int i;
    unsigned char c;
    unsigned int nid;
    unsigned int mid;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_6[_i];
        _i++;
    }
}
    zT_8 = 0;
    p = zT_8;
    zT_10 = 0;
    i = zT_10;
    goto z_bb_1;
    z_bb_1:
    zT_12 = prefix.len;
    if ((unsigned char)(i < zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_16 = prefix.ptr;
    zT_17 = prefix.len;
    zT_18 = i < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[i];
    zT_21 = p < (unsigned int)(128);
    if (!(zT_21)) { pal_trap(); }
    buf[p] = zT_19;
    zT_22 = 1;
    zT_23 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    p = zT_23;
    goto z_bb_4;
    z_bb_3:
    zT_32 = 0;
    i = zT_32;
    goto z_bb_8;
    z_bb_4:
    zT_27 = 1;
    zT_28 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_14 = p < cap;
    goto z_bb_7;
    z_bb_6:
    zT_14 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_14) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_34 = elem_name.len;
    if ((unsigned char)(i < zT_34)) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_39 = elem_name.ptr;
    zT_40 = elem_name.len;
    zT_41 = i < zT_40;
    if (!(zT_41)) { pal_trap(); }
    zT_42 = zT_39[i];
    c = zT_42;
    if ((unsigned char)(c == (unsigned char)(32))) goto z_bb_16; else goto z_bb_15;
    z_bb_10:
    zT_62 = len_text.len;
    if ((unsigned char)(zT_62 > (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_11:
    zT_56 = 1;
    zT_57 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    i = zT_57;
    goto z_bb_8;
    z_bb_12:
    zT_36 = p < cap;
    goto z_bb_14;
    z_bb_13:
    zT_36 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_36) goto z_bb_9; else goto z_bb_10;
    z_bb_15:
    zT_45 = c == (unsigned char)(42);
    goto z_bb_17;
    z_bb_16:
    zT_45 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_45) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_48 = 95;
    c = zT_48;
    goto z_bb_19;
    z_bb_19:
    zT_50 = p < (unsigned int)(128);
    if (!(zT_50)) { pal_trap(); }
    buf[p] = c;
    zT_51 = 1;
    zT_52 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    p = zT_52;
    goto z_bb_11;
    z_bb_20:
    zT_66 = elem_name.len;
    if ((unsigned char)(zT_66 > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_102 = self->interner;
    zT_107 = 0;
    zT_108 = (unsigned char*)((unsigned char*)buf) + zT_107;
    zT_109 = p - zT_107;
    zT_110 = (unsigned int)zT_107 <= p;
    if (!(zT_110)) { pal_trap(); }
    zT_111 = p <= (unsigned int)(128);
    if (!(zT_111)) { pal_trap(); }
    zT_112.ptr = (unsigned char*)zT_108;
    zT_112.len = zT_109;
    zT_103 = zT_112;
    zT_113 = zF_50C274AF_stringInternerInter(zT_102, zT_103);
    nid = zT_113;
    zT_115 = self;
    zT_116 = nid;
    zT_121 = zF_713D1938_nameManglerMangle(zT_115, zT_116, (unsigned char)(2), (unsigned int)(0));
    mid = zT_121;
    zT_122 = self->interner;
    zT_123 = mid;
    zT_125 = zF_9134020D_stringInternerGet(zT_122, zT_123);
    return zT_125;
    z_bb_22:
    zT_69 = p < cap;
    goto z_bb_24;
    z_bb_23:
    zT_69 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_69) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_71 = 95;
    zT_73 = p < (unsigned int)(128);
    if (!(zT_73)) { pal_trap(); }
    buf[p] = zT_71;
    zT_74 = 1;
    zT_75 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    p = zT_75;
    goto z_bb_26;
    z_bb_26:
    zT_79 = 0;
    i = zT_79;
    goto z_bb_27;
    z_bb_27:
    zT_81 = len_text.len;
    if ((unsigned char)(i < zT_81)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_85 = len_text.ptr;
    zT_86 = len_text.len;
    zT_87 = i < zT_86;
    if (!(zT_87)) { pal_trap(); }
    zT_88 = zT_85[i];
    zT_90 = p < (unsigned int)(128);
    if (!(zT_90)) { pal_trap(); }
    buf[p] = zT_88;
    zT_91 = 1;
    zT_92 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    p = zT_92;
    goto z_bb_30;
    z_bb_29:
    goto z_bb_21;
    z_bb_30:
    zT_96 = 1;
    zT_97 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    i = zT_97;
    goto z_bb_27;
    z_bb_31:
    zT_83 = p < cap;
    goto z_bb_33;
    z_bb_32:
    zT_83 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_83) goto z_bb_28; else goto z_bb_29;
}

/* nameManglerMintIndexName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C486DB29_nameManglerMintInde(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int n) {
    zT_C41F1B06_Arr_unsigned_char_6 zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned char* zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_5426B97B_Arr_unsigned_char_1 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_53;
    unsigned char zT_57;
    unsigned char zT_58;
    unsigned char zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    zT_D3EB6303_StringInterner* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    int zT_77;
    unsigned char* zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    unsigned char zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_D3EB6303_StringInterner* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zT_C41F1B06_Arr_unsigned_char_6 buf;
    unsigned int p;
    unsigned int i;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int j;
    unsigned int nid;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    p = zT_6;
    zT_8 = 0;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_10 = prefix.len;
    if ((unsigned char)(i < zT_10)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = prefix.ptr;
    zT_16 = prefix.len;
    zT_17 = i < zT_16;
    if (!(zT_17)) { pal_trap(); }
    zT_18 = zT_15[i];
    zT_20 = p < (unsigned int)(64);
    if (!(zT_20)) { pal_trap(); }
    buf[p] = zT_18;
    zT_21 = 1;
    zT_22 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    p = zT_22;
    goto z_bb_4;
    z_bb_3:
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = n;
    zT_38 = 0;
    zT_39 = (unsigned char*)((unsigned char*)db) + zT_38;
    zT_40 = (unsigned int)(16) - zT_38;
    zT_41.ptr = (unsigned char*)zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zT_42 = zF_A7504564_itoa(zT_34, zT_35);
    dl = zT_42;
    zT_44 = 15;
    zT_45 = (unsigned int)dl;
    zT_46 = zig_wrap_sub_u(((zu64)(zT_44)), ((zu64)(zT_45)), 32u);
    zT_47 = zig_overflow_flag_sub_u(((zu64)(zT_44)), ((zu64)(zT_45)), 32u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    ds = zT_46;
    j = ds;
    goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    goto z_bb_1;
    z_bb_5:
    zT_12 = p < (unsigned int)(63);
    goto z_bb_7;
    z_bb_6:
    zT_12 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_12) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    if ((unsigned char)(j < (unsigned int)(15))) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_57 = j < (unsigned int)(16);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = db[j];
    zT_60 = p < (unsigned int)(64);
    if (!(zT_60)) { pal_trap(); }
    buf[p] = zT_58;
    zT_61 = 1;
    zT_62 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_61)), 32u);
    zT_63 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_61)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    p = zT_62;
    goto z_bb_11;
    z_bb_10:
    zT_72 = self->interner;
    zT_77 = 0;
    zT_78 = (unsigned char*)((unsigned char*)buf) + zT_77;
    zT_79 = p - zT_77;
    zT_80 = (unsigned int)zT_77 <= p;
    if (!(zT_80)) { pal_trap(); }
    zT_81 = p <= (unsigned int)(64);
    if (!(zT_81)) { pal_trap(); }
    zT_82.ptr = (unsigned char*)zT_78;
    zT_82.len = zT_79;
    zT_73 = zT_82;
    zT_83 = zF_50C274AF_stringInternerInter(zT_72, zT_73);
    nid = zT_83;
    zT_84 = self->interner;
    zT_85 = nid;
    zT_87 = zF_9134020D_stringInternerGet(zT_84, zT_85);
    return zT_87;
    z_bb_11:
    zT_66 = 1;
    zT_67 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    j = zT_67;
    goto z_bb_8;
    z_bb_12:
    zT_53 = p < (unsigned int)(63);
    goto z_bb_14;
    z_bb_13:
    zT_53 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_53) goto z_bb_9; else goto z_bb_10;
}

/* nameManglerMintModuleStem */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C4A5232F_nameManglerMintModu(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u path_str) {
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    unsigned char zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_44;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    unsigned char zT_56;
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned char zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned int zT_78;
    unsigned char zT_79;
    unsigned char zT_80;
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned char zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    unsigned char zT_92;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned char* zT_101;
    unsigned int zT_102;
    int zT_103;
    unsigned char* zT_104;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned char zT_117;
    unsigned int zT_118;
    unsigned char zT_119;
    unsigned char zT_120;
    unsigned char zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    unsigned int zT_130;
    unsigned char zT_131;
    unsigned char zT_132;
    unsigned char zT_135;
    unsigned char* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    unsigned int zT_142;
    unsigned char zT_143;
    unsigned char zT_144;
    unsigned char zT_147;
    unsigned char* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_153;
    unsigned int zT_154;
    unsigned char zT_155;
    unsigned char zT_156;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned char zT_164;
    unsigned char* zT_165;
    unsigned int zT_166;
    int zT_167;
    unsigned char* zT_168;
    unsigned int zT_169;
    unsigned char zT_170;
    unsigned char zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_174;
    unsigned char* zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    unsigned char zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_443A2803_Arr_unsigned_char_9 zT_189;
    unsigned int zT_191;
    unsigned int zT_193;
    unsigned int zT_195;
    unsigned char* zT_197;
    unsigned int zT_198;
    unsigned char zT_199;
    unsigned char zT_200;
    unsigned char zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_212;
    unsigned char zT_213;
    unsigned char zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned char zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int* zT_222;
    unsigned int zT_223;
    int zT_226;
    unsigned char* zT_227;
    unsigned int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    zT_D3EB6303_StringInterner* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    int zT_237;
    unsigned char* zT_238;
    unsigned int zT_239;
    unsigned char zT_240;
    unsigned char zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_D3EB6303_StringInterner* zT_244;
    unsigned int zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zig_poison_fill((void*)&zT_187, (unsigned int)sizeof zT_187);
    zig_poison_fill((void*)&zT_243, (unsigned int)sizeof zT_243);
    zig_poison_fill((void*)&zT_247, (unsigned int)sizeof zT_247);
    unsigned int last_slash;
    unsigned char has_slash;
    unsigned int ps_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    unsigned int dbl_start;
    unsigned int bl;
    unsigned int bl4;
    unsigned int hash;
    zT_443A2803_Arr_unsigned_char_9 buf;
    unsigned int pos;
    unsigned int bi;
    unsigned int qid;
    zT_3 = 0;
    last_slash = zT_3;
    zT_5 = 0;
    has_slash = zT_5;
    zT_7 = 0;
    ps_i = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = path_str.len;
    if ((unsigned char)(ps_i < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = path_str.ptr;
    zT_12 = path_str.len;
    zT_13 = ps_i < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[ps_i];
    if ((unsigned char)(zT_14 == (unsigned char)(47))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    base = zT_24;
    if ((unsigned char)(has_slash != (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_4:
    zT_18 = 1;
    zT_19 = zig_wrap_add_u(((zu64)(ps_i)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(ps_i)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    ps_i = zT_19;
    goto z_bb_1;
    z_bb_5:
    last_slash = ps_i;
    zT_17 = 1;
    has_slash = zT_17;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_28 = 1;
    zT_29 = zig_wrap_add_u(((zu64)(last_slash)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(last_slash)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    dbl_start = zT_29;
    zT_33 = path_str.ptr;
    zT_34 = path_str.len;
    zT_36 = path_str.len;
    zT_37 = zT_33 + dbl_start;
    zT_38 = zT_36 - dbl_start;
    zT_39 = dbl_start <= zT_36;
    if (!(zT_39)) { pal_trap(); }
    zT_40 = zT_36 <= zT_34;
    if (!(zT_40)) { pal_trap(); }
    zT_41.ptr = (unsigned char*)zT_37;
    zT_41.len = zT_38;
    base = zT_41;
    goto z_bb_8;
    z_bb_8:
    zT_44 = base.len;
    bl = zT_44;
    if ((unsigned char)(bl >= (unsigned int)(4))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    base = path_str;
    goto z_bb_8;
    z_bb_10:
    zT_48 = base.ptr;
    zT_49 = 4;
    zT_50 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = base.len;
    zT_55 = zT_50 < zT_54;
    if (!(zT_55)) { pal_trap(); }
    zT_56 = zT_48[zT_50];
    zT_47 = zT_56 == (unsigned char)(46);
    goto z_bb_12;
    z_bb_11:
    zT_47 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_47) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_60 = base.ptr;
    zT_61 = 3;
    zT_62 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_61)), 32u);
    zT_63 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_61)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    zT_66 = base.len;
    zT_67 = zT_62 < zT_66;
    if (!(zT_67)) { pal_trap(); }
    zT_68 = zT_60[zT_62];
    zT_59 = zT_68 == (unsigned char)(122);
    goto z_bb_15;
    z_bb_14:
    zT_59 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_59) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_72 = base.ptr;
    zT_73 = 2;
    zT_74 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_73)), 32u);
    zT_75 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_73)), 32u);
    zT_77 = zT_75 == (unsigned int)(0);
    if (!(zT_77)) { pal_trap(); }
    zT_78 = base.len;
    zT_79 = zT_74 < zT_78;
    if (!(zT_79)) { pal_trap(); }
    zT_80 = zT_72[zT_74];
    zT_71 = zT_80 == (unsigned char)(105);
    goto z_bb_18;
    z_bb_17:
    zT_71 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_71) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_84 = base.ptr;
    zT_85 = 1;
    zT_86 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_85)), 32u);
    zT_87 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_85)), 32u);
    zT_89 = zT_87 == (unsigned int)(0);
    if (!(zT_89)) { pal_trap(); }
    zT_90 = base.len;
    zT_91 = zT_86 < zT_90;
    if (!(zT_91)) { pal_trap(); }
    zT_92 = zT_84[zT_86];
    zT_83 = zT_92 == (unsigned char)(103);
    goto z_bb_21;
    z_bb_20:
    zT_83 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_83) goto z_bb_22; else goto z_bb_24;
    z_bb_22:
    zT_96 = 4;
    zT_97 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    bl4 = zT_97;
    zT_101 = base.ptr;
    zT_102 = base.len;
    zT_103 = 0;
    zT_104 = zT_101 + zT_103;
    zT_105 = bl4 - zT_103;
    zT_106 = (unsigned int)zT_103 <= bl4;
    if (!(zT_106)) { pal_trap(); }
    zT_107 = bl4 <= zT_102;
    if (!(zT_107)) { pal_trap(); }
    zT_108.ptr = (unsigned char*)zT_104;
    zT_108.len = zT_105;
    base = zT_108;
    goto z_bb_23;
    z_bb_23:
    zT_174 = base.len;
    bl = zT_174;
    if ((unsigned char)(bl > (unsigned int)(64))) goto z_bb_39; else goto z_bb_40;
    z_bb_24:
    if ((unsigned char)(bl >= (unsigned int)(4))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_112 = base.ptr;
    zT_113 = 4;
    zT_114 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_113)), 32u);
    zT_115 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_113)), 32u);
    zT_117 = zT_115 == (unsigned int)(0);
    if (!(zT_117)) { pal_trap(); }
    zT_118 = base.len;
    zT_119 = zT_114 < zT_118;
    if (!(zT_119)) { pal_trap(); }
    zT_120 = zT_112[zT_114];
    zT_111 = zT_120 == (unsigned char)(46);
    goto z_bb_27;
    z_bb_26:
    zT_111 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_111) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_124 = base.ptr;
    zT_125 = 3;
    zT_126 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    zT_130 = base.len;
    zT_131 = zT_126 < zT_130;
    if (!(zT_131)) { pal_trap(); }
    zT_132 = zT_124[zT_126];
    zT_123 = zT_132 == (unsigned char)(122);
    goto z_bb_30;
    z_bb_29:
    zT_123 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_123) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_136 = base.ptr;
    zT_137 = 2;
    zT_138 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_137)), 32u);
    zT_139 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_137)), 32u);
    zT_141 = zT_139 == (unsigned int)(0);
    if (!(zT_141)) { pal_trap(); }
    zT_142 = base.len;
    zT_143 = zT_138 < zT_142;
    if (!(zT_143)) { pal_trap(); }
    zT_144 = zT_136[zT_138];
    zT_135 = zT_144 == (unsigned char)(57);
    goto z_bb_33;
    z_bb_32:
    zT_135 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_135) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_148 = base.ptr;
    zT_149 = 1;
    zT_150 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_149)), 32u);
    zT_151 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_149)), 32u);
    zT_153 = zT_151 == (unsigned int)(0);
    if (!(zT_153)) { pal_trap(); }
    zT_154 = base.len;
    zT_155 = zT_150 < zT_154;
    if (!(zT_155)) { pal_trap(); }
    zT_156 = zT_148[zT_150];
    zT_147 = zT_156 == (unsigned char)(56);
    goto z_bb_36;
    z_bb_35:
    zT_147 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_147) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_160 = 4;
    zT_161 = zig_wrap_sub_u(((zu64)(bl)), ((zu64)(zT_160)), 32u);
    zT_162 = zig_overflow_flag_sub_u(((zu64)(bl)), ((zu64)(zT_160)), 32u);
    zT_164 = zT_162 == (unsigned int)(0);
    if (!(zT_164)) { pal_trap(); }
    bl4 = zT_161;
    zT_165 = base.ptr;
    zT_166 = base.len;
    zT_167 = 0;
    zT_168 = zT_165 + zT_167;
    zT_169 = bl4 - zT_167;
    zT_170 = (unsigned int)zT_167 <= bl4;
    if (!(zT_170)) { pal_trap(); }
    zT_171 = bl4 <= zT_166;
    if (!(zT_171)) { pal_trap(); }
    zT_172.ptr = (unsigned char*)zT_168;
    zT_172.len = zT_169;
    base = zT_172;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_23;
    z_bb_39:
    zT_177 = base.ptr;
    zT_178 = base.len;
    zT_179 = 64;
    zT_180 = 0;
    zT_181 = zT_177 + zT_180;
    zT_182 = zT_179 - zT_180;
    zT_183 = zT_179 <= zT_178;
    if (!(zT_183)) { pal_trap(); }
    zT_184.ptr = (unsigned char*)zT_181;
    zT_184.len = zT_182;
    base = zT_184;
    goto z_bb_40;
    z_bb_40:
    zT_186 = path_str;
    zT_187 = zF_B22E025B_fnv1a(zT_186);
    hash = zT_187;
    zig_poison_fill((void*)&zT_189, (unsigned int)sizeof zT_189);
    {
    unsigned int _i = 0;
    while (_i < 96) {
        buf[_i] = zT_189[_i];
        _i++;
    }
}
    zT_191 = 0;
    pos = zT_191;
    zT_193 = 0;
    bi = zT_193;
    goto z_bb_41;
    z_bb_41:
    zT_195 = base.len;
    if ((unsigned char)(bi < zT_195)) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_197 = base.ptr;
    zT_198 = base.len;
    zT_199 = bi < zT_198;
    if (!(zT_199)) { pal_trap(); }
    zT_200 = zT_197[bi];
    zT_202 = pos < (unsigned int)(96);
    if (!(zT_202)) { pal_trap(); }
    buf[pos] = zT_200;
    zT_203 = 1;
    zT_204 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_203)), 32u);
    zT_205 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_203)), 32u);
    zT_207 = zT_205 == (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    pos = zT_204;
    goto z_bb_44;
    z_bb_43:
    zT_213 = 95;
    zT_215 = pos < (unsigned int)(96);
    if (!(zT_215)) { pal_trap(); }
    buf[pos] = zT_213;
    zT_216 = 1;
    zT_217 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_216)), 32u);
    zT_218 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_216)), 32u);
    zT_220 = zT_218 == (unsigned int)(0);
    if (!(zT_220)) { pal_trap(); }
    pos = zT_217;
    zT_226 = 0;
    zT_227 = (unsigned char*)((unsigned char*)buf) + zT_226;
    zT_228 = (unsigned int)(96) - zT_226;
    zT_229.ptr = (unsigned char*)zT_227;
    zT_229.len = zT_228;
    zT_221 = zT_229;
    zT_222 = (unsigned int*)&pos;
    zT_223 = hash;
    zF_8F8DE819_writeHex(zT_221, zT_222, zT_223);
    zT_232 = self->interner;
    zT_237 = 0;
    zT_238 = (unsigned char*)((unsigned char*)buf) + zT_237;
    zT_239 = pos - zT_237;
    zT_240 = (unsigned int)zT_237 <= pos;
    if (!(zT_240)) { pal_trap(); }
    zT_241 = pos <= (unsigned int)(96);
    if (!(zT_241)) { pal_trap(); }
    zT_242.ptr = (unsigned char*)zT_238;
    zT_242.len = zT_239;
    zT_233 = zT_242;
    zT_243 = zF_50C274AF_stringInternerInter(zT_232, zT_233);
    qid = zT_243;
    zT_244 = self->interner;
    zT_245 = qid;
    zT_247 = zF_9134020D_stringInternerGet(zT_244, zT_245);
    return zT_247;
    z_bb_44:
    zT_208 = 1;
    zT_209 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_208)), 32u);
    zT_210 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_208)), 32u);
    zT_212 = zT_210 == (unsigned int)(0);
    if (!(zT_212)) { pal_trap(); }
    bi = zT_209;
    goto z_bb_41;
}

/* EOF */
