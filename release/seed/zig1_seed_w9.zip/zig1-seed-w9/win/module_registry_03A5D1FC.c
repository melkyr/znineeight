#include "module_registry_03A5D1FC.h"
zT_072B53A6_ModuleRegistry zG_072B53A6_ModuleRegistry;
unsigned char zG_E8C23D2C_source_man_stub;
static unsigned char* const zG_1DDFFDDD_HASH_SPILL_READ_MOD = (unsigned char*)"rb";
static unsigned char* const zG_034DEF1E_HASH_SPILL_WRITE_MO = (unsigned char*)"wb";
static unsigned int const zG_0BC1A97F_HASH_SPILL_MAX_MAP_ = (unsigned int)(4000000);
/* moduleEntryArrayListInit */
zT_E41AEC18_ModuleEntryArrayLis zF_CD3AB3CA_moduleEntryArrayLis(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_E41AEC18_ModuleEntryArrayLis zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis* zT_7;
    unsigned int zT_8;
    zT_E41AEC18_ModuleEntryArrayLis list;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.items = (zT_6E8D187B_ModuleEntry*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = (zT_E41AEC18_ModuleEntryArrayLis*)&list;
    zT_8 = initial_capacity;
    zF_91E0DA42_moduleEntryArrayLis(zT_7, zT_8);
    return list;
}

/* moduleEntryArrayListEnsureCapacity */
void zF_91E0DA42_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_6E8D187B_ModuleEntry* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_6F2E32ED_Opt_259 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_81AD2998_EU_952 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    zT_6E8D187B_ModuleEntry* zT_64;
    zT_6E8D187B_ModuleEntry* zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_6E8D187B_ModuleEntry* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_71;
    zT_6E8D187B_ModuleEntry* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int new_cap;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    zT_6E8D187B_ModuleEntry* new_items;
    zT_6E8D187B_ModuleEntry item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->allocator;
    zT_32 = self->items;
    zT_34 = self->capacity;
    zT_35 = 52;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 52;
    zT_41 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->allocator;
    zT_53 = 52;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (zT_6E8D187B_ModuleEntry*)raw;
    new_items = zT_64;
    zT_65 = self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (zT_6E8D187B_ModuleEntry*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* moduleEntryArrayListAppend */
void zF_ABB1AEC0_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self, zT_6E8D187B_ModuleEntry value) {
    zT_E41AEC18_ModuleEntryArrayLis* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_6E8D187B_ModuleEntry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_91E0DA42_moduleEntryArrayLis(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* moduleEntryArrayListGetSlice */
zT_DDCD424B_Slice_zT_6E8D187B_M zF_9FE5DB1E_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self) {
    zT_6E8D187B_ModuleEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6E8D187B_ModuleEntry* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_7;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_6E8D187B_ModuleEntry*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* searchDirArrayListEnsureCapacity */
void zF_529FE8C7_searchDirArrayListE(zT_4EA49A91_SearchDirArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_6F2E32ED_Opt_259 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_81AD2998_EU_952 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned int* zT_64;
    unsigned int* zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_71;
    unsigned int* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int new_cap;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 2;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 2;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->alloc;
    zT_32 = self->items;
    zT_34 = self->capacity;
    zT_35 = 4;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 4;
    zT_41 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->alloc;
    zT_53 = 4;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (unsigned int*)raw;
    new_items = zT_64;
    zT_65 = self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (unsigned int*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* searchDirArrayListAppend */
void zF_DD10EA35_searchDirArrayListA(zT_4EA49A91_SearchDirArrayList* self, unsigned int value) {
    zT_4EA49A91_SearchDirArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_529FE8C7_searchDirArrayListE(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* joinPath */
zT_7230763D_Opt_246 zF_05C4CBC2_joinPath(zT_8F083A69_Slice_zT_0B42B2F8_u dir, zT_8F083A69_Slice_zT_0B42B2F8_u rel, zT_3E40CD83_Sand* scratch) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_19;
    zT_81AD2998_EU_952 zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    zT_7230763D_Opt_246 zT_25;
    unsigned char* zT_28;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned char* zT_35;
    unsigned int zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned char* zT_58;
    unsigned int zT_59;
    unsigned char zT_60;
    unsigned char zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    zT_7230763D_Opt_246 zT_81;
    unsigned char zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    zT_7230763D_Opt_246 zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_7230763D_Opt_246 zT_86;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    unsigned int total;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int i;
    unsigned int j;
    zT_8F083A69_Slice_zT_0B42B2F8_u full;
    zT_8F083A69_Slice_zT_0B42B2F8_u norm;
    zT_5 = dir.len;
    zT_6 = 1;
    zT_7 = zig_wrap_add_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_add_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    zT_12 = rel.len;
    zT_13 = zig_wrap_add_u(((zu64)(zT_7)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_add_u(((zu64)(zT_7)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    total = zT_13;
    zT_18 = scratch;
    zT_19 = total;
    zT_22 = zF_1395EB68_sandAlloc(zT_18, zT_19, (unsigned int)(1));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_2:
    zT_24 = zT_22.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_24;
    zT_28 = (unsigned char*)raw;
    buf = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_4;
    z_bb_4:
    zT_33 = dir.len;
    if ((unsigned char)(i < zT_33)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = dir.ptr;
    zT_36 = dir.len;
    zT_37 = i < zT_36;
    if (!(zT_37)) { pal_trap(); }
    zT_38 = zT_35[i];
    buf[i] = zT_38;
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    zT_41 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    i = zT_41;
    goto z_bb_7;
    z_bb_6:
    zT_45 = 47;
    buf[i] = zT_45;
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    i = zT_48;
    zT_53 = 0;
    zT_54 = (unsigned int)zT_53;
    j = zT_54;
    goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_56 = rel.len;
    if ((unsigned char)(j < zT_56)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_58 = rel.ptr;
    zT_59 = rel.len;
    zT_60 = j < zT_59;
    if (!(zT_60)) { pal_trap(); }
    zT_61 = zT_58[j];
    zT_62 = zig_wrap_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_63 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(j)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    buf[zT_62] = zT_61;
    zT_66 = 1;
    zT_67 = (unsigned int)zT_66;
    zT_68 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    j = zT_68;
    goto z_bb_11;
    z_bb_10:
    zT_73 = 0;
    zT_74 = buf + zT_73;
    zT_75 = total - zT_73;
    zT_76 = (unsigned int)zT_73 <= total;
    if (!(zT_76)) { pal_trap(); }
    zT_77.ptr = (unsigned char*)zT_74;
    zT_77.len = zT_75;
    full = zT_77;
    zT_79 = full;
    zT_80 = full;
    zT_81 = zF_36F0DB6B_normalizePath(zT_79, zT_80);
    zT_82 = zT_81.has_value;
    if (zT_82) goto z_bb_13; else goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_84.has_value = 1;
    zT_84.value = full;
    return zT_84;
    z_bb_13:
    if (!(zT_81.has_value)) { pal_trap(); }
    zT_85 = zT_81.value;
    zT_83 = zT_85;
    goto z_bb_14;
    z_bb_14:
    norm = zT_83;
    zT_86.has_value = 1;
    zT_86.value = norm;
    return zT_86;
}

/* moduleDirPath */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_75D2520B_moduleDirPath(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    unsigned int zT_3;
    int zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_3 = path.len;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    if ((unsigned char)(i > (unsigned int)zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    i = zT_8;
    zT_12 = path.ptr;
    zT_13 = path.len;
    zT_14 = i < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    if ((unsigned char)(zT_15 == (unsigned char)(47))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_27 = "";
    zT_29 = 0;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    empty_str = zT_28;
    return empty_str;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = path.ptr;
    zT_19 = path.len;
    zT_20 = 0;
    zT_21 = zT_18 + zT_20;
    zT_22 = i - zT_20;
    zT_23 = (unsigned int)zT_20 <= i;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = i <= zT_19;
    if (!(zT_24)) { pal_trap(); }
    zT_25.ptr = (unsigned char*)zT_21;
    zT_25.len = zT_22;
    return zT_25;
    z_bb_6:
    goto z_bb_4;
}

/* appendZigExt */
zT_85DA580C_Opt_476 zF_64D8041C_appendZigExt(zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_81AD2998_EU_952 zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    zT_85DA580C_Opt_476 zT_18;
    unsigned char* zT_21;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned char* zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned char zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned char zT_52;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned char zT_59;
    int zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_85DA580C_Opt_476 zT_65;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned int total;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int i;
    zT_4 = target.len;
    zT_5 = 4;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    total = zT_6;
    zT_11 = scratch;
    zT_12 = total;
    zT_15 = zF_1395EB68_sandAlloc(zT_11, zT_12, (unsigned int)(1));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18.has_value = 0;
    return zT_18;
    z_bb_2:
    zT_17 = zT_15.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_17;
    zT_21 = (unsigned char*)raw;
    buf = zT_21;
    zT_23 = 0;
    zT_24 = (unsigned int)zT_23;
    i = zT_24;
    goto z_bb_4;
    z_bb_4:
    zT_26 = target.len;
    if ((unsigned char)(i < zT_26)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_28 = target.ptr;
    zT_29 = target.len;
    zT_30 = i < zT_29;
    if (!(zT_30)) { pal_trap(); }
    zT_31 = zT_28[i];
    buf[i] = zT_31;
    zT_32 = 1;
    zT_33 = (unsigned int)zT_32;
    zT_34 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    i = zT_34;
    goto z_bb_7;
    z_bb_6:
    zT_38 = 46;
    buf[i] = zT_38;
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    zT_41 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    i = zT_41;
    zT_45 = 122;
    buf[i] = zT_45;
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    i = zT_48;
    zT_52 = 105;
    buf[i] = zT_52;
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    i = zT_55;
    zT_59 = 103;
    buf[i] = zT_59;
    zT_60 = 0;
    zT_61 = buf + zT_60;
    zT_62 = total - zT_60;
    zT_63 = (unsigned int)zT_60 <= total;
    if (!(zT_63)) { pal_trap(); }
    zT_64.ptr = (unsigned char*)zT_61;
    zT_64.len = zT_62;
    zT_65.has_value = 1;
    zT_65.value = zT_64;
    return zT_65;
    z_bb_7:
    goto z_bb_4;
}

/* moduleResolverTryDir */
zT_BAEE192E_Opt_10 zF_25488423_moduleResolverTryDi(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u dir, zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_3E40CD83_Sand* zT_7;
    zT_7230763D_Opt_246 zT_8;
    unsigned char zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_BAEE192E_Opt_10 zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_18;
    zT_BAEE192E_Opt_10 zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_85DA580C_Opt_476 zT_23;
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_BAEE192E_Opt_10 zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_3E40CD83_Sand* zT_31;
    zT_7230763D_Opt_246 zT_32;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_BAEE192E_Opt_10 zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char zT_38;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_42;
    zT_BAEE192E_Opt_10 zT_43;
    zT_BAEE192E_Opt_10 zT_44;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zT_8F083A69_Slice_zT_0B42B2F8_u full;
    zT_8F083A69_Slice_zT_0B42B2F8_u tzig;
    zT_8F083A69_Slice_zT_0B42B2F8_u full2;
    zT_5 = dir;
    zT_6 = target;
    zT_7 = scratch;
    zT_8 = zF_05C4CBC2_joinPath(zT_5, zT_6, zT_7);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11.has_value = 0;
    return zT_11;
    z_bb_2:
    if (!(zT_8.has_value)) { pal_trap(); }
    zT_12 = zT_8.value;
    zT_10 = zT_12;
    goto z_bb_3;
    z_bb_3:
    full = zT_10;
    zT_13 = full;
    zT_14 = zF_852C5C93_fileExists(zT_13);
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self->interner;
    zT_16 = full;
    zT_18 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_5:
    zT_21 = target;
    zT_22 = scratch;
    zT_23 = zF_64D8041C_appendZigExt(zT_21, zT_22);
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_26.has_value = 0;
    return zT_26;
    z_bb_7:
    if (!(zT_23.has_value)) { pal_trap(); }
    zT_27 = zT_23.value;
    zT_25 = zT_27;
    goto z_bb_8;
    z_bb_8:
    tzig = zT_25;
    zT_29 = dir;
    zT_30 = tzig;
    zT_31 = scratch;
    zT_32 = zF_05C4CBC2_joinPath(zT_29, zT_30, zT_31);
    zT_33 = zT_32.has_value;
    if (zT_33) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_35.has_value = 0;
    return zT_35;
    z_bb_10:
    if (!(zT_32.has_value)) { pal_trap(); }
    zT_36 = zT_32.value;
    zT_34 = zT_36;
    goto z_bb_11;
    z_bb_11:
    full2 = zT_34;
    zT_37 = full2;
    zT_38 = zF_852C5C93_fileExists(zT_37);
    if (zT_38) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_39 = self->interner;
    zT_40 = full2;
    zT_42 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    zT_43.has_value = 1;
    zT_43.value = zT_42;
    return zT_43;
    z_bb_13:
    zT_44.has_value = 0;
    return zT_44;
}

/* moduleResolverInit */
zT_4DB1475B_ModuleResolver zF_64765145_moduleResolverInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_4DB1475B_ModuleResolver zT_3;
    zT_4EA49A91_SearchDirArrayList zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_4.items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_4.len = zT_6;
    zT_7 = 0;
    zT_4.capacity = zT_7;
    zT_4.alloc = alloc;
    zT_3.search_dirs = zT_4;
    zT_3.interner = interner;
    zT_3.diag = diag;
    return zT_3;
}

/* moduleResolverAddSearchDir */
void zF_B75A4515_moduleResolverAddSe(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u dir) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    unsigned int zT_6;
    int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_7230763D_Opt_246 zT_22;
    unsigned char zT_23;
    zT_D3EB6303_StringInterner* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_29;
    zT_4EA49A91_SearchDirArrayList* zT_30;
    unsigned int zT_31;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zT_846744CC_Arr_unsigned_char_5 buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u use_dir;
    zT_7230763D_Opt_246 norm;
    unsigned int id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    use_dir = dir;
    zT_6 = dir.len;
    zT_7 = 512;
    if ((unsigned char)(zT_6 <= (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = dir.len;
    zT_16 = 0;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19 = (unsigned int)zT_16 <= zT_15;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_15 <= (unsigned int)(512);
    if (!(zT_20)) { pal_trap(); }
    zT_21.ptr = (unsigned char*)zT_17;
    zT_21.len = zT_18;
    zT_10 = zT_21;
    zT_11 = dir;
    zT_22 = zF_36F0DB6B_normalizePath(zT_10, zT_11);
    norm = zT_22;
    zT_23 = norm.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_26 = self->interner;
    zT_27 = use_dir;
    zT_29 = zF_50C274AF_stringInternerInter(zT_26, zT_27);
    id = zT_29;
    zT_30 = &self->search_dirs;
    zT_31 = id;
    zF_DD10EA35_searchDirArrayListA(zT_30, zT_31);
    return;
    z_bb_3:
    if (!(norm.has_value)) { pal_trap(); }
    n = norm.value;
    use_dir = n;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* moduleResolverResolve */
zT_BAEE192E_Opt_10 zF_6F148E15_moduleResolverResol(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u importer_path, zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_8;
    int zT_9;
    zT_4DB1475B_ModuleResolver* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_BAEE192E_Opt_10 zT_16;
    unsigned char zT_17;
    zT_BAEE192E_Opt_10 zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_4EA49A91_SearchDirArrayList zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_27;
    unsigned int zT_28;
    zT_4EA49A91_SearchDirArrayList zT_30;
    unsigned int* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_4DB1475B_ModuleResolver* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_3E40CD83_Sand* zT_38;
    zT_BAEE192E_Opt_10 zT_39;
    unsigned char zT_40;
    zT_BAEE192E_Opt_10 zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_4DB1475B_ModuleResolver* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_3E40CD83_Sand* zT_57;
    zT_BAEE192E_Opt_10 zT_58;
    unsigned char zT_59;
    zT_BAEE192E_Opt_10 zT_61;
    zT_BAEE192E_Opt_10 zT_62;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zT_8F083A69_Slice_zT_0B42B2F8_u importer_dir;
    zT_BAEE192E_Opt_10 id;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_s;
    zT_5 = importer_path;
    zT_6 = zF_75D2520B_moduleDirPath(zT_5);
    importer_dir = zT_6;
    zT_8 = importer_dir.len;
    zT_9 = 0;
    if ((unsigned char)(zT_8 > (unsigned int)zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = importer_dir;
    zT_14 = target;
    zT_15 = scratch;
    zT_16 = zF_25488423_moduleResolverTryDi(zT_12, zT_13, zT_14, zT_15);
    id = zT_16;
    zT_17 = id.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    i = zT_22;
    goto z_bb_5;
    z_bb_3:
    if (!(id.has_value)) { pal_trap(); }
    v = id.value;
    zT_19.has_value = 1;
    zT_19.value = v;
    return zT_19;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = self->search_dirs;
    zT_24 = zT_23.len;
    if ((unsigned char)(i < zT_24)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = self->interner;
    zT_30 = self->search_dirs;
    zT_31 = zT_30.items;
    zT_28 = zT_31[i];
    zT_33 = zF_9134020D_stringInternerGet(zT_27, zT_28);
    dir = zT_33;
    zT_35 = self;
    zT_36 = dir;
    zT_37 = target;
    zT_38 = scratch;
    zT_39 = zF_25488423_moduleResolverTryDi(zT_35, zT_36, zT_37, zT_38);
    id = zT_39;
    zT_40 = id.has_value;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_50 = ".";
    zT_52 = 1;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    lib_s = zT_51;
    zT_54 = self;
    zT_55 = lib_s;
    zT_56 = target;
    zT_57 = scratch;
    zT_58 = zF_25488423_moduleResolverTryDi(zT_54, zT_55, zT_56, zT_57);
    id = zT_58;
    zT_59 = id.has_value;
    if (zT_59) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    if (!(id.has_value)) { pal_trap(); }
    v = id.value;
    zT_42.has_value = 1;
    zT_42.value = v;
    return zT_42;
    z_bb_10:
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    i = zT_45;
    goto z_bb_8;
    z_bb_11:
    if (!(id.has_value)) { pal_trap(); }
    v = id.value;
    zT_61.has_value = 1;
    zT_61.value = v;
    return zT_61;
    z_bb_12:
    zT_62.has_value = 0;
    return zT_62;
}

/* importEdgesEnsureCapacity */
void zF_11AFB41C_importEdgesEnsureCa(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int new_cap) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6F2E32ED_Opt_259 zT_48;
    unsigned char zT_49;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_81AD2998_EU_952 zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    unsigned char zT_71;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_72;
    unsigned int* zT_73;
    unsigned int zT_74;
    unsigned int zT_79;
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int nc;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_5 = *cap;
    if ((unsigned char)(new_cap <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_8 = *cap;
    zT_9 = 2;
    zT_10 = zig_wrap_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    if ((unsigned char)(nc < zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = *cap;
    zT_16 = 2;
    zT_17 = zig_wrap_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    nc = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_21 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 8;
    zT_24 = (unsigned int)zT_23;
    nc = zT_24;
    goto z_bb_6;
    z_bb_6:
    zT_25 = *cap;
    zT_26 = 0;
    if ((unsigned char)(zT_25 > (unsigned int)zT_26)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = alloc;
    zT_34 = *items;
    zT_36 = *cap;
    zT_37 = 4;
    zT_38 = zig_wrap_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_31 = zT_38;
    zT_42 = 4;
    zT_43 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_32 = zT_43;
    zT_48 = zF_33A3D4F8_sandTryReallocInPla(zT_29, (unsigned char*)((unsigned char*)zT_34), zT_31, zT_32, (unsigned int)(4));
    grown = zT_48;
    zT_49 = grown.has_value;
    if (zT_49) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_51 = alloc;
    zT_54 = 4;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(nc)), 32u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(nc)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_52 = zT_55;
    zT_60 = zF_1395EB68_sandAlloc(zT_51, zT_52, (unsigned int)(4));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_62 = zT_60.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_62;
    zT_65 = (unsigned int*)raw;
    new_items = zT_65;
    zT_66 = *items;
    zT_67 = *len;
    zT_68 = 0;
    zT_69 = zT_66 + zT_68;
    zT_70 = zT_67 - zT_68;
    zT_71 = (unsigned int)zT_68 <= zT_67;
    if (!(zT_71)) { pal_trap(); }
    zT_72.ptr = (unsigned int*)zT_69;
    zT_72.len = zT_70;
    zT_73 = zT_72.ptr;
    zT_74 = zT_72.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_74)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_73[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items;
    *cap = nc;
    return;
    z_bb_17:
    zT_79 = i + (unsigned int)(1);
    i = zT_79;
    goto z_bb_14;
}

/* importEdgesAppend */
void zF_358620BA_importEdgesAppend(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int value) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_5 = items;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = alloc;
    zT_10 = *len;
    zT_11 = 1;
    zT_12 = zig_wrap_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_9 = zT_12;
    zF_11AFB41C_importEdgesEnsureCa(zT_5, zT_6, zT_7, zT_8, zT_9);
    zT_16 = *items;
    zT_17 = *len;
    zT_16[zT_17] = value;
    zT_18 = *len;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    *len = zT_21;
    return;
}

/* moduleRegistryInit */
zT_072B53A6_ModuleRegistry zF_896FAF3C_moduleRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry zT_3;
    zT_3E40CD83_Sand* zT_4;
    int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_12;
    zT_D3EB6303_StringInterner* zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    zT_4DB1475B_ModuleResolver zT_15;
    unsigned char* zT_17;
    zT_227EDE07_SourceManager* zT_18;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_20;
    zT_21D3708C_U32ToU32Map zT_23;
    zT_3E40CD83_Sand* zT_24;
    zT_21D3708C_U32ToU32Map zT_27;
    unsigned int zT_28;
    zT_D21A8776_SpillStore zT_29;
    zT_ABD0FF08_HashMapSpillMeta zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_ABD0FF08_HashMapSpillMeta zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    zT_3E40CD83_Sand* zT_40;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    zT_47A5CDFB_ImportQueue zT_42;
    unsigned char zT_43;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zT_4 = alloc;
    zT_6 = 8;
    zT_8 = zF_CD3AB3CA_moduleEntryArrayLis(zT_4, (unsigned int)((unsigned int)zT_6));
    zT_3.modules = zT_8;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_3.import_edges_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.import_edges_len = zT_10;
    zT_11 = 0;
    zT_3.import_edges_cap = zT_11;
    zT_3.import_edges_alloc = alloc;
    zT_12 = alloc;
    zT_13 = interner;
    zT_14 = diag;
    zT_15 = zF_64765145_moduleResolverInit(zT_12, zT_13, zT_14);
    zT_3.resolver = zT_15;
    zT_3.interner = interner;
    zT_3.diag = diag;
    zT_17 = (unsigned char*)&zG_E8C23D2C_source_man_stub;
    zT_18 = (zT_227EDE07_SourceManager*)zT_17;
    zT_3.source_man = zT_18;
    zT_3.alloc = alloc;
    zT_19 = 0;
    zT_3.next_id = zT_19;
    zT_20 = alloc;
    zT_23 = zF_619D56E6_u32ToU32MapInitCap(zT_20, (unsigned int)(32));
    zT_3.path_to_id = zT_23;
    zT_24 = alloc;
    zT_27 = zF_619D56E6_u32ToU32MapInitCap(zT_24, (unsigned int)(32));
    zT_3.content_to_id = zT_27;
    zT_28 = 0;
    zT_3.hash_spill_path_len = zT_28;
    zT_29 = zF_22C79E6C_spillStoreInit();
    zT_3.spill = zT_29;
    zT_31 = 0;
    zT_30.disk_off = zT_31;
    zT_32 = 0;
    zT_30.capacity = zT_32;
    zT_33 = 0;
    zT_30.count = zT_33;
    zT_34 = 0;
    zT_30.spilled = zT_34;
    zT_3.path_to_id_spill = zT_30;
    zT_36 = 0;
    zT_35.disk_off = zT_36;
    zT_37 = 0;
    zT_35.capacity = zT_37;
    zT_38 = 0;
    zT_35.count = zT_38;
    zT_39 = 0;
    zT_35.spilled = zT_39;
    zT_3.content_to_id_spill = zT_35;
    zT_40 = alloc;
    zT_41 = diag;
    zT_42 = zF_4CF3FEA5_importQueueInit(zT_40, zT_41);
    zT_3.import_queue = zT_42;
    zT_43 = 0;
    zT_3.target_is_windows = zT_43;
    return zT_3;
}

/* moduleRegistrySetSourceMan */
void zF_BD2BF0BD_moduleRegistrySetSo(zT_072B53A6_ModuleRegistry* self, zT_227EDE07_SourceManager* sm) {
    self->source_man = sm;
    return;
}

/* moduleRegistrySetTargetIsWindows */
void zF_849BBF28_moduleRegistrySetTa(zT_072B53A6_ModuleRegistry* self, unsigned char is_windows) {
    self->target_is_windows = is_windows;
    return;
}

/* moduleRegistryAddModule */
unsigned int zF_E4DCE20D_moduleRegistryAddMo(zT_072B53A6_ModuleRegistry* self, unsigned int path_id) {
    unsigned int zT_3;
    zT_6E8D187B_ModuleEntry zT_5;
    unsigned int zT_6;
    zT_9FE1BFFE_ModuleState zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_B687BB96_U32ArrayList zT_15;
    zT_E41AEC18_ModuleEntryArrayLis* zT_16;
    zT_6E8D187B_ModuleEntry zT_17;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    unsigned int id;
    zT_6E8D187B_ModuleEntry entry;
    zT_3 = self->next_id;
    id = zT_3;
    zT_5.id = id;
    zT_5.path_id = path_id;
    zT_6 = 0;
    zT_5.source_file_id = zT_6;
    zT_7 = zT_9FE1BFFE_ModuleState_pending;
    zT_5.state = zT_7;
    zT_8 = 0;
    zT_5.ast_root = zT_8;
    zT_9 = 0;
    zT_5.import_count = zT_9;
    zT_10 = 0;
    zT_5.imports_start = zT_10;
    zT_11 = 0;
    zT_5.symbol_table = zT_11;
    zT_12 = 0;
    zT_5.type_offset = zT_12;
    zT_13 = self->alloc;
    zT_15 = zF_8E537D0C_u32ArrayListInit(zT_13);
    zT_5.c_includes = zT_15;
    entry = zT_5;
    zT_16 = &self->modules;
    zT_17 = entry;
    zF_ABB1AEC0_moduleEntryArrayLis(zT_16, zT_17);
    zT_19 = self->next_id;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(zT_19)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(zT_19)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    self->next_id = zT_22;
    return id;
}

/* moduleRegistryGetModules */
zT_DDCD424B_Slice_zT_6E8D187B_M zF_3452C137_moduleRegistryGetMo(zT_072B53A6_ModuleRegistry* self) {
    zT_E41AEC18_ModuleEntryArrayLis zT_1;
    zT_6E8D187B_ModuleEntry* zT_2;
    zT_E41AEC18_ModuleEntryArrayLis zT_3;
    unsigned int zT_4;
    int zT_5;
    zT_6E8D187B_ModuleEntry* zT_6;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_9;
    zT_1 = self->modules;
    zT_2 = zT_1.items;
    zT_3 = self->modules;
    zT_4 = zT_3.len;
    zT_5 = 0;
    zT_6 = zT_2 + zT_5;
    zT_7 = zT_4 - zT_5;
    zT_8 = (unsigned int)zT_5 <= zT_4;
    if (!(zT_8)) { pal_trap(); }
    zT_9.ptr = (zT_6E8D187B_ModuleEntry*)zT_6;
    zT_9.len = zT_7;
    return zT_9;
}

/* moduleRegistryAssertPathToIdResident */
void zF_D00A7313_moduleRegistryAsser(zT_072B53A6_ModuleRegistry* self) {
    zT_ABD0FF08_HashMapSpillMeta zT_1;
    unsigned char zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_1 = self->path_to_id_spill;
    zT_2 = zT_1.spilled;
    if ((unsigned char)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = "direct path_to_id access after spill; route through moduleRegistryPathToIdGet";
    zT_8 = 77;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    emsg = zT_7;
    zT_10 = "module_registry.zig";
    zT_12 = 19;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    ef = zT_11;
    zT_13 = emsg;
    zT_14 = ef;
    zT_16 = 331;
    zF_6D97D338_panicHandler(zT_13, zT_14, (unsigned int)((unsigned int)zT_16));
    return;
    z_bb_2:
    return;
}

/* moduleRegistryGetOrCreateModule */
unsigned int zF_AEB49EC3_moduleRegistryGetOr(zT_072B53A6_ModuleRegistry* self, unsigned int path_id) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_21D3708C_U32ToU32Map* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7;
    unsigned char zT_8;
    zT_072B53A6_ModuleRegistry* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zT_BAEE192E_Opt_10 existing;
    unsigned int id;
    unsigned int new_id;
    zT_2 = self;
    zF_D00A7313_moduleRegistryAsser(zT_2);
    zT_4 = &self->path_to_id;
    zT_5 = path_id;
    zT_7 = zF_F3EE5998_u32ToU32MapGet(zT_4, zT_5);
    existing = zT_7;
    zT_8 = existing.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(existing.has_value)) { pal_trap(); }
    id = existing.value;
    return id;
    z_bb_2:
    zT_11 = self;
    zT_12 = path_id;
    zT_13 = zF_E4DCE20D_moduleRegistryAddMo(zT_11, zT_12);
    new_id = zT_13;
    zT_14 = &self->path_to_id;
    zT_15 = path_id;
    zT_16 = new_id;
    zF_26476265_u32ToU32MapPut(zT_14, zT_15, zT_16);
    return new_id;
}

/* moduleRegistryAddImport */
void zF_F9E76704_moduleRegistryAddIm(zT_072B53A6_ModuleRegistry* self, unsigned int importer_id, unsigned int imported_id) {
    unsigned int** zT_3;
    unsigned int* zT_4;
    unsigned int* zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    zT_E41AEC18_ModuleEntryArrayLis zT_13;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_E41AEC18_ModuleEntryArrayLis zT_33;
    zT_6E8D187B_ModuleEntry* zT_34;
    zT_6E8D187B_ModuleEntry entry;
    zT_3 = &self->import_edges_items;
    zT_4 = &self->import_edges_len;
    zT_5 = &self->import_edges_cap;
    zT_6 = self->import_edges_alloc;
    zT_7 = imported_id;
    zF_358620BA_importEdgesAppend(zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_13 = self->modules;
    zT_14 = zT_13.items;
    zT_15 = zT_14[importer_id];
    entry = zT_15;
    zT_16 = entry.import_count;
    if ((unsigned char)(zT_16 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->import_edges_len;
    zT_20 = 1;
    zT_21 = zig_wrap_sub_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_sub_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    entry.imports_start = (unsigned int)((unsigned int)zT_21);
    goto z_bb_2;
    z_bb_2:
    zT_26 = entry.import_count;
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(zT_26)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_26)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    entry.import_count = zT_29;
    zT_33 = self->modules;
    zT_34 = zT_33.items;
    zT_34[importer_id] = entry;
    return;
}

/* moduleRegistryResolveImport */
zT_BAEE192E_Opt_10 zF_620E3E3B_moduleRegistryResol(zT_072B53A6_ModuleRegistry* self, unsigned int path_id, unsigned int importer_id, zT_3E40CD83_Sand* scratch) {
    zT_072B53A6_ModuleRegistry* zT_4;
    zT_D3EB6303_StringInterner* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_D3EB6303_StringInterner* zT_11;
    unsigned int zT_12;
    zT_E41AEC18_ModuleEntryArrayLis zT_14;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_4DB1475B_ModuleResolver* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_3E40CD83_Sand* zT_23;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_44;
    int zT_47;
    unsigned char zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_BAEE192E_Opt_10 zT_69;
    zT_21D3708C_U32ToU32Map* zT_72;
    unsigned int zT_73;
    zT_BAEE192E_Opt_10 zT_75;
    unsigned char zT_76;
    zT_072B53A6_ModuleRegistry* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    zT_47A5CDFB_ImportQueue* zT_81;
    unsigned int zT_82;
    zT_21D3708C_U32ToU32Map* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_BAEE192E_Opt_10 zT_88;
    zT_D3EB6303_StringInterner* zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_85DA580C_Opt_476 zT_97;
    unsigned char zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    zT_072B53A6_ModuleRegistry* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_072B53A6_ModuleRegistry* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_47A5CDFB_ImportQueue* zT_108;
    unsigned int zT_109;
    zT_21D3708C_U32ToU32Map* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_BAEE192E_Opt_10 zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_21D3708C_U32ToU32Map* zT_121;
    unsigned int zT_122;
    zT_BAEE192E_Opt_10 zT_124;
    unsigned char zT_125;
    zT_21D3708C_U32ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_072B53A6_ModuleRegistry* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    zT_47A5CDFB_ImportQueue* zT_134;
    unsigned int zT_135;
    zT_21D3708C_U32ToU32Map* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    zT_BAEE192E_Opt_10 zT_141;
    zT_072B53A6_ModuleRegistry* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_21D3708C_U32ToU32Map* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_072B53A6_ModuleRegistry* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_47A5CDFB_ImportQueue* zT_153;
    unsigned int zT_154;
    zT_21D3708C_U32ToU32Map* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_BAEE192E_Opt_10 zT_160;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zT_8F083A69_Slice_zT_0B42B2F8_u path_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u importer_path;
    unsigned int resolved_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_BAEE192E_Opt_10 by_path;
    unsigned int existing_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u resolved_path_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned int mod_id;
    unsigned int c_hash;
    zT_BAEE192E_Opt_10 by_content;
    unsigned int target_id;
    zT_4 = self;
    zF_D00A7313_moduleRegistryAsser(zT_4);
    zT_6 = self->interner;
    zT_7 = path_id;
    zT_9 = zF_9134020D_stringInternerGet(zT_6, zT_7);
    path_s = zT_9;
    zT_11 = self->interner;
    zT_14 = self->modules;
    zT_15 = zT_14.items;
    zT_16 = zT_15[importer_id];
    zT_12 = zT_16.path_id;
    zT_18 = zF_9134020D_stringInternerGet(zT_11, zT_12);
    importer_path = zT_18;
    zT_20 = &self->resolver;
    zT_21 = importer_path;
    zT_22 = path_s;
    zT_23 = scratch;
    zT_25 = zF_6F148E15_moduleResolverResol(zT_20, zT_21, zT_22, zT_23);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_30 = "could not resolve imported file '";
    zT_32 = 33;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    p1 = zT_31;
    zT_34 = "'";
    zT_36 = 1;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    p2 = zT_35;
    zT_39 = 0;
    zT_38[zT_39] = p1;
    zT_40 = 1;
    zT_38[zT_40] = path_s;
    zT_41 = 2;
    zT_38[zT_41] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_38[_i];
        _i++;
    }
}
    zT_43 = self->interner;
    zT_47 = 0;
    zT_49 = (unsigned int)zT_47 < (unsigned int)(3);
    if (!(zT_49)) { pal_trap(); }
    zT_50 = parts + zT_47;
    zT_44 = zT_50;
    zT_52 = zF_8C4BFF7C_diagnosticBuilderMa(zT_43, zT_44, (unsigned int)(3));
    msg = zT_52;
    zT_53 = self->diag;
    zT_59 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_53, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_59);
    zT_69.has_value = 0;
    return zT_69;
    z_bb_2:
    if (!(zT_25.has_value)) { pal_trap(); }
    zT_27 = zT_25.value;
    goto z_bb_3;
    z_bb_3:
    resolved_path_id = zT_27;
    zT_72 = &self->path_to_id;
    zT_73 = resolved_path_id;
    zT_75 = zF_F3EE5998_u32ToU32MapGet(zT_72, zT_73);
    by_path = zT_75;
    zT_76 = by_path.has_value;
    if (zT_76) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    if (!(by_path.has_value)) { pal_trap(); }
    existing_id = by_path.value;
    zT_78 = self;
    zT_79 = importer_id;
    zT_80 = existing_id;
    zF_F9E76704_moduleRegistryAddIm(zT_78, zT_79, zT_80);
    zT_81 = &self->import_queue;
    zT_82 = existing_id;
    zF_9BB96D13_importQueueEnqueue(zT_81, zT_82);
    zT_84 = &self->path_to_id;
    zT_85 = path_id;
    zT_86 = existing_id;
    zF_26476265_u32ToU32MapPut(zT_84, zT_85, zT_86);
    zT_88.has_value = 1;
    zT_88.value = existing_id;
    return zT_88;
    z_bb_5:
    zT_90 = self->interner;
    zT_91 = resolved_path_id;
    zT_93 = zF_9134020D_stringInternerGet(zT_90, zT_91);
    resolved_path_s = zT_93;
    zT_95 = resolved_path_s;
    zT_96 = scratch;
    zT_97 = zF_5B859C63_readFile(zT_95, zT_96);
    zT_98 = zT_97.has_value;
    if (zT_98) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_102 = self;
    zT_103 = resolved_path_id;
    zT_104 = zF_AEB49EC3_moduleRegistryGetOr(zT_102, zT_103);
    mod_id = zT_104;
    zT_105 = self;
    zT_106 = importer_id;
    zT_107 = mod_id;
    zF_F9E76704_moduleRegistryAddIm(zT_105, zT_106, zT_107);
    zT_108 = &self->import_queue;
    zT_109 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_108, zT_109);
    zT_111 = &self->path_to_id;
    zT_112 = path_id;
    zT_113 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_111, zT_112, zT_113);
    zT_115.has_value = 1;
    zT_115.value = mod_id;
    return zT_115;
    z_bb_7:
    if (!(zT_97.has_value)) { pal_trap(); }
    zT_116 = zT_97.value;
    zT_99 = zT_116;
    goto z_bb_8;
    z_bb_8:
    content = zT_99;
    zT_118 = content;
    zT_119 = zF_B22E025B_fnv1a(zT_118);
    c_hash = zT_119;
    zT_121 = &self->content_to_id;
    zT_122 = c_hash;
    zT_124 = zF_F3EE5998_u32ToU32MapGet(zT_121, zT_122);
    by_content = zT_124;
    zT_125 = by_content.has_value;
    if (zT_125) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    if (!(by_content.has_value)) { pal_trap(); }
    target_id = by_content.value;
    zT_127 = &self->path_to_id;
    zT_128 = resolved_path_id;
    zT_129 = target_id;
    zF_26476265_u32ToU32MapPut(zT_127, zT_128, zT_129);
    zT_131 = self;
    zT_132 = importer_id;
    zT_133 = target_id;
    zF_F9E76704_moduleRegistryAddIm(zT_131, zT_132, zT_133);
    zT_134 = &self->import_queue;
    zT_135 = target_id;
    zF_9BB96D13_importQueueEnqueue(zT_134, zT_135);
    zT_137 = &self->path_to_id;
    zT_138 = path_id;
    zT_139 = target_id;
    zF_26476265_u32ToU32MapPut(zT_137, zT_138, zT_139);
    zT_141.has_value = 1;
    zT_141.value = target_id;
    return zT_141;
    z_bb_10:
    zT_143 = self;
    zT_144 = resolved_path_id;
    zT_145 = zF_AEB49EC3_moduleRegistryGetOr(zT_143, zT_144);
    mod_id = zT_145;
    zT_146 = &self->content_to_id;
    zT_147 = c_hash;
    zT_148 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_146, zT_147, zT_148);
    zT_150 = self;
    zT_151 = importer_id;
    zT_152 = mod_id;
    zF_F9E76704_moduleRegistryAddIm(zT_150, zT_151, zT_152);
    zT_153 = &self->import_queue;
    zT_154 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_153, zT_154);
    zT_156 = &self->path_to_id;
    zT_157 = path_id;
    zT_158 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_156, zT_157, zT_158);
    zT_160.has_value = 1;
    zT_160.value = mod_id;
    return zT_160;
}

/* hashSpillWriteU32 */
void zF_67A3663A_hashSpillWriteU32(zT_D21A8776_SpillStore* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_17;
    unsigned char zT_19;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned char zT_39;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_46;
    unsigned char* zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = v & (unsigned int)(255);
    zT_6 = (unsigned char)zig_cast_checked_u((zu64)zT_5, 32u, 0u, 8u);
    zT_7 = 0;
    zT_9 = (unsigned int)zT_7 < (unsigned int)(4);
    if (!(zT_9)) { pal_trap(); }
    b[zT_7] = zT_6;
    zT_13 = 1;
    if (!(zT_13)) { pal_trap(); }
    zT_15 = (unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255);
    zT_16 = (unsigned char)zig_cast_checked_u((zu64)zT_15, 32u, 0u, 8u);
    zT_17 = 1;
    zT_19 = (unsigned int)zT_17 < (unsigned int)(4);
    if (!(zT_19)) { pal_trap(); }
    b[zT_17] = zT_16;
    zT_23 = 1;
    if (!(zT_23)) { pal_trap(); }
    zT_25 = (unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255);
    zT_26 = (unsigned char)zig_cast_checked_u((zu64)zT_25, 32u, 0u, 8u);
    zT_27 = 2;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(4);
    if (!(zT_29)) { pal_trap(); }
    b[zT_27] = zT_26;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_35 = (unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255);
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_35, 32u, 0u, 8u);
    zT_37 = 3;
    zT_39 = (unsigned int)zT_37 < (unsigned int)(4);
    if (!(zT_39)) { pal_trap(); }
    b[zT_37] = zT_36;
    zT_40 = s;
    zT_41 = s->cur;
    zT_46 = 0;
    zT_47 = (unsigned char*)((unsigned char*)b) + zT_46;
    zT_48 = (unsigned int)(4) - zT_46;
    zT_49.ptr = (unsigned char*)zT_47;
    zT_49.len = zT_48;
    zT_42 = zT_49;
    zF_BFB33631_spillWriteAt(zT_40, zT_41, zT_42);
    return;
}

/* hashSpillReadU32 */
unsigned int zF_C8FC272D_hashSpillReadU32(zT_D21A8776_SpillStore* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_14;
    int zT_15;
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned int zT_59;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = s;
    zT_4 = s->cur;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)b) + zT_9;
    zT_11 = (unsigned int)(4) - zT_9;
    zT_12.ptr = (unsigned char*)zT_10;
    zT_12.len = zT_11;
    zT_5 = zT_12;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_14 = 0;
    v = zT_14;
    zT_15 = 0;
    zT_17 = (unsigned int)zT_15 < (unsigned int)(4);
    if (!(zT_17)) { pal_trap(); }
    zT_18 = b[zT_15];
    zT_20 = v | (unsigned int)((unsigned int)zT_18);
    v = zT_20;
    zT_21 = 1;
    zT_23 = (unsigned int)zT_21 < (unsigned int)(4);
    if (!(zT_23)) { pal_trap(); }
    zT_24 = b[zT_21];
    zT_25 = (unsigned int)zT_24;
    zT_26 = 8;
    zT_29 = 1;
    if (!(zT_29)) { pal_trap(); }
    zT_27 = zig_wrap_shl_u(((zu64)(zT_25)), ((zu64)(zT_26)), 32u);
    zT_30 = zig_overflow_flag_shl_u(((zu64)(zT_25)), ((zu64)(zT_26)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_33 = v | zT_27;
    v = zT_33;
    zT_34 = 2;
    zT_36 = (unsigned int)zT_34 < (unsigned int)(4);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = b[zT_34];
    zT_38 = (unsigned int)zT_37;
    zT_39 = 16;
    zT_42 = 1;
    if (!(zT_42)) { pal_trap(); }
    zT_40 = zig_wrap_shl_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_43 = zig_overflow_flag_shl_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    zT_46 = v | zT_40;
    v = zT_46;
    zT_47 = 3;
    zT_49 = (unsigned int)zT_47 < (unsigned int)(4);
    if (!(zT_49)) { pal_trap(); }
    zT_50 = b[zT_47];
    zT_51 = (unsigned int)zT_50;
    zT_52 = 24;
    zT_55 = 1;
    if (!(zT_55)) { pal_trap(); }
    zT_53 = zig_wrap_shl_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_56 = zig_overflow_flag_shl_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_59 = v | zT_53;
    v = zT_59;
    return v;
}

/* hashSpillWriteMap */
void zF_090598CE_hashSpillWriteMap(zT_D21A8776_SpillStore* s, zT_21D3708C_U32ToU32Map* m, zT_ABD0FF08_HashMapSpillMeta* meta) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D21A8776_SpillStore* zT_7;
    unsigned int zT_9;
    zT_D21A8776_SpillStore* zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int* zT_33;
    unsigned char* zT_34;
    unsigned int* zT_36;
    unsigned char* zT_37;
    unsigned char* zT_39;
    unsigned char* zT_40;
    int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_54;
    int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    unsigned char zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_D21A8776_SpillStore* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D21A8776_SpillStore* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_D21A8776_SpillStore* zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int keys_bytes;
    unsigned int vals_bytes;
    unsigned char* keys_ptr;
    unsigned char* vals_ptr;
    unsigned char* occ_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u keys_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u vals_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u occ_slice;
    zT_3 = s->cur;
    meta->disk_off = zT_3;
    zT_4 = m->capacity;
    meta->capacity = zT_4;
    zT_5 = m->count;
    meta->count = zT_5;
    meta->spilled = (unsigned char)(1);
    zT_7 = s;
    zT_9 = m->capacity;
    zF_67A3663A_hashSpillWriteU32(zT_7, (unsigned int)((unsigned int)zT_9));
    zT_11 = s;
    zT_13 = m->count;
    zF_67A3663A_hashSpillWriteU32(zT_11, (unsigned int)((unsigned int)zT_13));
    zT_15 = m->capacity;
    if ((unsigned char)(zT_15 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = m->capacity;
    zT_20 = 4;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    keys_bytes = zT_21;
    zT_26 = m->capacity;
    zT_27 = 4;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    vals_bytes = zT_28;
    zT_33 = m->keys;
    zT_34 = (unsigned char*)zT_33;
    keys_ptr = zT_34;
    zT_36 = m->values;
    zT_37 = (unsigned char*)zT_36;
    vals_ptr = zT_37;
    zT_39 = m->occupied;
    zT_40 = (unsigned char*)zT_39;
    occ_ptr = zT_40;
    zT_42 = 0;
    zT_43 = keys_ptr + zT_42;
    zT_44 = keys_bytes - zT_42;
    zT_45 = (unsigned int)zT_42 <= keys_bytes;
    if (!(zT_45)) { pal_trap(); }
    zT_46.ptr = (unsigned char*)zT_43;
    zT_46.len = zT_44;
    keys_slice = zT_46;
    zT_48 = 0;
    zT_49 = vals_ptr + zT_48;
    zT_50 = vals_bytes - zT_48;
    zT_51 = (unsigned int)zT_48 <= vals_bytes;
    if (!(zT_51)) { pal_trap(); }
    zT_52.ptr = (unsigned char*)zT_49;
    zT_52.len = zT_50;
    vals_slice = zT_52;
    zT_54 = m->capacity;
    zT_55 = 0;
    zT_56 = occ_ptr + zT_55;
    zT_57 = zT_54 - zT_55;
    zT_58 = (unsigned int)zT_55 <= zT_54;
    if (!(zT_58)) { pal_trap(); }
    zT_59.ptr = (unsigned char*)zT_56;
    zT_59.len = zT_57;
    occ_slice = zT_59;
    zT_60 = s;
    zT_61 = s->cur;
    zT_62 = keys_slice;
    zF_BFB33631_spillWriteAt(zT_60, zT_61, zT_62);
    zT_64 = s;
    zT_65 = s->cur;
    zT_66 = vals_slice;
    zF_BFB33631_spillWriteAt(zT_64, zT_65, zT_66);
    zT_68 = s;
    zT_69 = s->cur;
    zT_70 = occ_slice;
    zF_BFB33631_spillWriteAt(zT_68, zT_69, zT_70);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* moduleRegistrySpillHashMaps */
void zF_8767909B_moduleRegistrySpill(zT_072B53A6_ModuleRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u spill_path) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned char zT_7;
    unsigned char* zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char* zT_14;
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char zT_25;
    zT_0426DCE7_SpillBackend zT_29;
    zT_D21A8776_SpillStore* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_3E40CD83_Sand* zT_36;
    unsigned char* zT_37;
    zT_D21A8776_SpillStore* zT_43;
    zT_21D3708C_U32ToU32Map* zT_44;
    zT_ABD0FF08_HashMapSpillMeta* zT_45;
    zT_D21A8776_SpillStore* zT_49;
    zT_21D3708C_U32ToU32Map* zT_50;
    zT_ABD0FF08_HashMapSpillMeta* zT_51;
    zT_D21A8776_SpillStore* zT_55;
    zT_21D3708C_U32ToU32Map* zT_58;
    zT_21D3708C_U32ToU32Map* zT_60;
    int zT_61;
    zT_21D3708C_U32ToU32Map* zT_62;
    int zT_63;
    zT_21D3708C_U32ToU32Map* zT_64;
    int zT_65;
    zT_21D3708C_U32ToU32Map* zT_66;
    zT_21D3708C_U32ToU32Map* zT_68;
    zT_21D3708C_U32ToU32Map* zT_70;
    int zT_71;
    zT_21D3708C_U32ToU32Map* zT_72;
    int zT_73;
    zT_21D3708C_U32ToU32Map* zT_74;
    int zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    unsigned int i;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_5 = spill_path.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_10 = spill_path.ptr;
    zT_11 = spill_path.len;
    zT_12 = i < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[i];
    zT_14 = self->hash_spill_path;
    zT_16 = i < (unsigned int)(512);
    if (!(zT_16)) { pal_trap(); }
    zT_14[i] = zT_13;
    goto z_bb_4;
    z_bb_3:
    self->hash_spill_path_len = i;
    zT_22 = 0;
    zT_23 = self->hash_spill_path;
    zT_25 = i < (unsigned int)(512);
    if (!(zT_25)) { pal_trap(); }
    zT_23[i] = zT_22;
    zT_29 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_hash));
    if ((unsigned char)(zT_29 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    zT_17 = 1;
    zT_18 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_7 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_7 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    return;
    z_bb_9:
    zT_33 = &self->spill;
    zT_35 = spill_path;
    zT_36 = self->alloc;
    zT_37 = zG_034DEF1E_HASH_SPILL_WRITE_MO;
    zF_8AF94F71_spillOpen(zT_33, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_35, zT_36, zT_37);
    zT_43 = &self->spill;
    zT_44 = &self->path_to_id;
    zT_45 = &self->path_to_id_spill;
    zF_090598CE_hashSpillWriteMap(zT_43, zT_44, zT_45);
    zT_49 = &self->spill;
    zT_50 = &self->content_to_id;
    zT_51 = &self->content_to_id_spill;
    zF_090598CE_hashSpillWriteMap(zT_49, zT_50, zT_51);
    zT_55 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_55);
    zT_58 = &self->path_to_id;
    zT_58->capacity = (unsigned int)(0);
    zT_60 = &self->path_to_id;
    zT_60->count = (unsigned int)(0);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zT_62 = &self->path_to_id;
    zT_62->keys = (unsigned int*)zT_61;
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zT_64 = &self->path_to_id;
    zT_64->values = (unsigned int*)zT_63;
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zT_66 = &self->path_to_id;
    zT_66->occupied = (unsigned char*)zT_65;
    zT_68 = &self->content_to_id;
    zT_68->capacity = (unsigned int)(0);
    zT_70 = &self->content_to_id;
    zT_70->count = (unsigned int)(0);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zT_72 = &self->content_to_id;
    zT_72->keys = (unsigned int*)zT_71;
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zT_74 = &self->content_to_id;
    zT_74->values = (unsigned int*)zT_73;
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zT_76 = &self->content_to_id;
    zT_76->occupied = (unsigned char*)zT_75;
    return;
}

/* moduleRegistryFaultInPathToId */
void zF_34911396_moduleRegistryFault(zT_072B53A6_ModuleRegistry* self) {
    zT_ABD0FF08_HashMapSpillMeta zT_1;
    unsigned char zT_2;
    unsigned int zT_5;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    int zT_19;
    zT_D21A8776_SpillStore* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_3E40CD83_Sand* zT_24;
    unsigned char* zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned char zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_ABD0FF08_HashMapSpillMeta zT_43;
    zT_D21A8776_SpillStore* zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_D21A8776_SpillStore* zT_51;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_ABD0FF08_HashMapSpillMeta zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_ABD0FF08_HashMapSpillMeta zT_59;
    unsigned int zT_60;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    int zT_73;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    int zT_87;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    int zT_102;
    zT_3E40CD83_Sand* zT_107;
    unsigned int zT_108;
    zT_21D3708C_U32ToU32Map zT_110;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    zT_81AD2998_EU_952 zT_118;
    unsigned char zT_119;
    unsigned char* zT_120;
    zT_3E40CD83_Sand* zT_123;
    unsigned int zT_124;
    zT_21D3708C_U32ToU32Map zT_126;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_132;
    zT_81AD2998_EU_952 zT_134;
    unsigned char zT_135;
    unsigned char* zT_136;
    zT_3E40CD83_Sand* zT_139;
    unsigned int zT_140;
    zT_21D3708C_U32ToU32Map zT_142;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned char zT_148;
    zT_81AD2998_EU_952 zT_150;
    unsigned char zT_151;
    unsigned char* zT_152;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char zT_159;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned char zT_165;
    unsigned char* zT_167;
    unsigned char* zT_169;
    unsigned char* zT_171;
    int zT_173;
    unsigned char* zT_174;
    unsigned int zT_175;
    unsigned char zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    int zT_179;
    unsigned char* zT_180;
    unsigned int zT_181;
    unsigned char zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    int zT_185;
    unsigned char* zT_186;
    unsigned int zT_187;
    unsigned char zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    zT_D21A8776_SpillStore* zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_D21A8776_SpillStore zT_194;
    zT_D21A8776_SpillStore* zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    zT_D21A8776_SpillStore zT_200;
    zT_D21A8776_SpillStore* zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_D21A8776_SpillStore zT_206;
    zT_21D3708C_U32ToU32Map* zT_209;
    zT_21D3708C_U32ToU32Map* zT_211;
    zT_21D3708C_U32ToU32Map* zT_213;
    zT_21D3708C_U32ToU32Map* zT_214;
    zT_21D3708C_U32ToU32Map* zT_215;
    zT_D21A8776_SpillStore* zT_216;
    zT_ABD0FF08_HashMapSpillMeta* zT_219;
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int cap;
    unsigned int cnt;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int keys_bytes;
    unsigned int vals_bytes;
    unsigned char* keys_ptr;
    unsigned char* vals_ptr;
    unsigned char* occ_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u keys_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u vals_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u occ_slice;
    zT_1 = self->path_to_id_spill;
    zT_2 = zT_1.spilled;
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->hash_spill_path_len;
    if ((unsigned char)(zT_5 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = "hash spill state inconsistent: spilled with no spill path (moduleRegistryFaultInPathToId)";
    zT_11 = 89;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    emsg = zT_10;
    zT_13 = "module_registry.zig";
    zT_15 = 19;
    zT_14.ptr = (unsigned char*)zT_13;
    zT_14.len = zT_15;
    ef = zT_14;
    zT_16 = emsg;
    zT_17 = ef;
    zT_19 = 488;
    zF_6D97D338_panicHandler(zT_16, zT_17, (unsigned int)((unsigned int)zT_19));
    return;
    z_bb_4:
    zT_21 = &self->spill;
    zT_29 = self->hash_spill_path;
    zT_30 = self->hash_spill_path_len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_35 = (unsigned int)zT_31 <= zT_30;
    if (!(zT_35)) { pal_trap(); }
    zT_36 = zT_30 <= (unsigned int)(512);
    if (!(zT_36)) { pal_trap(); }
    zT_37.ptr = (unsigned char*)zT_32;
    zT_37.len = zT_33;
    zT_23 = zT_37;
    zT_24 = self->alloc;
    zT_25 = zG_1DDFFDDD_HASH_SPILL_READ_MOD;
    zF_8AF94F71_spillOpen(zT_21, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_23, zT_24, zT_25);
    zT_40 = &self->spill;
    zT_43 = self->path_to_id_spill;
    zT_41 = zT_43.disk_off;
    zF_56A911A9_spillSeek(zT_40, zT_41);
    zT_46 = &self->spill;
    zT_48 = zF_C8FC272D_hashSpillReadU32(zT_46);
    zT_49 = (unsigned int)zT_48;
    cap = zT_49;
    zT_51 = &self->spill;
    zT_53 = zF_C8FC272D_hashSpillReadU32(zT_51);
    zT_54 = (unsigned int)zT_53;
    cnt = zT_54;
    zT_55 = self->path_to_id_spill;
    zT_56 = zT_55.capacity;
    if ((unsigned char)(cap != zT_56)) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_59 = self->path_to_id_spill;
    zT_60 = zT_59.count;
    zT_58 = cnt != zT_60;
    goto z_bb_7;
    z_bb_6:
    zT_58 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_58) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_63 = "hash spill header cap/count mismatch vs recorded spill metadata (moduleRegistryFaultInPathToId)";
    zT_65 = 95;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    emsg = zT_64;
    zT_67 = "module_registry.zig";
    zT_69 = 19;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    ef = zT_68;
    zT_70 = emsg;
    zT_71 = ef;
    zT_73 = 504;
    zF_6D97D338_panicHandler(zT_70, zT_71, (unsigned int)((unsigned int)zT_73));
    return;
    z_bb_9:
    if ((unsigned char)(cnt > cap)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_77 = "hash spill header count exceeds capacity (moduleRegistryFaultInPathToId)";
    zT_79 = 72;
    zT_78.ptr = (unsigned char*)zT_77;
    zT_78.len = zT_79;
    emsg = zT_78;
    zT_81 = "module_registry.zig";
    zT_83 = 19;
    zT_82.ptr = (unsigned char*)zT_81;
    zT_82.len = zT_83;
    ef = zT_82;
    zT_84 = emsg;
    zT_85 = ef;
    zT_87 = 510;
    zF_6D97D338_panicHandler(zT_84, zT_85, (unsigned int)((unsigned int)zT_87));
    return;
    z_bb_11:
    if ((unsigned char)(cap > (unsigned int)(4000000))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_92 = "hash spill header capacity absurd (moduleRegistryFaultInPathToId)";
    zT_94 = 65;
    zT_93.ptr = (unsigned char*)zT_92;
    zT_93.len = zT_94;
    emsg = zT_93;
    zT_96 = "module_registry.zig";
    zT_98 = 19;
    zT_97.ptr = (unsigned char*)zT_96;
    zT_97.len = zT_98;
    ef = zT_97;
    zT_99 = emsg;
    zT_100 = ef;
    zT_102 = 516;
    zF_6D97D338_panicHandler(zT_99, zT_100, (unsigned int)((unsigned int)zT_102));
    return;
    z_bb_13:
    if ((unsigned char)(cap > (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_110 = self->path_to_id;
    zT_107 = zT_110.alloc;
    zT_112 = 4;
    zT_113 = zig_wrap_mul_u(((zu64)(zT_112)), ((zu64)(cap)), 32u);
    zT_114 = zig_overflow_flag_mul_u(((zu64)(zT_112)), ((zu64)(cap)), 32u);
    zT_116 = zT_114 == (unsigned int)(0);
    if (!(zT_116)) { pal_trap(); }
    zT_108 = zT_113;
    zT_118 = zF_1395EB68_sandAlloc(zT_107, zT_108, (unsigned int)(4));
    zT_119 = zT_118.is_error;
    if (zT_119) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_216 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_216);
    zT_219 = &self->path_to_id_spill;
    zT_219->spilled = (unsigned char)(0);
    return;
    z_bb_16:
    pal_trap();
    z_bb_17:
    zT_120 = zT_118.data.payload;
    goto z_bb_18;
    z_bb_18:
    raw_keys = zT_120;
    zT_126 = self->path_to_id;
    zT_123 = zT_126.alloc;
    zT_128 = 4;
    zT_129 = zig_wrap_mul_u(((zu64)(zT_128)), ((zu64)(cap)), 32u);
    zT_130 = zig_overflow_flag_mul_u(((zu64)(zT_128)), ((zu64)(cap)), 32u);
    zT_132 = zT_130 == (unsigned int)(0);
    if (!(zT_132)) { pal_trap(); }
    zT_124 = zT_129;
    zT_134 = zF_1395EB68_sandAlloc(zT_123, zT_124, (unsigned int)(4));
    zT_135 = zT_134.is_error;
    if (zT_135) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_136 = zT_134.data.payload;
    goto z_bb_21;
    z_bb_21:
    raw_vals = zT_136;
    zT_142 = self->path_to_id;
    zT_139 = zT_142.alloc;
    zT_144 = 1;
    zT_145 = zig_wrap_mul_u(((zu64)(zT_144)), ((zu64)(cap)), 32u);
    zT_146 = zig_overflow_flag_mul_u(((zu64)(zT_144)), ((zu64)(cap)), 32u);
    zT_148 = zT_146 == (unsigned int)(0);
    if (!(zT_148)) { pal_trap(); }
    zT_140 = zT_145;
    zT_150 = zF_1395EB68_sandAlloc(zT_139, zT_140, (unsigned int)(4));
    zT_151 = zT_150.is_error;
    if (zT_151) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    pal_trap();
    z_bb_23:
    zT_152 = zT_150.data.payload;
    goto z_bb_24;
    z_bb_24:
    raw_occ = zT_152;
    zT_155 = 4;
    zT_156 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_155)), 32u);
    zT_157 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_155)), 32u);
    zT_159 = zT_157 == (unsigned int)(0);
    if (!(zT_159)) { pal_trap(); }
    keys_bytes = zT_156;
    zT_161 = 4;
    zT_162 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_161)), 32u);
    zT_163 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_161)), 32u);
    zT_165 = zT_163 == (unsigned int)(0);
    if (!(zT_165)) { pal_trap(); }
    vals_bytes = zT_162;
    zT_167 = (unsigned char*)raw_keys;
    keys_ptr = zT_167;
    zT_169 = (unsigned char*)raw_vals;
    vals_ptr = zT_169;
    zT_171 = (unsigned char*)raw_occ;
    occ_ptr = zT_171;
    zT_173 = 0;
    zT_174 = keys_ptr + zT_173;
    zT_175 = keys_bytes - zT_173;
    zT_176 = (unsigned int)zT_173 <= keys_bytes;
    if (!(zT_176)) { pal_trap(); }
    zT_177.ptr = (unsigned char*)zT_174;
    zT_177.len = zT_175;
    keys_slice = zT_177;
    zT_179 = 0;
    zT_180 = vals_ptr + zT_179;
    zT_181 = vals_bytes - zT_179;
    zT_182 = (unsigned int)zT_179 <= vals_bytes;
    if (!(zT_182)) { pal_trap(); }
    zT_183.ptr = (unsigned char*)zT_180;
    zT_183.len = zT_181;
    vals_slice = zT_183;
    zT_185 = 0;
    zT_186 = occ_ptr + zT_185;
    zT_187 = cap - zT_185;
    zT_188 = (unsigned int)zT_185 <= cap;
    if (!(zT_188)) { pal_trap(); }
    zT_189.ptr = (unsigned char*)zT_186;
    zT_189.len = zT_187;
    occ_slice = zT_189;
    zT_190 = &self->spill;
    zT_194 = self->spill;
    zT_191 = zT_194.cur;
    zT_192 = keys_slice;
    zF_E9F67450_spillReadAt(zT_190, zT_191, zT_192);
    zT_196 = &self->spill;
    zT_200 = self->spill;
    zT_197 = zT_200.cur;
    zT_198 = vals_slice;
    zF_E9F67450_spillReadAt(zT_196, zT_197, zT_198);
    zT_202 = &self->spill;
    zT_206 = self->spill;
    zT_203 = zT_206.cur;
    zT_204 = occ_slice;
    zF_E9F67450_spillReadAt(zT_202, zT_203, zT_204);
    zT_209 = &self->path_to_id;
    zT_209->keys = (unsigned int*)((unsigned int*)raw_keys);
    zT_211 = &self->path_to_id;
    zT_211->values = (unsigned int*)((unsigned int*)raw_vals);
    zT_213 = &self->path_to_id;
    zT_213->occupied = (unsigned char*)((unsigned char*)raw_occ);
    zT_214 = &self->path_to_id;
    zT_214->capacity = cap;
    zT_215 = &self->path_to_id;
    zT_215->count = cnt;
    goto z_bb_15;
}

/* moduleRegistryPathToIdGet */
zT_BAEE192E_Opt_10 zF_A258E183_moduleRegistryPathT(zT_072B53A6_ModuleRegistry* self, unsigned int key) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = self;
    zF_34911396_moduleRegistryFault(zT_2);
    zT_3 = &self->path_to_id;
    zT_4 = key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    return zT_6;
}

/* importQueuePendingEnsureCapacity */
void zF_DB8D7B50_importQueuePendingE(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int new_cap) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int* zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6F2E32ED_Opt_259 zT_48;
    unsigned char zT_49;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_81AD2998_EU_952 zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    unsigned char zT_71;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_72;
    unsigned int* zT_73;
    unsigned int zT_74;
    unsigned int zT_79;
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int nc;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_5 = *cap;
    if ((unsigned char)(new_cap <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_8 = *cap;
    zT_9 = 2;
    zT_10 = zig_wrap_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    if ((unsigned char)(nc < zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = *cap;
    zT_16 = 2;
    zT_17 = zig_wrap_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    nc = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_21 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 8;
    zT_24 = (unsigned int)zT_23;
    nc = zT_24;
    goto z_bb_6;
    z_bb_6:
    zT_25 = *cap;
    zT_26 = 0;
    if ((unsigned char)(zT_25 > (unsigned int)zT_26)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = alloc;
    zT_34 = *items;
    zT_36 = *cap;
    zT_37 = 4;
    zT_38 = zig_wrap_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_31 = zT_38;
    zT_42 = 4;
    zT_43 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_32 = zT_43;
    zT_48 = zF_33A3D4F8_sandTryReallocInPla(zT_29, (unsigned char*)((unsigned char*)zT_34), zT_31, zT_32, (unsigned int)(4));
    grown = zT_48;
    zT_49 = grown.has_value;
    if (zT_49) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_51 = alloc;
    zT_54 = 4;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(nc)), 32u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(nc)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_52 = zT_55;
    zT_60 = zF_1395EB68_sandAlloc(zT_51, zT_52, (unsigned int)(4));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_62 = zT_60.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_62;
    zT_65 = (unsigned int*)raw;
    new_items = zT_65;
    zT_66 = *items;
    zT_67 = *len;
    zT_68 = 0;
    zT_69 = zT_66 + zT_68;
    zT_70 = zT_67 - zT_68;
    zT_71 = (unsigned int)zT_68 <= zT_67;
    if (!(zT_71)) { pal_trap(); }
    zT_72.ptr = (unsigned int*)zT_69;
    zT_72.len = zT_70;
    zT_73 = zT_72.ptr;
    zT_74 = zT_72.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_74)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_73[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items;
    *cap = nc;
    return;
    z_bb_17:
    zT_79 = i + (unsigned int)(1);
    i = zT_79;
    goto z_bb_14;
}

/* importQueuePendingAppend */
void zF_1649C2CE_importQueuePendingA(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int value) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_5 = items;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = alloc;
    zT_10 = *len;
    zT_11 = 1;
    zT_12 = zig_wrap_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_9 = zT_12;
    zF_DB8D7B50_importQueuePendingE(zT_5, zT_6, zT_7, zT_8, zT_9);
    zT_16 = *items;
    zT_17 = *len;
    zT_16[zT_17] = value;
    zT_18 = *len;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    *len = zT_21;
    return;
}

/* importQueuePendingPop */
zT_BAEE192E_Opt_10 zF_79A6B129_importQueuePendingP(unsigned int** items, unsigned int* len) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_16;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = *len;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_6 = *len;
    zT_7 = 1;
    zT_8 = (unsigned int)zT_7;
    zT_9 = zig_wrap_sub_u(((zu64)(zT_6)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_u(((zu64)(zT_6)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    *len = zT_9;
    zT_13 = *items;
    zT_14 = *len;
    zT_15 = zT_13[zT_14];
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
}

/* importQueueInit */
zT_47A5CDFB_ImportQueue zF_4CF3FEA5_importQueueInit(zT_3E40CD83_Sand* alloc, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_47A5CDFB_ImportQueue zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_47A5CDFB_ImportQueue q;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.pending_items = (unsigned int*)zT_4;
    zT_5 = 0;
    zT_3.pending_len = zT_5;
    zT_6 = 0;
    zT_3.pending_cap = zT_6;
    zT_3.pending_alloc = alloc;
    zT_3.diag = diag;
    q = zT_3;
    return q;
}

/* importQueueEnqueue */
void zF_9BB96D13_importQueueEnqueue(zT_47A5CDFB_ImportQueue* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int** zT_16;
    unsigned int* zT_17;
    unsigned int* zT_18;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->pending_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->pending_items;
    zT_8 = zT_7[i];
    if ((unsigned char)(zT_8 == module_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_16 = &self->pending_items;
    zT_17 = &self->pending_len;
    zT_18 = &self->pending_cap;
    zT_19 = self->pending_alloc;
    zT_20 = module_id;
    zF_1649C2CE_importQueuePendingA(zT_16, zT_17, zT_18, zT_19, zT_20);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    return;
    z_bb_6:
    zT_10 = 1;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    i = zT_12;
    goto z_bb_4;
}

/* importQueueDequeue */
zT_BAEE192E_Opt_10 zF_F8B96877_importQueueDequeue(zT_47A5CDFB_ImportQueue* self) {
    unsigned int** zT_1;
    unsigned int* zT_2;
    zT_BAEE192E_Opt_10 zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_1 = &self->pending_items;
    zT_2 = &self->pending_len;
    zT_5 = zF_79A6B129_importQueuePendingP(zT_1, zT_2);
    return zT_5;
}

/* moduleRegistrySortModules */
void zF_30C22573_moduleRegistrySortM(zT_072B53A6_ModuleRegistry* reg) {
    zT_E41AEC18_ModuleEntryArrayLis zT_2;
    unsigned int zT_3;
    zT_157C0A16_Arr_unsigned_int_25 zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    int zT_20;
    unsigned int zT_21;
    zT_E41AEC18_ModuleEntryArrayLis zT_24;
    zT_6E8D187B_ModuleEntry* zT_25;
    zT_6E8D187B_ModuleEntry zT_26;
    zT_9FE1BFFE_ModuleState zT_27;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    int zT_39;
    unsigned int zT_40;
    zT_157C0A16_Arr_unsigned_int_25 zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned char zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned char zT_52;
    zT_E41AEC18_ModuleEntryArrayLis zT_53;
    zT_6E8D187B_ModuleEntry* zT_54;
    zT_6E8D187B_ModuleEntry zT_55;
    zT_9FE1BFFE_ModuleState zT_56;
    unsigned int zT_59;
    unsigned char zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    int zT_75;
    unsigned int zT_76;
    int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned char zT_83;
    unsigned char zT_86;
    unsigned int zT_87;
    unsigned char zT_89;
    unsigned int zT_90;
    unsigned char zT_94;
    unsigned int zT_95;
    unsigned char zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned char zT_102;
    int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned char zT_108;
    int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned char zT_114;
    int zT_116;
    unsigned int zT_117;
    int zT_118;
    int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned char zT_125;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_131;
    zT_E41AEC18_ModuleEntryArrayLis zT_132;
    zT_6E8D187B_ModuleEntry* zT_133;
    zT_6E8D187B_ModuleEntry zT_134;
    zT_9FE1BFFE_ModuleState zT_135;
    zT_E41AEC18_ModuleEntryArrayLis zT_139;
    zT_6E8D187B_ModuleEntry* zT_140;
    zT_6E8D187B_ModuleEntry zT_141;
    zT_E41AEC18_ModuleEntryArrayLis zT_143;
    zT_6E8D187B_ModuleEntry* zT_144;
    int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    int zT_152;
    unsigned int zT_153;
    zT_E41AEC18_ModuleEntryArrayLis zT_156;
    zT_6E8D187B_ModuleEntry* zT_157;
    zT_6E8D187B_ModuleEntry zT_158;
    zT_9FE1BFFE_ModuleState zT_159;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    unsigned int* zT_174;
    unsigned int zT_175;
    unsigned char zT_178;
    unsigned int zT_179;
    int zT_180;
    unsigned char zT_183;
    unsigned int zT_184;
    int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned char zT_190;
    unsigned char zT_192;
    unsigned char zT_194;
    unsigned int zT_195;
    int zT_196;
    unsigned int zT_198;
    unsigned char zT_200;
    int zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned char zT_206;
    int zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_212;
    int zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    unsigned char zT_218;
    int zT_222;
    unsigned int zT_223;
    zT_E41AEC18_ModuleEntryArrayLis zT_226;
    zT_6E8D187B_ModuleEntry* zT_227;
    zT_6E8D187B_ModuleEntry zT_228;
    zT_9FE1BFFE_ModuleState zT_229;
    unsigned char zT_232;
    unsigned char zT_234;
    unsigned int zT_235;
    int zT_236;
    zT_D3EB6303_StringInterner* zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned char* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    zT_D3EB6303_StringInterner* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_259;
    zT_F85C5DED_DiagnosticCollector* zT_261;
    int zT_263;
    unsigned char zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    zT_F85C5DED_DiagnosticCollector* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    zT_E41AEC18_ModuleEntryArrayLis zT_286;
    zT_6E8D187B_ModuleEntry* zT_287;
    int zT_288;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    zT_072B53A6_ModuleRegistry* zT_294;
    zig_poison_fill((void*)&zT_243, (unsigned int)sizeof zT_243);
    zig_poison_fill((void*)&zT_268, (unsigned int)sizeof zT_268);
    unsigned int mod_count;
    zT_157C0A16_Arr_unsigned_int_25 in_degree;
    unsigned int i;
    zT_6E8D187B_ModuleEntry entry;
    zT_157C0A16_Arr_unsigned_int_25 worklist_items;
    unsigned int worklist_len;
    unsigned int si;
    unsigned int sj;
    unsigned int sorted_count;
    unsigned int tmp;
    unsigned int id;
    unsigned int id_idx;
    unsigned int ii;
    zT_6E8D187B_ModuleEntry imp_entry;
    unsigned int start;
    unsigned int end;
    unsigned int j;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u mn;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli cparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = reg->modules;
    zT_3 = zT_2.len;
    mod_count = zT_3;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 256) {
        in_degree[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < mod_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    zT_13 = i < (unsigned int)(256);
    if (!(zT_13)) { pal_trap(); }
    in_degree[i] = zT_11;
    zT_14 = 1;
    zT_15 = (unsigned int)zT_14;
    zT_16 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    i = zT_16;
    goto z_bb_4;
    z_bb_3:
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    i = zT_21;
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    if ((unsigned char)(i < mod_count)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = reg->modules;
    zT_25 = zT_24.items;
    zT_26 = zT_25[i];
    entry = zT_26;
    zT_27 = entry.state;
    if ((unsigned char)(zT_27 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    {
    unsigned int _i = 0;
    while (_i < 256) {
        worklist_items[_i] = zT_42[_i];
        _i++;
    }
}
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    worklist_len = zT_45;
    goto z_bb_11;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_30 = entry.import_count;
    zT_32 = i < (unsigned int)(256);
    if (!(zT_32)) { pal_trap(); }
    in_degree[i] = zT_30;
    goto z_bb_10;
    z_bb_10:
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    i = zT_35;
    goto z_bb_8;
    z_bb_11:
    if ((unsigned char)(i < mod_count)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_48 = i < (unsigned int)(256);
    if (!(zT_48)) { pal_trap(); }
    zT_49 = in_degree[i];
    zT_50 = 0;
    if ((unsigned char)(zT_49 == (unsigned int)zT_50)) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_75 = 0;
    zT_76 = (unsigned int)zT_75;
    si = zT_76;
    goto z_bb_20;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_53 = reg->modules;
    zT_54 = zT_53.items;
    zT_55 = zT_54[i];
    zT_56 = zT_55.state;
    zT_52 = zT_56 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    goto z_bb_17;
    z_bb_16:
    zT_52 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_52) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_59 = (unsigned int)i;
    zT_61 = worklist_len < (unsigned int)(256);
    if (!(zT_61)) { pal_trap(); }
    worklist_items[worklist_len] = zT_59;
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zig_wrap_add_u(((zu64)(worklist_len)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(worklist_len)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    worklist_len = zT_64;
    goto z_bb_19;
    z_bb_19:
    zT_68 = 1;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    i = zT_70;
    goto z_bb_14;
    z_bb_20:
    if ((unsigned char)(si < worklist_len)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_79 = 1;
    zT_80 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_79)), 32u);
    zT_81 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_79)), 32u);
    zT_83 = zT_81 == (unsigned int)(0);
    if (!(zT_83)) { pal_trap(); }
    sj = zT_80;
    goto z_bb_24;
    z_bb_22:
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    sorted_count = zT_117;
    goto z_bb_30;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    if ((unsigned char)(sj < worklist_len)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_86 = si < (unsigned int)(256);
    if (!(zT_86)) { pal_trap(); }
    zT_87 = worklist_items[si];
    zT_89 = sj < (unsigned int)(256);
    if (!(zT_89)) { pal_trap(); }
    zT_90 = worklist_items[sj];
    if ((unsigned char)(zT_87 > zT_90)) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_109 = 1;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_110)), 32u);
    zT_112 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_110)), 32u);
    zT_114 = zT_112 == (unsigned int)(0);
    if (!(zT_114)) { pal_trap(); }
    si = zT_111;
    goto z_bb_23;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_94 = si < (unsigned int)(256);
    if (!(zT_94)) { pal_trap(); }
    zT_95 = worklist_items[si];
    tmp = zT_95;
    zT_97 = sj < (unsigned int)(256);
    if (!(zT_97)) { pal_trap(); }
    zT_98 = worklist_items[sj];
    zT_100 = si < (unsigned int)(256);
    if (!(zT_100)) { pal_trap(); }
    worklist_items[si] = zT_98;
    zT_102 = sj < (unsigned int)(256);
    if (!(zT_102)) { pal_trap(); }
    worklist_items[sj] = tmp;
    goto z_bb_29;
    z_bb_29:
    zT_103 = 1;
    zT_104 = (unsigned int)zT_103;
    zT_105 = zig_wrap_add_u(((zu64)(sj)), ((zu64)(zT_104)), 32u);
    zT_106 = zig_overflow_flag_add_u(((zu64)(sj)), ((zu64)(zT_104)), 32u);
    zT_108 = zT_106 == (unsigned int)(0);
    if (!(zT_108)) { pal_trap(); }
    sj = zT_105;
    goto z_bb_27;
    z_bb_30:
    zT_118 = 0;
    if ((unsigned char)(worklist_len > (unsigned int)zT_118)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_120 = 1;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zig_wrap_sub_u(((zu64)(worklist_len)), ((zu64)(zT_121)), 32u);
    zT_123 = zig_overflow_flag_sub_u(((zu64)(worklist_len)), ((zu64)(zT_121)), 32u);
    zT_125 = zT_123 == (unsigned int)(0);
    if (!(zT_125)) { pal_trap(); }
    worklist_len = zT_122;
    zT_128 = worklist_len < (unsigned int)(256);
    if (!(zT_128)) { pal_trap(); }
    zT_129 = worklist_items[worklist_len];
    id = zT_129;
    zT_131 = (unsigned int)id;
    id_idx = zT_131;
    zT_132 = reg->modules;
    zT_133 = zT_132.items;
    zT_134 = zT_133[id_idx];
    zT_135 = zT_134.state;
    if ((unsigned char)(zT_135 == (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    if ((unsigned char)(sorted_count < (unsigned int)((unsigned int)mod_count))) goto z_bb_52; else goto z_bb_53;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    goto z_bb_33;
    z_bb_35:
    zT_139 = reg->modules;
    zT_140 = zT_139.items;
    zT_141 = zT_140[id_idx];
    entry = zT_141;
    entry.state = (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    zT_143 = reg->modules;
    zT_144 = zT_143.items;
    zT_144[id_idx] = entry;
    zT_145 = 1;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zig_wrap_add_u(((zu64)(sorted_count)), ((zu64)(zT_146)), 32u);
    zT_148 = zig_overflow_flag_add_u(((zu64)(sorted_count)), ((zu64)(zT_146)), 32u);
    zT_150 = zT_148 == (unsigned int)(0);
    if (!(zT_150)) { pal_trap(); }
    sorted_count = zT_147;
    zT_152 = 0;
    zT_153 = (unsigned int)zT_152;
    ii = zT_153;
    goto z_bb_36;
    z_bb_36:
    if ((unsigned char)(ii < mod_count)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_156 = reg->modules;
    zT_157 = zT_156.items;
    zT_158 = zT_157[ii];
    imp_entry = zT_158;
    zT_159 = imp_entry.state;
    if ((unsigned char)(zT_159 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_40; else goto z_bb_41;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_163 = imp_entry.imports_start;
    zT_164 = (unsigned int)zT_163;
    start = zT_164;
    zT_166 = imp_entry.import_count;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zig_wrap_add_u(((zu64)(start)), ((zu64)(zT_167)), 32u);
    zT_169 = zig_overflow_flag_add_u(((zu64)(start)), ((zu64)(zT_167)), 32u);
    zT_171 = zT_169 == (unsigned int)(0);
    if (!(zT_171)) { pal_trap(); }
    end = zT_168;
    j = start;
    goto z_bb_42;
    z_bb_41:
    zT_213 = 1;
    zT_214 = (unsigned int)zT_213;
    zT_215 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_214)), 32u);
    zT_216 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_214)), 32u);
    zT_218 = zT_216 == (unsigned int)(0);
    if (!(zT_218)) { pal_trap(); }
    ii = zT_215;
    goto z_bb_39;
    z_bb_42:
    if ((unsigned char)(j < end)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_174 = reg->import_edges_items;
    zT_175 = zT_174[j];
    if ((unsigned char)(zT_175 == id)) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_41;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_178 = ii < (unsigned int)(256);
    if (!(zT_178)) { pal_trap(); }
    zT_179 = in_degree[ii];
    zT_180 = 0;
    if ((unsigned char)(zT_179 > (unsigned int)zT_180)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_207 = 1;
    zT_208 = (unsigned int)zT_207;
    zT_209 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_208)), 32u);
    zT_210 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_208)), 32u);
    zT_212 = zT_210 == (unsigned int)(0);
    if (!(zT_212)) { pal_trap(); }
    j = zT_209;
    goto z_bb_45;
    z_bb_48:
    zT_183 = ii < (unsigned int)(256);
    if (!(zT_183)) { pal_trap(); }
    zT_184 = in_degree[ii];
    zT_185 = 1;
    zT_186 = (unsigned int)zT_185;
    zT_187 = zig_wrap_sub_u(((zu64)(zT_184)), ((zu64)(zT_186)), 32u);
    zT_188 = zig_overflow_flag_sub_u(((zu64)(zT_184)), ((zu64)(zT_186)), 32u);
    zT_190 = zT_188 == (unsigned int)(0);
    if (!(zT_190)) { pal_trap(); }
    zT_192 = ii < (unsigned int)(256);
    if (!(zT_192)) { pal_trap(); }
    in_degree[ii] = zT_187;
    goto z_bb_49;
    z_bb_49:
    zT_194 = ii < (unsigned int)(256);
    if (!(zT_194)) { pal_trap(); }
    zT_195 = in_degree[ii];
    zT_196 = 0;
    if ((unsigned char)(zT_195 == (unsigned int)zT_196)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_198 = (unsigned int)ii;
    zT_200 = worklist_len < (unsigned int)(256);
    if (!(zT_200)) { pal_trap(); }
    worklist_items[worklist_len] = zT_198;
    zT_201 = 1;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zig_wrap_add_u(((zu64)(worklist_len)), ((zu64)(zT_202)), 32u);
    zT_204 = zig_overflow_flag_add_u(((zu64)(worklist_len)), ((zu64)(zT_202)), 32u);
    zT_206 = zT_204 == (unsigned int)(0);
    if (!(zT_206)) { pal_trap(); }
    worklist_len = zT_203;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_222 = 0;
    zT_223 = (unsigned int)zT_222;
    ci = zT_223;
    goto z_bb_54;
    z_bb_53:
    zT_294 = reg;
    zF_F87B71D9_moduleRegistryVerif(zT_294);
    return;
    z_bb_54:
    if ((unsigned char)(ci < mod_count)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_226 = reg->modules;
    zT_227 = zT_226.items;
    zT_228 = zT_227[ci];
    entry = zT_228;
    zT_229 = entry.state;
    if ((unsigned char)(zT_229 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_234 = ci < (unsigned int)(256);
    if (!(zT_234)) { pal_trap(); }
    zT_235 = in_degree[ci];
    zT_236 = 0;
    zT_232 = zT_235 > (unsigned int)zT_236;
    goto z_bb_60;
    z_bb_59:
    zT_232 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_232) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_239 = reg->interner;
    zT_240 = entry.path_id;
    zT_243 = zF_9134020D_stringInternerGet(zT_239, zT_240);
    mn = zT_243;
    zT_245 = "circular import detected in module '";
    zT_247 = 36;
    zT_246.ptr = (unsigned char*)zT_245;
    zT_246.len = zT_247;
    cp1 = zT_246;
    zT_249 = "'";
    zT_251 = 1;
    zT_250.ptr = (unsigned char*)zT_249;
    zT_250.len = zT_251;
    cp2 = zT_250;
    zT_254 = 0;
    zT_253[zT_254] = cp1;
    zT_255 = 1;
    zT_253[zT_255] = mn;
    zT_256 = 2;
    zT_253[zT_256] = cp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        cparts[_i] = zT_253[_i];
        _i++;
    }
}
    zT_261 = reg->diag;
    zT_258 = zT_261->interner;
    zT_263 = 0;
    zT_265 = (unsigned int)zT_263 < (unsigned int)(3);
    if (!(zT_265)) { pal_trap(); }
    zT_266 = cparts + zT_263;
    zT_259 = zT_266;
    zT_268 = zF_8C4BFF7C_diagnosticBuilderMa(zT_258, zT_259, (unsigned int)(3));
    msg = zT_268;
    zT_269 = reg->diag;
    zT_275 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_269, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_275);
    entry.state = (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    zT_286 = reg->modules;
    zT_287 = zT_286.items;
    zT_287[ci] = entry;
    goto z_bb_62;
    z_bb_62:
    zT_288 = 1;
    zT_289 = (unsigned int)zT_288;
    zT_290 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_289)), 32u);
    zT_291 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_289)), 32u);
    zT_293 = zT_291 == (unsigned int)(0);
    if (!(zT_293)) { pal_trap(); }
    ci = zT_290;
    goto z_bb_57;
}

/* moduleRegistryVerifyOrder */
void zF_F87B71D9_moduleRegistryVerif(zT_072B53A6_ModuleRegistry* reg) {
    zT_E41AEC18_ModuleEntryArrayLis zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis zT_9;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int* zT_28;
    unsigned int zT_29;
    zT_E41AEC18_ModuleEntryArrayLis zT_31;
    zT_6E8D187B_ModuleEntry* zT_32;
    unsigned int zT_33;
    zT_6E8D187B_ModuleEntry zT_34;
    zT_9FE1BFFE_ModuleState zT_35;
    unsigned char zT_38;
    zT_9FE1BFFE_ModuleState zT_39;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_F85C5DED_DiagnosticCollector* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    unsigned int mod_count;
    unsigned int vi;
    zT_6E8D187B_ModuleEntry entry;
    unsigned int start;
    unsigned int end;
    unsigned int vj;
    unsigned int imp_id;
    zT_6E8D187B_ModuleEntry imp;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = reg->modules;
    zT_3 = zT_2.len;
    mod_count = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    vi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(vi < mod_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = reg->modules;
    zT_10 = zT_9.items;
    zT_11 = zT_10[vi];
    entry = zT_11;
    zT_12 = entry.state;
    if ((unsigned char)(zT_12 == (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_16 = entry.imports_start;
    zT_17 = (unsigned int)zT_16;
    start = zT_17;
    zT_19 = entry.import_count;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(start)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(start)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    end = zT_21;
    vj = start;
    goto z_bb_7;
    z_bb_6:
    zT_68 = 1;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zig_wrap_add_u(((zu64)(vi)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(vi)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    vi = zT_70;
    goto z_bb_4;
    z_bb_7:
    if ((unsigned char)(vj < end)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_28 = reg->import_edges_items;
    zT_29 = zT_28[vj];
    imp_id = zT_29;
    zT_31 = reg->modules;
    zT_32 = zT_31.items;
    zT_33 = (unsigned int)imp_id;
    zT_34 = zT_32[zT_33];
    imp = zT_34;
    zT_35 = imp.state;
    if ((unsigned char)(zT_35 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_39 = imp.state;
    zT_38 = zT_39 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_43 = "topological sort violation: import not resolved";
    zT_45 = 47;
    zT_44.ptr = (unsigned char*)zT_43;
    zT_44.len = zT_45;
    msg = zT_44;
    zT_46 = reg->diag;
    zT_52 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_46, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_4000_INVALID_CONTROL_FLOW)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_52);
    goto z_bb_15;
    z_bb_15:
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zig_wrap_add_u(((zu64)(vj)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(vj)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    vj = zT_64;
    goto z_bb_10;
}

/* moduleRegistryCollectIncludes */
void zF_7D71E4ED_moduleRegistryColle(zT_6B0A7D14_AstStore* store, unsigned int root_idx, zT_B687BB96_U32ArrayList* c_includes) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_20;
    zT_8143F551_AstKind zT_21;
    zT_B687BB96_U32ArrayList* zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8143F551_AstKind zT_30;
    unsigned char zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_42;
    zT_8143F551_AstKind zT_43;
    zT_B687BB96_U32ArrayList* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_4 = store;
    zT_5 = root_idx;
    zT_6 = zF_152E19CB_astStoreNodeExtraCh(zT_4, zT_5);
    decls_n = zT_6;
    zT_8 = 0;
    di = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = store;
    zT_13 = root_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_12, zT_13, (unsigned int)((unsigned int)di));
    decl_idx = zT_16;
    zT_18 = store;
    zT_19 = decl_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    decl = zT_20;
    zT_21 = decl.kind;
    if ((unsigned char)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_53 = 1;
    zT_54 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    di = zT_54;
    goto z_bb_1;
    z_bb_5:
    zT_25 = c_includes;
    zT_27 = store;
    zT_28 = decl_idx;
    zT_29 = zF_8BA26B9E_astStoreNodePayload(zT_27, zT_28);
    zT_26 = zT_29;
    zF_62F717A2_u32ArrayListAppend(zT_25, zT_26);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = decl.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = decl.child_1;
    zT_34 = zT_35 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_34 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_34) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = store;
    zT_40 = decl.child_1;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    init = zT_42;
    zT_43 = init.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_6;
    z_bb_13:
    zT_47 = c_includes;
    zT_49 = store;
    zT_50 = decl.child_1;
    zT_52 = zF_8BA26B9E_astStoreNodePayload(zT_49, zT_50);
    zT_48 = zT_52;
    zF_62F717A2_u32ArrayListAppend(zT_47, zT_48);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
}

/* __module_init */
void zF_780653D2___module_init_8(void) {
    zT_B687BB96_U32ArrayList zT_0;
    int zT_1;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_B687BB96_U32ArrayList = zT_0;
    zT_1 = 0;
    zG_E8C23D2C_source_man_stub = (unsigned char)((unsigned char)zT_1);
    return;
}

/* EOF */
