#include "string_interner_51340A9F.h"
zT_D3EB6303_StringInterner zG_D3EB6303_StringInterner;
static unsigned int const zG_78B9D882_NARROW_BUCKET_MAX_B = (unsigned int)(131070);
static unsigned int const zG_E1B4665A_MAX_U16_ENTRY_INDEX = (unsigned int)(65535);
/* internerBucketsAllocNarrow */
void zF_9DC2533D_internerBucketsAllo(zT_D3EB6303_StringInterner* self, unsigned int count) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_FDFD82FD_EU_362 zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    unsigned char* raw;
    zT_3 = self->allocator;
    zT_7 = 2;
    zT_8 = zig_wrap_mul_u(((zu64)(zT_7)), ((zu64)(count)), 32u);
    zT_9 = zig_overflow_flag_mul_u(((zu64)(zT_7)), ((zu64)(count)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_4 = zT_8;
    zT_13 = zF_1395EB68_sandAlloc(zT_3, zT_4, (unsigned int)(2));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_15;
    self->buckets_narrow_items = (unsigned short*)((unsigned short*)raw);
    return;
}

/* internerBucketsAllocWide */
void zF_22329EAD_internerBucketsAllo(zT_D3EB6303_StringInterner* self, unsigned int count) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_FDFD82FD_EU_362 zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    unsigned char* raw;
    zT_3 = self->allocator;
    zT_7 = 4;
    zT_8 = zig_wrap_mul_u(((zu64)(zT_7)), ((zu64)(count)), 32u);
    zT_9 = zig_overflow_flag_mul_u(((zu64)(zT_7)), ((zu64)(count)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_4 = zT_8;
    zT_13 = zF_1395EB68_sandAlloc(zT_3, zT_4, (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_15 = zT_13.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_15;
    self->buckets_wide_items = (unsigned int*)((unsigned int*)raw);
    return;
}

/* internerBucketGet */
unsigned int zF_6162B7CC_internerBucketGet(zT_D3EB6303_StringInterner* self, unsigned int bucket) {
    unsigned char zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned short* zT_5;
    unsigned short zT_6;
    zT_2 = self->buckets_is_wide;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = self->buckets_wide_items;
    zT_4 = zT_3[bucket];
    return zT_4;
    z_bb_2:
    zT_5 = self->buckets_narrow_items;
    zT_6 = zT_5[bucket];
    return (unsigned int)((unsigned int)zT_6);
}

/* internerBucketSet */
void zF_DF70E160_internerBucketSet(zT_D3EB6303_StringInterner* self, unsigned int bucket, unsigned int value) {
    unsigned char zT_3;
    unsigned int* zT_4;
    unsigned short zT_5;
    unsigned short* zT_6;
    zT_3 = self->buckets_is_wide;
    if (zT_3) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_4 = self->buckets_wide_items;
    zT_4[bucket] = value;
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_5 = (unsigned short)zig_cast_checked_u((zu64)value, 32u, 0u, 16u);
    zT_6 = self->buckets_narrow_items;
    zT_6[bucket] = zT_5;
    goto z_bb_2;
}

/* internerBucketZero */
void zF_57DE4452_internerBucketZero(zT_D3EB6303_StringInterner* self, unsigned int bucket) {
    unsigned char zT_2;
    unsigned int zT_3;
    unsigned int* zT_4;
    unsigned short zT_5;
    unsigned short* zT_6;
    zT_2 = self->buckets_is_wide;
    if (zT_2) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_3 = 0;
    zT_4 = self->buckets_wide_items;
    zT_4[bucket] = zT_3;
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_5 = 0;
    zT_6 = self->buckets_narrow_items;
    zT_6[bucket] = zT_5;
    goto z_bb_2;
}

/* ensureCapacityEntries */
void zF_FB994A71_ensureCapacityEntri(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int new_capacity) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_FDFD82FD_EU_362 zT_35;
    unsigned char zT_36;
    unsigned char* zT_37;
    zT_EABC94D3_InternEntry* zT_40;
    zT_EABC94D3_InternEntry* zT_41;
    unsigned int zT_42;
    int zT_43;
    zT_EABC94D3_InternEntry* zT_44;
    unsigned int zT_45;
    unsigned char zT_46;
    zT_0B638573_Slice_zT_EABC94D3_I zT_47;
    zT_EABC94D3_InternEntry* zT_48;
    unsigned int zT_49;
    unsigned int zT_54;
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    unsigned int new_cap;
    unsigned char* raw;
    zT_EABC94D3_InternEntry* new_items;
    zT_EABC94D3_InternEntry item;
    unsigned int i;
    zT_5 = *capacity;
    if ((unsigned char)(new_capacity <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_8 = *capacity;
    zT_9 = 2;
    zT_10 = zig_wrap_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = *capacity;
    zT_16 = 2;
    zT_17 = zig_wrap_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    new_cap = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_21 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 8;
    zT_24 = (unsigned int)zT_23;
    new_cap = zT_24;
    goto z_bb_6;
    z_bb_6:
    zT_26 = arena;
    zT_29 = 12;
    zT_30 = zig_wrap_mul_u(((zu64)(zT_29)), ((zu64)(new_cap)), 32u);
    zT_31 = zig_overflow_flag_mul_u(((zu64)(zT_29)), ((zu64)(new_cap)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_27 = zT_30;
    zT_35 = zF_1395EB68_sandAlloc(zT_26, zT_27, (unsigned int)(4));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_37 = zT_35.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_37;
    zT_40 = (zT_EABC94D3_InternEntry*)raw;
    new_items = zT_40;
    zT_41 = *items;
    zT_42 = *len;
    zT_43 = 0;
    zT_44 = zT_41 + zT_43;
    zT_45 = zT_42 - zT_43;
    zT_46 = (unsigned int)zT_43 <= zT_42;
    if (!(zT_46)) { pal_trap(); }
    zT_47.ptr = (zT_EABC94D3_InternEntry*)zT_44;
    zT_47.len = zT_45;
    zT_48 = zT_47.ptr;
    zT_49 = zT_47.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_49)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_48[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    *items = new_items;
    *capacity = new_cap;
    return;
    z_bb_13:
    zT_54 = i + (unsigned int)(1);
    i = zT_54;
    goto z_bb_10;
}

/* appendEntry */
void zF_A7C4EDCF_appendEntry(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_EABC94D3_InternEntry value) {
    zT_EABC94D3_InternEntry** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_EABC94D3_InternEntry* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_5 = items;
    zT_6 = len;
    zT_7 = capacity;
    zT_8 = arena;
    zT_10 = *len;
    zT_11 = 1;
    zT_12 = zig_wrap_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_9 = zT_12;
    zF_FB994A71_ensureCapacityEntri(zT_5, zT_6, zT_7, zT_8, zT_9);
    zT_16 = *items;
    zT_17 = *len;
    zT_16[zT_17] = value;
    zT_18 = *len;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_18)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    *len = zT_21;
    return;
}

/* stringInternerInit */
zT_D3EB6303_StringInterner zF_FB2E811D_stringInternerInit(zT_3E40CD83_Sand* allocator, unsigned int bucket_count) {
    zT_D3EB6303_StringInterner zT_3;
    int zT_4;
    int zT_5;
    unsigned char zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned char zT_19;
    zT_D3EB6303_StringInterner* zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    unsigned int zT_24;
    int zT_27;
    unsigned int zT_28;
    zT_D3EB6303_StringInterner* zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    zT_FDFD82FD_EU_362 zT_56;
    unsigned char zT_57;
    unsigned char* zT_58;
    zT_EABC94D3_InternEntry zT_61;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_EABC94D3_InternEntry* zT_66;
    unsigned int zT_67;
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zT_D3EB6303_StringInterner interner;
    unsigned int bc;
    unsigned int ec;
    unsigned int bi;
    unsigned char* entries_raw;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.buckets_narrow_items = (unsigned short*)zT_4;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_3.buckets_wide_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_3.buckets_is_wide = zT_6;
    zT_7 = 0;
    zT_3.buckets_len = zT_7;
    zT_8 = 0;
    zT_3.buckets_capacity = zT_8;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_3.entries_items = (zT_EABC94D3_InternEntry*)zT_9;
    zT_10 = 0;
    zT_3.entries_len = zT_10;
    zT_11 = 0;
    zT_3.entries_capacity = zT_11;
    zT_3.entries_allocator = allocator;
    zT_3.allocator = allocator;
    interner = zT_3;
    zT_13 = (unsigned int)bucket_count;
    bc = zT_13;
    if ((unsigned char)(bc > (unsigned int)(131070))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    interner.buckets_is_wide = (unsigned char)(1);
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(bc > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = interner.buckets_is_wide;
    if (zT_19) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_42 = 1;
    if (!(zT_42)) { pal_trap(); }
    zT_40 = bc / (unsigned int)(2);
    ec = zT_40;
    if ((unsigned char)(ec < (unsigned int)(8))) goto z_bb_12; else goto z_bb_13;
    z_bb_5:
    zT_20 = (zT_D3EB6303_StringInterner*)&interner;
    zT_21 = bc;
    zF_22329EAD_internerBucketsAllo(zT_20, zT_21);
    goto z_bb_6;
    z_bb_6:
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    bi = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_23 = (zT_D3EB6303_StringInterner*)&interner;
    zT_24 = bc;
    zF_9DC2533D_internerBucketsAllo(zT_23, zT_24);
    goto z_bb_6;
    z_bb_8:
    if ((unsigned char)(bi < bc)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = (zT_D3EB6303_StringInterner*)&interner;
    zT_31 = bi;
    zF_57DE4452_internerBucketZero(zT_30, zT_31);
    goto z_bb_11;
    z_bb_10:
    interner.buckets_capacity = bc;
    interner.buckets_len = bc;
    goto z_bb_4;
    z_bb_11:
    zT_33 = 1;
    zT_34 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    bi = zT_34;
    goto z_bb_8;
    z_bb_12:
    zT_45 = 8;
    ec = zT_45;
    goto z_bb_13;
    z_bb_13:
    zT_47 = allocator;
    zT_50 = 12;
    zT_51 = zig_wrap_mul_u(((zu64)(zT_50)), ((zu64)(ec)), 32u);
    zT_52 = zig_overflow_flag_mul_u(((zu64)(zT_50)), ((zu64)(ec)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    zT_48 = zT_51;
    zT_56 = zF_1395EB68_sandAlloc(zT_47, zT_48, (unsigned int)(4));
    zT_57 = zT_56.is_error;
    if (zT_57) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_58 = zT_56.data.payload;
    goto z_bb_16;
    z_bb_16:
    entries_raw = zT_58;
    interner.entries_items = (zT_EABC94D3_InternEntry*)((zT_EABC94D3_InternEntry*)entries_raw);
    interner.entries_capacity = ec;
    zT_62 = "";
    zT_64 = 0;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    zT_61.text = zT_63;
    zT_65 = 0;
    zT_61.next = zT_65;
    zT_66 = interner.entries_items;
    zT_67 = 0;
    zT_66[zT_67] = zT_61;
    interner.entries_len = (unsigned int)(1);
    return interner;
}

/* stringInternerIntern */
unsigned int zF_50C274AF_stringInternerInter(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    int zT_32;
    zT_D3EB6303_StringInterner* zT_34;
    int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned char zT_43;
    unsigned int zT_44;
    zT_D3EB6303_StringInterner* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_EABC94D3_InternEntry* zT_52;
    zT_EABC94D3_InternEntry* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned char zT_58;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_67;
    unsigned char zT_68;
    unsigned char zT_70;
    zT_D3EB6303_StringInterner* zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D3EB6303_StringInterner* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_84;
    zT_EABC94D3_InternEntry** zT_85;
    unsigned int* zT_86;
    unsigned int* zT_87;
    zT_3E40CD83_Sand* zT_88;
    zT_EABC94D3_InternEntry zT_89;
    zT_EABC94D3_InternEntry zT_94;
    unsigned int zT_96;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_D3EB6303_StringInterner* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_D3EB6303_StringInterner* zT_105;
    unsigned int zT_106;
    unsigned int zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    zT_D3EB6303_StringInterner* zT_117;
    int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zT_8F083A69_Slice_zT_0B42B2F8_u inth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u inth2_m;
    unsigned int hash;
    unsigned int bucket_count;
    unsigned int bucket;
    unsigned int idx;
    zT_EABC94D3_InternEntry* entry;
    unsigned int new_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u indp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u innw_m;
    unsigned char* copied;
    unsigned int entry_count;
    zT_3 = "INT:tl";
    zT_5 = 6;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    inth_m = zT_4;
    zT_6 = inth_m;
    zT_9 = text.len;
    zF_C914CB83_markerWriteInt(zT_6, (unsigned int)((unsigned int)zT_9));
    zT_12 = text.len;
    if ((unsigned char)(zT_12 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = "INT:t0";
    zT_18 = 6;
    zT_17.ptr = (unsigned char*)zT_16;
    zT_17.len = zT_18;
    inth2_m = zT_17;
    zT_19 = inth2_m;
    zT_21 = text.ptr;
    zT_22 = 0;
    zT_23 = text.len;
    zT_24 = (unsigned int)zT_22 < zT_23;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_21[zT_22];
    zF_C914CB83_markerWriteInt(zT_19, (unsigned int)((unsigned int)zT_25));
    goto z_bb_2;
    z_bb_2:
    zT_28 = text;
    zT_29 = zF_B22E025B_fnv1a(zT_28);
    hash = zT_29;
    zT_31 = self->buckets_len;
    bucket_count = zT_31;
    zT_32 = 0;
    if ((unsigned char)(bucket_count == (unsigned int)zT_32)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_34 = self;
    zT_36 = 8;
    zF_3A9E8EDF_stringInternerGrowB(zT_34, (unsigned int)((unsigned int)zT_36));
    zT_38 = self->buckets_len;
    bucket_count = zT_38;
    goto z_bb_4;
    z_bb_4:
    zT_40 = (unsigned int)bucket_count;
    zT_43 = zT_40 != (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = (unsigned int)(unsigned int)(hash % zT_40);
    bucket = zT_44;
    zT_46 = self;
    zT_47 = bucket;
    zT_48 = zF_6162B7CC_internerBucketGet(zT_46, zT_47);
    idx = zT_48;
    goto z_bb_5;
    z_bb_5:
    zT_49 = 0;
    if ((unsigned char)(idx != (unsigned int)zT_49)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_52 = self->entries_items;
    zT_54 = zT_52 + (unsigned int)((unsigned int)idx);
    entry = zT_54;
    zT_57 = entry->text;
    zT_55 = zT_57;
    zT_56 = text;
    zT_58 = zF_B7662C9F_mem_eql(zT_55, zT_56);
    if (zT_58) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_67 = self->entries_len;
    new_idx = zT_67;
    zT_68 = self->buckets_is_wide;
    if ((unsigned char)(!zT_68)) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_60 = "INT:dup";
    zT_62 = 7;
    zT_61.ptr = (unsigned char*)zT_60;
    zT_61.len = zT_62;
    indp_m = zT_61;
    zT_63 = indp_m;
    zT_64 = idx;
    zF_C914CB83_markerWriteInt(zT_63, zT_64);
    return idx;
    z_bb_10:
    zT_65 = entry->next;
    idx = zT_65;
    goto z_bb_8;
    z_bb_11:
    zT_70 = new_idx > (unsigned int)(65535);
    goto z_bb_13;
    z_bb_12:
    zT_70 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_70) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_73 = self;
    zF_3765B9F7_stringInternerMakeB(zT_73);
    goto z_bb_15;
    z_bb_15:
    zT_75 = "INT:new";
    zT_77 = 7;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    innw_m = zT_76;
    zT_78 = innw_m;
    zF_95B5C5CD_measureMarkerWriteI(zT_78, (unsigned int)((unsigned int)new_idx));
    zT_82 = self;
    zT_83 = text;
    zT_84 = zF_EDFF876E_stringInternerCopyT(zT_82, zT_83);
    copied = zT_84;
    zT_85 = &self->entries_items;
    zT_86 = &self->entries_len;
    zT_87 = &self->entries_capacity;
    zT_88 = self->entries_allocator;
    zT_96 = text.len;
    zT_97 = 0;
    zT_98 = copied + zT_97;
    zT_99 = zT_96 - zT_97;
    zT_100 = (unsigned int)zT_97 <= zT_96;
    if (!(zT_100)) { pal_trap(); }
    zT_101.ptr = (unsigned char*)zT_98;
    zT_101.len = zT_99;
    zT_94.text = zT_101;
    zT_102 = self;
    zT_103 = bucket;
    zT_104 = zF_6162B7CC_internerBucketGet(zT_102, zT_103);
    zT_94.next = zT_104;
    zT_89 = zT_94;
    zF_A7C4EDCF_appendEntry(zT_85, zT_86, zT_87, zT_88, zT_89);
    zT_105 = self;
    zT_106 = bucket;
    zF_DF70E160_internerBucketSet(zT_105, zT_106, (unsigned int)((unsigned int)new_idx));
    zT_110 = self->entries_len;
    entry_count = zT_110;
    zT_111 = 2;
    zT_112 = zig_wrap_mul_u(((zu64)(entry_count)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_mul_u(((zu64)(entry_count)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    if ((unsigned char)(zT_112 > bucket_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_117 = self;
    zT_119 = 2;
    zT_120 = zig_wrap_mul_u(((zu64)(bucket_count)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_mul_u(((zu64)(bucket_count)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    zF_3A9E8EDF_stringInternerGrowB(zT_117, (unsigned int)((unsigned int)zT_120));
    goto z_bb_17;
    z_bb_17:
    return (unsigned int)((unsigned int)new_idx);
}

/* stringInternerGet */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9134020D_stringInternerGet(zT_D3EB6303_StringInterner* self, unsigned int id) {
    zT_EABC94D3_InternEntry* zT_2;
    unsigned int zT_3;
    zT_EABC94D3_InternEntry zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_2 = self->entries_items;
    zT_3 = (unsigned int)id;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.text;
    return zT_5;
}

/* stringInternerCopyToArena */
unsigned char* zF_EDFF876E_stringInternerCopyT(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    zT_FDFD82FD_EU_362 zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned int zT_20;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_3 = self->allocator;
    zT_4 = text.len;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, (unsigned int)(1));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    zT_14 = text.ptr;
    zT_15 = text.len;
    i = 0;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = zT_14[i];
    raw[i] = c;
    goto z_bb_7;
    z_bb_6:
    return raw;
    z_bb_7:
    zT_20 = i + (unsigned int)(1);
    i = zT_20;
    goto z_bb_4;
}

/* stringInternerMakeBucketsWide */
void zF_3765B9F7_stringInternerMakeB(zT_D3EB6303_StringInterner* self) {
    unsigned char zT_1;
    unsigned int zT_3;
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_EABC94D3_InternEntry* zT_25;
    zT_EABC94D3_InternEntry* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned int* zT_38;
    unsigned int zT_39;
    unsigned int* zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    unsigned int count;
    unsigned int wi;
    unsigned int mei;
    zT_EABC94D3_InternEntry* entry;
    unsigned int mh;
    unsigned int mb;
    zT_1 = self->buckets_is_wide;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_3 = self->buckets_len;
    count = zT_3;
    zT_4 = self;
    zT_5 = count;
    zF_22329EAD_internerBucketsAllo(zT_4, zT_5);
    self->buckets_is_wide = (unsigned char)(1);
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    wi = zT_9;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(wi < count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = 0;
    zT_12 = self->buckets_wide_items;
    zT_12[wi] = zT_11;
    goto z_bb_6;
    z_bb_5:
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    mei = zT_20;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 1;
    zT_14 = zig_wrap_add_u(((zu64)(wi)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(wi)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    wi = zT_14;
    goto z_bb_3;
    z_bb_7:
    zT_21 = self->entries_len;
    if ((unsigned char)(mei < (unsigned int)((unsigned int)zT_21))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = self->entries_items;
    zT_27 = zT_25 + (unsigned int)((unsigned int)mei);
    entry = zT_27;
    zT_30 = entry->text;
    zT_29 = zT_30;
    zT_31 = zF_B22E025B_fnv1a(zT_29);
    mh = zT_31;
    zT_33 = (unsigned int)count;
    zT_36 = zT_33 != (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = (unsigned int)(unsigned int)(mh % zT_33);
    mb = zT_37;
    zT_38 = self->buckets_wide_items;
    zT_39 = zT_38[mb];
    entry->next = zT_39;
    zT_40 = self->buckets_wide_items;
    zT_40[mb] = mei;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    zT_43 = zig_wrap_add_u(((zu64)(mei)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(mei)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    mei = zT_43;
    goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    goto z_bb_7;
}

/* stringInternerGrowBuckets */
void zF_3A9E8EDF_stringInternerGrowB(zT_D3EB6303_StringInterner* self, unsigned int new_bucket_count) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_D3EB6303_StringInterner* zT_24;
    unsigned int zT_25;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    int zT_30;
    unsigned int zT_31;
    zT_D3EB6303_StringInterner* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_EABC94D3_InternEntry* zT_47;
    zT_EABC94D3_InternEntry* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned int zT_55;
    unsigned char zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    unsigned int zT_64;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    unsigned int new_count;
    unsigned int new_cap;
    unsigned int i;
    unsigned int ei;
    zT_EABC94D3_InternEntry* entry;
    unsigned int h;
    unsigned int bucket;
    zT_3 = (unsigned int)new_bucket_count;
    new_count = zT_3;
    zT_4 = self->buckets_capacity;
    if ((unsigned char)(new_count > zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    new_cap = new_count;
    zT_7 = self->buckets_capacity;
    zT_8 = 2;
    zT_9 = zig_wrap_mul_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_mul_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    self->buckets_len = (unsigned int)(0);
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_3:
    zT_14 = self->buckets_capacity;
    zT_15 = 2;
    zT_16 = zig_wrap_mul_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_mul_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    new_cap = zT_16;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = 8;
    new_cap = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_23 = self->buckets_is_wide;
    if (zT_23) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_24 = self;
    zT_25 = new_cap;
    zF_22329EAD_internerBucketsAllo(zT_24, zT_25);
    goto z_bb_8;
    z_bb_8:
    self->buckets_capacity = new_cap;
    goto z_bb_2;
    z_bb_9:
    zT_26 = self;
    zT_27 = new_cap;
    zF_9DC2533D_internerBucketsAllo(zT_26, zT_27);
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)(i < new_count)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self;
    zT_34 = i;
    zF_57DE4452_internerBucketZero(zT_33, zT_34);
    goto z_bb_13;
    z_bb_12:
    self->buckets_len = new_count;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    zT_36 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    i = zT_36;
    goto z_bb_10;
    z_bb_14:
    zT_43 = self->entries_len;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_43))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_47 = self->entries_items;
    zT_49 = zT_47 + (unsigned int)((unsigned int)ei);
    entry = zT_49;
    zT_52 = entry->text;
    zT_51 = zT_52;
    zT_53 = zF_B22E025B_fnv1a(zT_51);
    h = zT_53;
    zT_55 = (unsigned int)new_count;
    zT_58 = zT_55 != (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_59 = (unsigned int)(unsigned int)(h % zT_55);
    bucket = zT_59;
    zT_60 = self;
    zT_61 = bucket;
    zT_62 = zF_6162B7CC_internerBucketGet(zT_60, zT_61);
    entry->next = zT_62;
    zT_63 = self;
    zT_64 = bucket;
    zF_DF70E160_internerBucketSet(zT_63, zT_64, (unsigned int)((unsigned int)ei));
    zT_67 = 1;
    zT_68 = (unsigned int)zT_67;
    zT_69 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    ei = zT_69;
    goto z_bb_17;
    z_bb_16:
    return;
    z_bb_17:
    goto z_bb_14;
}

/* EOF */
