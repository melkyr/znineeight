#include "const_alias_prepass_A733A209.h"
/* resolveWellKnownTypeName */
unsigned int zF_0D410D69_resolveWellKnownTyp(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned char zT_8;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char zT_20;
    unsigned char* zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char* zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned char zT_32;
    unsigned char zT_33;
    unsigned char* zT_37;
    int zT_38;
    unsigned int zT_39;
    unsigned char zT_40;
    unsigned char zT_41;
    unsigned char zT_44;
    unsigned char* zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned char zT_48;
    unsigned char zT_49;
    unsigned char zT_52;
    unsigned char* zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned char zT_56;
    unsigned char zT_57;
    unsigned char zT_60;
    unsigned char* zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned char zT_64;
    unsigned char zT_65;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    unsigned char zT_80;
    unsigned char* zT_81;
    int zT_82;
    unsigned int zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    unsigned char* zT_88;
    int zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    unsigned char zT_92;
    unsigned char* zT_96;
    int zT_97;
    unsigned int zT_98;
    unsigned char zT_99;
    unsigned char zT_100;
    unsigned char zT_103;
    unsigned char* zT_104;
    int zT_105;
    unsigned int zT_106;
    unsigned char zT_107;
    unsigned char zT_108;
    unsigned char* zT_111;
    int zT_112;
    unsigned int zT_113;
    unsigned char zT_114;
    unsigned char zT_115;
    unsigned char* zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned char zT_122;
    unsigned char zT_123;
    unsigned char zT_126;
    unsigned char* zT_127;
    int zT_128;
    unsigned int zT_129;
    unsigned char zT_130;
    unsigned char zT_131;
    unsigned char zT_134;
    unsigned char* zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned char zT_138;
    unsigned char zT_139;
    unsigned char* zT_143;
    int zT_144;
    unsigned int zT_145;
    unsigned char zT_146;
    unsigned char zT_147;
    unsigned char zT_150;
    unsigned char* zT_151;
    int zT_152;
    unsigned int zT_153;
    unsigned char zT_154;
    unsigned char zT_155;
    unsigned char zT_158;
    unsigned char* zT_159;
    int zT_160;
    unsigned int zT_161;
    unsigned char zT_162;
    unsigned char zT_163;
    unsigned char* zT_167;
    int zT_168;
    unsigned int zT_169;
    unsigned char zT_170;
    unsigned char zT_171;
    unsigned char zT_174;
    unsigned char* zT_175;
    int zT_176;
    unsigned int zT_177;
    unsigned char zT_178;
    unsigned char zT_179;
    unsigned char* zT_182;
    int zT_183;
    unsigned int zT_184;
    unsigned char zT_185;
    unsigned char zT_186;
    unsigned char* zT_190;
    int zT_191;
    unsigned int zT_192;
    unsigned char zT_193;
    unsigned char zT_194;
    unsigned int zT_199;
    int zT_200;
    unsigned char* zT_202;
    int zT_203;
    unsigned int zT_204;
    unsigned char zT_205;
    unsigned char zT_206;
    unsigned char zT_209;
    unsigned char* zT_210;
    int zT_211;
    unsigned int zT_212;
    unsigned char zT_213;
    unsigned char zT_214;
    unsigned char* zT_218;
    int zT_219;
    unsigned int zT_220;
    unsigned char zT_221;
    unsigned char zT_222;
    unsigned char zT_225;
    unsigned char* zT_226;
    int zT_227;
    unsigned int zT_228;
    unsigned char zT_229;
    unsigned char zT_230;
    unsigned int zT_235;
    int zT_236;
    unsigned char* zT_238;
    int zT_239;
    unsigned int zT_240;
    unsigned char zT_241;
    unsigned char zT_242;
    unsigned char zT_245;
    unsigned char* zT_246;
    int zT_247;
    unsigned int zT_248;
    unsigned char zT_249;
    unsigned char zT_250;
    unsigned char zT_253;
    unsigned char* zT_254;
    int zT_255;
    unsigned int zT_256;
    unsigned char zT_257;
    unsigned char zT_258;
    unsigned char zT_261;
    unsigned char* zT_262;
    int zT_263;
    unsigned int zT_264;
    unsigned char zT_265;
    unsigned char zT_266;
    unsigned char zT_269;
    unsigned char* zT_270;
    int zT_271;
    unsigned int zT_272;
    unsigned char zT_273;
    unsigned char zT_274;
    unsigned char* zT_278;
    int zT_279;
    unsigned int zT_280;
    unsigned char zT_281;
    unsigned char zT_282;
    unsigned char zT_285;
    unsigned char* zT_286;
    int zT_287;
    unsigned int zT_288;
    unsigned char zT_289;
    unsigned char zT_290;
    unsigned char zT_293;
    unsigned char* zT_294;
    int zT_295;
    unsigned int zT_296;
    unsigned char zT_297;
    unsigned char zT_298;
    unsigned char zT_301;
    unsigned char* zT_302;
    int zT_303;
    unsigned int zT_304;
    unsigned char zT_305;
    unsigned char zT_306;
    unsigned char zT_309;
    unsigned char* zT_310;
    int zT_311;
    unsigned int zT_312;
    unsigned char zT_313;
    unsigned char zT_314;
    zT_2 = name.len;
    zT_3 = 4;
    if ((unsigned char)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = name.ptr;
    zT_6 = 0;
    zT_7 = name.len;
    zT_8 = (unsigned int)zT_6 < zT_7;
    if (!(zT_8)) { pal_trap(); }
    zT_9 = zT_5[zT_6];
    if ((unsigned char)(zT_9 == (unsigned char)(118))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_70 = name.len;
    zT_71 = 3;
    if ((unsigned char)(zT_70 == (unsigned int)zT_71)) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    zT_13 = name.ptr;
    zT_14 = 1;
    zT_15 = name.len;
    zT_16 = (unsigned int)zT_14 < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_13[zT_14];
    zT_12 = zT_17 == (unsigned char)(111);
    goto z_bb_5;
    z_bb_4:
    zT_12 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_21 = name.ptr;
    zT_22 = 2;
    zT_23 = name.len;
    zT_24 = (unsigned int)zT_22 < zT_23;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_21[zT_22];
    zT_20 = zT_25 == (unsigned char)(105);
    goto z_bb_8;
    z_bb_7:
    zT_20 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_20) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_29 = name.ptr;
    zT_30 = 3;
    zT_31 = name.len;
    zT_32 = (unsigned int)zT_30 < zT_31;
    if (!(zT_32)) { pal_trap(); }
    zT_33 = zT_29[zT_30];
    zT_28 = zT_33 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_28 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_28) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_37 = name.ptr;
    zT_38 = 0;
    zT_39 = name.len;
    zT_40 = (unsigned int)zT_38 < zT_39;
    if (!(zT_40)) { pal_trap(); }
    zT_41 = zT_37[zT_38];
    if ((unsigned char)(zT_41 == (unsigned char)(98))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = name.ptr;
    zT_46 = 1;
    zT_47 = name.len;
    zT_48 = (unsigned int)zT_46 < zT_47;
    if (!(zT_48)) { pal_trap(); }
    zT_49 = zT_45[zT_46];
    zT_44 = zT_49 == (unsigned char)(111);
    goto z_bb_16;
    z_bb_15:
    zT_44 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_44) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_53 = name.ptr;
    zT_54 = 2;
    zT_55 = name.len;
    zT_56 = (unsigned int)zT_54 < zT_55;
    if (!(zT_56)) { pal_trap(); }
    zT_57 = zT_53[zT_54];
    zT_52 = zT_57 == (unsigned char)(111);
    goto z_bb_19;
    z_bb_18:
    zT_52 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_52) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = name.ptr;
    zT_62 = 3;
    zT_63 = name.len;
    zT_64 = (unsigned int)zT_62 < zT_63;
    if (!(zT_64)) { pal_trap(); }
    zT_65 = zT_61[zT_62];
    zT_60 = zT_65 == (unsigned char)(108);
    goto z_bb_22;
    z_bb_21:
    zT_60 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_60) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(2);
    z_bb_24:
    goto z_bb_2;
    z_bb_25:
    zT_73 = name.ptr;
    zT_74 = 0;
    zT_75 = name.len;
    zT_76 = (unsigned int)zT_74 < zT_75;
    if (!(zT_76)) { pal_trap(); }
    zT_77 = zT_73[zT_74];
    if ((unsigned char)(zT_77 == (unsigned char)(105))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_199 = name.len;
    zT_200 = 2;
    if ((unsigned char)(zT_199 == (unsigned int)zT_200)) goto z_bb_66; else goto z_bb_67;
    z_bb_27:
    zT_81 = name.ptr;
    zT_82 = 2;
    zT_83 = name.len;
    zT_84 = (unsigned int)zT_82 < zT_83;
    if (!(zT_84)) { pal_trap(); }
    zT_85 = zT_81[zT_82];
    zT_80 = zT_85 == (unsigned char)(50);
    goto z_bb_29;
    z_bb_28:
    zT_80 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_80) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_88 = name.ptr;
    zT_89 = 1;
    zT_90 = name.len;
    zT_91 = (unsigned int)zT_89 < zT_90;
    if (!(zT_91)) { pal_trap(); }
    zT_92 = zT_88[zT_89];
    if ((unsigned char)(zT_92 == (unsigned char)(51))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_96 = name.ptr;
    zT_97 = 0;
    zT_98 = name.len;
    zT_99 = (unsigned int)zT_97 < zT_98;
    if (!(zT_99)) { pal_trap(); }
    zT_100 = zT_96[zT_97];
    if ((unsigned char)(zT_100 == (unsigned char)(117))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    return (unsigned int)(6);
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_104 = name.ptr;
    zT_105 = 2;
    zT_106 = name.len;
    zT_107 = (unsigned int)zT_105 < zT_106;
    if (!(zT_107)) { pal_trap(); }
    zT_108 = zT_104[zT_105];
    zT_103 = zT_108 == (unsigned char)(50);
    goto z_bb_36;
    z_bb_35:
    zT_103 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_103) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_111 = name.ptr;
    zT_112 = 1;
    zT_113 = name.len;
    zT_114 = (unsigned int)zT_112 < zT_113;
    if (!(zT_114)) { pal_trap(); }
    zT_115 = zT_111[zT_112];
    if ((unsigned char)(zT_115 == (unsigned char)(51))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_119 = name.ptr;
    zT_120 = 0;
    zT_121 = name.len;
    zT_122 = (unsigned int)zT_120 < zT_121;
    if (!(zT_122)) { pal_trap(); }
    zT_123 = zT_119[zT_120];
    if ((unsigned char)(zT_123 == (unsigned char)(117))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    return (unsigned int)(10);
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_127 = name.ptr;
    zT_128 = 1;
    zT_129 = name.len;
    zT_130 = (unsigned int)zT_128 < zT_129;
    if (!(zT_130)) { pal_trap(); }
    zT_131 = zT_127[zT_128];
    zT_126 = zT_131 == (unsigned char)(54);
    goto z_bb_43;
    z_bb_42:
    zT_126 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_126) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_135 = name.ptr;
    zT_136 = 2;
    zT_137 = name.len;
    zT_138 = (unsigned int)zT_136 < zT_137;
    if (!(zT_138)) { pal_trap(); }
    zT_139 = zT_135[zT_136];
    zT_134 = zT_139 == (unsigned char)(52);
    goto z_bb_46;
    z_bb_45:
    zT_134 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_134) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned int)(11);
    z_bb_48:
    zT_143 = name.ptr;
    zT_144 = 0;
    zT_145 = name.len;
    zT_146 = (unsigned int)zT_144 < zT_145;
    if (!(zT_146)) { pal_trap(); }
    zT_147 = zT_143[zT_144];
    if ((unsigned char)(zT_147 == (unsigned char)(105))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_151 = name.ptr;
    zT_152 = 1;
    zT_153 = name.len;
    zT_154 = (unsigned int)zT_152 < zT_153;
    if (!(zT_154)) { pal_trap(); }
    zT_155 = zT_151[zT_152];
    zT_150 = zT_155 == (unsigned char)(54);
    goto z_bb_51;
    z_bb_50:
    zT_150 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_150) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_159 = name.ptr;
    zT_160 = 2;
    zT_161 = name.len;
    zT_162 = (unsigned int)zT_160 < zT_161;
    if (!(zT_162)) { pal_trap(); }
    zT_163 = zT_159[zT_160];
    zT_158 = zT_163 == (unsigned char)(52);
    goto z_bb_54;
    z_bb_53:
    zT_158 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_158) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned int)(7);
    z_bb_56:
    zT_167 = name.ptr;
    zT_168 = 0;
    zT_169 = name.len;
    zT_170 = (unsigned int)zT_168 < zT_169;
    if (!(zT_170)) { pal_trap(); }
    zT_171 = zT_167[zT_168];
    if ((unsigned char)(zT_171 == (unsigned char)(102))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_175 = name.ptr;
    zT_176 = 2;
    zT_177 = name.len;
    zT_178 = (unsigned int)zT_176 < zT_177;
    if (!(zT_178)) { pal_trap(); }
    zT_179 = zT_175[zT_176];
    zT_174 = zT_179 == (unsigned char)(50);
    goto z_bb_59;
    z_bb_58:
    zT_174 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_174) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_182 = name.ptr;
    zT_183 = 1;
    zT_184 = name.len;
    zT_185 = (unsigned int)zT_183 < zT_184;
    if (!(zT_185)) { pal_trap(); }
    zT_186 = zT_182[zT_183];
    if ((unsigned char)(zT_186 == (unsigned char)(51))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_26;
    z_bb_62:
    return (unsigned int)(15);
    z_bb_63:
    zT_190 = name.ptr;
    zT_191 = 1;
    zT_192 = name.len;
    zT_193 = (unsigned int)zT_191 < zT_192;
    if (!(zT_193)) { pal_trap(); }
    zT_194 = zT_190[zT_191];
    if ((unsigned char)(zT_194 == (unsigned char)(54))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return (unsigned int)(16);
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_202 = name.ptr;
    zT_203 = 0;
    zT_204 = name.len;
    zT_205 = (unsigned int)zT_203 < zT_204;
    if (!(zT_205)) { pal_trap(); }
    zT_206 = zT_202[zT_203];
    if ((unsigned char)(zT_206 == (unsigned char)(105))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    zT_235 = name.len;
    zT_236 = 5;
    if ((unsigned char)(zT_235 == (unsigned int)zT_236)) goto z_bb_78; else goto z_bb_79;
    z_bb_68:
    zT_210 = name.ptr;
    zT_211 = 1;
    zT_212 = name.len;
    zT_213 = (unsigned int)zT_211 < zT_212;
    if (!(zT_213)) { pal_trap(); }
    zT_214 = zT_210[zT_211];
    zT_209 = zT_214 == (unsigned char)(56);
    goto z_bb_70;
    z_bb_69:
    zT_209 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_209) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned int)(4);
    z_bb_72:
    zT_218 = name.ptr;
    zT_219 = 0;
    zT_220 = name.len;
    zT_221 = (unsigned int)zT_219 < zT_220;
    if (!(zT_221)) { pal_trap(); }
    zT_222 = zT_218[zT_219];
    if ((unsigned char)(zT_222 == (unsigned char)(117))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_226 = name.ptr;
    zT_227 = 1;
    zT_228 = name.len;
    zT_229 = (unsigned int)zT_227 < zT_228;
    if (!(zT_229)) { pal_trap(); }
    zT_230 = zT_226[zT_227];
    zT_225 = zT_230 == (unsigned char)(56);
    goto z_bb_75;
    z_bb_74:
    zT_225 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_225) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (unsigned int)(8);
    z_bb_77:
    goto z_bb_67;
    z_bb_78:
    zT_238 = name.ptr;
    zT_239 = 0;
    zT_240 = name.len;
    zT_241 = (unsigned int)zT_239 < zT_240;
    if (!(zT_241)) { pal_trap(); }
    zT_242 = zT_238[zT_239];
    if ((unsigned char)(zT_242 == (unsigned char)(117))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    return (unsigned int)(18);
    z_bb_80:
    zT_246 = name.ptr;
    zT_247 = 1;
    zT_248 = name.len;
    zT_249 = (unsigned int)zT_247 < zT_248;
    if (!(zT_249)) { pal_trap(); }
    zT_250 = zT_246[zT_247];
    zT_245 = zT_250 == (unsigned char)(115);
    goto z_bb_82;
    z_bb_81:
    zT_245 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_245) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_254 = name.ptr;
    zT_255 = 2;
    zT_256 = name.len;
    zT_257 = (unsigned int)zT_255 < zT_256;
    if (!(zT_257)) { pal_trap(); }
    zT_258 = zT_254[zT_255];
    zT_253 = zT_258 == (unsigned char)(105);
    goto z_bb_85;
    z_bb_84:
    zT_253 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_253) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_262 = name.ptr;
    zT_263 = 3;
    zT_264 = name.len;
    zT_265 = (unsigned int)zT_263 < zT_264;
    if (!(zT_265)) { pal_trap(); }
    zT_266 = zT_262[zT_263];
    zT_261 = zT_266 == (unsigned char)(122);
    goto z_bb_88;
    z_bb_87:
    zT_261 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_261) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_270 = name.ptr;
    zT_271 = 4;
    zT_272 = name.len;
    zT_273 = (unsigned int)zT_271 < zT_272;
    if (!(zT_273)) { pal_trap(); }
    zT_274 = zT_270[zT_271];
    zT_269 = zT_274 == (unsigned char)(101);
    goto z_bb_91;
    z_bb_90:
    zT_269 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_269) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    return (unsigned int)(13);
    z_bb_93:
    zT_278 = name.ptr;
    zT_279 = 0;
    zT_280 = name.len;
    zT_281 = (unsigned int)zT_279 < zT_280;
    if (!(zT_281)) { pal_trap(); }
    zT_282 = zT_278[zT_279];
    if ((unsigned char)(zT_282 == (unsigned char)(105))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_286 = name.ptr;
    zT_287 = 1;
    zT_288 = name.len;
    zT_289 = (unsigned int)zT_287 < zT_288;
    if (!(zT_289)) { pal_trap(); }
    zT_290 = zT_286[zT_287];
    zT_285 = zT_290 == (unsigned char)(115);
    goto z_bb_96;
    z_bb_95:
    zT_285 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_285) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_294 = name.ptr;
    zT_295 = 2;
    zT_296 = name.len;
    zT_297 = (unsigned int)zT_295 < zT_296;
    if (!(zT_297)) { pal_trap(); }
    zT_298 = zT_294[zT_295];
    zT_293 = zT_298 == (unsigned char)(105);
    goto z_bb_99;
    z_bb_98:
    zT_293 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_293) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_302 = name.ptr;
    zT_303 = 3;
    zT_304 = name.len;
    zT_305 = (unsigned int)zT_303 < zT_304;
    if (!(zT_305)) { pal_trap(); }
    zT_306 = zT_302[zT_303];
    zT_301 = zT_306 == (unsigned char)(122);
    goto z_bb_102;
    z_bb_101:
    zT_301 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_301) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_310 = name.ptr;
    zT_311 = 4;
    zT_312 = name.len;
    zT_313 = (unsigned int)zT_311 < zT_312;
    if (!(zT_313)) { pal_trap(); }
    zT_314 = zT_310[zT_311];
    zT_309 = zT_314 == (unsigned char)(101);
    goto z_bb_105;
    z_bb_104:
    zT_309 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_309) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (unsigned int)(12);
    z_bb_107:
    goto z_bb_79;
}

/* growDep */
void zF_62CBE4C7_growDep(zT_3E40CD83_Sand* perm, unsigned int** to_ptr, unsigned int** next_ptr, unsigned int* cap_ptr) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    int zT_13;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_FDFD82FD_EU_362 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int* zT_31;
    zT_3E40CD83_Sand* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zT_FDFD82FD_EU_362 zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int* zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int* zT_55;
    unsigned int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    unsigned int nc;
    unsigned char* ntr;
    unsigned int* nto;
    unsigned char* nnr;
    unsigned int* nno;
    unsigned int ci;
    zT_5 = *cap_ptr;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    nc = zT_7;
    zT_11 = 16;
    if ((unsigned char)(nc < (unsigned int)zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = 16;
    zT_14 = (unsigned int)zT_13;
    nc = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_16 = perm;
    zT_19 = 4;
    zT_20 = (unsigned int)nc;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_19)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_17 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_16, zT_17, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_28 = zT_26.data.payload;
    goto z_bb_5;
    z_bb_5:
    ntr = zT_28;
    zT_31 = (unsigned int*)ntr;
    nto = zT_31;
    zT_33 = perm;
    zT_36 = 4;
    zT_37 = (unsigned int)nc;
    zT_38 = zig_wrap_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_mul_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_34 = zT_38;
    zT_43 = zF_1395EB68_sandAlloc(zT_33, zT_34, (unsigned int)(4));
    zT_44 = zT_43.is_error;
    if (zT_44) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_45 = zT_43.data.payload;
    goto z_bb_8;
    z_bb_8:
    nnr = zT_45;
    zT_48 = (unsigned int*)nnr;
    nno = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    ci = zT_51;
    goto z_bb_9;
    z_bb_9:
    zT_52 = *cap_ptr;
    if ((unsigned char)(ci < (unsigned int)((unsigned int)zT_52))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_55 = *to_ptr;
    zT_56 = zT_55[ci];
    nto[ci] = zT_56;
    zT_57 = *next_ptr;
    zT_58 = zT_57[ci];
    nno[ci] = zT_58;
    goto z_bb_12;
    z_bb_11:
    *to_ptr = nto;
    *next_ptr = nno;
    *cap_ptr = nc;
    return;
    z_bb_12:
    zT_59 = 1;
    zT_60 = (unsigned int)zT_59;
    zT_61 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_60)), 32u);
    zT_62 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_60)), 32u);
    zT_64 = zT_62 == (unsigned int)(0);
    if (!(zT_64)) { pal_trap(); }
    ci = zT_61;
    goto z_bb_9;
}

/* constAliasPrepass */
void zF_EF7F7D3C_constAliasPrepass(zT_3D7259E2_SymbolRegistry* symbol_reg, zT_338B7C76_TypeRegistry* registry, zT_D3EB6303_StringInterner* interner, zT_6B0A7D14_AstStore* store, zT_3E40CD83_Sand* perm_alloc) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_11;
    unsigned int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_060CD1EB_SymbolTable* zT_18;
    zT_060CD1EB_SymbolTable zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_3E40CD83_Sand* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_FDFD82FD_EU_362 zT_61;
    unsigned char zT_62;
    unsigned char* zT_63;
    unsigned int* zT_66;
    zT_3E40CD83_Sand* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    zT_FDFD82FD_EU_362 zT_76;
    unsigned char zT_77;
    unsigned char* zT_78;
    unsigned int* zT_81;
    unsigned int zT_83;
    unsigned int zT_86;
    zT_3E40CD83_Sand* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    zT_FDFD82FD_EU_362 zT_95;
    unsigned char zT_96;
    unsigned char* zT_97;
    unsigned int* zT_100;
    int zT_102;
    unsigned int zT_103;
    int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned char zT_110;
    int zT_112;
    unsigned int zT_113;
    zT_3E40CD83_Sand* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    zT_FDFD82FD_EU_362 zT_123;
    unsigned char zT_124;
    unsigned char* zT_125;
    unsigned int* zT_128;
    int zT_130;
    unsigned int zT_131;
    zT_3E40CD83_Sand* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    zT_FDFD82FD_EU_362 zT_141;
    unsigned char zT_142;
    unsigned char* zT_143;
    unsigned int* zT_146;
    zT_3E40CD83_Sand* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned char zT_155;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned char zT_160;
    zT_FDFD82FD_EU_362 zT_161;
    unsigned char zT_162;
    unsigned char* zT_163;
    unsigned int* zT_166;
    int zT_168;
    unsigned int zT_169;
    int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    zT_060CD1EB_SymbolTable* zT_176;
    zT_060CD1EB_SymbolTable zT_177;
    int zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    zT_3A105EF1_Symbol* zT_184;
    zT_3A105EF1_Symbol* zT_185;
    zT_3C598AEF_SymbolKind zT_186;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned int zT_197;
    int zT_198;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_6B0A7D14_AstStore* zT_206;
    unsigned int zT_207;
    zT_22A7C88B_AstNode zT_209;
    zT_8143F551_AstKind zT_210;
    int zT_211;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    zT_8143F551_AstKind zT_219;
    unsigned int zT_221;
    int zT_222;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    zT_22A7C88B_AstNode zT_233;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    zT_8143F551_AstKind zT_240;
    zT_8143F551_AstKind zT_242;
    int zT_243;
    zT_6B0A7D14_AstStore* zT_246;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned char* zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    zT_D3EB6303_StringInterner* zT_257;
    unsigned int zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    zT_D3EB6303_StringInterner* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    int zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned char zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned char zT_278;
    int zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned char zT_283;
    zT_3E40CD83_Sand* zT_285;
    unsigned int** zT_286;
    unsigned int** zT_287;
    unsigned int* zT_288;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    unsigned char zT_302;
    int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned char zT_308;
    int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned char zT_314;
    int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned char zT_320;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    int zT_327;
    unsigned char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    int zT_335;
    unsigned int zT_336;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_342;
    int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned char zT_347;
    unsigned int zT_348;
    unsigned int zT_350;
    int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned char zT_355;
    int zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    unsigned char zT_360;
    unsigned int zT_361;
    zT_060CD1EB_SymbolTable* zT_363;
    unsigned int zT_364;
    zT_060CD1EB_SymbolTable zT_365;
    zT_3A105EF1_Symbol* zT_367;
    zT_3A105EF1_Symbol* zT_369;
    unsigned int zT_372;
    zT_79FAE712_u64 zT_374;
    zT_79FAE712_u64 zT_375;
    zT_79FAE712_u64 zT_376;
    unsigned int zT_377;
    unsigned char zT_379;
    zT_79FAE712_u64 zT_380;
    zT_79FAE712_u64 zT_381;
    unsigned int zT_382;
    unsigned char zT_384;
    zT_338B7C76_TypeRegistry* zT_385;
    zT_79FAE712_u64 zT_386;
    zT_BAEE192E_Opt_10 zT_387;
    unsigned char zT_388;
    zT_338B7C76_TypeRegistry* zT_392;
    zT_BAEE192E_Opt_10 zT_395;
    unsigned char zT_396;
    int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_79FAE712_u64 zT_406;
    zT_79FAE712_u64 zT_407;
    zT_79FAE712_u64 zT_408;
    unsigned int zT_409;
    unsigned char zT_411;
    zT_79FAE712_u64 zT_412;
    zT_79FAE712_u64 zT_413;
    unsigned int zT_414;
    unsigned char zT_416;
    zT_338B7C76_TypeRegistry* zT_417;
    zT_79FAE712_u64 zT_418;
    zT_BAEE192E_Opt_10 zT_419;
    unsigned char zT_420;
    int zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned char zT_427;
    zT_D3EB6303_StringInterner* zT_431;
    unsigned int zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    zT_79FAE712_u64 zT_441;
    zT_79FAE712_u64 zT_442;
    zT_79FAE712_u64 zT_443;
    unsigned int zT_444;
    unsigned char zT_446;
    zT_79FAE712_u64 zT_447;
    zT_79FAE712_u64 zT_448;
    unsigned int zT_449;
    unsigned char zT_451;
    zT_338B7C76_TypeRegistry* zT_452;
    zT_79FAE712_u64 zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    int zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    unsigned char zT_461;
    int zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned char zT_467;
    unsigned char* zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    unsigned int zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    int zT_473;
    int zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned int zT_478;
    unsigned char zT_480;
    unsigned int zT_482;
    unsigned int zT_483;
    unsigned int zT_485;
    int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    unsigned char zT_490;
    unsigned int zT_491;
    zT_060CD1EB_SymbolTable* zT_493;
    unsigned int zT_494;
    zT_060CD1EB_SymbolTable zT_495;
    zT_3A105EF1_Symbol* zT_497;
    unsigned int zT_498;
    int zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    unsigned char zT_503;
    int zT_504;
    unsigned int zT_505;
    unsigned int zT_506;
    unsigned char zT_508;
    unsigned int zT_509;
    zT_3A105EF1_Symbol* zT_511;
    unsigned int zT_513;
    zT_6B0A7D14_AstStore* zT_515;
    unsigned int zT_516;
    zT_22A7C88B_AstNode zT_518;
    zT_6B0A7D14_AstStore* zT_520;
    unsigned int zT_521;
    unsigned int zT_523;
    zT_D3EB6303_StringInterner* zT_525;
    unsigned int zT_526;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_527;
    zT_D3EB6303_StringInterner* zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    unsigned int zT_531;
    unsigned int zT_533;
    unsigned int zT_534;
    unsigned int zT_537;
    unsigned int zT_538;
    unsigned int zT_540;
    int zT_541;
    unsigned int zT_542;
    unsigned int zT_543;
    unsigned char zT_545;
    unsigned int zT_546;
    unsigned int zT_548;
    int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned char zT_553;
    int zT_554;
    unsigned int zT_555;
    unsigned int zT_556;
    unsigned char zT_558;
    unsigned int zT_559;
    zT_060CD1EB_SymbolTable* zT_561;
    unsigned int zT_562;
    zT_060CD1EB_SymbolTable zT_563;
    zT_3A105EF1_Symbol* zT_565;
    zT_3A105EF1_Symbol* zT_567;
    unsigned int zT_568;
    int zT_569;
    unsigned int zT_574;
    unsigned int zT_575;
    zT_79FAE712_u64 zT_577;
    zT_79FAE712_u64 zT_578;
    zT_79FAE712_u64 zT_579;
    unsigned int zT_580;
    unsigned char zT_582;
    zT_79FAE712_u64 zT_583;
    zT_79FAE712_u64 zT_584;
    unsigned int zT_585;
    unsigned char zT_587;
    zT_338B7C76_TypeRegistry* zT_588;
    zT_79FAE712_u64 zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned char zT_597;
    unsigned int zT_598;
    unsigned int zT_599;
    unsigned char* zT_601;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_602;
    unsigned int zT_603;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_604;
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_95, (unsigned int)sizeof zT_95);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_209, (unsigned int)sizeof zT_209);
    zig_poison_fill((void*)&zT_233, (unsigned int)sizeof zT_233);
    zig_poison_fill((void*)&zT_249, (unsigned int)sizeof zT_249);
    zig_poison_fill((void*)&zT_259, (unsigned int)sizeof zT_259);
    zig_poison_fill((void*)&zT_263, (unsigned int)sizeof zT_263);
    zig_poison_fill((void*)&zT_387, (unsigned int)sizeof zT_387);
    zig_poison_fill((void*)&zT_395, (unsigned int)sizeof zT_395);
    zig_poison_fill((void*)&zT_419, (unsigned int)sizeof zT_419);
    zig_poison_fill((void*)&zT_433, (unsigned int)sizeof zT_433);
    zig_poison_fill((void*)&zT_435, (unsigned int)sizeof zT_435);
    zig_poison_fill((void*)&zT_518, (unsigned int)sizeof zT_518);
    zig_poison_fill((void*)&zT_523, (unsigned int)sizeof zT_523);
    zig_poison_fill((void*)&zT_527, (unsigned int)sizeof zT_527);
    zig_poison_fill((void*)&zT_531, (unsigned int)sizeof zT_531);
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_m;
    unsigned int tl;
    unsigned int cti;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_tm;
    unsigned int SZ_U32;
    unsigned int U32_MAX;
    unsigned int dep_cap;
    unsigned char* dep_to_raw;
    unsigned int* dep_to;
    unsigned char* dep_next_raw;
    unsigned int* dep_next;
    unsigned int head_cap;
    unsigned char* dep_head_raw;
    unsigned int* dep_head;
    unsigned int si0;
    unsigned int dep_count;
    unsigned char* wl_raw;
    unsigned int* wl;
    unsigned int wl_len;
    unsigned char* alias_name_raw;
    unsigned int* alias_name;
    unsigned char* alias_sym_raw;
    unsigned int* alias_sym_id;
    unsigned int alias_count;
    unsigned int mi;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_acm;
    zT_3A105EF1_Symbol* sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u g0_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g1_m;
    zT_22A7C88B_AstNode decl_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u g2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g3_m;
    zT_22A7C88B_AstNode init;
    zT_8F083A69_Slice_zT_0B42B2F8_u c1_m;
    unsigned int dep_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u c2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dep_text;
    unsigned int dep_canonical;
    unsigned int ai;
    unsigned int mod_id;
    unsigned int sym_idx;
    unsigned int resolved;
    zT_79FAE712_u64 mod_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u kst_m;
    unsigned int tid;
    unsigned int cmi;
    zT_79FAE712_u64 ckey;
    zT_8F083A69_Slice_zT_0B42B2F8_u name_str;
    unsigned int resolved_idx;
    unsigned int resolved_mod;
    zT_060CD1EB_SymbolTable resolved_table;
    zT_3A105EF1_Symbol* resolved_sym;
    unsigned int rt;
    unsigned int alias_own_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u alias_own_text;
    unsigned int alias_own_canonical;
    unsigned int edge_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ken_m;
    unsigned int dep_alias_idx;
    unsigned int dep_mod;
    unsigned int dep_sym_idx;
    zT_060CD1EB_SymbolTable dep_table;
    zT_3A105EF1_Symbol* dep_sym;
    zT_79FAE712_u64 dkey;
    zT_6 = "CAP:ent\n";
    zT_8 = 8;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    cap_m = zT_7;
    zT_9 = cap_m;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    tl = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    cti = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = symbol_reg->tables_len;
    if ((unsigned char)(cti < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = symbol_reg->tables_items;
    zT_19 = zT_18[cti];
    zT_20 = zT_19.len;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_add_u(((zu64)(tl)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(tl)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    tl = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_33 = "CAP:tlm";
    zT_35 = 7;
    zT_34.ptr = (unsigned char*)zT_33;
    zT_34.len = zT_35;
    cap_tm = zT_34;
    zT_36 = cap_tm;
    zT_37 = tl;
    zF_C914CB83_markerWriteInt(zT_36, zT_37);
    zT_38 = 0;
    if ((unsigned char)(tl == (unsigned int)zT_38)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zig_wrap_add_u(((zu64)(cti)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(cti)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    cti = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_41 = "CAP:tl0\n";
    zT_43 = 8;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    cap_m = zT_42;
    zT_44 = cap_m;
    zF_48AC7B3A_markerWrite(zT_44);
    return;
    z_bb_6:
    zT_46 = 4;
    zT_47 = (unsigned int)zT_46;
    SZ_U32 = zT_47;
    zT_49 = 4294967295u;
    zT_50 = (unsigned int)zT_49;
    U32_MAX = zT_50;
    dep_cap = tl;
    zT_53 = perm_alloc;
    zT_56 = (unsigned int)tl;
    zT_57 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_54 = zT_57;
    zT_55 = SZ_U32;
    zT_61 = zF_1395EB68_sandAlloc(zT_53, zT_54, zT_55);
    zT_62 = zT_61.is_error;
    if (zT_62) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_63 = zT_61.data.payload;
    goto z_bb_9;
    z_bb_9:
    dep_to_raw = zT_63;
    zT_66 = (unsigned int*)dep_to_raw;
    dep_to = zT_66;
    zT_68 = perm_alloc;
    zT_71 = (unsigned int)tl;
    zT_72 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_71)), 32u);
    zT_73 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_71)), 32u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    zT_69 = zT_72;
    zT_70 = SZ_U32;
    zT_76 = zF_1395EB68_sandAlloc(zT_68, zT_69, zT_70);
    zT_77 = zT_76.is_error;
    if (zT_77) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_78 = zT_76.data.payload;
    goto z_bb_12;
    z_bb_12:
    dep_next_raw = zT_78;
    zT_81 = (unsigned int*)dep_next_raw;
    dep_next = zT_81;
    zT_83 = interner->entries_len;
    head_cap = zT_83;
    if ((unsigned char)(head_cap < (unsigned int)((unsigned int)tl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_86 = (unsigned int)tl;
    head_cap = zT_86;
    goto z_bb_14;
    z_bb_14:
    zT_88 = perm_alloc;
    zT_91 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(head_cap)), 32u);
    zT_92 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(head_cap)), 32u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    zT_89 = zT_91;
    zT_90 = SZ_U32;
    zT_95 = zF_1395EB68_sandAlloc(zT_88, zT_89, zT_90);
    zT_96 = zT_95.is_error;
    if (zT_96) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    pal_trap();
    z_bb_16:
    zT_97 = zT_95.data.payload;
    goto z_bb_17;
    z_bb_17:
    dep_head_raw = zT_97;
    zT_100 = (unsigned int*)dep_head_raw;
    dep_head = zT_100;
    zT_102 = 0;
    zT_103 = (unsigned int)zT_102;
    si0 = zT_103;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(si0 < head_cap)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    dep_head[si0] = U32_MAX;
    goto z_bb_21;
    z_bb_20:
    zT_112 = 0;
    zT_113 = (unsigned int)zT_112;
    dep_count = zT_113;
    zT_115 = perm_alloc;
    zT_118 = (unsigned int)tl;
    zT_119 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_118)), 32u);
    zT_120 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_118)), 32u);
    zT_122 = zT_120 == (unsigned int)(0);
    if (!(zT_122)) { pal_trap(); }
    zT_116 = zT_119;
    zT_117 = SZ_U32;
    zT_123 = zF_1395EB68_sandAlloc(zT_115, zT_116, zT_117);
    zT_124 = zT_123.is_error;
    if (zT_124) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_105 = 1;
    zT_106 = (unsigned int)zT_105;
    zT_107 = zig_wrap_add_u(((zu64)(si0)), ((zu64)(zT_106)), 32u);
    zT_108 = zig_overflow_flag_add_u(((zu64)(si0)), ((zu64)(zT_106)), 32u);
    zT_110 = zT_108 == (unsigned int)(0);
    if (!(zT_110)) { pal_trap(); }
    si0 = zT_107;
    goto z_bb_18;
    z_bb_22:
    pal_trap();
    z_bb_23:
    zT_125 = zT_123.data.payload;
    goto z_bb_24;
    z_bb_24:
    wl_raw = zT_125;
    zT_128 = (unsigned int*)wl_raw;
    wl = zT_128;
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    wl_len = zT_131;
    zT_133 = perm_alloc;
    zT_136 = (unsigned int)tl;
    zT_137 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_136)), 32u);
    zT_138 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_136)), 32u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    zT_134 = zT_137;
    zT_135 = SZ_U32;
    zT_141 = zF_1395EB68_sandAlloc(zT_133, zT_134, zT_135);
    zT_142 = zT_141.is_error;
    if (zT_142) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    pal_trap();
    z_bb_26:
    zT_143 = zT_141.data.payload;
    goto z_bb_27;
    z_bb_27:
    alias_name_raw = zT_143;
    zT_146 = (unsigned int*)alias_name_raw;
    alias_name = zT_146;
    zT_148 = perm_alloc;
    zT_151 = (unsigned int)tl;
    zT_152 = zig_wrap_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_151)), 32u);
    zT_153 = zig_overflow_flag_mul_u(((zu64)(SZ_U32)), ((zu64)(zT_151)), 32u);
    zT_155 = zT_153 == (unsigned int)(0);
    if (!(zT_155)) { pal_trap(); }
    zT_156 = 2;
    zT_157 = zig_wrap_mul_u(((zu64)(zT_152)), ((zu64)(zT_156)), 32u);
    zT_158 = zig_overflow_flag_mul_u(((zu64)(zT_152)), ((zu64)(zT_156)), 32u);
    zT_160 = zT_158 == (unsigned int)(0);
    if (!(zT_160)) { pal_trap(); }
    zT_149 = zT_157;
    zT_150 = SZ_U32;
    zT_161 = zF_1395EB68_sandAlloc(zT_148, zT_149, zT_150);
    zT_162 = zT_161.is_error;
    if (zT_162) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    pal_trap();
    z_bb_29:
    zT_163 = zT_161.data.payload;
    goto z_bb_30;
    z_bb_30:
    alias_sym_raw = zT_163;
    zT_166 = (unsigned int*)alias_sym_raw;
    alias_sym_id = zT_166;
    zT_168 = 0;
    zT_169 = (unsigned int)zT_168;
    alias_count = zT_169;
    zT_171 = 0;
    zT_172 = (unsigned int)zT_171;
    mi = zT_172;
    goto z_bb_31;
    z_bb_31:
    zT_173 = symbol_reg->tables_len;
    if ((unsigned char)(mi < zT_173)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_176 = symbol_reg->tables_items;
    zT_177 = zT_176[mi];
    table = zT_177;
    zT_179 = 0;
    zT_180 = (unsigned int)zT_179;
    si = zT_180;
    goto z_bb_35;
    z_bb_33:
    zT_322 = "CAP:ac";
    zT_324 = 6;
    zT_323.ptr = (unsigned char*)zT_322;
    zT_323.len = zT_324;
    cap_acm = zT_323;
    zT_325 = cap_acm;
    zT_326 = alias_count;
    zF_C914CB83_markerWriteInt(zT_325, zT_326);
    zT_327 = 0;
    if ((unsigned char)(alias_count == (unsigned int)zT_327)) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    zT_315 = 1;
    zT_316 = (unsigned int)zT_315;
    zT_317 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_316)), 32u);
    zT_318 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_316)), 32u);
    zT_320 = zT_318 == (unsigned int)(0);
    if (!(zT_320)) { pal_trap(); }
    mi = zT_317;
    goto z_bb_31;
    z_bb_35:
    zT_181 = table.len;
    if ((unsigned char)(si < zT_181)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_184 = table.items;
    zT_185 = zT_184 + si;
    sym = zT_185;
    zT_186 = sym->kind;
    if ((unsigned char)(zT_186 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_309 = 1;
    zT_310 = (unsigned int)zT_309;
    zT_311 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_310)), 32u);
    zT_312 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_310)), 32u);
    zT_314 = zT_312 == (unsigned int)(0);
    if (!(zT_314)) { pal_trap(); }
    si = zT_311;
    goto z_bb_35;
    z_bb_39:
    goto z_bb_38;
    z_bb_40:
    zT_191 = "GATE:g0";
    zT_193 = 7;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    g0_m = zT_192;
    zT_194 = g0_m;
    zT_195 = sym->type_id;
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_197 = sym->type_id;
    zT_198 = 0;
    if ((unsigned char)(zT_197 != (unsigned int)zT_198)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_201 = "GATE:g1\n";
    zT_203 = 8;
    zT_202.ptr = (unsigned char*)zT_201;
    zT_202.len = zT_203;
    g1_m = zT_202;
    zT_204 = g1_m;
    zF_48AC7B3A_markerWrite(zT_204);
    zT_206 = store;
    zT_207 = sym->decl_node;
    zT_209 = zF_FCDD1D35_astStoreNodeAt(zT_206, zT_207);
    decl_node = zT_209;
    zT_210 = decl_node.kind;
    zT_211 = 1;
    if ((unsigned char)(zT_210 != zT_211)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_214 = "GATE:g2";
    zT_216 = 7;
    zT_215.ptr = (unsigned char*)zT_214;
    zT_215.len = zT_216;
    g2_m = zT_215;
    zT_217 = g2_m;
    zT_219 = decl_node.kind;
    zF_C914CB83_markerWriteInt(zT_217, (unsigned int)((unsigned int)zT_219));
    goto z_bb_38;
    z_bb_44:
    zT_221 = decl_node.child_1;
    zT_222 = 0;
    if ((unsigned char)(zT_221 == (unsigned int)zT_222)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_225 = "GATE:g3\n";
    zT_227 = 8;
    zT_226.ptr = (unsigned char*)zT_225;
    zT_226.len = zT_227;
    g3_m = zT_226;
    zT_228 = g3_m;
    zF_48AC7B3A_markerWrite(zT_228);
    goto z_bb_38;
    z_bb_46:
    zT_230 = store;
    zT_231 = decl_node.child_1;
    zT_233 = zF_FCDD1D35_astStoreNodeAt(zT_230, zT_231);
    init = zT_233;
    zT_235 = "CAT:ik";
    zT_237 = 6;
    zT_236.ptr = (unsigned char*)zT_235;
    zT_236.len = zT_237;
    c1_m = zT_236;
    zT_238 = c1_m;
    zT_240 = init.kind;
    zF_C914CB83_markerWriteInt(zT_238, (unsigned int)((unsigned int)zT_240));
    zT_242 = init.kind;
    zT_243 = 24;
    if ((unsigned char)(zT_242 != zT_243)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_38;
    z_bb_48:
    zT_246 = store;
    zT_247 = decl_node.child_1;
    zT_249 = zF_53458827_astStoreIdentifier(zT_246, zT_247);
    dep_name = zT_249;
    zT_251 = "CAT:dn";
    zT_253 = 6;
    zT_252.ptr = (unsigned char*)zT_251;
    zT_252.len = zT_253;
    c2_m = zT_252;
    zT_254 = c2_m;
    zT_255 = dep_name;
    zF_C914CB83_markerWriteInt(zT_254, zT_255);
    zT_257 = interner;
    zT_258 = dep_name;
    zT_259 = zF_9134020D_stringInternerGet(zT_257, zT_258);
    dep_text = zT_259;
    zT_261 = interner;
    zT_262 = dep_text;
    zT_263 = zF_50C274AF_stringInternerInter(zT_261, zT_262);
    dep_canonical = zT_263;
    zT_264 = (unsigned int)alias_count;
    alias_name[zT_264] = dep_canonical;
    zT_265 = (unsigned int)mi;
    zT_266 = (unsigned int)alias_count;
    zT_267 = 2;
    zT_268 = zig_wrap_mul_u(((zu64)(zT_266)), ((zu64)(zT_267)), 32u);
    zT_269 = zig_overflow_flag_mul_u(((zu64)(zT_266)), ((zu64)(zT_267)), 32u);
    zT_271 = zT_269 == (unsigned int)(0);
    if (!(zT_271)) { pal_trap(); }
    alias_sym_id[zT_268] = zT_265;
    zT_272 = (unsigned int)si;
    zT_273 = (unsigned int)alias_count;
    zT_274 = 2;
    zT_275 = zig_wrap_mul_u(((zu64)(zT_273)), ((zu64)(zT_274)), 32u);
    zT_276 = zig_overflow_flag_mul_u(((zu64)(zT_273)), ((zu64)(zT_274)), 32u);
    zT_278 = zT_276 == (unsigned int)(0);
    if (!(zT_278)) { pal_trap(); }
    zT_279 = 1;
    zT_280 = zig_wrap_add_u(((zu64)(zT_275)), ((zu64)(zT_279)), 32u);
    zT_281 = zig_overflow_flag_add_u(((zu64)(zT_275)), ((zu64)(zT_279)), 32u);
    zT_283 = zT_281 == (unsigned int)(0);
    if (!(zT_283)) { pal_trap(); }
    alias_sym_id[zT_280] = zT_272;
    if ((unsigned char)(dep_count >= dep_cap)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_285 = perm_alloc;
    zT_286 = (unsigned int**)&dep_to;
    zT_287 = (unsigned int**)&dep_next;
    zT_288 = (unsigned int*)&dep_cap;
    zF_62CBE4C7_growDep(zT_285, zT_286, zT_287, zT_288);
    goto z_bb_50;
    z_bb_50:
    zT_292 = (unsigned int)dep_count;
    dep_to[zT_292] = alias_count;
    zT_293 = (unsigned int)dep_canonical;
    zT_294 = dep_head[zT_293];
    zT_295 = (unsigned int)dep_count;
    dep_next[zT_295] = zT_294;
    zT_296 = (unsigned int)dep_canonical;
    dep_head[zT_296] = dep_count;
    zT_297 = 1;
    zT_298 = (unsigned int)zT_297;
    zT_299 = zig_wrap_add_u(((zu64)(dep_count)), ((zu64)(zT_298)), 32u);
    zT_300 = zig_overflow_flag_add_u(((zu64)(dep_count)), ((zu64)(zT_298)), 32u);
    zT_302 = zT_300 == (unsigned int)(0);
    if (!(zT_302)) { pal_trap(); }
    dep_count = zT_299;
    zT_303 = 1;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zig_wrap_add_u(((zu64)(alias_count)), ((zu64)(zT_304)), 32u);
    zT_306 = zig_overflow_flag_add_u(((zu64)(alias_count)), ((zu64)(zT_304)), 32u);
    zT_308 = zT_306 == (unsigned int)(0);
    if (!(zT_308)) { pal_trap(); }
    alias_count = zT_305;
    goto z_bb_38;
    z_bb_51:
    zT_330 = "CAP:ac0\n";
    zT_332 = 8;
    zT_331.ptr = (unsigned char*)zT_330;
    zT_331.len = zT_332;
    cap_m = zT_331;
    zT_333 = cap_m;
    zF_48AC7B3A_markerWrite(zT_333);
    return;
    z_bb_52:
    zT_335 = 0;
    zT_336 = (unsigned int)zT_335;
    ai = zT_336;
    goto z_bb_53;
    z_bb_53:
    if ((unsigned char)(ai < alias_count)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_339 = (unsigned int)ai;
    zT_340 = alias_name[zT_339];
    dep_name = zT_340;
    zT_342 = (unsigned int)ai;
    zT_343 = 2;
    zT_344 = zig_wrap_mul_u(((zu64)(zT_342)), ((zu64)(zT_343)), 32u);
    zT_345 = zig_overflow_flag_mul_u(((zu64)(zT_342)), ((zu64)(zT_343)), 32u);
    zT_347 = zT_345 == (unsigned int)(0);
    if (!(zT_347)) { pal_trap(); }
    zT_348 = alias_sym_id[zT_344];
    mod_id = zT_348;
    zT_350 = (unsigned int)ai;
    zT_351 = 2;
    zT_352 = zig_wrap_mul_u(((zu64)(zT_350)), ((zu64)(zT_351)), 32u);
    zT_353 = zig_overflow_flag_mul_u(((zu64)(zT_350)), ((zu64)(zT_351)), 32u);
    zT_355 = zT_353 == (unsigned int)(0);
    if (!(zT_355)) { pal_trap(); }
    zT_356 = 1;
    zT_357 = zig_wrap_add_u(((zu64)(zT_352)), ((zu64)(zT_356)), 32u);
    zT_358 = zig_overflow_flag_add_u(((zu64)(zT_352)), ((zu64)(zT_356)), 32u);
    zT_360 = zT_358 == (unsigned int)(0);
    if (!(zT_360)) { pal_trap(); }
    zT_361 = alias_sym_id[zT_357];
    sym_idx = zT_361;
    zT_363 = symbol_reg->tables_items;
    zT_364 = (unsigned int)mod_id;
    zT_365 = zT_363[zT_364];
    table = zT_365;
    zT_367 = table.items;
    zT_369 = zT_367 + (unsigned int)((unsigned int)sym_idx);
    sym = zT_369;
    zT_372 = 18;
    resolved = zT_372;
    zT_374 = (zT_79FAE712_u64)mod_id;
    zT_375 = Z98_U64_C(4294967296);
    zT_376 = zig_wrap_mul_u(((zu64)(zT_374)), ((zu64)(zT_375)), 64u);
    zT_377 = zig_overflow_flag_mul_u(((zu64)(zT_374)), ((zu64)(zT_375)), 64u);
    zT_379 = zT_377 == (unsigned int)(0);
    if (!(zT_379)) { pal_trap(); }
    zT_380 = (zT_79FAE712_u64)dep_name;
    zT_381 = zig_wrap_add_u(((zu64)(zT_376)), ((zu64)(zT_380)), 64u);
    zT_382 = zig_overflow_flag_add_u(((zu64)(zT_376)), ((zu64)(zT_380)), 64u);
    zT_384 = zT_382 == (unsigned int)(0);
    if (!(zT_384)) { pal_trap(); }
    mod_key = zT_381;
    zT_385 = registry;
    zT_386 = mod_key;
    zT_387 = zF_0EB68360_nameCacheGet(zT_385, zT_386);
    zT_388 = zT_387.has_value;
    if (zT_388) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    zT_469 = "KAHN:start\n";
    zT_471 = 11;
    zT_470.ptr = (unsigned char*)zT_469;
    zT_470.len = zT_471;
    kst_m = zT_470;
    zT_472 = kst_m;
    zF_48AC7B3A_markerWrite(zT_472);
    goto z_bb_75;
    z_bb_56:
    zT_462 = 1;
    zT_463 = (unsigned int)zT_462;
    zT_464 = zig_wrap_add_u(((zu64)(ai)), ((zu64)(zT_463)), 32u);
    zT_465 = zig_overflow_flag_add_u(((zu64)(ai)), ((zu64)(zT_463)), 32u);
    zT_467 = zT_465 == (unsigned int)(0);
    if (!(zT_467)) { pal_trap(); }
    ai = zT_464;
    goto z_bb_53;
    z_bb_57:
    if (!(zT_387.has_value)) { pal_trap(); }
    tid = zT_387.value;
    resolved = tid;
    goto z_bb_58;
    z_bb_58:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_392 = registry;
    zT_395 = zF_0EB68360_nameCacheGet(zT_392, (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name));
    zT_396 = zT_395.has_value;
    if (zT_396) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    if (!(zT_395.has_value)) { pal_trap(); }
    tid = zT_395.value;
    resolved = tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_401 = 0;
    zT_402 = (unsigned int)zT_401;
    cmi = zT_402;
    goto z_bb_65;
    z_bb_64:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_71; else goto z_bb_72;
    z_bb_65:
    zT_403 = symbol_reg->tables_len;
    if ((unsigned char)(cmi < zT_403)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_406 = (zT_79FAE712_u64)cmi;
    zT_407 = Z98_U64_C(4294967296);
    zT_408 = zig_wrap_mul_u(((zu64)(zT_406)), ((zu64)(zT_407)), 64u);
    zT_409 = zig_overflow_flag_mul_u(((zu64)(zT_406)), ((zu64)(zT_407)), 64u);
    zT_411 = zT_409 == (unsigned int)(0);
    if (!(zT_411)) { pal_trap(); }
    zT_412 = (zT_79FAE712_u64)dep_name;
    zT_413 = zig_wrap_add_u(((zu64)(zT_408)), ((zu64)(zT_412)), 64u);
    zT_414 = zig_overflow_flag_add_u(((zu64)(zT_408)), ((zu64)(zT_412)), 64u);
    zT_416 = zT_414 == (unsigned int)(0);
    if (!(zT_416)) { pal_trap(); }
    ckey = zT_413;
    zT_417 = registry;
    zT_418 = ckey;
    zT_419 = zF_0EB68360_nameCacheGet(zT_417, zT_418);
    zT_420 = zT_419.has_value;
    if (zT_420) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_422 = 1;
    zT_423 = (unsigned int)zT_422;
    zT_424 = zig_wrap_add_u(((zu64)(cmi)), ((zu64)(zT_423)), 32u);
    zT_425 = zig_overflow_flag_add_u(((zu64)(cmi)), ((zu64)(zT_423)), 32u);
    zT_427 = zT_425 == (unsigned int)(0);
    if (!(zT_427)) { pal_trap(); }
    cmi = zT_424;
    goto z_bb_65;
    z_bb_69:
    if (!(zT_419.has_value)) { pal_trap(); }
    tid = zT_419.value;
    resolved = tid;
    goto z_bb_67;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_431 = interner;
    zT_432 = dep_name;
    zT_433 = zF_9134020D_stringInternerGet(zT_431, zT_432);
    name_str = zT_433;
    zT_434 = name_str;
    zT_435 = zF_0D410D69_resolveWellKnownTyp(zT_434);
    resolved = zT_435;
    goto z_bb_72;
    z_bb_72:
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    sym->type_id = resolved;
    sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_441 = (zT_79FAE712_u64)mod_id;
    zT_442 = Z98_U64_C(4294967296);
    zT_443 = zig_wrap_mul_u(((zu64)(zT_441)), ((zu64)(zT_442)), 64u);
    zT_444 = zig_overflow_flag_mul_u(((zu64)(zT_441)), ((zu64)(zT_442)), 64u);
    zT_446 = zT_444 == (unsigned int)(0);
    if (!(zT_446)) { pal_trap(); }
    zT_447 = (zT_79FAE712_u64)dep_name;
    zT_448 = zig_wrap_add_u(((zu64)(zT_443)), ((zu64)(zT_447)), 64u);
    zT_449 = zig_overflow_flag_add_u(((zu64)(zT_443)), ((zu64)(zT_447)), 64u);
    zT_451 = zT_449 == (unsigned int)(0);
    if (!(zT_451)) { pal_trap(); }
    ckey = zT_448;
    zT_452 = registry;
    zT_453 = ckey;
    zT_454 = resolved;
    zF_5E95558D_nameCachePut(zT_452, zT_453, zT_454);
    zT_455 = (unsigned int)wl_len;
    wl[zT_455] = ai;
    zT_456 = 1;
    zT_457 = (unsigned int)zT_456;
    zT_458 = zig_wrap_add_u(((zu64)(wl_len)), ((zu64)(zT_457)), 32u);
    zT_459 = zig_overflow_flag_add_u(((zu64)(wl_len)), ((zu64)(zT_457)), 32u);
    zT_461 = zT_459 == (unsigned int)(0);
    if (!(zT_461)) { pal_trap(); }
    wl_len = zT_458;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_56;
    z_bb_75:
    zT_473 = 0;
    if ((unsigned char)(wl_len > (unsigned int)zT_473)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_475 = 1;
    zT_476 = (unsigned int)zT_475;
    zT_477 = zig_wrap_sub_u(((zu64)(wl_len)), ((zu64)(zT_476)), 32u);
    zT_478 = zig_overflow_flag_sub_u(((zu64)(wl_len)), ((zu64)(zT_476)), 32u);
    zT_480 = zT_478 == (unsigned int)(0);
    if (!(zT_480)) { pal_trap(); }
    wl_len = zT_477;
    zT_482 = (unsigned int)wl_len;
    zT_483 = wl[zT_482];
    resolved_idx = zT_483;
    zT_485 = (unsigned int)resolved_idx;
    zT_486 = 2;
    zT_487 = zig_wrap_mul_u(((zu64)(zT_485)), ((zu64)(zT_486)), 32u);
    zT_488 = zig_overflow_flag_mul_u(((zu64)(zT_485)), ((zu64)(zT_486)), 32u);
    zT_490 = zT_488 == (unsigned int)(0);
    if (!(zT_490)) { pal_trap(); }
    zT_491 = alias_sym_id[zT_487];
    resolved_mod = zT_491;
    zT_493 = symbol_reg->tables_items;
    zT_494 = (unsigned int)resolved_mod;
    zT_495 = zT_493[zT_494];
    resolved_table = zT_495;
    zT_497 = resolved_table.items;
    zT_498 = (unsigned int)resolved_idx;
    zT_499 = 2;
    zT_500 = zig_wrap_mul_u(((zu64)(zT_498)), ((zu64)(zT_499)), 32u);
    zT_501 = zig_overflow_flag_mul_u(((zu64)(zT_498)), ((zu64)(zT_499)), 32u);
    zT_503 = zT_501 == (unsigned int)(0);
    if (!(zT_503)) { pal_trap(); }
    zT_504 = 1;
    zT_505 = zig_wrap_add_u(((zu64)(zT_500)), ((zu64)(zT_504)), 32u);
    zT_506 = zig_overflow_flag_add_u(((zu64)(zT_500)), ((zu64)(zT_504)), 32u);
    zT_508 = zT_506 == (unsigned int)(0);
    if (!(zT_508)) { pal_trap(); }
    zT_509 = alias_sym_id[zT_505];
    zT_511 = zT_497 + (unsigned int)((unsigned int)zT_509);
    resolved_sym = zT_511;
    zT_513 = resolved_sym->type_id;
    rt = zT_513;
    zT_515 = store;
    zT_516 = resolved_sym->decl_node;
    zT_518 = zF_FCDD1D35_astStoreNodeAt(zT_515, zT_516);
    decl_node = zT_518;
    zT_520 = store;
    zT_521 = resolved_sym->decl_node;
    zT_523 = zF_8BA26B9E_astStoreNodePayload(zT_520, zT_521);
    alias_own_name = zT_523;
    zT_525 = interner;
    zT_526 = alias_own_name;
    zT_527 = zF_9134020D_stringInternerGet(zT_525, zT_526);
    alias_own_text = zT_527;
    zT_529 = interner;
    zT_530 = alias_own_text;
    zT_531 = zF_50C274AF_stringInternerInter(zT_529, zT_530);
    alias_own_canonical = zT_531;
    zT_533 = (unsigned int)alias_own_canonical;
    zT_534 = dep_head[zT_533];
    edge_idx = zT_534;
    goto z_bb_79;
    z_bb_77:
    zT_601 = "KAHN:end\n";
    zT_603 = 9;
    zT_602.ptr = (unsigned char*)zT_601;
    zT_602.len = zT_603;
    ken_m = zT_602;
    zT_604 = ken_m;
    zF_48AC7B3A_markerWrite(zT_604);
    return;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    if ((unsigned char)(edge_idx != U32_MAX)) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_537 = (unsigned int)edge_idx;
    zT_538 = dep_to[zT_537];
    dep_alias_idx = zT_538;
    zT_540 = (unsigned int)dep_alias_idx;
    zT_541 = 2;
    zT_542 = zig_wrap_mul_u(((zu64)(zT_540)), ((zu64)(zT_541)), 32u);
    zT_543 = zig_overflow_flag_mul_u(((zu64)(zT_540)), ((zu64)(zT_541)), 32u);
    zT_545 = zT_543 == (unsigned int)(0);
    if (!(zT_545)) { pal_trap(); }
    zT_546 = alias_sym_id[zT_542];
    dep_mod = zT_546;
    zT_548 = (unsigned int)dep_alias_idx;
    zT_549 = 2;
    zT_550 = zig_wrap_mul_u(((zu64)(zT_548)), ((zu64)(zT_549)), 32u);
    zT_551 = zig_overflow_flag_mul_u(((zu64)(zT_548)), ((zu64)(zT_549)), 32u);
    zT_553 = zT_551 == (unsigned int)(0);
    if (!(zT_553)) { pal_trap(); }
    zT_554 = 1;
    zT_555 = zig_wrap_add_u(((zu64)(zT_550)), ((zu64)(zT_554)), 32u);
    zT_556 = zig_overflow_flag_add_u(((zu64)(zT_550)), ((zu64)(zT_554)), 32u);
    zT_558 = zT_556 == (unsigned int)(0);
    if (!(zT_558)) { pal_trap(); }
    zT_559 = alias_sym_id[zT_555];
    dep_sym_idx = zT_559;
    zT_561 = symbol_reg->tables_items;
    zT_562 = (unsigned int)dep_mod;
    zT_563 = zT_561[zT_562];
    dep_table = zT_563;
    zT_565 = dep_table.items;
    zT_567 = zT_565 + (unsigned int)((unsigned int)dep_sym_idx);
    dep_sym = zT_567;
    zT_568 = dep_sym->type_id;
    zT_569 = 0;
    if ((unsigned char)(zT_568 == (unsigned int)zT_569)) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    dep_sym->type_id = rt;
    dep_sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_574 = (unsigned int)dep_alias_idx;
    zT_575 = alias_name[zT_574];
    dep_name = zT_575;
    zT_577 = (zT_79FAE712_u64)dep_mod;
    zT_578 = Z98_U64_C(4294967296);
    zT_579 = zig_wrap_mul_u(((zu64)(zT_577)), ((zu64)(zT_578)), 64u);
    zT_580 = zig_overflow_flag_mul_u(((zu64)(zT_577)), ((zu64)(zT_578)), 64u);
    zT_582 = zT_580 == (unsigned int)(0);
    if (!(zT_582)) { pal_trap(); }
    zT_583 = (zT_79FAE712_u64)dep_name;
    zT_584 = zig_wrap_add_u(((zu64)(zT_579)), ((zu64)(zT_583)), 64u);
    zT_585 = zig_overflow_flag_add_u(((zu64)(zT_579)), ((zu64)(zT_583)), 64u);
    zT_587 = zT_585 == (unsigned int)(0);
    if (!(zT_587)) { pal_trap(); }
    dkey = zT_584;
    zT_588 = registry;
    zT_589 = dkey;
    zT_590 = rt;
    zF_5E95558D_nameCachePut(zT_588, zT_589, zT_590);
    zT_591 = (unsigned int)wl_len;
    wl[zT_591] = dep_alias_idx;
    zT_592 = 1;
    zT_593 = (unsigned int)zT_592;
    zT_594 = zig_wrap_add_u(((zu64)(wl_len)), ((zu64)(zT_593)), 32u);
    zT_595 = zig_overflow_flag_add_u(((zu64)(wl_len)), ((zu64)(zT_593)), 32u);
    zT_597 = zT_595 == (unsigned int)(0);
    if (!(zT_597)) { pal_trap(); }
    wl_len = zT_594;
    goto z_bb_84;
    z_bb_84:
    zT_598 = (unsigned int)edge_idx;
    zT_599 = dep_next[zT_598];
    edge_idx = zT_599;
    goto z_bb_82;
}

/* __module_init */
void zF_780653D2___module_init_15(void) {
    zT_3D7259E2_SymbolRegistry zT_0;
    zT_060CD1EB_SymbolTable zT_1;
    zT_338B7C76_TypeRegistry zT_2;
    zT_D3EB6303_StringInterner zT_3;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_060CD1EB_SymbolTable = zT_1;
    zG_338B7C76_TypeRegistry = zT_2;
    zG_D3EB6303_StringInterner = zT_3;
    return;
}

/* EOF */
