#include "lir_64CB5435.h"
zT_CA01C129_LirSlotArrayList zG_CA01C129_LirSlotArrayList;
unsigned char const zG_85047B93_CHECK_OP_ADD = (unsigned char)(0);
unsigned char const zG_92FF6172_CHECK_OP_SUB = (unsigned char)(1);
unsigned char const zG_08A9DD8E_CHECK_OP_MUL = (unsigned char)(2);
unsigned char const zG_DB0C9EBD_CHECK_OP_SHL = (unsigned char)(3);
unsigned char const zG_5C81A75E_CHECK_OP_NEG = (unsigned char)(4);
zT_BBC23664_LirFunction zG_BBC23664_LirFunction;
zT_E7714190_LirSlot zG_E7714190_LirSlot;
zT_6BA597BC_LirInst zG_6BA597BC_LirInst;
/* lirSideEntryArrayListInit */
zT_AC00B5F6_LirSideEntryArrayLi zF_4231AD2C_lirSideEntryArrayLi(zT_3E40CD83_Sand* allocator) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_A8A5B231_LirSideEntry*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirSideEntryArrayListEnsureCapacity */
void zF_B5A8F8E4_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_A8A5B231_LirSideEntry* zT_37;
    zT_A8A5B231_LirSideEntry* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_A8A5B231_LirSideEntry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_99DE57BF_Slice_zT_A8A5B231_L zT_44;
    zT_A8A5B231_LirSideEntry* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_A8A5B231_LirSideEntry* new_items;
    zT_A8A5B231_LirSideEntry item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 32;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_A8A5B231_LirSideEntry*)raw;
    new_items = zT_37;
    zT_38 = (zT_A8A5B231_LirSideEntry*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_A8A5B231_LirSideEntry*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_A8A5B231_LirSideEntry*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* lirSideEntryArrayListAppend */
void zF_6E2511C2_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self, zT_A8A5B231_LirSideEntry value) {
    zT_AC00B5F6_LirSideEntryArrayLi* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_A8A5B231_LirSideEntry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_B5A8F8E4_lirSideEntryArrayLi(zT_2, zT_3);
    zT_10 = (zT_A8A5B231_LirSideEntry*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* lirSideEntryArrayListGetSlice */
zT_99DE57BF_Slice_zT_A8A5B231_L zF_AC1429C8_lirSideEntryArrayLi(zT_AC00B5F6_LirSideEntryArrayLi* self) {
    zT_A8A5B231_LirSideEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_A8A5B231_LirSideEntry* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_99DE57BF_Slice_zT_A8A5B231_L zT_7;
    zT_1 = (zT_A8A5B231_LirSideEntry*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_A8A5B231_LirSideEntry*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* debugSpanArrayListInit */
zT_1F328BC1_DebugSpanArrayList zF_48A72C7F_debugSpanArrayListI(zT_3E40CD83_Sand* allocator) {
    zT_1F328BC1_DebugSpanArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_10BDA76C_DebugSpanEntry*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* debugSpanArrayListEnsureCapacity */
void zF_422886F7_debugSpanArrayListE(zT_1F328BC1_DebugSpanArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_10BDA76C_DebugSpanEntry* zT_37;
    zT_10BDA76C_DebugSpanEntry* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_10BDA76C_DebugSpanEntry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_44;
    zT_10BDA76C_DebugSpanEntry* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_10BDA76C_DebugSpanEntry* new_items;
    zT_10BDA76C_DebugSpanEntry item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 12;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_10BDA76C_DebugSpanEntry*)raw;
    new_items = zT_37;
    zT_38 = (zT_10BDA76C_DebugSpanEntry*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_10BDA76C_DebugSpanEntry*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* debugSpanArrayListAppend */
void zF_B5AA64A5_debugSpanArrayListA(zT_1F328BC1_DebugSpanArrayList* self, zT_10BDA76C_DebugSpanEntry value) {
    zT_1F328BC1_DebugSpanArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_10BDA76C_DebugSpanEntry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_422886F7_debugSpanArrayListE(zT_2, zT_3);
    zT_10 = (zT_10BDA76C_DebugSpanEntry*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* debugSpanArrayListGetSlice */
zT_34BFE5CB_Slice_zT_10BDA76C_D zF_17E5D29B_debugSpanArrayListG(zT_1F328BC1_DebugSpanArrayList* self) {
    zT_10BDA76C_DebugSpanEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_10BDA76C_DebugSpanEntry* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_7;
    zT_1 = (zT_10BDA76C_DebugSpanEntry*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* lirInstArrayListInit */
zT_DAE4631D_LirInstArrayList zF_C6E3B5BB_lirInstArrayListIni(zT_3E40CD83_Sand* allocator) {
    zT_DAE4631D_LirInstArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_6BA597BC_LirInst*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirInstArrayListEnsureCapacity */
void zF_178C876B_lirInstArrayListEns(zT_DAE4631D_LirInstArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_6BA597BC_LirInst* zT_37;
    zT_6BA597BC_LirInst* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_6BA597BC_LirInst* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_804A8058_Slice_zT_6BA597BC_L zT_44;
    zT_6BA597BC_LirInst* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_6BA597BC_LirInst* new_items;
    zT_6BA597BC_LirInst item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 32;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_6BA597BC_LirInst*)raw;
    new_items = zT_37;
    zT_38 = (zT_6BA597BC_LirInst*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_6BA597BC_LirInst*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_6BA597BC_LirInst*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* lirInstArrayListAppend */
void zF_4BFD6009_lirInstArrayListApp(zT_DAE4631D_LirInstArrayList* self, zT_6BA597BC_LirInst value) {
    zT_DAE4631D_LirInstArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_6BA597BC_LirInst* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_178C876B_lirInstArrayListEns(zT_2, zT_3);
    zT_10 = (zT_6BA597BC_LirInst*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* lirInstArrayListGetSlice */
zT_804A8058_Slice_zT_6BA597BC_L zF_33BACEFF_lirInstArrayListGet(zT_DAE4631D_LirInstArrayList* self) {
    zT_6BA597BC_LirInst* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6BA597BC_LirInst* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_804A8058_Slice_zT_6BA597BC_L zT_7;
    zT_1 = (zT_6BA597BC_LirInst*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_6BA597BC_LirInst*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* basicBlockArrayListInit */
zT_1CF28CA3_BasicBlockArrayList zF_2B78727D_basicBlockArrayList(zT_3E40CD83_Sand* allocator) {
    zT_1CF28CA3_BasicBlockArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_88A68B1A_BasicBlock*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* basicBlockArrayListEnsureCapacity */
void zF_DFD16D95_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_88A68B1A_BasicBlock* zT_37;
    zT_88A68B1A_BasicBlock* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_88A68B1A_BasicBlock* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_A12E931C_Slice_zT_88A68B1A_B zT_44;
    zT_88A68B1A_BasicBlock* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_88A68B1A_BasicBlock* new_items;
    zT_88A68B1A_BasicBlock item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 24;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_88A68B1A_BasicBlock*)raw;
    new_items = zT_37;
    zT_38 = (zT_88A68B1A_BasicBlock*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_88A68B1A_BasicBlock*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_88A68B1A_BasicBlock*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* basicBlockArrayListAppend */
void zF_09D85813_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self, zT_88A68B1A_BasicBlock value) {
    zT_1CF28CA3_BasicBlockArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_88A68B1A_BasicBlock* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_DFD16D95_basicBlockArrayList(zT_2, zT_3);
    zT_10 = (zT_88A68B1A_BasicBlock*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* basicBlockArrayListGetSlice */
zT_A12E931C_Slice_zT_88A68B1A_B zF_EF689609_basicBlockArrayList(zT_1CF28CA3_BasicBlockArrayList* self) {
    zT_88A68B1A_BasicBlock* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_88A68B1A_BasicBlock* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_A12E931C_Slice_zT_88A68B1A_B zT_7;
    zT_1 = (zT_88A68B1A_BasicBlock*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_88A68B1A_BasicBlock*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* lirParamArrayListInit */
zT_CFE23D0A_LirParamArrayList zF_0ED358C0_lirParamArrayListIn(zT_3E40CD83_Sand* allocator) {
    zT_CFE23D0A_LirParamArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_8779209D_LirParam*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirParamArrayListEnsureCapacity */
void zF_D7BA6100_lirParamArrayListEn(zT_CFE23D0A_LirParamArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_8779209D_LirParam* zT_37;
    zT_8779209D_LirParam* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_8779209D_LirParam* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_2F054080_Slice_zT_8779209D_L zT_44;
    zT_8779209D_LirParam* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_8779209D_LirParam* new_items;
    zT_8779209D_LirParam item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 12;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_8779209D_LirParam*)raw;
    new_items = zT_37;
    zT_38 = (zT_8779209D_LirParam*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_8779209D_LirParam*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_8779209D_LirParam*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* lirParamArrayListAppend */
void zF_5266C13E_lirParamArrayListAp(zT_CFE23D0A_LirParamArrayList* self, zT_8779209D_LirParam value) {
    zT_CFE23D0A_LirParamArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_8779209D_LirParam* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_D7BA6100_lirParamArrayListEn(zT_2, zT_3);
    zT_10 = (zT_8779209D_LirParam*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* lirParamArrayListGetSlice */
zT_2F054080_Slice_zT_8779209D_L zF_DFC53FA4_lirParamArrayListGe(zT_CFE23D0A_LirParamArrayList* self) {
    zT_8779209D_LirParam* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_8779209D_LirParam* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_2F054080_Slice_zT_8779209D_L zT_7;
    zT_1 = (zT_8779209D_LirParam*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_8779209D_LirParam*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* tempDeclArrayListInit */
zT_5D72FBF8_TempDeclArrayList zF_DE63156A_tempDeclArrayListIn(zT_3E40CD83_Sand* allocator) {
    zT_5D72FBF8_TempDeclArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_1937645B_TempDecl*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* tempDeclArrayListEnsureCapacity */
void zF_2A1781A2_tempDeclArrayListEn(zT_5D72FBF8_TempDeclArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_1937645B_TempDecl* zT_37;
    zT_1937645B_TempDecl* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_1937645B_TempDecl* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_732DFD13_Slice_zT_1937645B_T zT_44;
    zT_1937645B_TempDecl* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_1937645B_TempDecl* new_items;
    zT_1937645B_TempDecl item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 8;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_1937645B_TempDecl*)raw;
    new_items = zT_37;
    zT_38 = (zT_1937645B_TempDecl*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_1937645B_TempDecl*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_1937645B_TempDecl*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* tempDeclArrayListAppend */
void zF_70DD3460_tempDeclArrayListAp(zT_5D72FBF8_TempDeclArrayList* self, zT_1937645B_TempDecl value) {
    zT_5D72FBF8_TempDeclArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_1937645B_TempDecl* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_2A1781A2_tempDeclArrayListEn(zT_2, zT_3);
    zT_10 = (zT_1937645B_TempDecl*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* tempDeclArrayListGetSlice */
zT_732DFD13_Slice_zT_1937645B_T zF_5450447E_tempDeclArrayListGe(zT_5D72FBF8_TempDeclArrayList* self) {
    zT_1937645B_TempDecl* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_1937645B_TempDecl* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_732DFD13_Slice_zT_1937645B_T zT_7;
    zT_1 = (zT_1937645B_TempDecl*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_1937645B_TempDecl*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* switchCaseArrayListInit */
zT_9F514E82_SwitchCaseArrayList zF_64707188_switchCaseArrayList(zT_3E40CD83_Sand* allocator) {
    zT_9F514E82_SwitchCaseArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_4BD97095_SwitchCase*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* switchCaseArrayListEnsureCapacity */
void zF_937B1D28_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_4BD97095_SwitchCase* zT_37;
    zT_4BD97095_SwitchCase* zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_4BD97095_SwitchCase* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_11D00852_Slice_zT_4BD97095_S zT_44;
    zT_4BD97095_SwitchCase* zT_45;
    unsigned int zT_46;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_4BD97095_SwitchCase* new_items;
    zT_4BD97095_SwitchCase item;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 16;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_4BD97095_SwitchCase*)raw;
    new_items = zT_37;
    zT_38 = (zT_4BD97095_SwitchCase*)self->items;
    zT_39 = self->len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (zT_4BD97095_SwitchCase*)zT_41;
    zT_44.len = zT_42;
    zT_45 = (zT_4BD97095_SwitchCase*)zT_44.ptr;
    zT_46 = zT_44.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_45[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_51 = i + (unsigned int)(1);
    i = zT_51;
    goto z_bb_10;
}

/* switchCaseArrayListAppend */
void zF_AFFB7306_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self, zT_4BD97095_SwitchCase value) {
    zT_9F514E82_SwitchCaseArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_4BD97095_SwitchCase* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_937B1D28_switchCaseArrayList(zT_2, zT_3);
    zT_10 = (zT_4BD97095_SwitchCase*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* switchCaseArrayListGetSlice */
zT_11D00852_Slice_zT_4BD97095_S zF_82C0CEBC_switchCaseArrayList(zT_9F514E82_SwitchCaseArrayList* self) {
    zT_4BD97095_SwitchCase* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_4BD97095_SwitchCase* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_11D00852_Slice_zT_4BD97095_S zT_7;
    zT_1 = (zT_4BD97095_SwitchCase*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_4BD97095_SwitchCase*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* lirSlotArrayListInit */
zT_CA01C129_LirSlotArrayList zF_F91F6677_lirSlotArrayListIni(zT_3E40CD83_Sand* allocator) {
    zT_CA01C129_LirSlotArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_E7714190_LirSlot*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* lirSlotArrayListEnsureCapacity */
void zF_851221CF_lirSlotArrayListEns(zT_CA01C129_LirSlotArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_FDFD82FD_EU_362 zT_32;
    unsigned char zT_33;
    unsigned char* zT_34;
    zT_E7714190_LirSlot* zT_37;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_E7714190_LirSlot* zT_42;
    zT_E7714190_LirSlot zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned int new_cap;
    unsigned char* raw;
    zT_E7714190_LirSlot* new_items;
    unsigned int i;
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 4;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->allocator;
    zT_26 = 12;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(new_cap)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_23 = zT_27;
    zT_32 = zF_1395EB68_sandAlloc(zT_22, zT_23, (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_34 = zT_32.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_34;
    zT_37 = (zT_E7714190_LirSlot*)raw;
    new_items = zT_37;
    zT_39 = 0;
    i = zT_39;
    goto z_bb_10;
    z_bb_10: ;
    zT_40 = self->len;
    if ((unsigned char)(i < zT_40)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    zT_42 = (zT_E7714190_LirSlot*)self->items;
    zT_43 = zT_42[i];
    new_items[i] = zT_43;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_44 = 1;
    zT_45 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    i = zT_45;
    goto z_bb_10;
}

/* lirSlotArrayListAppend */
void zF_BD1C46FD_lirSlotArrayListApp(zT_CA01C129_LirSlotArrayList* self, zT_E7714190_LirSlot value) {
    zT_CA01C129_LirSlotArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_E7714190_LirSlot* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_851221CF_lirSlotArrayListEns(zT_2, zT_3);
    zT_10 = (zT_E7714190_LirSlot*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* lirSlotArrayListGetSlice */
zT_E44058BB_Slice_zT_E7714190_L zF_8E0BDF63_lirSlotArrayListGet(zT_CA01C129_LirSlotArrayList* self) {
    zT_E7714190_LirSlot* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_E7714190_LirSlot* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_E44058BB_Slice_zT_E7714190_L zT_7;
    zT_1 = (zT_E7714190_LirSlot*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_E7714190_LirSlot*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* lirSideAppendCallDirect */
unsigned int zF_F05FBDC6_lirSideAppendCallDi(zT_BBC23664_LirFunction* lfn, zT_3BFB1E70_CallDirectData d) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_AC00B5F6_LirSideEntryArrayLi* zT_6;
    zT_A8A5B231_LirSideEntry zT_7;
    zT_A8A5B231_LirSideEntry zT_9;
    unsigned int slot;
    zT_3 = lfn->side_table;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    slot = zT_5;
    zT_6 = &lfn->side_table;
    zT_9.call_direct = d;
    zT_7 = zT_9;
    zF_6E2511C2_lirSideEntryArrayLi(zT_6, zT_7);
    return slot;
}

/* lirSideAppendTailCall */
unsigned int zF_79C20A59_lirSideAppendTailCa(zT_BBC23664_LirFunction* lfn, zT_0624AC1B_TailCallData d) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_AC00B5F6_LirSideEntryArrayLi* zT_6;
    zT_A8A5B231_LirSideEntry zT_7;
    zT_A8A5B231_LirSideEntry zT_9;
    unsigned int slot;
    zT_3 = lfn->side_table;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    slot = zT_5;
    zT_6 = &lfn->side_table;
    zT_9.tail_call = d;
    zT_7 = zT_9;
    zF_6E2511C2_lirSideEntryArrayLi(zT_6, zT_7);
    return slot;
}

/* lirSideGetCallDirect */
zT_3BFB1E70_CallDirectData zF_75DE985C_lirSideGetCallDirec(zT_BBC23664_LirFunction* lfn, unsigned int slot) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_2;
    zT_A8A5B231_LirSideEntry* zT_3;
    unsigned int zT_4;
    zT_A8A5B231_LirSideEntry zT_5;
    zT_3BFB1E70_CallDirectData zT_6;
    zT_2 = lfn->side_table;
    zT_3 = (zT_A8A5B231_LirSideEntry*)zT_2.items;
    zT_4 = (unsigned int)slot;
    zT_5 = zT_3[zT_4];
    zT_6 = zT_5.call_direct;
    return zT_6;
}

/* lirSideGetTailCall */
zT_0624AC1B_TailCallData zF_1AB3807F_lirSideGetTailCall(zT_BBC23664_LirFunction* lfn, unsigned int slot) {
    zT_AC00B5F6_LirSideEntryArrayLi zT_2;
    zT_A8A5B231_LirSideEntry* zT_3;
    unsigned int zT_4;
    zT_A8A5B231_LirSideEntry zT_5;
    zT_0624AC1B_TailCallData zT_6;
    zT_2 = lfn->side_table;
    zT_3 = (zT_A8A5B231_LirSideEntry*)zT_2.items;
    zT_4 = (unsigned int)slot;
    zT_5 = zT_3[zT_4];
    zT_6 = zT_5.tail_call;
    return zT_6;
}

/* globalDeclArrayListInit */
zT_E1A783EF_GlobalDeclArrayList zF_EB0B1609_globalDeclArrayList(zT_3E40CD83_Sand* allocator) {
    zT_E1A783EF_GlobalDeclArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_54906056_ModuleGlobalDecl*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* globalDeclArrayListEnsureCapacity */
void zF_31512729_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    zT_3E40CD83_Sand* zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_54906056_ModuleGlobalDecl* zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_DD2B0E80_Opt_263 zT_45;
    unsigned char zT_46;
    zT_3E40CD83_Sand* zT_48;
    unsigned int zT_49;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_FDFD82FD_EU_362 zT_58;
    unsigned char zT_59;
    unsigned char* zT_60;
    zT_54906056_ModuleGlobalDecl* zT_63;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_54906056_ModuleGlobalDecl* zT_68;
    zT_54906056_ModuleGlobalDecl zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_54906056_ModuleGlobalDecl* new_items;
    unsigned int i;
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    if ((unsigned char)(new_cap < (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 4;
    new_cap = zT_20;
    goto z_bb_6;
    z_bb_6: ;
    zT_21 = self->capacity;
    zT_22 = 0;
    if ((unsigned char)(zT_21 > (unsigned int)zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    zT_25 = self->allocator;
    zT_31 = (zT_54906056_ModuleGlobalDecl*)self->items;
    zT_33 = self->capacity;
    zT_34 = 24;
    zT_35 = zig_wrap_mul_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_mul_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    zT_27 = zT_35;
    zT_39 = 24;
    zT_40 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_28 = zT_40;
    zT_45 = zF_33A3D4F8_sandTryReallocInPla(zT_25, (unsigned char*)((unsigned char*)zT_31), zT_27, zT_28, (unsigned int)(4));
    grown = zT_45;
    zT_46 = grown.has_value;
    if (zT_46) goto z_bb_9; else goto z_bb_10;
    z_bb_8: ;
    zT_48 = self->allocator;
    zT_52 = 24;
    zT_53 = zig_wrap_mul_u(((zu64)(zT_52)), ((zu64)(new_cap)), 32u);
    zT_54 = zig_overflow_flag_mul_u(((zu64)(zT_52)), ((zu64)(new_cap)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    zT_49 = zT_53;
    zT_58 = zF_1395EB68_sandAlloc(zT_48, zT_49, (unsigned int)(4));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_11; else goto z_bb_12;
    z_bb_9: ;
    self->capacity = new_cap;
    return;
    z_bb_10: ;
    goto z_bb_8;
    z_bb_11: ;
    pal_trap();
    z_bb_12: ;
    zT_60 = zT_58.data.payload;
    goto z_bb_13;
    z_bb_13: ;
    raw = zT_60;
    zT_63 = (zT_54906056_ModuleGlobalDecl*)raw;
    new_items = zT_63;
    zT_65 = 0;
    i = zT_65;
    goto z_bb_14;
    z_bb_14: ;
    zT_66 = self->len;
    if ((unsigned char)(i < zT_66)) goto z_bb_15; else goto z_bb_16;
    z_bb_15: ;
    zT_68 = (zT_54906056_ModuleGlobalDecl*)self->items;
    zT_69 = zT_68[i];
    new_items[i] = zT_69;
    goto z_bb_17;
    z_bb_16: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17: ;
    zT_70 = 1;
    zT_71 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    i = zT_71;
    goto z_bb_14;
}

/* globalDeclArrayListAppend */
void zF_F2C82CE7_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self, zT_54906056_ModuleGlobalDecl value) {
    zT_E1A783EF_GlobalDeclArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_54906056_ModuleGlobalDecl* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_31512729_globalDeclArrayList(zT_2, zT_3);
    zT_10 = (zT_54906056_ModuleGlobalDecl*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* globalDeclArrayListGetSlice */
zT_23133B1E_Slice_zT_54906056_M zF_6ACCE52D_globalDeclArrayList(zT_E1A783EF_GlobalDeclArrayList* self) {
    zT_54906056_ModuleGlobalDecl* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_54906056_ModuleGlobalDecl* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_23133B1E_Slice_zT_54906056_M zT_7;
    zT_1 = (zT_54906056_ModuleGlobalDecl*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_54906056_ModuleGlobalDecl*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* EOF */
