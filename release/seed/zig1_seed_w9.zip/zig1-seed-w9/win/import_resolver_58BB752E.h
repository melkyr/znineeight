#ifndef ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H
#define ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "pal_388A8A1B.h"
#include "lexer_23F0DAD4.h"
#include "parser_61A67AF1.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "source_manager_0C564FCF.h"
#include "growable_array_6014E5AF.h"
#include "comptime_eval_02C4526F.h"
#include "type_resolver_7446D285.h"
#include "type_registry_8EE489B8.h"
#include "symbol_table_74081C75.h"
#include "token_76C7CBBF.h"
#include "spill_store_AC8E76BA.h"

#ifndef ZIG_STRUCT_zT_C7F6EF0E_ImportSwitchSelecti
#define ZIG_STRUCT_zT_C7F6EF0E_ImportSwitchSelecti
struct zT_C7F6EF0E_ImportSwitchSelecti {
	unsigned char decisive;
	unsigned int prong;
};
#endif /* ZIG_STRUCT_zT_C7F6EF0E_ImportSwitchSelecti */

/* Forward declarations */
zT_BAEE192E_Opt_10 zF_EEBAC601_moduleRegistryParse(zT_072B53A6_ModuleRegistry*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*);
unsigned char zF_11A0D4D8_importDeferredValEq(zT_89B1DDDA_ComptimeVal, zT_89B1DDDA_ComptimeVal);
zT_C7F6EF0E_ImportSwitchSelecti zF_225677E0_importSwitchSelectP(zT_6B0A7D14_AstStore*, zT_DA663F79_ComptimeEval*, unsigned int, zT_89B1DDDA_ComptimeVal);
zT_49E17557_Opt_2 zF_B7337DD4_importDeferredFoldB(zT_DA663F79_ComptimeEval*, unsigned int);
unsigned char zF_83953ADC_importDeferredSubtr(zT_6B0A7D14_AstStore*, unsigned char*, unsigned int, unsigned int);
void zF_ECEC8D73_importDeferredPushM(zT_6B0A7D14_AstStore*, unsigned int, zT_E2DF2801_LocalConstScope*);
void zF_C4BEF722_importDeferredScanN(zT_072B53A6_ModuleRegistry*, unsigned int, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_DA663F79_ComptimeEval*, zT_E2DF2801_LocalConstScope*, unsigned char*, unsigned int, unsigned int);
void zF_1A388C46_moduleRegistryScanD(zT_072B53A6_ModuleRegistry*, unsigned int, unsigned int, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_DA663F79_ComptimeEval*);
void zF_A46C0B58_moduleRegistryResol(zT_072B53A6_ModuleRegistry*, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H */
