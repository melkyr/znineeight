#include "spill_store_AC8E76BA.h"
unsigned int const zG_6568D425_SPILL_COUNT = (unsigned int)(6);
unsigned int const zG_36E2E10B_SPILL_SEEK_MAX = (unsigned int)(2147483647);
unsigned char zG_43DA845B_g_s_ast;
unsigned char zG_563B9F3C_g_s_lir;
unsigned char zG_B3E107B1_g_s_hash;
unsigned char zG_43E32C79_g_s_res;
unsigned char zG_189B793E_g_s_side;
unsigned char zG_59A74B49_g_s_extra;
/* spillSetLevel */
void zF_4EDF4E7B_spillSetLevel(unsigned int level) {
    unsigned int zT_4;
    unsigned int n;
    n = level;
    if ((unsigned char)(n > (unsigned int)(6))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 6;
    n = zT_4;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(n >= (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zG_43DA845B_g_s_ast = (unsigned char)(1);
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(n >= (unsigned int)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zG_563B9F3C_g_s_lir = (unsigned char)(1);
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(n >= (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zG_B3E107B1_g_s_hash = (unsigned char)(1);
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(n >= (unsigned int)(4))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zG_43E32C79_g_s_res = (unsigned char)(1);
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(n >= (unsigned int)(5))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zG_189B793E_g_s_side = (unsigned char)(1);
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(n >= (unsigned int)(6))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zG_59A74B49_g_s_extra = (unsigned char)(1);
    goto z_bb_14;
    z_bb_14:
    return;
}

/* spillBackendFor */
zT_0426DCE7_SpillBackend zF_1AA39172_spillBackendFor(zT_F12DA458_SpillId id) {
    if ((unsigned char)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_ast))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(zG_43DA845B_g_s_ast != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_4:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_5:
    if ((unsigned char)(zG_563B9F3C_g_s_lir != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    if ((unsigned char)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_hash))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_8:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_9:
    if ((unsigned char)(zG_B3E107B1_g_s_hash != (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((unsigned char)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_res))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_12:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_13:
    if ((unsigned char)(zG_43E32C79_g_s_res != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((unsigned char)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_side))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_16:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_17:
    if ((unsigned char)(zG_189B793E_g_s_side != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    if ((unsigned char)(zG_59A74B49_g_s_extra != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_20:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_21:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_22:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
}

/* spillStoreInit */
zT_D21A8776_SpillStore zF_22C79E6C_spillStoreInit(void) {
    zT_D21A8776_SpillStore zT_0;
    zT_0426DCE7_SpillBackend zT_1;
    unsigned char zT_2;
    zT_94D83112_Opt_449 zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_8;
    int zT_9;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1 = zT_0426DCE7_SpillBackend_disk;
    zT_0.backend = zT_1;
    zT_2 = 0;
    zT_0.opened = zT_2;
    zT_3.has_value = 0;
    zT_0.handle = zT_3;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_0.buf = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_0.cap = zT_5;
    zT_6 = 0;
    zT_0.len = zT_6;
    zT_7 = 0;
    zT_0.cur = zT_7;
    zT_8 = 0;
    zT_0.last_dir = zT_8;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_0.alloc = (zT_3E40CD83_Sand*)zT_9;
    return zT_0;
}

/* ramEnsure */
void zF_7BAD89D9_ramEnsure(zT_D21A8776_SpillStore* s, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_19;
    zT_81AD2998_EU_952 zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    zT_3E40CD83_Sand* zT_30;
    unsigned char* zT_31;
    unsigned int zT_37;
    zT_6F2E32ED_Opt_259 zT_41;
    unsigned char zT_42;
    zT_3E40CD83_Sand* zT_44;
    zT_81AD2998_EU_952 zT_50;
    unsigned char zT_51;
    unsigned char* zT_52;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char* zT_60;
    unsigned char zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    unsigned int new_cap;
    unsigned char* raw;
    zT_6F2E32ED_Opt_259 grown;
    unsigned int i;
    zT_2 = s->cap;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = s->cap;
    new_cap = zT_5;
    if ((unsigned char)(new_cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 65536;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_15 = s->cap;
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_10 = 2;
    zT_11 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    zT_19 = s->alloc;
    zT_25 = zF_1395EB68_sandAlloc(zT_19, (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_30 = s->alloc;
    zT_31 = s->buf;
    zT_37 = s->cap;
    zT_41 = zF_33A3D4F8_sandTryReallocInPla(zT_30, zT_31, (unsigned int)((unsigned int)zT_37), (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    grown = zT_41;
    zT_42 = grown.has_value;
    if (zT_42) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_27 = zT_25.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_27;
    s->buf = raw;
    s->cap = new_cap;
    return;
    z_bb_14:
    s->cap = new_cap;
    return;
    z_bb_15:
    zT_44 = s->alloc;
    zT_50 = zF_1395EB68_sandAlloc(zT_44, (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    zT_51 = zT_50.is_error;
    if (zT_51) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    pal_trap();
    z_bb_17:
    zT_52 = zT_50.data.payload;
    goto z_bb_18;
    z_bb_18:
    raw = zT_52;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    i = zT_56;
    goto z_bb_19;
    z_bb_19:
    zT_57 = s->cap;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_57))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_60 = s->buf;
    zT_61 = zT_60[i];
    raw[i] = zT_61;
    goto z_bb_22;
    z_bb_21:
    s->buf = raw;
    s->cap = new_cap;
    return;
    z_bb_22:
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    i = zT_64;
    goto z_bb_19;
}

/* spillOpen */
void zF_8AF94F71_spillOpen(zT_D21A8776_SpillStore* s, zT_0426DCE7_SpillBackend backend, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc, unsigned char* mode) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_10;
    zT_94D83112_Opt_449 zT_11;
    zT_94D83112_Opt_449 zT_12;
    unsigned char zT_13;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    int zT_26;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    s->backend = backend;
    s->cur = (unsigned int)(0);
    s->last_dir = (unsigned char)(0);
    if ((unsigned char)(backend == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_9 = path;
    zT_10 = mode;
    zT_11 = zF_A1EF0C49_streamOpen(zT_9, zT_10);
    s->handle = zT_11;
    zT_12 = s->handle;
    zT_13 = zT_12.has_value;
    if ((unsigned char)(!zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    s->opened = (unsigned char)(1);
    return;
    z_bb_3:
    s->alloc = alloc;
    goto z_bb_2;
    z_bb_4:
    zT_16 = "spill file open failed (spillOpen)";
    zT_18 = 34;
    zT_17.ptr = (unsigned char*)zT_16;
    zT_17.len = zT_18;
    emsg = zT_17;
    zT_20 = "spill_store.zig";
    zT_22 = 15;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    ef = zT_21;
    zT_23 = emsg;
    zT_24 = ef;
    zT_26 = 132;
    zF_6D97D338_panicHandler(zT_23, zT_24, (unsigned int)((unsigned int)zT_26));
    return;
    z_bb_5:
    goto z_bb_2;
}

/* spillClose */
void zF_DB2CDC3B_spillClose(zT_D21A8776_SpillStore* s) {
    zT_0426DCE7_SpillBackend zT_1;
    zT_94D83112_Opt_449 zT_4;
    unsigned char zT_5;
    void* zT_7;
    zT_94D83112_Opt_449 zT_8;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    void* h;
    zT_1 = s->backend;
    if ((unsigned char)(zT_1 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = s->handle;
    zT_5 = zT_4.has_value;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    s->opened = (unsigned char)(0);
    return;
    z_bb_3:
    if (!(zT_4.has_value)) { pal_trap(); }
    h = zT_4.value;
    zT_7 = h;
    zF_D4EBC9A3_streamClose(zT_7);
    zT_8.has_value = 0;
    s->handle = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* spillSeek */
void zF_56A911A9_spillSeek(zT_D21A8776_SpillStore* s, unsigned int off) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_15;
    zT_0426DCE7_SpillBackend zT_17;
    zT_94D83112_Opt_449 zT_21;
    unsigned char zT_22;
    void* zT_23;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_36;
    void* zT_39;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    void* h;
    if ((unsigned char)(off > (unsigned int)(2147483647))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "spill seek offset exceeds i32 limit (spillSeek)";
    zT_7 = 47;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    emsg = zT_6;
    zT_9 = "spill_store.zig";
    zT_11 = 15;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    ef = zT_10;
    zT_12 = emsg;
    zT_13 = ef;
    zT_15 = 154;
    zF_6D97D338_panicHandler(zT_12, zT_13, (unsigned int)((unsigned int)zT_15));
    return;
    z_bb_2:
    zT_17 = s->backend;
    if ((unsigned char)(zT_17 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = s->handle;
    zT_22 = zT_21.has_value;
    if (zT_22) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    s->cur = off;
    s->last_dir = (unsigned char)(0);
    return;
    z_bb_5:
    zT_26 = "spill seek on null handle (spillSeek)";
    zT_28 = 37;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    emsg = zT_27;
    zT_30 = "spill_store.zig";
    zT_32 = 15;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    ef = zT_31;
    zT_33 = emsg;
    zT_34 = ef;
    zT_36 = 160;
    zF_6D97D338_panicHandler(zT_33, zT_34, (unsigned int)((unsigned int)zT_36));
    return;
    z_bb_6:
    if (!(zT_21.has_value)) { pal_trap(); }
    zT_23 = zT_21.value;
    goto z_bb_7;
    z_bb_7:
    h = zT_23;
    zT_39 = h;
    zT_40 = (int)zig_cast_checked_s((zu64)off, 32u, 0u, 32u);
    zF_25D60F31_streamSeek(zT_39, zT_40);
    goto z_bb_4;
}

/* spillWriteAt */
void zF_BFB33631_spillWriteAt(zT_D21A8776_SpillStore* s, unsigned int off, zT_8F083A69_Slice_zT_0B42B2F8_u bytes) {
    unsigned int zT_4;
    unsigned char zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    zT_0426DCE7_SpillBackend zT_40;
    zT_D21A8776_SpillStore* zT_43;
    unsigned int zT_44;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned char* zT_51;
    unsigned int zT_52;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned int zT_67;
    zT_94D83112_Opt_449 zT_70;
    unsigned char zT_71;
    void* zT_72;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_85;
    unsigned int zT_88;
    unsigned char zT_90;
    unsigned char zT_91;
    void* zT_94;
    int zT_95;
    void* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int end;
    unsigned int i;
    void* h;
    zT_4 = bytes.len;
    if ((unsigned char)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((unsigned char)(off > (unsigned int)(2147483647))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = bytes.len;
    zT_12 = 2147483647;
    zT_13 = (unsigned int)off;
    zT_14 = zig_wrap_sub_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_sub_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_9 = zT_11 > zT_14;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = "spill write exceeds i32 seek limit (spillWriteAt)";
    zT_22 = 49;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    emsg = zT_21;
    zT_24 = "spill_store.zig";
    zT_26 = 15;
    zT_25.ptr = (unsigned char*)zT_24;
    zT_25.len = zT_26;
    ef = zT_25;
    zT_27 = emsg;
    zT_28 = ef;
    zT_30 = 171;
    zF_6D97D338_panicHandler(zT_27, zT_28, (unsigned int)((unsigned int)zT_30));
    return;
    z_bb_7:
    zT_34 = bytes.len;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    end = zT_36;
    zT_40 = s->backend;
    if ((unsigned char)(zT_40 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_43 = s;
    zT_44 = end;
    zF_7BAD89D9_ramEnsure(zT_43, zT_44);
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    i = zT_47;
    goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_70 = s->handle;
    zT_71 = zT_70.has_value;
    if (zT_71) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_49 = bytes.len;
    if ((unsigned char)(i < zT_49)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_51 = bytes.ptr;
    zT_52 = bytes.len;
    zT_53 = i < zT_52;
    if (!(zT_53)) { pal_trap(); }
    zT_54 = zT_51[i];
    zT_55 = s->buf;
    zT_56 = (unsigned int)off;
    zT_57 = zig_wrap_add_u(((zu64)(zT_56)), ((zu64)(i)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_56)), ((zu64)(i)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_55[zT_57] = zT_54;
    goto z_bb_14;
    z_bb_13:
    zT_67 = s->len;
    if ((unsigned char)(end > zT_67)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_61 = 1;
    zT_62 = (unsigned int)zT_61;
    zT_63 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    i = zT_63;
    goto z_bb_11;
    z_bb_15:
    s->len = end;
    goto z_bb_16;
    z_bb_16:
    s->cur = end;
    goto z_bb_9;
    z_bb_17:
    zT_75 = "spill write on null handle (spillWriteAt)";
    zT_77 = 41;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    emsg = zT_76;
    zT_79 = "spill_store.zig";
    zT_81 = 15;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    ef = zT_80;
    zT_82 = emsg;
    zT_83 = ef;
    zT_85 = 187;
    zF_6D97D338_panicHandler(zT_82, zT_83, (unsigned int)((unsigned int)zT_85));
    return;
    z_bb_18:
    if (!(zT_70.has_value)) { pal_trap(); }
    zT_72 = zT_70.value;
    goto z_bb_19;
    z_bb_19:
    h = zT_72;
    zT_88 = s->cur;
    if ((unsigned char)(zT_88 != off)) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_91 = s->last_dir;
    zT_90 = zT_91 == (unsigned char)(2);
    goto z_bb_22;
    z_bb_21:
    zT_90 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_90) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_94 = h;
    zT_95 = (int)zig_cast_checked_s((zu64)off, 32u, 0u, 32u);
    zF_25D60F31_streamSeek(zT_94, zT_95);
    goto z_bb_24;
    z_bb_24:
    zT_97 = h;
    zT_98 = bytes;
    zF_6B472DDC_streamWrite(zT_97, zT_98);
    s->cur = end;
    s->last_dir = (unsigned char)(1);
    goto z_bb_9;
}

/* spillReadAt */
void zF_E9F67450_spillReadAt(zT_D21A8776_SpillStore* s, unsigned int off, zT_8F083A69_Slice_zT_0B42B2F8_u dst) {
    unsigned int zT_4;
    unsigned char zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    zT_0426DCE7_SpillBackend zT_40;
    unsigned int zT_43;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_56;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned char* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    zT_94D83112_Opt_449 zT_81;
    unsigned char zT_82;
    void* zT_83;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    int zT_96;
    unsigned int zT_99;
    unsigned char zT_101;
    unsigned char zT_102;
    void* zT_105;
    int zT_106;
    void* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int end;
    void* h;
    unsigned int i;
    zT_4 = dst.len;
    if ((unsigned char)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((unsigned char)(off > (unsigned int)(2147483647))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = dst.len;
    zT_12 = 2147483647;
    zT_13 = (unsigned int)off;
    zT_14 = zig_wrap_sub_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_sub_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_9 = zT_11 > zT_14;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = "spill read exceeds i32 seek limit (spillReadAt)";
    zT_22 = 47;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    emsg = zT_21;
    zT_24 = "spill_store.zig";
    zT_26 = 15;
    zT_25.ptr = (unsigned char*)zT_24;
    zT_25.len = zT_26;
    ef = zT_25;
    zT_27 = emsg;
    zT_28 = ef;
    zT_30 = 199;
    zF_6D97D338_panicHandler(zT_27, zT_28, (unsigned int)((unsigned int)zT_30));
    return;
    z_bb_7:
    zT_34 = dst.len;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    end = zT_36;
    zT_40 = s->backend;
    if ((unsigned char)(zT_40 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_43 = s->len;
    if ((unsigned char)(end > zT_43)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_81 = s->handle;
    zT_82 = zT_81.has_value;
    if (zT_82) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_46 = "spill read past logical end (spillReadAt)";
    zT_48 = 41;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    emsg = zT_47;
    zT_50 = "spill_store.zig";
    zT_52 = 15;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    ef = zT_51;
    zT_53 = emsg;
    zT_54 = ef;
    zT_56 = 207;
    zF_6D97D338_panicHandler(zT_53, zT_54, (unsigned int)((unsigned int)zT_56));
    return;
    z_bb_12:
    zT_59 = 0;
    zT_60 = (unsigned int)zT_59;
    i = zT_60;
    goto z_bb_13;
    z_bb_13:
    zT_62 = dst.len;
    if ((unsigned char)(i < zT_62)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_64 = s->buf;
    zT_65 = (unsigned int)off;
    zT_66 = zig_wrap_add_u(((zu64)(zT_65)), ((zu64)(i)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(zT_65)), ((zu64)(i)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = zT_64[zT_66];
    zT_71 = dst.ptr;
    zT_72 = dst.len;
    zT_73 = i < zT_72;
    if (!(zT_73)) { pal_trap(); }
    zT_71[i] = zT_70;
    goto z_bb_16;
    z_bb_15:
    s->cur = end;
    goto z_bb_9;
    z_bb_16:
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    i = zT_76;
    goto z_bb_13;
    z_bb_17:
    zT_86 = "spill read on null handle (spillReadAt)";
    zT_88 = 39;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    emsg = zT_87;
    zT_90 = "spill_store.zig";
    zT_92 = 15;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    ef = zT_91;
    zT_93 = emsg;
    zT_94 = ef;
    zT_96 = 221;
    zF_6D97D338_panicHandler(zT_93, zT_94, (unsigned int)((unsigned int)zT_96));
    return;
    z_bb_18:
    if (!(zT_81.has_value)) { pal_trap(); }
    zT_83 = zT_81.value;
    goto z_bb_19;
    z_bb_19:
    h = zT_83;
    zT_99 = s->cur;
    if ((unsigned char)(zT_99 != off)) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_102 = s->last_dir;
    zT_101 = zT_102 == (unsigned char)(1);
    goto z_bb_22;
    z_bb_21:
    zT_101 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_101) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_105 = h;
    zT_106 = (int)zig_cast_checked_s((zu64)off, 32u, 0u, 32u);
    zF_25D60F31_streamSeek(zT_105, zT_106);
    goto z_bb_24;
    z_bb_24:
    zT_108 = h;
    zT_109 = dst;
    zF_9D6FEB45_streamRead(zT_108, zT_109);
    s->cur = end;
    s->last_dir = (unsigned char)(2);
    goto z_bb_9;
}

/* __module_init */
void zF_780653D2___module_init_21(void) {
    int zT_0;
    int zT_2;
    int zT_4;
    int zT_6;
    int zT_8;
    int zT_10;
    zT_0 = 0;
    zG_43DA845B_g_s_ast = (unsigned char)((unsigned char)zT_0);
    zT_2 = 0;
    zG_563B9F3C_g_s_lir = (unsigned char)((unsigned char)zT_2);
    zT_4 = 0;
    zG_B3E107B1_g_s_hash = (unsigned char)((unsigned char)zT_4);
    zT_6 = 0;
    zG_43E32C79_g_s_res = (unsigned char)((unsigned char)zT_6);
    zT_8 = 0;
    zG_189B793E_g_s_side = (unsigned char)((unsigned char)zT_8);
    zT_10 = 0;
    zG_59A74B49_g_s_extra = (unsigned char)((unsigned char)zT_10);
    return;
}

/* EOF */
