#include "resolved_type_table_5F22E794.h"
zT_8EED1867_ResolvedTypeTable zG_8EED1867_ResolvedTypeTable;
unsigned int const zG_C385D0F1_RTT_BLOCK_NODES = (unsigned int)(409);
unsigned int const zG_7B358D5F_RTT_BLOCK_BYTES = (unsigned int)(2045);
unsigned int const zG_B20FCCAC_RTT_REC_BYTES = (unsigned int)(5);
unsigned int const zG_3959D89B_RTT_SLOTS = (unsigned int)(8);
unsigned int const zG_B5C00A9C_EMPTY_BLOCK = (unsigned int)(4294967295u);
unsigned int const zG_9C3F251C_SEEK_MAX = (unsigned int)(2147483647);
unsigned char* const zG_82B6E276_WRITE_MODE_1 = (unsigned char*)"w+b";
/* resolvedTypeTableInit */
zT_8EED1867_ResolvedTypeTable zF_8D0F00B1_resolvedTypeTableIn(zT_3E40CD83_Sand* alloc) {
    zT_8EED1867_ResolvedTypeTable zT_2;
    unsigned int zT_3;
    zT_D21A8776_SpillStore zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_21D3708C_U32ToU32Map zT_9;
    int zT_10;
    int zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char* zT_25;
    unsigned char zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char* zT_44;
    unsigned int zT_45;
    unsigned char zT_46;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned char zT_50;
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    unsigned int zT_58;
    zT_8EED1867_ResolvedTypeTable t;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp;
    unsigned int di;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3 = 0;
    zT_2.cap = zT_3;
    zT_2.entries_alloc = alloc;
    zT_4 = zF_22C79E6C_spillStoreInit();
    zT_2.spill = zT_4;
    zT_5 = 0;
    zT_2.spill_path_len = zT_5;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2.cache_buf = (unsigned char*)zT_6;
    zT_7 = 0;
    zT_2.cache_allocated = zT_7;
    zT_8 = 0;
    zT_2.ring_next = zT_8;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_9.keys = (unsigned int*)zT_10;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_9.values = (unsigned int*)zT_11;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_9.occupied = (unsigned char*)zT_12;
    zT_13 = 0;
    zT_9.capacity = zT_13;
    zT_14 = 0;
    zT_9.count = zT_14;
    zT_9.alloc = alloc;
    zT_2.src_map = zT_9;
    t = zT_2;
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    si = zT_17;
    goto z_bb_1;
    z_bb_1: ;
    if ((unsigned char)(si < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2: ;
    zT_20 = 4294967295u;
    zT_21 = t.slot_block;
    zT_23 = si < (unsigned int)(8);
    if (!(zT_23)) { pal_trap(); }
    zT_21[si] = zT_20;
    zT_24 = 0;
    zT_25 = t.slot_dirty;
    zT_27 = si < (unsigned int)(8);
    if (!(zT_27)) { pal_trap(); }
    zT_25[si] = zT_24;
    goto z_bb_4;
    z_bb_3: ;
    zT_35 = (unsigned char*)".zig1_res.tmp";
    zT_37 = 13;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    dp = zT_36;
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    di = zT_40;
    goto z_bb_5;
    z_bb_4: ;
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    si = zT_30;
    goto z_bb_1;
    z_bb_5: ;
    zT_42 = dp.len;
    if ((unsigned char)(di < zT_42)) goto z_bb_6; else goto z_bb_7;
    z_bb_6: ;
    zT_44 = (unsigned char*)dp.ptr;
    zT_45 = dp.len;
    zT_46 = di < zT_45;
    if (!(zT_46)) { pal_trap(); }
    zT_47 = zT_44[di];
    zT_48 = t.spill_path;
    zT_50 = di < (unsigned int)(512);
    if (!(zT_50)) { pal_trap(); }
    zT_48[di] = zT_47;
    goto z_bb_8;
    z_bb_7: ;
    zT_58 = dp.len;
    t.spill_path_len = zT_58;
    return t;
    z_bb_8: ;
    zT_51 = 1;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    di = zT_53;
    goto z_bb_5;
}

/* resolvedTypeTableSetSpillPath */
void zF_7238A436_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable* self, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char* zT_25;
    unsigned char zT_27;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1: ;
    zT_6 = path.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_11 = (unsigned char*)path.ptr;
    zT_12 = path.len;
    zT_13 = i < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[i];
    zT_15 = self->spill_path;
    zT_17 = i < (unsigned int)(512);
    if (!(zT_17)) { pal_trap(); }
    zT_15[i] = zT_14;
    goto z_bb_4;
    z_bb_3: ;
    self->spill_path_len = i;
    zT_24 = 0;
    zT_25 = self->spill_path;
    zT_27 = i < (unsigned int)(512);
    if (!(zT_27)) { pal_trap(); }
    zT_25[i] = zT_24;
    return;
    z_bb_4: ;
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    i = zT_20;
    goto z_bb_1;
    z_bb_5: ;
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6: ;
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* rttAlignedNodes */
unsigned int zF_1CE20124_rttAlignedNodes(unsigned int n) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned char zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int mult;
    zT_2 = 409;
    zT_3 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_2)), 32u);
    zT_4 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_2)), 32u);
    zT_6 = zT_4 == (unsigned int)(0);
    if (!(zT_6)) { pal_trap(); }
    zT_7 = 1;
    zT_8 = zig_wrap_sub_u(((zu64)(zT_3)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(zT_3)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_15 = 1;
    if (!(zT_15)) { pal_trap(); }
    zT_13 = zT_8 / (unsigned int)(409);
    mult = zT_13;
    zT_16 = 409;
    zT_17 = zig_wrap_mul_u(((zu64)(mult)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_mul_u(((zu64)(mult)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    return zT_17;
}

/* rttOpenSpill */
void zF_01066AE9_rttOpenSpill(zT_8EED1867_ResolvedTypeTable* self) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    zT_D21A8776_SpillStore* zT_5;
    zT_0426DCE7_SpillBackend zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    zT_0426DCE7_SpillBackend zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zT_1 = self->spill;
    zT_2 = zT_1.opened;
    if ((unsigned char)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_5 = &self->spill;
    zT_14 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_res));
    zT_6 = zT_14;
    zT_15 = self->spill_path;
    zT_16 = self->spill_path_len;
    zT_17 = 0;
    zT_18 = zT_15 + zT_17;
    zT_19 = zT_16 - zT_17;
    zT_21 = (unsigned int)zT_17 <= zT_16;
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_16 <= (unsigned int)(512);
    if (!(zT_22)) { pal_trap(); }
    zT_23.ptr = (unsigned char*)zT_18;
    zT_23.len = zT_19;
    zT_7 = zT_23;
    zT_8 = self->entries_alloc;
    zT_9 = zG_82B6E276_WRITE_MODE_1;
    zF_8AF94F71_spillOpen(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* rttExtend */
void zF_C592EFE9_rttExtend(zT_8EED1867_ResolvedTypeTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_40;
    zT_B2425549_Arr_unsigned_char_2 zT_43;
    int zT_45;
    unsigned int zT_46;
    unsigned char zT_49;
    unsigned char zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_D21A8776_SpillStore* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int old_an;
    unsigned int new_an;
    unsigned int old_bytes;
    unsigned int new_bytes;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_B2425549_Arr_unsigned_char_2 zero_buf;
    unsigned int zi;
    unsigned int to_write;
    unsigned int off;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_2 = self->cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_4 = self;
    zF_01066AE9_rttOpenSpill(zT_4);
    zT_6 = self->cap;
    zT_8 = zF_1CE20124_rttAlignedNodes(zT_6);
    old_an = zT_8;
    zT_10 = new_cap;
    zT_11 = zF_1CE20124_rttAlignedNodes(zT_10);
    new_an = zT_11;
    if ((unsigned char)(new_an > old_an)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_14 = (unsigned int)old_an;
    zT_15 = 5;
    zT_16 = zig_wrap_mul_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_mul_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    old_bytes = zT_16;
    zT_21 = (unsigned int)new_an;
    zT_22 = 5;
    zT_23 = zig_wrap_mul_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_mul_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    new_bytes = zT_23;
    if ((unsigned char)(new_bytes > (unsigned int)(2147483647))) goto z_bb_5; else goto z_bb_6;
    z_bb_4: ;
    self->cap = new_cap;
    return;
    z_bb_5: ;
    zT_30 = (unsigned char*)"resolved-type spill exceeds seek limit (rttExtend)";
    zT_32 = 50;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    emsg = zT_31;
    zT_34 = (unsigned char*)"resolved_type_table.zig";
    zT_36 = 23;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    ef = zT_35;
    zT_37 = emsg;
    zT_38 = ef;
    zT_40 = 112;
    zF_6D97D338_panicHandler(zT_37, zT_38, (unsigned int)((unsigned int)zT_40));
    return;
    z_bb_6: ;
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    {
    unsigned int _i = 0;
    while (_i < 2045) {
        zero_buf[_i] = zT_43[_i];
        _i++;
    }
}
    zT_45 = 0;
    zT_46 = (unsigned int)zT_45;
    zi = zT_46;
    goto z_bb_7;
    z_bb_7: ;
    if ((unsigned char)(zi < (unsigned int)(2045))) goto z_bb_8; else goto z_bb_9;
    z_bb_8: ;
    zT_49 = 0;
    zT_51 = zi < (unsigned int)(2045);
    if (!(zT_51)) { pal_trap(); }
    zero_buf[zi] = zT_49;
    goto z_bb_10;
    z_bb_9: ;
    zT_59 = zig_wrap_sub_u(((zu64)(new_bytes)), ((zu64)(old_bytes)), 32u);
    zT_60 = zig_overflow_flag_sub_u(((zu64)(new_bytes)), ((zu64)(old_bytes)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    to_write = zT_59;
    off = old_bytes;
    goto z_bb_11;
    z_bb_10: ;
    zT_52 = 1;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zi = zT_54;
    goto z_bb_7;
    z_bb_11: ;
    if ((unsigned char)(to_write > (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_12: ;
    zT_66 = &self->spill;
    zT_67 = off;
    zT_73 = 0;
    zT_74 = (unsigned char*)((unsigned char*)zero_buf) + zT_73;
    zT_75 = (unsigned int)(2045) - zT_73;
    zT_76.ptr = (unsigned char*)zT_74;
    zT_76.len = zT_75;
    zT_68 = zT_76;
    zF_BFB33631_spillWriteAt(zT_66, zT_67, zT_68);
    zT_77 = 2045;
    zT_78 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_77)), 32u);
    zT_79 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_77)), 32u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    off = zT_78;
    goto z_bb_14;
    z_bb_13: ;
    goto z_bb_4;
    z_bb_14: ;
    zT_82 = 2045;
    zT_83 = zig_wrap_sub_u(((zu64)(to_write)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_sub_u(((zu64)(to_write)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    to_write = zT_83;
    goto z_bb_11;
}

/* rttEnsureCache */
void zF_79C87F6B_rttEnsureCache(zT_8EED1867_ResolvedTypeTable* self) {
    unsigned char zT_1;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_22C2203A_EU_172 zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned char* raw;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zT_1 = self->cache_allocated;
    if ((unsigned char)(zT_1 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_5 = self->entries_alloc;
    zT_9 = 8;
    zT_10 = 2045;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_6 = zT_11;
    zT_16 = zF_1395EB68_sandAlloc(zT_5, zT_6, (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    pal_trap();
    z_bb_4: ;
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5: ;
    raw = zT_18;
    self->cache_buf = raw;
    self->cache_allocated = (unsigned char)(1);
    return;
}

/* rttSlotBuf */
unsigned char* zF_8D0C78B6_rttSlotBuf(zT_8EED1867_ResolvedTypeTable* self, unsigned int s) {
    unsigned char* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    zT_2 = self->cache_buf;
    zT_3 = (unsigned int)s;
    zT_4 = 2045;
    zT_5 = zig_wrap_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    return (unsigned char*)(zT_2 + zT_5);
}

/* rttResidentSlot */
unsigned int zF_5D06B445_rttResidentSlot(zT_8EED1867_ResolvedTypeTable* self, unsigned int block) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned char zT_9;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int s;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    s = zT_4;
    goto z_bb_1;
    z_bb_1: ;
    if ((unsigned char)(s < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2: ;
    zT_7 = self->slot_block;
    zT_9 = s < (unsigned int)(8);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_7[s];
    if ((unsigned char)(zT_10 == block)) goto z_bb_5; else goto z_bb_6;
    z_bb_3: ;
    return (unsigned int)(8);
    z_bb_4: ;
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zig_wrap_add_u(((zu64)(s)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(s)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    s = zT_14;
    goto z_bb_1;
    z_bb_5: ;
    return s;
    z_bb_6: ;
    goto z_bb_4;
}

/* rttWriteBack */
void zF_2C4861F7_rttWriteBack(zT_8EED1867_ResolvedTypeTable* self, unsigned int s) {
    unsigned int* zT_3;
    unsigned char zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    int zT_31;
    zT_D21A8776_SpillStore* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_8EED1867_ResolvedTypeTable* zT_37;
    unsigned int zT_38;
    unsigned char* zT_39;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char zT_48;
    unsigned int block;
    unsigned int off;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zT_3 = self->slot_block;
    zT_5 = s < (unsigned int)(8);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = zT_3[s];
    block = zT_6;
    zT_8 = 2045;
    zT_9 = zig_wrap_mul_u(((zu64)(block)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_mul_u(((zu64)(block)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    off = zT_9;
    zT_13 = 2147483647;
    zT_14 = 2045;
    zT_15 = zig_wrap_sub_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_sub_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    if ((unsigned char)(off > zT_15)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_21 = (unsigned char*)"resolved-type spill exceeds seek limit (rttWriteBack)";
    zT_23 = 53;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    emsg = zT_22;
    zT_25 = (unsigned char*)"resolved_type_table.zig";
    zT_27 = 23;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    ef = zT_26;
    zT_28 = emsg;
    zT_29 = ef;
    zT_31 = 151;
    zF_6D97D338_panicHandler(zT_28, zT_29, (unsigned int)((unsigned int)zT_31));
    return;
    z_bb_2: ;
    zT_33 = &self->spill;
    zT_34 = off;
    zT_37 = self;
    zT_38 = s;
    zT_39 = zF_8D0C78B6_rttSlotBuf(zT_37, zT_38);
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = (unsigned int)(2045) - zT_41;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    zT_35 = zT_44;
    zF_BFB33631_spillWriteAt(zT_33, zT_34, zT_35);
    zT_45 = 0;
    zT_46 = self->slot_dirty;
    zT_48 = s < (unsigned int)(8);
    if (!(zT_48)) { pal_trap(); }
    zT_46[s] = zT_45;
    return;
}

/* rttBlockEnsure */
unsigned int zF_41F8466C_rttBlockEnsure(zT_8EED1867_ResolvedTypeTable* self, unsigned int block) {
    zT_8EED1867_ResolvedTypeTable* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_8;
    unsigned int zT_10;
    unsigned int* zT_11;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned char zT_20;
    unsigned char zT_21;
    zT_8EED1867_ResolvedTypeTable* zT_24;
    unsigned int zT_25;
    zT_8EED1867_ResolvedTypeTable* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    int zT_51;
    zT_D21A8776_SpillStore* zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_8EED1867_ResolvedTypeTable* zT_57;
    unsigned int zT_58;
    unsigned char* zT_59;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int* zT_65;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned char* zT_69;
    unsigned char zT_71;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    unsigned int zT_77;
    unsigned int r;
    unsigned int v;
    unsigned int off;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_3 = self;
    zT_4 = block;
    zT_5 = zF_5D06B445_rttResidentSlot(zT_3, zT_4);
    r = zT_5;
    if ((unsigned char)(r < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return r;
    z_bb_2: ;
    zT_8 = self;
    zF_79C87F6B_rttEnsureCache(zT_8);
    zT_10 = self->ring_next;
    v = zT_10;
    zT_11 = self->slot_block;
    zT_13 = v < (unsigned int)(8);
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[v];
    if ((unsigned char)(zT_14 != (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_18 = self->slot_dirty;
    zT_20 = v < (unsigned int)(8);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = zT_18[v];
    zT_17 = zT_21 != (unsigned char)(0);
    goto z_bb_5;
    z_bb_4: ;
    zT_17 = 0;
    goto z_bb_5;
    z_bb_5: ;
    if (zT_17) goto z_bb_6; else goto z_bb_7;
    z_bb_6: ;
    zT_24 = self;
    zT_25 = v;
    zF_2C4861F7_rttWriteBack(zT_24, zT_25);
    goto z_bb_7;
    z_bb_7: ;
    zT_26 = self;
    zF_01066AE9_rttOpenSpill(zT_26);
    zT_28 = 2045;
    zT_29 = zig_wrap_mul_u(((zu64)(block)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_mul_u(((zu64)(block)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    off = zT_29;
    zT_33 = 2147483647;
    zT_34 = 2045;
    zT_35 = zig_wrap_sub_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_sub_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    if ((unsigned char)(off > zT_35)) goto z_bb_8; else goto z_bb_9;
    z_bb_8: ;
    zT_41 = (unsigned char*)"resolved-type spill exceeds seek limit (rttBlockEnsure)";
    zT_43 = 55;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    emsg = zT_42;
    zT_45 = (unsigned char*)"resolved_type_table.zig";
    zT_47 = 23;
    zT_46.ptr = (unsigned char*)zT_45;
    zT_46.len = zT_47;
    ef = zT_46;
    zT_48 = emsg;
    zT_49 = ef;
    zT_51 = 174;
    zF_6D97D338_panicHandler(zT_48, zT_49, (unsigned int)((unsigned int)zT_51));
    return v;
    z_bb_9: ;
    zT_53 = &self->spill;
    zT_54 = off;
    zT_57 = self;
    zT_58 = v;
    zT_59 = zF_8D0C78B6_rttSlotBuf(zT_57, zT_58);
    zT_61 = 0;
    zT_62 = zT_59 + zT_61;
    zT_63 = (unsigned int)(2045) - zT_61;
    zT_64.ptr = (unsigned char*)zT_62;
    zT_64.len = zT_63;
    zT_55 = zT_64;
    zF_E9F67450_spillReadAt(zT_53, zT_54, zT_55);
    zT_65 = self->slot_block;
    zT_67 = v < (unsigned int)(8);
    if (!(zT_67)) { pal_trap(); }
    zT_65[v] = block;
    zT_68 = 0;
    zT_69 = self->slot_dirty;
    zT_71 = v < (unsigned int)(8);
    if (!(zT_71)) { pal_trap(); }
    zT_69[v] = zT_68;
    zT_72 = 1;
    zT_73 = zig_wrap_add_u(((zu64)(v)), ((zu64)(zT_72)), 32u);
    zT_74 = zig_overflow_flag_add_u(((zu64)(v)), ((zu64)(zT_72)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    self->ring_next = zT_73;
    zT_77 = self->ring_next;
    if ((unsigned char)(zT_77 >= (unsigned int)(8))) goto z_bb_10; else goto z_bb_11;
    z_bb_10: ;
    self->ring_next = (unsigned int)(0);
    goto z_bb_11;
    z_bb_11: ;
    return v;
}

/* rttReadU32 */
unsigned int zF_AD4FEE31_rttReadU32(unsigned char* p, unsigned int off) {
    unsigned char zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned int zT_34;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned char zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int v;
    zT_3 = p[off];
    zT_4 = (unsigned int)zT_3;
    v = zT_4;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = p[zT_6];
    zT_11 = (unsigned int)zT_10;
    zT_12 = 8;
    zT_15 = 1;
    if (!(zT_15)) { pal_trap(); }
    zT_13 = zig_wrap_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_16 = zig_overflow_flag_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = v | zT_13;
    v = zT_19;
    zT_20 = 2;
    zT_21 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_25 = p[zT_21];
    zT_26 = (unsigned int)zT_25;
    zT_27 = 16;
    zT_30 = 1;
    if (!(zT_30)) { pal_trap(); }
    zT_28 = zig_wrap_shl_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_31 = zig_overflow_flag_shl_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_34 = v | zT_28;
    v = zT_34;
    zT_35 = 3;
    zT_36 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = p[zT_36];
    zT_41 = (unsigned int)zT_40;
    zT_42 = 24;
    zT_45 = 1;
    if (!(zT_45)) { pal_trap(); }
    zT_43 = zig_wrap_shl_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_46 = zig_overflow_flag_shl_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_49 = v | zT_43;
    v = zT_49;
    return v;
}

/* rttWriteU32 */
void zF_CEEF106E_rttWriteU32(unsigned char* p, unsigned int off, unsigned int v) {
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned char zT_9;
    unsigned int zT_11;
    unsigned char zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char zT_21;
    unsigned int zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zT_4 = v & (unsigned int)(255);
    zT_5 = (unsigned char)zig_cast_checked_u((zu64)zT_4, 32u, 0u, 8u);
    p[off] = zT_5;
    zT_9 = 1;
    if (!(zT_9)) { pal_trap(); }
    zT_11 = (unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255);
    zT_12 = (unsigned char)zig_cast_checked_u((zu64)zT_11, 32u, 0u, 8u);
    zT_13 = 1;
    zT_14 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    p[zT_14] = zT_12;
    zT_21 = 1;
    if (!(zT_21)) { pal_trap(); }
    zT_23 = (unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255);
    zT_24 = (unsigned char)zig_cast_checked_u((zu64)zT_23, 32u, 0u, 8u);
    zT_25 = 2;
    zT_26 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    p[zT_26] = zT_24;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_35 = (unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255);
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_35, 32u, 0u, 8u);
    zT_37 = 3;
    zT_38 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    p[zT_38] = zT_36;
    return;
}

/* resolvedTypeTableReserve */
void zF_75224871_resolvedTypeTableRe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_count) {
    zT_8EED1867_ResolvedTypeTable* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_count;
    zF_C592EFE9_rttExtend(zT_2, zT_3);
    return;
}

/* resolvedTypeTableSet */
void zF_19B4A07D_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx, unsigned int type_id) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_8EED1867_ResolvedTypeTable* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8EED1867_ResolvedTypeTable* zT_25;
    unsigned int zT_26;
    unsigned char* zT_27;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned char zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned char* zT_49;
    unsigned char zT_51;
    unsigned int ni;
    unsigned int block;
    unsigned int s;
    unsigned char* buf;
    unsigned int rec_off;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zT_4 = (unsigned int)node_idx;
    ni = zT_4;
    zT_5 = self->cap;
    if ((unsigned char)(ni >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_7 = self;
    zT_9 = 1;
    zT_10 = zig_wrap_add_u(((zu64)(ni)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_add_u(((zu64)(ni)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    zT_8 = zT_10;
    zF_C592EFE9_rttExtend(zT_7, zT_8);
    goto z_bb_2;
    z_bb_2: ;
    zT_18 = 1;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = (unsigned int)(unsigned int)(ni / (unsigned int)(409));
    block = zT_19;
    zT_21 = self;
    zT_22 = block;
    zT_23 = zF_41F8466C_rttBlockEnsure(zT_21, zT_22);
    s = zT_23;
    zT_25 = self;
    zT_26 = s;
    zT_27 = zF_8D0C78B6_rttSlotBuf(zT_25, zT_26);
    buf = zT_27;
    zT_32 = 1;
    if (!(zT_32)) { pal_trap(); }
    zT_30 = ni % (unsigned int)(409);
    zT_33 = 5;
    zT_34 = zig_wrap_mul_u(((zu64)(zT_30)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_mul_u(((zu64)(zT_30)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    rec_off = zT_34;
    zT_38 = buf;
    zT_39 = rec_off;
    zF_CEEF106E_rttWriteU32(zT_38, zT_39, (unsigned int)((unsigned int)type_id));
    zT_42 = 1;
    zT_43 = 4;
    zT_44 = zig_wrap_add_u(((zu64)(rec_off)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_add_u(((zu64)(rec_off)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    buf[zT_44] = zT_42;
    zT_48 = 1;
    zT_49 = self->slot_dirty;
    zT_51 = s < (unsigned int)(8);
    if (!(zT_51)) { pal_trap(); }
    zT_49[s] = zT_48;
    return;
}

/* resolvedTypeTableGet */
zT_BAEE192E_Opt_10 zF_999DCF51_resolvedTypeTableGe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    unsigned char zT_11;
    unsigned int zT_12;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_8EED1867_ResolvedTypeTable* zT_18;
    unsigned int zT_19;
    unsigned char* zT_20;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_BAEE192E_Opt_10 zT_42;
    zT_BAEE192E_Opt_10 zT_43;
    unsigned int ni;
    unsigned int block;
    unsigned int s;
    unsigned char* buf;
    unsigned int rec_off;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zT_3 = (unsigned int)node_idx;
    ni = zT_3;
    zT_4 = self->cap;
    if ((unsigned char)(ni >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2: ;
    zT_11 = 1;
    if (!(zT_11)) { pal_trap(); }
    zT_12 = (unsigned int)(unsigned int)(ni / (unsigned int)(409));
    block = zT_12;
    zT_14 = self;
    zT_15 = block;
    zT_16 = zF_41F8466C_rttBlockEnsure(zT_14, zT_15);
    s = zT_16;
    zT_18 = self;
    zT_19 = s;
    zT_20 = zF_8D0C78B6_rttSlotBuf(zT_18, zT_19);
    buf = zT_20;
    zT_25 = 1;
    if (!(zT_25)) { pal_trap(); }
    zT_23 = ni % (unsigned int)(409);
    zT_26 = 5;
    zT_27 = zig_wrap_mul_u(((zu64)(zT_23)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_mul_u(((zu64)(zT_23)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    rec_off = zT_27;
    zT_31 = 4;
    zT_32 = zig_wrap_add_u(((zu64)(rec_off)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(rec_off)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_36 = buf[zT_32];
    if ((unsigned char)(zT_36 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_39 = buf;
    zT_40 = rec_off;
    zT_41 = zF_AD4FEE31_rttReadU32(zT_39, zT_40);
    zT_42.has_value = 1;
    zT_42.value = zT_41;
    return zT_42;
    z_bb_4: ;
    zT_43.has_value = 0;
    return zT_43;
}

/* resolvedSourceTableSet */
void zF_D976B454_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx, unsigned int source_name_id) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = &self->src_map;
    zT_4 = node_idx;
    zT_5 = source_name_id;
    zF_26476265_u32ToU32MapPut(zT_3, zT_4, zT_5);
    return;
}

/* resolvedSourceTableGet */
zT_BAEE192E_Opt_10 zF_F45AE288_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = &self->src_map;
    zT_3 = node_idx;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    return zT_5;
}

/* resolvedTypeTableClose */
void zF_5209815D_resolvedTypeTableCl(zT_8EED1867_ResolvedTypeTable* self) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    int zT_6;
    unsigned int zT_7;
    unsigned int* zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned char zT_19;
    unsigned char zT_20;
    zT_8EED1867_ResolvedTypeTable* zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_D21A8776_SpillStore* zT_31;
    unsigned int s;
    zT_1 = self->spill;
    zT_2 = zT_1.opened;
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    s = zT_7;
    goto z_bb_3;
    z_bb_3: ;
    if ((unsigned char)(s < (unsigned int)(8))) goto z_bb_4; else goto z_bb_5;
    z_bb_4: ;
    zT_10 = self->slot_block;
    zT_12 = s < (unsigned int)(8);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[s];
    if ((unsigned char)(zT_13 != (unsigned int)(4294967295u))) goto z_bb_7; else goto z_bb_8;
    z_bb_5: ;
    zT_31 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_31);
    return;
    z_bb_6: ;
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(s)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(s)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    s = zT_27;
    goto z_bb_3;
    z_bb_7: ;
    zT_17 = self->slot_dirty;
    zT_19 = s < (unsigned int)(8);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[s];
    zT_16 = zT_20 != (unsigned char)(0);
    goto z_bb_9;
    z_bb_8: ;
    zT_16 = 0;
    goto z_bb_9;
    z_bb_9: ;
    if (zT_16) goto z_bb_10; else goto z_bb_11;
    z_bb_10: ;
    zT_23 = self;
    zT_24 = s;
    zF_2C4861F7_rttWriteBack(zT_23, zT_24);
    goto z_bb_11;
    z_bb_11: ;
    goto z_bb_6;
}

/* EOF */
