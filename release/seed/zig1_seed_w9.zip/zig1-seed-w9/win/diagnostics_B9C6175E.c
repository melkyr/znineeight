#include "diagnostics_B9C6175E.h"
zT_F85C5DED_DiagnosticCollector zG_F85C5DED_DiagnosticCollector;
unsigned short const zG_CD1D676D_ERR_1000_UNTERMINAT = (unsigned short)(0);
unsigned short const zG_03075056_ERR_1001_UNTERMINAT = (unsigned short)(1);
unsigned short const zG_28A81ECF_ERR_1002_INVALID_CH = (unsigned short)(2);
unsigned short const zG_C46AE43D_ERR_1003_INVALID_ES = (unsigned short)(3);
unsigned short const zG_9F2B9E01_ERR_1004_BARE_AT_SI = (unsigned short)(4);
unsigned short const zG_BDB44740_ERR_1005_UNRECOGNIZ = (unsigned short)(5);
unsigned short const zG_E5E7A1C2_WARN_1010_UNRECOGNI = (unsigned short)(6);
unsigned short const zG_F685B4FB_WARN_1011_INTEGER_O = (unsigned short)(7);
unsigned short const zG_21EFDA5B_ERR_3045_UNKNOWN_CA = (unsigned short)(3045);
unsigned short const zG_20197026_ERR_3017_SUSPENDING = (unsigned short)(3017);
unsigned int const zG_E55A587A_MAX_DIAGNOSTICS = (unsigned int)(256);
/* getLevelName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_1620F424_getLevelName(unsigned char level) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
switch (level) {
case 0: goto z_bb_1;
case 1: goto z_bb_2;
case 2: goto z_bb_3;
case 3: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    zT_2 = "error";
    zT_4 = 5;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s = zT_3;
    return s;
    z_bb_2:
    zT_6 = "warning";
    zT_8 = 7;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    s = zT_7;
    return s;
    z_bb_3:
    zT_10 = "info";
    zT_12 = 4;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    s = zT_11;
    return s;
    z_bb_4:
    zT_14 = "note";
    zT_16 = 4;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    s = zT_15;
    return s;
    z_bb_5:
    zT_18 = "unknown";
    zT_20 = 7;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    s = zT_19;
    return s;
    { zT_8F083A69_Slice_zT_0B42B2F8_u zT_ret_void = {0}; return zT_ret_void; }
}

/* formatU32 */
unsigned int zF_2FED9490_formatU32(unsigned int value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    int zT_20;
    unsigned char zT_22;
    int zT_23;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned char zT_31;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int v;
    unsigned int i;
    v = value;
    zT_5 = buf.len;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_9 = 1;
    zT_10 = (unsigned int)zT_9;
    zT_11 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    i = zT_11;
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_17 = (unsigned int)i;
    zT_18 = buf.len;
    zT_19 = zT_17 < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_16[zT_17] = zT_15;
    goto z_bb_2;
    z_bb_2:
    zT_50 = buf.len;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zig_wrap_sub_u(((zu64)(zT_51)), ((zu64)(i)), 32u);
    zT_53 = zig_overflow_flag_sub_u(((zu64)(zT_51)), ((zu64)(i)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    return zT_52;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((unsigned char)(v > (unsigned int)zT_20)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    zT_31 = 48;
    zT_32 = 10;
    zT_35 = (unsigned int)zT_32 != (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_33 = v % zT_32;
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_33, 32u, 0u, 8u);
    zT_37 = zig_wrap_add_u(((zu64)(zT_31)), ((zu64)(zT_36)), 8u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(zT_31)), ((zu64)(zT_36)), 8u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_41 = buf.ptr;
    zT_42 = (unsigned int)i;
    zT_43 = buf.len;
    zT_44 = zT_42 < zT_43;
    if (!(zT_44)) { pal_trap(); }
    zT_41[zT_42] = zT_37;
    zT_45 = 10;
    zT_48 = (unsigned int)zT_45 != (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_46 = v / zT_45;
    v = zT_46;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_23 = 0;
    zT_22 = i > (unsigned int)zT_23;
    goto z_bb_10;
    z_bb_9:
    zT_22 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_22) goto z_bb_5; else goto z_bb_6;
}

/* writeStr */
void zF_76BE513B_writeStr(zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1;
    zT_1 = s;
    zF_E4B2EF19_stderr_write(zT_1);
    return;
}

/* compareDiag */
int zF_36E7146B_compareDiag(zT_50FBF81E_Diagnostic* a, zT_50FBF81E_Diagnostic* b) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_27;
    int zT_28;
    unsigned char zT_29;
    int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    int zT_35;
    zT_2 = a->file_id;
    zT_3 = b->file_id;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a->file_id;
    zT_6 = (int)zig_cast_checked_s((zu64)zT_5, 32u, 0u, 32u);
    zT_7 = b->file_id;
    zT_8 = (int)zig_cast_checked_s((zu64)zT_7, 32u, 0u, 32u);
    zT_9 = zig_wrap_sub_s(((z64)(zT_6)), ((z64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_s(((z64)(zT_6)), ((z64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    return zT_9;
    z_bb_2:
    zT_13 = a->span_start;
    zT_14 = b->span_start;
    if ((unsigned char)(zT_13 != zT_14)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = a->span_start;
    zT_17 = (int)zig_cast_checked_s((zu64)zT_16, 32u, 0u, 32u);
    zT_18 = b->span_start;
    zT_19 = (int)zig_cast_checked_s((zu64)zT_18, 32u, 0u, 32u);
    zT_20 = zig_wrap_sub_s(((z64)(zT_17)), ((z64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_sub_s(((z64)(zT_17)), ((z64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    return zT_20;
    z_bb_4:
    zT_24 = a->level;
    zT_25 = b->level;
    if ((unsigned char)(zT_24 != zT_25)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = a->level;
    zT_28 = (int)zT_27;
    zT_29 = b->level;
    zT_30 = (int)zT_29;
    zT_31 = zig_wrap_sub_s(((z64)(zT_28)), ((z64)(zT_30)), 32u);
    zT_32 = zig_overflow_flag_sub_s(((z64)(zT_28)), ((z64)(zT_30)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    return zT_31;
    z_bb_6:
    zT_35 = 0;
    return (int)((int)zT_35);
}

/* sortDiagnostics */
void zF_F6BADF23_sortDiagnostics(zT_8D25846A_Slice_zT_50FBF81E_D diags) {
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    zT_50FBF81E_Diagnostic* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_50FBF81E_Diagnostic zT_11;
    int zT_13;
    int zT_14;
    unsigned char zT_16;
    zT_50FBF81E_Diagnostic* zT_17;
    zT_50FBF81E_Diagnostic* zT_18;
    zT_50FBF81E_Diagnostic* zT_19;
    int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_50FBF81E_Diagnostic* zT_28;
    zT_50FBF81E_Diagnostic* zT_29;
    int zT_30;
    int zT_31;
    zT_50FBF81E_Diagnostic* zT_33;
    int zT_34;
    int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    zT_50FBF81E_Diagnostic zT_42;
    zT_50FBF81E_Diagnostic* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_46;
    int zT_47;
    int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned char zT_52;
    zT_50FBF81E_Diagnostic* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_56;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    unsigned int i;
    zT_50FBF81E_Diagnostic key;
    int j;
    zT_2 = 1;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_5 = diags.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = diags.ptr;
    zT_9 = diags.len;
    zT_10 = i < zT_9;
    if (!(zT_10)) { pal_trap(); }
    zT_11 = zT_8[i];
    key = zT_11;
    zT_13 = (int)zig_cast_checked_s((zu64)i, 32u, 0u, 32u);
    j = zT_13;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_14 = 0;
    if ((unsigned char)(j > zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_33 = diags.ptr;
    zT_34 = 1;
    zT_35 = zig_wrap_sub_s(((z64)(j)), ((z64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_sub_s(((z64)(j)), ((z64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    zT_39 = (unsigned int)zig_cast_checked_u((zu64)zT_35, 32u, 1u, 32u);
    zT_40 = diags.len;
    zT_41 = zT_39 < zT_40;
    if (!(zT_41)) { pal_trap(); }
    zT_42 = zT_33[zT_39];
    zT_43 = diags.ptr;
    zT_44 = (unsigned int)zig_cast_checked_u((zu64)j, 32u, 1u, 32u);
    zT_45 = diags.len;
    zT_46 = zT_44 < zT_45;
    if (!(zT_46)) { pal_trap(); }
    zT_43[zT_44] = zT_42;
    zT_47 = 1;
    zT_48 = (int)zT_47;
    zT_49 = zig_wrap_sub_s(((z64)(j)), ((z64)(zT_48)), 32u);
    zT_50 = zig_overflow_flag_sub_s(((z64)(j)), ((z64)(zT_48)), 32u);
    zT_52 = zT_50 == (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    j = zT_49;
    goto z_bb_8;
    z_bb_7:
    zT_53 = diags.ptr;
    zT_54 = (unsigned int)zig_cast_checked_u((zu64)j, 32u, 1u, 32u);
    zT_55 = diags.len;
    zT_56 = zT_54 < zT_55;
    if (!(zT_56)) { pal_trap(); }
    zT_53[zT_54] = key;
    zT_57 = 1;
    zT_58 = (unsigned int)zT_57;
    zT_59 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    i = zT_59;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_19 = diags.ptr;
    zT_20 = 1;
    zT_21 = zig_wrap_sub_s(((z64)(j)), ((z64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_sub_s(((z64)(j)), ((z64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_25 = (unsigned int)zig_cast_checked_u((zu64)zT_21, 32u, 1u, 32u);
    zT_26 = diags.len;
    zT_27 = zT_25 < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_19 + zT_25;
    zT_17 = zT_28;
    zT_29 = (zT_50FBF81E_Diagnostic*)&key;
    zT_18 = zT_29;
    zT_30 = zF_36E7146B_compareDiag(zT_17, zT_18);
    zT_31 = 0;
    zT_16 = zT_30 > zT_31;
    goto z_bb_11;
    z_bb_10:
    zT_16 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_16) goto z_bb_6; else goto z_bb_7;
}

/* diagnosticArrayListInit */
zT_C0B2E5AF_DiagnosticArrayList zF_D95B9309_diagnosticArrayList(zT_3E40CD83_Sand* allocator) {
    zT_C0B2E5AF_DiagnosticArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_50FBF81E_Diagnostic*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* diagnosticArrayListEnsureCapacity */
void zF_622A0C29_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_50FBF81E_Diagnostic* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_DD2B0E80_Opt_263 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_FDFD82FD_EU_362 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    zT_50FBF81E_Diagnostic* zT_64;
    zT_50FBF81E_Diagnostic* zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_50FBF81E_Diagnostic* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_71;
    zT_50FBF81E_Diagnostic* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_50FBF81E_Diagnostic* new_items;
    zT_50FBF81E_Diagnostic item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->allocator;
    zT_32 = self->items;
    zT_34 = self->capacity;
    zT_35 = 40;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 40;
    zT_41 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->allocator;
    zT_53 = 40;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (zT_50FBF81E_Diagnostic*)raw;
    new_items = zT_64;
    zT_65 = self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (zT_50FBF81E_Diagnostic*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* diagnosticArrayListAppend */
void zF_075D71E7_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, zT_50FBF81E_Diagnostic value) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_50FBF81E_Diagnostic* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_622A0C29_diagnosticArrayList(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* diagnosticArrayListGetSlice */
zT_8D25846A_Slice_zT_50FBF81E_D zF_88E8322D_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self) {
    zT_50FBF81E_Diagnostic* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_50FBF81E_Diagnostic* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_7;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_50FBF81E_Diagnostic*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* diagnosticCollectorInit */
zT_F85C5DED_DiagnosticCollector zF_C7BA7DAB_diagnosticCollector(zT_3E40CD83_Sand* allocator, zT_227EDE07_SourceManager* source_manager, zT_D3EB6303_StringInterner* interner) {
    zT_3E40CD83_Sand* zT_4;
    zT_FDFD82FD_EU_362 zT_9;
    unsigned char zT_10;
    unsigned char* zT_11;
    zT_C0B2E5AF_DiagnosticArrayList* zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_C0B2E5AF_DiagnosticArrayList zT_16;
    zT_F85C5DED_DiagnosticCollector zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned char* d_raw;
    zT_C0B2E5AF_DiagnosticArrayList* d_ptr;
    zT_4 = allocator;
    zT_9 = zF_1395EB68_sandAlloc(zT_4, (unsigned int)(16), (unsigned int)(4));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    d_raw = zT_11;
    zT_14 = (zT_C0B2E5AF_DiagnosticArrayList*)d_raw;
    d_ptr = zT_14;
    zT_15 = allocator;
    zT_16 = zF_D95B9309_diagnosticArrayList(zT_15);
    *d_ptr = zT_16;
    zT_17.diagnostics = d_ptr;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zT_17.related_span_items = (zT_B258D528_RelatedSpan*)zT_18;
    zT_19 = 0;
    zT_17.related_span_len = zT_19;
    zT_20 = 0;
    zT_17.related_span_cap = zT_20;
    zT_17.allocator = allocator;
    zT_17.source_manager = source_manager;
    zT_17.interner = interner;
    zT_21 = 0;
    zT_17.error_count = zT_21;
    zT_22 = 0;
    zT_17.warning_count = zT_22;
    zT_23 = 256;
    zT_17.max_diagnostics = zT_23;
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zT_17.diag_seen_items = (unsigned int*)zT_24;
    zT_25 = 0;
    zT_17.diag_seen_len = zT_25;
    zT_26 = 0;
    zT_17.diag_seen_cap = zT_26;
    return zT_17;
}

/* diagnosticCollectorIntern */
unsigned int zF_14631FFD_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_D3EB6303_StringInterner* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = self->interner;
    zT_3 = msg;
    zT_5 = zF_50C274AF_stringInternerInter(zT_2, zT_3);
    return zT_5;
}

/* diagnosticCollectorAdd */
unsigned int zF_C82559AC_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned char level, unsigned short code, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u message) {
    int zT_7;
    zT_C0B2E5AF_DiagnosticArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_D3EB6303_StringInterner* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_22;
    zT_C0B2E5AF_DiagnosticArrayList* zT_23;
    zT_50FBF81E_Diagnostic zT_24;
    zT_50FBF81E_Diagnostic zT_26;
    unsigned char zT_27;
    unsigned short zT_28;
    unsigned char zT_29;
    zT_959EEC26_Arr_unsigned_int_3 zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned short zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_50;
    zT_C0B2E5AF_DiagnosticArrayList* zT_51;
    zT_50FBF81E_Diagnostic zT_52;
    zT_50FBF81E_Diagnostic zT_54;
    unsigned char zT_55;
    zT_959EEC26_Arr_unsigned_int_3 zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned short zT_63;
    int zT_64;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    int zT_73;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    zT_C0B2E5AF_DiagnosticArrayList* zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    unsigned int msg_id;
    zT_7 = 9999;
    if ((unsigned char)(code == zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_10 = self->diagnostics;
    zT_11 = zT_10->len;
    zT_12 = self->max_diagnostics;
    if ((unsigned char)(zT_11 >= zT_12)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = "too many errors, stopping";
    zT_17 = 25;
    zT_16.ptr = (unsigned char*)zT_15;
    zT_16.len = zT_17;
    overflow_msg = zT_16;
    zT_19 = self->interner;
    zT_20 = overflow_msg;
    zT_22 = zF_50C274AF_stringInternerInter(zT_19, zT_20);
    msg_id = zT_22;
    zT_23 = self->diagnostics;
    zT_27 = 0;
    zT_26.level = zT_27;
    zT_28 = 9999;
    zT_26.code = zT_28;
    zT_26.file_id = file_id;
    zT_26.span_start = span_start;
    zT_26.span_end = span_end;
    zT_26.message_id = msg_id;
    zT_29 = 0;
    zT_26.note_count = zT_29;
    zT_31 = 0;
    zT_32 = 0;
    zT_30[zT_32] = zT_31;
    zT_33 = 0;
    zT_34 = 1;
    zT_30[zT_34] = zT_33;
    zT_35 = 0;
    zT_36 = 2;
    zT_30[zT_36] = zT_35;
    (void)zT_26.note_ids;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_26.note_ids)) {
        ((unsigned char*)&zT_26.note_ids)[_j] = ((unsigned char*)&zT_30)[_j];
        _j++;
    }
}
    zT_37 = 0;
    zT_26.related_span_idx = zT_37;
    zT_24 = zT_26;
    zF_075D71E7_diagnosticArrayList(zT_23, zT_24);
    zT_38 = self->error_count;
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    zT_41 = zig_wrap_add_u(((zu64)(zT_38)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(zT_38)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    self->error_count = zT_41;
    return (unsigned int)(0);
    z_bb_4:
    zT_47 = self->interner;
    zT_48 = message;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    msg_id = zT_50;
    zT_51 = self->diagnostics;
    zT_54.level = level;
    zT_54.code = code;
    zT_54.file_id = file_id;
    zT_54.span_start = span_start;
    zT_54.span_end = span_end;
    zT_54.message_id = msg_id;
    zT_55 = 0;
    zT_54.note_count = zT_55;
    zT_57 = 0;
    zT_58 = 0;
    zT_56[zT_58] = zT_57;
    zT_59 = 0;
    zT_60 = 1;
    zT_56[zT_60] = zT_59;
    zT_61 = 0;
    zT_62 = 2;
    zT_56[zT_62] = zT_61;
    (void)zT_54.note_ids;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_54.note_ids)) {
        ((unsigned char*)&zT_54.note_ids)[_j] = ((unsigned char*)&zT_56)[_j];
        _j++;
    }
}
    zT_63 = 0;
    zT_54.related_span_idx = zT_63;
    zT_52 = zT_54;
    zF_075D71E7_diagnosticArrayList(zT_51, zT_52);
    zT_64 = 0;
    if ((unsigned char)(level == zT_64)) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_66 = self->error_count;
    zT_67 = 1;
    zT_68 = (unsigned int)zT_67;
    zT_69 = zig_wrap_add_u(((zu64)(zT_66)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_add_u(((zu64)(zT_66)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    self->error_count = zT_69;
    goto z_bb_6;
    z_bb_6:
    zT_82 = self->diagnostics;
    zT_83 = zT_82->len;
    zT_84 = 1;
    zT_85 = zig_wrap_sub_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_sub_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    return (unsigned int)((unsigned int)zT_85);
    z_bb_7:
    zT_73 = 1;
    if ((unsigned char)(level == zT_73)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_75 = self->warning_count;
    zT_76 = 1;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zig_wrap_add_u(((zu64)(zT_75)), ((zu64)(zT_77)), 32u);
    zT_79 = zig_overflow_flag_add_u(((zu64)(zT_75)), ((zu64)(zT_77)), 32u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    self->warning_count = zT_78;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
}

/* diagnosticCollectorHasErrors */
unsigned char zF_8F770780_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    int zT_2;
    zT_1 = self->error_count;
    zT_2 = 0;
    return (unsigned char)(zT_1 > (unsigned int)zT_2);
}

/* diagnosticCollectorErrorCount */
unsigned int zF_4BDFF7E0_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    zT_1 = self->error_count;
    return (unsigned int)((unsigned int)zT_1);
}

/* diagnosticCollectorMarkNodeOnce */
unsigned char zF_4DD9DB2D_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_3E40CD83_Sand* zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zT_FDFD82FD_EU_362 zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int* zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int* zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    unsigned int i;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* items;
    unsigned int ci;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->diag_seen_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->diag_seen_items;
    zT_8 = zT_7[i];
    if ((unsigned char)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->diag_seen_len;
    zT_18 = self->diag_seen_cap;
    if ((unsigned char)(zT_17 >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_11 = 1;
    zT_12 = (unsigned int)zT_11;
    zT_13 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    i = zT_13;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_21 = self->diag_seen_cap;
    if ((unsigned char)(zT_21 < (unsigned int)(16))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_62 = self->diag_seen_items;
    zT_63 = self->diag_seen_len;
    zT_62[zT_63] = node_idx;
    zT_64 = self->diag_seen_len;
    zT_65 = 1;
    zT_66 = (unsigned int)zT_65;
    zT_67 = zig_wrap_add_u(((zu64)(zT_64)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_add_u(((zu64)(zT_64)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    self->diag_seen_len = zT_67;
    return (unsigned char)(1);
    z_bb_9:
    zT_24 = 16;
    goto z_bb_11;
    z_bb_10:
    zT_26 = self->diag_seen_cap;
    zT_27 = 2;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_26)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    goto z_bb_11;
    z_bb_11:
    new_cap = zT_24;
    zT_33 = self->allocator;
    zT_37 = 4;
    zT_38 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    zT_34 = zT_38;
    zT_43 = zF_1395EB68_sandAlloc(zT_33, zT_34, (unsigned int)(4));
    zT_44 = zT_43.is_error;
    if (zT_44) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    pal_trap();
    z_bb_13:
    zT_45 = zT_43.data.payload;
    goto z_bb_14;
    z_bb_14:
    raw = zT_45;
    zT_48 = (unsigned int*)raw;
    items = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    ci = zT_51;
    goto z_bb_15;
    z_bb_15:
    zT_52 = self->diag_seen_len;
    if ((unsigned char)(ci < zT_52)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = self->diag_seen_items;
    zT_55 = zT_54[ci];
    items[ci] = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->diag_seen_items = items;
    self->diag_seen_cap = new_cap;
    goto z_bb_8;
    z_bb_18:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    ci = zT_58;
    goto z_bb_15;
}

/* diagnosticCollectorWarningCount */
unsigned int zF_4AF2092E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    zT_1 = self->warning_count;
    return (unsigned int)((unsigned int)zT_1);
}

/* diagnosticCollectorAddNote */
void zF_426E1F18_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, zT_8F083A69_Slice_zT_0B42B2F8_u note) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_3;
    unsigned int zT_4;
    zT_C0B2E5AF_DiagnosticArrayList* zT_8;
    zT_50FBF81E_Diagnostic* zT_9;
    zT_50FBF81E_Diagnostic* zT_11;
    unsigned char zT_12;
    int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zT_50FBF81E_Diagnostic* d;
    zT_3 = self->diagnostics;
    zT_4 = zT_3->len;
    if ((unsigned char)(diag_idx >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->diagnostics;
    zT_9 = zT_8->items;
    zT_11 = zT_9 + (unsigned int)((unsigned int)diag_idx);
    d = zT_11;
    zT_12 = d->note_count;
    zT_13 = 3;
    if ((unsigned char)(zT_12 < zT_13)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->interner;
    zT_16 = note;
    zT_18 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    zT_19 = d->note_ids;
    zT_20 = d->note_count;
    zT_21 = (unsigned int)zT_20;
    zT_23 = zT_21 < (unsigned int)(3);
    if (!(zT_23)) { pal_trap(); }
    zT_19[zT_21] = zT_18;
    zT_24 = d->note_count;
    zT_25 = 1;
    zT_26 = (unsigned char)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_26)), 8u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_26)), 8u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    d->note_count = zT_27;
    goto z_bb_4;
    z_bb_4:
    return;
}

/* diagnosticCollectorAddRelatedSpan */
void zF_A9049B03_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_6;
    unsigned int zT_7;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_FDFD82FD_EU_362 zT_31;
    unsigned char zT_32;
    unsigned char* zT_33;
    zT_B258D528_RelatedSpan* zT_36;
    zT_B258D528_RelatedSpan zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    int zT_60;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    int zT_65;
    zT_3E40CD83_Sand* zT_68;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_B258D528_RelatedSpan* zT_74;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    zT_DD2B0E80_Opt_263 zT_88;
    unsigned char zT_89;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    zT_3E40CD83_Sand* zT_97;
    unsigned int zT_98;
    zT_FDFD82FD_EU_362 zT_102;
    unsigned char zT_103;
    unsigned char* zT_104;
    zT_B258D528_RelatedSpan* zT_107;
    zT_B258D528_RelatedSpan* zT_108;
    unsigned int zT_109;
    int zT_110;
    zT_B258D528_RelatedSpan* zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_114;
    zT_B258D528_RelatedSpan* zT_115;
    unsigned int zT_116;
    unsigned int zT_121;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned char zT_127;
    zT_3E40CD83_Sand* zT_129;
    unsigned int zT_130;
    zT_FDFD82FD_EU_362 zT_134;
    unsigned char zT_135;
    unsigned char* zT_136;
    zT_B258D528_RelatedSpan* zT_139;
    zT_B258D528_RelatedSpan* zT_140;
    unsigned int zT_141;
    int zT_142;
    zT_B258D528_RelatedSpan* zT_143;
    unsigned int zT_144;
    unsigned char zT_145;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_146;
    zT_B258D528_RelatedSpan* zT_147;
    unsigned int zT_148;
    unsigned int zT_153;
    zT_B258D528_RelatedSpan zT_154;
    zT_B258D528_RelatedSpan* zT_155;
    unsigned int zT_156;
    unsigned int zT_158;
    unsigned short zT_159;
    unsigned int zT_160;
    int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned char zT_166;
    zT_C0B2E5AF_DiagnosticArrayList* zT_167;
    zT_50FBF81E_Diagnostic* zT_168;
    zT_50FBF81E_Diagnostic* zT_170;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    unsigned int msg_id;
    unsigned int seed_cap;
    unsigned char* seed_raw;
    unsigned int new_len;
    zT_B258D528_RelatedSpan* seed_items;
    unsigned int new_cap;
    unsigned short rs_idx;
    zT_DD2B0E80_Opt_263 grown;
    unsigned int sz;
    unsigned char* raw;
    zT_B258D528_RelatedSpan* items;
    zT_B258D528_RelatedSpan item;
    unsigned int i;
    zT_6 = self->diagnostics;
    zT_7 = zT_6->len;
    if ((unsigned char)(diag_idx >= (unsigned int)((unsigned int)zT_7))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_11 = self->interner;
    zT_12 = msg;
    zT_14 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    msg_id = zT_14;
    zT_15 = self->related_span_len;
    zT_16 = 0;
    if ((unsigned char)(zT_15 == (unsigned int)zT_16)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = 8;
    seed_cap = zT_19;
    zT_21 = self->allocator;
    zT_25 = 16;
    zT_26 = zig_wrap_mul_u(((zu64)(zT_25)), ((zu64)(seed_cap)), 32u);
    zT_27 = zig_overflow_flag_mul_u(((zu64)(zT_25)), ((zu64)(seed_cap)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    zT_22 = zT_26;
    zT_31 = zF_1395EB68_sandAlloc(zT_21, zT_22, (unsigned int)(4));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_45 = self->related_span_len;
    zT_46 = 1;
    zT_47 = zig_wrap_add_u(((zu64)(zT_45)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_add_u(((zu64)(zT_45)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    new_len = zT_47;
    zT_51 = self->related_span_cap;
    if ((unsigned char)(new_len >= zT_51)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_33 = zT_31.data.payload;
    goto z_bb_7;
    z_bb_7:
    seed_raw = zT_33;
    zT_36 = (zT_B258D528_RelatedSpan*)seed_raw;
    seed_items = zT_36;
    zT_38 = 0;
    zT_37.span_file_id = zT_38;
    zT_39 = 0;
    zT_37.span_start = zT_39;
    zT_40 = 0;
    zT_37.span_end = zT_40;
    zT_41 = 0;
    zT_37.message_id = zT_41;
    zT_42 = 0;
    seed_items[zT_42] = zT_37;
    self->related_span_items = seed_items;
    self->related_span_cap = seed_cap;
    self->related_span_len = (unsigned int)(1);
    goto z_bb_4;
    z_bb_8:
    zT_54 = self->related_span_cap;
    zT_55 = 2;
    zT_56 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    new_cap = zT_56;
    zT_60 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_60)) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_154.span_file_id = file_id;
    zT_154.span_start = span_start;
    zT_154.span_end = span_end;
    zT_154.message_id = msg_id;
    zT_155 = self->related_span_items;
    zT_156 = self->related_span_len;
    zT_155[zT_156] = zT_154;
    zT_158 = self->related_span_len;
    zT_159 = (unsigned short)zig_cast_checked_u((zu64)zT_158, 32u, 0u, 16u);
    rs_idx = zT_159;
    zT_160 = self->related_span_len;
    zT_161 = 1;
    zT_162 = (unsigned int)zT_161;
    zT_163 = zig_wrap_add_u(((zu64)(zT_160)), ((zu64)(zT_162)), 32u);
    zT_164 = zig_overflow_flag_add_u(((zu64)(zT_160)), ((zu64)(zT_162)), 32u);
    zT_166 = zT_164 == (unsigned int)(0);
    if (!(zT_166)) { pal_trap(); }
    self->related_span_len = zT_163;
    zT_167 = self->diagnostics;
    zT_168 = zT_167->items;
    zT_170 = zT_168 + (unsigned int)((unsigned int)diag_idx);
    zT_170->related_span_idx = rs_idx;
    return;
    z_bb_10:
    zT_62 = 8;
    zT_63 = (unsigned int)zT_62;
    new_cap = zT_63;
    goto z_bb_11;
    z_bb_11:
    zT_64 = self->related_span_cap;
    zT_65 = 0;
    if ((unsigned char)(zT_64 > (unsigned int)zT_65)) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_68 = self->allocator;
    zT_74 = self->related_span_items;
    zT_76 = self->related_span_cap;
    zT_77 = 16;
    zT_78 = zig_wrap_mul_u(((zu64)(zT_76)), ((zu64)(zT_77)), 32u);
    zT_79 = zig_overflow_flag_mul_u(((zu64)(zT_76)), ((zu64)(zT_77)), 32u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    zT_70 = zT_78;
    zT_82 = 16;
    zT_83 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    zT_71 = zT_83;
    zT_88 = zF_33A3D4F8_sandTryReallocInPla(zT_68, (unsigned char*)((unsigned char*)zT_74), zT_70, zT_71, (unsigned int)(4));
    grown = zT_88;
    zT_89 = grown.has_value;
    if (zT_89) goto z_bb_15; else goto z_bb_17;
    z_bb_13:
    goto z_bb_9;
    z_bb_14:
    zT_123 = 16;
    zT_124 = zig_wrap_mul_u(((zu64)(zT_123)), ((zu64)(new_cap)), 32u);
    zT_125 = zig_overflow_flag_mul_u(((zu64)(zT_123)), ((zu64)(new_cap)), 32u);
    zT_127 = zT_125 == (unsigned int)(0);
    if (!(zT_127)) { pal_trap(); }
    sz = zT_124;
    zT_129 = self->allocator;
    zT_130 = sz;
    zT_134 = zF_1395EB68_sandAlloc(zT_129, zT_130, (unsigned int)(4));
    zT_135 = zT_134.is_error;
    if (zT_135) goto z_bb_25; else goto z_bb_26;
    z_bb_15:
    self->related_span_cap = new_cap;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_91 = 16;
    zT_92 = zig_wrap_mul_u(((zu64)(zT_91)), ((zu64)(new_cap)), 32u);
    zT_93 = zig_overflow_flag_mul_u(((zu64)(zT_91)), ((zu64)(new_cap)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    sz = zT_92;
    zT_97 = self->allocator;
    zT_98 = sz;
    zT_102 = zF_1395EB68_sandAlloc(zT_97, zT_98, (unsigned int)(4));
    zT_103 = zT_102.is_error;
    if (zT_103) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    pal_trap();
    z_bb_19:
    zT_104 = zT_102.data.payload;
    goto z_bb_20;
    z_bb_20:
    raw = zT_104;
    zT_107 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_107;
    zT_108 = self->related_span_items;
    zT_109 = self->related_span_len;
    zT_110 = 0;
    zT_111 = zT_108 + zT_110;
    zT_112 = zT_109 - zT_110;
    zT_113 = (unsigned int)zT_110 <= zT_109;
    if (!(zT_113)) { pal_trap(); }
    zT_114.ptr = (zT_B258D528_RelatedSpan*)zT_111;
    zT_114.len = zT_112;
    zT_115 = zT_114.ptr;
    zT_116 = zT_114.len;
    i = 0;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(i < zT_116)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    item = zT_115[i];
    items[i] = item;
    goto z_bb_24;
    z_bb_23:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_16;
    z_bb_24:
    zT_121 = i + (unsigned int)(1);
    i = zT_121;
    goto z_bb_21;
    z_bb_25:
    pal_trap();
    z_bb_26:
    zT_136 = zT_134.data.payload;
    goto z_bb_27;
    z_bb_27:
    raw = zT_136;
    zT_139 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_139;
    zT_140 = self->related_span_items;
    zT_141 = self->related_span_len;
    zT_142 = 0;
    zT_143 = zT_140 + zT_142;
    zT_144 = zT_141 - zT_142;
    zT_145 = (unsigned int)zT_142 <= zT_141;
    if (!(zT_145)) { pal_trap(); }
    zT_146.ptr = (zT_B258D528_RelatedSpan*)zT_143;
    zT_146.len = zT_144;
    zT_147 = zT_146.ptr;
    zT_148 = zT_146.len;
    i = 0;
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(i < zT_148)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    item = zT_147[i];
    items[i] = item;
    goto z_bb_31;
    z_bb_30:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_13;
    z_bb_31:
    zT_153 = i + (unsigned int)(1);
    i = zT_153;
    goto z_bb_28;
}

/* diagnosticCollectorFlushAndExit */
void zF_E7E26C7E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int exit_code) {
    zT_F85C5DED_DiagnosticCollector* zT_2;
    unsigned char zT_3;
    zT_2 = self;
    zF_8E894A93_diagnosticCollector(zT_2);
    zT_3 = (unsigned char)zig_cast_checked_u((zu64)exit_code, 32u, 0u, 8u);
    zF_CDED1A85_exit(zT_3);
    return;
}

/* isIdentStartByte */
unsigned char zF_3D9E01BD_isIdentStartByte(unsigned char c) {
    unsigned char zT_3;
    unsigned char zT_9;
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(122);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_9 = c <= (unsigned char)(90);
    goto z_bb_8;
    z_bb_7:
    zT_9 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_9) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(0);
}

/* isIdentByte */
unsigned char zF_0998A79F_isIdentByte(unsigned char c) {
    unsigned char zT_1;
    unsigned char zT_2;
    unsigned char zT_6;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = c;
    zT_2 = zF_3D9E01BD_isIdentStartByte(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_6 = c <= (unsigned char)(57);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_6) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(0);
}

/* diagnosticCollectorScanIdentSpan */
unsigned char zF_BCEBD9F2_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int file_id, unsigned int from, unsigned int to, unsigned int* out_start, unsigned int* out_end) {
    zT_227EDE07_SourceManager* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_13;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned char zT_34;
    unsigned char* zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned char zT_69;
    unsigned char* zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    unsigned int zT_76;
    unsigned char zT_77;
    unsigned char zT_78;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    unsigned char zT_93;
    unsigned char* zT_94;
    unsigned int zT_95;
    unsigned char zT_96;
    unsigned char zT_97;
    unsigned char zT_100;
    unsigned char* zT_101;
    int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned char zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    unsigned char zT_109;
    int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned char zT_118;
    int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    unsigned char zT_131;
    unsigned char zT_132;
    unsigned char zT_135;
    unsigned char zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    unsigned char zT_139;
    unsigned char zT_141;
    int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned char zT_147;
    int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_132, (unsigned int)sizeof zT_132);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned int limit;
    unsigned int i;
    unsigned char c;
    unsigned int s;
    zT_7 = self->source_manager;
    zT_8 = file_id;
    zT_10 = zF_FFE72B39_sourceManagerGetSou(zT_7, zT_8);
    content = zT_10;
    zT_13 = content.len;
    limit = zT_13;
    if ((unsigned char)((unsigned int)((unsigned int)to) < limit)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = (unsigned int)to;
    limit = zT_16;
    goto z_bb_2;
    z_bb_2:
    zT_18 = (unsigned int)from;
    i = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < limit)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_21 = content.ptr;
    zT_22 = content.len;
    zT_23 = i < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[i];
    c = zT_24;
    if ((unsigned char)(c == (unsigned char)(47))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_28 = 1;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_27 = zT_29 < limit;
    goto z_bb_9;
    z_bb_8:
    zT_27 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_27) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = content.ptr;
    zT_36 = 1;
    zT_37 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_41 = content.len;
    zT_42 = zT_37 < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_35[zT_37];
    zT_34 = zT_43 == (unsigned char)(47);
    goto z_bb_12;
    z_bb_11:
    zT_34 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_15;
    z_bb_14:
    if ((unsigned char)(c == (unsigned char)(47))) goto z_bb_22; else goto z_bb_23;
    z_bb_15:
    if ((unsigned char)(i < limit)) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    i = zT_56;
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_48 = content.ptr;
    zT_49 = content.len;
    zT_50 = i < zT_49;
    if (!(zT_50)) { pal_trap(); }
    zT_51 = zT_48[i];
    zT_47 = zT_51 != (unsigned char)(10);
    goto z_bb_21;
    z_bb_20:
    zT_47 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_47) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_63 = 1;
    zT_64 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_62 = zT_64 < limit;
    goto z_bb_24;
    z_bb_23:
    zT_62 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_62) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_70 = content.ptr;
    zT_71 = 1;
    zT_72 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_71)), 32u);
    zT_73 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_71)), 32u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    zT_76 = content.len;
    zT_77 = zT_72 < zT_76;
    if (!(zT_77)) { pal_trap(); }
    zT_78 = zT_70[zT_72];
    zT_69 = zT_78 == (unsigned char)(42);
    goto z_bb_27;
    z_bb_26:
    zT_69 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_69) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_81 = 2;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    i = zT_83;
    goto z_bb_30;
    z_bb_29:
    zT_131 = c;
    zT_132 = zF_3D9E01BD_isIdentStartByte(zT_131);
    if (zT_132) goto z_bb_43; else goto z_bb_44;
    z_bb_30:
    zT_87 = 1;
    zT_88 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    if ((unsigned char)(zT_88 < limit)) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_113 = 1;
    zT_114 = (unsigned int)zT_113;
    zT_115 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_114)), 32u);
    zT_116 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_114)), 32u);
    zT_118 = zT_116 == (unsigned int)(0);
    if (!(zT_118)) { pal_trap(); }
    i = zT_115;
    goto z_bb_33;
    z_bb_32:
    zT_119 = 1;
    zT_120 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    if ((unsigned char)(zT_120 < limit)) goto z_bb_40; else goto z_bb_42;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_94 = content.ptr;
    zT_95 = content.len;
    zT_96 = i < zT_95;
    if (!(zT_96)) { pal_trap(); }
    zT_97 = zT_94[i];
    if ((unsigned char)(zT_97 == (unsigned char)(42))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_93 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_93) goto z_bb_31; else goto z_bb_32;
    z_bb_37:
    zT_101 = content.ptr;
    zT_102 = 1;
    zT_103 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_102)), 32u);
    zT_104 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_102)), 32u);
    zT_106 = zT_104 == (unsigned int)(0);
    if (!(zT_106)) { pal_trap(); }
    zT_107 = content.len;
    zT_108 = zT_103 < zT_107;
    if (!(zT_108)) { pal_trap(); }
    zT_109 = zT_101[zT_103];
    zT_100 = zT_109 == (unsigned char)(47);
    goto z_bb_39;
    z_bb_38:
    zT_100 = 0;
    goto z_bb_39;
    z_bb_39:
    zT_93 = !zT_100;
    goto z_bb_36;
    z_bb_40:
    zT_125 = 2;
    zT_126 = (unsigned int)zT_125;
    zT_127 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_126)), 32u);
    zT_128 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_126)), 32u);
    zT_130 = zT_128 == (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    i = zT_127;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_6;
    z_bb_42:
    i = limit;
    goto z_bb_41;
    z_bb_43:
    s = i;
    goto z_bb_45;
    z_bb_44:
    zT_151 = 1;
    zT_152 = (unsigned int)zT_151;
    zT_153 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_152)), 32u);
    zT_154 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_152)), 32u);
    zT_156 = zT_154 == (unsigned int)(0);
    if (!(zT_156)) { pal_trap(); }
    i = zT_153;
    goto z_bb_6;
    z_bb_45:
    if ((unsigned char)(i < limit)) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_142 = 1;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_143)), 32u);
    zT_145 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_143)), 32u);
    zT_147 = zT_145 == (unsigned int)(0);
    if (!(zT_147)) { pal_trap(); }
    i = zT_144;
    goto z_bb_48;
    z_bb_47:
    *out_start = (unsigned int)((unsigned int)s);
    *out_end = (unsigned int)((unsigned int)i);
    return (unsigned char)(1);
    z_bb_48:
    goto z_bb_45;
    z_bb_49:
    zT_137 = content.ptr;
    zT_138 = content.len;
    zT_139 = i < zT_138;
    if (!(zT_139)) { pal_trap(); }
    zT_136 = zT_137[i];
    zT_141 = zF_0998A79F_isIdentByte(zT_136);
    zT_135 = zT_141;
    goto z_bb_51;
    z_bb_50:
    zT_135 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_135) goto z_bb_46; else goto z_bb_47;
}

/* diagnosticCollectorFindLastByte */
unsigned int zF_C887E05C_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int file_id, unsigned int from, unsigned int to, unsigned char byte) {
    zT_227EDE07_SourceManager* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_12;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned int limit;
    unsigned int i;
    unsigned int found;
    zT_6 = self->source_manager;
    zT_7 = file_id;
    zT_9 = zF_FFE72B39_sourceManagerGetSou(zT_6, zT_7);
    content = zT_9;
    zT_12 = content.len;
    limit = zT_12;
    if ((unsigned char)((unsigned int)((unsigned int)to) < limit)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = (unsigned int)to;
    limit = zT_15;
    goto z_bb_2;
    z_bb_2:
    zT_17 = (unsigned int)from;
    i = zT_17;
    zT_19 = 4294967295u;
    found = zT_19;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < limit)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_21 = content.ptr;
    zT_22 = content.len;
    zT_23 = i < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[i];
    if ((unsigned char)(zT_24 == byte)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return found;
    z_bb_6:
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_3;
    z_bb_7:
    zT_26 = (unsigned int)i;
    found = zT_26;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* diagnosticCollectorFindFirstByte */
unsigned int zF_DFE292F2_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int file_id, unsigned int from, unsigned int to, unsigned char byte) {
    zT_227EDE07_SourceManager* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_12;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned int limit;
    unsigned int i;
    zT_6 = self->source_manager;
    zT_7 = file_id;
    zT_9 = zF_FFE72B39_sourceManagerGetSou(zT_6, zT_7);
    content = zT_9;
    zT_12 = content.len;
    limit = zT_12;
    if ((unsigned char)((unsigned int)((unsigned int)to) < limit)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = (unsigned int)to;
    limit = zT_15;
    goto z_bb_2;
    z_bb_2:
    zT_17 = (unsigned int)from;
    i = zT_17;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < limit)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = content.ptr;
    zT_20 = content.len;
    zT_21 = i < zT_20;
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_19[i];
    if ((unsigned char)(zT_22 == byte)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (unsigned int)((unsigned int)i);
    z_bb_8:
    goto z_bb_6;
}

/* diagnosticBuilderMakeMsg */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8C4BFF7C_diagnosticBuilderMa(zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u* parts, unsigned int count) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_3E40CD83_Sand* zT_25;
    unsigned int zT_26;
    int zT_29;
    zT_FDFD82FD_EU_362 zT_31;
    unsigned char zT_32;
    unsigned char* zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_46;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char* zT_60;
    unsigned int zT_61;
    unsigned char zT_62;
    unsigned char zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_D3EB6303_StringInterner* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_D3EB6303_StringInterner* zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    unsigned int total;
    unsigned int ci;
    unsigned char* raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    zT_8F083A69_Slice_zT_0B42B2F8_u buf;
    unsigned int pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u part;
    unsigned int pi;
    unsigned int sid;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    total = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ci = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ci < count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = (unsigned int)ci;
    zT_11 = parts[zT_10];
    zT_13 = zT_11.len;
    zT_14 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    total = zT_14;
    goto z_bb_4;
    z_bb_3:
    zT_25 = interner->allocator;
    zT_26 = total;
    zT_29 = 1;
    zT_31 = zF_1395EB68_sandAlloc(zT_25, zT_26, (unsigned int)((unsigned int)zT_29));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    ci = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_35 = "diagnostic message too long";
    zT_37 = 27;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    fallback = zT_36;
    return fallback;
    z_bb_6:
    zT_33 = zT_31.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_33;
    zT_40 = 0;
    zT_41 = raw + zT_40;
    zT_42 = total - zT_40;
    zT_43 = (unsigned int)zT_40 <= total;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (unsigned char*)zT_41;
    zT_44.len = zT_42;
    buf = zT_44;
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    pos = zT_47;
    zT_48 = 0;
    zT_49 = (unsigned int)zT_48;
    ci = zT_49;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(ci < count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_52 = (unsigned int)ci;
    zT_53 = parts[zT_52];
    part = zT_53;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    pi = zT_56;
    goto z_bb_12;
    z_bb_10:
    zT_86 = interner;
    zT_87 = buf;
    zT_88 = zF_50C274AF_stringInternerInter(zT_86, zT_87);
    sid = zT_88;
    zT_89 = interner;
    zT_90 = sid;
    zT_91 = zF_9134020D_stringInternerGet(zT_89, zT_90);
    return zT_91;
    z_bb_11:
    zT_79 = 1;
    zT_80 = (unsigned int)zT_79;
    zT_81 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    ci = zT_81;
    goto z_bb_8;
    z_bb_12:
    zT_58 = part.len;
    if ((unsigned char)(pi < zT_58)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_60 = part.ptr;
    zT_61 = part.len;
    zT_62 = pi < zT_61;
    if (!(zT_62)) { pal_trap(); }
    zT_63 = zT_60[pi];
    zT_64 = buf.ptr;
    zT_65 = buf.len;
    zT_66 = pos < zT_65;
    if (!(zT_66)) { pal_trap(); }
    zT_64[pos] = zT_63;
    zT_67 = 1;
    zT_68 = (unsigned int)zT_67;
    zT_69 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    pos = zT_69;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_73 = 1;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    pi = zT_75;
    goto z_bb_12;
}

/* diagnosticCollectorPrintAll */
void zF_8E894A93_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_227EDE07_SourceManager* zT_5;
    zT_C0B2E5AF_DiagnosticArrayList* zT_8;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_10;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_11;
    int zT_13;
    unsigned int zT_14;
    zT_C0B2E5AF_DiagnosticArrayList* zT_15;
    unsigned int zT_16;
    zT_50FBF81E_Diagnostic* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    zT_50FBF81E_Diagnostic* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned char zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_C1AB0454_Arr_unsigned_char_8 zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned short zT_40;
    int zT_44;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_D3EB6303_StringInterner* zT_74;
    zT_EABC94D3_InternEntry* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_EABC94D3_InternEntry zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    zT_227EDE07_SourceManager* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_5BC08DC6_Location zT_99;
    zT_227EDE07_SourceManager* zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    zT_5426B97B_Arr_unsigned_char_1 zT_113;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    int zT_120;
    int zT_121;
    unsigned char* zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    unsigned char zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    zT_5426B97B_Arr_unsigned_char_1 zT_147;
    unsigned int zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    int zT_154;
    int zT_155;
    unsigned char* zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned char zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_170;
    unsigned char* zT_171;
    unsigned int zT_172;
    unsigned char zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned char zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_C1AB0454_Arr_unsigned_char_8 zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned short zT_194;
    int zT_198;
    int zT_199;
    unsigned char* zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned char zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_214;
    unsigned char* zT_215;
    unsigned int zT_216;
    unsigned char zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned char* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_D3EB6303_StringInterner* zT_228;
    zT_EABC94D3_InternEntry* zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    zT_EABC94D3_InternEntry zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    zT_227EDE07_SourceManager* zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    zT_227EDE07_SourceManager* zT_252;
    unsigned int zT_253;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_256;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_258;
    unsigned int zT_259;
    unsigned int zT_261;
    unsigned int* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned char zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_271;
    int zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned char zT_277;
    unsigned int zT_279;
    unsigned int* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned char zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    int zT_288;
    unsigned char zT_290;
    unsigned char* zT_291;
    int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned char zT_296;
    unsigned int zT_297;
    unsigned char zT_298;
    unsigned char zT_299;
    int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char zT_307;
    unsigned char zT_311;
    unsigned int zT_313;
    unsigned char* zT_316;
    unsigned int zT_317;
    unsigned char* zT_318;
    unsigned int zT_319;
    unsigned char zT_320;
    unsigned char zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned char* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned char zT_338;
    unsigned int zT_339;
    int zT_340;
    int zT_342;
    unsigned int zT_343;
    zT_22590979_Arr_unsigned_char_2 zT_345;
    int zT_347;
    unsigned int zT_348;
    int zT_350;
    int zT_352;
    unsigned int zT_353;
    unsigned char zT_356;
    unsigned char zT_358;
    int zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned char zT_364;
    unsigned int zT_366;
    int zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned char zT_372;
    int zT_374;
    unsigned int zT_375;
    unsigned int zT_376;
    unsigned char zT_378;
    int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned char zT_384;
    int zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned char zT_390;
    unsigned char zT_393;
    unsigned char zT_395;
    int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned char zT_401;
    unsigned int zT_403;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_404;
    int zT_407;
    unsigned char* zT_408;
    unsigned int zT_409;
    unsigned char zT_410;
    unsigned char zT_411;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_412;
    unsigned char* zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    int zT_419;
    unsigned char zT_420;
    unsigned char zT_421;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427;
    zT_D3EB6303_StringInterner* zT_429;
    zT_EABC94D3_InternEntry* zT_430;
    unsigned int* zT_431;
    unsigned int zT_432;
    unsigned char zT_434;
    unsigned int zT_435;
    unsigned int zT_436;
    zT_EABC94D3_InternEntry zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned char* zT_441;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_442;
    unsigned int zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    int zT_445;
    unsigned char zT_446;
    unsigned char zT_447;
    unsigned int zT_448;
    unsigned char zT_450;
    unsigned short zT_451;
    int zT_452;
    unsigned char zT_454;
    unsigned short zT_455;
    unsigned int zT_456;
    unsigned short zT_457;
    zT_B258D528_RelatedSpan* zT_460;
    unsigned short zT_461;
    unsigned int zT_462;
    zT_B258D528_RelatedSpan zT_463;
    zT_227EDE07_SourceManager* zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    zT_5BC08DC6_Location zT_471;
    zT_227EDE07_SourceManager* zT_473;
    unsigned int zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_478;
    unsigned char* zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    zT_5426B97B_Arr_unsigned_char_1 zT_485;
    unsigned int zT_487;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_488;
    int zT_492;
    int zT_493;
    unsigned char* zT_494;
    unsigned int zT_495;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_496;
    unsigned int zT_497;
    unsigned int zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    unsigned char zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    unsigned int zT_508;
    unsigned char* zT_509;
    unsigned int zT_510;
    unsigned char zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned char* zT_514;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_515;
    unsigned int zT_516;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_517;
    zT_D3EB6303_StringInterner* zT_519;
    zT_EABC94D3_InternEntry* zT_520;
    unsigned int zT_521;
    unsigned int zT_522;
    zT_EABC94D3_InternEntry zT_523;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_524;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_525;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    unsigned char zT_536;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_105, (unsigned int)sizeof zT_105);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_159, (unsigned int)sizeof zT_159);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_203, (unsigned int)sizeof zT_203);
    zig_poison_fill((void*)&zT_250, (unsigned int)sizeof zT_250);
    zig_poison_fill((void*)&zT_256, (unsigned int)sizeof zT_256);
    zig_poison_fill((void*)&zT_261, (unsigned int)sizeof zT_261);
    zig_poison_fill((void*)&zT_471, (unsigned int)sizeof zT_471);
    zig_poison_fill((void*)&zT_477, (unsigned int)sizeof zT_477);
    zig_poison_fill((void*)&zT_497, (unsigned int)sizeof zT_497);
    zT_8D25846A_Slice_zT_50FBF81E_D diags;
    unsigned int i;
    zT_50FBF81E_Diagnostic* d;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb0;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf0;
    unsigned int code_len0;
    unsigned int kcs0;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb0;
    zT_5BC08DC6_Location loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s;
    zT_5426B97B_Arr_unsigned_char_1 line_buf;
    unsigned int line_len;
    unsigned int ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s2;
    zT_5426B97B_Arr_unsigned_char_1 col_buf;
    unsigned int col_len;
    unsigned int cs;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf;
    unsigned int code_len;
    unsigned int kcs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb;
    zT_EABC94D3_InternEntry entry0;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl0;
    zT_EABC94D3_InternEntry entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    unsigned int line_start;
    unsigned int line_end;
    unsigned int next_line;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    unsigned int l_start;
    unsigned int l_end;
    zT_8F083A69_Slice_zT_0B42B2F8_u line_text;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl2;
    unsigned int loc_col;
    unsigned int cspan;
    unsigned char n;
    zT_22590979_Arr_unsigned_char_2 caret_buf;
    unsigned int caret_len;
    unsigned int space_count;
    unsigned int _;
    unsigned int ulen;
    unsigned int max_carets;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl3;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_hdr;
    zT_EABC94D3_InternEntry note_entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_nl;
    zT_B258D528_RelatedSpan rs;
    zT_5BC08DC6_Location rs_loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_col_s;
    zT_5426B97B_Arr_unsigned_char_1 rs_line_buf;
    unsigned int rs_line_len;
    unsigned int rls;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_sep;
    zT_EABC94D3_InternEntry rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_nl;
    zT_1 = self->diagnostics;
    zT_2 = zT_1->len;
    zT_3 = 0;
    if ((unsigned char)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->source_manager;
    zF_196FDF3B_sourceManagerResetF(zT_5);
    zT_8 = self->diagnostics;
    zT_10 = zF_88E8322D_diagnosticArrayList(zT_8);
    diags = zT_10;
    zT_11 = diags;
    zF_F6BADF23_sortDiagnostics(zT_11);
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    i = zT_14;
    goto z_bb_3;
    z_bb_3:
    zT_15 = self->diagnostics;
    zT_16 = zT_15->len;
    if ((unsigned char)(i < zT_16)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = diags.ptr;
    zT_20 = diags.len;
    zT_21 = i < zT_20;
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_19 + i;
    d = zT_22;
    zT_23 = d->file_id;
    if ((unsigned char)(zT_23 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = d->level;
    zT_29 = zF_1620F424_getLevelName(zT_27);
    zT_26 = zT_29;
    zF_76BE513B_writeStr(zT_26);
    zT_31 = "[";
    zT_33 = 1;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    lb0 = zT_32;
    zT_34 = lb0;
    zF_76BE513B_writeStr(zT_34);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf0[_i] = zT_36[_i];
        _i++;
    }
}
    zT_40 = d->code;
    zT_44 = 8;
    zT_45 = 0;
    zT_46 = (unsigned char*)((unsigned char*)code_buf0) + zT_45;
    zT_47 = zT_44 - zT_45;
    zT_48.ptr = (unsigned char*)zT_46;
    zT_48.len = zT_47;
    zT_39 = zT_48;
    zT_49 = zF_2FED9490_formatU32((unsigned int)((unsigned int)zT_40), zT_39);
    code_len0 = zT_49;
    zT_51 = 8;
    zT_52 = (unsigned int)code_len0;
    zT_53 = zig_wrap_sub_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_sub_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    kcs0 = zT_53;
    zT_60 = 8;
    zT_61 = (unsigned char*)((unsigned char*)code_buf0) + kcs0;
    zT_62 = zT_60 - kcs0;
    zT_63 = kcs0 <= zT_60;
    if (!(zT_63)) { pal_trap(); }
    zT_64.ptr = (unsigned char*)zT_61;
    zT_64.len = zT_62;
    zT_57 = zT_64;
    zF_76BE513B_writeStr(zT_57);
    zT_66 = "]: ";
    zT_68 = 3;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    rb0 = zT_67;
    zT_69 = rb0;
    zF_76BE513B_writeStr(zT_69);
    zT_70 = d->message_id;
    if ((unsigned char)(zT_70 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_93 = self->source_manager;
    zT_94 = d->file_id;
    zT_95 = d->span_start;
    zT_99 = zF_4966CE4A_sourceManagerGetLoc(zT_93, zT_94, zT_95);
    loc = zT_99;
    zT_101 = self->source_manager;
    zT_102 = d->file_id;
    zT_105 = zF_B7076474_sourceManagerGetFil(zT_101, zT_102);
    fname = zT_105;
    zT_106 = fname;
    zF_76BE513B_writeStr(zT_106);
    zT_108 = ":";
    zT_110 = 1;
    zT_109.ptr = (unsigned char*)zT_108;
    zT_109.len = zT_110;
    col_s = zT_109;
    zT_111 = col_s;
    zF_76BE513B_writeStr(zT_111);
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        line_buf[_i] = zT_113[_i];
        _i++;
    }
}
    zT_115 = loc.line;
    zT_120 = 16;
    zT_121 = 0;
    zT_122 = (unsigned char*)((unsigned char*)line_buf) + zT_121;
    zT_123 = zT_120 - zT_121;
    zT_124.ptr = (unsigned char*)zT_122;
    zT_124.len = zT_123;
    zT_116 = zT_124;
    zT_125 = zF_2FED9490_formatU32(zT_115, zT_116);
    line_len = zT_125;
    zT_127 = 16;
    zT_128 = (unsigned int)line_len;
    zT_129 = zig_wrap_sub_u(((zu64)(zT_127)), ((zu64)(zT_128)), 32u);
    zT_130 = zig_overflow_flag_sub_u(((zu64)(zT_127)), ((zu64)(zT_128)), 32u);
    zT_132 = zT_130 == (unsigned int)(0);
    if (!(zT_132)) { pal_trap(); }
    ls = zT_129;
    zT_136 = 16;
    zT_137 = (unsigned char*)((unsigned char*)line_buf) + ls;
    zT_138 = zT_136 - ls;
    zT_139 = ls <= zT_136;
    if (!(zT_139)) { pal_trap(); }
    zT_140.ptr = (unsigned char*)zT_137;
    zT_140.len = zT_138;
    zT_133 = zT_140;
    zF_76BE513B_writeStr(zT_133);
    zT_142 = ":";
    zT_144 = 1;
    zT_143.ptr = (unsigned char*)zT_142;
    zT_143.len = zT_144;
    col_s2 = zT_143;
    zT_145 = col_s2;
    zF_76BE513B_writeStr(zT_145);
    zig_poison_fill((void*)&zT_147, (unsigned int)sizeof zT_147);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        col_buf[_i] = zT_147[_i];
        _i++;
    }
}
    zT_149 = loc.col;
    zT_154 = 16;
    zT_155 = 0;
    zT_156 = (unsigned char*)((unsigned char*)col_buf) + zT_155;
    zT_157 = zT_154 - zT_155;
    zT_158.ptr = (unsigned char*)zT_156;
    zT_158.len = zT_157;
    zT_150 = zT_158;
    zT_159 = zF_2FED9490_formatU32(zT_149, zT_150);
    col_len = zT_159;
    zT_161 = 16;
    zT_162 = (unsigned int)col_len;
    zT_163 = zig_wrap_sub_u(((zu64)(zT_161)), ((zu64)(zT_162)), 32u);
    zT_164 = zig_overflow_flag_sub_u(((zu64)(zT_161)), ((zu64)(zT_162)), 32u);
    zT_166 = zT_164 == (unsigned int)(0);
    if (!(zT_166)) { pal_trap(); }
    cs = zT_163;
    zT_170 = 16;
    zT_171 = (unsigned char*)((unsigned char*)col_buf) + cs;
    zT_172 = zT_170 - cs;
    zT_173 = cs <= zT_170;
    if (!(zT_173)) { pal_trap(); }
    zT_174.ptr = (unsigned char*)zT_171;
    zT_174.len = zT_172;
    zT_167 = zT_174;
    zF_76BE513B_writeStr(zT_167);
    zT_176 = ": ";
    zT_178 = 2;
    zT_177.ptr = (unsigned char*)zT_176;
    zT_177.len = zT_178;
    sep = zT_177;
    zT_179 = sep;
    zF_76BE513B_writeStr(zT_179);
    zT_181 = d->level;
    zT_183 = zF_1620F424_getLevelName(zT_181);
    zT_180 = zT_183;
    zF_76BE513B_writeStr(zT_180);
    zT_185 = "[";
    zT_187 = 1;
    zT_186.ptr = (unsigned char*)zT_185;
    zT_186.len = zT_187;
    lb = zT_186;
    zT_188 = lb;
    zF_76BE513B_writeStr(zT_188);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf[_i] = zT_190[_i];
        _i++;
    }
}
    zT_194 = d->code;
    zT_198 = 8;
    zT_199 = 0;
    zT_200 = (unsigned char*)((unsigned char*)code_buf) + zT_199;
    zT_201 = zT_198 - zT_199;
    zT_202.ptr = (unsigned char*)zT_200;
    zT_202.len = zT_201;
    zT_193 = zT_202;
    zT_203 = zF_2FED9490_formatU32((unsigned int)((unsigned int)zT_194), zT_193);
    code_len = zT_203;
    zT_205 = 8;
    zT_206 = (unsigned int)code_len;
    zT_207 = zig_wrap_sub_u(((zu64)(zT_205)), ((zu64)(zT_206)), 32u);
    zT_208 = zig_overflow_flag_sub_u(((zu64)(zT_205)), ((zu64)(zT_206)), 32u);
    zT_210 = zT_208 == (unsigned int)(0);
    if (!(zT_210)) { pal_trap(); }
    kcs = zT_207;
    zT_214 = 8;
    zT_215 = (unsigned char*)((unsigned char*)code_buf) + kcs;
    zT_216 = zT_214 - kcs;
    zT_217 = kcs <= zT_214;
    if (!(zT_217)) { pal_trap(); }
    zT_218.ptr = (unsigned char*)zT_215;
    zT_218.len = zT_216;
    zT_211 = zT_218;
    zF_76BE513B_writeStr(zT_211);
    zT_220 = "]: ";
    zT_222 = 3;
    zT_221.ptr = (unsigned char*)zT_220;
    zT_221.len = zT_222;
    rb = zT_221;
    zT_223 = rb;
    zF_76BE513B_writeStr(zT_223);
    zT_224 = d->message_id;
    if ((unsigned char)(zT_224 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_74 = self->interner;
    zT_75 = zT_74->entries_items;
    zT_76 = d->message_id;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zT_75[zT_77];
    entry0 = zT_78;
    zT_80 = entry0.text;
    zT_79 = zT_80;
    zF_76BE513B_writeStr(zT_79);
    goto z_bb_10;
    z_bb_10:
    zT_82 = "\n";
    zT_84 = 1;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    nl0 = zT_83;
    zT_85 = nl0;
    zF_76BE513B_writeStr(zT_85);
    zT_86 = 1;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_87)), 32u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    i = zT_88;
    goto z_bb_6;
    z_bb_11:
    zT_228 = self->interner;
    zT_229 = zT_228->entries_items;
    zT_230 = d->message_id;
    zT_231 = (unsigned int)zT_230;
    zT_232 = zT_229[zT_231];
    entry = zT_232;
    zT_234 = entry.text;
    zT_233 = zT_234;
    zF_76BE513B_writeStr(zT_233);
    goto z_bb_12;
    z_bb_12:
    zT_241 = "\n";
    zT_243 = 1;
    zT_242.ptr = (unsigned char*)zT_241;
    zT_242.len = zT_243;
    nl = zT_242;
    zT_244 = nl;
    zF_76BE513B_writeStr(zT_244);
    zT_246 = self->source_manager;
    zT_247 = d->file_id;
    zT_250 = zF_FFE72B39_sourceManagerGetSou(zT_246, zT_247);
    content = zT_250;
    zT_252 = self->source_manager;
    zT_253 = d->file_id;
    zT_256 = zF_5041A561_sourceManagerGetLin(zT_252, zT_253);
    offsets = zT_256;
    zT_258 = offsets;
    zT_259 = d->span_start;
    zT_261 = zF_1457D8A5_binary_search(zT_258, zT_259);
    line_idx = zT_261;
    zT_263 = offsets.ptr;
    zT_264 = (unsigned int)line_idx;
    zT_265 = offsets.len;
    zT_266 = zT_264 < zT_265;
    if (!(zT_266)) { pal_trap(); }
    zT_267 = zT_263[zT_264];
    zT_268 = (unsigned int)zT_267;
    line_start = zT_268;
    zT_271 = content.len;
    line_end = zT_271;
    zT_273 = 1;
    zT_274 = zig_wrap_add_u(((zu64)(line_idx)), ((zu64)(zT_273)), 32u);
    zT_275 = zig_overflow_flag_add_u(((zu64)(line_idx)), ((zu64)(zT_273)), 32u);
    zT_277 = zT_275 == (unsigned int)(0);
    if (!(zT_277)) { pal_trap(); }
    next_line = zT_274;
    zT_279 = offsets.len;
    if ((unsigned char)(next_line < (unsigned int)((unsigned int)zT_279))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_236 = "(no message)";
    zT_238 = 12;
    zT_237.ptr = (unsigned char*)zT_236;
    zT_237.len = zT_238;
    em = zT_237;
    zT_239 = em;
    zF_76BE513B_writeStr(zT_239);
    goto z_bb_12;
    z_bb_14:
    zT_282 = offsets.ptr;
    zT_283 = (unsigned int)next_line;
    zT_284 = offsets.len;
    zT_285 = zT_283 < zT_284;
    if (!(zT_285)) { pal_trap(); }
    zT_286 = zT_282[zT_283];
    zT_287 = (unsigned int)zT_286;
    line_end = zT_287;
    zT_288 = 0;
    if ((unsigned char)(line_end > (unsigned int)zT_288)) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    l_start = line_start;
    l_end = line_end;
    if ((unsigned char)(l_start < l_end)) goto z_bb_21; else goto z_bb_22;
    z_bb_16:
    zT_291 = content.ptr;
    zT_292 = 1;
    zT_293 = zig_wrap_sub_u(((zu64)(line_end)), ((zu64)(zT_292)), 32u);
    zT_294 = zig_overflow_flag_sub_u(((zu64)(line_end)), ((zu64)(zT_292)), 32u);
    zT_296 = zT_294 == (unsigned int)(0);
    if (!(zT_296)) { pal_trap(); }
    zT_297 = content.len;
    zT_298 = zT_293 < zT_297;
    if (!(zT_298)) { pal_trap(); }
    zT_299 = zT_291[zT_293];
    zT_290 = zT_299 == (unsigned char)(10);
    goto z_bb_18;
    z_bb_17:
    zT_290 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_290) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_302 = 1;
    zT_303 = (unsigned int)zT_302;
    zT_304 = zig_wrap_sub_u(((zu64)(line_end)), ((zu64)(zT_303)), 32u);
    zT_305 = zig_overflow_flag_sub_u(((zu64)(line_end)), ((zu64)(zT_303)), 32u);
    zT_307 = zT_305 == (unsigned int)(0);
    if (!(zT_307)) { pal_trap(); }
    line_end = zT_304;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_313 = content.len;
    zT_311 = l_end <= zT_313;
    goto z_bb_23;
    z_bb_22:
    zT_311 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_311) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_316 = content.ptr;
    zT_317 = content.len;
    zT_318 = zT_316 + l_start;
    zT_319 = l_end - l_start;
    zT_320 = l_start <= l_end;
    if (!(zT_320)) { pal_trap(); }
    zT_321 = l_end <= zT_317;
    if (!(zT_321)) { pal_trap(); }
    zT_322.ptr = (unsigned char*)zT_318;
    zT_322.len = zT_319;
    line_text = zT_322;
    zT_323 = line_text;
    zF_76BE513B_writeStr(zT_323);
    zT_325 = "\n";
    zT_327 = 1;
    zT_326.ptr = (unsigned char*)zT_325;
    zT_326.len = zT_327;
    nl2 = zT_326;
    zT_328 = nl2;
    zF_76BE513B_writeStr(zT_328);
    zT_330 = loc.col;
    zT_331 = (unsigned int)zT_330;
    loc_col = zT_331;
    zT_333 = d->span_end;
    zT_334 = d->span_start;
    zT_335 = zig_wrap_sub_u(((zu64)(zT_333)), ((zu64)(zT_334)), 32u);
    zT_336 = zig_overflow_flag_sub_u(((zu64)(zT_333)), ((zu64)(zT_334)), 32u);
    zT_338 = zT_336 == (unsigned int)(0);
    if (!(zT_338)) { pal_trap(); }
    zT_339 = (unsigned int)zT_335;
    cspan = zT_339;
    zT_340 = 0;
    if ((unsigned char)(cspan == (unsigned int)zT_340)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_419 = 0;
    zT_420 = (unsigned char)zT_419;
    n = zT_420;
    goto z_bb_42;
    z_bb_26:
    zT_342 = 1;
    zT_343 = (unsigned int)zT_342;
    cspan = zT_343;
    goto z_bb_27;
    z_bb_27:
    zig_poison_fill((void*)&zT_345, (unsigned int)sizeof zT_345);
    {
    unsigned int _i = 0;
    while (_i < 256) {
        caret_buf[_i] = zT_345[_i];
        _i++;
    }
}
    zT_347 = 0;
    zT_348 = (unsigned int)zT_347;
    caret_len = zT_348;
    space_count = loc_col;
    zT_350 = 256;
    if ((unsigned char)(space_count > (unsigned int)zT_350)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_352 = 256;
    zT_353 = (unsigned int)zT_352;
    space_count = zT_353;
    goto z_bb_29;
    z_bb_29:
    _ = 0;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)((unsigned int)_ < space_count)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_356 = 32;
    zT_358 = caret_len < (unsigned int)(256);
    if (!(zT_358)) { pal_trap(); }
    caret_buf[caret_len] = zT_356;
    zT_359 = 1;
    zT_360 = (unsigned int)zT_359;
    zT_361 = zig_wrap_add_u(((zu64)(caret_len)), ((zu64)(zT_360)), 32u);
    zT_362 = zig_overflow_flag_add_u(((zu64)(caret_len)), ((zu64)(zT_360)), 32u);
    zT_364 = zT_362 == (unsigned int)(0);
    if (!(zT_364)) { pal_trap(); }
    caret_len = zT_361;
    goto z_bb_33;
    z_bb_32:
    ulen = cspan;
    zT_368 = 256;
    zT_369 = zig_wrap_sub_u(((zu64)(zT_368)), ((zu64)(loc_col)), 32u);
    zT_370 = zig_overflow_flag_sub_u(((zu64)(zT_368)), ((zu64)(loc_col)), 32u);
    zT_372 = zT_370 == (unsigned int)(0);
    if (!(zT_372)) { pal_trap(); }
    if ((unsigned char)(ulen > zT_369)) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_366 = _ + (unsigned int)(1);
    _ = zT_366;
    goto z_bb_30;
    z_bb_34:
    zT_374 = 256;
    zT_375 = zig_wrap_sub_u(((zu64)(zT_374)), ((zu64)(loc_col)), 32u);
    zT_376 = zig_overflow_flag_sub_u(((zu64)(zT_374)), ((zu64)(loc_col)), 32u);
    zT_378 = zT_376 == (unsigned int)(0);
    if (!(zT_378)) { pal_trap(); }
    ulen = zT_375;
    goto z_bb_35;
    z_bb_35:
    max_carets = ulen;
    zT_380 = 256;
    zT_381 = zig_wrap_sub_u(((zu64)(zT_380)), ((zu64)(caret_len)), 32u);
    zT_382 = zig_overflow_flag_sub_u(((zu64)(zT_380)), ((zu64)(caret_len)), 32u);
    zT_384 = zT_382 == (unsigned int)(0);
    if (!(zT_384)) { pal_trap(); }
    if ((unsigned char)(max_carets > zT_381)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_386 = 256;
    zT_387 = zig_wrap_sub_u(((zu64)(zT_386)), ((zu64)(caret_len)), 32u);
    zT_388 = zig_overflow_flag_sub_u(((zu64)(zT_386)), ((zu64)(caret_len)), 32u);
    zT_390 = zT_388 == (unsigned int)(0);
    if (!(zT_390)) { pal_trap(); }
    max_carets = zT_387;
    goto z_bb_37;
    z_bb_37:
    _ = 0;
    goto z_bb_38;
    z_bb_38:
    if ((unsigned char)((unsigned int)_ < max_carets)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_393 = 94;
    zT_395 = caret_len < (unsigned int)(256);
    if (!(zT_395)) { pal_trap(); }
    caret_buf[caret_len] = zT_393;
    zT_396 = 1;
    zT_397 = (unsigned int)zT_396;
    zT_398 = zig_wrap_add_u(((zu64)(caret_len)), ((zu64)(zT_397)), 32u);
    zT_399 = zig_overflow_flag_add_u(((zu64)(caret_len)), ((zu64)(zT_397)), 32u);
    zT_401 = zT_399 == (unsigned int)(0);
    if (!(zT_401)) { pal_trap(); }
    caret_len = zT_398;
    goto z_bb_41;
    z_bb_40:
    zT_407 = 0;
    zT_408 = (unsigned char*)((unsigned char*)caret_buf) + zT_407;
    zT_409 = caret_len - zT_407;
    zT_410 = (unsigned int)zT_407 <= caret_len;
    if (!(zT_410)) { pal_trap(); }
    zT_411 = caret_len <= (unsigned int)(256);
    if (!(zT_411)) { pal_trap(); }
    zT_412.ptr = (unsigned char*)zT_408;
    zT_412.len = zT_409;
    zT_404 = zT_412;
    zF_76BE513B_writeStr(zT_404);
    zT_414 = "\n";
    zT_416 = 1;
    zT_415.ptr = (unsigned char*)zT_414;
    zT_415.len = zT_416;
    nl3 = zT_415;
    zT_417 = nl3;
    zF_76BE513B_writeStr(zT_417);
    goto z_bb_25;
    z_bb_41:
    zT_403 = _ + (unsigned int)(1);
    _ = zT_403;
    goto z_bb_38;
    z_bb_42:
    zT_421 = d->note_count;
    if ((unsigned char)(n < zT_421)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_424 = "note: ";
    zT_426 = 6;
    zT_425.ptr = (unsigned char*)zT_424;
    zT_425.len = zT_426;
    note_hdr = zT_425;
    zT_427 = note_hdr;
    zF_76BE513B_writeStr(zT_427);
    zT_429 = self->interner;
    zT_430 = zT_429->entries_items;
    zT_431 = d->note_ids;
    zT_432 = (unsigned int)n;
    zT_434 = zT_432 < (unsigned int)(3);
    if (!(zT_434)) { pal_trap(); }
    zT_435 = zT_431[zT_432];
    zT_436 = (unsigned int)zT_435;
    zT_437 = zT_430[zT_436];
    note_entry = zT_437;
    zT_439 = note_entry.text;
    zT_438 = zT_439;
    zF_76BE513B_writeStr(zT_438);
    zT_441 = "\n";
    zT_443 = 1;
    zT_442.ptr = (unsigned char*)zT_441;
    zT_442.len = zT_443;
    note_nl = zT_442;
    zT_444 = note_nl;
    zF_76BE513B_writeStr(zT_444);
    zT_445 = 1;
    zT_446 = (unsigned char)zT_445;
    zT_447 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_446)), 8u);
    zT_448 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_446)), 8u);
    zT_450 = zT_448 == (unsigned int)(0);
    if (!(zT_450)) { pal_trap(); }
    n = zT_447;
    goto z_bb_45;
    z_bb_44:
    zT_451 = d->related_span_idx;
    zT_452 = 0;
    if ((unsigned char)(zT_451 > zT_452)) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_455 = d->related_span_idx;
    zT_456 = self->related_span_len;
    zT_457 = (unsigned short)zig_cast_checked_u((zu64)zT_456, 32u, 0u, 16u);
    zT_454 = zT_455 < zT_457;
    goto z_bb_48;
    z_bb_47:
    zT_454 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_454) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_460 = self->related_span_items;
    zT_461 = d->related_span_idx;
    zT_462 = (unsigned int)zT_461;
    zT_463 = zT_460[zT_462];
    rs = zT_463;
    zT_465 = self->source_manager;
    zT_466 = rs.span_file_id;
    zT_467 = rs.span_start;
    zT_471 = zF_4966CE4A_sourceManagerGetLoc(zT_465, zT_466, zT_467);
    rs_loc = zT_471;
    zT_473 = self->source_manager;
    zT_474 = rs.span_file_id;
    zT_477 = zF_B7076474_sourceManagerGetFil(zT_473, zT_474);
    rs_fname = zT_477;
    zT_478 = rs_fname;
    zF_76BE513B_writeStr(zT_478);
    zT_480 = ":";
    zT_482 = 1;
    zT_481.ptr = (unsigned char*)zT_480;
    zT_481.len = zT_482;
    rs_col_s = zT_481;
    zT_483 = rs_col_s;
    zF_76BE513B_writeStr(zT_483);
    zig_poison_fill((void*)&zT_485, (unsigned int)sizeof zT_485);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        rs_line_buf[_i] = zT_485[_i];
        _i++;
    }
}
    zT_487 = rs_loc.line;
    zT_492 = 16;
    zT_493 = 0;
    zT_494 = (unsigned char*)((unsigned char*)rs_line_buf) + zT_493;
    zT_495 = zT_492 - zT_493;
    zT_496.ptr = (unsigned char*)zT_494;
    zT_496.len = zT_495;
    zT_488 = zT_496;
    zT_497 = zF_2FED9490_formatU32(zT_487, zT_488);
    rs_line_len = zT_497;
    zT_499 = 16;
    zT_500 = (unsigned int)rs_line_len;
    zT_501 = zig_wrap_sub_u(((zu64)(zT_499)), ((zu64)(zT_500)), 32u);
    zT_502 = zig_overflow_flag_sub_u(((zu64)(zT_499)), ((zu64)(zT_500)), 32u);
    zT_504 = zT_502 == (unsigned int)(0);
    if (!(zT_504)) { pal_trap(); }
    rls = zT_501;
    zT_508 = 16;
    zT_509 = (unsigned char*)((unsigned char*)rs_line_buf) + rls;
    zT_510 = zT_508 - rls;
    zT_511 = rls <= zT_508;
    if (!(zT_511)) { pal_trap(); }
    zT_512.ptr = (unsigned char*)zT_509;
    zT_512.len = zT_510;
    zT_505 = zT_512;
    zF_76BE513B_writeStr(zT_505);
    zT_514 = ": note: ";
    zT_516 = 8;
    zT_515.ptr = (unsigned char*)zT_514;
    zT_515.len = zT_516;
    rs_sep = zT_515;
    zT_517 = rs_sep;
    zF_76BE513B_writeStr(zT_517);
    zT_519 = self->interner;
    zT_520 = zT_519->entries_items;
    zT_521 = rs.message_id;
    zT_522 = (unsigned int)zT_521;
    zT_523 = zT_520[zT_522];
    rs_msg = zT_523;
    zT_525 = rs_msg.text;
    zT_524 = zT_525;
    zF_76BE513B_writeStr(zT_524);
    zT_527 = "\n";
    zT_529 = 1;
    zT_528.ptr = (unsigned char*)zT_527;
    zT_528.len = zT_529;
    rs_nl = zT_528;
    zT_530 = rs_nl;
    zF_76BE513B_writeStr(zT_530);
    goto z_bb_50;
    z_bb_50:
    zT_531 = 1;
    zT_532 = (unsigned int)zT_531;
    zT_533 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_532)), 32u);
    zT_534 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_532)), 32u);
    zT_536 = zT_534 == (unsigned int)(0);
    if (!(zT_536)) { pal_trap(); }
    i = zT_533;
    goto z_bb_6;
}

/* typeKindSrcStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C14453DE_typeKindSrcStr(zT_33EF6BFB_TypeKind kind) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "source: void";
    zT_4 = 12;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    zT_6 = "source: bool";
    zT_8 = 12;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    zT_10 = "source: comptime_int";
    zT_12 = 20;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    zT_14 = "source: i8";
    zT_16 = 10;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    zT_18 = "source: i16";
    zT_20 = 11;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    zT_22 = "source: i32";
    zT_24 = 11;
    zT_23.ptr = (unsigned char*)zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    zT_26 = "source: i64";
    zT_28 = 11;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    zT_30 = "source: u8";
    zT_32 = 10;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    zT_34 = "source: u16";
    zT_36 = 11;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    zT_38 = "source: u32";
    zT_40 = 11;
    zT_39.ptr = (unsigned char*)zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    zT_42 = "source: u64";
    zT_44 = 11;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    zT_46 = "source: f32";
    zT_48 = 11;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    zT_50 = "source: f64";
    zT_52 = 11;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    zT_54 = "source: pointer";
    zT_56 = 15;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    zT_58 = "source: many-pointer";
    zT_60 = 20;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    zT_62 = "source: slice";
    zT_64 = 13;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    zT_66 = "source: optional";
    zT_68 = 16;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    zT_70 = "source: error-union";
    zT_72 = 19;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    zT_74 = "source: error-set";
    zT_76 = 17;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    zT_78 = "source: array";
    zT_80 = 13;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    zT_82 = "source: struct";
    zT_84 = 14;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    zT_86 = "source: enum";
    zT_88 = 12;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    zT_90 = "source: union";
    zT_92 = 13;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    zT_94 = "source: tagged-union";
    zT_96 = 20;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    zT_98 = "source: function";
    zT_100 = 16;
    zT_99.ptr = (unsigned char*)zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    zT_102 = "source: tuple";
    zT_104 = 13;
    zT_103.ptr = (unsigned char*)zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    zT_106 = "source: null";
    zT_108 = 12;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    zT_110 = "source: noreturn";
    zT_112 = 16;
    zT_111.ptr = (unsigned char*)zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    zT_114 = "source: type";
    zT_116 = 12;
    zT_115.ptr = (unsigned char*)zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* typeKindTgtStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_CC479241_typeKindTgtStr(zT_33EF6BFB_TypeKind kind) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "target: void";
    zT_4 = 12;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    zT_6 = "target: bool";
    zT_8 = 12;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    zT_10 = "target: comptime_int";
    zT_12 = 20;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    zT_14 = "target: i8";
    zT_16 = 10;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    zT_18 = "target: i16";
    zT_20 = 11;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    zT_22 = "target: i32";
    zT_24 = 11;
    zT_23.ptr = (unsigned char*)zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    zT_26 = "target: i64";
    zT_28 = 11;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    zT_30 = "target: u8";
    zT_32 = 10;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    zT_34 = "target: u16";
    zT_36 = 11;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    zT_38 = "target: u32";
    zT_40 = 11;
    zT_39.ptr = (unsigned char*)zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    zT_42 = "target: u64";
    zT_44 = 11;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    zT_46 = "target: f32";
    zT_48 = 11;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    zT_50 = "target: f64";
    zT_52 = 11;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    zT_54 = "target: pointer";
    zT_56 = 15;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    zT_58 = "target: many-pointer";
    zT_60 = 20;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    zT_62 = "target: slice";
    zT_64 = 13;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    zT_66 = "target: optional";
    zT_68 = 16;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    zT_70 = "target: error-union";
    zT_72 = 19;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    zT_74 = "target: error-set";
    zT_76 = 17;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    zT_78 = "target: array";
    zT_80 = 13;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    zT_82 = "target: struct";
    zT_84 = 14;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    zT_86 = "target: enum";
    zT_88 = 12;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    zT_90 = "target: union";
    zT_92 = 13;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    zT_94 = "target: tagged-union";
    zT_96 = 20;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    zT_98 = "target: function";
    zT_100 = 16;
    zT_99.ptr = (unsigned char*)zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    zT_102 = "target: tuple";
    zT_104 = 13;
    zT_103.ptr = (unsigned char*)zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    zT_106 = "target: null";
    zT_108 = 12;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    zT_110 = "target: noreturn";
    zT_112 = 16;
    zT_111.ptr = (unsigned char*)zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    zT_114 = "target: type";
    zT_116 = 12;
    zT_115.ptr = (unsigned char*)zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* __module_init */
void zF_780653D2___module_init_3(void) {
    zT_227EDE07_SourceManager zT_0;
    zT_D3EB6303_StringInterner zT_1;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zG_227EDE07_SourceManager = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    return;
}

/* EOF */
