#ifndef ZIG_MODULE_ANALYZER_2FA863C8_H
#define ZIG_MODULE_ANALYZER_2FA863C8_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "ast_2FA12982.h"
#include "type_registry_8EE489B8.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "allocator_E75B7A0B.h"
#include "state_map_1CD0D172.h"
#include "symbol_table_74081C75.h"
#include "comptime_eval_02C4526F.h"
#include "import_resolver_58BB752E.h"
#include "itoa_4E677A6A.h"

#ifndef ZIG_STRUCT_zT_7A19C4A5_DeferEntry
#define ZIG_STRUCT_zT_7A19C4A5_DeferEntry
struct zT_7A19C4A5_DeferEntry {
	unsigned char kind;
	unsigned int stmt_idx;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_7A19C4A5_DeferEntry */
#ifndef ZIG_ENUM_zT_E48CAD8A_PtrState
#define ZIG_ENUM_zT_E48CAD8A_PtrState
typedef unsigned char zT_E48CAD8A_PtrState;
#define zT_E48CAD8A_PtrState_uninit 10
#define zT_E48CAD8A_PtrState_is_null 11
#define zT_E48CAD8A_PtrState_safe 12
#define zT_E48CAD8A_PtrState_maybe 13

#endif /* ZIG_ENUM_zT_E48CAD8A_PtrState */
#ifndef ZIG_ENUM_zT_32E64562_Provenance
#define ZIG_ENUM_zT_32E64562_Provenance
typedef unsigned char zT_32E64562_Provenance;
#define zT_32E64562_Provenance_unknown 0
#define zT_32E64562_Provenance_local 1
#define zT_32E64562_Provenance_param 2
#define zT_32E64562_Provenance_param_addr 3
#define zT_32E64562_Provenance_global 4
#define zT_32E64562_Provenance_heap 5
#define zT_32E64562_Provenance_external 6
#define zT_32E64562_Provenance_local_array 7

#endif /* ZIG_ENUM_zT_32E64562_Provenance */
#ifndef ZIG_ENUM_zT_480593AB_AllocState
#define ZIG_ENUM_zT_480593AB_AllocState
typedef unsigned char zT_480593AB_AllocState;
#define zT_480593AB_AllocState_untracked 0
#define zT_480593AB_AllocState_allocated 1
#define zT_480593AB_AllocState_freed 2
#define zT_480593AB_AllocState_returned_val 3
#define zT_480593AB_AllocState_transferred 4
#define zT_480593AB_AllocState_unknown 5
#define zT_480593AB_AllocState_freed_reported 6

#endif /* ZIG_ENUM_zT_480593AB_AllocState */
#ifndef ZIG_STRUCT_zT_E8C0B717_AliasClassSummary
#define ZIG_STRUCT_zT_E8C0B717_AliasClassSummary
struct zT_E8C0B717_AliasClassSummary {
	unsigned char saw_any;
	unsigned char saw_allocated;
	unsigned char saw_freed;
	unsigned char saw_unowned;
};
#endif /* ZIG_STRUCT_zT_E8C0B717_AliasClassSummary */
#ifndef ZIG_STRUCT_zT_F09D0ED6_StmtWalk
#define ZIG_STRUCT_zT_F09D0ED6_StmtWalk
struct zT_F09D0ED6_StmtWalk {
	zT_7E2F335A_AnalyzerContext* ctx;
	zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt;
	zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn;
	unsigned char internal;
	zT_5E506466_StmtWork* items;
	unsigned int len;
	unsigned int cap;
};
#endif /* ZIG_STRUCT_zT_F09D0ED6_StmtWalk */
#ifndef ZIG_STRUCT_zT_7E2F335A_AnalyzerContext
#define ZIG_STRUCT_zT_7E2F335A_AnalyzerContext
struct zT_7E2F335A_AnalyzerContext {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* registry;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_060CD1EB_SymbolTable* symbols;
	zT_3E40CD83_Sand* alloc;
	unsigned int current_fn_name;
	zT_7A19C4A5_DeferEntry* defer_queue_items;
	unsigned int defer_queue_len;
	unsigned int defer_queue_cap;
	zT_3E40CD83_Sand* defer_queue_alloc;
	unsigned int current_depth;
	unsigned char null_analysis_mode;
	unsigned char skip_null_check;
	unsigned char skip_lifetime_check;
	unsigned char skip_doublefree_check;
	unsigned char warn_all;
	zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt_cb;
	unsigned char in_defer_exec;
	unsigned char lifetime_analysis_mode;
	unsigned char doublefree_analysis_mode;
	unsigned int source_file_id;
	zT_86A5306E_Opt_315 comptime_folds;
	zT_E12B14CC_Opt_267 symbol_reg;
	unsigned char target_is_windows;
	unsigned int current_fn_span_start;
	unsigned int current_fn_span_end;
};
#endif /* ZIG_STRUCT_zT_7E2F335A_AnalyzerContext */
#ifndef ZIG_STRUCT_zT_5E506466_StmtWork
#define ZIG_STRUCT_zT_5E506466_StmtWork
struct zT_5E506466_StmtWork {
	unsigned char tag;
	zT_2C0927B0_StateMap* state;
	zT_2C0927B0_StateMap* alt;
	zT_2C0927B0_StateMap* exit_state;
	unsigned int node_idx;
	unsigned int saved_depth;
	unsigned int saved_label;
	zT_B9EE179B_Opt_13 ctrl;
	unsigned int idx;
	zT_2C0927B0_StateMap** exits;
	unsigned int exits_n;
	unsigned int exits_cap;
	unsigned char sel_decisive;
	unsigned int sel_prong;
	unsigned char has_alt;
	unsigned char active;
	unsigned char is_error;
};
#endif /* ZIG_STRUCT_zT_5E506466_StmtWork */

/* Forward declarations */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore*, unsigned int);
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_358A0836_aliasReset(void);
zT_BAEE192E_Opt_10 zF_67D2EC5C_aliasLookupCanon(zT_2C0927B0_StateMap*, unsigned int);
unsigned int zF_4F44F91A_aliasResolveName(zT_2C0927B0_StateMap*, unsigned int);
void zF_B9BF926D_aliasSet(zT_2C0927B0_StateMap*, unsigned int, unsigned int);
void zF_02432EFE_aliasRecord(zT_2C0927B0_StateMap*, unsigned int, unsigned int);
void zF_BC69916E_aliasForget(zT_2C0927B0_StateMap*, unsigned int);
void zF_021A8EFB_aliasCopyState(zT_2C0927B0_StateMap*, unsigned int, unsigned int);
unsigned char zF_3CD28686_aliasHasInbound(zT_2C0927B0_StateMap*, unsigned int);
unsigned int zF_C308634B_aliasRerootInbound(zT_2C0927B0_StateMap*, unsigned int);
zT_E8C0B717_AliasClassSummary zF_E7D83DF7_aliasClassSummary(zT_2C0927B0_StateMap*, unsigned int);
void zF_942D4B88_aliasSetClassState(zT_2C0927B0_StateMap*, unsigned int, unsigned char);
unsigned char zF_2D8292B3_aliasNameInList(zT_3CB0179A_Slice_zT_05F374B1_u, unsigned int, unsigned int);
void zF_35C02CDB_aliasMergeBranchInt(zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*);
void zF_050895D1_aliasMergeBranches(zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*);
void zF_FE1121B2_handleReset(void);
void zF_42DCEB42_handleRecord(unsigned int);
unsigned char zF_1BA566A7_handleIs(unsigned int);
zT_BAEE192E_Opt_10 zF_2B75F11C_indexKeyNameId(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_D238CD98_resolveLValueIdenti(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_CEF2EDFB_npResetTypeDecls(void);
void zF_1DAE0272_npTypeDeclAdd(unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_6C635B91_npTypeDeclLookup(unsigned int);
void zF_ED64579A_npFnDeclAdd(unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_7D61EF69_npFnDeclLookup(unsigned int);
void zF_EABBCC34_npCollectModuleType(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_26DFBC8B_npResetDeclTypes(void);
void zF_E9B292FD_npDeclTypeSet(zT_2C0927B0_StateMap*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_0DF611D1_npDeclTypeLookup(zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_FEDA8909_npTypeExprIsPointer(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned char zF_F414A6E7_npTypeExprNullClass(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned char zF_9007AC3C_npNullClassToState(unsigned char);
zT_BAEE192E_Opt_10 zF_A5D760AE_npFieldTypeInDecl(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_396F0EC4_npTypeExprFieldType(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_B010CB73_npTypeExprElemType(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_554F816C_npTypeExprPointeeTy(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_EC091DF3_npTypeExprUnwrapOpt(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_B8ADF10A_npTypeExprUnwrapErr(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_37F68EF5_npFnProtoReturnType(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_08C1DC2F_npSymbolFnProto(zT_7E2F335A_AnalyzerContext*, zT_3A105EF1_Symbol*);
zT_BAEE192E_Opt_10 zF_A5D5994D_npExprModuleId(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_DDF22011_npCalleeFnProto(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_87992239_npFnReturnType(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
zT_BAEE192E_Opt_10 zF_E7BC3470_npExprType(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_DBDEE1FF_calleeFinalNameId(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned char zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner*, unsigned int, unsigned int);
void zF_20F3D91E_reportUseAfterFree(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
void zF_81AD738D_checkUseAfterFreeEx(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
void zF_96EACE5B_emitFreeingUntracke(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*);
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_13E7D509_handleAllocVarDecl(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_202AF108_isOwnershipTakingNa(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned char zF_08DFDF62_isOwnershipTakingCa(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_215D4B9F_recordAllocatorHand(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_61F0EB83_resetDeferQueue(zT_7E2F335A_AnalyzerContext*);
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_11BB0278_rejectAnytypeType(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_C745AF68_validateSignatureNa(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int, unsigned int);
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_FF589221_npBuiltinNameIs(zT_7E2F335A_AnalyzerContext*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore*, unsigned int);
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore*, unsigned int);
zT_5DCD052D_Opt_127 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore*, unsigned int);
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore*, unsigned int, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*);
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned char, zT_68F0EBCB_FP_void_zT_7E2F335A);
zT_5E506466_StmtWork zF_FF223750_stmtWorkNew(unsigned char);
void zF_93CCEC20_stmtWalkEnsure(zT_F09D0ED6_StmtWalk*, unsigned int);
void zF_A8FECE7E_stmtWalkPush(zT_F09D0ED6_StmtWalk*, zT_5E506466_StmtWork);
zT_5E506466_StmtWork zF_EF202FD5_stmtWalkPop(zT_F09D0ED6_StmtWalk*);
void zF_FB7F9D1D_runStmtWalk(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned char, zT_68F0EBCB_FP_void_zT_7E2F335A, zT_68F0EBCB_FP_void_zT_7E2F335A);
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, zT_68F0EBCB_FP_void_zT_7E2F335A);
unsigned int zF_CE47A44A_captureNameIdOf(zT_6B0A7D14_AstStore*, unsigned int);
void zF_C06E7771_bindCaptureState(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
zT_B9EE179B_Opt_13 zF_3D4B7D06_npPushCtrl(unsigned int, unsigned char);
void zF_1AF52C1F_npPopCtrl(void);
void zF_89AE88B4_npPopUnpushed(void);
void zF_7FE51DF2_npForceMaybe(zT_2C0927B0_StateMap*);
zT_2C0927B0_StateMap* zF_4DC0B3C4_npSnapshotState(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*);
void zF_C367D4CB_npRecordCtrlExit(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned char, unsigned int);
void zF_07E6CF3A_npMergeStatesOneSid(zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, unsigned char);
void zF_40B3C9C6_npMergeStatesSymmet(zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, unsigned char);
void zF_E64F00DA_npAppendCtrlBranch(zT_1D7388AD_Slice_zT_2C0927B0_S, unsigned int*, zT_2C0927B0_StateMap*);
void zF_8D041ABB_npAppendCtrlExits(unsigned int, zT_1D7388AD_Slice_zT_2C0927B0_S, unsigned int*);
void zF_B0C4C169_npMergeNullExits(zT_2C0927B0_StateMap*, zT_1D7388AD_Slice_zT_2C0927B0_S, zT_3E40CD83_Sand*);
zT_7332B667_Opt_231 zF_2E389B5D_analyzerFoldComptim(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_C7F6EF0E_ImportSwitchSelecti zF_EA5675A7_analyzerSwitchSelec(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_49E17557_Opt_2 zF_A1341A8A_analyzerFoldComptim(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
unsigned char zF_42EA7E8C_paramTypeIsPointerL(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, zT_68F0EBCB_FP_void_zT_7E2F335A, zT_68F0EBCB_FP_void_zT_7E2F335A);
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_780653D2___module_init_9(void);
/* Storage globals (extern decls) */
extern zT_C7C7C6E3_Arr_zT_261F9C91_Ali zG_CA212B48_alias_entries;
extern unsigned int zG_7A7DD00F_alias_len;
extern zT_BE7C4AC5_Arr_unsigned_int_81 zG_8DB2D67B_alias_merge_names;
extern zT_BE7C4AC5_Arr_unsigned_int_81 zG_A2881590_alias_merge_a;
extern zT_BE7C4AC5_Arr_unsigned_int_81 zG_A5881A49_alias_merge_b;
extern zT_BE7C4AC5_Arr_unsigned_int_81 zG_ECCF6B8E_alias_reroot_names;
extern zT_157C0A16_Arr_unsigned_int_25 zG_9C3A4184_handle_names;
extern unsigned int zG_8BB5A58B_handle_len;
extern zT_0CBE91C5_Arr_zT_23DDC3A7_NpT zG_A87EF5DE_np_type_decls;
extern unsigned int zG_A91C6F19_np_type_decl_len;
extern zT_5E8E0A7D_Arr_zT_F4307D1F_NpF zG_1F11CC3A_np_fn_decls;
extern unsigned int zG_EC4E11ED_np_fn_decl_len;
extern zT_F2D292B9_Arr_zT_26EAA6E7_NpD zG_CD441BCA_np_decl_types;
extern unsigned int zG_04FE73DD_np_decl_type_len;
extern unsigned int zG_14AD521F_np_ctrl_depth;
extern unsigned int zG_31CDA604_np_ctrl_unpushed;
extern zT_9D2DA37C_Arr_unsigned_int_32 zG_8AE6670C_np_ctrl_label;
extern zT_482B23C5_Arr_unsigned_char_3 zG_4BD13FA5_np_ctrl_is_loop;
extern zT_9D2DA37C_Arr_unsigned_int_32 zG_3AC65475_np_ctrl_break_count;
extern zT_9D2DA37C_Arr_unsigned_int_32 zG_900152CF_np_ctrl_continue_co;
extern zT_BC2B310E_Arr_zT_A5953ADF_Arr zG_FD374C4A_np_ctrl_breaks;
extern zT_BC2B310E_Arr_zT_A5953ADF_Arr zG_6EF64D04_np_ctrl_continues;
extern unsigned int zG_32DDAA60_np_current_label;
extern unsigned int const zG_73BDFDC5_PER_FUNC_BUDGET;

#endif /* ZIG_MODULE_ANALYZER_2FA863C8_H */
