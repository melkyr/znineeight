#include "source_manager_0C564FCF.h"
zT_227EDE07_SourceManager zG_227EDE07_SourceManager;
/* sourceFileArrayListInit */
zT_6B45117F_SourceFileArrayList zF_EB529E39_sourceFileArrayList(zT_3E40CD83_Sand* allocator) {
    zT_6B45117F_SourceFileArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_ED18556E_SourceFile*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* sourceFileArrayListEnsureCapacity */
void zF_9E523C79_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_ED18556E_SourceFile* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_6F2E32ED_Opt_259 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_81AD2998_EU_952 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    zT_ED18556E_SourceFile* zT_64;
    zT_ED18556E_SourceFile* zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_ED18556E_SourceFile* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_71;
    zT_ED18556E_SourceFile* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    unsigned int new_cap;
    zT_6F2E32ED_Opt_259 grown;
    unsigned char* raw;
    zT_ED18556E_SourceFile* new_items;
    zT_ED18556E_SourceFile item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = self->allocator;
    zT_32 = self->items;
    zT_34 = self->capacity;
    zT_35 = 28;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 28;
    zT_41 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(4));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_49 = self->allocator;
    zT_53 = 28;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_61;
    zT_64 = (zT_ED18556E_SourceFile*)raw;
    new_items = zT_64;
    zT_65 = self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (zT_ED18556E_SourceFile*)zT_68;
    zT_71.len = zT_69;
    zT_72 = zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17:
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* sourceFileArrayListAppend */
void zF_5368F9F7_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self, zT_ED18556E_SourceFile value) {
    zT_6B45117F_SourceFileArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_ED18556E_SourceFile* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_9E523C79_sourceFileArrayList(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* sourceFileArrayListGetSlice */
zT_1D6CA09C_Slice_zT_ED18556E_S zF_276A1E3D_sourceFileArrayList(zT_6B45117F_SourceFileArrayList* self) {
    zT_ED18556E_SourceFile* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_ED18556E_SourceFile* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_7;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_ED18556E_SourceFile*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* sourceManagerInit */
zT_227EDE07_SourceManager zF_01351F51_sourceManagerInit(zT_3E40CD83_Sand* allocator) {
    zT_3E40CD83_Sand* zT_2;
    zT_81AD2998_EU_952 zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    zT_6B45117F_SourceFileArrayList* zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_6B45117F_SourceFileArrayList zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_81AD2998_EU_952 zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    zT_7D82FE60_GrowableSand* zT_26;
    zT_227EDE07_SourceManager zT_27;
    unsigned char zT_28;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    unsigned char* f_raw;
    zT_6B45117F_SourceFileArrayList* f_ptr;
    unsigned char* gs_raw;
    zT_7D82FE60_GrowableSand* gs_ptr;
    zT_2 = allocator;
    zT_7 = zF_1395EB68_sandAlloc(zT_2, (unsigned int)(16), (unsigned int)(4));
    zT_8 = zT_7.is_error;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_9 = zT_7.data.payload;
    goto z_bb_3;
    z_bb_3:
    f_raw = zT_9;
    zT_12 = (zT_6B45117F_SourceFileArrayList*)f_raw;
    f_ptr = zT_12;
    zT_13 = allocator;
    zT_14 = zF_EB529E39_sourceFileArrayList(zT_13);
    *f_ptr = zT_14;
    zT_16 = allocator;
    zT_21 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(60), (unsigned int)(4));
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_23 = zT_21.data.payload;
    goto z_bb_6;
    z_bb_6:
    gs_raw = zT_23;
    zT_26 = (zT_7D82FE60_GrowableSand*)gs_raw;
    gs_ptr = zT_26;
    zT_27.files = f_ptr;
    zT_27.allocator = allocator;
    zT_27.fault = gs_ptr;
    zT_28 = 0;
    zT_27.fault_ready = zT_28;
    return zT_27;
}

/* sourceManagerAddFile */
unsigned int zF_3A49F0F4_sourceManagerAddFil(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u filename, zT_8F083A69_Slice_zT_0B42B2F8_u content) {
    zT_227EDE07_SourceManager* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_3E40CD83_Sand* zT_43;
    zT_81AD2998_EU_952 zT_49;
    unsigned char zT_50;
    unsigned char* zT_51;
    zT_B687BB96_U32ArrayList* zT_54;
    zT_3E40CD83_Sand* zT_55;
    zT_B687BB96_U32ArrayList zT_57;
    zT_B687BB96_U32ArrayList* zT_58;
    unsigned int zT_59;
    zT_B687BB96_U32ArrayList* zT_60;
    int zT_62;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_B687BB96_U32ArrayList* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    unsigned int zT_80;
    zT_6B45117F_SourceFileArrayList* zT_81;
    zT_ED18556E_SourceFile zT_82;
    zT_ED18556E_SourceFile zT_84;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    zT_6B45117F_SourceFileArrayList* zT_89;
    unsigned int zT_90;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    unsigned char* fname_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname_copy;
    unsigned int line_count;
    unsigned char c;
    unsigned int cap;
    unsigned char* lo_raw;
    zT_B687BB96_U32ArrayList* lo_ptr;
    unsigned int i;
    zT_4 = self;
    zT_5 = filename;
    zT_6 = zF_B158E4F2_sourceManagerCopyTo(zT_4, zT_5);
    fname_raw = zT_6;
    zT_9 = filename.len;
    zT_10 = 0;
    zT_11 = fname_raw + zT_10;
    zT_12 = zT_9 - zT_10;
    zT_13 = (unsigned int)zT_10 <= zT_9;
    if (!(zT_13)) { pal_trap(); }
    zT_14.ptr = (unsigned char*)zT_11;
    zT_14.len = zT_12;
    fname_copy = zT_14;
    zT_16 = 0;
    line_count = zT_16;
    zT_17 = content.ptr;
    zT_18 = content.len;
    zT_19 = 0;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(zT_19 < zT_18)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    c = zT_17[zT_19];
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_33 = 1;
    zT_34 = zig_wrap_add_u(((zu64)(line_count)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(line_count)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    cap = zT_34;
    zT_38 = 64;
    if ((unsigned char)(cap < (unsigned int)zT_38)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_31 = zT_19 + (unsigned int)(1);
    zT_19 = zT_31;
    goto z_bb_1;
    z_bb_5:
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(line_count)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(line_count)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    line_count = zT_26;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40 = 64;
    zT_41 = (unsigned int)zT_40;
    cap = zT_41;
    goto z_bb_8;
    z_bb_8:
    zT_43 = self->allocator;
    zT_49 = zF_1395EB68_sandAlloc(zT_43, (unsigned int)(16), (unsigned int)(4));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_51 = zT_49.data.payload;
    goto z_bb_11;
    z_bb_11:
    lo_raw = zT_51;
    zT_54 = (zT_B687BB96_U32ArrayList*)lo_raw;
    lo_ptr = zT_54;
    zT_55 = self->allocator;
    zT_57 = zF_8E537D0C_u32ArrayListInit(zT_55);
    *lo_ptr = zT_57;
    zT_58 = lo_ptr;
    zT_59 = cap;
    zF_1580F084_u32ArrayListEnsureC(zT_58, zT_59);
    zT_60 = lo_ptr;
    zT_62 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_60, (unsigned int)((unsigned int)zT_62));
    zT_64 = content.ptr;
    zT_65 = content.len;
    i = 0;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(i < zT_65)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    c = zT_64[i];
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_81 = self->files;
    zT_84.filename = fname_copy;
    zT_84.content = content;
    zT_84.line_offsets = lo_ptr;
    zT_86 = content.len;
    zT_84.len = zT_86;
    zT_87 = 1;
    zT_84.loaded = zT_87;
    zT_88 = 0;
    zT_84.transient = zT_88;
    zT_82 = zT_84;
    zF_5368F9F7_sourceFileArrayList(zT_81, zT_82);
    zT_89 = self->files;
    zT_90 = zT_89->len;
    return (unsigned int)((unsigned int)zT_90);
    z_bb_15:
    zT_80 = i + (unsigned int)(1);
    i = zT_80;
    goto z_bb_12;
    z_bb_16:
    zT_71 = lo_ptr;
    zT_73 = (unsigned int)i;
    zT_74 = 1;
    zT_75 = zig_wrap_add_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_add_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    zT_72 = zT_75;
    zF_62F717A2_u32ArrayListAppend(zT_71, zT_72);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_15;
}

/* sourceManagerAddFileTransient */
unsigned int zF_55F5B402_sourceManagerAddFil(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u filename, zT_8F083A69_Slice_zT_0B42B2F8_u content) {
    zT_227EDE07_SourceManager* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_81AD2998_EU_952 zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    zT_B687BB96_U32ArrayList* zT_27;
    zT_3E40CD83_Sand* zT_28;
    zT_B687BB96_U32ArrayList zT_30;
    zT_6B45117F_SourceFileArrayList* zT_31;
    zT_ED18556E_SourceFile zT_32;
    zT_ED18556E_SourceFile zT_34;
    unsigned int zT_36;
    unsigned char zT_37;
    unsigned char zT_38;
    zT_6B45117F_SourceFileArrayList* zT_39;
    unsigned int zT_40;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    unsigned char* fname_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname_copy;
    unsigned char* dummy_raw;
    zT_B687BB96_U32ArrayList* dummy_ptr;
    zT_4 = self;
    zT_5 = filename;
    zT_6 = zF_B158E4F2_sourceManagerCopyTo(zT_4, zT_5);
    fname_raw = zT_6;
    zT_9 = filename.len;
    zT_10 = 0;
    zT_11 = fname_raw + zT_10;
    zT_12 = zT_9 - zT_10;
    zT_13 = (unsigned int)zT_10 <= zT_9;
    if (!(zT_13)) { pal_trap(); }
    zT_14.ptr = (unsigned char*)zT_11;
    zT_14.len = zT_12;
    fname_copy = zT_14;
    zT_16 = self->allocator;
    zT_22 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(16), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_24 = zT_22.data.payload;
    goto z_bb_3;
    z_bb_3:
    dummy_raw = zT_24;
    zT_27 = (zT_B687BB96_U32ArrayList*)dummy_raw;
    dummy_ptr = zT_27;
    zT_28 = self->allocator;
    zT_30 = zF_8E537D0C_u32ArrayListInit(zT_28);
    *dummy_ptr = zT_30;
    zT_31 = self->files;
    zT_34.filename = fname_copy;
    zT_34.content = content;
    zT_34.line_offsets = dummy_ptr;
    zT_36 = content.len;
    zT_34.len = zT_36;
    zT_37 = 0;
    zT_34.loaded = zT_37;
    zT_38 = 1;
    zT_34.transient = zT_38;
    zT_32 = zT_34;
    zF_5368F9F7_sourceFileArrayList(zT_31, zT_32);
    zT_39 = self->files;
    zT_40 = zT_39->len;
    return (unsigned int)((unsigned int)zT_40);
}

/* sourceManagerFaultIn */
void zF_088D3002_sourceManagerFaultI(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    zT_6B45117F_SourceFileArrayList* zT_5;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_7;
    unsigned int zT_9;
    unsigned int zT_14;
    unsigned int zT_17;
    zT_ED18556E_SourceFile* zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_ED18556E_SourceFile* zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_7D82FE60_GrowableSand* zT_36;
    zT_3E40CD83_Sand* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_3E40CD83_Sand* zT_41;
    int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_3E40CD83_Sand* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_7D82FE60_GrowableSand* zT_49;
    zT_85DA580C_Opt_476 zT_51;
    unsigned char zT_52;
    zT_3E40CD83_Sand* zT_55;
    zT_7D82FE60_GrowableSand* zT_58;
    zT_81AD2998_EU_952 zT_62;
    unsigned char zT_63;
    unsigned char* zT_64;
    zT_B687BB96_U32ArrayList* zT_67;
    zT_3E40CD83_Sand* zT_68;
    zT_7D82FE60_GrowableSand* zT_69;
    zT_B687BB96_U32ArrayList zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned char* zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    unsigned char zT_87;
    int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    zT_B687BB96_U32ArrayList* zT_108;
    unsigned int zT_109;
    zT_B687BB96_U32ArrayList* zT_110;
    int zT_112;
    unsigned char* zT_114;
    unsigned int zT_115;
    zT_B687BB96_U32ArrayList* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned int zT_130;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_3E40CD83_Sand* zT_137;
    zT_7D82FE60_GrowableSand* zT_140;
    zT_81AD2998_EU_952 zT_144;
    unsigned char zT_145;
    unsigned char* zT_146;
    zT_B687BB96_U32ArrayList* zT_149;
    zT_3E40CD83_Sand* zT_150;
    zT_7D82FE60_GrowableSand* zT_151;
    zT_B687BB96_U32ArrayList zT_153;
    zT_B687BB96_U32ArrayList* zT_154;
    int zT_156;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_144, (unsigned int)sizeof zT_144);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_ED18556E_SourceFile* file;
    zT_8F083A69_Slice_zT_0B42B2F8_u gs_name;
    zT_85DA580C_Opt_476 content_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned char* lo_raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_content;
    unsigned char* lo_raw2;
    zT_B687BB96_U32ArrayList* lo_ptr;
    unsigned int scan_len;
    unsigned int line_count;
    unsigned int si;
    unsigned int cap;
    unsigned char c;
    unsigned int i;
    zT_B687BB96_U32ArrayList* lo_ptr2;
    if ((unsigned char)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->files;
    zT_7 = zF_276A1E3D_sourceFileArrayList(zT_5);
    files_slice = zT_7;
    zT_9 = files_slice.len;
    if ((unsigned char)(zT_9 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    fid = file_id;
    zT_14 = files_slice.len;
    if ((unsigned char)(fid > (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 1;
    fid = zT_17;
    goto z_bb_6;
    z_bb_6:
    zT_19 = files_slice.ptr;
    zT_20 = 1;
    zT_21 = zig_wrap_sub_u(((zu64)(fid)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_sub_u(((zu64)(fid)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_25 = (unsigned int)zT_21;
    zT_26 = files_slice.len;
    zT_27 = zT_25 < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_19 + zT_25;
    file = zT_28;
    zT_29 = file->loaded;
    if (zT_29) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_30 = self->fault_ready;
    if ((unsigned char)(!zT_30)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = "diag_read";
    zT_35 = 9;
    zT_34.ptr = (unsigned char*)zT_33;
    zT_34.len = zT_35;
    gs_name = zT_34;
    zT_36 = self->fault;
    zT_41 = zF_8C23960F_poolPtr();
    zT_37 = zT_41;
    zT_42 = 4096;
    zT_39 = gs_name;
    zF_07B11742_growableSandInit(zT_36, zT_37, (unsigned int)((unsigned int)zT_42), zT_39);
    self->fault_ready = (unsigned char)(1);
    goto z_bb_10;
    z_bb_10:
    zT_48 = file->filename;
    zT_46 = zT_48;
    zT_49 = self->fault;
    zT_47 = &zT_49->view;
    zT_51 = zF_5B859C63_readFile(zT_46, zT_47);
    content_opt = zT_51;
    zT_52 = content_opt.has_value;
    if (zT_52) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    if (!(content_opt.has_value)) { pal_trap(); }
    content = content_opt.value;
    zT_58 = self->fault;
    zT_55 = &zT_58->view;
    zT_62 = zF_1395EB68_sandAlloc(zT_55, (unsigned int)(16), (unsigned int)(4));
    zT_63 = zT_62.is_error;
    if (zT_63) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    return;
    z_bb_13:
    zT_133 = "";
    zT_135 = 0;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    empty_content = zT_134;
    zT_140 = self->fault;
    zT_137 = &zT_140->view;
    zT_144 = zF_1395EB68_sandAlloc(zT_137, (unsigned int)(16), (unsigned int)(4));
    zT_145 = zT_144.is_error;
    if (zT_145) goto z_bb_31; else goto z_bb_32;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_64 = zT_62.data.payload;
    goto z_bb_16;
    z_bb_16:
    lo_raw = zT_64;
    zT_67 = (zT_B687BB96_U32ArrayList*)lo_raw;
    lo_ptr = zT_67;
    zT_69 = self->fault;
    zT_68 = &zT_69->view;
    zT_71 = zF_8E537D0C_u32ArrayListInit(zT_68);
    *lo_ptr = zT_71;
    zT_73 = file->len;
    scan_len = zT_73;
    zT_75 = content.len;
    if ((unsigned char)(scan_len > zT_75)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_78 = content.len;
    scan_len = zT_78;
    goto z_bb_18;
    z_bb_18:
    zT_80 = 0;
    line_count = zT_80;
    zT_82 = 0;
    si = zT_82;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(si < scan_len)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_84 = content.ptr;
    zT_85 = content.len;
    zT_86 = si < zT_85;
    if (!(zT_86)) { pal_trap(); }
    zT_87 = zT_84[si];
    if ((unsigned char)(zT_87 == (unsigned char)(10))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_103 = 1;
    zT_104 = zig_wrap_add_u(((zu64)(line_count)), ((zu64)(zT_103)), 32u);
    zT_105 = zig_overflow_flag_add_u(((zu64)(line_count)), ((zu64)(zT_103)), 32u);
    zT_107 = zT_105 == (unsigned int)(0);
    if (!(zT_107)) { pal_trap(); }
    cap = zT_104;
    zT_108 = lo_ptr;
    zT_109 = cap;
    zF_1580F084_u32ArrayListEnsureC(zT_108, zT_109);
    zT_110 = lo_ptr;
    zT_112 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_110, (unsigned int)((unsigned int)zT_112));
    zT_114 = content.ptr;
    zT_115 = content.len;
    i = 0;
    goto z_bb_25;
    z_bb_22:
    zT_96 = 1;
    zT_97 = (unsigned int)zT_96;
    zT_98 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    si = zT_98;
    goto z_bb_19;
    z_bb_23:
    zT_90 = 1;
    zT_91 = (unsigned int)zT_90;
    zT_92 = zig_wrap_add_u(((zu64)(line_count)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(line_count)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    line_count = zT_92;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    if ((unsigned char)(i < zT_115)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    c = zT_114[i];
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    file->content = content;
    file->line_offsets = lo_ptr;
    file->loaded = (unsigned char)(1);
    goto z_bb_12;
    z_bb_28:
    zT_130 = i + (unsigned int)(1);
    i = zT_130;
    goto z_bb_25;
    z_bb_29:
    zT_121 = lo_ptr;
    zT_123 = (unsigned int)i;
    zT_124 = 1;
    zT_125 = zig_wrap_add_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_126 = zig_overflow_flag_add_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_128 = zT_126 == (unsigned int)(0);
    if (!(zT_128)) { pal_trap(); }
    zT_122 = zT_125;
    zF_62F717A2_u32ArrayListAppend(zT_121, zT_122);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    pal_trap();
    z_bb_32:
    zT_146 = zT_144.data.payload;
    goto z_bb_33;
    z_bb_33:
    lo_raw2 = zT_146;
    zT_149 = (zT_B687BB96_U32ArrayList*)lo_raw2;
    lo_ptr2 = zT_149;
    zT_151 = self->fault;
    zT_150 = &zT_151->view;
    zT_153 = zF_8E537D0C_u32ArrayListInit(zT_150);
    *lo_ptr2 = zT_153;
    zT_154 = lo_ptr2;
    zT_156 = 0;
    zF_62F717A2_u32ArrayListAppend(zT_154, (unsigned int)((unsigned int)zT_156));
    file->content = empty_content;
    file->line_offsets = lo_ptr2;
    file->loaded = (unsigned char)(1);
    goto z_bb_12;
}

/* sourceManagerResetFaults */
void zF_196FDF3B_sourceManagerResetF(zT_227EDE07_SourceManager* self) {
    unsigned char zT_1;
    zT_3E40CD83_Sand* zT_3;
    zT_7D82FE60_GrowableSand* zT_4;
    zT_6B45117F_SourceFileArrayList* zT_7;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_ED18556E_SourceFile* zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    zT_ED18556E_SourceFile zT_18;
    unsigned char zT_19;
    zT_ED18556E_SourceFile* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_ED18556E_SourceFile* zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int i;
    zT_1 = self->fault_ready;
    if ((unsigned char)(!zT_1)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->fault;
    zT_3 = &zT_4->view;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_7 = self->files;
    zT_9 = zF_276A1E3D_sourceFileArrayList(zT_7);
    files_slice = zT_9;
    zT_11 = 0;
    i = zT_11;
    goto z_bb_3;
    z_bb_3:
    zT_13 = files_slice.len;
    if ((unsigned char)(i < zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = files_slice.ptr;
    zT_16 = files_slice.len;
    zT_17 = i < zT_16;
    if (!(zT_17)) { pal_trap(); }
    zT_18 = zT_15[i];
    zT_19 = zT_18.transient;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    goto z_bb_3;
    z_bb_7:
    zT_21 = files_slice.ptr;
    zT_22 = files_slice.len;
    zT_23 = i < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21 + i;
    zT_24->loaded = (unsigned char)(0);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* sourceManagerGetFileName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7076474_sourceManagerGetFil(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11;
    unsigned int zT_13;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_ED18556E_SourceFile* zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_ED18556E_SourceFile zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((unsigned char)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_9 = self->files;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    zT_13 = files_slice.len;
    if ((unsigned char)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = (unsigned char*)zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    zT_22 = files_slice.len;
    if ((unsigned char)(fid > (unsigned int)((unsigned int)zT_22))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = files_slice.ptr;
    zT_27 = 1;
    zT_28 = zig_wrap_sub_u(((zu64)(fid)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_sub_u(((zu64)(fid)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_32 = (unsigned int)zT_28;
    zT_33 = files_slice.len;
    zT_34 = zT_32 < zT_33;
    if (!(zT_34)) { pal_trap(); }
    zT_35 = zT_26[zT_32];
    zT_36 = zT_35.filename;
    return zT_36;
}

/* sourceManagerGetSourceContent */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_FFE72B39_sourceManagerGetSou(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B45117F_SourceFileArrayList* zT_9;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_11;
    unsigned int zT_13;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_227EDE07_SourceManager* zT_26;
    unsigned int zT_27;
    zT_ED18556E_SourceFile* zT_28;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_36;
    zT_ED18556E_SourceFile zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_8F083A69_Slice_zT_0B42B2F8_u dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((unsigned char)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "";
    zT_7 = 0;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    dummy = zT_6;
    return dummy;
    z_bb_2:
    zT_9 = self->files;
    zT_11 = zF_276A1E3D_sourceFileArrayList(zT_9);
    files_slice = zT_11;
    zT_13 = files_slice.len;
    if ((unsigned char)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "";
    zT_19 = 0;
    zT_18.ptr = (unsigned char*)zT_17;
    zT_18.len = zT_19;
    dummy = zT_18;
    return dummy;
    z_bb_4:
    fid = file_id;
    zT_22 = files_slice.len;
    if ((unsigned char)(fid > (unsigned int)((unsigned int)zT_22))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 1;
    fid = zT_25;
    goto z_bb_6;
    z_bb_6:
    zT_26 = self;
    zT_27 = fid;
    zF_088D3002_sourceManagerFaultI(zT_26, zT_27);
    zT_28 = files_slice.ptr;
    zT_29 = 1;
    zT_30 = zig_wrap_sub_u(((zu64)(fid)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(fid)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_34 = (unsigned int)zT_30;
    zT_35 = files_slice.len;
    zT_36 = zT_34 < zT_35;
    if (!(zT_36)) { pal_trap(); }
    zT_37 = zT_28[zT_34];
    zT_38 = zT_37.content;
    return zT_38;
}

/* sourceManagerGetLineOffsets */
zT_3CB0179A_Slice_zT_05F374B1_u zF_5041A561_sourceManagerGetLin(zT_227EDE07_SourceManager* self, unsigned int file_id) {
    zT_949EEA93_Arr_unsigned_int_0 zT_5;
    int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_11;
    zT_6B45117F_SourceFileArrayList* zT_13;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_15;
    unsigned int zT_17;
    zT_949EEA93_Arr_unsigned_int_0 zT_21;
    int zT_24;
    unsigned int* zT_25;
    unsigned int zT_26;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27;
    unsigned int zT_30;
    unsigned int zT_33;
    zT_227EDE07_SourceManager* zT_34;
    unsigned int zT_35;
    zT_B687BB96_U32ArrayList* zT_36;
    zT_ED18556E_SourceFile* zT_37;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    zT_ED18556E_SourceFile zT_46;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_48;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_949EEA93_Arr_unsigned_int_0 dummy;
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    if ((unsigned char)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_5[_i];
        _i++;
    }
}
    zT_8 = 0;
    zT_9 = (unsigned int*)((unsigned int*)dummy) + zT_8;
    zT_10 = (unsigned int)(0) - zT_8;
    zT_11.ptr = (unsigned int*)zT_9;
    zT_11.len = zT_10;
    return zT_11;
    z_bb_2:
    zT_13 = self->files;
    zT_15 = zF_276A1E3D_sourceFileArrayList(zT_13);
    files_slice = zT_15;
    zT_17 = files_slice.len;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    {
    int _i = 0;
    while (_i < 0) {
        dummy[_i] = zT_21[_i];
        _i++;
    }
}
    zT_24 = 0;
    zT_25 = (unsigned int*)((unsigned int*)dummy) + zT_24;
    zT_26 = (unsigned int)(0) - zT_24;
    zT_27.ptr = (unsigned int*)zT_25;
    zT_27.len = zT_26;
    return zT_27;
    z_bb_4:
    fid = file_id;
    zT_30 = files_slice.len;
    if ((unsigned char)(fid > (unsigned int)((unsigned int)zT_30))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_33 = 1;
    fid = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_34 = self;
    zT_35 = fid;
    zF_088D3002_sourceManagerFaultI(zT_34, zT_35);
    zT_37 = files_slice.ptr;
    zT_38 = 1;
    zT_39 = zig_wrap_sub_u(((zu64)(fid)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_sub_u(((zu64)(fid)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_43 = (unsigned int)zT_39;
    zT_44 = files_slice.len;
    zT_45 = zT_43 < zT_44;
    if (!(zT_45)) { pal_trap(); }
    zT_46 = zT_37[zT_43];
    zT_36 = zT_46.line_offsets;
    zT_48 = zF_281E4968_u32ArrayListGetSlic(zT_36);
    return zT_48;
}

/* sourceManagerGetLocation */
zT_5BC08DC6_Location zF_4966CE4A_sourceManagerGetLoc(zT_227EDE07_SourceManager* self, unsigned int file_id, unsigned int offset) {
    zT_5BC08DC6_Location zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_6B45117F_SourceFileArrayList* zT_10;
    zT_1D6CA09C_Slice_zT_ED18556E_S zT_12;
    unsigned int zT_15;
    zT_5BC08DC6_Location zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_26;
    zT_227EDE07_SourceManager* zT_27;
    unsigned int zT_28;
    zT_ED18556E_SourceFile* zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    zT_ED18556E_SourceFile* zT_39;
    zT_B687BB96_U32ArrayList* zT_41;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_43;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_5BC08DC6_Location zT_58;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zT_1D6CA09C_Slice_zT_ED18556E_S files_slice;
    unsigned int fid;
    zT_ED18556E_SourceFile* file;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    unsigned int col;
    if ((unsigned char)(file_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 0;
    zT_5.file_id = zT_6;
    zT_7 = 0;
    zT_5.line = zT_7;
    zT_8 = 0;
    zT_5.col = zT_8;
    return zT_5;
    z_bb_2:
    zT_10 = self->files;
    zT_12 = zF_276A1E3D_sourceFileArrayList(zT_10);
    files_slice = zT_12;
    fid = file_id;
    zT_15 = files_slice.len;
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = 0;
    zT_18.file_id = zT_19;
    zT_20 = 0;
    zT_18.line = zT_20;
    zT_21 = 0;
    zT_18.col = zT_21;
    return zT_18;
    z_bb_4:
    zT_23 = files_slice.len;
    if ((unsigned char)(fid > (unsigned int)((unsigned int)zT_23))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = 1;
    fid = zT_26;
    goto z_bb_6;
    z_bb_6:
    zT_27 = self;
    zT_28 = fid;
    zF_088D3002_sourceManagerFaultI(zT_27, zT_28);
    zT_30 = files_slice.ptr;
    zT_31 = 1;
    zT_32 = zig_wrap_sub_u(((zu64)(fid)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_sub_u(((zu64)(fid)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_36 = (unsigned int)zT_32;
    zT_37 = files_slice.len;
    zT_38 = zT_36 < zT_37;
    if (!(zT_38)) { pal_trap(); }
    zT_39 = zT_30 + zT_36;
    file = zT_39;
    zT_41 = file->line_offsets;
    zT_43 = zF_281E4968_u32ArrayListGetSlic(zT_41);
    offsets = zT_43;
    zT_45 = offsets;
    zT_46 = offset;
    zT_47 = zF_1457D8A5_binary_search(zT_45, zT_46);
    line_idx = zT_47;
    zT_49 = offsets.ptr;
    zT_50 = (unsigned int)line_idx;
    zT_51 = offsets.len;
    zT_52 = zT_50 < zT_51;
    if (!(zT_52)) { pal_trap(); }
    zT_53 = zT_49[zT_50];
    zT_54 = zig_wrap_sub_u(((zu64)(offset)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_sub_u(((zu64)(offset)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    col = zT_54;
    zT_58.file_id = file_id;
    zT_59 = 1;
    zT_60 = zig_wrap_add_u(((zu64)(line_idx)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(line_idx)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    zT_58.line = zT_60;
    zT_58.col = col;
    return zT_58;
}

/* sourceManagerCopyToArena */
unsigned char* zF_B158E4F2_sourceManagerCopyTo(zT_227EDE07_SourceManager* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_3;
    int zT_4;
    unsigned char* zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_81AD2998_EU_952 zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned int zT_25;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_3 = text.len;
    zT_4 = 0;
    if ((unsigned char)(zT_3 == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    return zT_6;
    z_bb_2:
    zT_8 = self->allocator;
    zT_9 = text.len;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(1));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_19 = text.ptr;
    zT_20 = text.len;
    i = 0;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(i < zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    c = zT_19[i];
    raw[i] = c;
    goto z_bb_9;
    z_bb_8:
    return raw;
    z_bb_9:
    zT_25 = i + (unsigned int)(1);
    i = zT_25;
    goto z_bb_6;
}

/* __module_init */
void zF_780653D2___module_init_2(void) {
    zT_B687BB96_U32ArrayList zT_0;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_B687BB96_U32ArrayList = zT_0;
    return;
}

/* EOF */
