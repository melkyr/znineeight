#include "const_init_eval_283ED887.h"
unsigned char const zG_7572E8D7_CIE_ZERO = (unsigned char)(0);
unsigned char const zG_002ED8FA_CIE_INT = (unsigned char)(1);
unsigned char const zG_DE01BAF1_CIE_FLOAT = (unsigned char)(2);
unsigned char const zG_E69D9919_CIE_BOOL = (unsigned char)(3);
unsigned char const zG_DD770F31_CIE_CHAR = (unsigned char)(4);
unsigned char const zG_DC260CE4_CIE_STRING = (unsigned char)(5);
unsigned char const zG_8BCA4402_CIE_GLOBAL = (unsigned char)(6);
unsigned char const zG_AA7CCD69_CIE_FN = (unsigned char)(7);
unsigned char const zG_56522CBE_CIE_AGG = (unsigned char)(8);
unsigned int const zG_F7845E8F_CIE_NONE = (unsigned int)(4294967295u);
static unsigned int const zG_1C8CEEE7_kEvalDepthCap = (unsigned int)(256);
/* constInitTableInit */
zT_4065182A_ConstInitTable zF_046B7660_constInitTableInit(zT_3E40CD83_Sand* alloc) {
    zT_4065182A_ConstInitTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_8;
    zT_21D3708C_U32ToU32Map zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_21D3708C_U32ToU32Map zT_11;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.nodes = (zT_49DE1C22_ConstInitNode*)zT_2;
    zT_3 = 0;
    zT_1.nodes_len = zT_3;
    zT_4 = 0;
    zT_1.nodes_cap = zT_4;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_1.kids = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_1.kids_len = zT_6;
    zT_7 = 0;
    zT_1.kids_cap = zT_7;
    zT_8 = alloc;
    zT_9 = zF_58BDA2DE_u32ToU32MapInit(zT_8);
    zT_1.roots = zT_9;
    zT_10 = alloc;
    zT_11 = zF_58BDA2DE_u32ToU32MapInit(zT_10);
    zT_1.in_progress = zT_11;
    zT_1.alloc = alloc;
    return zT_1;
}

/* tableEnsureNodes */
void zF_7EB8906A_tableEnsureNodes(zT_4065182A_ConstInitTable* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_81AD2998_EU_952 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_49DE1C22_ConstInitNode* zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_49DE1C22_ConstInitNode* zT_36;
    zT_49DE1C22_ConstInitNode zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int new_cap;
    unsigned char* raw;
    zT_49DE1C22_ConstInitNode* new_nodes;
    unsigned int i;
    zT_2 = self->nodes_cap;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->nodes_cap;
    new_cap = zT_5;
    if ((unsigned char)(new_cap < (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 16;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_16 = self->alloc;
    zT_20 = 32;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(new_cap)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(new_cap)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_17 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_16, zT_17, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_10 = 2;
    zT_11 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_28 = zT_26.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_28;
    zT_31 = (zT_49DE1C22_ConstInitNode*)raw;
    new_nodes = zT_31;
    zT_33 = 0;
    i = zT_33;
    goto z_bb_12;
    z_bb_12:
    zT_34 = self->nodes_len;
    if ((unsigned char)(i < zT_34)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36 = self->nodes;
    zT_37 = zT_36[i];
    new_nodes[i] = zT_37;
    goto z_bb_15;
    z_bb_14:
    self->nodes = new_nodes;
    self->nodes_cap = new_cap;
    return;
    z_bb_15:
    zT_38 = 1;
    zT_39 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    i = zT_39;
    goto z_bb_12;
}

/* tableEnsureKids */
void zF_0E390AEC_tableEnsureKids(zT_4065182A_ConstInitTable* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_81AD2998_EU_952 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int* zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* new_kids;
    unsigned int i;
    zT_2 = self->kids_cap;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->kids_cap;
    new_cap = zT_5;
    if ((unsigned char)(new_cap < (unsigned int)(32))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 32;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_16 = self->alloc;
    zT_20 = 4;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(new_cap)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(new_cap)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_17 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_16, zT_17, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_10 = 2;
    zT_11 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_28 = zT_26.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_28;
    zT_31 = (unsigned int*)raw;
    new_kids = zT_31;
    zT_33 = 0;
    i = zT_33;
    goto z_bb_12;
    z_bb_12:
    zT_34 = self->kids_len;
    if ((unsigned char)(i < zT_34)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36 = self->kids;
    zT_37 = zT_36[i];
    new_kids[i] = zT_37;
    goto z_bb_15;
    z_bb_14:
    self->kids = new_kids;
    self->kids_cap = new_cap;
    return;
    z_bb_15:
    zT_38 = 1;
    zT_39 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    i = zT_39;
    goto z_bb_12;
}

/* tableAddNode */
unsigned int zF_094E0976_tableAddNode(zT_4065182A_ConstInitTable* self, unsigned char kind, zT_79FAE712_u64 a, unsigned int b, unsigned int c) {
    zT_4065182A_ConstInitTable* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_49DE1C22_ConstInitNode zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_49DE1C22_ConstInitNode* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int idx;
    zT_5 = self;
    zT_7 = self->nodes_len;
    zT_8 = 1;
    zT_9 = zig_wrap_add_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_6 = zT_9;
    zF_7EB8906A_tableEnsureNodes(zT_5, zT_6);
    zT_14 = self->nodes_len;
    zT_15 = (unsigned int)zT_14;
    idx = zT_15;
    zT_16.kind = kind;
    zT_17 = 0;
    zT_16._pad0 = zT_17;
    zT_18 = 0;
    zT_16._pad1 = zT_18;
    zT_19 = 0;
    zT_16._pad2 = zT_19;
    zT_16.a = a;
    zT_16.b = b;
    zT_16.c = c;
    zT_20 = 0;
    zT_16.child_start = zT_20;
    zT_21 = 0;
    zT_16.child_count = zT_21;
    zT_22 = self->nodes;
    zT_23 = self->nodes_len;
    zT_22[zT_23] = zT_16;
    zT_24 = self->nodes_len;
    zT_25 = 1;
    zT_26 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->nodes_len = zT_26;
    return idx;
}

/* tableFinishAgg */
void zF_D8E7F449_tableFinishAgg(zT_4065182A_ConstInitTable* self, unsigned int node_idx, unsigned int* scratch, unsigned int count) {
    zT_4065182A_ConstInitTable* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_49DE1C22_ConstInitNode* zT_33;
    zT_49DE1C22_ConstInitNode* zT_35;
    zT_49DE1C22_ConstInitNode* zT_36;
    zT_49DE1C22_ConstInitNode* zT_38;
    unsigned int start;
    unsigned int i;
    zT_4 = self;
    zT_6 = self->kids_len;
    zT_7 = (unsigned int)count;
    zT_8 = zig_wrap_add_u(((zu64)(zT_6)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_add_u(((zu64)(zT_6)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_5 = zT_8;
    zF_0E390AEC_tableEnsureKids(zT_4, zT_5);
    zT_13 = self->kids_len;
    zT_14 = (unsigned int)zT_13;
    start = zT_14;
    zT_16 = 0;
    i = zT_16;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = (unsigned int)i;
    zT_19 = scratch[zT_18];
    zT_20 = self->kids;
    zT_21 = self->kids_len;
    zT_20[zT_21] = zT_19;
    zT_22 = self->kids_len;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    self->kids_len = zT_24;
    goto z_bb_4;
    z_bb_3:
    zT_33 = self->nodes;
    zT_35 = zT_33 + (unsigned int)((unsigned int)node_idx);
    zT_35->child_start = start;
    zT_36 = self->nodes;
    zT_38 = zT_36 + (unsigned int)((unsigned int)node_idx);
    zT_38->child_count = count;
    return;
    z_bb_4:
    zT_28 = 1;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_1;
}

/* constInitNodeAt */
zT_49DE1C22_ConstInitNode zF_C30CDA77_constInitNodeAt(zT_4065182A_ConstInitTable* tbl, unsigned int idx) {
    zT_49DE1C22_ConstInitNode* zT_2;
    unsigned int zT_3;
    zT_49DE1C22_ConstInitNode zT_4;
    zT_2 = tbl->nodes;
    zT_3 = (unsigned int)idx;
    zT_4 = zT_2[zT_3];
    return zT_4;
}

/* constInitChildAt */
unsigned int zF_45C63E41_constInitChildAt(zT_4065182A_ConstInitTable* tbl, unsigned int node_idx, unsigned int i) {
    zT_49DE1C22_ConstInitNode* zT_4;
    unsigned int zT_5;
    zT_49DE1C22_ConstInitNode zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_49DE1C22_ConstInitNode nd;
    zT_4 = tbl->nodes;
    zT_5 = (unsigned int)node_idx;
    zT_6 = zT_4[zT_5];
    nd = zT_6;
    zT_7 = tbl->kids;
    zT_8 = nd.child_start;
    zT_9 = zig_wrap_add_u(((zu64)(zT_8)), ((zu64)(i)), 32u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(zT_8)), ((zu64)(i)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = (unsigned int)zT_9;
    zT_14 = zT_7[zT_13];
    return zT_14;
}

/* constInitEvaluate */
zT_BAEE192E_Opt_10 zF_2B750645_constInitEvaluate(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int decl_idx) {
    zT_4D150975_ConstInitEvalCtx* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_8;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_3 = ec;
    zT_4 = module_id;
    zT_5 = decl_idx;
    zT_8 = zF_4E698A93_evalDecl(zT_3, zT_4, zT_5, (unsigned int)(0));
    return zT_8;
}

/* evalDecl */
zT_BAEE192E_Opt_10 zF_4E698A93_evalDecl(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int decl_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_6;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_4065182A_ConstInitTable* zT_9;
    zT_BAEE192E_Opt_10 zT_11;
    unsigned char zT_12;
    zT_BAEE192E_Opt_10 zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_BAEE192E_Opt_10 zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    unsigned int zT_22;
    zT_4065182A_ConstInitTable* zT_23;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned char zT_26;
    zT_BAEE192E_Opt_10 zT_27;
    zT_21D3708C_U32ToU32Map* zT_28;
    unsigned int zT_29;
    zT_4065182A_ConstInitTable* zT_31;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_22A7C88B_AstNode zT_38;
    zT_8143F551_AstKind zT_40;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned int zT_50;
    zT_8EED1867_ResolvedTypeTable* zT_51;
    unsigned int zT_52;
    zT_BAEE192E_Opt_10 zT_54;
    unsigned char zT_55;
    zT_4D150975_ConstInitEvalCtx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    zT_BAEE192E_Opt_10 zT_68;
    unsigned char zT_69;
    zT_21D3708C_U32ToU32Map* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_4065182A_ConstInitTable* zT_74;
    zT_BAEE192E_Opt_10 zT_76;
    zT_21D3708C_U32ToU32Map* zT_77;
    unsigned int zT_78;
    zT_4065182A_ConstInitTable* zT_80;
    zT_BAEE192E_Opt_10 zT_83;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    unsigned int memo;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 root;
    unsigned int dtype;
    unsigned int dt;
    unsigned int r;
    if ((unsigned char)(decl_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_9 = ec->tbl;
    zT_7 = &zT_9->roots;
    zT_8 = decl_idx;
    zT_11 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(zT_11.has_value)) { pal_trap(); }
    memo = zT_11.value;
    if ((unsigned char)(memo == (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_16.has_value = 0;
    return zT_16;
    z_bb_6:
    zT_17.has_value = 1;
    zT_17.value = memo;
    return zT_17;
    z_bb_7:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_8:
    zT_23 = ec->tbl;
    zT_21 = &zT_23->in_progress;
    zT_22 = decl_idx;
    zT_25 = zF_F3EE5998_u32ToU32MapGet(zT_21, zT_22);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_27.has_value = 0;
    return zT_27;
    z_bb_10:
    zT_31 = ec->tbl;
    zT_28 = &zT_31->in_progress;
    zT_29 = decl_idx;
    zF_26476265_u32ToU32MapPut(zT_28, zT_29, (unsigned int)(1));
    zT_35 = ec->store;
    zT_36 = decl_idx;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    decl = zT_38;
    root.has_value = 0;
    zT_40 = decl.kind;
    if ((unsigned char)(zT_40 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_45 = decl.child_1;
    zT_44 = zT_45 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_44 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_44) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_50 = 18;
    dtype = zT_50;
    zT_51 = ec->resolved;
    zT_52 = decl_idx;
    zT_54 = zF_999DCF51_resolvedTypeTableGe(zT_51, zT_52);
    zT_55 = zT_54.has_value;
    if (zT_55) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_69 = root.has_value;
    if (zT_69) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    if (!(zT_54.has_value)) { pal_trap(); }
    dt = zT_54.value;
    dtype = dt;
    goto z_bb_17;
    z_bb_17:
    zT_57 = ec;
    zT_58 = module_id;
    zT_59 = decl.child_1;
    zT_60 = dtype;
    zT_63 = 1;
    zT_64 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_61 = zT_64;
    zT_68 = zF_BF602E2F_classify(zT_57, zT_58, zT_59, zT_60, zT_61);
    root = zT_68;
    goto z_bb_15;
    z_bb_18:
    if (!(root.has_value)) { pal_trap(); }
    r = root.value;
    zT_74 = ec->tbl;
    zT_71 = &zT_74->roots;
    zT_72 = decl_idx;
    zT_73 = r;
    zF_26476265_u32ToU32MapPut(zT_71, zT_72, zT_73);
    zT_76.has_value = 1;
    zT_76.value = r;
    return zT_76;
    z_bb_19:
    zT_80 = ec->tbl;
    zT_77 = &zT_80->roots;
    zT_78 = decl_idx;
    zF_26476265_u32ToU32MapPut(zT_77, zT_78, (unsigned int)(4294967295u));
    zT_83.has_value = 0;
    return zT_83;
}

/* typeKindOf */
unsigned int zF_4E56FBAE_typeKindOf(zT_4D150975_ConstInitEvalCtx* ec, unsigned int type_id) {
    unsigned char zT_4;
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_D155D06D_Type* zT_13;
    unsigned int zT_14;
    zT_D155D06D_Type zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    if ((unsigned char)(type_id == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = ec->registry;
    zT_7 = zT_6->types_len;
    zT_4 = (unsigned int)((unsigned int)type_id) >= zT_7;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel));
    z_bb_5:
    zT_12 = ec->registry;
    zT_13 = zT_12->types_items;
    zT_14 = (unsigned int)type_id;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.kind;
    return (unsigned int)((unsigned int)zT_16);
}

/* isU8ish */
unsigned char zF_092A96D8_isU8ish(zT_4D150975_ConstInitEvalCtx* ec, unsigned int elem) {
    unsigned char zT_4;
    zT_4D150975_ConstInitEvalCtx* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    if ((unsigned char)(elem == (unsigned int)(8))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = elem == (unsigned int)(14);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    zT_8 = ec;
    zT_9 = elem;
    zT_10 = zF_4E56FBAE_typeKindOf(zT_8, zT_9);
    if ((unsigned char)(zT_10 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type)))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(0);
}

/* valNodeFromComptime */
zT_BAEE192E_Opt_10 zF_23832EEE_valNodeFromComptime(zT_4D150975_ConstInitEvalCtx* ec, zT_89B1DDDA_ComptimeVal cv, unsigned int type_id) {
    unsigned char zT_3;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    unsigned char zT_8;
    zT_BAEE192E_Opt_10 zT_10;
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    zT_4D150975_ConstInitEvalCtx* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_27;
    unsigned char zT_32;
    unsigned char zT_37;
    unsigned char zT_42;
    unsigned char zT_47;
    unsigned char zT_52;
    unsigned char zT_57;
    unsigned char zT_62;
    unsigned char zT_67;
    unsigned char zT_72;
    unsigned char zT_77;
    unsigned char zT_82;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_0163D9A4_ComptimeInt zT_88;
    unsigned int zT_89;
    zT_0163D9A4_ComptimeInt zT_91;
    unsigned char zT_92;
    zT_BAEE192E_Opt_10 zT_94;
    zT_0163D9A4_ComptimeInt zT_96;
    zT_0163D9A4_ComptimeInt zT_97;
    zT_79FAE712_u64 zT_98;
    unsigned int zT_100;
    zT_0163D9A4_ComptimeInt zT_101;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_4065182A_ConstInitTable* zT_104;
    unsigned char zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned int zT_110;
    unsigned int zT_112;
    zT_BAEE192E_Opt_10 zT_113;
    unsigned char zT_114;
    zT_79FAE712_u64 zT_118;
    zT_0163D9A4_ComptimeInt zT_119;
    zT_0163D9A4_ComptimeInt zT_120;
    unsigned char zT_121;
    zT_79FAE712_u64 zT_123;
    zT_4065182A_ConstInitTable* zT_124;
    unsigned char zT_125;
    zT_79FAE712_u64 zT_126;
    unsigned int zT_130;
    unsigned int zT_133;
    zT_BAEE192E_Opt_10 zT_134;
    unsigned char zT_135;
    zT_4065182A_ConstInitTable* zT_138;
    unsigned char zT_139;
    zT_79FAE712_u64 zT_140;
    unsigned int zT_144;
    unsigned int zT_148;
    zT_BAEE192E_Opt_10 zT_149;
    zT_BAEE192E_Opt_10 zT_150;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    unsigned int tk;
    unsigned char is_int_ty;
    zT_79FAE712_u64 pattern;
    unsigned int nflag;
    zT_79FAE712_u64 bv;
    zT_3 = cv.kind;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = cv.v;
    zT_6 = zT_7;
    zT_8 = zF_EF3A264A_comptimeIntFits64(zT_6);
    if ((unsigned char)(!zT_8)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_114 = cv.kind;
    if ((unsigned char)(zT_114 == (unsigned char)(1))) goto z_bb_52; else goto z_bb_53;
    z_bb_3:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_4:
    if ((unsigned char)(type_id != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = ec->registry;
    zT_16 = zT_15->types_len;
    zT_13 = (unsigned int)((unsigned int)type_id) < zT_16;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = ec;
    zT_20 = type_id;
    zT_21 = zF_4E56FBAE_typeKindOf(zT_19, zT_20);
    tk = zT_21;
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type)))) goto z_bb_11; else goto z_bb_10;
    z_bb_9:
    zT_97 = cv.v;
    zT_96 = zT_97;
    zT_98 = zF_4F2C9C5D_ciToU64(zT_96);
    pattern = zT_98;
    zT_100 = 0;
    nflag = zT_100;
    zT_101 = cv.v;
    zT_102 = zT_101.neg;
    if (zT_102) goto z_bb_50; else goto z_bb_51;
    z_bb_10:
    zT_27 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type));
    goto z_bb_12;
    z_bb_11:
    zT_27 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_27) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_32 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type));
    goto z_bb_15;
    z_bb_14:
    zT_32 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_37 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type));
    goto z_bb_18;
    z_bb_17:
    zT_37 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_37) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_42 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type));
    goto z_bb_21;
    z_bb_20:
    zT_42 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_42) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_47 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type));
    goto z_bb_24;
    z_bb_23:
    zT_47 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_47) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_52 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type));
    goto z_bb_27;
    z_bb_26:
    zT_52 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_52) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_57 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type));
    goto z_bb_30;
    z_bb_29:
    zT_57 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_57) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_62 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type));
    goto z_bb_33;
    z_bb_32:
    zT_62 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_62) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_67 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type));
    goto z_bb_36;
    z_bb_35:
    zT_67 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_67) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_72 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type));
    goto z_bb_39;
    z_bb_38:
    zT_72 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_72) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_77 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type));
    goto z_bb_42;
    z_bb_41:
    zT_77 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_77) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_82 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type));
    goto z_bb_45;
    z_bb_44:
    zT_82 = 1;
    goto z_bb_45;
    z_bb_45:
    is_int_ty = zT_82;
    if (is_int_ty) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_87 = ec->registry;
    zT_91 = cv.v;
    zT_88 = zT_91;
    zT_89 = type_id;
    zT_92 = zF_B28C4720_comptimeIntFitsType(zT_87, zT_88, zT_89);
    if ((unsigned char)(!zT_92)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_9;
    z_bb_48:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_103 = 1;
    nflag = zT_103;
    goto z_bb_51;
    z_bb_51:
    zT_104 = ec->tbl;
    zT_110 = 1;
    zT_105 = zT_110;
    zT_106 = pattern;
    zT_107 = nflag;
    zT_112 = zF_094E0976_tableAddNode(zT_104, zT_105, zT_106, zT_107, (unsigned int)(0));
    zT_113.has_value = 1;
    zT_113.value = zT_112;
    return zT_113;
    z_bb_52:
    zT_118 = 0;
    bv = zT_118;
    zT_120 = cv.v;
    zT_119 = zT_120;
    zT_121 = zF_0F5FA15F_ciIsZero(zT_119);
    if ((unsigned char)(!zT_121)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_135 = cv.kind;
    if ((unsigned char)(zT_135 == (unsigned char)(2))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_123 = 1;
    bv = zT_123;
    goto z_bb_55;
    z_bb_55:
    zT_124 = ec->tbl;
    zT_130 = 3;
    zT_125 = zT_130;
    zT_126 = bv;
    zT_133 = zF_094E0976_tableAddNode(zT_124, zT_125, zT_126, (unsigned int)(0), (unsigned int)(0));
    zT_134.has_value = 1;
    zT_134.value = zT_133;
    return zT_134;
    z_bb_56:
    zT_138 = ec->tbl;
    zT_144 = 2;
    zT_139 = zT_144;
    zT_140 = cv.float_bits;
    zT_148 = zF_094E0976_tableAddNode(zT_138, zT_139, zT_140, (unsigned int)(0), (unsigned int)(0));
    zT_149.has_value = 1;
    zT_149.value = zT_148;
    return zT_149;
    z_bb_57:
    zT_150.has_value = 0;
    return zT_150;
}

/* symbolIsConstGlobalSym */
unsigned char zF_145B7326_symbolIsConstGlobal(zT_3A105EF1_Symbol* s) {
    zT_3C598AEF_SymbolKind zT_1;
    unsigned short zT_6;
    zT_1 = s->kind;
    if ((unsigned char)(zT_1 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = s->flags;
    return (unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_6) & (unsigned short)(1)) == (unsigned short)(0));
}

/* resolveModuleBaseNode */
unsigned int zF_644AB5CE_resolveModuleBaseNo(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int base_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10;
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    zT_3D7259E2_SymbolRegistry* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_EAF7A2A2_Opt_953 zT_24;
    unsigned char zT_25;
    zT_3C598AEF_SymbolKind zT_27;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_35;
    unsigned int zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    unsigned short zT_51;
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_072B53A6_ModuleRegistry* zT_63;
    unsigned int zT_64;
    zT_BAEE192E_Opt_10 zT_66;
    unsigned char zT_67;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zT_22A7C88B_AstNode bn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    unsigned int path_id;
    unsigned int mtid;
    if ((unsigned char)(base_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = ec->store;
    zT_8 = base_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    bn = zT_10;
    zT_11 = bn.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ec->store;
    zT_17 = base_idx;
    zT_19 = zF_53458827_astStoreIdentifier(zT_16, zT_17);
    nid = zT_19;
    zT_20 = ec->symbol_reg;
    zT_21 = module_id;
    zT_22 = nid;
    zT_24 = zF_A398987E_symbolRegistryQuali(zT_20, zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_54 = bn.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_5:
    if (!(zT_24.has_value)) { pal_trap(); }
    s = zT_24.value;
    zT_27 = s->kind;
    if ((unsigned char)(zT_27 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_31 = s->module_id;
    return zT_31;
    z_bb_8:
    zT_32 = s->type_id;
    if ((unsigned char)(zT_32 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_36 = s->type_id;
    zT_38 = ec->registry;
    zT_39 = zT_38->types_len;
    zT_35 = (unsigned int)((unsigned int)zT_36) < zT_39;
    goto z_bb_11;
    z_bb_10:
    zT_35 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_35) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_42 = ec->registry;
    zT_43 = zT_42->types_items;
    zT_44 = s->type_id;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    sty = zT_46;
    zT_47 = sty.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_6;
    z_bb_14:
    zT_51 = sty.module_id;
    return (unsigned int)((unsigned int)zT_51);
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_59 = ec->store;
    zT_60 = base_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    path_id = zT_62;
    zT_63 = ec->module_reg;
    zT_64 = path_id;
    zT_66 = zF_A258E183_moduleRegistryPathT(zT_63, zT_64);
    zT_67 = zT_66.has_value;
    if (zT_67) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return (unsigned int)(0);
    z_bb_18:
    if (!(zT_66.has_value)) { pal_trap(); }
    mtid = zT_66.value;
    return mtid;
    z_bb_19:
    return (unsigned int)(0);
}

/* valueCopyDecl */
zT_BAEE192E_Opt_10 zF_07765C6B_valueCopyDecl(zT_4D150975_ConstInitEvalCtx* ec, unsigned int target_module, unsigned int decl_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11;
    zT_8143F551_AstKind zT_12;
    zT_BAEE192E_Opt_10 zT_16;
    unsigned char zT_17;
    zT_BAEE192E_Opt_10 zT_23;
    zT_4D150975_ConstInitEvalCtx* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_BAEE192E_Opt_10 zT_28;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zT_22A7C88B_AstNode decl;
    if ((unsigned char)(decl_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_8 = ec->store;
    zT_9 = decl_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    decl = zT_11;
    zT_12 = decl.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16.has_value = 0;
    return zT_16;
    z_bb_4:
    zT_17 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_17) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_6:
    zT_24 = ec;
    zT_25 = target_module;
    zT_26 = decl_idx;
    zT_27 = depth;
    zT_28 = zF_4E698A93_evalDecl(zT_24, zT_25, zT_26, zT_27);
    return zT_28;
}

/* classifyScalar */
zT_BAEE192E_Opt_10 zF_83AC95E3_classifyScalar(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    zT_0BB15AEA_anon_284822 zT_16;
    zT_00435AEB_f64* zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_00435AEB_f64 zT_23;
    zT_00435AEB_f64* zT_25;
    zT_79FAE712_u64* zT_26;
    zT_4065182A_ConstInitTable* zT_27;
    unsigned char zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_33;
    unsigned int zT_37;
    zT_BAEE192E_Opt_10 zT_38;
    zT_8143F551_AstKind zT_39;
    zT_79FAE712_u64 zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_79FAE712_u64 zT_48;
    zT_0163D9A4_ComptimeInt zT_49;
    zT_4D150975_ConstInitEvalCtx* zT_50;
    zT_89B1DDDA_ComptimeVal zT_51;
    unsigned int zT_52;
    zT_0163D9A4_ComptimeInt zT_53;
    zT_89B1DDDA_ComptimeVal zT_54;
    zT_BAEE192E_Opt_10 zT_55;
    zT_8143F551_AstKind zT_56;
    zT_79FAE712_u64 zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_79FAE712_u64 zT_65;
    zT_0163D9A4_ComptimeInt zT_66;
    zT_4D150975_ConstInitEvalCtx* zT_68;
    zT_89B1DDDA_ComptimeVal zT_69;
    unsigned int zT_70;
    zT_0163D9A4_ComptimeInt zT_71;
    zT_89B1DDDA_ComptimeVal zT_72;
    zT_BAEE192E_Opt_10 zT_73;
    unsigned char zT_74;
    zT_4065182A_ConstInitTable* zT_77;
    zT_49DE1C22_ConstInitNode* zT_78;
    zT_49DE1C22_ConstInitNode* zT_80;
    zT_BAEE192E_Opt_10 zT_81;
    zT_BAEE192E_Opt_10 zT_82;
    zT_8143F551_AstKind zT_83;
    zT_79FAE712_u64 zT_88;
    unsigned char zT_89;
    zT_79FAE712_u64 zT_94;
    zT_4065182A_ConstInitTable* zT_95;
    unsigned char zT_96;
    zT_79FAE712_u64 zT_97;
    unsigned int zT_101;
    unsigned int zT_104;
    zT_BAEE192E_Opt_10 zT_105;
    zT_8143F551_AstKind zT_106;
    zT_21D3708C_U32ToU32Map* zT_110;
    unsigned int zT_111;
    zT_BAEE192E_Opt_10 zT_113;
    unsigned char zT_114;
    zT_0163D9A4_ComptimeInt zT_119;
    zT_4D150975_ConstInitEvalCtx* zT_120;
    zT_89B1DDDA_ComptimeVal zT_121;
    unsigned int zT_122;
    zT_0163D9A4_ComptimeInt zT_123;
    zT_89B1DDDA_ComptimeVal zT_124;
    zT_BAEE192E_Opt_10 zT_125;
    zT_BAEE192E_Opt_10 zT_126;
    zT_8143F551_AstKind zT_127;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    unsigned int zT_135;
    zT_3D7259E2_SymbolRegistry* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    zT_EAF7A2A2_Opt_953 zT_140;
    unsigned char zT_141;
    zT_3C598AEF_SymbolKind zT_143;
    zT_4065182A_ConstInitTable* zT_147;
    unsigned char zT_148;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_158;
    zT_BAEE192E_Opt_10 zT_159;
    zT_3A105EF1_Symbol* zT_160;
    unsigned char zT_161;
    zT_4D150975_ConstInitEvalCtx* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_BAEE192E_Opt_10 zT_168;
    zT_BAEE192E_Opt_10 zT_169;
    zT_8143F551_AstKind zT_170;
    zT_4D150975_ConstInitEvalCtx* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    unsigned int zT_186;
    zT_3D7259E2_SymbolRegistry* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_EAF7A2A2_Opt_953 zT_191;
    unsigned char zT_192;
    zT_3C598AEF_SymbolKind zT_194;
    zT_4065182A_ConstInitTable* zT_198;
    unsigned char zT_199;
    unsigned int zT_201;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_209;
    zT_BAEE192E_Opt_10 zT_210;
    zT_3A105EF1_Symbol* zT_211;
    unsigned char zT_212;
    zT_4D150975_ConstInitEvalCtx* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_BAEE192E_Opt_10 zT_219;
    zT_BAEE192E_Opt_10 zT_220;
    zT_8143F551_AstKind zT_221;
    zT_4D150975_ConstInitEvalCtx* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_BAEE192E_Opt_10 zT_231;
    zT_8143F551_AstKind zT_232;
    unsigned char zT_234;
    zT_DA663F79_ComptimeEval* zT_235;
    unsigned int zT_236;
    zT_E737EA31_Opt_219 zT_238;
    unsigned char zT_239;
    zT_4D150975_ConstInitEvalCtx* zT_241;
    zT_89B1DDDA_ComptimeVal zT_242;
    unsigned int zT_243;
    zT_BAEE192E_Opt_10 zT_244;
    zT_BAEE192E_Opt_10 zT_245;
    zT_BAEE192E_Opt_10 zT_246;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_82, (unsigned int)sizeof zT_82);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_126, (unsigned int)sizeof zT_126);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_179, (unsigned int)sizeof zT_179);
    zig_poison_fill((void*)&zT_186, (unsigned int)sizeof zT_186);
    zig_poison_fill((void*)&zT_191, (unsigned int)sizeof zT_191);
    zig_poison_fill((void*)&zT_209, (unsigned int)sizeof zT_209);
    zig_poison_fill((void*)&zT_212, (unsigned int)sizeof zT_212);
    zig_poison_fill((void*)&zT_219, (unsigned int)sizeof zT_219);
    zig_poison_fill((void*)&zT_220, (unsigned int)sizeof zT_220);
    zig_poison_fill((void*)&zT_231, (unsigned int)sizeof zT_231);
    zig_poison_fill((void*)&zT_234, (unsigned int)sizeof zT_234);
    zig_poison_fill((void*)&zT_238, (unsigned int)sizeof zT_238);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_245, (unsigned int)sizeof zT_245);
    zig_poison_fill((void*)&zT_246, (unsigned int)sizeof zT_246);
    zT_22A7C88B_AstNode node;
    zT_00435AEB_f64 fb0;
    zT_79FAE712_u64* fbp0;
    zT_0163D9A4_ComptimeInt v;
    zT_0163D9A4_ComptimeInt v2;
    zT_BAEE192E_Opt_10 nid2;
    unsigned int n2;
    zT_79FAE712_u64 bv;
    unsigned int ev;
    zT_0163D9A4_ComptimeInt pv;
    unsigned int name_id;
    zT_3A105EF1_Symbol* s;
    unsigned int mid;
    unsigned int fname;
    zT_3A105EF1_Symbol* s2;
    zT_89B1DDDA_ComptimeVal cv;
    zT_6 = ec->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = ec->store;
    zT_16 = zT_15->float_values;
    zT_17 = zT_16.items;
    zT_18 = ec->store;
    zT_19 = node_idx;
    zT_21 = zF_8BA26B9E_astStoreNodePayload(zT_18, zT_19);
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_17[zT_22];
    fb0 = zT_23;
    zT_25 = (zT_00435AEB_f64*)&fb0;
    zT_26 = (zT_79FAE712_u64*)zT_25;
    fbp0 = zT_26;
    zT_27 = ec->tbl;
    zT_33 = 2;
    zT_28 = zT_33;
    zT_29 = *fbp0;
    zT_37 = zF_094E0976_tableAddNode(zT_27, zT_28, zT_29, (unsigned int)(0), (unsigned int)(0));
    zT_38.has_value = 1;
    zT_38.value = zT_37;
    return zT_38;
    z_bb_2:
    zT_39 = node.kind;
    if ((unsigned char)(zT_39 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_45 = ec->store;
    zT_46 = node_idx;
    zT_48 = zF_678B9A72_astStoreIntValue(zT_45, zT_46);
    zT_44 = zT_48;
    zT_49 = zF_1EAA44E6_ciFromU64(zT_44);
    v = zT_49;
    zT_50 = ec;
    zT_53 = v;
    zT_54 = zF_237A4571_ciIntVal(zT_53);
    zT_51 = zT_54;
    zT_52 = type_id;
    zT_55 = zF_23832EEE_valNodeFromComptime(zT_50, zT_51, zT_52);
    return zT_55;
    z_bb_4:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_62 = ec->store;
    zT_63 = node_idx;
    zT_65 = zF_678B9A72_astStoreIntValue(zT_62, zT_63);
    zT_61 = zT_65;
    zT_66 = zF_1EAA44E6_ciFromU64(zT_61);
    v2 = zT_66;
    zT_68 = ec;
    zT_71 = v2;
    zT_72 = zF_237A4571_ciIntVal(zT_71);
    zT_69 = zT_72;
    zT_70 = type_id;
    zT_73 = zF_23832EEE_valNodeFromComptime(zT_68, zT_69, zT_70);
    nid2 = zT_73;
    zT_74 = nid2.has_value;
    if (zT_74) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_83 = node.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if (!(nid2.has_value)) { pal_trap(); }
    n2 = nid2.value;
    zT_77 = ec->tbl;
    zT_78 = zT_77->nodes;
    zT_80 = zT_78 + (unsigned int)((unsigned int)n2);
    zT_80->kind = (unsigned int)(4);
    zT_81.has_value = 1;
    zT_81.value = n2;
    return zT_81;
    z_bb_8:
    zT_82.has_value = 0;
    return zT_82;
    z_bb_9:
    zT_88 = 0;
    bv = zT_88;
    zT_89 = node.flags;
    if ((unsigned char)((unsigned char)(zT_89 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_106 = node.kind;
    if ((unsigned char)(zT_106 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_94 = 1;
    bv = zT_94;
    goto z_bb_12;
    z_bb_12:
    zT_95 = ec->tbl;
    zT_101 = 3;
    zT_96 = zT_101;
    zT_97 = bv;
    zT_104 = zF_094E0976_tableAddNode(zT_95, zT_96, zT_97, (unsigned int)(0), (unsigned int)(0));
    zT_105.has_value = 1;
    zT_105.value = zT_104;
    return zT_105;
    z_bb_13:
    zT_110 = ec->enum_values;
    zT_111 = node_idx;
    zT_113 = zF_F3EE5998_u32ToU32MapGet(zT_110, zT_111);
    zT_114 = zT_113.has_value;
    if (zT_114) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_127 = node.kind;
    if ((unsigned char)(zT_127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    if (!(zT_113.has_value)) { pal_trap(); }
    ev = zT_113.value;
    zT_119 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)ev));
    pv = zT_119;
    zT_120 = ec;
    zT_123 = pv;
    zT_124 = zF_237A4571_ciIntVal(zT_123);
    zT_121 = zT_124;
    zT_122 = type_id;
    zT_125 = zF_23832EEE_valNodeFromComptime(zT_120, zT_121, zT_122);
    return zT_125;
    z_bb_16:
    zT_126.has_value = 0;
    return zT_126;
    z_bb_17:
    zT_132 = ec->store;
    zT_133 = node_idx;
    zT_135 = zF_53458827_astStoreIdentifier(zT_132, zT_133);
    name_id = zT_135;
    zT_136 = ec->symbol_reg;
    zT_137 = module_id;
    zT_138 = name_id;
    zT_140 = zF_A398987E_symbolRegistryQuali(zT_136, zT_137, zT_138);
    zT_141 = zT_140.has_value;
    if (zT_141) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_170 = node.kind;
    if ((unsigned char)(zT_170 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_25; else goto z_bb_26;
    z_bb_19:
    if (!(zT_140.has_value)) { pal_trap(); }
    s = zT_140.value;
    zT_143 = s->kind;
    if ((unsigned char)(zT_143 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_169.has_value = 0;
    return zT_169;
    z_bb_21:
    zT_147 = ec->tbl;
    zT_153 = 7;
    zT_148 = zT_153;
    zT_154 = s->name_id;
    zT_150 = s->module_id;
    zT_158 = zF_094E0976_tableAddNode(zT_147, zT_148, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_154), zT_150, (unsigned int)(0));
    zT_159.has_value = 1;
    zT_159.value = zT_158;
    return zT_159;
    z_bb_22:
    zT_160 = s;
    zT_161 = zF_145B7326_symbolIsConstGlobal(zT_160);
    if (zT_161) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_162 = ec;
    zT_163 = s->module_id;
    zT_164 = s->decl_node;
    zT_165 = depth;
    zT_168 = zF_07765C6B_valueCopyDecl(zT_162, zT_163, zT_164, zT_165);
    return zT_168;
    z_bb_24:
    goto z_bb_20;
    z_bb_25:
    zT_175 = ec;
    zT_176 = module_id;
    zT_177 = node.child_0;
    zT_179 = zF_644AB5CE_resolveModuleBaseNo(zT_175, zT_176, zT_177);
    mid = zT_179;
    if ((unsigned char)(mid != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_221 = node.kind;
    if ((unsigned char)(zT_221 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_35; else goto z_bb_36;
    z_bb_27:
    zT_183 = ec->store;
    zT_184 = node_idx;
    zT_186 = zF_8BA26B9E_astStoreNodePayload(zT_183, zT_184);
    fname = zT_186;
    zT_187 = ec->symbol_reg;
    zT_188 = mid;
    zT_189 = fname;
    zT_191 = zF_A398987E_symbolRegistryQuali(zT_187, zT_188, zT_189);
    zT_192 = zT_191.has_value;
    if (zT_192) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_220.has_value = 0;
    return zT_220;
    z_bb_29:
    if (!(zT_191.has_value)) { pal_trap(); }
    s2 = zT_191.value;
    zT_194 = s2->kind;
    if ((unsigned char)(zT_194 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_198 = ec->tbl;
    zT_204 = 7;
    zT_199 = zT_204;
    zT_205 = s2->name_id;
    zT_201 = s2->module_id;
    zT_209 = zF_094E0976_tableAddNode(zT_198, zT_199, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_205), zT_201, (unsigned int)(0));
    zT_210.has_value = 1;
    zT_210.value = zT_209;
    return zT_210;
    z_bb_32:
    zT_211 = s2;
    zT_212 = zF_145B7326_symbolIsConstGlobal(zT_211);
    if (zT_212) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_213 = ec;
    zT_214 = s2->module_id;
    zT_215 = s2->decl_node;
    zT_216 = depth;
    zT_219 = zF_07765C6B_valueCopyDecl(zT_213, zT_214, zT_215, zT_216);
    return zT_219;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_225 = ec;
    zT_226 = module_id;
    zT_227 = node.child_0;
    zT_228 = type_id;
    zT_229 = depth;
    zT_231 = zF_BF602E2F_classify(zT_225, zT_226, zT_227, zT_228, zT_229);
    return zT_231;
    z_bb_36:
    zT_232 = node.kind;
    zT_234 = zF_CEDEFC06_comptimeShapeKind(zT_232);
    if (zT_234) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_235 = ec->ce;
    zT_236 = node_idx;
    zT_238 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_235, zT_236);
    zT_239 = zT_238.has_value;
    if (zT_239) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_246.has_value = 0;
    return zT_246;
    z_bb_39:
    if (!(zT_238.has_value)) { pal_trap(); }
    cv = zT_238.value;
    zT_241 = ec;
    zT_242 = cv;
    zT_243 = type_id;
    zT_244 = zF_23832EEE_valNodeFromComptime(zT_241, zT_242, zT_243);
    return zT_244;
    z_bb_40:
    zT_245.has_value = 0;
    return zT_245;
}

/* comptimeShapeKind */
unsigned char zF_CEDEFC06_comptimeShapeKind(zT_8143F551_AstKind k) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    unsigned char zT_28;
    unsigned char zT_36;
    unsigned char zT_40;
    unsigned char zT_44;
    unsigned char zT_48;
    unsigned char zT_56;
    unsigned char zT_64;
    unsigned char zT_68;
    unsigned char zT_72;
    unsigned char zT_76;
    unsigned char zT_80;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_16 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_11;
    z_bb_10:
    zT_16 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_16) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_20 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_14;
    z_bb_13:
    zT_20 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_20) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_24 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_17;
    z_bb_16:
    zT_24 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_24) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_28 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_20;
    z_bb_19:
    zT_28 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_28) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_36 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_25;
    z_bb_24:
    zT_36 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_36) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_40 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_28;
    z_bb_27:
    zT_40 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_40) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_44 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_31;
    z_bb_30:
    zT_44 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_44) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_48 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_34;
    z_bb_33:
    zT_48 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_48) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_56 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_39;
    z_bb_38:
    zT_56 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_56) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)(1);
    z_bb_41:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_64 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_44;
    z_bb_43:
    zT_64 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_64) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_68 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_47;
    z_bb_46:
    zT_68 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_68) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_72 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_50;
    z_bb_49:
    zT_72 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_72) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_76 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_53;
    z_bb_52:
    zT_76 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_76) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_80 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_56;
    z_bb_55:
    zT_80 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_80) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned char)(1);
    z_bb_58:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(1);
    z_bb_60:
    return (unsigned char)(0);
}

/* classifyAddr */
zT_BAEE192E_Opt_10 zF_19E37948_classifyAddr(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int target_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    zT_3D7259E2_SymbolRegistry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_EAF7A2A2_Opt_953 zT_22;
    unsigned char zT_23;
    zT_3C598AEF_SymbolKind zT_25;
    zT_4065182A_ConstInitTable* zT_29;
    unsigned char zT_30;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_41;
    zT_3C598AEF_SymbolKind zT_42;
    unsigned int zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    unsigned int zT_49;
    zT_BAEE192E_Opt_10 zT_52;
    unsigned char zT_53;
    unsigned int zT_55;
    zT_4065182A_ConstInitTable* zT_56;
    unsigned char zT_57;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_66;
    zT_BAEE192E_Opt_10 zT_67;
    zT_BAEE192E_Opt_10 zT_68;
    zT_8143F551_AstKind zT_69;
    zT_4D150975_ConstInitEvalCtx* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_78;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    zT_3D7259E2_SymbolRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_EAF7A2A2_Opt_953 zT_90;
    unsigned char zT_91;
    zT_3C598AEF_SymbolKind zT_93;
    zT_4065182A_ConstInitTable* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_108;
    zT_BAEE192E_Opt_10 zT_109;
    zT_3C598AEF_SymbolKind zT_110;
    unsigned int zT_115;
    zT_8EED1867_ResolvedTypeTable* zT_116;
    unsigned int zT_117;
    zT_BAEE192E_Opt_10 zT_120;
    unsigned char zT_121;
    zT_4065182A_ConstInitTable* zT_123;
    unsigned char zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_133;
    zT_BAEE192E_Opt_10 zT_134;
    zT_BAEE192E_Opt_10 zT_135;
    zT_BAEE192E_Opt_10 zT_136;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_120, (unsigned int)sizeof zT_120);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    zig_poison_fill((void*)&zT_136, (unsigned int)sizeof zT_136);
    zT_22A7C88B_AstNode t;
    unsigned int name_id;
    zT_3A105EF1_Symbol* s;
    unsigned int gtid;
    unsigned int gt;
    unsigned int mid;
    unsigned int fname;
    zT_3A105EF1_Symbol* s2;
    unsigned int gtid2;
    unsigned int gt2;
    (void)depth;
    zT_5 = ec->store;
    zT_6 = target_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    t = zT_8;
    zT_9 = t.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = ec->store;
    zT_15 = target_idx;
    zT_17 = zF_53458827_astStoreIdentifier(zT_14, zT_15);
    name_id = zT_17;
    zT_18 = ec->symbol_reg;
    zT_19 = module_id;
    zT_20 = name_id;
    zT_22 = zF_A398987E_symbolRegistryQuali(zT_18, zT_19, zT_20);
    zT_23 = zT_22.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_69 = t.kind;
    if ((unsigned char)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_12; else goto z_bb_13;
    z_bb_3:
    if (!(zT_22.has_value)) { pal_trap(); }
    s = zT_22.value;
    zT_25 = s->kind;
    if ((unsigned char)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_68.has_value = 0;
    return zT_68;
    z_bb_5:
    zT_29 = ec->tbl;
    zT_35 = 7;
    zT_30 = zT_35;
    zT_36 = s->name_id;
    zT_32 = s->module_id;
    zT_40 = zF_094E0976_tableAddNode(zT_29, zT_30, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_36), zT_32, (unsigned int)(0));
    zT_41.has_value = 1;
    zT_41.value = zT_40;
    return zT_41;
    z_bb_6:
    zT_42 = s->kind;
    if ((unsigned char)(zT_42 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_47 = 0;
    gtid = zT_47;
    zT_48 = ec->resolved;
    zT_49 = s->decl_node;
    zT_52 = zF_999DCF51_resolvedTypeTableGe(zT_48, zT_49);
    zT_53 = zT_52.has_value;
    if (zT_53) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    if (!(zT_52.has_value)) { pal_trap(); }
    gt = zT_52.value;
    gtid = gt;
    goto z_bb_10;
    z_bb_10:
    zT_56 = ec->tbl;
    zT_62 = 6;
    zT_57 = zT_62;
    zT_63 = s->name_id;
    zT_59 = s->module_id;
    zT_60 = gtid;
    zT_66 = zF_094E0976_tableAddNode(zT_56, zT_57, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_63), zT_59, zT_60);
    zT_67.has_value = 1;
    zT_67.value = zT_66;
    return zT_67;
    z_bb_11:
    zT_55 = s->type_id;
    gtid = zT_55;
    goto z_bb_10;
    z_bb_12:
    zT_74 = ec;
    zT_75 = module_id;
    zT_76 = t.child_0;
    zT_78 = zF_644AB5CE_resolveModuleBaseNo(zT_74, zT_75, zT_76);
    mid = zT_78;
    if ((unsigned char)(mid != (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_14:
    zT_82 = ec->store;
    zT_83 = target_idx;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_82, zT_83);
    fname = zT_85;
    zT_86 = ec->symbol_reg;
    zT_87 = mid;
    zT_88 = fname;
    zT_90 = zF_A398987E_symbolRegistryQuali(zT_86, zT_87, zT_88);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_135.has_value = 0;
    return zT_135;
    z_bb_16:
    if (!(zT_90.has_value)) { pal_trap(); }
    s2 = zT_90.value;
    zT_93 = s2->kind;
    if ((unsigned char)(zT_93 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_97 = ec->tbl;
    zT_103 = 7;
    zT_98 = zT_103;
    zT_104 = s2->name_id;
    zT_100 = s2->module_id;
    zT_108 = zF_094E0976_tableAddNode(zT_97, zT_98, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_104), zT_100, (unsigned int)(0));
    zT_109.has_value = 1;
    zT_109.value = zT_108;
    return zT_109;
    z_bb_19:
    zT_110 = s2->kind;
    if ((unsigned char)(zT_110 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_115 = s2->type_id;
    gtid2 = zT_115;
    zT_116 = ec->resolved;
    zT_117 = s2->decl_node;
    zT_120 = zF_999DCF51_resolvedTypeTableGe(zT_116, zT_117);
    zT_121 = zT_120.has_value;
    if (zT_121) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_17;
    z_bb_22:
    if (!(zT_120.has_value)) { pal_trap(); }
    gt2 = zT_120.value;
    gtid2 = gt2;
    goto z_bb_23;
    z_bb_23:
    zT_123 = ec->tbl;
    zT_129 = 6;
    zT_124 = zT_129;
    zT_130 = s2->name_id;
    zT_126 = s2->module_id;
    zT_127 = gtid2;
    zT_133 = zF_094E0976_tableAddNode(zT_123, zT_124, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_130), zT_126, zT_127);
    zT_134.has_value = 1;
    zT_134.value = zT_133;
    return zT_134;
}

/* classifyAgg */
zT_BAEE192E_Opt_10 zF_F7CF67F0_classifyAgg(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12;
    zT_4D150975_ConstInitEvalCtx* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    zT_3D7259E2_SymbolRegistry* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_EAF7A2A2_Opt_953 zT_30;
    unsigned char zT_31;
    zT_3A105EF1_Symbol* zT_33;
    unsigned char zT_34;
    zT_4D150975_ConstInitEvalCtx* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_BAEE192E_Opt_10 zT_41;
    zT_BAEE192E_Opt_10 zT_42;
    zT_8143F551_AstKind zT_43;
    zT_4D150975_ConstInitEvalCtx* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    zT_3D7259E2_SymbolRegistry* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_EAF7A2A2_Opt_953 zT_64;
    unsigned char zT_65;
    zT_3A105EF1_Symbol* zT_67;
    unsigned char zT_68;
    zT_4D150975_ConstInitEvalCtx* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_BAEE192E_Opt_10 zT_75;
    zT_BAEE192E_Opt_10 zT_76;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_E834303C_ArrayPayload* zT_83;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_D155D06D_Type* zT_85;
    unsigned int zT_86;
    zT_D155D06D_Type zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_E834303C_ArrayPayload zT_90;
    unsigned int zT_92;
    zT_8143F551_AstKind zT_93;
    unsigned char zT_97;
    zT_8143F551_AstKind zT_98;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    unsigned int zT_106;
    zT_BAEE192E_Opt_10 zT_109;
    zT_4065182A_ConstInitTable* zT_111;
    unsigned char zT_112;
    unsigned int zT_117;
    unsigned int zT_121;
    zT_3E40CD83_Sand* zT_123;
    unsigned int zT_124;
    zT_4065182A_ConstInitTable* zT_126;
    unsigned int zT_128;
    int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    zT_81AD2998_EU_952 zT_140;
    unsigned char zT_141;
    unsigned char* zT_142;
    unsigned int* zT_145;
    unsigned int zT_147;
    unsigned char zT_149;
    zT_6B0A7D14_AstStore* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_158;
    zT_4D150975_ConstInitEvalCtx* zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    zT_BAEE192E_Opt_10 zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned char zT_174;
    zT_4065182A_ConstInitTable* zT_175;
    unsigned char zT_176;
    unsigned int zT_181;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned char zT_191;
    zT_BAEE192E_Opt_10 zT_193;
    zT_4065182A_ConstInitTable* zT_194;
    unsigned int zT_195;
    unsigned int* zT_196;
    unsigned int zT_197;
    zT_BAEE192E_Opt_10 zT_199;
    zT_BAEE192E_Opt_10 zT_200;
    zT_8143F551_AstKind zT_205;
    zT_BAEE192E_Opt_10 zT_209;
    zT_338B7C76_TypeRegistry* zT_211;
    zT_666DC2E1_TuplePayload* zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_D155D06D_Type* zT_214;
    unsigned int zT_215;
    zT_D155D06D_Type zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    zT_666DC2E1_TuplePayload zT_219;
    unsigned short zT_221;
    unsigned int zT_222;
    zT_6B0A7D14_AstStore* zT_224;
    unsigned int zT_225;
    unsigned int zT_227;
    zT_BAEE192E_Opt_10 zT_230;
    zT_4065182A_ConstInitTable* zT_232;
    unsigned char zT_233;
    unsigned int zT_238;
    unsigned int zT_242;
    zT_3E40CD83_Sand* zT_244;
    unsigned int zT_245;
    zT_4065182A_ConstInitTable* zT_247;
    unsigned int zT_249;
    int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned char zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned char zT_259;
    zT_81AD2998_EU_952 zT_261;
    unsigned char zT_262;
    unsigned char* zT_263;
    unsigned int* zT_266;
    unsigned int zT_268;
    unsigned char zT_270;
    zT_338B7C76_TypeRegistry* zT_273;
    unsigned int* zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned char zT_281;
    unsigned int zT_282;
    zT_6B0A7D14_AstStore* zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    zT_4D150975_ConstInitEvalCtx* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned char zT_298;
    zT_BAEE192E_Opt_10 zT_299;
    unsigned char zT_300;
    unsigned int zT_302;
    unsigned char zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned char zT_308;
    zT_BAEE192E_Opt_10 zT_310;
    zT_4065182A_ConstInitTable* zT_311;
    unsigned int zT_312;
    unsigned int* zT_313;
    unsigned int zT_314;
    zT_BAEE192E_Opt_10 zT_316;
    zT_338B7C76_TypeRegistry* zT_322;
    zT_406493CE_StructPayload* zT_323;
    zT_338B7C76_TypeRegistry* zT_324;
    zT_D155D06D_Type* zT_325;
    unsigned int zT_326;
    zT_D155D06D_Type zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    zT_406493CE_StructPayload zT_330;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned short zT_335;
    unsigned int zT_336;
    zT_3E40CD83_Sand* zT_338;
    unsigned int zT_339;
    zT_4065182A_ConstInitTable* zT_341;
    unsigned int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    unsigned char zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    unsigned char zT_352;
    zT_81AD2998_EU_952 zT_354;
    unsigned char zT_355;
    unsigned char* zT_356;
    unsigned int* zT_359;
    unsigned int zT_361;
    unsigned int zT_363;
    zT_338B7C76_TypeRegistry* zT_365;
    zT_2DF01B61_FieldEntry* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned char zT_370;
    zT_2DF01B61_FieldEntry zT_371;
    unsigned int zT_372;
    unsigned int zT_375;
    unsigned int zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned char zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned char zT_386;
    zT_8143F551_AstKind zT_387;
    zT_6B0A7D14_AstStore* zT_392;
    unsigned int zT_393;
    unsigned int zT_395;
    unsigned int zT_397;
    zT_6B0A7D14_AstStore* zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_405;
    zT_6B0A7D14_AstStore* zT_407;
    unsigned int zT_408;
    unsigned int zT_410;
    unsigned char zT_412;
    unsigned int zT_414;
    zT_338B7C76_TypeRegistry* zT_416;
    zT_2DF01B61_FieldEntry* zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    unsigned char zT_421;
    zT_2DF01B61_FieldEntry zT_422;
    unsigned int zT_423;
    unsigned char zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    unsigned int zT_428;
    unsigned char zT_430;
    zT_BAEE192E_Opt_10 zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    unsigned int zT_435;
    unsigned char zT_437;
    zT_4065182A_ConstInitTable* zT_439;
    unsigned char zT_440;
    unsigned int zT_445;
    unsigned int zT_449;
    zT_3E40CD83_Sand* zT_451;
    unsigned int zT_452;
    zT_4065182A_ConstInitTable* zT_454;
    unsigned int zT_456;
    int zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    unsigned char zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned char zT_466;
    zT_81AD2998_EU_952 zT_468;
    unsigned char zT_469;
    unsigned char* zT_470;
    unsigned int* zT_473;
    unsigned int zT_475;
    unsigned char zT_477;
    zT_338B7C76_TypeRegistry* zT_480;
    zT_2DF01B61_FieldEntry* zT_481;
    unsigned int zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    unsigned char zT_488;
    zT_2DF01B61_FieldEntry zT_489;
    unsigned int zT_491;
    unsigned char zT_493;
    unsigned int zT_495;
    zT_6B0A7D14_AstStore* zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    unsigned int zT_503;
    zT_6B0A7D14_AstStore* zT_504;
    unsigned int zT_505;
    unsigned int zT_507;
    unsigned int zT_508;
    zT_4D150975_ConstInitEvalCtx* zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    zT_6B0A7D14_AstStore* zT_515;
    unsigned int zT_516;
    zT_22A7C88B_AstNode zT_518;
    unsigned int zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned char zT_525;
    zT_BAEE192E_Opt_10 zT_526;
    unsigned char zT_527;
    unsigned char zT_529;
    unsigned char zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned char zT_535;
    zT_4065182A_ConstInitTable* zT_538;
    unsigned char zT_539;
    unsigned int zT_544;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    unsigned char zT_554;
    zT_BAEE192E_Opt_10 zT_556;
    zT_4065182A_ConstInitTable* zT_557;
    unsigned int zT_558;
    unsigned int* zT_559;
    unsigned int zT_560;
    zT_BAEE192E_Opt_10 zT_562;
    zT_8143F551_AstKind zT_563;
    zT_6B0A7D14_AstStore* zT_568;
    unsigned int zT_569;
    unsigned int zT_571;
    zT_BAEE192E_Opt_10 zT_574;
    zT_4065182A_ConstInitTable* zT_576;
    unsigned char zT_577;
    unsigned int zT_582;
    unsigned int zT_586;
    zT_3E40CD83_Sand* zT_588;
    unsigned int zT_589;
    zT_4065182A_ConstInitTable* zT_591;
    unsigned int zT_593;
    int zT_594;
    unsigned int zT_595;
    unsigned int zT_596;
    unsigned char zT_598;
    unsigned int zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    unsigned char zT_603;
    zT_81AD2998_EU_952 zT_605;
    unsigned char zT_606;
    unsigned char* zT_607;
    unsigned int* zT_610;
    unsigned int zT_612;
    unsigned char zT_614;
    zT_338B7C76_TypeRegistry* zT_617;
    zT_2DF01B61_FieldEntry* zT_618;
    unsigned int zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned int zT_622;
    unsigned int zT_623;
    unsigned char zT_625;
    zT_2DF01B61_FieldEntry zT_626;
    zT_6B0A7D14_AstStore* zT_628;
    unsigned int zT_629;
    unsigned int zT_630;
    unsigned int zT_632;
    zT_4D150975_ConstInitEvalCtx* zT_633;
    unsigned int zT_634;
    unsigned int zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned int zT_639;
    unsigned int zT_640;
    unsigned int zT_641;
    unsigned char zT_643;
    zT_BAEE192E_Opt_10 zT_644;
    unsigned char zT_645;
    unsigned int zT_647;
    unsigned char zT_648;
    unsigned int zT_649;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned char zT_653;
    zT_BAEE192E_Opt_10 zT_655;
    zT_4065182A_ConstInitTable* zT_656;
    unsigned int zT_657;
    unsigned int* zT_658;
    unsigned int zT_659;
    zT_BAEE192E_Opt_10 zT_661;
    zT_BAEE192E_Opt_10 zT_662;
    zT_8143F551_AstKind zT_667;
    zT_BAEE192E_Opt_10 zT_671;
    zT_338B7C76_TypeRegistry* zT_673;
    zT_AF9231A2_UnionPayload* zT_674;
    zT_338B7C76_TypeRegistry* zT_675;
    zT_D155D06D_Type* zT_676;
    unsigned int zT_677;
    zT_D155D06D_Type zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    zT_AF9231A2_UnionPayload zT_681;
    unsigned int zT_683;
    unsigned int zT_684;
    unsigned short zT_686;
    unsigned int zT_687;
    zT_6B0A7D14_AstStore* zT_689;
    unsigned int zT_690;
    unsigned int zT_692;
    zT_BAEE192E_Opt_10 zT_696;
    zT_6B0A7D14_AstStore* zT_698;
    unsigned int zT_699;
    unsigned int zT_703;
    zT_6B0A7D14_AstStore* zT_705;
    unsigned int zT_706;
    unsigned int zT_708;
    zT_C69B2266_i64 zT_710;
    unsigned int zT_712;
    zT_338B7C76_TypeRegistry* zT_714;
    zT_2DF01B61_FieldEntry* zT_715;
    unsigned int zT_716;
    unsigned int zT_717;
    unsigned char zT_719;
    zT_2DF01B61_FieldEntry zT_720;
    unsigned int zT_721;
    zT_C69B2266_i64 zT_723;
    unsigned int zT_724;
    unsigned int zT_725;
    unsigned int zT_726;
    unsigned char zT_728;
    zT_BAEE192E_Opt_10 zT_731;
    zT_C69B2266_i64 zT_733;
    unsigned int zT_735;
    zT_338B7C76_TypeRegistry* zT_737;
    zT_2DF01B61_FieldEntry* zT_738;
    unsigned int zT_739;
    unsigned int zT_740;
    unsigned char zT_742;
    zT_2DF01B61_FieldEntry zT_743;
    unsigned int zT_744;
    zT_C69B2266_i64 zT_747;
    unsigned int zT_748;
    unsigned int zT_749;
    unsigned int zT_750;
    unsigned char zT_752;
    zT_BAEE192E_Opt_10 zT_754;
    zT_338B7C76_TypeRegistry* zT_756;
    zT_2DF01B61_FieldEntry* zT_757;
    unsigned int zT_758;
    unsigned int zT_759;
    unsigned int zT_760;
    unsigned char zT_762;
    zT_2DF01B61_FieldEntry zT_763;
    zT_4D150975_ConstInitEvalCtx* zT_764;
    unsigned int zT_765;
    unsigned int zT_766;
    unsigned int zT_767;
    unsigned int zT_768;
    zT_6B0A7D14_AstStore* zT_769;
    unsigned int zT_770;
    zT_22A7C88B_AstNode zT_772;
    unsigned int zT_775;
    unsigned int zT_776;
    unsigned int zT_777;
    unsigned char zT_779;
    zT_BAEE192E_Opt_10 zT_780;
    unsigned char zT_781;
    zT_4065182A_ConstInitTable* zT_784;
    unsigned char zT_785;
    unsigned int zT_790;
    unsigned int zT_794;
    zT_3E40CD83_Sand* zT_796;
    zT_4065182A_ConstInitTable* zT_799;
    int zT_802;
    unsigned int zT_803;
    zT_81AD2998_EU_952 zT_806;
    unsigned char zT_807;
    unsigned char* zT_808;
    unsigned int* zT_811;
    int zT_812;
    zT_4065182A_ConstInitTable* zT_813;
    unsigned int zT_814;
    unsigned int* zT_815;
    zT_BAEE192E_Opt_10 zT_819;
    zT_BAEE192E_Opt_10 zT_820;
    zT_8143F551_AstKind zT_825;
    zT_BAEE192E_Opt_10 zT_829;
    zT_338B7C76_TypeRegistry* zT_831;
    zT_54FF90FA_TaggedUnionPayload* zT_832;
    zT_338B7C76_TypeRegistry* zT_833;
    zT_D155D06D_Type* zT_834;
    unsigned int zT_835;
    zT_D155D06D_Type zT_836;
    unsigned int zT_837;
    unsigned int zT_838;
    zT_54FF90FA_TaggedUnionPayload zT_839;
    unsigned int zT_841;
    unsigned int zT_842;
    unsigned short zT_844;
    unsigned int zT_845;
    zT_6B0A7D14_AstStore* zT_847;
    unsigned int zT_848;
    unsigned int zT_850;
    zT_BAEE192E_Opt_10 zT_854;
    zT_6B0A7D14_AstStore* zT_856;
    unsigned int zT_857;
    unsigned int zT_861;
    zT_6B0A7D14_AstStore* zT_863;
    unsigned int zT_864;
    unsigned int zT_866;
    zT_C69B2266_i64 zT_868;
    unsigned int zT_870;
    zT_338B7C76_TypeRegistry* zT_872;
    zT_2DF01B61_FieldEntry* zT_873;
    unsigned int zT_874;
    unsigned int zT_875;
    unsigned char zT_877;
    zT_2DF01B61_FieldEntry zT_878;
    unsigned int zT_879;
    zT_C69B2266_i64 zT_881;
    unsigned int zT_882;
    unsigned int zT_883;
    unsigned int zT_884;
    unsigned char zT_886;
    zT_BAEE192E_Opt_10 zT_889;
    zT_338B7C76_TypeRegistry* zT_891;
    zT_2DF01B61_FieldEntry* zT_892;
    unsigned int zT_893;
    unsigned int zT_894;
    unsigned int zT_895;
    unsigned char zT_897;
    zT_2DF01B61_FieldEntry zT_898;
    unsigned int zT_899;
    zT_BAEE192E_Opt_10 zT_902;
    zT_79FAE712_u64 zT_904;
    zT_338B7C76_TypeRegistry* zT_906;
    zT_D155D06D_Type* zT_907;
    unsigned int zT_908;
    unsigned int zT_909;
    zT_D155D06D_Type zT_910;
    zT_33EF6BFB_TypeKind zT_911;
    zT_338B7C76_TypeRegistry* zT_916;
    zT_457ECFEE_EnumPayload* zT_917;
    unsigned int zT_918;
    unsigned int zT_919;
    zT_457ECFEE_EnumPayload zT_920;
    unsigned char zT_922;
    unsigned short zT_924;
    unsigned short zT_925;
    zT_338B7C76_TypeRegistry* zT_928;
    zT_D96DCDF2_EnumMember* zT_929;
    unsigned int zT_930;
    unsigned int zT_931;
    unsigned int zT_932;
    unsigned int zT_933;
    unsigned int zT_934;
    unsigned char zT_936;
    zT_D96DCDF2_EnumMember zT_937;
    unsigned int zT_938;
    zT_C69B2266_i64 zT_940;
    zT_C69B2266_i64 zT_941;
    zT_79FAE712_u64 zT_942;
    unsigned char zT_943;
    unsigned short zT_944;
    unsigned short zT_945;
    unsigned int zT_946;
    unsigned char zT_948;
    zT_BAEE192E_Opt_10 zT_950;
    zT_4065182A_ConstInitTable* zT_952;
    unsigned char zT_953;
    unsigned int zT_958;
    unsigned int zT_962;
    zT_3E40CD83_Sand* zT_964;
    zT_4065182A_ConstInitTable* zT_967;
    int zT_970;
    unsigned int zT_971;
    zT_81AD2998_EU_952 zT_974;
    unsigned char zT_975;
    unsigned char* zT_976;
    unsigned int* zT_979;
    zT_4065182A_ConstInitTable* zT_980;
    unsigned char zT_981;
    zT_79FAE712_u64 zT_982;
    unsigned int zT_986;
    unsigned int zT_989;
    int zT_990;
    zT_4065182A_ConstInitTable* zT_991;
    unsigned char zT_992;
    unsigned int zT_997;
    unsigned int zT_1001;
    int zT_1002;
    zT_4065182A_ConstInitTable* zT_1003;
    unsigned int zT_1004;
    unsigned int* zT_1005;
    zT_BAEE192E_Opt_10 zT_1009;
    zT_8143F551_AstKind zT_1014;
    zT_4065182A_ConstInitTable* zT_1018;
    unsigned char zT_1019;
    unsigned int zT_1024;
    unsigned int zT_1028;
    zT_BAEE192E_Opt_10 zT_1029;
    zT_338B7C76_TypeRegistry* zT_1031;
    zT_0B10E8E9_OptionalPayload* zT_1032;
    zT_338B7C76_TypeRegistry* zT_1033;
    zT_D155D06D_Type* zT_1034;
    unsigned int zT_1035;
    zT_D155D06D_Type zT_1036;
    unsigned int zT_1037;
    unsigned int zT_1038;
    zT_0B10E8E9_OptionalPayload zT_1039;
    zT_4D150975_ConstInitEvalCtx* zT_1040;
    unsigned int zT_1041;
    unsigned int zT_1042;
    unsigned int zT_1043;
    unsigned int zT_1044;
    unsigned int zT_1046;
    unsigned int zT_1047;
    unsigned int zT_1048;
    unsigned char zT_1050;
    zT_BAEE192E_Opt_10 zT_1051;
    unsigned char zT_1052;
    zT_4065182A_ConstInitTable* zT_1055;
    unsigned char zT_1056;
    unsigned int zT_1061;
    unsigned int zT_1065;
    zT_3E40CD83_Sand* zT_1067;
    zT_4065182A_ConstInitTable* zT_1070;
    int zT_1073;
    unsigned int zT_1074;
    zT_81AD2998_EU_952 zT_1077;
    unsigned char zT_1078;
    unsigned char* zT_1079;
    unsigned int* zT_1082;
    int zT_1083;
    zT_4065182A_ConstInitTable* zT_1084;
    unsigned char zT_1085;
    unsigned int zT_1090;
    unsigned int zT_1094;
    int zT_1095;
    zT_4065182A_ConstInitTable* zT_1096;
    unsigned int zT_1097;
    unsigned int* zT_1098;
    zT_BAEE192E_Opt_10 zT_1102;
    zT_BAEE192E_Opt_10 zT_1103;
    zT_338B7C76_TypeRegistry* zT_1109;
    zT_42C2D6BF_EUPayload* zT_1110;
    zT_338B7C76_TypeRegistry* zT_1111;
    zT_D155D06D_Type* zT_1112;
    unsigned int zT_1113;
    zT_D155D06D_Type zT_1114;
    unsigned int zT_1115;
    unsigned int zT_1116;
    zT_42C2D6BF_EUPayload zT_1117;
    unsigned int zT_1119;
    unsigned char zT_1123;
    zT_4D150975_ConstInitEvalCtx* zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1126;
    zT_8143F551_AstKind zT_1131;
    zT_BAEE192E_Opt_10 zT_1136;
    zT_21D3708C_U32ToU32Map* zT_1137;
    unsigned int zT_1138;
    zT_BAEE192E_Opt_10 zT_1140;
    unsigned char zT_1141;
    zT_4065182A_ConstInitTable* zT_1144;
    unsigned char zT_1145;
    unsigned int zT_1150;
    unsigned int zT_1154;
    zT_3E40CD83_Sand* zT_1156;
    zT_4065182A_ConstInitTable* zT_1159;
    int zT_1162;
    unsigned int zT_1163;
    zT_81AD2998_EU_952 zT_1166;
    unsigned char zT_1167;
    unsigned char* zT_1168;
    unsigned int* zT_1171;
    zT_4065182A_ConstInitTable* zT_1172;
    unsigned char zT_1173;
    unsigned int zT_1178;
    unsigned int zT_1182;
    int zT_1183;
    zT_4065182A_ConstInitTable* zT_1184;
    unsigned char zT_1185;
    unsigned int zT_1190;
    unsigned int zT_1194;
    int zT_1195;
    zT_4065182A_ConstInitTable* zT_1196;
    unsigned int zT_1197;
    unsigned int* zT_1198;
    zT_BAEE192E_Opt_10 zT_1202;
    zT_BAEE192E_Opt_10 zT_1203;
    zT_BAEE192E_Opt_10 zT_1204;
    zT_4D150975_ConstInitEvalCtx* zT_1205;
    unsigned int zT_1206;
    unsigned int zT_1207;
    unsigned int zT_1208;
    unsigned int zT_1209;
    unsigned int zT_1210;
    unsigned int zT_1211;
    unsigned int zT_1212;
    unsigned char zT_1214;
    zT_BAEE192E_Opt_10 zT_1215;
    unsigned char zT_1216;
    zT_4065182A_ConstInitTable* zT_1219;
    unsigned char zT_1220;
    unsigned int zT_1225;
    unsigned int zT_1229;
    zT_3E40CD83_Sand* zT_1231;
    zT_4065182A_ConstInitTable* zT_1234;
    int zT_1237;
    unsigned int zT_1238;
    zT_81AD2998_EU_952 zT_1241;
    unsigned char zT_1242;
    unsigned char* zT_1243;
    unsigned int* zT_1246;
    int zT_1247;
    zT_4065182A_ConstInitTable* zT_1248;
    unsigned char zT_1249;
    unsigned int zT_1254;
    unsigned int zT_1258;
    int zT_1259;
    zT_4065182A_ConstInitTable* zT_1260;
    unsigned int zT_1261;
    unsigned int* zT_1262;
    zT_BAEE192E_Opt_10 zT_1266;
    zT_BAEE192E_Opt_10 zT_1267;
    zT_BAEE192E_Opt_10 zT_1268;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_170, (unsigned int)sizeof zT_170);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    zig_poison_fill((void*)&zT_193, (unsigned int)sizeof zT_193);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zig_poison_fill((void*)&zT_209, (unsigned int)sizeof zT_209);
    zig_poison_fill((void*)&zT_227, (unsigned int)sizeof zT_227);
    zig_poison_fill((void*)&zT_230, (unsigned int)sizeof zT_230);
    zig_poison_fill((void*)&zT_242, (unsigned int)sizeof zT_242);
    zig_poison_fill((void*)&zT_261, (unsigned int)sizeof zT_261);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zig_poison_fill((void*)&zT_299, (unsigned int)sizeof zT_299);
    zig_poison_fill((void*)&zT_310, (unsigned int)sizeof zT_310);
    zig_poison_fill((void*)&zT_354, (unsigned int)sizeof zT_354);
    zig_poison_fill((void*)&zT_395, (unsigned int)sizeof zT_395);
    zig_poison_fill((void*)&zT_405, (unsigned int)sizeof zT_405);
    zig_poison_fill((void*)&zT_410, (unsigned int)sizeof zT_410);
    zig_poison_fill((void*)&zT_432, (unsigned int)sizeof zT_432);
    zig_poison_fill((void*)&zT_449, (unsigned int)sizeof zT_449);
    zig_poison_fill((void*)&zT_468, (unsigned int)sizeof zT_468);
    zig_poison_fill((void*)&zT_503, (unsigned int)sizeof zT_503);
    zig_poison_fill((void*)&zT_507, (unsigned int)sizeof zT_507);
    zig_poison_fill((void*)&zT_518, (unsigned int)sizeof zT_518);
    zig_poison_fill((void*)&zT_526, (unsigned int)sizeof zT_526);
    zig_poison_fill((void*)&zT_548, (unsigned int)sizeof zT_548);
    zig_poison_fill((void*)&zT_556, (unsigned int)sizeof zT_556);
    zig_poison_fill((void*)&zT_571, (unsigned int)sizeof zT_571);
    zig_poison_fill((void*)&zT_574, (unsigned int)sizeof zT_574);
    zig_poison_fill((void*)&zT_586, (unsigned int)sizeof zT_586);
    zig_poison_fill((void*)&zT_605, (unsigned int)sizeof zT_605);
    zig_poison_fill((void*)&zT_632, (unsigned int)sizeof zT_632);
    zig_poison_fill((void*)&zT_644, (unsigned int)sizeof zT_644);
    zig_poison_fill((void*)&zT_655, (unsigned int)sizeof zT_655);
    zig_poison_fill((void*)&zT_662, (unsigned int)sizeof zT_662);
    zig_poison_fill((void*)&zT_671, (unsigned int)sizeof zT_671);
    zig_poison_fill((void*)&zT_692, (unsigned int)sizeof zT_692);
    zig_poison_fill((void*)&zT_696, (unsigned int)sizeof zT_696);
    zig_poison_fill((void*)&zT_703, (unsigned int)sizeof zT_703);
    zig_poison_fill((void*)&zT_708, (unsigned int)sizeof zT_708);
    zig_poison_fill((void*)&zT_731, (unsigned int)sizeof zT_731);
    zig_poison_fill((void*)&zT_754, (unsigned int)sizeof zT_754);
    zig_poison_fill((void*)&zT_772, (unsigned int)sizeof zT_772);
    zig_poison_fill((void*)&zT_780, (unsigned int)sizeof zT_780);
    zig_poison_fill((void*)&zT_794, (unsigned int)sizeof zT_794);
    zig_poison_fill((void*)&zT_806, (unsigned int)sizeof zT_806);
    zig_poison_fill((void*)&zT_820, (unsigned int)sizeof zT_820);
    zig_poison_fill((void*)&zT_829, (unsigned int)sizeof zT_829);
    zig_poison_fill((void*)&zT_850, (unsigned int)sizeof zT_850);
    zig_poison_fill((void*)&zT_854, (unsigned int)sizeof zT_854);
    zig_poison_fill((void*)&zT_861, (unsigned int)sizeof zT_861);
    zig_poison_fill((void*)&zT_866, (unsigned int)sizeof zT_866);
    zig_poison_fill((void*)&zT_889, (unsigned int)sizeof zT_889);
    zig_poison_fill((void*)&zT_902, (unsigned int)sizeof zT_902);
    zig_poison_fill((void*)&zT_950, (unsigned int)sizeof zT_950);
    zig_poison_fill((void*)&zT_962, (unsigned int)sizeof zT_962);
    zig_poison_fill((void*)&zT_974, (unsigned int)sizeof zT_974);
    zig_poison_fill((void*)&zT_989, (unsigned int)sizeof zT_989);
    zig_poison_fill((void*)&zT_1001, (unsigned int)sizeof zT_1001);
    zig_poison_fill((void*)&zT_1028, (unsigned int)sizeof zT_1028);
    zig_poison_fill((void*)&zT_1051, (unsigned int)sizeof zT_1051);
    zig_poison_fill((void*)&zT_1065, (unsigned int)sizeof zT_1065);
    zig_poison_fill((void*)&zT_1077, (unsigned int)sizeof zT_1077);
    zig_poison_fill((void*)&zT_1094, (unsigned int)sizeof zT_1094);
    zig_poison_fill((void*)&zT_1103, (unsigned int)sizeof zT_1103);
    zig_poison_fill((void*)&zT_1126, (unsigned int)sizeof zT_1126);
    zig_poison_fill((void*)&zT_1136, (unsigned int)sizeof zT_1136);
    zig_poison_fill((void*)&zT_1140, (unsigned int)sizeof zT_1140);
    zig_poison_fill((void*)&zT_1154, (unsigned int)sizeof zT_1154);
    zig_poison_fill((void*)&zT_1166, (unsigned int)sizeof zT_1166);
    zig_poison_fill((void*)&zT_1182, (unsigned int)sizeof zT_1182);
    zig_poison_fill((void*)&zT_1194, (unsigned int)sizeof zT_1194);
    zig_poison_fill((void*)&zT_1203, (unsigned int)sizeof zT_1203);
    zig_poison_fill((void*)&zT_1204, (unsigned int)sizeof zT_1204);
    zig_poison_fill((void*)&zT_1215, (unsigned int)sizeof zT_1215);
    zig_poison_fill((void*)&zT_1229, (unsigned int)sizeof zT_1229);
    zig_poison_fill((void*)&zT_1241, (unsigned int)sizeof zT_1241);
    zig_poison_fill((void*)&zT_1258, (unsigned int)sizeof zT_1258);
    zig_poison_fill((void*)&zT_1267, (unsigned int)sizeof zT_1267);
    zig_poison_fill((void*)&zT_1268, (unsigned int)sizeof zT_1268);
    zT_22A7C88B_AstNode node;
    unsigned int tk;
    unsigned int cv_name;
    zT_3A105EF1_Symbol* cvs;
    unsigned int cv_mid;
    unsigned int cv_fn;
    zT_3A105EF1_Symbol* cvs2;
    zT_E834303C_ArrayPayload ap;
    unsigned int want;
    unsigned int n;
    unsigned int agg;
    unsigned char* scratch_raw;
    unsigned int* scratch;
    unsigned int i;
    unsigned char ok;
    unsigned int cei;
    unsigned int ch;
    zT_666DC2E1_TuplePayload tp;
    unsigned int tcount;
    unsigned int n2;
    unsigned int agg2;
    unsigned char* scratch_raw2;
    unsigned int* scratch2;
    unsigned int j;
    unsigned char ok2;
    unsigned int et;
    unsigned int cj;
    unsigned int ch2;
    zT_406493CE_StructPayload sp;
    unsigned int fs;
    unsigned int fc;
    unsigned char* vis_raw;
    unsigned int* vis;
    unsigned int vc;
    unsigned int fi;
    unsigned int n3;
    unsigned int ei3;
    unsigned int fi3;
    unsigned int fn3;
    unsigned char found3;
    unsigned int fj3;
    unsigned int agg3;
    unsigned char* scratch_raw3;
    unsigned int* scratch3;
    unsigned int vi;
    unsigned char ok3;
    zT_2DF01B61_FieldEntry fe3;
    unsigned int val_node;
    unsigned char have;
    unsigned int fj4;
    unsigned int fi4;
    unsigned int ch3;
    unsigned int n4;
    unsigned int agg4;
    unsigned char* scratch_raw4;
    unsigned int* scratch4;
    unsigned int vi4;
    unsigned char ok4;
    zT_2DF01B61_FieldEntry fe4;
    unsigned int cj4;
    unsigned int ch4;
    zT_AF9231A2_UnionPayload up;
    unsigned int ufs;
    unsigned int ufc;
    unsigned int n5;
    unsigned int fi5;
    unsigned int fn5;
    zT_C69B2266_i64 ai5;
    unsigned int uj;
    zT_C69B2266_i64 first_vis;
    unsigned int uj2;
    zT_2DF01B61_FieldEntry afe;
    unsigned int ch5;
    unsigned int agg5;
    unsigned char* scratch_raw5;
    unsigned int* scratch5;
    zT_54FF90FA_TaggedUnionPayload tpu;
    unsigned int tfs;
    unsigned int tfc;
    unsigned int n6;
    unsigned int fi6;
    unsigned int fn6;
    zT_C69B2266_i64 ai6;
    unsigned int tj;
    zT_2DF01B61_FieldEntry tfe;
    zT_79FAE712_u64 tag_val;
    zT_D155D06D_Type ttag;
    zT_457ECFEE_EnumPayload ep;
    unsigned char found_t;
    unsigned short em;
    unsigned int agg6;
    unsigned char* scratch_raw6;
    zT_D96DCDF2_EnumMember mem;
    unsigned int* scratch6;
    zT_0B10E8E9_OptionalPayload op;
    unsigned int pay;
    unsigned int agg7;
    unsigned char* scratch_raw7;
    unsigned int* scratch7;
    zT_42C2D6BF_EUPayload ep2;
    unsigned int pay_ty;
    unsigned char is_void_pay;
    unsigned int ev2;
    unsigned int agg8;
    unsigned char* scratch_raw8;
    unsigned int* scratch8;
    unsigned int pay2;
    unsigned int agg9;
    unsigned char* scratch_raw9;
    unsigned int* scratch9;
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = ec->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = ec;
    zT_15 = type_id;
    zT_16 = zF_4E56FBAE_typeKindOf(zT_14, zT_15);
    tk = zT_16;
    zT_17 = node.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = ec->store;
    zT_23 = node_idx;
    zT_25 = zF_53458827_astStoreIdentifier(zT_22, zT_23);
    cv_name = zT_25;
    zT_26 = ec->symbol_reg;
    zT_27 = module_id;
    zT_28 = cv_name;
    zT_30 = zF_A398987E_symbolRegistryQuali(zT_26, zT_27, zT_28);
    zT_31 = zT_30.has_value;
    if (zT_31) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_5:
    if (!(zT_30.has_value)) { pal_trap(); }
    cvs = zT_30.value;
    zT_33 = cvs;
    zT_34 = zF_145B7326_symbolIsConstGlobal(zT_33);
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_42.has_value = 0;
    return zT_42;
    z_bb_7:
    zT_35 = ec;
    zT_36 = cvs->module_id;
    zT_37 = cvs->decl_node;
    zT_38 = depth;
    zT_41 = zF_07765C6B_valueCopyDecl(zT_35, zT_36, zT_37, zT_38);
    return zT_41;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_48 = ec;
    zT_49 = module_id;
    zT_50 = node.child_0;
    zT_52 = zF_644AB5CE_resolveModuleBaseNo(zT_48, zT_49, zT_50);
    cv_mid = zT_52;
    if ((unsigned char)(cv_mid != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_17; else goto z_bb_18;
    z_bb_11:
    zT_56 = ec->store;
    zT_57 = node_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    cv_fn = zT_59;
    zT_60 = ec->symbol_reg;
    zT_61 = cv_mid;
    zT_62 = cv_fn;
    zT_64 = zF_A398987E_symbolRegistryQuali(zT_60, zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_76.has_value = 0;
    return zT_76;
    z_bb_13:
    if (!(zT_64.has_value)) { pal_trap(); }
    cvs2 = zT_64.value;
    zT_67 = cvs2;
    zT_68 = zF_145B7326_symbolIsConstGlobal(zT_67);
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_69 = ec;
    zT_70 = cvs2->module_id;
    zT_71 = cvs2->decl_node;
    zT_72 = depth;
    zT_75 = zF_07765C6B_valueCopyDecl(zT_69, zT_70, zT_71, zT_72);
    return zT_75;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_82 = ec->registry;
    zT_83 = zT_82->array_items;
    zT_84 = ec->registry;
    zT_85 = zT_84->types_items;
    zT_86 = (unsigned int)type_id;
    zT_87 = zT_85[zT_86];
    zT_88 = zT_87.payload_idx;
    zT_89 = (unsigned int)zT_88;
    zT_90 = zT_83[zT_89];
    ap = zT_90;
    zT_92 = ap.length;
    want = zT_92;
    zT_93 = node.kind;
    if ((unsigned char)(zT_93 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_20; else goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type)))) goto z_bb_41; else goto z_bb_42;
    z_bb_19:
    zT_98 = node.kind;
    zT_97 = zT_98 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_21;
    z_bb_20:
    zT_97 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_97) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_103 = ec->store;
    zT_104 = node_idx;
    zT_106 = zF_152E19CB_astStoreNodeExtraCh(zT_103, zT_104);
    n = zT_106;
    if ((unsigned char)((unsigned int)((unsigned int)n) > want)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_200.has_value = 0;
    return zT_200;
    z_bb_24:
    zT_109.has_value = 0;
    return zT_109;
    z_bb_25:
    zT_111 = ec->tbl;
    zT_117 = 8;
    zT_112 = zT_117;
    zT_121 = zF_094E0976_tableAddNode(zT_111, zT_112, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg = zT_121;
    zT_126 = ec->tbl;
    zT_123 = zT_126->alloc;
    zT_128 = 4;
    zT_129 = 1;
    zT_130 = zig_wrap_add_u(((zu64)(want)), ((zu64)(zT_129)), 32u);
    zT_131 = zig_overflow_flag_add_u(((zu64)(want)), ((zu64)(zT_129)), 32u);
    zT_133 = zT_131 == (unsigned int)(0);
    if (!(zT_133)) { pal_trap(); }
    zT_134 = (unsigned int)zT_130;
    zT_135 = zig_wrap_mul_u(((zu64)(zT_128)), ((zu64)(zT_134)), 32u);
    zT_136 = zig_overflow_flag_mul_u(((zu64)(zT_128)), ((zu64)(zT_134)), 32u);
    zT_138 = zT_136 == (unsigned int)(0);
    if (!(zT_138)) { pal_trap(); }
    zT_124 = zT_135;
    zT_140 = zF_1395EB68_sandAlloc(zT_123, zT_124, (unsigned int)(4));
    zT_141 = zT_140.is_error;
    if (zT_141) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    pal_trap();
    z_bb_27:
    zT_142 = zT_140.data.payload;
    goto z_bb_28;
    z_bb_28:
    scratch_raw = zT_142;
    zT_145 = (unsigned int*)scratch_raw;
    scratch = zT_145;
    zT_147 = 0;
    i = zT_147;
    zT_149 = 1;
    ok = zT_149;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(i < want)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    if ((unsigned char)(i < (unsigned int)((unsigned int)n))) goto z_bb_33; else goto z_bb_35;
    z_bb_31:
    if ((unsigned char)(!ok)) goto z_bb_39; else goto z_bb_40;
    z_bb_32:
    zT_187 = 1;
    zT_188 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_187)), 32u);
    zT_189 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_187)), 32u);
    zT_191 = zT_189 == (unsigned int)(0);
    if (!(zT_191)) { pal_trap(); }
    i = zT_188;
    goto z_bb_29;
    z_bb_33:
    zT_154 = ec->store;
    zT_155 = node_idx;
    zT_156 = i;
    zT_158 = zF_B10B1BC1_astStoreNodeExtraCh(zT_154, zT_155, zT_156);
    cei = zT_158;
    zT_159 = ec;
    zT_160 = module_id;
    zT_161 = cei;
    zT_162 = ap.elem;
    zT_165 = 1;
    zT_166 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_165)), 32u);
    zT_167 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_165)), 32u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    zT_163 = zT_166;
    zT_170 = zF_BF602E2F_classify(zT_159, zT_160, zT_161, zT_162, zT_163);
    zT_171 = zT_170.has_value;
    if (zT_171) goto z_bb_36; else goto z_bb_38;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_175 = ec->tbl;
    zT_181 = 0;
    zT_176 = zT_181;
    zT_185 = zF_094E0976_tableAddNode(zT_175, zT_176, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_186 = (unsigned int)i;
    scratch[zT_186] = zT_185;
    goto z_bb_34;
    z_bb_36:
    if (!(zT_170.has_value)) { pal_trap(); }
    ch = zT_170.value;
    zT_173 = (unsigned int)i;
    scratch[zT_173] = ch;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_174 = 0;
    ok = zT_174;
    goto z_bb_31;
    z_bb_39:
    zT_193.has_value = 0;
    return zT_193;
    z_bb_40:
    zT_194 = ec->tbl;
    zT_195 = agg;
    zT_196 = scratch;
    zT_197 = want;
    zF_D8E7F449_tableFinishAgg(zT_194, zT_195, zT_196, zT_197);
    zT_199.has_value = 1;
    zT_199.value = agg;
    return zT_199;
    z_bb_41:
    zT_205 = node.kind;
    if ((unsigned char)(zT_205 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type)))) goto z_bb_59; else goto z_bb_60;
    z_bb_43:
    zT_209.has_value = 0;
    return zT_209;
    z_bb_44:
    zT_211 = ec->registry;
    zT_212 = zT_211->tup_items;
    zT_213 = ec->registry;
    zT_214 = zT_213->types_items;
    zT_215 = (unsigned int)type_id;
    zT_216 = zT_214[zT_215];
    zT_217 = zT_216.payload_idx;
    zT_218 = (unsigned int)zT_217;
    zT_219 = zT_212[zT_218];
    tp = zT_219;
    zT_221 = tp.elems_count;
    zT_222 = (unsigned int)zT_221;
    tcount = zT_222;
    zT_224 = ec->store;
    zT_225 = node_idx;
    zT_227 = zF_152E19CB_astStoreNodeExtraCh(zT_224, zT_225);
    n2 = zT_227;
    if ((unsigned char)((unsigned int)((unsigned int)n2) != tcount)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_230.has_value = 0;
    return zT_230;
    z_bb_46:
    zT_232 = ec->tbl;
    zT_238 = 8;
    zT_233 = zT_238;
    zT_242 = zF_094E0976_tableAddNode(zT_232, zT_233, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg2 = zT_242;
    zT_247 = ec->tbl;
    zT_244 = zT_247->alloc;
    zT_249 = 4;
    zT_250 = 1;
    zT_251 = zig_wrap_add_u(((zu64)(tcount)), ((zu64)(zT_250)), 32u);
    zT_252 = zig_overflow_flag_add_u(((zu64)(tcount)), ((zu64)(zT_250)), 32u);
    zT_254 = zT_252 == (unsigned int)(0);
    if (!(zT_254)) { pal_trap(); }
    zT_255 = (unsigned int)zT_251;
    zT_256 = zig_wrap_mul_u(((zu64)(zT_249)), ((zu64)(zT_255)), 32u);
    zT_257 = zig_overflow_flag_mul_u(((zu64)(zT_249)), ((zu64)(zT_255)), 32u);
    zT_259 = zT_257 == (unsigned int)(0);
    if (!(zT_259)) { pal_trap(); }
    zT_245 = zT_256;
    zT_261 = zF_1395EB68_sandAlloc(zT_244, zT_245, (unsigned int)(4));
    zT_262 = zT_261.is_error;
    if (zT_262) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    pal_trap();
    z_bb_48:
    zT_263 = zT_261.data.payload;
    goto z_bb_49;
    z_bb_49:
    scratch_raw2 = zT_263;
    zT_266 = (unsigned int*)scratch_raw2;
    scratch2 = zT_266;
    zT_268 = 0;
    j = zT_268;
    zT_270 = 1;
    ok2 = zT_270;
    goto z_bb_50;
    z_bb_50:
    if ((unsigned char)(j < tcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_273 = ec->registry;
    zT_274 = zT_273->xt_items;
    zT_275 = tp.elems_start;
    zT_276 = (unsigned int)zT_275;
    zT_277 = (unsigned int)j;
    zT_278 = zig_wrap_add_u(((zu64)(zT_276)), ((zu64)(zT_277)), 32u);
    zT_279 = zig_overflow_flag_add_u(((zu64)(zT_276)), ((zu64)(zT_277)), 32u);
    zT_281 = zT_279 == (unsigned int)(0);
    if (!(zT_281)) { pal_trap(); }
    zT_282 = zT_274[zT_278];
    et = zT_282;
    zT_284 = ec->store;
    zT_285 = node_idx;
    zT_286 = j;
    zT_288 = zF_B10B1BC1_astStoreNodeExtraCh(zT_284, zT_285, zT_286);
    cj = zT_288;
    zT_289 = ec;
    zT_290 = module_id;
    zT_291 = cj;
    zT_292 = et;
    zT_294 = 1;
    zT_295 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_294)), 32u);
    zT_296 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_294)), 32u);
    zT_298 = zT_296 == (unsigned int)(0);
    if (!(zT_298)) { pal_trap(); }
    zT_293 = zT_295;
    zT_299 = zF_BF602E2F_classify(zT_289, zT_290, zT_291, zT_292, zT_293);
    zT_300 = zT_299.has_value;
    if (zT_300) goto z_bb_54; else goto z_bb_56;
    z_bb_52:
    if ((unsigned char)(!ok2)) goto z_bb_57; else goto z_bb_58;
    z_bb_53:
    zT_304 = 1;
    zT_305 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_304)), 32u);
    zT_306 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_304)), 32u);
    zT_308 = zT_306 == (unsigned int)(0);
    if (!(zT_308)) { pal_trap(); }
    j = zT_305;
    goto z_bb_50;
    z_bb_54:
    if (!(zT_299.has_value)) { pal_trap(); }
    ch2 = zT_299.value;
    zT_302 = (unsigned int)j;
    scratch2[zT_302] = ch2;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_303 = 0;
    ok2 = zT_303;
    goto z_bb_52;
    z_bb_57:
    zT_310.has_value = 0;
    return zT_310;
    z_bb_58:
    zT_311 = ec->tbl;
    zT_312 = agg2;
    zT_313 = scratch2;
    zT_314 = tcount;
    zF_D8E7F449_tableFinishAgg(zT_311, zT_312, zT_313, zT_314);
    zT_316.has_value = 1;
    zT_316.value = agg2;
    return zT_316;
    z_bb_59:
    zT_322 = ec->registry;
    zT_323 = zT_322->st_items;
    zT_324 = ec->registry;
    zT_325 = zT_324->types_items;
    zT_326 = (unsigned int)type_id;
    zT_327 = zT_325[zT_326];
    zT_328 = zT_327.payload_idx;
    zT_329 = (unsigned int)zT_328;
    zT_330 = zT_323[zT_329];
    sp = zT_330;
    zT_332 = sp.fields_start;
    zT_333 = (unsigned int)zT_332;
    fs = zT_333;
    zT_335 = sp.fields_count;
    zT_336 = (unsigned int)zT_335;
    fc = zT_336;
    zT_341 = ec->tbl;
    zT_338 = zT_341->alloc;
    zT_343 = 4;
    zT_344 = 1;
    zT_345 = zig_wrap_add_u(((zu64)(fc)), ((zu64)(zT_344)), 32u);
    zT_346 = zig_overflow_flag_add_u(((zu64)(fc)), ((zu64)(zT_344)), 32u);
    zT_348 = zT_346 == (unsigned int)(0);
    if (!(zT_348)) { pal_trap(); }
    zT_349 = zig_wrap_mul_u(((zu64)(zT_343)), ((zu64)(zT_345)), 32u);
    zT_350 = zig_overflow_flag_mul_u(((zu64)(zT_343)), ((zu64)(zT_345)), 32u);
    zT_352 = zT_350 == (unsigned int)(0);
    if (!(zT_352)) { pal_trap(); }
    zT_339 = zT_349;
    zT_354 = zF_1395EB68_sandAlloc(zT_338, zT_339, (unsigned int)(4));
    zT_355 = zT_354.is_error;
    if (zT_355) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type)))) goto z_bb_122; else goto z_bb_123;
    z_bb_61:
    pal_trap();
    z_bb_62:
    zT_356 = zT_354.data.payload;
    goto z_bb_63;
    z_bb_63:
    vis_raw = zT_356;
    zT_359 = (unsigned int*)vis_raw;
    vis = zT_359;
    zT_361 = 0;
    vc = zT_361;
    zT_363 = 0;
    fi = zT_363;
    goto z_bb_64;
    z_bb_64:
    if ((unsigned char)(fi < fc)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_365 = ec->registry;
    zT_366 = zT_365->fe_items;
    zT_367 = zig_wrap_add_u(((zu64)(fs)), ((zu64)(fi)), 32u);
    zT_368 = zig_overflow_flag_add_u(((zu64)(fs)), ((zu64)(fi)), 32u);
    zT_370 = zT_368 == (unsigned int)(0);
    if (!(zT_370)) { pal_trap(); }
    zT_371 = zT_366[zT_367];
    zT_372 = zT_371.type_id;
    if ((unsigned char)(zT_372 != (unsigned int)(1))) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    zT_387 = node.kind;
    if ((unsigned char)(zT_387 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    zT_382 = 1;
    zT_383 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_382)), 32u);
    zT_384 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_382)), 32u);
    zT_386 = zT_384 == (unsigned int)(0);
    if (!(zT_386)) { pal_trap(); }
    fi = zT_383;
    goto z_bb_64;
    z_bb_68:
    zT_375 = (unsigned int)fi;
    zT_376 = (unsigned int)vc;
    vis[zT_376] = zT_375;
    zT_377 = 1;
    zT_378 = zig_wrap_add_u(((zu64)(vc)), ((zu64)(zT_377)), 32u);
    zT_379 = zig_overflow_flag_add_u(((zu64)(vc)), ((zu64)(zT_377)), 32u);
    zT_381 = zT_379 == (unsigned int)(0);
    if (!(zT_381)) { pal_trap(); }
    vc = zT_378;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_67;
    z_bb_70:
    zT_392 = ec->store;
    zT_393 = node_idx;
    zT_395 = zF_152E19CB_astStoreNodeExtraCh(zT_392, zT_393);
    n3 = zT_395;
    zT_397 = 0;
    ei3 = zT_397;
    goto z_bb_72;
    z_bb_71:
    zT_563 = node.kind;
    if ((unsigned char)(zT_563 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_106; else goto z_bb_107;
    z_bb_72:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)n3))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_401 = ec->store;
    zT_402 = node_idx;
    zT_403 = ei3;
    zT_405 = zF_B10B1BC1_astStoreNodeExtraCh(zT_401, zT_402, zT_403);
    fi3 = zT_405;
    zT_407 = ec->store;
    zT_408 = fi3;
    zT_410 = zF_8BA26B9E_astStoreNodePayload(zT_407, zT_408);
    fn3 = zT_410;
    zT_412 = 0;
    found3 = zT_412;
    zT_414 = 0;
    fj3 = zT_414;
    goto z_bb_76;
    z_bb_74:
    zT_439 = ec->tbl;
    zT_445 = 8;
    zT_440 = zT_445;
    zT_449 = zF_094E0976_tableAddNode(zT_439, zT_440, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg3 = zT_449;
    zT_454 = ec->tbl;
    zT_451 = zT_454->alloc;
    zT_456 = 4;
    zT_457 = 1;
    zT_458 = zig_wrap_add_u(((zu64)(vc)), ((zu64)(zT_457)), 32u);
    zT_459 = zig_overflow_flag_add_u(((zu64)(vc)), ((zu64)(zT_457)), 32u);
    zT_461 = zT_459 == (unsigned int)(0);
    if (!(zT_461)) { pal_trap(); }
    zT_462 = (unsigned int)zT_458;
    zT_463 = zig_wrap_mul_u(((zu64)(zT_456)), ((zu64)(zT_462)), 32u);
    zT_464 = zig_overflow_flag_mul_u(((zu64)(zT_456)), ((zu64)(zT_462)), 32u);
    zT_466 = zT_464 == (unsigned int)(0);
    if (!(zT_466)) { pal_trap(); }
    zT_452 = zT_463;
    zT_468 = zF_1395EB68_sandAlloc(zT_451, zT_452, (unsigned int)(4));
    zT_469 = zT_468.is_error;
    if (zT_469) goto z_bb_84; else goto z_bb_85;
    z_bb_75:
    zT_433 = 1;
    zT_434 = zig_wrap_add_u(((zu64)(ei3)), ((zu64)(zT_433)), 32u);
    zT_435 = zig_overflow_flag_add_u(((zu64)(ei3)), ((zu64)(zT_433)), 32u);
    zT_437 = zT_435 == (unsigned int)(0);
    if (!(zT_437)) { pal_trap(); }
    ei3 = zT_434;
    goto z_bb_72;
    z_bb_76:
    if ((unsigned char)(fj3 < fc)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_416 = ec->registry;
    zT_417 = zT_416->fe_items;
    zT_418 = zig_wrap_add_u(((zu64)(fs)), ((zu64)(fj3)), 32u);
    zT_419 = zig_overflow_flag_add_u(((zu64)(fs)), ((zu64)(fj3)), 32u);
    zT_421 = zT_419 == (unsigned int)(0);
    if (!(zT_421)) { pal_trap(); }
    zT_422 = zT_417[zT_418];
    zT_423 = zT_422.name_id;
    if ((unsigned char)(zT_423 == fn3)) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    if ((unsigned char)(!found3)) goto z_bb_82; else goto z_bb_83;
    z_bb_79:
    zT_426 = 1;
    zT_427 = zig_wrap_add_u(((zu64)(fj3)), ((zu64)(zT_426)), 32u);
    zT_428 = zig_overflow_flag_add_u(((zu64)(fj3)), ((zu64)(zT_426)), 32u);
    zT_430 = zT_428 == (unsigned int)(0);
    if (!(zT_430)) { pal_trap(); }
    fj3 = zT_427;
    goto z_bb_76;
    z_bb_80:
    zT_425 = 1;
    found3 = zT_425;
    goto z_bb_78;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_432.has_value = 0;
    return zT_432;
    z_bb_83:
    goto z_bb_75;
    z_bb_84:
    pal_trap();
    z_bb_85:
    zT_470 = zT_468.data.payload;
    goto z_bb_86;
    z_bb_86:
    scratch_raw3 = zT_470;
    zT_473 = (unsigned int*)scratch_raw3;
    scratch3 = zT_473;
    zT_475 = 0;
    vi = zT_475;
    zT_477 = 1;
    ok3 = zT_477;
    goto z_bb_87;
    z_bb_87:
    if ((unsigned char)(vi < vc)) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_480 = ec->registry;
    zT_481 = zT_480->fe_items;
    zT_482 = (unsigned int)vi;
    zT_483 = vis[zT_482];
    zT_484 = (unsigned int)zT_483;
    zT_485 = zig_wrap_add_u(((zu64)(fs)), ((zu64)(zT_484)), 32u);
    zT_486 = zig_overflow_flag_add_u(((zu64)(fs)), ((zu64)(zT_484)), 32u);
    zT_488 = zT_486 == (unsigned int)(0);
    if (!(zT_488)) { pal_trap(); }
    zT_489 = zT_481[zT_485];
    fe3 = zT_489;
    zT_491 = 0;
    val_node = zT_491;
    zT_493 = 0;
    have = zT_493;
    zT_495 = 0;
    fj4 = zT_495;
    goto z_bb_91;
    z_bb_89:
    if ((unsigned char)(!ok3)) goto z_bb_104; else goto z_bb_105;
    z_bb_90:
    zT_550 = 1;
    zT_551 = zig_wrap_add_u(((zu64)(vi)), ((zu64)(zT_550)), 32u);
    zT_552 = zig_overflow_flag_add_u(((zu64)(vi)), ((zu64)(zT_550)), 32u);
    zT_554 = zT_552 == (unsigned int)(0);
    if (!(zT_554)) { pal_trap(); }
    vi = zT_551;
    goto z_bb_87;
    z_bb_91:
    if ((unsigned char)(fj4 < (unsigned int)((unsigned int)n3))) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_499 = ec->store;
    zT_500 = node_idx;
    zT_501 = fj4;
    zT_503 = zF_B10B1BC1_astStoreNodeExtraCh(zT_499, zT_500, zT_501);
    fi4 = zT_503;
    zT_504 = ec->store;
    zT_505 = fi4;
    zT_507 = zF_8BA26B9E_astStoreNodePayload(zT_504, zT_505);
    zT_508 = fe3.name_id;
    if ((unsigned char)(zT_507 == zT_508)) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    if ((unsigned char)(!ok3)) goto z_bb_100; else goto z_bb_101;
    z_bb_94:
    zT_531 = 1;
    zT_532 = zig_wrap_add_u(((zu64)(fj4)), ((zu64)(zT_531)), 32u);
    zT_533 = zig_overflow_flag_add_u(((zu64)(fj4)), ((zu64)(zT_531)), 32u);
    zT_535 = zT_533 == (unsigned int)(0);
    if (!(zT_535)) { pal_trap(); }
    fj4 = zT_532;
    goto z_bb_91;
    z_bb_95:
    zT_510 = ec;
    zT_511 = module_id;
    zT_515 = ec->store;
    zT_516 = fi4;
    zT_518 = zF_FCDD1D35_astStoreNodeAt(zT_515, zT_516);
    zT_512 = zT_518.child_0;
    zT_513 = fe3.type_id;
    zT_521 = 1;
    zT_522 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_521)), 32u);
    zT_523 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_521)), 32u);
    zT_525 = zT_523 == (unsigned int)(0);
    if (!(zT_525)) { pal_trap(); }
    zT_514 = zT_522;
    zT_526 = zF_BF602E2F_classify(zT_510, zT_511, zT_512, zT_513, zT_514);
    zT_527 = zT_526.has_value;
    if (zT_527) goto z_bb_97; else goto z_bb_99;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    if (!(zT_526.has_value)) { pal_trap(); }
    ch3 = zT_526.value;
    val_node = ch3;
    zT_529 = 1;
    have = zT_529;
    goto z_bb_98;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_530 = 0;
    ok3 = zT_530;
    goto z_bb_98;
    z_bb_100:
    goto z_bb_89;
    z_bb_101:
    if ((unsigned char)(!have)) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_538 = ec->tbl;
    zT_544 = 0;
    zT_539 = zT_544;
    zT_548 = zF_094E0976_tableAddNode(zT_538, zT_539, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    val_node = zT_548;
    goto z_bb_103;
    z_bb_103:
    zT_549 = (unsigned int)vi;
    scratch3[zT_549] = val_node;
    goto z_bb_90;
    z_bb_104:
    zT_556.has_value = 0;
    return zT_556;
    z_bb_105:
    zT_557 = ec->tbl;
    zT_558 = agg3;
    zT_559 = scratch3;
    zT_560 = vc;
    zF_D8E7F449_tableFinishAgg(zT_557, zT_558, zT_559, zT_560);
    zT_562.has_value = 1;
    zT_562.value = agg3;
    return zT_562;
    z_bb_106:
    zT_568 = ec->store;
    zT_569 = node_idx;
    zT_571 = zF_152E19CB_astStoreNodeExtraCh(zT_568, zT_569);
    n4 = zT_571;
    if ((unsigned char)((unsigned int)((unsigned int)n4) != vc)) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    zT_662.has_value = 0;
    return zT_662;
    z_bb_108:
    zT_574.has_value = 0;
    return zT_574;
    z_bb_109:
    zT_576 = ec->tbl;
    zT_582 = 8;
    zT_577 = zT_582;
    zT_586 = zF_094E0976_tableAddNode(zT_576, zT_577, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg4 = zT_586;
    zT_591 = ec->tbl;
    zT_588 = zT_591->alloc;
    zT_593 = 4;
    zT_594 = 1;
    zT_595 = zig_wrap_add_u(((zu64)(vc)), ((zu64)(zT_594)), 32u);
    zT_596 = zig_overflow_flag_add_u(((zu64)(vc)), ((zu64)(zT_594)), 32u);
    zT_598 = zT_596 == (unsigned int)(0);
    if (!(zT_598)) { pal_trap(); }
    zT_599 = (unsigned int)zT_595;
    zT_600 = zig_wrap_mul_u(((zu64)(zT_593)), ((zu64)(zT_599)), 32u);
    zT_601 = zig_overflow_flag_mul_u(((zu64)(zT_593)), ((zu64)(zT_599)), 32u);
    zT_603 = zT_601 == (unsigned int)(0);
    if (!(zT_603)) { pal_trap(); }
    zT_589 = zT_600;
    zT_605 = zF_1395EB68_sandAlloc(zT_588, zT_589, (unsigned int)(4));
    zT_606 = zT_605.is_error;
    if (zT_606) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    pal_trap();
    z_bb_111:
    zT_607 = zT_605.data.payload;
    goto z_bb_112;
    z_bb_112:
    scratch_raw4 = zT_607;
    zT_610 = (unsigned int*)scratch_raw4;
    scratch4 = zT_610;
    zT_612 = 0;
    vi4 = zT_612;
    zT_614 = 1;
    ok4 = zT_614;
    goto z_bb_113;
    z_bb_113:
    if ((unsigned char)(vi4 < vc)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_617 = ec->registry;
    zT_618 = zT_617->fe_items;
    zT_619 = (unsigned int)vi4;
    zT_620 = vis[zT_619];
    zT_621 = (unsigned int)zT_620;
    zT_622 = zig_wrap_add_u(((zu64)(fs)), ((zu64)(zT_621)), 32u);
    zT_623 = zig_overflow_flag_add_u(((zu64)(fs)), ((zu64)(zT_621)), 32u);
    zT_625 = zT_623 == (unsigned int)(0);
    if (!(zT_625)) { pal_trap(); }
    zT_626 = zT_618[zT_622];
    fe4 = zT_626;
    zT_628 = ec->store;
    zT_629 = node_idx;
    zT_630 = vi4;
    zT_632 = zF_B10B1BC1_astStoreNodeExtraCh(zT_628, zT_629, zT_630);
    cj4 = zT_632;
    zT_633 = ec;
    zT_634 = module_id;
    zT_635 = cj4;
    zT_636 = fe4.type_id;
    zT_639 = 1;
    zT_640 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_639)), 32u);
    zT_641 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_639)), 32u);
    zT_643 = zT_641 == (unsigned int)(0);
    if (!(zT_643)) { pal_trap(); }
    zT_637 = zT_640;
    zT_644 = zF_BF602E2F_classify(zT_633, zT_634, zT_635, zT_636, zT_637);
    zT_645 = zT_644.has_value;
    if (zT_645) goto z_bb_117; else goto z_bb_119;
    z_bb_115:
    if ((unsigned char)(!ok4)) goto z_bb_120; else goto z_bb_121;
    z_bb_116:
    zT_649 = 1;
    zT_650 = zig_wrap_add_u(((zu64)(vi4)), ((zu64)(zT_649)), 32u);
    zT_651 = zig_overflow_flag_add_u(((zu64)(vi4)), ((zu64)(zT_649)), 32u);
    zT_653 = zT_651 == (unsigned int)(0);
    if (!(zT_653)) { pal_trap(); }
    vi4 = zT_650;
    goto z_bb_113;
    z_bb_117:
    if (!(zT_644.has_value)) { pal_trap(); }
    ch4 = zT_644.value;
    zT_647 = (unsigned int)vi4;
    scratch4[zT_647] = ch4;
    goto z_bb_118;
    z_bb_118:
    goto z_bb_116;
    z_bb_119:
    zT_648 = 0;
    ok4 = zT_648;
    goto z_bb_115;
    z_bb_120:
    zT_655.has_value = 0;
    return zT_655;
    z_bb_121:
    zT_656 = ec->tbl;
    zT_657 = agg4;
    zT_658 = scratch4;
    zT_659 = vc;
    zF_D8E7F449_tableFinishAgg(zT_656, zT_657, zT_658, zT_659);
    zT_661.has_value = 1;
    zT_661.value = agg4;
    return zT_661;
    z_bb_122:
    zT_667 = node.kind;
    if ((unsigned char)(zT_667 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type)))) goto z_bb_149; else goto z_bb_150;
    z_bb_124:
    zT_671.has_value = 0;
    return zT_671;
    z_bb_125:
    zT_673 = ec->registry;
    zT_674 = zT_673->un_items;
    zT_675 = ec->registry;
    zT_676 = zT_675->types_items;
    zT_677 = (unsigned int)type_id;
    zT_678 = zT_676[zT_677];
    zT_679 = zT_678.payload_idx;
    zT_680 = (unsigned int)zT_679;
    zT_681 = zT_674[zT_680];
    up = zT_681;
    zT_683 = up.fields_start;
    zT_684 = (unsigned int)zT_683;
    ufs = zT_684;
    zT_686 = up.fields_count;
    zT_687 = (unsigned int)zT_686;
    ufc = zT_687;
    zT_689 = ec->store;
    zT_690 = node_idx;
    zT_692 = zF_152E19CB_astStoreNodeExtraCh(zT_689, zT_690);
    n5 = zT_692;
    if ((unsigned char)((unsigned int)((unsigned int)n5) != (unsigned int)(1))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_696.has_value = 0;
    return zT_696;
    z_bb_127:
    zT_698 = ec->store;
    zT_699 = node_idx;
    zT_703 = zF_B10B1BC1_astStoreNodeExtraCh(zT_698, zT_699, (unsigned int)(0));
    fi5 = zT_703;
    zT_705 = ec->store;
    zT_706 = fi5;
    zT_708 = zF_8BA26B9E_astStoreNodePayload(zT_705, zT_706);
    fn5 = zT_708;
    zT_710 = (zT_C69B2266_i64)-1;
    ai5 = zT_710;
    zT_712 = 0;
    uj = zT_712;
    goto z_bb_128;
    z_bb_128:
    if ((unsigned char)(uj < ufc)) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_714 = ec->registry;
    zT_715 = zT_714->fe_items;
    zT_716 = zig_wrap_add_u(((zu64)(ufs)), ((zu64)(uj)), 32u);
    zT_717 = zig_overflow_flag_add_u(((zu64)(ufs)), ((zu64)(uj)), 32u);
    zT_719 = zT_717 == (unsigned int)(0);
    if (!(zT_719)) { pal_trap(); }
    zT_720 = zT_715[zT_716];
    zT_721 = zT_720.name_id;
    if ((unsigned char)(zT_721 == fn5)) goto z_bb_132; else goto z_bb_133;
    z_bb_130:
    if ((unsigned char)(ai5 < (zT_C69B2266_i64)(0))) goto z_bb_134; else goto z_bb_135;
    z_bb_131:
    zT_724 = 1;
    zT_725 = zig_wrap_add_u(((zu64)(uj)), ((zu64)(zT_724)), 32u);
    zT_726 = zig_overflow_flag_add_u(((zu64)(uj)), ((zu64)(zT_724)), 32u);
    zT_728 = zT_726 == (unsigned int)(0);
    if (!(zT_728)) { pal_trap(); }
    uj = zT_725;
    goto z_bb_128;
    z_bb_132:
    zT_723 = (zT_C69B2266_i64)uj;
    ai5 = zT_723;
    goto z_bb_130;
    z_bb_133:
    goto z_bb_131;
    z_bb_134:
    zT_731.has_value = 0;
    return zT_731;
    z_bb_135:
    zT_733 = (zT_C69B2266_i64)-1;
    first_vis = zT_733;
    zT_735 = 0;
    uj2 = zT_735;
    goto z_bb_136;
    z_bb_136:
    if ((unsigned char)(uj2 < ufc)) goto z_bb_137; else goto z_bb_138;
    z_bb_137:
    zT_737 = ec->registry;
    zT_738 = zT_737->fe_items;
    zT_739 = zig_wrap_add_u(((zu64)(ufs)), ((zu64)(uj2)), 32u);
    zT_740 = zig_overflow_flag_add_u(((zu64)(ufs)), ((zu64)(uj2)), 32u);
    zT_742 = zT_740 == (unsigned int)(0);
    if (!(zT_742)) { pal_trap(); }
    zT_743 = zT_738[zT_739];
    zT_744 = zT_743.type_id;
    if ((unsigned char)(zT_744 != (unsigned int)(1))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    if ((unsigned char)(ai5 != first_vis)) goto z_bb_142; else goto z_bb_143;
    z_bb_139:
    zT_748 = 1;
    zT_749 = zig_wrap_add_u(((zu64)(uj2)), ((zu64)(zT_748)), 32u);
    zT_750 = zig_overflow_flag_add_u(((zu64)(uj2)), ((zu64)(zT_748)), 32u);
    zT_752 = zT_750 == (unsigned int)(0);
    if (!(zT_752)) { pal_trap(); }
    uj2 = zT_749;
    goto z_bb_136;
    z_bb_140:
    zT_747 = (zT_C69B2266_i64)uj2;
    first_vis = zT_747;
    goto z_bb_138;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_754.has_value = 0;
    return zT_754;
    z_bb_143:
    zT_756 = ec->registry;
    zT_757 = zT_756->fe_items;
    zT_758 = (unsigned int)zig_cast_checked_u((zu64)ai5, 64u, 1u, 32u);
    zT_759 = zig_wrap_add_u(((zu64)(ufs)), ((zu64)(zT_758)), 32u);
    zT_760 = zig_overflow_flag_add_u(((zu64)(ufs)), ((zu64)(zT_758)), 32u);
    zT_762 = zT_760 == (unsigned int)(0);
    if (!(zT_762)) { pal_trap(); }
    zT_763 = zT_757[zT_759];
    afe = zT_763;
    zT_764 = ec;
    zT_765 = module_id;
    zT_769 = ec->store;
    zT_770 = fi5;
    zT_772 = zF_FCDD1D35_astStoreNodeAt(zT_769, zT_770);
    zT_766 = zT_772.child_0;
    zT_767 = afe.type_id;
    zT_775 = 1;
    zT_776 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_775)), 32u);
    zT_777 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_775)), 32u);
    zT_779 = zT_777 == (unsigned int)(0);
    if (!(zT_779)) { pal_trap(); }
    zT_768 = zT_776;
    zT_780 = zF_BF602E2F_classify(zT_764, zT_765, zT_766, zT_767, zT_768);
    zT_781 = zT_780.has_value;
    if (zT_781) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    if (!(zT_780.has_value)) { pal_trap(); }
    ch5 = zT_780.value;
    zT_784 = ec->tbl;
    zT_790 = 8;
    zT_785 = zT_790;
    zT_794 = zF_094E0976_tableAddNode(zT_784, zT_785, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg5 = zT_794;
    zT_799 = ec->tbl;
    zT_796 = zT_799->alloc;
    zT_802 = 2;
    zT_803 = (unsigned int)(4) * zT_802;
    zT_806 = zF_1395EB68_sandAlloc(zT_796, (unsigned int)((unsigned int)zT_803), (unsigned int)(4));
    zT_807 = zT_806.is_error;
    if (zT_807) goto z_bb_146; else goto z_bb_147;
    z_bb_145:
    zT_820.has_value = 0;
    return zT_820;
    z_bb_146:
    pal_trap();
    z_bb_147:
    zT_808 = zT_806.data.payload;
    goto z_bb_148;
    z_bb_148:
    scratch_raw5 = zT_808;
    zT_811 = (unsigned int*)scratch_raw5;
    scratch5 = zT_811;
    zT_812 = 0;
    scratch5[zT_812] = ch5;
    zT_813 = ec->tbl;
    zT_814 = agg5;
    zT_815 = scratch5;
    zF_D8E7F449_tableFinishAgg(zT_813, zT_814, zT_815, (unsigned int)(1));
    zT_819.has_value = 1;
    zT_819.value = agg5;
    return zT_819;
    z_bb_149:
    zT_825 = node.kind;
    if ((unsigned char)(zT_825 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_151; else goto z_bb_152;
    z_bb_150:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type)))) goto z_bb_178; else goto z_bb_179;
    z_bb_151:
    zT_829.has_value = 0;
    return zT_829;
    z_bb_152:
    zT_831 = ec->registry;
    zT_832 = zT_831->tu_items;
    zT_833 = ec->registry;
    zT_834 = zT_833->types_items;
    zT_835 = (unsigned int)type_id;
    zT_836 = zT_834[zT_835];
    zT_837 = zT_836.payload_idx;
    zT_838 = (unsigned int)zT_837;
    zT_839 = zT_832[zT_838];
    tpu = zT_839;
    zT_841 = tpu.fields_start;
    zT_842 = (unsigned int)zT_841;
    tfs = zT_842;
    zT_844 = tpu.fields_count;
    zT_845 = (unsigned int)zT_844;
    tfc = zT_845;
    zT_847 = ec->store;
    zT_848 = node_idx;
    zT_850 = zF_152E19CB_astStoreNodeExtraCh(zT_847, zT_848);
    n6 = zT_850;
    if ((unsigned char)((unsigned int)((unsigned int)n6) != (unsigned int)(1))) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_854.has_value = 0;
    return zT_854;
    z_bb_154:
    zT_856 = ec->store;
    zT_857 = node_idx;
    zT_861 = zF_B10B1BC1_astStoreNodeExtraCh(zT_856, zT_857, (unsigned int)(0));
    fi6 = zT_861;
    zT_863 = ec->store;
    zT_864 = fi6;
    zT_866 = zF_8BA26B9E_astStoreNodePayload(zT_863, zT_864);
    fn6 = zT_866;
    zT_868 = (zT_C69B2266_i64)-1;
    ai6 = zT_868;
    zT_870 = 0;
    tj = zT_870;
    goto z_bb_155;
    z_bb_155:
    if ((unsigned char)(tj < tfc)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_872 = ec->registry;
    zT_873 = zT_872->fe_items;
    zT_874 = zig_wrap_add_u(((zu64)(tfs)), ((zu64)(tj)), 32u);
    zT_875 = zig_overflow_flag_add_u(((zu64)(tfs)), ((zu64)(tj)), 32u);
    zT_877 = zT_875 == (unsigned int)(0);
    if (!(zT_877)) { pal_trap(); }
    zT_878 = zT_873[zT_874];
    zT_879 = zT_878.name_id;
    if ((unsigned char)(zT_879 == fn6)) goto z_bb_159; else goto z_bb_160;
    z_bb_157:
    if ((unsigned char)(ai6 < (zT_C69B2266_i64)(0))) goto z_bb_161; else goto z_bb_162;
    z_bb_158:
    zT_882 = 1;
    zT_883 = zig_wrap_add_u(((zu64)(tj)), ((zu64)(zT_882)), 32u);
    zT_884 = zig_overflow_flag_add_u(((zu64)(tj)), ((zu64)(zT_882)), 32u);
    zT_886 = zT_884 == (unsigned int)(0);
    if (!(zT_886)) { pal_trap(); }
    tj = zT_883;
    goto z_bb_155;
    z_bb_159:
    zT_881 = (zT_C69B2266_i64)tj;
    ai6 = zT_881;
    goto z_bb_157;
    z_bb_160:
    goto z_bb_158;
    z_bb_161:
    zT_889.has_value = 0;
    return zT_889;
    z_bb_162:
    zT_891 = ec->registry;
    zT_892 = zT_891->fe_items;
    zT_893 = (unsigned int)zig_cast_checked_u((zu64)ai6, 64u, 1u, 32u);
    zT_894 = zig_wrap_add_u(((zu64)(tfs)), ((zu64)(zT_893)), 32u);
    zT_895 = zig_overflow_flag_add_u(((zu64)(tfs)), ((zu64)(zT_893)), 32u);
    zT_897 = zT_895 == (unsigned int)(0);
    if (!(zT_897)) { pal_trap(); }
    zT_898 = zT_892[zT_894];
    tfe = zT_898;
    zT_899 = tfe.type_id;
    if ((unsigned char)(zT_899 != (unsigned int)(1))) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    zT_902.has_value = 0;
    return zT_902;
    z_bb_164:
    zT_904 = (zT_79FAE712_u64)zig_cast_checked_u((zu64)ai6, 64u, 1u, 64u);
    tag_val = zT_904;
    zT_906 = ec->registry;
    zT_907 = zT_906->types_items;
    zT_908 = tpu.tag_type;
    zT_909 = (unsigned int)zT_908;
    zT_910 = zT_907[zT_909];
    ttag = zT_910;
    zT_911 = ttag.kind;
    if ((unsigned char)(zT_911 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_916 = ec->registry;
    zT_917 = zT_916->en_items;
    zT_918 = ttag.payload_idx;
    zT_919 = (unsigned int)zT_918;
    zT_920 = zT_917[zT_919];
    ep = zT_920;
    zT_922 = 0;
    found_t = zT_922;
    zT_924 = 0;
    em = zT_924;
    goto z_bb_167;
    z_bb_166:
    zT_952 = ec->tbl;
    zT_958 = 8;
    zT_953 = zT_958;
    zT_962 = zF_094E0976_tableAddNode(zT_952, zT_953, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg6 = zT_962;
    zT_967 = ec->tbl;
    zT_964 = zT_967->alloc;
    zT_970 = 3;
    zT_971 = (unsigned int)(4) * zT_970;
    zT_974 = zF_1395EB68_sandAlloc(zT_964, (unsigned int)((unsigned int)zT_971), (unsigned int)(4));
    zT_975 = zT_974.is_error;
    if (zT_975) goto z_bb_175; else goto z_bb_176;
    z_bb_167:
    zT_925 = ep.members_count;
    if ((unsigned char)(em < zT_925)) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_928 = ec->registry;
    zT_929 = zT_928->em_items;
    zT_930 = ep.members_start;
    zT_931 = (unsigned int)zT_930;
    zT_932 = (unsigned int)em;
    zT_933 = zig_wrap_add_u(((zu64)(zT_931)), ((zu64)(zT_932)), 32u);
    zT_934 = zig_overflow_flag_add_u(((zu64)(zT_931)), ((zu64)(zT_932)), 32u);
    zT_936 = zT_934 == (unsigned int)(0);
    if (!(zT_936)) { pal_trap(); }
    zT_937 = zT_929[zT_933];
    mem = zT_937;
    zT_938 = mem.name_id;
    if ((unsigned char)(zT_938 == fn6)) goto z_bb_171; else goto z_bb_172;
    z_bb_169:
    if ((unsigned char)(!found_t)) goto z_bb_173; else goto z_bb_174;
    z_bb_170:
    zT_944 = 1;
    zT_945 = zig_wrap_add_u(((zu64)(em)), ((zu64)(zT_944)), 16u);
    zT_946 = zig_overflow_flag_add_u(((zu64)(em)), ((zu64)(zT_944)), 16u);
    zT_948 = zT_946 == (unsigned int)(0);
    if (!(zT_948)) { pal_trap(); }
    em = zT_945;
    goto z_bb_167;
    z_bb_171:
    zT_940 = mem.value;
    zT_941 = (zT_C69B2266_i64)zT_940;
    zT_942 = (zT_79FAE712_u64)zig_cast_checked_u((zu64)zT_941, 64u, 1u, 64u);
    tag_val = zT_942;
    zT_943 = 1;
    found_t = zT_943;
    goto z_bb_169;
    z_bb_172:
    goto z_bb_170;
    z_bb_173:
    zT_950.has_value = 0;
    return zT_950;
    z_bb_174:
    goto z_bb_166;
    z_bb_175:
    pal_trap();
    z_bb_176:
    zT_976 = zT_974.data.payload;
    goto z_bb_177;
    z_bb_177:
    scratch_raw6 = zT_976;
    zT_979 = (unsigned int*)scratch_raw6;
    scratch6 = zT_979;
    zT_980 = ec->tbl;
    zT_986 = 1;
    zT_981 = zT_986;
    zT_982 = tag_val;
    zT_989 = zF_094E0976_tableAddNode(zT_980, zT_981, zT_982, (unsigned int)(0), (unsigned int)(0));
    zT_990 = 0;
    scratch6[zT_990] = zT_989;
    zT_991 = ec->tbl;
    zT_997 = 0;
    zT_992 = zT_997;
    zT_1001 = zF_094E0976_tableAddNode(zT_991, zT_992, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_1002 = 1;
    scratch6[zT_1002] = zT_1001;
    zT_1003 = ec->tbl;
    zT_1004 = agg6;
    zT_1005 = scratch6;
    zF_D8E7F449_tableFinishAgg(zT_1003, zT_1004, zT_1005, (unsigned int)(2));
    zT_1009.has_value = 1;
    zT_1009.value = agg6;
    return zT_1009;
    z_bb_178:
    zT_1014 = node.kind;
    if ((unsigned char)(zT_1014 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_180; else goto z_bb_181;
    z_bb_179:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type)))) goto z_bb_187; else goto z_bb_188;
    z_bb_180:
    zT_1018 = ec->tbl;
    zT_1024 = 0;
    zT_1019 = zT_1024;
    zT_1028 = zF_094E0976_tableAddNode(zT_1018, zT_1019, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_1029.has_value = 1;
    zT_1029.value = zT_1028;
    return zT_1029;
    z_bb_181:
    zT_1031 = ec->registry;
    zT_1032 = zT_1031->opt_items;
    zT_1033 = ec->registry;
    zT_1034 = zT_1033->types_items;
    zT_1035 = (unsigned int)type_id;
    zT_1036 = zT_1034[zT_1035];
    zT_1037 = zT_1036.payload_idx;
    zT_1038 = (unsigned int)zT_1037;
    zT_1039 = zT_1032[zT_1038];
    op = zT_1039;
    zT_1040 = ec;
    zT_1041 = module_id;
    zT_1042 = node_idx;
    zT_1043 = op.payload;
    zT_1046 = 1;
    zT_1047 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_1046)), 32u);
    zT_1048 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_1046)), 32u);
    zT_1050 = zT_1048 == (unsigned int)(0);
    if (!(zT_1050)) { pal_trap(); }
    zT_1044 = zT_1047;
    zT_1051 = zF_BF602E2F_classify(zT_1040, zT_1041, zT_1042, zT_1043, zT_1044);
    zT_1052 = zT_1051.has_value;
    if (zT_1052) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    if (!(zT_1051.has_value)) { pal_trap(); }
    pay = zT_1051.value;
    zT_1055 = ec->tbl;
    zT_1061 = 8;
    zT_1056 = zT_1061;
    zT_1065 = zF_094E0976_tableAddNode(zT_1055, zT_1056, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg7 = zT_1065;
    zT_1070 = ec->tbl;
    zT_1067 = zT_1070->alloc;
    zT_1073 = 3;
    zT_1074 = (unsigned int)(4) * zT_1073;
    zT_1077 = zF_1395EB68_sandAlloc(zT_1067, (unsigned int)((unsigned int)zT_1074), (unsigned int)(4));
    zT_1078 = zT_1077.is_error;
    if (zT_1078) goto z_bb_184; else goto z_bb_185;
    z_bb_183:
    zT_1103.has_value = 0;
    return zT_1103;
    z_bb_184:
    pal_trap();
    z_bb_185:
    zT_1079 = zT_1077.data.payload;
    goto z_bb_186;
    z_bb_186:
    scratch_raw7 = zT_1079;
    zT_1082 = (unsigned int*)scratch_raw7;
    scratch7 = zT_1082;
    zT_1083 = 0;
    scratch7[zT_1083] = pay;
    zT_1084 = ec->tbl;
    zT_1090 = 1;
    zT_1085 = zT_1090;
    zT_1094 = zF_094E0976_tableAddNode(zT_1084, zT_1085, (zT_79FAE712_u64)(1), (unsigned int)(0), (unsigned int)(0));
    zT_1095 = 1;
    scratch7[zT_1095] = zT_1094;
    zT_1096 = ec->tbl;
    zT_1097 = agg7;
    zT_1098 = scratch7;
    zF_D8E7F449_tableFinishAgg(zT_1096, zT_1097, zT_1098, (unsigned int)(2));
    zT_1102.has_value = 1;
    zT_1102.value = agg7;
    return zT_1102;
    z_bb_187:
    zT_1109 = ec->registry;
    zT_1110 = zT_1109->eu_items;
    zT_1111 = ec->registry;
    zT_1112 = zT_1111->types_items;
    zT_1113 = (unsigned int)type_id;
    zT_1114 = zT_1112[zT_1113];
    zT_1115 = zT_1114.payload_idx;
    zT_1116 = (unsigned int)zT_1115;
    zT_1117 = zT_1110[zT_1116];
    ep2 = zT_1117;
    zT_1119 = ep2.payload;
    pay_ty = zT_1119;
    if ((unsigned char)(pay_ty == (unsigned int)(1))) goto z_bb_190; else goto z_bb_189;
    z_bb_188:
    zT_1268.has_value = 0;
    return zT_1268;
    z_bb_189:
    zT_1124 = ec;
    zT_1125 = pay_ty;
    zT_1126 = zF_4E56FBAE_typeKindOf(zT_1124, zT_1125);
    zT_1123 = zT_1126 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type));
    goto z_bb_191;
    z_bb_190:
    zT_1123 = 1;
    goto z_bb_191;
    z_bb_191:
    is_void_pay = zT_1123;
    zT_1131 = node.kind;
    if ((unsigned char)(zT_1131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    if ((unsigned char)(!is_void_pay)) goto z_bb_194; else goto z_bb_195;
    z_bb_193:
    if (is_void_pay) goto z_bb_201; else goto z_bb_202;
    z_bb_194:
    zT_1136.has_value = 0;
    return zT_1136;
    z_bb_195:
    zT_1137 = ec->enum_values;
    zT_1138 = node_idx;
    zT_1140 = zF_F3EE5998_u32ToU32MapGet(zT_1137, zT_1138);
    zT_1141 = zT_1140.has_value;
    if (zT_1141) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    if (!(zT_1140.has_value)) { pal_trap(); }
    ev2 = zT_1140.value;
    zT_1144 = ec->tbl;
    zT_1150 = 8;
    zT_1145 = zT_1150;
    zT_1154 = zF_094E0976_tableAddNode(zT_1144, zT_1145, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg8 = zT_1154;
    zT_1159 = ec->tbl;
    zT_1156 = zT_1159->alloc;
    zT_1162 = 3;
    zT_1163 = (unsigned int)(4) * zT_1162;
    zT_1166 = zF_1395EB68_sandAlloc(zT_1156, (unsigned int)((unsigned int)zT_1163), (unsigned int)(4));
    zT_1167 = zT_1166.is_error;
    if (zT_1167) goto z_bb_198; else goto z_bb_199;
    z_bb_197:
    zT_1203.has_value = 0;
    return zT_1203;
    z_bb_198:
    pal_trap();
    z_bb_199:
    zT_1168 = zT_1166.data.payload;
    goto z_bb_200;
    z_bb_200:
    scratch_raw8 = zT_1168;
    zT_1171 = (unsigned int*)scratch_raw8;
    scratch8 = zT_1171;
    zT_1172 = ec->tbl;
    zT_1178 = 1;
    zT_1173 = zT_1178;
    zT_1182 = zF_094E0976_tableAddNode(zT_1172, zT_1173, (zT_79FAE712_u64)((zT_79FAE712_u64)ev2), (unsigned int)(0), (unsigned int)(0));
    zT_1183 = 0;
    scratch8[zT_1183] = zT_1182;
    zT_1184 = ec->tbl;
    zT_1190 = 1;
    zT_1185 = zT_1190;
    zT_1194 = zF_094E0976_tableAddNode(zT_1184, zT_1185, (zT_79FAE712_u64)(1), (unsigned int)(0), (unsigned int)(0));
    zT_1195 = 1;
    scratch8[zT_1195] = zT_1194;
    zT_1196 = ec->tbl;
    zT_1197 = agg8;
    zT_1198 = scratch8;
    zF_D8E7F449_tableFinishAgg(zT_1196, zT_1197, zT_1198, (unsigned int)(2));
    zT_1202.has_value = 1;
    zT_1202.value = agg8;
    return zT_1202;
    z_bb_201:
    zT_1204.has_value = 0;
    return zT_1204;
    z_bb_202:
    zT_1205 = ec;
    zT_1206 = module_id;
    zT_1207 = node_idx;
    zT_1208 = pay_ty;
    zT_1210 = 1;
    zT_1211 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_1210)), 32u);
    zT_1212 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_1210)), 32u);
    zT_1214 = zT_1212 == (unsigned int)(0);
    if (!(zT_1214)) { pal_trap(); }
    zT_1209 = zT_1211;
    zT_1215 = zF_BF602E2F_classify(zT_1205, zT_1206, zT_1207, zT_1208, zT_1209);
    zT_1216 = zT_1215.has_value;
    if (zT_1216) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    if (!(zT_1215.has_value)) { pal_trap(); }
    pay2 = zT_1215.value;
    zT_1219 = ec->tbl;
    zT_1225 = 8;
    zT_1220 = zT_1225;
    zT_1229 = zF_094E0976_tableAddNode(zT_1219, zT_1220, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    agg9 = zT_1229;
    zT_1234 = ec->tbl;
    zT_1231 = zT_1234->alloc;
    zT_1237 = 3;
    zT_1238 = (unsigned int)(4) * zT_1237;
    zT_1241 = zF_1395EB68_sandAlloc(zT_1231, (unsigned int)((unsigned int)zT_1238), (unsigned int)(4));
    zT_1242 = zT_1241.is_error;
    if (zT_1242) goto z_bb_205; else goto z_bb_206;
    z_bb_204:
    zT_1267.has_value = 0;
    return zT_1267;
    z_bb_205:
    pal_trap();
    z_bb_206:
    zT_1243 = zT_1241.data.payload;
    goto z_bb_207;
    z_bb_207:
    scratch_raw9 = zT_1243;
    zT_1246 = (unsigned int*)scratch_raw9;
    scratch9 = zT_1246;
    zT_1247 = 0;
    scratch9[zT_1247] = pay2;
    zT_1248 = ec->tbl;
    zT_1254 = 1;
    zT_1249 = zT_1254;
    zT_1258 = zF_094E0976_tableAddNode(zT_1248, zT_1249, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_1259 = 1;
    scratch9[zT_1259] = zT_1258;
    zT_1260 = ec->tbl;
    zT_1261 = agg9;
    zT_1262 = scratch9;
    zF_D8E7F449_tableFinishAgg(zT_1260, zT_1261, zT_1262, (unsigned int)(2));
    zT_1266.has_value = 1;
    zT_1266.value = agg9;
    return zT_1266;
}

/* classify */
zT_BAEE192E_Opt_10 zF_BF602E2F_classify(zT_4D150975_ConstInitEvalCtx* ec, unsigned int module_id, unsigned int node_idx, unsigned int type_id, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_7;
    zT_BAEE192E_Opt_10 zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15;
    zT_4D150975_ConstInitEvalCtx* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_8143F551_AstKind zT_20;
    zT_BAEE192E_Opt_10 zT_24;
    unsigned char zT_29;
    unsigned char zT_34;
    unsigned char zT_39;
    unsigned char zT_44;
    unsigned char zT_49;
    unsigned char zT_54;
    zT_8143F551_AstKind zT_59;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_E834303C_ArrayPayload* zT_70;
    zT_338B7C76_TypeRegistry* zT_71;
    zT_D155D06D_Type* zT_72;
    unsigned int zT_73;
    zT_D155D06D_Type zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_E834303C_ArrayPayload zT_77;
    zT_4D150975_ConstInitEvalCtx* zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    zT_6B0A7D14_AstStore* zT_83;
    zT_0EB39E3A_anon_284831 zT_84;
    unsigned int* zT_85;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_4065182A_ConstInitTable* zT_92;
    unsigned char zT_93;
    unsigned int zT_98;
    unsigned int zT_102;
    zT_BAEE192E_Opt_10 zT_103;
    zT_BAEE192E_Opt_10 zT_104;
    zT_4D150975_ConstInitEvalCtx* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_BAEE192E_Opt_10 zT_110;
    unsigned char zT_115;
    zT_8143F551_AstKind zT_120;
    zT_4065182A_ConstInitTable* zT_124;
    unsigned char zT_125;
    unsigned int zT_130;
    unsigned int zT_134;
    zT_BAEE192E_Opt_10 zT_135;
    zT_8143F551_AstKind zT_136;
    zT_6B0A7D14_AstStore* zT_141;
    zT_0EB39E3A_anon_284831 zT_142;
    unsigned int* zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_4065182A_ConstInitTable* zT_150;
    unsigned char zT_151;
    unsigned int zT_156;
    unsigned int zT_160;
    zT_BAEE192E_Opt_10 zT_161;
    zT_8143F551_AstKind zT_162;
    zT_4D150975_ConstInitEvalCtx* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_BAEE192E_Opt_10 zT_171;
    zT_8143F551_AstKind zT_172;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    zT_3D7259E2_SymbolRegistry* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_EAF7A2A2_Opt_953 zT_185;
    unsigned char zT_186;
    zT_3C598AEF_SymbolKind zT_188;
    zT_4065182A_ConstInitTable* zT_192;
    unsigned char zT_193;
    unsigned int zT_195;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_203;
    zT_BAEE192E_Opt_10 zT_204;
    zT_3C598AEF_SymbolKind zT_205;
    unsigned int zT_210;
    zT_8EED1867_ResolvedTypeTable* zT_211;
    unsigned int zT_212;
    zT_BAEE192E_Opt_10 zT_215;
    unsigned char zT_216;
    zT_4D150975_ConstInitEvalCtx* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_4065182A_ConstInitTable* zT_225;
    unsigned char zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_235;
    zT_BAEE192E_Opt_10 zT_236;
    zT_4D150975_ConstInitEvalCtx* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    zT_BAEE192E_Opt_10 zT_243;
    zT_BAEE192E_Opt_10 zT_244;
    zT_BAEE192E_Opt_10 zT_245;
    zT_8143F551_AstKind zT_250;
    zT_6B0A7D14_AstStore* zT_255;
    zT_0EB39E3A_anon_284831 zT_256;
    unsigned int* zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_4065182A_ConstInitTable* zT_264;
    unsigned char zT_265;
    unsigned int zT_270;
    unsigned int zT_274;
    zT_BAEE192E_Opt_10 zT_275;
    zT_8143F551_AstKind zT_276;
    zT_6B0A7D14_AstStore* zT_281;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_3D7259E2_SymbolRegistry* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    zT_EAF7A2A2_Opt_953 zT_289;
    unsigned char zT_290;
    zT_3C598AEF_SymbolKind zT_292;
    unsigned int zT_297;
    zT_8EED1867_ResolvedTypeTable* zT_298;
    unsigned int zT_299;
    zT_BAEE192E_Opt_10 zT_302;
    unsigned char zT_303;
    zT_4D150975_ConstInitEvalCtx* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_4065182A_ConstInitTable* zT_312;
    unsigned char zT_313;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_322;
    zT_BAEE192E_Opt_10 zT_323;
    zT_4D150975_ConstInitEvalCtx* zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_BAEE192E_Opt_10 zT_330;
    zT_BAEE192E_Opt_10 zT_331;
    zT_8143F551_AstKind zT_332;
    zT_4D150975_ConstInitEvalCtx* zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    zT_BAEE192E_Opt_10 zT_341;
    zT_BAEE192E_Opt_10 zT_342;
    unsigned char zT_347;
    zT_8143F551_AstKind zT_352;
    zT_6B0A7D14_AstStore* zT_357;
    zT_0BB15AEA_anon_284822 zT_358;
    zT_00435AEB_f64* zT_359;
    zT_6B0A7D14_AstStore* zT_360;
    unsigned int zT_361;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_00435AEB_f64 zT_365;
    zT_00435AEB_f64* zT_367;
    zT_79FAE712_u64* zT_368;
    zT_4065182A_ConstInitTable* zT_369;
    unsigned char zT_370;
    zT_79FAE712_u64 zT_371;
    unsigned int zT_375;
    unsigned int zT_379;
    zT_BAEE192E_Opt_10 zT_380;
    zT_BAEE192E_Opt_10 zT_381;
    zT_4D150975_ConstInitEvalCtx* zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_BAEE192E_Opt_10 zT_391;
    zT_4D150975_ConstInitEvalCtx* zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_BAEE192E_Opt_10 zT_397;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_110, (unsigned int)sizeof zT_110);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    zig_poison_fill((void*)&zT_147, (unsigned int)sizeof zT_147);
    zig_poison_fill((void*)&zT_160, (unsigned int)sizeof zT_160);
    zig_poison_fill((void*)&zT_171, (unsigned int)sizeof zT_171);
    zig_poison_fill((void*)&zT_180, (unsigned int)sizeof zT_180);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    zig_poison_fill((void*)&zT_203, (unsigned int)sizeof zT_203);
    zig_poison_fill((void*)&zT_215, (unsigned int)sizeof zT_215);
    zig_poison_fill((void*)&zT_220, (unsigned int)sizeof zT_220);
    zig_poison_fill((void*)&zT_235, (unsigned int)sizeof zT_235);
    zig_poison_fill((void*)&zT_243, (unsigned int)sizeof zT_243);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_245, (unsigned int)sizeof zT_245);
    zig_poison_fill((void*)&zT_261, (unsigned int)sizeof zT_261);
    zig_poison_fill((void*)&zT_274, (unsigned int)sizeof zT_274);
    zig_poison_fill((void*)&zT_284, (unsigned int)sizeof zT_284);
    zig_poison_fill((void*)&zT_289, (unsigned int)sizeof zT_289);
    zig_poison_fill((void*)&zT_302, (unsigned int)sizeof zT_302);
    zig_poison_fill((void*)&zT_307, (unsigned int)sizeof zT_307);
    zig_poison_fill((void*)&zT_322, (unsigned int)sizeof zT_322);
    zig_poison_fill((void*)&zT_330, (unsigned int)sizeof zT_330);
    zig_poison_fill((void*)&zT_331, (unsigned int)sizeof zT_331);
    zig_poison_fill((void*)&zT_341, (unsigned int)sizeof zT_341);
    zig_poison_fill((void*)&zT_342, (unsigned int)sizeof zT_342);
    zig_poison_fill((void*)&zT_363, (unsigned int)sizeof zT_363);
    zig_poison_fill((void*)&zT_379, (unsigned int)sizeof zT_379);
    zig_poison_fill((void*)&zT_381, (unsigned int)sizeof zT_381);
    zig_poison_fill((void*)&zT_391, (unsigned int)sizeof zT_391);
    zig_poison_fill((void*)&zT_397, (unsigned int)sizeof zT_397);
    zT_22A7C88B_AstNode node;
    unsigned int tk;
    zT_E834303C_ArrayPayload ap;
    unsigned int sid;
    unsigned int sid2;
    unsigned int name_id2;
    zT_3A105EF1_Symbol* s3;
    unsigned int gtid3;
    unsigned int gt3;
    unsigned int sid3;
    unsigned int name_id3;
    zT_3A105EF1_Symbol* s4;
    unsigned int gtid4;
    unsigned int gt4;
    zT_00435AEB_f64 fb;
    zT_79FAE712_u64* fbp;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(256))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_4:
    zT_12 = ec->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    node = zT_15;
    zT_17 = ec;
    zT_18 = type_id;
    zT_19 = zF_4E56FBAE_typeKindOf(zT_17, zT_18);
    tk = zT_19;
    zT_20 = node.kind;
    if ((unsigned char)(zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_24.has_value = 0;
    return zT_24;
    z_bb_6:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type)))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_29 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type));
    goto z_bb_9;
    z_bb_8:
    zT_29 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_29) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_34 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type));
    goto z_bb_12;
    z_bb_11:
    zT_34 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_34) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_39 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type));
    goto z_bb_15;
    z_bb_14:
    zT_39 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_39) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_44 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type));
    goto z_bb_18;
    z_bb_17:
    zT_44 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_44) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_49 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type));
    goto z_bb_21;
    z_bb_20:
    zT_49 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_49) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_54 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type));
    goto z_bb_24;
    z_bb_23:
    zT_54 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_54) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_59 = node.kind;
    if ((unsigned char)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type)))) goto z_bb_35; else goto z_bb_34;
    z_bb_27:
    zT_63 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type));
    goto z_bb_29;
    z_bb_28:
    zT_63 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_63) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_69 = ec->registry;
    zT_70 = zT_69->array_items;
    zT_71 = ec->registry;
    zT_72 = zT_71->types_items;
    zT_73 = (unsigned int)type_id;
    zT_74 = zT_72[zT_73];
    zT_75 = zT_74.payload_idx;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zT_70[zT_76];
    ap = zT_77;
    zT_78 = ec;
    zT_79 = ap.elem;
    zT_81 = zF_092A96D8_isU8ish(zT_78, zT_79);
    if (zT_81) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_105 = ec;
    zT_106 = module_id;
    zT_107 = node_idx;
    zT_108 = type_id;
    zT_109 = depth;
    zT_110 = zF_F7CF67F0_classifyAgg(zT_105, zT_106, zT_107, zT_108, zT_109);
    return zT_110;
    z_bb_32:
    zT_83 = ec->store;
    zT_84 = zT_83->string_values;
    zT_85 = zT_84.items;
    zT_86 = ec->store;
    zT_87 = node_idx;
    zT_89 = zF_8BA26B9E_astStoreNodePayload(zT_86, zT_87);
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_85[zT_90];
    sid = zT_91;
    zT_92 = ec->tbl;
    zT_98 = 5;
    zT_93 = zT_98;
    zT_102 = zF_094E0976_tableAddNode(zT_92, zT_93, (zT_79FAE712_u64)((zT_79FAE712_u64)sid), (unsigned int)(0), (unsigned int)(0));
    zT_103.has_value = 1;
    zT_103.value = zT_102;
    return zT_103;
    z_bb_33:
    zT_104.has_value = 0;
    return zT_104;
    z_bb_34:
    zT_115 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type));
    goto z_bb_36;
    z_bb_35:
    zT_115 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_115) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_120 = node.kind;
    if ((unsigned char)(zT_120 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type)))) goto z_bb_57; else goto z_bb_58;
    z_bb_39:
    zT_124 = ec->tbl;
    zT_130 = 0;
    zT_125 = zT_130;
    zT_134 = zF_094E0976_tableAddNode(zT_124, zT_125, (zT_79FAE712_u64)(0), (unsigned int)(0), (unsigned int)(0));
    zT_135.has_value = 1;
    zT_135.value = zT_134;
    return zT_135;
    z_bb_40:
    zT_136 = node.kind;
    if ((unsigned char)(zT_136 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_141 = ec->store;
    zT_142 = zT_141->string_values;
    zT_143 = zT_142.items;
    zT_144 = ec->store;
    zT_145 = node_idx;
    zT_147 = zF_8BA26B9E_astStoreNodePayload(zT_144, zT_145);
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_143[zT_148];
    sid2 = zT_149;
    zT_150 = ec->tbl;
    zT_156 = 5;
    zT_151 = zT_156;
    zT_160 = zF_094E0976_tableAddNode(zT_150, zT_151, (zT_79FAE712_u64)((zT_79FAE712_u64)sid2), (unsigned int)(0), (unsigned int)(0));
    zT_161.has_value = 1;
    zT_161.value = zT_160;
    return zT_161;
    z_bb_42:
    zT_162 = node.kind;
    if ((unsigned char)(zT_162 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_166 = ec;
    zT_167 = module_id;
    zT_168 = node.child_0;
    zT_169 = depth;
    zT_171 = zF_19E37948_classifyAddr(zT_166, zT_167, zT_168, zT_169);
    return zT_171;
    z_bb_44:
    zT_172 = node.kind;
    if ((unsigned char)(zT_172 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_177 = ec->store;
    zT_178 = node_idx;
    zT_180 = zF_53458827_astStoreIdentifier(zT_177, zT_178);
    name_id2 = zT_180;
    zT_181 = ec->symbol_reg;
    zT_182 = module_id;
    zT_183 = name_id2;
    zT_185 = zF_A398987E_symbolRegistryQuali(zT_181, zT_182, zT_183);
    zT_186 = zT_185.has_value;
    if (zT_186) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_245.has_value = 0;
    return zT_245;
    z_bb_47:
    if (!(zT_185.has_value)) { pal_trap(); }
    s3 = zT_185.value;
    zT_188 = s3->kind;
    if ((unsigned char)(zT_188 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_244.has_value = 0;
    return zT_244;
    z_bb_49:
    zT_192 = ec->tbl;
    zT_198 = 7;
    zT_193 = zT_198;
    zT_199 = s3->name_id;
    zT_195 = s3->module_id;
    zT_203 = zF_094E0976_tableAddNode(zT_192, zT_193, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_199), zT_195, (unsigned int)(0));
    zT_204.has_value = 1;
    zT_204.value = zT_203;
    return zT_204;
    z_bb_50:
    zT_205 = s3->kind;
    if ((unsigned char)(zT_205 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_210 = s3->type_id;
    gtid3 = zT_210;
    zT_211 = ec->resolved;
    zT_212 = s3->decl_node;
    zT_215 = zF_999DCF51_resolvedTypeTableGe(zT_211, zT_212);
    zT_216 = zT_215.has_value;
    if (zT_216) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_48;
    z_bb_53:
    if (!(zT_215.has_value)) { pal_trap(); }
    gt3 = zT_215.value;
    gtid3 = gt3;
    goto z_bb_54;
    z_bb_54:
    zT_218 = ec;
    zT_219 = gtid3;
    zT_220 = zF_4E56FBAE_typeKindOf(zT_218, zT_219);
    if ((unsigned char)(zT_220 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_225 = ec->tbl;
    zT_231 = 6;
    zT_226 = zT_231;
    zT_232 = s3->name_id;
    zT_228 = s3->module_id;
    zT_229 = gtid3;
    zT_235 = zF_094E0976_tableAddNode(zT_225, zT_226, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_232), zT_228, zT_229);
    zT_236.has_value = 1;
    zT_236.value = zT_235;
    return zT_236;
    z_bb_56:
    zT_237 = ec;
    zT_238 = s3->module_id;
    zT_239 = s3->decl_node;
    zT_240 = depth;
    zT_243 = zF_07765C6B_valueCopyDecl(zT_237, zT_238, zT_239, zT_240);
    return zT_243;
    z_bb_57:
    zT_250 = node.kind;
    if ((unsigned char)(zT_250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type)))) goto z_bb_74; else goto z_bb_73;
    z_bb_59:
    zT_255 = ec->store;
    zT_256 = zT_255->string_values;
    zT_257 = zT_256.items;
    zT_258 = ec->store;
    zT_259 = node_idx;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_258, zT_259);
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_257[zT_262];
    sid3 = zT_263;
    zT_264 = ec->tbl;
    zT_270 = 5;
    zT_265 = zT_270;
    zT_274 = zF_094E0976_tableAddNode(zT_264, zT_265, (zT_79FAE712_u64)((zT_79FAE712_u64)sid3), (unsigned int)(0), (unsigned int)(0));
    zT_275.has_value = 1;
    zT_275.value = zT_274;
    return zT_275;
    z_bb_60:
    zT_276 = node.kind;
    if ((unsigned char)(zT_276 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_281 = ec->store;
    zT_282 = node_idx;
    zT_284 = zF_53458827_astStoreIdentifier(zT_281, zT_282);
    name_id3 = zT_284;
    zT_285 = ec->symbol_reg;
    zT_286 = module_id;
    zT_287 = name_id3;
    zT_289 = zF_A398987E_symbolRegistryQuali(zT_285, zT_286, zT_287);
    zT_290 = zT_289.has_value;
    if (zT_290) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_332 = node.kind;
    if ((unsigned char)(zT_332 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_71; else goto z_bb_72;
    z_bb_63:
    if (!(zT_289.has_value)) { pal_trap(); }
    s4 = zT_289.value;
    zT_292 = s4->kind;
    if ((unsigned char)(zT_292 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_331.has_value = 0;
    return zT_331;
    z_bb_65:
    zT_297 = s4->type_id;
    gtid4 = zT_297;
    zT_298 = ec->resolved;
    zT_299 = s4->decl_node;
    zT_302 = zF_999DCF51_resolvedTypeTableGe(zT_298, zT_299);
    zT_303 = zT_302.has_value;
    if (zT_303) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    if (!(zT_302.has_value)) { pal_trap(); }
    gt4 = zT_302.value;
    gtid4 = gt4;
    goto z_bb_68;
    z_bb_68:
    zT_305 = ec;
    zT_306 = gtid4;
    zT_307 = zF_4E56FBAE_typeKindOf(zT_305, zT_306);
    if ((unsigned char)(zT_307 == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type)))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_312 = ec->tbl;
    zT_318 = 6;
    zT_313 = zT_318;
    zT_319 = s4->name_id;
    zT_315 = s4->module_id;
    zT_316 = gtid4;
    zT_322 = zF_094E0976_tableAddNode(zT_312, zT_313, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_319), zT_315, zT_316);
    zT_323.has_value = 1;
    zT_323.value = zT_322;
    return zT_323;
    z_bb_70:
    zT_324 = ec;
    zT_325 = s4->module_id;
    zT_326 = s4->decl_node;
    zT_327 = depth;
    zT_330 = zF_07765C6B_valueCopyDecl(zT_324, zT_325, zT_326, zT_327);
    return zT_330;
    z_bb_71:
    zT_336 = ec;
    zT_337 = module_id;
    zT_338 = node.child_0;
    zT_339 = depth;
    zT_341 = zF_19E37948_classifyAddr(zT_336, zT_337, zT_338, zT_339);
    return zT_341;
    z_bb_72:
    zT_342.has_value = 0;
    return zT_342;
    z_bb_73:
    zT_347 = tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type));
    goto z_bb_75;
    z_bb_74:
    zT_347 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_347) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_352 = node.kind;
    if ((unsigned char)(zT_352 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    if ((unsigned char)(tk == (unsigned int)((unsigned int)(zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type)))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    zT_357 = ec->store;
    zT_358 = zT_357->float_values;
    zT_359 = zT_358.items;
    zT_360 = ec->store;
    zT_361 = node_idx;
    zT_363 = zF_8BA26B9E_astStoreNodePayload(zT_360, zT_361);
    zT_364 = (unsigned int)zT_363;
    zT_365 = zT_359[zT_364];
    fb = zT_365;
    zT_367 = (zT_00435AEB_f64*)&fb;
    zT_368 = (zT_79FAE712_u64*)zT_367;
    fbp = zT_368;
    zT_369 = ec->tbl;
    zT_375 = 2;
    zT_370 = zT_375;
    zT_371 = *fbp;
    zT_379 = zF_094E0976_tableAddNode(zT_369, zT_370, zT_371, (unsigned int)(0), (unsigned int)(0));
    zT_380.has_value = 1;
    zT_380.value = zT_379;
    return zT_380;
    z_bb_79:
    zT_381.has_value = 0;
    return zT_381;
    z_bb_80:
    zT_386 = ec;
    zT_387 = module_id;
    zT_388 = node_idx;
    zT_389 = type_id;
    zT_390 = depth;
    zT_391 = zF_83AC95E3_classifyScalar(zT_386, zT_387, zT_388, zT_389, zT_390);
    return zT_391;
    z_bb_81:
    zT_392 = ec;
    zT_393 = module_id;
    zT_394 = node_idx;
    zT_395 = type_id;
    zT_396 = depth;
    zT_397 = zF_83AC95E3_classifyScalar(zT_392, zT_393, zT_394, zT_395, zT_396);
    return zT_397;
}

/* EOF */
