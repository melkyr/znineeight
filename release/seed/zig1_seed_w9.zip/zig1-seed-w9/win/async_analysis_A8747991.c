#include "async_analysis_A8747991.h"
/* asyncKey */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int module_id, unsigned int name_id) {
    zT_79FAE712_u64 zT_2;
    zT_79FAE712_u64 zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned char zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_2 = (zT_79FAE712_u64)module_id;
    zT_3 = 32;
    zT_6 = zT_3 < (unsigned int)(64);
    if (!(zT_6)) { pal_trap(); }
    zT_4 = zig_wrap_shl_u(((zu64)(zT_2)), ((zu64)(zT_3)), 64u);
    zT_7 = zig_overflow_flag_shl_u(((zu64)(zT_2)), ((zu64)(zT_3)), 64u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    return (zT_79FAE712_u64)(zT_4 | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
}

/* asyncIsSuspending */
unsigned char zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8;
    zT_BAEE192E_Opt_10 zT_9;
    unsigned char zT_10;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_BAEE192E_Opt_10 v;
    unsigned int val;
    zT_4 = map;
    zT_6 = module_id;
    zT_7 = name_id;
    zT_8 = zF_9D041EB6_asyncKey(zT_6, zT_7);
    zT_5 = zT_8;
    zT_9 = zF_A05A7BE1_u64ToU32MapGet(zT_4, zT_5);
    v = zT_9;
    zT_10 = v.has_value;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(v.has_value)) { pal_trap(); }
    val = v.value;
    return (unsigned char)(val != (unsigned int)(0));
    z_bb_2:
    return (unsigned char)(0);
}

/* asyncFrameSizeOf */
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7;
    zT_BAEE192E_Opt_10 zT_8;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    return zT_8;
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand* sand, unsigned int count) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_FDFD82FD_EU_362 zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned int c;
    unsigned char* raw;
    c = count;
    if ((unsigned char)(c == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    c = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = sand;
    zT_10 = 4;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(c)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(c)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_8 = zT_11;
    zT_16 = zF_1395EB68_sandAlloc(zT_7, zT_8, (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    return (unsigned int*)((unsigned int*)raw);
}

/* resolveCalleeKey */
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int callee_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_7;
    zT_8143F551_AstKind zT_8;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_3D7259E2_SymbolRegistry* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_77F031D4_Opt_960 zT_19;
    unsigned char zT_20;
    zT_3C598AEF_SymbolKind zT_22;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_79FAE712_u64 zT_30;
    zT_BBEE1AC1_Opt_11 zT_31;
    zT_BBEE1AC1_Opt_11 zT_32;
    zT_8143F551_AstKind zT_33;
    zT_BBEE1AC1_Opt_11 zT_37;
    zT_99292002_Arr_unsigned_int_16 zT_39;
    int zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_60;
    zT_8143F551_AstKind zT_61;
    zT_BBEE1AC1_Opt_11 zT_67;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    zT_22A7C88B_AstNode zT_83;
    zT_8143F551_AstKind zT_84;
    zT_BBEE1AC1_Opt_11 zT_88;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_3D7259E2_SymbolRegistry* zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_77F031D4_Opt_960 zT_97;
    unsigned char zT_98;
    zT_3C598AEF_SymbolKind zT_100;
    zT_BBEE1AC1_Opt_11 zT_104;
    unsigned int zT_105;
    zT_BBEE1AC1_Opt_11 zT_106;
    int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    zT_3D7259E2_SymbolRegistry* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_121;
    zT_77F031D4_Opt_960 zT_123;
    unsigned char zT_124;
    zT_3C598AEF_SymbolKind zT_126;
    zT_BBEE1AC1_Opt_11 zT_130;
    unsigned int zT_131;
    zT_BBEE1AC1_Opt_11 zT_132;
    zT_3D7259E2_SymbolRegistry* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_136;
    unsigned char zT_138;
    zT_77F031D4_Opt_960 zT_140;
    unsigned char zT_141;
    zT_3C598AEF_SymbolKind zT_143;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_79FAE712_u64 zT_151;
    zT_BBEE1AC1_Opt_11 zT_152;
    zT_BBEE1AC1_Opt_11 zT_153;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_132, (unsigned int)sizeof zT_132);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_151, (unsigned int)sizeof zT_151);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zT_22A7C88B_AstNode cn;
    unsigned int nid;
    zT_3A105EF1_Symbol* s;
    zT_99292002_Arr_unsigned_int_16 names;
    unsigned int nlen;
    unsigned int cur;
    zT_22A7C88B_AstNode cw;
    unsigned int base_nid;
    unsigned int cur_mod;
    zT_3A105EF1_Symbol* bs;
    unsigned int i;
    zT_3A105EF1_Symbol* ms;
    zT_3A105EF1_Symbol* fs;
    zT_5 = store;
    zT_6 = callee_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    cn = zT_7;
    zT_8 = cn.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = store;
    zT_14 = callee_idx;
    zT_15 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    nid = zT_15;
    zT_16 = sym_reg;
    zT_17 = module_id;
    zT_18 = nid;
    zT_19 = zF_A398987E_symbolRegistryQuali(zT_16, zT_17, zT_18);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_33 = cn.kind;
    if ((unsigned char)(zT_33 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    if (!(zT_19.has_value)) { pal_trap(); }
    s = zT_19.value;
    zT_22 = s->kind;
    if ((unsigned char)(zT_22 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_5:
    zT_26 = s->module_id;
    zT_27 = s->name_id;
    zT_30 = zF_9D041EB6_asyncKey(zT_26, zT_27);
    zT_31.has_value = 1;
    zT_31.value = zT_30;
    return zT_31;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_8:
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        names[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    nlen = zT_42;
    zT_43 = store;
    zT_44 = callee_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    zT_46 = (unsigned int)nlen;
    zT_48 = zT_46 < (unsigned int)(16);
    if (!(zT_48)) { pal_trap(); }
    names[zT_46] = zT_45;
    zT_49 = 1;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zig_wrap_add_u(((zu64)(nlen)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(nlen)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    nlen = zT_51;
    zT_56 = cn.child_0;
    cur = zT_56;
    zT_58 = store;
    zT_59 = cur;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    cw = zT_60;
    goto z_bb_9;
    z_bb_9:
    zT_61 = cw.kind;
    if ((unsigned char)(zT_61 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if ((unsigned char)(nlen >= (unsigned int)(16))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_84 = cw.kind;
    if ((unsigned char)(zT_84 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_67.has_value = 0;
    return zT_67;
    z_bb_14:
    zT_68 = store;
    zT_69 = cur;
    zT_70 = zF_8BA26B9E_astStoreNodePayload(zT_68, zT_69);
    zT_71 = (unsigned int)nlen;
    zT_73 = zT_71 < (unsigned int)(16);
    if (!(zT_73)) { pal_trap(); }
    names[zT_71] = zT_70;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(nlen)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(nlen)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    nlen = zT_76;
    zT_80 = cw.child_0;
    cur = zT_80;
    zT_81 = store;
    zT_82 = cur;
    zT_83 = zF_FCDD1D35_astStoreNodeAt(zT_81, zT_82);
    cw = zT_83;
    goto z_bb_12;
    z_bb_15:
    zT_88.has_value = 0;
    return zT_88;
    z_bb_16:
    zT_90 = store;
    zT_91 = cur;
    zT_92 = zF_53458827_astStoreIdentifier(zT_90, zT_91);
    base_nid = zT_92;
    cur_mod = module_id;
    zT_94 = sym_reg;
    zT_95 = module_id;
    zT_96 = base_nid;
    zT_97 = zF_A398987E_symbolRegistryQuali(zT_94, zT_95, zT_96);
    zT_98 = zT_97.has_value;
    if (zT_98) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    if (!(zT_97.has_value)) { pal_trap(); }
    bs = zT_97.value;
    zT_100 = bs->kind;
    if ((unsigned char)(zT_100 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    i = nlen;
    goto z_bb_22;
    z_bb_19:
    zT_106.has_value = 0;
    return zT_106;
    z_bb_20:
    zT_104.has_value = 0;
    return zT_104;
    z_bb_21:
    zT_105 = bs->module_id;
    cur_mod = zT_105;
    goto z_bb_18;
    z_bb_22:
    if ((unsigned char)(i > (unsigned int)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_110 = 1;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    i = zT_112;
    zT_116 = sym_reg;
    zT_117 = cur_mod;
    zT_119 = (unsigned int)i;
    zT_121 = zT_119 < (unsigned int)(16);
    if (!(zT_121)) { pal_trap(); }
    zT_118 = names[zT_119];
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_116, zT_117, zT_118);
    zT_124 = zT_123.has_value;
    if (zT_124) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_133 = sym_reg;
    zT_134 = cur_mod;
    zT_136 = 0;
    zT_138 = (unsigned int)zT_136 < (unsigned int)(16);
    if (!(zT_138)) { pal_trap(); }
    zT_135 = names[zT_136];
    zT_140 = zF_A398987E_symbolRegistryQuali(zT_133, zT_134, zT_135);
    zT_141 = zT_140.has_value;
    if (zT_141) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    if (!(zT_123.has_value)) { pal_trap(); }
    ms = zT_123.value;
    zT_126 = ms->kind;
    if ((unsigned char)(zT_126 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_132.has_value = 0;
    return zT_132;
    z_bb_29:
    zT_130.has_value = 0;
    return zT_130;
    z_bb_30:
    zT_131 = ms->module_id;
    cur_mod = zT_131;
    goto z_bb_27;
    z_bb_31:
    if (!(zT_140.has_value)) { pal_trap(); }
    fs = zT_140.value;
    zT_143 = fs->kind;
    if ((unsigned char)(zT_143 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_153.has_value = 0;
    return zT_153;
    z_bb_33:
    zT_147 = fs->module_id;
    zT_148 = fs->name_id;
    zT_151 = zF_9D041EB6_asyncKey(zT_147, zT_148);
    zT_152.has_value = 1;
    zT_152.value = zT_151;
    return zT_152;
    z_bb_34:
    goto z_bb_32;
}

/* scanFunction */
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int caller_idx, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_B687BB96_U32ArrayList* edge_caller, zT_B687BB96_U32ArrayList* edge_callee, zT_47B162D1_U8ArrayList* direct, zT_A4CE86B7_U64ToU32Map* fn_index, unsigned int async_suspend_name_id) {
    zT_B687BB96_U32ArrayList* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_22A7C88B_AstNode zT_37;
    zT_8143F551_AstKind zT_39;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_46;
    zT_3D7259E2_SymbolRegistry* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_BBEE1AC1_Opt_11 zT_51;
    unsigned char zT_52;
    zT_A4CE86B7_U64ToU32Map* zT_54;
    zT_79FAE712_u64 zT_55;
    zT_BAEE192E_Opt_10 zT_56;
    unsigned char zT_57;
    zT_B687BB96_U32ArrayList* zT_59;
    unsigned int zT_60;
    zT_B687BB96_U32ArrayList* zT_61;
    unsigned int zT_62;
    zT_B687BB96_U32ArrayList* zT_63;
    unsigned int zT_64;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_71;
    zT_B687BB96_U32ArrayList* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_80;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int zT_90;
    unsigned char zT_92;
    unsigned char* zT_93;
    unsigned int zT_94;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    zT_B687BB96_U32ArrayList* zT_103;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    unsigned int zT_109;
    int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    unsigned int zT_116;
    unsigned char zT_119;
    zT_8143F551_AstKind zT_120;
    unsigned char zT_123;
    zT_B687BB96_U32ArrayList* zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    unsigned char zT_134;
    zT_B687BB96_U32ArrayList* zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    unsigned char zT_141;
    zT_8143F551_AstKind zT_142;
    unsigned char zT_145;
    zT_B687BB96_U32ArrayList* zT_146;
    unsigned int zT_147;
    zT_8143F551_AstKind zT_149;
    unsigned char zT_150;
    zT_6B0A7D14_AstStore* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_B687BB96_U32ArrayList* zT_159;
    unsigned int zT_160;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    unsigned int zT_165;
    int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    zig_poison_fill((void*)&zT_145, (unsigned int)sizeof zT_145);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_165, (unsigned int)sizeof zT_165);
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int gi;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_14 = stack;
    zT_15 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_14, zT_15);
    goto z_bb_3;
    z_bb_3:
    zT_16 = stack->len;
    if ((unsigned char)(zT_16 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = stack->items;
    zT_21 = stack->len;
    zT_22 = 1;
    zT_23 = zig_wrap_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    zT_27 = zT_20[zT_23];
    ni = zT_27;
    zT_28 = stack->len;
    zT_29 = 1;
    zT_30 = zig_wrap_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    stack->len = zT_30;
    zT_35 = store;
    zT_36 = ni;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    n = zT_37;
    zT_39 = n.kind;
    k = zT_39;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_43 = n.child_0;
    if ((unsigned char)(zT_43 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_19; else goto z_bb_20;
    z_bb_9:
    zT_46 = store;
    zT_47 = sym_reg;
    zT_48 = module_id;
    zT_49 = n.child_0;
    zT_51 = zF_860C82EC_resolveCalleeKey(zT_46, zT_47, zT_48, zT_49);
    zT_52 = zT_51.has_value;
    if (zT_52) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_67 = store;
    zT_68 = ni;
    zT_69 = zF_152E19CB_astStoreNodeExtraCh(zT_67, zT_68);
    ec_n = zT_69;
    zT_71 = 0;
    ei = zT_71;
    goto z_bb_15;
    z_bb_11:
    if (!(zT_51.has_value)) { pal_trap(); }
    ck = zT_51.value;
    zT_54 = fn_index;
    zT_55 = ck;
    zT_56 = zF_A05A7BE1_u64ToU32MapGet(zT_54, zT_55);
    zT_57 = zT_56.has_value;
    if (zT_57) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_63 = stack;
    zT_64 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_63, zT_64);
    goto z_bb_10;
    z_bb_13:
    if (!(zT_56.has_value)) { pal_trap(); }
    gi = zT_56.value;
    zT_59 = edge_caller;
    zT_60 = caller_idx;
    zF_62F717A2_u32ArrayListAppend(zT_59, zT_60);
    zT_61 = edge_callee;
    zT_62 = gi;
    zF_62F717A2_u32ArrayListAppend(zT_61, zT_62);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((unsigned char)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_74 = stack;
    zT_76 = store;
    zT_77 = ni;
    zT_80 = zF_B10B1BC1_astStoreNodeExtraCh(zT_76, zT_77, (unsigned int)((unsigned int)ei));
    zT_75 = zT_80;
    zF_62F717A2_u32ArrayListAppend(zT_74, zT_75);
    goto z_bb_18;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_81 = 1;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    ei = zT_83;
    goto z_bb_15;
    z_bb_19:
    zT_90 = n.child_0;
    if ((unsigned char)(zT_90 == async_suspend_name_id)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_116 = n.child_0;
    if ((unsigned char)(zT_116 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    zT_92 = 1;
    zT_93 = direct->items;
    zT_94 = (unsigned int)caller_idx;
    zT_93[zT_94] = zT_92;
    goto z_bb_22;
    z_bb_22:
    zT_96 = store;
    zT_97 = ni;
    zT_98 = zF_152E19CB_astStoreNodeExtraCh(zT_96, zT_97);
    ec2_n = zT_98;
    zT_100 = 0;
    ei2 = zT_100;
    goto z_bb_23;
    z_bb_23:
    if ((unsigned char)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_103 = stack;
    zT_105 = store;
    zT_106 = ni;
    zT_109 = zF_B10B1BC1_astStoreNodeExtraCh(zT_105, zT_106, (unsigned int)((unsigned int)ei2));
    zT_104 = zT_109;
    zF_62F717A2_u32ArrayListAppend(zT_103, zT_104);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_6;
    z_bb_26:
    zT_110 = 1;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zig_wrap_add_u(((zu64)(ei2)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(ei2)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    ei2 = zT_112;
    goto z_bb_23;
    z_bb_27:
    zT_120 = k;
    zT_123 = zF_C395F6FD_nodeChildIsNode(zT_120, (unsigned char)(0));
    zT_119 = zT_123;
    goto z_bb_29;
    z_bb_28:
    zT_119 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_119) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_124 = stack;
    zT_125 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_124, zT_125);
    goto z_bb_31;
    z_bb_31:
    zT_127 = n.child_1;
    if ((unsigned char)(zT_127 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_131 = k;
    zT_134 = zF_C395F6FD_nodeChildIsNode(zT_131, (unsigned char)(1));
    zT_130 = zT_134;
    goto z_bb_34;
    z_bb_33:
    zT_130 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_130) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_135 = stack;
    zT_136 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_135, zT_136);
    goto z_bb_36;
    z_bb_36:
    zT_138 = n.child_2;
    if ((unsigned char)(zT_138 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_142 = k;
    zT_145 = zF_C395F6FD_nodeChildIsNode(zT_142, (unsigned char)(2));
    zT_141 = zT_145;
    goto z_bb_39;
    z_bb_38:
    zT_141 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_141) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_146 = stack;
    zT_147 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_146, zT_147);
    goto z_bb_41;
    z_bb_41:
    zT_149 = k;
    zT_150 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_149);
    if (zT_150) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_152 = store;
    zT_153 = ni;
    zT_154 = zF_152E19CB_astStoreNodeExtraCh(zT_152, zT_153);
    ec3_n = zT_154;
    zT_156 = 0;
    ei3 = zT_156;
    goto z_bb_44;
    z_bb_43:
    goto z_bb_6;
    z_bb_44:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_159 = stack;
    zT_161 = store;
    zT_162 = ni;
    zT_165 = zF_B10B1BC1_astStoreNodeExtraCh(zT_161, zT_162, (unsigned int)((unsigned int)ei3));
    zT_160 = zT_165;
    zF_62F717A2_u32ArrayListAppend(zT_159, zT_160);
    goto z_bb_47;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_166 = 1;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zig_wrap_add_u(((zu64)(ei3)), ((zu64)(zT_167)), 32u);
    zT_169 = zig_overflow_flag_add_u(((zu64)(ei3)), ((zu64)(zT_167)), 32u);
    zT_171 = zT_169 == (unsigned int)(0);
    if (!(zT_171)) { pal_trap(); }
    ei3 = zT_168;
    goto z_bb_44;
}

/* emitSuspMarker */
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64 key) {
    zT_79FAE712_u64 zT_2;
    zT_79FAE712_u64 zT_3;
    unsigned char zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_5826BFC7_Arr_unsigned_char_1 zT_17;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_39;
    unsigned char* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_5826BFC7_Arr_unsigned_char_1 zT_50;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_72;
    unsigned char* zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_2 = 32;
    zT_5 = zT_2 < (unsigned int)(64);
    if (!(zT_5)) { pal_trap(); }
    zT_3 = key >> zT_2;
    zT_6 = (unsigned int)zig_cast_checked_u((zu64)zT_3, 64u, 0u, 32u);
    module_id = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    zT_10 = (unsigned int)zig_cast_checked_u((zu64)zT_9, 64u, 0u, 32u);
    name_id = zT_10;
    zT_12 = "SUSP:m";
    zT_14 = 6;
    zT_13.ptr = (unsigned char*)zT_12;
    zT_13.len = zT_14;
    m1 = zT_13;
    zT_15 = m1;
    zF_48AC7B3A_markerWrite(zT_15);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_17[_i];
        _i++;
    }
}
    zT_19 = module_id;
    zT_23 = 0;
    zT_24 = (unsigned char*)((unsigned char*)b1) + zT_23;
    zT_25 = (unsigned int)(12) - zT_23;
    zT_26.ptr = (unsigned char*)zT_24;
    zT_26.len = zT_25;
    zT_20 = zT_26;
    zT_27 = zF_A7504564_itoa(zT_19, zT_20);
    l1 = zT_27;
    zT_29 = 11;
    zT_31 = (unsigned int)(unsigned int)((unsigned int)l1);
    zT_32 = zig_wrap_sub_u(((zu64)(zT_29)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_sub_u(((zu64)(zT_29)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    s1 = zT_32;
    zT_39 = 11;
    zT_40 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_41 = zT_39 - s1;
    zT_42 = s1 <= zT_39;
    if (!(zT_42)) { pal_trap(); }
    zT_43.ptr = (unsigned char*)zT_40;
    zT_43.len = zT_41;
    zT_36 = zT_43;
    zF_48AC7B3A_markerWrite(zT_36);
    zT_45 = ":n";
    zT_47 = 2;
    zT_46.ptr = (unsigned char*)zT_45;
    zT_46.len = zT_47;
    m2 = zT_46;
    zT_48 = m2;
    zF_48AC7B3A_markerWrite(zT_48);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_50[_i];
        _i++;
    }
}
    zT_52 = name_id;
    zT_56 = 0;
    zT_57 = (unsigned char*)((unsigned char*)b2) + zT_56;
    zT_58 = (unsigned int)(12) - zT_56;
    zT_59.ptr = (unsigned char*)zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zT_60 = zF_A7504564_itoa(zT_52, zT_53);
    l2 = zT_60;
    zT_62 = 11;
    zT_64 = (unsigned int)(unsigned int)((unsigned int)l2);
    zT_65 = zig_wrap_sub_u(((zu64)(zT_62)), ((zu64)(zT_64)), 32u);
    zT_66 = zig_overflow_flag_sub_u(((zu64)(zT_62)), ((zu64)(zT_64)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    s2 = zT_65;
    zT_72 = 11;
    zT_73 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_74 = zT_72 - s2;
    zT_75 = s2 <= zT_72;
    if (!(zT_75)) { pal_trap(); }
    zT_76.ptr = (unsigned char*)zT_73;
    zT_76.len = zT_74;
    zT_69 = zT_76;
    zF_48AC7B3A_markerWrite(zT_69);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    m3 = zT_79;
    zT_81 = m3;
    zF_48AC7B3A_markerWrite(zT_81);
    return;
}

/* suspensionAnalysisRun */
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_072B53A6_ModuleRegistry* module_reg, zT_D3EB6303_StringInterner* interner, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_C4A0A7DB_U64ArrayList zT_26;
    zT_3E40CD83_Sand* zT_28;
    zT_47B162D1_U8ArrayList zT_29;
    zT_3E40CD83_Sand* zT_31;
    zT_B687BB96_U32ArrayList zT_32;
    zT_3E40CD83_Sand* zT_34;
    zT_B687BB96_U32ArrayList zT_35;
    zT_072B53A6_ModuleRegistry* zT_37;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_6E8D187B_ModuleEntry zT_48;
    unsigned int zT_49;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_55;
    zT_8143F551_AstKind zT_56;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_22A7C88B_AstNode zT_77;
    zT_8143F551_AstKind zT_78;
    zT_6B0A7D14_AstStore* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_5838FCFA_anon_324009 zT_87;
    zT_243D6A41_FnProto* zT_88;
    unsigned int zT_89;
    zT_243D6A41_FnProto zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_94;
    unsigned int zT_95;
    unsigned char zT_96;
    zT_6E8D187B_ModuleEntry zT_97;
    zT_79FAE712_u64 zT_100;
    zT_A4CE86B7_U64ToU32Map* zT_101;
    zT_79FAE712_u64 zT_102;
    zT_BAEE192E_Opt_10 zT_104;
    unsigned char zT_105;
    zT_A4CE86B7_U64ToU32Map* zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_111;
    zT_C4A0A7DB_U64ArrayList* zT_113;
    zT_79FAE712_u64 zT_114;
    zT_47B162D1_U8ArrayList* zT_116;
    int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned char zT_125;
    int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned char zT_131;
    zT_3E40CD83_Sand* zT_133;
    zT_B687BB96_U32ArrayList zT_134;
    unsigned int zT_135;
    unsigned int zT_137;
    zT_6E8D187B_ModuleEntry* zT_140;
    unsigned int zT_141;
    unsigned char zT_142;
    zT_6E8D187B_ModuleEntry zT_143;
    unsigned int zT_144;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    zT_22A7C88B_AstNode zT_150;
    zT_8143F551_AstKind zT_151;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_160;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_168;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    zT_22A7C88B_AstNode zT_172;
    zT_8143F551_AstKind zT_173;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_5838FCFA_anon_324009 zT_182;
    zT_243D6A41_FnProto* zT_183;
    unsigned int zT_184;
    zT_243D6A41_FnProto zT_185;
    unsigned int zT_187;
    unsigned int zT_188;
    zT_6E8D187B_ModuleEntry* zT_189;
    unsigned int zT_190;
    unsigned char zT_191;
    zT_6E8D187B_ModuleEntry zT_192;
    zT_79FAE712_u64 zT_195;
    zT_A4CE86B7_U64ToU32Map* zT_197;
    zT_79FAE712_u64 zT_198;
    zT_BAEE192E_Opt_10 zT_200;
    unsigned char zT_201;
    zT_6B0A7D14_AstStore* zT_203;
    zT_3D7259E2_SymbolRegistry* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_B687BB96_U32ArrayList* zT_208;
    zT_B687BB96_U32ArrayList* zT_209;
    zT_B687BB96_U32ArrayList* zT_210;
    zT_47B162D1_U8ArrayList* zT_211;
    zT_A4CE86B7_U64ToU32Map* zT_212;
    unsigned int zT_213;
    zT_6E8D187B_ModuleEntry* zT_214;
    unsigned int zT_215;
    unsigned char zT_216;
    zT_6E8D187B_ModuleEntry zT_217;
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned char zT_230;
    int zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned char zT_236;
    unsigned int zT_238;
    zT_3E40CD83_Sand* zT_242;
    unsigned int zT_243;
    unsigned int* zT_244;
    unsigned int zT_246;
    unsigned int zT_248;
    int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned char zT_254;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int* zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned char zT_268;
    unsigned int zT_269;
    int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned char zT_275;
    zT_3E40CD83_Sand* zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned char zT_283;
    unsigned int* zT_284;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    unsigned char zT_299;
    zT_3E40CD83_Sand* zT_301;
    unsigned int zT_302;
    unsigned int* zT_303;
    unsigned int zT_304;
    unsigned int zT_306;
    int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned char zT_312;
    zT_3E40CD83_Sand* zT_314;
    unsigned int zT_315;
    unsigned int* zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int* zT_322;
    unsigned int zT_323;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int* zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned char zT_334;
    unsigned int zT_335;
    int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned char zT_341;
    zT_3E40CD83_Sand* zT_343;
    unsigned int zT_344;
    unsigned int* zT_345;
    unsigned int zT_347;
    unsigned int zT_349;
    unsigned int zT_350;
    unsigned char* zT_352;
    unsigned char zT_353;
    zT_A4CE86B7_U64ToU32Map* zT_356;
    zT_79FAE712_u64 zT_357;
    zT_79FAE712_u64* zT_359;
    unsigned int zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    unsigned char zT_367;
    int zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned char zT_373;
    unsigned int zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned char zT_381;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned char zT_391;
    unsigned int zT_392;
    unsigned int zT_396;
    unsigned int zT_397;
    zT_79FAE712_u64* zT_399;
    unsigned int zT_400;
    zT_79FAE712_u64 zT_401;
    zT_A4CE86B7_U64ToU32Map* zT_402;
    zT_79FAE712_u64 zT_403;
    zT_BAEE192E_Opt_10 zT_404;
    unsigned char zT_405;
    zT_A4CE86B7_U64ToU32Map* zT_407;
    zT_79FAE712_u64 zT_408;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned char zT_415;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned char zT_420;
    unsigned int zT_422;
    unsigned int zT_423;
    zT_79FAE712_u64* zT_426;
    zT_79FAE712_u64 zT_427;
    zT_A4CE86B7_U64ToU32Map* zT_429;
    zT_79FAE712_u64 zT_430;
    zT_BAEE192E_Opt_10 zT_431;
    unsigned char zT_432;
    zT_79FAE712_u64 zT_436;
    int zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    unsigned int zT_440;
    unsigned char zT_442;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_77, (unsigned int)sizeof zT_77);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_172, (unsigned int)sizeof zT_172);
    zig_poison_fill((void*)&zT_180, (unsigned int)sizeof zT_180);
    zig_poison_fill((void*)&zT_195, (unsigned int)sizeof zT_195);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_284, (unsigned int)sizeof zT_284);
    zig_poison_fill((void*)&zT_303, (unsigned int)sizeof zT_303);
    zig_poison_fill((void*)&zT_317, (unsigned int)sizeof zT_317);
    zig_poison_fill((void*)&zT_345, (unsigned int)sizeof zT_345);
    zig_poison_fill((void*)&zT_404, (unsigned int)sizeof zT_404);
    zig_poison_fill((void*)&zT_431, (unsigned int)sizeof zT_431);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_A4CE86B7_U64ToU32Map fn_index;
    zT_C4A0A7DB_U64ArrayList fn_keys;
    zT_47B162D1_U8ArrayList direct;
    zT_B687BB96_U32ArrayList edge_caller;
    zT_B687BB96_U32ArrayList edge_callee;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_B687BB96_U32ArrayList stack;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned int ast_root2;
    unsigned int n;
    zT_22A7C88B_AstNode root2;
    unsigned int decls2_n;
    unsigned int di2;
    unsigned int decl2_idx;
    zT_22A7C88B_AstNode decl2;
    unsigned int proto_idx2;
    zT_243D6A41_FnProto proto2;
    zT_79FAE712_u64 key2;
    zT_BAEE192E_Opt_10 cidx;
    unsigned int ci0;
    unsigned int* rev_count;
    unsigned int i;
    unsigned int m;
    unsigned int e;
    unsigned int g;
    unsigned int* rev_off;
    unsigned int acc;
    unsigned int* rev_pos;
    unsigned int* rev_to;
    unsigned int g2;
    unsigned int p;
    unsigned int* queue;
    unsigned int head;
    unsigned int tail;
    unsigned int g3;
    unsigned int k0;
    unsigned int k1;
    unsigned int kk;
    unsigned int c;
    zT_79FAE712_u64 ckey;
    zT_79FAE712_u64 kk2;
    zT_BAEE192E_Opt_10 vv;
    unsigned int val2;
    zT_7 = "YA\n";
    zT_9 = 3;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    p_msg = zT_8;
    zT_10 = p_msg;
    zF_48AC7B3A_markerWrite(zT_10);
    zT_12 = "@asyncSuspend";
    zT_14 = 13;
    zT_13.ptr = (unsigned char*)zT_12;
    zT_13.len = zT_14;
    asu_text = zT_13;
    zT_16 = interner;
    zT_17 = asu_text;
    zT_18 = zF_50C274AF_stringInternerInter(zT_16, zT_17);
    async_suspend_name_id = zT_18;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    fn_index = zT_21;
    zT_23 = alloc;
    zT_26 = zF_477F0605_u64ArrayListInit(zT_23, (unsigned int)(256));
    fn_keys = zT_26;
    zT_28 = alloc;
    zT_29 = zF_E9FF0E66_byteArrayListInit(zT_28);
    direct = zT_29;
    zT_31 = alloc;
    zT_32 = zF_8E537D0C_u32ArrayListInit(zT_31);
    edge_caller = zT_32;
    zT_34 = alloc;
    zT_35 = zF_8E537D0C_u32ArrayListInit(zT_34);
    edge_callee = zT_35;
    zT_37 = module_reg;
    zT_38 = zF_3452C137_moduleRegistryGetMo(zT_37);
    mods = zT_38;
    zT_40 = 0;
    mi = zT_40;
    goto z_bb_1;
    z_bb_1:
    zT_42 = mods.len;
    if ((unsigned char)(mi < zT_42)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_45 = mods.ptr;
    zT_46 = mods.len;
    zT_47 = mi < zT_46;
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_45[mi];
    zT_49 = zT_48.ast_root;
    ast_root = zT_49;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_133 = alloc;
    zT_134 = zF_8E537D0C_u32ArrayListInit(zT_133);
    stack = zT_134;
    zT_135 = 0;
    mi = zT_135;
    goto z_bb_17;
    z_bb_4:
    zT_126 = 1;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_127)), 32u);
    zT_129 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_127)), 32u);
    zT_131 = zT_129 == (unsigned int)(0);
    if (!(zT_131)) { pal_trap(); }
    mi = zT_128;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_53 = store;
    zT_54 = ast_root;
    zT_55 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    root = zT_55;
    zT_56 = root.kind;
    if ((unsigned char)(zT_56 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_61 = store;
    zT_62 = ast_root;
    zT_63 = zF_152E19CB_astStoreNodeExtraCh(zT_61, zT_62);
    decls_n = zT_63;
    zT_65 = 0;
    di = zT_65;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_69 = store;
    zT_70 = ast_root;
    zT_73 = zF_B10B1BC1_astStoreNodeExtraCh(zT_69, zT_70, (unsigned int)((unsigned int)di));
    decl_idx = zT_73;
    zT_75 = store;
    zT_76 = decl_idx;
    zT_77 = zF_FCDD1D35_astStoreNodeAt(zT_75, zT_76);
    decl = zT_77;
    zT_78 = decl.kind;
    if ((unsigned char)(zT_78 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_120 = 1;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_121)), 32u);
    zT_123 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_121)), 32u);
    zT_125 = zT_123 == (unsigned int)(0);
    if (!(zT_125)) { pal_trap(); }
    di = zT_122;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_83 = store;
    zT_84 = decl_idx;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_83, zT_84);
    proto_idx = zT_85;
    zT_87 = store->fn_protos;
    zT_88 = zT_87.items;
    zT_89 = (unsigned int)proto_idx;
    zT_90 = zT_88[zT_89];
    proto = zT_90;
    zT_94 = mods.ptr;
    zT_95 = mods.len;
    zT_96 = mi < zT_95;
    if (!(zT_96)) { pal_trap(); }
    zT_97 = zT_94[mi];
    zT_92 = zT_97.id;
    zT_93 = proto.name_id;
    zT_100 = zF_9D041EB6_asyncKey(zT_92, zT_93);
    key = zT_100;
    zT_101 = (zT_A4CE86B7_U64ToU32Map*)&fn_index;
    zT_102 = key;
    zT_104 = zF_A05A7BE1_u64ToU32MapGet(zT_101, zT_102);
    zT_105 = zT_104.has_value;
    if ((unsigned char)(!zT_105)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_107 = (zT_A4CE86B7_U64ToU32Map*)&fn_index;
    zT_108 = key;
    zT_111 = fn_keys.len;
    zF_B6EB812C_u64ToU32MapPut(zT_107, zT_108, (unsigned int)((unsigned int)zT_111));
    zT_113 = (zT_C4A0A7DB_U64ArrayList*)&fn_keys;
    zT_114 = key;
    zF_A553AD3B_u64ArrayListAppend(zT_113, zT_114);
    zT_116 = (zT_47B162D1_U8ArrayList*)&direct;
    zF_463FE7A4_byteArrayListAppend(zT_116, (unsigned char)(0));
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    zT_137 = mods.len;
    if ((unsigned char)(mi < zT_137)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_140 = mods.ptr;
    zT_141 = mods.len;
    zT_142 = mi < zT_141;
    if (!(zT_142)) { pal_trap(); }
    zT_143 = zT_140[mi];
    zT_144 = zT_143.ast_root;
    ast_root2 = zT_144;
    if ((unsigned char)(ast_root2 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_238 = fn_keys.len;
    n = zT_238;
    if ((unsigned char)(n > (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_20:
    zT_231 = 1;
    zT_232 = (unsigned int)zT_231;
    zT_233 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_232)), 32u);
    zT_234 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_232)), 32u);
    zT_236 = zT_234 == (unsigned int)(0);
    if (!(zT_236)) { pal_trap(); }
    mi = zT_233;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_148 = store;
    zT_149 = ast_root2;
    zT_150 = zF_FCDD1D35_astStoreNodeAt(zT_148, zT_149);
    root2 = zT_150;
    zT_151 = root2.kind;
    if ((unsigned char)(zT_151 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_156 = store;
    zT_157 = ast_root2;
    zT_158 = zF_152E19CB_astStoreNodeExtraCh(zT_156, zT_157);
    decls2_n = zT_158;
    zT_160 = 0;
    di2 = zT_160;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(di2 < (unsigned int)((unsigned int)decls2_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_164 = store;
    zT_165 = ast_root2;
    zT_168 = zF_B10B1BC1_astStoreNodeExtraCh(zT_164, zT_165, (unsigned int)((unsigned int)di2));
    decl2_idx = zT_168;
    zT_170 = store;
    zT_171 = decl2_idx;
    zT_172 = zF_FCDD1D35_astStoreNodeAt(zT_170, zT_171);
    decl2 = zT_172;
    zT_173 = decl2.kind;
    if ((unsigned char)(zT_173 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_225 = 1;
    zT_226 = (unsigned int)zT_225;
    zT_227 = zig_wrap_add_u(((zu64)(di2)), ((zu64)(zT_226)), 32u);
    zT_228 = zig_overflow_flag_add_u(((zu64)(di2)), ((zu64)(zT_226)), 32u);
    zT_230 = zT_228 == (unsigned int)(0);
    if (!(zT_230)) { pal_trap(); }
    di2 = zT_227;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_178 = store;
    zT_179 = decl2_idx;
    zT_180 = zF_8BA26B9E_astStoreNodePayload(zT_178, zT_179);
    proto_idx2 = zT_180;
    zT_182 = store->fn_protos;
    zT_183 = zT_182.items;
    zT_184 = (unsigned int)proto_idx2;
    zT_185 = zT_183[zT_184];
    proto2 = zT_185;
    zT_189 = mods.ptr;
    zT_190 = mods.len;
    zT_191 = mi < zT_190;
    if (!(zT_191)) { pal_trap(); }
    zT_192 = zT_189[mi];
    zT_187 = zT_192.id;
    zT_188 = proto2.name_id;
    zT_195 = zF_9D041EB6_asyncKey(zT_187, zT_188);
    key2 = zT_195;
    zT_197 = (zT_A4CE86B7_U64ToU32Map*)&fn_index;
    zT_198 = key2;
    zT_200 = zF_A05A7BE1_u64ToU32MapGet(zT_197, zT_198);
    cidx = zT_200;
    zT_201 = cidx.has_value;
    if (zT_201) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    if (!(cidx.has_value)) { pal_trap(); }
    ci0 = cidx.value;
    zT_203 = store;
    zT_204 = sym_reg;
    zT_214 = mods.ptr;
    zT_215 = mods.len;
    zT_216 = mi < zT_215;
    if (!(zT_216)) { pal_trap(); }
    zT_217 = zT_214[mi];
    zT_205 = zT_217.id;
    zT_206 = ci0;
    zT_207 = decl2.child_0;
    zT_208 = (zT_B687BB96_U32ArrayList*)&stack;
    zT_209 = (zT_B687BB96_U32ArrayList*)&edge_caller;
    zT_210 = (zT_B687BB96_U32ArrayList*)&edge_callee;
    zT_211 = (zT_47B162D1_U8ArrayList*)&direct;
    zT_212 = (zT_A4CE86B7_U64ToU32Map*)&fn_index;
    zT_213 = async_suspend_name_id;
    zF_32651930_scanFunction(zT_203, zT_204, zT_205, zT_206, zT_207, zT_208, zT_209, zT_210, zT_211, zT_212, zT_213);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_242 = alloc;
    zT_243 = n;
    zT_244 = zF_43BEEDA4_allocU32(zT_242, zT_243);
    rev_count = zT_244;
    zT_246 = 0;
    i = zT_246;
    goto z_bb_35;
    z_bb_34:
    zT_422 = 0;
    m = zT_422;
    goto z_bb_71;
    z_bb_35:
    if ((unsigned char)(i < n)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_248 = 0;
    rev_count[i] = zT_248;
    goto z_bb_38;
    z_bb_37:
    zT_256 = 0;
    e = zT_256;
    goto z_bb_39;
    z_bb_38:
    zT_249 = 1;
    zT_250 = (unsigned int)zT_249;
    zT_251 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_250)), 32u);
    zT_252 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_250)), 32u);
    zT_254 = zT_252 == (unsigned int)(0);
    if (!(zT_254)) { pal_trap(); }
    i = zT_251;
    goto z_bb_35;
    z_bb_39:
    zT_257 = edge_callee.len;
    if ((unsigned char)(e < zT_257)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_260 = edge_callee.items;
    zT_261 = zT_260[e];
    g = zT_261;
    zT_262 = (unsigned int)g;
    zT_263 = rev_count[zT_262];
    zT_264 = 1;
    zT_265 = zig_wrap_add_u(((zu64)(zT_263)), ((zu64)(zT_264)), 32u);
    zT_266 = zig_overflow_flag_add_u(((zu64)(zT_263)), ((zu64)(zT_264)), 32u);
    zT_268 = zT_266 == (unsigned int)(0);
    if (!(zT_268)) { pal_trap(); }
    zT_269 = (unsigned int)g;
    rev_count[zT_269] = zT_265;
    goto z_bb_42;
    z_bb_41:
    zT_277 = alloc;
    zT_279 = 1;
    zT_280 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_279)), 32u);
    zT_281 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_279)), 32u);
    zT_283 = zT_281 == (unsigned int)(0);
    if (!(zT_283)) { pal_trap(); }
    zT_278 = zT_280;
    zT_284 = zF_43BEEDA4_allocU32(zT_277, zT_278);
    rev_off = zT_284;
    zT_286 = 0;
    acc = zT_286;
    zT_287 = 0;
    i = zT_287;
    goto z_bb_43;
    z_bb_42:
    zT_270 = 1;
    zT_271 = (unsigned int)zT_270;
    zT_272 = zig_wrap_add_u(((zu64)(e)), ((zu64)(zT_271)), 32u);
    zT_273 = zig_overflow_flag_add_u(((zu64)(e)), ((zu64)(zT_271)), 32u);
    zT_275 = zT_273 == (unsigned int)(0);
    if (!(zT_275)) { pal_trap(); }
    e = zT_272;
    goto z_bb_39;
    z_bb_43:
    if ((unsigned char)(i < n)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    rev_off[i] = acc;
    zT_289 = rev_count[i];
    zT_290 = zig_wrap_add_u(((zu64)(acc)), ((zu64)(zT_289)), 32u);
    zT_291 = zig_overflow_flag_add_u(((zu64)(acc)), ((zu64)(zT_289)), 32u);
    zT_293 = zT_291 == (unsigned int)(0);
    if (!(zT_293)) { pal_trap(); }
    acc = zT_290;
    goto z_bb_46;
    z_bb_45:
    rev_off[n] = acc;
    zT_301 = alloc;
    zT_302 = n;
    zT_303 = zF_43BEEDA4_allocU32(zT_301, zT_302);
    rev_pos = zT_303;
    zT_304 = 0;
    i = zT_304;
    goto z_bb_47;
    z_bb_46:
    zT_294 = 1;
    zT_295 = (unsigned int)zT_294;
    zT_296 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_295)), 32u);
    zT_297 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_295)), 32u);
    zT_299 = zT_297 == (unsigned int)(0);
    if (!(zT_299)) { pal_trap(); }
    i = zT_296;
    goto z_bb_43;
    z_bb_47:
    if ((unsigned char)(i < n)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_306 = rev_off[i];
    rev_pos[i] = zT_306;
    goto z_bb_50;
    z_bb_49:
    zT_314 = alloc;
    zT_315 = edge_callee.len;
    zT_317 = zF_43BEEDA4_allocU32(zT_314, zT_315);
    rev_to = zT_317;
    zT_318 = 0;
    e = zT_318;
    goto z_bb_51;
    z_bb_50:
    zT_307 = 1;
    zT_308 = (unsigned int)zT_307;
    zT_309 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_308)), 32u);
    zT_310 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_308)), 32u);
    zT_312 = zT_310 == (unsigned int)(0);
    if (!(zT_312)) { pal_trap(); }
    i = zT_309;
    goto z_bb_47;
    z_bb_51:
    zT_319 = edge_callee.len;
    if ((unsigned char)(e < zT_319)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_322 = edge_callee.items;
    zT_323 = zT_322[e];
    g2 = zT_323;
    zT_325 = (unsigned int)g2;
    zT_326 = rev_pos[zT_325];
    p = zT_326;
    zT_327 = edge_caller.items;
    zT_328 = zT_327[e];
    zT_329 = (unsigned int)p;
    rev_to[zT_329] = zT_328;
    zT_330 = 1;
    zT_331 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_330)), 32u);
    zT_332 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_330)), 32u);
    zT_334 = zT_332 == (unsigned int)(0);
    if (!(zT_334)) { pal_trap(); }
    zT_335 = (unsigned int)g2;
    rev_pos[zT_335] = zT_331;
    goto z_bb_54;
    z_bb_53:
    zT_343 = alloc;
    zT_344 = n;
    zT_345 = zF_43BEEDA4_allocU32(zT_343, zT_344);
    queue = zT_345;
    zT_347 = 0;
    head = zT_347;
    zT_349 = 0;
    tail = zT_349;
    zT_350 = 0;
    i = zT_350;
    goto z_bb_55;
    z_bb_54:
    zT_336 = 1;
    zT_337 = (unsigned int)zT_336;
    zT_338 = zig_wrap_add_u(((zu64)(e)), ((zu64)(zT_337)), 32u);
    zT_339 = zig_overflow_flag_add_u(((zu64)(e)), ((zu64)(zT_337)), 32u);
    zT_341 = zT_339 == (unsigned int)(0);
    if (!(zT_341)) { pal_trap(); }
    e = zT_338;
    goto z_bb_51;
    z_bb_55:
    if ((unsigned char)(i < n)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_352 = direct.items;
    zT_353 = zT_352[i];
    if ((unsigned char)(zT_353 != (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    goto z_bb_61;
    z_bb_58:
    zT_368 = 1;
    zT_369 = (unsigned int)zT_368;
    zT_370 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_369)), 32u);
    zT_371 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_369)), 32u);
    zT_373 = zT_371 == (unsigned int)(0);
    if (!(zT_373)) { pal_trap(); }
    i = zT_370;
    goto z_bb_55;
    z_bb_59:
    zT_356 = suspending_fns;
    zT_359 = fn_keys.items;
    zT_357 = zT_359[i];
    zF_B6EB812C_u64ToU32MapPut(zT_356, zT_357, (unsigned int)(1));
    zT_362 = (unsigned int)i;
    queue[tail] = zT_362;
    zT_363 = 1;
    zT_364 = zig_wrap_add_u(((zu64)(tail)), ((zu64)(zT_363)), 32u);
    zT_365 = zig_overflow_flag_add_u(((zu64)(tail)), ((zu64)(zT_363)), 32u);
    zT_367 = zT_365 == (unsigned int)(0);
    if (!(zT_367)) { pal_trap(); }
    tail = zT_364;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    if ((unsigned char)(head < tail)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_376 = queue[head];
    g3 = zT_376;
    zT_377 = 1;
    zT_378 = zig_wrap_add_u(((zu64)(head)), ((zu64)(zT_377)), 32u);
    zT_379 = zig_overflow_flag_add_u(((zu64)(head)), ((zu64)(zT_377)), 32u);
    zT_381 = zT_379 == (unsigned int)(0);
    if (!(zT_381)) { pal_trap(); }
    head = zT_378;
    zT_383 = (unsigned int)g3;
    zT_384 = rev_off[zT_383];
    k0 = zT_384;
    zT_386 = (unsigned int)g3;
    zT_387 = 1;
    zT_388 = zig_wrap_add_u(((zu64)(zT_386)), ((zu64)(zT_387)), 32u);
    zT_389 = zig_overflow_flag_add_u(((zu64)(zT_386)), ((zu64)(zT_387)), 32u);
    zT_391 = zT_389 == (unsigned int)(0);
    if (!(zT_391)) { pal_trap(); }
    zT_392 = rev_off[zT_388];
    k1 = zT_392;
    kk = k0;
    goto z_bb_65;
    z_bb_63:
    goto z_bb_34;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    if ((unsigned char)(kk < k1)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_396 = (unsigned int)kk;
    zT_397 = rev_to[zT_396];
    c = zT_397;
    zT_399 = fn_keys.items;
    zT_400 = (unsigned int)c;
    zT_401 = zT_399[zT_400];
    ckey = zT_401;
    zT_402 = suspending_fns;
    zT_403 = ckey;
    zT_404 = zF_A05A7BE1_u64ToU32MapGet(zT_402, zT_403);
    zT_405 = zT_404.has_value;
    if ((unsigned char)(!zT_405)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_416 = 1;
    zT_417 = zig_wrap_add_u(((zu64)(kk)), ((zu64)(zT_416)), 32u);
    zT_418 = zig_overflow_flag_add_u(((zu64)(kk)), ((zu64)(zT_416)), 32u);
    zT_420 = zT_418 == (unsigned int)(0);
    if (!(zT_420)) { pal_trap(); }
    kk = zT_417;
    goto z_bb_65;
    z_bb_69:
    zT_407 = suspending_fns;
    zT_408 = ckey;
    zF_B6EB812C_u64ToU32MapPut(zT_407, zT_408, (unsigned int)(1));
    queue[tail] = c;
    zT_411 = 1;
    zT_412 = zig_wrap_add_u(((zu64)(tail)), ((zu64)(zT_411)), 32u);
    zT_413 = zig_overflow_flag_add_u(((zu64)(tail)), ((zu64)(zT_411)), 32u);
    zT_415 = zT_413 == (unsigned int)(0);
    if (!(zT_415)) { pal_trap(); }
    tail = zT_412;
    goto z_bb_70;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_423 = fn_keys.len;
    if ((unsigned char)(m < zT_423)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_426 = fn_keys.items;
    zT_427 = zT_426[m];
    kk2 = zT_427;
    zT_429 = suspending_fns;
    zT_430 = kk2;
    zT_431 = zF_A05A7BE1_u64ToU32MapGet(zT_429, zT_430);
    vv = zT_431;
    zT_432 = vv.has_value;
    if (zT_432) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return;
    z_bb_74:
    zT_437 = 1;
    zT_438 = (unsigned int)zT_437;
    zT_439 = zig_wrap_add_u(((zu64)(m)), ((zu64)(zT_438)), 32u);
    zT_440 = zig_overflow_flag_add_u(((zu64)(m)), ((zu64)(zT_438)), 32u);
    zT_442 = zT_440 == (unsigned int)(0);
    if (!(zT_442)) { pal_trap(); }
    m = zT_439;
    goto z_bb_71;
    z_bb_75:
    if (!(vv.has_value)) { pal_trap(); }
    val2 = vv.value;
    if ((unsigned char)(val2 != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_436 = kk2;
    zF_76D5E8D3_emitSuspMarker(zT_436);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_2 = zig_wrap_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_3 = zig_overflow_flag_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_5 = zT_3 == (unsigned int)(0);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = 1;
    zT_12 = zig_wrap_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    return (unsigned int)(zT_7 & (unsigned int)(~zT_12));
}

/* frameFieldSizeAlign */
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned short zT_19;
    unsigned short zT_22;
    unsigned int zT_23;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    zT_19 = t.alignment;
    if ((unsigned char)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_22 = t.alignment;
    zT_23 = (unsigned int)zT_22;
    al = zT_23;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* addFrameField */
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned int sz;
    unsigned int al;
    unsigned int at;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_8 = reg;
    zT_9 = tid;
    zT_10 = (unsigned int*)&sz;
    zT_11 = (unsigned int*)&al;
    zF_816D1610_frameFieldSizeAlign(zT_8, zT_9, zT_10, zT_11);
    zT_14 = *offset;
    zT_15 = al;
    zT_17 = zF_978D7C93_alignUpU32(zT_14, zT_15);
    *offset = zT_17;
    zT_19 = *offset;
    at = zT_19;
    zT_20 = *offset;
    zT_21 = zig_wrap_add_u(((zu64)(zT_20)), ((zu64)(sz)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(zT_20)), ((zu64)(sz)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    *offset = zT_21;
    zT_25 = *max_align;
    if ((unsigned char)(al > zT_25)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = al;
    goto z_bb_2;
    z_bb_2:
    return at;
}

/* typeIsPtrVoid */
unsigned char zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_112BF819_PtrPayload zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_16 = reg->ptr_items;
    zT_17 = t.payload_idx;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zT_16[zT_18];
    zT_20 = zT_19.base;
    base = zT_20;
    return (unsigned char)(base == (unsigned int)(1));
}

/* frameLocalTypeId */
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable* resolved_types, zT_22A7C88B_AstNode n) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8;
    unsigned char zT_9;
    unsigned int zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_17;
    unsigned char zT_18;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned int t;
    zT_2 = n.child_0;
    if ((unsigned char)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_5 = resolved_types;
    zT_6 = n.child_0;
    zT_8 = zF_999DCF51_resolvedTypeTableGe(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    return (unsigned int)(18);
    z_bb_3:
    zT_11 = n.child_1;
    if ((unsigned char)(zT_11 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    if (!(zT_8.has_value)) { pal_trap(); }
    t = zT_8.value;
    return t;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_14 = resolved_types;
    zT_15 = n.child_1;
    zT_17 = zF_999DCF51_resolvedTypeTableGe(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    goto z_bb_2;
    z_bb_8:
    if (!(zT_17.has_value)) { pal_trap(); }
    t = zT_17.value;
    return t;
    z_bb_9:
    goto z_bb_7;
}

/* scanFrameLocals */
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore* store, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_338B7C76_TypeRegistry* reg, zT_8EED1867_ResolvedTypeTable* resolved_types, unsigned int* offset, unsigned int* max_align) {
    zT_B687BB96_U32ArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33;
    zT_8143F551_AstKind zT_35;
    unsigned int zT_37;
    zT_8EED1867_ResolvedTypeTable* zT_38;
    unsigned int zT_39;
    zT_BAEE192E_Opt_10 zT_40;
    unsigned char zT_41;
    unsigned char zT_45;
    zT_8EED1867_ResolvedTypeTable* zT_49;
    zT_22A7C88B_AstNode zT_50;
    unsigned int zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    unsigned int* zT_54;
    unsigned int* zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    zT_B687BB96_U32ArrayList* zT_73;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_88;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    zT_B687BB96_U32ArrayList* zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_B687BB96_U32ArrayList* zT_106;
    unsigned int zT_107;
    zT_8143F551_AstKind zT_109;
    unsigned char zT_110;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    zT_B687BB96_U32ArrayList* zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_134;
    zT_8143F551_AstKind zT_135;
    unsigned char zT_138;
    zT_B687BB96_U32ArrayList* zT_139;
    unsigned int zT_140;
    unsigned int zT_142;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_149;
    zT_B687BB96_U32ArrayList* zT_150;
    unsigned int zT_151;
    unsigned int zT_153;
    unsigned char zT_156;
    zT_8143F551_AstKind zT_157;
    unsigned char zT_160;
    zT_B687BB96_U32ArrayList* zT_161;
    unsigned int zT_162;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_110, (unsigned int)sizeof zT_110);
    zig_poison_fill((void*)&zT_114, (unsigned int)sizeof zT_114);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_138, (unsigned int)sizeof zT_138);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_160, (unsigned int)sizeof zT_160);
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int lvt;
    unsigned int t;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    unsigned int ec3_n;
    unsigned int ei3;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = stack;
    zT_11 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_10, zT_11);
    goto z_bb_3;
    z_bb_3:
    zT_12 = stack->len;
    if ((unsigned char)(zT_12 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = stack->items;
    zT_17 = stack->len;
    zT_18 = 1;
    zT_19 = zig_wrap_sub_u(((zu64)(zT_17)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_sub_u(((zu64)(zT_17)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    zT_23 = zT_16[zT_19];
    ni = zT_23;
    zT_24 = stack->len;
    zT_25 = 1;
    zT_26 = zig_wrap_sub_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_sub_u(((zu64)(zT_24)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    stack->len = zT_26;
    zT_31 = store;
    zT_32 = ni;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    n = zT_33;
    zT_35 = n.kind;
    k = zT_35;
    zT_37 = 18;
    lvt = zT_37;
    zT_38 = resolved_types;
    zT_39 = ni;
    zT_40 = zF_999DCF51_resolvedTypeTableGe(zT_38, zT_39);
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    if (!(zT_40.has_value)) { pal_trap(); }
    t = zT_40.value;
    lvt = t;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(lvt == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_45 = k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_11;
    z_bb_10:
    zT_45 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_45) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = resolved_types;
    zT_50 = n;
    zT_51 = zF_436F92E0_frameLocalTypeId(zT_49, zT_50);
    lvt = zT_51;
    goto z_bb_13;
    z_bb_13:
    zT_52 = reg;
    zT_53 = lvt;
    zT_54 = offset;
    zT_55 = max_align;
    zT_56 = zF_769CB99B_addFrameField(zT_52, zT_53, zT_54, zT_55);
    (void)zT_56;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_61 = store;
    zT_62 = ni;
    zT_63 = zF_152E19CB_astStoreNodeExtraCh(zT_61, zT_62);
    ecb_n = zT_63;
    zT_65 = (unsigned int)ecb_n;
    bi = zT_65;
    goto z_bb_16;
    z_bb_15:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_20; else goto z_bb_21;
    z_bb_16:
    if ((unsigned char)(bi > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_68 = 1;
    zT_69 = zig_wrap_sub_u(((zu64)(bi)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_sub_u(((zu64)(bi)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    bi = zT_69;
    zT_73 = stack;
    zT_75 = store;
    zT_76 = ni;
    zT_79 = zF_B10B1BC1_astStoreNodeExtraCh(zT_75, zT_76, (unsigned int)((unsigned int)bi));
    zT_74 = zT_79;
    zF_62F717A2_u32ArrayListAppend(zT_73, zT_74);
    goto z_bb_19;
    z_bb_18:
    goto z_bb_6;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_84 = store;
    zT_85 = ni;
    zT_86 = zF_152E19CB_astStoreNodeExtraCh(zT_84, zT_85);
    ecf_n = zT_86;
    zT_88 = (unsigned int)ecf_n;
    fi = zT_88;
    goto z_bb_22;
    z_bb_21:
    zT_109 = k;
    zT_110 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_109);
    if (zT_110) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    if ((unsigned char)(fi > (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_91 = 1;
    zT_92 = zig_wrap_sub_u(((zu64)(fi)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_sub_u(((zu64)(fi)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    fi = zT_92;
    zT_96 = stack;
    zT_98 = store;
    zT_99 = ni;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)fi));
    zT_97 = zT_102;
    zF_62F717A2_u32ArrayListAppend(zT_96, zT_97);
    goto z_bb_25;
    z_bb_24:
    zT_103 = n.child_0;
    if ((unsigned char)(zT_103 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_106 = stack;
    zT_107 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_106, zT_107);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_112 = store;
    zT_113 = ni;
    zT_114 = zF_152E19CB_astStoreNodeExtraCh(zT_112, zT_113);
    ec3_n = zT_114;
    zT_116 = (unsigned int)ec3_n;
    ei3 = zT_116;
    goto z_bb_30;
    z_bb_29:
    zT_131 = n.child_2;
    if ((unsigned char)(zT_131 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((unsigned char)(ei3 > (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_119 = 1;
    zT_120 = zig_wrap_sub_u(((zu64)(ei3)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_sub_u(((zu64)(ei3)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    ei3 = zT_120;
    zT_124 = stack;
    zT_126 = store;
    zT_127 = ni;
    zT_130 = zF_B10B1BC1_astStoreNodeExtraCh(zT_126, zT_127, (unsigned int)((unsigned int)ei3));
    zT_125 = zT_130;
    zF_62F717A2_u32ArrayListAppend(zT_124, zT_125);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_135 = k;
    zT_138 = zF_C395F6FD_nodeChildIsNode(zT_135, (unsigned char)(2));
    zT_134 = zT_138;
    goto z_bb_36;
    z_bb_35:
    zT_134 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_134) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_139 = stack;
    zT_140 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_139, zT_140);
    goto z_bb_38;
    z_bb_38:
    zT_142 = n.child_1;
    if ((unsigned char)(zT_142 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_146 = k;
    zT_149 = zF_C395F6FD_nodeChildIsNode(zT_146, (unsigned char)(1));
    zT_145 = zT_149;
    goto z_bb_41;
    z_bb_40:
    zT_145 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_145) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_150 = stack;
    zT_151 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_150, zT_151);
    goto z_bb_43;
    z_bb_43:
    zT_153 = n.child_0;
    if ((unsigned char)(zT_153 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_157 = k;
    zT_160 = zF_C395F6FD_nodeChildIsNode(zT_157, (unsigned char)(0));
    zT_156 = zT_160;
    goto z_bb_46;
    z_bb_45:
    zT_156 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_156) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_161 = stack;
    zT_162 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_161, zT_162);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_6;
}

/* scanImplicitAwaits */
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, zT_79FAE712_u64 caller_key, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* fn_ret_types, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* hidden_fns, zT_B687BB96_U32ArrayList* parent_type_list, zT_A4CE86B7_U64ToU32Map* parent_start, zT_A4CE86B7_U64ToU32Map* parent_count) {
    zT_B687BB96_U32ArrayList* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_39;
    zT_8143F551_AstKind zT_41;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_BBEE1AC1_Opt_11 zT_53;
    unsigned char zT_54;
    zT_79FAE712_u64 zT_57;
    zT_79FAE712_u64 zT_58;
    unsigned char zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_64;
    unsigned int zT_65;
    zT_A4CE86B7_U64ToU32Map* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_69;
    zT_A4CE86B7_U64ToU32Map* zT_70;
    zT_79FAE712_u64 zT_71;
    unsigned int zT_75;
    zT_A4CE86B7_U64ToU32Map* zT_76;
    zT_79FAE712_u64 zT_77;
    zT_BAEE192E_Opt_10 zT_78;
    unsigned char zT_79;
    unsigned int zT_82;
    unsigned int zT_84;
    zT_A4CE86B7_U64ToU32Map* zT_85;
    zT_79FAE712_u64 zT_86;
    zT_BAEE192E_Opt_10 zT_87;
    unsigned char zT_88;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_A4CE86B7_U64ToU32Map* zT_96;
    zT_79FAE712_u64 zT_97;
    zT_BAEE192E_Opt_10 zT_98;
    unsigned char zT_99;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    unsigned int zT_106;
    zT_B687BB96_U32ArrayList* zT_108;
    unsigned int zT_109;
    zT_A4CE86B7_U64ToU32Map* zT_110;
    zT_79FAE712_u64 zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned char zT_117;
    zT_A4CE86B7_U64ToU32Map* zT_118;
    zT_79FAE712_u64 zT_119;
    unsigned int zT_120;
    zT_B687BB96_U32ArrayList* zT_121;
    unsigned int zT_122;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_B687BB96_U32ArrayList* zT_132;
    unsigned int zT_133;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    unsigned int zT_138;
    int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_144;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_153;
    zT_B687BB96_U32ArrayList* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_162;
    int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned char zT_168;
    unsigned int zT_169;
    unsigned char zT_172;
    zT_8143F551_AstKind zT_173;
    unsigned char zT_176;
    zT_B687BB96_U32ArrayList* zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned char zT_183;
    zT_8143F551_AstKind zT_184;
    unsigned char zT_187;
    zT_B687BB96_U32ArrayList* zT_188;
    unsigned int zT_189;
    unsigned int zT_191;
    unsigned char zT_194;
    zT_8143F551_AstKind zT_195;
    unsigned char zT_198;
    zT_B687BB96_U32ArrayList* zT_199;
    unsigned int zT_200;
    zT_8143F551_AstKind zT_202;
    unsigned char zT_203;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_209;
    zT_B687BB96_U32ArrayList* zT_212;
    unsigned int zT_213;
    zT_6B0A7D14_AstStore* zT_214;
    unsigned int zT_215;
    unsigned int zT_218;
    int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned char zT_224;
    zT_A4CE86B7_U64ToU32Map* zT_225;
    zT_79FAE712_u64 zT_226;
    zT_BAEE192E_Opt_10 zT_227;
    unsigned char zT_228;
    zT_A4CE86B7_U64ToU32Map* zT_232;
    zT_79FAE712_u64 zT_233;
    zT_BAEE192E_Opt_10 zT_234;
    unsigned char zT_235;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned char zT_245;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int* zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned char zT_255;
    unsigned int zT_256;
    unsigned int* zT_257;
    unsigned int* zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned char zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned char zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned char zT_273;
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_127, (unsigned int)sizeof zT_127);
    zig_poison_fill((void*)&zT_138, (unsigned int)sizeof zT_138);
    zig_poison_fill((void*)&zT_151, (unsigned int)sizeof zT_151);
    zig_poison_fill((void*)&zT_162, (unsigned int)sizeof zT_162);
    zig_poison_fill((void*)&zT_176, (unsigned int)sizeof zT_176);
    zig_poison_fill((void*)&zT_187, (unsigned int)sizeof zT_187);
    zig_poison_fill((void*)&zT_198, (unsigned int)sizeof zT_198);
    zig_poison_fill((void*)&zT_203, (unsigned int)sizeof zT_203);
    zig_poison_fill((void*)&zT_207, (unsigned int)sizeof zT_207);
    zig_poison_fill((void*)&zT_218, (unsigned int)sizeof zT_218);
    zig_poison_fill((void*)&zT_227, (unsigned int)sizeof zT_227);
    zig_poison_fill((void*)&zT_234, (unsigned int)sizeof zT_234);
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ec_n;
    unsigned int ei;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int hf;
    unsigned int old;
    unsigned int rt;
    unsigned int r;
    unsigned int pc;
    unsigned int oldc;
    unsigned int ec2_n;
    unsigned int ei2;
    unsigned int ec3_n;
    unsigned int ei3;
    unsigned int ps;
    unsigned int lo;
    unsigned int hi;
    unsigned int tmp;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_16 = stack;
    zT_17 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_16, zT_17);
    goto z_bb_3;
    z_bb_3:
    zT_18 = stack->len;
    if ((unsigned char)(zT_18 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = stack->items;
    zT_23 = stack->len;
    zT_24 = 1;
    zT_25 = zig_wrap_sub_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_sub_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_29 = zT_22[zT_25];
    ni = zT_29;
    zT_30 = stack->len;
    zT_31 = 1;
    zT_32 = zig_wrap_sub_u(((zu64)(zT_30)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_sub_u(((zu64)(zT_30)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    stack->len = zT_32;
    zT_37 = store;
    zT_38 = ni;
    zT_39 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    n = zT_39;
    zT_41 = n.kind;
    k = zT_41;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_225 = parent_count;
    zT_226 = caller_key;
    zT_227 = zF_A05A7BE1_u64ToU32MapGet(zT_225, zT_226);
    zT_228 = zT_227.has_value;
    if (zT_228) goto z_bb_56; else goto z_bb_57;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_45 = n.child_0;
    if ((unsigned char)(zT_45 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_9:
    zT_48 = store;
    zT_49 = sym_reg;
    zT_50 = module_id;
    zT_51 = n.child_0;
    zT_53 = zF_860C82EC_resolveCalleeKey(zT_48, zT_49, zT_50, zT_51);
    zT_54 = zT_53.has_value;
    if (zT_54) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_125 = store;
    zT_126 = ni;
    zT_127 = zF_152E19CB_astStoreNodeExtraCh(zT_125, zT_126);
    ec_n = zT_127;
    zT_129 = 0;
    ei = zT_129;
    goto z_bb_25;
    z_bb_11:
    if (!(zT_53.has_value)) { pal_trap(); }
    ck = zT_53.value;
    zT_57 = 32;
    zT_60 = zT_57 < (unsigned int)(64);
    if (!(zT_60)) { pal_trap(); }
    zT_58 = ck >> zT_57;
    zT_61 = (unsigned int)zig_cast_checked_u((zu64)zT_58, 64u, 0u, 32u);
    cmid = zT_61;
    zT_64 = ck & (zT_79FAE712_u64)(4294967295u);
    zT_65 = (unsigned int)zig_cast_checked_u((zu64)zT_64, 64u, 0u, 32u);
    cnid = zT_65;
    zT_66 = suspending_fns;
    zT_67 = cmid;
    zT_68 = cnid;
    zT_69 = zF_7C7E43BF_asyncIsSuspending(zT_66, zT_67, zT_68);
    if (zT_69) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_121 = stack;
    zT_122 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_121, zT_122);
    goto z_bb_10;
    z_bb_13:
    zT_70 = awaited_fns;
    zT_71 = ck;
    zF_B6EB812C_u64ToU32MapPut(zT_70, zT_71, (unsigned int)(1));
    zT_75 = 1;
    hf = zT_75;
    zT_76 = hidden_fns;
    zT_77 = caller_key;
    zT_78 = zF_A05A7BE1_u64ToU32MapGet(zT_76, zT_77);
    zT_79 = zT_78.has_value;
    if (zT_79) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if (!(zT_78.has_value)) { pal_trap(); }
    old = zT_78.value;
    zT_82 = old | (unsigned int)(1);
    hf = zT_82;
    goto z_bb_16;
    z_bb_16:
    zT_84 = 1;
    rt = zT_84;
    zT_85 = fn_ret_types;
    zT_86 = ck;
    zT_87 = zF_A05A7BE1_u64ToU32MapGet(zT_85, zT_86);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    if (!(zT_87.has_value)) { pal_trap(); }
    r = zT_87.value;
    rt = r;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(rt != (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_93 = hf | (unsigned int)(2);
    hf = zT_93;
    zT_95 = 0;
    pc = zT_95;
    zT_96 = parent_count;
    zT_97 = caller_key;
    zT_98 = zF_A05A7BE1_u64ToU32MapGet(zT_96, zT_97);
    zT_99 = zT_98.has_value;
    if (zT_99) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_118 = hidden_fns;
    zT_119 = caller_key;
    zT_120 = hf;
    zF_B6EB812C_u64ToU32MapPut(zT_118, zT_119, zT_120);
    goto z_bb_14;
    z_bb_21:
    if (!(zT_98.has_value)) { pal_trap(); }
    oldc = zT_98.value;
    pc = oldc;
    goto z_bb_22;
    z_bb_22:
    if ((unsigned char)(pc == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_103 = parent_start;
    zT_104 = caller_key;
    zT_106 = parent_type_list->len;
    zF_B6EB812C_u64ToU32MapPut(zT_103, zT_104, (unsigned int)((unsigned int)zT_106));
    goto z_bb_24;
    z_bb_24:
    zT_108 = parent_type_list;
    zT_109 = rt;
    zF_62F717A2_u32ArrayListAppend(zT_108, zT_109);
    zT_110 = parent_count;
    zT_111 = caller_key;
    zT_113 = 1;
    zT_114 = zig_wrap_add_u(((zu64)(pc)), ((zu64)(zT_113)), 32u);
    zT_115 = zig_overflow_flag_add_u(((zu64)(pc)), ((zu64)(zT_113)), 32u);
    zT_117 = zT_115 == (unsigned int)(0);
    if (!(zT_117)) { pal_trap(); }
    zT_112 = zT_114;
    zF_B6EB812C_u64ToU32MapPut(zT_110, zT_111, zT_112);
    goto z_bb_20;
    z_bb_25:
    if ((unsigned char)(ei < (unsigned int)((unsigned int)ec_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_132 = stack;
    zT_134 = store;
    zT_135 = ni;
    zT_138 = zF_B10B1BC1_astStoreNodeExtraCh(zT_134, zT_135, (unsigned int)((unsigned int)ei));
    zT_133 = zT_138;
    zF_62F717A2_u32ArrayListAppend(zT_132, zT_133);
    goto z_bb_28;
    z_bb_27:
    goto z_bb_6;
    z_bb_28:
    zT_139 = 1;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_140)), 32u);
    zT_142 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_140)), 32u);
    zT_144 = zT_142 == (unsigned int)(0);
    if (!(zT_144)) { pal_trap(); }
    ei = zT_141;
    goto z_bb_25;
    z_bb_29:
    zT_149 = store;
    zT_150 = ni;
    zT_151 = zF_152E19CB_astStoreNodeExtraCh(zT_149, zT_150);
    ec2_n = zT_151;
    zT_153 = 0;
    ei2 = zT_153;
    goto z_bb_31;
    z_bb_30:
    zT_169 = n.child_0;
    if ((unsigned char)(zT_169 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_31:
    if ((unsigned char)(ei2 < (unsigned int)((unsigned int)ec2_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_156 = stack;
    zT_158 = store;
    zT_159 = ni;
    zT_162 = zF_B10B1BC1_astStoreNodeExtraCh(zT_158, zT_159, (unsigned int)((unsigned int)ei2));
    zT_157 = zT_162;
    zF_62F717A2_u32ArrayListAppend(zT_156, zT_157);
    goto z_bb_34;
    z_bb_33:
    goto z_bb_6;
    z_bb_34:
    zT_163 = 1;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zig_wrap_add_u(((zu64)(ei2)), ((zu64)(zT_164)), 32u);
    zT_166 = zig_overflow_flag_add_u(((zu64)(ei2)), ((zu64)(zT_164)), 32u);
    zT_168 = zT_166 == (unsigned int)(0);
    if (!(zT_168)) { pal_trap(); }
    ei2 = zT_165;
    goto z_bb_31;
    z_bb_35:
    zT_173 = k;
    zT_176 = zF_C395F6FD_nodeChildIsNode(zT_173, (unsigned char)(0));
    zT_172 = zT_176;
    goto z_bb_37;
    z_bb_36:
    zT_172 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_172) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_177 = stack;
    zT_178 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_177, zT_178);
    goto z_bb_39;
    z_bb_39:
    zT_180 = n.child_1;
    if ((unsigned char)(zT_180 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_184 = k;
    zT_187 = zF_C395F6FD_nodeChildIsNode(zT_184, (unsigned char)(1));
    zT_183 = zT_187;
    goto z_bb_42;
    z_bb_41:
    zT_183 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_183) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_188 = stack;
    zT_189 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_188, zT_189);
    goto z_bb_44;
    z_bb_44:
    zT_191 = n.child_2;
    if ((unsigned char)(zT_191 != (unsigned int)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_195 = k;
    zT_198 = zF_C395F6FD_nodeChildIsNode(zT_195, (unsigned char)(2));
    zT_194 = zT_198;
    goto z_bb_47;
    z_bb_46:
    zT_194 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_194) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_199 = stack;
    zT_200 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_199, zT_200);
    goto z_bb_49;
    z_bb_49:
    zT_202 = k;
    zT_203 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_202);
    if (zT_203) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_205 = store;
    zT_206 = ni;
    zT_207 = zF_152E19CB_astStoreNodeExtraCh(zT_205, zT_206);
    ec3_n = zT_207;
    zT_209 = 0;
    ei3 = zT_209;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_6;
    z_bb_52:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_212 = stack;
    zT_214 = store;
    zT_215 = ni;
    zT_218 = zF_B10B1BC1_astStoreNodeExtraCh(zT_214, zT_215, (unsigned int)((unsigned int)ei3));
    zT_213 = zT_218;
    zF_62F717A2_u32ArrayListAppend(zT_212, zT_213);
    goto z_bb_55;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_219 = 1;
    zT_220 = (unsigned int)zT_219;
    zT_221 = zig_wrap_add_u(((zu64)(ei3)), ((zu64)(zT_220)), 32u);
    zT_222 = zig_overflow_flag_add_u(((zu64)(ei3)), ((zu64)(zT_220)), 32u);
    zT_224 = zT_222 == (unsigned int)(0);
    if (!(zT_224)) { pal_trap(); }
    ei3 = zT_221;
    goto z_bb_52;
    z_bb_56:
    if (!(zT_227.has_value)) { pal_trap(); }
    pc = zT_227.value;
    if ((unsigned char)(pc > (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return;
    z_bb_58:
    zT_232 = parent_start;
    zT_233 = caller_key;
    zT_234 = zF_A05A7BE1_u64ToU32MapGet(zT_232, zT_233);
    zT_235 = zT_234.has_value;
    if (zT_235) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    if (!(zT_234.has_value)) { pal_trap(); }
    ps = zT_234.value;
    zT_238 = (unsigned int)ps;
    lo = zT_238;
    zT_240 = parent_type_list->len;
    hi = zT_240;
    goto z_bb_62;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_241 = 1;
    zT_242 = zig_wrap_add_u(((zu64)(lo)), ((zu64)(zT_241)), 32u);
    zT_243 = zig_overflow_flag_add_u(((zu64)(lo)), ((zu64)(zT_241)), 32u);
    zT_245 = zT_243 == (unsigned int)(0);
    if (!(zT_245)) { pal_trap(); }
    if ((unsigned char)(zT_242 < hi)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_248 = parent_type_list->items;
    zT_249 = zT_248[lo];
    tmp = zT_249;
    zT_250 = parent_type_list->items;
    zT_251 = 1;
    zT_252 = zig_wrap_sub_u(((zu64)(hi)), ((zu64)(zT_251)), 32u);
    zT_253 = zig_overflow_flag_sub_u(((zu64)(hi)), ((zu64)(zT_251)), 32u);
    zT_255 = zT_253 == (unsigned int)(0);
    if (!(zT_255)) { pal_trap(); }
    zT_256 = zT_250[zT_252];
    zT_257 = parent_type_list->items;
    zT_257[lo] = zT_256;
    zT_258 = parent_type_list->items;
    zT_259 = 1;
    zT_260 = zig_wrap_sub_u(((zu64)(hi)), ((zu64)(zT_259)), 32u);
    zT_261 = zig_overflow_flag_sub_u(((zu64)(hi)), ((zu64)(zT_259)), 32u);
    zT_263 = zT_261 == (unsigned int)(0);
    if (!(zT_263)) { pal_trap(); }
    zT_258[zT_260] = tmp;
    zT_264 = 1;
    zT_265 = zig_wrap_add_u(((zu64)(lo)), ((zu64)(zT_264)), 32u);
    zT_266 = zig_overflow_flag_add_u(((zu64)(lo)), ((zu64)(zT_264)), 32u);
    zT_268 = zT_266 == (unsigned int)(0);
    if (!(zT_268)) { pal_trap(); }
    lo = zT_265;
    zT_269 = 1;
    zT_270 = zig_wrap_sub_u(((zu64)(hi)), ((zu64)(zT_269)), 32u);
    zT_271 = zig_overflow_flag_sub_u(((zu64)(hi)), ((zu64)(zT_269)), 32u);
    zT_273 = zT_271 == (unsigned int)(0);
    if (!(zT_273)) { pal_trap(); }
    hi = zT_270;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    goto z_bb_62;
}

/* asyncStateTypeForCount */
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int count) {
    if ((unsigned char)(count <= (unsigned int)(255))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(8);
    z_bb_2:
    if ((unsigned char)(count <= (unsigned int)(65535))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(9);
    z_bb_4:
    return (unsigned int)(10);
}

/* scanSuspensionCount */
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, unsigned int module_id, unsigned int body_idx, zT_B687BB96_U32ArrayList* stack, zT_A4CE86B7_U64ToU32Map* suspending_fns, unsigned int async_suspend_name_id, unsigned int async_init_name_id) {
    unsigned int zT_9;
    zT_B687BB96_U32ArrayList* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_36;
    zT_8143F551_AstKind zT_38;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    zT_B687BB96_U32ArrayList* zT_60;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned int zT_76;
    zT_6B0A7D14_AstStore* zT_79;
    zT_3D7259E2_SymbolRegistry* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_BBEE1AC1_Opt_11 zT_84;
    unsigned char zT_85;
    zT_79FAE712_u64 zT_88;
    zT_79FAE712_u64 zT_89;
    unsigned char zT_91;
    unsigned int zT_92;
    zT_79FAE712_u64 zT_95;
    unsigned int zT_96;
    zT_A4CE86B7_U64ToU32Map* zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned char zT_105;
    zT_B687BB96_U32ArrayList* zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_114;
    zT_B687BB96_U32ArrayList* zT_117;
    unsigned int zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    unsigned int zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    unsigned int zT_130;
    unsigned char zT_133;
    zT_8143F551_AstKind zT_134;
    unsigned char zT_137;
    zT_B687BB96_U32ArrayList* zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    unsigned char zT_144;
    zT_8143F551_AstKind zT_145;
    unsigned char zT_148;
    zT_B687BB96_U32ArrayList* zT_149;
    unsigned int zT_150;
    unsigned int zT_152;
    unsigned char zT_155;
    zT_8143F551_AstKind zT_156;
    unsigned char zT_159;
    zT_B687BB96_U32ArrayList* zT_160;
    unsigned int zT_161;
    zT_8143F551_AstKind zT_163;
    unsigned char zT_164;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_170;
    zT_B687BB96_U32ArrayList* zT_173;
    unsigned int zT_174;
    zT_6B0A7D14_AstStore* zT_175;
    unsigned int zT_176;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_159, (unsigned int)sizeof zT_159);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_179, (unsigned int)sizeof zT_179);
    unsigned int count;
    unsigned int ni;
    zT_22A7C88B_AstNode n;
    zT_8143F551_AstKind k;
    unsigned int ecb_n;
    unsigned int bi;
    unsigned int ecf_n;
    unsigned int fi;
    zT_79FAE712_u64 ck;
    unsigned int cmid;
    unsigned int cnid;
    unsigned int ec3_n;
    unsigned int ei3;
    zT_9 = 0;
    count = zT_9;
    stack->len = (unsigned int)(0);
    if ((unsigned char)(body_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return count;
    z_bb_2:
    zT_13 = stack;
    zT_14 = body_idx;
    zF_62F717A2_u32ArrayListAppend(zT_13, zT_14);
    goto z_bb_3;
    z_bb_3:
    zT_15 = stack->len;
    if ((unsigned char)(zT_15 > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = stack->items;
    zT_20 = stack->len;
    zT_21 = 1;
    zT_22 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = zT_19[zT_22];
    ni = zT_26;
    zT_27 = stack->len;
    zT_28 = 1;
    zT_29 = zig_wrap_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    stack->len = zT_29;
    zT_34 = store;
    zT_35 = ni;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    n = zT_36;
    zT_38 = n.kind;
    k = zT_38;
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return count;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_42 = n.child_0;
    if ((unsigned char)(zT_42 == async_suspend_name_id)) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    if ((unsigned char)(k == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_18; else goto z_bb_19;
    z_bb_9:
    zT_45 = n.child_0;
    zT_44 = zT_45 == async_init_name_id;
    goto z_bb_11;
    z_bb_10:
    zT_44 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_44) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_47 = 1;
    zT_48 = zig_wrap_add_u(((zu64)(count)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(count)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    count = zT_48;
    goto z_bb_13;
    z_bb_13:
    zT_53 = store;
    zT_54 = ni;
    zT_55 = zF_152E19CB_astStoreNodeExtraCh(zT_53, zT_54);
    ecb_n = zT_55;
    zT_57 = 0;
    bi = zT_57;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)ecb_n))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_60 = stack;
    zT_62 = store;
    zT_63 = ni;
    zT_66 = zF_B10B1BC1_astStoreNodeExtraCh(zT_62, zT_63, (unsigned int)((unsigned int)bi));
    zT_61 = zT_66;
    zF_62F717A2_u32ArrayListAppend(zT_60, zT_61);
    goto z_bb_17;
    z_bb_16:
    goto z_bb_6;
    z_bb_17:
    zT_67 = 1;
    zT_68 = (unsigned int)zT_67;
    zT_69 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    bi = zT_69;
    goto z_bb_14;
    z_bb_18:
    zT_76 = n.child_0;
    if ((unsigned char)(zT_76 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_130 = n.child_0;
    if ((unsigned char)(zT_130 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_20:
    zT_79 = store;
    zT_80 = sym_reg;
    zT_81 = module_id;
    zT_82 = n.child_0;
    zT_84 = zF_860C82EC_resolveCalleeKey(zT_79, zT_80, zT_81, zT_82);
    zT_85 = zT_84.has_value;
    if (zT_85) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_110 = store;
    zT_111 = ni;
    zT_112 = zF_152E19CB_astStoreNodeExtraCh(zT_110, zT_111);
    ecf_n = zT_112;
    zT_114 = 0;
    fi = zT_114;
    goto z_bb_26;
    z_bb_22:
    if (!(zT_84.has_value)) { pal_trap(); }
    ck = zT_84.value;
    zT_88 = 32;
    zT_91 = zT_88 < (unsigned int)(64);
    if (!(zT_91)) { pal_trap(); }
    zT_89 = ck >> zT_88;
    zT_92 = (unsigned int)zig_cast_checked_u((zu64)zT_89, 64u, 0u, 32u);
    cmid = zT_92;
    zT_95 = ck & (zT_79FAE712_u64)(4294967295u);
    zT_96 = (unsigned int)zig_cast_checked_u((zu64)zT_95, 64u, 0u, 32u);
    cnid = zT_96;
    zT_97 = suspending_fns;
    zT_98 = cmid;
    zT_99 = cnid;
    zT_100 = zF_7C7E43BF_asyncIsSuspending(zT_97, zT_98, zT_99);
    if (zT_100) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_106 = stack;
    zT_107 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_106, zT_107);
    goto z_bb_21;
    z_bb_24:
    zT_101 = 1;
    zT_102 = zig_wrap_add_u(((zu64)(count)), ((zu64)(zT_101)), 32u);
    zT_103 = zig_overflow_flag_add_u(((zu64)(count)), ((zu64)(zT_101)), 32u);
    zT_105 = zT_103 == (unsigned int)(0);
    if (!(zT_105)) { pal_trap(); }
    count = zT_102;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)ecf_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_117 = stack;
    zT_119 = store;
    zT_120 = ni;
    zT_123 = zF_B10B1BC1_astStoreNodeExtraCh(zT_119, zT_120, (unsigned int)((unsigned int)fi));
    zT_118 = zT_123;
    zF_62F717A2_u32ArrayListAppend(zT_117, zT_118);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_6;
    z_bb_29:
    zT_124 = 1;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    fi = zT_126;
    goto z_bb_26;
    z_bb_30:
    zT_134 = k;
    zT_137 = zF_C395F6FD_nodeChildIsNode(zT_134, (unsigned char)(0));
    zT_133 = zT_137;
    goto z_bb_32;
    z_bb_31:
    zT_133 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_133) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_138 = stack;
    zT_139 = n.child_0;
    zF_62F717A2_u32ArrayListAppend(zT_138, zT_139);
    goto z_bb_34;
    z_bb_34:
    zT_141 = n.child_1;
    if ((unsigned char)(zT_141 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_145 = k;
    zT_148 = zF_C395F6FD_nodeChildIsNode(zT_145, (unsigned char)(1));
    zT_144 = zT_148;
    goto z_bb_37;
    z_bb_36:
    zT_144 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_144) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_149 = stack;
    zT_150 = n.child_1;
    zF_62F717A2_u32ArrayListAppend(zT_149, zT_150);
    goto z_bb_39;
    z_bb_39:
    zT_152 = n.child_2;
    if ((unsigned char)(zT_152 != (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_156 = k;
    zT_159 = zF_C395F6FD_nodeChildIsNode(zT_156, (unsigned char)(2));
    zT_155 = zT_159;
    goto z_bb_42;
    z_bb_41:
    zT_155 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_155) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_160 = stack;
    zT_161 = n.child_2;
    zF_62F717A2_u32ArrayListAppend(zT_160, zT_161);
    goto z_bb_44;
    z_bb_44:
    zT_163 = k;
    zT_164 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_163);
    if (zT_164) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_166 = store;
    zT_167 = ni;
    zT_168 = zF_152E19CB_astStoreNodeExtraCh(zT_166, zT_167);
    ec3_n = zT_168;
    zT_170 = 0;
    ei3 = zT_170;
    goto z_bb_47;
    z_bb_46:
    goto z_bb_6;
    z_bb_47:
    if ((unsigned char)(ei3 < (unsigned int)((unsigned int)ec3_n))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_173 = stack;
    zT_175 = store;
    zT_176 = ni;
    zT_179 = zF_B10B1BC1_astStoreNodeExtraCh(zT_175, zT_176, (unsigned int)((unsigned int)ei3));
    zT_174 = zT_179;
    zF_62F717A2_u32ArrayListAppend(zT_173, zT_174);
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_180 = 1;
    zT_181 = (unsigned int)zT_180;
    zT_182 = zig_wrap_add_u(((zu64)(ei3)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_add_u(((zu64)(ei3)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    ei3 = zT_182;
    goto z_bb_47;
}

/* asyncPtrVoid */
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_1;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_1 = reg;
    zT_6 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1, (unsigned int)(1), (unsigned char)(0));
    return zT_6;
}

/* emitFrameMarker */
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64 key, unsigned int size) {
    zT_79FAE712_u64 zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned char zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_5826BFC7_Arr_unsigned_char_1 zT_18;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    zT_5826BFC7_Arr_unsigned_char_1 zT_51;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_57;
    unsigned char* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    unsigned int zT_63;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_5826BFC7_Arr_unsigned_char_1 zT_84;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    int zT_90;
    unsigned char* zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    unsigned int zT_96;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned char zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_106;
    unsigned char* zT_107;
    unsigned int zT_108;
    unsigned char zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    unsigned int module_id;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_3 = 32;
    zT_6 = zT_3 < (unsigned int)(64);
    if (!(zT_6)) { pal_trap(); }
    zT_4 = key >> zT_3;
    zT_7 = (unsigned int)zig_cast_checked_u((zu64)zT_4, 64u, 0u, 32u);
    module_id = zT_7;
    zT_10 = key & (zT_79FAE712_u64)(4294967295u);
    zT_11 = (unsigned int)zig_cast_checked_u((zu64)zT_10, 64u, 0u, 32u);
    name_id = zT_11;
    zT_13 = "FRAME:m";
    zT_15 = 7;
    zT_14.ptr = (unsigned char*)zT_13;
    zT_14.len = zT_15;
    m1 = zT_14;
    zT_16 = m1;
    zF_48AC7B3A_markerWrite(zT_16);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_18[_i];
        _i++;
    }
}
    zT_20 = module_id;
    zT_24 = 0;
    zT_25 = (unsigned char*)((unsigned char*)b1) + zT_24;
    zT_26 = (unsigned int)(12) - zT_24;
    zT_27.ptr = (unsigned char*)zT_25;
    zT_27.len = zT_26;
    zT_21 = zT_27;
    zT_28 = zF_A7504564_itoa(zT_20, zT_21);
    l1 = zT_28;
    zT_30 = 11;
    zT_32 = (unsigned int)(unsigned int)((unsigned int)l1);
    zT_33 = zig_wrap_sub_u(((zu64)(zT_30)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_sub_u(((zu64)(zT_30)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    s1 = zT_33;
    zT_40 = 11;
    zT_41 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_42 = zT_40 - s1;
    zT_43 = s1 <= zT_40;
    if (!(zT_43)) { pal_trap(); }
    zT_44.ptr = (unsigned char*)zT_41;
    zT_44.len = zT_42;
    zT_37 = zT_44;
    zF_48AC7B3A_markerWrite(zT_37);
    zT_46 = ":n";
    zT_48 = 2;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    m2 = zT_47;
    zT_49 = m2;
    zF_48AC7B3A_markerWrite(zT_49);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_51[_i];
        _i++;
    }
}
    zT_53 = name_id;
    zT_57 = 0;
    zT_58 = (unsigned char*)((unsigned char*)b2) + zT_57;
    zT_59 = (unsigned int)(12) - zT_57;
    zT_60.ptr = (unsigned char*)zT_58;
    zT_60.len = zT_59;
    zT_54 = zT_60;
    zT_61 = zF_A7504564_itoa(zT_53, zT_54);
    l2 = zT_61;
    zT_63 = 11;
    zT_65 = (unsigned int)(unsigned int)((unsigned int)l2);
    zT_66 = zig_wrap_sub_u(((zu64)(zT_63)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_sub_u(((zu64)(zT_63)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    s2 = zT_66;
    zT_73 = 11;
    zT_74 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_75 = zT_73 - s2;
    zT_76 = s2 <= zT_73;
    if (!(zT_76)) { pal_trap(); }
    zT_77.ptr = (unsigned char*)zT_74;
    zT_77.len = zT_75;
    zT_70 = zT_77;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_79 = ":s";
    zT_81 = 2;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    m3 = zT_80;
    zT_82 = m3;
    zF_48AC7B3A_markerWrite(zT_82);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_84[_i];
        _i++;
    }
}
    zT_86 = size;
    zT_90 = 0;
    zT_91 = (unsigned char*)((unsigned char*)b3) + zT_90;
    zT_92 = (unsigned int)(12) - zT_90;
    zT_93.ptr = (unsigned char*)zT_91;
    zT_93.len = zT_92;
    zT_87 = zT_93;
    zT_94 = zF_A7504564_itoa(zT_86, zT_87);
    l3 = zT_94;
    zT_96 = 11;
    zT_98 = (unsigned int)(unsigned int)((unsigned int)l3);
    zT_99 = zig_wrap_sub_u(((zu64)(zT_96)), ((zu64)(zT_98)), 32u);
    zT_100 = zig_overflow_flag_sub_u(((zu64)(zT_96)), ((zu64)(zT_98)), 32u);
    zT_102 = zT_100 == (unsigned int)(0);
    if (!(zT_102)) { pal_trap(); }
    s3 = zT_99;
    zT_106 = 11;
    zT_107 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_108 = zT_106 - s3;
    zT_109 = s3 <= zT_106;
    if (!(zT_109)) { pal_trap(); }
    zT_110.ptr = (unsigned char*)zT_107;
    zT_110.len = zT_108;
    zT_103 = zT_110;
    zF_48AC7B3A_markerWrite(zT_103);
    zT_112 = "\n";
    zT_114 = 1;
    zT_113.ptr = (unsigned char*)zT_112;
    zT_113.len = zT_114;
    m4 = zT_113;
    zT_115 = m4;
    zF_48AC7B3A_markerWrite(zT_115);
    return;
}

/* asyncFrameSizeRun */
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand* alloc, zT_6B0A7D14_AstStore* store, zT_3D7259E2_SymbolRegistry* sym_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* typereg, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_B687BB96_U32ArrayList zT_23;
    zT_072B53A6_ModuleRegistry* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_3E40CD83_Sand* zT_44;
    zT_A4CE86B7_U64ToU32Map zT_45;
    unsigned int zT_47;
    unsigned int zT_49;
    zT_6E8D187B_ModuleEntry* zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    zT_6E8D187B_ModuleEntry zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_62;
    zT_8143F551_AstKind zT_63;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_72;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    zT_22A7C88B_AstNode zT_84;
    zT_8143F551_AstKind zT_85;
    zT_5838FCFA_anon_324009 zT_90;
    zT_243D6A41_FnProto* zT_91;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_243D6A41_FnProto zT_96;
    unsigned int zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_99;
    unsigned int zT_100;
    zT_BAEE192E_Opt_10 zT_102;
    unsigned char zT_103;
    zT_A4CE86B7_U64ToU32Map* zT_105;
    zT_79FAE712_u64 zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_6E8D187B_ModuleEntry* zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_6E8D187B_ModuleEntry zT_114;
    zT_79FAE712_u64 zT_117;
    int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_6E8D187B_ModuleEntry* zT_136;
    unsigned int zT_137;
    unsigned char zT_138;
    zT_6E8D187B_ModuleEntry zT_139;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    zT_22A7C88B_AstNode zT_146;
    zT_8143F551_AstKind zT_147;
    zT_6B0A7D14_AstStore* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_160;
    unsigned int zT_161;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    zT_22A7C88B_AstNode zT_168;
    zT_8143F551_AstKind zT_169;
    zT_5838FCFA_anon_324009 zT_174;
    zT_243D6A41_FnProto* zT_175;
    zT_6B0A7D14_AstStore* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_243D6A41_FnProto zT_180;
    zT_A4CE86B7_U64ToU32Map* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_6E8D187B_ModuleEntry* zT_184;
    unsigned int zT_185;
    unsigned char zT_186;
    zT_6E8D187B_ModuleEntry zT_187;
    unsigned char zT_190;
    zT_6B0A7D14_AstStore* zT_192;
    zT_3D7259E2_SymbolRegistry* zT_193;
    unsigned int zT_194;
    zT_79FAE712_u64 zT_195;
    unsigned int zT_196;
    zT_B687BB96_U32ArrayList* zT_197;
    zT_A4CE86B7_U64ToU32Map* zT_198;
    zT_A4CE86B7_U64ToU32Map* zT_199;
    zT_A4CE86B7_U64ToU32Map* zT_200;
    zT_A4CE86B7_U64ToU32Map* zT_201;
    zT_B687BB96_U32ArrayList* zT_202;
    zT_A4CE86B7_U64ToU32Map* zT_203;
    zT_A4CE86B7_U64ToU32Map* zT_204;
    zT_6E8D187B_ModuleEntry* zT_205;
    unsigned int zT_206;
    unsigned char zT_207;
    zT_6E8D187B_ModuleEntry zT_208;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_6E8D187B_ModuleEntry* zT_212;
    unsigned int zT_213;
    unsigned char zT_214;
    zT_6E8D187B_ModuleEntry zT_215;
    zT_79FAE712_u64 zT_218;
    int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned char zT_227;
    int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned char zT_233;
    unsigned int zT_235;
    unsigned int zT_237;
    zT_6E8D187B_ModuleEntry* zT_240;
    unsigned int zT_241;
    unsigned char zT_242;
    zT_6E8D187B_ModuleEntry zT_243;
    unsigned int zT_244;
    zT_6B0A7D14_AstStore* zT_248;
    unsigned int zT_249;
    zT_22A7C88B_AstNode zT_250;
    zT_8143F551_AstKind zT_251;
    zT_6B0A7D14_AstStore* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_260;
    zT_6B0A7D14_AstStore* zT_264;
    unsigned int zT_265;
    unsigned int zT_268;
    zT_6B0A7D14_AstStore* zT_270;
    unsigned int zT_271;
    zT_22A7C88B_AstNode zT_272;
    zT_8143F551_AstKind zT_273;
    zT_6B0A7D14_AstStore* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    zT_5838FCFA_anon_324009 zT_282;
    zT_243D6A41_FnProto* zT_283;
    unsigned int zT_284;
    zT_243D6A41_FnProto zT_285;
    zT_A4CE86B7_U64ToU32Map* zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_6E8D187B_ModuleEntry* zT_289;
    unsigned int zT_290;
    unsigned char zT_291;
    zT_6E8D187B_ModuleEntry zT_292;
    unsigned char zT_295;
    unsigned int zT_298;
    unsigned int zT_299;
    zT_6E8D187B_ModuleEntry* zT_300;
    unsigned int zT_301;
    unsigned char zT_302;
    zT_6E8D187B_ModuleEntry zT_303;
    zT_79FAE712_u64 zT_306;
    unsigned char zT_308;
    unsigned char zT_309;
    unsigned char zT_315;
    zT_6E8D187B_ModuleEntry* zT_316;
    unsigned int zT_317;
    unsigned char zT_318;
    zT_6E8D187B_ModuleEntry zT_319;
    unsigned int zT_320;
    unsigned char zT_323;
    unsigned char zT_324;
    zT_D3EB6303_StringInterner* zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    unsigned int zT_336;
    unsigned char zT_339;
    unsigned char* zT_340;
    int zT_341;
    unsigned int zT_342;
    unsigned char zT_343;
    unsigned char zT_344;
    unsigned char zT_347;
    unsigned char* zT_348;
    int zT_349;
    unsigned int zT_350;
    unsigned char zT_351;
    unsigned char zT_352;
    unsigned char zT_355;
    unsigned char* zT_356;
    int zT_357;
    unsigned int zT_358;
    unsigned char zT_359;
    unsigned char zT_360;
    unsigned char zT_363;
    unsigned char* zT_364;
    int zT_365;
    unsigned int zT_366;
    unsigned char zT_367;
    unsigned char zT_368;
    unsigned char zT_371;
    zT_A4CE86B7_U64ToU32Map* zT_372;
    zT_79FAE712_u64 zT_373;
    zT_6B0A7D14_AstStore* zT_377;
    zT_3D7259E2_SymbolRegistry* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    zT_B687BB96_U32ArrayList* zT_381;
    zT_A4CE86B7_U64ToU32Map* zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    zT_6E8D187B_ModuleEntry* zT_385;
    unsigned int zT_386;
    unsigned char zT_387;
    zT_6E8D187B_ModuleEntry zT_388;
    unsigned int zT_392;
    unsigned int zT_394;
    unsigned int zT_395;
    zT_A4CE86B7_U64ToU32Map* zT_396;
    zT_79FAE712_u64 zT_397;
    unsigned int zT_398;
    unsigned int zT_400;
    unsigned int zT_402;
    zT_338B7C76_TypeRegistry* zT_403;
    unsigned int* zT_405;
    unsigned int* zT_406;
    unsigned int zT_410;
    zT_338B7C76_TypeRegistry* zT_411;
    unsigned int* zT_413;
    unsigned int* zT_414;
    unsigned int zT_418;
    zT_338B7C76_TypeRegistry* zT_419;
    unsigned int zT_420;
    unsigned int* zT_421;
    unsigned int* zT_422;
    unsigned int zT_425;
    unsigned short zT_426;
    unsigned int zT_430;
    zT_79FAE712_u64 zT_431;
    zT_79FAE712_u64 zT_432;
    zT_79FAE712_u64 zT_433;
    unsigned char zT_435;
    unsigned int zT_436;
    unsigned char zT_438;
    unsigned short zT_439;
    zT_79FAE712_u64 zT_441;
    zT_6B0A7D14_AstStore* zT_443;
    zT_79FAE712_u64 zT_444;
    unsigned int zT_445;
    unsigned int zT_447;
    zT_6B0A7D14_AstStore* zT_451;
    unsigned int zT_452;
    zT_6B0A7D14_AstStore* zT_453;
    zT_79FAE712_u64 zT_454;
    unsigned int zT_457;
    zT_22A7C88B_AstNode zT_458;
    unsigned int zT_459;
    unsigned int zT_463;
    zT_8EED1867_ResolvedTypeTable* zT_464;
    unsigned int zT_465;
    zT_BAEE192E_Opt_10 zT_467;
    unsigned char zT_468;
    zT_338B7C76_TypeRegistry* zT_470;
    unsigned int zT_471;
    unsigned int* zT_472;
    unsigned int* zT_473;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned char zT_481;
    zT_6B0A7D14_AstStore* zT_482;
    unsigned int zT_483;
    zT_B687BB96_U32ArrayList* zT_484;
    zT_338B7C76_TypeRegistry* zT_485;
    zT_8EED1867_ResolvedTypeTable* zT_486;
    unsigned int* zT_487;
    unsigned int* zT_488;
    unsigned int zT_494;
    zT_A4CE86B7_U64ToU32Map* zT_495;
    zT_79FAE712_u64 zT_496;
    zT_BAEE192E_Opt_10 zT_497;
    unsigned char zT_498;
    zT_338B7C76_TypeRegistry* zT_504;
    unsigned int zT_505;
    unsigned int* zT_506;
    unsigned int* zT_507;
    zT_338B7C76_TypeRegistry* zT_508;
    unsigned int zT_509;
    unsigned int zT_512;
    zT_A4CE86B7_U64ToU32Map* zT_513;
    zT_79FAE712_u64 zT_514;
    zT_BAEE192E_Opt_10 zT_515;
    unsigned char zT_516;
    unsigned char zT_517;
    zT_A4CE86B7_U64ToU32Map* zT_518;
    zT_79FAE712_u64 zT_519;
    zT_BAEE192E_Opt_10 zT_520;
    unsigned char zT_521;
    zT_338B7C76_TypeRegistry* zT_522;
    unsigned int zT_523;
    unsigned int* zT_524;
    unsigned int* zT_525;
    zT_338B7C76_TypeRegistry* zT_526;
    unsigned int zT_527;
    unsigned int zT_530;
    unsigned int zT_536;
    zT_A4CE86B7_U64ToU32Map* zT_537;
    zT_79FAE712_u64 zT_538;
    zT_BAEE192E_Opt_10 zT_539;
    unsigned char zT_540;
    unsigned int zT_543;
    zT_A4CE86B7_U64ToU32Map* zT_544;
    zT_79FAE712_u64 zT_545;
    zT_BAEE192E_Opt_10 zT_546;
    unsigned char zT_547;
    unsigned int zT_550;
    unsigned int* zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    unsigned char zT_557;
    unsigned int zT_558;
    unsigned int zT_559;
    zT_338B7C76_TypeRegistry* zT_560;
    unsigned int zT_561;
    unsigned int* zT_562;
    unsigned int* zT_563;
    unsigned int zT_566;
    unsigned int zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    unsigned char zT_571;
    unsigned int zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_578;
    unsigned int zT_579;
    unsigned int zT_582;
    zT_A4CE86B7_U64ToU32Map* zT_583;
    zT_79FAE712_u64 zT_584;
    unsigned int zT_585;
    zT_79FAE712_u64 zT_586;
    unsigned int zT_587;
    int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned char zT_593;
    int zT_594;
    unsigned int zT_595;
    unsigned int zT_596;
    unsigned int zT_597;
    unsigned char zT_599;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_218, (unsigned int)sizeof zT_218);
    zig_poison_fill((void*)&zT_250, (unsigned int)sizeof zT_250);
    zig_poison_fill((void*)&zT_258, (unsigned int)sizeof zT_258);
    zig_poison_fill((void*)&zT_268, (unsigned int)sizeof zT_268);
    zig_poison_fill((void*)&zT_272, (unsigned int)sizeof zT_272);
    zig_poison_fill((void*)&zT_280, (unsigned int)sizeof zT_280);
    zig_poison_fill((void*)&zT_295, (unsigned int)sizeof zT_295);
    zig_poison_fill((void*)&zT_306, (unsigned int)sizeof zT_306);
    zig_poison_fill((void*)&zT_334, (unsigned int)sizeof zT_334);
    zig_poison_fill((void*)&zT_392, (unsigned int)sizeof zT_392);
    zig_poison_fill((void*)&zT_395, (unsigned int)sizeof zT_395);
    zig_poison_fill((void*)&zT_410, (unsigned int)sizeof zT_410);
    zig_poison_fill((void*)&zT_418, (unsigned int)sizeof zT_418);
    zig_poison_fill((void*)&zT_425, (unsigned int)sizeof zT_425);
    zig_poison_fill((void*)&zT_445, (unsigned int)sizeof zT_445);
    zig_poison_fill((void*)&zT_457, (unsigned int)sizeof zT_457);
    zig_poison_fill((void*)&zT_458, (unsigned int)sizeof zT_458);
    zig_poison_fill((void*)&zT_467, (unsigned int)sizeof zT_467);
    zig_poison_fill((void*)&zT_476, (unsigned int)sizeof zT_476);
    zig_poison_fill((void*)&zT_497, (unsigned int)sizeof zT_497);
    zig_poison_fill((void*)&zT_509, (unsigned int)sizeof zT_509);
    zig_poison_fill((void*)&zT_512, (unsigned int)sizeof zT_512);
    zig_poison_fill((void*)&zT_515, (unsigned int)sizeof zT_515);
    zig_poison_fill((void*)&zT_520, (unsigned int)sizeof zT_520);
    zig_poison_fill((void*)&zT_527, (unsigned int)sizeof zT_527);
    zig_poison_fill((void*)&zT_530, (unsigned int)sizeof zT_530);
    zig_poison_fill((void*)&zT_539, (unsigned int)sizeof zT_539);
    zig_poison_fill((void*)&zT_546, (unsigned int)sizeof zT_546);
    zig_poison_fill((void*)&zT_566, (unsigned int)sizeof zT_566);
    zig_poison_fill((void*)&zT_575, (unsigned int)sizeof zT_575);
    zig_poison_fill((void*)&zT_582, (unsigned int)sizeof zT_582);
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_B687BB96_U32ArrayList stack;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_text;
    unsigned int async_suspend_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_text;
    unsigned int async_init_name_id;
    zT_A4CE86B7_U64ToU32Map fn_ret_types;
    unsigned int mi0;
    unsigned int ar0;
    unsigned int mi0b;
    zT_22A7C88B_AstNode r0;
    unsigned int d0_n;
    unsigned int di0;
    unsigned int d0_idx;
    zT_22A7C88B_AstNode dc0;
    zT_243D6A41_FnProto pr0;
    unsigned int rt0;
    unsigned int rr0;
    unsigned int ar0b;
    unsigned int mi;
    zT_22A7C88B_AstNode r0b;
    unsigned int d0b_n;
    unsigned int di0b;
    unsigned int d0b_idx;
    zT_22A7C88B_AstNode dc0b;
    zT_243D6A41_FnProto pr0b;
    unsigned int ast_root;
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 key;
    unsigned char is_driver_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u dm;
    unsigned int susp_count;
    unsigned int state_type;
    unsigned int offset;
    unsigned int max_align;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int hid;
    zT_22A7C88B_AstNode pnode;
    unsigned int pt;
    unsigned int rtp;
    unsigned int h;
    unsigned int pstart;
    unsigned int total;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_17 = "AFS\n";
    zT_19 = 4;
    zT_18.ptr = (unsigned char*)zT_17;
    zT_18.len = zT_19;
    p_msg = zT_18;
    zT_20 = p_msg;
    zF_48AC7B3A_markerWrite(zT_20);
    zT_22 = alloc;
    zT_23 = zF_8E537D0C_u32ArrayListInit(zT_22);
    stack = zT_23;
    zT_25 = module_reg;
    zT_26 = zF_3452C137_moduleRegistryGetMo(zT_25);
    mods = zT_26;
    zT_28 = "@asyncSuspend";
    zT_30 = 13;
    zT_29.ptr = (unsigned char*)zT_28;
    zT_29.len = zT_30;
    asu_text = zT_29;
    zT_32 = interner;
    zT_33 = asu_text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_32, zT_33);
    async_suspend_name_id = zT_34;
    zT_36 = "@asyncInit";
    zT_38 = 10;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    ain_text = zT_37;
    zT_40 = interner;
    zT_41 = ain_text;
    zT_42 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    async_init_name_id = zT_42;
    zT_44 = alloc;
    zT_45 = zF_986226E1_u64ToU32MapInit(zT_44);
    fn_ret_types = zT_45;
    zT_47 = 0;
    mi0 = zT_47;
    goto z_bb_1;
    z_bb_1:
    zT_49 = mods.len;
    if ((unsigned char)(mi0 < zT_49)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_52 = mods.ptr;
    zT_53 = mods.len;
    zT_54 = mi0 < zT_53;
    if (!(zT_54)) { pal_trap(); }
    zT_55 = zT_52[mi0];
    zT_56 = zT_55.ast_root;
    ar0 = zT_56;
    if ((unsigned char)(ar0 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_131 = 0;
    mi0b = zT_131;
    goto z_bb_17;
    z_bb_4:
    zT_124 = 1;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zig_wrap_add_u(((zu64)(mi0)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_add_u(((zu64)(mi0)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    mi0 = zT_126;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_60 = store;
    zT_61 = ar0;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_60, zT_61);
    r0 = zT_62;
    zT_63 = r0.kind;
    if ((unsigned char)(zT_63 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_68 = store;
    zT_69 = ar0;
    zT_70 = zF_152E19CB_astStoreNodeExtraCh(zT_68, zT_69);
    d0_n = zT_70;
    zT_72 = 0;
    di0 = zT_72;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(di0 < (unsigned int)((unsigned int)d0_n))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_76 = store;
    zT_77 = ar0;
    zT_80 = zF_B10B1BC1_astStoreNodeExtraCh(zT_76, zT_77, (unsigned int)((unsigned int)di0));
    d0_idx = zT_80;
    zT_82 = store;
    zT_83 = d0_idx;
    zT_84 = zF_FCDD1D35_astStoreNodeAt(zT_82, zT_83);
    dc0 = zT_84;
    zT_85 = dc0.kind;
    if ((unsigned char)(zT_85 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_118 = 1;
    zT_119 = (unsigned int)zT_118;
    zT_120 = zig_wrap_add_u(((zu64)(di0)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_add_u(((zu64)(di0)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    di0 = zT_120;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_90 = store->fn_protos;
    zT_91 = zT_90.items;
    zT_92 = store;
    zT_93 = d0_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_92, zT_93);
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_91[zT_95];
    pr0 = zT_96;
    zT_98 = 1;
    rt0 = zT_98;
    zT_99 = resolved_types;
    zT_100 = pr0.return_type_node;
    zT_102 = zF_999DCF51_resolvedTypeTableGe(zT_99, zT_100);
    zT_103 = zT_102.has_value;
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    if (!(zT_102.has_value)) { pal_trap(); }
    rr0 = zT_102.value;
    rt0 = rr0;
    goto z_bb_16;
    z_bb_16:
    zT_105 = (zT_A4CE86B7_U64ToU32Map*)&fn_ret_types;
    zT_111 = mods.ptr;
    zT_112 = mods.len;
    zT_113 = mi0 < zT_112;
    if (!(zT_113)) { pal_trap(); }
    zT_114 = zT_111[mi0];
    zT_109 = zT_114.id;
    zT_110 = pr0.name_id;
    zT_117 = zF_9D041EB6_asyncKey(zT_109, zT_110);
    zT_106 = zT_117;
    zT_107 = rt0;
    zF_B6EB812C_u64ToU32MapPut(zT_105, zT_106, zT_107);
    goto z_bb_12;
    z_bb_17:
    zT_133 = mods.len;
    if ((unsigned char)(mi0b < zT_133)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_136 = mods.ptr;
    zT_137 = mods.len;
    zT_138 = mi0b < zT_137;
    if (!(zT_138)) { pal_trap(); }
    zT_139 = zT_136[mi0b];
    zT_140 = zT_139.ast_root;
    ar0b = zT_140;
    if ((unsigned char)(ar0b == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_235 = 0;
    mi = zT_235;
    goto z_bb_33;
    z_bb_20:
    zT_228 = 1;
    zT_229 = (unsigned int)zT_228;
    zT_230 = zig_wrap_add_u(((zu64)(mi0b)), ((zu64)(zT_229)), 32u);
    zT_231 = zig_overflow_flag_add_u(((zu64)(mi0b)), ((zu64)(zT_229)), 32u);
    zT_233 = zT_231 == (unsigned int)(0);
    if (!(zT_233)) { pal_trap(); }
    mi0b = zT_230;
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_144 = store;
    zT_145 = ar0b;
    zT_146 = zF_FCDD1D35_astStoreNodeAt(zT_144, zT_145);
    r0b = zT_146;
    zT_147 = r0b.kind;
    if ((unsigned char)(zT_147 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_152 = store;
    zT_153 = ar0b;
    zT_154 = zF_152E19CB_astStoreNodeExtraCh(zT_152, zT_153);
    d0b_n = zT_154;
    zT_156 = 0;
    di0b = zT_156;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(di0b < (unsigned int)((unsigned int)d0b_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_160 = store;
    zT_161 = ar0b;
    zT_164 = zF_B10B1BC1_astStoreNodeExtraCh(zT_160, zT_161, (unsigned int)((unsigned int)di0b));
    d0b_idx = zT_164;
    zT_166 = store;
    zT_167 = d0b_idx;
    zT_168 = zF_FCDD1D35_astStoreNodeAt(zT_166, zT_167);
    dc0b = zT_168;
    zT_169 = dc0b.kind;
    if ((unsigned char)(zT_169 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_20;
    z_bb_28:
    zT_222 = 1;
    zT_223 = (unsigned int)zT_222;
    zT_224 = zig_wrap_add_u(((zu64)(di0b)), ((zu64)(zT_223)), 32u);
    zT_225 = zig_overflow_flag_add_u(((zu64)(di0b)), ((zu64)(zT_223)), 32u);
    zT_227 = zT_225 == (unsigned int)(0);
    if (!(zT_227)) { pal_trap(); }
    di0b = zT_224;
    goto z_bb_25;
    z_bb_29:
    goto z_bb_28;
    z_bb_30:
    zT_174 = store->fn_protos;
    zT_175 = zT_174.items;
    zT_176 = store;
    zT_177 = d0b_idx;
    zT_178 = zF_8BA26B9E_astStoreNodePayload(zT_176, zT_177);
    zT_179 = (unsigned int)zT_178;
    zT_180 = zT_175[zT_179];
    pr0b = zT_180;
    zT_181 = suspending_fns;
    zT_184 = mods.ptr;
    zT_185 = mods.len;
    zT_186 = mi0b < zT_185;
    if (!(zT_186)) { pal_trap(); }
    zT_187 = zT_184[mi0b];
    zT_182 = zT_187.id;
    zT_183 = pr0b.name_id;
    zT_190 = zF_7C7E43BF_asyncIsSuspending(zT_181, zT_182, zT_183);
    if ((unsigned char)(!zT_190)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_192 = store;
    zT_193 = sym_reg;
    zT_205 = mods.ptr;
    zT_206 = mods.len;
    zT_207 = mi0b < zT_206;
    if (!(zT_207)) { pal_trap(); }
    zT_208 = zT_205[mi0b];
    zT_194 = zT_208.id;
    zT_212 = mods.ptr;
    zT_213 = mods.len;
    zT_214 = mi0b < zT_213;
    if (!(zT_214)) { pal_trap(); }
    zT_215 = zT_212[mi0b];
    zT_210 = zT_215.id;
    zT_211 = pr0b.name_id;
    zT_218 = zF_9D041EB6_asyncKey(zT_210, zT_211);
    zT_195 = zT_218;
    zT_196 = dc0b.child_0;
    zT_197 = (zT_B687BB96_U32ArrayList*)&stack;
    zT_198 = suspending_fns;
    zT_199 = (zT_A4CE86B7_U64ToU32Map*)&fn_ret_types;
    zT_200 = awaited_fns;
    zT_201 = async_hidden_fns;
    zT_202 = parent_result_type_list;
    zT_203 = parent_result_start;
    zT_204 = parent_result_count;
    zF_D62E4E4C_scanImplicitAwaits(zT_192, zT_193, zT_194, zT_195, zT_196, zT_197, zT_198, zT_199, zT_200, zT_201, zT_202, zT_203, zT_204);
    goto z_bb_28;
    z_bb_33:
    zT_237 = mods.len;
    if ((unsigned char)(mi < zT_237)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_240 = mods.ptr;
    zT_241 = mods.len;
    zT_242 = mi < zT_241;
    if (!(zT_242)) { pal_trap(); }
    zT_243 = zT_240[mi];
    zT_244 = zT_243.ast_root;
    ast_root = zT_244;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return;
    z_bb_36:
    zT_594 = 1;
    zT_595 = (unsigned int)zT_594;
    zT_596 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_595)), 32u);
    zT_597 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_595)), 32u);
    zT_599 = zT_597 == (unsigned int)(0);
    if (!(zT_599)) { pal_trap(); }
    mi = zT_596;
    goto z_bb_33;
    z_bb_37:
    goto z_bb_36;
    z_bb_38:
    zT_248 = store;
    zT_249 = ast_root;
    zT_250 = zF_FCDD1D35_astStoreNodeAt(zT_248, zT_249);
    root = zT_250;
    zT_251 = root.kind;
    if ((unsigned char)(zT_251 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_256 = store;
    zT_257 = ast_root;
    zT_258 = zF_152E19CB_astStoreNodeExtraCh(zT_256, zT_257);
    decls_n = zT_258;
    zT_260 = 0;
    di = zT_260;
    goto z_bb_41;
    z_bb_41:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_264 = store;
    zT_265 = ast_root;
    zT_268 = zF_B10B1BC1_astStoreNodeExtraCh(zT_264, zT_265, (unsigned int)((unsigned int)di));
    decl_idx = zT_268;
    zT_270 = store;
    zT_271 = decl_idx;
    zT_272 = zF_FCDD1D35_astStoreNodeAt(zT_270, zT_271);
    decl = zT_272;
    zT_273 = decl.kind;
    if ((unsigned char)(zT_273 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_588 = 1;
    zT_589 = (unsigned int)zT_588;
    zT_590 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_589)), 32u);
    zT_591 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_589)), 32u);
    zT_593 = zT_591 == (unsigned int)(0);
    if (!(zT_593)) { pal_trap(); }
    di = zT_590;
    goto z_bb_41;
    z_bb_45:
    goto z_bb_44;
    z_bb_46:
    zT_278 = store;
    zT_279 = decl_idx;
    zT_280 = zF_8BA26B9E_astStoreNodePayload(zT_278, zT_279);
    proto_idx = zT_280;
    zT_282 = store->fn_protos;
    zT_283 = zT_282.items;
    zT_284 = (unsigned int)proto_idx;
    zT_285 = zT_283[zT_284];
    proto = zT_285;
    zT_286 = suspending_fns;
    zT_289 = mods.ptr;
    zT_290 = mods.len;
    zT_291 = mi < zT_290;
    if (!(zT_291)) { pal_trap(); }
    zT_292 = zT_289[mi];
    zT_287 = zT_292.id;
    zT_288 = proto.name_id;
    zT_295 = zF_7C7E43BF_asyncIsSuspending(zT_286, zT_287, zT_288);
    if ((unsigned char)(!zT_295)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_300 = mods.ptr;
    zT_301 = mods.len;
    zT_302 = mi < zT_301;
    if (!(zT_302)) { pal_trap(); }
    zT_303 = zT_300[mi];
    zT_298 = zT_303.id;
    zT_299 = proto.name_id;
    zT_306 = zF_9D041EB6_asyncKey(zT_298, zT_299);
    key = zT_306;
    zT_308 = 0;
    is_driver_target = zT_308;
    zT_309 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_309) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_315 = 1;
    is_driver_target = zT_315;
    goto z_bb_50;
    z_bb_50:
    zT_316 = mods.ptr;
    zT_317 = mods.len;
    zT_318 = mi < zT_317;
    if (!(zT_318)) { pal_trap(); }
    zT_319 = zT_316[mi];
    zT_320 = zT_319.id;
    if ((unsigned char)(zT_320 == (unsigned int)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_324 = decl.flags;
    zT_323 = (unsigned short)((unsigned short)((unsigned short)zT_324) & (unsigned short)(2)) != (unsigned short)(0);
    goto z_bb_53;
    z_bb_52:
    zT_323 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_323) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_331 = interner;
    zT_332 = proto.name_id;
    zT_334 = zF_9134020D_stringInternerGet(zT_331, zT_332);
    dm = zT_334;
    zT_336 = dm.len;
    if ((unsigned char)(zT_336 == (unsigned int)(4))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if (is_driver_target) goto z_bb_70; else goto z_bb_71;
    z_bb_56:
    zT_340 = dm.ptr;
    zT_341 = 0;
    zT_342 = dm.len;
    zT_343 = (unsigned int)zT_341 < zT_342;
    if (!(zT_343)) { pal_trap(); }
    zT_344 = zT_340[zT_341];
    zT_339 = zT_344 == (unsigned char)(109);
    goto z_bb_58;
    z_bb_57:
    zT_339 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_339) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_348 = dm.ptr;
    zT_349 = 1;
    zT_350 = dm.len;
    zT_351 = (unsigned int)zT_349 < zT_350;
    if (!(zT_351)) { pal_trap(); }
    zT_352 = zT_348[zT_349];
    zT_347 = zT_352 == (unsigned char)(97);
    goto z_bb_61;
    z_bb_60:
    zT_347 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_347) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_356 = dm.ptr;
    zT_357 = 2;
    zT_358 = dm.len;
    zT_359 = (unsigned int)zT_357 < zT_358;
    if (!(zT_359)) { pal_trap(); }
    zT_360 = zT_356[zT_357];
    zT_355 = zT_360 == (unsigned char)(105);
    goto z_bb_64;
    z_bb_63:
    zT_355 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_355) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_364 = dm.ptr;
    zT_365 = 3;
    zT_366 = dm.len;
    zT_367 = (unsigned int)zT_365 < zT_366;
    if (!(zT_367)) { pal_trap(); }
    zT_368 = zT_364[zT_365];
    zT_363 = zT_368 == (unsigned char)(110);
    goto z_bb_67;
    z_bb_66:
    zT_363 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_363) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_371 = 1;
    is_driver_target = zT_371;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_55;
    z_bb_70:
    zT_372 = driver_targets;
    zT_373 = key;
    zF_B6EB812C_u64ToU32MapPut(zT_372, zT_373, (unsigned int)(1));
    goto z_bb_71;
    z_bb_71:
    zT_377 = store;
    zT_378 = sym_reg;
    zT_385 = mods.ptr;
    zT_386 = mods.len;
    zT_387 = mi < zT_386;
    if (!(zT_387)) { pal_trap(); }
    zT_388 = zT_385[mi];
    zT_379 = zT_388.id;
    zT_380 = decl.child_0;
    zT_381 = (zT_B687BB96_U32ArrayList*)&stack;
    zT_382 = suspending_fns;
    zT_383 = async_suspend_name_id;
    zT_384 = async_init_name_id;
    zT_392 = zF_0782A438_scanSuspensionCount(zT_377, zT_378, zT_379, zT_380, zT_381, zT_382, zT_383, zT_384);
    susp_count = zT_392;
    zT_394 = susp_count;
    zT_395 = zF_74FC996E_asyncStateTypeForCo(zT_394);
    state_type = zT_395;
    zT_396 = state_widths;
    zT_397 = key;
    zT_398 = state_type;
    zF_B6EB812C_u64ToU32MapPut(zT_396, zT_397, zT_398);
    zT_400 = 0;
    offset = zT_400;
    zT_402 = 1;
    max_align = zT_402;
    zT_403 = typereg;
    zT_405 = (unsigned int*)&offset;
    zT_406 = (unsigned int*)&max_align;
    zT_410 = zF_769CB99B_addFrameField(zT_403, (unsigned int)(13), zT_405, zT_406);
    (void)zT_410;
    zT_411 = typereg;
    zT_413 = (unsigned int*)&offset;
    zT_414 = (unsigned int*)&max_align;
    zT_418 = zF_769CB99B_addFrameField(zT_411, (unsigned int)(13), zT_413, zT_414);
    (void)zT_418;
    zT_419 = typereg;
    zT_420 = state_type;
    zT_421 = (unsigned int*)&offset;
    zT_422 = (unsigned int*)&max_align;
    zT_425 = zF_769CB99B_addFrameField(zT_419, zT_420, zT_421, zT_422);
    (void)zT_425;
    zT_426 = proto.params_count;
    if ((unsigned char)(zT_426 > (unsigned short)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_430 = proto.params_start;
    zT_431 = (zT_79FAE712_u64)zT_430;
    zT_432 = 32;
    zT_435 = zT_432 < (unsigned int)(64);
    if (!(zT_435)) { pal_trap(); }
    zT_433 = zig_wrap_shl_u(((zu64)(zT_431)), ((zu64)(zT_432)), 64u);
    zT_436 = zig_overflow_flag_shl_u(((zu64)(zT_431)), ((zu64)(zT_432)), 64u);
    zT_438 = zT_436 == (unsigned int)(0);
    if (!(zT_438)) { pal_trap(); }
    zT_439 = proto.params_count;
    zT_441 = zT_433 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_439);
    p_payload = zT_441;
    zT_443 = store;
    zT_444 = p_payload;
    zT_445 = zF_03CE8CAB_astStoreGetExtraChi(zT_443, zT_444);
    pnodes_n = zT_445;
    zT_447 = 0;
    pi = zT_447;
    goto z_bb_74;
    z_bb_73:
    zT_482 = store;
    zT_483 = decl.child_0;
    zT_484 = (zT_B687BB96_U32ArrayList*)&stack;
    zT_485 = typereg;
    zT_486 = resolved_types;
    zT_487 = (unsigned int*)&offset;
    zT_488 = (unsigned int*)&max_align;
    zF_68BD38B1_scanFrameLocals(zT_482, zT_483, zT_484, zT_485, zT_486, zT_487, zT_488);
    zT_494 = 0;
    hid = zT_494;
    zT_495 = async_hidden_fns;
    zT_496 = key;
    zT_497 = zF_A05A7BE1_u64ToU32MapGet(zT_495, zT_496);
    zT_498 = zT_497.has_value;
    if (zT_498) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_451 = store;
    zT_453 = store;
    zT_454 = p_payload;
    zT_457 = zF_E5B10421_astStoreGetExtraChi(zT_453, zT_454, (unsigned int)((unsigned int)pi));
    zT_452 = zT_457;
    zT_458 = zF_FCDD1D35_astStoreNodeAt(zT_451, zT_452);
    pnode = zT_458;
    zT_459 = pnode.child_0;
    if ((unsigned char)(zT_459 == (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_477 = 1;
    zT_478 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_477)), 32u);
    zT_479 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_477)), 32u);
    zT_481 = zT_479 == (unsigned int)(0);
    if (!(zT_481)) { pal_trap(); }
    pi = zT_478;
    goto z_bb_74;
    z_bb_78:
    goto z_bb_77;
    z_bb_79:
    zT_463 = 18;
    pt = zT_463;
    zT_464 = resolved_types;
    zT_465 = pnode.child_0;
    zT_467 = zF_999DCF51_resolvedTypeTableGe(zT_464, zT_465);
    zT_468 = zT_467.has_value;
    if (zT_468) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    if (!(zT_467.has_value)) { pal_trap(); }
    rtp = zT_467.value;
    pt = rtp;
    goto z_bb_81;
    z_bb_81:
    zT_470 = typereg;
    zT_471 = pt;
    zT_472 = (unsigned int*)&offset;
    zT_473 = (unsigned int*)&max_align;
    zT_476 = zF_769CB99B_addFrameField(zT_470, zT_471, zT_472, zT_473);
    (void)zT_476;
    goto z_bb_77;
    z_bb_82:
    if (!(zT_497.has_value)) { pal_trap(); }
    h = zT_497.value;
    hid = h;
    goto z_bb_83;
    z_bb_83:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_504 = typereg;
    zT_508 = typereg;
    zT_509 = zF_FF3C4865_asyncPtrVoid(zT_508);
    zT_505 = zT_509;
    zT_506 = (unsigned int*)&offset;
    zT_507 = (unsigned int*)&max_align;
    zT_512 = zF_769CB99B_addFrameField(zT_504, zT_505, zT_506, zT_507);
    (void)zT_512;
    goto z_bb_85;
    z_bb_85:
    zT_513 = awaited_fns;
    zT_514 = key;
    zT_515 = zF_A05A7BE1_u64ToU32MapGet(zT_513, zT_514);
    zT_516 = zT_515.has_value;
    if (zT_516) goto z_bb_87; else goto z_bb_86;
    z_bb_86:
    zT_518 = driver_targets;
    zT_519 = key;
    zT_520 = zF_A05A7BE1_u64ToU32MapGet(zT_518, zT_519);
    zT_521 = zT_520.has_value;
    zT_517 = zT_521;
    goto z_bb_88;
    z_bb_87:
    zT_517 = 1;
    goto z_bb_88;
    z_bb_88:
    if (zT_517) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_522 = typereg;
    zT_526 = typereg;
    zT_527 = zF_FF3C4865_asyncPtrVoid(zT_526);
    zT_523 = zT_527;
    zT_524 = (unsigned int*)&offset;
    zT_525 = (unsigned int*)&max_align;
    zT_530 = zF_769CB99B_addFrameField(zT_522, zT_523, zT_524, zT_525);
    (void)zT_530;
    goto z_bb_90;
    z_bb_90:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_536 = 0;
    pstart = zT_536;
    zT_537 = parent_result_start;
    zT_538 = key;
    zT_539 = zF_A05A7BE1_u64ToU32MapGet(zT_537, zT_538);
    zT_540 = zT_539.has_value;
    if (zT_540) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_573 = offset;
    zT_574 = max_align;
    zT_575 = zF_978D7C93_alignUpU32(zT_573, zT_574);
    total = zT_575;
    if ((unsigned char)(total == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_93:
    if (!(zT_539.has_value)) { pal_trap(); }
    ps = zT_539.value;
    pstart = ps;
    goto z_bb_94;
    z_bb_94:
    zT_543 = 0;
    pcount = zT_543;
    zT_544 = parent_result_count;
    zT_545 = key;
    zT_546 = zF_A05A7BE1_u64ToU32MapGet(zT_544, zT_545);
    zT_547 = zT_546.has_value;
    if (zT_547) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    if (!(zT_546.has_value)) { pal_trap(); }
    pc = zT_546.value;
    pcount = pc;
    goto z_bb_96;
    z_bb_96:
    zT_550 = 0;
    pk = zT_550;
    goto z_bb_97;
    z_bb_97:
    if ((unsigned char)(pk < pcount)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_553 = parent_result_type_list->items;
    zT_554 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pk)), 32u);
    zT_555 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pk)), 32u);
    zT_557 = zT_555 == (unsigned int)(0);
    if (!(zT_557)) { pal_trap(); }
    zT_558 = (unsigned int)zT_554;
    zT_559 = zT_553[zT_558];
    prt = zT_559;
    zT_560 = typereg;
    zT_561 = prt;
    zT_562 = (unsigned int*)&offset;
    zT_563 = (unsigned int*)&max_align;
    zT_566 = zF_769CB99B_addFrameField(zT_560, zT_561, zT_562, zT_563);
    (void)zT_566;
    goto z_bb_100;
    z_bb_99:
    goto z_bb_92;
    z_bb_100:
    zT_567 = 1;
    zT_568 = zig_wrap_add_u(((zu64)(pk)), ((zu64)(zT_567)), 32u);
    zT_569 = zig_overflow_flag_add_u(((zu64)(pk)), ((zu64)(zT_567)), 32u);
    zT_571 = zT_569 == (unsigned int)(0);
    if (!(zT_571)) { pal_trap(); }
    pk = zT_568;
    goto z_bb_97;
    z_bb_101:
    zT_578 = 1;
    total = zT_578;
    goto z_bb_102;
    z_bb_102:
    zT_579 = total;
    zT_582 = zF_978D7C93_alignUpU32(zT_579, (unsigned int)(8));
    total = zT_582;
    zT_583 = frame_sizes;
    zT_584 = key;
    zT_585 = total;
    zF_B6EB812C_u64ToU32MapPut(zT_583, zT_584, zT_585);
    zT_586 = key;
    zT_587 = total;
    zF_7011AA79_emitFrameMarker(zT_586, zT_587);
    goto z_bb_44;
}

/* __module_init */
void zF_780653D2___module_init_17(void) {
    zT_8143F551_AstKind zT_0;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_8143F551_AstKind = zT_0;
    return;
}

/* EOF */
