#include "growable_array_6014E5AF.h"
zT_B687BB96_U32ArrayList zG_B687BB96_U32ArrayList;
zT_47B162D1_U8ArrayList zG_47B162D1_U8ArrayList;
/* u32ArrayListInit */
zT_B687BB96_U32ArrayList zF_8E537D0C_u32ArrayListInit(zT_3E40CD83_Sand* allocator) {
    zT_B687BB96_U32ArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* u32ArrayListEnsureCapacity */
void zF_1580F084_u32ArrayListEnsureC(zT_B687BB96_U32ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned int* zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_45;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_23 = self->allocator;
    zT_27 = 4;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_35;
    zT_38 = (unsigned int*)raw;
    new_items = zT_38;
    zT_39 = (unsigned int*)self->items;
    zT_40 = self->len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (unsigned int*)zT_42;
    zT_45.len = zT_43;
    zT_46 = (unsigned int*)zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* u32ArrayListAppend */
void zF_62F717A2_u32ArrayListAppend(zT_B687BB96_U32ArrayList* self, unsigned int value) {
    zT_B687BB96_U32ArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_1580F084_u32ArrayListEnsureC(zT_2, zT_3);
    zT_10 = (unsigned int*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* u32ArrayListPopOrNull */
zT_BAEE192E_Opt_10 zF_3F5916E1_u32ArrayListPopOrNu(zT_B687BB96_U32ArrayList* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1 = self->len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2: ;
    zT_5 = self->len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zig_wrap_sub_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    self->len = zT_8;
    zT_12 = (unsigned int*)self->items;
    zT_13 = self->len;
    zT_14 = zT_12[zT_13];
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* u32ArrayListGetSlice */
zT_3CB0179A_Slice_zT_05F374B1_u zF_281E4968_u32ArrayListGetSlic(zT_B687BB96_U32ArrayList* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_7;
    zT_1 = (unsigned int*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (unsigned int*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* byteArrayListInit */
zT_47B162D1_U8ArrayList zF_E9FF0E66_byteArrayListInit(zT_3E40CD83_Sand* allocator) {
    zT_47B162D1_U8ArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (unsigned char*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* byteArrayListGrow */
void zF_59A66857_byteArrayListGrow(zT_47B162D1_U8ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char* zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_DD2B0E80_Opt_263 zT_46;
    unsigned char zT_47;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_FDFD82FD_EU_362 zT_59;
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned char* zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    unsigned int zT_78;
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    unsigned char* new_items;
    unsigned char item;
    unsigned int i;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_22 = self->capacity;
    zT_23 = 0;
    if ((unsigned char)(zT_22 > (unsigned int)zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    zT_26 = self->allocator;
    zT_32 = (unsigned char*)self->items;
    zT_34 = self->capacity;
    zT_35 = 1;
    zT_36 = zig_wrap_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(zT_34)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_28 = zT_36;
    zT_40 = 1;
    zT_41 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_29 = zT_41;
    zT_46 = zF_33A3D4F8_sandTryReallocInPla(zT_26, (unsigned char*)((unsigned char*)zT_32), zT_28, zT_29, (unsigned int)(1));
    grown = zT_46;
    zT_47 = grown.has_value;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_8: ;
    zT_49 = self->allocator;
    zT_53 = 1;
    zT_54 = zig_wrap_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_55 = zig_overflow_flag_mul_u(((zu64)(zT_53)), ((zu64)(new_cap)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_50 = zT_54;
    zT_59 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(1));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_9: ;
    self->capacity = new_cap;
    return;
    z_bb_10: ;
    goto z_bb_8;
    z_bb_11: ;
    pal_trap();
    z_bb_12: ;
    zT_61 = zT_59.data.payload;
    goto z_bb_13;
    z_bb_13: ;
    raw = zT_61;
    zT_64 = (unsigned char*)raw;
    new_items = zT_64;
    zT_65 = (unsigned char*)self->items;
    zT_66 = self->len;
    zT_67 = 0;
    zT_68 = zT_65 + zT_67;
    zT_69 = zT_66 - zT_67;
    zT_70 = (unsigned int)zT_67 <= zT_66;
    if (!(zT_70)) { pal_trap(); }
    zT_71.ptr = (unsigned char*)zT_68;
    zT_71.len = zT_69;
    zT_72 = (unsigned char*)zT_71.ptr;
    zT_73 = zT_71.len;
    i = 0;
    goto z_bb_14;
    z_bb_14: ;
    if ((unsigned char)(i < zT_73)) goto z_bb_15; else goto z_bb_16;
    z_bb_15: ;
    item = zT_72[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_17: ;
    zT_78 = i + (unsigned int)(1);
    i = zT_78;
    goto z_bb_14;
}

/* byteArrayListAppend */
void zF_463FE7A4_byteArrayListAppend(zT_47B162D1_U8ArrayList* self, unsigned char value) {
    zT_47B162D1_U8ArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_59A66857_byteArrayListGrow(zT_2, zT_3);
    zT_10 = (unsigned char*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* byteArrayListGetSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2ADA0742_byteArrayListGetSli(zT_47B162D1_U8ArrayList* self) {
    unsigned char* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_1 = (unsigned char*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (unsigned char*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* astNodeArrayListInit */
zT_1386C3E8_AstNodeArrayList zF_6F8101FA_astNodeArrayListIni(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_1386C3E8_AstNodeArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1386C3E8_AstNodeArrayList* zT_7;
    unsigned int zT_8;
    zT_1386C3E8_AstNodeArrayList list;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.items = (zT_22A7C88B_AstNode*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = (zT_1386C3E8_AstNodeArrayList*)&list;
    zT_8 = initial_capacity;
    zF_BA440392_astNodeArrayListEns(zT_7, zT_8);
    return list;
}

/* astNodeArrayListEnsureCapacity */
void zF_BA440392_astNodeArrayListEns(zT_1386C3E8_AstNodeArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_22A7C88B_AstNode* zT_38;
    zT_22A7C88B_AstNode* zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_22A7C88B_AstNode* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_8FBDC967_Slice_zT_22A7C88B_A zT_45;
    zT_22A7C88B_AstNode* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw;
    zT_22A7C88B_AstNode* new_items;
    zT_22A7C88B_AstNode item;
    unsigned int i;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_23 = self->allocator;
    zT_27 = 24;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_35;
    zT_38 = (zT_22A7C88B_AstNode*)raw;
    new_items = zT_38;
    zT_39 = (zT_22A7C88B_AstNode*)self->items;
    zT_40 = self->len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (zT_22A7C88B_AstNode*)zT_42;
    zT_45.len = zT_43;
    zT_46 = (zT_22A7C88B_AstNode*)zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* astNodeArrayListAppend */
void zF_FFA68CD0_astNodeArrayListApp(zT_1386C3E8_AstNodeArrayList* self, zT_22A7C88B_AstNode value) {
    zT_1386C3E8_AstNodeArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_22A7C88B_AstNode* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_BA440392_astNodeArrayListEns(zT_2, zT_3);
    zT_10 = (zT_22A7C88B_AstNode*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* astNodeArrayListGetSlice */
zT_8FBDC967_Slice_zT_22A7C88B_A zF_BD2D926E_astNodeArrayListGet(zT_1386C3E8_AstNodeArrayList* self) {
    zT_22A7C88B_AstNode* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_22A7C88B_AstNode* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_8FBDC967_Slice_zT_22A7C88B_A zT_7;
    zT_1 = (zT_22A7C88B_AstNode*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_22A7C88B_AstNode*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* u64ArrayListInit */
zT_C4A0A7DB_U64ArrayList zF_477F0605_u64ArrayListInit(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_C4A0A7DB_U64ArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_C4A0A7DB_U64ArrayList* zT_7;
    unsigned int zT_8;
    zT_C4A0A7DB_U64ArrayList list;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.items = (zT_79FAE712_u64*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = (zT_C4A0A7DB_U64ArrayList*)&list;
    zT_8 = initial_capacity;
    zF_111B1CFD_u64ArrayListEnsureC(zT_7, zT_8);
    return list;
}

/* u64ArrayListEnsureCapacity */
void zF_111B1CFD_u64ArrayListEnsureC(zT_C4A0A7DB_U64ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_79FAE712_u64* zT_38;
    zT_79FAE712_u64* zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_79FAE712_u64* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_45;
    zT_79FAE712_u64* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw;
    zT_79FAE712_u64* new_items;
    zT_79FAE712_u64 item;
    unsigned int i;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_23 = self->allocator;
    zT_27 = 8;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_35;
    zT_38 = (zT_79FAE712_u64*)raw;
    new_items = zT_38;
    zT_39 = (zT_79FAE712_u64*)self->items;
    zT_40 = self->len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (zT_79FAE712_u64*)zT_42;
    zT_45.len = zT_43;
    zT_46 = (zT_79FAE712_u64*)zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* u64ArrayListAppend */
void zF_A553AD3B_u64ArrayListAppend(zT_C4A0A7DB_U64ArrayList* self, zT_79FAE712_u64 value) {
    zT_C4A0A7DB_U64ArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_79FAE712_u64* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_111B1CFD_u64ArrayListEnsureC(zT_2, zT_3);
    zT_10 = (zT_79FAE712_u64*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* u64ArrayListGetSlice */
zT_A62C5D8D_Slice_zT_79FAE712_u zF_87EC4681_u64ArrayListGetSlic(zT_C4A0A7DB_U64ArrayList* self) {
    zT_79FAE712_u64* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_79FAE712_u64* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_7;
    zT_1 = (zT_79FAE712_u64*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_79FAE712_u64*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* f64ArrayListInit */
zT_AB1FE668_F64ArrayList zF_5950A33A_f64ArrayListInit(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_AB1FE668_F64ArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_AB1FE668_F64ArrayList* zT_7;
    unsigned int zT_8;
    zT_AB1FE668_F64ArrayList list;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.items = (zT_00435AEB_f64*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = (zT_AB1FE668_F64ArrayList*)&list;
    zT_8 = initial_capacity;
    zF_7F2FDCD2_f64ArrayListEnsureC(zT_7, zT_8);
    return list;
}

/* f64ArrayListEnsureCapacity */
void zF_7F2FDCD2_f64ArrayListEnsureC(zT_AB1FE668_F64ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_00435AEB_f64* zT_38;
    zT_00435AEB_f64* zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_00435AEB_f64* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_45;
    zT_00435AEB_f64* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw;
    zT_00435AEB_f64* new_items;
    zT_00435AEB_f64 item;
    unsigned int i;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_23 = self->allocator;
    zT_27 = 8;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_35;
    zT_38 = (zT_00435AEB_f64*)raw;
    new_items = zT_38;
    zT_39 = (zT_00435AEB_f64*)self->items;
    zT_40 = self->len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (zT_00435AEB_f64*)zT_42;
    zT_45.len = zT_43;
    zT_46 = (zT_00435AEB_f64*)zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* f64ArrayListAppend */
void zF_0317E610_f64ArrayListAppend(zT_AB1FE668_F64ArrayList* self, zT_00435AEB_f64 value) {
    zT_AB1FE668_F64ArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_00435AEB_f64* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_7F2FDCD2_f64ArrayListEnsureC(zT_2, zT_3);
    zT_10 = (zT_00435AEB_f64*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* f64ArrayListGetSlice */
zT_ACF60AF6_Slice_zT_00435AEB_f zF_96EB7CAE_f64ArrayListGetSlic(zT_AB1FE668_F64ArrayList* self) {
    zT_00435AEB_f64* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_00435AEB_f64* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_7;
    zT_1 = (zT_00435AEB_f64*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_00435AEB_f64*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* fnProtoArrayListInit */
zT_CCB21906_FnProtoArrayList zF_315F8F5C_fnProtoArrayListIni(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_CCB21906_FnProtoArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_CCB21906_FnProtoArrayList* zT_7;
    unsigned int zT_8;
    zT_CCB21906_FnProtoArrayList list;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.items = (zT_243D6A41_FnProto*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = (zT_CCB21906_FnProtoArrayList*)&list;
    zT_8 = initial_capacity;
    zF_D57F7CF4_fnProtoArrayListEns(zT_7, zT_8);
    return list;
}

/* fnProtoArrayListEnsureCapacity */
void zF_D57F7CF4_fnProtoArrayListEns(zT_CCB21906_FnProtoArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_243D6A41_FnProto* zT_38;
    zT_243D6A41_FnProto* zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_243D6A41_FnProto* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_45;
    zT_243D6A41_FnProto* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw;
    zT_243D6A41_FnProto* new_items;
    zT_243D6A41_FnProto item;
    unsigned int i;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_12 = self->capacity;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4: ;
    zT_18 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5: ;
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    new_cap = zT_21;
    goto z_bb_6;
    z_bb_6: ;
    zT_23 = self->allocator;
    zT_27 = 16;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(new_cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7: ;
    pal_trap();
    z_bb_8: ;
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9: ;
    raw = zT_35;
    zT_38 = (zT_243D6A41_FnProto*)raw;
    new_items = zT_38;
    zT_39 = (zT_243D6A41_FnProto*)self->items;
    zT_40 = self->len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (zT_243D6A41_FnProto*)zT_42;
    zT_45.len = zT_43;
    zT_46 = (zT_243D6A41_FnProto*)zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10: ;
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11: ;
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12: ;
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13: ;
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* fnProtoArrayListAppend */
void zF_919D3F12_fnProtoArrayListApp(zT_CCB21906_FnProtoArrayList* self, zT_243D6A41_FnProto value) {
    zT_CCB21906_FnProtoArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_243D6A41_FnProto* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_D57F7CF4_fnProtoArrayListEns(zT_2, zT_3);
    zT_10 = (zT_243D6A41_FnProto*)self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    self->len = zT_15;
    return;
}

/* fnProtoArrayListGetSlice */
zT_91F8F99F_Slice_zT_243D6A41_F zF_A4813F98_fnProtoArrayListGet(zT_CCB21906_FnProtoArrayList* self) {
    zT_243D6A41_FnProto* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_243D6A41_FnProto* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_7;
    zT_1 = (zT_243D6A41_FnProto*)self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_243D6A41_FnProto*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* EOF */
