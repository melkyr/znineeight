#include "type_resolver_7446D285.h"
#include <stdio.h>
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int const zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
static unsigned int const zG_1DA72E61_MAX_FN_PARAMS = (unsigned int)(64);
static unsigned int const zG_F8F0AD97_MAX_CONTAINER_FIELD = (unsigned int)(32);
/* localTypeScopeInit */
zT_C8A278E4_LocalTypeScope zF_8A85AA66_localTypeScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_C8A278E4_LocalTypeScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.names = (unsigned int*)zT_2;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1.types = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* nameScopeGrowPair */
void zF_F638C869_nameScopeGrowPair(zT_3E40CD83_Sand* alloc, unsigned int** names, unsigned int** values, unsigned int count, unsigned int* cap, unsigned int min_cap) {
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_FDFD82FD_EU_362 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_3E40CD83_Sand* zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    zT_FDFD82FD_EU_362 zT_40;
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int* zT_45;
    unsigned int* zT_47;
    int zT_49;
    unsigned int zT_50;
    unsigned int* zT_52;
    unsigned int zT_53;
    unsigned int* zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_v;
    unsigned int* nn;
    unsigned int* nv;
    unsigned int i;
    zT_7 = *cap;
    if ((unsigned char)(zT_7 < min_cap)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = min_cap;
    goto z_bb_3;
    z_bb_2:
    zT_10 = *cap;
    zT_11 = 2;
    zT_12 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_9 = zT_12;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_17 = alloc;
    zT_20 = 4;
    zT_21 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_18 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_17, zT_18, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_28 = zT_26.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_n = zT_28;
    zT_31 = alloc;
    zT_34 = 4;
    zT_35 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    zT_32 = zT_35;
    zT_40 = zF_1395EB68_sandAlloc(zT_31, zT_32, (unsigned int)(4));
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_42 = zT_40.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_v = zT_42;
    zT_45 = (unsigned int*)raw_n;
    nn = zT_45;
    zT_47 = (unsigned int*)raw_v;
    nv = zT_47;
    zT_49 = 0;
    zT_50 = (unsigned int)zT_49;
    i = zT_50;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < count)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_52 = *names;
    zT_53 = zT_52[i];
    nn[i] = zT_53;
    zT_54 = *values;
    zT_55 = zT_54[i];
    nv[i] = zT_55;
    goto z_bb_13;
    z_bb_12:
    *names = nn;
    *values = nv;
    *cap = nc;
    return;
    z_bb_13:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    i = zT_58;
    goto z_bb_10;
}

/* nameScopeLookup */
zT_BAEE192E_Opt_10 zF_1B08A8E4_nameScopeLookup(unsigned int* names, unsigned int* values, unsigned int count, unsigned int name_id) {
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zT_BAEE192E_Opt_10 zT_16;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned int i;
    i = count;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_8 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    i = zT_8;
    zT_12 = names[i];
    if ((unsigned char)(zT_12 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_16.has_value = 0;
    return zT_16;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_14 = values[i];
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
    z_bb_6:
    goto z_bb_4;
}

/* localTypeScopePush */
void zF_A3A445A0_localTypeScopePush(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->types;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->types;
    zT_21 = scope->count;
    zT_20[zT_21] = type_id;
    zT_22 = scope->count;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    scope->count = zT_24;
    return;
}

/* localTypeScopeLookup */
zT_BAEE192E_Opt_10 zF_C768898A_localTypeScopeLooku(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_2 = scope->names;
    zT_3 = scope->types;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* localConstScopeInit */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_E2DF2801_LocalConstScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.names = (unsigned int*)zT_2;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1.nodes = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localConstScopePush */
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->nodes;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->nodes;
    zT_21 = scope->count;
    zT_20[zT_21] = decl_node;
    zT_22 = scope->count;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    scope->count = zT_24;
    return;
}

/* localConstScopeLookup */
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_2 = scope->names;
    zT_3 = scope->nodes;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* rawArrayEnsureCapacity */
void zF_BEFE4370_rawArrayEnsureCapac(zT_3E40CD83_Sand* alloc, unsigned char** items, unsigned int len, unsigned int* cap, unsigned int elem_size, unsigned int min_cap) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    int zT_19;
    zT_3E40CD83_Sand* zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_DD2B0E80_Opt_263 zT_38;
    unsigned char zT_39;
    zT_3E40CD83_Sand* zT_41;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_FDFD82FD_EU_362 zT_49;
    unsigned char zT_50;
    unsigned char* zT_51;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char* zT_61;
    unsigned char zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    unsigned int nc;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    unsigned int ei;
    zT_6 = *cap;
    if ((unsigned char)(len < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap;
    if ((unsigned char)(zT_9 < min_cap)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = min_cap;
    goto z_bb_5;
    z_bb_4:
    zT_12 = *cap;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_11 = zT_14;
    goto z_bb_5;
    z_bb_5:
    nc = zT_11;
    zT_18 = *cap;
    zT_19 = 0;
    if ((unsigned char)(zT_18 > (unsigned int)zT_19)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = alloc;
    zT_23 = *items;
    zT_28 = *cap;
    zT_29 = zig_wrap_mul_u(((zu64)(zT_28)), ((zu64)(elem_size)), 32u);
    zT_30 = zig_overflow_flag_mul_u(((zu64)(zT_28)), ((zu64)(elem_size)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_24 = zT_29;
    zT_33 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(elem_size)), 32u);
    zT_34 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(elem_size)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_25 = zT_33;
    zT_38 = zF_33A3D4F8_sandTryReallocInPla(zT_22, zT_23, zT_24, zT_25, (unsigned int)(4));
    grown = zT_38;
    zT_39 = grown.has_value;
    if (zT_39) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_41 = alloc;
    zT_44 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(elem_size)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(elem_size)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_42 = zT_44;
    zT_49 = zF_1395EB68_sandAlloc(zT_41, zT_42, (unsigned int)(4));
    zT_50 = zT_49.is_error;
    if (zT_50) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    *cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_51 = zT_49.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_51;
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ei = zT_55;
    goto z_bb_13;
    z_bb_13:
    zT_56 = zig_wrap_mul_u(((zu64)(len)), ((zu64)(elem_size)), 32u);
    zT_57 = zig_overflow_flag_mul_u(((zu64)(len)), ((zu64)(elem_size)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    if ((unsigned char)(ei < zT_56)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_61 = *items;
    zT_62 = zT_61[ei];
    raw[ei] = zT_62;
    goto z_bb_16;
    z_bb_15:
    *items = raw;
    *cap = nc;
    return;
    z_bb_16:
    zT_63 = 1;
    zT_64 = (unsigned int)zT_63;
    zT_65 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_64)), 32u);
    zT_66 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_64)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    ei = zT_65;
    goto z_bb_13;
}

/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    zT_52CDA6EF_DepEdge* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->depend_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = (unsigned char**)&p;
    zT_6 = self->depend_len;
    zT_7 = &self->depend_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(8), (unsigned int)(8));
    self->depend_items = (zT_52CDA6EF_DepEdge*)((zT_52CDA6EF_DepEdge*)p);
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    zT_9 = (unsigned int)zT_8;
    zT_10 = zig_wrap_add_u(((zu64)(zT_7)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_add_u(((zu64)(zT_7)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    self->depend_len = zT_10;
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->worklist_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = (unsigned char**)&p;
    zT_6 = self->worklist_len;
    zT_7 = &self->worklist_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(4), (unsigned int)(64));
    self->worklist_items = (unsigned int*)((unsigned int*)p);
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zig_wrap_add_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_add_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    self->worklist_len = zT_8;
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zig_wrap_sub_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    self->worklist_len = zT_8;
    zT_12 = self->worklist_items;
    zT_13 = self->worklist_len;
    zT_14 = zT_12[zT_13];
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_FDFD82FD_EU_362 zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((unsigned char)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((unsigned char)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_14 = 4;
    zT_15 = zig_wrap_mul_u(((zu64)(nc)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(nc)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_11 = zT_15;
    zT_20 = zF_1395EB68_sandAlloc(zT_10, zT_11, (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_22 = zT_20.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_22;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_2 = zig_wrap_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_3 = zig_overflow_flag_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_5 = zT_3 == (unsigned int)(0);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = 1;
    zT_12 = zig_wrap_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    return (unsigned int)(zT_7 & (unsigned int)(~zT_12));
}

/* markerU32 */
void zF_C8A36147_markerU32(unsigned int value) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_5826BFC7_Arr_unsigned_char_1 b;
    unsigned int l;
    unsigned int s;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = value;
    zT_8 = 0;
    zT_9 = (unsigned char*)((unsigned char*)b) + zT_8;
    zT_10 = (unsigned int)(12) - zT_8;
    zT_11.ptr = (unsigned char*)zT_9;
    zT_11.len = zT_10;
    zT_5 = zT_11;
    zT_12 = zF_A7504564_itoa(zT_4, zT_5);
    l = zT_12;
    zT_14 = 11;
    zT_15 = (unsigned int)l;
    zT_16 = zig_wrap_sub_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_sub_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    s = zT_16;
    zT_23 = 11;
    zT_24 = (unsigned char*)((unsigned char*)b) + s;
    zT_25 = zT_23 - s;
    zT_26 = s <= zT_23;
    if (!(zT_26)) { pal_trap(); }
    zT_27.ptr = (unsigned char*)zT_24;
    zT_27.len = zT_25;
    zT_20 = zT_27;
    zF_48AC7B3A_markerWrite(zT_20);
    return;
}

/* layoutCompute */
void zF_0E9E97D8_layoutCompute(zT_338B7C76_TypeRegistry* registry, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_2DF01B61_FieldEntry* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_2DF01B61_FieldEntry zT_45;
    zT_D155D06D_Type* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    zT_2DF01B61_FieldEntry* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned int zT_60;
    unsigned short zT_62;
    unsigned int zT_64;
    zT_2DF01B61_FieldEntry* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    unsigned short zT_75;
    unsigned short zT_77;
    unsigned int zT_78;
    int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned short zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type* zT_94;
    zT_33EF6BFB_TypeKind zT_95;
    zT_457ECFEE_EnumPayload* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_457ECFEE_EnumPayload zT_103;
    zT_D155D06D_Type* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    unsigned int zT_109;
    unsigned short zT_110;
    zT_D155D06D_Type* zT_112;
    zT_33EF6BFB_TypeKind zT_113;
    zT_AF9231A2_UnionPayload* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_AF9231A2_UnionPayload zT_121;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned short zT_126;
    unsigned int zT_127;
    int zT_129;
    unsigned int zT_130;
    int zT_132;
    unsigned int zT_133;
    int zT_135;
    unsigned int zT_136;
    zT_2DF01B61_FieldEntry* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned char zT_143;
    zT_2DF01B61_FieldEntry zT_144;
    zT_D155D06D_Type* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_D155D06D_Type zT_149;
    zT_33EF6BFB_TypeKind zT_150;
    unsigned int zT_154;
    unsigned int zT_156;
    unsigned short zT_157;
    unsigned short zT_159;
    unsigned int zT_160;
    int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned char zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned short zT_170;
    unsigned int zT_171;
    zT_D155D06D_Type* zT_176;
    zT_33EF6BFB_TypeKind zT_177;
    zT_338B7C76_TypeRegistry* zT_181;
    unsigned int zT_182;
    zT_33EF6BFB_TypeKind zT_183;
    zT_54FF90FA_TaggedUnionPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_54FF90FA_TaggedUnionPayload zT_191;
    zT_D155D06D_Type* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_D155D06D_Type zT_196;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned short zT_201;
    unsigned int zT_202;
    int zT_204;
    unsigned int zT_205;
    int zT_207;
    unsigned int zT_208;
    int zT_210;
    unsigned int zT_211;
    zT_2DF01B61_FieldEntry* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    unsigned char zT_218;
    zT_2DF01B61_FieldEntry zT_219;
    unsigned char* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned char zT_229;
    unsigned char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_D155D06D_Type* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_D155D06D_Type zT_242;
    zT_33EF6BFB_TypeKind zT_243;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned short zT_250;
    unsigned short zT_252;
    unsigned int zT_253;
    int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned char zT_259;
    unsigned short zT_261;
    unsigned int zT_264;
    unsigned short zT_265;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned char zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned short zT_282;
    zT_D155D06D_Type* zT_283;
    zT_33EF6BFB_TypeKind zT_284;
    zT_0B10E8E9_OptionalPayload* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    zT_0B10E8E9_OptionalPayload zT_292;
    zT_D155D06D_Type* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_D155D06D_Type zT_297;
    unsigned short zT_299;
    unsigned int zT_303;
    unsigned short zT_304;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned char zT_318;
    unsigned int zT_319;
    unsigned short zT_320;
    zT_D155D06D_Type* zT_321;
    zT_33EF6BFB_TypeKind zT_322;
    zT_42C2D6BF_EUPayload* zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    zT_42C2D6BF_EUPayload zT_330;
    zT_D155D06D_Type* zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    zT_D155D06D_Type zT_335;
    unsigned int zT_337;
    unsigned int zT_340;
    unsigned short zT_344;
    unsigned int zT_348;
    unsigned short zT_349;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    unsigned int zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned char zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned short zT_368;
    zT_D155D06D_Type* zT_369;
    zT_33EF6BFB_TypeKind zT_370;
    zT_E834303C_ArrayPayload* zT_375;
    unsigned int zT_376;
    unsigned int zT_377;
    zT_E834303C_ArrayPayload zT_378;
    zT_D155D06D_Type* zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    zT_D155D06D_Type zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    unsigned char zT_389;
    unsigned short zT_390;
    zT_D155D06D_Type* zT_392;
    zT_33EF6BFB_TypeKind zT_393;
    zT_666DC2E1_TuplePayload* zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    zT_666DC2E1_TuplePayload zT_401;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned short zT_406;
    unsigned int zT_407;
    int zT_409;
    unsigned int zT_410;
    int zT_412;
    unsigned int zT_413;
    int zT_415;
    unsigned int zT_416;
    unsigned int* zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned char zT_423;
    unsigned int zT_424;
    zT_D155D06D_Type* zT_426;
    unsigned int zT_427;
    zT_D155D06D_Type zT_428;
    unsigned int zT_429;
    unsigned short zT_431;
    unsigned int zT_433;
    unsigned int zT_434;
    unsigned int zT_435;
    unsigned int zT_436;
    unsigned char zT_438;
    unsigned short zT_439;
    unsigned short zT_441;
    unsigned int zT_442;
    int zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    unsigned char zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned short zT_452;
    unsigned int zT_453;
    zT_D155D06D_Type* zT_458;
    zT_33EF6BFB_TypeKind zT_459;
    zT_D155D06D_Type* zT_465;
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_271, (unsigned int)sizeof zT_271);
    zig_poison_fill((void*)&zT_274, (unsigned int)sizeof zT_274);
    zig_poison_fill((void*)&zT_281, (unsigned int)sizeof zT_281);
    zig_poison_fill((void*)&zT_313, (unsigned int)sizeof zT_313);
    zig_poison_fill((void*)&zT_319, (unsigned int)sizeof zT_319);
    zig_poison_fill((void*)&zT_355, (unsigned int)sizeof zT_355);
    zig_poison_fill((void*)&zT_359, (unsigned int)sizeof zT_359);
    zig_poison_fill((void*)&zT_367, (unsigned int)sizeof zT_367);
    zig_poison_fill((void*)&zT_433, (unsigned int)sizeof zT_433);
    zig_poison_fill((void*)&zT_451, (unsigned int)sizeof zT_451);
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = registry->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_11 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_11 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_95 = ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_16 = registry;
    zT_17 = tid;
    zF_331152CD_typeRegistryCompute(zT_16, zT_17);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_19 = registry->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_24 = sp.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = sp.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    offset = zT_31;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    max_align = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    fi = zT_37;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = registry->fe_items;
    zT_41 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_45 = zT_40[zT_41];
    fe = zT_45;
    zT_47 = registry->types_items;
    zT_48 = fe.type_id;
    zT_49 = (unsigned int)zT_48;
    zT_50 = zT_47[zT_49];
    ft = zT_50;
    zT_51 = ft.kind;
    if ((unsigned char)(zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_85 = offset;
    zT_86 = max_align;
    zT_87 = zF_D2BAC673_alignUp_1(zT_85, zT_86);
    ty.size = zT_87;
    zT_88 = (unsigned short)zig_cast_checked_u((zu64)max_align, 32u, 0u, 16u);
    ty.alignment = zT_88;
    zT_89 = ty.size;
    if ((unsigned char)(zT_89 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_79 = 1;
    zT_80 = (unsigned int)zT_79;
    zT_81 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    fi = zT_81;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_55 = registry->fe_items;
    zT_56 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    zT_55[zT_56] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_60 = offset;
    zT_62 = ft.alignment;
    zT_64 = zF_D2BAC673_alignUp_1(zT_60, (unsigned int)((unsigned int)zT_62));
    offset = zT_64;
    fe.offset = offset;
    zT_65 = registry->fe_items;
    zT_66 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_65[zT_66] = fe;
    zT_70 = ft.size;
    zT_71 = zig_wrap_add_u(((zu64)(offset)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(offset)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    offset = zT_71;
    zT_75 = ft.alignment;
    if ((unsigned char)(zT_75 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_77 = ft.alignment;
    zT_78 = (unsigned int)zT_77;
    max_align = zT_78;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_17;
    z_bb_17:
    zT_94 = registry->types_items;
    zT_94[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_100 = registry->en_items;
    zT_101 = ty.payload_idx;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    ep = zT_103;
    zT_105 = registry->types_items;
    zT_106 = ep.backing_type;
    zT_107 = (unsigned int)zT_106;
    zT_108 = zT_105[zT_107];
    bt = zT_108;
    zT_109 = bt.size;
    ty.size = zT_109;
    zT_110 = bt.alignment;
    ty.alignment = (unsigned short)((unsigned short)zT_110);
    zT_112 = registry->types_items;
    zT_112[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_113 = ty.kind;
    if ((unsigned char)(zT_113 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_118 = registry->un_items;
    zT_119 = ty.payload_idx;
    zT_120 = (unsigned int)zT_119;
    zT_121 = zT_118[zT_120];
    up = zT_121;
    zT_123 = up.fields_start;
    zT_124 = (unsigned int)zT_123;
    fstart = zT_124;
    zT_126 = up.fields_count;
    zT_127 = (unsigned int)zT_126;
    fcount = zT_127;
    zT_129 = 0;
    zT_130 = (unsigned int)zT_129;
    max_sz = zT_130;
    zT_132 = 1;
    zT_133 = (unsigned int)zT_132;
    max_align = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned int)zT_135;
    fi = zT_136;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_177 = ty.kind;
    if ((unsigned char)(zT_177 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((unsigned char)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_139 = registry->fe_items;
    zT_140 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_141 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_143 = zT_141 == (unsigned int)(0);
    if (!(zT_143)) { pal_trap(); }
    zT_144 = zT_139[zT_140];
    fe = zT_144;
    zT_146 = registry->types_items;
    zT_147 = fe.type_id;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    ft = zT_149;
    zT_150 = ft.kind;
    if ((unsigned char)(zT_150 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_167 = max_sz;
    zT_168 = max_align;
    zT_169 = zF_D2BAC673_alignUp_1(zT_167, zT_168);
    ty.size = zT_169;
    zT_170 = (unsigned short)zig_cast_checked_u((zu64)max_align, 32u, 0u, 16u);
    ty.alignment = zT_170;
    zT_171 = ty.size;
    if ((unsigned char)(zT_171 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_161 = 1;
    zT_162 = (unsigned int)zT_161;
    zT_163 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_162)), 32u);
    zT_164 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_162)), 32u);
    zT_166 = zT_164 == (unsigned int)(0);
    if (!(zT_166)) { pal_trap(); }
    fi = zT_163;
    goto z_bb_24;
    z_bb_28:
    zT_154 = ft.size;
    if ((unsigned char)(zT_154 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_156 = ft.size;
    max_sz = zT_156;
    goto z_bb_31;
    z_bb_31:
    zT_157 = ft.alignment;
    if ((unsigned char)(zT_157 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_159 = ft.alignment;
    zT_160 = (unsigned int)zT_159;
    max_align = zT_160;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_35;
    z_bb_35:
    zT_176 = registry->types_items;
    zT_176[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_181 = registry;
    zT_182 = tid;
    zF_62A8E268_typeRegistryCompute(zT_181, zT_182);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_183 = ty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_188 = registry->tu_items;
    zT_189 = ty.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    tp = zT_191;
    zT_193 = registry->types_items;
    zT_194 = tp.tag_type;
    zT_195 = (unsigned int)zT_194;
    zT_196 = zT_193[zT_195];
    tag_ty = zT_196;
    zT_198 = tp.fields_start;
    zT_199 = (unsigned int)zT_198;
    fstart = zT_199;
    zT_201 = tp.fields_count;
    zT_202 = (unsigned int)zT_201;
    fcount = zT_202;
    zT_204 = 0;
    zT_205 = (unsigned int)zT_204;
    max_ps = zT_205;
    zT_207 = 1;
    zT_208 = (unsigned int)zT_207;
    max_pa = zT_208;
    zT_210 = 0;
    zT_211 = (unsigned int)zT_210;
    fi = zT_211;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_284 = ty.kind;
    if ((unsigned char)(zT_284 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((unsigned char)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_214 = registry->fe_items;
    zT_215 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_216 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_218 = zT_216 == (unsigned int)(0);
    if (!(zT_218)) { pal_trap(); }
    zT_219 = zT_214[zT_215];
    fe = zT_219;
    zT_221 = "FER:n";
    zT_223 = 5;
    zT_222.ptr = (unsigned char*)zT_221;
    zT_222.len = zT_223;
    fer_nm = zT_222;
    zT_224 = fer_nm;
    zT_226 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_227 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_229 = zT_227 == (unsigned int)(0);
    if (!(zT_229)) { pal_trap(); }
    zF_C914CB83_markerWriteInt(zT_224, (unsigned int)((unsigned int)zT_226));
    zT_232 = "FER:t";
    zT_234 = 5;
    zT_233.ptr = (unsigned char*)zT_232;
    zT_233.len = zT_234;
    fer_tm = zT_233;
    zT_235 = fer_tm;
    zT_236 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_235, zT_236);
    zT_239 = registry->types_items;
    zT_240 = fe.type_id;
    zT_241 = (unsigned int)zT_240;
    zT_242 = zT_239[zT_241];
    ft = zT_242;
    zT_243 = ft.kind;
    if ((unsigned char)(zT_243 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_261 = tag_ty.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_261) > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_254 = 1;
    zT_255 = (unsigned int)zT_254;
    zT_256 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_255)), 32u);
    zT_257 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_255)), 32u);
    zT_259 = zT_257 == (unsigned int)(0);
    if (!(zT_259)) { pal_trap(); }
    fi = zT_256;
    goto z_bb_42;
    z_bb_46:
    zT_247 = ft.size;
    if ((unsigned char)(zT_247 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_249 = ft.size;
    max_ps = zT_249;
    goto z_bb_49;
    z_bb_49:
    zT_250 = ft.alignment;
    if ((unsigned char)(zT_250 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_252 = ft.alignment;
    zT_253 = (unsigned int)zT_252;
    max_pa = zT_253;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_265 = tag_ty.alignment;
    zT_264 = (unsigned int)zT_265;
    goto z_bb_54;
    z_bb_53:
    zT_264 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_264;
    zT_268 = tag_ty.size;
    total = zT_268;
    zT_269 = total;
    zT_270 = max_pa;
    zT_271 = zF_D2BAC673_alignUp_1(zT_269, zT_270);
    total = zT_271;
    zT_272 = max_ps;
    zT_273 = max_pa;
    zT_274 = zF_D2BAC673_alignUp_1(zT_272, zT_273);
    zT_275 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_274)), 32u);
    zT_276 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_274)), 32u);
    zT_278 = zT_276 == (unsigned int)(0);
    if (!(zT_278)) { pal_trap(); }
    total = zT_275;
    zT_279 = total;
    zT_280 = overall_align;
    zT_281 = zF_D2BAC673_alignUp_1(zT_279, zT_280);
    ty.size = zT_281;
    zT_282 = (unsigned short)zig_cast_checked_u((zu64)overall_align, 32u, 0u, 16u);
    ty.alignment = zT_282;
    zT_283 = registry->types_items;
    zT_283[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_289 = registry->opt_items;
    zT_290 = ty.payload_idx;
    zT_291 = (unsigned int)zT_290;
    zT_292 = zT_289[zT_291];
    op = zT_292;
    zT_294 = registry->types_items;
    zT_295 = op.payload;
    zT_296 = (unsigned int)zT_295;
    zT_297 = zT_294[zT_296];
    pt = zT_297;
    zT_299 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_299) > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_322 = ty.kind;
    if ((unsigned char)(zT_322 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_304 = pt.alignment;
    zT_303 = (unsigned int)zT_304;
    goto z_bb_60;
    z_bb_59:
    zT_303 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_303;
    zT_309 = pt.size;
    zT_313 = zF_D2BAC673_alignUp_1(zT_309, (unsigned int)(4));
    zT_314 = 4;
    zT_315 = zig_wrap_add_u(((zu64)(zT_313)), ((zu64)(zT_314)), 32u);
    zT_316 = zig_overflow_flag_add_u(((zu64)(zT_313)), ((zu64)(zT_314)), 32u);
    zT_318 = zT_316 == (unsigned int)(0);
    if (!(zT_318)) { pal_trap(); }
    zT_307 = zT_315;
    zT_308 = pay_align;
    zT_319 = zF_D2BAC673_alignUp_1(zT_307, zT_308);
    ty.size = zT_319;
    zT_320 = (unsigned short)zig_cast_checked_u((zu64)pay_align, 32u, 0u, 16u);
    ty.alignment = zT_320;
    zT_321 = registry->types_items;
    zT_321[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_327 = registry->eu_items;
    zT_328 = ty.payload_idx;
    zT_329 = (unsigned int)zT_328;
    zT_330 = zT_327[zT_329];
    ep_1 = zT_330;
    zT_332 = registry->types_items;
    zT_333 = ep_1.payload;
    zT_334 = (unsigned int)zT_333;
    zT_335 = zT_332[zT_334];
    pt = zT_335;
    zT_337 = pt.size;
    if ((unsigned char)(zT_337 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_370 = ty.kind;
    if ((unsigned char)(zT_370 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_340 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_340 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_340;
    zT_344 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_344) > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_349 = pt.alignment;
    zT_348 = (unsigned int)zT_349;
    goto z_bb_69;
    z_bb_68:
    zT_348 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_348;
    zT_353 = union_sz;
    zT_354 = union_align;
    zT_355 = zF_D2BAC673_alignUp_1(zT_353, zT_354);
    total = zT_355;
    zT_356 = total;
    zT_359 = zF_D2BAC673_alignUp_1(zT_356, (unsigned int)(4));
    zT_360 = 4;
    zT_361 = zig_wrap_add_u(((zu64)(zT_359)), ((zu64)(zT_360)), 32u);
    zT_362 = zig_overflow_flag_add_u(((zu64)(zT_359)), ((zu64)(zT_360)), 32u);
    zT_364 = zT_362 == (unsigned int)(0);
    if (!(zT_364)) { pal_trap(); }
    total = zT_361;
    zT_365 = total;
    zT_366 = union_align;
    zT_367 = zF_D2BAC673_alignUp_1(zT_365, zT_366);
    ty.size = zT_367;
    zT_368 = (unsigned short)zig_cast_checked_u((zu64)union_align, 32u, 0u, 16u);
    ty.alignment = zT_368;
    zT_369 = registry->types_items;
    zT_369[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_375 = registry->array_items;
    zT_376 = ty.payload_idx;
    zT_377 = (unsigned int)zT_376;
    zT_378 = zT_375[zT_377];
    ap = zT_378;
    zT_380 = registry->types_items;
    zT_381 = ap.elem;
    zT_382 = (unsigned int)zT_381;
    zT_383 = zT_380[zT_382];
    et = zT_383;
    zT_384 = et.size;
    zT_385 = ap.length;
    zT_386 = zig_wrap_mul_u(((zu64)(zT_384)), ((zu64)(zT_385)), 32u);
    zT_387 = zig_overflow_flag_mul_u(((zu64)(zT_384)), ((zu64)(zT_385)), 32u);
    zT_389 = zT_387 == (unsigned int)(0);
    if (!(zT_389)) { pal_trap(); }
    ty.size = zT_386;
    zT_390 = et.alignment;
    ty.alignment = (unsigned short)((unsigned short)zT_390);
    zT_392 = registry->types_items;
    zT_392[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_393 = ty.kind;
    if ((unsigned char)(zT_393 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_398 = registry->tup_items;
    zT_399 = ty.payload_idx;
    zT_400 = (unsigned int)zT_399;
    zT_401 = zT_398[zT_400];
    tp_2 = zT_401;
    zT_403 = tp_2.elems_start;
    zT_404 = (unsigned int)zT_403;
    estr = zT_404;
    zT_406 = tp_2.elems_count;
    zT_407 = (unsigned int)zT_406;
    ecount = zT_407;
    zT_409 = 0;
    zT_410 = (unsigned int)zT_409;
    offset = zT_410;
    zT_412 = 1;
    zT_413 = (unsigned int)zT_412;
    max_align = zT_413;
    zT_415 = 0;
    zT_416 = (unsigned int)zT_415;
    ei = zT_416;
    goto z_bb_76;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_459 = ty.kind;
    if ((unsigned char)(zT_459 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_76:
    if ((unsigned char)(ei < ecount)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_419 = registry->xt_items;
    zT_420 = zig_wrap_add_u(((zu64)(estr)), ((zu64)(ei)), 32u);
    zT_421 = zig_overflow_flag_add_u(((zu64)(estr)), ((zu64)(ei)), 32u);
    zT_423 = zT_421 == (unsigned int)(0);
    if (!(zT_423)) { pal_trap(); }
    zT_424 = zT_419[zT_420];
    elem_tid = zT_424;
    zT_426 = registry->types_items;
    zT_427 = (unsigned int)elem_tid;
    zT_428 = zT_426[zT_427];
    et = zT_428;
    zT_429 = offset;
    zT_431 = et.alignment;
    zT_433 = zF_D2BAC673_alignUp_1(zT_429, (unsigned int)((unsigned int)zT_431));
    offset = zT_433;
    zT_434 = et.size;
    zT_435 = zig_wrap_add_u(((zu64)(offset)), ((zu64)(zT_434)), 32u);
    zT_436 = zig_overflow_flag_add_u(((zu64)(offset)), ((zu64)(zT_434)), 32u);
    zT_438 = zT_436 == (unsigned int)(0);
    if (!(zT_438)) { pal_trap(); }
    offset = zT_435;
    zT_439 = et.alignment;
    if ((unsigned char)(zT_439 > max_align)) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    zT_449 = offset;
    zT_450 = max_align;
    zT_451 = zF_D2BAC673_alignUp_1(zT_449, zT_450);
    ty.size = zT_451;
    zT_452 = (unsigned short)zig_cast_checked_u((zu64)max_align, 32u, 0u, 16u);
    ty.alignment = zT_452;
    zT_453 = ty.size;
    if ((unsigned char)(zT_453 == (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_79:
    zT_443 = 1;
    zT_444 = (unsigned int)zT_443;
    zT_445 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_444)), 32u);
    zT_446 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_444)), 32u);
    zT_448 = zT_446 == (unsigned int)(0);
    if (!(zT_448)) { pal_trap(); }
    ei = zT_445;
    goto z_bb_76;
    z_bb_80:
    zT_441 = et.alignment;
    zT_442 = (unsigned int)zT_441;
    max_align = zT_442;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_83;
    z_bb_83:
    zT_458 = registry->types_items;
    zT_458[idx] = ty;
    goto z_bb_74;
    z_bb_84:
    ty.size = (unsigned int)(4);
    ty.alignment = (unsigned short)(4);
    zT_465 = registry->types_items;
    zT_465[idx] = ty;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_74;
}

/* layoutDepOk */
unsigned char zF_BEEAF73E_layoutDepOk(zT_338B7C76_TypeRegistry* registry, unsigned int dep, unsigned int depth) {
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    if ((unsigned char)(dep == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(dep == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(dep == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_12 = registry;
    zT_13 = dep;
    zT_14 = depth;
    zT_15 = zF_3E55D0D5_layoutEnsure(zT_12, zT_13, zT_14);
    return zT_15;
}

/* layoutFieldDepsOk */
unsigned char zF_B32C0425_layoutFieldDepsOk(zT_338B7C76_TypeRegistry* registry, unsigned int fstart, unsigned short fcount, unsigned int depth) {
    int zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_2DF01B61_FieldEntry* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_2DF01B61_FieldEntry zT_18;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = registry;
    zT_12 = registry->fe_items;
    zT_13 = (unsigned int)fstart;
    zT_14 = zig_wrap_add_u(((zu64)(zT_13)), ((zu64)(fi)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(zT_13)), ((zu64)(fi)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_18 = zT_12[zT_14];
    zT_10 = zT_18.type_id;
    zT_11 = depth;
    zT_20 = zF_BEEAF73E_layoutDepOk(zT_9, zT_10, zT_11);
    if ((unsigned char)(!zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_23 = 1;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    fi = zT_25;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
}

/* layoutEnsure */
unsigned char zF_3E55D0D5_layoutEnsure(zT_338B7C76_TypeRegistry* registry, unsigned int tid, unsigned int depth) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    unsigned char zT_14;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_406493CE_StructPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    unsigned short zT_36;
    unsigned int zT_37;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    zT_457ECFEE_EnumPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_457ECFEE_EnumPayload zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned char zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    zT_AF9231A2_UnionPayload* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_AF9231A2_UnionPayload zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned short zT_76;
    unsigned int zT_77;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned char zT_85;
    zT_33EF6BFB_TypeKind zT_86;
    zT_AF9231A2_UnionPayload* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_AF9231A2_UnionPayload zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    unsigned int zT_96;
    unsigned short zT_97;
    unsigned int zT_98;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned char zT_105;
    unsigned char zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    zT_54FF90FA_TaggedUnionPayload* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_54FF90FA_TaggedUnionPayload zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    unsigned char zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    unsigned int zT_127;
    unsigned short zT_128;
    unsigned int zT_129;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_E834303C_ArrayPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_E834303C_ArrayPayload zT_146;
    zT_338B7C76_TypeRegistry* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned char zT_155;
    unsigned char zT_156;
    zT_33EF6BFB_TypeKind zT_157;
    zT_666DC2E1_TuplePayload* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_666DC2E1_TuplePayload zT_165;
    int zT_167;
    unsigned int zT_168;
    unsigned short zT_169;
    zT_338B7C76_TypeRegistry* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned char zT_181;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned char zT_187;
    unsigned char zT_188;
    unsigned char zT_190;
    int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned char zT_196;
    zT_33EF6BFB_TypeKind zT_197;
    zT_0B10E8E9_OptionalPayload* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_0B10E8E9_OptionalPayload zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    unsigned char zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    zT_42C2D6BF_EUPayload* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_42C2D6BF_EUPayload zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned char zT_233;
    unsigned char zT_234;
    unsigned char zT_235;
    zT_338B7C76_TypeRegistry* zT_240;
    unsigned int zT_241;
    zT_D155D06D_Type* zT_243;
    zT_D155D06D_Type* zT_245;
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    zig_poison_fill((void*)&zT_156, (unsigned int)sizeof zT_156);
    zig_poison_fill((void*)&zT_188, (unsigned int)sizeof zT_188);
    zig_poison_fill((void*)&zT_215, (unsigned int)sizeof zT_215);
    zig_poison_fill((void*)&zT_234, (unsigned int)sizeof zT_234);
    zT_D155D06D_Type ty;
    unsigned char deps_ok;
    unsigned char handled;
    zT_406493CE_StructPayload sp;
    zT_457ECFEE_EnumPayload ep;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_E834303C_ArrayPayload ap;
    zT_666DC2E1_TuplePayload tup;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload op;
    zT_42C2D6BF_EUPayload eup;
    if ((unsigned char)(tid == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = registry->types_items;
    zT_12 = (unsigned int)tid;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.state;
    if ((unsigned char)(zT_14 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_22 = 1;
    deps_ok = zT_22;
    zT_24 = 1;
    handled = zT_24;
    zT_25 = ty.kind;
    if ((unsigned char)(zT_25 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_30 = registry->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = registry;
    zT_35 = sp.fields_start;
    zT_36 = sp.fields_count;
    zT_40 = 1;
    zT_41 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_37 = zT_41;
    zT_45 = zF_B32C0425_layoutFieldDepsOk(zT_34, zT_35, zT_36, zT_37);
    deps_ok = zT_45;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(!handled)) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_46 = ty.kind;
    if ((unsigned char)(zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_51 = registry->en_items;
    zT_52 = ty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    ep = zT_54;
    zT_55 = registry;
    zT_56 = ep.backing_type;
    zT_59 = 1;
    zT_60 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    zT_57 = zT_60;
    zT_64 = zF_BEEAF73E_layoutDepOk(zT_55, zT_56, zT_57);
    deps_ok = zT_64;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_65 = ty.kind;
    if ((unsigned char)(zT_65 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_70 = registry->un_items;
    zT_71 = ty.payload_idx;
    zT_72 = (unsigned int)zT_71;
    zT_73 = zT_70[zT_72];
    up = zT_73;
    zT_74 = registry;
    zT_75 = up.fields_start;
    zT_76 = up.fields_count;
    zT_80 = 1;
    zT_81 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    zT_77 = zT_81;
    zT_85 = zF_B32C0425_layoutFieldDepsOk(zT_74, zT_75, zT_76, zT_77);
    deps_ok = zT_85;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_86 = ty.kind;
    if ((unsigned char)(zT_86 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_91 = registry->un_items;
    zT_92 = ty.payload_idx;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    pup = zT_94;
    zT_95 = registry;
    zT_96 = pup.fields_start;
    zT_97 = pup.fields_count;
    zT_101 = 1;
    zT_102 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_101)), 32u);
    zT_103 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_101)), 32u);
    zT_105 = zT_103 == (unsigned int)(0);
    if (!(zT_105)) { pal_trap(); }
    zT_98 = zT_102;
    zT_106 = zF_B32C0425_layoutFieldDepsOk(zT_95, zT_96, zT_97, zT_98);
    deps_ok = zT_106;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_107 = ty.kind;
    if ((unsigned char)(zT_107 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_112 = registry->tu_items;
    zT_113 = ty.payload_idx;
    zT_114 = (unsigned int)zT_113;
    zT_115 = zT_112[zT_114];
    tp = zT_115;
    zT_116 = registry;
    zT_117 = tp.tag_type;
    zT_120 = 1;
    zT_121 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_120)), 32u);
    zT_122 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_120)), 32u);
    zT_124 = zT_122 == (unsigned int)(0);
    if (!(zT_124)) { pal_trap(); }
    zT_118 = zT_121;
    zT_125 = zF_BEEAF73E_layoutDepOk(zT_116, zT_117, zT_118);
    deps_ok = zT_125;
    if (deps_ok) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_126 = registry;
    zT_127 = tp.fields_start;
    zT_128 = tp.fields_count;
    zT_132 = 1;
    zT_133 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_132)), 32u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_132)), 32u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    zT_129 = zT_133;
    zT_137 = zF_B32C0425_layoutFieldDepsOk(zT_126, zT_127, zT_128, zT_129);
    deps_ok = zT_137;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_143 = registry->array_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    ap = zT_146;
    zT_147 = registry;
    zT_148 = ap.elem;
    zT_151 = 1;
    zT_152 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_151)), 32u);
    zT_153 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_151)), 32u);
    zT_155 = zT_153 == (unsigned int)(0);
    if (!(zT_155)) { pal_trap(); }
    zT_149 = zT_152;
    zT_156 = zF_BEEAF73E_layoutDepOk(zT_147, zT_148, zT_149);
    deps_ok = zT_156;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    zT_157 = ty.kind;
    if ((unsigned char)(zT_157 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_162 = registry->tup_items;
    zT_163 = ty.payload_idx;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zT_162[zT_164];
    tup = zT_165;
    zT_167 = 0;
    zT_168 = (unsigned int)zT_167;
    ei = zT_168;
    goto z_bb_32;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_197 = ty.kind;
    if ((unsigned char)(zT_197 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_40;
    z_bb_32:
    zT_169 = tup.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_169))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_172 = registry;
    zT_175 = registry->xt_items;
    zT_176 = tup.elems_start;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zig_wrap_add_u(((zu64)(zT_177)), ((zu64)(ei)), 32u);
    zT_179 = zig_overflow_flag_add_u(((zu64)(zT_177)), ((zu64)(ei)), 32u);
    zT_181 = zT_179 == (unsigned int)(0);
    if (!(zT_181)) { pal_trap(); }
    zT_173 = zT_175[zT_178];
    zT_183 = 1;
    zT_184 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_183)), 32u);
    zT_185 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_183)), 32u);
    zT_187 = zT_185 == (unsigned int)(0);
    if (!(zT_187)) { pal_trap(); }
    zT_174 = zT_184;
    zT_188 = zF_BEEAF73E_layoutDepOk(zT_172, zT_173, zT_174);
    if ((unsigned char)(!zT_188)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_191 = 1;
    zT_192 = (unsigned int)zT_191;
    zT_193 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_192)), 32u);
    zT_194 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_192)), 32u);
    zT_196 = zT_194 == (unsigned int)(0);
    if (!(zT_196)) { pal_trap(); }
    ei = zT_193;
    goto z_bb_32;
    z_bb_36:
    zT_190 = 0;
    deps_ok = zT_190;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    zT_202 = registry->opt_items;
    zT_203 = ty.payload_idx;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zT_202[zT_204];
    op = zT_205;
    zT_206 = registry;
    zT_207 = op.payload;
    zT_210 = 1;
    zT_211 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    zT_208 = zT_211;
    zT_215 = zF_BEEAF73E_layoutDepOk(zT_206, zT_207, zT_208);
    deps_ok = zT_215;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_30;
    z_bb_40:
    zT_216 = ty.kind;
    if ((unsigned char)(zT_216 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_221 = registry->eu_items;
    zT_222 = ty.payload_idx;
    zT_223 = (unsigned int)zT_222;
    zT_224 = zT_221[zT_223];
    eup = zT_224;
    zT_225 = registry;
    zT_226 = eup.payload;
    zT_229 = 1;
    zT_230 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_229)), 32u);
    zT_231 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_229)), 32u);
    zT_233 = zT_231 == (unsigned int)(0);
    if (!(zT_233)) { pal_trap(); }
    zT_227 = zT_230;
    zT_234 = zF_BEEAF73E_layoutDepOk(zT_225, zT_226, zT_227);
    deps_ok = zT_234;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_235 = 0;
    handled = zT_235;
    goto z_bb_42;
    z_bb_44:
    return (unsigned char)(0);
    z_bb_45:
    if ((unsigned char)(!deps_ok)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return (unsigned char)(0);
    z_bb_47:
    zT_240 = registry;
    zT_241 = tid;
    zF_0E9E97D8_layoutCompute(zT_240, zT_241);
    zT_243 = registry->types_items;
    zT_245 = zT_243 + (unsigned int)((unsigned int)tid);
    zT_245->state = (unsigned char)(2);
    return (unsigned char)(1);
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned char zT_7;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_2 = self->registry;
    zT_3 = tid;
    zT_7 = zF_3E55D0D5_layoutEnsure(zT_2, zT_3, (unsigned int)(0));
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->registry;
    zT_10 = tid;
    zF_0E9E97D8_layoutCompute(zT_9, zT_10);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_C890C8CB_TypeResolver* zT_25;
    unsigned int zT_26;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_FDFD82FD_EU_362 zT_38;
    unsigned char zT_39;
    unsigned char* zT_40;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_47;
    unsigned int* zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_52CDA6EF_DepEdge* zT_61;
    zT_52CDA6EF_DepEdge zT_62;
    unsigned int zT_63;
    unsigned int* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    unsigned int* zT_75;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    type_count = zT_24;
    zT_25 = self;
    zT_26 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_25, zT_26);
    zT_28 = self->alloc;
    zT_32 = 4;
    zT_33 = zig_wrap_mul_u(((zu64)(type_count)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_mul_u(((zu64)(type_count)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_29 = zT_33;
    zT_38 = zF_1395EB68_sandAlloc(zT_28, zT_29, (unsigned int)(4));
    zT_39 = zT_38.is_error;
    if (zT_39) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_40 = zT_38.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_40;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    zi = zT_45;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_47 = 0;
    zT_48 = self->in_degree_items;
    zT_48[zi] = zT_47;
    zT_49 = 1;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    zi = zT_51;
    goto z_bb_11;
    z_bb_10:
    zT_56 = 0;
    zT_57 = (unsigned int)zT_56;
    ei = zT_57;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_58 = self->depend_len;
    if ((unsigned char)(ei < zT_58)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_61 = self->depend_items;
    zT_62 = zT_61[ei];
    zT_63 = zT_62.to;
    target = zT_63;
    if ((unsigned char)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_66 = self->in_degree_items;
    zT_67 = (unsigned int)target;
    zT_68 = zT_66[zT_67];
    zT_69 = 1;
    zT_70 = (unsigned int)zT_69;
    zT_71 = zig_wrap_add_u(((zu64)(zT_68)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(zT_68)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    zT_75 = self->in_degree_items;
    zT_76 = (unsigned int)target;
    zT_75[zT_76] = zT_71;
    goto z_bb_17;
    z_bb_17:
    zT_77 = 1;
    zT_78 = (unsigned int)zT_77;
    zT_79 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    ei = zT_79;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned int zT_23;
    int zT_24;
    zT_C890C8CB_TypeResolver* zT_27;
    zT_BAEE192E_Opt_10 zT_28;
    unsigned char zT_29;
    unsigned int* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    zT_C890C8CB_TypeResolver* zT_39;
    unsigned int zT_40;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    zT_D155D06D_Type* zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_51;
    zT_52CDA6EF_DepEdge zT_52;
    unsigned int zT_53;
    zT_52CDA6EF_DepEdge* zT_56;
    zT_52CDA6EF_DepEdge zT_57;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int* zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    unsigned int* zT_74;
    unsigned int* zT_75;
    unsigned int zT_76;
    int zT_77;
    zT_C890C8CB_TypeResolver* zT_79;
    unsigned int zT_80;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_D155D06D_Type* zT_93;
    zT_D155D06D_Type zT_94;
    unsigned char zT_95;
    unsigned char zT_98;
    unsigned int* zT_99;
    unsigned int zT_100;
    int zT_101;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_F85C5DED_DiagnosticCollector* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    zT_338B7C76_TypeRegistry* zT_128;
    zT_D155D06D_Type* zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned char zT_135;
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((unsigned char)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((unsigned char)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_23 = self->worklist_len;
    zT_24 = 0;
    if ((unsigned char)(zT_23 > (unsigned int)zT_24)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_27 = self;
    zT_28 = zF_D7A5282F_worklistPop(zT_27);
    tid_val = zT_28;
    zT_29 = tid_val.has_value;
    if (zT_29) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    ci = zT_89;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    if (!(tid_val.has_value)) { pal_trap(); }
    tid = tid_val.value;
    zT_31 = self->sorted_items;
    zT_32 = self->sorted_len;
    zT_31[zT_32] = tid;
    zT_33 = self->sorted_len;
    zT_34 = 1;
    zT_35 = zig_wrap_add_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_add_u(((zu64)(zT_33)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    self->sorted_len = zT_35;
    zT_39 = self;
    zT_40 = tid;
    zF_3957E0DF_typeResolverResolve(zT_39, zT_40);
    zT_42 = self->registry;
    zT_43 = zT_42->types_items;
    zT_45 = zT_43 + (unsigned int)((unsigned int)tid);
    zT_45->state = (unsigned char)(2);
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_49 = self->depend_len;
    if ((unsigned char)(ei < zT_49)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_51 = self->depend_items;
    zT_52 = zT_51[ei];
    zT_53 = zT_52.from;
    if ((unsigned char)(zT_53 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_56 = self->depend_items;
    zT_57 = zT_56[ei];
    zT_58 = zT_57.to;
    dep = zT_58;
    zT_60 = (unsigned int)dep;
    dep_idx = zT_60;
    if ((unsigned char)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_81 = 1;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    ei = zT_83;
    goto z_bb_18;
    z_bb_21:
    zT_62 = self->in_degree_items;
    zT_63 = zT_62[dep_idx];
    zT_64 = 0;
    if ((unsigned char)(zT_63 > (unsigned int)zT_64)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 1;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zig_wrap_sub_u(((zu64)(zT_67)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_sub_u(((zu64)(zT_67)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    zT_74 = self->in_degree_items;
    zT_74[dep_idx] = zT_70;
    zT_75 = self->in_degree_items;
    zT_76 = zT_75[dep_idx];
    zT_77 = 0;
    if ((unsigned char)(zT_76 == (unsigned int)zT_77)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_79 = self;
    zT_80 = dep;
    zF_352BC6BC_worklistPush(zT_79, zT_80);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((unsigned char)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_92 = self->registry;
    zT_93 = zT_92->types_items;
    zT_94 = zT_93[ci];
    ty = zT_94;
    zT_95 = ty.state;
    if ((unsigned char)(zT_95 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_130 = 1;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_131)), 32u);
    zT_133 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_131)), 32u);
    zT_135 = zT_133 == (unsigned int)(0);
    if (!(zT_135)) { pal_trap(); }
    ci = zT_132;
    goto z_bb_27;
    z_bb_31:
    zT_99 = self->in_degree_items;
    zT_100 = zT_99[ci];
    zT_101 = 0;
    zT_98 = zT_100 > (unsigned int)zT_101;
    goto z_bb_33;
    z_bb_32:
    zT_98 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_98) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_104 = "circular type dependency detected (type refers to itself)";
    zT_106 = 57;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    msg = zT_105;
    zT_107 = self->diag;
    zT_113 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_107, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_113);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    ty.alignment = (unsigned short)(1);
    ty.state = (unsigned char)(2);
    zT_128 = self->registry;
    zT_129 = zT_128->types_items;
    zT_129[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* kindIsAggregateCore */
unsigned char zF_95CB1909_kindIsAggregateCore(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    return zT_20;
}

/* fieldEmbedsByValue */
unsigned char zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_7;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* requiresFullDef */
unsigned char zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_7;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    zT_3E40CD83_Sand* zT_7;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_FDFD82FD_EU_362 zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int* zT_22;
    int zT_24;
    unsigned int zT_25;
    zT_338B7C76_TypeRegistry* zT_28;
    unsigned int* zT_30;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_C890C8CB_TypeResolver* zT_37;
    unsigned int zT_38;
    unsigned int zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    unsigned int tl;
    unsigned char* raw;
    unsigned int* buf;
    unsigned int ti;
    unsigned int n;
    unsigned int k;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    tl = zT_3;
    if ((unsigned char)(tl == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = self->alloc;
    zT_11 = 4;
    zT_12 = zig_wrap_mul_u(((zu64)(tl)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(tl)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_8 = zT_12;
    zT_17 = zF_1395EB68_sandAlloc(zT_7, zT_8, (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_19 = zT_17.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_19;
    zT_22 = (unsigned int*)raw;
    buf = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    ti = zT_25;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(ti < tl)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = self->registry;
    zT_30 = buf;
    zT_33 = zF_F41AC8EB_typeRefs(zT_28, (unsigned int)((unsigned int)ti), zT_30);
    n = zT_33;
    zT_35 = 0;
    k = zT_35;
    goto z_bb_10;
    z_bb_8:
    return;
    z_bb_9:
    zT_49 = 1;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    ti = zT_51;
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(k < n)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_37 = self;
    zT_40 = (unsigned int)k;
    zT_38 = buf[zT_40];
    zF_F1D68957_typeResolverAddEdge(zT_37, zT_38, (unsigned int)((unsigned int)ti));
    goto z_bb_13;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    k = zT_45;
    goto z_bb_10;
}

/* classifyTypeEmissionGroups */
void zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_786E6CF2_EmissionClassificat* classif, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    int zT_15;
    zT_FDFD82FD_EU_362 zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char* zT_22;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    int zT_38;
    zT_FDFD82FD_EU_362 zT_40;
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int* zT_45;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    int zT_55;
    zT_FDFD82FD_EU_362 zT_57;
    unsigned char zT_58;
    unsigned char* zT_59;
    unsigned int* zT_62;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    int zT_72;
    zT_FDFD82FD_EU_362 zT_74;
    unsigned char zT_75;
    unsigned char* zT_76;
    unsigned int* zT_79;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    unsigned int zT_92;
    zT_3E40CD83_Sand* zT_94;
    unsigned int zT_95;
    int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    int zT_102;
    zT_FDFD82FD_EU_362 zT_104;
    unsigned char zT_105;
    unsigned char* zT_106;
    unsigned int* zT_109;
    unsigned int zT_111;
    unsigned int zT_113;
    int zT_115;
    unsigned int zT_116;
    zT_338B7C76_TypeRegistry* zT_119;
    zT_D155D06D_Type* zT_120;
    zT_D155D06D_Type zT_121;
    unsigned char zT_123;
    zT_33EF6BFB_TypeKind zT_124;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_406493CE_StructPayload* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_406493CE_StructPayload zT_133;
    int zT_135;
    unsigned int zT_136;
    unsigned short zT_137;
    unsigned char zT_140;
    int zT_141;
    zT_338B7C76_TypeRegistry* zT_144;
    zT_2DF01B61_FieldEntry* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned char zT_151;
    zT_2DF01B61_FieldEntry zT_152;
    unsigned int zT_153;
    zT_338B7C76_TypeRegistry* zT_155;
    zT_D155D06D_Type* zT_156;
    unsigned int zT_157;
    zT_D155D06D_Type zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    unsigned char zT_161;
    unsigned char zT_162;
    zT_33EF6BFB_TypeKind zT_163;
    zT_3E40CD83_Sand* zT_167;
    unsigned int** zT_168;
    unsigned int** zT_169;
    unsigned int* zT_170;
    unsigned int zT_171;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    zT_33EF6BFB_TypeKind zT_186;
    zT_3E40CD83_Sand* zT_190;
    unsigned int** zT_191;
    unsigned int** zT_192;
    unsigned int* zT_193;
    unsigned int zT_194;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned char zT_208;
    int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_338B7C76_TypeRegistry* zT_220;
    zT_54FF90FA_TaggedUnionPayload* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_54FF90FA_TaggedUnionPayload zT_224;
    int zT_226;
    unsigned int zT_227;
    unsigned short zT_228;
    unsigned char zT_231;
    int zT_232;
    zT_338B7C76_TypeRegistry* zT_235;
    zT_2DF01B61_FieldEntry* zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned char zT_242;
    zT_2DF01B61_FieldEntry zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_246;
    zT_D155D06D_Type* zT_247;
    unsigned int zT_248;
    zT_D155D06D_Type zT_249;
    zT_33EF6BFB_TypeKind zT_250;
    unsigned char zT_252;
    unsigned char zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_3E40CD83_Sand* zT_258;
    unsigned int** zT_259;
    unsigned int** zT_260;
    unsigned int* zT_261;
    unsigned int zT_262;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned char zT_276;
    zT_33EF6BFB_TypeKind zT_277;
    zT_3E40CD83_Sand* zT_281;
    unsigned int** zT_282;
    unsigned int** zT_283;
    unsigned int* zT_284;
    unsigned int zT_285;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    unsigned char zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned char zT_305;
    zT_33EF6BFB_TypeKind zT_306;
    zT_338B7C76_TypeRegistry* zT_311;
    zT_AF9231A2_UnionPayload* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_AF9231A2_UnionPayload zT_315;
    int zT_317;
    unsigned int zT_318;
    unsigned short zT_319;
    unsigned char zT_322;
    int zT_323;
    zT_338B7C76_TypeRegistry* zT_326;
    zT_2DF01B61_FieldEntry* zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned char zT_333;
    zT_2DF01B61_FieldEntry zT_334;
    unsigned int zT_335;
    zT_338B7C76_TypeRegistry* zT_337;
    zT_D155D06D_Type* zT_338;
    unsigned int zT_339;
    zT_D155D06D_Type zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    unsigned char zT_343;
    unsigned char zT_344;
    zT_33EF6BFB_TypeKind zT_345;
    zT_3E40CD83_Sand* zT_349;
    unsigned int** zT_350;
    unsigned int** zT_351;
    unsigned int* zT_352;
    unsigned int zT_353;
    unsigned int zT_357;
    unsigned int zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    unsigned char zT_367;
    zT_33EF6BFB_TypeKind zT_368;
    zT_3E40CD83_Sand* zT_372;
    unsigned int** zT_373;
    unsigned int** zT_374;
    unsigned int* zT_375;
    unsigned int zT_376;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned char zT_390;
    int zT_391;
    unsigned int zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned char zT_396;
    zT_33EF6BFB_TypeKind zT_397;
    zT_338B7C76_TypeRegistry* zT_402;
    zT_AF9231A2_UnionPayload* zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    zT_AF9231A2_UnionPayload zT_406;
    int zT_408;
    unsigned int zT_409;
    unsigned short zT_410;
    unsigned char zT_413;
    int zT_414;
    zT_338B7C76_TypeRegistry* zT_417;
    zT_2DF01B61_FieldEntry* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    unsigned char zT_424;
    zT_2DF01B61_FieldEntry zT_425;
    unsigned int zT_426;
    zT_338B7C76_TypeRegistry* zT_428;
    zT_D155D06D_Type* zT_429;
    unsigned int zT_430;
    zT_D155D06D_Type zT_431;
    zT_33EF6BFB_TypeKind zT_432;
    unsigned char zT_434;
    unsigned char zT_435;
    zT_33EF6BFB_TypeKind zT_436;
    zT_3E40CD83_Sand* zT_440;
    unsigned int** zT_441;
    unsigned int** zT_442;
    unsigned int* zT_443;
    unsigned int zT_444;
    unsigned int zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    unsigned char zT_458;
    zT_33EF6BFB_TypeKind zT_459;
    zT_3E40CD83_Sand* zT_463;
    unsigned int** zT_464;
    unsigned int** zT_465;
    unsigned int* zT_466;
    unsigned int zT_467;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned char zT_481;
    int zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned char zT_487;
    zT_33EF6BFB_TypeKind zT_488;
    zT_338B7C76_TypeRegistry* zT_493;
    zT_E834303C_ArrayPayload* zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    zT_E834303C_ArrayPayload zT_497;
    unsigned int zT_498;
    zT_338B7C76_TypeRegistry* zT_500;
    zT_D155D06D_Type* zT_501;
    unsigned int zT_502;
    zT_D155D06D_Type zT_503;
    zT_33EF6BFB_TypeKind zT_504;
    unsigned char zT_506;
    unsigned char zT_507;
    zT_33EF6BFB_TypeKind zT_508;
    zT_3E40CD83_Sand* zT_512;
    unsigned int** zT_513;
    unsigned int** zT_514;
    unsigned int* zT_515;
    unsigned int zT_516;
    unsigned int zT_520;
    unsigned int zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_525;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned char zT_530;
    zT_33EF6BFB_TypeKind zT_531;
    zT_3E40CD83_Sand* zT_535;
    unsigned int** zT_536;
    unsigned int** zT_537;
    unsigned int* zT_538;
    unsigned int zT_539;
    unsigned int zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned char zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    zT_338B7C76_TypeRegistry* zT_559;
    zT_42C2D6BF_EUPayload* zT_560;
    unsigned int zT_561;
    unsigned int zT_562;
    zT_42C2D6BF_EUPayload zT_563;
    unsigned int zT_564;
    zT_338B7C76_TypeRegistry* zT_566;
    zT_D155D06D_Type* zT_567;
    unsigned int zT_568;
    zT_D155D06D_Type zT_569;
    zT_33EF6BFB_TypeKind zT_570;
    unsigned char zT_572;
    unsigned char zT_573;
    zT_33EF6BFB_TypeKind zT_574;
    zT_3E40CD83_Sand* zT_578;
    unsigned int** zT_579;
    unsigned int** zT_580;
    unsigned int* zT_581;
    unsigned int zT_582;
    unsigned int zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned char zT_596;
    zT_33EF6BFB_TypeKind zT_597;
    zT_3E40CD83_Sand* zT_601;
    unsigned int** zT_602;
    unsigned int** zT_603;
    unsigned int* zT_604;
    unsigned int zT_605;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    unsigned char zT_619;
    zT_33EF6BFB_TypeKind zT_620;
    zT_338B7C76_TypeRegistry* zT_625;
    zT_0B10E8E9_OptionalPayload* zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    zT_0B10E8E9_OptionalPayload zT_629;
    unsigned int zT_630;
    zT_338B7C76_TypeRegistry* zT_632;
    zT_D155D06D_Type* zT_633;
    unsigned int zT_634;
    zT_D155D06D_Type zT_635;
    zT_33EF6BFB_TypeKind zT_636;
    unsigned char zT_638;
    unsigned char zT_639;
    zT_33EF6BFB_TypeKind zT_640;
    zT_3E40CD83_Sand* zT_644;
    unsigned int** zT_645;
    unsigned int** zT_646;
    unsigned int* zT_647;
    unsigned int zT_648;
    unsigned int zT_652;
    unsigned int zT_653;
    unsigned int zT_654;
    unsigned int zT_655;
    unsigned int zT_656;
    unsigned int zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    unsigned int zT_660;
    unsigned char zT_662;
    zT_33EF6BFB_TypeKind zT_663;
    zT_3E40CD83_Sand* zT_667;
    unsigned int** zT_668;
    unsigned int** zT_669;
    unsigned int* zT_670;
    unsigned int zT_671;
    unsigned int zT_675;
    unsigned int zT_676;
    unsigned int zT_677;
    unsigned int zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    unsigned int zT_681;
    unsigned int zT_682;
    unsigned int zT_683;
    unsigned char zT_685;
    unsigned int zT_688;
    unsigned int zT_689;
    unsigned int zT_690;
    unsigned int zT_691;
    unsigned int zT_692;
    unsigned char zT_694;
    int zT_695;
    unsigned int zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    unsigned char zT_700;
    unsigned int zT_703;
    unsigned int zT_704;
    unsigned int zT_705;
    unsigned int zT_706;
    unsigned int zT_707;
    unsigned char zT_709;
    unsigned int zT_711;
    unsigned int zT_712;
    unsigned int zT_716;
    unsigned int zT_717;
    unsigned int zT_718;
    unsigned char zT_719;
    unsigned char zT_722;
    unsigned int zT_723;
    unsigned int zT_724;
    unsigned int zT_725;
    unsigned int zT_726;
    unsigned int zT_727;
    unsigned char zT_729;
    unsigned int zT_730;
    unsigned int zT_731;
    zT_3E40CD83_Sand* zT_733;
    unsigned int zT_734;
    zT_21D3708C_U32ToU32Map zT_735;
    zT_3E40CD83_Sand* zT_737;
    unsigned int zT_738;
    zT_21D3708C_U32ToU32Map zT_739;
    zT_3E40CD83_Sand* zT_741;
    unsigned int zT_742;
    zT_21D3708C_U32ToU32Map zT_743;
    unsigned int zT_745;
    int zT_746;
    unsigned int zT_747;
    zT_338B7C76_TypeRegistry* zT_750;
    zT_D155D06D_Type* zT_751;
    zT_D155D06D_Type zT_752;
    unsigned char zT_753;
    zT_21D3708C_U32ToU32Map* zT_756;
    unsigned int zT_762;
    unsigned int zT_763;
    unsigned int zT_764;
    unsigned char zT_766;
    zT_D155D06D_Type zT_767;
    unsigned char zT_768;
    zT_21D3708C_U32ToU32Map* zT_769;
    unsigned char zT_776;
    unsigned int zT_777;
    zT_33EF6BFB_TypeKind zT_780;
    unsigned char zT_782;
    unsigned char zT_783;
    unsigned char zT_785;
    unsigned char zT_786;
    unsigned char zT_789;
    unsigned char zT_791;
    zT_33EF6BFB_TypeKind zT_792;
    unsigned char zT_796;
    zT_33EF6BFB_TypeKind zT_797;
    unsigned char zT_801;
    zT_33EF6BFB_TypeKind zT_802;
    unsigned char zT_806;
    unsigned char zT_808;
    zT_33EF6BFB_TypeKind zT_809;
    unsigned char zT_813;
    unsigned int zT_814;
    unsigned char zT_817;
    unsigned char zT_820;
    unsigned char zT_823;
    unsigned char zT_826;
    zT_21D3708C_U32ToU32Map* zT_829;
    int zT_835;
    unsigned int zT_836;
    unsigned int zT_837;
    unsigned int zT_838;
    unsigned char zT_840;
    zT_338B7C76_TypeRegistry* zT_841;
    zT_21D3708C_U32ToU32Map* zT_842;
    zT_21D3708C_U32ToU32Map* zT_843;
    unsigned char* zT_848;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_849;
    unsigned int zT_850;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_851;
    unsigned int zT_852;
    unsigned char* zT_854;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_855;
    unsigned int zT_856;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_857;
    int zT_858;
    unsigned int zT_859;
    unsigned char zT_861;
    unsigned char* zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_866;
    unsigned int zT_867;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_868;
    unsigned char* zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    unsigned int zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_873;
    unsigned char* zT_877;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_878;
    unsigned int zT_879;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_880;
    zT_338B7C76_TypeRegistry* zT_882;
    zT_D155D06D_Type* zT_883;
    zT_D155D06D_Type zT_884;
    zT_33EF6BFB_TypeKind zT_885;
    unsigned char* zT_888;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_889;
    unsigned int zT_890;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_891;
    int zT_892;
    unsigned int zT_893;
    unsigned int zT_894;
    unsigned int zT_895;
    unsigned char zT_897;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_252, (unsigned int)sizeof zT_252);
    zig_poison_fill((void*)&zT_343, (unsigned int)sizeof zT_343);
    zig_poison_fill((void*)&zT_434, (unsigned int)sizeof zT_434);
    zig_poison_fill((void*)&zT_506, (unsigned int)sizeof zT_506);
    zig_poison_fill((void*)&zT_572, (unsigned int)sizeof zT_572);
    zig_poison_fill((void*)&zT_638, (unsigned int)sizeof zT_638);
    zig_poison_fill((void*)&zT_735, (unsigned int)sizeof zT_735);
    zig_poison_fill((void*)&zT_739, (unsigned int)sizeof zT_739);
    zig_poison_fill((void*)&zT_743, (unsigned int)sizeof zT_743);
    zig_poison_fill((void*)&zT_768, (unsigned int)sizeof zT_768);
    zig_poison_fill((void*)&zT_782, (unsigned int)sizeof zT_782);
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    zT_21D3708C_U32ToU32Map po_map;
    zT_21D3708C_U32ToU32Map nd_map;
    zT_21D3708C_U32ToU32Map sh_map;
    unsigned int plen;
    unsigned int parent_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    unsigned char is_synthetic;
    unsigned char is_clsv;
    unsigned char is_carrier64;
    unsigned char is_fn_named;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    tl = zT_5;
    zT_7 = perm_alloc;
    zT_10 = 1;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(tl)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(tl)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_8 = zT_11;
    zT_15 = 1;
    zT_17 = zF_1395EB68_sandAlloc(zT_7, zT_8, (unsigned int)((unsigned int)zT_15));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_19 = zT_17.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_19;
    zT_22 = (unsigned char*)po_raw;
    pointer_only = zT_22;
    zT_24 = 4;
    zT_25 = zig_wrap_mul_u(((zu64)(tl)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(tl)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    wp_edge_cap = zT_25;
    zT_30 = perm_alloc;
    zT_33 = 4;
    zT_34 = zig_wrap_mul_u(((zu64)(zT_33)), ((zu64)(wp_edge_cap)), 32u);
    zT_35 = zig_overflow_flag_mul_u(((zu64)(zT_33)), ((zu64)(wp_edge_cap)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_31 = zT_34;
    zT_38 = 4;
    zT_40 = zF_1395EB68_sandAlloc(zT_30, zT_31, (unsigned int)((unsigned int)zT_38));
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_42 = zT_40.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_42;
    zT_45 = (unsigned int*)wp_to_raw;
    wp_to = zT_45;
    zT_47 = perm_alloc;
    zT_50 = 4;
    zT_51 = zig_wrap_mul_u(((zu64)(zT_50)), ((zu64)(wp_edge_cap)), 32u);
    zT_52 = zig_overflow_flag_mul_u(((zu64)(zT_50)), ((zu64)(wp_edge_cap)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    zT_48 = zT_51;
    zT_55 = 4;
    zT_57 = zF_1395EB68_sandAlloc(zT_47, zT_48, (unsigned int)((unsigned int)zT_55));
    zT_58 = zT_57.is_error;
    if (zT_58) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_59 = zT_57.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_59;
    zT_62 = (unsigned int*)wp_next_raw;
    wp_next = zT_62;
    zT_64 = perm_alloc;
    zT_67 = 4;
    zT_68 = zig_wrap_mul_u(((zu64)(zT_67)), ((zu64)(tl)), 32u);
    zT_69 = zig_overflow_flag_mul_u(((zu64)(zT_67)), ((zu64)(tl)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    zT_65 = zT_68;
    zT_72 = 4;
    zT_74 = zF_1395EB68_sandAlloc(zT_64, zT_65, (unsigned int)((unsigned int)zT_72));
    zT_75 = zT_74.is_error;
    if (zT_75) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_76 = zT_74.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_76;
    zT_79 = (unsigned int*)wp_head_raw;
    wp_head = zT_79;
    zT_81 = 0;
    zT_82 = (unsigned int)zT_81;
    whi = zT_82;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_84 = 4294967295u;
    wp_head[whi] = zT_84;
    goto z_bb_16;
    z_bb_15:
    zT_92 = 0;
    wp_count = zT_92;
    zT_94 = perm_alloc;
    zT_97 = 4;
    zT_98 = zig_wrap_mul_u(((zu64)(zT_97)), ((zu64)(tl)), 32u);
    zT_99 = zig_overflow_flag_mul_u(((zu64)(zT_97)), ((zu64)(tl)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    zT_95 = zT_98;
    zT_102 = 4;
    zT_104 = zF_1395EB68_sandAlloc(zT_94, zT_95, (unsigned int)((unsigned int)zT_102));
    zT_105 = zT_104.is_error;
    if (zT_105) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_85 = 1;
    zT_86 = (unsigned int)zT_85;
    zT_87 = zig_wrap_add_u(((zu64)(whi)), ((zu64)(zT_86)), 32u);
    zT_88 = zig_overflow_flag_add_u(((zu64)(whi)), ((zu64)(zT_86)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    whi = zT_87;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_106 = zT_104.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_106;
    zT_109 = (unsigned int*)wl_raw;
    worklist = zT_109;
    zT_111 = 0;
    wl_head = zT_111;
    zT_113 = 0;
    wl_tail = zT_113;
    zT_115 = 0;
    zT_116 = (unsigned int)zT_115;
    ti = zT_116;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_119 = self->registry;
    zT_120 = zT_119->types_items;
    zT_121 = zT_120[ti];
    ty = zT_121;
    zT_123 = 1;
    is_po = zT_123;
    zT_124 = ty.kind;
    if ((unsigned char)(zT_124 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_695 = 1;
    zT_696 = (unsigned int)zT_695;
    zT_697 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_696)), 32u);
    zT_698 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_696)), 32u);
    zT_700 = zT_698 == (unsigned int)(0);
    if (!(zT_700)) { pal_trap(); }
    ti = zT_697;
    goto z_bb_20;
    z_bb_24:
    zT_129 = self->registry;
    zT_130 = zT_129->st_items;
    zT_131 = ty.payload_idx;
    zT_132 = (unsigned int)zT_131;
    zT_133 = zT_130[zT_132];
    sp = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned int)zT_135;
    fi = zT_136;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((unsigned char)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_215 = ty.kind;
    if ((unsigned char)(zT_215 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_137 = sp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_137))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_144 = self->registry;
    zT_145 = zT_144->fe_items;
    zT_146 = sp.fields_start;
    zT_147 = (unsigned int)zT_146;
    zT_148 = zig_wrap_add_u(((zu64)(zT_147)), ((zu64)(fi)), 32u);
    zT_149 = zig_overflow_flag_add_u(((zu64)(zT_147)), ((zu64)(fi)), 32u);
    zT_151 = zT_149 == (unsigned int)(0);
    if (!(zT_151)) { pal_trap(); }
    zT_152 = zT_145[zT_148];
    zT_153 = zT_152.type_id;
    ft_id = zT_153;
    zT_155 = self->registry;
    zT_156 = zT_155->types_items;
    zT_157 = (unsigned int)ft_id;
    zT_158 = zT_156[zT_157];
    ft = zT_158;
    zT_159 = ft.kind;
    zT_161 = zF_A47239A9_fieldEmbedsByValue(zT_159);
    if (zT_161) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_209 = 1;
    zT_210 = (unsigned int)zT_209;
    zT_211 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    fi = zT_211;
    goto z_bb_27;
    z_bb_31:
    zT_141 = 0;
    zT_140 = is_po != zT_141;
    goto z_bb_33;
    z_bb_32:
    zT_140 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_140) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_162 = 0;
    is_po = zT_162;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_163 = ft.kind;
    if ((unsigned char)(zT_163 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_167 = perm_alloc;
    zT_168 = (unsigned int**)&wp_to;
    zT_169 = (unsigned int**)&wp_next;
    zT_170 = (unsigned int*)&wp_edge_cap;
    zT_171 = wp_count;
    zF_25C377BD_growWpEdges(zT_167, zT_168, zT_169, zT_170, zT_171);
    zT_175 = (unsigned int)ti;
    zT_176 = (unsigned int)wp_count;
    wp_to[zT_176] = zT_175;
    zT_177 = (unsigned int)ft_id;
    zT_178 = wp_head[zT_177];
    zT_179 = (unsigned int)wp_count;
    wp_next[zT_179] = zT_178;
    zT_180 = (unsigned int)ft_id;
    wp_head[zT_180] = wp_count;
    zT_181 = 1;
    zT_182 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    wp_count = zT_182;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_186 = ft.kind;
    if ((unsigned char)(zT_186 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_190 = perm_alloc;
    zT_191 = (unsigned int**)&wp_to;
    zT_192 = (unsigned int**)&wp_next;
    zT_193 = (unsigned int*)&wp_edge_cap;
    zT_194 = wp_count;
    zF_25C377BD_growWpEdges(zT_190, zT_191, zT_192, zT_193, zT_194);
    zT_198 = (unsigned int)ti;
    zT_199 = (unsigned int)wp_count;
    wp_to[zT_199] = zT_198;
    zT_200 = (unsigned int)ft_id;
    zT_201 = wp_head[zT_200];
    zT_202 = (unsigned int)wp_count;
    wp_next[zT_202] = zT_201;
    zT_203 = (unsigned int)ft_id;
    wp_head[zT_203] = wp_count;
    zT_204 = 1;
    zT_205 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_204)), 32u);
    zT_206 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_204)), 32u);
    zT_208 = zT_206 == (unsigned int)(0);
    if (!(zT_208)) { pal_trap(); }
    wp_count = zT_205;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_220 = self->registry;
    zT_221 = zT_220->tu_items;
    zT_222 = ty.payload_idx;
    zT_223 = (unsigned int)zT_222;
    zT_224 = zT_221[zT_223];
    tp = zT_224;
    zT_226 = 0;
    zT_227 = (unsigned int)zT_226;
    fi = zT_227;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_306 = ty.kind;
    if ((unsigned char)(zT_306 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_228 = tp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_228))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_235 = self->registry;
    zT_236 = zT_235->fe_items;
    zT_237 = tp.fields_start;
    zT_238 = (unsigned int)zT_237;
    zT_239 = zig_wrap_add_u(((zu64)(zT_238)), ((zu64)(fi)), 32u);
    zT_240 = zig_overflow_flag_add_u(((zu64)(zT_238)), ((zu64)(fi)), 32u);
    zT_242 = zT_240 == (unsigned int)(0);
    if (!(zT_242)) { pal_trap(); }
    zT_243 = zT_236[zT_239];
    zT_244 = zT_243.type_id;
    ft_id = zT_244;
    zT_246 = self->registry;
    zT_247 = zT_246->types_items;
    zT_248 = (unsigned int)ft_id;
    zT_249 = zT_247[zT_248];
    ft = zT_249;
    zT_250 = ft.kind;
    zT_252 = zF_A47239A9_fieldEmbedsByValue(zT_250);
    if (zT_252) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_300 = 1;
    zT_301 = (unsigned int)zT_300;
    zT_302 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_301)), 32u);
    zT_303 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_301)), 32u);
    zT_305 = zT_303 == (unsigned int)(0);
    if (!(zT_305)) { pal_trap(); }
    fi = zT_302;
    goto z_bb_45;
    z_bb_49:
    zT_232 = 0;
    zT_231 = is_po != zT_232;
    goto z_bb_51;
    z_bb_50:
    zT_231 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_231) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_253 = 0;
    is_po = zT_253;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_254 = ft.kind;
    if ((unsigned char)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_258 = perm_alloc;
    zT_259 = (unsigned int**)&wp_to;
    zT_260 = (unsigned int**)&wp_next;
    zT_261 = (unsigned int*)&wp_edge_cap;
    zT_262 = wp_count;
    zF_25C377BD_growWpEdges(zT_258, zT_259, zT_260, zT_261, zT_262);
    zT_266 = (unsigned int)ti;
    zT_267 = (unsigned int)wp_count;
    wp_to[zT_267] = zT_266;
    zT_268 = (unsigned int)ft_id;
    zT_269 = wp_head[zT_268];
    zT_270 = (unsigned int)wp_count;
    wp_next[zT_270] = zT_269;
    zT_271 = (unsigned int)ft_id;
    wp_head[zT_271] = wp_count;
    zT_272 = 1;
    zT_273 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_272)), 32u);
    zT_274 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_272)), 32u);
    zT_276 = zT_274 == (unsigned int)(0);
    if (!(zT_276)) { pal_trap(); }
    wp_count = zT_273;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_277 = ft.kind;
    if ((unsigned char)(zT_277 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_281 = perm_alloc;
    zT_282 = (unsigned int**)&wp_to;
    zT_283 = (unsigned int**)&wp_next;
    zT_284 = (unsigned int*)&wp_edge_cap;
    zT_285 = wp_count;
    zF_25C377BD_growWpEdges(zT_281, zT_282, zT_283, zT_284, zT_285);
    zT_289 = (unsigned int)ti;
    zT_290 = (unsigned int)wp_count;
    wp_to[zT_290] = zT_289;
    zT_291 = (unsigned int)ft_id;
    zT_292 = wp_head[zT_291];
    zT_293 = (unsigned int)wp_count;
    wp_next[zT_293] = zT_292;
    zT_294 = (unsigned int)ft_id;
    wp_head[zT_294] = wp_count;
    zT_295 = 1;
    zT_296 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_295)), 32u);
    zT_297 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_295)), 32u);
    zT_299 = zT_297 == (unsigned int)(0);
    if (!(zT_299)) { pal_trap(); }
    wp_count = zT_296;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_311 = self->registry;
    zT_312 = zT_311->un_items;
    zT_313 = ty.payload_idx;
    zT_314 = (unsigned int)zT_313;
    zT_315 = zT_312[zT_314];
    up = zT_315;
    zT_317 = 0;
    zT_318 = (unsigned int)zT_317;
    fi = zT_318;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_397 = ty.kind;
    if ((unsigned char)(zT_397 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_319 = up.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_319))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_326 = self->registry;
    zT_327 = zT_326->fe_items;
    zT_328 = up.fields_start;
    zT_329 = (unsigned int)zT_328;
    zT_330 = zig_wrap_add_u(((zu64)(zT_329)), ((zu64)(fi)), 32u);
    zT_331 = zig_overflow_flag_add_u(((zu64)(zT_329)), ((zu64)(fi)), 32u);
    zT_333 = zT_331 == (unsigned int)(0);
    if (!(zT_333)) { pal_trap(); }
    zT_334 = zT_327[zT_330];
    zT_335 = zT_334.type_id;
    ft_id = zT_335;
    zT_337 = self->registry;
    zT_338 = zT_337->types_items;
    zT_339 = (unsigned int)ft_id;
    zT_340 = zT_338[zT_339];
    ft = zT_340;
    zT_341 = ft.kind;
    zT_343 = zF_A47239A9_fieldEmbedsByValue(zT_341);
    if (zT_343) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_391 = 1;
    zT_392 = (unsigned int)zT_391;
    zT_393 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_392)), 32u);
    zT_394 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_392)), 32u);
    zT_396 = zT_394 == (unsigned int)(0);
    if (!(zT_396)) { pal_trap(); }
    fi = zT_393;
    goto z_bb_63;
    z_bb_67:
    zT_323 = 0;
    zT_322 = is_po != zT_323;
    goto z_bb_69;
    z_bb_68:
    zT_322 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_322) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_344 = 0;
    is_po = zT_344;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_345 = ft.kind;
    if ((unsigned char)(zT_345 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_349 = perm_alloc;
    zT_350 = (unsigned int**)&wp_to;
    zT_351 = (unsigned int**)&wp_next;
    zT_352 = (unsigned int*)&wp_edge_cap;
    zT_353 = wp_count;
    zF_25C377BD_growWpEdges(zT_349, zT_350, zT_351, zT_352, zT_353);
    zT_357 = (unsigned int)ti;
    zT_358 = (unsigned int)wp_count;
    wp_to[zT_358] = zT_357;
    zT_359 = (unsigned int)ft_id;
    zT_360 = wp_head[zT_359];
    zT_361 = (unsigned int)wp_count;
    wp_next[zT_361] = zT_360;
    zT_362 = (unsigned int)ft_id;
    wp_head[zT_362] = wp_count;
    zT_363 = 1;
    zT_364 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_363)), 32u);
    zT_365 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_363)), 32u);
    zT_367 = zT_365 == (unsigned int)(0);
    if (!(zT_367)) { pal_trap(); }
    wp_count = zT_364;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_368 = ft.kind;
    if ((unsigned char)(zT_368 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_372 = perm_alloc;
    zT_373 = (unsigned int**)&wp_to;
    zT_374 = (unsigned int**)&wp_next;
    zT_375 = (unsigned int*)&wp_edge_cap;
    zT_376 = wp_count;
    zF_25C377BD_growWpEdges(zT_372, zT_373, zT_374, zT_375, zT_376);
    zT_380 = (unsigned int)ti;
    zT_381 = (unsigned int)wp_count;
    wp_to[zT_381] = zT_380;
    zT_382 = (unsigned int)ft_id;
    zT_383 = wp_head[zT_382];
    zT_384 = (unsigned int)wp_count;
    wp_next[zT_384] = zT_383;
    zT_385 = (unsigned int)ft_id;
    wp_head[zT_385] = wp_count;
    zT_386 = 1;
    zT_387 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_386)), 32u);
    zT_388 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_386)), 32u);
    zT_390 = zT_388 == (unsigned int)(0);
    if (!(zT_390)) { pal_trap(); }
    wp_count = zT_387;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_402 = self->registry;
    zT_403 = zT_402->un_items;
    zT_404 = ty.payload_idx;
    zT_405 = (unsigned int)zT_404;
    zT_406 = zT_403[zT_405];
    p_up = zT_406;
    zT_408 = 0;
    zT_409 = (unsigned int)zT_408;
    pfi = zT_409;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_488 = ty.kind;
    if ((unsigned char)(zT_488 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_410 = p_up.fields_count;
    if ((unsigned char)(pfi < (unsigned int)((unsigned int)zT_410))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_417 = self->registry;
    zT_418 = zT_417->fe_items;
    zT_419 = p_up.fields_start;
    zT_420 = (unsigned int)zT_419;
    zT_421 = zig_wrap_add_u(((zu64)(zT_420)), ((zu64)(pfi)), 32u);
    zT_422 = zig_overflow_flag_add_u(((zu64)(zT_420)), ((zu64)(pfi)), 32u);
    zT_424 = zT_422 == (unsigned int)(0);
    if (!(zT_424)) { pal_trap(); }
    zT_425 = zT_418[zT_421];
    zT_426 = zT_425.type_id;
    ft_id = zT_426;
    zT_428 = self->registry;
    zT_429 = zT_428->types_items;
    zT_430 = (unsigned int)ft_id;
    zT_431 = zT_429[zT_430];
    ft = zT_431;
    zT_432 = ft.kind;
    zT_434 = zF_A47239A9_fieldEmbedsByValue(zT_432);
    if (zT_434) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_482 = 1;
    zT_483 = (unsigned int)zT_482;
    zT_484 = zig_wrap_add_u(((zu64)(pfi)), ((zu64)(zT_483)), 32u);
    zT_485 = zig_overflow_flag_add_u(((zu64)(pfi)), ((zu64)(zT_483)), 32u);
    zT_487 = zT_485 == (unsigned int)(0);
    if (!(zT_487)) { pal_trap(); }
    pfi = zT_484;
    goto z_bb_81;
    z_bb_85:
    zT_414 = 0;
    zT_413 = is_po != zT_414;
    goto z_bb_87;
    z_bb_86:
    zT_413 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_413) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_435 = 0;
    is_po = zT_435;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_436 = ft.kind;
    if ((unsigned char)(zT_436 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_440 = perm_alloc;
    zT_441 = (unsigned int**)&wp_to;
    zT_442 = (unsigned int**)&wp_next;
    zT_443 = (unsigned int*)&wp_edge_cap;
    zT_444 = wp_count;
    zF_25C377BD_growWpEdges(zT_440, zT_441, zT_442, zT_443, zT_444);
    zT_448 = (unsigned int)ti;
    zT_449 = (unsigned int)wp_count;
    wp_to[zT_449] = zT_448;
    zT_450 = (unsigned int)ft_id;
    zT_451 = wp_head[zT_450];
    zT_452 = (unsigned int)wp_count;
    wp_next[zT_452] = zT_451;
    zT_453 = (unsigned int)ft_id;
    wp_head[zT_453] = wp_count;
    zT_454 = 1;
    zT_455 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_454)), 32u);
    zT_456 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_454)), 32u);
    zT_458 = zT_456 == (unsigned int)(0);
    if (!(zT_458)) { pal_trap(); }
    wp_count = zT_455;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_459 = ft.kind;
    if ((unsigned char)(zT_459 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_463 = perm_alloc;
    zT_464 = (unsigned int**)&wp_to;
    zT_465 = (unsigned int**)&wp_next;
    zT_466 = (unsigned int*)&wp_edge_cap;
    zT_467 = wp_count;
    zF_25C377BD_growWpEdges(zT_463, zT_464, zT_465, zT_466, zT_467);
    zT_471 = (unsigned int)ti;
    zT_472 = (unsigned int)wp_count;
    wp_to[zT_472] = zT_471;
    zT_473 = (unsigned int)ft_id;
    zT_474 = wp_head[zT_473];
    zT_475 = (unsigned int)wp_count;
    wp_next[zT_475] = zT_474;
    zT_476 = (unsigned int)ft_id;
    wp_head[zT_476] = wp_count;
    zT_477 = 1;
    zT_478 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_477)), 32u);
    zT_479 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_477)), 32u);
    zT_481 = zT_479 == (unsigned int)(0);
    if (!(zT_481)) { pal_trap(); }
    wp_count = zT_478;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_493 = self->registry;
    zT_494 = zT_493->array_items;
    zT_495 = ty.payload_idx;
    zT_496 = (unsigned int)zT_495;
    zT_497 = zT_494[zT_496];
    zT_498 = zT_497.elem;
    et = zT_498;
    zT_500 = self->registry;
    zT_501 = zT_500->types_items;
    zT_502 = (unsigned int)et;
    zT_503 = zT_501[zT_502];
    et_ty = zT_503;
    zT_504 = et_ty.kind;
    zT_506 = zF_A47239A9_fieldEmbedsByValue(zT_504);
    if (zT_506) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_554 = ty.kind;
    if ((unsigned char)(zT_554 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_507 = 0;
    is_po = zT_507;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_508 = et_ty.kind;
    if ((unsigned char)(zT_508 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_512 = perm_alloc;
    zT_513 = (unsigned int**)&wp_to;
    zT_514 = (unsigned int**)&wp_next;
    zT_515 = (unsigned int*)&wp_edge_cap;
    zT_516 = wp_count;
    zF_25C377BD_growWpEdges(zT_512, zT_513, zT_514, zT_515, zT_516);
    zT_520 = (unsigned int)ti;
    zT_521 = (unsigned int)wp_count;
    wp_to[zT_521] = zT_520;
    zT_522 = (unsigned int)et;
    zT_523 = wp_head[zT_522];
    zT_524 = (unsigned int)wp_count;
    wp_next[zT_524] = zT_523;
    zT_525 = (unsigned int)et;
    wp_head[zT_525] = wp_count;
    zT_526 = 1;
    zT_527 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_526)), 32u);
    zT_528 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_526)), 32u);
    zT_530 = zT_528 == (unsigned int)(0);
    if (!(zT_530)) { pal_trap(); }
    wp_count = zT_527;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_531 = et_ty.kind;
    if ((unsigned char)(zT_531 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_535 = perm_alloc;
    zT_536 = (unsigned int**)&wp_to;
    zT_537 = (unsigned int**)&wp_next;
    zT_538 = (unsigned int*)&wp_edge_cap;
    zT_539 = wp_count;
    zF_25C377BD_growWpEdges(zT_535, zT_536, zT_537, zT_538, zT_539);
    zT_543 = (unsigned int)ti;
    zT_544 = (unsigned int)wp_count;
    wp_to[zT_544] = zT_543;
    zT_545 = (unsigned int)et;
    zT_546 = wp_head[zT_545];
    zT_547 = (unsigned int)wp_count;
    wp_next[zT_547] = zT_546;
    zT_548 = (unsigned int)et;
    wp_head[zT_548] = wp_count;
    zT_549 = 1;
    zT_550 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_549)), 32u);
    zT_551 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_549)), 32u);
    zT_553 = zT_551 == (unsigned int)(0);
    if (!(zT_553)) { pal_trap(); }
    wp_count = zT_550;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_559 = self->registry;
    zT_560 = zT_559->eu_items;
    zT_561 = ty.payload_idx;
    zT_562 = (unsigned int)zT_561;
    zT_563 = zT_560[zT_562];
    zT_564 = zT_563.payload;
    eup = zT_564;
    zT_566 = self->registry;
    zT_567 = zT_566->types_items;
    zT_568 = (unsigned int)eup;
    zT_569 = zT_567[zT_568];
    eup_ty = zT_569;
    zT_570 = eup_ty.kind;
    zT_572 = zF_A47239A9_fieldEmbedsByValue(zT_570);
    if (zT_572) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_620 = ty.kind;
    if ((unsigned char)(zT_620 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_573 = 0;
    is_po = zT_573;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_574 = eup_ty.kind;
    if ((unsigned char)(zT_574 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_578 = perm_alloc;
    zT_579 = (unsigned int**)&wp_to;
    zT_580 = (unsigned int**)&wp_next;
    zT_581 = (unsigned int*)&wp_edge_cap;
    zT_582 = wp_count;
    zF_25C377BD_growWpEdges(zT_578, zT_579, zT_580, zT_581, zT_582);
    zT_586 = (unsigned int)ti;
    zT_587 = (unsigned int)wp_count;
    wp_to[zT_587] = zT_586;
    zT_588 = (unsigned int)eup;
    zT_589 = wp_head[zT_588];
    zT_590 = (unsigned int)wp_count;
    wp_next[zT_590] = zT_589;
    zT_591 = (unsigned int)eup;
    wp_head[zT_591] = wp_count;
    zT_592 = 1;
    zT_593 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_592)), 32u);
    zT_594 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_592)), 32u);
    zT_596 = zT_594 == (unsigned int)(0);
    if (!(zT_596)) { pal_trap(); }
    wp_count = zT_593;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_597 = eup_ty.kind;
    if ((unsigned char)(zT_597 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_601 = perm_alloc;
    zT_602 = (unsigned int**)&wp_to;
    zT_603 = (unsigned int**)&wp_next;
    zT_604 = (unsigned int*)&wp_edge_cap;
    zT_605 = wp_count;
    zF_25C377BD_growWpEdges(zT_601, zT_602, zT_603, zT_604, zT_605);
    zT_609 = (unsigned int)ti;
    zT_610 = (unsigned int)wp_count;
    wp_to[zT_610] = zT_609;
    zT_611 = (unsigned int)eup;
    zT_612 = wp_head[zT_611];
    zT_613 = (unsigned int)wp_count;
    wp_next[zT_613] = zT_612;
    zT_614 = (unsigned int)eup;
    wp_head[zT_614] = wp_count;
    zT_615 = 1;
    zT_616 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_615)), 32u);
    zT_617 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_615)), 32u);
    zT_619 = zT_617 == (unsigned int)(0);
    if (!(zT_619)) { pal_trap(); }
    wp_count = zT_616;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_625 = self->registry;
    zT_626 = zT_625->opt_items;
    zT_627 = ty.payload_idx;
    zT_628 = (unsigned int)zT_627;
    zT_629 = zT_626[zT_628];
    zT_630 = zT_629.payload;
    op_p = zT_630;
    zT_632 = self->registry;
    zT_633 = zT_632->types_items;
    zT_634 = (unsigned int)op_p;
    zT_635 = zT_633[zT_634];
    op_ty = zT_635;
    zT_636 = op_ty.kind;
    zT_638 = zF_EA3ED3F3_requiresFullDef(zT_636);
    if (zT_638) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_639 = 0;
    is_po = zT_639;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_640 = op_ty.kind;
    if ((unsigned char)(zT_640 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_644 = perm_alloc;
    zT_645 = (unsigned int**)&wp_to;
    zT_646 = (unsigned int**)&wp_next;
    zT_647 = (unsigned int*)&wp_edge_cap;
    zT_648 = wp_count;
    zF_25C377BD_growWpEdges(zT_644, zT_645, zT_646, zT_647, zT_648);
    zT_652 = (unsigned int)ti;
    zT_653 = (unsigned int)wp_count;
    wp_to[zT_653] = zT_652;
    zT_654 = (unsigned int)op_p;
    zT_655 = wp_head[zT_654];
    zT_656 = (unsigned int)wp_count;
    wp_next[zT_656] = zT_655;
    zT_657 = (unsigned int)op_p;
    wp_head[zT_657] = wp_count;
    zT_658 = 1;
    zT_659 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_658)), 32u);
    zT_660 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_658)), 32u);
    zT_662 = zT_660 == (unsigned int)(0);
    if (!(zT_662)) { pal_trap(); }
    wp_count = zT_659;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_663 = op_ty.kind;
    if ((unsigned char)(zT_663 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_667 = perm_alloc;
    zT_668 = (unsigned int**)&wp_to;
    zT_669 = (unsigned int**)&wp_next;
    zT_670 = (unsigned int*)&wp_edge_cap;
    zT_671 = wp_count;
    zF_25C377BD_growWpEdges(zT_667, zT_668, zT_669, zT_670, zT_671);
    zT_675 = (unsigned int)ti;
    zT_676 = (unsigned int)wp_count;
    wp_to[zT_676] = zT_675;
    zT_677 = (unsigned int)op_p;
    zT_678 = wp_head[zT_677];
    zT_679 = (unsigned int)wp_count;
    wp_next[zT_679] = zT_678;
    zT_680 = (unsigned int)op_p;
    wp_head[zT_680] = wp_count;
    zT_681 = 1;
    zT_682 = zig_wrap_add_u(((zu64)(wp_count)), ((zu64)(zT_681)), 32u);
    zT_683 = zig_overflow_flag_add_u(((zu64)(wp_count)), ((zu64)(zT_681)), 32u);
    zT_685 = zT_683 == (unsigned int)(0);
    if (!(zT_685)) { pal_trap(); }
    wp_count = zT_682;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_688 = (unsigned int)ti;
    zT_689 = (unsigned int)wl_tail;
    worklist[zT_689] = zT_688;
    zT_690 = 1;
    zT_691 = zig_wrap_add_u(((zu64)(wl_tail)), ((zu64)(zT_690)), 32u);
    zT_692 = zig_overflow_flag_add_u(((zu64)(wl_tail)), ((zu64)(zT_690)), 32u);
    zT_694 = zT_692 == (unsigned int)(0);
    if (!(zT_694)) { pal_trap(); }
    wl_tail = zT_691;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((unsigned char)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_703 = (unsigned int)wl_head;
    zT_704 = worklist[zT_703];
    cur = zT_704;
    zT_705 = 1;
    zT_706 = zig_wrap_add_u(((zu64)(wl_head)), ((zu64)(zT_705)), 32u);
    zT_707 = zig_overflow_flag_add_u(((zu64)(wl_head)), ((zu64)(zT_705)), 32u);
    zT_709 = zT_707 == (unsigned int)(0);
    if (!(zT_709)) { pal_trap(); }
    wl_head = zT_706;
    zT_711 = (unsigned int)cur;
    zT_712 = wp_head[zT_711];
    e = zT_712;
    goto z_bb_134;
    z_bb_132:
    zT_733 = perm_alloc;
    zT_734 = tl;
    zT_735 = zF_619D56E6_u32ToU32MapInitCap(zT_733, zT_734);
    po_map = zT_735;
    zT_737 = perm_alloc;
    zT_738 = tl;
    zT_739 = zF_619D56E6_u32ToU32MapInitCap(zT_737, zT_738);
    nd_map = zT_739;
    zT_741 = perm_alloc;
    zT_742 = tl;
    zT_743 = zF_619D56E6_u32ToU32MapInitCap(zT_741, zT_742);
    sh_map = zT_743;
    zT_745 = 0;
    plen = zT_745;
    zT_746 = 0;
    zT_747 = (unsigned int)zT_746;
    ti = zT_747;
    goto z_bb_140;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((unsigned char)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_716 = (unsigned int)e;
    zT_717 = wp_to[zT_716];
    parent_tid = zT_717;
    zT_718 = (unsigned int)parent_tid;
    zT_719 = pointer_only[zT_718];
    if ((unsigned char)(zT_719 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_722 = 0;
    zT_723 = (unsigned int)parent_tid;
    pointer_only[zT_723] = zT_722;
    zT_724 = (unsigned int)wl_tail;
    worklist[zT_724] = parent_tid;
    zT_725 = 1;
    zT_726 = zig_wrap_add_u(((zu64)(wl_tail)), ((zu64)(zT_725)), 32u);
    zT_727 = zig_overflow_flag_add_u(((zu64)(wl_tail)), ((zu64)(zT_725)), 32u);
    zT_729 = zT_727 == (unsigned int)(0);
    if (!(zT_729)) { pal_trap(); }
    wl_tail = zT_726;
    goto z_bb_139;
    z_bb_139:
    zT_730 = (unsigned int)e;
    zT_731 = wp_next[zT_730];
    e = zT_731;
    goto z_bb_137;
    z_bb_140:
    if ((unsigned char)(ti < tl)) goto z_bb_141; else goto z_bb_142;
    z_bb_141:
    zT_750 = self->registry;
    zT_751 = zT_750->types_items;
    zT_752 = zT_751[ti];
    ty = zT_752;
    zT_753 = pointer_only[ti];
    if ((unsigned char)(zT_753 != (unsigned char)(0))) goto z_bb_144; else goto z_bb_145;
    z_bb_142:
    zT_841 = self->registry;
    zT_842 = (zT_21D3708C_U32ToU32Map*)&sh_map;
    zT_843 = (zT_21D3708C_U32ToU32Map*)&po_map;
    zF_586B7FD5_classificationShare(zT_841, zT_842, zT_843);
    zT_848 = "CLS:c";
    zT_850 = 5;
    zT_849.ptr = (unsigned char*)zT_848;
    zT_849.len = zT_850;
    cls_m = zT_849;
    zT_851 = cls_m;
    zF_48AC7B3A_markerWrite(zT_851);
    zT_852 = plen;
    zF_C8A36147_markerU32(zT_852);
    zT_854 = "\n";
    zT_856 = 1;
    zT_855.ptr = (unsigned char*)zT_854;
    zT_855.len = zT_856;
    cls_nl = zT_855;
    zT_857 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_857);
    zT_858 = 0;
    zT_859 = (unsigned int)zT_858;
    ti = zT_859;
    goto z_bb_178;
    z_bb_143:
    zT_835 = 1;
    zT_836 = (unsigned int)zT_835;
    zT_837 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_836)), 32u);
    zT_838 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_836)), 32u);
    zT_840 = zT_838 == (unsigned int)(0);
    if (!(zT_840)) { pal_trap(); }
    ti = zT_837;
    goto z_bb_140;
    z_bb_144:
    zT_756 = (zT_21D3708C_U32ToU32Map*)&po_map;
    zF_26476265_u32ToU32MapPut(zT_756, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    zT_762 = 1;
    zT_763 = zig_wrap_add_u(((zu64)(plen)), ((zu64)(zT_762)), 32u);
    zT_764 = zig_overflow_flag_add_u(((zu64)(plen)), ((zu64)(zT_762)), 32u);
    zT_766 = zT_764 == (unsigned int)(0);
    if (!(zT_766)) { pal_trap(); }
    plen = zT_763;
    goto z_bb_145;
    z_bb_145:
    zT_767 = ty;
    zT_768 = zF_F673DF45_classificationNeeds(zT_767);
    if (zT_768) goto z_bb_146; else goto z_bb_147;
    z_bb_146:
    zT_769 = (zT_21D3708C_U32ToU32Map*)&nd_map;
    zF_26476265_u32ToU32MapPut(zT_769, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    goto z_bb_147;
    z_bb_147:
    zT_776 = 0;
    is_synthetic = zT_776;
    zT_777 = ty.name_id;
    if ((unsigned char)(zT_777 == (unsigned int)(0))) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    zT_780 = ty.kind;
    zT_782 = zF_EEDBE6D1_classificationIsSyn(zT_780);
    if (zT_782) goto z_bb_150; else goto z_bb_151;
    z_bb_149:
    zT_785 = 0;
    is_clsv = zT_785;
    zT_786 = pointer_only[ti];
    if ((unsigned char)(zT_786 == (unsigned char)(0))) goto z_bb_152; else goto z_bb_153;
    z_bb_150:
    zT_783 = 1;
    is_synthetic = zT_783;
    goto z_bb_151;
    z_bb_151:
    goto z_bb_149;
    z_bb_152:
    zT_789 = 1;
    is_clsv = zT_789;
    goto z_bb_153;
    z_bb_153:
    zT_791 = 0;
    is_carrier64 = zT_791;
    zT_792 = ty.kind;
    if ((unsigned char)(zT_792 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_155; else goto z_bb_154;
    z_bb_154:
    zT_797 = ty.kind;
    zT_796 = zT_797 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_156;
    z_bb_155:
    zT_796 = 1;
    goto z_bb_156;
    z_bb_156:
    if (zT_796) goto z_bb_158; else goto z_bb_157;
    z_bb_157:
    zT_802 = ty.kind;
    zT_801 = zT_802 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_159;
    z_bb_158:
    zT_801 = 1;
    goto z_bb_159;
    z_bb_159:
    if (zT_801) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_806 = 1;
    is_carrier64 = zT_806;
    goto z_bb_161;
    z_bb_161:
    zT_808 = 0;
    is_fn_named = zT_808;
    zT_809 = ty.kind;
    if ((unsigned char)(zT_809 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_814 = ty.name_id;
    zT_813 = zT_814 != (unsigned int)(0);
    goto z_bb_164;
    z_bb_163:
    zT_813 = 0;
    goto z_bb_164;
    z_bb_164:
    if (zT_813) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_817 = 1;
    is_fn_named = zT_817;
    goto z_bb_166;
    z_bb_166:
    if ((unsigned char)(is_synthetic != (unsigned char)(0))) goto z_bb_168; else goto z_bb_167;
    z_bb_167:
    zT_820 = is_clsv != (unsigned char)(0);
    goto z_bb_169;
    z_bb_168:
    zT_820 = 1;
    goto z_bb_169;
    z_bb_169:
    if (zT_820) goto z_bb_171; else goto z_bb_170;
    z_bb_170:
    zT_823 = is_carrier64 != (unsigned char)(0);
    goto z_bb_172;
    z_bb_171:
    zT_823 = 1;
    goto z_bb_172;
    z_bb_172:
    if (zT_823) goto z_bb_174; else goto z_bb_173;
    z_bb_173:
    zT_826 = is_fn_named != (unsigned char)(0);
    goto z_bb_175;
    z_bb_174:
    zT_826 = 1;
    goto z_bb_175;
    z_bb_175:
    if (zT_826) goto z_bb_176; else goto z_bb_177;
    z_bb_176:
    zT_829 = (zT_21D3708C_U32ToU32Map*)&sh_map;
    zF_26476265_u32ToU32MapPut(zT_829, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    goto z_bb_177;
    z_bb_177:
    goto z_bb_143;
    z_bb_178:
    if ((unsigned char)(ti < tl)) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_861 = pointer_only[ti];
    if ((unsigned char)(zT_861 != (unsigned char)(0))) goto z_bb_182; else goto z_bb_184;
    z_bb_180:
    classif->pointer_only_map = po_map;
    classif->needs_def_map = nd_map;
    classif->shared_set = sh_map;
    return;
    z_bb_181:
    zT_892 = 1;
    zT_893 = (unsigned int)zT_892;
    zT_894 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_893)), 32u);
    zT_895 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_893)), 32u);
    zT_897 = zT_895 == (unsigned int)(0);
    if (!(zT_897)) { pal_trap(); }
    ti = zT_894;
    goto z_bb_178;
    z_bb_182:
    zT_865 = "CLS:p";
    zT_867 = 5;
    zT_866.ptr = (unsigned char*)zT_865;
    zT_866.len = zT_867;
    pfx = zT_866;
    zT_868 = pfx;
    zF_48AC7B3A_markerWrite(zT_868);
    goto z_bb_183;
    z_bb_183:
    zF_C8A36147_markerU32((unsigned int)((unsigned int)ti));
    zT_877 = "k";
    zT_879 = 1;
    zT_878.ptr = (unsigned char*)zT_877;
    zT_878.len = zT_879;
    ck = zT_878;
    zT_880 = ck;
    zF_48AC7B3A_markerWrite(zT_880);
    zT_882 = self->registry;
    zT_883 = zT_882->types_items;
    zT_884 = zT_883[ti];
    zT_885 = zT_884.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_885));
    zT_888 = "\n";
    zT_890 = 1;
    zT_889.ptr = (unsigned char*)zT_888;
    zT_889.len = zT_890;
    cnl = zT_889;
    zT_891 = cnl;
    zF_48AC7B3A_markerWrite(zT_891);
    goto z_bb_181;
    z_bb_184:
    zT_870 = "CLS:v";
    zT_872 = 5;
    zT_871.ptr = (unsigned char*)zT_870;
    zT_871.len = zT_872;
    pfx = zT_871;
    zT_873 = pfx;
    zF_48AC7B3A_markerWrite(zT_873);
    goto z_bb_183;
}

/* classificationIsSyntheticEmittable */
unsigned char zF_EEDBE6D1_classificationIsSyn(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    unsigned char zT_28;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_24) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_28 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_21;
    z_bb_20:
    zT_28 = 1;
    goto z_bb_21;
    z_bb_21:
    return zT_28;
}

/* classificationNeedsDef */
unsigned char zF_F673DF45_classificationNeeds(zT_D155D06D_Type ty) {
    zT_33EF6BFB_TypeKind zT_1;
    zT_33EF6BFB_TypeKind zT_6;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_16;
    zT_33EF6BFB_TypeKind zT_21;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_31;
    zT_33EF6BFB_TypeKind zT_36;
    unsigned int zT_41;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned char zT_46;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zT_1 = ty.kind;
    if ((unsigned char)(zT_1 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_16 = ty.kind;
    if ((unsigned char)(zT_16 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_21 = ty.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_26 = ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_31 = ty.kind;
    if ((unsigned char)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_36 = ty.kind;
    if ((unsigned char)(zT_36 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_41 = ty.name_id;
    if ((unsigned char)(zT_41 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_44 = ty.kind;
    zT_46 = zF_EEDBE6D1_classificationIsSyn(zT_44);
    if ((unsigned char)(!zT_46)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    goto z_bb_18;
}

/* classificationSharedClosure */
void zF_586B7FD5_classificationShare(zT_338B7C76_TypeRegistry* reg, zT_21D3708C_U32ToU32Map* shared, zT_21D3708C_U32ToU32Map* po) {
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_D155D06D_Type* zT_14;
    unsigned int zT_15;
    zT_D155D06D_Type zT_16;
    unsigned int zT_17;
    zT_21D3708C_U32ToU32Map* zT_20;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 zT_22;
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    unsigned char zT_28;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned char zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    unsigned char zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned char zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    zT_21D3708C_U32ToU32Map* zT_53;
    unsigned int zT_54;
    zT_BAEE192E_Opt_10 zT_55;
    unsigned char zT_56;
    unsigned int zT_59;
    unsigned int zT_61;
    zT_21D3708C_U32ToU32Map* zT_63;
    unsigned int zT_64;
    zT_BAEE192E_Opt_10 zT_65;
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_71;
    zT_21D3708C_U32ToU32Map* zT_72;
    unsigned int zT_73;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    unsigned int changed;
    unsigned int ti2;
    zT_D155D06D_Type ty2;
    unsigned int sj;
    zT_4 = 1;
    changed = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(changed != (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 0;
    changed = zT_7;
    zT_9 = 0;
    ti2 = zT_9;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ti2) < zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_14 = reg->types_items;
    zT_15 = (unsigned int)ti2;
    zT_16 = zT_14[zT_15];
    ty2 = zT_16;
    zT_17 = ty2.name_id;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_83 = 1;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zig_wrap_add_u(((zu64)(ti2)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_add_u(((zu64)(ti2)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    ti2 = zT_85;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_20 = shared;
    zT_21 = ti2;
    zT_22 = zF_F3EE5998_u32ToU32MapGet(zT_20, zT_21);
    zT_23 = zT_22.has_value;
    if (zT_23) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_24 = ty2.kind;
    if ((unsigned char)(zT_24 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_29 = ty2.kind;
    zT_28 = zT_29 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_28 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_28) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_34 = ty2.kind;
    zT_33 = zT_34 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_18;
    z_bb_17:
    zT_33 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_33) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_39 = ty2.kind;
    zT_38 = zT_39 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_21;
    z_bb_20:
    zT_38 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_38) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_44 = ty2.kind;
    zT_43 = zT_44 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_24;
    z_bb_23:
    zT_43 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_43) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_49 = ty2.kind;
    zT_48 = zT_49 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_27;
    z_bb_26:
    zT_48 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_48) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    goto z_bb_8;
    z_bb_29:
    zT_53 = po;
    zT_54 = ti2;
    zT_55 = zF_F3EE5998_u32ToU32MapGet(zT_53, zT_54);
    zT_56 = zT_55.has_value;
    if ((unsigned char)(!zT_56)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_8;
    z_bb_31:
    zT_59 = 0;
    sj = zT_59;
    goto z_bb_32;
    z_bb_32:
    zT_61 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)sj) < zT_61)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_63 = shared;
    zT_64 = sj;
    zT_65 = zF_F3EE5998_u32ToU32MapGet(zT_63, zT_64);
    zT_66 = zT_65.has_value;
    if ((unsigned char)(!zT_66)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_8;
    z_bb_35:
    zT_77 = 1;
    zT_78 = (unsigned int)zT_77;
    zT_79 = zig_wrap_add_u(((zu64)(sj)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_add_u(((zu64)(sj)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    sj = zT_79;
    goto z_bb_32;
    z_bb_36:
    goto z_bb_35;
    z_bb_37:
    zT_68 = reg;
    zT_69 = sj;
    zT_70 = ti2;
    zT_71 = zF_8A421992_typeRefsContains(zT_68, zT_69, zT_70);
    if (zT_71) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_72 = shared;
    zT_73 = ti2;
    zF_26476265_u32ToU32MapPut(zT_72, zT_73, (unsigned int)(1));
    zT_76 = 1;
    changed = zT_76;
    goto z_bb_34;
    z_bb_39:
    goto z_bb_35;
}

/* collectNeededTuples */
void zF_7845A68F_collectNeededTuples(zT_338B7C76_TypeRegistry* reg, zT_21D3708C_U32ToU32Map* set, unsigned int tid) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_21D3708C_U32ToU32Map* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_16;
    unsigned char zT_17;
    zT_21D3708C_U32ToU32Map* zT_18;
    unsigned int zT_19;
    zT_666DC2E1_TuplePayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_666DC2E1_TuplePayload zT_26;
    unsigned int zT_28;
    unsigned short zT_29;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_21D3708C_U32ToU32Map* zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zT_D155D06D_Type ty;
    zT_666DC2E1_TuplePayload tup;
    unsigned int i;
    unsigned int et;
    zT_4 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = set;
    zT_15 = tid;
    zT_16 = zF_F3EE5998_u32ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_18 = set;
    zT_19 = tid;
    zF_26476265_u32ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->tup_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    tup = zT_26;
    zT_28 = 0;
    i = zT_28;
    goto z_bb_7;
    z_bb_7:
    zT_29 = tup.elems_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_29))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = reg->xt_items;
    zT_34 = tup.elems_start;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zig_wrap_add_u(((zu64)(zT_35)), ((zu64)(i)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(zT_35)), ((zu64)(i)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = zT_33[zT_36];
    et = zT_40;
    zT_42 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)et) < zT_42)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    i = zT_56;
    goto z_bb_7;
    z_bb_11:
    zT_44 = reg->types_items;
    zT_45 = (unsigned int)et;
    zT_46 = zT_44[zT_45];
    zT_47 = zT_46.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_51 = reg;
    zT_52 = set;
    zT_53 = et;
    zF_7845A68F_collectNeededTuples(zT_51, zT_52, zT_53);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
}

/* classifyTypeEmissionFinalize */
void zF_0DE160E2_classifyTypeEmissio(zT_338B7C76_TypeRegistry* reg, zT_786E6CF2_EmissionClassificat* classif) {
    zT_21D3708C_U32ToU32Map* zT_3;
    zT_21D3708C_U32ToU32Map* zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    zT_21D3708C_U32ToU32Map* zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_D155D06D_Type* zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type zT_18;
    zT_D155D06D_Type zT_19;
    unsigned char zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    unsigned int zT_22;
    unsigned char zT_26;
    unsigned int zT_27;
    zT_33EF6BFB_TypeKind zT_30;
    unsigned char zT_32;
    unsigned char zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_45;
    zT_21D3708C_U32ToU32Map* zT_46;
    unsigned int zT_47;
    zT_BAEE192E_Opt_10 zT_48;
    unsigned char zT_49;
    unsigned char zT_51;
    unsigned char zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    unsigned char zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned char zT_68;
    unsigned char zT_70;
    zT_33EF6BFB_TypeKind zT_71;
    unsigned char zT_75;
    unsigned int zT_76;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char zT_85;
    unsigned char zT_88;
    zT_21D3708C_U32ToU32Map* zT_91;
    unsigned int zT_92;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_21D3708C_U32ToU32Map* zT_102;
    zT_21D3708C_U32ToU32Map* zT_103;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_21D3708C_U32ToU32Map* shared;
    zT_21D3708C_U32ToU32Map* po;
    zT_21D3708C_U32ToU32Map* nd;
    zT_21D3708C_U32ToU32Map* needed;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_synthetic;
    unsigned char is_clsv;
    unsigned char is_carrier64;
    unsigned char is_fn_named;
    zT_3 = &classif->shared_set;
    shared = zT_3;
    zT_5 = &classif->pointer_only_map;
    po = zT_5;
    zT_7 = &classif->needs_def_map;
    nd = zT_7;
    zT_9 = &classif->needed_tuple_set;
    needed = zT_9;
    zT_11 = 0;
    ti = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ti) < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = reg->types_items;
    zT_17 = (unsigned int)ti;
    zT_18 = zT_16[zT_17];
    ty = zT_18;
    zT_19 = ty;
    zT_20 = zF_F673DF45_classificationNeeds(zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_101 = reg;
    zT_102 = shared;
    zT_103 = po;
    zF_586B7FD5_classificationShare(zT_101, zT_102, zT_103);
    return;
    z_bb_4:
    zT_95 = 1;
    zT_96 = (unsigned int)zT_95;
    zT_97 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    ti = zT_97;
    goto z_bb_1;
    z_bb_5:
    zT_21 = nd;
    zT_22 = ti;
    zF_26476265_u32ToU32MapPut(zT_21, zT_22, (unsigned int)(1));
    goto z_bb_6;
    z_bb_6:
    zT_26 = 0;
    is_synthetic = zT_26;
    zT_27 = ty.name_id;
    if ((unsigned char)(zT_27 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = ty.kind;
    zT_32 = zF_EEDBE6D1_classificationIsSyn(zT_30);
    if (zT_32) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_45 = 0;
    is_clsv = zT_45;
    zT_46 = po;
    zT_47 = ti;
    zT_48 = zF_F3EE5998_u32ToU32MapGet(zT_46, zT_47);
    zT_49 = zT_48.has_value;
    if ((unsigned char)(!zT_49)) goto z_bb_16; else goto z_bb_17;
    z_bb_9:
    zT_33 = 1;
    is_synthetic = zT_33;
    goto z_bb_10;
    z_bb_10:
    zT_34 = ty.kind;
    if ((unsigned char)(zT_34 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = needed;
    zT_40 = ti;
    zT_41 = zF_F3EE5998_u32ToU32MapGet(zT_39, zT_40);
    zT_42 = zT_41.has_value;
    zT_38 = zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_43 = 1;
    is_synthetic = zT_43;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_51 = 1;
    is_clsv = zT_51;
    goto z_bb_17;
    z_bb_17:
    zT_53 = 0;
    is_carrier64 = zT_53;
    zT_54 = ty.kind;
    if ((unsigned char)(zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_20;
    z_bb_19:
    zT_58 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_58) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_64 = ty.kind;
    zT_63 = zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_23;
    z_bb_22:
    zT_63 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_63) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_68 = 1;
    is_carrier64 = zT_68;
    goto z_bb_25;
    z_bb_25:
    zT_70 = 0;
    is_fn_named = zT_70;
    zT_71 = ty.kind;
    if ((unsigned char)(zT_71 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_76 = ty.name_id;
    zT_75 = zT_76 != (unsigned int)(0);
    goto z_bb_28;
    z_bb_27:
    zT_75 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_75) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_79 = 1;
    is_fn_named = zT_79;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)(is_synthetic != (unsigned char)(0))) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_82 = is_clsv != (unsigned char)(0);
    goto z_bb_33;
    z_bb_32:
    zT_82 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_82) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_85 = is_carrier64 != (unsigned char)(0);
    goto z_bb_36;
    z_bb_35:
    zT_85 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_85) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_88 = is_fn_named != (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_88 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_88) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_91 = shared;
    zT_92 = ti;
    zF_26476265_u32ToU32MapPut(zT_91, zT_92, (unsigned int)(1));
    goto z_bb_41;
    z_bb_41:
    goto z_bb_4;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int** zT_9;
    unsigned int** zT_10;
    unsigned int* zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = perm_a;
    zT_9 = wp_to_ptr;
    zT_10 = wp_next_ptr;
    zT_12 = cap_ptr;
    zF_F638C869_nameScopeGrowPair(zT_8, zT_9, zT_10, (unsigned int)((unsigned int)count), zT_12, (unsigned int)(0));
    return;
}

/* evalConstModuleOfExpr */
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_3D7259E2_SymbolRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_77F031D4_Opt_960 zT_27;
    unsigned char zT_28;
    zT_3C598AEF_SymbolKind zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned short zT_54;
    int zT_57;
    unsigned int zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    zT_3D7259E2_SymbolRegistry* zT_64;
    unsigned int zT_66;
    zT_77F031D4_Opt_960 zT_69;
    unsigned char zT_70;
    zT_3C598AEF_SymbolKind zT_72;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    unsigned short zT_96;
    int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned char zT_103;
    zT_8143F551_AstKind zT_105;
    zT_ABC1EBBE_TypeResolveEnv* zT_110;
    unsigned int zT_111;
    unsigned int zT_113;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    zT_3D7259E2_SymbolRegistry* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_77F031D4_Opt_960 zT_126;
    unsigned char zT_127;
    zT_3C598AEF_SymbolKind zT_129;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_137;
    unsigned int zT_138;
    zT_338B7C76_TypeRegistry* zT_140;
    unsigned int zT_141;
    zT_338B7C76_TypeRegistry* zT_144;
    zT_D155D06D_Type* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_D155D06D_Type zT_148;
    zT_33EF6BFB_TypeKind zT_149;
    unsigned short zT_153;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_126, (unsigned int)sizeof zT_126);
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* s2;
    zT_D155D06D_Type sty2;
    unsigned int base_mod;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* msym;
    zT_D155D06D_Type mty;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_53458827_astStoreIdentifier(zT_15, zT_16);
    name_id = zT_18;
    zT_19 = env->module_id;
    if ((unsigned char)(zT_19 != (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_105 = node.kind;
    if ((unsigned char)(zT_105 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_22 = env->symbol_reg;
    zT_23 = env->module_id;
    zT_24 = name_id;
    zT_27 = zF_A398987E_symbolRegistryQuali(zT_22, zT_23, zT_24);
    zT_28 = zT_27.has_value;
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    si = zT_58;
    goto z_bb_18;
    z_bb_7:
    if (!(zT_27.has_value)) { pal_trap(); }
    s = zT_27.value;
    zT_30 = s->kind;
    if ((unsigned char)(zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_34 = s->module_id;
    return zT_34;
    z_bb_10:
    zT_35 = s->type_id;
    if ((unsigned char)(zT_35 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = s->type_id;
    zT_41 = env->typereg;
    zT_42 = zT_41->types_len;
    zT_38 = (unsigned int)((unsigned int)zT_39) < zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = env->typereg;
    zT_46 = zT_45->types_items;
    zT_47 = s->type_id;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    sty = zT_49;
    zT_50 = sty.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_54 = sty.module_id;
    return (unsigned int)((unsigned int)zT_54);
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_59 = env->symbol_reg;
    zT_60 = zT_59->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_60))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_64 = env->symbol_reg;
    zT_66 = name_id;
    zT_69 = zF_A398987E_symbolRegistryQuali(zT_64, (unsigned int)((unsigned int)si), zT_66);
    sym = zT_69;
    zT_70 = sym.has_value;
    if (zT_70) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    zT_98 = 1;
    zT_99 = (unsigned int)zT_98;
    zT_100 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_99)), 32u);
    zT_101 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_99)), 32u);
    zT_103 = zT_101 == (unsigned int)(0);
    if (!(zT_103)) { pal_trap(); }
    si = zT_100;
    goto z_bb_18;
    z_bb_22:
    if (!(sym.has_value)) { pal_trap(); }
    s2 = sym.value;
    zT_72 = s2->kind;
    if ((unsigned char)(zT_72 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_76 = s2->module_id;
    return zT_76;
    z_bb_25:
    zT_77 = s2->type_id;
    if ((unsigned char)(zT_77 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_81 = s2->type_id;
    zT_83 = env->typereg;
    zT_84 = zT_83->types_len;
    zT_80 = (unsigned int)((unsigned int)zT_81) < zT_84;
    goto z_bb_28;
    z_bb_27:
    zT_80 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_80) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_items;
    zT_89 = s2->type_id;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    sty2 = zT_91;
    zT_92 = sty2.kind;
    if ((unsigned char)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_23;
    z_bb_31:
    zT_96 = sty2.module_id;
    return (unsigned int)((unsigned int)zT_96);
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_110 = env;
    zT_111 = node.child_0;
    zT_113 = zF_0E4084E4_evalConstModuleOfEx(zT_110, zT_111);
    base_mod = zT_113;
    if ((unsigned char)(base_mod == (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    return (unsigned int)(0);
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_118 = env->store;
    zT_119 = node_idx;
    zT_121 = zF_8BA26B9E_astStoreNodePayload(zT_118, zT_119);
    field_name_id = zT_121;
    zT_122 = env->symbol_reg;
    zT_123 = base_mod;
    zT_124 = field_name_id;
    zT_126 = zF_A398987E_symbolRegistryQuali(zT_122, zT_123, zT_124);
    zT_127 = zT_126.has_value;
    if (zT_127) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    if (!(zT_126.has_value)) { pal_trap(); }
    msym = zT_126.value;
    zT_129 = msym->kind;
    if ((unsigned char)(zT_129 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    return (unsigned int)(0);
    z_bb_39:
    zT_133 = msym->module_id;
    return zT_133;
    z_bb_40:
    zT_134 = msym->type_id;
    if ((unsigned char)(zT_134 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_138 = msym->type_id;
    zT_140 = env->typereg;
    zT_141 = zT_140->types_len;
    zT_137 = (unsigned int)((unsigned int)zT_138) < zT_141;
    goto z_bb_43;
    z_bb_42:
    zT_137 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_137) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_144 = env->typereg;
    zT_145 = zT_144->types_items;
    zT_146 = msym->type_id;
    zT_147 = (unsigned int)zT_146;
    zT_148 = zT_145[zT_147];
    mty = zT_148;
    zT_149 = mty.kind;
    if ((unsigned char)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_38;
    z_bb_46:
    zT_153 = mty.module_id;
    return (unsigned int)((unsigned int)zT_153);
    z_bb_47:
    goto z_bb_45;
}

/* evalConstScalarKind */
unsigned char zF_6AE4DFFC_evalConstScalarKind(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    return (unsigned char)(1);
}

/* evalConstIntFull */
zT_7634F9B7_Opt_222 zF_382591DE_evalConstIntFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_7634F9B7_Opt_222 zT_5;
    zT_7634F9B7_Opt_222 zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    zT_79FAE712_u64 zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_79FAE712_u64 zT_27;
    zT_0163D9A4_ComptimeInt zT_28;
    zT_7634F9B7_Opt_222 zT_29;
    zT_8143F551_AstKind zT_30;
    unsigned int zT_34;
    zT_ABC1EBBE_TypeResolveEnv* zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_7634F9B7_Opt_222 zT_47;
    unsigned char zT_48;
    zT_0163D9A4_ComptimeInt zT_51;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt* zT_53;
    unsigned char zT_55;
    zT_7634F9B7_Opt_222 zT_56;
    zT_7634F9B7_Opt_222 zT_57;
    zT_8143F551_AstKind zT_58;
    zT_ABC1EBBE_TypeResolveEnv* zT_62;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    zT_8143F551_AstKind zT_72;
    unsigned char zT_76;
    zT_8143F551_AstKind zT_77;
    unsigned char zT_81;
    zT_8143F551_AstKind zT_82;
    unsigned char zT_86;
    zT_8143F551_AstKind zT_87;
    unsigned char zT_91;
    zT_8143F551_AstKind zT_92;
    unsigned char zT_96;
    zT_8143F551_AstKind zT_97;
    unsigned char zT_101;
    zT_8143F551_AstKind zT_102;
    unsigned char zT_106;
    zT_8143F551_AstKind zT_107;
    unsigned char zT_111;
    zT_8143F551_AstKind zT_112;
    unsigned char zT_116;
    zT_8143F551_AstKind zT_117;
    zT_ABC1EBBE_TypeResolveEnv* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    zT_7634F9B7_Opt_222 zT_131;
    zT_ABC1EBBE_TypeResolveEnv* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    zT_7634F9B7_Opt_222 zT_142;
    unsigned char zT_143;
    unsigned char zT_145;
    zT_0163D9A4_ComptimeInt zT_148;
    zT_8143F551_AstKind zT_149;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    zT_0163D9A4_ComptimeInt* zT_155;
    unsigned char zT_157;
    zT_7634F9B7_Opt_222 zT_159;
    zT_7634F9B7_Opt_222 zT_160;
    zT_8143F551_AstKind zT_161;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    zT_0163D9A4_ComptimeInt* zT_167;
    unsigned char zT_169;
    zT_7634F9B7_Opt_222 zT_171;
    zT_7634F9B7_Opt_222 zT_172;
    zT_8143F551_AstKind zT_173;
    zT_0163D9A4_ComptimeInt zT_177;
    zT_0163D9A4_ComptimeInt zT_178;
    zT_0163D9A4_ComptimeInt* zT_179;
    unsigned char zT_181;
    zT_7634F9B7_Opt_222 zT_183;
    zT_7634F9B7_Opt_222 zT_184;
    zT_8143F551_AstKind zT_185;
    zT_0163D9A4_ComptimeInt zT_190;
    zT_0163D9A4_ComptimeInt zT_191;
    zT_0163D9A4_ComptimeInt zT_192;
    zT_0163D9A4_ComptimeInt* zT_193;
    zT_0163D9A4_ComptimeInt* zT_194;
    unsigned char zT_197;
    zT_7634F9B7_Opt_222 zT_199;
    zT_7634F9B7_Opt_222 zT_200;
    zT_8143F551_AstKind zT_201;
    zT_0163D9A4_ComptimeInt zT_206;
    zT_0163D9A4_ComptimeInt zT_207;
    zT_0163D9A4_ComptimeInt zT_208;
    zT_0163D9A4_ComptimeInt* zT_209;
    zT_0163D9A4_ComptimeInt* zT_210;
    unsigned char zT_213;
    zT_7634F9B7_Opt_222 zT_215;
    zT_7634F9B7_Opt_222 zT_216;
    zT_8143F551_AstKind zT_217;
    zT_0163D9A4_ComptimeInt zT_221;
    zT_0163D9A4_ComptimeInt zT_222;
    zT_0163D9A4_ComptimeInt* zT_223;
    unsigned char zT_225;
    zT_7634F9B7_Opt_222 zT_227;
    zT_7634F9B7_Opt_222 zT_228;
    zT_8143F551_AstKind zT_229;
    zT_0163D9A4_ComptimeInt zT_233;
    zT_0163D9A4_ComptimeInt zT_234;
    zT_0163D9A4_ComptimeInt* zT_235;
    unsigned char zT_237;
    zT_7634F9B7_Opt_222 zT_239;
    zT_7634F9B7_Opt_222 zT_240;
    zT_8143F551_AstKind zT_241;
    zT_0163D9A4_ComptimeInt zT_245;
    zT_0163D9A4_ComptimeInt zT_246;
    zT_0163D9A4_ComptimeInt* zT_247;
    unsigned char zT_249;
    zT_7634F9B7_Opt_222 zT_251;
    zT_7634F9B7_Opt_222 zT_252;
    zT_8143F551_AstKind zT_253;
    zT_0163D9A4_ComptimeInt zT_257;
    zT_0163D9A4_ComptimeInt zT_258;
    zT_0163D9A4_ComptimeInt* zT_259;
    unsigned char zT_261;
    zT_7634F9B7_Opt_222 zT_263;
    zT_7634F9B7_Opt_222 zT_264;
    zT_0163D9A4_ComptimeInt zT_265;
    zT_0163D9A4_ComptimeInt zT_266;
    zT_0163D9A4_ComptimeInt* zT_267;
    unsigned char zT_269;
    zT_7634F9B7_Opt_222 zT_271;
    zT_7634F9B7_Opt_222 zT_272;
    zT_7634F9B7_Opt_222 zT_273;
    zT_8143F551_AstKind zT_274;
    zT_6B0A7D14_AstStore* zT_279;
    unsigned int zT_280;
    unsigned int zT_282;
    zT_9BD83C17_Opt_442 zT_283;
    unsigned char zT_284;
    zT_E2DF2801_LocalConstScope* zT_286;
    unsigned int zT_287;
    zT_BAEE192E_Opt_10 zT_288;
    unsigned char zT_289;
    zT_6B0A7D14_AstStore* zT_292;
    unsigned int zT_293;
    zT_22A7C88B_AstNode zT_295;
    unsigned int zT_296;
    zT_ABC1EBBE_TypeResolveEnv* zT_299;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char zT_307;
    zT_ABC1EBBE_TypeResolveEnv* zT_310;
    unsigned int zT_311;
    zT_77F031D4_Opt_960 zT_312;
    unsigned char zT_313;
    unsigned short zT_315;
    zT_6B0A7D14_AstStore* zT_321;
    unsigned int zT_322;
    zT_22A7C88B_AstNode zT_325;
    unsigned int zT_326;
    zT_ABC1EBBE_TypeResolveEnv* zT_329;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned char zT_337;
    zT_7634F9B7_Opt_222 zT_339;
    zT_8143F551_AstKind zT_340;
    zT_ABC1EBBE_TypeResolveEnv* zT_345;
    unsigned int zT_346;
    unsigned int zT_348;
    zT_6B0A7D14_AstStore* zT_352;
    unsigned int zT_353;
    unsigned int zT_355;
    zT_3D7259E2_SymbolRegistry* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    zT_77F031D4_Opt_960 zT_360;
    unsigned char zT_361;
    zT_ABC1EBBE_TypeResolveEnv* zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    zT_3A105EF1_Symbol* zT_366;
    unsigned char zT_367;
    zT_7634F9B7_Opt_222 zT_369;
    unsigned short zT_370;
    zT_6B0A7D14_AstStore* zT_376;
    unsigned int zT_377;
    zT_22A7C88B_AstNode zT_380;
    unsigned int zT_381;
    zT_ABC1EBBE_TypeResolveEnv* zT_384;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned char zT_392;
    zT_7634F9B7_Opt_222 zT_394;
    zT_8143F551_AstKind zT_395;
    unsigned char* zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_402;
    zT_D3EB6303_StringInterner* zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned int zT_407;
    unsigned char* zT_409;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_410;
    unsigned int zT_411;
    zT_D3EB6303_StringInterner* zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_416;
    unsigned char* zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_420;
    zT_D3EB6303_StringInterner* zT_422;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_423;
    unsigned int zT_425;
    unsigned char* zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428;
    unsigned int zT_429;
    zT_D3EB6303_StringInterner* zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    unsigned int zT_434;
    unsigned char* zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    unsigned int zT_438;
    zT_D3EB6303_StringInterner* zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_443;
    unsigned char* zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    zT_D3EB6303_StringInterner* zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    unsigned int zT_452;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    zT_D3EB6303_StringInterner* zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_461;
    zT_6B0A7D14_AstStore* zT_463;
    unsigned int zT_464;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned char zT_469;
    unsigned int zT_470;
    zT_ABC1EBBE_TypeResolveEnv* zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    zT_6B0A7D14_AstStore* zT_478;
    unsigned int zT_479;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    unsigned char zT_488;
    unsigned int zT_489;
    zT_ABC1EBBE_TypeResolveEnv* zT_493;
    unsigned int zT_494;
    unsigned int zT_495;
    zT_6B0A7D14_AstStore* zT_496;
    unsigned int zT_497;
    unsigned int zT_501;
    unsigned int zT_502;
    unsigned int zT_503;
    unsigned int zT_504;
    unsigned char zT_506;
    zT_7634F9B7_Opt_222 zT_507;
    unsigned char zT_508;
    zT_338B7C76_TypeRegistry* zT_510;
    zT_0163D9A4_ComptimeInt zT_511;
    unsigned int zT_512;
    unsigned char zT_514;
    zT_7634F9B7_Opt_222 zT_515;
    zT_7634F9B7_Opt_222 zT_516;
    unsigned int zT_517;
    unsigned char zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    unsigned int zT_523;
    zT_ABC1EBBE_TypeResolveEnv* zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    zT_6B0A7D14_AstStore* zT_531;
    unsigned int zT_532;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    unsigned int zT_539;
    unsigned char zT_541;
    unsigned int zT_542;
    zT_338B7C76_TypeRegistry* zT_546;
    zT_D155D06D_Type* zT_547;
    unsigned int zT_548;
    zT_D155D06D_Type zT_549;
    unsigned char zT_550;
    unsigned char zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    zT_338B7C76_TypeRegistry* zT_558;
    unsigned int zT_559;
    unsigned char zT_563;
    zT_338B7C76_TypeRegistry* zT_564;
    zT_D155D06D_Type* zT_565;
    unsigned int zT_566;
    zT_D155D06D_Type zT_567;
    zT_33EF6BFB_TypeKind zT_569;
    unsigned char zT_571;
    zT_33EF6BFB_TypeKind zT_572;
    unsigned char zT_576;
    unsigned char zT_577;
    unsigned char zT_580;
    unsigned int zT_581;
    unsigned int zT_584;
    zT_0163D9A4_ComptimeInt zT_586;
    zT_7634F9B7_Opt_222 zT_587;
    unsigned int zT_588;
    unsigned short zT_591;
    zT_0163D9A4_ComptimeInt zT_593;
    zT_7634F9B7_Opt_222 zT_594;
    unsigned int zT_596;
    unsigned int zT_597;
    unsigned int zT_598;
    unsigned int zT_599;
    unsigned char zT_601;
    zT_338B7C76_TypeRegistry* zT_602;
    unsigned int zT_603;
    unsigned char zT_605;
    zT_338B7C76_TypeRegistry* zT_606;
    unsigned int zT_607;
    unsigned char zT_609;
    unsigned int zT_610;
    zT_33EF6BFB_TypeKind zT_611;
    zT_338B7C76_TypeRegistry* zT_615;
    unsigned int zT_616;
    zT_338B7C76_TypeRegistry* zT_618;
    unsigned int zT_619;
    unsigned int zT_621;
    unsigned char zT_622;
    unsigned int zT_623;
    zT_33EF6BFB_TypeKind zT_624;
    unsigned int zT_628;
    zT_33EF6BFB_TypeKind zT_629;
    unsigned char zT_633;
    unsigned char zT_634;
    zT_338B7C76_TypeRegistry* zT_639;
    unsigned int zT_640;
    unsigned int zT_642;
    unsigned int zT_643;
    zT_0163D9A4_ComptimeInt zT_646;
    zT_7634F9B7_Opt_222 zT_647;
    zT_7634F9B7_Opt_222 zT_648;
    unsigned int zT_649;
    unsigned char zT_651;
    unsigned int zT_652;
    zT_ABC1EBBE_TypeResolveEnv* zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_6B0A7D14_AstStore* zT_660;
    unsigned int zT_661;
    unsigned int zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    unsigned int zT_668;
    unsigned char zT_670;
    unsigned int zT_671;
    zT_338B7C76_TypeRegistry* zT_675;
    zT_D155D06D_Type* zT_676;
    unsigned int zT_677;
    zT_D155D06D_Type zT_678;
    unsigned char zT_679;
    unsigned char zT_682;
    zT_33EF6BFB_TypeKind zT_683;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_688;
    zT_338B7C76_TypeRegistry* zT_689;
    unsigned int zT_690;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_691;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_695;
    zT_338B7C76_TypeRegistry* zT_697;
    unsigned int zT_698;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_699;
    unsigned char zT_702;
    zT_6B0A7D14_AstStore* zT_704;
    unsigned int zT_705;
    zT_6B0A7D14_AstStore* zT_707;
    unsigned int zT_708;
    unsigned int zT_712;
    zT_22A7C88B_AstNode zT_713;
    zT_8143F551_AstKind zT_714;
    zT_6B0A7D14_AstStore* zT_719;
    unsigned int zT_720;
    zT_6B0A7D14_AstStore* zT_722;
    unsigned int zT_723;
    unsigned int zT_727;
    unsigned int zT_728;
    zT_6B0A7D14_AstStore* zT_730;
    zT_35F68E39_anon_318182 zT_731;
    unsigned int* zT_732;
    unsigned int zT_733;
    unsigned int zT_734;
    int zT_736;
    unsigned int zT_737;
    unsigned int zT_739;
    zT_2DF01B61_FieldEntry* zT_741;
    unsigned int zT_742;
    unsigned char zT_743;
    zT_2DF01B61_FieldEntry zT_744;
    unsigned int zT_745;
    zT_2DF01B61_FieldEntry* zT_748;
    unsigned int zT_749;
    unsigned char zT_750;
    zT_2DF01B61_FieldEntry zT_751;
    unsigned int zT_752;
    zT_79FAE712_u64 zT_753;
    zT_79FAE712_u64 zT_755;
    unsigned int zT_757;
    zT_E276DDD0_PackedBitField* zT_759;
    unsigned int zT_760;
    unsigned char zT_761;
    zT_E276DDD0_PackedBitField zT_762;
    unsigned int zT_763;
    zT_79FAE712_u64 zT_764;
    unsigned int zT_765;
    zT_79FAE712_u64 zT_767;
    zT_79FAE712_u64 zT_768;
    unsigned char zT_770;
    unsigned int zT_771;
    zT_79FAE712_u64 zT_773;
    zT_79FAE712_u64 zT_774;
    unsigned int zT_775;
    unsigned char zT_777;
    zT_79FAE712_u64 zT_778;
    zT_0163D9A4_ComptimeInt zT_779;
    zT_7634F9B7_Opt_222 zT_780;
    int zT_781;
    unsigned int zT_782;
    unsigned int zT_783;
    unsigned int zT_784;
    unsigned char zT_786;
    zT_7634F9B7_Opt_222 zT_787;
    zT_7634F9B7_Opt_222 zT_788;
    zT_7634F9B7_Opt_222 zT_789;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    zig_poison_fill((void*)&zT_142, (unsigned int)sizeof zT_142);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_157, (unsigned int)sizeof zT_157);
    zig_poison_fill((void*)&zT_159, (unsigned int)sizeof zT_159);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_171, (unsigned int)sizeof zT_171);
    zig_poison_fill((void*)&zT_181, (unsigned int)sizeof zT_181);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_197, (unsigned int)sizeof zT_197);
    zig_poison_fill((void*)&zT_199, (unsigned int)sizeof zT_199);
    zig_poison_fill((void*)&zT_206, (unsigned int)sizeof zT_206);
    zig_poison_fill((void*)&zT_213, (unsigned int)sizeof zT_213);
    zig_poison_fill((void*)&zT_215, (unsigned int)sizeof zT_215);
    zig_poison_fill((void*)&zT_225, (unsigned int)sizeof zT_225);
    zig_poison_fill((void*)&zT_227, (unsigned int)sizeof zT_227);
    zig_poison_fill((void*)&zT_237, (unsigned int)sizeof zT_237);
    zig_poison_fill((void*)&zT_239, (unsigned int)sizeof zT_239);
    zig_poison_fill((void*)&zT_249, (unsigned int)sizeof zT_249);
    zig_poison_fill((void*)&zT_251, (unsigned int)sizeof zT_251);
    zig_poison_fill((void*)&zT_261, (unsigned int)sizeof zT_261);
    zig_poison_fill((void*)&zT_263, (unsigned int)sizeof zT_263);
    zig_poison_fill((void*)&zT_269, (unsigned int)sizeof zT_269);
    zig_poison_fill((void*)&zT_271, (unsigned int)sizeof zT_271);
    zig_poison_fill((void*)&zT_273, (unsigned int)sizeof zT_273);
    zig_poison_fill((void*)&zT_282, (unsigned int)sizeof zT_282);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zig_poison_fill((void*)&zT_295, (unsigned int)sizeof zT_295);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_325, (unsigned int)sizeof zT_325);
    zig_poison_fill((void*)&zT_339, (unsigned int)sizeof zT_339);
    zig_poison_fill((void*)&zT_348, (unsigned int)sizeof zT_348);
    zig_poison_fill((void*)&zT_355, (unsigned int)sizeof zT_355);
    zig_poison_fill((void*)&zT_360, (unsigned int)sizeof zT_360);
    zig_poison_fill((void*)&zT_367, (unsigned int)sizeof zT_367);
    zig_poison_fill((void*)&zT_369, (unsigned int)sizeof zT_369);
    zig_poison_fill((void*)&zT_380, (unsigned int)sizeof zT_380);
    zig_poison_fill((void*)&zT_394, (unsigned int)sizeof zT_394);
    zig_poison_fill((void*)&zT_407, (unsigned int)sizeof zT_407);
    zig_poison_fill((void*)&zT_416, (unsigned int)sizeof zT_416);
    zig_poison_fill((void*)&zT_425, (unsigned int)sizeof zT_425);
    zig_poison_fill((void*)&zT_434, (unsigned int)sizeof zT_434);
    zig_poison_fill((void*)&zT_443, (unsigned int)sizeof zT_443);
    zig_poison_fill((void*)&zT_452, (unsigned int)sizeof zT_452);
    zig_poison_fill((void*)&zT_461, (unsigned int)sizeof zT_461);
    zig_poison_fill((void*)&zT_466, (unsigned int)sizeof zT_466);
    zig_poison_fill((void*)&zT_483, (unsigned int)sizeof zT_483);
    zig_poison_fill((void*)&zT_489, (unsigned int)sizeof zT_489);
    zig_poison_fill((void*)&zT_501, (unsigned int)sizeof zT_501);
    zig_poison_fill((void*)&zT_507, (unsigned int)sizeof zT_507);
    zig_poison_fill((void*)&zT_514, (unsigned int)sizeof zT_514);
    zig_poison_fill((void*)&zT_516, (unsigned int)sizeof zT_516);
    zig_poison_fill((void*)&zT_536, (unsigned int)sizeof zT_536);
    zig_poison_fill((void*)&zT_542, (unsigned int)sizeof zT_542);
    zig_poison_fill((void*)&zT_563, (unsigned int)sizeof zT_563);
    zig_poison_fill((void*)&zT_571, (unsigned int)sizeof zT_571);
    zig_poison_fill((void*)&zT_586, (unsigned int)sizeof zT_586);
    zig_poison_fill((void*)&zT_593, (unsigned int)sizeof zT_593);
    zig_poison_fill((void*)&zT_605, (unsigned int)sizeof zT_605);
    zig_poison_fill((void*)&zT_609, (unsigned int)sizeof zT_609);
    zig_poison_fill((void*)&zT_621, (unsigned int)sizeof zT_621);
    zig_poison_fill((void*)&zT_622, (unsigned int)sizeof zT_622);
    zig_poison_fill((void*)&zT_642, (unsigned int)sizeof zT_642);
    zig_poison_fill((void*)&zT_646, (unsigned int)sizeof zT_646);
    zig_poison_fill((void*)&zT_648, (unsigned int)sizeof zT_648);
    zig_poison_fill((void*)&zT_665, (unsigned int)sizeof zT_665);
    zig_poison_fill((void*)&zT_671, (unsigned int)sizeof zT_671);
    zig_poison_fill((void*)&zT_702, (unsigned int)sizeof zT_702);
    zig_poison_fill((void*)&zT_712, (unsigned int)sizeof zT_712);
    zig_poison_fill((void*)&zT_713, (unsigned int)sizeof zT_713);
    zig_poison_fill((void*)&zT_727, (unsigned int)sizeof zT_727);
    zig_poison_fill((void*)&zT_728, (unsigned int)sizeof zT_728);
    zig_poison_fill((void*)&zT_779, (unsigned int)sizeof zT_779);
    zig_poison_fill((void*)&zT_787, (unsigned int)sizeof zT_787);
    zig_poison_fill((void*)&zT_788, (unsigned int)sizeof zT_788);
    zig_poison_fill((void*)&zT_789, (unsigned int)sizeof zT_789);
    zT_22A7C88B_AstNode node;
    zT_7634F9B7_Opt_222 inner;
    zT_0163D9A4_ComptimeInt iv;
    zT_0163D9A4_ComptimeInt nv;
    zT_7634F9B7_Opt_222 l_opt;
    zT_7634F9B7_Opt_222 r_opt;
    zT_0163D9A4_ComptimeInt lv;
    zT_0163D9A4_ComptimeInt rv;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    zT_77F031D4_Opt_960 c_sym;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int fa_mod_id;
    unsigned int fa_field_id;
    zT_3A105EF1_Symbol* fa_sym;
    zT_22A7C88B_AstNode fa_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    unsigned int size_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    unsigned int bitsz_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    unsigned int off_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int bitoff_id;
    unsigned int bc_n;
    unsigned int ct_tid;
    zT_7634F9B7_Opt_222 cv_opt;
    zT_0163D9A4_ComptimeInt cv;
    unsigned int bt_tid;
    zT_D155D06D_Type bt_ty;
    unsigned char bt_foldable;
    unsigned int bt_bits;
    unsigned int ot_tid;
    zT_D155D06D_Type ot_ty;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_19 = node.kind;
    zT_18 = zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = env->store;
    zT_25 = node_idx;
    zT_27 = zF_678B9A72_astStoreIntValue(zT_24, zT_25);
    zT_23 = zT_27;
    zT_28 = zF_1EAA44E6_ciFromU64(zT_23);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_9:
    zT_30 = node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = node.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_58 = node.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    zT_38 = env;
    zT_39 = node.child_0;
    zT_42 = 1;
    zT_43 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_40 = zT_43;
    zT_47 = zF_382591DE_evalConstIntFull(zT_38, zT_39, zT_40);
    inner = zT_47;
    zT_48 = inner.has_value;
    if (zT_48) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_57.has_value = 0;
    return zT_57;
    z_bb_14:
    if (!(inner.has_value)) { pal_trap(); }
    iv = inner.value;
    zT_51 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_51;
    zT_52 = iv;
    zT_53 = (zT_0163D9A4_ComptimeInt*)&nv;
    zT_55 = zF_EECBFD7D_ciNeg(zT_52, zT_53);
    (void)zT_55;
    zT_56.has_value = 1;
    zT_56.value = nv;
    return zT_56;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_62 = env;
    zT_65 = node.child_0;
    zT_66 = 1;
    zT_67 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    env = zT_62;
    node_idx = zT_65;
    depth = zT_67;
    goto z_bb_0;
    z_bb_17:
    zT_72 = node.kind;
    if ((unsigned char)(zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_77 = node.kind;
    zT_76 = zT_77 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_20;
    z_bb_19:
    zT_76 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_76) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_82 = node.kind;
    zT_81 = zT_82 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_23;
    z_bb_22:
    zT_81 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_81) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_87 = node.kind;
    zT_86 = zT_87 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_26;
    z_bb_25:
    zT_86 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_86) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_92 = node.kind;
    zT_91 = zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_29;
    z_bb_28:
    zT_91 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_91) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_97 = node.kind;
    zT_96 = zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_32;
    z_bb_31:
    zT_96 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_96) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_102 = node.kind;
    zT_101 = zT_102 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_35;
    z_bb_34:
    zT_101 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_101) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_107 = node.kind;
    zT_106 = zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_38;
    z_bb_37:
    zT_106 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_106) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_112 = node.kind;
    zT_111 = zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_41;
    z_bb_40:
    zT_111 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_111) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_117 = node.kind;
    zT_116 = zT_117 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_44;
    z_bb_43:
    zT_116 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_116) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_122 = env;
    zT_123 = node.child_0;
    zT_126 = 1;
    zT_127 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_126)), 32u);
    zT_128 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_126)), 32u);
    zT_130 = zT_128 == (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    zT_124 = zT_127;
    zT_131 = zF_382591DE_evalConstIntFull(zT_122, zT_123, zT_124);
    l_opt = zT_131;
    zT_133 = env;
    zT_134 = node.child_1;
    zT_137 = 1;
    zT_138 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_137)), 32u);
    zT_139 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_137)), 32u);
    zT_141 = zT_139 == (unsigned int)(0);
    if (!(zT_141)) { pal_trap(); }
    zT_135 = zT_138;
    zT_142 = zF_382591DE_evalConstIntFull(zT_133, zT_134, zT_135);
    r_opt = zT_142;
    zT_143 = l_opt.has_value;
    if (zT_143) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_274 = node.kind;
    if ((unsigned char)(zT_274 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_47:
    if (!(l_opt.has_value)) { pal_trap(); }
    lv = l_opt.value;
    zT_145 = r_opt.has_value;
    if (zT_145) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_273.has_value = 0;
    return zT_273;
    z_bb_49:
    if (!(r_opt.has_value)) { pal_trap(); }
    rv = r_opt.value;
    zT_148 = zF_DC9B7BC0_ciZeroInt();
    res = zT_148;
    zT_149 = node.kind;
    if ((unsigned char)(zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_153 = lv;
    zT_154 = rv;
    zT_155 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_157 = zF_8A5DB878_ciAdd(zT_153, zT_154, zT_155);
    if ((unsigned char)(!zT_157)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_161 = node.kind;
    if ((unsigned char)(zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_159.has_value = 0;
    return zT_159;
    z_bb_54:
    zT_160.has_value = 1;
    zT_160.value = res;
    return zT_160;
    z_bb_55:
    zT_165 = lv;
    zT_166 = rv;
    zT_167 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_169 = zF_539A2D81_ciSub(zT_165, zT_166, zT_167);
    if ((unsigned char)(!zT_169)) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_173 = node.kind;
    if ((unsigned char)(zT_173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_171.has_value = 0;
    return zT_171;
    z_bb_58:
    zT_172.has_value = 1;
    zT_172.value = res;
    return zT_172;
    z_bb_59:
    zT_177 = lv;
    zT_178 = rv;
    zT_179 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_181 = zF_A3E385DD_ciMul(zT_177, zT_178, zT_179);
    if ((unsigned char)(!zT_181)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_185 = node.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_183.has_value = 0;
    return zT_183;
    z_bb_62:
    zT_184.has_value = 1;
    zT_184.value = res;
    return zT_184;
    z_bb_63:
    zT_190 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_190;
    zT_191 = lv;
    zT_192 = rv;
    zT_193 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_194 = (zT_0163D9A4_ComptimeInt*)&rem;
    zT_197 = zF_25A0EEC0_ciDivMod(zT_191, zT_192, zT_193, zT_194);
    if ((unsigned char)(!zT_197)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_201 = node.kind;
    if ((unsigned char)(zT_201 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_199.has_value = 0;
    return zT_199;
    z_bb_66:
    zT_200.has_value = 1;
    zT_200.value = res;
    return zT_200;
    z_bb_67:
    zT_206 = zF_DC9B7BC0_ciZeroInt();
    q = zT_206;
    zT_207 = lv;
    zT_208 = rv;
    zT_209 = (zT_0163D9A4_ComptimeInt*)&q;
    zT_210 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_213 = zF_25A0EEC0_ciDivMod(zT_207, zT_208, zT_209, zT_210);
    if ((unsigned char)(!zT_213)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_217 = node.kind;
    if ((unsigned char)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    zT_215.has_value = 0;
    return zT_215;
    z_bb_70:
    zT_216.has_value = 1;
    zT_216.value = res;
    return zT_216;
    z_bb_71:
    zT_221 = lv;
    zT_222 = rv;
    zT_223 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_225 = zF_E15DE14D_ciBitAnd(zT_221, zT_222, zT_223);
    if ((unsigned char)(!zT_225)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_229 = node.kind;
    if ((unsigned char)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    zT_227.has_value = 0;
    return zT_227;
    z_bb_74:
    zT_228.has_value = 1;
    zT_228.value = res;
    return zT_228;
    z_bb_75:
    zT_233 = lv;
    zT_234 = rv;
    zT_235 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_237 = zF_93823331_ciBitOr(zT_233, zT_234, zT_235);
    if ((unsigned char)(!zT_237)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_241 = node.kind;
    if ((unsigned char)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_239.has_value = 0;
    return zT_239;
    z_bb_78:
    zT_240.has_value = 1;
    zT_240.value = res;
    return zT_240;
    z_bb_79:
    zT_245 = lv;
    zT_246 = rv;
    zT_247 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_249 = zF_C592CA21_ciBitXor(zT_245, zT_246, zT_247);
    if ((unsigned char)(!zT_249)) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_253 = node.kind;
    if ((unsigned char)(zT_253 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    zT_251.has_value = 0;
    return zT_251;
    z_bb_82:
    zT_252.has_value = 1;
    zT_252.value = res;
    return zT_252;
    z_bb_83:
    zT_257 = lv;
    zT_258 = rv;
    zT_259 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_261 = zF_4FDD0D22_ciShl(zT_257, zT_258, zT_259);
    if ((unsigned char)(!zT_261)) goto z_bb_85; else goto z_bb_86;
    z_bb_84:
    zT_265 = lv;
    zT_266 = rv;
    zT_267 = (zT_0163D9A4_ComptimeInt*)&res;
    zT_269 = zF_41DCF718_ciShr(zT_265, zT_266, zT_267);
    if ((unsigned char)(!zT_269)) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    zT_263.has_value = 0;
    return zT_263;
    z_bb_86:
    zT_264.has_value = 1;
    zT_264.value = res;
    return zT_264;
    z_bb_87:
    zT_271.has_value = 0;
    return zT_271;
    z_bb_88:
    zT_272.has_value = 1;
    zT_272.value = res;
    return zT_272;
    z_bb_89:
    zT_279 = env->store;
    zT_280 = node_idx;
    zT_282 = zF_53458827_astStoreIdentifier(zT_279, zT_280);
    name_id = zT_282;
    zT_283 = env->local_consts;
    zT_284 = zT_283.has_value;
    if (zT_284) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    zT_340 = node.kind;
    if ((unsigned char)(zT_340 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_103; else goto z_bb_104;
    z_bb_91:
    if (!(zT_283.has_value)) { pal_trap(); }
    lcs = zT_283.value;
    zT_286 = lcs;
    zT_287 = name_id;
    zT_288 = zF_6532C387_localConstScopeLook(zT_286, zT_287);
    zT_289 = zT_288.has_value;
    if (zT_289) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_310 = env;
    zT_311 = name_id;
    zT_312 = zF_04FED007_symbolLookupAllModu(zT_310, zT_311);
    c_sym = zT_312;
    zT_313 = c_sym.has_value;
    if (zT_313) goto z_bb_97; else goto z_bb_98;
    z_bb_93:
    if (!(zT_288.has_value)) { pal_trap(); }
    l_decl_node = zT_288.value;
    zT_292 = env->store;
    zT_293 = l_decl_node;
    zT_295 = zF_FCDD1D35_astStoreNodeAt(zT_292, zT_293);
    l_decl = zT_295;
    zT_296 = l_decl.child_1;
    if ((unsigned char)(zT_296 != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_299 = env;
    zT_302 = l_decl.child_1;
    zT_303 = 1;
    zT_304 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_303)), 32u);
    zT_305 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_303)), 32u);
    zT_307 = zT_305 == (unsigned int)(0);
    if (!(zT_307)) { pal_trap(); }
    env = zT_299;
    node_idx = zT_302;
    depth = zT_304;
    goto z_bb_0;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    if (!(c_sym.has_value)) { pal_trap(); }
    cs = c_sym.value;
    zT_315 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_315 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_339.has_value = 0;
    return zT_339;
    z_bb_99:
    zT_321 = env->store;
    zT_322 = cs->decl_node;
    zT_325 = zF_FCDD1D35_astStoreNodeAt(zT_321, zT_322);
    c_decl = zT_325;
    zT_326 = c_decl.child_1;
    if ((unsigned char)(zT_326 != (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_329 = env;
    zT_332 = c_decl.child_1;
    zT_333 = 1;
    zT_334 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_333)), 32u);
    zT_335 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_333)), 32u);
    zT_337 = zT_335 == (unsigned int)(0);
    if (!(zT_337)) { pal_trap(); }
    env = zT_329;
    node_idx = zT_332;
    depth = zT_334;
    goto z_bb_0;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_345 = env;
    zT_346 = node.child_0;
    zT_348 = zF_0E4084E4_evalConstModuleOfEx(zT_345, zT_346);
    fa_mod_id = zT_348;
    if ((unsigned char)(fa_mod_id != (unsigned int)(0))) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_395 = node.kind;
    if ((unsigned char)(zT_395 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_115; else goto z_bb_116;
    z_bb_105:
    zT_352 = env->store;
    zT_353 = node_idx;
    zT_355 = zF_8BA26B9E_astStoreNodePayload(zT_352, zT_353);
    fa_field_id = zT_355;
    zT_356 = env->symbol_reg;
    zT_357 = fa_mod_id;
    zT_358 = fa_field_id;
    zT_360 = zF_A398987E_symbolRegistryQuali(zT_356, zT_357, zT_358);
    zT_361 = zT_360.has_value;
    if (zT_361) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_394.has_value = 0;
    return zT_394;
    z_bb_107:
    if (!(zT_360.has_value)) { pal_trap(); }
    fa_sym = zT_360.value;
    zT_363 = env;
    zT_364 = node_idx;
    zT_365 = fa_field_id;
    zT_366 = fa_sym;
    zT_367 = zF_D43B245F_typeResolverCheckMe(zT_363, zT_364, zT_365, zT_366);
    if ((unsigned char)(!zT_367)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_369.has_value = 0;
    return zT_369;
    z_bb_110:
    zT_370 = fa_sym->flags;
    if ((unsigned char)((unsigned short)(zT_370 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_376 = env->store;
    zT_377 = fa_sym->decl_node;
    zT_380 = zF_FCDD1D35_astStoreNodeAt(zT_376, zT_377);
    fa_decl = zT_380;
    zT_381 = fa_decl.child_1;
    if ((unsigned char)(zT_381 != (unsigned int)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_108;
    z_bb_113:
    zT_384 = env;
    zT_387 = fa_decl.child_1;
    zT_388 = 1;
    zT_389 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_388)), 32u);
    zT_390 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_388)), 32u);
    zT_392 = zT_390 == (unsigned int)(0);
    if (!(zT_392)) { pal_trap(); }
    env = zT_384;
    node_idx = zT_387;
    depth = zT_389;
    goto z_bb_0;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_400 = "@sizeOf";
    zT_402 = 7;
    zT_401.ptr = (unsigned char*)zT_400;
    zT_401.len = zT_402;
    s_size = zT_401;
    zT_404 = env->interner;
    zT_405 = s_size;
    zT_407 = zF_50C274AF_stringInternerInter(zT_404, zT_405);
    size_id = zT_407;
    zT_409 = "@alignOf";
    zT_411 = 8;
    zT_410.ptr = (unsigned char*)zT_409;
    zT_410.len = zT_411;
    s_align = zT_410;
    zT_413 = env->interner;
    zT_414 = s_align;
    zT_416 = zF_50C274AF_stringInternerInter(zT_413, zT_414);
    align_id = zT_416;
    zT_418 = "@bitSizeOf";
    zT_420 = 10;
    zT_419.ptr = (unsigned char*)zT_418;
    zT_419.len = zT_420;
    s_bitsz = zT_419;
    zT_422 = env->interner;
    zT_423 = s_bitsz;
    zT_425 = zF_50C274AF_stringInternerInter(zT_422, zT_423);
    bitsz_id = zT_425;
    zT_427 = "@intCast";
    zT_429 = 8;
    zT_428.ptr = (unsigned char*)zT_427;
    zT_428.len = zT_429;
    s_intc = zT_428;
    zT_431 = env->interner;
    zT_432 = s_intc;
    zT_434 = zF_50C274AF_stringInternerInter(zT_431, zT_432);
    intc_id = zT_434;
    zT_436 = "@as";
    zT_438 = 3;
    zT_437.ptr = (unsigned char*)zT_436;
    zT_437.len = zT_438;
    s_as = zT_437;
    zT_440 = env->interner;
    zT_441 = s_as;
    zT_443 = zF_50C274AF_stringInternerInter(zT_440, zT_441);
    as_id = zT_443;
    zT_445 = "@offsetOf";
    zT_447 = 9;
    zT_446.ptr = (unsigned char*)zT_445;
    zT_446.len = zT_447;
    s_off = zT_446;
    zT_449 = env->interner;
    zT_450 = s_off;
    zT_452 = zF_50C274AF_stringInternerInter(zT_449, zT_450);
    off_id = zT_452;
    zT_454 = "@bitOffsetOf";
    zT_456 = 12;
    zT_455.ptr = (unsigned char*)zT_454;
    zT_455.len = zT_456;
    s_bitoff = zT_455;
    zT_458 = env->interner;
    zT_459 = s_bitoff;
    zT_461 = zF_50C274AF_stringInternerInter(zT_458, zT_459);
    bitoff_id = zT_461;
    zT_463 = env->store;
    zT_464 = node_idx;
    zT_466 = zF_152E19CB_astStoreNodeExtraCh(zT_463, zT_464);
    bc_n = zT_466;
    zT_467 = node.child_0;
    if ((unsigned char)(zT_467 == intc_id)) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_789.has_value = 0;
    return zT_789;
    z_bb_117:
    zT_470 = node.child_0;
    zT_469 = zT_470 == as_id;
    goto z_bb_119;
    z_bb_118:
    zT_469 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_469) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_517 = node.child_0;
    if ((unsigned char)(zT_517 == size_id)) goto z_bb_131; else goto z_bb_130;
    z_bb_122:
    zT_475 = env;
    zT_478 = env->store;
    zT_479 = node_idx;
    zT_483 = zF_B10B1BC1_astStoreNodeExtraCh(zT_478, zT_479, (unsigned int)(0));
    zT_476 = zT_483;
    zT_484 = 1;
    zT_485 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_484)), 32u);
    zT_486 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_484)), 32u);
    zT_488 = zT_486 == (unsigned int)(0);
    if (!(zT_488)) { pal_trap(); }
    zT_477 = zT_485;
    zT_489 = zF_F2107C15_resolveTypeExprFull(zT_475, zT_476, zT_477);
    ct_tid = zT_489;
    if ((unsigned char)(ct_tid != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    zT_516.has_value = 0;
    return zT_516;
    z_bb_124:
    zT_493 = env;
    zT_496 = env->store;
    zT_497 = node_idx;
    zT_501 = zF_B10B1BC1_astStoreNodeExtraCh(zT_496, zT_497, (unsigned int)(1));
    zT_494 = zT_501;
    zT_502 = 1;
    zT_503 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_502)), 32u);
    zT_504 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_502)), 32u);
    zT_506 = zT_504 == (unsigned int)(0);
    if (!(zT_506)) { pal_trap(); }
    zT_495 = zT_503;
    zT_507 = zF_382591DE_evalConstIntFull(zT_493, zT_494, zT_495);
    cv_opt = zT_507;
    zT_508 = cv_opt.has_value;
    if (zT_508) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    goto z_bb_123;
    z_bb_126:
    if (!(cv_opt.has_value)) { pal_trap(); }
    cv = cv_opt.value;
    zT_510 = env->typereg;
    zT_511 = cv;
    zT_512 = ct_tid;
    zT_514 = zF_B28C4720_comptimeIntFitsType(zT_510, zT_511, zT_512);
    if (zT_514) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_515.has_value = 1;
    zT_515.value = cv;
    return zT_515;
    z_bb_129:
    goto z_bb_127;
    z_bb_130:
    zT_520 = node.child_0;
    zT_519 = zT_520 == align_id;
    goto z_bb_132;
    z_bb_131:
    zT_519 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_519) goto z_bb_134; else goto z_bb_133;
    z_bb_133:
    zT_523 = node.child_0;
    zT_522 = zT_523 == bitsz_id;
    goto z_bb_135;
    z_bb_134:
    zT_522 = 1;
    goto z_bb_135;
    z_bb_135:
    if (zT_522) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    if ((unsigned char)(bc_n >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_137:
    zT_649 = node.child_0;
    if ((unsigned char)(zT_649 == off_id)) goto z_bb_170; else goto z_bb_169;
    z_bb_138:
    zT_528 = env;
    zT_531 = env->store;
    zT_532 = node_idx;
    zT_536 = zF_B10B1BC1_astStoreNodeExtraCh(zT_531, zT_532, (unsigned int)(0));
    zT_529 = zT_536;
    zT_537 = 1;
    zT_538 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_537)), 32u);
    zT_539 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_537)), 32u);
    zT_541 = zT_539 == (unsigned int)(0);
    if (!(zT_541)) { pal_trap(); }
    zT_530 = zT_538;
    zT_542 = zF_F2107C15_resolveTypeExprFull(zT_528, zT_529, zT_530);
    bt_tid = zT_542;
    if ((unsigned char)(bt_tid != (unsigned int)(18))) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_648.has_value = 0;
    return zT_648;
    z_bb_140:
    zT_546 = env->typereg;
    zT_547 = zT_546->types_items;
    zT_548 = (unsigned int)bt_tid;
    zT_549 = zT_547[zT_548];
    bt_ty = zT_549;
    zT_550 = bt_ty.state;
    if ((unsigned char)(zT_550 != (unsigned char)(2))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_554 = bt_ty.kind;
    zT_553 = zT_554 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_144;
    z_bb_143:
    zT_553 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_553) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_558 = env->typereg;
    zT_559 = bt_tid;
    zT_563 = zF_3E55D0D5_layoutEnsure(zT_558, zT_559, (unsigned int)(0));
    (void)zT_563;
    zT_564 = env->typereg;
    zT_565 = zT_564->types_items;
    zT_566 = (unsigned int)bt_tid;
    zT_567 = zT_565[zT_566];
    bt_ty = zT_567;
    goto z_bb_146;
    z_bb_146:
    zT_569 = bt_ty.kind;
    zT_571 = zF_6AE4DFFC_evalConstScalarKind(zT_569);
    bt_foldable = zT_571;
    zT_572 = bt_ty.kind;
    if ((unsigned char)(zT_572 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_576 = 1;
    bt_foldable = zT_576;
    goto z_bb_148;
    z_bb_148:
    zT_577 = bt_ty.state;
    if ((unsigned char)(zT_577 == (unsigned char)(2))) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_580 = bt_foldable;
    goto z_bb_151;
    z_bb_150:
    zT_580 = 0;
    goto z_bb_151;
    z_bb_151:
    if (zT_580) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_581 = node.child_0;
    if ((unsigned char)(zT_581 == size_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_141;
    z_bb_154:
    zT_584 = bt_ty.size;
    zT_586 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_584));
    zT_587.has_value = 1;
    zT_587.value = zT_586;
    return zT_587;
    z_bb_155:
    zT_588 = node.child_0;
    if ((unsigned char)(zT_588 == align_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_591 = bt_ty.alignment;
    zT_593 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_591));
    zT_594.has_value = 1;
    zT_594.value = zT_593;
    return zT_594;
    z_bb_157:
    zT_596 = bt_ty.size;
    zT_597 = 8;
    zT_598 = zig_wrap_mul_u(((zu64)(zT_596)), ((zu64)(zT_597)), 32u);
    zT_599 = zig_overflow_flag_mul_u(((zu64)(zT_596)), ((zu64)(zT_597)), 32u);
    zT_601 = zT_599 == (unsigned int)(0);
    if (!(zT_601)) { pal_trap(); }
    bt_bits = zT_598;
    zT_602 = env->typereg;
    zT_603 = bt_tid;
    zT_605 = zF_3290E9C4_typeRegistryIsInteg(zT_602, zT_603);
    if (zT_605) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_606 = env->typereg;
    zT_607 = bt_tid;
    zT_609 = zF_655972D5_typeRegistryIntWidt(zT_606, zT_607);
    zT_610 = (unsigned int)zT_609;
    bt_bits = zT_610;
    goto z_bb_159;
    z_bb_159:
    zT_611 = bt_ty.kind;
    if ((unsigned char)(zT_611 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_615 = env->typereg;
    zT_618 = env->typereg;
    zT_619 = bt_tid;
    zT_621 = zF_014D7530_typeRegistryEnumBac(zT_618, zT_619);
    zT_616 = zT_621;
    zT_622 = zF_655972D5_typeRegistryIntWidt(zT_615, zT_616);
    zT_623 = (unsigned int)zT_622;
    bt_bits = zT_623;
    goto z_bb_161;
    z_bb_161:
    zT_624 = bt_ty.kind;
    if ((unsigned char)(zT_624 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_628 = 1;
    bt_bits = zT_628;
    goto z_bb_163;
    z_bb_163:
    zT_629 = bt_ty.kind;
    if ((unsigned char)(zT_629 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_634 = bt_ty.flags;
    zT_633 = (unsigned char)(zT_634 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_166;
    z_bb_165:
    zT_633 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_633) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_639 = env->typereg;
    zT_640 = bt_tid;
    zT_642 = zF_CB27DBA4_typeRegistryGetPack(zT_639, zT_640);
    zT_643 = (unsigned int)zT_642;
    bt_bits = zT_643;
    goto z_bb_168;
    z_bb_168:
    zT_646 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)bt_bits));
    zT_647.has_value = 1;
    zT_647.value = zT_646;
    return zT_647;
    z_bb_169:
    zT_652 = node.child_0;
    zT_651 = zT_652 == bitoff_id;
    goto z_bb_171;
    z_bb_170:
    zT_651 = 1;
    goto z_bb_171;
    z_bb_171:
    if (zT_651) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_174; else goto z_bb_175;
    z_bb_173:
    zT_788.has_value = 0;
    return zT_788;
    z_bb_174:
    zT_657 = env;
    zT_660 = env->store;
    zT_661 = node_idx;
    zT_665 = zF_B10B1BC1_astStoreNodeExtraCh(zT_660, zT_661, (unsigned int)(0));
    zT_658 = zT_665;
    zT_666 = 1;
    zT_667 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_666)), 32u);
    zT_668 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_666)), 32u);
    zT_670 = zT_668 == (unsigned int)(0);
    if (!(zT_670)) { pal_trap(); }
    zT_659 = zT_667;
    zT_671 = zF_F2107C15_resolveTypeExprFull(zT_657, zT_658, zT_659);
    ot_tid = zT_671;
    if ((unsigned char)(ot_tid != (unsigned int)(18))) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    zT_787.has_value = 0;
    return zT_787;
    z_bb_176:
    zT_675 = env->typereg;
    zT_676 = zT_675->types_items;
    zT_677 = (unsigned int)ot_tid;
    zT_678 = zT_676[zT_677];
    ot_ty = zT_678;
    zT_679 = ot_ty.state;
    if ((unsigned char)(zT_679 == (unsigned char)(2))) goto z_bb_178; else goto z_bb_179;
    z_bb_177:
    goto z_bb_175;
    z_bb_178:
    zT_683 = ot_ty.kind;
    zT_682 = zT_683 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_180;
    z_bb_179:
    zT_682 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_682) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    zig_poison_fill((void*)&zT_688, (unsigned int)sizeof zT_688);
    fields = zT_688;
    zT_689 = env->typereg;
    zT_690 = ot_tid;
    zT_691 = (zT_BF2E90D8_Slice_zT_2DF01B61_F*)&fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_689, zT_690, zT_691);
    zig_poison_fill((void*)&zT_695, (unsigned int)sizeof zT_695);
    packed_fields = zT_695;
    zT_697 = env->typereg;
    zT_698 = ot_tid;
    zT_699 = (zT_BCF34E4D_Slice_zT_E276DDD0_P*)&packed_fields;
    zT_702 = zF_7D87247C_typeRegistryGetPack(zT_697, zT_698, zT_699);
    has_pk = zT_702;
    zT_704 = env->store;
    zT_707 = env->store;
    zT_708 = node_idx;
    zT_712 = zF_B10B1BC1_astStoreNodeExtraCh(zT_707, zT_708, (unsigned int)(1));
    zT_705 = zT_712;
    zT_713 = zF_FCDD1D35_astStoreNodeAt(zT_704, zT_705);
    fname_node = zT_713;
    zT_714 = fname_node.kind;
    if ((unsigned char)(zT_714 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    goto z_bb_177;
    z_bb_183:
    zT_719 = env->store;
    zT_722 = env->store;
    zT_723 = node_idx;
    zT_727 = zF_B10B1BC1_astStoreNodeExtraCh(zT_722, zT_723, (unsigned int)(1));
    zT_720 = zT_727;
    zT_728 = zF_8BA26B9E_astStoreNodePayload(zT_719, zT_720);
    sv_idx = zT_728;
    zT_730 = env->store;
    zT_731 = zT_730->string_values;
    zT_732 = zT_731.items;
    zT_733 = (unsigned int)sv_idx;
    zT_734 = zT_732[zT_733];
    want_id = zT_734;
    zT_736 = 0;
    zT_737 = (unsigned int)zT_736;
    fi = zT_737;
    goto z_bb_185;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_739 = fields.len;
    if ((unsigned char)(fi < zT_739)) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_741 = fields.ptr;
    zT_742 = fields.len;
    zT_743 = fi < zT_742;
    if (!(zT_743)) { pal_trap(); }
    zT_744 = zT_741[fi];
    zT_745 = zT_744.name_id;
    if ((unsigned char)(zT_745 == want_id)) goto z_bb_189; else goto z_bb_190;
    z_bb_187:
    goto z_bb_184;
    z_bb_188:
    zT_781 = 1;
    zT_782 = (unsigned int)zT_781;
    zT_783 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_782)), 32u);
    zT_784 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_782)), 32u);
    zT_786 = zT_784 == (unsigned int)(0);
    if (!(zT_786)) { pal_trap(); }
    fi = zT_783;
    goto z_bb_185;
    z_bb_189:
    zT_748 = fields.ptr;
    zT_749 = fields.len;
    zT_750 = fi < zT_749;
    if (!(zT_750)) { pal_trap(); }
    zT_751 = zT_748[fi];
    zT_752 = zT_751.offset;
    zT_753 = (zT_79FAE712_u64)zT_752;
    bo = zT_753;
    if (has_pk) goto z_bb_191; else goto z_bb_193;
    z_bb_190:
    goto z_bb_188;
    z_bb_191:
    zT_755 = 0;
    pk_bo = zT_755;
    zT_757 = packed_fields.len;
    if ((unsigned char)(fi < zT_757)) goto z_bb_194; else goto z_bb_195;
    z_bb_192:
    zT_778 = bo;
    zT_779 = zF_1EAA44E6_ciFromU64(zT_778);
    zT_780.has_value = 1;
    zT_780.value = zT_779;
    return zT_780;
    z_bb_193:
    zT_771 = node.child_0;
    if ((unsigned char)(zT_771 == bitoff_id)) goto z_bb_199; else goto z_bb_200;
    z_bb_194:
    zT_759 = packed_fields.ptr;
    zT_760 = packed_fields.len;
    zT_761 = fi < zT_760;
    if (!(zT_761)) { pal_trap(); }
    zT_762 = zT_759[fi];
    zT_763 = zT_762.bit_offset;
    zT_764 = (zT_79FAE712_u64)zT_763;
    pk_bo = zT_764;
    goto z_bb_195;
    z_bb_195:
    zT_765 = node.child_0;
    if ((unsigned char)(zT_765 == bitoff_id)) goto z_bb_196; else goto z_bb_198;
    z_bb_196:
    bo = pk_bo;
    goto z_bb_197;
    z_bb_197:
    goto z_bb_192;
    z_bb_198:
    zT_767 = 8;
    zT_770 = zT_767 != (unsigned int)(0);
    if (!(zT_770)) { pal_trap(); }
    zT_768 = pk_bo / zT_767;
    bo = zT_768;
    goto z_bb_197;
    z_bb_199:
    zT_773 = 8;
    zT_774 = zig_wrap_mul_u(((zu64)(bo)), ((zu64)(zT_773)), 64u);
    zT_775 = zig_overflow_flag_mul_u(((zu64)(bo)), ((zu64)(zT_773)), 64u);
    zT_777 = zT_775 == (unsigned int)(0);
    if (!(zT_777)) { pal_trap(); }
    bo = zT_774;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_192;
}

/* evalConstIntToSize */
unsigned int zF_5C9D5CFF_evalConstIntToSize(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt zT_8;
    int zT_9;
    int zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_79FAE712_u64 zT_14;
    unsigned int zT_15;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zT_0163D9A4_ComptimeInt lim;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(4294967294u));
    lim = zT_6;
    zT_7 = v;
    zT_8 = lim;
    zT_9 = zF_6408F093_ciCmp(zT_7, zT_8);
    zT_10 = 0;
    if ((unsigned char)(zT_9 > zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_13 = v;
    zT_14 = zF_4F2C9C5D_ciToU64(zT_13);
    zT_15 = (unsigned int)zig_cast_checked_u((zu64)zT_14, 64u, 0u, 32u);
    return zT_15;
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_8143F551_AstKind zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_ABC1EBBE_TypeResolveEnv* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    zT_ABC1EBBE_TypeResolveEnv* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    zT_7634F9B7_Opt_222 zT_67;
    unsigned char zT_70;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_0163D9A4_ComptimeInt zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    zT_622E1E76_Opt_254 zT_78;
    unsigned char zT_79;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    unsigned int zT_82;
    unsigned char zT_83;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_F85C5DED_DiagnosticCollector* zT_88;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned char zT_105;
    unsigned int zT_106;
    zT_0163D9A4_ComptimeInt zT_108;
    unsigned int zT_109;
    zT_ABC1EBBE_TypeResolveEnv* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_7634F9B7_Opt_222 zT_115;
    unsigned char zT_116;
    zT_0163D9A4_ComptimeInt zT_117;
    zT_0163D9A4_ComptimeInt zT_119;
    zT_0163D9A4_ComptimeInt zT_120;
    unsigned int zT_121;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_0163D9A4_ComptimeInt v;
    unsigned int bc_n;
    unsigned int ic_tid;
    zT_7634F9B7_Opt_222 ic_v;
    zT_0163D9A4_ComptimeInt iv;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "@intCast";
    zT_21 = 8;
    zT_20.ptr = (unsigned char*)zT_19;
    zT_20.len = zT_21;
    s_intc = zT_20;
    zT_23 = env->interner;
    zT_24 = s_intc;
    zT_26 = zF_50C274AF_stringInternerInter(zT_23, zT_24);
    intc_id = zT_26;
    zT_27 = node.child_0;
    if ((unsigned char)(zT_27 == intc_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_112 = env;
    zT_113 = node_idx;
    zT_114 = depth;
    zT_115 = zF_382591DE_evalConstIntFull(zT_112, zT_113, zT_114);
    zT_116 = zT_115.has_value;
    if (zT_116) goto z_bb_22; else goto z_bb_21;
    z_bb_7:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_152E19CB_astStoreNodeExtraCh(zT_30, zT_31);
    bc_n = zT_33;
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_37 = env;
    zT_40 = env->store;
    zT_41 = node_idx;
    zT_45 = zF_B10B1BC1_astStoreNodeExtraCh(zT_40, zT_41, (unsigned int)(0));
    zT_38 = zT_45;
    zT_46 = 1;
    zT_47 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_39 = zT_47;
    zT_51 = zF_F2107C15_resolveTypeExprFull(zT_37, zT_38, zT_39);
    ic_tid = zT_51;
    zT_53 = env;
    zT_56 = env->store;
    zT_57 = node_idx;
    zT_61 = zF_B10B1BC1_astStoreNodeExtraCh(zT_56, zT_57, (unsigned int)(1));
    zT_54 = zT_61;
    zT_62 = 1;
    zT_63 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    zT_55 = zT_63;
    zT_67 = zF_382591DE_evalConstIntFull(zT_53, zT_54, zT_55);
    ic_v = zT_67;
    if ((unsigned char)(ic_tid != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_70 = ic_v.has_value;
    if (zT_70) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if (!(ic_v.has_value)) { pal_trap(); }
    iv = ic_v.value;
    zT_72 = env->typereg;
    zT_73 = iv;
    zT_74 = ic_tid;
    zT_76 = zF_B28C4720_comptimeIntFitsType(zT_72, zT_73, zT_74);
    if ((unsigned char)(!zT_76)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_78 = env->diag;
    zT_79 = zT_78.has_value;
    if (zT_79) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_108 = iv;
    zT_109 = zF_5C9D5CFF_evalConstIntToSize(zT_108);
    return zT_109;
    z_bb_17:
    if (!(zT_78.has_value)) { pal_trap(); }
    dg = zT_78.value;
    zT_81 = dg;
    zT_82 = node_idx;
    zT_83 = zF_4DD9DB2D_diagnosticCollector(zT_81, zT_82);
    if (zT_83) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned int)(4294967295u);
    z_bb_19:
    zT_85 = "@intCast value does not fit the target type";
    zT_87 = 43;
    zT_86.ptr = (unsigned char*)zT_85;
    zT_86.len = zT_87;
    ic_msg = zT_86;
    zT_88 = dg;
    zT_91 = env->source_file_id;
    zT_92 = node.span_start;
    zT_99 = node.span_start;
    zT_100 = node.span_len;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zig_wrap_add_u(((zu64)(zT_99)), ((zu64)(zT_101)), 32u);
    zT_103 = zig_overflow_flag_add_u(((zu64)(zT_99)), ((zu64)(zT_101)), 32u);
    zT_105 = zT_103 == (unsigned int)(0);
    if (!(zT_105)) { pal_trap(); }
    zT_93 = zT_102;
    zT_94 = ic_msg;
    zT_106 = zF_C82559AC_diagnosticCollector(zT_88, (unsigned char)(0), (unsigned short)(3000), zT_91, zT_92, zT_93, zT_94);
    (void)zT_106;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    return (unsigned int)(4294967295u);
    z_bb_22:
    if (!(zT_115.has_value)) { pal_trap(); }
    zT_119 = zT_115.value;
    zT_117 = zT_119;
    goto z_bb_23;
    z_bb_23:
    v = zT_117;
    zT_120 = v;
    zT_121 = zF_5C9D5CFF_evalConstIntToSize(zT_120);
    return zT_121;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_ABC1EBBE_TypeResolveEnv* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_7634F9B7_Opt_222 zT_7;
    unsigned char zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_44E16D78_Opt_7 zT_10;
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt zT_12;
    unsigned char zT_13;
    zT_44E16D78_Opt_7 zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_79FAE712_u64 zT_17;
    zT_C69B2266_i64 zT_18;
    zT_44E16D78_Opt_7 zT_19;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_0163D9A4_ComptimeInt v;
    zT_4 = env;
    zT_5 = node_idx;
    zT_6 = depth;
    zT_7 = zF_382591DE_evalConstIntFull(zT_4, zT_5, zT_6);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_2:
    if (!(zT_7.has_value)) { pal_trap(); }
    zT_11 = zT_7.value;
    zT_9 = zT_11;
    goto z_bb_3;
    z_bb_3:
    v = zT_9;
    zT_12 = v;
    zT_13 = zF_EF3A264A_comptimeIntFits64(zT_12);
    if ((unsigned char)(!zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_5:
    zT_16 = v;
    zT_17 = zF_4F2C9C5D_ciToU64(zT_16);
    zT_18 = (zT_C69B2266_i64)zT_17;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
}

/* symbolLookupAllModules */
zT_77F031D4_Opt_960 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_77F031D4_Opt_960 zT_15;
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    zT_77F031D4_Opt_960 zT_23;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    unsigned int si;
    zT_77F031D4_Opt_960 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_4:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* symbolTypeIdOfModule */
unsigned int zF_66C54985_symbolTypeIdOfModul(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int module_id, unsigned int name_id) {
    zT_3D7259E2_SymbolRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_77F031D4_Opt_960 zT_7;
    unsigned char zT_8;
    unsigned int zT_10;
    unsigned int zT_13;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_3A105EF1_Symbol* s;
    zT_3 = env->symbol_reg;
    zT_4 = module_id;
    zT_5 = name_id;
    zT_7 = zF_A398987E_symbolRegistryQuali(zT_3, zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_7.has_value)) { pal_trap(); }
    s = zT_7.value;
    zT_10 = s->type_id;
    if ((unsigned char)(zT_10 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return (unsigned int)(0);
    z_bb_3:
    zT_13 = s->type_id;
    return zT_13;
    z_bb_4:
    goto z_bb_2;
}

/* symbolLookupTypeAllModules */
unsigned int zF_DE1472AF_symbolLookupTypeAll(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_ABC1EBBE_TypeResolveEnv* zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    unsigned int si;
    unsigned int t;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env;
    zT_12 = name_id;
    zT_14 = zF_66C54985_symbolTypeIdOfModul(zT_10, (unsigned int)((unsigned int)si), zT_12);
    t = zT_14;
    if ((unsigned char)(t != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return t;
    z_bb_6:
    goto z_bb_4;
}

/* enumMembersResolve */
unsigned char zF_0FFDEDBD_enumMembersResolve(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node, unsigned char append, unsigned int mstart, unsigned char strict, unsigned char check_only, unsigned int* out_count, unsigned int* out_fail_node, unsigned int* out_fail_kind) {
    zT_29C26066_Arr_zT_C69B2266_i64 zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    zT_C69B2266_i64 zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_35;
    zT_8143F551_AstKind zT_36;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv* zT_45;
    unsigned int zT_46;
    zT_44E16D78_Opt_7 zT_50;
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned char zT_57;
    unsigned int zT_60;
    int zT_62;
    unsigned int zT_63;
    zT_C69B2266_i64 zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_C69B2266_i64 zT_70;
    zT_338B7C76_TypeRegistry* zT_71;
    zT_D96DCDF2_EnumMember* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    zT_D96DCDF2_EnumMember zT_79;
    zT_C69B2266_i64 zT_80;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned int zT_98;
    unsigned char zT_100;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_D96DCDF2_EnumMember zT_102;
    zT_D96DCDF2_EnumMember zT_104;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_D96DCDF2_EnumMember* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    zT_D96DCDF2_EnumMember* zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    zT_C69B2266_i64 zT_130;
    zT_C69B2266_i64 zT_131;
    unsigned int zT_132;
    unsigned char zT_134;
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    zig_poison_fill((void*)&zT_114, (unsigned int)sizeof zT_114);
    zT_29C26066_Arr_zT_C69B2266_i64 seen;
    unsigned int children_n;
    zT_C69B2266_i64 auto_val;
    unsigned int k;
    unsigned int i;
    zT_22A7C88B_AstNode mnode;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int dj_lim;
    unsigned int dj;
    zT_C69B2266_i64 prev;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    {
    unsigned int _i = 0;
    while (_i < 256) {
        seen[_i] = zT_10[_i];
        _i++;
    }
}
    zT_12 = env->store;
    zT_13 = enum_node;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    children_n = zT_15;
    zT_17 = 0;
    auto_val = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    k = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < children_n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_26 = env->store;
    zT_29 = env->store;
    zT_30 = enum_node;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_29, zT_30, (unsigned int)((unsigned int)i));
    zT_27 = zT_34;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    mnode = zT_35;
    zT_36 = mnode.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    *out_count = k;
    return (unsigned char)(1);
    z_bb_4:
    zT_135 = 1;
    zT_136 = (unsigned int)zT_135;
    zT_137 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_136)), 32u);
    zT_138 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_136)), 32u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    i = zT_137;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    mval = auto_val;
    zT_41 = mnode.child_1;
    if ((unsigned char)(zT_41 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_45 = env;
    zT_46 = mnode.child_1;
    zT_50 = zF_FFFAAD16_evalConstI64Full(zT_45, zT_46, (unsigned int)(0));
    ev_opt = zT_50;
    zT_51 = ev_opt.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    if (strict) goto z_bb_14; else goto z_bb_15;
    z_bb_9:
    if (!(ev_opt.has_value)) { pal_trap(); }
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    if (strict) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_53 = mnode.child_1;
    *out_fail_node = zT_53;
    *out_fail_kind = (unsigned int)(1);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    dj_lim = k;
    if (check_only) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if (check_only) goto z_bb_30; else goto z_bb_32;
    z_bb_16:
    zT_57 = dj_lim > (unsigned int)(256);
    goto z_bb_18;
    z_bb_17:
    zT_57 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_60 = 256;
    dj_lim = zT_60;
    goto z_bb_20;
    z_bb_20:
    zT_62 = 0;
    zT_63 = (unsigned int)zT_62;
    dj = zT_63;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(dj < dj_lim)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    prev = zT_66;
    if (check_only) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_15;
    z_bb_24:
    zT_90 = 1;
    zT_91 = (unsigned int)zT_90;
    zT_92 = zig_wrap_add_u(((zu64)(dj)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(dj)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    dj = zT_92;
    goto z_bb_21;
    z_bb_25:
    zT_67 = (unsigned int)dj;
    zT_69 = zT_67 < (unsigned int)(256);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = seen[zT_67];
    prev = zT_70;
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(prev == mval)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_71 = env->typereg;
    zT_72 = zT_71->em_items;
    zT_73 = (unsigned int)mstart;
    zT_74 = (unsigned int)dj;
    zT_75 = zig_wrap_add_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_add_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    zT_79 = zT_72[zT_75];
    zT_80 = zT_79.value;
    prev = zT_80;
    goto z_bb_26;
    z_bb_28:
    zT_82 = env->store;
    zT_83 = enum_node;
    zT_87 = zF_B10B1BC1_astStoreNodeExtraCh(zT_82, zT_83, (unsigned int)((unsigned int)i));
    *out_fail_node = zT_87;
    *out_fail_kind = (unsigned int)(2);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    if ((unsigned char)(k < (unsigned int)(256))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_124 = 1;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    k = zT_126;
    zT_130 = 1;
    zT_131 = zig_wrap_add_s(((z64)(mval)), ((z64)(zT_130)), 64u);
    zT_132 = zig_overflow_flag_add_s(((z64)(mval)), ((z64)(zT_130)), 64u);
    zT_134 = zT_132 == (unsigned int)(0);
    if (!(zT_134)) { pal_trap(); }
    auto_val = zT_131;
    goto z_bb_4;
    z_bb_32:
    if (append) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    zT_98 = (unsigned int)k;
    zT_100 = zT_98 < (unsigned int)(256);
    if (!(zT_100)) { pal_trap(); }
    seen[zT_98] = mval;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_101 = env->typereg;
    zT_105 = env->store;
    zT_108 = env->store;
    zT_109 = enum_node;
    zT_113 = zF_B10B1BC1_astStoreNodeExtraCh(zT_108, zT_109, (unsigned int)((unsigned int)i));
    zT_106 = zT_113;
    zT_114 = zF_8BA26B9E_astStoreNodePayload(zT_105, zT_106);
    zT_104.name_id = zT_114;
    zT_104.value = mval;
    zT_102 = zT_104;
    zF_157DA7BF_emAppend(zT_101, zT_102);
    goto z_bb_36;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_115 = env->typereg;
    zT_116 = zT_115->em_items;
    zT_117 = (unsigned int)mstart;
    zT_118 = (unsigned int)k;
    zT_119 = zig_wrap_add_u(((zu64)(zT_117)), ((zu64)(zT_118)), 32u);
    zT_120 = zig_overflow_flag_add_u(((zu64)(zT_117)), ((zu64)(zT_118)), 32u);
    zT_122 = zT_120 == (unsigned int)(0);
    if (!(zT_122)) { pal_trap(); }
    zT_123 = zT_116 + zT_119;
    zT_123->value = mval;
    goto z_bb_36;
}

/* reportEnumWalkFailure */
void zF_52B56F5B_reportEnumWalkFailu(zT_F85C5DED_DiagnosticCollector* diag, zT_6B0A7D14_AstStore* store, unsigned int source_file_id, unsigned int fail_node, unsigned int fail_kind) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_F85C5DED_DiagnosticCollector* zT_27;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_38;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_6 = store;
    zT_7 = fail_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    fn_ = zT_8;
    zT_10 = fn_.span_start;
    sp = zT_10;
    zT_12 = fn_.span_len;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    ep = zT_14;
    zT_19 = "enum member value is not a comptime-known integer expression";
    zT_21 = 60;
    zT_20.ptr = (unsigned char*)zT_19;
    zT_20.len = zT_21;
    msg = zT_20;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = "duplicate enum tag value (tag values must be unique)";
    zT_26 = 52;
    zT_25.ptr = (unsigned char*)zT_24;
    zT_25.len = zT_26;
    msg = zT_25;
    goto z_bb_2;
    z_bb_2:
    zT_27 = diag;
    zT_30 = source_file_id;
    zT_31 = sp;
    zT_32 = ep;
    zT_33 = msg;
    zT_38 = zF_C82559AC_diagnosticCollector(zT_27, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_30, zT_31, zT_32, zT_33);
    (void)zT_38;
    return;
}

/* enumReevaluateAll */
void zF_153D24FD_enumReevaluateAll(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_8;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    zT_8143F551_AstKind zT_45;
    unsigned char zT_49;
    unsigned int zT_50;
    unsigned int zT_53;
    zT_8143F551_AstKind zT_54;
    unsigned char zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    zT_22A7C88B_AstNode zT_66;
    zT_8143F551_AstKind zT_67;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_6E8D187B_ModuleEntry* zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_6E8D187B_ModuleEntry zT_81;
    unsigned int zT_82;
    zT_79FAE712_u64 zT_83;
    zT_79FAE712_u64 zT_84;
    zT_79FAE712_u64 zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    zT_939EE900_Arr_unsigned_int_1 zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_79FAE712_u64 zT_99;
    zT_BAEE192E_Opt_10 zT_100;
    unsigned char zT_101;
    int zT_103;
    unsigned char zT_105;
    int zT_107;
    unsigned char zT_109;
    unsigned int zT_110;
    unsigned int zT_112;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    zT_D155D06D_Type zT_117;
    zT_33EF6BFB_TypeKind zT_118;
    zT_457ECFEE_EnumPayload* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_457ECFEE_EnumPayload zT_126;
    zT_ABC1EBBE_TypeResolveEnv zT_128;
    zT_6E8D187B_ModuleEntry* zT_129;
    unsigned int zT_130;
    unsigned char zT_131;
    zT_6E8D187B_ModuleEntry zT_132;
    unsigned int zT_133;
    zT_6E8D187B_ModuleEntry* zT_134;
    unsigned int zT_135;
    unsigned char zT_136;
    zT_6E8D187B_ModuleEntry zT_137;
    unsigned int zT_138;
    zT_622E1E76_Opt_254 zT_139;
    zT_9BD83C17_Opt_442 zT_140;
    zT_99D838F1_Opt_444 zT_141;
    int zT_143;
    unsigned int zT_144;
    int zT_146;
    unsigned int zT_147;
    int zT_149;
    unsigned int zT_150;
    zT_ABC1EBBE_TypeResolveEnv* zT_151;
    unsigned int zT_152;
    unsigned int zT_154;
    unsigned int* zT_157;
    unsigned int* zT_158;
    unsigned int* zT_159;
    unsigned char zT_168;
    zT_F85C5DED_DiagnosticCollector* zT_170;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_6E8D187B_ModuleEntry* zT_175;
    unsigned int zT_176;
    unsigned char zT_177;
    zT_6E8D187B_ModuleEntry zT_178;
    int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned char zT_191;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    zT_939EE900_Arr_unsigned_int_1 tid_box;
    unsigned int t;
    unsigned int tid;
    zT_D155D06D_Type ety;
    zT_457ECFEE_EnumPayload ep;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_7 = module_reg;
    zT_8 = zF_3452C137_moduleRegistryGetMo(zT_7);
    mods = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    mi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    if ((unsigned char)(mi < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = mods.ptr;
    zT_17 = mods.len;
    zT_18 = mi < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[mi];
    zT_20 = zT_19.ast_root;
    ast_root = zT_20;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_186 = 1;
    zT_187 = (unsigned int)zT_186;
    zT_188 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_187)), 32u);
    zT_189 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_187)), 32u);
    zT_191 = zT_189 == (unsigned int)(0);
    if (!(zT_191)) { pal_trap(); }
    mi = zT_188;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_24 = store;
    zT_25 = ast_root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_24, zT_25);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < decls_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = store;
    zT_33 = ast_root;
    zT_36 = zF_B10B1BC1_astStoreNodeExtraCh(zT_32, zT_33, (unsigned int)((unsigned int)di));
    decl_idx = zT_36;
    zT_38 = store;
    zT_39 = decl_idx;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    dnode = zT_40;
    zT_42 = 0;
    enum_node = zT_42;
    zT_44 = 0;
    enum_name_id = zT_44;
    zT_45 = dnode.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_180 = 1;
    zT_181 = (unsigned int)zT_180;
    zT_182 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    di = zT_182;
    goto z_bb_7;
    z_bb_11:
    zT_50 = dnode.child_1;
    zT_49 = zT_50 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_49 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    enum_node = decl_idx;
    zT_53 = dnode.child_0;
    enum_name_id = zT_53;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_16:
    zT_54 = dnode.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_59 = dnode.child_1;
    zT_58 = zT_59 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_58 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_58) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_63 = store;
    zT_64 = dnode.child_1;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_63, zT_64);
    inn = zT_66;
    zT_67 = inn.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_71 = dnode.child_1;
    enum_node = zT_71;
    zT_72 = store;
    zT_73 = decl_idx;
    zT_74 = zF_8BA26B9E_astStoreNodePayload(zT_72, zT_73);
    enum_name_id = zT_74;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    goto z_bb_10;
    z_bb_25:
    zT_78 = mods.ptr;
    zT_79 = mods.len;
    zT_80 = mi < zT_79;
    if (!(zT_80)) { pal_trap(); }
    zT_81 = zT_78[mi];
    zT_82 = zT_81.id;
    zT_83 = (zT_79FAE712_u64)zT_82;
    zT_84 = Z98_U64_C(4294967296);
    zT_85 = zig_wrap_mul_u(((zu64)(zT_83)), ((zu64)(zT_84)), 64u);
    zT_86 = zig_overflow_flag_mul_u(((zu64)(zT_83)), ((zu64)(zT_84)), 64u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    zT_89 = (zT_79FAE712_u64)enum_name_id;
    zT_90 = zig_wrap_add_u(((zu64)(zT_85)), ((zu64)(zT_89)), 64u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(zT_85)), ((zu64)(zT_89)), 64u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    key = zT_90;
    zT_96 = 0;
    zT_97 = 0;
    zT_95[zT_97] = zT_96;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        tid_box[_i] = zT_95[_i];
        _i++;
    }
}
    zT_98 = typereg;
    zT_99 = key;
    zT_100 = zF_0EB68360_nameCacheGet(zT_98, zT_99);
    zT_101 = zT_100.has_value;
    if (zT_101) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    if (!(zT_100.has_value)) { pal_trap(); }
    t = zT_100.value;
    zT_103 = 0;
    zT_105 = (unsigned int)zT_103 < (unsigned int)(1);
    if (!(zT_105)) { pal_trap(); }
    tid_box[zT_103] = t;
    goto z_bb_27;
    z_bb_27:
    zT_107 = 0;
    zT_109 = (unsigned int)zT_107 < (unsigned int)(1);
    if (!(zT_109)) { pal_trap(); }
    zT_110 = tid_box[zT_107];
    tid = zT_110;
    zT_112 = typereg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_112)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_115 = typereg->types_items;
    zT_116 = (unsigned int)tid;
    zT_117 = zT_115[zT_116];
    ety = zT_117;
    zT_118 = ety.kind;
    if ((unsigned char)(zT_118 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_10;
    z_bb_32:
    zT_123 = typereg->en_items;
    zT_124 = ety.payload_idx;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_123[zT_125];
    ep = zT_126;
    zT_128.store = store;
    zT_128.typereg = typereg;
    zT_128.symbol_reg = symbol_reg;
    zT_128.interner = interner;
    zT_129 = mods.ptr;
    zT_130 = mods.len;
    zT_131 = mi < zT_130;
    if (!(zT_131)) { pal_trap(); }
    zT_132 = zT_129[mi];
    zT_133 = zT_132.id;
    zT_128.module_id = zT_133;
    zT_134 = mods.ptr;
    zT_135 = mods.len;
    zT_136 = mi < zT_135;
    if (!(zT_136)) { pal_trap(); }
    zT_137 = zT_134[mi];
    zT_138 = zT_137.source_file_id;
    zT_128.source_file_id = zT_138;
    zT_139.has_value = 1;
    zT_139.value = diag;
    zT_128.diag = zT_139;
    zT_140.has_value = 0;
    zT_128.local_consts = zT_140;
    zT_141.has_value = 0;
    zT_128.local_types = zT_141;
    env = zT_128;
    zT_143 = 0;
    zT_144 = (unsigned int)zT_143;
    count = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    fail_node = zT_147;
    zT_149 = 0;
    zT_150 = (unsigned int)zT_149;
    fail_kind = zT_150;
    zT_151 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_152 = enum_node;
    zT_154 = ep.members_start;
    zT_157 = (unsigned int*)&count;
    zT_158 = (unsigned int*)&fail_node;
    zT_159 = (unsigned int*)&fail_kind;
    zT_168 = zF_0FFDEDBD_enumMembersResolve(zT_151, zT_152, (unsigned char)(0), zT_154, (unsigned char)(1), (unsigned char)(0), zT_157, zT_158, zT_159);
    if ((unsigned char)(!zT_168)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_170 = diag;
    zT_171 = store;
    zT_175 = mods.ptr;
    zT_176 = mods.len;
    zT_177 = mi < zT_176;
    if (!(zT_177)) { pal_trap(); }
    zT_178 = zT_175[mi];
    zT_172 = zT_178.source_file_id;
    zT_173 = fail_node;
    zT_174 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_170, zT_171, zT_172, zT_173, zT_174);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_10;
}

/* containerAnonNameId */
unsigned int zF_27A59B24_containerAnonNameId(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_3;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_4428DEE2_Arr_unsigned_char_2 zT_22;
    unsigned char zT_23;
    int zT_24;
    unsigned char zT_26;
    unsigned char zT_27;
    int zT_28;
    unsigned char zT_30;
    unsigned char zT_31;
    int zT_32;
    unsigned char zT_34;
    unsigned char zT_35;
    int zT_36;
    unsigned char zT_38;
    unsigned char zT_39;
    int zT_40;
    unsigned char zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    int zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    unsigned char zT_83;
    unsigned char zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zT_5826BFC7_Arr_unsigned_char_1 idb;
    unsigned int idl;
    unsigned int ids;
    zT_4428DEE2_Arr_unsigned_char_2 nm;
    unsigned int di;
    unsigned int namelen;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        idb[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = node_idx;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)idb) + zT_9;
    zT_11 = (unsigned int)(12) - zT_9;
    zT_12.ptr = (unsigned char*)zT_10;
    zT_12.len = zT_11;
    zT_6 = zT_12;
    zT_13 = zF_A7504564_itoa(zT_5, zT_6);
    idl = zT_13;
    zT_15 = 11;
    zT_16 = (unsigned int)idl;
    zT_17 = zig_wrap_sub_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    ids = zT_17;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    {
    unsigned int _i = 0;
    while (_i < 24) {
        nm[_i] = zT_22[_i];
        _i++;
    }
}
    zT_23 = 97;
    zT_24 = 0;
    zT_26 = (unsigned int)zT_24 < (unsigned int)(24);
    if (!(zT_26)) { pal_trap(); }
    nm[zT_24] = zT_23;
    zT_27 = 110;
    zT_28 = 1;
    zT_30 = (unsigned int)zT_28 < (unsigned int)(24);
    if (!(zT_30)) { pal_trap(); }
    nm[zT_28] = zT_27;
    zT_31 = 111;
    zT_32 = 2;
    zT_34 = (unsigned int)zT_32 < (unsigned int)(24);
    if (!(zT_34)) { pal_trap(); }
    nm[zT_32] = zT_31;
    zT_35 = 110;
    zT_36 = 3;
    zT_38 = (unsigned int)zT_36 < (unsigned int)(24);
    if (!(zT_38)) { pal_trap(); }
    nm[zT_36] = zT_35;
    zT_39 = 95;
    zT_40 = 4;
    zT_42 = (unsigned int)zT_40 < (unsigned int)(24);
    if (!(zT_42)) { pal_trap(); }
    nm[zT_40] = zT_39;
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    di = zT_45;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(di < (unsigned int)((unsigned int)idl))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_48 = zig_wrap_add_u(((zu64)(ids)), ((zu64)(di)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(ids)), ((zu64)(di)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_53 = zT_48 < (unsigned int)(12);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = idb[zT_48];
    zT_55 = 5;
    zT_56 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(di)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(di)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    zT_61 = zT_56 < (unsigned int)(24);
    if (!(zT_61)) { pal_trap(); }
    nm[zT_56] = zT_54;
    goto z_bb_4;
    z_bb_3:
    zT_69 = 5;
    zT_70 = (unsigned int)idl;
    zT_71 = zig_wrap_add_u(((zu64)(zT_69)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(zT_69)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    namelen = zT_71;
    zT_75 = env->interner;
    zT_80 = 0;
    zT_81 = (unsigned char*)((unsigned char*)nm) + zT_80;
    zT_82 = namelen - zT_80;
    zT_83 = (unsigned int)zT_80 <= namelen;
    if (!(zT_83)) { pal_trap(); }
    zT_84 = namelen <= (unsigned int)(24);
    if (!(zT_84)) { pal_trap(); }
    zT_85.ptr = (unsigned char*)zT_81;
    zT_85.len = zT_82;
    zT_76 = zT_85;
    zT_86 = zF_50C274AF_stringInternerInter(zT_75, zT_76);
    return zT_86;
    z_bb_4:
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    di = zT_64;
    goto z_bb_1;
}

/* isContainerDeclKind */
unsigned char zF_82C2F046_isContainerDeclKind(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    return zT_12;
}

/* isCompoundTypeExprKind */
unsigned char zF_599C0D79_isCompoundTypeExprK(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    return zT_24;
}

/* containerFieldCount */
unsigned int zF_3B3163AB_containerFieldCount(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25;
    zT_8143F551_AstKind zT_26;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    unsigned int count;
    unsigned int children_n;
    unsigned int i;
    unsigned int child;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    count = zT_4;
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_152E19CB_astStoreNodeExtraCh(zT_6, zT_7);
    children_n = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = env->store;
    zT_17 = node_idx;
    zT_21 = zF_B10B1BC1_astStoreNodeExtraCh(zT_16, zT_17, (unsigned int)((unsigned int)i));
    child = zT_21;
    zT_22 = env->store;
    zT_23 = child;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_26 = zT_25.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return count;
    z_bb_4:
    zT_36 = 1;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    i = zT_38;
    goto z_bb_1;
    z_bb_5:
    zT_30 = 1;
    zT_31 = (unsigned int)zT_30;
    zT_32 = zig_wrap_add_u(((zu64)(count)), ((zu64)(zT_31)), 32u);
    zT_33 = zig_overflow_flag_add_u(((zu64)(count)), ((zu64)(zT_31)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    count = zT_32;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* tupleElemArrayUnsupported */
unsigned char zF_E2A017C6_tupleElemArrayUnsup(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int elem_tid, unsigned int mark_node) {
    unsigned char zT_5;
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_622E1E76_Opt_254 zT_23;
    unsigned char zT_24;
    zT_F85C5DED_DiagnosticCollector* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int zT_56;
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    if ((unsigned char)(elem_tid == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = elem_tid == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_10 = env->typereg;
    zT_11 = zT_10->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)elem_tid) >= zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_14 = env->typereg;
    zT_15 = zT_14->types_items;
    zT_16 = (unsigned int)elem_tid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_23 = env->diag;
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    if (!(zT_23.has_value)) { pal_trap(); }
    diag = zT_23.value;
    zT_26 = diag;
    zT_27 = mark_node;
    zT_28 = zF_4DD9DB2D_diagnosticCollector(zT_26, zT_27);
    if (zT_28) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_30 = env->store;
    zT_31 = mark_node;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    node = zT_33;
    zT_35 = "tuple types with array elements are not supported";
    zT_37 = 49;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    msg = zT_36;
    zT_38 = diag;
    zT_41 = env->source_file_id;
    zT_42 = node.span_start;
    zT_49 = node.span_start;
    zT_50 = node.span_len;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zig_wrap_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    zT_43 = zT_52;
    zT_44 = msg;
    zT_56 = zF_C82559AC_diagnosticCollector(zT_38, (unsigned char)(0), (unsigned short)(3000), zT_41, zT_42, zT_43, zT_44);
    (void)zT_56;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* validateLocalEnum */
void zF_9084D8CB_validateLocalEnum(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node) {
    zT_622E1E76_Opt_254 zT_5;
    unsigned char zT_6;
    zT_F85C5DED_DiagnosticCollector* zT_7;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    unsigned int zT_23;
    unsigned int* zT_28;
    unsigned int* zT_29;
    unsigned int* zT_30;
    unsigned char zT_38;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zT_F85C5DED_DiagnosticCollector* diag;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = env->diag;
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    return;
    z_bb_4:
    if (!(zT_5.has_value)) { pal_trap(); }
    zT_7 = zT_5.value;
    goto z_bb_5;
    z_bb_5:
    diag = zT_7;
    zT_9 = diag;
    zT_10 = enum_node;
    zT_11 = zF_4DD9DB2D_diagnosticCollector(zT_9, zT_10);
    if ((unsigned char)(!zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    count = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fail_node = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    fail_kind = zT_21;
    zT_22 = env;
    zT_23 = enum_node;
    zT_28 = (unsigned int*)&count;
    zT_29 = (unsigned int*)&fail_node;
    zT_30 = (unsigned int*)&fail_kind;
    zT_38 = zF_0FFDEDBD_enumMembersResolve(zT_22, zT_23, (unsigned char)(0), (unsigned int)(0), (unsigned char)(1), (unsigned char)(1), zT_28, zT_29, zT_30);
    if ((unsigned char)(!zT_38)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = diag;
    zT_41 = env->store;
    zT_42 = env->source_file_id;
    zT_43 = fail_node;
    zT_44 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_40, zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    return;
}

/* registerContainerType */
unsigned int zF_FE81311F_registerContainerTy(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, zT_8143F551_AstKind kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_ABC1EBBE_TypeResolveEnv* zT_12;
    unsigned int zT_13;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_BAEE192E_Opt_10 zT_23;
    unsigned char zT_24;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned char zT_39;
    zT_ABC1EBBE_TypeResolveEnv* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_622E1E76_Opt_254 zT_45;
    unsigned char zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    zT_33EF6BFB_TypeKind zT_73;
    unsigned char zT_74;
    int zT_78;
    zT_33EF6BFB_TypeKind zT_80;
    unsigned char zT_87;
    int zT_91;
    zT_33EF6BFB_TypeKind zT_93;
    unsigned char zT_96;
    int zT_98;
    int zT_100;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_112;
    unsigned int zT_114;
    zT_33EF6BFB_TypeKind zT_115;
    unsigned int zT_118;
    unsigned char zT_122;
    unsigned char zT_126;
    unsigned char zT_127;
    zT_338B7C76_TypeRegistry* zT_133;
    unsigned int zT_134;
    unsigned char zT_139;
    unsigned char zT_140;
    int zT_144;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    unsigned int zT_149;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_158;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_160;
    int zT_162;
    unsigned int zT_163;
    int zT_165;
    unsigned int zT_166;
    unsigned char zT_169;
    zT_6B0A7D14_AstStore* zT_173;
    unsigned int zT_174;
    unsigned int zT_178;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode zT_183;
    zT_8143F551_AstKind zT_184;
    zT_ABC1EBBE_TypeResolveEnv* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned char zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    unsigned char zT_201;
    int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned char zT_207;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned char zT_213;
    zT_338B7C76_TypeRegistry* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    int zT_221;
    unsigned int zT_222;
    zT_ABC1EBBE_TypeResolveEnv* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned char zT_228;
    unsigned char zT_231;
    unsigned char zT_233;
    zT_338B7C76_TypeRegistry* zT_234;
    unsigned int zT_235;
    unsigned char zT_238;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned char zT_245;
    zT_338B7C76_TypeRegistry* zT_246;
    zT_666DC2E1_TuplePayload zT_247;
    zT_666DC2E1_TuplePayload zT_249;
    unsigned int zT_250;
    unsigned short zT_251;
    zT_338B7C76_TypeRegistry* zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned char zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_262;
    zT_D155D06D_Type* zT_263;
    unsigned int zT_264;
    zT_D155D06D_Type zT_265;
    zT_338B7C76_TypeRegistry* zT_266;
    zT_D155D06D_Type* zT_267;
    unsigned int zT_268;
    zT_6B0A7D14_AstStore* zT_272;
    unsigned int zT_273;
    unsigned int zT_275;
    zT_6B0A7D14_AstStore* zT_279;
    unsigned int zT_280;
    unsigned int zT_282;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_284;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_286;
    int zT_288;
    unsigned int zT_289;
    int zT_291;
    unsigned int zT_292;
    unsigned char zT_295;
    zT_6B0A7D14_AstStore* zT_299;
    unsigned int zT_300;
    unsigned int zT_304;
    zT_6B0A7D14_AstStore* zT_306;
    unsigned int zT_307;
    zT_22A7C88B_AstNode zT_309;
    zT_8143F551_AstKind zT_310;
    zT_ABC1EBBE_TypeResolveEnv* zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned char zT_322;
    unsigned int zT_323;
    unsigned char zT_325;
    zT_6B0A7D14_AstStore* zT_326;
    unsigned int zT_327;
    unsigned int zT_329;
    unsigned char zT_331;
    int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned char zT_337;
    int zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned char zT_343;
    zT_338B7C76_TypeRegistry* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    int zT_351;
    unsigned int zT_352;
    zT_338B7C76_TypeRegistry* zT_354;
    zT_2DF01B61_FieldEntry zT_355;
    zT_2DF01B61_FieldEntry zT_357;
    unsigned char zT_359;
    unsigned int zT_360;
    unsigned char zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned char zT_370;
    zT_338B7C76_TypeRegistry* zT_371;
    zT_406493CE_StructPayload zT_372;
    zT_406493CE_StructPayload zT_374;
    unsigned int zT_375;
    unsigned short zT_376;
    zT_338B7C76_TypeRegistry* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned char zT_384;
    unsigned int zT_385;
    zT_338B7C76_TypeRegistry* zT_387;
    zT_D155D06D_Type* zT_388;
    unsigned int zT_389;
    zT_D155D06D_Type zT_390;
    zT_338B7C76_TypeRegistry* zT_391;
    zT_D155D06D_Type* zT_392;
    unsigned int zT_393;
    zT_6B0A7D14_AstStore* zT_397;
    unsigned int zT_398;
    unsigned int zT_400;
    zT_6B0A7D14_AstStore* zT_404;
    unsigned int zT_405;
    unsigned int zT_407;
    int zT_408;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_411;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_413;
    int zT_415;
    unsigned int zT_416;
    int zT_418;
    unsigned int zT_419;
    unsigned char zT_422;
    zT_6B0A7D14_AstStore* zT_426;
    unsigned int zT_427;
    unsigned int zT_431;
    zT_6B0A7D14_AstStore* zT_433;
    unsigned int zT_434;
    zT_22A7C88B_AstNode zT_436;
    zT_8143F551_AstKind zT_437;
    zT_ABC1EBBE_TypeResolveEnv* zT_441;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    unsigned char zT_449;
    unsigned int zT_450;
    unsigned char zT_452;
    zT_6B0A7D14_AstStore* zT_453;
    unsigned int zT_454;
    unsigned int zT_456;
    unsigned char zT_458;
    int zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned char zT_464;
    int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    unsigned char zT_470;
    zT_338B7C76_TypeRegistry* zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    int zT_476;
    unsigned int zT_477;
    zT_338B7C76_TypeRegistry* zT_479;
    zT_2DF01B61_FieldEntry zT_480;
    zT_2DF01B61_FieldEntry zT_482;
    unsigned char zT_484;
    unsigned int zT_485;
    unsigned char zT_487;
    unsigned int zT_488;
    unsigned int zT_489;
    int zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    unsigned int zT_493;
    unsigned char zT_495;
    unsigned char zT_496;
    int zT_498;
    int zT_500;
    zT_338B7C76_TypeRegistry* zT_502;
    zT_54FF90FA_TaggedUnionPayload zT_503;
    zT_54FF90FA_TaggedUnionPayload zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned short zT_508;
    zT_338B7C76_TypeRegistry* zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned char zT_516;
    unsigned int zT_517;
    zT_338B7C76_TypeRegistry* zT_519;
    zT_D155D06D_Type* zT_520;
    unsigned int zT_521;
    zT_D155D06D_Type zT_522;
    zT_338B7C76_TypeRegistry* zT_523;
    zT_D155D06D_Type* zT_524;
    unsigned int zT_525;
    zT_338B7C76_TypeRegistry* zT_526;
    zT_AF9231A2_UnionPayload zT_527;
    zT_AF9231A2_UnionPayload zT_529;
    unsigned int zT_530;
    unsigned short zT_531;
    unsigned int zT_532;
    zT_338B7C76_TypeRegistry* zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    unsigned char zT_540;
    unsigned int zT_541;
    zT_338B7C76_TypeRegistry* zT_543;
    zT_D155D06D_Type* zT_544;
    unsigned int zT_545;
    zT_D155D06D_Type zT_546;
    zT_338B7C76_TypeRegistry* zT_547;
    zT_D155D06D_Type* zT_548;
    unsigned int zT_549;
    zT_338B7C76_TypeRegistry* zT_550;
    zT_6B0A7D14_AstStore* zT_551;
    zT_8143F551_AstKind zT_552;
    unsigned int zT_553;
    unsigned int zT_554;
    zT_3D7259E2_SymbolRegistry* zT_555;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_156, (unsigned int)sizeof zT_156);
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_197, (unsigned int)sizeof zT_197);
    zig_poison_fill((void*)&zT_233, (unsigned int)sizeof zT_233);
    zig_poison_fill((void*)&zT_275, (unsigned int)sizeof zT_275);
    zig_poison_fill((void*)&zT_282, (unsigned int)sizeof zT_282);
    zig_poison_fill((void*)&zT_304, (unsigned int)sizeof zT_304);
    zig_poison_fill((void*)&zT_309, (unsigned int)sizeof zT_309);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    zig_poison_fill((void*)&zT_329, (unsigned int)sizeof zT_329);
    zig_poison_fill((void*)&zT_400, (unsigned int)sizeof zT_400);
    zig_poison_fill((void*)&zT_407, (unsigned int)sizeof zT_407);
    zig_poison_fill((void*)&zT_431, (unsigned int)sizeof zT_431);
    zig_poison_fill((void*)&zT_436, (unsigned int)sizeof zT_436);
    zig_poison_fill((void*)&zT_450, (unsigned int)sizeof zT_450);
    zig_poison_fill((void*)&zT_456, (unsigned int)sizeof zT_456);
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_BAEE192E_Opt_10 existing;
    unsigned int e;
    zT_33EF6BFB_TypeKind type_kind;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_msg;
    unsigned int tid;
    unsigned int tup_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_ety;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_enode;
    unsigned int tup_ec;
    unsigned int tup_i;
    unsigned int tup_child;
    zT_22A7C88B_AstNode tup_fd;
    unsigned int tup_estart;
    unsigned int tup_j;
    unsigned int tup_tidx;
    zT_D155D06D_Type tup_ty;
    unsigned int sd_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    unsigned int sd_child;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned int un_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fnm;
    unsigned int un_fc;
    unsigned int un_i;
    unsigned int un_child;
    zT_22A7C88B_AstNode un_fd;
    unsigned int un_fstart;
    unsigned int un_j;
    unsigned int un_tu_idx;
    zT_D155D06D_Type un_tu_ty;
    unsigned int un_un_idx;
    zT_D155D06D_Type un_un_ty;
    zT_5 = env->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = env;
    zT_13 = node_idx;
    zF_9084D8CB_validateLocalEnum(zT_12, zT_13);
    goto z_bb_2;
    z_bb_2:
    zT_15 = env;
    zT_16 = node_idx;
    zT_17 = zF_27A59B24_containerAnonNameId(zT_15, zT_16);
    name_id = zT_17;
    zT_19 = env->typereg;
    zT_23 = zF_0EB68360_nameCacheGet(zT_19, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    existing = zT_23;
    zT_24 = existing.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(existing.has_value)) { pal_trap(); }
    e = existing.value;
    return e;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_29 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_7;
    z_bb_6:
    zT_29 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = node_idx;
    zT_36 = zF_8BA26B9E_astStoreNodePayload(zT_33, zT_34);
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
switch (kind) {
case 3: goto z_bb_17;
case 4: goto z_bb_18;
case 5: goto z_bb_19;
case 9: goto z_bb_20;
default: goto z_bb_21;
}
    z_bb_10:
    zT_40 = env;
    zT_41 = node_idx;
    zT_42 = zF_3B3163AB_containerFieldCount(zT_40, zT_41);
    zT_39 = zT_42 > (unsigned int)(32);
    goto z_bb_12;
    z_bb_11:
    zT_39 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_39) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = env->diag;
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    if (!(zT_45.has_value)) { pal_trap(); }
    diag = zT_45.value;
    zT_49 = "aggregate type has more than 32 fields, which is not supported";
    zT_51 = 62;
    zT_50.ptr = (unsigned char*)zT_49;
    zT_50.len = zT_51;
    fc_msg = zT_50;
    zT_52 = diag;
    zT_55 = env->source_file_id;
    zT_56 = node.span_start;
    zT_63 = node.span_start;
    zT_64 = node.span_len;
    zT_65 = (unsigned int)zT_64;
    zT_66 = zig_wrap_add_u(((zu64)(zT_63)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(zT_63)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_57 = zT_66;
    zT_58 = fc_msg;
    zT_70 = zF_C82559AC_diagnosticCollector(zT_52, (unsigned char)(0), (unsigned short)(3000), zT_55, zT_56, zT_57, zT_58);
    (void)zT_70;
    goto z_bb_16;
    z_bb_16:
    return (unsigned int)(18);
    z_bb_17:
    zT_74 = node.flags;
    zT_78 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_74) & (unsigned short)(32)) != zT_78)) goto z_bb_24; else goto z_bb_25;
    z_bb_18:
    zT_73 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_23;
    z_bb_19:
    zT_87 = node.flags;
    zT_91 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_87) & (unsigned short)(16)) != zT_91)) goto z_bb_27; else goto z_bb_28;
    z_bb_20:
    zT_73 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_23;
    z_bb_21:
    zT_73 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_23;
    z_bb_23:
    type_kind = zT_73;
    zT_112 = env->typereg;
    zT_114 = name_id;
    zT_115 = type_kind;
    zT_118 = zF_3A64E2E0_typeRegistryRegiste(zT_112, (unsigned int)(0), zT_114, zT_115);
    tid = zT_118;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_34; else goto z_bb_33;
    z_bb_24:
    zT_80 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_26;
    z_bb_25:
    zT_80 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_26;
    z_bb_26:
    zT_73 = zT_80;
    goto z_bb_23;
    z_bb_27:
    zT_93 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_29;
    z_bb_28:
    zT_96 = node.flags;
    zT_98 = 1;
    zT_100 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_96) & zT_98) != zT_100)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_73 = zT_93;
    goto z_bb_23;
    z_bb_30:
    zT_102 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_32;
    z_bb_31:
    zT_102 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_32;
    z_bb_32:
    zT_93 = zT_102;
    goto z_bb_29;
    z_bb_33:
    zT_122 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_35;
    z_bb_34:
    zT_122 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_122) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_127 = node.flags;
    zT_126 = (unsigned short)((unsigned short)((unsigned short)zT_127) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_38;
    z_bb_37:
    zT_126 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_126) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_133 = env->typereg;
    zT_134 = tid;
    zF_52816016_typeRegistrySetPack(zT_133, zT_134);
    goto z_bb_40;
    z_bb_40:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_140 = node.flags;
    zT_144 = 0;
    zT_139 = (unsigned short)((unsigned short)((unsigned short)zT_140) & (unsigned short)(32)) != zT_144;
    goto z_bb_43;
    z_bb_42:
    zT_139 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_139) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_146 = env->store;
    zT_147 = node_idx;
    zT_149 = zF_8BA26B9E_astStoreNodePayload(zT_146, zT_147);
    if ((unsigned char)(zT_149 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    return tid;
    z_bb_46:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_64; else goto z_bb_66;
    z_bb_47:
    zT_153 = env->store;
    zT_154 = node_idx;
    zT_156 = zF_152E19CB_astStoreNodeExtraCh(zT_153, zT_154);
    tup_children_n = zT_156;
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_ety[_i] = zT_158[_i];
        _i++;
    }
}
    zig_poison_fill((void*)&zT_160, (unsigned int)sizeof zT_160);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_enode[_i] = zT_160[_i];
        _i++;
    }
}
    zT_162 = 0;
    zT_163 = (unsigned int)zT_162;
    tup_ec = zT_163;
    zT_165 = 0;
    zT_166 = (unsigned int)zT_165;
    tup_i = zT_166;
    goto z_bb_49;
    z_bb_48:
    goto z_bb_45;
    z_bb_49:
    if ((unsigned char)(tup_i < (unsigned int)((unsigned int)tup_children_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_173 = env->store;
    zT_174 = node_idx;
    zT_178 = zF_B10B1BC1_astStoreNodeExtraCh(zT_173, zT_174, (unsigned int)((unsigned int)tup_i));
    tup_child = zT_178;
    zT_180 = env->store;
    zT_181 = tup_child;
    zT_183 = zF_FCDD1D35_astStoreNodeAt(zT_180, zT_181);
    tup_fd = zT_183;
    zT_184 = tup_fd.kind;
    if ((unsigned char)(zT_184 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_56; else goto z_bb_57;
    z_bb_51:
    if ((unsigned char)(tup_ec > (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_52:
    zT_208 = 1;
    zT_209 = (unsigned int)zT_208;
    zT_210 = zig_wrap_add_u(((zu64)(tup_i)), ((zu64)(zT_209)), 32u);
    zT_211 = zig_overflow_flag_add_u(((zu64)(tup_i)), ((zu64)(zT_209)), 32u);
    zT_213 = zT_211 == (unsigned int)(0);
    if (!(zT_213)) { pal_trap(); }
    tup_i = zT_210;
    goto z_bb_49;
    z_bb_53:
    zT_169 = tup_ec < (unsigned int)(32);
    goto z_bb_55;
    z_bb_54:
    zT_169 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_169) goto z_bb_50; else goto z_bb_51;
    z_bb_56:
    zT_188 = env;
    zT_189 = tup_fd.child_0;
    zT_192 = 1;
    zT_193 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_192)), 32u);
    zT_194 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_192)), 32u);
    zT_196 = zT_194 == (unsigned int)(0);
    if (!(zT_196)) { pal_trap(); }
    zT_190 = zT_193;
    zT_197 = zF_F2107C15_resolveTypeExprFull(zT_188, zT_189, zT_190);
    zT_199 = tup_ec < (unsigned int)(32);
    if (!(zT_199)) { pal_trap(); }
    tup_ety[tup_ec] = zT_197;
    zT_201 = tup_ec < (unsigned int)(32);
    if (!(zT_201)) { pal_trap(); }
    tup_enode[tup_ec] = tup_child;
    zT_202 = 1;
    zT_203 = (unsigned int)zT_202;
    zT_204 = zig_wrap_add_u(((zu64)(tup_ec)), ((zu64)(zT_203)), 32u);
    zT_205 = zig_overflow_flag_add_u(((zu64)(tup_ec)), ((zu64)(zT_203)), 32u);
    zT_207 = zT_205 == (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    tup_ec = zT_204;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
    z_bb_58:
    zT_217 = env->typereg;
    zT_218 = zT_217->xt_len;
    zT_219 = (unsigned int)zT_218;
    tup_estart = zT_219;
    zT_221 = 0;
    zT_222 = (unsigned int)zT_221;
    tup_j = zT_222;
    goto z_bb_60;
    z_bb_59:
    goto z_bb_48;
    z_bb_60:
    if ((unsigned char)(tup_j < tup_ec)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_224 = env;
    zT_228 = tup_j < (unsigned int)(32);
    if (!(zT_228)) { pal_trap(); }
    zT_225 = tup_ety[tup_j];
    zT_231 = tup_j < (unsigned int)(32);
    if (!(zT_231)) { pal_trap(); }
    zT_226 = tup_enode[tup_j];
    zT_233 = zF_E2A017C6_tupleElemArrayUnsup(zT_224, zT_225, zT_226);
    (void)zT_233;
    zT_234 = env->typereg;
    zT_238 = tup_j < (unsigned int)(32);
    if (!(zT_238)) { pal_trap(); }
    zT_235 = tup_ety[tup_j];
    zF_4C03AE3D_xtAppend(zT_234, zT_235);
    goto z_bb_63;
    z_bb_62:
    zT_246 = env->typereg;
    zT_250 = (unsigned int)tup_estart;
    zT_249.elems_start = zT_250;
    zT_251 = (unsigned short)zig_cast_checked_u((zu64)tup_ec, 32u, 0u, 16u);
    zT_249.elems_count = zT_251;
    zT_247 = zT_249;
    zF_C94DF842_tupAppend(zT_246, zT_247);
    zT_253 = env->typereg;
    zT_254 = zT_253->tup_len;
    zT_255 = 1;
    zT_256 = zig_wrap_sub_u(((zu64)(zT_254)), ((zu64)(zT_255)), 32u);
    zT_257 = zig_overflow_flag_sub_u(((zu64)(zT_254)), ((zu64)(zT_255)), 32u);
    zT_259 = zT_257 == (unsigned int)(0);
    if (!(zT_259)) { pal_trap(); }
    zT_260 = (unsigned int)zT_256;
    tup_tidx = zT_260;
    zT_262 = env->typereg;
    zT_263 = zT_262->types_items;
    zT_264 = (unsigned int)tid;
    zT_265 = zT_263[zT_264];
    tup_ty = zT_265;
    tup_ty.payload_idx = tup_tidx;
    zT_266 = env->typereg;
    zT_267 = zT_266->types_items;
    zT_268 = (unsigned int)tid;
    zT_267[zT_268] = tup_ty;
    goto z_bb_59;
    z_bb_63:
    zT_240 = 1;
    zT_241 = (unsigned int)zT_240;
    zT_242 = zig_wrap_add_u(((zu64)(tup_j)), ((zu64)(zT_241)), 32u);
    zT_243 = zig_overflow_flag_add_u(((zu64)(tup_j)), ((zu64)(zT_241)), 32u);
    zT_245 = zT_243 == (unsigned int)(0);
    if (!(zT_245)) { pal_trap(); }
    tup_j = zT_242;
    goto z_bb_60;
    z_bb_64:
    zT_272 = env->store;
    zT_273 = node_idx;
    zT_275 = zF_8BA26B9E_astStoreNodePayload(zT_272, zT_273);
    if ((unsigned char)(zT_275 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    goto z_bb_45;
    z_bb_66:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_84; else goto z_bb_86;
    z_bb_67:
    zT_279 = env->store;
    zT_280 = node_idx;
    zT_282 = zF_152E19CB_astStoreNodeExtraCh(zT_279, zT_280);
    sd_children_n = zT_282;
    zig_poison_fill((void*)&zT_284, (unsigned int)sizeof zT_284);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_284[_i];
        _i++;
    }
}
    zig_poison_fill((void*)&zT_286, (unsigned int)sizeof zT_286);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_286[_i];
        _i++;
    }
}
    zT_288 = 0;
    zT_289 = (unsigned int)zT_288;
    sd_fc = zT_289;
    zT_291 = 0;
    zT_292 = (unsigned int)zT_291;
    sd_i = zT_292;
    goto z_bb_69;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    if ((unsigned char)(sd_i < (unsigned int)((unsigned int)sd_children_n))) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_299 = env->store;
    zT_300 = node_idx;
    zT_304 = zF_B10B1BC1_astStoreNodeExtraCh(zT_299, zT_300, (unsigned int)((unsigned int)sd_i));
    sd_child = zT_304;
    zT_306 = env->store;
    zT_307 = sd_child;
    zT_309 = zF_FCDD1D35_astStoreNodeAt(zT_306, zT_307);
    sd_fd = zT_309;
    zT_310 = sd_fd.kind;
    if ((unsigned char)(zT_310 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_76; else goto z_bb_77;
    z_bb_71:
    if ((unsigned char)(sd_fc > (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_72:
    zT_338 = 1;
    zT_339 = (unsigned int)zT_338;
    zT_340 = zig_wrap_add_u(((zu64)(sd_i)), ((zu64)(zT_339)), 32u);
    zT_341 = zig_overflow_flag_add_u(((zu64)(sd_i)), ((zu64)(zT_339)), 32u);
    zT_343 = zT_341 == (unsigned int)(0);
    if (!(zT_343)) { pal_trap(); }
    sd_i = zT_340;
    goto z_bb_69;
    z_bb_73:
    zT_295 = sd_fc < (unsigned int)(32);
    goto z_bb_75;
    z_bb_74:
    zT_295 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_295) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_314 = env;
    zT_315 = sd_fd.child_0;
    zT_318 = 1;
    zT_319 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_318)), 32u);
    zT_320 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_318)), 32u);
    zT_322 = zT_320 == (unsigned int)(0);
    if (!(zT_322)) { pal_trap(); }
    zT_316 = zT_319;
    zT_323 = zF_F2107C15_resolveTypeExprFull(zT_314, zT_315, zT_316);
    zT_325 = sd_fc < (unsigned int)(32);
    if (!(zT_325)) { pal_trap(); }
    sd_fty[sd_fc] = zT_323;
    zT_326 = env->store;
    zT_327 = sd_child;
    zT_329 = zF_8BA26B9E_astStoreNodePayload(zT_326, zT_327);
    zT_331 = sd_fc < (unsigned int)(32);
    if (!(zT_331)) { pal_trap(); }
    sd_fnm[sd_fc] = zT_329;
    zT_332 = 1;
    zT_333 = (unsigned int)zT_332;
    zT_334 = zig_wrap_add_u(((zu64)(sd_fc)), ((zu64)(zT_333)), 32u);
    zT_335 = zig_overflow_flag_add_u(((zu64)(sd_fc)), ((zu64)(zT_333)), 32u);
    zT_337 = zT_335 == (unsigned int)(0);
    if (!(zT_337)) { pal_trap(); }
    sd_fc = zT_334;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_347 = env->typereg;
    zT_348 = zT_347->fe_len;
    zT_349 = (unsigned int)zT_348;
    sd_fstart = zT_349;
    zT_351 = 0;
    zT_352 = (unsigned int)zT_351;
    sd_j = zT_352;
    goto z_bb_80;
    z_bb_79:
    goto z_bb_68;
    z_bb_80:
    if ((unsigned char)(sd_j < sd_fc)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_354 = env->typereg;
    zT_359 = sd_j < (unsigned int)(32);
    if (!(zT_359)) { pal_trap(); }
    zT_360 = sd_fnm[sd_j];
    zT_357.name_id = zT_360;
    zT_362 = sd_j < (unsigned int)(32);
    if (!(zT_362)) { pal_trap(); }
    zT_363 = sd_fty[sd_j];
    zT_357.type_id = zT_363;
    zT_364 = 0;
    zT_357.offset = zT_364;
    zT_355 = zT_357;
    zF_701DF154_feAppend(zT_354, zT_355);
    goto z_bb_83;
    z_bb_82:
    zT_371 = env->typereg;
    zT_375 = (unsigned int)sd_fstart;
    zT_374.fields_start = zT_375;
    zT_376 = (unsigned short)zig_cast_checked_u((zu64)sd_fc, 32u, 0u, 16u);
    zT_374.fields_count = zT_376;
    zT_372 = zT_374;
    zF_CF849366_stAppend(zT_371, zT_372);
    zT_378 = env->typereg;
    zT_379 = zT_378->st_len;
    zT_380 = 1;
    zT_381 = zig_wrap_sub_u(((zu64)(zT_379)), ((zu64)(zT_380)), 32u);
    zT_382 = zig_overflow_flag_sub_u(((zu64)(zT_379)), ((zu64)(zT_380)), 32u);
    zT_384 = zT_382 == (unsigned int)(0);
    if (!(zT_384)) { pal_trap(); }
    zT_385 = (unsigned int)zT_381;
    sd_st_idx = zT_385;
    zT_387 = env->typereg;
    zT_388 = zT_387->types_items;
    zT_389 = (unsigned int)tid;
    zT_390 = zT_388[zT_389];
    sd_ty = zT_390;
    sd_ty.payload_idx = sd_st_idx;
    zT_391 = env->typereg;
    zT_392 = zT_391->types_items;
    zT_393 = (unsigned int)tid;
    zT_392[zT_393] = sd_ty;
    goto z_bb_79;
    z_bb_83:
    zT_365 = 1;
    zT_366 = (unsigned int)zT_365;
    zT_367 = zig_wrap_add_u(((zu64)(sd_j)), ((zu64)(zT_366)), 32u);
    zT_368 = zig_overflow_flag_add_u(((zu64)(sd_j)), ((zu64)(zT_366)), 32u);
    zT_370 = zT_368 == (unsigned int)(0);
    if (!(zT_370)) { pal_trap(); }
    sd_j = zT_367;
    goto z_bb_80;
    z_bb_84:
    zT_397 = env->store;
    zT_398 = node_idx;
    zT_400 = zF_8BA26B9E_astStoreNodePayload(zT_397, zT_398);
    if ((unsigned char)(zT_400 != (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    goto z_bb_65;
    z_bb_86:
    zT_550 = env->typereg;
    zT_551 = env->store;
    zT_552 = kind;
    zT_553 = node_idx;
    zT_554 = tid;
    zT_555 = env->symbol_reg;
    zF_020995FB_populateTypePayload(zT_550, zT_551, zT_552, zT_553, zT_554, zT_555);
    goto z_bb_85;
    z_bb_87:
    zT_404 = env->store;
    zT_405 = node_idx;
    zT_407 = zF_152E19CB_astStoreNodeExtraCh(zT_404, zT_405);
    un_children_n = zT_407;
    zT_408 = 0;
    if ((unsigned char)(un_children_n != (unsigned int)zT_408)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zig_poison_fill((void*)&zT_411, (unsigned int)sizeof zT_411);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fty[_i] = zT_411[_i];
        _i++;
    }
}
    zig_poison_fill((void*)&zT_413, (unsigned int)sizeof zT_413);
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fnm[_i] = zT_413[_i];
        _i++;
    }
}
    zT_415 = 0;
    zT_416 = (unsigned int)zT_415;
    un_fc = zT_416;
    zT_418 = 0;
    zT_419 = (unsigned int)zT_418;
    un_i = zT_419;
    goto z_bb_91;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    if ((unsigned char)(un_i < (unsigned int)((unsigned int)un_children_n))) goto z_bb_95; else goto z_bb_96;
    z_bb_92:
    zT_426 = env->store;
    zT_427 = node_idx;
    zT_431 = zF_B10B1BC1_astStoreNodeExtraCh(zT_426, zT_427, (unsigned int)((unsigned int)un_i));
    un_child = zT_431;
    zT_433 = env->store;
    zT_434 = un_child;
    zT_436 = zF_FCDD1D35_astStoreNodeAt(zT_433, zT_434);
    un_fd = zT_436;
    zT_437 = un_fd.kind;
    if ((unsigned char)(zT_437 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_98; else goto z_bb_99;
    z_bb_93:
    zT_472 = env->typereg;
    zT_473 = zT_472->fe_len;
    zT_474 = (unsigned int)zT_473;
    un_fstart = zT_474;
    zT_476 = 0;
    zT_477 = (unsigned int)zT_476;
    un_j = zT_477;
    goto z_bb_100;
    z_bb_94:
    zT_465 = 1;
    zT_466 = (unsigned int)zT_465;
    zT_467 = zig_wrap_add_u(((zu64)(un_i)), ((zu64)(zT_466)), 32u);
    zT_468 = zig_overflow_flag_add_u(((zu64)(un_i)), ((zu64)(zT_466)), 32u);
    zT_470 = zT_468 == (unsigned int)(0);
    if (!(zT_470)) { pal_trap(); }
    un_i = zT_467;
    goto z_bb_91;
    z_bb_95:
    zT_422 = un_fc < (unsigned int)(32);
    goto z_bb_97;
    z_bb_96:
    zT_422 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_422) goto z_bb_92; else goto z_bb_93;
    z_bb_98:
    zT_441 = env;
    zT_442 = un_fd.child_0;
    zT_445 = 1;
    zT_446 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_445)), 32u);
    zT_447 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_445)), 32u);
    zT_449 = zT_447 == (unsigned int)(0);
    if (!(zT_449)) { pal_trap(); }
    zT_443 = zT_446;
    zT_450 = zF_F2107C15_resolveTypeExprFull(zT_441, zT_442, zT_443);
    zT_452 = un_fc < (unsigned int)(32);
    if (!(zT_452)) { pal_trap(); }
    un_fty[un_fc] = zT_450;
    zT_453 = env->store;
    zT_454 = un_child;
    zT_456 = zF_8BA26B9E_astStoreNodePayload(zT_453, zT_454);
    zT_458 = un_fc < (unsigned int)(32);
    if (!(zT_458)) { pal_trap(); }
    un_fnm[un_fc] = zT_456;
    zT_459 = 1;
    zT_460 = (unsigned int)zT_459;
    zT_461 = zig_wrap_add_u(((zu64)(un_fc)), ((zu64)(zT_460)), 32u);
    zT_462 = zig_overflow_flag_add_u(((zu64)(un_fc)), ((zu64)(zT_460)), 32u);
    zT_464 = zT_462 == (unsigned int)(0);
    if (!(zT_464)) { pal_trap(); }
    un_fc = zT_461;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_94;
    z_bb_100:
    if ((unsigned char)(un_j < un_fc)) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_479 = env->typereg;
    zT_484 = un_j < (unsigned int)(32);
    if (!(zT_484)) { pal_trap(); }
    zT_485 = un_fnm[un_j];
    zT_482.name_id = zT_485;
    zT_487 = un_j < (unsigned int)(32);
    if (!(zT_487)) { pal_trap(); }
    zT_488 = un_fty[un_j];
    zT_482.type_id = zT_488;
    zT_489 = 0;
    zT_482.offset = zT_489;
    zT_480 = zT_482;
    zF_701DF154_feAppend(zT_479, zT_480);
    goto z_bb_103;
    z_bb_102:
    zT_496 = node.flags;
    zT_498 = 1;
    zT_500 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_496) & zT_498) != zT_500)) goto z_bb_104; else goto z_bb_106;
    z_bb_103:
    zT_490 = 1;
    zT_491 = (unsigned int)zT_490;
    zT_492 = zig_wrap_add_u(((zu64)(un_j)), ((zu64)(zT_491)), 32u);
    zT_493 = zig_overflow_flag_add_u(((zu64)(un_j)), ((zu64)(zT_491)), 32u);
    zT_495 = zT_493 == (unsigned int)(0);
    if (!(zT_495)) { pal_trap(); }
    un_j = zT_492;
    goto z_bb_100;
    z_bb_104:
    zT_502 = env->typereg;
    zT_506 = 10;
    zT_505.tag_type = zT_506;
    zT_507 = (unsigned int)un_fstart;
    zT_505.fields_start = zT_507;
    zT_508 = (unsigned short)zig_cast_checked_u((zu64)un_fc, 32u, 0u, 16u);
    zT_505.fields_count = zT_508;
    zT_503 = zT_505;
    zF_FB6B57C6_tuAppend(zT_502, zT_503);
    zT_510 = env->typereg;
    zT_511 = zT_510->tu_len;
    zT_512 = 1;
    zT_513 = zig_wrap_sub_u(((zu64)(zT_511)), ((zu64)(zT_512)), 32u);
    zT_514 = zig_overflow_flag_sub_u(((zu64)(zT_511)), ((zu64)(zT_512)), 32u);
    zT_516 = zT_514 == (unsigned int)(0);
    if (!(zT_516)) { pal_trap(); }
    zT_517 = (unsigned int)zT_513;
    un_tu_idx = zT_517;
    zT_519 = env->typereg;
    zT_520 = zT_519->types_items;
    zT_521 = (unsigned int)tid;
    zT_522 = zT_520[zT_521];
    un_tu_ty = zT_522;
    un_tu_ty.payload_idx = un_tu_idx;
    zT_523 = env->typereg;
    zT_524 = zT_523->types_items;
    zT_525 = (unsigned int)tid;
    zT_524[zT_525] = un_tu_ty;
    goto z_bb_105;
    z_bb_105:
    goto z_bb_90;
    z_bb_106:
    zT_526 = env->typereg;
    zT_530 = (unsigned int)un_fstart;
    zT_529.fields_start = zT_530;
    zT_531 = (unsigned short)zig_cast_checked_u((zu64)un_fc, 32u, 0u, 16u);
    zT_529.fields_count = zT_531;
    zT_532 = 1;
    zT_529.tag_type = zT_532;
    zT_527 = zT_529;
    zF_1718422E_unAppend(zT_526, zT_527);
    zT_534 = env->typereg;
    zT_535 = zT_534->un_len;
    zT_536 = 1;
    zT_537 = zig_wrap_sub_u(((zu64)(zT_535)), ((zu64)(zT_536)), 32u);
    zT_538 = zig_overflow_flag_sub_u(((zu64)(zT_535)), ((zu64)(zT_536)), 32u);
    zT_540 = zT_538 == (unsigned int)(0);
    if (!(zT_540)) { pal_trap(); }
    zT_541 = (unsigned int)zT_537;
    un_un_idx = zT_541;
    zT_543 = env->typereg;
    zT_544 = zT_543->types_items;
    zT_545 = (unsigned int)tid;
    zT_546 = zT_544[zT_545];
    un_un_ty = zT_546;
    un_un_ty.payload_idx = un_un_idx;
    zT_547 = env->typereg;
    zT_548 = zT_547->types_items;
    zT_549 = (unsigned int)tid;
    zT_548[zT_549] = un_un_ty;
    goto z_bb_105;
}

/* typeResolverCheckMemberVisibility */
unsigned char zF_D43B245F_typeResolverCheckMe(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int name_id, zT_3A105EF1_Symbol* sym) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_8;
    unsigned char zT_9;
    zT_622E1E76_Opt_254 zT_11;
    unsigned char zT_12;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_37;
    int zT_40;
    unsigned char zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50;
    zT_F85C5DED_DiagnosticCollector* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    zT_22A7C88B_AstNode zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_F85C5DED_DiagnosticCollector* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zT_F85C5DED_DiagnosticCollector* dc;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv2;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvnm;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tvparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvmsg;
    zT_22A7C88B_AstNode tvnode;
    unsigned int tv_di;
    zT_22A7C88B_AstNode tv_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv_note;
    zT_4 = sym->module_id;
    zT_5 = env->module_id;
    if ((unsigned char)(zT_4 == zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = sym;
    zT_9 = zF_C08C479C_symbolIsPublic(zT_8);
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_11 = env->diag;
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    if (!(zT_11.has_value)) { pal_trap(); }
    dc = zT_11.value;
    zT_14 = dc;
    zT_15 = node_idx;
    zT_16 = zF_4DD9DB2D_diagnosticCollector(zT_14, zT_15);
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = "'";
    zT_20 = 1;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    tv1 = zT_19;
    zT_22 = "' is not marked 'pub'";
    zT_24 = 21;
    zT_23.ptr = (unsigned char*)zT_22;
    zT_23.len = zT_24;
    tv2 = zT_23;
    zT_26 = env->interner;
    zT_27 = name_id;
    zT_29 = zF_9134020D_stringInternerGet(zT_26, zT_27);
    tvnm = zT_29;
    zT_32 = 0;
    zT_31[zT_32] = tv1;
    zT_33 = 1;
    zT_31[zT_33] = tvnm;
    zT_34 = 2;
    zT_31[zT_34] = tv2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tvparts[_i] = zT_31[_i];
        _i++;
    }
}
    zT_36 = env->interner;
    zT_40 = 0;
    zT_42 = (unsigned int)zT_40 < (unsigned int)(3);
    if (!(zT_42)) { pal_trap(); }
    zT_43 = tvparts + zT_40;
    zT_37 = zT_43;
    zT_45 = zF_8C4BFF7C_diagnosticBuilderMa(zT_36, zT_37, (unsigned int)(3));
    tvmsg = zT_45;
    zT_47 = env->store;
    zT_48 = node_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    tvnode = zT_50;
    zT_52 = dc;
    zT_55 = env->source_file_id;
    zT_56 = tvnode.span_start;
    zT_65 = tvnode.span_start;
    zT_66 = tvnode.span_len;
    zT_67 = (unsigned int)zT_66;
    zT_68 = zig_wrap_add_u(((zu64)(zT_65)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_add_u(((zu64)(zT_65)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    zT_57 = zT_68;
    zT_58 = tvmsg;
    zT_72 = zF_C82559AC_diagnosticCollector(zT_52, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3007_VISIBILITY_VIOLATION)), zT_55, zT_56, zT_57, zT_58);
    tv_di = zT_72;
    zT_73 = sym->decl_node;
    if ((unsigned char)(zT_73 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_77 = env->store;
    zT_78 = sym->decl_node;
    zT_81 = zF_FCDD1D35_astStoreNodeAt(zT_77, zT_78);
    tv_decl = zT_81;
    zT_83 = "declared here";
    zT_85 = 13;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    tv_note = zT_84;
    zT_86 = dc;
    zT_87 = tv_di;
    zT_88 = sym->file_id;
    zT_89 = tv_decl.span_start;
    zT_94 = tv_decl.span_start;
    zT_95 = tv_decl.span_len;
    zT_96 = (unsigned int)zT_95;
    zT_97 = zig_wrap_add_u(((zu64)(zT_94)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(zT_94)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    zT_90 = zT_97;
    zT_91 = tv_note;
    zF_A9049B03_diagnosticCollector(zT_86, zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* typeResolverIsInferredLenArray */
unsigned char zF_54996FA4_typeResolverIsInfer(zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_23;
    zT_8143F551_AstKind zT_24;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_39;
    unsigned char zT_42;
    unsigned char* zT_43;
    int zT_44;
    unsigned int zT_45;
    unsigned char zT_46;
    unsigned char zT_47;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zT_22A7C88B_AstNode nd;
    zT_22A7C88B_AstNode sz;
    unsigned int nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tx;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = store;
    zT_8 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    nd = zT_9;
    zT_10 = nd.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = nd.child_1;
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = store;
    zT_21 = nd.child_1;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    sz = zT_23;
    zT_24 = sz.kind;
    if ((unsigned char)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_30 = store;
    zT_31 = nd.child_1;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    nm = zT_33;
    zT_35 = interner;
    zT_36 = nm;
    zT_37 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    tx = zT_37;
    zT_39 = tx.len;
    if ((unsigned char)(zT_39 == (unsigned int)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_43 = tx.ptr;
    zT_44 = 0;
    zT_45 = tx.len;
    zT_46 = (unsigned int)zT_44 < zT_45;
    if (!(zT_46)) { pal_trap(); }
    zT_47 = zT_43[zT_44];
    zT_42 = zT_47 == (unsigned char)(95);
    goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    goto z_bb_11;
    z_bb_11:
    return zT_42;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_99D838F1_Opt_444 zT_40;
    unsigned char zT_41;
    zT_C8A278E4_LocalTypeScope* zT_43;
    unsigned int zT_44;
    zT_BAEE192E_Opt_10 zT_45;
    unsigned char zT_46;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_D3EB6303_StringInterner* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_63;
    zT_79FAE712_u64 zT_64;
    zT_79FAE712_u64 zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    zT_338B7C76_TypeRegistry* zT_75;
    zT_79FAE712_u64 zT_76;
    zT_BAEE192E_Opt_10 zT_78;
    unsigned char zT_79;
    zT_ABC1EBBE_TypeResolveEnv* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_86;
    zT_338B7C76_TypeRegistry* zT_90;
    zT_BAEE192E_Opt_10 zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    int zT_109;
    unsigned int zT_110;
    zT_3D7259E2_SymbolRegistry* zT_111;
    unsigned int zT_112;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_117;
    zT_79FAE712_u64 zT_118;
    unsigned int zT_119;
    unsigned char zT_121;
    zT_79FAE712_u64 zT_122;
    zT_79FAE712_u64 zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zT_338B7C76_TypeRegistry* zT_128;
    zT_79FAE712_u64 zT_129;
    zT_BAEE192E_Opt_10 zT_131;
    unsigned char zT_132;
    int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned char zT_139;
    unsigned char* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    zT_ABC1EBBE_TypeResolveEnv* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    unsigned char zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned char* zT_167;
    unsigned int zT_169;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_175;
    zT_8143F551_AstKind zT_177;
    unsigned char zT_181;
    zT_8143F551_AstKind zT_182;
    unsigned char zT_186;
    zT_8143F551_AstKind zT_187;
    zT_ABC1EBBE_TypeResolveEnv* zT_191;
    unsigned int zT_192;
    zT_8143F551_AstKind zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_8143F551_AstKind zT_197;
    unsigned char zT_202;
    zT_ABC1EBBE_TypeResolveEnv* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_212;
    unsigned int zT_213;
    zT_6B0A7D14_AstStore* zT_217;
    unsigned int zT_218;
    zT_22A7C88B_AstNode zT_221;
    zT_8143F551_AstKind zT_222;
    zT_6B0A7D14_AstStore* zT_227;
    unsigned int zT_228;
    unsigned int zT_231;
    int zT_233;
    unsigned int zT_234;
    zT_3D7259E2_SymbolRegistry* zT_235;
    unsigned int zT_236;
    zT_3D7259E2_SymbolRegistry* zT_240;
    unsigned int zT_242;
    zT_77F031D4_Opt_960 zT_245;
    unsigned char zT_246;
    zT_3C598AEF_SymbolKind zT_248;
    unsigned int zT_253;
    zT_3D7259E2_SymbolRegistry* zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    zT_6B0A7D14_AstStore* zT_259;
    unsigned int zT_260;
    unsigned int zT_262;
    zT_77F031D4_Opt_960 zT_263;
    unsigned char zT_264;
    zT_ABC1EBBE_TypeResolveEnv* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_3A105EF1_Symbol* zT_269;
    zT_6B0A7D14_AstStore* zT_270;
    unsigned int zT_271;
    unsigned int zT_273;
    unsigned char zT_274;
    unsigned int zT_277;
    unsigned char zT_280;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    unsigned int zT_286;
    unsigned int zT_288;
    int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    unsigned char zT_294;
    unsigned char* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_304;
    zT_D155D06D_Type* zT_305;
    unsigned int zT_306;
    zT_D155D06D_Type zT_307;
    zT_33EF6BFB_TypeKind zT_308;
    unsigned short zT_313;
    zT_3D7259E2_SymbolRegistry* zT_315;
    unsigned int zT_317;
    zT_6B0A7D14_AstStore* zT_320;
    unsigned int zT_321;
    unsigned int zT_323;
    zT_77F031D4_Opt_960 zT_324;
    unsigned char zT_325;
    zT_ABC1EBBE_TypeResolveEnv* zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    zT_3A105EF1_Symbol* zT_330;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    unsigned int zT_334;
    unsigned char zT_335;
    unsigned int zT_338;
    unsigned char zT_341;
    unsigned char* zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned int zT_347;
    unsigned int zT_349;
    unsigned char* zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned int zT_357;
    zT_8143F551_AstKind zT_358;
    zT_939EE900_Arr_unsigned_int_1 zT_363;
    zT_338B7C76_TypeRegistry* zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    zT_EDD37787_Arr_unsigned_short_ zT_369;
    unsigned short zT_370;
    unsigned int zT_371;
    zT_6B0A7D14_AstStore* zT_372;
    unsigned int zT_373;
    unsigned int zT_375;
    zT_6B0A7D14_AstStore* zT_379;
    unsigned int zT_380;
    unsigned int zT_382;
    unsigned short zT_383;
    int zT_384;
    unsigned char zT_386;
    int zT_388;
    unsigned int zT_389;
    zT_338B7C76_TypeRegistry* zT_392;
    unsigned int zT_393;
    zT_6B0A7D14_AstStore* zT_395;
    unsigned int zT_396;
    unsigned int zT_400;
    int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned char zT_406;
    zT_338B7C76_TypeRegistry* zT_407;
    unsigned int zT_408;
    unsigned short zT_409;
    int zT_411;
    unsigned char zT_413;
    int zT_415;
    unsigned char zT_417;
    unsigned int zT_419;
    zT_8143F551_AstKind zT_420;
    zT_ABC1EBBE_TypeResolveEnv* zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    unsigned int zT_429;
    unsigned int zT_430;
    unsigned int zT_431;
    unsigned char zT_433;
    unsigned int zT_434;
    zT_939EE900_Arr_unsigned_int_1 zT_439;
    unsigned int zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    int zT_443;
    zT_ABC1EBBE_TypeResolveEnv* zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned char zT_454;
    unsigned int zT_455;
    int zT_459;
    unsigned char zT_461;
    unsigned int zT_462;
    int zT_463;
    unsigned char zT_465;
    zT_338B7C76_TypeRegistry* zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    int zT_470;
    unsigned char zT_472;
    unsigned int zT_474;
    zT_8143F551_AstKind zT_475;
    zT_939EE900_Arr_unsigned_int_1 zT_480;
    unsigned int zT_481;
    unsigned int zT_482;
    unsigned int zT_483;
    int zT_484;
    unsigned char zT_486;
    unsigned int zT_487;
    int zT_488;
    zT_ABC1EBBE_TypeResolveEnv* zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    unsigned int zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    unsigned char zT_498;
    unsigned int zT_499;
    int zT_500;
    unsigned char zT_502;
    unsigned char* zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    unsigned int zT_506;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_507;
    unsigned int zT_508;
    int zT_509;
    unsigned char zT_511;
    int zT_513;
    unsigned char zT_515;
    unsigned int zT_516;
    zT_99292002_Arr_unsigned_int_16 zT_521;
    unsigned int zT_523;
    zT_6B0A7D14_AstStore* zT_524;
    unsigned int zT_525;
    unsigned int zT_527;
    zT_6B0A7D14_AstStore* zT_531;
    unsigned int zT_532;
    unsigned int zT_534;
    unsigned int zT_536;
    unsigned char zT_539;
    zT_ABC1EBBE_TypeResolveEnv* zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    zT_6B0A7D14_AstStore* zT_546;
    unsigned int zT_547;
    unsigned int zT_551;
    unsigned int zT_552;
    unsigned int zT_553;
    unsigned int zT_554;
    unsigned char zT_556;
    unsigned int zT_557;
    unsigned char zT_562;
    unsigned int zT_563;
    unsigned int zT_564;
    unsigned int zT_565;
    unsigned char zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    unsigned int zT_570;
    unsigned char zT_572;
    unsigned char zT_574;
    unsigned char zT_575;
    unsigned char zT_580;
    zT_443A2803_Arr_unsigned_char_9 zT_582;
    unsigned int zT_584;
    unsigned char* zT_586;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_587;
    unsigned int zT_588;
    unsigned char* zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    unsigned int zT_593;
    unsigned int zT_595;
    unsigned int zT_597;
    unsigned char zT_599;
    unsigned char* zT_602;
    unsigned int zT_603;
    unsigned char zT_604;
    unsigned char zT_605;
    unsigned char zT_607;
    unsigned int zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned char zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned char zT_617;
    zT_5826BFC7_Arr_unsigned_char_1 zT_619;
    unsigned int zT_621;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    int zT_623;
    unsigned char zT_625;
    int zT_629;
    unsigned char* zT_630;
    unsigned int zT_631;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_632;
    unsigned int zT_633;
    unsigned int zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned int zT_638;
    unsigned char zT_640;
    unsigned char zT_643;
    unsigned char zT_647;
    unsigned char zT_648;
    unsigned char zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    unsigned int zT_653;
    unsigned char zT_655;
    unsigned int zT_656;
    unsigned int zT_657;
    unsigned int zT_658;
    unsigned char zT_660;
    unsigned int zT_662;
    unsigned char zT_664;
    unsigned char zT_669;
    unsigned char zT_671;
    unsigned int zT_672;
    unsigned int zT_673;
    unsigned int zT_674;
    unsigned char zT_676;
    zT_5826BFC7_Arr_unsigned_char_1 zT_678;
    unsigned int zT_680;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_681;
    unsigned char zT_683;
    int zT_687;
    unsigned char* zT_688;
    unsigned int zT_689;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_690;
    unsigned int zT_691;
    unsigned int zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    unsigned int zT_696;
    unsigned char zT_698;
    unsigned char zT_701;
    unsigned char zT_705;
    unsigned char zT_706;
    unsigned char zT_708;
    unsigned int zT_709;
    unsigned int zT_710;
    unsigned int zT_711;
    unsigned char zT_713;
    unsigned int zT_714;
    unsigned int zT_715;
    unsigned int zT_716;
    unsigned char zT_718;
    unsigned int zT_719;
    unsigned int zT_720;
    unsigned int zT_721;
    unsigned char zT_723;
    zT_D3EB6303_StringInterner* zT_725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_726;
    int zT_730;
    unsigned char* zT_731;
    unsigned int zT_732;
    unsigned char zT_733;
    unsigned char zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_338B7C76_TypeRegistry* zT_738;
    unsigned int zT_739;
    unsigned int zT_740;
    unsigned int zT_742;
    zT_338B7C76_TypeRegistry* zT_744;
    unsigned int zT_745;
    unsigned char zT_748;
    unsigned int zT_750;
    unsigned int zT_751;
    unsigned int zT_752;
    unsigned char zT_754;
    zT_338B7C76_TypeRegistry* zT_756;
    unsigned int zT_757;
    unsigned short zT_762;
    unsigned int zT_763;
    unsigned char zT_764;
    int zT_771;
    unsigned char zT_773;
    unsigned int zT_775;
    unsigned char* zT_777;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    unsigned int zT_781;
    zT_338B7C76_TypeRegistry* zT_782;
    unsigned int zT_783;
    zT_338B7C76_TypeRegistry* zT_785;
    unsigned int zT_786;
    unsigned int zT_790;
    unsigned int zT_791;
    int zT_792;
    unsigned char zT_794;
    zT_8143F551_AstKind zT_795;
    unsigned char zT_799;
    zT_8143F551_AstKind zT_800;
    unsigned char zT_804;
    zT_8143F551_AstKind zT_805;
    unsigned char zT_809;
    zT_8143F551_AstKind zT_810;
    unsigned char zT_814;
    zT_6B0A7D14_AstStore* zT_815;
    zT_D3EB6303_StringInterner* zT_816;
    unsigned int zT_817;
    unsigned char zT_821;
    zT_ABC1EBBE_TypeResolveEnv* zT_824;
    unsigned int zT_825;
    unsigned int zT_826;
    unsigned int zT_828;
    unsigned int zT_829;
    unsigned int zT_830;
    unsigned char zT_832;
    unsigned int zT_833;
    zT_8143F551_AstKind zT_837;
    unsigned char zT_841;
    zT_8143F551_AstKind zT_842;
    unsigned char* zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    unsigned int zT_851;
    unsigned char* zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned int zT_855;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_856;
    zT_8143F551_AstKind zT_858;
    unsigned char* zT_861;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_862;
    unsigned int zT_863;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_864;
    unsigned int zT_865;
    unsigned char zT_867;
    unsigned char zT_871;
    unsigned char zT_873;
    unsigned char zT_877;
    zT_8143F551_AstKind zT_878;
    zT_338B7C76_TypeRegistry* zT_883;
    unsigned int zT_884;
    unsigned char zT_885;
    unsigned char zT_886;
    unsigned int zT_888;
    unsigned char* zT_890;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_891;
    unsigned int zT_892;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_893;
    unsigned int zT_894;
    unsigned char* zT_896;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_897;
    unsigned int zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    zT_338B7C76_TypeRegistry* zT_901;
    unsigned int zT_902;
    unsigned char zT_903;
    unsigned char zT_904;
    unsigned int zT_906;
    unsigned char* zT_908;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_909;
    unsigned int zT_910;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_911;
    unsigned int zT_912;
    unsigned char* zT_914;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_915;
    unsigned int zT_916;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_917;
    zT_8143F551_AstKind zT_918;
    unsigned char zT_923;
    unsigned char zT_927;
    zT_338B7C76_TypeRegistry* zT_929;
    unsigned int zT_930;
    unsigned char zT_931;
    unsigned int zT_933;
    unsigned char* zT_935;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_936;
    unsigned int zT_937;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_938;
    unsigned int zT_939;
    unsigned char* zT_941;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_942;
    unsigned int zT_943;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_944;
    unsigned int zT_945;
    unsigned char* zT_947;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_948;
    unsigned int zT_949;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_950;
    zT_8143F551_AstKind zT_951;
    unsigned char* zT_956;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_957;
    unsigned int zT_958;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_959;
    unsigned int zT_960;
    zT_338B7C76_TypeRegistry* zT_962;
    unsigned int zT_963;
    unsigned int zT_965;
    unsigned char* zT_967;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_968;
    unsigned int zT_969;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_970;
    unsigned int zT_971;
    zT_8143F551_AstKind zT_972;
    unsigned char* zT_977;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_978;
    unsigned int zT_979;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_980;
    unsigned char* zT_982;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_983;
    unsigned int zT_984;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_985;
    unsigned int zT_986;
    unsigned int zT_987;
    int zT_988;
    zT_6B0A7D14_AstStore* zT_991;
    unsigned int zT_992;
    zT_22A7C88B_AstNode zT_995;
    unsigned int zT_997;
    unsigned char zT_999;
    zT_ABC1EBBE_TypeResolveEnv* zT_1001;
    unsigned int zT_1002;
    unsigned int zT_1006;
    unsigned char zT_1009;
    unsigned char* zT_1011;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1012;
    unsigned int zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1014;
    unsigned int zT_1015;
    zT_338B7C76_TypeRegistry* zT_1017;
    unsigned int zT_1018;
    unsigned int zT_1019;
    unsigned int zT_1021;
    unsigned char* zT_1023;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1024;
    unsigned int zT_1025;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1026;
    unsigned int zT_1027;
    unsigned char* zT_1031;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1032;
    unsigned int zT_1033;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1034;
    unsigned char* zT_1036;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1037;
    unsigned int zT_1038;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1039;
    unsigned char zT_1041;
    zT_8143F551_AstKind zT_1042;
    zT_6B0A7D14_AstStore* zT_1047;
    unsigned int zT_1048;
    unsigned int zT_1051;
    zT_D3EB6303_StringInterner* zT_1053;
    unsigned int zT_1054;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1056;
    unsigned int zT_1058;
    unsigned char zT_1061;
    unsigned char* zT_1062;
    int zT_1063;
    unsigned int zT_1064;
    unsigned char zT_1065;
    unsigned char zT_1066;
    unsigned char zT_1069;
    zT_622E1E76_Opt_254 zT_1070;
    unsigned char zT_1071;
    zT_F85C5DED_DiagnosticCollector* zT_1073;
    unsigned int zT_1074;
    unsigned char zT_1075;
    unsigned char* zT_1077;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1078;
    unsigned int zT_1079;
    zT_F85C5DED_DiagnosticCollector* zT_1080;
    unsigned int zT_1083;
    unsigned int zT_1084;
    unsigned int zT_1085;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1086;
    unsigned int zT_1091;
    unsigned int zT_1092;
    unsigned int zT_1093;
    unsigned int zT_1094;
    unsigned int zT_1095;
    unsigned char zT_1097;
    unsigned int zT_1098;
    zT_622E1E76_Opt_254 zT_1099;
    unsigned char zT_1100;
    zT_F85C5DED_DiagnosticCollector* zT_1102;
    unsigned int zT_1103;
    unsigned char zT_1104;
    unsigned char* zT_1106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1108;
    zT_F85C5DED_DiagnosticCollector* zT_1109;
    unsigned int zT_1112;
    unsigned int zT_1113;
    unsigned int zT_1114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1115;
    unsigned int zT_1122;
    unsigned int zT_1123;
    unsigned int zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1126;
    unsigned char zT_1128;
    unsigned int zT_1129;
    unsigned char* zT_1132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1133;
    unsigned int zT_1134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1135;
    unsigned int zT_1136;
    unsigned char* zT_1138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1139;
    unsigned int zT_1140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1141;
    zT_8143F551_AstKind zT_1143;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_175, (unsigned int)sizeof zT_175);
    zig_poison_fill((void*)&zT_196, (unsigned int)sizeof zT_196);
    zig_poison_fill((void*)&zT_213, (unsigned int)sizeof zT_213);
    zig_poison_fill((void*)&zT_221, (unsigned int)sizeof zT_221);
    zig_poison_fill((void*)&zT_231, (unsigned int)sizeof zT_231);
    zig_poison_fill((void*)&zT_245, (unsigned int)sizeof zT_245);
    zig_poison_fill((void*)&zT_262, (unsigned int)sizeof zT_262);
    zig_poison_fill((void*)&zT_263, (unsigned int)sizeof zT_263);
    zig_poison_fill((void*)&zT_273, (unsigned int)sizeof zT_273);
    zig_poison_fill((void*)&zT_274, (unsigned int)sizeof zT_274);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    zig_poison_fill((void*)&zT_324, (unsigned int)sizeof zT_324);
    zig_poison_fill((void*)&zT_334, (unsigned int)sizeof zT_334);
    zig_poison_fill((void*)&zT_335, (unsigned int)sizeof zT_335);
    zig_poison_fill((void*)&zT_375, (unsigned int)sizeof zT_375);
    zig_poison_fill((void*)&zT_382, (unsigned int)sizeof zT_382);
    zig_poison_fill((void*)&zT_400, (unsigned int)sizeof zT_400);
    zig_poison_fill((void*)&zT_419, (unsigned int)sizeof zT_419);
    zig_poison_fill((void*)&zT_434, (unsigned int)sizeof zT_434);
    zig_poison_fill((void*)&zT_455, (unsigned int)sizeof zT_455);
    zig_poison_fill((void*)&zT_474, (unsigned int)sizeof zT_474);
    zig_poison_fill((void*)&zT_499, (unsigned int)sizeof zT_499);
    zig_poison_fill((void*)&zT_527, (unsigned int)sizeof zT_527);
    zig_poison_fill((void*)&zT_534, (unsigned int)sizeof zT_534);
    zig_poison_fill((void*)&zT_551, (unsigned int)sizeof zT_551);
    zig_poison_fill((void*)&zT_557, (unsigned int)sizeof zT_557);
    zig_poison_fill((void*)&zT_633, (unsigned int)sizeof zT_633);
    zig_poison_fill((void*)&zT_691, (unsigned int)sizeof zT_691);
    zig_poison_fill((void*)&zT_736, (unsigned int)sizeof zT_736);
    zig_poison_fill((void*)&zT_775, (unsigned int)sizeof zT_775);
    zig_poison_fill((void*)&zT_790, (unsigned int)sizeof zT_790);
    zig_poison_fill((void*)&zT_799, (unsigned int)sizeof zT_799);
    zig_poison_fill((void*)&zT_821, (unsigned int)sizeof zT_821);
    zig_poison_fill((void*)&zT_833, (unsigned int)sizeof zT_833);
    zig_poison_fill((void*)&zT_888, (unsigned int)sizeof zT_888);
    zig_poison_fill((void*)&zT_906, (unsigned int)sizeof zT_906);
    zig_poison_fill((void*)&zT_933, (unsigned int)sizeof zT_933);
    zig_poison_fill((void*)&zT_965, (unsigned int)sizeof zT_965);
    zig_poison_fill((void*)&zT_995, (unsigned int)sizeof zT_995);
    zig_poison_fill((void*)&zT_1006, (unsigned int)sizeof zT_1006);
    zig_poison_fill((void*)&zT_1021, (unsigned int)sizeof zT_1021);
    zig_poison_fill((void*)&zT_1051, (unsigned int)sizeof zT_1051);
    zig_poison_fill((void*)&zT_1056, (unsigned int)sizeof zT_1056);
    zig_poison_fill((void*)&zT_1075, (unsigned int)sizeof zT_1075);
    zig_poison_fill((void*)&zT_1098, (unsigned int)sizeof zT_1098);
    zig_poison_fill((void*)&zT_1104, (unsigned int)sizeof zT_1104);
    zig_poison_fill((void*)&zT_1129, (unsigned int)sizeof zT_1129);
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_C8A278E4_LocalTypeScope* lts;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    unsigned int lt;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    unsigned int sym_cur_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    unsigned int all_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    unsigned char arbu;
    unsigned int arbw;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_77F031D4_Opt_960 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_77F031D4_Opt_960 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    unsigned short mod_id_1;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    unsigned int esd_children_n;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    unsigned int fnt_extra_n;
    unsigned int fnt_i;
    unsigned char fnt_conv;
    unsigned int fnt_pt;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    unsigned char is_const;
    unsigned char is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    unsigned char arr_resolved;
    unsigned int alf;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    unsigned char sz_is_inferred;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ail_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asn_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = (unsigned char*)zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    name_id = zT_33;
    zT_35 = "OPTVOID:id";
    zT_37 = 10;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    opm4_m = zT_36;
    zT_38 = opm4_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_40 = env->local_types;
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_177 = node.kind;
    if ((unsigned char)(zT_177 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_28; else goto z_bb_27;
    z_bb_5:
    if (!(zT_40.has_value)) { pal_trap(); }
    lts = zT_40.value;
    zT_43 = lts;
    zT_44 = name_id;
    zT_45 = zF_C768898A_localTypeScopeLooku(zT_43, zT_44);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_49 = env->interner;
    zT_50 = name_id;
    zT_52 = zF_9134020D_stringInternerGet(zT_49, zT_50);
    text = zT_52;
    zT_54 = env->interner;
    zT_55 = text;
    zT_57 = zF_50C274AF_stringInternerInter(zT_54, zT_55);
    canonical_id = zT_57;
    zT_58 = env->module_id;
    if ((unsigned char)(zT_58 != (unsigned int)(4294967295u))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if (!(zT_45.has_value)) { pal_trap(); }
    lt = zT_45.value;
    return lt;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_62 = env->module_id;
    zT_63 = (zT_79FAE712_u64)zT_62;
    zT_64 = Z98_U64_C(4294967296);
    zT_65 = zig_wrap_mul_u(((zu64)(zT_63)), ((zu64)(zT_64)), 64u);
    zT_66 = zig_overflow_flag_mul_u(((zu64)(zT_63)), ((zu64)(zT_64)), 64u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_69 = (zT_79FAE712_u64)canonical_id;
    zT_70 = zig_wrap_add_u(((zu64)(zT_65)), ((zu64)(zT_69)), 64u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(zT_65)), ((zu64)(zT_69)), 64u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    ck_cur = zT_70;
    zT_75 = env->typereg;
    zT_76 = ck_cur;
    zT_78 = zF_0EB68360_nameCacheGet(zT_75, zT_76);
    tc_cur = zT_78;
    zT_79 = tc_cur.has_value;
    if (zT_79) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_90 = env->typereg;
    zT_94 = zF_0EB68360_nameCacheGet(zT_90, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_94;
    zT_96 = "OPTVOID:nc";
    zT_98 = 10;
    zT_97.ptr = (unsigned char*)zT_96;
    zT_97.len = zT_98;
    opnc_m = zT_97;
    zT_99 = opnc_m;
    zT_100 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_99, zT_100);
    zT_101 = tid.has_value;
    if (zT_101) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    if (!(tc_cur.has_value)) { pal_trap(); }
    t = tc_cur.value;
    return t;
    z_bb_12:
    zT_82 = env;
    zT_83 = env->module_id;
    zT_84 = name_id;
    zT_86 = zF_66C54985_symbolTypeIdOfModul(zT_82, zT_83, zT_84);
    sym_cur_tid = zT_86;
    if ((unsigned char)(sym_cur_tid != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return sym_cur_tid;
    z_bb_14:
    goto z_bb_10;
    z_bb_15:
    if (!(tid.has_value)) { pal_trap(); }
    t = tid.value;
    return t;
    z_bb_16:
    zT_104 = "NF";
    zT_106 = 2;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    nf = zT_105;
    zT_107 = nf;
    zF_48AC7B3A_markerWrite(zT_107);
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    mi = zT_110;
    goto z_bb_17;
    z_bb_17:
    zT_111 = env->symbol_reg;
    zT_112 = zT_111->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_112))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_116 = (zT_79FAE712_u64)mi;
    zT_117 = Z98_U64_C(4294967296);
    zT_118 = zig_wrap_mul_u(((zu64)(zT_116)), ((zu64)(zT_117)), 64u);
    zT_119 = zig_overflow_flag_mul_u(((zu64)(zT_116)), ((zu64)(zT_117)), 64u);
    zT_121 = zT_119 == (unsigned int)(0);
    if (!(zT_121)) { pal_trap(); }
    zT_122 = (zT_79FAE712_u64)canonical_id;
    zT_123 = zig_wrap_add_u(((zu64)(zT_118)), ((zu64)(zT_122)), 64u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(zT_118)), ((zu64)(zT_122)), 64u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    ck = zT_123;
    zT_128 = env->typereg;
    zT_129 = ck;
    zT_131 = zF_0EB68360_nameCacheGet(zT_128, zT_129);
    tc = zT_131;
    zT_132 = tc.has_value;
    if (zT_132) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_141 = "N2";
    zT_143 = 2;
    zT_142.ptr = (unsigned char*)zT_141;
    zT_142.len = zT_143;
    n2 = zT_142;
    zT_144 = n2;
    zF_48AC7B3A_markerWrite(zT_144);
    zT_146 = env;
    zT_147 = name_id;
    zT_148 = zF_DE1472AF_symbolLookupTypeAll(zT_146, zT_147);
    all_tid = zT_148;
    if ((unsigned char)(all_tid != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_134 = 1;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_135)), 32u);
    zT_137 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_135)), 32u);
    zT_139 = zT_137 == (unsigned int)(0);
    if (!(zT_139)) { pal_trap(); }
    mi = zT_136;
    goto z_bb_17;
    z_bb_21:
    if (!(tc.has_value)) { pal_trap(); }
    t = tc.value;
    return t;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_152 = "OPTVOID:ids";
    zT_154 = 11;
    zT_153.ptr = (unsigned char*)zT_152;
    zT_153.len = zT_154;
    ops_m = zT_153;
    zT_155 = ops_m;
    zT_156 = all_tid;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    return all_tid;
    z_bb_24:
    zT_158 = "OPTVOID:idF";
    zT_160 = 11;
    zT_159.ptr = (unsigned char*)zT_158;
    zT_159.len = zT_160;
    opm4f_m = zT_159;
    zT_161 = opm4f_m;
    zT_162 = name_id;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_164 = 0;
    arbu = zT_164;
    zT_166 = text;
    zT_167 = (unsigned char*)&arbu;
    zT_169 = zF_741B5264_parseArbIntWidth(zT_166, zT_167);
    arbw = zT_169;
    if ((unsigned char)(arbw != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_172 = env->typereg;
    zT_173 = text;
    zT_175 = zF_B8CF3697_typeRegistryGetOrCr(zT_172, zT_173);
    return zT_175;
    z_bb_26:
    return (unsigned int)(18);
    z_bb_27:
    zT_182 = node.kind;
    zT_181 = zT_182 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_29;
    z_bb_28:
    zT_181 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_181) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_187 = node.kind;
    zT_186 = zT_187 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_32;
    z_bb_31:
    zT_186 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_186) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_191 = env;
    zT_192 = node_idx;
    zT_193 = node.kind;
    zT_194 = depth;
    zT_196 = zF_FE81311F_registerContainerTy(zT_191, zT_192, zT_193, zT_194);
    return zT_196;
    z_bb_34:
    zT_197 = node.kind;
    if ((unsigned char)(zT_197 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_202 = 0;
    fah_matched = zT_202;
    zT_204 = env;
    zT_205 = node.child_0;
    zT_208 = 1;
    zT_209 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_208)), 32u);
    zT_210 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_208)), 32u);
    zT_212 = zT_210 == (unsigned int)(0);
    if (!(zT_212)) { pal_trap(); }
    zT_206 = zT_209;
    zT_213 = zF_F2107C15_resolveTypeExprFull(zT_204, zT_205, zT_206);
    base_type = zT_213;
    if ((unsigned char)(base_type == (unsigned int)(18))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_358 = node.kind;
    if ((unsigned char)(zT_358 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_65; else goto z_bb_66;
    z_bb_37:
    zT_217 = env->store;
    zT_218 = node.child_0;
    zT_221 = zF_FCDD1D35_astStoreNodeAt(zT_217, zT_218);
    base_node = zT_221;
    zT_222 = base_node.kind;
    if ((unsigned char)(zT_222 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_304 = env->typereg;
    zT_305 = zT_304->types_items;
    zT_306 = (unsigned int)base_type;
    zT_307 = zT_305[zT_306];
    base_ty = zT_307;
    zT_308 = base_ty.kind;
    if ((unsigned char)(zT_308 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_39:
    zT_227 = env->store;
    zT_228 = node.child_0;
    zT_231 = zF_53458827_astStoreIdentifier(zT_227, zT_228);
    base_name_id = zT_231;
    zT_233 = 0;
    zT_234 = (unsigned int)zT_233;
    smi = zT_234;
    goto z_bb_41;
    z_bb_40:
    zT_296 = "FAH:m";
    zT_298 = 5;
    zT_297.ptr = (unsigned char*)zT_296;
    zT_297.len = zT_298;
    fam_m = zT_297;
    zT_299 = fam_m;
    zT_300 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_299, zT_300);
    return (unsigned int)(18);
    z_bb_41:
    zT_235 = env->symbol_reg;
    zT_236 = zT_235->tables_len;
    if ((unsigned char)(smi < (unsigned int)((unsigned int)zT_236))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_240 = env->symbol_reg;
    zT_242 = base_name_id;
    zT_245 = zF_A398987E_symbolRegistryQuali(zT_240, (unsigned int)((unsigned int)smi), zT_242);
    base_sym = zT_245;
    zT_246 = base_sym.has_value;
    if (zT_246) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_289 = 1;
    zT_290 = (unsigned int)zT_289;
    zT_291 = zig_wrap_add_u(((zu64)(smi)), ((zu64)(zT_290)), 32u);
    zT_292 = zig_overflow_flag_add_u(((zu64)(smi)), ((zu64)(zT_290)), 32u);
    zT_294 = zT_292 == (unsigned int)(0);
    if (!(zT_294)) { pal_trap(); }
    smi = zT_291;
    goto z_bb_41;
    z_bb_45:
    if (!(base_sym.has_value)) { pal_trap(); }
    bs = base_sym.value;
    zT_248 = bs->kind;
    if ((unsigned char)(zT_248 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    zT_253 = bs->module_id;
    mod_id = zT_253;
    zT_255 = env->symbol_reg;
    zT_256 = mod_id;
    zT_259 = env->store;
    zT_260 = node_idx;
    zT_262 = zF_8BA26B9E_astStoreNodePayload(zT_259, zT_260);
    zT_257 = zT_262;
    zT_263 = zF_A398987E_symbolRegistryQuali(zT_255, zT_256, zT_257);
    payload_sym = zT_263;
    zT_264 = payload_sym.has_value;
    if (zT_264) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    if (!(payload_sym.has_value)) { pal_trap(); }
    ps = payload_sym.value;
    zT_266 = env;
    zT_267 = node_idx;
    zT_270 = env->store;
    zT_271 = node_idx;
    zT_273 = zF_8BA26B9E_astStoreNodePayload(zT_270, zT_271);
    zT_268 = zT_273;
    zT_269 = ps;
    zT_274 = zF_D43B245F_typeResolverCheckMe(zT_266, zT_267, zT_268, zT_269);
    if ((unsigned char)(!zT_274)) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    return (unsigned int)(18);
    z_bb_52:
    zT_277 = ps->type_id;
    if ((unsigned char)(zT_277 != (unsigned int)(0))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_280 = 1;
    fah_matched = zT_280;
    zT_282 = "FAH:r";
    zT_284 = 5;
    zT_283.ptr = (unsigned char*)zT_282;
    zT_283.len = zT_284;
    fam = zT_283;
    zT_285 = fam;
    zT_286 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_285, zT_286);
    zT_288 = ps->type_id;
    return zT_288;
    z_bb_54:
    goto z_bb_50;
    z_bb_55:
    zT_313 = base_ty.module_id;
    mod_id_1 = zT_313;
    zT_315 = env->symbol_reg;
    zT_320 = env->store;
    zT_321 = node_idx;
    zT_323 = zF_8BA26B9E_astStoreNodePayload(zT_320, zT_321);
    zT_317 = zT_323;
    zT_324 = zF_A398987E_symbolRegistryQuali(zT_315, (unsigned int)((unsigned int)mod_id_1), zT_317);
    sym = zT_324;
    zT_325 = sym.has_value;
    if (zT_325) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    if ((unsigned char)(fah_matched == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_57:
    if (!(sym.has_value)) { pal_trap(); }
    s = sym.value;
    zT_327 = env;
    zT_328 = node_idx;
    zT_331 = env->store;
    zT_332 = node_idx;
    zT_334 = zF_8BA26B9E_astStoreNodePayload(zT_331, zT_332);
    zT_329 = zT_334;
    zT_330 = s;
    zT_335 = zF_D43B245F_typeResolverCheckMe(zT_327, zT_328, zT_329, zT_330);
    if ((unsigned char)(!zT_335)) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    return (unsigned int)(18);
    z_bb_60:
    zT_338 = s->type_id;
    if ((unsigned char)(zT_338 != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_341 = 1;
    fah_matched = zT_341;
    zT_343 = "FAH:r";
    zT_345 = 5;
    zT_344.ptr = (unsigned char*)zT_343;
    zT_344.len = zT_345;
    fam = zT_344;
    zT_346 = fam;
    zT_347 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_346, zT_347);
    zT_349 = s->type_id;
    return zT_349;
    z_bb_62:
    goto z_bb_58;
    z_bb_63:
    zT_353 = "FAH:N";
    zT_355 = 5;
    zT_354.ptr = (unsigned char*)zT_353;
    zT_354.len = zT_355;
    fnm = zT_354;
    zT_356 = fnm;
    zT_357 = node_idx;
    zF_C914CB83_markerWriteInt(zT_356, zT_357);
    goto z_bb_64;
    z_bb_64:
    goto z_bb_36;
    z_bb_65:
    zT_364 = env->typereg;
    zT_365 = zT_364->xn_len;
    zT_366 = (unsigned int)zT_365;
    zT_367 = 0;
    zT_363[zT_367] = zT_366;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_363[_i];
        _i++;
    }
}
    zT_370 = 0;
    zT_371 = 0;
    zT_369[zT_371] = zT_370;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_369[_i];
        _i++;
    }
}
    zT_372 = env->store;
    zT_373 = node_idx;
    zT_375 = zF_8BA26B9E_astStoreNodePayload(zT_372, zT_373);
    if ((unsigned char)(zT_375 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_420 = node.kind;
    if ((unsigned char)(zT_420 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_67:
    zT_379 = env->store;
    zT_380 = node_idx;
    zT_382 = zF_152E19CB_astStoreNodeExtraCh(zT_379, zT_380);
    esd_children_n = zT_382;
    zT_383 = (unsigned short)zig_cast_checked_u((zu64)esd_children_n, 32u, 0u, 16u);
    zT_384 = 0;
    zT_386 = (unsigned int)zT_384 < (unsigned int)(1);
    if (!(zT_386)) { pal_trap(); }
    esd_count_box[zT_384] = zT_383;
    zT_388 = 0;
    zT_389 = (unsigned int)zT_388;
    esd_i = zT_389;
    goto z_bb_69;
    z_bb_68:
    zT_407 = env->typereg;
    zT_411 = 0;
    zT_413 = (unsigned int)zT_411 < (unsigned int)(1);
    if (!(zT_413)) { pal_trap(); }
    zT_408 = esd_start_box[zT_411];
    zT_415 = 0;
    zT_417 = (unsigned int)zT_415 < (unsigned int)(1);
    if (!(zT_417)) { pal_trap(); }
    zT_409 = esd_count_box[zT_415];
    zT_419 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_407, zT_408, zT_409);
    return zT_419;
    z_bb_69:
    if ((unsigned char)(esd_i < (unsigned int)((unsigned int)esd_children_n))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_392 = env->typereg;
    zT_395 = env->store;
    zT_396 = node_idx;
    zT_400 = zF_B10B1BC1_astStoreNodeExtraCh(zT_395, zT_396, (unsigned int)((unsigned int)esd_i));
    zT_393 = zT_400;
    zF_A648B1CB_xnAppend(zT_392, zT_393);
    goto z_bb_72;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    zT_401 = 1;
    zT_402 = (unsigned int)zT_401;
    zT_403 = zig_wrap_add_u(((zu64)(esd_i)), ((zu64)(zT_402)), 32u);
    zT_404 = zig_overflow_flag_add_u(((zu64)(esd_i)), ((zu64)(zT_402)), 32u);
    zT_406 = zT_404 == (unsigned int)(0);
    if (!(zT_406)) { pal_trap(); }
    esd_i = zT_403;
    goto z_bb_69;
    z_bb_73:
    zT_425 = env;
    zT_426 = node.child_1;
    zT_429 = 1;
    zT_430 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_429)), 32u);
    zT_431 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_429)), 32u);
    zT_433 = zT_431 == (unsigned int)(0);
    if (!(zT_433)) { pal_trap(); }
    zT_427 = zT_430;
    zT_434 = zF_F2107C15_resolveTypeExprFull(zT_425, zT_426, zT_427);
    eu_payload_type = zT_434;
    if ((unsigned char)(eu_payload_type == (unsigned int)(18))) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_475 = node.kind;
    if ((unsigned char)(zT_475 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_75:
    return (unsigned int)(18);
    z_bb_76:
    zT_440 = 0;
    zT_441 = 0;
    zT_439[zT_441] = zT_440;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_439[_i];
        _i++;
    }
}
    zT_442 = node.child_0;
    zT_443 = 0;
    if ((unsigned char)(zT_442 != (unsigned int)zT_443)) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    zT_446 = env;
    zT_447 = node.child_0;
    zT_450 = 1;
    zT_451 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_450)), 32u);
    zT_452 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_450)), 32u);
    zT_454 = zT_452 == (unsigned int)(0);
    if (!(zT_454)) { pal_trap(); }
    zT_448 = zT_451;
    zT_455 = zF_F2107C15_resolveTypeExprFull(zT_446, zT_447, zT_448);
    eu_resolved_es = zT_455;
    if ((unsigned char)(eu_resolved_es == (unsigned int)(18))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    zT_466 = env->typereg;
    zT_467 = eu_payload_type;
    zT_470 = 0;
    zT_472 = (unsigned int)zT_470 < (unsigned int)(1);
    if (!(zT_472)) { pal_trap(); }
    zT_468 = eu_es_box[zT_470];
    zT_474 = zF_16D1A6EE_typeRegistryGetOrCr(zT_466, zT_467, zT_468);
    return zT_474;
    z_bb_79:
    zT_462 = 0;
    zT_463 = 0;
    zT_465 = (unsigned int)zT_463 < (unsigned int)(1);
    if (!(zT_465)) { pal_trap(); }
    eu_es_box[zT_463] = zT_462;
    goto z_bb_78;
    z_bb_80:
    return (unsigned int)(18);
    z_bb_81:
    zT_459 = 0;
    zT_461 = (unsigned int)zT_459 < (unsigned int)(1);
    if (!(zT_461)) { pal_trap(); }
    eu_es_box[zT_459] = eu_resolved_es;
    goto z_bb_78;
    z_bb_82:
    zT_481 = 0;
    zT_482 = 0;
    zT_480[zT_482] = zT_481;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_480[_i];
        _i++;
    }
}
    zT_483 = 1;
    zT_484 = 0;
    zT_486 = (unsigned int)zT_484 < (unsigned int)(1);
    if (!(zT_486)) { pal_trap(); }
    fnt_ret_box[zT_484] = zT_483;
    zT_487 = node.child_0;
    zT_488 = 0;
    if ((unsigned char)(zT_487 != (unsigned int)zT_488)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_791 = node.child_0;
    zT_792 = 0;
    if ((unsigned char)(zT_791 != (unsigned int)zT_792)) goto z_bb_137; else goto z_bb_138;
    z_bb_84:
    zT_490 = env;
    zT_491 = node.child_0;
    zT_494 = 1;
    zT_495 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_494)), 32u);
    zT_496 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_494)), 32u);
    zT_498 = zT_496 == (unsigned int)(0);
    if (!(zT_498)) { pal_trap(); }
    zT_492 = zT_495;
    zT_499 = zF_F2107C15_resolveTypeExprFull(zT_490, zT_491, zT_492);
    zT_500 = 0;
    zT_502 = (unsigned int)zT_500 < (unsigned int)(1);
    if (!(zT_502)) { pal_trap(); }
    fnt_ret_box[zT_500] = zT_499;
    zT_504 = "OPTVOID:fntR";
    zT_506 = 12;
    zT_505.ptr = (unsigned char*)zT_504;
    zT_505.len = zT_506;
    opm2_m = zT_505;
    zT_507 = opm2_m;
    zT_509 = 0;
    zT_511 = (unsigned int)zT_509 < (unsigned int)(1);
    if (!(zT_511)) { pal_trap(); }
    zT_508 = fnt_ret_box[zT_509];
    zF_C914CB83_markerWriteInt(zT_507, zT_508);
    zT_513 = 0;
    zT_515 = (unsigned int)zT_513 < (unsigned int)(1);
    if (!(zT_515)) { pal_trap(); }
    zT_516 = fnt_ret_box[zT_513];
    if ((unsigned char)(zT_516 == (unsigned int)(18))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zig_poison_fill((void*)&zT_521, (unsigned int)sizeof zT_521);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_521[_i];
        _i++;
    }
}
    zT_523 = 0;
    fnt_pc = zT_523;
    zT_524 = env->store;
    zT_525 = node_idx;
    zT_527 = zF_8BA26B9E_astStoreNodePayload(zT_524, zT_525);
    if ((unsigned char)(zT_527 != (unsigned int)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    return (unsigned int)(18);
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_531 = env->store;
    zT_532 = node_idx;
    zT_534 = zF_152E19CB_astStoreNodeExtraCh(zT_531, zT_532);
    fnt_extra_n = zT_534;
    zT_536 = 0;
    fnt_i = zT_536;
    goto z_bb_90;
    z_bb_89:
    zT_574 = 0;
    fnt_conv = zT_574;
    zT_575 = node.flags;
    if ((unsigned char)((unsigned char)(zT_575 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_90:
    if ((unsigned char)(fnt_i < (unsigned int)((unsigned int)fnt_extra_n))) goto z_bb_94; else goto z_bb_95;
    z_bb_91:
    zT_543 = env;
    zT_546 = env->store;
    zT_547 = node_idx;
    zT_551 = zF_B10B1BC1_astStoreNodeExtraCh(zT_546, zT_547, (unsigned int)((unsigned int)fnt_i));
    zT_544 = zT_551;
    zT_552 = 1;
    zT_553 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_552)), 32u);
    zT_554 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_552)), 32u);
    zT_556 = zT_554 == (unsigned int)(0);
    if (!(zT_556)) { pal_trap(); }
    zT_545 = zT_553;
    zT_557 = zF_F2107C15_resolveTypeExprFull(zT_543, zT_544, zT_545);
    fnt_pt = zT_557;
    if ((unsigned char)(fnt_pt == (unsigned int)(18))) goto z_bb_97; else goto z_bb_98;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_568 = 1;
    zT_569 = zig_wrap_add_u(((zu64)(fnt_i)), ((zu64)(zT_568)), 32u);
    zT_570 = zig_overflow_flag_add_u(((zu64)(fnt_i)), ((zu64)(zT_568)), 32u);
    zT_572 = zT_570 == (unsigned int)(0);
    if (!(zT_572)) { pal_trap(); }
    fnt_i = zT_569;
    goto z_bb_90;
    z_bb_94:
    zT_539 = fnt_pc < (unsigned int)(16);
    goto z_bb_96;
    z_bb_95:
    zT_539 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_539) goto z_bb_91; else goto z_bb_92;
    z_bb_97:
    return (unsigned int)(18);
    z_bb_98:
    zT_562 = fnt_pc < (unsigned int)(16);
    if (!(zT_562)) { pal_trap(); }
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_563 = 1;
    zT_564 = zig_wrap_add_u(((zu64)(fnt_pc)), ((zu64)(zT_563)), 32u);
    zT_565 = zig_overflow_flag_add_u(((zu64)(fnt_pc)), ((zu64)(zT_563)), 32u);
    zT_567 = zT_565 == (unsigned int)(0);
    if (!(zT_567)) { pal_trap(); }
    fnt_pc = zT_564;
    goto z_bb_93;
    z_bb_99:
    zT_580 = 1;
    fnt_conv = zT_580;
    goto z_bb_100;
    z_bb_100:
    zig_poison_fill((void*)&zT_582, (unsigned int)sizeof zT_582);
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_582[_i];
        _i++;
    }
}
    zT_584 = 0;
    fnt_np = zT_584;
    zT_586 = "fnt_";
    zT_588 = 4;
    zT_587.ptr = (unsigned char*)zT_586;
    zT_587.len = zT_588;
    fnt_pre = zT_587;
    if ((unsigned char)(fnt_conv == (unsigned char)(1))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_591 = "fnts_";
    zT_593 = 5;
    zT_592.ptr = (unsigned char*)zT_591;
    zT_592.len = zT_593;
    fnt_pre = zT_592;
    goto z_bb_102;
    z_bb_102:
    zT_595 = 0;
    fnt_pri = zT_595;
    goto z_bb_103;
    z_bb_103:
    zT_597 = fnt_pre.len;
    if ((unsigned char)(fnt_pri < zT_597)) goto z_bb_107; else goto z_bb_108;
    z_bb_104:
    zT_602 = fnt_pre.ptr;
    zT_603 = fnt_pre.len;
    zT_604 = fnt_pri < zT_603;
    if (!(zT_604)) { pal_trap(); }
    zT_605 = zT_602[fnt_pri];
    zT_607 = fnt_np < (unsigned int)(96);
    if (!(zT_607)) { pal_trap(); }
    fnt_nb[fnt_np] = zT_605;
    zT_608 = 1;
    zT_609 = zig_wrap_add_u(((zu64)(fnt_np)), ((zu64)(zT_608)), 32u);
    zT_610 = zig_overflow_flag_add_u(((zu64)(fnt_np)), ((zu64)(zT_608)), 32u);
    zT_612 = zT_610 == (unsigned int)(0);
    if (!(zT_612)) { pal_trap(); }
    fnt_np = zT_609;
    goto z_bb_106;
    z_bb_105:
    zig_poison_fill((void*)&zT_619, (unsigned int)sizeof zT_619);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_619[_i];
        _i++;
    }
}
    zT_623 = 0;
    zT_625 = (unsigned int)zT_623 < (unsigned int)(1);
    if (!(zT_625)) { pal_trap(); }
    zT_621 = fnt_ret_box[zT_623];
    zT_629 = 0;
    zT_630 = (unsigned char*)((unsigned char*)fnt_rb) + zT_629;
    zT_631 = (unsigned int)(12) - zT_629;
    zT_632.ptr = (unsigned char*)zT_630;
    zT_632.len = zT_631;
    zT_622 = zT_632;
    zT_633 = zF_A7504564_itoa(zT_621, zT_622);
    fnt_rl = zT_633;
    zT_635 = 11;
    zT_636 = (unsigned int)fnt_rl;
    zT_637 = zig_wrap_sub_u(((zu64)(zT_635)), ((zu64)(zT_636)), 32u);
    zT_638 = zig_overflow_flag_sub_u(((zu64)(zT_635)), ((zu64)(zT_636)), 32u);
    zT_640 = zT_638 == (unsigned int)(0);
    if (!(zT_640)) { pal_trap(); }
    fnt_rs = zT_637;
    goto z_bb_110;
    z_bb_106:
    zT_613 = 1;
    zT_614 = zig_wrap_add_u(((zu64)(fnt_pri)), ((zu64)(zT_613)), 32u);
    zT_615 = zig_overflow_flag_add_u(((zu64)(fnt_pri)), ((zu64)(zT_613)), 32u);
    zT_617 = zT_615 == (unsigned int)(0);
    if (!(zT_617)) { pal_trap(); }
    fnt_pri = zT_614;
    goto z_bb_103;
    z_bb_107:
    zT_599 = fnt_np < (unsigned int)(95);
    goto z_bb_109;
    z_bb_108:
    zT_599 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_599) goto z_bb_104; else goto z_bb_105;
    z_bb_110:
    if ((unsigned char)(fnt_rs < (unsigned int)(11))) goto z_bb_114; else goto z_bb_115;
    z_bb_111:
    zT_647 = fnt_rs < (unsigned int)(12);
    if (!(zT_647)) { pal_trap(); }
    zT_648 = fnt_rb[fnt_rs];
    zT_650 = fnt_np < (unsigned int)(96);
    if (!(zT_650)) { pal_trap(); }
    fnt_nb[fnt_np] = zT_648;
    zT_651 = 1;
    zT_652 = zig_wrap_add_u(((zu64)(fnt_np)), ((zu64)(zT_651)), 32u);
    zT_653 = zig_overflow_flag_add_u(((zu64)(fnt_np)), ((zu64)(zT_651)), 32u);
    zT_655 = zT_653 == (unsigned int)(0);
    if (!(zT_655)) { pal_trap(); }
    fnt_np = zT_652;
    goto z_bb_113;
    z_bb_112:
    zT_662 = 0;
    fnt_k = zT_662;
    goto z_bb_117;
    z_bb_113:
    zT_656 = 1;
    zT_657 = zig_wrap_add_u(((zu64)(fnt_rs)), ((zu64)(zT_656)), 32u);
    zT_658 = zig_overflow_flag_add_u(((zu64)(fnt_rs)), ((zu64)(zT_656)), 32u);
    zT_660 = zT_658 == (unsigned int)(0);
    if (!(zT_660)) { pal_trap(); }
    fnt_rs = zT_657;
    goto z_bb_110;
    z_bb_114:
    zT_643 = fnt_np < (unsigned int)(95);
    goto z_bb_116;
    z_bb_115:
    zT_643 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_643) goto z_bb_111; else goto z_bb_112;
    z_bb_117:
    if ((unsigned char)(fnt_k < fnt_pc)) goto z_bb_121; else goto z_bb_122;
    z_bb_118:
    if ((unsigned char)(fnt_np < (unsigned int)(95))) goto z_bb_124; else goto z_bb_125;
    z_bb_119:
    zT_725 = env->interner;
    zT_730 = 0;
    zT_731 = (unsigned char*)((unsigned char*)fnt_nb) + zT_730;
    zT_732 = fnt_np - zT_730;
    zT_733 = (unsigned int)zT_730 <= fnt_np;
    if (!(zT_733)) { pal_trap(); }
    zT_734 = fnt_np <= (unsigned int)(96);
    if (!(zT_734)) { pal_trap(); }
    zT_735.ptr = (unsigned char*)zT_731;
    zT_735.len = zT_732;
    zT_726 = zT_735;
    zT_736 = zF_50C274AF_stringInternerInter(zT_725, zT_726);
    fnt_name_id = zT_736;
    zT_738 = env->typereg;
    zT_739 = zT_738->xt_len;
    zT_740 = (unsigned int)zT_739;
    fnt_pstart = zT_740;
    zT_742 = 0;
    fnt_a = zT_742;
    goto z_bb_133;
    z_bb_120:
    zT_719 = 1;
    zT_720 = zig_wrap_add_u(((zu64)(fnt_k)), ((zu64)(zT_719)), 32u);
    zT_721 = zig_overflow_flag_add_u(((zu64)(fnt_k)), ((zu64)(zT_719)), 32u);
    zT_723 = zT_721 == (unsigned int)(0);
    if (!(zT_723)) { pal_trap(); }
    fnt_k = zT_720;
    goto z_bb_117;
    z_bb_121:
    zT_664 = fnt_np < (unsigned int)(95);
    goto z_bb_123;
    z_bb_122:
    zT_664 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_664) goto z_bb_118; else goto z_bb_119;
    z_bb_124:
    zT_669 = 95;
    zT_671 = fnt_np < (unsigned int)(96);
    if (!(zT_671)) { pal_trap(); }
    fnt_nb[fnt_np] = zT_669;
    zT_672 = 1;
    zT_673 = zig_wrap_add_u(((zu64)(fnt_np)), ((zu64)(zT_672)), 32u);
    zT_674 = zig_overflow_flag_add_u(((zu64)(fnt_np)), ((zu64)(zT_672)), 32u);
    zT_676 = zT_674 == (unsigned int)(0);
    if (!(zT_676)) { pal_trap(); }
    fnt_np = zT_673;
    goto z_bb_125;
    z_bb_125:
    zig_poison_fill((void*)&zT_678, (unsigned int)sizeof zT_678);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_678[_i];
        _i++;
    }
}
    zT_683 = fnt_k < (unsigned int)(16);
    if (!(zT_683)) { pal_trap(); }
    zT_680 = fnt_ptypes[fnt_k];
    zT_687 = 0;
    zT_688 = (unsigned char*)((unsigned char*)fnt_pb) + zT_687;
    zT_689 = (unsigned int)(12) - zT_687;
    zT_690.ptr = (unsigned char*)zT_688;
    zT_690.len = zT_689;
    zT_681 = zT_690;
    zT_691 = zF_A7504564_itoa(zT_680, zT_681);
    fnt_pl = zT_691;
    zT_693 = 11;
    zT_694 = (unsigned int)fnt_pl;
    zT_695 = zig_wrap_sub_u(((zu64)(zT_693)), ((zu64)(zT_694)), 32u);
    zT_696 = zig_overflow_flag_sub_u(((zu64)(zT_693)), ((zu64)(zT_694)), 32u);
    zT_698 = zT_696 == (unsigned int)(0);
    if (!(zT_698)) { pal_trap(); }
    fnt_ps = zT_695;
    goto z_bb_126;
    z_bb_126:
    if ((unsigned char)(fnt_ps < (unsigned int)(11))) goto z_bb_130; else goto z_bb_131;
    z_bb_127:
    zT_705 = fnt_ps < (unsigned int)(12);
    if (!(zT_705)) { pal_trap(); }
    zT_706 = fnt_pb[fnt_ps];
    zT_708 = fnt_np < (unsigned int)(96);
    if (!(zT_708)) { pal_trap(); }
    fnt_nb[fnt_np] = zT_706;
    zT_709 = 1;
    zT_710 = zig_wrap_add_u(((zu64)(fnt_np)), ((zu64)(zT_709)), 32u);
    zT_711 = zig_overflow_flag_add_u(((zu64)(fnt_np)), ((zu64)(zT_709)), 32u);
    zT_713 = zT_711 == (unsigned int)(0);
    if (!(zT_713)) { pal_trap(); }
    fnt_np = zT_710;
    goto z_bb_129;
    z_bb_128:
    goto z_bb_120;
    z_bb_129:
    zT_714 = 1;
    zT_715 = zig_wrap_add_u(((zu64)(fnt_ps)), ((zu64)(zT_714)), 32u);
    zT_716 = zig_overflow_flag_add_u(((zu64)(fnt_ps)), ((zu64)(zT_714)), 32u);
    zT_718 = zT_716 == (unsigned int)(0);
    if (!(zT_718)) { pal_trap(); }
    fnt_ps = zT_715;
    goto z_bb_126;
    z_bb_130:
    zT_701 = fnt_np < (unsigned int)(95);
    goto z_bb_132;
    z_bb_131:
    zT_701 = 0;
    goto z_bb_132;
    z_bb_132:
    if (zT_701) goto z_bb_127; else goto z_bb_128;
    z_bb_133:
    if ((unsigned char)(fnt_a < fnt_pc)) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    zT_744 = env->typereg;
    zT_748 = fnt_a < (unsigned int)(16);
    if (!(zT_748)) { pal_trap(); }
    zT_745 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_744, zT_745);
    goto z_bb_136;
    z_bb_135:
    zT_756 = env->typereg;
    zT_757 = fnt_name_id;
    zT_762 = (unsigned short)zig_cast_checked_u((zu64)fnt_pc, 32u, 0u, 16u);
    zT_771 = 0;
    zT_773 = (unsigned int)zT_771 < (unsigned int)(1);
    if (!(zT_773)) { pal_trap(); }
    zT_763 = fnt_ret_box[zT_771];
    zT_764 = fnt_conv;
    zT_775 = zF_474336D7_typeRegistryGetOrCr(zT_756, zT_757, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), zT_762, zT_763, zT_764);
    fnt_tid = zT_775;
    zT_777 = "OPTVOID:fntT";
    zT_779 = 12;
    zT_778.ptr = (unsigned char*)zT_777;
    zT_778.len = zT_779;
    opm3_m = zT_778;
    zT_780 = opm3_m;
    zT_781 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_780, zT_781);
    zT_782 = env->typereg;
    zT_783 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_782, zT_783);
    zT_785 = env->typereg;
    zT_786 = fnt_tid;
    zT_790 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_785, zT_786, (unsigned char)(0));
    return zT_790;
    z_bb_136:
    zT_750 = 1;
    zT_751 = zig_wrap_add_u(((zu64)(fnt_a)), ((zu64)(zT_750)), 32u);
    zT_752 = zig_overflow_flag_add_u(((zu64)(fnt_a)), ((zu64)(zT_750)), 32u);
    zT_754 = zT_752 == (unsigned int)(0);
    if (!(zT_754)) { pal_trap(); }
    fnt_a = zT_751;
    goto z_bb_133;
    z_bb_137:
    zT_795 = node.kind;
    zT_799 = zF_C395F6FD_nodeChildIsNode(zT_795, (unsigned char)(0));
    zT_794 = zT_799;
    goto z_bb_139;
    z_bb_138:
    zT_794 = 0;
    goto z_bb_139;
    z_bb_139:
    if (zT_794) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    zT_800 = node.kind;
    if ((unsigned char)(zT_800 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_143; else goto z_bb_142;
    z_bb_141:
    zT_1132 = "UND:n";
    zT_1134 = 5;
    zT_1133.ptr = (unsigned char*)zT_1132;
    zT_1133.len = zT_1134;
    und_nm2 = zT_1133;
    zT_1135 = und_nm2;
    zT_1136 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1135, zT_1136);
    zT_1138 = "UND:k";
    zT_1140 = 5;
    zT_1139.ptr = (unsigned char*)zT_1138;
    zT_1139.len = zT_1140;
    und_km = zT_1139;
    zT_1141 = und_km;
    zT_1143 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1141, (unsigned int)((unsigned int)zT_1143));
    return (unsigned int)(18);
    z_bb_142:
    zT_805 = node.kind;
    zT_804 = zT_805 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_144;
    z_bb_143:
    zT_804 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_804) goto z_bb_146; else goto z_bb_145;
    z_bb_145:
    zT_810 = node.kind;
    zT_809 = zT_810 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_147;
    z_bb_146:
    zT_809 = 1;
    goto z_bb_147;
    z_bb_147:
    if (zT_809) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    zT_815 = env->store;
    zT_816 = env->interner;
    zT_817 = node.child_0;
    zT_821 = zF_54996FA4_typeResolverIsInfer(zT_815, zT_816, zT_817);
    zT_814 = zT_821;
    goto z_bb_150;
    z_bb_149:
    zT_814 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_814) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    return (unsigned int)(18);
    z_bb_152:
    zT_824 = env;
    zT_825 = node.child_0;
    zT_828 = 1;
    zT_829 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_828)), 32u);
    zT_830 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_828)), 32u);
    zT_832 = zT_830 == (unsigned int)(0);
    if (!(zT_832)) { pal_trap(); }
    zT_826 = zT_829;
    zT_833 = zF_F2107C15_resolveTypeExprFull(zT_824, zT_825, zT_826);
    child_type = zT_833;
    if ((unsigned char)(child_type == (unsigned int)(18))) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    return (unsigned int)(18);
    z_bb_154:
    zT_837 = node.kind;
    if ((unsigned char)(zT_837 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_156; else goto z_bb_155;
    z_bb_155:
    zT_842 = node.kind;
    zT_841 = zT_842 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_157;
    z_bb_156:
    zT_841 = 1;
    goto z_bb_157;
    z_bb_157:
    if (zT_841) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_847 = "PTR:i";
    zT_849 = 5;
    zT_848.ptr = (unsigned char*)zT_847;
    zT_848.len = zT_849;
    ptm = zT_848;
    zT_850 = ptm;
    zF_48AC7B3A_markerWrite(zT_850);
    zT_851 = node_idx;
    zF_C8A36147_markerU32(zT_851);
    zT_853 = "k";
    zT_855 = 1;
    zT_854.ptr = (unsigned char*)zT_853;
    zT_854.len = zT_855;
    ptkm = zT_854;
    zT_856 = ptkm;
    zF_48AC7B3A_markerWrite(zT_856);
    zT_858 = node.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_858));
    zT_861 = "c";
    zT_863 = 1;
    zT_862.ptr = (unsigned char*)zT_861;
    zT_862.len = zT_863;
    ptcm = zT_862;
    zT_864 = ptcm;
    zF_48AC7B3A_markerWrite(zT_864);
    zT_865 = child_type;
    zF_C8A36147_markerU32(zT_865);
    zT_867 = node.flags;
    zT_871 = (unsigned char)(zT_867 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_871;
    zT_873 = node.flags;
    zT_877 = (unsigned char)(zT_873 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_877;
    zT_878 = node.kind;
    if ((unsigned char)(zT_878 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_160; else goto z_bb_162;
    z_bb_159:
    zT_918 = node.kind;
    if ((unsigned char)(zT_918 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_163; else goto z_bb_164;
    z_bb_160:
    zT_883 = env->typereg;
    zT_884 = child_type;
    zT_885 = is_const;
    zT_886 = is_volatile;
    zT_888 = zF_0C0306D6_typeRegistryGetOrCr(zT_883, zT_884, zT_885, zT_886);
    ptr_tid = zT_888;
    zT_890 = "P";
    zT_892 = 1;
    zT_891.ptr = (unsigned char*)zT_890;
    zT_891.len = zT_892;
    ppm = zT_891;
    zT_893 = ppm;
    zF_48AC7B3A_markerWrite(zT_893);
    zT_894 = ptr_tid;
    zF_C8A36147_markerU32(zT_894);
    zT_896 = "\n";
    zT_898 = 1;
    zT_897.ptr = (unsigned char*)zT_896;
    zT_897.len = zT_898;
    pnl = zT_897;
    zT_899 = pnl;
    zF_48AC7B3A_markerWrite(zT_899);
    return ptr_tid;
    goto z_bb_159;
    z_bb_162:
    zT_901 = env->typereg;
    zT_902 = child_type;
    zT_903 = is_const;
    zT_904 = is_volatile;
    zT_906 = zF_827207A1_typeRegistryGetOrCr(zT_901, zT_902, zT_903, zT_904);
    ptr_tid2 = zT_906;
    zT_908 = "M";
    zT_910 = 1;
    zT_909.ptr = (unsigned char*)zT_908;
    zT_909.len = zT_910;
    ppm2 = zT_909;
    zT_911 = ppm2;
    zF_48AC7B3A_markerWrite(zT_911);
    zT_912 = ptr_tid2;
    zF_C8A36147_markerU32(zT_912);
    zT_914 = "\n";
    zT_916 = 1;
    zT_915.ptr = (unsigned char*)zT_914;
    zT_915.len = zT_916;
    pnl2 = zT_915;
    zT_917 = pnl2;
    zF_48AC7B3A_markerWrite(zT_917);
    return ptr_tid2;
    z_bb_163:
    zT_923 = node.flags;
    zT_927 = (unsigned char)(zT_923 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_927;
    zT_929 = env->typereg;
    zT_930 = child_type;
    zT_931 = is_const;
    zT_933 = zF_8FC81A87_typeRegistryGetOrCr(zT_929, zT_930, zT_931);
    sl_tid = zT_933;
    zT_935 = "SL:e";
    zT_937 = 4;
    zT_936.ptr = (unsigned char*)zT_935;
    zT_936.len = zT_937;
    sm = zT_936;
    zT_938 = sm;
    zF_48AC7B3A_markerWrite(zT_938);
    zT_939 = child_type;
    zF_C8A36147_markerU32(zT_939);
    zT_941 = "s";
    zT_943 = 1;
    zT_942.ptr = (unsigned char*)zT_941;
    zT_942.len = zT_943;
    s2 = zT_942;
    zT_944 = s2;
    zF_48AC7B3A_markerWrite(zT_944);
    zT_945 = sl_tid;
    zF_C8A36147_markerU32(zT_945);
    zT_947 = "\n";
    zT_949 = 1;
    zT_948.ptr = (unsigned char*)zT_947;
    zT_948.len = zT_949;
    s3 = zT_948;
    zT_950 = s3;
    zF_48AC7B3A_markerWrite(zT_950);
    return sl_tid;
    z_bb_164:
    zT_951 = node.kind;
    if ((unsigned char)(zT_951 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_956 = "OPTVOID:opt";
    zT_958 = 11;
    zT_957.ptr = (unsigned char*)zT_956;
    zT_957.len = zT_958;
    optvd_m = zT_957;
    zT_959 = optvd_m;
    zT_960 = child_type;
    zF_C914CB83_markerWriteInt(zT_959, zT_960);
    zT_962 = env->typereg;
    zT_963 = child_type;
    zT_965 = zF_74A7234F_typeRegistryGetOrCr(zT_962, zT_963);
    optvd_tid = zT_965;
    zT_967 = "OPTVOID:optR";
    zT_969 = 12;
    zT_968.ptr = (unsigned char*)zT_967;
    zT_968.len = zT_969;
    optvd_rm = zT_968;
    zT_970 = optvd_rm;
    zT_971 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_970, zT_971);
    return optvd_tid;
    z_bb_166:
    zT_972 = node.kind;
    if ((unsigned char)(zT_972 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_977 = "T0";
    zT_979 = 2;
    zT_978.ptr = (unsigned char*)zT_977;
    zT_978.len = zT_979;
    t0m = zT_978;
    zT_980 = t0m;
    zF_48AC7B3A_markerWrite(zT_980);
    zT_982 = "T1e";
    zT_984 = 3;
    zT_983.ptr = (unsigned char*)zT_982;
    zT_983.len = zT_984;
    t1m = zT_983;
    zT_985 = t1m;
    zF_48AC7B3A_markerWrite(zT_985);
    zT_986 = child_type;
    zF_C8A36147_markerU32(zT_986);
    zT_987 = node.child_1;
    zT_988 = 0;
    if ((unsigned char)(zT_987 != (unsigned int)zT_988)) goto z_bb_169; else goto z_bb_170;
    z_bb_168:
    goto z_bb_141;
    z_bb_169:
    zT_991 = env->store;
    zT_992 = node.child_1;
    zT_995 = zF_FCDD1D35_astStoreNodeAt(zT_991, zT_992);
    sz_node = zT_995;
    zT_997 = 0;
    arr_len = zT_997;
    zT_999 = 0;
    arr_resolved = zT_999;
    zT_1001 = env;
    zT_1002 = node.child_1;
    zT_1006 = zF_6D0DD27D_evalConstU32Full(zT_1001, zT_1002, (unsigned int)(0));
    alf = zT_1006;
    if ((unsigned char)(alf != (unsigned int)(4294967295u))) goto z_bb_171; else goto z_bb_172;
    z_bb_170:
    return (unsigned int)(18);
    z_bb_171:
    arr_len = alf;
    zT_1009 = 1;
    arr_resolved = zT_1009;
    goto z_bb_172;
    z_bb_172:
    zT_1011 = "T2L";
    zT_1013 = 3;
    zT_1012.ptr = (unsigned char*)zT_1011;
    zT_1012.len = zT_1013;
    t2m = zT_1012;
    zT_1014 = t2m;
    zF_48AC7B3A_markerWrite(zT_1014);
    zT_1015 = arr_len;
    zF_C8A36147_markerU32(zT_1015);
    if (arr_resolved) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_1017 = env->typereg;
    zT_1018 = child_type;
    zT_1019 = arr_len;
    zT_1021 = zF_BA693C74_typeRegistryGetOrCr(zT_1017, zT_1018, zT_1019);
    at = zT_1021;
    zT_1023 = "T3a";
    zT_1025 = 3;
    zT_1024.ptr = (unsigned char*)zT_1023;
    zT_1024.len = zT_1025;
    t3m = zT_1024;
    zT_1026 = t3m;
    zF_48AC7B3A_markerWrite(zT_1026);
    zT_1027 = at;
    zF_C8A36147_markerU32(zT_1027);
    if ((unsigned char)(at != (unsigned int)(18))) goto z_bb_175; else goto z_bb_177;
    z_bb_174:
    zT_1041 = 0;
    sz_is_inferred = zT_1041;
    zT_1042 = sz_node.kind;
    if ((unsigned char)(zT_1042 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_178; else goto z_bb_179;
    z_bb_175:
    zT_1031 = "A";
    zT_1033 = 1;
    zT_1032.ptr = (unsigned char*)zT_1031;
    zT_1032.len = zT_1033;
    am = zT_1032;
    zT_1034 = am;
    zF_48AC7B3A_markerWrite(zT_1034);
    goto z_bb_176;
    z_bb_176:
    return at;
    z_bb_177:
    zT_1036 = "a";
    zT_1038 = 1;
    zT_1037.ptr = (unsigned char*)zT_1036;
    zT_1037.len = zT_1038;
    am = zT_1037;
    zT_1039 = am;
    zF_48AC7B3A_markerWrite(zT_1039);
    goto z_bb_176;
    z_bb_178:
    zT_1047 = env->store;
    zT_1048 = node.child_1;
    zT_1051 = zF_53458827_astStoreIdentifier(zT_1047, zT_1048);
    sz_name = zT_1051;
    zT_1053 = env->interner;
    zT_1054 = sz_name;
    zT_1056 = zF_9134020D_stringInternerGet(zT_1053, zT_1054);
    sz_text = zT_1056;
    zT_1058 = sz_text.len;
    if ((unsigned char)(zT_1058 == (unsigned int)(1))) goto z_bb_180; else goto z_bb_181;
    z_bb_179:
    if (sz_is_inferred) goto z_bb_185; else goto z_bb_187;
    z_bb_180:
    zT_1062 = sz_text.ptr;
    zT_1063 = 0;
    zT_1064 = sz_text.len;
    zT_1065 = (unsigned int)zT_1063 < zT_1064;
    if (!(zT_1065)) { pal_trap(); }
    zT_1066 = zT_1062[zT_1063];
    zT_1061 = zT_1066 == (unsigned char)(95);
    goto z_bb_182;
    z_bb_181:
    zT_1061 = 0;
    goto z_bb_182;
    z_bb_182:
    if (zT_1061) goto z_bb_183; else goto z_bb_184;
    z_bb_183:
    zT_1069 = 1;
    sz_is_inferred = zT_1069;
    goto z_bb_184;
    z_bb_184:
    goto z_bb_179;
    z_bb_185:
    zT_1070 = env->diag;
    zT_1071 = zT_1070.has_value;
    if (zT_1071) goto z_bb_188; else goto z_bb_189;
    z_bb_186:
    goto z_bb_170;
    z_bb_187:
    zT_1099 = env->diag;
    zT_1100 = zT_1099.has_value;
    if (zT_1100) goto z_bb_192; else goto z_bb_193;
    z_bb_188:
    if (!(zT_1070.has_value)) { pal_trap(); }
    dg = zT_1070.value;
    zT_1073 = dg;
    zT_1074 = node_idx;
    zT_1075 = zF_4DD9DB2D_diagnosticCollector(zT_1073, zT_1074);
    if (zT_1075) goto z_bb_190; else goto z_bb_191;
    z_bb_189:
    goto z_bb_186;
    z_bb_190:
    zT_1077 = "unable to infer array size";
    zT_1079 = 26;
    zT_1078.ptr = (unsigned char*)zT_1077;
    zT_1078.len = zT_1079;
    ail_msg = zT_1078;
    zT_1080 = dg;
    zT_1083 = env->source_file_id;
    zT_1084 = sz_node.span_start;
    zT_1091 = sz_node.span_start;
    zT_1092 = sz_node.span_len;
    zT_1093 = (unsigned int)zT_1092;
    zT_1094 = zig_wrap_add_u(((zu64)(zT_1091)), ((zu64)(zT_1093)), 32u);
    zT_1095 = zig_overflow_flag_add_u(((zu64)(zT_1091)), ((zu64)(zT_1093)), 32u);
    zT_1097 = zT_1095 == (unsigned int)(0);
    if (!(zT_1097)) { pal_trap(); }
    zT_1085 = zT_1094;
    zT_1086 = ail_msg;
    zT_1098 = zF_C82559AC_diagnosticCollector(zT_1080, (unsigned char)(0), (unsigned short)(3000), zT_1083, zT_1084, zT_1085, zT_1086);
    (void)zT_1098;
    goto z_bb_191;
    z_bb_191:
    goto z_bb_189;
    z_bb_192:
    if (!(zT_1099.has_value)) { pal_trap(); }
    dg = zT_1099.value;
    zT_1102 = dg;
    zT_1103 = node_idx;
    zT_1104 = zF_4DD9DB2D_diagnosticCollector(zT_1102, zT_1103);
    if (zT_1104) goto z_bb_194; else goto z_bb_195;
    z_bb_193:
    goto z_bb_186;
    z_bb_194:
    zT_1106 = "array size is not a constant expression";
    zT_1108 = 39;
    zT_1107.ptr = (unsigned char*)zT_1106;
    zT_1107.len = zT_1108;
    asn_msg = zT_1107;
    zT_1109 = dg;
    zT_1112 = env->source_file_id;
    zT_1113 = sz_node.span_start;
    zT_1122 = sz_node.span_start;
    zT_1123 = sz_node.span_len;
    zT_1124 = (unsigned int)zT_1123;
    zT_1125 = zig_wrap_add_u(((zu64)(zT_1122)), ((zu64)(zT_1124)), 32u);
    zT_1126 = zig_overflow_flag_add_u(((zu64)(zT_1122)), ((zu64)(zT_1124)), 32u);
    zT_1128 = zT_1126 == (unsigned int)(0);
    if (!(zT_1128)) { pal_trap(); }
    zT_1114 = zT_1125;
    zT_1115 = asn_msg;
    zT_1129 = zF_C82559AC_diagnosticCollector(zT_1109, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3050_ARRAY_SIZE_NOT_CONSTANT)), zT_1112, zT_1113, zT_1114, zT_1115);
    (void)zT_1129;
    goto z_bb_195;
    z_bb_195:
    goto z_bb_193;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_79FAE712_u64 zT_18;
    zT_79FAE712_u64 zT_19;
    zT_79FAE712_u64 zT_20;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    zT_BAEE192E_Opt_10 zT_32;
    unsigned char zT_33;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    zT_D155D06D_Type zT_39;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    int zT_47;
    unsigned int zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_406493CE_StructPayload* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_406493CE_StructPayload zT_58;
    unsigned short zT_59;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_74;
    zT_8143F551_AstKind zT_75;
    unsigned char zT_79;
    unsigned int zT_80;
    int zT_81;
    zT_ABC1EBBE_TypeResolveEnv* zT_84;
    unsigned int zT_85;
    unsigned int zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_2DF01B61_FieldEntry* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    zT_2DF01B61_FieldEntry* zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_338B7C76_TypeRegistry* zT_147;
    zT_666DC2E1_TuplePayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_666DC2E1_TuplePayload zT_151;
    unsigned short zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    zT_22A7C88B_AstNode zT_167;
    zT_8143F551_AstKind zT_168;
    unsigned char zT_172;
    unsigned int zT_173;
    int zT_174;
    zT_ABC1EBBE_TypeResolveEnv* zT_177;
    unsigned int zT_178;
    unsigned int zT_182;
    zT_ABC1EBBE_TypeResolveEnv* zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned char zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    unsigned int* zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned char zT_196;
    int zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    unsigned char zT_202;
    zT_33EF6BFB_TypeKind zT_203;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_54FF90FA_TaggedUnionPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_54FF90FA_TaggedUnionPayload zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_219;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned short zT_227;
    unsigned short zT_229;
    zT_6B0A7D14_AstStore* zT_233;
    unsigned int zT_234;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int zT_237;
    unsigned int zT_242;
    zT_22A7C88B_AstNode zT_243;
    zT_8143F551_AstKind zT_244;
    unsigned char zT_248;
    unsigned int zT_249;
    int zT_250;
    zT_ABC1EBBE_TypeResolveEnv* zT_253;
    unsigned int zT_254;
    unsigned int zT_258;
    unsigned char* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned char* zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    unsigned int zT_277;
    zT_6B0A7D14_AstStore* zT_278;
    unsigned int zT_279;
    zT_6B0A7D14_AstStore* zT_281;
    unsigned int zT_282;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294;
    unsigned char* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_338B7C76_TypeRegistry* zT_302;
    zT_2DF01B61_FieldEntry* zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned char zT_309;
    zT_2DF01B61_FieldEntry* zT_310;
    unsigned char* zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned int zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned char zT_322;
    unsigned char* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned char* zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned char zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    unsigned char zT_345;
    zT_33EF6BFB_TypeKind zT_346;
    zT_338B7C76_TypeRegistry* zT_351;
    zT_AF9231A2_UnionPayload* zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    zT_AF9231A2_UnionPayload zT_355;
    unsigned short zT_356;
    zT_6B0A7D14_AstStore* zT_360;
    unsigned int zT_361;
    zT_6B0A7D14_AstStore* zT_363;
    unsigned int zT_364;
    unsigned int zT_369;
    zT_22A7C88B_AstNode zT_370;
    zT_8143F551_AstKind zT_371;
    unsigned char zT_375;
    unsigned int zT_376;
    int zT_377;
    zT_ABC1EBBE_TypeResolveEnv* zT_380;
    unsigned int zT_381;
    unsigned int zT_385;
    zT_338B7C76_TypeRegistry* zT_388;
    zT_2DF01B61_FieldEntry* zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    unsigned int zT_393;
    unsigned char zT_395;
    zT_2DF01B61_FieldEntry* zT_396;
    int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned char zT_402;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_162, (unsigned int)sizeof zT_162);
    zig_poison_fill((void*)&zT_167, (unsigned int)sizeof zT_167);
    zig_poison_fill((void*)&zT_182, (unsigned int)sizeof zT_182);
    zig_poison_fill((void*)&zT_188, (unsigned int)sizeof zT_188);
    zig_poison_fill((void*)&zT_242, (unsigned int)sizeof zT_242);
    zig_poison_fill((void*)&zT_243, (unsigned int)sizeof zT_243);
    zig_poison_fill((void*)&zT_258, (unsigned int)sizeof zT_258);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    zig_poison_fill((void*)&zT_288, (unsigned int)sizeof zT_288);
    zig_poison_fill((void*)&zT_369, (unsigned int)sizeof zT_369);
    zig_poison_fill((void*)&zT_370, (unsigned int)sizeof zT_370);
    zig_poison_fill((void*)&zT_385, (unsigned int)sizeof zT_385);
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    unsigned int fchild;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_666DC2E1_TuplePayload tp_t;
    unsigned int tfchild;
    zT_22A7C88B_AstNode tfd;
    unsigned int tft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_18 = (zT_79FAE712_u64)mod_id;
    zT_19 = 32;
    zT_22 = zT_19 < (unsigned int)(64);
    if (!(zT_22)) { pal_trap(); }
    zT_20 = zig_wrap_shl_u(((zu64)(zT_18)), ((zu64)(zT_19)), 64u);
    zT_23 = zig_overflow_flag_shl_u(((zu64)(zT_18)), ((zu64)(zT_19)), 64u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = env->store;
    zT_27 = decl_idx;
    zT_29 = zF_8BA26B9E_astStoreNodePayload(zT_26, zT_27);
    zT_32 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)(zT_20 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_29)));
    spid = zT_32;
    zT_33 = spid.has_value;
    if (zT_33) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(spid.has_value)) { pal_trap(); }
    stid = spid.value;
    zT_36 = env->typereg;
    zT_37 = zT_36->types_items;
    zT_38 = (unsigned int)stid;
    zT_39 = zT_37[zT_38];
    sty = zT_39;
    zT_41 = env->store;
    zT_42 = decl.child_1;
    (void)zF_152E19CB_astStoreNodeExtraCh(zT_41, zT_42);
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    fi2 = zT_48;
    zT_49 = sty.kind;
    if ((unsigned char)(zT_49 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_54 = env->typereg;
    zT_55 = zT_54->st_items;
    zT_56 = sty.payload_idx;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zT_55[zT_57];
    sp = zT_58;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_142 = sty.kind;
    if ((unsigned char)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_59 = sp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_59))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_63 = env->store;
    zT_64 = decl.child_1;
    zT_69 = zF_B10B1BC1_astStoreNodeExtraCh(zT_63, zT_64, (unsigned int)((unsigned int)fi2));
    fchild = zT_69;
    zT_71 = env->store;
    zT_72 = fchild;
    zT_74 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    fd = zT_74;
    zT_75 = fd.kind;
    if ((unsigned char)(zT_75 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_136 = 1;
    zT_137 = (unsigned int)zT_136;
    zT_138 = zig_wrap_add_u(((zu64)(fi2)), ((zu64)(zT_137)), 32u);
    zT_139 = zig_overflow_flag_add_u(((zu64)(fi2)), ((zu64)(zT_137)), 32u);
    zT_141 = zT_139 == (unsigned int)(0);
    if (!(zT_141)) { pal_trap(); }
    fi2 = zT_138;
    goto z_bb_6;
    z_bb_10:
    zT_80 = fd.child_0;
    zT_81 = 0;
    zT_79 = zT_80 != (unsigned int)zT_81;
    goto z_bb_12;
    z_bb_11:
    zT_79 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_79) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_84 = env;
    zT_85 = fd.child_0;
    zT_89 = zF_F2107C15_resolveTypeExprFull(zT_84, zT_85, (unsigned int)(0));
    ft = zT_89;
    zT_91 = "B2:p";
    zT_93 = 4;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    b2_pn = zT_92;
    zT_94 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_96 = env->store;
    zT_97 = fchild;
    zT_99 = zF_8BA26B9E_astStoreNodePayload(zT_96, zT_97);
    zT_95 = zT_99;
    zF_C8A36147_markerU32(zT_95);
    zT_101 = "t";
    zT_103 = 1;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    b2_tn = zT_102;
    zT_104 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_104);
    zT_105 = ft;
    zF_C8A36147_markerU32(zT_105);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_108 = env->typereg;
    zT_109 = zT_108->fe_items;
    zT_110 = sp.fields_start;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zig_wrap_add_u(((zu64)(zT_111)), ((zu64)(fi2)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(zT_111)), ((zu64)(fi2)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    zT_116 = zT_109 + zT_112;
    zT_116->type_id = ft;
    zT_118 = "FSW:n";
    zT_120 = 5;
    zT_119.ptr = (unsigned char*)zT_118;
    zT_119.len = zT_120;
    fsw_nm = zT_119;
    zT_121 = fsw_nm;
    zT_123 = sp.fields_start;
    zT_124 = (unsigned int)zT_123;
    zT_125 = zig_wrap_add_u(((zu64)(zT_124)), ((zu64)(fi2)), 32u);
    zT_126 = zig_overflow_flag_add_u(((zu64)(zT_124)), ((zu64)(fi2)), 32u);
    zT_128 = zT_126 == (unsigned int)(0);
    if (!(zT_128)) { pal_trap(); }
    zF_C914CB83_markerWriteInt(zT_121, (unsigned int)((unsigned int)zT_125));
    zT_131 = "FSW:t";
    zT_133 = 5;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    fsw_tm = zT_132;
    zT_134 = fsw_tm;
    zT_135 = ft;
    zF_C914CB83_markerWriteInt(zT_134, zT_135);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_147 = env->typereg;
    zT_148 = zT_147->tup_items;
    zT_149 = sty.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    tp_t = zT_151;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_203 = sty.kind;
    if ((unsigned char)(zT_203 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_31; else goto z_bb_33;
    z_bb_20:
    zT_152 = tp_t.elems_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_152))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_156 = env->store;
    zT_157 = decl.child_1;
    zT_162 = zF_B10B1BC1_astStoreNodeExtraCh(zT_156, zT_157, (unsigned int)((unsigned int)fi2));
    tfchild = zT_162;
    zT_164 = env->store;
    zT_165 = tfchild;
    zT_167 = zF_FCDD1D35_astStoreNodeAt(zT_164, zT_165);
    tfd = zT_167;
    zT_168 = tfd.kind;
    if ((unsigned char)(zT_168 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_197 = 1;
    zT_198 = (unsigned int)zT_197;
    zT_199 = zig_wrap_add_u(((zu64)(fi2)), ((zu64)(zT_198)), 32u);
    zT_200 = zig_overflow_flag_add_u(((zu64)(fi2)), ((zu64)(zT_198)), 32u);
    zT_202 = zT_200 == (unsigned int)(0);
    if (!(zT_202)) { pal_trap(); }
    fi2 = zT_199;
    goto z_bb_20;
    z_bb_24:
    zT_173 = tfd.child_0;
    zT_174 = 0;
    zT_172 = zT_173 != (unsigned int)zT_174;
    goto z_bb_26;
    z_bb_25:
    zT_172 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_172) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_177 = env;
    zT_178 = tfd.child_0;
    zT_182 = zF_F2107C15_resolveTypeExprFull(zT_177, zT_178, (unsigned int)(0));
    tft = zT_182;
    if ((unsigned char)(tft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_185 = env;
    zT_186 = tft;
    zT_187 = tfchild;
    zT_188 = zF_E2A017C6_tupleElemArrayUnsup(zT_185, zT_186, zT_187);
    (void)zT_188;
    zT_189 = env->typereg;
    zT_190 = zT_189->xt_items;
    zT_191 = tp_t.elems_start;
    zT_192 = (unsigned int)zT_191;
    zT_193 = zig_wrap_add_u(((zu64)(zT_192)), ((zu64)(fi2)), 32u);
    zT_194 = zig_overflow_flag_add_u(((zu64)(zT_192)), ((zu64)(fi2)), 32u);
    zT_196 = zT_194 == (unsigned int)(0);
    if (!(zT_196)) { pal_trap(); }
    zT_190[zT_193] = tft;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_208 = env->typereg;
    zT_209 = zT_208->tu_items;
    zT_210 = sty.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    tp = zT_212;
    zT_214 = "TUI:fs";
    zT_216 = 6;
    zT_215.ptr = (unsigned char*)zT_214;
    zT_215.len = zT_216;
    tui_fsm = zT_215;
    zT_217 = tui_fsm;
    zT_219 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_217, (unsigned int)((unsigned int)zT_219));
    zT_222 = "TUI:fc";
    zT_224 = 6;
    zT_223.ptr = (unsigned char*)zT_222;
    zT_223.len = zT_224;
    tui_fcm = zT_223;
    zT_225 = tui_fcm;
    zT_227 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_225, (unsigned int)((unsigned int)zT_227));
    goto z_bb_34;
    z_bb_32:
    goto z_bb_18;
    z_bb_33:
    zT_341 = sty.kind;
    if ((unsigned char)(zT_341 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_47; else goto z_bb_46;
    z_bb_34:
    zT_229 = tp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_229))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_233 = env->store;
    zT_236 = env->store;
    zT_237 = decl.child_1;
    zT_242 = zF_B10B1BC1_astStoreNodeExtraCh(zT_236, zT_237, (unsigned int)((unsigned int)fi2));
    zT_234 = zT_242;
    zT_243 = zF_FCDD1D35_astStoreNodeAt(zT_233, zT_234);
    fd = zT_243;
    zT_244 = fd.kind;
    if ((unsigned char)(zT_244 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_32;
    z_bb_37:
    zT_335 = 1;
    zT_336 = (unsigned int)zT_335;
    zT_337 = zig_wrap_add_u(((zu64)(fi2)), ((zu64)(zT_336)), 32u);
    zT_338 = zig_overflow_flag_add_u(((zu64)(fi2)), ((zu64)(zT_336)), 32u);
    zT_340 = zT_338 == (unsigned int)(0);
    if (!(zT_340)) { pal_trap(); }
    fi2 = zT_337;
    goto z_bb_34;
    z_bb_38:
    zT_249 = fd.child_0;
    zT_250 = 0;
    zT_248 = zT_249 != (unsigned int)zT_250;
    goto z_bb_40;
    z_bb_39:
    zT_248 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_248) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_253 = env;
    zT_254 = fd.child_0;
    zT_258 = zF_F2107C15_resolveTypeExprFull(zT_253, zT_254, (unsigned int)(0));
    ft = zT_258;
    zT_260 = "DFT:n";
    zT_262 = 5;
    zT_261.ptr = (unsigned char*)zT_260;
    zT_261.len = zT_262;
    dft_nm = zT_261;
    zT_263 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_263, (unsigned int)((unsigned int)fi2));
    zT_267 = "DFT:t";
    zT_269 = 5;
    zT_268.ptr = (unsigned char*)zT_267;
    zT_268.len = zT_269;
    dft_tm = zT_268;
    zT_270 = dft_tm;
    zT_271 = ft;
    zF_C914CB83_markerWriteInt(zT_270, zT_271);
    zT_273 = "B2:p";
    zT_275 = 4;
    zT_274.ptr = (unsigned char*)zT_273;
    zT_274.len = zT_275;
    b2_pn = zT_274;
    zT_276 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_276);
    zT_278 = env->store;
    zT_281 = env->store;
    zT_282 = decl.child_1;
    zT_287 = zF_B10B1BC1_astStoreNodeExtraCh(zT_281, zT_282, (unsigned int)((unsigned int)fi2));
    zT_279 = zT_287;
    zT_288 = zF_8BA26B9E_astStoreNodePayload(zT_278, zT_279);
    zT_277 = zT_288;
    zF_C8A36147_markerU32(zT_277);
    zT_290 = "t";
    zT_292 = 1;
    zT_291.ptr = (unsigned char*)zT_290;
    zT_291.len = zT_292;
    b2_tn = zT_291;
    zT_293 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_293);
    zT_294 = ft;
    zF_C8A36147_markerU32(zT_294);
    zT_296 = "DTWR\n";
    zT_298 = 5;
    zT_297.ptr = (unsigned char*)zT_296;
    zT_297.len = zT_298;
    dtwr_m = zT_297;
    zT_299 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_299);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_43; else goto z_bb_45;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_302 = env->typereg;
    zT_303 = zT_302->fe_items;
    zT_304 = tp.fields_start;
    zT_305 = (unsigned int)zT_304;
    zT_306 = zig_wrap_add_u(((zu64)(zT_305)), ((zu64)(fi2)), 32u);
    zT_307 = zig_overflow_flag_add_u(((zu64)(zT_305)), ((zu64)(fi2)), 32u);
    zT_309 = zT_307 == (unsigned int)(0);
    if (!(zT_309)) { pal_trap(); }
    zT_310 = zT_303 + zT_306;
    zT_310->type_id = ft;
    zT_312 = "FTW:n";
    zT_314 = 5;
    zT_313.ptr = (unsigned char*)zT_312;
    zT_313.len = zT_314;
    ftw_nm = zT_313;
    zT_315 = ftw_nm;
    zT_317 = tp.fields_start;
    zT_318 = (unsigned int)zT_317;
    zT_319 = zig_wrap_add_u(((zu64)(zT_318)), ((zu64)(fi2)), 32u);
    zT_320 = zig_overflow_flag_add_u(((zu64)(zT_318)), ((zu64)(fi2)), 32u);
    zT_322 = zT_320 == (unsigned int)(0);
    if (!(zT_322)) { pal_trap(); }
    zF_C914CB83_markerWriteInt(zT_315, (unsigned int)((unsigned int)zT_319));
    zT_325 = "FTW:t";
    zT_327 = 5;
    zT_326.ptr = (unsigned char*)zT_325;
    zT_326.len = zT_327;
    ftw_tm = zT_326;
    zT_328 = ftw_tm;
    zT_329 = ft;
    zF_C914CB83_markerWriteInt(zT_328, zT_329);
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_331 = "DTSK\n";
    zT_333 = 5;
    zT_332.ptr = (unsigned char*)zT_331;
    zT_332.len = zT_333;
    dtsk_m = zT_332;
    zT_334 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_334);
    goto z_bb_44;
    z_bb_46:
    zT_346 = sty.kind;
    zT_345 = zT_346 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_48;
    z_bb_47:
    zT_345 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_345) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_351 = env->typereg;
    zT_352 = zT_351->un_items;
    zT_353 = sty.payload_idx;
    zT_354 = (unsigned int)zT_353;
    zT_355 = zT_352[zT_354];
    up = zT_355;
    goto z_bb_51;
    z_bb_50:
    goto z_bb_32;
    z_bb_51:
    zT_356 = up.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_356))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_360 = env->store;
    zT_363 = env->store;
    zT_364 = decl.child_1;
    zT_369 = zF_B10B1BC1_astStoreNodeExtraCh(zT_363, zT_364, (unsigned int)((unsigned int)fi2));
    zT_361 = zT_369;
    zT_370 = zF_FCDD1D35_astStoreNodeAt(zT_360, zT_361);
    fd = zT_370;
    zT_371 = fd.kind;
    if ((unsigned char)(zT_371 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    zT_397 = 1;
    zT_398 = (unsigned int)zT_397;
    zT_399 = zig_wrap_add_u(((zu64)(fi2)), ((zu64)(zT_398)), 32u);
    zT_400 = zig_overflow_flag_add_u(((zu64)(fi2)), ((zu64)(zT_398)), 32u);
    zT_402 = zT_400 == (unsigned int)(0);
    if (!(zT_402)) { pal_trap(); }
    fi2 = zT_399;
    goto z_bb_51;
    z_bb_55:
    zT_376 = fd.child_0;
    zT_377 = 0;
    zT_375 = zT_376 != (unsigned int)zT_377;
    goto z_bb_57;
    z_bb_56:
    zT_375 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_375) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_380 = env;
    zT_381 = fd.child_0;
    zT_385 = zF_F2107C15_resolveTypeExprFull(zT_380, zT_381, (unsigned int)(0));
    ft = zT_385;
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_54;
    z_bb_60:
    zT_388 = env->typereg;
    zT_389 = zT_388->fe_items;
    zT_390 = up.fields_start;
    zT_391 = (unsigned int)zT_390;
    zT_392 = zig_wrap_add_u(((zu64)(zT_391)), ((zu64)(fi2)), 32u);
    zT_393 = zig_overflow_flag_add_u(((zu64)(zT_391)), ((zu64)(fi2)), 32u);
    zT_395 = zT_393 == (unsigned int)(0);
    if (!(zT_395)) { pal_trap(); }
    zT_396 = zT_389 + zT_392;
    zT_396->type_id = ft;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_59;
}

/* varDeclInitNeedsNameCache */
unsigned char zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    return (unsigned char)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6E8D187B_ModuleEntry* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_6E8D187B_ModuleEntry zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned char zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_22A7C88B_AstNode zT_66;
    zT_8143F551_AstKind zT_67;
    unsigned char zT_69;
    zT_ABC1EBBE_TypeResolveEnv* zT_71;
    unsigned int zT_72;
    unsigned int zT_76;
    zT_6E8D187B_ModuleEntry* zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    zT_6E8D187B_ModuleEntry zT_83;
    unsigned int zT_84;
    zT_79FAE712_u64 zT_85;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_96;
    unsigned int zT_97;
    unsigned char zT_99;
    zT_338B7C76_TypeRegistry* zT_100;
    zT_79FAE712_u64 zT_101;
    unsigned int zT_102;
    zT_3D7259E2_SymbolRegistry* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_6E8D187B_ModuleEntry* zT_109;
    unsigned int zT_110;
    unsigned char zT_111;
    zT_6E8D187B_ModuleEntry zT_112;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    zT_77F031D4_Opt_960 zT_118;
    unsigned char zT_119;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_132;
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_94, (unsigned int)sizeof zT_94);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_118, (unsigned int)sizeof zT_118);
    unsigned int ci;
    unsigned int cr;
    unsigned int cd_n;
    unsigned int cdi;
    unsigned int cd_i;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_77F031D4_Opt_960 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = mods.len;
    zT_11 = ci < zT_10;
    if (!(zT_11)) { pal_trap(); }
    zT_12 = zT_9[ci];
    zT_13 = zT_12.ast_root;
    cr = zT_13;
    if ((unsigned char)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_127 = 1;
    zT_128 = (unsigned int)zT_127;
    zT_129 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_128)), 32u);
    zT_130 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_128)), 32u);
    zT_132 = zT_130 == (unsigned int)(0);
    if (!(zT_132)) { pal_trap(); }
    ci = zT_129;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = mods.ptr;
    zT_17 = mods.len;
    zT_18 = ci < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[ci];
    zT_20 = zT_19.id;
    env->module_id = zT_20;
    zT_21 = mods.ptr;
    zT_22 = mods.len;
    zT_23 = ci < zT_22;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_21[ci];
    zT_25 = zT_24.source_file_id;
    env->source_file_id = zT_25;
    zT_27 = env->store;
    zT_28 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_27, zT_28);
    zT_32 = env->store;
    zT_33 = cr;
    zT_35 = zF_152E19CB_astStoreNodeExtraCh(zT_32, zT_33);
    cd_n = zT_35;
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    cdi = zT_38;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cd_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_42 = env->store;
    zT_43 = cr;
    zT_47 = zF_B10B1BC1_astStoreNodeExtraCh(zT_42, zT_43, (unsigned int)((unsigned int)cdi));
    cd_i = zT_47;
    zT_49 = env->store;
    zT_50 = cd_i;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    cdcl = zT_52;
    zT_53 = cdcl.kind;
    if ((unsigned char)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = zig_wrap_add_u(((zu64)(cdi)), ((zu64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(cdi)), ((zu64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    cdi = zT_123;
    goto z_bb_7;
    z_bb_11:
    zT_58 = cdcl.child_1;
    zT_57 = zT_58 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_57 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_57) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_62 = env->store;
    zT_63 = cdcl.child_1;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_62, zT_63);
    cdinit = zT_66;
    zT_67 = cdinit.kind;
    zT_69 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_67);
    if (zT_69) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_71 = env;
    zT_72 = cdcl.child_1;
    zT_76 = zF_F2107C15_resolveTypeExprFull(zT_71, zT_72, (unsigned int)(0));
    cdtype = zT_76;
    if ((unsigned char)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_80 = mods.ptr;
    zT_81 = mods.len;
    zT_82 = ci < zT_81;
    if (!(zT_82)) { pal_trap(); }
    zT_83 = zT_80[ci];
    zT_84 = zT_83.id;
    zT_85 = (zT_79FAE712_u64)zT_84;
    zT_86 = Z98_U64_C(4294967296);
    zT_87 = zig_wrap_mul_u(((zu64)(zT_85)), ((zu64)(zT_86)), 64u);
    zT_88 = zig_overflow_flag_mul_u(((zu64)(zT_85)), ((zu64)(zT_86)), 64u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    zT_91 = env->store;
    zT_92 = cd_i;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_95 = (zT_79FAE712_u64)zT_94;
    zT_96 = zig_wrap_add_u(((zu64)(zT_87)), ((zu64)(zT_95)), 64u);
    zT_97 = zig_overflow_flag_add_u(((zu64)(zT_87)), ((zu64)(zT_95)), 64u);
    zT_99 = zT_97 == (unsigned int)(0);
    if (!(zT_99)) { pal_trap(); }
    ck = zT_96;
    zT_100 = env->typereg;
    zT_101 = ck;
    zT_102 = cdtype;
    zF_5E95558D_nameCachePut(zT_100, zT_101, zT_102);
    zT_105 = env->symbol_reg;
    zT_109 = mods.ptr;
    zT_110 = mods.len;
    zT_111 = ci < zT_110;
    if (!(zT_111)) { pal_trap(); }
    zT_112 = zT_109[ci];
    zT_106 = zT_112.id;
    zT_114 = env->store;
    zT_115 = cd_i;
    zT_117 = zF_8BA26B9E_astStoreNodePayload(zT_114, zT_115);
    zT_107 = zT_117;
    zT_118 = zF_A398987E_symbolRegistryQuali(zT_105, zT_106, zT_107);
    cdsym = zT_118;
    zT_119 = cdsym.has_value;
    if (zT_119) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    if (!(cdsym.has_value)) { pal_trap(); }
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_77F031D4_Opt_960 zT_14;
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26;
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_37;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_48;
    zT_8143F551_AstKind zT_49;
    zT_072B53A6_ModuleRegistry* zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_61;
    zT_BAEE192E_Opt_10 zT_62;
    unsigned char zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_62, (unsigned int)sizeof zT_62);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zT_77F031D4_Opt_960 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(fs.has_value)) { pal_trap(); }
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((unsigned char)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_33 = env->store;
    zT_34 = fd.child_1;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fi = zT_37;
    zT_38 = fi.kind;
    if ((unsigned char)(zT_38 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_44 = env->store;
    zT_45 = fi.child_0;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    fb = zT_48;
    zT_49 = fb.kind;
    if ((unsigned char)(zT_49 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_55 = module_reg;
    zT_57 = env->store;
    zT_58 = fi.child_0;
    zT_61 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    zT_56 = zT_61;
    zT_62 = zF_A258E183_moduleRegistryPathT(zT_55, zT_56);
    t2 = zT_62;
    zT_63 = t2.has_value;
    if (zT_63) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    if (!(t2.has_value)) { pal_trap(); }
    m2 = t2.value;
    zT_65 = env;
    zT_66 = module_reg;
    zT_67 = importer_mod_id;
    zT_68 = m2;
    zT_71 = env->store;
    zT_72 = fd.child_1;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_69 = zT_75;
    zT_76 = 1;
    zT_77 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_76)), 32u);
    zT_78 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_76)), 32u);
    zT_80 = zT_78 == (unsigned int)(0);
    if (!(zT_80)) { pal_trap(); }
    env = zT_65;
    module_reg = zT_66;
    importer_mod_id = zT_67;
    target_mod_id = zT_68;
    field_name_id = zT_69;
    depth = zT_77;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    zT_6E8D187B_ModuleEntry zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_43;
    zT_8143F551_AstKind zT_44;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_22A7C88B_AstNode zT_56;
    zT_8143F551_AstKind zT_57;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    zT_22A7C88B_AstNode zT_66;
    zT_8143F551_AstKind zT_67;
    zT_072B53A6_ModuleRegistry* zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_78;
    zT_BAEE192E_Opt_10 zT_79;
    unsigned char zT_80;
    zT_ABC1EBBE_TypeResolveEnv* zT_83;
    zT_072B53A6_ModuleRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_6E8D187B_ModuleEntry* zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    zT_6E8D187B_ModuleEntry zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    unsigned int zT_98;
    unsigned int zT_100;
    zT_3D7259E2_SymbolRegistry* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_6E8D187B_ModuleEntry* zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    zT_6E8D187B_ModuleEntry zT_111;
    zT_6B0A7D14_AstStore* zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    zT_77F031D4_Opt_960 zT_117;
    unsigned char zT_118;
    zT_6E8D187B_ModuleEntry* zT_121;
    unsigned int zT_122;
    unsigned char zT_123;
    zT_6E8D187B_ModuleEntry zT_124;
    unsigned int zT_125;
    zT_79FAE712_u64 zT_126;
    zT_79FAE712_u64 zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    unsigned char zT_131;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    unsigned int zT_135;
    zT_79FAE712_u64 zT_136;
    zT_79FAE712_u64 zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_79FAE712_u64 zT_142;
    unsigned int zT_143;
    int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = mods.len;
    zT_12 = mi < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[mi];
    zT_14 = zT_13.ast_root;
    root = zT_14;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_151 = 1;
    zT_152 = (unsigned int)zT_151;
    zT_153 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_152)), 32u);
    zT_154 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_152)), 32u);
    zT_156 = zT_154 == (unsigned int)(0);
    if (!(zT_156)) { pal_trap(); }
    mi = zT_153;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = env->store;
    zT_19 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = root;
    zT_38 = zF_B10B1BC1_astStoreNodeExtraCh(zT_33, zT_34, (unsigned int)((unsigned int)di));
    decl_idx = zT_38;
    zT_40 = env->store;
    zT_41 = decl_idx;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    decl = zT_43;
    zT_44 = decl.kind;
    if ((unsigned char)(zT_44 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_145 = 1;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_146)), 32u);
    zT_148 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_146)), 32u);
    zT_150 = zT_148 == (unsigned int)(0);
    if (!(zT_150)) { pal_trap(); }
    di = zT_147;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_48 = decl.child_1;
    if ((unsigned char)(zT_48 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_52 = env->store;
    zT_53 = decl.child_1;
    zT_56 = zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    init = zT_56;
    zT_57 = init.kind;
    if ((unsigned char)(zT_57 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_62 = env->store;
    zT_63 = init.child_0;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_62, zT_63);
    base = zT_66;
    zT_67 = base.kind;
    if ((unsigned char)(zT_67 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_72 = module_reg;
    zT_74 = env->store;
    zT_75 = init.child_0;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_73 = zT_78;
    zT_79 = zF_A258E183_moduleRegistryPathT(zT_72, zT_73);
    target = zT_79;
    zT_80 = target.has_value;
    if (zT_80) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    if (!(target.has_value)) { pal_trap(); }
    mtid = target.value;
    zT_83 = env;
    zT_84 = module_reg;
    zT_89 = mods.ptr;
    zT_90 = mods.len;
    zT_91 = mi < zT_90;
    if (!(zT_91)) { pal_trap(); }
    zT_92 = zT_89[mi];
    zT_85 = zT_92.id;
    zT_86 = mtid;
    zT_94 = env->store;
    zT_95 = decl.child_1;
    zT_98 = zF_8BA26B9E_astStoreNodePayload(zT_94, zT_95);
    zT_87 = zT_98;
    zT_100 = zF_E8C2AADA_resolveImportFieldA(zT_83, zT_84, zT_85, zT_86, zT_87, (unsigned int)(0));
    resolved = zT_100;
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_104 = env->symbol_reg;
    zT_108 = mods.ptr;
    zT_109 = mods.len;
    zT_110 = mi < zT_109;
    if (!(zT_110)) { pal_trap(); }
    zT_111 = zT_108[mi];
    zT_105 = zT_111.id;
    zT_113 = env->store;
    zT_114 = decl_idx;
    zT_116 = zF_8BA26B9E_astStoreNodePayload(zT_113, zT_114);
    zT_106 = zT_116;
    zT_117 = zF_A398987E_symbolRegistryQuali(zT_104, zT_105, zT_106);
    sym = zT_117;
    zT_118 = sym.has_value;
    if (zT_118) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    if (!(sym.has_value)) { pal_trap(); }
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_121 = mods.ptr;
    zT_122 = mods.len;
    zT_123 = mi < zT_122;
    if (!(zT_123)) { pal_trap(); }
    zT_124 = zT_121[mi];
    zT_125 = zT_124.id;
    zT_126 = (zT_79FAE712_u64)zT_125;
    zT_127 = Z98_U64_C(4294967296);
    zT_128 = zig_wrap_mul_u(((zu64)(zT_126)), ((zu64)(zT_127)), 64u);
    zT_129 = zig_overflow_flag_mul_u(((zu64)(zT_126)), ((zu64)(zT_127)), 64u);
    zT_131 = zT_129 == (unsigned int)(0);
    if (!(zT_131)) { pal_trap(); }
    zT_132 = env->store;
    zT_133 = decl_idx;
    zT_135 = zF_8BA26B9E_astStoreNodePayload(zT_132, zT_133);
    zT_136 = (zT_79FAE712_u64)zT_135;
    zT_137 = zig_wrap_add_u(((zu64)(zT_128)), ((zu64)(zT_136)), 64u);
    zT_138 = zig_overflow_flag_add_u(((zu64)(zT_128)), ((zu64)(zT_136)), 64u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    ck = zT_137;
    zT_141 = env->typereg;
    zT_142 = ck;
    zT_143 = resolved;
    zF_5E95558D_nameCachePut(zT_141, zT_142, zT_143);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_47;
    zT_8143F551_AstKind zT_48;
    unsigned char zT_52;
    unsigned int zT_53;
    int zT_54;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    zT_22A7C88B_AstNode zT_61;
    zT_8143F551_AstKind zT_62;
    unsigned char zT_66;
    zT_8143F551_AstKind zT_67;
    zT_ABC1EBBE_TypeResolveEnv* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_90;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = mods.len;
    zT_11 = mi < zT_10;
    if (!(zT_11)) { pal_trap(); }
    zT_12 = zT_9[mi];
    zT_13 = zT_12.ast_root;
    root = zT_13;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_85 = 1;
    zT_86 = (unsigned int)zT_85;
    zT_87 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_86)), 32u);
    zT_88 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_86)), 32u);
    zT_90 = zT_88 == (unsigned int)(0);
    if (!(zT_90)) { pal_trap(); }
    mi = zT_87;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = mods.ptr;
    zT_17 = mods.len;
    zT_18 = mi < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[mi];
    zT_20 = zT_19.source_file_id;
    env->source_file_id = zT_20;
    zT_22 = env->store;
    zT_23 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_27 = env->store;
    zT_28 = root;
    zT_30 = zF_152E19CB_astStoreNodeExtraCh(zT_27, zT_28);
    decls_n = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    di = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_38 = root;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)di));
    decl_idx = zT_42;
    zT_44 = env->store;
    zT_45 = decl_idx;
    zT_47 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    decl = zT_47;
    zT_48 = decl.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_79 = 1;
    zT_80 = (unsigned int)zT_79;
    zT_81 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    di = zT_81;
    goto z_bb_7;
    z_bb_11:
    zT_53 = decl.child_1;
    zT_54 = 0;
    zT_52 = zT_53 != (unsigned int)zT_54;
    goto z_bb_13;
    z_bb_12:
    zT_52 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_52) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = env->store;
    zT_58 = decl.child_1;
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    init = zT_61;
    zT_62 = init.kind;
    if ((unsigned char)(zT_62 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_67 = init.kind;
    zT_66 = zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_66 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_66) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_71 = env;
    zT_74 = mods.ptr;
    zT_75 = mods.len;
    zT_76 = mi < zT_75;
    if (!(zT_76)) { pal_trap(); }
    zT_77 = zT_74[mi];
    zT_72 = zT_77.id;
    zT_73 = decl_idx;
    zF_F5C3193B_resolveDeclAggregat(zT_71, zT_72, zT_73);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* reportUndefinedSymbol */
void zF_76A5E245_reportUndefinedSymb(zT_F85C5DED_DiagnosticCollector* diag, zT_D3EB6303_StringInterner* interner, unsigned int source_file_id, unsigned int span_start, unsigned int span_len, unsigned int name_id) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_25;
    int zT_27;
    unsigned char zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    zT_F85C5DED_DiagnosticCollector* zT_33;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_8F083A69_Slice_zT_0B42B2F8_u uitext;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    zT_7 = "identifier '";
    zT_9 = 12;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    ui1 = zT_8;
    zT_11 = "' is not declared or imported in this module";
    zT_13 = 44;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    ui2 = zT_12;
    zT_15 = interner;
    zT_16 = name_id;
    zT_17 = zF_9134020D_stringInternerGet(zT_15, zT_16);
    uitext = zT_17;
    zT_20 = 0;
    zT_19[zT_20] = ui1;
    zT_21 = 1;
    zT_19[zT_21] = uitext;
    zT_22 = 2;
    zT_19[zT_22] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_19[_i];
        _i++;
    }
}
    zT_24 = interner;
    zT_27 = 0;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(3);
    if (!(zT_29)) { pal_trap(); }
    zT_30 = uiparts + zT_27;
    zT_25 = zT_30;
    zT_32 = zF_8C4BFF7C_diagnosticBuilderMa(zT_24, zT_25, (unsigned int)(3));
    uimsg = zT_32;
    zT_33 = diag;
    zT_36 = source_file_id;
    zT_37 = span_start;
    zT_44 = zig_wrap_add_u(((zu64)(span_start)), ((zu64)(span_len)), 32u);
    zT_45 = zig_overflow_flag_add_u(((zu64)(span_start)), ((zu64)(span_len)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_38 = zT_44;
    zT_39 = uimsg;
    zT_48 = zF_C82559AC_diagnosticCollector(zT_33, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_36, zT_37, zT_38, zT_39);
    (void)zT_48;
    return;
}

/* typeResolverDiagnoseSignatureType */
void zF_2501AC4F_typeResolverDiagnos(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_622E1E76_Opt_254 zT_8;
    unsigned char zT_9;
    zT_F85C5DED_DiagnosticCollector* zT_10;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16;
    zT_8143F551_AstKind zT_17;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_41;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_66;
    zT_8143F551_AstKind zT_68;
    unsigned int zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_79;
    unsigned char zT_81;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D155D06D_Type* zT_92;
    unsigned int zT_93;
    zT_D155D06D_Type zT_94;
    zT_33EF6BFB_TypeKind zT_95;
    unsigned char zT_99;
    unsigned short zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    zT_22A7C88B_AstNode zT_106;
    zT_8143F551_AstKind zT_107;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned int zT_115;
    int zT_117;
    unsigned int zT_118;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    zT_3D7259E2_SymbolRegistry* zT_124;
    unsigned int zT_126;
    zT_77F031D4_Opt_960 zT_129;
    unsigned char zT_130;
    zT_3C598AEF_SymbolKind zT_132;
    unsigned char zT_136;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned char zT_143;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    zT_3D7259E2_SymbolRegistry* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_77F031D4_Opt_960 zT_154;
    unsigned char zT_155;
    zT_F85C5DED_DiagnosticCollector* zT_157;
    unsigned int zT_158;
    unsigned char zT_159;
    zT_F85C5DED_DiagnosticCollector* zT_160;
    zT_D3EB6303_StringInterner* zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned int zT_169;
    zT_ABC1EBBE_TypeResolveEnv* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned char zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned int zT_185;
    int zT_186;
    zT_ABC1EBBE_TypeResolveEnv* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned char zT_196;
    unsigned int zT_197;
    int zT_198;
    zT_ABC1EBBE_TypeResolveEnv* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned char zT_208;
    zT_8143F551_AstKind zT_209;
    unsigned int zT_213;
    int zT_214;
    zT_ABC1EBBE_TypeResolveEnv* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned char zT_224;
    zT_6B0A7D14_AstStore* zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int zT_235;
    int zT_237;
    unsigned int zT_238;
    zT_6B0A7D14_AstStore* zT_242;
    unsigned int zT_243;
    unsigned int zT_247;
    int zT_248;
    zT_ABC1EBBE_TypeResolveEnv* zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned char zT_257;
    int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned char zT_263;
    zT_8143F551_AstKind zT_264;
    unsigned char zT_268;
    zT_8143F551_AstKind zT_269;
    unsigned char zT_273;
    zT_8143F551_AstKind zT_274;
    unsigned char zT_278;
    zT_8143F551_AstKind zT_279;
    unsigned char zT_283;
    zT_8143F551_AstKind zT_284;
    unsigned int zT_288;
    int zT_289;
    zT_ABC1EBBE_TypeResolveEnv* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    unsigned char zT_299;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_129, (unsigned int)sizeof zT_129);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_159, (unsigned int)sizeof zT_159);
    zig_poison_fill((void*)&zT_228, (unsigned int)sizeof zT_228);
    zig_poison_fill((void*)&zT_235, (unsigned int)sizeof zT_235);
    zig_poison_fill((void*)&zT_247, (unsigned int)sizeof zT_247);
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u nr_text;
    unsigned int nr_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_text;
    unsigned int at_id;
    unsigned int fd_base;
    unsigned int fd_bt;
    unsigned char fd_is_mod;
    unsigned int fd_mod_id;
    zT_22A7C88B_AstNode fd_bn;
    zT_D155D06D_Type fd_ty;
    unsigned int fd_bname;
    unsigned int fd_mi;
    zT_77F031D4_Opt_960 fd_bs;
    zT_3A105EF1_Symbol* fb;
    unsigned int fd_member;
    zT_77F031D4_Opt_960 fd_ms;
    unsigned int ft_n;
    unsigned int ft_i;
    unsigned int ft_child;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_8 = env->diag;
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    return;
    z_bb_6:
    if (!(zT_8.has_value)) { pal_trap(); }
    zT_10 = zT_8.value;
    goto z_bb_7;
    z_bb_7:
    diag = zT_10;
    zT_13 = env->store;
    zT_14 = node_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    node = zT_16;
    zT_17 = node.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = env;
    zT_22 = node_idx;
    zT_25 = zF_F2107C15_resolveTypeExprFull(zT_21, zT_22, (unsigned int)(0));
    if ((unsigned char)(zT_25 != (unsigned int)(18))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_68 = node.kind;
    if ((unsigned char)(zT_68 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_18; else goto z_bb_19;
    z_bb_10:
    return;
    z_bb_11:
    zT_29 = env->store;
    zT_30 = node_idx;
    zT_32 = zF_53458827_astStoreIdentifier(zT_29, zT_30);
    name_id = zT_32;
    zT_34 = "noreturn";
    zT_36 = 8;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    nr_text = zT_35;
    zT_38 = env->interner;
    zT_39 = nr_text;
    zT_41 = zF_50C274AF_stringInternerInter(zT_38, zT_39);
    nr_id = zT_41;
    if ((unsigned char)(name_id == nr_id)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    zT_44 = "anytype";
    zT_46 = 7;
    zT_45.ptr = (unsigned char*)zT_44;
    zT_45.len = zT_46;
    at_text = zT_45;
    zT_48 = env->interner;
    zT_49 = at_text;
    zT_51 = zF_50C274AF_stringInternerInter(zT_48, zT_49);
    at_id = zT_51;
    if ((unsigned char)(name_id == at_id)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return;
    z_bb_15:
    zT_53 = diag;
    zT_54 = node_idx;
    zT_55 = zF_4DD9DB2D_diagnosticCollector(zT_53, zT_54);
    if ((unsigned char)(!zT_55)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return;
    z_bb_17:
    zT_57 = diag;
    zT_58 = env->interner;
    zT_59 = env->source_file_id;
    zT_60 = node.span_start;
    zT_66 = node.span_len;
    zT_62 = name_id;
    zF_76A5E245_reportUndefinedSymb(zT_57, zT_58, zT_59, zT_60, (unsigned int)((unsigned int)zT_66), zT_62);
    return;
    z_bb_18:
    zT_73 = node.child_0;
    fd_base = zT_73;
    zT_75 = env;
    zT_76 = fd_base;
    zT_79 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, (unsigned int)(0));
    fd_bt = zT_79;
    zT_81 = 0;
    fd_is_mod = zT_81;
    zT_83 = 0;
    fd_mod_id = zT_83;
    if ((unsigned char)(fd_bt != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_181 = node.kind;
    if ((unsigned char)(zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_20:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)fd_bt) < zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    if (fd_is_mod) goto z_bb_37; else goto z_bb_38;
    z_bb_22:
    zT_103 = env->store;
    zT_104 = fd_base;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_103, zT_104);
    fd_bn = zT_106;
    zT_107 = fd_bn.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_27; else goto z_bb_28;
    z_bb_23:
    zT_91 = env->typereg;
    zT_92 = zT_91->types_items;
    zT_93 = (unsigned int)fd_bt;
    zT_94 = zT_92[zT_93];
    fd_ty = zT_94;
    zT_95 = fd_ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_99 = 1;
    fd_is_mod = zT_99;
    zT_100 = fd_ty.module_id;
    zT_101 = (unsigned int)zT_100;
    fd_mod_id = zT_101;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_112 = env->store;
    zT_113 = fd_base;
    zT_115 = zF_53458827_astStoreIdentifier(zT_112, zT_113);
    fd_bname = zT_115;
    zT_117 = 0;
    zT_118 = (unsigned int)zT_117;
    fd_mi = zT_118;
    goto z_bb_29;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_119 = env->symbol_reg;
    zT_120 = zT_119->tables_len;
    if ((unsigned char)(fd_mi < (unsigned int)((unsigned int)zT_120))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_124 = env->symbol_reg;
    zT_126 = fd_bname;
    zT_129 = zF_A398987E_symbolRegistryQuali(zT_124, (unsigned int)((unsigned int)fd_mi), zT_126);
    fd_bs = zT_129;
    zT_130 = fd_bs.has_value;
    if (zT_130) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_138 = 1;
    zT_139 = (unsigned int)zT_138;
    zT_140 = zig_wrap_add_u(((zu64)(fd_mi)), ((zu64)(zT_139)), 32u);
    zT_141 = zig_overflow_flag_add_u(((zu64)(fd_mi)), ((zu64)(zT_139)), 32u);
    zT_143 = zT_141 == (unsigned int)(0);
    if (!(zT_143)) { pal_trap(); }
    fd_mi = zT_140;
    goto z_bb_29;
    z_bb_33:
    if (!(fd_bs.has_value)) { pal_trap(); }
    fb = fd_bs.value;
    zT_132 = fb->kind;
    if ((unsigned char)(zT_132 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_136 = 1;
    fd_is_mod = zT_136;
    zT_137 = fb->module_id;
    fd_mod_id = zT_137;
    goto z_bb_36;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_145 = env->store;
    zT_146 = node_idx;
    zT_148 = zF_8BA26B9E_astStoreNodePayload(zT_145, zT_146);
    fd_member = zT_148;
    zT_150 = env->symbol_reg;
    zT_151 = fd_mod_id;
    zT_152 = fd_member;
    zT_154 = zF_A398987E_symbolRegistryQuali(zT_150, zT_151, zT_152);
    fd_ms = zT_154;
    zT_155 = fd_ms.has_value;
    if ((unsigned char)(!zT_155)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    if ((unsigned char)(fd_bt == (unsigned int)(18))) goto z_bb_43; else goto z_bb_44;
    z_bb_39:
    zT_157 = diag;
    zT_158 = node_idx;
    zT_159 = zF_4DD9DB2D_diagnosticCollector(zT_157, zT_158);
    if (zT_159) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    return;
    z_bb_41:
    zT_160 = diag;
    zT_161 = env->interner;
    zT_162 = env->source_file_id;
    zT_163 = node.span_start;
    zT_169 = node.span_len;
    zT_165 = fd_member;
    zF_76A5E245_reportUndefinedSymb(zT_160, zT_161, zT_162, zT_163, (unsigned int)((unsigned int)zT_169), zT_165);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_173 = env;
    zT_174 = fd_base;
    zT_176 = 1;
    zT_177 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_176)), 32u);
    zT_178 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_176)), 32u);
    zT_180 = zT_178 == (unsigned int)(0);
    if (!(zT_180)) { pal_trap(); }
    zT_175 = zT_177;
    zF_2501AC4F_typeResolverDiagnos(zT_173, zT_174, zT_175);
    goto z_bb_44;
    z_bb_44:
    return;
    z_bb_45:
    zT_185 = node.child_0;
    zT_186 = 0;
    if ((unsigned char)(zT_185 != (unsigned int)zT_186)) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_209 = node.kind;
    if ((unsigned char)(zT_209 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_47:
    zT_188 = env;
    zT_189 = node.child_0;
    zT_192 = 1;
    zT_193 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_192)), 32u);
    zT_194 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_192)), 32u);
    zT_196 = zT_194 == (unsigned int)(0);
    if (!(zT_196)) { pal_trap(); }
    zT_190 = zT_193;
    zF_2501AC4F_typeResolverDiagnos(zT_188, zT_189, zT_190);
    goto z_bb_48;
    z_bb_48:
    zT_197 = node.child_1;
    zT_198 = 0;
    if ((unsigned char)(zT_197 != (unsigned int)zT_198)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_200 = env;
    zT_201 = node.child_1;
    zT_204 = 1;
    zT_205 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_204)), 32u);
    zT_206 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_204)), 32u);
    zT_208 = zT_206 == (unsigned int)(0);
    if (!(zT_208)) { pal_trap(); }
    zT_202 = zT_205;
    zF_2501AC4F_typeResolverDiagnos(zT_200, zT_201, zT_202);
    goto z_bb_50;
    z_bb_50:
    return;
    z_bb_51:
    zT_213 = node.child_0;
    zT_214 = 0;
    if ((unsigned char)(zT_213 != (unsigned int)zT_214)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_264 = node.kind;
    if ((unsigned char)(zT_264 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_64; else goto z_bb_63;
    z_bb_53:
    zT_216 = env;
    zT_217 = node.child_0;
    zT_220 = 1;
    zT_221 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_220)), 32u);
    zT_222 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_220)), 32u);
    zT_224 = zT_222 == (unsigned int)(0);
    if (!(zT_224)) { pal_trap(); }
    zT_218 = zT_221;
    zF_2501AC4F_typeResolverDiagnos(zT_216, zT_217, zT_218);
    goto z_bb_54;
    z_bb_54:
    zT_225 = env->store;
    zT_226 = node_idx;
    zT_228 = zF_8BA26B9E_astStoreNodePayload(zT_225, zT_226);
    if ((unsigned char)(zT_228 != (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_232 = env->store;
    zT_233 = node_idx;
    zT_235 = zF_152E19CB_astStoreNodeExtraCh(zT_232, zT_233);
    ft_n = zT_235;
    zT_237 = 0;
    zT_238 = (unsigned int)zT_237;
    ft_i = zT_238;
    goto z_bb_57;
    z_bb_56:
    return;
    z_bb_57:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_242 = env->store;
    zT_243 = node_idx;
    zT_247 = zF_B10B1BC1_astStoreNodeExtraCh(zT_242, zT_243, (unsigned int)((unsigned int)ft_i));
    ft_child = zT_247;
    zT_248 = 0;
    if ((unsigned char)(ft_child != (unsigned int)zT_248)) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_258 = 1;
    zT_259 = (unsigned int)zT_258;
    zT_260 = zig_wrap_add_u(((zu64)(ft_i)), ((zu64)(zT_259)), 32u);
    zT_261 = zig_overflow_flag_add_u(((zu64)(ft_i)), ((zu64)(zT_259)), 32u);
    zT_263 = zT_261 == (unsigned int)(0);
    if (!(zT_263)) { pal_trap(); }
    ft_i = zT_260;
    goto z_bb_57;
    z_bb_61:
    zT_250 = env;
    zT_251 = ft_child;
    zT_253 = 1;
    zT_254 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_253)), 32u);
    zT_255 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_253)), 32u);
    zT_257 = zT_255 == (unsigned int)(0);
    if (!(zT_257)) { pal_trap(); }
    zT_252 = zT_254;
    zF_2501AC4F_typeResolverDiagnos(zT_250, zT_251, zT_252);
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_269 = node.kind;
    zT_268 = zT_269 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_65;
    z_bb_64:
    zT_268 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_268) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_274 = node.kind;
    zT_273 = zT_274 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_68;
    z_bb_67:
    zT_273 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_273) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_279 = node.kind;
    zT_278 = zT_279 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_71;
    z_bb_70:
    zT_278 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_278) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_284 = node.kind;
    zT_283 = zT_284 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_74;
    z_bb_73:
    zT_283 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_283) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_288 = node.child_0;
    zT_289 = 0;
    if ((unsigned char)(zT_288 != (unsigned int)zT_289)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return;
    z_bb_77:
    zT_291 = env;
    zT_292 = node.child_0;
    zT_295 = 1;
    zT_296 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_295)), 32u);
    zT_297 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_295)), 32u);
    zT_299 = zT_297 == (unsigned int)(0);
    if (!(zT_299)) { pal_trap(); }
    zT_293 = zT_296;
    zF_2501AC4F_typeResolverDiagnos(zT_291, zT_292, zT_293);
    goto z_bb_78;
    z_bb_78:
    return;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    zT_6E8D187B_ModuleEntry zT_13;
    unsigned int zT_14;
    zT_6E8D187B_ModuleEntry* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    zT_6E8D187B_ModuleEntry zT_20;
    unsigned int zT_21;
    zT_6E8D187B_ModuleEntry* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_6E8D187B_ModuleEntry zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    int zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_53;
    zT_8143F551_AstKind zT_54;
    zT_6B0A7D14_AstStore* zT_59;
    zT_4EF476FD_anon_318191 zT_60;
    zT_243D6A41_FnProto* zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_243D6A41_FnProto zT_67;
    zT_3D7259E2_SymbolRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_6E8D187B_ModuleEntry* zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    zT_6E8D187B_ModuleEntry zT_76;
    zT_77F031D4_Opt_960 zT_79;
    unsigned char zT_80;
    unsigned int zT_82;
    zT_939EE900_Arr_unsigned_int_1 zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    int zT_90;
    zT_ABC1EBBE_TypeResolveEnv* zT_93;
    unsigned int zT_94;
    unsigned int zT_98;
    int zT_101;
    unsigned char zT_103;
    zT_8EED1867_ResolvedTypeTable* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_ABC1EBBE_TypeResolveEnv* zT_108;
    unsigned int zT_109;
    unsigned char zT_114;
    unsigned char zT_115;
    unsigned char zT_120;
    unsigned char zT_122;
    unsigned char zT_123;
    unsigned char zT_128;
    zT_993A6923_Arr_unsigned_int_64 zT_130;
    unsigned int zT_132;
    unsigned short zT_133;
    char* zT_137;
    unsigned int zT_138;
    char* zT_139;
    unsigned int zT_140;
    char* zT_141;
    unsigned int zT_142;
    unsigned short zT_144;
    unsigned int zT_148;
    zT_79FAE712_u64 zT_149;
    zT_79FAE712_u64 zT_150;
    zT_79FAE712_u64 zT_151;
    unsigned char zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    unsigned short zT_157;
    zT_79FAE712_u64 zT_159;
    zT_6B0A7D14_AstStore* zT_161;
    zT_79FAE712_u64 zT_162;
    unsigned int zT_164;
    int zT_166;
    unsigned int zT_167;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_172;
    zT_6B0A7D14_AstStore* zT_174;
    zT_79FAE712_u64 zT_175;
    unsigned int zT_179;
    zT_22A7C88B_AstNode zT_180;
    unsigned int zT_181;
    int zT_182;
    zT_ABC1EBBE_TypeResolveEnv* zT_185;
    unsigned int zT_186;
    unsigned int zT_190;
    char* zT_193;
    unsigned int zT_194;
    char* zT_195;
    unsigned int zT_196;
    char* zT_197;
    unsigned int zT_198;
    unsigned char zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned char zT_206;
    zT_8EED1867_ResolvedTypeTable* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_ABC1EBBE_TypeResolveEnv* zT_213;
    unsigned int zT_214;
    int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned char zT_223;
    zT_338B7C76_TypeRegistry* zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_229;
    zT_338B7C76_TypeRegistry* zT_231;
    unsigned int zT_232;
    unsigned char zT_235;
    int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned char zT_242;
    zT_338B7C76_TypeRegistry* zT_244;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned char zT_247;
    unsigned char zT_248;
    unsigned int zT_249;
    unsigned short zT_250;
    unsigned int zT_251;
    unsigned char zT_252;
    zT_6E8D187B_ModuleEntry* zT_255;
    unsigned int zT_256;
    unsigned char zT_257;
    zT_6E8D187B_ModuleEntry zT_258;
    int zT_261;
    unsigned char zT_263;
    unsigned int zT_266;
    zT_8EED1867_ResolvedTypeTable* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    zT_3D7259E2_SymbolRegistry* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    zT_6E8D187B_ModuleEntry* zT_275;
    unsigned int zT_276;
    unsigned char zT_277;
    zT_6E8D187B_ModuleEntry zT_278;
    zT_77F031D4_Opt_960 zT_281;
    unsigned char zT_282;
    zT_8143F551_AstKind zT_284;
    unsigned char zT_288;
    unsigned int zT_289;
    int zT_290;
    zT_ABC1EBBE_TypeResolveEnv* zT_293;
    unsigned int zT_294;
    unsigned int zT_298;
    zT_8EED1867_ResolvedTypeTable* zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    zT_8EED1867_ResolvedTypeTable* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_3D7259E2_SymbolRegistry* zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    zT_6E8D187B_ModuleEntry* zT_313;
    unsigned int zT_314;
    unsigned char zT_315;
    zT_6E8D187B_ModuleEntry zT_316;
    zT_6B0A7D14_AstStore* zT_318;
    unsigned int zT_319;
    unsigned int zT_321;
    zT_77F031D4_Opt_960 zT_322;
    unsigned char zT_323;
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned char zT_330;
    int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned char zT_336;
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_179, (unsigned int)sizeof zT_179);
    zig_poison_fill((void*)&zT_180, (unsigned int)sizeof zT_180);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_266, (unsigned int)sizeof zT_266);
    zig_poison_fill((void*)&zT_281, (unsigned int)sizeof zT_281);
    zig_poison_fill((void*)&zT_298, (unsigned int)sizeof zT_298);
    zig_poison_fill((void*)&zT_321, (unsigned int)sizeof zT_321);
    zig_poison_fill((void*)&zT_322, (unsigned int)sizeof zT_322);
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_77F031D4_Opt_960 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    zT_993A6923_Arr_unsigned_int_64 ptypes_buf;
    unsigned int ptypes_n;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int fn_start;
    unsigned int pf;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    unsigned int tid;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = mods.len;
    zT_12 = mi < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[mi];
    zT_14 = zT_13.ast_root;
    root = zT_14;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_331 = 1;
    zT_332 = (unsigned int)zT_331;
    zT_333 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_332)), 32u);
    zT_334 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_332)), 32u);
    zT_336 = zT_334 == (unsigned int)(0);
    if (!(zT_336)) { pal_trap(); }
    mi = zT_333;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_17 = mods.ptr;
    zT_18 = mods.len;
    zT_19 = mi < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[mi];
    zT_21 = zT_20.id;
    env->module_id = zT_21;
    zT_22 = mods.ptr;
    zT_23 = mods.len;
    zT_24 = mi < zT_23;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_22[mi];
    zT_26 = zT_25.source_file_id;
    env->source_file_id = zT_26;
    zT_28 = env->store;
    zT_29 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_28, zT_29);
    zT_33 = env->store;
    zT_34 = root;
    zT_36 = zF_152E19CB_astStoreNodeExtraCh(zT_33, zT_34);
    decls_n = zT_36;
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    di = zT_39;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_43 = env->store;
    zT_44 = root;
    zT_48 = zF_B10B1BC1_astStoreNodeExtraCh(zT_43, zT_44, (unsigned int)((unsigned int)di));
    decl_idx = zT_48;
    zT_50 = env->store;
    zT_51 = decl_idx;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    decl = zT_53;
    zT_54 = decl.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_325 = 1;
    zT_326 = (unsigned int)zT_325;
    zT_327 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_326)), 32u);
    zT_328 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_326)), 32u);
    zT_330 = zT_328 == (unsigned int)(0);
    if (!(zT_330)) { pal_trap(); }
    di = zT_327;
    goto z_bb_7;
    z_bb_11:
    zT_59 = env->store;
    zT_60 = zT_59->fn_protos;
    zT_61 = zT_60.items;
    zT_62 = env->store;
    zT_63 = decl_idx;
    zT_65 = zF_8BA26B9E_astStoreNodePayload(zT_62, zT_63);
    zT_66 = (unsigned int)zT_65;
    zT_67 = zT_61[zT_66];
    proto = zT_67;
    zT_69 = env->symbol_reg;
    zT_73 = mods.ptr;
    zT_74 = mods.len;
    zT_75 = mi < zT_74;
    if (!(zT_75)) { pal_trap(); }
    zT_76 = zT_73[mi];
    zT_70 = zT_76.id;
    zT_71 = proto.name_id;
    zT_79 = zF_A398987E_symbolRegistryQuali(zT_69, zT_70, zT_71);
    sym_check = zT_79;
    zT_80 = sym_check.has_value;
    if (zT_80) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_284 = decl.kind;
    if ((unsigned char)(zT_284 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_48; else goto z_bb_49;
    z_bb_14:
    if (!(sym_check.has_value)) { pal_trap(); }
    sc = sym_check.value;
    zT_82 = sc->type_id;
    if ((unsigned char)(zT_82 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_87 = 1;
    zT_88 = 0;
    zT_86[zT_88] = zT_87;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_86[_i];
        _i++;
    }
}
    zT_89 = proto.return_type_node;
    zT_90 = 0;
    if ((unsigned char)(zT_89 != (unsigned int)zT_90)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_93 = env;
    zT_94 = proto.return_type_node;
    zT_98 = zF_F2107C15_resolveTypeExprFull(zT_93, zT_94, (unsigned int)(0));
    rtype = zT_98;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_114 = 0;
    is_ext = zT_114;
    zT_115 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_115 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_101 = 0;
    zT_103 = (unsigned int)zT_101 < (unsigned int)(1);
    if (!(zT_103)) { pal_trap(); }
    rt_box[zT_101] = rtype;
    zT_104 = resolved_types;
    zT_105 = proto.return_type_node;
    zT_106 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_104, zT_105, zT_106);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_108 = env;
    zT_109 = proto.return_type_node;
    zF_2501AC4F_typeResolverDiagnos(zT_108, zT_109, (unsigned int)(0));
    goto z_bb_21;
    z_bb_23:
    zT_120 = 1;
    is_ext = zT_120;
    goto z_bb_24;
    z_bb_24:
    zT_122 = 0;
    is_variadic = zT_122;
    zT_123 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_123 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_128 = 1;
    is_variadic = zT_128;
    goto z_bb_26;
    z_bb_26:
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        ptypes_buf[_i] = zT_130[_i];
        _i++;
    }
}
    zT_132 = 0;
    ptypes_n = zT_132;
    zT_133 = proto.params_count;
    if ((unsigned char)((unsigned int)((unsigned int)zT_133) > (unsigned int)(64))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_137 = "panic: ";
    zT_138 = 7;
    fwrite(zT_137, 1, zT_138, stderr);
    zT_139 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_140 = 72;
    fwrite(zT_139, 1, zT_140, stderr);
    zT_141 = "\n";
    zT_142 = 1;
    fwrite(zT_141, 1, zT_142, stderr);
    pal_trap();
    z_bb_28:
    zT_144 = proto.params_count;
    if ((unsigned char)(zT_144 > (unsigned short)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_148 = proto.params_start;
    zT_149 = (zT_79FAE712_u64)zT_148;
    zT_150 = 32;
    zT_153 = zT_150 < (unsigned int)(64);
    if (!(zT_153)) { pal_trap(); }
    zT_151 = zig_wrap_shl_u(((zu64)(zT_149)), ((zu64)(zT_150)), 64u);
    zT_154 = zig_overflow_flag_shl_u(((zu64)(zT_149)), ((zu64)(zT_150)), 64u);
    zT_156 = zT_154 == (unsigned int)(0);
    if (!(zT_156)) { pal_trap(); }
    zT_157 = proto.params_count;
    zT_159 = zT_151 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_157);
    p_payload = zT_159;
    zT_161 = env->store;
    zT_162 = p_payload;
    zT_164 = zF_03CE8CAB_astStoreGetExtraChi(zT_161, zT_162);
    pnodes_n = zT_164;
    zT_166 = 0;
    zT_167 = (unsigned int)zT_166;
    pi = zT_167;
    goto z_bb_31;
    z_bb_30:
    zT_225 = env->typereg;
    zT_226 = zT_225->xt_len;
    zT_227 = (unsigned int)zT_226;
    fn_start = zT_227;
    zT_229 = 0;
    pf = zT_229;
    goto z_bb_42;
    z_bb_31:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_171 = env->store;
    zT_174 = env->store;
    zT_175 = p_payload;
    zT_179 = zF_E5B10421_astStoreGetExtraChi(zT_174, zT_175, (unsigned int)((unsigned int)pi));
    zT_172 = zT_179;
    zT_180 = zF_FCDD1D35_astStoreNodeAt(zT_171, zT_172);
    pnode = zT_180;
    zT_181 = pnode.child_0;
    zT_182 = 0;
    if ((unsigned char)(zT_181 != (unsigned int)zT_182)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_218 = 1;
    zT_219 = (unsigned int)zT_218;
    zT_220 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_219)), 32u);
    zT_221 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_219)), 32u);
    zT_223 = zT_221 == (unsigned int)(0);
    if (!(zT_223)) { pal_trap(); }
    pi = zT_220;
    goto z_bb_31;
    z_bb_35:
    zT_185 = env;
    zT_186 = pnode.child_0;
    zT_190 = zF_F2107C15_resolveTypeExprFull(zT_185, zT_186, (unsigned int)(0));
    ptype = zT_190;
    if ((unsigned char)(ptypes_n >= (unsigned int)(64))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_193 = "panic: ";
    zT_194 = 7;
    fwrite(zT_193, 1, zT_194, stderr);
    zT_195 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_196 = 72;
    fwrite(zT_195, 1, zT_196, stderr);
    zT_197 = "\n";
    zT_198 = 1;
    fwrite(zT_197, 1, zT_198, stderr);
    pal_trap();
    z_bb_38:
    zT_201 = ptypes_n < (unsigned int)(64);
    if (!(zT_201)) { pal_trap(); }
    ptypes_buf[ptypes_n] = ptype;
    zT_202 = 1;
    zT_203 = zig_wrap_add_u(((zu64)(ptypes_n)), ((zu64)(zT_202)), 32u);
    zT_204 = zig_overflow_flag_add_u(((zu64)(ptypes_n)), ((zu64)(zT_202)), 32u);
    zT_206 = zT_204 == (unsigned int)(0);
    if (!(zT_206)) { pal_trap(); }
    ptypes_n = zT_203;
    if ((unsigned char)(ptype != (unsigned int)(18))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_209 = resolved_types;
    zT_210 = pnode.child_0;
    zT_211 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_209, zT_210, zT_211);
    goto z_bb_40;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_213 = env;
    zT_214 = pnode.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_213, zT_214, (unsigned int)(0));
    goto z_bb_40;
    z_bb_42:
    if ((unsigned char)(pf < ptypes_n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_231 = env->typereg;
    zT_235 = pf < (unsigned int)(64);
    if (!(zT_235)) { pal_trap(); }
    zT_232 = ptypes_buf[pf];
    zF_4C03AE3D_xtAppend(zT_231, zT_232);
    goto z_bb_45;
    z_bb_44:
    zT_244 = env->typereg;
    zT_245 = proto.name_id;
    zT_255 = mods.ptr;
    zT_256 = mods.len;
    zT_257 = mi < zT_256;
    if (!(zT_257)) { pal_trap(); }
    zT_258 = zT_255[mi];
    zT_246 = zT_258.id;
    zT_247 = is_ext;
    zT_248 = is_variadic;
    zT_249 = fn_start;
    zT_250 = proto.params_count;
    zT_261 = 0;
    zT_263 = (unsigned int)zT_261 < (unsigned int)(1);
    if (!(zT_263)) { pal_trap(); }
    zT_251 = rt_box[zT_261];
    zT_252 = proto.call_conv;
    zT_266 = zF_474336D7_typeRegistryGetOrCr(zT_244, zT_245, zT_246, zT_247, zT_248, zT_249, zT_250, zT_251, zT_252);
    tid = zT_266;
    zT_267 = resolved_types;
    zT_268 = decl_idx;
    zT_269 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_267, zT_268, zT_269);
    zT_271 = env->symbol_reg;
    zT_275 = mods.ptr;
    zT_276 = mods.len;
    zT_277 = mi < zT_276;
    if (!(zT_277)) { pal_trap(); }
    zT_278 = zT_275[mi];
    zT_272 = zT_278.id;
    zT_273 = proto.name_id;
    zT_281 = zF_A398987E_symbolRegistryQuali(zT_271, zT_272, zT_273);
    sym = zT_281;
    zT_282 = sym.has_value;
    if (zT_282) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_237 = 1;
    zT_238 = (unsigned int)zT_237;
    zT_239 = zig_wrap_add_u(((zu64)(pf)), ((zu64)(zT_238)), 32u);
    zT_240 = zig_overflow_flag_add_u(((zu64)(pf)), ((zu64)(zT_238)), 32u);
    zT_242 = zT_240 == (unsigned int)(0);
    if (!(zT_242)) { pal_trap(); }
    pf = zT_239;
    goto z_bb_42;
    z_bb_46:
    if (!(sym.has_value)) { pal_trap(); }
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_289 = decl.child_0;
    zT_290 = 0;
    zT_288 = zT_289 != (unsigned int)zT_290;
    goto z_bb_50;
    z_bb_49:
    zT_288 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_288) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_293 = env;
    zT_294 = decl.child_0;
    zT_298 = zF_F2107C15_resolveTypeExprFull(zT_293, zT_294, (unsigned int)(0));
    vtype = zT_298;
    if ((unsigned char)(vtype != (unsigned int)(18))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_12;
    z_bb_53:
    zT_301 = resolved_types;
    zT_302 = decl.child_0;
    zT_303 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_301, zT_302, zT_303);
    zT_305 = resolved_types;
    zT_306 = decl_idx;
    zT_307 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_305, zT_306, zT_307);
    zT_309 = env->symbol_reg;
    zT_313 = mods.ptr;
    zT_314 = mods.len;
    zT_315 = mi < zT_314;
    if (!(zT_315)) { pal_trap(); }
    zT_316 = zT_313[mi];
    zT_310 = zT_316.id;
    zT_318 = env->store;
    zT_319 = decl_idx;
    zT_321 = zF_8BA26B9E_astStoreNodePayload(zT_318, zT_319);
    zT_311 = zT_321;
    zT_322 = zF_A398987E_symbolRegistryQuali(zT_309, zT_310, zT_311);
    sym = zT_322;
    zT_323 = sym.has_value;
    if (zT_323) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    if (!(sym.has_value)) { pal_trap(); }
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_54;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_9;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_10;
    zT_ABC1EBBE_TypeResolveEnv zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_622E1E76_Opt_254 zT_15;
    zT_9BD83C17_Opt_442 zT_16;
    zT_99D838F1_Opt_444 zT_17;
    zT_ABC1EBBE_TypeResolveEnv* zT_18;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_22;
    zT_072B53A6_ModuleRegistry* zT_23;
    zT_ABC1EBBE_TypeResolveEnv* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_9 = module_reg;
    zT_10 = zF_3452C137_moduleRegistryGetMo(zT_9);
    mods = zT_10;
    zT_12.store = store;
    zT_12.typereg = typereg;
    zT_12.symbol_reg = symbol_reg;
    zT_12.interner = interner;
    zT_13 = 4294967295u;
    zT_12.module_id = zT_13;
    zT_14 = 0;
    zT_12.source_file_id = zT_14;
    zT_15.has_value = 1;
    zT_15.value = diag;
    zT_12.diag = zT_15;
    zT_16.has_value = 0;
    zT_12.local_consts = zT_16;
    zT_17.has_value = 0;
    zT_12.local_types = zT_17;
    env = zT_12;
    (void)perm_alloc;
    zT_18 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_19 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_18, zT_19);
    zT_21 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_22 = mods;
    zT_23 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_21, zT_22, zT_23);
    zT_25 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_26 = mods;
    zF_E2882212_resolveAggregateFie(zT_25, zT_26);
    zT_28 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_29 = mods;
    zT_30 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_28, zT_29, zT_30);
    return;
}

/* __module_init */
void zF_780653D2___module_init_13(void) {
    zT_52CDA6EF_DepEdge zT_0;
    zT_D3EB6303_StringInterner zT_1;
    zT_3D7259E2_SymbolRegistry zT_2;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    return;
}

/* EOF */
