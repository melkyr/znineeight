#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
unsigned int const zG_D3698568_TYPE_VOID = (unsigned int)(1);
unsigned int const zG_98A640DA_TYPE_BOOL = (unsigned int)(2);
unsigned int const zG_F9BAA47F_TYPE_NORETURN = (unsigned int)(3);
unsigned int const zG_8A81E76F_TYPE_I8 = (unsigned int)(4);
unsigned int const zG_51905DE6_TYPE_I16 = (unsigned int)(5);
unsigned int const zG_DD95B778_TYPE_I32 = (unsigned int)(6);
unsigned int const zG_518E1F4F_TYPE_I64 = (unsigned int)(7);
unsigned int const zG_023BECD3_TYPE_U8 = (unsigned int)(8);
unsigned int const zG_77674BAA_TYPE_U16 = (unsigned int)(9);
unsigned int const zG_7B6BCF24_TYPE_U32 = (unsigned int)(10);
unsigned int const zG_777894CB_TYPE_U64 = (unsigned int)(11);
unsigned int const zG_5C2F9844_TYPE_ISIZE = (unsigned int)(12);
unsigned int const zG_916E46A8_TYPE_USIZE = (unsigned int)(13);
unsigned int const zG_1E69444C_TYPE_C_CHAR = (unsigned int)(14);
unsigned int const zG_FD27E511_TYPE_F32 = (unsigned int)(15);
unsigned int const zG_712F5772_TYPE_F64 = (unsigned int)(16);
unsigned int const zG_41346447_TYPE_NULL = (unsigned int)(17);
unsigned int const zG_7DF595D2_TYPE_UNDEFINED = (unsigned int)(18);
unsigned int const zG_718E9CA1_TYPE_INT_LIT = (unsigned int)(19);
unsigned int const zG_1E022DA6_TYPE_TYPE = (unsigned int)(20);
unsigned int const zG_A87EA08C_TYPE_VA_LIST = (unsigned int)(21);
unsigned int const zG_4FF9553F_SLICE_FIELD_PTR = (unsigned int)(0);
unsigned int const zG_4B466382_SLICE_FIELD_LEN = (unsigned int)(1);
unsigned int const zG_269BE98A_TU_FIELD_TAG = (unsigned int)(0);
unsigned int const zG_C0257238_TU_FIELD_PAYLOAD = (unsigned int)(1);
unsigned int const zG_C7DB4B56_FIRST_USER_TYPE = (unsigned int)(20);
unsigned char const zG_5FFE6058_VOLATILE_FLAG = (unsigned char)(2);
unsigned char const zG_53F06A4B_CONST_FLAG = (unsigned char)(1);
unsigned char const zG_DFDEC5C8_FN_FLAG_VARIADIC = (unsigned char)(1);
unsigned char const zG_A9D5651E_FN_FLAG_STDCALL = (unsigned char)(2);
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_5426B97B_Arr_unsigned_char_1 zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)ubuf) + zT_15;
    zT_17 = (unsigned int)(16) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa((unsigned int)((unsigned int)used), zT_11);
    ulen = zT_19;
    zT_21 = 15;
    zT_22 = (unsigned int)ulen;
    zT_23 = zig_wrap_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    ustart = zT_23;
    zT_30 = 15;
    zT_31 = (unsigned char*)((unsigned char*)ubuf) + ustart;
    zT_32 = zT_30 - ustart;
    zT_33 = ustart <= zT_30;
    if (!(zT_33)) { pal_trap(); }
    zT_34.ptr = (unsigned char*)zT_31;
    zT_34.len = zT_32;
    zT_27 = zT_34;
    zF_E4B2EF19_stderr_write(zT_27);
    zT_36 = " -> ";
    zT_38 = 4;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    p1 = zT_37;
    zT_39 = p1;
    zF_E4B2EF19_stderr_write(zT_39);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_41[_i];
        _i++;
    }
}
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)nbuf) + zT_48;
    zT_50 = (unsigned int)(16) - zT_48;
    zT_51.ptr = (unsigned char*)zT_49;
    zT_51.len = zT_50;
    zT_44 = zT_51;
    zT_52 = zF_A7504564_itoa((unsigned int)((unsigned int)new_bytes), zT_44);
    nlen = zT_52;
    zT_54 = 15;
    zT_55 = (unsigned int)nlen;
    zT_56 = zig_wrap_sub_u(((zu64)(zT_54)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_sub_u(((zu64)(zT_54)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    nstart = zT_56;
    zT_63 = 15;
    zT_64 = (unsigned char*)((unsigned char*)nbuf) + nstart;
    zT_65 = zT_63 - nstart;
    zT_66 = nstart <= zT_63;
    if (!(zT_66)) { pal_trap(); }
    zT_67.ptr = (unsigned char*)zT_64;
    zT_67.len = zT_65;
    zT_60 = zT_67;
    zF_E4B2EF19_stderr_write(zT_60);
    zT_69 = "\n";
    zT_71 = 1;
    zT_70.ptr = (unsigned char*)zT_69;
    zT_70.len = zT_71;
    p2 = zT_70;
    zT_72 = p2;
    zF_E4B2EF19_stderr_write(zT_72);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_81AD2998_EU_952 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned char* zT_42;
    unsigned char* zT_43;
    unsigned char* zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned char zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    if ((unsigned char)(zT_6 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_12 = 2;
    zT_13 = zig_wrap_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_mul_u(((zu64)(zT_11)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_9 = zT_13;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_18 = alloc;
    zT_21 = zig_wrap_mul_u(((zu64)(elem_size)), ((zu64)(nc)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(elem_size)), ((zu64)(nc)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_19 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_18, zT_19, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_31 = *len_ptr;
    zT_32 = zig_wrap_mul_u(((zu64)(zT_31)), ((zu64)(elem_size)), 32u);
    zT_33 = zig_overflow_flag_mul_u(((zu64)(zT_31)), ((zu64)(elem_size)), 32u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_29 = zT_32;
    zT_36 = zig_wrap_mul_u(((zu64)(elem_size)), ((zu64)(nc)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(elem_size)), ((zu64)(nc)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_30 = zT_36;
    zF_9091237C_typeDbOom(zT_29, zT_30);
    return;
    z_bb_5:
    zT_28 = zT_26.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_28;
    zT_42 = *items_out;
    zT_43 = (unsigned char*)zT_42;
    src = zT_43;
    zT_45 = (unsigned char*)raw;
    dst = zT_45;
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    i = zT_48;
    goto z_bb_7;
    z_bb_7:
    zT_49 = *len_ptr;
    zT_50 = zig_wrap_mul_u(((zu64)(zT_49)), ((zu64)(elem_size)), 32u);
    zT_51 = zig_overflow_flag_mul_u(((zu64)(zT_49)), ((zu64)(elem_size)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    if ((unsigned char)(i < zT_50)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_55 = src[i];
    dst[i] = zT_55;
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    i = zT_58;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)(new_cap <= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* arrayReserve */
void zF_EC48931A_arrayReserve(unsigned char** items_out, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int cap) {
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_81AD2998_EU_952 zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned char* raw;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = alloc;
    zT_11 = zig_wrap_mul_u(((zu64)(elem_size)), ((zu64)(cap)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(elem_size)), ((zu64)(cap)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_9 = zT_11;
    zT_16 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = zig_wrap_mul_u(((zu64)(elem_size)), ((zu64)(cap)), 32u);
    zT_23 = zig_overflow_flag_mul_u(((zu64)(elem_size)), ((zu64)(cap)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_20 = zT_22;
    zF_9091237C_typeDbOom((unsigned int)(0), zT_20);
    return;
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_18;
    *items_out = raw;
    *cap_ptr = cap;
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_81AD2998_EU_952 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    zT_D155D06D_Type* zT_51;
    zT_D155D06D_Type* zT_52;
    unsigned int zT_53;
    int zT_54;
    zT_D155D06D_Type* zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_58;
    zT_D155D06D_Type* zT_59;
    unsigned int zT_60;
    unsigned int zT_65;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(nc < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->types_cap;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 32;
    if ((unsigned char)(nc < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 32;
    zT_21 = (unsigned int)zT_20;
    nc = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_23 = self->types_alloc;
    zT_27 = 20;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_38 = self->types_len;
    zT_39 = 20;
    zT_40 = zig_wrap_mul_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_36 = zT_40;
    zT_44 = 20;
    zT_45 = zig_wrap_mul_u(((zu64)(zT_44)), ((zu64)(nc)), 32u);
    zT_46 = zig_overflow_flag_mul_u(((zu64)(zT_44)), ((zu64)(nc)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_37 = zT_45;
    zF_9091237C_typeDbOom(zT_36, zT_37);
    return;
    z_bb_8:
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_35;
    zT_51 = (zT_D155D06D_Type*)raw;
    new_items = zT_51;
    zT_52 = self->types_items;
    zT_53 = self->types_len;
    zT_54 = 0;
    zT_55 = zT_52 + zT_54;
    zT_56 = zT_53 - zT_54;
    zT_57 = (unsigned int)zT_54 <= zT_53;
    if (!(zT_57)) { pal_trap(); }
    zT_58.ptr = (zT_D155D06D_Type*)zT_55;
    zT_58.len = zT_56;
    zT_59 = zT_58.ptr;
    zT_60 = zT_58.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_60)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_59[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
    z_bb_13:
    zT_65 = i + (unsigned int)(1);
    i = zT_65;
    goto z_bb_10;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_4028D896_Arr_unsigned_char_2 zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_4028D896_Arr_unsigned_char_2 zT_57;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    int zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    zT_4028D896_Arr_unsigned_char_2 zT_90;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_96;
    unsigned char* zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    unsigned char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_116;
    unsigned char* zT_117;
    unsigned int zT_118;
    unsigned char zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    unsigned char* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_BCE30624_typeRegistryEnsureC(zT_2, zT_3);
    zT_11 = self->types_len;
    zT_12 = (unsigned int)zT_11;
    id = zT_12;
    zT_13 = self->types_items;
    zT_14 = self->types_len;
    zT_13[zT_14] = t;
    zT_15 = self->types_len;
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    self->types_len = zT_18;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_23[_i];
        _i++;
    }
}
    zT_27 = t.kind;
    zT_31 = 0;
    zT_32 = (unsigned char*)((unsigned char*)dc_k) + zT_31;
    zT_33 = (unsigned int)(20) - zT_31;
    zT_34.ptr = (unsigned char*)zT_32;
    zT_34.len = zT_33;
    zT_26 = zT_34;
    zT_35 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_27), zT_26);
    dc_kl = zT_35;
    zT_37 = 19;
    zT_38 = (unsigned int)dc_kl;
    zT_39 = zig_wrap_sub_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_sub_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    dc_ks = zT_39;
    zT_44 = "DC:k";
    zT_46 = 4;
    zT_45.ptr = (unsigned char*)zT_44;
    zT_45.len = zT_46;
    dcm = zT_45;
    zT_47 = dcm;
    zF_B5478454_measureMarkerWrite(zT_47);
    zT_51 = 19;
    zT_52 = (unsigned char*)((unsigned char*)dc_k) + dc_ks;
    zT_53 = zT_51 - dc_ks;
    zT_54 = dc_ks <= zT_51;
    if (!(zT_54)) { pal_trap(); }
    zT_55.ptr = (unsigned char*)zT_52;
    zT_55.len = zT_53;
    zT_48 = zT_55;
    zF_B5478454_measureMarkerWrite(zT_48);
    zig_poison_fill((void*)&zT_57, (unsigned int)sizeof zT_57);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_57[_i];
        _i++;
    }
}
    zT_59 = t.name_id;
    zT_64 = 0;
    zT_65 = (unsigned char*)((unsigned char*)dc_n) + zT_64;
    zT_66 = (unsigned int)(20) - zT_64;
    zT_67.ptr = (unsigned char*)zT_65;
    zT_67.len = zT_66;
    zT_60 = zT_67;
    zT_68 = zF_A7504564_itoa(zT_59, zT_60);
    dc_nl = zT_68;
    zT_70 = 19;
    zT_71 = (unsigned int)dc_nl;
    zT_72 = zig_wrap_sub_u(((zu64)(zT_70)), ((zu64)(zT_71)), 32u);
    zT_73 = zig_overflow_flag_sub_u(((zu64)(zT_70)), ((zu64)(zT_71)), 32u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    dc_ns = zT_72;
    zT_77 = "n";
    zT_79 = 1;
    zT_78.ptr = (unsigned char*)zT_77;
    zT_78.len = zT_79;
    dcn = zT_78;
    zT_80 = dcn;
    zF_B5478454_measureMarkerWrite(zT_80);
    zT_84 = 19;
    zT_85 = (unsigned char*)((unsigned char*)dc_n) + dc_ns;
    zT_86 = zT_84 - dc_ns;
    zT_87 = dc_ns <= zT_84;
    if (!(zT_87)) { pal_trap(); }
    zT_88.ptr = (unsigned char*)zT_85;
    zT_88.len = zT_86;
    zT_81 = zT_88;
    zF_B5478454_measureMarkerWrite(zT_81);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_90[_i];
        _i++;
    }
}
    zT_92 = id;
    zT_96 = 0;
    zT_97 = (unsigned char*)((unsigned char*)dc_i) + zT_96;
    zT_98 = (unsigned int)(20) - zT_96;
    zT_99.ptr = (unsigned char*)zT_97;
    zT_99.len = zT_98;
    zT_93 = zT_99;
    zT_100 = zF_A7504564_itoa(zT_92, zT_93);
    dc_il = zT_100;
    zT_102 = 19;
    zT_103 = (unsigned int)dc_il;
    zT_104 = zig_wrap_sub_u(((zu64)(zT_102)), ((zu64)(zT_103)), 32u);
    zT_105 = zig_overflow_flag_sub_u(((zu64)(zT_102)), ((zu64)(zT_103)), 32u);
    zT_107 = zT_105 == (unsigned int)(0);
    if (!(zT_107)) { pal_trap(); }
    dc_is = zT_104;
    zT_109 = "t";
    zT_111 = 1;
    zT_110.ptr = (unsigned char*)zT_109;
    zT_110.len = zT_111;
    dci = zT_110;
    zT_112 = dci;
    zF_B5478454_measureMarkerWrite(zT_112);
    zT_116 = 19;
    zT_117 = (unsigned char*)((unsigned char*)dc_i) + dc_is;
    zT_118 = zT_116 - dc_is;
    zT_119 = dc_is <= zT_116;
    if (!(zT_119)) { pal_trap(); }
    zT_120.ptr = (unsigned char*)zT_117;
    zT_120.len = zT_118;
    zT_113 = zT_120;
    zF_B5478454_measureMarkerWrite(zT_113);
    zT_122 = "\n";
    zT_124 = 1;
    zT_123.ptr = (unsigned char*)zT_122;
    zT_123.len = zT_124;
    dcnl = zT_123;
    zT_125 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_125);
    zT_126 = t.kind;
    if ((unsigned char)(zT_126 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_130 = "X:";
    zT_132 = 2;
    zT_131.ptr = (unsigned char*)zT_130;
    zT_131.len = zT_132;
    xs = zT_131;
    zT_133 = xs;
    zT_134 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_133, zT_134);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_112BF819_PtrPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_112BF819_PtrPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->ptr_items;
    zT_3 = &self->ptr_len;
    zT_4 = &self->ptr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), zT_7);
    zT_21 = self->ptr_items;
    zT_22 = self->ptr_len;
    zT_21[zT_22] = v;
    zT_23 = self->ptr_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->ptr_len = zT_26;
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_E834303C_ArrayPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->array_items;
    zT_3 = &self->array_len;
    zT_4 = &self->array_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->array_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->array_items;
    zT_22 = self->array_len;
    zT_21[zT_22] = v;
    zT_23 = self->array_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->array_len = zT_26;
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_0BB2A741_SlicePayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->slice_items;
    zT_3 = &self->slice_len;
    zT_4 = &self->slice_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), zT_7);
    zT_21 = self->slice_items;
    zT_22 = self->slice_len;
    zT_21[zT_22] = v;
    zT_23 = self->slice_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->slice_len = zT_26;
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_0B10E8E9_OptionalPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->opt_items;
    zT_3 = &self->opt_len;
    zT_4 = &self->opt_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), zT_7);
    zT_21 = self->opt_items;
    zT_22 = self->opt_len;
    zT_21[zT_22] = v;
    zT_23 = self->opt_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->opt_len = zT_26;
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_42C2D6BF_EUPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->eu_items;
    zT_3 = &self->eu_len;
    zT_4 = &self->eu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->eu_items;
    zT_22 = self->eu_len;
    zT_21[zT_22] = v;
    zT_23 = self->eu_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->eu_len = zT_26;
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->es_items;
    zT_3 = &self->es_len;
    zT_4 = &self->es_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->es_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->es_items;
    zT_22 = self->es_len;
    zT_21[zT_22] = v;
    zT_23 = self->es_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->es_len = zT_26;
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_0317B1D5_FnPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->fn_items;
    zT_3 = &self->fn_len;
    zT_4 = &self->fn_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(24), zT_7);
    zT_21 = self->fn_items;
    zT_22 = self->fn_len;
    zT_21[zT_22] = v;
    zT_23 = self->fn_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->fn_len = zT_26;
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_406493CE_StructPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_406493CE_StructPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_FA398D58_PackedStructInfo zT_31;
    zT_FA398D58_PackedStructInfo zT_32;
    unsigned int zT_33;
    unsigned short zT_34;
    unsigned int zT_35;
    zT_8 = &self->st_items;
    zT_3 = &self->st_len;
    zT_4 = &self->st_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->st_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->st_items;
    zT_22 = self->st_len;
    zT_21[zT_22] = v;
    zT_23 = self->st_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->st_len = zT_26;
    zT_30 = self;
    zT_33 = 0;
    zT_32.pk_start = zT_33;
    zT_34 = 0;
    zT_32.pk_count = zT_34;
    zT_35 = 0;
    zT_32.total_bits = zT_35;
    zT_31 = zT_32;
    zF_925BA889_pkStructAppend(zT_30, zT_31);
    return;
}

/* pkStructAppend */
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_FA398D58_PackedStructInfo* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->pk_struct_items;
    zT_3 = &self->pk_struct_len;
    zT_4 = &self->pk_struct_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_struct_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), zT_7);
    zT_21 = self->pk_struct_items;
    zT_22 = self->pk_struct_len;
    zT_21[zT_22] = v;
    zT_23 = self->pk_struct_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->pk_struct_len = zT_26;
    return;
}

/* pkFieldAppend */
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry* self, zT_E276DDD0_PackedBitField v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_E276DDD0_PackedBitField** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_E276DDD0_PackedBitField* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->pk_items;
    zT_3 = &self->pk_len;
    zT_4 = &self->pk_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->pk_items;
    zT_22 = self->pk_len;
    zT_21[zT_22] = v;
    zT_23 = self->pk_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->pk_len = zT_26;
    return;
}

/* pkSetFields */
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_struct_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_457ECFEE_EnumPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->en_items;
    zT_3 = &self->en_len;
    zT_4 = &self->en_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->en_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), zT_7);
    zT_21 = self->en_items;
    zT_22 = self->en_len;
    zT_21[zT_22] = v;
    zT_23 = self->en_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->en_len = zT_26;
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_AF9231A2_UnionPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_FA398D58_PackedStructInfo zT_31;
    zT_FA398D58_PackedStructInfo zT_32;
    unsigned int zT_33;
    unsigned short zT_34;
    unsigned int zT_35;
    zT_8 = &self->un_items;
    zT_3 = &self->un_len;
    zT_4 = &self->un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->un_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), zT_7);
    zT_21 = self->un_items;
    zT_22 = self->un_len;
    zT_21[zT_22] = v;
    zT_23 = self->un_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->un_len = zT_26;
    zT_30 = self;
    zT_33 = 0;
    zT_32.pk_start = zT_33;
    zT_34 = 0;
    zT_32.pk_count = zT_34;
    zT_35 = 0;
    zT_32.total_bits = zT_35;
    zT_31 = zT_32;
    zF_96B8622A_pkUnStructAppend(zT_30, zT_31);
    return;
}

/* pkUnStructAppend */
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry* self, zT_FA398D58_PackedStructInfo v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_FA398D58_PackedStructInfo** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_FA398D58_PackedStructInfo* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->pk_un_items;
    zT_3 = &self->pk_un_len;
    zT_4 = &self->pk_un_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->pk_un_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), zT_7);
    zT_21 = self->pk_un_items;
    zT_22 = self->pk_un_len;
    zT_21[zT_22] = v;
    zT_23 = self->pk_un_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->pk_un_len = zT_26;
    return;
}

/* pkUnSetFields */
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry* self, unsigned int pk_idx, zT_FA398D58_PackedStructInfo v) {
    zT_FA398D58_PackedStructInfo* zT_3;
    unsigned int zT_4;
    zT_3 = self->pk_un_items;
    zT_4 = (unsigned int)pk_idx;
    zT_3[zT_4] = v;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_54FF90FA_TaggedUnionPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->tu_items;
    zT_3 = &self->tu_len;
    zT_4 = &self->tu_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), zT_7);
    zT_21 = self->tu_items;
    zT_22 = self->tu_len;
    zT_21[zT_22] = v;
    zT_23 = self->tu_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->tu_len = zT_26;
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_666DC2E1_TuplePayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->tup_items;
    zT_3 = &self->tup_len;
    zT_4 = &self->tup_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->tup_items;
    zT_22 = self->tup_len;
    zT_21[zT_22] = v;
    zT_23 = self->tup_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->tup_len = zT_26;
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_42E798B0_UnresolvedPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->unr_items;
    zT_3 = &self->unr_len;
    zT_4 = &self->unr_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(8), zT_7);
    zT_21 = self->unr_items;
    zT_22 = self->unr_len;
    zT_21[zT_22] = v;
    zT_23 = self->unr_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->unr_len = zT_26;
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_2DF01B61_FieldEntry* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->fe_items;
    zT_3 = &self->fe_len;
    zT_4 = &self->fe_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(12), zT_7);
    zT_21 = self->fe_items;
    zT_22 = self->fe_len;
    zT_21[zT_22] = v;
    zT_23 = self->fe_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->fe_len = zT_26;
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_D96DCDF2_EnumMember* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_8 = &self->em_items;
    zT_3 = &self->em_len;
    zT_4 = &self->em_cap;
    zT_5 = self->types_alloc;
    zT_15 = self->em_len;
    zT_16 = 1;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(16), zT_7);
    zT_21 = self->em_items;
    zT_22 = self->em_len;
    zT_21[zT_22] = v;
    zT_23 = self->em_len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->em_len = zT_26;
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_8 = &self->xt_items;
    zT_3 = &self->xt_len;
    zT_4 = &self->xt_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zT_16 = zig_wrap_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), zT_7);
    zT_20 = self->xt_items;
    zT_21 = self->xt_len;
    zT_20[zT_21] = v;
    zT_22 = self->xt_len;
    zT_23 = 1;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    self->xt_len = zT_25;
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_8 = &self->xn_items;
    zT_3 = &self->xn_len;
    zT_4 = &self->xn_cap;
    zT_5 = self->types_alloc;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zT_16 = zig_wrap_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure((unsigned char**)((unsigned char**)zT_8), zT_3, zT_4, zT_5, (unsigned int)(4), zT_7);
    zT_20 = self->xn_items;
    zT_21 = self->xn_len;
    zT_20[zT_21] = v;
    zT_22 = self->xn_len;
    zT_23 = 1;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    self->xn_len = zT_25;
    return;
}

/* typeWidthBitsForKind */
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_12;
    unsigned char zT_18;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_30;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(8);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(16);
    z_bb_13:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_18 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_16;
    z_bb_15:
    zT_18 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_18) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_21 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_19;
    z_bb_18:
    zT_21 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_21) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_22;
    z_bb_21:
    zT_24 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_24) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(32);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(64);
    z_bb_29:
    return (unsigned char)(0);
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_6;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned short zT_12;
    unsigned int zT_13;
    unsigned short zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    unsigned char p_wb;
    zT_5 = kind;
    zT_6 = zF_534230F8_typeWidthBitsForKin(zT_5);
    p_wb = zT_6;
    zT_7 = self;
    zT_9.kind = kind;
    zT_10 = 2;
    zT_9.state = zT_10;
    zT_11 = 0;
    zT_9.flags = zT_11;
    zT_9.iw = p_wb;
    zT_9.size = size;
    zT_12 = (unsigned short)zig_cast_checked_u((zu64)alignment, 32u, 0u, 16u);
    zT_9.alignment = zT_12;
    zT_13 = 0;
    zT_9.name_id = zT_13;
    zT_14 = 0;
    zT_9.module_id = zT_14;
    zT_15 = 0;
    zT_9.payload_idx = zT_15;
    zT_8 = zT_9;
    zT_16 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    return zT_16;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_2 = zig_wrap_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_3 = zig_overflow_flag_add_u(((zu64)(v)), ((zu64)(a)), 32u);
    zT_5 = zT_3 == (unsigned int)(0);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(zT_2)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = 1;
    zT_12 = zig_wrap_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_sub_u(((zu64)(a)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    return (unsigned int)(zT_7 & (unsigned int)(~zT_12));
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    *items = (unsigned char*)zT_3;
    *len = (unsigned int)(0);
    *cap = (unsigned int)(0);
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_A4CE86B7_U64ToU32Map zT_68;
    zT_3E40CD83_Sand* zT_69;
    zT_A4CE86B7_U64ToU32Map zT_70;
    zT_3E40CD83_Sand* zT_71;
    zT_A4CE86B7_U64ToU32Map zT_72;
    zT_3E40CD83_Sand* zT_73;
    zT_21D3708C_U32ToU32Map zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_A4CE86B7_U64ToU32Map zT_76;
    zT_3E40CD83_Sand* zT_77;
    zT_A4CE86B7_U64ToU32Map zT_78;
    zT_3E40CD83_Sand* zT_79;
    zT_A4CE86B7_U64ToU32Map zT_80;
    zT_3E40CD83_Sand* zT_81;
    zT_A4CE86B7_U64ToU32Map zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_21D3708C_U32ToU32Map zT_84;
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_74, (unsigned int)sizeof zT_74);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_82, (unsigned int)sizeof zT_82);
    zig_poison_fill((void*)&zT_84, (unsigned int)sizeof zT_84);
    zT_338B7C76_TypeRegistry reg;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zT_3.pk_items = (zT_E276DDD0_PackedBitField*)zT_58;
    zT_59 = 0;
    zT_3.pk_len = zT_59;
    zT_60 = 0;
    zT_3.pk_cap = zT_60;
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zT_3.pk_struct_items = (zT_FA398D58_PackedStructInfo*)zT_61;
    zT_62 = 0;
    zT_3.pk_struct_len = zT_62;
    zT_63 = 0;
    zT_3.pk_struct_cap = zT_63;
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zT_3.pk_un_items = (zT_FA398D58_PackedStructInfo*)zT_64;
    zT_65 = 0;
    zT_3.pk_un_len = zT_65;
    zT_66 = 0;
    zT_3.pk_un_cap = zT_66;
    zT_67 = alloc;
    zT_68 = zF_986226E1_u64ToU32MapInit(zT_67);
    zT_3.ptr_cache = zT_68;
    zT_69 = alloc;
    zT_70 = zF_986226E1_u64ToU32MapInit(zT_69);
    zT_3.many_ptr_cache = zT_70;
    zT_71 = alloc;
    zT_72 = zF_986226E1_u64ToU32MapInit(zT_71);
    zT_3.slice_cache = zT_72;
    zT_73 = alloc;
    zT_74 = zF_58BDA2DE_u32ToU32MapInit(zT_73);
    zT_3.optional_cache = zT_74;
    zT_75 = alloc;
    zT_76 = zF_986226E1_u64ToU32MapInit(zT_75);
    zT_3.array_cache = zT_76;
    zT_77 = alloc;
    zT_78 = zF_986226E1_u64ToU32MapInit(zT_77);
    zT_3.eu_cache = zT_78;
    zT_79 = alloc;
    zT_80 = zF_986226E1_u64ToU32MapInit(zT_79);
    zT_3.es_cache = zT_80;
    zT_81 = alloc;
    zT_82 = zF_986226E1_u64ToU32MapInit(zT_81);
    zT_3.name_cache = zT_82;
    zT_83 = alloc;
    zT_84 = zF_58BDA2DE_u32ToU32MapInit(zT_83);
    zT_3.c_name_map = zT_84;
    reg = zT_3;
    return reg;
}

/* typeRegistryInitSized */
zT_338B7C76_TypeRegistry zF_28AE6613_typeRegistryInitSiz(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, unsigned int type_hint, unsigned int name_hint) {
    zT_3E40CD83_Sand* zT_5;
    zT_D3EB6303_StringInterner* zT_6;
    zT_338B7C76_TypeRegistry zT_7;
    unsigned int zT_9;
    unsigned int zT_13;
    zT_3E40CD83_Sand* zT_14;
    unsigned char zT_19;
    zT_A4CE86B7_U64ToU32Map zT_20;
    zT_3E40CD83_Sand* zT_21;
    unsigned char zT_26;
    zT_A4CE86B7_U64ToU32Map zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned char zT_33;
    zT_A4CE86B7_U64ToU32Map zT_34;
    zT_3E40CD83_Sand* zT_35;
    unsigned char zT_40;
    zT_21D3708C_U32ToU32Map zT_41;
    zT_3E40CD83_Sand* zT_42;
    unsigned char zT_47;
    zT_A4CE86B7_U64ToU32Map zT_48;
    zT_3E40CD83_Sand* zT_49;
    zT_A4CE86B7_U64ToU32Map zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_A4CE86B7_U64ToU32Map zT_56;
    zT_3E40CD83_Sand* zT_57;
    unsigned int zT_58;
    zT_A4CE86B7_U64ToU32Map zT_59;
    zT_338B7C76_TypeRegistry* zT_60;
    unsigned int zT_61;
    unsigned int* zT_64;
    zT_3E40CD83_Sand* zT_65;
    zT_338B7C76_TypeRegistry* zT_68;
    zT_112BF819_PtrPayload** zT_69;
    zT_338B7C76_TypeRegistry* zT_71;
    unsigned char zT_78;
    unsigned int* zT_80;
    zT_3E40CD83_Sand* zT_81;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_E834303C_ArrayPayload** zT_85;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned char zT_94;
    unsigned int* zT_96;
    zT_3E40CD83_Sand* zT_97;
    zT_338B7C76_TypeRegistry* zT_100;
    zT_0BB2A741_SlicePayload** zT_101;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned char zT_110;
    unsigned int* zT_112;
    zT_3E40CD83_Sand* zT_113;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_0B10E8E9_OptionalPayload** zT_117;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned char zT_126;
    unsigned int* zT_128;
    zT_3E40CD83_Sand* zT_129;
    zT_338B7C76_TypeRegistry* zT_132;
    zT_42C2D6BF_EUPayload** zT_133;
    zT_338B7C76_TypeRegistry* zT_135;
    unsigned int* zT_141;
    zT_3E40CD83_Sand* zT_142;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_0B73C507_ErrorSetPayload** zT_146;
    zT_338B7C76_TypeRegistry* zT_148;
    unsigned int* zT_154;
    zT_3E40CD83_Sand* zT_155;
    zT_338B7C76_TypeRegistry* zT_158;
    zT_0317B1D5_FnPayload** zT_159;
    zT_338B7C76_TypeRegistry* zT_161;
    unsigned char zT_168;
    unsigned int* zT_170;
    zT_3E40CD83_Sand* zT_171;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_406493CE_StructPayload** zT_175;
    zT_338B7C76_TypeRegistry* zT_177;
    unsigned char zT_184;
    unsigned int* zT_186;
    zT_3E40CD83_Sand* zT_187;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_457ECFEE_EnumPayload** zT_191;
    zT_338B7C76_TypeRegistry* zT_193;
    unsigned int* zT_199;
    zT_3E40CD83_Sand* zT_200;
    zT_338B7C76_TypeRegistry* zT_203;
    zT_AF9231A2_UnionPayload** zT_204;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int* zT_212;
    zT_3E40CD83_Sand* zT_213;
    zT_338B7C76_TypeRegistry* zT_216;
    zT_54FF90FA_TaggedUnionPayload** zT_217;
    zT_338B7C76_TypeRegistry* zT_219;
    unsigned int* zT_225;
    zT_3E40CD83_Sand* zT_226;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_666DC2E1_TuplePayload** zT_230;
    zT_338B7C76_TypeRegistry* zT_232;
    unsigned int* zT_238;
    zT_3E40CD83_Sand* zT_239;
    zT_338B7C76_TypeRegistry* zT_242;
    zT_42E798B0_UnresolvedPayload** zT_243;
    zT_338B7C76_TypeRegistry* zT_245;
    unsigned int* zT_251;
    zT_3E40CD83_Sand* zT_252;
    zT_338B7C76_TypeRegistry* zT_255;
    zT_2DF01B61_FieldEntry** zT_256;
    zT_338B7C76_TypeRegistry* zT_258;
    unsigned char zT_265;
    unsigned int* zT_267;
    zT_3E40CD83_Sand* zT_268;
    zT_338B7C76_TypeRegistry* zT_271;
    zT_D96DCDF2_EnumMember** zT_272;
    zT_338B7C76_TypeRegistry* zT_274;
    unsigned char zT_281;
    unsigned int* zT_283;
    zT_3E40CD83_Sand* zT_284;
    unsigned int zT_286;
    zT_338B7C76_TypeRegistry* zT_287;
    unsigned int** zT_288;
    zT_338B7C76_TypeRegistry* zT_290;
    unsigned int* zT_294;
    zT_3E40CD83_Sand* zT_295;
    zT_338B7C76_TypeRegistry* zT_298;
    unsigned int** zT_299;
    zT_338B7C76_TypeRegistry* zT_301;
    unsigned char zT_307;
    unsigned int* zT_309;
    zT_3E40CD83_Sand* zT_310;
    zT_338B7C76_TypeRegistry* zT_313;
    zT_E276DDD0_PackedBitField** zT_314;
    zT_338B7C76_TypeRegistry* zT_316;
    unsigned char zT_323;
    unsigned int* zT_325;
    zT_3E40CD83_Sand* zT_326;
    zT_338B7C76_TypeRegistry* zT_329;
    zT_FA398D58_PackedStructInfo** zT_330;
    zT_338B7C76_TypeRegistry* zT_332;
    unsigned char zT_339;
    unsigned int* zT_341;
    zT_3E40CD83_Sand* zT_342;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_FA398D58_PackedStructInfo** zT_346;
    zT_338B7C76_TypeRegistry* zT_348;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_338B7C76_TypeRegistry reg;
    unsigned int th;
    unsigned int nh;
    zT_5 = alloc;
    zT_6 = interner;
    zT_7 = zF_4801746C_typeRegistryInit(zT_5, zT_6);
    reg = zT_7;
    zT_9 = (unsigned int)type_hint;
    th = zT_9;
    if ((unsigned char)(th == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return reg;
    z_bb_2:
    zT_13 = (unsigned int)name_hint;
    nh = zT_13;
    zT_14 = alloc;
    zT_19 = 1;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zF_CE4144CF_u64ToU32MapInitCap(zT_14, (unsigned int)(th / (unsigned int)(16)));
    reg.ptr_cache = zT_20;
    zT_21 = alloc;
    zT_26 = 1;
    if (!(zT_26)) { pal_trap(); }
    zT_27 = zF_CE4144CF_u64ToU32MapInitCap(zT_21, (unsigned int)(th / (unsigned int)(64)));
    reg.many_ptr_cache = zT_27;
    zT_28 = alloc;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_34 = zF_CE4144CF_u64ToU32MapInitCap(zT_28, (unsigned int)(th / (unsigned int)(128)));
    reg.slice_cache = zT_34;
    zT_35 = alloc;
    zT_40 = 1;
    if (!(zT_40)) { pal_trap(); }
    zT_41 = zF_619D56E6_u32ToU32MapInitCap(zT_35, (unsigned int)(th / (unsigned int)(128)));
    reg.optional_cache = zT_41;
    zT_42 = alloc;
    zT_47 = 1;
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zF_CE4144CF_u64ToU32MapInitCap(zT_42, (unsigned int)(th / (unsigned int)(32)));
    reg.array_cache = zT_48;
    zT_49 = alloc;
    zT_52 = zF_CE4144CF_u64ToU32MapInitCap(zT_49, (unsigned int)(8));
    reg.eu_cache = zT_52;
    zT_53 = alloc;
    zT_56 = zF_CE4144CF_u64ToU32MapInitCap(zT_53, (unsigned int)(4));
    reg.es_cache = zT_56;
    zT_57 = alloc;
    zT_58 = nh;
    zT_59 = zF_CE4144CF_u64ToU32MapInitCap(zT_57, zT_58);
    reg.name_cache = zT_59;
    zT_60 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_61 = th;
    zF_BCE30624_typeRegistryEnsureC(zT_60, zT_61);
    zT_68 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_69 = &zT_68->ptr_items;
    zT_71 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_64 = &zT_71->ptr_cap;
    zT_65 = alloc;
    zT_78 = 1;
    if (!(zT_78)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_69), zT_64, zT_65, (unsigned int)(4), (unsigned int)(th / (unsigned int)(8)));
    zT_84 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_85 = &zT_84->array_items;
    zT_87 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_80 = &zT_87->array_cap;
    zT_81 = alloc;
    zT_94 = 1;
    if (!(zT_94)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_85), zT_80, zT_81, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_100 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_101 = &zT_100->slice_items;
    zT_103 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_96 = &zT_103->slice_cap;
    zT_97 = alloc;
    zT_110 = 1;
    if (!(zT_110)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_101), zT_96, zT_97, (unsigned int)(4), (unsigned int)(th / (unsigned int)(64)));
    zT_116 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_117 = &zT_116->opt_items;
    zT_119 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_112 = &zT_119->opt_cap;
    zT_113 = alloc;
    zT_126 = 1;
    if (!(zT_126)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_117), zT_112, zT_113, (unsigned int)(4), (unsigned int)(th / (unsigned int)(64)));
    zT_132 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_133 = &zT_132->eu_items;
    zT_135 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_128 = &zT_135->eu_cap;
    zT_129 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_133), zT_128, zT_129, (unsigned int)(8), (unsigned int)(16));
    zT_145 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_146 = &zT_145->es_items;
    zT_148 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_141 = &zT_148->es_cap;
    zT_142 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_146), zT_141, zT_142, (unsigned int)(8), (unsigned int)(8));
    zT_158 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_159 = &zT_158->fn_items;
    zT_161 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_154 = &zT_161->fn_cap;
    zT_155 = alloc;
    zT_168 = 1;
    if (!(zT_168)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_159), zT_154, zT_155, (unsigned int)(24), (unsigned int)(th / (unsigned int)(2)));
    zT_174 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_175 = &zT_174->st_items;
    zT_177 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_170 = &zT_177->st_cap;
    zT_171 = alloc;
    zT_184 = 1;
    if (!(zT_184)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_175), zT_170, zT_171, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_190 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_191 = &zT_190->en_items;
    zT_193 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_186 = &zT_193->en_cap;
    zT_187 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_191), zT_186, zT_187, (unsigned int)(16), (unsigned int)(32));
    zT_203 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_204 = &zT_203->un_items;
    zT_206 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_199 = &zT_206->un_cap;
    zT_200 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_204), zT_199, zT_200, (unsigned int)(12), (unsigned int)(8));
    zT_216 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_217 = &zT_216->tu_items;
    zT_219 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_212 = &zT_219->tu_cap;
    zT_213 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_217), zT_212, zT_213, (unsigned int)(12), (unsigned int)(8));
    zT_229 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_230 = &zT_229->tup_items;
    zT_232 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_225 = &zT_232->tup_cap;
    zT_226 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_230), zT_225, zT_226, (unsigned int)(8), (unsigned int)(8));
    zT_242 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_243 = &zT_242->unr_items;
    zT_245 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_238 = &zT_245->unr_cap;
    zT_239 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_243), zT_238, zT_239, (unsigned int)(8), (unsigned int)(8));
    zT_255 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_256 = &zT_255->fe_items;
    zT_258 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_251 = &zT_258->fe_cap;
    zT_252 = alloc;
    zT_265 = 1;
    if (!(zT_265)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_256), zT_251, zT_252, (unsigned int)(12), (unsigned int)(th / (unsigned int)(2)));
    zT_271 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_272 = &zT_271->em_items;
    zT_274 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_267 = &zT_274->em_cap;
    zT_268 = alloc;
    zT_281 = 1;
    if (!(zT_281)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_272), zT_267, zT_268, (unsigned int)(16), (unsigned int)(th / (unsigned int)(16)));
    zT_287 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_288 = &zT_287->xt_items;
    zT_290 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_283 = &zT_290->xt_cap;
    zT_284 = alloc;
    zT_286 = th;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_288), zT_283, zT_284, (unsigned int)(4), zT_286);
    zT_298 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_299 = &zT_298->xn_items;
    zT_301 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_294 = &zT_301->xn_cap;
    zT_295 = alloc;
    zT_307 = 1;
    if (!(zT_307)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_299), zT_294, zT_295, (unsigned int)(4), (unsigned int)(th / (unsigned int)(16)));
    zT_313 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_314 = &zT_313->pk_items;
    zT_316 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_309 = &zT_316->pk_cap;
    zT_310 = alloc;
    zT_323 = 1;
    if (!(zT_323)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_314), zT_309, zT_310, (unsigned int)(8), (unsigned int)(th / (unsigned int)(16)));
    zT_329 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_330 = &zT_329->pk_struct_items;
    zT_332 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_325 = &zT_332->pk_struct_cap;
    zT_326 = alloc;
    zT_339 = 1;
    if (!(zT_339)) { pal_trap(); }
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_330), zT_325, zT_326, (unsigned int)(12), (unsigned int)(th / (unsigned int)(16)));
    zT_345 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_346 = &zT_345->pk_un_items;
    zT_348 = (zT_338B7C76_TypeRegistry*)&reg;
    zT_341 = &zT_348->pk_un_cap;
    zT_342 = alloc;
    zF_EC48931A_arrayReserve((unsigned char**)((unsigned char**)zT_346), zT_341, zT_342, (unsigned int)(12), (unsigned int)(8));
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    zT_79FAE712_u64 zT_9;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    zT_9 = key & (zT_79FAE712_u64)(4294967295u);
    key_lo = zT_9;
    if ((unsigned char)(key_lo == (zT_79FAE712_u64)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = (unsigned char*)zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    if (!(val.has_value)) { pal_trap(); }
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_79FAE712_u64 zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned char zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    zT_4028D896_Arr_unsigned_char_2 zT_43;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    int zT_49;
    unsigned char* zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_69;
    unsigned char* zT_70;
    unsigned int zT_71;
    unsigned char zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_3 = &self->name_cache;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_13 = key & (zT_79FAE712_u64)(65535);
    zT_10 = (unsigned int)zig_cast_checked_u((zu64)zT_13, 64u, 0u, 32u);
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)np_k) + zT_17;
    zT_19 = (unsigned int)(20) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa(zT_10, zT_11);
    np_kl = zT_21;
    zT_23 = 19;
    zT_24 = (unsigned int)np_kl;
    zT_25 = zig_wrap_sub_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_sub_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    np_ks = zT_25;
    zT_30 = "NP:k";
    zT_32 = 4;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    npm = zT_31;
    zT_33 = npm;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_37 = 19;
    zT_38 = (unsigned char*)((unsigned char*)np_k) + np_ks;
    zT_39 = zT_37 - np_ks;
    zT_40 = np_ks <= zT_37;
    if (!(zT_40)) { pal_trap(); }
    zT_41.ptr = (unsigned char*)zT_38;
    zT_41.len = zT_39;
    zT_34 = zT_41;
    zF_48AC7B3A_markerWrite(zT_34);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_43[_i];
        _i++;
    }
}
    zT_45 = value;
    zT_49 = 0;
    zT_50 = (unsigned char*)((unsigned char*)np_v) + zT_49;
    zT_51 = (unsigned int)(20) - zT_49;
    zT_52.ptr = (unsigned char*)zT_50;
    zT_52.len = zT_51;
    zT_46 = zT_52;
    zT_53 = zF_A7504564_itoa(zT_45, zT_46);
    np_vl = zT_53;
    zT_55 = 19;
    zT_56 = (unsigned int)np_vl;
    zT_57 = zig_wrap_sub_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_sub_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    np_vs = zT_57;
    zT_62 = "v";
    zT_64 = 1;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    npv = zT_63;
    zT_65 = npv;
    zF_48AC7B3A_markerWrite(zT_65);
    zT_69 = 19;
    zT_70 = (unsigned char*)((unsigned char*)np_v) + np_vs;
    zT_71 = zT_69 - np_vs;
    zT_72 = np_vs <= zT_69;
    if (!(zT_72)) { pal_trap(); }
    zT_73.ptr = (unsigned char*)zT_70;
    zT_73.len = zT_71;
    zT_66 = zT_73;
    zF_48AC7B3A_markerWrite(zT_66);
    zT_75 = "\n";
    zT_77 = 1;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    npnl = zT_76;
    zT_78 = npnl;
    zF_48AC7B3A_markerWrite(zT_78);
    return;
}

/* typeRegistryCNameIdGet */
unsigned int zF_41B57F53_typeRegistryCNameId(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned char zT_6;
    unsigned int zT_7;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = &self->c_name_map;
    zT_3 = tid;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_7 = 0;
    goto z_bb_3;
    z_bb_2:
    if (!(zT_5.has_value)) { pal_trap(); }
    zT_7 = zT_5.value;
    goto z_bb_3;
    z_bb_3:
    return zT_7;
}

/* typeRegistryCNameIdSet */
void zF_6D108807_typeRegistryCNameId(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int c_name_id) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = &self->c_name_map;
    zT_4 = tid;
    zT_5 = c_name_id;
    zF_26476265_u32ToU32MapPut(zT_3, zT_4, zT_5);
    return;
}

/* typeSliceElementName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_28D4FDB0_typeSliceElementNam(zT_338B7C76_TypeRegistry* self, zT_CEC2984A_NameMangler* mangler, unsigned int elem_tid) {
    zT_D155D06D_Type* zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type zT_7;
    unsigned int zT_8;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_CEC2984A_NameMangler* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_CEC2984A_NameMangler* zT_16;
    unsigned int zT_17;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zT_338B7C76_TypeRegistry* reg;
    zT_D155D06D_Type elem_ty;
    unsigned int elem_mid;
    reg = self;
    zT_5 = reg->types_items;
    zT_6 = (unsigned int)elem_tid;
    zT_7 = zT_5[zT_6];
    elem_ty = zT_7;
    zT_8 = elem_ty.name_id;
    if ((unsigned char)(zT_8 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = reg;
    zT_12 = mangler;
    zT_13 = elem_tid;
    zT_14 = zF_08CFA1F1_typeCName(zT_11, zT_12, zT_13);
    return zT_14;
    z_bb_2:
    zT_16 = mangler;
    zT_17 = elem_ty.name_id;
    zT_23 = zF_713D1938_nameManglerMangle(zT_16, zT_17, (unsigned char)(2), (unsigned int)(0));
    elem_mid = zT_23;
    zT_24 = mangler->interner;
    zT_25 = elem_mid;
    zT_27 = zF_9134020D_stringInternerGet(zT_24, zT_25);
    return zT_27;
}

/* typeCName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08CFA1F1_typeCName(zT_338B7C76_TypeRegistry* self, zT_CEC2984A_NameMangler* mangler, unsigned int tid) {
    zT_D155D06D_Type* zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type zT_7;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_4028D896_Arr_unsigned_char_2 zT_16;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned char zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_4028D896_Arr_unsigned_char_2 zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_33EF6BFB_TypeKind zT_52;
    int zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    unsigned char zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_33EF6BFB_TypeKind zT_83;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_33EF6BFB_TypeKind zT_90;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_33EF6BFB_TypeKind zT_97;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_111;
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_33EF6BFB_TypeKind zT_118;
    zT_CEC2984A_NameMangler* zT_122;
    unsigned int zT_123;
    unsigned short zT_128;
    unsigned int zT_130;
    zT_D3EB6303_StringInterner* zT_131;
    unsigned int zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    unsigned char* zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    unsigned char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_33EF6BFB_TypeKind zT_149;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_33EF6BFB_TypeKind zT_156;
    zT_CEC2984A_NameMangler* zT_160;
    unsigned int zT_161;
    unsigned short zT_166;
    unsigned int zT_168;
    zT_D3EB6303_StringInterner* zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    zT_33EF6BFB_TypeKind zT_173;
    unsigned int zT_176;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_338B7C76_TypeRegistry* zT_193;
    zT_CEC2984A_NameMangler* zT_194;
    unsigned int zT_196;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    unsigned int zT_205;
    unsigned char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char* zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_338B7C76_TypeRegistry* zT_222;
    zT_CEC2984A_NameMangler* zT_223;
    unsigned int zT_225;
    unsigned char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_33EF6BFB_TypeKind zT_231;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_33EF6BFB_TypeKind zT_238;
    zT_CEC2984A_NameMangler* zT_242;
    unsigned int zT_243;
    unsigned short zT_248;
    unsigned int zT_250;
    zT_D3EB6303_StringInterner* zT_251;
    unsigned int zT_252;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_33EF6BFB_TypeKind zT_255;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_33EF6BFB_TypeKind zT_262;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_33EF6BFB_TypeKind zT_269;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    unsigned char* zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned int zT_282;
    zT_33EF6BFB_TypeKind zT_283;
    zT_CEC2984A_NameMangler* zT_287;
    unsigned int zT_288;
    unsigned short zT_293;
    unsigned int zT_295;
    zT_D3EB6303_StringInterner* zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_33EF6BFB_TypeKind zT_300;
    zT_E834303C_ArrayPayload* zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    zT_E834303C_ArrayPayload zT_307;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_CEC2984A_NameMangler* zT_310;
    unsigned int zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    zT_5426B97B_Arr_unsigned_char_1 zT_315;
    unsigned int zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    int zT_322;
    unsigned char* zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned char zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned char zT_338;
    unsigned char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_CEC2984A_NameMangler* zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned char zT_355;
    unsigned char* zT_356;
    unsigned int zT_357;
    unsigned char zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    zT_5426B97B_Arr_unsigned_char_1 zT_366;
    unsigned int zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    int zT_372;
    unsigned char* zT_373;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    unsigned int zT_376;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned char zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned char zT_388;
    unsigned char* zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned int zT_392;
    unsigned char* zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395;
    unsigned int zT_396;
    zT_CEC2984A_NameMangler* zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    unsigned char zT_409;
    unsigned char* zT_410;
    unsigned int zT_411;
    unsigned char zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    zT_33EF6BFB_TypeKind zT_416;
    unsigned char zT_419;
    zT_33EF6BFB_TypeKind zT_420;
    zT_112BF819_PtrPayload* zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    zT_112BF819_PtrPayload zT_427;
    zT_D155D06D_Type* zT_429;
    unsigned int zT_430;
    unsigned int zT_431;
    zT_D155D06D_Type zT_432;
    unsigned char zT_434;
    unsigned char zT_438;
    zT_33EF6BFB_TypeKind zT_439;
    zT_338B7C76_TypeRegistry* zT_442;
    zT_CEC2984A_NameMangler* zT_443;
    unsigned int zT_445;
    unsigned char zT_448;
    unsigned char zT_449;
    unsigned char zT_454;
    zT_33EF6BFB_TypeKind zT_455;
    zT_E834303C_ArrayPayload* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    zT_E834303C_ArrayPayload zT_462;
    unsigned int zT_463;
    unsigned char* zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    zT_33EF6BFB_TypeKind zT_471;
    unsigned char* zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned int zT_477;
    zT_33EF6BFB_TypeKind zT_478;
    unsigned char* zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    zT_33EF6BFB_TypeKind zT_485;
    unsigned char* zT_489;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_490;
    unsigned int zT_491;
    zT_33EF6BFB_TypeKind zT_492;
    unsigned char* zT_496;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_497;
    unsigned int zT_498;
    zT_33EF6BFB_TypeKind zT_499;
    unsigned char* zT_503;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_504;
    unsigned int zT_505;
    zT_338B7C76_TypeRegistry* zT_507;
    zT_CEC2984A_NameMangler* zT_508;
    unsigned int zT_509;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_511;
    zT_C4003E6D_Arr_unsigned_char_1 zT_513;
    int zT_515;
    unsigned int zT_516;
    zT_33EF6BFB_TypeKind zT_518;
    unsigned char zT_521;
    zT_33EF6BFB_TypeKind zT_522;
    unsigned char zT_525;
    unsigned char* zT_528;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_529;
    unsigned int zT_530;
    int zT_532;
    unsigned int zT_533;
    unsigned int zT_535;
    unsigned char zT_537;
    int zT_538;
    unsigned char* zT_540;
    unsigned int zT_541;
    unsigned char zT_542;
    unsigned char zT_543;
    unsigned char zT_545;
    int zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned char zT_551;
    int zT_552;
    unsigned int zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    unsigned char zT_557;
    int zT_559;
    unsigned int zT_560;
    unsigned int zT_562;
    unsigned char zT_564;
    int zT_565;
    unsigned char* zT_567;
    unsigned int zT_568;
    unsigned char zT_569;
    unsigned char zT_570;
    unsigned char zT_572;
    int zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    unsigned char zT_578;
    int zT_579;
    unsigned int zT_580;
    unsigned int zT_581;
    unsigned int zT_582;
    unsigned char zT_584;
    unsigned char zT_585;
    unsigned char* zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_589;
    int zT_591;
    unsigned int zT_592;
    unsigned int zT_594;
    unsigned char zT_596;
    int zT_597;
    unsigned char* zT_599;
    unsigned int zT_600;
    unsigned char zT_601;
    unsigned char zT_602;
    unsigned char zT_604;
    int zT_605;
    unsigned int zT_606;
    unsigned int zT_607;
    unsigned int zT_608;
    unsigned char zT_610;
    int zT_611;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    unsigned char zT_616;
    unsigned char zT_617;
    unsigned char zT_619;
    int zT_620;
    unsigned int zT_621;
    unsigned int zT_622;
    unsigned int zT_623;
    unsigned char zT_625;
    int zT_626;
    unsigned char zT_627;
    unsigned char zT_629;
    int zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    unsigned int zT_633;
    unsigned char zT_635;
    zT_D3EB6303_StringInterner* zT_637;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_638;
    unsigned int zT_642;
    unsigned int zT_643;
    unsigned int zT_644;
    unsigned char zT_646;
    int zT_647;
    unsigned char* zT_648;
    unsigned int zT_649;
    unsigned char zT_650;
    unsigned char zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    unsigned int zT_653;
    zT_D3EB6303_StringInterner* zT_654;
    unsigned int zT_655;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_657;
    zT_33EF6BFB_TypeKind zT_658;
    unsigned char* zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    unsigned int zT_664;
    zT_33EF6BFB_TypeKind zT_665;
    unsigned char* zT_669;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_670;
    unsigned int zT_671;
    zT_33EF6BFB_TypeKind zT_672;
    unsigned char* zT_676;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_677;
    unsigned int zT_678;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_679;
    unsigned char* zT_681;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_682;
    unsigned int zT_683;
    zT_33EF6BFB_TypeKind zT_684;
    zT_0BB2A741_SlicePayload* zT_688;
    unsigned int zT_689;
    unsigned int zT_690;
    zT_0BB2A741_SlicePayload zT_691;
    zT_338B7C76_TypeRegistry* zT_693;
    zT_CEC2984A_NameMangler* zT_694;
    unsigned int zT_695;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    unsigned char* zT_699;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_700;
    unsigned int zT_701;
    unsigned char* zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    unsigned int zT_705;
    zT_CEC2984A_NameMangler* zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_712;
    zT_33EF6BFB_TypeKind zT_713;
    zT_0B10E8E9_OptionalPayload* zT_717;
    unsigned int zT_718;
    unsigned int zT_719;
    zT_0B10E8E9_OptionalPayload zT_720;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_722;
    unsigned int zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_725;
    int zT_729;
    unsigned char* zT_730;
    unsigned int zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    unsigned int zT_733;
    unsigned int zT_735;
    unsigned int zT_736;
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned char zT_740;
    unsigned char* zT_742;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_743;
    unsigned int zT_744;
    unsigned char* zT_746;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_747;
    unsigned int zT_748;
    zT_CEC2984A_NameMangler* zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_751;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_752;
    unsigned int zT_756;
    unsigned char* zT_757;
    unsigned int zT_758;
    unsigned char zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_762;
    zT_338B7C76_TypeRegistry* zT_764;
    unsigned int zT_765;
    unsigned int zT_766;
    int zT_767;
    zT_D3EB6303_StringInterner* zT_769;
    unsigned int zT_770;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_772;
    zT_33EF6BFB_TypeKind zT_773;
    zT_42C2D6BF_EUPayload* zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    zT_42C2D6BF_EUPayload zT_780;
    zT_C41F1B06_Arr_unsigned_char_6 zT_782;
    unsigned int zT_784;
    unsigned char* zT_786;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_787;
    unsigned int zT_788;
    unsigned int zT_790;
    unsigned int zT_792;
    unsigned char zT_794;
    unsigned char* zT_797;
    unsigned int zT_798;
    unsigned char zT_799;
    unsigned char zT_800;
    unsigned char zT_802;
    unsigned int zT_803;
    unsigned int zT_804;
    unsigned int zT_805;
    unsigned char zT_807;
    unsigned int zT_808;
    unsigned int zT_809;
    unsigned int zT_810;
    unsigned char zT_812;
    unsigned int zT_814;
    unsigned char zT_818;
    unsigned int zT_820;
    unsigned int zT_822;
    unsigned char zT_824;
    unsigned int zT_825;
    unsigned int zT_826;
    unsigned char zT_828;
    unsigned char zT_829;
    unsigned char zT_831;
    unsigned int zT_833;
    unsigned char zT_835;
    unsigned int zT_838;
    unsigned int zT_839;
    unsigned int zT_840;
    unsigned char zT_842;
    zT_CEC2984A_NameMangler* zT_844;
    unsigned int zT_845;
    zT_D3EB6303_StringInterner* zT_848;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_849;
    int zT_853;
    unsigned char* zT_854;
    unsigned int zT_855;
    unsigned char zT_856;
    unsigned char zT_857;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_858;
    unsigned int zT_859;
    unsigned int zT_862;
    zT_338B7C76_TypeRegistry* zT_863;
    unsigned int zT_864;
    unsigned int zT_865;
    zT_D3EB6303_StringInterner* zT_866;
    unsigned int zT_867;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    zT_33EF6BFB_TypeKind zT_870;
    zT_0317B1D5_FnPayload* zT_874;
    unsigned int zT_875;
    unsigned int zT_876;
    zT_0317B1D5_FnPayload zT_877;
    zT_443A2803_Arr_unsigned_char_9 zT_879;
    unsigned int zT_881;
    unsigned char zT_882;
    int zT_883;
    unsigned char zT_885;
    unsigned char zT_886;
    int zT_887;
    unsigned char zT_889;
    unsigned char zT_890;
    unsigned char zT_895;
    int zT_896;
    unsigned char zT_898;
    unsigned char zT_899;
    unsigned char zT_901;
    unsigned char zT_904;
    int zT_905;
    unsigned char zT_907;
    unsigned char zT_908;
    int zT_909;
    unsigned char zT_911;
    unsigned int zT_912;
    zT_338B7C76_TypeRegistry* zT_914;
    zT_CEC2984A_NameMangler* zT_915;
    unsigned int zT_916;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_918;
    unsigned int zT_920;
    unsigned int zT_922;
    unsigned char zT_924;
    unsigned char* zT_928;
    unsigned int zT_929;
    unsigned char zT_930;
    unsigned char zT_931;
    unsigned char zT_934;
    unsigned char zT_937;
    unsigned char zT_939;
    unsigned int zT_940;
    unsigned int zT_941;
    unsigned int zT_942;
    unsigned char zT_944;
    unsigned int zT_945;
    unsigned int zT_946;
    unsigned int zT_947;
    unsigned char zT_949;
    unsigned short zT_951;
    unsigned int zT_953;
    unsigned int zT_954;
    unsigned int zT_955;
    unsigned int zT_956;
    unsigned int zT_957;
    unsigned char zT_959;
    unsigned int zT_960;
    unsigned int zT_963;
    unsigned int zT_964;
    unsigned char zT_966;
    unsigned char zT_971;
    unsigned char zT_973;
    unsigned int zT_974;
    unsigned int zT_975;
    unsigned int zT_976;
    unsigned char zT_978;
    unsigned int* zT_980;
    unsigned int zT_981;
    zT_338B7C76_TypeRegistry* zT_983;
    zT_CEC2984A_NameMangler* zT_984;
    unsigned int zT_985;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_986;
    unsigned int zT_988;
    unsigned int zT_990;
    unsigned char zT_992;
    unsigned char* zT_996;
    unsigned int zT_997;
    unsigned char zT_998;
    unsigned char zT_999;
    unsigned char zT_1002;
    unsigned char zT_1005;
    unsigned char zT_1007;
    unsigned int zT_1008;
    unsigned int zT_1009;
    unsigned int zT_1010;
    unsigned char zT_1012;
    unsigned int zT_1013;
    unsigned int zT_1014;
    unsigned int zT_1015;
    unsigned char zT_1017;
    unsigned int zT_1018;
    unsigned int zT_1019;
    unsigned int zT_1020;
    unsigned char zT_1022;
    zT_D3EB6303_StringInterner* zT_1024;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1025;
    int zT_1029;
    unsigned char* zT_1030;
    unsigned int zT_1031;
    unsigned char zT_1032;
    unsigned char zT_1033;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1034;
    unsigned int zT_1035;
    zT_CEC2984A_NameMangler* zT_1037;
    unsigned int zT_1038;
    unsigned int zT_1043;
    zT_338B7C76_TypeRegistry* zT_1044;
    unsigned int zT_1045;
    unsigned int zT_1046;
    zT_D3EB6303_StringInterner* zT_1047;
    unsigned int zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1050;
    zT_33EF6BFB_TypeKind zT_1051;
    unsigned int zT_1054;
    zT_C41F1B06_Arr_unsigned_char_6 zT_1058;
    unsigned int zT_1060;
    unsigned char* zT_1062;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1063;
    unsigned int zT_1064;
    unsigned int zT_1066;
    unsigned int zT_1068;
    unsigned char zT_1070;
    unsigned char* zT_1073;
    unsigned int zT_1074;
    unsigned char zT_1075;
    unsigned char zT_1076;
    unsigned char zT_1078;
    unsigned int zT_1079;
    unsigned int zT_1080;
    unsigned int zT_1081;
    unsigned char zT_1083;
    unsigned int zT_1084;
    unsigned int zT_1085;
    unsigned int zT_1086;
    unsigned char zT_1088;
    unsigned int zT_1090;
    unsigned int zT_1091;
    unsigned char zT_1095;
    unsigned int zT_1097;
    unsigned int zT_1099;
    unsigned char zT_1101;
    unsigned int zT_1102;
    unsigned int zT_1103;
    unsigned char zT_1105;
    unsigned char zT_1106;
    unsigned char zT_1108;
    unsigned int zT_1110;
    unsigned char zT_1112;
    unsigned int zT_1115;
    unsigned int zT_1116;
    unsigned int zT_1117;
    unsigned char zT_1119;
    zT_CEC2984A_NameMangler* zT_1121;
    unsigned int zT_1122;
    zT_D3EB6303_StringInterner* zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    int zT_1130;
    unsigned char* zT_1131;
    unsigned int zT_1132;
    unsigned char zT_1133;
    unsigned char zT_1134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1135;
    unsigned int zT_1136;
    unsigned int zT_1139;
    zT_338B7C76_TypeRegistry* zT_1140;
    unsigned int zT_1141;
    unsigned int zT_1142;
    zT_D3EB6303_StringInterner* zT_1143;
    unsigned int zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1146;
    zT_CEC2984A_NameMangler* zT_1148;
    unsigned int zT_1149;
    unsigned short zT_1154;
    unsigned int zT_1156;
    zT_338B7C76_TypeRegistry* zT_1157;
    unsigned int zT_1158;
    unsigned int zT_1159;
    zT_D3EB6303_StringInterner* zT_1160;
    unsigned int zT_1161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1163;
    zT_CEC2984A_NameMangler* zT_1165;
    unsigned int zT_1166;
    unsigned short zT_1171;
    unsigned int zT_1173;
    zT_338B7C76_TypeRegistry* zT_1174;
    unsigned int zT_1175;
    unsigned int zT_1176;
    zT_D3EB6303_StringInterner* zT_1177;
    unsigned int zT_1178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1180;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_172, (unsigned int)sizeof zT_172);
    zig_poison_fill((void*)&zT_250, (unsigned int)sizeof zT_250);
    zig_poison_fill((void*)&zT_254, (unsigned int)sizeof zT_254);
    zig_poison_fill((void*)&zT_295, (unsigned int)sizeof zT_295);
    zig_poison_fill((void*)&zT_299, (unsigned int)sizeof zT_299);
    zig_poison_fill((void*)&zT_313, (unsigned int)sizeof zT_313);
    zig_poison_fill((void*)&zT_326, (unsigned int)sizeof zT_326);
    zig_poison_fill((void*)&zT_361, (unsigned int)sizeof zT_361);
    zig_poison_fill((void*)&zT_376, (unsigned int)sizeof zT_376);
    zig_poison_fill((void*)&zT_415, (unsigned int)sizeof zT_415);
    zig_poison_fill((void*)&zT_511, (unsigned int)sizeof zT_511);
    zig_poison_fill((void*)&zT_653, (unsigned int)sizeof zT_653);
    zig_poison_fill((void*)&zT_657, (unsigned int)sizeof zT_657);
    zig_poison_fill((void*)&zT_697, (unsigned int)sizeof zT_697);
    zig_poison_fill((void*)&zT_712, (unsigned int)sizeof zT_712);
    zig_poison_fill((void*)&zT_733, (unsigned int)sizeof zT_733);
    zig_poison_fill((void*)&zT_762, (unsigned int)sizeof zT_762);
    zig_poison_fill((void*)&zT_766, (unsigned int)sizeof zT_766);
    zig_poison_fill((void*)&zT_772, (unsigned int)sizeof zT_772);
    zig_poison_fill((void*)&zT_859, (unsigned int)sizeof zT_859);
    zig_poison_fill((void*)&zT_862, (unsigned int)sizeof zT_862);
    zig_poison_fill((void*)&zT_869, (unsigned int)sizeof zT_869);
    zig_poison_fill((void*)&zT_918, (unsigned int)sizeof zT_918);
    zig_poison_fill((void*)&zT_986, (unsigned int)sizeof zT_986);
    zig_poison_fill((void*)&zT_1035, (unsigned int)sizeof zT_1035);
    zig_poison_fill((void*)&zT_1043, (unsigned int)sizeof zT_1043);
    zig_poison_fill((void*)&zT_1050, (unsigned int)sizeof zT_1050);
    zig_poison_fill((void*)&zT_1136, (unsigned int)sizeof zT_1136);
    zig_poison_fill((void*)&zT_1139, (unsigned int)sizeof zT_1139);
    zig_poison_fill((void*)&zT_1146, (unsigned int)sizeof zT_1146);
    zig_poison_fill((void*)&zT_1156, (unsigned int)sizeof zT_1156);
    zig_poison_fill((void*)&zT_1163, (unsigned int)sizeof zT_1163);
    zig_poison_fill((void*)&zT_1173, (unsigned int)sizeof zT_1173);
    zig_poison_fill((void*)&zT_1180, (unsigned int)sizeof zT_1180);
    zT_338B7C76_TypeRegistry* reg;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6m;
    zT_4028D896_Arr_unsigned_char_2 d6tb;
    unsigned int d6tl;
    unsigned int d6ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6kn;
    zT_4028D896_Arr_unsigned_char_2 d6kb;
    unsigned int d6kl;
    unsigned int d6ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u d6nn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int mid;
    zT_E834303C_ArrayPayload ap;
    zT_8F083A69_Slice_zT_0B42B2F8_u e_cname;
    zT_5426B97B_Arr_unsigned_char_1 a_dig;
    unsigned int a_dl;
    unsigned int a_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u a_pref;
    zT_5426B97B_Arr_unsigned_char_1 t_dig;
    unsigned int t_dl;
    unsigned int t_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u t_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u t_pref;
    zT_112BF819_PtrPayload pp;
    zT_D155D06D_Type et;
    unsigned char is_vol;
    zT_E834303C_ArrayPayload sc_ap;
    zT_8F083A69_Slice_zT_0B42B2F8_u base_cname;
    zT_C4003E6D_Arr_unsigned_char_1 pbuf;
    unsigned int bi;
    unsigned char et_is_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u vpx;
    unsigned int vpi;
    unsigned int bcj;
    zT_8F083A69_Slice_zT_0B42B2F8_u vpx2;
    unsigned int vpi2;
    unsigned int ptr_mid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nul_m;
    zT_0BB2A741_SlicePayload sp;
    zT_8F083A69_Slice_zT_0B42B2F8_u elem_mangled2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_pref;
    zT_0B10E8E9_OptionalPayload op;
    zT_5A26C2ED_Arr_unsigned_char_1 o_dig;
    unsigned int o_dl;
    unsigned int o_ds;
    zT_8F083A69_Slice_zT_0B42B2F8_u o_empty;
    zT_8F083A69_Slice_zT_0B42B2F8_u o_pref;
    unsigned int c_nid;
    zT_42C2D6BF_EUPayload ep;
    zT_C41F1B06_Arr_unsigned_char_6 buf;
    unsigned int p;
    zT_8F083A69_Slice_zT_0B42B2F8_u pref;
    unsigned int pi;
    unsigned int pl;
    unsigned int di;
    unsigned int eu_nid;
    zT_0317B1D5_FnPayload fpp;
    zT_443A2803_Arr_unsigned_char_9 fbuf;
    unsigned int fpos;
    zT_8F083A69_Slice_zT_0B42B2F8_u fret_c;
    unsigned int fri;
    unsigned char fc;
    unsigned short fpcnt;
    unsigned int fpend;
    unsigned int fpcur;
    unsigned int fp_nid;
    unsigned int fp_mid;
    unsigned int fptid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fp_c;
    unsigned int fpj;
    unsigned char fc2;
    unsigned int es_nid;
    z_bb_0:
    reg = self;
    zT_5 = reg->types_items;
    zT_6 = (unsigned int)tid;
    zT_7 = zT_5[zT_6];
    ty = zT_7;
    if ((unsigned char)(tid >= (unsigned int)(20))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = "D6:";
    zT_13 = 3;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    d6m = zT_12;
    zT_14 = d6m;
    zF_48AC7B3A_markerWrite(zT_14);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d6tb[_i] = zT_16[_i];
        _i++;
    }
}
    zT_18 = tid;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)d6tb) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = (unsigned char*)zT_23;
    zT_25.len = zT_24;
    zT_19 = zT_25;
    zT_26 = zF_A7504564_itoa(zT_18, zT_19);
    d6tl = zT_26;
    zT_28 = 19;
    zT_29 = (unsigned int)d6tl;
    zT_30 = zig_wrap_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_sub_u(((zu64)(zT_28)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    d6ts = zT_30;
    zT_37 = 19;
    zT_38 = (unsigned char*)((unsigned char*)d6tb) + d6ts;
    zT_39 = zT_37 - d6ts;
    zT_40 = d6ts <= zT_37;
    if (!(zT_40)) { pal_trap(); }
    zT_41.ptr = (unsigned char*)zT_38;
    zT_41.len = zT_39;
    zT_34 = zT_41;
    zF_48AC7B3A_markerWrite(zT_34);
    zT_43 = "k";
    zT_45 = 1;
    zT_44.ptr = (unsigned char*)zT_43;
    zT_44.len = zT_45;
    d6kn = zT_44;
    zT_46 = d6kn;
    zF_48AC7B3A_markerWrite(zT_46);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        d6kb[_i] = zT_48[_i];
        _i++;
    }
}
    zT_52 = ty.kind;
    zT_56 = 0;
    zT_57 = (unsigned char*)((unsigned char*)d6kb) + zT_56;
    zT_58 = (unsigned int)(20) - zT_56;
    zT_59.ptr = (unsigned char*)zT_57;
    zT_59.len = zT_58;
    zT_51 = zT_59;
    zT_60 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_52), zT_51);
    d6kl = zT_60;
    zT_62 = 19;
    zT_63 = (unsigned int)d6kl;
    zT_64 = zig_wrap_sub_u(((zu64)(zT_62)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_sub_u(((zu64)(zT_62)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    d6ks = zT_64;
    zT_71 = 19;
    zT_72 = (unsigned char*)((unsigned char*)d6kb) + d6ks;
    zT_73 = zT_71 - d6ks;
    zT_74 = d6ks <= zT_71;
    if (!(zT_74)) { pal_trap(); }
    zT_75.ptr = (unsigned char*)zT_72;
    zT_75.len = zT_73;
    zT_68 = zT_75;
    zF_48AC7B3A_markerWrite(zT_68);
    zT_77 = "n";
    zT_79 = 1;
    zT_78.ptr = (unsigned char*)zT_77;
    zT_78.len = zT_79;
    d6nn = zT_78;
    zT_80 = d6nn;
    zT_81 = ty.name_id;
    zF_C914CB83_markerWriteInt(zT_80, zT_81);
    goto z_bb_2;
    z_bb_2:
    zT_83 = ty.kind;
    if ((unsigned char)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_87 = "void";
    zT_89 = 4;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    s = zT_88;
    return s;
    z_bb_4:
    zT_90 = ty.kind;
    if ((unsigned char)(zT_90 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_94 = "unsigned char";
    zT_96 = 13;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    s = zT_95;
    return s;
    z_bb_6:
    zT_97 = ty.kind;
    if ((unsigned char)(zT_97 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_101 = "signed char";
    zT_103 = 11;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    s = zT_102;
    return s;
    z_bb_8:
    zT_104 = ty.kind;
    if ((unsigned char)(zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_108 = "short";
    zT_110 = 5;
    zT_109.ptr = (unsigned char*)zT_108;
    zT_109.len = zT_110;
    s = zT_109;
    return s;
    z_bb_10:
    zT_111 = ty.kind;
    if ((unsigned char)(zT_111 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_115 = "int";
    zT_117 = 3;
    zT_116.ptr = (unsigned char*)zT_115;
    zT_116.len = zT_117;
    s = zT_116;
    return s;
    z_bb_12:
    zT_118 = ty.kind;
    if ((unsigned char)(zT_118 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_122 = mangler;
    zT_123 = ty.name_id;
    zT_128 = ty.module_id;
    zT_130 = zF_713D1938_nameManglerMangle(zT_122, zT_123, (unsigned char)(2), (unsigned int)((unsigned int)zT_128));
    mid = zT_130;
    zT_131 = mangler->interner;
    zT_132 = mid;
    zT_134 = zF_9134020D_stringInternerGet(zT_131, zT_132);
    return zT_134;
    z_bb_14:
    zT_135 = ty.kind;
    if ((unsigned char)(zT_135 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_139 = "unsigned char";
    zT_141 = 13;
    zT_140.ptr = (unsigned char*)zT_139;
    zT_140.len = zT_141;
    s = zT_140;
    return s;
    z_bb_16:
    zT_142 = ty.kind;
    if ((unsigned char)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_146 = "unsigned short";
    zT_148 = 14;
    zT_147.ptr = (unsigned char*)zT_146;
    zT_147.len = zT_148;
    s = zT_147;
    return s;
    z_bb_18:
    zT_149 = ty.kind;
    if ((unsigned char)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_153 = "unsigned int";
    zT_155 = 12;
    zT_154.ptr = (unsigned char*)zT_153;
    zT_154.len = zT_155;
    s = zT_154;
    return s;
    z_bb_20:
    zT_156 = ty.kind;
    if ((unsigned char)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_160 = mangler;
    zT_161 = ty.name_id;
    zT_166 = ty.module_id;
    zT_168 = zF_713D1938_nameManglerMangle(zT_160, zT_161, (unsigned char)(2), (unsigned int)((unsigned int)zT_166));
    mid = zT_168;
    zT_169 = mangler->interner;
    zT_170 = mid;
    zT_172 = zF_9134020D_stringInternerGet(zT_169, zT_170);
    return zT_172;
    z_bb_22:
    zT_173 = ty.kind;
    if ((unsigned char)(zT_173 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_176 = ty.size;
    if ((unsigned char)(zT_176 == (unsigned int)(2))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_202 = ty.kind;
    if ((unsigned char)(zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_25:
    zT_180 = "unsigned short";
    zT_182 = 14;
    zT_181.ptr = (unsigned char*)zT_180;
    zT_181.len = zT_182;
    s = zT_181;
    return s;
    z_bb_26:
    zT_183 = ty.size;
    if ((unsigned char)(zT_183 == (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_187 = "unsigned int";
    zT_189 = 12;
    zT_188.ptr = (unsigned char*)zT_187;
    zT_188.len = zT_189;
    s = zT_188;
    return s;
    z_bb_28:
    zT_190 = ty.size;
    if ((unsigned char)(zT_190 == (unsigned int)(8))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_193 = reg;
    zT_194 = mangler;
    zT_196 = 11;
    self = zT_193;
    mangler = zT_194;
    tid = zT_196;
    goto z_bb_0;
    z_bb_30:
    zT_199 = "unsigned char";
    zT_201 = 13;
    zT_200.ptr = (unsigned char*)zT_199;
    zT_200.len = zT_201;
    s = zT_200;
    return s;
    z_bb_31:
    zT_205 = ty.size;
    if ((unsigned char)(zT_205 == (unsigned int)(2))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_231 = ty.kind;
    if ((unsigned char)(zT_231 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_33:
    zT_209 = "short";
    zT_211 = 5;
    zT_210.ptr = (unsigned char*)zT_209;
    zT_210.len = zT_211;
    s = zT_210;
    return s;
    z_bb_34:
    zT_212 = ty.size;
    if ((unsigned char)(zT_212 == (unsigned int)(4))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_216 = "int";
    zT_218 = 3;
    zT_217.ptr = (unsigned char*)zT_216;
    zT_217.len = zT_218;
    s = zT_217;
    return s;
    z_bb_36:
    zT_219 = ty.size;
    if ((unsigned char)(zT_219 == (unsigned int)(8))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_222 = reg;
    zT_223 = mangler;
    zT_225 = 7;
    self = zT_222;
    mangler = zT_223;
    tid = zT_225;
    goto z_bb_0;
    z_bb_38:
    zT_228 = "signed char";
    zT_230 = 11;
    zT_229.ptr = (unsigned char*)zT_228;
    zT_229.len = zT_230;
    s = zT_229;
    return s;
    z_bb_39:
    zT_235 = "float";
    zT_237 = 5;
    zT_236.ptr = (unsigned char*)zT_235;
    zT_236.len = zT_237;
    s = zT_236;
    return s;
    z_bb_40:
    zT_238 = ty.kind;
    if ((unsigned char)(zT_238 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_242 = mangler;
    zT_243 = ty.name_id;
    zT_248 = ty.module_id;
    zT_250 = zF_713D1938_nameManglerMangle(zT_242, zT_243, (unsigned char)(2), (unsigned int)((unsigned int)zT_248));
    mid = zT_250;
    zT_251 = mangler->interner;
    zT_252 = mid;
    zT_254 = zF_9134020D_stringInternerGet(zT_251, zT_252);
    return zT_254;
    z_bb_42:
    zT_255 = ty.kind;
    if ((unsigned char)(zT_255 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_259 = "unsigned int";
    zT_261 = 12;
    zT_260.ptr = (unsigned char*)zT_259;
    zT_260.len = zT_261;
    s = zT_260;
    return s;
    z_bb_44:
    zT_262 = ty.kind;
    if ((unsigned char)(zT_262 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_266 = "int";
    zT_268 = 3;
    zT_267.ptr = (unsigned char*)zT_266;
    zT_267.len = zT_268;
    s = zT_267;
    return s;
    z_bb_46:
    zT_269 = ty.kind;
    if ((unsigned char)(zT_269 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_273 = "char";
    zT_275 = 4;
    zT_274.ptr = (unsigned char*)zT_273;
    zT_274.len = zT_275;
    s = zT_274;
    return s;
    z_bb_48:
    zT_276 = ty.kind;
    if ((unsigned char)(zT_276 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_280 = "va_list";
    zT_282 = 7;
    zT_281.ptr = (unsigned char*)zT_280;
    zT_281.len = zT_282;
    s = zT_281;
    return s;
    z_bb_50:
    zT_283 = ty.kind;
    if ((unsigned char)(zT_283 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_287 = mangler;
    zT_288 = ty.name_id;
    zT_293 = ty.module_id;
    zT_295 = zF_713D1938_nameManglerMangle(zT_287, zT_288, (unsigned char)(2), (unsigned int)((unsigned int)zT_293));
    mid = zT_295;
    zT_296 = mangler->interner;
    zT_297 = mid;
    zT_299 = zF_9134020D_stringInternerGet(zT_296, zT_297);
    return zT_299;
    z_bb_52:
    zT_300 = ty.kind;
    if ((unsigned char)(zT_300 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_304 = reg->array_items;
    zT_305 = ty.payload_idx;
    zT_306 = (unsigned int)zT_305;
    zT_307 = zT_304[zT_306];
    ap = zT_307;
    zT_309 = reg;
    zT_310 = mangler;
    zT_311 = ap.elem;
    zT_313 = zF_08CFA1F1_typeCName(zT_309, zT_310, zT_311);
    e_cname = zT_313;
    zig_poison_fill((void*)&zT_315, (unsigned int)sizeof zT_315);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        a_dig[_i] = zT_315[_i];
        _i++;
    }
}
    zT_317 = ap.length;
    zT_322 = 0;
    zT_323 = (unsigned char*)((unsigned char*)a_dig) + zT_322;
    zT_324 = (unsigned int)(16) - zT_322;
    zT_325.ptr = (unsigned char*)zT_323;
    zT_325.len = zT_324;
    zT_318 = zT_325;
    zT_326 = zF_A7504564_itoa(zT_317, zT_318);
    a_dl = zT_326;
    zT_328 = 16;
    zT_329 = 1;
    zT_330 = zig_wrap_sub_u(((zu64)(zT_328)), ((zu64)(zT_329)), 32u);
    zT_331 = zig_overflow_flag_sub_u(((zu64)(zT_328)), ((zu64)(zT_329)), 32u);
    zT_333 = zT_331 == (unsigned int)(0);
    if (!(zT_333)) { pal_trap(); }
    zT_334 = (unsigned int)a_dl;
    zT_335 = zig_wrap_sub_u(((zu64)(zT_330)), ((zu64)(zT_334)), 32u);
    zT_336 = zig_overflow_flag_sub_u(((zu64)(zT_330)), ((zu64)(zT_334)), 32u);
    zT_338 = zT_336 == (unsigned int)(0);
    if (!(zT_338)) { pal_trap(); }
    a_ds = zT_335;
    zT_340 = "Arr_";
    zT_342 = 4;
    zT_341.ptr = (unsigned char*)zT_340;
    zT_341.len = zT_342;
    a_pref = zT_341;
    zT_343 = mangler;
    zT_344 = a_pref;
    zT_345 = e_cname;
    zT_350 = 16;
    zT_351 = 1;
    zT_352 = zig_wrap_sub_u(((zu64)(zT_350)), ((zu64)(zT_351)), 32u);
    zT_353 = zig_overflow_flag_sub_u(((zu64)(zT_350)), ((zu64)(zT_351)), 32u);
    zT_355 = zT_353 == (unsigned int)(0);
    if (!(zT_355)) { pal_trap(); }
    zT_356 = (unsigned char*)((unsigned char*)a_dig) + a_ds;
    zT_357 = zT_352 - a_ds;
    zT_358 = a_ds <= zT_352;
    if (!(zT_358)) { pal_trap(); }
    zT_359.ptr = (unsigned char*)zT_356;
    zT_359.len = zT_357;
    zT_346 = zT_359;
    zT_361 = zF_9DABAED9_nameManglerMintSynt(zT_343, zT_344, zT_345, zT_346, (unsigned int)(127));
    return zT_361;
    z_bb_54:
    zT_362 = ty.kind;
    if ((unsigned char)(zT_362 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zig_poison_fill((void*)&zT_366, (unsigned int)sizeof zT_366);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        t_dig[_i] = zT_366[_i];
        _i++;
    }
}
    zT_368 = tid;
    zT_372 = 0;
    zT_373 = (unsigned char*)((unsigned char*)t_dig) + zT_372;
    zT_374 = (unsigned int)(16) - zT_372;
    zT_375.ptr = (unsigned char*)zT_373;
    zT_375.len = zT_374;
    zT_369 = zT_375;
    zT_376 = zF_A7504564_itoa(zT_368, zT_369);
    t_dl = zT_376;
    zT_378 = 16;
    zT_379 = 1;
    zT_380 = zig_wrap_sub_u(((zu64)(zT_378)), ((zu64)(zT_379)), 32u);
    zT_381 = zig_overflow_flag_sub_u(((zu64)(zT_378)), ((zu64)(zT_379)), 32u);
    zT_383 = zT_381 == (unsigned int)(0);
    if (!(zT_383)) { pal_trap(); }
    zT_384 = (unsigned int)t_dl;
    zT_385 = zig_wrap_sub_u(((zu64)(zT_380)), ((zu64)(zT_384)), 32u);
    zT_386 = zig_overflow_flag_sub_u(((zu64)(zT_380)), ((zu64)(zT_384)), 32u);
    zT_388 = zT_386 == (unsigned int)(0);
    if (!(zT_388)) { pal_trap(); }
    t_ds = zT_385;
    zT_390 = "";
    zT_392 = 0;
    zT_391.ptr = (unsigned char*)zT_390;
    zT_391.len = zT_392;
    t_empty = zT_391;
    zT_394 = "Tup_";
    zT_396 = 4;
    zT_395.ptr = (unsigned char*)zT_394;
    zT_395.len = zT_396;
    t_pref = zT_395;
    zT_397 = mangler;
    zT_398 = t_pref;
    zT_399 = t_empty;
    zT_404 = 16;
    zT_405 = 1;
    zT_406 = zig_wrap_sub_u(((zu64)(zT_404)), ((zu64)(zT_405)), 32u);
    zT_407 = zig_overflow_flag_sub_u(((zu64)(zT_404)), ((zu64)(zT_405)), 32u);
    zT_409 = zT_407 == (unsigned int)(0);
    if (!(zT_409)) { pal_trap(); }
    zT_410 = (unsigned char*)((unsigned char*)t_dig) + t_ds;
    zT_411 = zT_406 - t_ds;
    zT_412 = t_ds <= zT_406;
    if (!(zT_412)) { pal_trap(); }
    zT_413.ptr = (unsigned char*)zT_410;
    zT_413.len = zT_411;
    zT_400 = zT_413;
    zT_415 = zF_9DABAED9_nameManglerMintSynt(zT_397, zT_398, zT_399, zT_400, (unsigned int)(31));
    return zT_415;
    z_bb_56:
    zT_416 = ty.kind;
    if ((unsigned char)(zT_416 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_420 = ty.kind;
    zT_419 = zT_420 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_59;
    z_bb_58:
    zT_419 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_419) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_424 = reg->ptr_items;
    zT_425 = ty.payload_idx;
    zT_426 = (unsigned int)zT_425;
    zT_427 = zT_424[zT_426];
    pp = zT_427;
    zT_429 = reg->types_items;
    zT_430 = pp.base;
    zT_431 = (unsigned int)zT_430;
    zT_432 = zT_429[zT_431];
    et = zT_432;
    zT_434 = ty.flags;
    zT_438 = (unsigned char)(zT_434 & (unsigned char)(2)) != (unsigned char)(0);
    is_vol = zT_438;
    zT_439 = et.kind;
    if ((unsigned char)(zT_439 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_658 = ty.kind;
    if ((unsigned char)(zT_658 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_120; else goto z_bb_121;
    z_bb_62:
    zT_442 = reg;
    zT_443 = mangler;
    zT_445 = pp.base;
    self = zT_442;
    mangler = zT_443;
    tid = zT_445;
    goto z_bb_0;
    z_bb_63:
    if ((unsigned char)(!is_vol)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_449 = ty.flags;
    zT_448 = (unsigned char)(zT_449 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_66;
    z_bb_65:
    zT_448 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_448) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_455 = et.kind;
    zT_454 = zT_455 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_69;
    z_bb_68:
    zT_454 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_454) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_459 = reg->array_items;
    zT_460 = et.payload_idx;
    zT_461 = (unsigned int)zT_460;
    zT_462 = zT_459[zT_461];
    sc_ap = zT_462;
    zT_463 = sc_ap.elem;
    if ((unsigned char)(zT_463 == (unsigned int)(8))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    if ((unsigned char)(!is_vol)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_467 = "unsigned char*";
    zT_469 = 14;
    zT_468.ptr = (unsigned char*)zT_467;
    zT_468.len = zT_469;
    s = zT_468;
    return s;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_471 = et.kind;
    if ((unsigned char)(zT_471 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_507 = reg;
    zT_508 = mangler;
    zT_509 = pp.base;
    zT_511 = zF_08CFA1F1_typeCName(zT_507, zT_508, zT_509);
    base_cname = zT_511;
    zig_poison_fill((void*)&zT_513, (unsigned int)sizeof zT_513);
    {
    unsigned int _i = 0;
    while (_i < 128) {
        pbuf[_i] = zT_513[_i];
        _i++;
    }
}
    zT_515 = 0;
    zT_516 = (unsigned int)zT_515;
    bi = zT_516;
    zT_518 = et.kind;
    if ((unsigned char)(zT_518 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_87; else goto z_bb_86;
    z_bb_76:
    zT_475 = "unsigned char*";
    zT_477 = 14;
    zT_476.ptr = (unsigned char*)zT_475;
    zT_476.len = zT_477;
    s = zT_476;
    return s;
    z_bb_77:
    zT_478 = et.kind;
    if ((unsigned char)(zT_478 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_482 = "unsigned int*";
    zT_484 = 13;
    zT_483.ptr = (unsigned char*)zT_482;
    zT_483.len = zT_484;
    s = zT_483;
    return s;
    z_bb_79:
    zT_485 = et.kind;
    if ((unsigned char)(zT_485 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_489 = "int*";
    zT_491 = 4;
    zT_490.ptr = (unsigned char*)zT_489;
    zT_490.len = zT_491;
    s = zT_490;
    return s;
    z_bb_81:
    zT_492 = et.kind;
    if ((unsigned char)(zT_492 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_496 = "char*";
    zT_498 = 5;
    zT_497.ptr = (unsigned char*)zT_496;
    zT_497.len = zT_498;
    s = zT_497;
    return s;
    z_bb_83:
    zT_499 = et.kind;
    if ((unsigned char)(zT_499 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_503 = "unsigned int*";
    zT_505 = 13;
    zT_504.ptr = (unsigned char*)zT_503;
    zT_504.len = zT_505;
    s = zT_504;
    return s;
    z_bb_85:
    goto z_bb_75;
    z_bb_86:
    zT_522 = et.kind;
    zT_521 = zT_522 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_88;
    z_bb_87:
    zT_521 = 1;
    goto z_bb_88;
    z_bb_88:
    et_is_ptr = zT_521;
    if (is_vol) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_525 = !et_is_ptr;
    goto z_bb_91;
    z_bb_90:
    zT_525 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_525) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_528 = "volatile ";
    zT_530 = 9;
    zT_529.ptr = (unsigned char*)zT_528;
    zT_529.len = zT_530;
    vpx = zT_529;
    zT_532 = 0;
    zT_533 = (unsigned int)zT_532;
    vpi = zT_533;
    goto z_bb_94;
    z_bb_93:
    zT_559 = 0;
    zT_560 = (unsigned int)zT_559;
    bcj = zT_560;
    goto z_bb_101;
    z_bb_94:
    zT_535 = vpx.len;
    if ((unsigned char)(vpi < zT_535)) goto z_bb_98; else goto z_bb_99;
    z_bb_95:
    zT_540 = vpx.ptr;
    zT_541 = vpx.len;
    zT_542 = vpi < zT_541;
    if (!(zT_542)) { pal_trap(); }
    zT_543 = zT_540[vpi];
    zT_545 = bi < (unsigned int)(128);
    if (!(zT_545)) { pal_trap(); }
    pbuf[bi] = zT_543;
    zT_546 = 1;
    zT_547 = (unsigned int)zT_546;
    zT_548 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_547)), 32u);
    zT_549 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_547)), 32u);
    zT_551 = zT_549 == (unsigned int)(0);
    if (!(zT_551)) { pal_trap(); }
    bi = zT_548;
    goto z_bb_97;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_552 = 1;
    zT_553 = (unsigned int)zT_552;
    zT_554 = zig_wrap_add_u(((zu64)(vpi)), ((zu64)(zT_553)), 32u);
    zT_555 = zig_overflow_flag_add_u(((zu64)(vpi)), ((zu64)(zT_553)), 32u);
    zT_557 = zT_555 == (unsigned int)(0);
    if (!(zT_557)) { pal_trap(); }
    vpi = zT_554;
    goto z_bb_94;
    z_bb_98:
    zT_538 = 126;
    zT_537 = bi < (unsigned int)zT_538;
    goto z_bb_100;
    z_bb_99:
    zT_537 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_537) goto z_bb_95; else goto z_bb_96;
    z_bb_101:
    zT_562 = base_cname.len;
    if ((unsigned char)(bcj < zT_562)) goto z_bb_105; else goto z_bb_106;
    z_bb_102:
    zT_567 = base_cname.ptr;
    zT_568 = base_cname.len;
    zT_569 = bcj < zT_568;
    if (!(zT_569)) { pal_trap(); }
    zT_570 = zT_567[bcj];
    zT_572 = bi < (unsigned int)(128);
    if (!(zT_572)) { pal_trap(); }
    pbuf[bi] = zT_570;
    zT_573 = 1;
    zT_574 = (unsigned int)zT_573;
    zT_575 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_574)), 32u);
    zT_576 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_574)), 32u);
    zT_578 = zT_576 == (unsigned int)(0);
    if (!(zT_578)) { pal_trap(); }
    bi = zT_575;
    goto z_bb_104;
    z_bb_103:
    if (is_vol) goto z_bb_108; else goto z_bb_109;
    z_bb_104:
    zT_579 = 1;
    zT_580 = (unsigned int)zT_579;
    zT_581 = zig_wrap_add_u(((zu64)(bcj)), ((zu64)(zT_580)), 32u);
    zT_582 = zig_overflow_flag_add_u(((zu64)(bcj)), ((zu64)(zT_580)), 32u);
    zT_584 = zT_582 == (unsigned int)(0);
    if (!(zT_584)) { pal_trap(); }
    bcj = zT_581;
    goto z_bb_101;
    z_bb_105:
    zT_565 = 126;
    zT_564 = bi < (unsigned int)zT_565;
    goto z_bb_107;
    z_bb_106:
    zT_564 = 0;
    goto z_bb_107;
    z_bb_107:
    if (zT_564) goto z_bb_102; else goto z_bb_103;
    z_bb_108:
    zT_585 = et_is_ptr;
    goto z_bb_110;
    z_bb_109:
    zT_585 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_585) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_587 = " volatile";
    zT_589 = 9;
    zT_588.ptr = (unsigned char*)zT_587;
    zT_588.len = zT_589;
    vpx2 = zT_588;
    zT_591 = 0;
    zT_592 = (unsigned int)zT_591;
    vpi2 = zT_592;
    goto z_bb_113;
    z_bb_112:
    zT_617 = 42;
    zT_619 = bi < (unsigned int)(128);
    if (!(zT_619)) { pal_trap(); }
    pbuf[bi] = zT_617;
    zT_620 = 1;
    zT_621 = (unsigned int)zT_620;
    zT_622 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_621)), 32u);
    zT_623 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_621)), 32u);
    zT_625 = zT_623 == (unsigned int)(0);
    if (!(zT_625)) { pal_trap(); }
    bi = zT_622;
    zT_626 = 0;
    zT_627 = (unsigned char)zT_626;
    zT_629 = bi < (unsigned int)(128);
    if (!(zT_629)) { pal_trap(); }
    pbuf[bi] = zT_627;
    zT_630 = 1;
    zT_631 = (unsigned int)zT_630;
    zT_632 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_631)), 32u);
    zT_633 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_631)), 32u);
    zT_635 = zT_633 == (unsigned int)(0);
    if (!(zT_635)) { pal_trap(); }
    bi = zT_632;
    zT_637 = mangler->interner;
    zT_642 = 1;
    zT_643 = zig_wrap_sub_u(((zu64)(bi)), ((zu64)(zT_642)), 32u);
    zT_644 = zig_overflow_flag_sub_u(((zu64)(bi)), ((zu64)(zT_642)), 32u);
    zT_646 = zT_644 == (unsigned int)(0);
    if (!(zT_646)) { pal_trap(); }
    zT_647 = 0;
    zT_648 = (unsigned char*)((unsigned char*)pbuf) + zT_647;
    zT_649 = zT_643 - zT_647;
    zT_650 = (unsigned int)zT_647 <= zT_643;
    if (!(zT_650)) { pal_trap(); }
    zT_651 = zT_643 <= (unsigned int)(128);
    if (!(zT_651)) { pal_trap(); }
    zT_652.ptr = (unsigned char*)zT_648;
    zT_652.len = zT_649;
    zT_638 = zT_652;
    zT_653 = zF_50C274AF_stringInternerInter(zT_637, zT_638);
    ptr_mid = zT_653;
    zT_654 = mangler->interner;
    zT_655 = ptr_mid;
    zT_657 = zF_9134020D_stringInternerGet(zT_654, zT_655);
    return zT_657;
    z_bb_113:
    zT_594 = vpx2.len;
    if ((unsigned char)(vpi2 < zT_594)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_599 = vpx2.ptr;
    zT_600 = vpx2.len;
    zT_601 = vpi2 < zT_600;
    if (!(zT_601)) { pal_trap(); }
    zT_602 = zT_599[vpi2];
    zT_604 = bi < (unsigned int)(128);
    if (!(zT_604)) { pal_trap(); }
    pbuf[bi] = zT_602;
    zT_605 = 1;
    zT_606 = (unsigned int)zT_605;
    zT_607 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_606)), 32u);
    zT_608 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_606)), 32u);
    zT_610 = zT_608 == (unsigned int)(0);
    if (!(zT_610)) { pal_trap(); }
    bi = zT_607;
    goto z_bb_116;
    z_bb_115:
    goto z_bb_112;
    z_bb_116:
    zT_611 = 1;
    zT_612 = (unsigned int)zT_611;
    zT_613 = zig_wrap_add_u(((zu64)(vpi2)), ((zu64)(zT_612)), 32u);
    zT_614 = zig_overflow_flag_add_u(((zu64)(vpi2)), ((zu64)(zT_612)), 32u);
    zT_616 = zT_614 == (unsigned int)(0);
    if (!(zT_616)) { pal_trap(); }
    vpi2 = zT_613;
    goto z_bb_113;
    z_bb_117:
    zT_597 = 126;
    zT_596 = bi < (unsigned int)zT_597;
    goto z_bb_119;
    z_bb_118:
    zT_596 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_596) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    zT_662 = "int";
    zT_664 = 3;
    zT_663.ptr = (unsigned char*)zT_662;
    zT_663.len = zT_664;
    s = zT_663;
    return s;
    z_bb_121:
    zT_665 = ty.kind;
    if ((unsigned char)(zT_665 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_669 = "int";
    zT_671 = 3;
    zT_670.ptr = (unsigned char*)zT_669;
    zT_670.len = zT_671;
    s = zT_670;
    return s;
    z_bb_123:
    zT_672 = ty.kind;
    if ((unsigned char)(zT_672 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_676 = "NUL:TYnul ";
    zT_678 = 10;
    zT_677.ptr = (unsigned char*)zT_676;
    zT_677.len = zT_678;
    nul_m = zT_677;
    zT_679 = nul_m;
    zF_48AC7B3A_markerWrite(zT_679);
    zT_681 = "int";
    zT_683 = 3;
    zT_682.ptr = (unsigned char*)zT_681;
    zT_682.len = zT_683;
    s = zT_682;
    return s;
    z_bb_125:
    zT_684 = ty.kind;
    if ((unsigned char)(zT_684 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_688 = reg->slice_items;
    zT_689 = ty.payload_idx;
    zT_690 = (unsigned int)zT_689;
    zT_691 = zT_688[zT_690];
    sp = zT_691;
    zT_693 = reg;
    zT_694 = mangler;
    zT_695 = sp.elem;
    zT_697 = zF_28D4FDB0_typeSliceElementNam(zT_693, zT_694, zT_695);
    elem_mangled2 = zT_697;
    zT_699 = "";
    zT_701 = 0;
    zT_700.ptr = (unsigned char*)zT_699;
    zT_700.len = zT_701;
    s_empty = zT_700;
    zT_703 = "Slice_";
    zT_705 = 6;
    zT_704.ptr = (unsigned char*)zT_703;
    zT_704.len = zT_705;
    s_pref = zT_704;
    zT_706 = mangler;
    zT_707 = s_pref;
    zT_708 = elem_mangled2;
    zT_709 = s_empty;
    zT_712 = zF_9DABAED9_nameManglerMintSynt(zT_706, zT_707, zT_708, zT_709, (unsigned int)(63));
    return zT_712;
    z_bb_127:
    zT_713 = ty.kind;
    if ((unsigned char)(zT_713 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_717 = reg->opt_items;
    zT_718 = ty.payload_idx;
    zT_719 = (unsigned int)zT_718;
    zT_720 = zT_717[zT_719];
    op = zT_720;
    zig_poison_fill((void*)&zT_722, (unsigned int)sizeof zT_722);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        o_dig[_i] = zT_722[_i];
        _i++;
    }
}
    zT_724 = op.payload;
    zT_729 = 0;
    zT_730 = (unsigned char*)((unsigned char*)o_dig) + zT_729;
    zT_731 = (unsigned int)(10) - zT_729;
    zT_732.ptr = (unsigned char*)zT_730;
    zT_732.len = zT_731;
    zT_725 = zT_732;
    zT_733 = zF_A7504564_itoa(zT_724, zT_725);
    o_dl = zT_733;
    zT_735 = 9;
    zT_736 = (unsigned int)o_dl;
    zT_737 = zig_wrap_sub_u(((zu64)(zT_735)), ((zu64)(zT_736)), 32u);
    zT_738 = zig_overflow_flag_sub_u(((zu64)(zT_735)), ((zu64)(zT_736)), 32u);
    zT_740 = zT_738 == (unsigned int)(0);
    if (!(zT_740)) { pal_trap(); }
    o_ds = zT_737;
    zT_742 = "";
    zT_744 = 0;
    zT_743.ptr = (unsigned char*)zT_742;
    zT_743.len = zT_744;
    o_empty = zT_743;
    zT_746 = "Opt_";
    zT_748 = 4;
    zT_747.ptr = (unsigned char*)zT_746;
    zT_747.len = zT_748;
    o_pref = zT_747;
    zT_749 = mangler;
    zT_750 = o_pref;
    zT_751 = o_empty;
    zT_756 = 9;
    zT_757 = (unsigned char*)((unsigned char*)o_dig) + o_ds;
    zT_758 = zT_756 - o_ds;
    zT_759 = o_ds <= zT_756;
    if (!(zT_759)) { pal_trap(); }
    zT_760.ptr = (unsigned char*)zT_757;
    zT_760.len = zT_758;
    zT_752 = zT_760;
    zT_762 = zF_9DABAED9_nameManglerMintSynt(zT_749, zT_750, zT_751, zT_752, (unsigned int)(63));
    return zT_762;
    z_bb_129:
    zT_764 = reg;
    zT_765 = tid;
    zT_766 = zF_41B57F53_typeRegistryCNameId(zT_764, zT_765);
    c_nid = zT_766;
    zT_767 = 0;
    if ((unsigned char)(c_nid != (unsigned int)zT_767)) goto z_bb_130; else goto z_bb_131;
    z_bb_130:
    zT_769 = mangler->interner;
    zT_770 = c_nid;
    zT_772 = zF_9134020D_stringInternerGet(zT_769, zT_770);
    return zT_772;
    z_bb_131:
    zT_773 = ty.kind;
    if ((unsigned char)(zT_773 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_132; else goto z_bb_133;
    z_bb_132:
    zT_777 = reg->eu_items;
    zT_778 = ty.payload_idx;
    zT_779 = (unsigned int)zT_778;
    zT_780 = zT_777[zT_779];
    ep = zT_780;
    zig_poison_fill((void*)&zT_782, (unsigned int)sizeof zT_782);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_782[_i];
        _i++;
    }
}
    zT_784 = 0;
    p = zT_784;
    zT_786 = "EU_";
    zT_788 = 3;
    zT_787.ptr = (unsigned char*)zT_786;
    zT_787.len = zT_788;
    pref = zT_787;
    zT_790 = 0;
    pi = zT_790;
    goto z_bb_134;
    z_bb_133:
    zT_870 = ty.kind;
    if ((unsigned char)(zT_870 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_150; else goto z_bb_151;
    z_bb_134:
    zT_792 = pref.len;
    if ((unsigned char)(pi < zT_792)) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    zT_797 = pref.ptr;
    zT_798 = pref.len;
    zT_799 = pi < zT_798;
    if (!(zT_799)) { pal_trap(); }
    zT_800 = zT_797[pi];
    zT_802 = p < (unsigned int)(64);
    if (!(zT_802)) { pal_trap(); }
    buf[p] = zT_800;
    zT_803 = 1;
    zT_804 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_803)), 32u);
    zT_805 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_803)), 32u);
    zT_807 = zT_805 == (unsigned int)(0);
    if (!(zT_807)) { pal_trap(); }
    p = zT_804;
    goto z_bb_137;
    z_bb_136:
    zT_814 = ep.payload;
    pl = zT_814;
    di = p;
    goto z_bb_141;
    z_bb_137:
    zT_808 = 1;
    zT_809 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_808)), 32u);
    zT_810 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_808)), 32u);
    zT_812 = zT_810 == (unsigned int)(0);
    if (!(zT_812)) { pal_trap(); }
    pi = zT_809;
    goto z_bb_134;
    z_bb_138:
    zT_794 = p < (unsigned int)(63);
    goto z_bb_140;
    z_bb_139:
    zT_794 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_794) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    if ((unsigned char)(pl > (unsigned int)(0))) goto z_bb_146; else goto z_bb_145;
    z_bb_142:
    zT_820 = 48;
    zT_824 = 1;
    if (!(zT_824)) { pal_trap(); }
    zT_822 = pl % (unsigned int)(10);
    zT_825 = zig_wrap_add_u(((zu64)(zT_820)), ((zu64)(zT_822)), 32u);
    zT_826 = zig_overflow_flag_add_u(((zu64)(zT_820)), ((zu64)(zT_822)), 32u);
    zT_828 = zT_826 == (unsigned int)(0);
    if (!(zT_828)) { pal_trap(); }
    zT_829 = (unsigned char)zig_cast_checked_u((zu64)zT_825, 32u, 0u, 8u);
    zT_831 = di < (unsigned int)(64);
    if (!(zT_831)) { pal_trap(); }
    buf[di] = zT_829;
    zT_835 = 1;
    if (!(zT_835)) { pal_trap(); }
    zT_833 = pl / (unsigned int)(10);
    pl = zT_833;
    if ((unsigned char)(di >= (unsigned int)(63))) goto z_bb_148; else goto z_bb_149;
    z_bb_143:
    p = di;
    zT_844 = mangler;
    zT_848 = mangler->interner;
    zT_853 = 0;
    zT_854 = (unsigned char*)((unsigned char*)buf) + zT_853;
    zT_855 = p - zT_853;
    zT_856 = (unsigned int)zT_853 <= p;
    if (!(zT_856)) { pal_trap(); }
    zT_857 = p <= (unsigned int)(64);
    if (!(zT_857)) { pal_trap(); }
    zT_858.ptr = (unsigned char*)zT_854;
    zT_858.len = zT_855;
    zT_849 = zT_858;
    zT_859 = zF_50C274AF_stringInternerInter(zT_848, zT_849);
    zT_845 = zT_859;
    zT_862 = zF_713D1938_nameManglerMangle(zT_844, zT_845, (unsigned char)(2), (unsigned int)(0));
    eu_nid = zT_862;
    zT_863 = reg;
    zT_864 = tid;
    zT_865 = eu_nid;
    zF_6D108807_typeRegistryCNameId(zT_863, zT_864, zT_865);
    zT_866 = mangler->interner;
    zT_867 = eu_nid;
    zT_869 = zF_9134020D_stringInternerGet(zT_866, zT_867);
    return zT_869;
    z_bb_144:
    zT_838 = 1;
    zT_839 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_838)), 32u);
    zT_840 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_838)), 32u);
    zT_842 = zT_840 == (unsigned int)(0);
    if (!(zT_842)) { pal_trap(); }
    di = zT_839;
    goto z_bb_141;
    z_bb_145:
    zT_818 = di == p;
    goto z_bb_147;
    z_bb_146:
    zT_818 = 1;
    goto z_bb_147;
    z_bb_147:
    if (zT_818) goto z_bb_142; else goto z_bb_143;
    z_bb_148:
    goto z_bb_143;
    z_bb_149:
    goto z_bb_144;
    z_bb_150:
    zT_874 = reg->fn_items;
    zT_875 = ty.payload_idx;
    zT_876 = (unsigned int)zT_875;
    zT_877 = zT_874[zT_876];
    fpp = zT_877;
    zig_poison_fill((void*)&zT_879, (unsigned int)sizeof zT_879);
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fbuf[_i] = zT_879[_i];
        _i++;
    }
}
    zT_881 = 0;
    fpos = zT_881;
    zT_882 = 70;
    zT_883 = 0;
    zT_885 = (unsigned int)zT_883 < (unsigned int)(96);
    if (!(zT_885)) { pal_trap(); }
    fbuf[zT_883] = zT_882;
    zT_886 = 95;
    zT_887 = 2;
    zT_889 = (unsigned int)zT_887 < (unsigned int)(96);
    if (!(zT_889)) { pal_trap(); }
    fbuf[zT_887] = zT_886;
    zT_890 = fpp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_890 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_152; else goto z_bb_154;
    z_bb_151:
    zT_1051 = ty.kind;
    if ((unsigned char)(zT_1051 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_152:
    zT_895 = 83;
    zT_896 = 1;
    zT_898 = (unsigned int)zT_896 < (unsigned int)(96);
    if (!(zT_898)) { pal_trap(); }
    fbuf[zT_896] = zT_895;
    goto z_bb_153;
    z_bb_153:
    zT_912 = 3;
    fpos = zT_912;
    zT_914 = reg;
    zT_915 = mangler;
    zT_916 = fpp.return_type;
    zT_918 = zF_08CFA1F1_typeCName(zT_914, zT_915, zT_916);
    fret_c = zT_918;
    zT_920 = 0;
    fri = zT_920;
    goto z_bb_158;
    z_bb_154:
    zT_899 = ty.flags;
    zT_901 = zT_899 & (unsigned int)(1);
    if ((unsigned char)(zT_901 != (unsigned int)(0))) goto z_bb_155; else goto z_bb_157;
    z_bb_155:
    zT_904 = 80;
    zT_905 = 1;
    zT_907 = (unsigned int)zT_905 < (unsigned int)(96);
    if (!(zT_907)) { pal_trap(); }
    fbuf[zT_905] = zT_904;
    goto z_bb_156;
    z_bb_156:
    goto z_bb_153;
    z_bb_157:
    zT_908 = 78;
    zT_909 = 1;
    zT_911 = (unsigned int)zT_909 < (unsigned int)(96);
    if (!(zT_911)) { pal_trap(); }
    fbuf[zT_909] = zT_908;
    goto z_bb_156;
    z_bb_158:
    zT_922 = fret_c.len;
    if ((unsigned char)(fri < zT_922)) goto z_bb_162; else goto z_bb_163;
    z_bb_159:
    zT_928 = fret_c.ptr;
    zT_929 = fret_c.len;
    zT_930 = fri < zT_929;
    if (!(zT_930)) { pal_trap(); }
    zT_931 = zT_928[fri];
    fc = zT_931;
    if ((unsigned char)(fc == (unsigned char)(32))) goto z_bb_166; else goto z_bb_165;
    z_bb_160:
    zT_951 = fpp.params_count;
    fpcnt = zT_951;
    zT_953 = fpp.params_start;
    zT_954 = (unsigned int)zT_953;
    zT_955 = (unsigned int)fpcnt;
    zT_956 = zig_wrap_add_u(((zu64)(zT_954)), ((zu64)(zT_955)), 32u);
    zT_957 = zig_overflow_flag_add_u(((zu64)(zT_954)), ((zu64)(zT_955)), 32u);
    zT_959 = zT_957 == (unsigned int)(0);
    if (!(zT_959)) { pal_trap(); }
    fpend = zT_956;
    zT_960 = reg->xt_len;
    if ((unsigned char)(fpend <= zT_960)) goto z_bb_170; else goto z_bb_171;
    z_bb_161:
    zT_945 = 1;
    zT_946 = zig_wrap_add_u(((zu64)(fri)), ((zu64)(zT_945)), 32u);
    zT_947 = zig_overflow_flag_add_u(((zu64)(fri)), ((zu64)(zT_945)), 32u);
    zT_949 = zT_947 == (unsigned int)(0);
    if (!(zT_949)) { pal_trap(); }
    fri = zT_946;
    goto z_bb_158;
    z_bb_162:
    zT_924 = fpos < (unsigned int)(95);
    goto z_bb_164;
    z_bb_163:
    zT_924 = 0;
    goto z_bb_164;
    z_bb_164:
    if (zT_924) goto z_bb_159; else goto z_bb_160;
    z_bb_165:
    zT_934 = fc == (unsigned char)(42);
    goto z_bb_167;
    z_bb_166:
    zT_934 = 1;
    goto z_bb_167;
    z_bb_167:
    if (zT_934) goto z_bb_168; else goto z_bb_169;
    z_bb_168:
    zT_937 = 95;
    fc = zT_937;
    goto z_bb_169;
    z_bb_169:
    zT_939 = fpos < (unsigned int)(96);
    if (!(zT_939)) { pal_trap(); }
    fbuf[fpos] = fc;
    zT_940 = 1;
    zT_941 = zig_wrap_add_u(((zu64)(fpos)), ((zu64)(zT_940)), 32u);
    zT_942 = zig_overflow_flag_add_u(((zu64)(fpos)), ((zu64)(zT_940)), 32u);
    zT_944 = zT_942 == (unsigned int)(0);
    if (!(zT_944)) { pal_trap(); }
    fpos = zT_941;
    goto z_bb_161;
    z_bb_170:
    zT_963 = fpp.params_start;
    zT_964 = (unsigned int)zT_963;
    fpcur = zT_964;
    goto z_bb_172;
    z_bb_171:
    zT_1024 = mangler->interner;
    zT_1029 = 0;
    zT_1030 = (unsigned char*)((unsigned char*)fbuf) + zT_1029;
    zT_1031 = fpos - zT_1029;
    zT_1032 = (unsigned int)zT_1029 <= fpos;
    if (!(zT_1032)) { pal_trap(); }
    zT_1033 = fpos <= (unsigned int)(96);
    if (!(zT_1033)) { pal_trap(); }
    zT_1034.ptr = (unsigned char*)zT_1030;
    zT_1034.len = zT_1031;
    zT_1025 = zT_1034;
    zT_1035 = zF_50C274AF_stringInternerInter(zT_1024, zT_1025);
    fp_nid = zT_1035;
    zT_1037 = mangler;
    zT_1038 = fp_nid;
    zT_1043 = zF_713D1938_nameManglerMangle(zT_1037, zT_1038, (unsigned char)(2), (unsigned int)(0));
    fp_mid = zT_1043;
    zT_1044 = reg;
    zT_1045 = tid;
    zT_1046 = fp_mid;
    zF_6D108807_typeRegistryCNameId(zT_1044, zT_1045, zT_1046);
    zT_1047 = mangler->interner;
    zT_1048 = fp_mid;
    zT_1050 = zF_9134020D_stringInternerGet(zT_1047, zT_1048);
    return zT_1050;
    z_bb_172:
    if ((unsigned char)(fpcur < fpend)) goto z_bb_176; else goto z_bb_177;
    z_bb_173:
    if ((unsigned char)(fpos < (unsigned int)(95))) goto z_bb_179; else goto z_bb_180;
    z_bb_174:
    goto z_bb_171;
    z_bb_175:
    zT_1018 = 1;
    zT_1019 = zig_wrap_add_u(((zu64)(fpcur)), ((zu64)(zT_1018)), 32u);
    zT_1020 = zig_overflow_flag_add_u(((zu64)(fpcur)), ((zu64)(zT_1018)), 32u);
    zT_1022 = zT_1020 == (unsigned int)(0);
    if (!(zT_1022)) { pal_trap(); }
    fpcur = zT_1019;
    goto z_bb_172;
    z_bb_176:
    zT_966 = fpos < (unsigned int)(95);
    goto z_bb_178;
    z_bb_177:
    zT_966 = 0;
    goto z_bb_178;
    z_bb_178:
    if (zT_966) goto z_bb_173; else goto z_bb_174;
    z_bb_179:
    zT_971 = 95;
    zT_973 = fpos < (unsigned int)(96);
    if (!(zT_973)) { pal_trap(); }
    fbuf[fpos] = zT_971;
    zT_974 = 1;
    zT_975 = zig_wrap_add_u(((zu64)(fpos)), ((zu64)(zT_974)), 32u);
    zT_976 = zig_overflow_flag_add_u(((zu64)(fpos)), ((zu64)(zT_974)), 32u);
    zT_978 = zT_976 == (unsigned int)(0);
    if (!(zT_978)) { pal_trap(); }
    fpos = zT_975;
    goto z_bb_180;
    z_bb_180:
    zT_980 = reg->xt_items;
    zT_981 = zT_980[fpcur];
    fptid = zT_981;
    zT_983 = reg;
    zT_984 = mangler;
    zT_985 = fptid;
    zT_986 = zF_08CFA1F1_typeCName(zT_983, zT_984, zT_985);
    fp_c = zT_986;
    zT_988 = 0;
    fpj = zT_988;
    goto z_bb_181;
    z_bb_181:
    zT_990 = fp_c.len;
    if ((unsigned char)(fpj < zT_990)) goto z_bb_185; else goto z_bb_186;
    z_bb_182:
    zT_996 = fp_c.ptr;
    zT_997 = fp_c.len;
    zT_998 = fpj < zT_997;
    if (!(zT_998)) { pal_trap(); }
    zT_999 = zT_996[fpj];
    fc2 = zT_999;
    if ((unsigned char)(fc2 == (unsigned char)(32))) goto z_bb_189; else goto z_bb_188;
    z_bb_183:
    goto z_bb_175;
    z_bb_184:
    zT_1013 = 1;
    zT_1014 = zig_wrap_add_u(((zu64)(fpj)), ((zu64)(zT_1013)), 32u);
    zT_1015 = zig_overflow_flag_add_u(((zu64)(fpj)), ((zu64)(zT_1013)), 32u);
    zT_1017 = zT_1015 == (unsigned int)(0);
    if (!(zT_1017)) { pal_trap(); }
    fpj = zT_1014;
    goto z_bb_181;
    z_bb_185:
    zT_992 = fpos < (unsigned int)(95);
    goto z_bb_187;
    z_bb_186:
    zT_992 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_992) goto z_bb_182; else goto z_bb_183;
    z_bb_188:
    zT_1002 = fc2 == (unsigned char)(42);
    goto z_bb_190;
    z_bb_189:
    zT_1002 = 1;
    goto z_bb_190;
    z_bb_190:
    if (zT_1002) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_1005 = 95;
    fc2 = zT_1005;
    goto z_bb_192;
    z_bb_192:
    zT_1007 = fpos < (unsigned int)(96);
    if (!(zT_1007)) { pal_trap(); }
    fbuf[fpos] = fc2;
    zT_1008 = 1;
    zT_1009 = zig_wrap_add_u(((zu64)(fpos)), ((zu64)(zT_1008)), 32u);
    zT_1010 = zig_overflow_flag_add_u(((zu64)(fpos)), ((zu64)(zT_1008)), 32u);
    zT_1012 = zT_1010 == (unsigned int)(0);
    if (!(zT_1012)) { pal_trap(); }
    fpos = zT_1009;
    goto z_bb_184;
    z_bb_193:
    zT_1054 = ty.name_id;
    if ((unsigned char)(zT_1054 == (unsigned int)(0))) goto z_bb_195; else goto z_bb_196;
    z_bb_194:
    zT_1165 = mangler;
    zT_1166 = ty.name_id;
    zT_1171 = ty.module_id;
    zT_1173 = zF_713D1938_nameManglerMangle(zT_1165, zT_1166, (unsigned char)(2), (unsigned int)((unsigned int)zT_1171));
    mid = zT_1173;
    zT_1174 = reg;
    zT_1175 = tid;
    zT_1176 = mid;
    zF_6D108807_typeRegistryCNameId(zT_1174, zT_1175, zT_1176);
    zT_1177 = mangler->interner;
    zT_1178 = mid;
    zT_1180 = zF_9134020D_stringInternerGet(zT_1177, zT_1178);
    return zT_1180;
    z_bb_195:
    zig_poison_fill((void*)&zT_1058, (unsigned int)sizeof zT_1058);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_1058[_i];
        _i++;
    }
}
    zT_1060 = 0;
    p = zT_1060;
    zT_1062 = "ES_";
    zT_1064 = 3;
    zT_1063.ptr = (unsigned char*)zT_1062;
    zT_1063.len = zT_1064;
    pref = zT_1063;
    zT_1066 = 0;
    pi = zT_1066;
    goto z_bb_197;
    z_bb_196:
    zT_1148 = mangler;
    zT_1149 = ty.name_id;
    zT_1154 = ty.module_id;
    zT_1156 = zF_713D1938_nameManglerMangle(zT_1148, zT_1149, (unsigned char)(2), (unsigned int)((unsigned int)zT_1154));
    mid = zT_1156;
    zT_1157 = reg;
    zT_1158 = tid;
    zT_1159 = mid;
    zF_6D108807_typeRegistryCNameId(zT_1157, zT_1158, zT_1159);
    zT_1160 = mangler->interner;
    zT_1161 = mid;
    zT_1163 = zF_9134020D_stringInternerGet(zT_1160, zT_1161);
    return zT_1163;
    z_bb_197:
    zT_1068 = pref.len;
    if ((unsigned char)(pi < zT_1068)) goto z_bb_201; else goto z_bb_202;
    z_bb_198:
    zT_1073 = pref.ptr;
    zT_1074 = pref.len;
    zT_1075 = pi < zT_1074;
    if (!(zT_1075)) { pal_trap(); }
    zT_1076 = zT_1073[pi];
    zT_1078 = p < (unsigned int)(64);
    if (!(zT_1078)) { pal_trap(); }
    buf[p] = zT_1076;
    zT_1079 = 1;
    zT_1080 = zig_wrap_add_u(((zu64)(p)), ((zu64)(zT_1079)), 32u);
    zT_1081 = zig_overflow_flag_add_u(((zu64)(p)), ((zu64)(zT_1079)), 32u);
    zT_1083 = zT_1081 == (unsigned int)(0);
    if (!(zT_1083)) { pal_trap(); }
    p = zT_1080;
    goto z_bb_200;
    z_bb_199:
    zT_1090 = ty.payload_idx;
    zT_1091 = (unsigned int)zT_1090;
    pl = zT_1091;
    di = p;
    goto z_bb_204;
    z_bb_200:
    zT_1084 = 1;
    zT_1085 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_1084)), 32u);
    zT_1086 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_1084)), 32u);
    zT_1088 = zT_1086 == (unsigned int)(0);
    if (!(zT_1088)) { pal_trap(); }
    pi = zT_1085;
    goto z_bb_197;
    z_bb_201:
    zT_1070 = p < (unsigned int)(63);
    goto z_bb_203;
    z_bb_202:
    zT_1070 = 0;
    goto z_bb_203;
    z_bb_203:
    if (zT_1070) goto z_bb_198; else goto z_bb_199;
    z_bb_204:
    if ((unsigned char)(pl > (unsigned int)(0))) goto z_bb_209; else goto z_bb_208;
    z_bb_205:
    zT_1097 = 48;
    zT_1101 = 1;
    if (!(zT_1101)) { pal_trap(); }
    zT_1099 = pl % (unsigned int)(10);
    zT_1102 = zig_wrap_add_u(((zu64)(zT_1097)), ((zu64)(zT_1099)), 32u);
    zT_1103 = zig_overflow_flag_add_u(((zu64)(zT_1097)), ((zu64)(zT_1099)), 32u);
    zT_1105 = zT_1103 == (unsigned int)(0);
    if (!(zT_1105)) { pal_trap(); }
    zT_1106 = (unsigned char)zig_cast_checked_u((zu64)zT_1102, 32u, 0u, 8u);
    zT_1108 = di < (unsigned int)(64);
    if (!(zT_1108)) { pal_trap(); }
    buf[di] = zT_1106;
    zT_1112 = 1;
    if (!(zT_1112)) { pal_trap(); }
    zT_1110 = pl / (unsigned int)(10);
    pl = zT_1110;
    if ((unsigned char)(di >= (unsigned int)(63))) goto z_bb_211; else goto z_bb_212;
    z_bb_206:
    p = di;
    zT_1121 = mangler;
    zT_1125 = mangler->interner;
    zT_1130 = 0;
    zT_1131 = (unsigned char*)((unsigned char*)buf) + zT_1130;
    zT_1132 = p - zT_1130;
    zT_1133 = (unsigned int)zT_1130 <= p;
    if (!(zT_1133)) { pal_trap(); }
    zT_1134 = p <= (unsigned int)(64);
    if (!(zT_1134)) { pal_trap(); }
    zT_1135.ptr = (unsigned char*)zT_1131;
    zT_1135.len = zT_1132;
    zT_1126 = zT_1135;
    zT_1136 = zF_50C274AF_stringInternerInter(zT_1125, zT_1126);
    zT_1122 = zT_1136;
    zT_1139 = zF_713D1938_nameManglerMangle(zT_1121, zT_1122, (unsigned char)(2), (unsigned int)(0));
    es_nid = zT_1139;
    zT_1140 = reg;
    zT_1141 = tid;
    zT_1142 = es_nid;
    zF_6D108807_typeRegistryCNameId(zT_1140, zT_1141, zT_1142);
    zT_1143 = mangler->interner;
    zT_1144 = es_nid;
    zT_1146 = zF_9134020D_stringInternerGet(zT_1143, zT_1144);
    return zT_1146;
    z_bb_207:
    zT_1115 = 1;
    zT_1116 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_1115)), 32u);
    zT_1117 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_1115)), 32u);
    zT_1119 = zT_1117 == (unsigned int)(0);
    if (!(zT_1119)) { pal_trap(); }
    di = zT_1116;
    goto z_bb_204;
    z_bb_208:
    zT_1095 = di == p;
    goto z_bb_210;
    z_bb_209:
    zT_1095 = 1;
    goto z_bb_210;
    z_bb_210:
    if (zT_1095) goto z_bb_205; else goto z_bb_206;
    z_bb_211:
    goto z_bb_206;
    z_bb_212:
    goto z_bb_207;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_0C0306D6_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreatePtrQ */
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_79FAE712_u64 zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_79FAE712_u64 zT_21;
    zT_BAEE192E_Opt_10 zT_23;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_112BF819_PtrPayload zT_27;
    zT_112BF819_PtrPayload zT_28;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_D155D06D_Type zT_31;
    zT_D155D06D_Type zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    unsigned char zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned short zT_38;
    unsigned int zT_39;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_11 = (zT_79FAE712_u64)base;
    zT_12 = 2;
    zT_15 = zT_12 < (unsigned int)(64);
    if (!(zT_15)) { pal_trap(); }
    zT_13 = zig_wrap_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 64u);
    zT_16 = zig_overflow_flag_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 64u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_13 | q;
    key = zT_19;
    zT_20 = &self->ptr_cache;
    zT_21 = key;
    zT_23 = zF_A05A7BE1_u64ToU32MapGet(zT_20, zT_21);
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    if (!(zT_23.has_value)) { pal_trap(); }
    existing = zT_23.value;
    return existing;
    z_bb_7:
    zT_26 = self;
    zT_28.base = base;
    zT_27 = zT_28;
    zF_E5939FBD_ptrAppend(zT_26, zT_27);
    zT_30 = self;
    zT_33 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_32.kind = zT_33;
    zT_34 = 2;
    zT_32.state = zT_34;
    zT_35 = (unsigned char)zig_cast_checked_u((zu64)q, 64u, 0u, 8u);
    zT_32.flags = zT_35;
    zT_36 = 0;
    zT_32.iw = zT_36;
    zT_37 = 4;
    zT_32.size = zT_37;
    zT_38 = 4;
    zT_32.alignment = zT_38;
    zT_39 = 0;
    zT_32.name_id = zT_39;
    zT_40 = 0;
    zT_32.module_id = zT_40;
    zT_41 = self->ptr_len;
    zT_42 = 1;
    zT_43 = zig_wrap_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = (unsigned int)zT_43;
    zT_32.payload_idx = zT_47;
    zT_31 = zT_32;
    zT_48 = zF_D4993F02_typeRegistryAppend(zT_30, zT_31);
    tid = zT_48;
    zT_49 = &self->ptr_cache;
    zT_50 = key;
    zT_51 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_49, zT_50, zT_51);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned char zT_5;
    unsigned int zT_8;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_3 = self;
    zT_4 = base;
    zT_5 = is_const;
    zT_8 = zF_827207A1_typeRegistryGetOrCr(zT_3, zT_4, zT_5, (unsigned char)(0));
    return zT_8;
}

/* typeRegistryGetOrCreateManyPtrQ */
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, unsigned char is_const, unsigned char is_volatile) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_79FAE712_u64 zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_79FAE712_u64 zT_21;
    zT_BAEE192E_Opt_10 zT_23;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_112BF819_PtrPayload zT_27;
    zT_112BF819_PtrPayload zT_28;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_D155D06D_Type zT_31;
    zT_D155D06D_Type zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    unsigned char zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned int zT_37;
    unsigned short zT_38;
    unsigned int zT_39;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_A4CE86B7_U64ToU32Map* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    q = zT_5;
    if (is_volatile) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_9 = q | (zT_79FAE712_u64)(2);
    q = zT_9;
    goto z_bb_5;
    z_bb_5:
    zT_11 = (zT_79FAE712_u64)base;
    zT_12 = 2;
    zT_15 = zT_12 < (unsigned int)(64);
    if (!(zT_15)) { pal_trap(); }
    zT_13 = zig_wrap_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 64u);
    zT_16 = zig_overflow_flag_shl_u(((zu64)(zT_11)), ((zu64)(zT_12)), 64u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_13 | q;
    key = zT_19;
    zT_20 = &self->many_ptr_cache;
    zT_21 = key;
    zT_23 = zF_A05A7BE1_u64ToU32MapGet(zT_20, zT_21);
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    if (!(zT_23.has_value)) { pal_trap(); }
    existing = zT_23.value;
    return existing;
    z_bb_7:
    zT_26 = self;
    zT_28.base = base;
    zT_27 = zT_28;
    zF_E5939FBD_ptrAppend(zT_26, zT_27);
    zT_30 = self;
    zT_33 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_32.kind = zT_33;
    zT_34 = 2;
    zT_32.state = zT_34;
    zT_35 = (unsigned char)zig_cast_checked_u((zu64)q, 64u, 0u, 8u);
    zT_32.flags = zT_35;
    zT_36 = 0;
    zT_32.iw = zT_36;
    zT_37 = 4;
    zT_32.size = zT_37;
    zT_38 = 4;
    zT_32.alignment = zT_38;
    zT_39 = 0;
    zT_32.name_id = zT_39;
    zT_40 = 0;
    zT_32.module_id = zT_40;
    zT_41 = self->ptr_len;
    zT_42 = 1;
    zT_43 = zig_wrap_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = (unsigned int)zT_43;
    zT_32.payload_idx = zT_47;
    zT_31 = zT_32;
    zT_48 = zF_D4993F02_typeRegistryAppend(zT_30, zT_31);
    tid = zT_48;
    zT_49 = &self->many_ptr_cache;
    zT_50 = key;
    zT_51 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_49, zT_50, zT_51);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned char is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_79FAE712_u64 zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_79FAE712_u64 zT_18;
    zT_BAEE192E_Opt_10 zT_20;
    unsigned char zT_21;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_4028D896_Arr_unsigned_char_2 zT_29;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    int zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    unsigned char zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_4028D896_Arr_unsigned_char_2 zT_61;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    int zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    unsigned char zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_4028D896_Arr_unsigned_char_2 zT_93;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    int zT_100;
    unsigned char* zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned char zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_115;
    unsigned char* zT_116;
    unsigned int zT_117;
    unsigned char zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_338B7C76_TypeRegistry* zT_120;
    zT_0BB2A741_SlicePayload zT_121;
    zT_0BB2A741_SlicePayload zT_122;
    zT_338B7C76_TypeRegistry* zT_124;
    zT_D155D06D_Type zT_125;
    zT_D155D06D_Type zT_126;
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char zT_128;
    unsigned char zT_129;
    int zT_130;
    int zT_132;
    unsigned char zT_134;
    unsigned char zT_135;
    unsigned int zT_136;
    unsigned short zT_137;
    unsigned int zT_138;
    unsigned short zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_A4CE86B7_U64ToU32Map* zT_148;
    zT_79FAE712_u64 zT_149;
    unsigned int zT_150;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    zT_4028D896_Arr_unsigned_char_2 zT_158;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    int zT_164;
    unsigned char* zT_165;
    unsigned int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_179;
    unsigned char* zT_180;
    unsigned int zT_181;
    unsigned char zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_4028D896_Arr_unsigned_char_2 zT_190;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    int zT_196;
    unsigned char* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    unsigned int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned char zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_211;
    unsigned char* zT_212;
    unsigned int zT_213;
    unsigned char zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    zT_4028D896_Arr_unsigned_char_2 zT_222;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    int zT_229;
    unsigned char* zT_230;
    unsigned int zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned char zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_244;
    unsigned char* zT_245;
    unsigned int zT_246;
    unsigned char zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_104, (unsigned int)sizeof zT_104);
    zig_poison_fill((void*)&zT_147, (unsigned int)sizeof zT_147);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zig_poison_fill((void*)&zT_233, (unsigned int)sizeof zT_233);
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)elem;
    zT_9 = 1;
    zT_12 = zT_9 < (unsigned int)(64);
    if (!(zT_12)) { pal_trap(); }
    zT_10 = zig_wrap_shl_u(((zu64)(zT_8)), ((zu64)(zT_9)), 64u);
    zT_13 = zig_overflow_flag_shl_u(((zu64)(zT_8)), ((zu64)(zT_9)), 64u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_10 | ic;
    key = zT_16;
    zT_17 = &self->slice_cache;
    zT_18 = key;
    zT_20 = zF_A05A7BE1_u64ToU32MapGet(zT_17, zT_18);
    zT_21 = zT_20.has_value;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    if (!(zT_20.has_value)) { pal_trap(); }
    existing = zT_20.value;
    zT_24 = "U2H:e";
    zT_26 = 5;
    zT_25.ptr = (unsigned char*)zT_24;
    zT_25.len = zT_26;
    u2h_m = zT_25;
    zT_27 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_27);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_29[_i];
        _i++;
    }
}
    zT_31 = elem;
    zT_35 = 0;
    zT_36 = (unsigned char*)((unsigned char*)u2h_eb) + zT_35;
    zT_37 = (unsigned int)(20) - zT_35;
    zT_38.ptr = (unsigned char*)zT_36;
    zT_38.len = zT_37;
    zT_32 = zT_38;
    zT_39 = zF_A7504564_itoa(zT_31, zT_32);
    u2h_el = zT_39;
    zT_41 = 19;
    zT_42 = (unsigned int)u2h_el;
    zT_43 = zig_wrap_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_sub_u(((zu64)(zT_41)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    u2h_es = zT_43;
    zT_50 = 19;
    zT_51 = (unsigned char*)((unsigned char*)u2h_eb) + u2h_es;
    zT_52 = zT_50 - u2h_es;
    zT_53 = u2h_es <= zT_50;
    if (!(zT_53)) { pal_trap(); }
    zT_54.ptr = (unsigned char*)zT_51;
    zT_54.len = zT_52;
    zT_47 = zT_54;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_56 = "r";
    zT_58 = 1;
    zT_57.ptr = (unsigned char*)zT_56;
    zT_57.len = zT_58;
    u2h_rm = zT_57;
    zT_59 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_59);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_61[_i];
        _i++;
    }
}
    zT_63 = existing;
    zT_67 = 0;
    zT_68 = (unsigned char*)((unsigned char*)u2h_rb) + zT_67;
    zT_69 = (unsigned int)(20) - zT_67;
    zT_70.ptr = (unsigned char*)zT_68;
    zT_70.len = zT_69;
    zT_64 = zT_70;
    zT_71 = zF_A7504564_itoa(zT_63, zT_64);
    u2h_rl = zT_71;
    zT_73 = 19;
    zT_74 = (unsigned int)u2h_rl;
    zT_75 = zig_wrap_sub_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_sub_u(((zu64)(zT_73)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    u2h_rs = zT_75;
    zT_82 = 19;
    zT_83 = (unsigned char*)((unsigned char*)u2h_rb) + u2h_rs;
    zT_84 = zT_82 - u2h_rs;
    zT_85 = u2h_rs <= zT_82;
    if (!(zT_85)) { pal_trap(); }
    zT_86.ptr = (unsigned char*)zT_83;
    zT_86.len = zT_84;
    zT_79 = zT_86;
    zF_48AC7B3A_markerWrite(zT_79);
    zT_88 = "c";
    zT_90 = 1;
    zT_89.ptr = (unsigned char*)zT_88;
    zT_89.len = zT_90;
    u2h_cm = zT_89;
    zT_91 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_91);
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_93[_i];
        _i++;
    }
}
    zT_95 = (unsigned int)zig_cast_checked_u((zu64)ic, 64u, 0u, 32u);
    zT_100 = 0;
    zT_101 = (unsigned char*)((unsigned char*)u2h_cb) + zT_100;
    zT_102 = (unsigned int)(20) - zT_100;
    zT_103.ptr = (unsigned char*)zT_101;
    zT_103.len = zT_102;
    zT_96 = zT_103;
    zT_104 = zF_A7504564_itoa(zT_95, zT_96);
    u2h_cl = zT_104;
    zT_106 = 19;
    zT_107 = (unsigned int)u2h_cl;
    zT_108 = zig_wrap_sub_u(((zu64)(zT_106)), ((zu64)(zT_107)), 32u);
    zT_109 = zig_overflow_flag_sub_u(((zu64)(zT_106)), ((zu64)(zT_107)), 32u);
    zT_111 = zT_109 == (unsigned int)(0);
    if (!(zT_111)) { pal_trap(); }
    u2h_cs = zT_108;
    zT_115 = 19;
    zT_116 = (unsigned char*)((unsigned char*)u2h_cb) + u2h_cs;
    zT_117 = zT_115 - u2h_cs;
    zT_118 = u2h_cs <= zT_115;
    if (!(zT_118)) { pal_trap(); }
    zT_119.ptr = (unsigned char*)zT_116;
    zT_119.len = zT_117;
    zT_112 = zT_119;
    zF_48AC7B3A_markerWrite(zT_112);
    return existing;
    z_bb_5:
    zT_120 = self;
    zT_122.elem = elem;
    zT_121 = zT_122;
    zF_8BFD6695_sliceAppend(zT_120, zT_121);
    zT_124 = self;
    zT_127 = zT_33EF6BFB_TypeKind_slice_type;
    zT_126.kind = zT_127;
    zT_128 = 2;
    zT_126.state = zT_128;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_130 = 1;
    zT_129 = (unsigned char)zT_130;
    goto z_bb_8;
    z_bb_7:
    zT_132 = 0;
    zT_129 = (unsigned char)zT_132;
    goto z_bb_8;
    z_bb_8:
    zT_134 = (unsigned char)zT_129;
    zT_126.flags = zT_134;
    zT_135 = 0;
    zT_126.iw = zT_135;
    zT_136 = 8;
    zT_126.size = zT_136;
    zT_137 = 4;
    zT_126.alignment = zT_137;
    zT_138 = 0;
    zT_126.name_id = zT_138;
    zT_139 = 0;
    zT_126.module_id = zT_139;
    zT_140 = self->slice_len;
    zT_141 = 1;
    zT_142 = zig_wrap_sub_u(((zu64)(zT_140)), ((zu64)(zT_141)), 32u);
    zT_143 = zig_overflow_flag_sub_u(((zu64)(zT_140)), ((zu64)(zT_141)), 32u);
    zT_145 = zT_143 == (unsigned int)(0);
    if (!(zT_145)) { pal_trap(); }
    zT_146 = (unsigned int)zT_142;
    zT_126.payload_idx = zT_146;
    zT_125 = zT_126;
    zT_147 = zF_D4993F02_typeRegistryAppend(zT_124, zT_125);
    tid = zT_147;
    zT_148 = &self->slice_cache;
    zT_149 = key;
    zT_150 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_148, zT_149, zT_150);
    zT_153 = "U2N:e";
    zT_155 = 5;
    zT_154.ptr = (unsigned char*)zT_153;
    zT_154.len = zT_155;
    u2n_m = zT_154;
    zT_156 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_156);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_158[_i];
        _i++;
    }
}
    zT_160 = elem;
    zT_164 = 0;
    zT_165 = (unsigned char*)((unsigned char*)u2n_eb) + zT_164;
    zT_166 = (unsigned int)(20) - zT_164;
    zT_167.ptr = (unsigned char*)zT_165;
    zT_167.len = zT_166;
    zT_161 = zT_167;
    zT_168 = zF_A7504564_itoa(zT_160, zT_161);
    u2n_el = zT_168;
    zT_170 = 19;
    zT_171 = (unsigned int)u2n_el;
    zT_172 = zig_wrap_sub_u(((zu64)(zT_170)), ((zu64)(zT_171)), 32u);
    zT_173 = zig_overflow_flag_sub_u(((zu64)(zT_170)), ((zu64)(zT_171)), 32u);
    zT_175 = zT_173 == (unsigned int)(0);
    if (!(zT_175)) { pal_trap(); }
    u2n_es = zT_172;
    zT_179 = 19;
    zT_180 = (unsigned char*)((unsigned char*)u2n_eb) + u2n_es;
    zT_181 = zT_179 - u2n_es;
    zT_182 = u2n_es <= zT_179;
    if (!(zT_182)) { pal_trap(); }
    zT_183.ptr = (unsigned char*)zT_180;
    zT_183.len = zT_181;
    zT_176 = zT_183;
    zF_48AC7B3A_markerWrite(zT_176);
    zT_185 = "r";
    zT_187 = 1;
    zT_186.ptr = (unsigned char*)zT_185;
    zT_186.len = zT_187;
    u2n_rm = zT_186;
    zT_188 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_188);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_190[_i];
        _i++;
    }
}
    zT_192 = tid;
    zT_196 = 0;
    zT_197 = (unsigned char*)((unsigned char*)u2n_rb) + zT_196;
    zT_198 = (unsigned int)(20) - zT_196;
    zT_199.ptr = (unsigned char*)zT_197;
    zT_199.len = zT_198;
    zT_193 = zT_199;
    zT_200 = zF_A7504564_itoa(zT_192, zT_193);
    u2n_rl = zT_200;
    zT_202 = 19;
    zT_203 = (unsigned int)u2n_rl;
    zT_204 = zig_wrap_sub_u(((zu64)(zT_202)), ((zu64)(zT_203)), 32u);
    zT_205 = zig_overflow_flag_sub_u(((zu64)(zT_202)), ((zu64)(zT_203)), 32u);
    zT_207 = zT_205 == (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    u2n_rs = zT_204;
    zT_211 = 19;
    zT_212 = (unsigned char*)((unsigned char*)u2n_rb) + u2n_rs;
    zT_213 = zT_211 - u2n_rs;
    zT_214 = u2n_rs <= zT_211;
    if (!(zT_214)) { pal_trap(); }
    zT_215.ptr = (unsigned char*)zT_212;
    zT_215.len = zT_213;
    zT_208 = zT_215;
    zF_48AC7B3A_markerWrite(zT_208);
    zT_217 = "c";
    zT_219 = 1;
    zT_218.ptr = (unsigned char*)zT_217;
    zT_218.len = zT_219;
    u2n_cm = zT_218;
    zT_220 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_220);
    zig_poison_fill((void*)&zT_222, (unsigned int)sizeof zT_222);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_222[_i];
        _i++;
    }
}
    zT_224 = (unsigned int)zig_cast_checked_u((zu64)ic, 64u, 0u, 32u);
    zT_229 = 0;
    zT_230 = (unsigned char*)((unsigned char*)u2n_cb) + zT_229;
    zT_231 = (unsigned int)(20) - zT_229;
    zT_232.ptr = (unsigned char*)zT_230;
    zT_232.len = zT_231;
    zT_225 = zT_232;
    zT_233 = zF_A7504564_itoa(zT_224, zT_225);
    u2n_cl = zT_233;
    zT_235 = 19;
    zT_236 = (unsigned int)u2n_cl;
    zT_237 = zig_wrap_sub_u(((zu64)(zT_235)), ((zu64)(zT_236)), 32u);
    zT_238 = zig_overflow_flag_sub_u(((zu64)(zT_235)), ((zu64)(zT_236)), 32u);
    zT_240 = zT_238 == (unsigned int)(0);
    if (!(zT_240)) { pal_trap(); }
    u2n_cs = zT_237;
    zT_244 = 19;
    zT_245 = (unsigned char*)((unsigned char*)u2n_cb) + u2n_cs;
    zT_246 = zT_244 - u2n_cs;
    zT_247 = u2n_cs <= zT_244;
    if (!(zT_247)) { pal_trap(); }
    zT_248.ptr = (unsigned char*)zT_245;
    zT_248.len = zT_246;
    zT_241 = zT_248;
    zF_48AC7B3A_markerWrite(zT_241);
    return tid;
}

/* optionalCompleteIfReady */
void zF_B75A61E8_optionalCompleteIfR(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_0B10E8E9_OptionalPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0B10E8E9_OptionalPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned short zT_33;
    unsigned int zT_37;
    unsigned short zT_38;
    unsigned int zT_42;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned short zT_55;
    zT_D155D06D_Type* zT_57;
    unsigned int zT_58;
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zT_D155D06D_Type ty;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pay_type;
    unsigned int pay_align;
    unsigned int opt_size;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->opt_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->opt_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    op = zT_20;
    zT_21 = op.payload;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = op.payload;
    zT_28 = zT_26[zT_27];
    pay_type = zT_28;
    zT_29 = pay_type.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_33 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_33) > (unsigned int)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_38 = pay_type.alignment;
    zT_37 = (unsigned int)zT_38;
    goto z_bb_13;
    z_bb_12:
    zT_37 = 4;
    goto z_bb_13;
    z_bb_13:
    pay_align = zT_37;
    zT_42 = pay_type.size;
    zT_46 = zF_D2BAC673_alignUp(zT_42, (unsigned int)(4));
    zT_47 = 4;
    zT_48 = zig_wrap_add_u(((zu64)(zT_46)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(zT_46)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    opt_size = zT_48;
    zT_52 = opt_size;
    zT_53 = pay_align;
    zT_54 = zF_D2BAC673_alignUp(zT_52, zT_53);
    opt_size = zT_54;
    ty.size = opt_size;
    zT_55 = (unsigned short)zig_cast_checked_u((zu64)pay_align, 32u, 0u, 16u);
    ty.alignment = zT_55;
    ty.state = (unsigned char)(2);
    zT_57 = self->types_items;
    zT_58 = (unsigned int)tid;
    zT_57[zT_58] = ty;
    return;
}

/* errorUnionCompleteIfReady */
void zF_35E259CB_errorUnionCompleteI(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_42C2D6BF_EUPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_42C2D6BF_EUPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned short zT_40;
    unsigned int zT_44;
    unsigned short zT_45;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned short zT_64;
    zT_D155D06D_Type* zT_66;
    unsigned int zT_67;
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eup;
    zT_D155D06D_Type pay_type;
    unsigned int union_size;
    unsigned int union_align;
    unsigned int total;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->eu_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->eu_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    eup = zT_20;
    zT_21 = eup.payload;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = eup.payload;
    zT_28 = zT_26[zT_27];
    pay_type = zT_28;
    zT_29 = pay_type.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_33 = pay_type.size;
    if ((unsigned char)(zT_33 > (unsigned int)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_36 = pay_type.size;
    goto z_bb_13;
    z_bb_12:
    zT_36 = 4;
    goto z_bb_13;
    z_bb_13:
    union_size = zT_36;
    zT_40 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_40) > (unsigned int)(4))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = pay_type.alignment;
    zT_44 = (unsigned int)zT_45;
    goto z_bb_16;
    z_bb_15:
    zT_44 = 4;
    goto z_bb_16;
    z_bb_16:
    union_align = zT_44;
    zT_49 = union_size;
    zT_50 = union_align;
    zT_51 = zF_D2BAC673_alignUp(zT_49, zT_50);
    total = zT_51;
    zT_52 = total;
    zT_55 = zF_D2BAC673_alignUp(zT_52, (unsigned int)(4));
    zT_56 = 4;
    zT_57 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    total = zT_57;
    zT_61 = total;
    zT_62 = union_align;
    zT_63 = zF_D2BAC673_alignUp(zT_61, zT_62);
    ty.size = zT_63;
    zT_64 = (unsigned short)zig_cast_checked_u((zu64)union_align, 32u, 0u, 16u);
    ty.alignment = zT_64;
    ty.state = (unsigned char)(2);
    zT_66 = self->types_items;
    zT_67 = (unsigned int)tid;
    zT_66[zT_67] = ty;
    return;
}

/* arrayCompleteIfReady */
void zF_C173376D_arrayCompleteIfRead(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    unsigned char zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E834303C_ArrayPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_E834303C_ArrayPayload zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D155D06D_Type* zT_26;
    unsigned int zT_27;
    zT_D155D06D_Type zT_28;
    unsigned char zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned short zT_38;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_D155D06D_Type ty;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type elem_ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.state;
    if ((unsigned char)(zT_9 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = ty.payload_idx;
    zT_13 = self->array_len;
    if ((unsigned char)(zT_12 >= (unsigned int)((unsigned int)zT_13))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_17 = self->array_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    ap = zT_20;
    zT_21 = ap.elem;
    zT_23 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_21) >= zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_26 = self->types_items;
    zT_27 = ap.elem;
    zT_28 = zT_26[zT_27];
    elem_ty = zT_28;
    zT_29 = elem_ty.state;
    if ((unsigned char)(zT_29 != (unsigned char)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    zT_32 = elem_ty.size;
    zT_33 = ap.length;
    zT_34 = zig_wrap_mul_u(((zu64)(zT_32)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_mul_u(((zu64)(zT_32)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    ty.size = zT_34;
    zT_38 = elem_ty.alignment;
    ty.alignment = zT_38;
    ty.state = (unsigned char)(2);
    zT_40 = self->types_items;
    zT_41 = (unsigned int)tid;
    zT_40[zT_41] = ty;
    return;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned char zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_11;
    zT_D155D06D_Type zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned short zT_26;
    unsigned int zT_30;
    unsigned short zT_31;
    unsigned int zT_34;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_338B7C76_TypeRegistry* zT_48;
    zT_0B10E8E9_OptionalPayload zT_49;
    zT_0B10E8E9_OptionalPayload zT_50;
    zT_338B7C76_TypeRegistry* zT_52;
    zT_D155D06D_Type zT_53;
    zT_D155D06D_Type zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_56;
    unsigned char zT_57;
    unsigned short zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_21D3708C_U32ToU32Map* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_2 = &self->optional_cache;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_5.has_value)) { pal_trap(); }
    existing = zT_5.value;
    zT_8 = self;
    zT_9 = existing;
    zF_B75A61E8_optionalCompleteIfR(zT_8, zT_9);
    return existing;
    z_bb_2:
    zT_11 = self->types_items;
    zT_12 = zT_11[payload];
    pay_type = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    opt_size = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    opt_align = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned char)zT_20;
    opt_state = zT_21;
    zT_22 = pay_type.state;
    if ((unsigned char)(zT_22 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_26 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_26) > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_48 = self;
    zT_50.payload = payload;
    zT_49 = zT_50;
    zF_4569340E_optAppend(zT_48, zT_49);
    zT_52 = self;
    zT_55 = zT_33EF6BFB_TypeKind_optional_type;
    zT_54.kind = zT_55;
    zT_54.state = opt_state;
    zT_56 = 0;
    zT_54.flags = zT_56;
    zT_57 = 0;
    zT_54.iw = zT_57;
    zT_54.size = opt_size;
    zT_58 = (unsigned short)zig_cast_checked_u((zu64)opt_align, 32u, 0u, 16u);
    zT_54.alignment = zT_58;
    zT_59 = 0;
    zT_54.name_id = zT_59;
    zT_60 = 0;
    zT_54.module_id = zT_60;
    zT_61 = self->opt_len;
    zT_62 = 1;
    zT_63 = zig_wrap_sub_u(((zu64)(zT_61)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_sub_u(((zu64)(zT_61)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    zT_67 = (unsigned int)zT_63;
    zT_54.payload_idx = zT_67;
    zT_53 = zT_54;
    zT_68 = zF_D4993F02_typeRegistryAppend(zT_52, zT_53);
    tid = zT_68;
    zT_69 = &self->optional_cache;
    zT_70 = payload;
    zT_71 = tid;
    zF_26476265_u32ToU32MapPut(zT_69, zT_70, zT_71);
    return tid;
    z_bb_5:
    zT_31 = pay_type.alignment;
    zT_30 = (unsigned int)zT_31;
    goto z_bb_7;
    z_bb_6:
    zT_30 = 4;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_30;
    zT_34 = pay_type.size;
    zT_38 = zF_D2BAC673_alignUp(zT_34, (unsigned int)(4));
    zT_39 = 4;
    zT_40 = zig_wrap_add_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    opt_size = zT_40;
    zT_44 = opt_size;
    zT_45 = pay_align;
    zT_46 = zF_D2BAC673_alignUp(zT_44, zT_45);
    opt_size = zT_46;
    opt_align = pay_align;
    zT_47 = 2;
    opt_state = zT_47;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_17;
    unsigned char zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type* zT_23;
    zT_D155D06D_Type zT_24;
    int zT_26;
    unsigned int zT_27;
    int zT_29;
    unsigned int zT_30;
    int zT_32;
    unsigned char zT_33;
    unsigned char zT_34;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned short zT_45;
    unsigned int zT_49;
    unsigned short zT_50;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_69;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_42C2D6BF_EUPayload zT_71;
    zT_42C2D6BF_EUPayload zT_72;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_D155D06D_Type zT_75;
    zT_D155D06D_Type zT_76;
    zT_33EF6BFB_TypeKind zT_77;
    unsigned char zT_78;
    unsigned char zT_79;
    unsigned short zT_80;
    unsigned int zT_81;
    unsigned short zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_A4CE86B7_U64ToU32Map* zT_91;
    zT_79FAE712_u64 zT_92;
    unsigned int zT_93;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_4 = (zT_79FAE712_u64)payload;
    zT_5 = 32;
    zT_8 = zT_5 < (unsigned int)(64);
    if (!(zT_8)) { pal_trap(); }
    zT_6 = zig_wrap_shl_u(((zu64)(zT_4)), ((zu64)(zT_5)), 64u);
    zT_9 = zig_overflow_flag_shl_u(((zu64)(zT_4)), ((zu64)(zT_5)), 64u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_13 = zT_6 | (zT_79FAE712_u64)((zT_79FAE712_u64)error_set);
    eu_key = zT_13;
    zT_14 = &self->eu_cache;
    zT_15 = eu_key;
    zT_17 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_17.has_value)) { pal_trap(); }
    existing = zT_17.value;
    zT_20 = self;
    zT_21 = existing;
    zF_35E259CB_errorUnionCompleteI(zT_20, zT_21);
    return existing;
    z_bb_2:
    zT_23 = self->types_items;
    zT_24 = zT_23[payload];
    pay_type = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    eu_size = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    eu_align = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned char)zT_32;
    eu_state = zT_33;
    zT_34 = pay_type.state;
    if ((unsigned char)(zT_34 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_38 = pay_type.size;
    if ((unsigned char)(zT_38 > (unsigned int)(4))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_70 = self;
    zT_72.payload = payload;
    zT_72.error_set = error_set;
    zT_71 = zT_72;
    zF_ABBA52E7_euAppend(zT_70, zT_71);
    zT_74 = self;
    zT_77 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_76.kind = zT_77;
    zT_76.state = eu_state;
    zT_78 = 0;
    zT_76.flags = zT_78;
    zT_79 = 0;
    zT_76.iw = zT_79;
    zT_76.size = eu_size;
    zT_80 = (unsigned short)zig_cast_checked_u((zu64)eu_align, 32u, 0u, 16u);
    zT_76.alignment = zT_80;
    zT_81 = 0;
    zT_76.name_id = zT_81;
    zT_82 = 0;
    zT_76.module_id = zT_82;
    zT_83 = self->eu_len;
    zT_84 = 1;
    zT_85 = zig_wrap_sub_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_sub_u(((zu64)(zT_83)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    zT_89 = (unsigned int)zT_85;
    zT_76.payload_idx = zT_89;
    zT_75 = zT_76;
    zT_90 = zF_D4993F02_typeRegistryAppend(zT_74, zT_75);
    tid = zT_90;
    zT_91 = &self->eu_cache;
    zT_92 = eu_key;
    zT_93 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_91, zT_92, zT_93);
    return tid;
    z_bb_5:
    zT_41 = pay_type.size;
    goto z_bb_7;
    z_bb_6:
    zT_41 = 4;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_41;
    zT_45 = pay_type.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_45) > (unsigned int)(4))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_50 = pay_type.alignment;
    zT_49 = (unsigned int)zT_50;
    goto z_bb_10;
    z_bb_9:
    zT_49 = 4;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_49;
    zT_54 = union_size;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    total = zT_56;
    zT_57 = total;
    zT_60 = zF_D2BAC673_alignUp(zT_57, (unsigned int)(4));
    zT_61 = 4;
    zT_62 = zig_wrap_add_u(((zu64)(zT_60)), ((zu64)(zT_61)), 32u);
    zT_63 = zig_overflow_flag_add_u(((zu64)(zT_60)), ((zu64)(zT_61)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    total = zT_62;
    zT_66 = total;
    zT_67 = union_align;
    zT_68 = zF_D2BAC673_alignUp(zT_66, zT_67);
    eu_size = zT_68;
    eu_align = union_align;
    zT_69 = 2;
    eu_state = zT_69;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_4028D896_Arr_unsigned_char_2 zT_41;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    unsigned char zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_79FAE712_u64 zT_68;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_70;
    unsigned char zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    zT_79FAE712_u64 zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    zT_79FAE712_u64 zT_79;
    zT_BAEE192E_Opt_10 zT_81;
    unsigned char zT_82;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    zT_4028D896_Arr_unsigned_char_2 zT_90;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_96;
    unsigned char* zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    unsigned char zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    unsigned int zT_117;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_E834303C_ArrayPayload zT_119;
    zT_E834303C_ArrayPayload zT_120;
    zT_D155D06D_Type* zT_122;
    zT_D155D06D_Type zT_123;
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned char zT_132;
    unsigned char zT_133;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    unsigned short zT_141;
    unsigned int zT_142;
    unsigned char zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_D155D06D_Type zT_146;
    zT_D155D06D_Type zT_147;
    zT_33EF6BFB_TypeKind zT_148;
    unsigned char zT_149;
    unsigned char zT_150;
    unsigned short zT_151;
    unsigned int zT_152;
    unsigned short zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_4028D896_Arr_unsigned_char_2 zT_168;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    int zT_174;
    unsigned char* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned char zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_189;
    unsigned char* zT_190;
    unsigned int zT_191;
    unsigned char zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    zT_A4CE86B7_U64ToU32Map* zT_194;
    zT_79FAE712_u64 zT_195;
    unsigned int zT_196;
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_161, (unsigned int)sizeof zT_161);
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = (unsigned char*)zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)o0b) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    zT_21 = 19;
    zT_22 = (unsigned int)o0l;
    zT_23 = zig_wrap_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    o0s = zT_23;
    zT_30 = 19;
    zT_31 = (unsigned char*)((unsigned char*)o0b) + o0s;
    zT_32 = zT_30 - o0s;
    zT_33 = o0s <= zT_30;
    if (!(zT_33)) { pal_trap(); }
    zT_34.ptr = (unsigned char*)zT_31;
    zT_34.len = zT_32;
    zT_27 = zT_34;
    zF_48AC7B3A_markerWrite(zT_27);
    zT_36 = "L";
    zT_38 = 1;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    o0m2 = zT_37;
    zT_39 = o0m2;
    zF_48AC7B3A_markerWrite(zT_39);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_41[_i];
        _i++;
    }
}
    zT_43 = length;
    zT_47 = 0;
    zT_48 = (unsigned char*)((unsigned char*)o0b2) + zT_47;
    zT_49 = (unsigned int)(20) - zT_47;
    zT_50.ptr = (unsigned char*)zT_48;
    zT_50.len = zT_49;
    zT_44 = zT_50;
    zT_51 = zF_A7504564_itoa(zT_43, zT_44);
    o0l2 = zT_51;
    zT_53 = 19;
    zT_54 = (unsigned int)o0l2;
    zT_55 = zig_wrap_sub_u(((zu64)(zT_53)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_sub_u(((zu64)(zT_53)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    o0s2 = zT_55;
    zT_62 = 19;
    zT_63 = (unsigned char*)((unsigned char*)o0b2) + o0s2;
    zT_64 = zT_62 - o0s2;
    zT_65 = o0s2 <= zT_62;
    if (!(zT_65)) { pal_trap(); }
    zT_66.ptr = (unsigned char*)zT_63;
    zT_66.len = zT_64;
    zT_59 = zT_66;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_68 = (zT_79FAE712_u64)elem;
    zT_69 = 32;
    zT_72 = zT_69 < (unsigned int)(64);
    if (!(zT_72)) { pal_trap(); }
    zT_70 = zig_wrap_shl_u(((zu64)(zT_68)), ((zu64)(zT_69)), 64u);
    zT_73 = zig_overflow_flag_shl_u(((zu64)(zT_68)), ((zu64)(zT_69)), 64u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    zT_77 = zT_70 | (zT_79FAE712_u64)((zT_79FAE712_u64)length);
    key = zT_77;
    zT_78 = &self->array_cache;
    zT_79 = key;
    zT_81 = zF_A05A7BE1_u64ToU32MapGet(zT_78, zT_79);
    zT_82 = zT_81.has_value;
    if (zT_82) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_81.has_value)) { pal_trap(); }
    existing = zT_81.value;
    zT_85 = "O1H";
    zT_87 = 3;
    zT_86.ptr = (unsigned char*)zT_85;
    zT_86.len = zT_87;
    o1m = zT_86;
    zT_88 = o1m;
    zF_48AC7B3A_markerWrite(zT_88);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_90[_i];
        _i++;
    }
}
    zT_92 = existing;
    zT_96 = 0;
    zT_97 = (unsigned char*)((unsigned char*)o1b) + zT_96;
    zT_98 = (unsigned int)(20) - zT_96;
    zT_99.ptr = (unsigned char*)zT_97;
    zT_99.len = zT_98;
    zT_93 = zT_99;
    zT_100 = zF_A7504564_itoa(zT_92, zT_93);
    o1l = zT_100;
    zT_102 = 19;
    zT_103 = (unsigned int)o1l;
    zT_104 = zig_wrap_sub_u(((zu64)(zT_102)), ((zu64)(zT_103)), 32u);
    zT_105 = zig_overflow_flag_sub_u(((zu64)(zT_102)), ((zu64)(zT_103)), 32u);
    zT_107 = zT_105 == (unsigned int)(0);
    if (!(zT_107)) { pal_trap(); }
    o1s = zT_104;
    zT_111 = 19;
    zT_112 = (unsigned char*)((unsigned char*)o1b) + o1s;
    zT_113 = zT_111 - o1s;
    zT_114 = o1s <= zT_111;
    if (!(zT_114)) { pal_trap(); }
    zT_115.ptr = (unsigned char*)zT_112;
    zT_115.len = zT_113;
    zT_108 = zT_115;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_116 = self;
    zT_117 = existing;
    zF_C173376D_arrayCompleteIfRead(zT_116, zT_117);
    return existing;
    z_bb_2:
    zT_118 = self;
    zT_120.elem = elem;
    zT_120.length = length;
    zT_119 = zT_120;
    zF_4D5CD212_arrayAppend(zT_118, zT_119);
    zT_122 = self->types_items;
    zT_123 = zT_122[elem];
    elem_ty = zT_123;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    arr_size = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    arr_align = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned char)zT_131;
    arr_state = zT_132;
    zT_133 = elem_ty.state;
    if ((unsigned char)(zT_133 == (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_136 = elem_ty.size;
    zT_137 = zig_wrap_mul_u(((zu64)(zT_136)), ((zu64)(length)), 32u);
    zT_138 = zig_overflow_flag_mul_u(((zu64)(zT_136)), ((zu64)(length)), 32u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    arr_size = zT_137;
    zT_141 = elem_ty.alignment;
    zT_142 = (unsigned int)zT_141;
    arr_align = zT_142;
    zT_143 = 2;
    arr_state = zT_143;
    goto z_bb_4;
    z_bb_4:
    zT_145 = self;
    zT_148 = zT_33EF6BFB_TypeKind_array_type;
    zT_147.kind = zT_148;
    zT_147.state = arr_state;
    zT_149 = 0;
    zT_147.flags = zT_149;
    zT_150 = 0;
    zT_147.iw = zT_150;
    zT_147.size = arr_size;
    zT_151 = (unsigned short)zig_cast_checked_u((zu64)arr_align, 32u, 0u, 16u);
    zT_147.alignment = zT_151;
    zT_152 = 0;
    zT_147.name_id = zT_152;
    zT_153 = 0;
    zT_147.module_id = zT_153;
    zT_154 = self->array_len;
    zT_155 = 1;
    zT_156 = zig_wrap_sub_u(((zu64)(zT_154)), ((zu64)(zT_155)), 32u);
    zT_157 = zig_overflow_flag_sub_u(((zu64)(zT_154)), ((zu64)(zT_155)), 32u);
    zT_159 = zT_157 == (unsigned int)(0);
    if (!(zT_159)) { pal_trap(); }
    zT_160 = (unsigned int)zT_156;
    zT_147.payload_idx = zT_160;
    zT_146 = zT_147;
    zT_161 = zF_D4993F02_typeRegistryAppend(zT_145, zT_146);
    tid = zT_161;
    zT_163 = "O2N";
    zT_165 = 3;
    zT_164.ptr = (unsigned char*)zT_163;
    zT_164.len = zT_165;
    o2m = zT_164;
    zT_166 = o2m;
    zF_48AC7B3A_markerWrite(zT_166);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_168[_i];
        _i++;
    }
}
    zT_170 = tid;
    zT_174 = 0;
    zT_175 = (unsigned char*)((unsigned char*)o2b) + zT_174;
    zT_176 = (unsigned int)(20) - zT_174;
    zT_177.ptr = (unsigned char*)zT_175;
    zT_177.len = zT_176;
    zT_171 = zT_177;
    zT_178 = zF_A7504564_itoa(zT_170, zT_171);
    o2l = zT_178;
    zT_180 = 19;
    zT_181 = (unsigned int)o2l;
    zT_182 = zig_wrap_sub_u(((zu64)(zT_180)), ((zu64)(zT_181)), 32u);
    zT_183 = zig_overflow_flag_sub_u(((zu64)(zT_180)), ((zu64)(zT_181)), 32u);
    zT_185 = zT_183 == (unsigned int)(0);
    if (!(zT_185)) { pal_trap(); }
    o2s = zT_182;
    zT_189 = 19;
    zT_190 = (unsigned char*)((unsigned char*)o2b) + o2s;
    zT_191 = zT_189 - o2s;
    zT_192 = o2s <= zT_189;
    if (!(zT_192)) { pal_trap(); }
    zT_193.ptr = (unsigned char*)zT_190;
    zT_193.len = zT_191;
    zT_186 = zT_193;
    zF_48AC7B3A_markerWrite(zT_186);
    zT_194 = &self->array_cache;
    zT_195 = key;
    zT_196 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_194, zT_195, zT_196);
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned short zT_15;
    unsigned int zT_16;
    unsigned short zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9.iw = zT_13;
    zT_14 = 0;
    zT_9.size = zT_14;
    zT_15 = 1;
    zT_9.alignment = zT_15;
    zT_16 = 0;
    zT_9.name_id = zT_16;
    zT_17 = 0;
    zT_9.module_id = zT_17;
    zT_18 = self->tup_len;
    zT_19 = 1;
    zT_20 = zig_wrap_sub_u(((zu64)(zT_18)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_sub_u(((zu64)(zT_18)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    zT_24 = (unsigned int)zT_20;
    zT_9.payload_idx = zT_24;
    zT_8 = zT_9;
    zT_25 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_25;
    return tid;
}

/* typeRegistryTupleElem */
zT_BAEE192E_Opt_10 zF_ACB4F3DB_typeRegistryTupleEl(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ordinal) {
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_BAEE192E_Opt_10 zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_19;
    zT_666DC2E1_TuplePayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_666DC2E1_TuplePayload zT_24;
    unsigned short zT_25;
    zT_BAEE192E_Opt_10 zT_28;
    unsigned int* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_BAEE192E_Opt_10 zT_37;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zT_D155D06D_Type ty;
    zT_666DC2E1_TuplePayload tup;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->tup_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_6:
    zT_21 = self->tup_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    tup = zT_24;
    zT_25 = tup.elems_count;
    if ((unsigned char)(ordinal >= (unsigned int)((unsigned int)zT_25))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28.has_value = 0;
    return zT_28;
    z_bb_8:
    zT_29 = self->xt_items;
    zT_30 = tup.elems_start;
    zT_31 = zig_wrap_add_u(((zu64)(zT_30)), ((zu64)(ordinal)), 32u);
    zT_32 = zig_overflow_flag_add_u(((zu64)(zT_30)), ((zu64)(ordinal)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = (unsigned int)zT_31;
    zT_36 = zT_29[zT_35];
    zT_37.has_value = 1;
    zT_37.value = zT_36;
    return zT_37;
}

/* typeRegistryTupleOrdinalFromNameId */
zT_BAEE192E_Opt_10 zF_D3BC911B_typeRegistryTupleOr(zT_338B7C76_TypeRegistry* self, unsigned int name_id) {
    zT_D3EB6303_StringInterner* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_9;
    zT_BAEE192E_Opt_10 zT_12;
    unsigned int zT_14;
    unsigned char* zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned int zT_22;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned int zT_27;
    unsigned char* zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    unsigned char zT_34;
    unsigned char zT_37;
    zT_BAEE192E_Opt_10 zT_40;
    unsigned int zT_43;
    zT_BAEE192E_Opt_10 zT_44;
    unsigned char zT_46;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    zT_BAEE192E_Opt_10 zT_67;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int nlen;
    unsigned int start;
    unsigned int v;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_3 = self->interner;
    zT_4 = name_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_3, zT_4);
    text = zT_6;
    zT_9 = text.len;
    nlen = zT_9;
    if ((unsigned char)(nlen == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_2:
    zT_14 = 0;
    start = zT_14;
    zT_15 = text.ptr;
    zT_16 = 0;
    zT_17 = text.len;
    zT_18 = (unsigned int)zT_16 < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_15[zT_16];
    if ((unsigned char)(zT_19 == (unsigned char)(95))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = 1;
    start = zT_22;
    if ((unsigned char)(nlen == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_27 = 0;
    v = zT_27;
    i = start;
    goto z_bb_7;
    z_bb_5:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    if ((unsigned char)(i < nlen)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = text.ptr;
    zT_32 = text.len;
    zT_33 = i < zT_32;
    if (!(zT_33)) { pal_trap(); }
    zT_34 = zT_31[i];
    c = zT_34;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_12; else goto z_bb_11;
    z_bb_9:
    zT_67.has_value = 1;
    zT_67.value = v;
    return zT_67;
    z_bb_10:
    zT_61 = 1;
    zT_62 = (unsigned int)zT_61;
    zT_63 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    i = zT_63;
    goto z_bb_7;
    z_bb_11:
    zT_37 = c > (unsigned char)(57);
    goto z_bb_13;
    z_bb_12:
    zT_37 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_37) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_15:
    if ((unsigned char)(v > (unsigned int)(99999999))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_43 = 1000000000;
    zT_44.has_value = 1;
    zT_44.value = zT_43;
    return zT_44;
    z_bb_17:
    zT_46 = 48;
    zT_47 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_46)), 8u);
    zT_48 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_46)), 8u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_51 = (unsigned int)zT_47;
    d = zT_51;
    zT_52 = 10;
    zT_53 = zig_wrap_mul_u(((zu64)(v)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_mul_u(((zu64)(v)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    zT_57 = zig_wrap_add_u(((zu64)(zT_53)), ((zu64)(d)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_53)), ((zu64)(d)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    v = zT_57;
    goto z_bb_10;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type, unsigned char call_conv) {
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_4028D896_Arr_unsigned_char_2 zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned char zT_42;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type* zT_52;
    zT_D155D06D_Type zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    unsigned char zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_0317B1D5_FnPayload* zT_61;
    zT_D155D06D_Type* zT_62;
    zT_D155D06D_Type zT_63;
    unsigned int zT_64;
    zT_0317B1D5_FnPayload zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_0317B1D5_FnPayload* zT_69;
    zT_D155D06D_Type* zT_70;
    zT_D155D06D_Type zT_71;
    unsigned int zT_72;
    zT_0317B1D5_FnPayload zT_73;
    unsigned char zT_74;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_D155D06D_Type* zT_85;
    zT_D155D06D_Type zT_86;
    unsigned char zT_87;
    zT_D155D06D_Type* zT_90;
    zT_D155D06D_Type* zT_91;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_0317B1D5_FnPayload zT_100;
    zT_0317B1D5_FnPayload zT_101;
    unsigned char zT_102;
    zT_338B7C76_TypeRegistry* zT_104;
    zT_D155D06D_Type zT_105;
    zT_D155D06D_Type zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    unsigned char zT_108;
    unsigned char zT_109;
    unsigned char zT_110;
    unsigned int zT_111;
    unsigned short zT_112;
    unsigned short zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_D155D06D_Type* zT_124;
    unsigned int zT_125;
    zT_D155D06D_Type zT_126;
    unsigned char zT_127;
    zT_D155D06D_Type* zT_130;
    zT_D155D06D_Type* zT_132;
    zT_4028D896_Arr_unsigned_char_2 zT_134;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned char zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_155;
    unsigned char* zT_156;
    unsigned int zT_157;
    unsigned char zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_144, (unsigned int)sizeof zT_144);
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned char conv_bit;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_10 = "P2:n";
    zT_12 = 4;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    p2m = zT_11;
    zT_13 = p2m;
    zF_48AC7B3A_markerWrite(zT_13);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_15[_i];
        _i++;
    }
}
    zT_17 = name_id;
    zT_21 = 0;
    zT_22 = (unsigned char*)((unsigned char*)p2nb) + zT_21;
    zT_23 = (unsigned int)(20) - zT_21;
    zT_24.ptr = (unsigned char*)zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zT_25 = zF_A7504564_itoa(zT_17, zT_18);
    p2nl = zT_25;
    zT_27 = 19;
    zT_28 = (unsigned int)p2nl;
    zT_29 = zig_wrap_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    p2ns = zT_29;
    zT_36 = 19;
    zT_37 = (unsigned char*)((unsigned char*)p2nb) + p2ns;
    zT_38 = zT_36 - p2ns;
    zT_39 = p2ns <= zT_36;
    if (!(zT_39)) { pal_trap(); }
    zT_40.ptr = (unsigned char*)zT_37;
    zT_40.len = zT_38;
    zT_33 = zT_40;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_42 = 0;
    conv_bit = zT_42;
    if ((unsigned char)(call_conv == (unsigned char)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_45 = 2;
    conv_bit = zT_45;
    goto z_bb_2;
    z_bb_2:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    i = zT_48;
    goto z_bb_3;
    z_bb_3:
    zT_49 = self->types_len;
    if ((unsigned char)(i < zT_49)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_52 = self->types_items;
    zT_53 = zT_52[i];
    it = zT_53;
    zT_54 = it.kind;
    if ((unsigned char)(zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_99 = self;
    zT_101.name_id = name_id;
    zT_101.module_id = module_id;
    zT_101.is_extern = is_extern;
    zT_101.params_start = params_start;
    zT_101.params_count = params_count;
    zT_101.return_type = return_type;
    zT_102 = is_variadic | conv_bit;
    zT_101.flags_packed = zT_102;
    zT_100 = zT_101;
    zF_07DDC351_fnAppend(zT_99, zT_100);
    zT_104 = self;
    zT_107 = zT_33EF6BFB_TypeKind_fn_type;
    zT_106.kind = zT_107;
    zT_108 = 2;
    zT_106.state = zT_108;
    zT_109 = 0;
    zT_106.flags = zT_109;
    zT_110 = 0;
    zT_106.iw = zT_110;
    zT_111 = 4;
    zT_106.size = zT_111;
    zT_112 = 4;
    zT_106.alignment = zT_112;
    zT_106.name_id = name_id;
    zT_113 = 0;
    zT_106.module_id = zT_113;
    zT_114 = self->fn_len;
    zT_115 = 1;
    zT_116 = zig_wrap_sub_u(((zu64)(zT_114)), ((zu64)(zT_115)), 32u);
    zT_117 = zig_overflow_flag_sub_u(((zu64)(zT_114)), ((zu64)(zT_115)), 32u);
    zT_119 = zT_117 == (unsigned int)(0);
    if (!(zT_119)) { pal_trap(); }
    zT_120 = (unsigned int)zT_116;
    zT_106.payload_idx = zT_120;
    zT_105 = zT_106;
    zT_121 = zF_D4993F02_typeRegistryAppend(zT_104, zT_105);
    tid = zT_121;
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_6:
    zT_93 = 1;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    i = zT_95;
    goto z_bb_3;
    z_bb_7:
    zT_58 = it.name_id;
    zT_57 = zT_58 == name_id;
    goto z_bb_9;
    z_bb_8:
    zT_57 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_57) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_61 = self->fn_items;
    zT_62 = self->types_items;
    zT_63 = zT_62[i];
    zT_64 = zT_63.payload_idx;
    zT_65 = zT_61[zT_64];
    zT_66 = zT_65.module_id;
    zT_60 = zT_66 == module_id;
    goto z_bb_12;
    z_bb_11:
    zT_60 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_60) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_69 = self->fn_items;
    zT_70 = self->types_items;
    zT_71 = zT_70[i];
    zT_72 = zT_71.payload_idx;
    zT_73 = zT_69[zT_72];
    zT_74 = zT_73.flags_packed;
    zT_68 = (unsigned char)(zT_74 & (unsigned int)(2)) == conv_bit;
    goto z_bb_15;
    z_bb_14:
    zT_68 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_68) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_79 = "H";
    zT_81 = 1;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    p2hm = zT_80;
    zT_82 = p2hm;
    zF_48AC7B3A_markerWrite(zT_82);
    if ((unsigned char)(conv_bit != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_6;
    z_bb_18:
    zT_85 = self->types_items;
    zT_86 = zT_85[i];
    zT_87 = zT_86.flags;
    zT_90 = self->types_items;
    zT_91 = zT_90 + i;
    zT_91->flags = (unsigned char)(zT_87 | (unsigned char)(1));
    goto z_bb_19;
    z_bb_19:
    return (unsigned int)((unsigned int)i);
    z_bb_20:
    zT_124 = self->types_items;
    zT_125 = (unsigned int)tid;
    zT_126 = zT_124[zT_125];
    zT_127 = zT_126.flags;
    zT_130 = self->types_items;
    zT_132 = zT_130 + (unsigned int)((unsigned int)tid);
    zT_132->flags = (unsigned char)(zT_127 | (unsigned char)(1));
    goto z_bb_21;
    z_bb_21:
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_134[_i];
        _i++;
    }
}
    zT_136 = tid;
    zT_140 = 0;
    zT_141 = (unsigned char*)((unsigned char*)p2sb) + zT_140;
    zT_142 = (unsigned int)(20) - zT_140;
    zT_143.ptr = (unsigned char*)zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zT_144 = zF_A7504564_itoa(zT_136, zT_137);
    p2sl = zT_144;
    zT_146 = 19;
    zT_147 = (unsigned int)p2sl;
    zT_148 = zig_wrap_sub_u(((zu64)(zT_146)), ((zu64)(zT_147)), 32u);
    zT_149 = zig_overflow_flag_sub_u(((zu64)(zT_146)), ((zu64)(zT_147)), 32u);
    zT_151 = zT_149 == (unsigned int)(0);
    if (!(zT_151)) { pal_trap(); }
    p2ss = zT_148;
    zT_155 = 19;
    zT_156 = (unsigned char*)((unsigned char*)p2sb) + p2ss;
    zT_157 = zT_155 - p2ss;
    zT_158 = p2ss <= zT_155;
    if (!(zT_158)) { pal_trap(); }
    zT_159.ptr = (unsigned char*)zT_156;
    zT_159.len = zT_157;
    zT_152 = zT_159;
    zF_48AC7B3A_markerWrite(zT_152);
    zT_161 = "\n";
    zT_163 = 1;
    zT_162.ptr = (unsigned char*)zT_161;
    zT_162.len = zT_163;
    p2nl2 = zT_162;
    zT_164 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_164);
    return tid;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_8 = self->types_items;
    zT_10 = zT_8 + (unsigned int)((unsigned int)tid);
    zT_10->flags = (unsigned char)(zT_5 | (unsigned char)(1));
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_21;
    int zT_22;
    unsigned short zT_23;
    unsigned short zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_A4CE86B7_U64ToU32Map* zT_28;
    zT_79FAE712_u64 zT_29;
    zT_BAEE192E_Opt_10 zT_31;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_0B73C507_ErrorSetPayload zT_35;
    zT_0B73C507_ErrorSetPayload zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D155D06D_Type zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    unsigned int zT_47;
    unsigned short zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_A4CE86B7_U64ToU32Map* zT_57;
    zT_79FAE712_u64 zT_58;
    unsigned int zT_59;
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ki < tags_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_11 = (unsigned int)ki;
    zT_12 = zig_wrap_add_u(((zu64)(tags_start)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(tags_start)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_16 = (unsigned int)zT_12;
    zT_17 = zT_10[zT_16];
    tag = zT_17;
    zT_21 = (zT_79FAE712_u64)(key ^ (zT_79FAE712_u64)((zT_79FAE712_u64)tag)) * (zT_79FAE712_u64)(Z98_U64_C(1099511628211));
    key = zT_21;
    goto z_bb_4;
    z_bb_3:
    zT_28 = &self->es_cache;
    zT_29 = key;
    zT_31 = zF_A05A7BE1_u64ToU32MapGet(zT_28, zT_29);
    zT_32 = zT_31.has_value;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_22 = 1;
    zT_23 = (unsigned short)zT_22;
    zT_24 = zig_wrap_add_u(((zu64)(ki)), ((zu64)(zT_23)), 16u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(ki)), ((zu64)(zT_23)), 16u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    ki = zT_24;
    goto z_bb_1;
    z_bb_5:
    if (!(zT_31.has_value)) { pal_trap(); }
    existing = zT_31.value;
    return existing;
    z_bb_6:
    zT_34 = self;
    zT_36.tags_start = tags_start;
    zT_36.tags_count = tags_count;
    zT_35 = zT_36;
    zF_B86143DD_esAppend(zT_34, zT_35);
    zT_38 = self;
    zT_41 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_40.kind = zT_41;
    zT_42 = 2;
    zT_40.state = zT_42;
    zT_43 = 0;
    zT_40.flags = zT_43;
    zT_44 = 0;
    zT_40.iw = zT_44;
    zT_45 = 4;
    zT_40.size = zT_45;
    zT_46 = 4;
    zT_40.alignment = zT_46;
    zT_47 = 0;
    zT_40.name_id = zT_47;
    zT_48 = 0;
    zT_40.module_id = zT_48;
    zT_49 = self->es_len;
    zT_50 = 1;
    zT_51 = zig_wrap_sub_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_sub_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    zT_55 = (unsigned int)zT_51;
    zT_40.payload_idx = zT_55;
    zT_39 = zT_40;
    zT_56 = zF_D4993F02_typeRegistryAppend(zT_38, zT_39);
    tid = zT_56;
    zT_57 = &self->es_cache;
    zT_58 = key;
    zT_59 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_57, zT_58, zT_59);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    unsigned int zT_35;
    int zT_39;
    unsigned int zT_40;
    unsigned int* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    if ((unsigned char)(es_type_id >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(4294967295u);
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    zT_31 = zig_wrap_add_u(((zu64)(tags_start)), ((zu64)(tags_count)), 32u);
    zT_32 = zig_overflow_flag_add_u(((zu64)(tags_start)), ((zu64)(tags_count)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = reg->xn_len;
    if ((unsigned char)(zT_31 > zT_35)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(4294967295u);
    z_bb_8:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(i < tags_count)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = reg->xn_items;
    zT_43 = zig_wrap_add_u(((zu64)(tags_start)), ((zu64)(i)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(tags_start)), ((zu64)(i)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = zT_42[zT_43];
    if ((unsigned char)(zT_47 == name_id)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned int)(4294967295u);
    z_bb_12:
    zT_50 = 1;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    i = zT_52;
    goto z_bb_9;
    z_bb_13:
    return (unsigned int)((unsigned int)i);
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_13;
    unsigned short zT_14;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned short zT_30;
    unsigned int zT_31;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    unsigned int zT_42;
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    zT_10 = it.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_25 = zT_33EF6BFB_TypeKind_module_type;
    zT_24.kind = zT_25;
    zT_26 = 0;
    zT_24.state = zT_26;
    zT_27 = 0;
    zT_24.flags = zT_27;
    zT_28 = 0;
    zT_24.iw = zT_28;
    zT_29 = 0;
    zT_24.size = zT_29;
    zT_30 = 0;
    zT_24.alignment = zT_30;
    zT_31 = 0;
    zT_24.name_id = zT_31;
    zT_32 = (unsigned short)zig_cast_checked_u((zu64)module_id, 32u, 0u, 16u);
    zT_24.module_id = zT_32;
    zT_33 = 0;
    zT_24.payload_idx = zT_33;
    t = zT_24;
    zT_35 = "MC";
    zT_37 = 2;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    mc = zT_36;
    zT_38 = mc;
    zF_48AC7B3A_markerWrite(zT_38);
    zT_40 = self;
    zT_41 = t;
    zT_42 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    mcid = zT_42;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    i = zT_19;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_13 = zT_14 == module_id;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)((unsigned int)i);
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    (void)zF_4F84B621_registerPrimitive(zT_1, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel), (unsigned int)(0), (unsigned int)(0));
    zT_9 = self;
    (void)zF_4F84B621_registerPrimitive(zT_9, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type), (unsigned int)(0), (unsigned int)(0));
    zT_17 = self;
    (void)zF_4F84B621_registerPrimitive(zT_17, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type), (unsigned int)(1), (unsigned int)(1));
    zT_25 = self;
    (void)zF_4F84B621_registerPrimitive(zT_25, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type), (unsigned int)(0), (unsigned int)(0));
    zT_33 = self;
    (void)zF_4F84B621_registerPrimitive(zT_33, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type), (unsigned int)(1), (unsigned int)(1));
    zT_41 = self;
    (void)zF_4F84B621_registerPrimitive(zT_41, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type), (unsigned int)(2), (unsigned int)(2));
    zT_49 = self;
    (void)zF_4F84B621_registerPrimitive(zT_49, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type), (unsigned int)(4), (unsigned int)(4));
    zT_57 = self;
    (void)zF_4F84B621_registerPrimitive(zT_57, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type), (unsigned int)(8), (unsigned int)(8));
    zT_65 = self;
    (void)zF_4F84B621_registerPrimitive(zT_65, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type), (unsigned int)(1), (unsigned int)(1));
    zT_73 = self;
    (void)zF_4F84B621_registerPrimitive(zT_73, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type), (unsigned int)(2), (unsigned int)(2));
    zT_81 = self;
    (void)zF_4F84B621_registerPrimitive(zT_81, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type), (unsigned int)(4), (unsigned int)(4));
    zT_89 = self;
    (void)zF_4F84B621_registerPrimitive(zT_89, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type), (unsigned int)(8), (unsigned int)(8));
    zT_97 = self;
    (void)zF_4F84B621_registerPrimitive(zT_97, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type), (unsigned int)(4), (unsigned int)(4));
    zT_105 = self;
    (void)zF_4F84B621_registerPrimitive(zT_105, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type), (unsigned int)(4), (unsigned int)(4));
    zT_113 = self;
    (void)zF_4F84B621_registerPrimitive(zT_113, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type), (unsigned int)(1), (unsigned int)(1));
    zT_121 = self;
    (void)zF_4F84B621_registerPrimitive(zT_121, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type), (unsigned int)(4), (unsigned int)(4));
    zT_129 = self;
    (void)zF_4F84B621_registerPrimitive(zT_129, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type), (unsigned int)(8), (unsigned int)(8));
    zT_137 = self;
    (void)zF_4F84B621_registerPrimitive(zT_137, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type), (unsigned int)(0), (unsigned int)(0));
    zT_145 = self;
    (void)zF_4F84B621_registerPrimitive(zT_145, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type), (unsigned int)(0), (unsigned int)(0));
    zT_153 = self;
    (void)zF_4F84B621_registerPrimitive(zT_153, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type), (unsigned int)(0), (unsigned int)(0));
    zT_161 = self;
    (void)zF_4F84B621_registerPrimitive(zT_161, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type), (unsigned int)(0), (unsigned int)(0));
    zT_169 = self;
    (void)zF_4F84B621_registerPrimitive(zT_169, (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_va_list_type), (unsigned int)(4), (unsigned int)(4));
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = (unsigned char*)zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    zT_181 = self;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, (unsigned int)(1), zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    zT_189 = self;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, (unsigned int)(2), zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = (unsigned char*)zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, (unsigned int)(4), zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = (unsigned char*)zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, (unsigned int)(5), zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = (unsigned char*)zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, (unsigned int)(6), zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = (unsigned char*)zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, (unsigned int)(7), zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = (unsigned char*)zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, (unsigned int)(8), zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = (unsigned char*)zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, (unsigned int)(9), zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = (unsigned char*)zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, (unsigned int)(10), zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = (unsigned char*)zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, (unsigned int)(11), zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = (unsigned char*)zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    zT_261 = self;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, (unsigned int)(12), zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = (unsigned char*)zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    zT_269 = self;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, (unsigned int)(13), zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = (unsigned char*)zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, (unsigned int)(14), zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = (unsigned char*)zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, (unsigned int)(15), zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = (unsigned char*)zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, (unsigned int)(16), zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = (unsigned char*)zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    zT_301 = self;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, (unsigned int)(17), zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = (unsigned char*)zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, (unsigned int)(18), zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = (unsigned char*)zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    zT_317 = self;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, (unsigned int)(20), zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = (unsigned char*)zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, (unsigned int)(21), zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_16;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_4 = self->interner;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, (zT_79FAE712_u64)((zT_79FAE712_u64)nid), zT_16);
    return;
}

/* parseArbIntWidth */
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u name, unsigned char* is_unsigned) {
    unsigned int zT_4;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    unsigned char zT_19;
    unsigned char zT_21;
    unsigned int zT_27;
    unsigned int zT_29;
    unsigned char* zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    unsigned char zT_35;
    unsigned char zT_38;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned char zT_69;
    unsigned char zT_75;
    unsigned int nlen;
    unsigned char prefix;
    unsigned char is_u;
    unsigned char is_i;
    unsigned int w;
    unsigned int i;
    unsigned char c;
    unsigned int d;
    zT_4 = name.len;
    nlen = zT_4;
    if ((unsigned char)(nlen < (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_9 = name.ptr;
    zT_10 = 0;
    zT_11 = name.len;
    zT_12 = (unsigned int)zT_10 < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_9[zT_10];
    prefix = zT_13;
    zT_16 = prefix == (unsigned char)(117);
    is_u = zT_16;
    zT_19 = prefix == (unsigned char)(105);
    is_i = zT_19;
    if ((unsigned char)(!is_u)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = !is_i;
    goto z_bb_5;
    z_bb_4:
    zT_21 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_21) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    if (is_u) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    *is_unsigned = (unsigned char)(1);
    goto z_bb_9;
    z_bb_9:
    zT_27 = 0;
    w = zT_27;
    zT_29 = 1;
    i = zT_29;
    goto z_bb_11;
    z_bb_10:
    *is_unsigned = (unsigned char)(0);
    goto z_bb_9;
    z_bb_11:
    if ((unsigned char)(i < nlen)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_32 = name.ptr;
    zT_33 = name.len;
    zT_34 = i < zT_33;
    if (!(zT_34)) { pal_trap(); }
    zT_35 = zT_32[i];
    c = zT_35;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (is_u) goto z_bb_22; else goto z_bb_24;
    z_bb_14:
    zT_61 = 1;
    zT_62 = (unsigned int)zT_61;
    zT_63 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    i = zT_63;
    goto z_bb_11;
    z_bb_15:
    zT_38 = c > (unsigned char)(57);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned int)(0);
    z_bb_19:
    zT_43 = 48;
    zT_44 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_43)), 8u);
    zT_45 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_43)), 8u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = (unsigned int)zT_44;
    d = zT_48;
    zT_49 = 10;
    zT_50 = zig_wrap_mul_u(((zu64)(w)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_mul_u(((zu64)(w)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = zig_wrap_add_u(((zu64)(zT_50)), ((zu64)(d)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(zT_50)), ((zu64)(d)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    w = zT_54;
    if ((unsigned char)(w > (unsigned int)(64))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    goto z_bb_14;
    z_bb_22:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_26; else goto z_bb_25;
    z_bb_23:
    return w;
    z_bb_24:
    if ((unsigned char)(w < (unsigned int)(1))) goto z_bb_31; else goto z_bb_30;
    z_bb_25:
    zT_69 = w > (unsigned int)(64);
    goto z_bb_27;
    z_bb_26:
    zT_69 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_69) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    goto z_bb_23;
    z_bb_30:
    zT_75 = w > (unsigned int)(63);
    goto z_bb_32;
    z_bb_31:
    zT_75 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_75) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned int)(0);
    z_bb_34:
    goto z_bb_23;
}

/* typeRegistryGetOrCreateArbInt */
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned char zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_6;
    unsigned int zT_8;
    zT_D3EB6303_StringInterner* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_BAEE192E_Opt_10 zT_21;
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_D155D06D_Type zT_41;
    zT_D155D06D_Type zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    unsigned short zT_46;
    unsigned int zT_47;
    unsigned short zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    unsigned char arb_u;
    unsigned int arb_w;
    unsigned int nid;
    zT_BAEE192E_Opt_10 ck_existing;
    unsigned int ce;
    zT_33EF6BFB_TypeKind kind;
    unsigned int carrier;
    unsigned int tid;
    zT_3 = 0;
    arb_u = zT_3;
    zT_5 = name;
    zT_6 = (unsigned char*)&arb_u;
    zT_8 = zF_741B5264_parseArbIntWidth(zT_5, zT_6);
    arb_w = zT_8;
    if ((unsigned char)(arb_w == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_13 = self->interner;
    zT_14 = name;
    zT_16 = zF_50C274AF_stringInternerInter(zT_13, zT_14);
    nid = zT_16;
    zT_18 = self;
    zT_21 = zF_0EB68360_nameCacheGet(zT_18, (zT_79FAE712_u64)((zT_79FAE712_u64)nid));
    ck_existing = zT_21;
    zT_22 = ck_existing.has_value;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(ck_existing.has_value)) { pal_trap(); }
    ce = ck_existing.value;
    return ce;
    z_bb_4:
    if (arb_u) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = zT_33EF6BFB_TypeKind_arb_uint_type;
    goto z_bb_7;
    z_bb_6:
    zT_25 = zT_33EF6BFB_TypeKind_arb_int_type;
    goto z_bb_7;
    z_bb_7:
    kind = zT_25;
    zT_29 = 1;
    carrier = zT_29;
    if ((unsigned char)(arb_w > (unsigned int)(8))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = 2;
    carrier = zT_32;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(arb_w > (unsigned int)(16))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = 4;
    carrier = zT_35;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(arb_w > (unsigned int)(32))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_38 = 8;
    carrier = zT_38;
    goto z_bb_13;
    z_bb_13:
    zT_40 = self;
    zT_42.kind = kind;
    zT_43 = 2;
    zT_42.state = zT_43;
    zT_44 = 0;
    zT_42.flags = zT_44;
    zT_45 = (unsigned char)zig_cast_checked_u((zu64)arb_w, 32u, 0u, 8u);
    zT_42.iw = zT_45;
    zT_42.size = carrier;
    zT_46 = (unsigned short)zig_cast_checked_u((zu64)carrier, 32u, 0u, 16u);
    zT_42.alignment = zT_46;
    zT_47 = 0;
    zT_42.name_id = zT_47;
    zT_48 = 0;
    zT_42.module_id = zT_48;
    zT_49 = 0;
    zT_42.payload_idx = zT_49;
    zT_41 = zT_42;
    zT_50 = zF_D4993F02_typeRegistryAppend(zT_40, zT_41);
    tid = zT_50;
    zT_51 = self;
    zT_52 = tid;
    zT_53 = name;
    zF_BA76727A_registerPrimitiveNa(zT_51, zT_52, zT_53);
    return tid;
}

/* typeRegistryEnumBackingType */
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(10);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(10);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(10);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.backing_type;
    return zT_24;
}

/* typeRegistryEnumHasExplicitBacking */
unsigned char zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_457ECFEE_EnumPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_457ECFEE_EnumPayload zT_23;
    unsigned char zT_24;
    zT_D155D06D_Type ty;
    zT_457ECFEE_EnumPayload ep;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = self->en_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    ep = zT_23;
    zT_24 = ep.explicit_backing;
    return (unsigned char)(zT_24 != (unsigned char)(0));
}

/* typeRegistryIntWidthBits */
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned char zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_29;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_23 = ty.kind;
    zT_22 = zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = ty.iw;
    return zT_26;
    z_bb_9:
    zT_27 = ty.kind;
    zT_29 = zF_534230F8_typeWidthBitsForKin(zT_27);
    return zT_29;
}

/* typeRegistryIntIsSigned */
unsigned char zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_47;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    unsigned char zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_D155D06D_Type ty;
    z_bb_0:
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = self;
    zT_15 = self;
    zT_16 = tid;
    zT_17 = zF_014D7530_typeRegistryEnumBac(zT_15, zT_16);
    zT_14 = zT_17;
    self = zT_13;
    tid = zT_14;
    goto z_bb_0;
    z_bb_4:
    zT_19 = ty.kind;
    if ((unsigned char)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_27 = ty.kind;
    if ((unsigned char)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = ty.kind;
    zT_30 = zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_30 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_30) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_35 = ty.kind;
    zT_34 = zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_39 = ty.kind;
    zT_38 = zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_20;
    z_bb_19:
    zT_42 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_42) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_47 = ty.kind;
    if ((unsigned char)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_51 = ty.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_25;
    z_bb_24:
    zT_50 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_50) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = ty.kind;
    zT_54 = zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_28;
    z_bb_27:
    zT_54 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_54) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_31;
    z_bb_30:
    zT_58 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_58) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_63 = ty.kind;
    zT_62 = zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_34;
    z_bb_33:
    zT_62 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_62) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_67 = ty.kind;
    zT_66 = zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_37;
    z_bb_36:
    zT_66 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_66) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    return (unsigned char)(0);
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_79FAE712_u64 zT_17;
    zT_BAEE192E_Opt_10 zT_18;
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_D155D06D_Type zT_23;
    zT_D155D06D_Type zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    unsigned short zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_79FAE712_u64 zT_34;
    unsigned int zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_4028D896_Arr_unsigned_char_2 zT_69;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    int zT_75;
    unsigned char* zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    unsigned char zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    zT_4028D896_Arr_unsigned_char_2 zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_108;
    unsigned char* zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_128;
    unsigned char* zT_129;
    unsigned int zT_130;
    unsigned char zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    zT_4028D896_Arr_unsigned_char_2 zT_134;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned char zT_151;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_160;
    unsigned char* zT_161;
    unsigned int zT_162;
    unsigned char zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_144, (unsigned int)sizeof zT_144);
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_5 = (zT_79FAE712_u64)module_id;
    zT_6 = Z98_U64_C(4294967296);
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 64u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 64u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = (zT_79FAE712_u64)name_id;
    zT_12 = zig_wrap_add_u(((zu64)(zT_7)), ((zu64)(zT_11)), 64u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(zT_7)), ((zu64)(zT_11)), 64u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    key = zT_12;
    zT_16 = self;
    zT_17 = key;
    zT_18 = zF_0EB68360_nameCacheGet(zT_16, zT_17);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_18.has_value)) { pal_trap(); }
    existing = zT_18.value;
    return existing;
    z_bb_2:
    zT_22 = self;
    zT_24.kind = kind;
    zT_25 = 0;
    zT_24.state = zT_25;
    zT_26 = 0;
    zT_24.flags = zT_26;
    zT_27 = 0;
    zT_24.iw = zT_27;
    zT_28 = 0;
    zT_24.size = zT_28;
    zT_29 = 0;
    zT_24.alignment = zT_29;
    zT_24.name_id = name_id;
    zT_30 = (unsigned short)zig_cast_checked_u((zu64)module_id, 32u, 0u, 16u);
    zT_24.module_id = zT_30;
    zT_31 = 0;
    zT_24.payload_idx = zT_31;
    zT_23 = zT_24;
    zT_32 = zF_D4993F02_typeRegistryAppend(zT_22, zT_23);
    tid = zT_32;
    zT_33 = self;
    zT_34 = key;
    zT_35 = tid;
    zF_5E95558D_nameCachePut(zT_33, zT_34, zT_35);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = module_id;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)rn_m) + zT_43;
    zT_45 = (unsigned int)(20) - zT_43;
    zT_46.ptr = (unsigned char*)zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    rn_ml = zT_47;
    zT_49 = 19;
    zT_50 = (unsigned int)rn_ml;
    zT_51 = zig_wrap_sub_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_52 = zig_overflow_flag_sub_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    rn_ms = zT_51;
    zT_56 = "RN:m";
    zT_58 = 4;
    zT_57.ptr = (unsigned char*)zT_56;
    zT_57.len = zT_58;
    rnm = zT_57;
    zT_59 = rnm;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_63 = 19;
    zT_64 = (unsigned char*)((unsigned char*)rn_m) + rn_ms;
    zT_65 = zT_63 - rn_ms;
    zT_66 = rn_ms <= zT_63;
    if (!(zT_66)) { pal_trap(); }
    zT_67.ptr = (unsigned char*)zT_64;
    zT_67.len = zT_65;
    zT_60 = zT_67;
    zF_48AC7B3A_markerWrite(zT_60);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_69[_i];
        _i++;
    }
}
    zT_71 = name_id;
    zT_75 = 0;
    zT_76 = (unsigned char*)((unsigned char*)rn_n) + zT_75;
    zT_77 = (unsigned int)(20) - zT_75;
    zT_78.ptr = (unsigned char*)zT_76;
    zT_78.len = zT_77;
    zT_72 = zT_78;
    zT_79 = zF_A7504564_itoa(zT_71, zT_72);
    rn_nl = zT_79;
    zT_81 = 19;
    zT_82 = (unsigned int)rn_nl;
    zT_83 = zig_wrap_sub_u(((zu64)(zT_81)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_sub_u(((zu64)(zT_81)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    rn_ns = zT_83;
    zT_88 = "n";
    zT_90 = 1;
    zT_89.ptr = (unsigned char*)zT_88;
    zT_89.len = zT_90;
    rnn = zT_89;
    zT_91 = rnn;
    zF_48AC7B3A_markerWrite(zT_91);
    zT_95 = 19;
    zT_96 = (unsigned char*)((unsigned char*)rn_n) + rn_ns;
    zT_97 = zT_95 - rn_ns;
    zT_98 = rn_ns <= zT_95;
    if (!(zT_98)) { pal_trap(); }
    zT_99.ptr = (unsigned char*)zT_96;
    zT_99.len = zT_97;
    zT_92 = zT_99;
    zF_48AC7B3A_markerWrite(zT_92);
    zig_poison_fill((void*)&zT_101, (unsigned int)sizeof zT_101);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_101[_i];
        _i++;
    }
}
    zT_108 = 0;
    zT_109 = (unsigned char*)((unsigned char*)rn_k) + zT_108;
    zT_110 = (unsigned int)(20) - zT_108;
    zT_111.ptr = (unsigned char*)zT_109;
    zT_111.len = zT_110;
    zT_104 = zT_111;
    zT_112 = zF_A7504564_itoa((unsigned int)((unsigned int)kind), zT_104);
    rn_kl = zT_112;
    zT_114 = 19;
    zT_115 = (unsigned int)rn_kl;
    zT_116 = zig_wrap_sub_u(((zu64)(zT_114)), ((zu64)(zT_115)), 32u);
    zT_117 = zig_overflow_flag_sub_u(((zu64)(zT_114)), ((zu64)(zT_115)), 32u);
    zT_119 = zT_117 == (unsigned int)(0);
    if (!(zT_119)) { pal_trap(); }
    rn_ks = zT_116;
    zT_121 = "k";
    zT_123 = 1;
    zT_122.ptr = (unsigned char*)zT_121;
    zT_122.len = zT_123;
    rnk = zT_122;
    zT_124 = rnk;
    zF_48AC7B3A_markerWrite(zT_124);
    zT_128 = 19;
    zT_129 = (unsigned char*)((unsigned char*)rn_k) + rn_ks;
    zT_130 = zT_128 - rn_ks;
    zT_131 = rn_ks <= zT_128;
    if (!(zT_131)) { pal_trap(); }
    zT_132.ptr = (unsigned char*)zT_129;
    zT_132.len = zT_130;
    zT_125 = zT_132;
    zF_48AC7B3A_markerWrite(zT_125);
    zig_poison_fill((void*)&zT_134, (unsigned int)sizeof zT_134);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_134[_i];
        _i++;
    }
}
    zT_136 = tid;
    zT_140 = 0;
    zT_141 = (unsigned char*)((unsigned char*)rn_t) + zT_140;
    zT_142 = (unsigned int)(20) - zT_140;
    zT_143.ptr = (unsigned char*)zT_141;
    zT_143.len = zT_142;
    zT_137 = zT_143;
    zT_144 = zF_A7504564_itoa(zT_136, zT_137);
    rn_tl = zT_144;
    zT_146 = 19;
    zT_147 = (unsigned int)rn_tl;
    zT_148 = zig_wrap_sub_u(((zu64)(zT_146)), ((zu64)(zT_147)), 32u);
    zT_149 = zig_overflow_flag_sub_u(((zu64)(zT_146)), ((zu64)(zT_147)), 32u);
    zT_151 = zT_149 == (unsigned int)(0);
    if (!(zT_151)) { pal_trap(); }
    rn_ts = zT_148;
    zT_153 = "t";
    zT_155 = 1;
    zT_154.ptr = (unsigned char*)zT_153;
    zT_154.len = zT_155;
    rnt = zT_154;
    zT_156 = rnt;
    zF_48AC7B3A_markerWrite(zT_156);
    zT_160 = 19;
    zT_161 = (unsigned char*)((unsigned char*)rn_t) + rn_ts;
    zT_162 = zT_160 - rn_ts;
    zT_163 = rn_ts <= zT_160;
    if (!(zT_163)) { pal_trap(); }
    zT_164.ptr = (unsigned char*)zT_161;
    zT_164.len = zT_162;
    zT_157 = zT_164;
    zF_48AC7B3A_markerWrite(zT_157);
    zT_166 = "\n";
    zT_168 = 1;
    zT_167.ptr = (unsigned char*)zT_166;
    zT_167.len = zT_168;
    rnnl = zT_167;
    zT_169 = rnnl;
    zF_48AC7B3A_markerWrite(zT_169);
    return tid;
}

/* typeHasForwardDecl */
unsigned char zF_A42DCA4C_typeHasForwardDecl(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    unsigned int zT_10;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_18;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.name_id;
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_18 = ty.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_22 = ty.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = self;
    zT_26 = tid;
    zT_27 = zF_041ACB92_typeRegistryIsPacke(zT_25, zT_26);
    if (zT_27) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    return (unsigned char)(1);
}

/* typeNeedsFullDef */
unsigned char zF_E789C17A_typeNeedsFullDef(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    zT_10 = zT_9.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    return (unsigned char)(0);
}

/* typeRefPtrLeaf */
unsigned int zF_7AC9839C_typeRefPtrLeaf(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_4;
    unsigned int zT_8;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    unsigned char zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_112BF819_PtrPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_112BF819_PtrPayload zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int cur;
    unsigned int steps;
    zT_D155D06D_Type ty;
    cur = tid;
    zT_4 = 0;
    steps = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(steps < (unsigned int)(64))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cur) >= zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cur;
    z_bb_4:
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zig_wrap_add_u(((zu64)(steps)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(steps)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    steps = zT_28;
    goto z_bb_1;
    z_bb_5:
    return cur;
    z_bb_6:
    zT_11 = self->types_items;
    zT_12 = (unsigned int)cur;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_18 = ty.kind;
    zT_17 = zT_18 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_9;
    z_bb_8:
    zT_17 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_17) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return cur;
    z_bb_11:
    zT_21 = self->ptr_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    zT_25 = zT_24.base;
    cur = zT_25;
    goto z_bb_4;
}

/* typeRefEdgeTarget */
unsigned int zF_E447DE16_typeRefEdgeTarget(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ref, unsigned char name_pos) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    unsigned char zT_19;
    zT_33EF6BFB_TypeKind zT_20;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    zT_338B7C76_TypeRegistry* zT_29;
    unsigned int zT_30;
    unsigned char zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zT_D155D06D_Type ref_ty;
    unsigned int tgt;
    unsigned char tgt_name_pos;
    if ((unsigned char)(ref == tid)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_7 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ref) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_11 = self->types_items;
    zT_12 = (unsigned int)ref;
    zT_13 = zT_11[zT_12];
    ref_ty = zT_13;
    tgt = ref;
    tgt_name_pos = name_pos;
    zT_16 = ref_ty.kind;
    if ((unsigned char)(zT_16 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_20 = ref_ty.kind;
    zT_19 = zT_20 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_19 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_23 = self;
    zT_24 = ref;
    zT_25 = zF_7AC9839C_typeRefPtrLeaf(zT_23, zT_24);
    tgt = zT_25;
    zT_26 = 1;
    tgt_name_pos = zT_26;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(tgt == tid)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_29 = self;
    zT_30 = tgt;
    zT_31 = zF_E789C17A_typeNeedsFullDef(zT_29, zT_30);
    if ((unsigned char)(!zT_31)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(4294967295u);
    z_bb_13:
    if ((unsigned char)(tgt_name_pos != (unsigned char)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = self;
    zT_37 = tgt;
    zT_38 = zF_A42DCA4C_typeHasForwardDecl(zT_36, zT_37);
    if (zT_38) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    return tgt;
    z_bb_16:
    return (unsigned int)(4294967295u);
    z_bb_17:
    goto z_bb_15;
}

/* typeRefsSeenOut */
unsigned char zF_15186E0C_typeRefsSeenOut(unsigned int* out, unsigned int start, unsigned int off, unsigned int tgt) {
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int j;
    j = start;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(j < off)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = (unsigned int)j;
    zT_7 = out[zT_6];
    if ((unsigned char)(zT_7 == tgt)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_10 = 1;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    j = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_4;
}

/* typeRefsNote */
unsigned int zF_DAC9FA8B_typeRefsNote(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int ref, unsigned char name_pos, unsigned int* out, unsigned int* off, unsigned int start, unsigned int probe, unsigned int probe_target) {
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    unsigned int etgt;
    zT_10 = self;
    zT_11 = tid;
    zT_12 = ref;
    zT_13 = name_pos;
    zT_14 = zF_E447DE16_typeRefEdgeTarget(zT_10, zT_11, zT_12, zT_13);
    etgt = zT_14;
    if ((unsigned char)(etgt == (unsigned int)(4294967295u))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    if ((unsigned char)(probe != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(etgt == probe_target)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = out;
    zT_24 = start;
    zT_25 = *off;
    zT_26 = etgt;
    zT_28 = zF_15186E0C_typeRefsSeenOut(zT_23, zT_24, zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_30 = *off;
    zT_31 = (unsigned int)zT_30;
    out[zT_31] = etgt;
    zT_32 = *off;
    zT_33 = 1;
    zT_34 = zig_wrap_add_u(((zu64)(zT_32)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(zT_32)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    *off = zT_34;
    goto z_bb_8;
    z_bb_8:
    return (unsigned int)(0);
}

/* typeRefsWalk */
unsigned int zF_07B0FCB6_typeRefsWalk(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int* out, unsigned int start, unsigned int probe, unsigned int probe_target) {
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    unsigned char zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    unsigned int zT_23;
    unsigned short zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_406493CE_StructPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    unsigned int zT_34;
    unsigned short zT_35;
    zT_AF9231A2_UnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_AF9231A2_UnionPayload zT_40;
    unsigned int zT_41;
    unsigned short zT_42;
    unsigned int zT_44;
    zT_2DF01B61_FieldEntry* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    zT_2DF01B61_FieldEntry zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int* zT_60;
    unsigned int* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    zT_33EF6BFB_TypeKind zT_77;
    zT_54FF90FA_TaggedUnionPayload* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_54FF90FA_TaggedUnionPayload zT_84;
    unsigned int zT_86;
    unsigned short zT_87;
    zT_2DF01B61_FieldEntry* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned char zT_97;
    zT_2DF01B61_FieldEntry zT_98;
    unsigned int zT_99;
    zT_338B7C76_TypeRegistry* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int* zT_104;
    unsigned int* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_111;
    int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int* zT_125;
    unsigned int* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_133;
    zT_33EF6BFB_TypeKind zT_137;
    zT_E834303C_ArrayPayload* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_E834303C_ArrayPayload zT_144;
    unsigned int zT_145;
    zT_338B7C76_TypeRegistry* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int* zT_150;
    unsigned int* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_157;
    zT_33EF6BFB_TypeKind zT_161;
    zT_42C2D6BF_EUPayload* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_42C2D6BF_EUPayload zT_168;
    unsigned int zT_169;
    zT_338B7C76_TypeRegistry* zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int* zT_174;
    unsigned int* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_181;
    zT_33EF6BFB_TypeKind zT_185;
    zT_0B10E8E9_OptionalPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_0B10E8E9_OptionalPayload zT_192;
    unsigned int zT_193;
    zT_338B7C76_TypeRegistry* zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int* zT_198;
    unsigned int* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_205;
    zT_33EF6BFB_TypeKind zT_209;
    zT_0BB2A741_SlicePayload* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    zT_0BB2A741_SlicePayload zT_216;
    unsigned int zT_217;
    zT_338B7C76_TypeRegistry* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int* zT_222;
    unsigned int* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_229;
    zT_33EF6BFB_TypeKind zT_233;
    zT_666DC2E1_TuplePayload* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_666DC2E1_TuplePayload zT_240;
    unsigned int zT_242;
    unsigned short zT_243;
    unsigned int* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned char zT_253;
    unsigned int zT_254;
    zT_338B7C76_TypeRegistry* zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int* zT_259;
    unsigned int* zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_266;
    int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned char zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    zT_0317B1D5_FnPayload* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    zT_0317B1D5_FnPayload zT_283;
    zT_338B7C76_TypeRegistry* zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int* zT_288;
    unsigned int* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    unsigned int zT_296;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned short zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned char zT_308;
    unsigned int zT_309;
    unsigned int zT_312;
    unsigned int zT_313;
    zT_338B7C76_TypeRegistry* zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int* zT_319;
    unsigned int* zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int* zT_324;
    unsigned int zT_328;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned char zT_336;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned char zT_343;
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_111, (unsigned int)sizeof zT_111);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_157, (unsigned int)sizeof zT_157);
    zig_poison_fill((void*)&zT_181, (unsigned int)sizeof zT_181);
    zig_poison_fill((void*)&zT_205, (unsigned int)sizeof zT_205);
    zig_poison_fill((void*)&zT_229, (unsigned int)sizeof zT_229);
    zig_poison_fill((void*)&zT_266, (unsigned int)sizeof zT_266);
    zig_poison_fill((void*)&zT_296, (unsigned int)sizeof zT_296);
    zig_poison_fill((void*)&zT_328, (unsigned int)sizeof zT_328);
    unsigned int off;
    zT_D155D06D_Type ty;
    unsigned int fstart;
    unsigned short fcount;
    zT_406493CE_StructPayload sp;
    unsigned int i;
    zT_AF9231A2_UnionPayload up;
    unsigned int ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int et;
    unsigned int eup;
    unsigned int op;
    unsigned int se;
    zT_666DC2E1_TuplePayload tp_1;
    zT_0317B1D5_FnPayload fp;
    unsigned int fpend;
    unsigned int pi;
    off = start;
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_15 = ty.kind;
    zT_14 = zT_15 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_19 = ty.kind;
    zT_18 = zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_18 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_18) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_23 = 0;
    fstart = zT_23;
    zT_25 = 0;
    fcount = zT_25;
    zT_26 = ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_8:
    if ((unsigned char)(probe != (unsigned int)(0))) goto z_bb_71; else goto z_bb_72;
    z_bb_9:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_19; else goto z_bb_21;
    z_bb_10:
    zT_30 = self->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = sp.fields_start;
    fstart = zT_34;
    zT_35 = sp.fields_count;
    fcount = zT_35;
    goto z_bb_11;
    z_bb_11:
    zT_44 = 0;
    i = zT_44;
    goto z_bb_13;
    z_bb_12:
    zT_37 = self->un_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    up = zT_40;
    zT_41 = up.fields_start;
    fstart = zT_41;
    zT_42 = up.fields_count;
    fcount = zT_42;
    goto z_bb_11;
    z_bb_13:
    if ((unsigned char)(i < (unsigned int)((unsigned int)fcount))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_48 = self->fe_items;
    zT_49 = (unsigned int)fstart;
    zT_50 = zig_wrap_add_u(((zu64)(zT_49)), ((zu64)(i)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(zT_49)), ((zu64)(i)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = zT_48[zT_50];
    zT_55 = zT_54.type_id;
    ft = zT_55;
    zT_56 = self;
    zT_57 = tid;
    zT_58 = ft;
    zT_60 = out;
    zT_61 = (unsigned int*)&off;
    zT_62 = start;
    zT_63 = probe;
    zT_64 = probe_target;
    zT_67 = zF_DAC9FA8B_typeRefsNote(zT_56, zT_57, zT_58, (unsigned char)(0), zT_60, zT_61, zT_62, zT_63, zT_64);
    if ((unsigned char)(zT_67 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_71 = 1;
    zT_72 = (unsigned int)zT_71;
    zT_73 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_72)), 32u);
    zT_74 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_72)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    i = zT_73;
    goto z_bb_13;
    z_bb_17:
    return (unsigned int)(1);
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_81 = self->tu_items;
    zT_82 = ty.payload_idx;
    zT_83 = (unsigned int)zT_82;
    zT_84 = zT_81[zT_83];
    tp = zT_84;
    zT_86 = 0;
    i = zT_86;
    goto z_bb_22;
    z_bb_20:
    goto z_bb_8;
    z_bb_21:
    zT_137 = ty.kind;
    if ((unsigned char)(zT_137 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_30; else goto z_bb_32;
    z_bb_22:
    zT_87 = tp.fields_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_87))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_91 = self->fe_items;
    zT_92 = tp.fields_start;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zig_wrap_add_u(((zu64)(zT_93)), ((zu64)(i)), 32u);
    zT_95 = zig_overflow_flag_add_u(((zu64)(zT_93)), ((zu64)(i)), 32u);
    zT_97 = zT_95 == (unsigned int)(0);
    if (!(zT_97)) { pal_trap(); }
    zT_98 = zT_91[zT_94];
    zT_99 = zT_98.type_id;
    ft = zT_99;
    zT_100 = self;
    zT_101 = tid;
    zT_102 = ft;
    zT_104 = out;
    zT_105 = (unsigned int*)&off;
    zT_106 = start;
    zT_107 = probe;
    zT_108 = probe_target;
    zT_111 = zF_DAC9FA8B_typeRefsNote(zT_100, zT_101, zT_102, (unsigned char)(0), zT_104, zT_105, zT_106, zT_107, zT_108);
    if ((unsigned char)(zT_111 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    zT_121 = self;
    zT_122 = tid;
    zT_123 = tp.tag_type;
    zT_125 = out;
    zT_126 = (unsigned int*)&off;
    zT_127 = start;
    zT_128 = probe;
    zT_129 = probe_target;
    zT_133 = zF_DAC9FA8B_typeRefsNote(zT_121, zT_122, zT_123, (unsigned char)(0), zT_125, zT_126, zT_127, zT_128, zT_129);
    if ((unsigned char)(zT_133 != (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_115 = 1;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    i = zT_117;
    goto z_bb_22;
    z_bb_26:
    return (unsigned int)(1);
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    return (unsigned int)(1);
    z_bb_29:
    goto z_bb_20;
    z_bb_30:
    zT_141 = self->array_items;
    zT_142 = ty.payload_idx;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    zT_145 = zT_144.elem;
    et = zT_145;
    zT_146 = self;
    zT_147 = tid;
    zT_148 = et;
    zT_150 = out;
    zT_151 = (unsigned int*)&off;
    zT_152 = start;
    zT_153 = probe;
    zT_154 = probe_target;
    zT_157 = zF_DAC9FA8B_typeRefsNote(zT_146, zT_147, zT_148, (unsigned char)(0), zT_150, zT_151, zT_152, zT_153, zT_154);
    if ((unsigned char)(zT_157 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_20;
    z_bb_32:
    zT_161 = ty.kind;
    if ((unsigned char)(zT_161 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    return (unsigned int)(1);
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_165 = self->eu_items;
    zT_166 = ty.payload_idx;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zT_165[zT_167];
    zT_169 = zT_168.payload;
    eup = zT_169;
    zT_170 = self;
    zT_171 = tid;
    zT_172 = eup;
    zT_174 = out;
    zT_175 = (unsigned int*)&off;
    zT_176 = start;
    zT_177 = probe;
    zT_178 = probe_target;
    zT_181 = zF_DAC9FA8B_typeRefsNote(zT_170, zT_171, zT_172, (unsigned char)(0), zT_174, zT_175, zT_176, zT_177, zT_178);
    if ((unsigned char)(zT_181 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_185 = ty.kind;
    if ((unsigned char)(zT_185 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_38:
    return (unsigned int)(1);
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_189 = self->opt_items;
    zT_190 = ty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    zT_193 = zT_192.payload;
    op = zT_193;
    zT_194 = self;
    zT_195 = tid;
    zT_196 = op;
    zT_198 = out;
    zT_199 = (unsigned int*)&off;
    zT_200 = start;
    zT_201 = probe;
    zT_202 = probe_target;
    zT_205 = zF_DAC9FA8B_typeRefsNote(zT_194, zT_195, zT_196, (unsigned char)(0), zT_198, zT_199, zT_200, zT_201, zT_202);
    if ((unsigned char)(zT_205 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_36;
    z_bb_42:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_45; else goto z_bb_47;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    goto z_bb_41;
    z_bb_45:
    zT_213 = self->slice_items;
    zT_214 = ty.payload_idx;
    zT_215 = (unsigned int)zT_214;
    zT_216 = zT_213[zT_215];
    zT_217 = zT_216.elem;
    se = zT_217;
    zT_218 = self;
    zT_219 = tid;
    zT_220 = se;
    zT_222 = out;
    zT_223 = (unsigned int*)&off;
    zT_224 = start;
    zT_225 = probe;
    zT_226 = probe_target;
    zT_229 = zF_DAC9FA8B_typeRefsNote(zT_218, zT_219, zT_220, (unsigned char)(1), zT_222, zT_223, zT_224, zT_225, zT_226);
    if ((unsigned char)(zT_229 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    goto z_bb_41;
    z_bb_47:
    zT_233 = ty.kind;
    if ((unsigned char)(zT_233 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_50; else goto z_bb_52;
    z_bb_48:
    return (unsigned int)(1);
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_237 = self->tup_items;
    zT_238 = ty.payload_idx;
    zT_239 = (unsigned int)zT_238;
    zT_240 = zT_237[zT_239];
    tp_1 = zT_240;
    zT_242 = 0;
    i = zT_242;
    goto z_bb_53;
    z_bb_51:
    goto z_bb_46;
    z_bb_52:
    zT_276 = ty.kind;
    if ((unsigned char)(zT_276 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_59; else goto z_bb_60;
    z_bb_53:
    zT_243 = tp_1.elems_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_243))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_247 = self->xt_items;
    zT_248 = tp_1.elems_start;
    zT_249 = (unsigned int)zT_248;
    zT_250 = zig_wrap_add_u(((zu64)(zT_249)), ((zu64)(i)), 32u);
    zT_251 = zig_overflow_flag_add_u(((zu64)(zT_249)), ((zu64)(i)), 32u);
    zT_253 = zT_251 == (unsigned int)(0);
    if (!(zT_253)) { pal_trap(); }
    zT_254 = zT_247[zT_250];
    et = zT_254;
    zT_255 = self;
    zT_256 = tid;
    zT_257 = et;
    zT_259 = out;
    zT_260 = (unsigned int*)&off;
    zT_261 = start;
    zT_262 = probe;
    zT_263 = probe_target;
    zT_266 = zF_DAC9FA8B_typeRefsNote(zT_255, zT_256, zT_257, (unsigned char)(0), zT_259, zT_260, zT_261, zT_262, zT_263);
    if ((unsigned char)(zT_266 != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    goto z_bb_51;
    z_bb_56:
    zT_270 = 1;
    zT_271 = (unsigned int)zT_270;
    zT_272 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_271)), 32u);
    zT_273 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_271)), 32u);
    zT_275 = zT_273 == (unsigned int)(0);
    if (!(zT_275)) { pal_trap(); }
    i = zT_272;
    goto z_bb_53;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_280 = self->fn_items;
    zT_281 = ty.payload_idx;
    zT_282 = (unsigned int)zT_281;
    zT_283 = zT_280[zT_282];
    fp = zT_283;
    zT_284 = self;
    zT_285 = tid;
    zT_286 = fp.return_type;
    zT_288 = out;
    zT_289 = (unsigned int*)&off;
    zT_290 = start;
    zT_291 = probe;
    zT_292 = probe_target;
    zT_296 = zF_DAC9FA8B_typeRefsNote(zT_284, zT_285, zT_286, (unsigned char)(1), zT_288, zT_289, zT_290, zT_291, zT_292);
    if ((unsigned char)(zT_296 != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_51;
    z_bb_61:
    return (unsigned int)(1);
    z_bb_62:
    zT_301 = fp.params_start;
    zT_302 = (unsigned int)zT_301;
    zT_303 = fp.params_count;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zig_wrap_add_u(((zu64)(zT_302)), ((zu64)(zT_304)), 32u);
    zT_306 = zig_overflow_flag_add_u(((zu64)(zT_302)), ((zu64)(zT_304)), 32u);
    zT_308 = zT_306 == (unsigned int)(0);
    if (!(zT_308)) { pal_trap(); }
    fpend = zT_305;
    zT_309 = self->xt_len;
    if ((unsigned char)(fpend <= zT_309)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_312 = fp.params_start;
    zT_313 = (unsigned int)zT_312;
    pi = zT_313;
    goto z_bb_65;
    z_bb_64:
    goto z_bb_60;
    z_bb_65:
    if ((unsigned char)(pi < fpend)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_315 = self;
    zT_316 = tid;
    zT_324 = self->xt_items;
    zT_317 = zT_324[pi];
    zT_319 = out;
    zT_320 = (unsigned int*)&off;
    zT_321 = start;
    zT_322 = probe;
    zT_323 = probe_target;
    zT_328 = zF_DAC9FA8B_typeRefsNote(zT_315, zT_316, zT_317, (unsigned char)(1), zT_319, zT_320, zT_321, zT_322, zT_323);
    if ((unsigned char)(zT_328 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_332 = 1;
    zT_333 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_332)), 32u);
    zT_334 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_332)), 32u);
    zT_336 = zT_334 == (unsigned int)(0);
    if (!(zT_336)) { pal_trap(); }
    pi = zT_333;
    goto z_bb_65;
    z_bb_69:
    return (unsigned int)(1);
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    return (unsigned int)(0);
    z_bb_72:
    zT_340 = zig_wrap_sub_u(((zu64)(off)), ((zu64)(start)), 32u);
    zT_341 = zig_overflow_flag_sub_u(((zu64)(off)), ((zu64)(start)), 32u);
    zT_343 = zT_341 == (unsigned int)(0);
    if (!(zT_343)) { pal_trap(); }
    return zT_340;
}

/* typeRefs */
unsigned int zF_F41AC8EB_typeRefs(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int* out) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int* zT_5;
    unsigned int zT_12;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_3 = self;
    zT_4 = tid;
    zT_5 = out;
    zT_12 = zF_07B0FCB6_typeRefsWalk(zT_3, zT_4, zT_5, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0));
    return zT_12;
}

/* typeRefsContains */
unsigned char zF_8A421992_typeRefsContains(zT_338B7C76_TypeRegistry* self, unsigned int tid, unsigned int target) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    unsigned char zT_7;
    zT_939EE900_Arr_unsigned_int_1 zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_17;
    int zT_18;
    unsigned char zT_20;
    unsigned int zT_25;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zT_939EE900_Arr_unsigned_int_1 dummy;
    if ((unsigned char)(target == tid)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_5 = self;
    zT_6 = target;
    zT_7 = zF_E789C17A_typeNeedsFullDef(zT_5, zT_6);
    if ((unsigned char)(!zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    {
    unsigned int _i = 0;
    while (_i < 1) {
        dummy[_i] = zT_11[_i];
        _i++;
    }
}
    zT_12 = self;
    zT_13 = tid;
    zT_18 = 0;
    zT_20 = (unsigned int)zT_18 < (unsigned int)(1);
    if (!(zT_20)) { pal_trap(); }
    zT_17 = target;
    zT_25 = zF_07B0FCB6_typeRefsWalk(zT_12, zT_13, (unsigned int*)((unsigned int*)(unsigned int*)(dummy + zT_18)), (unsigned int)(0), (unsigned int)(1), zT_17);
    if ((unsigned char)(zT_25 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(0);
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
unsigned char zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    return (unsigned char)(0);
}

/* typeRegistryIsInteger */
unsigned char zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    return (unsigned char)(0);
}

/* typeRegistryIsUnsigned */
unsigned char zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(0);
}

/* typeRegistryIsPointer */
unsigned char zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
unsigned char zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type));
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned char zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_BAEE192E_Opt_10 zT_12;
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_8 = zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeKindIsSignedIntBase */
unsigned char zF_6D4AC571_typeKindIsSignedInt(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char zT_15;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_9 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_9) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_12) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_15 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_15;
    z_bb_14:
    zT_15 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_15) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
}

/* typeKindIsUnsignedIntBase */
unsigned char zF_C8A7A444_typeKindIsUnsignedI(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    unsigned char zT_15;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_9 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_9) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_12) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_15 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type);
    goto z_bb_15;
    z_bb_14:
    zT_15 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_15) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
}

/* typeKindIntWidthBytes */
unsigned int zF_450A9F7B_typeKindIntWidthByt(zT_33EF6BFB_TypeKind k) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_12;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_27;
    unsigned char zT_30;
    unsigned char zT_33;
    unsigned char zT_36;
    unsigned char zT_42;
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_6 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_6;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(1);
    z_bb_8:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_12 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_11;
    z_bb_10:
    zT_12 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_12) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(2);
    z_bb_13:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned int)(1);
    z_bb_15:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_21 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_18;
    z_bb_17:
    zT_21 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_21) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_24 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_21;
    z_bb_20:
    zT_24 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_24) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_27 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_24;
    z_bb_23:
    zT_27 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_27) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_30 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_27;
    z_bb_26:
    zT_30 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_30) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_33 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_30;
    z_bb_29:
    zT_33 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_33) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_36 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_33;
    z_bb_32:
    zT_36 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_36) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return (unsigned int)(4);
    z_bb_35:
    if ((unsigned char)(k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_42 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_38;
    z_bb_37:
    zT_42 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_42) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned int)(8);
    z_bb_40:
    return (unsigned int)(0);
}

/* typeRegistryIntSignednessClass */
signed char zF_DE90B14C_typeRegistryIntSign(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned char zT_20;
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_27;
    unsigned char zT_28;
    unsigned char zT_31;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zT_33EF6BFB_TypeKind k;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (signed char)((signed char)-1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_10 = k;
    zT_11 = zF_6D4AC571_typeKindIsSignedInt(zT_10);
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_17 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_20 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_11;
    z_bb_10:
    zT_20 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_20) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_23 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_14;
    z_bb_13:
    zT_23 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_23) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (signed char)(1);
    z_bb_16:
    zT_27 = k;
    zT_28 = zF_C8A7A444_typeKindIsUnsignedI(zT_27);
    if ((unsigned char)(zT_28 != (unsigned char)(0))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_31 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_19;
    z_bb_18:
    zT_31 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_31) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (signed char)(0);
    z_bb_21:
    return (signed char)((signed char)-1);
}

/* typeRegistryIntNeedsWidthWrap */
unsigned char zF_AA3DF530_typeRegistryIntNeed(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    unsigned char zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zT_D155D06D_Type ty;
    unsigned char w;
    unsigned int cb;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    ty = zT_8;
    zT_9 = ty.kind;
    if ((unsigned char)(zT_9 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = ty.kind;
    zT_12 = zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_5;
    z_bb_4:
    zT_12 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = self;
    zT_19 = tyid;
    zT_20 = zF_655972D5_typeRegistryIntWidt(zT_18, zT_19);
    w = zT_20;
    zT_22 = ty.size;
    zT_23 = 8;
    zT_24 = zig_wrap_mul_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_mul_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = (unsigned int)zT_24;
    cb = zT_28;
    if ((unsigned char)((unsigned int)((unsigned int)w) < (unsigned int)(1))) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_32 = (unsigned int)((unsigned int)w) >= cb;
    goto z_bb_10;
    z_bb_9:
    zT_32 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_32) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    return (unsigned char)(1);
}

/* typeRegistryIntByteWidth */
unsigned int zF_47244FDF_typeRegistryIntByte(zT_338B7C76_TypeRegistry* self, unsigned int tyid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    unsigned int zT_18;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zT_33EF6BFB_TypeKind k;
    unsigned int w;
    if ((unsigned char)(tyid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tyid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_11 = k;
    zT_12 = zF_450A9F7B_typeKindIntWidthByt(zT_11);
    w = zT_12;
    if ((unsigned char)(w != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return w;
    z_bb_4:
    zT_15 = self->types_items;
    zT_16 = (unsigned int)tyid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17.size;
    return zT_18;
}

/* typeRegistryIsIntKind */
unsigned char zF_AA5656C9_typeRegistryIsIntKi(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    unsigned char zT_16;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zT_33EF6BFB_TypeKind k;
    if ((unsigned char)(tid == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)tid;
    zT_8 = zT_6[zT_7];
    zT_9 = zT_8.kind;
    k = zT_9;
    zT_10 = k;
    zT_11 = zF_6D4AC571_typeKindIsSignedInt(zT_10);
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_15 = k;
    zT_16 = zF_C8A7A444_typeKindIsUnsignedI(zT_15);
    zT_14 = zT_16 != (unsigned char)(0);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_19 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_22 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_11;
    z_bb_10:
    zT_22 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_22) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_25 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_14;
    z_bb_13:
    zT_25 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_25) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_28 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_17;
    z_bb_16:
    zT_28 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_28) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_31 = k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_20;
    z_bb_19:
    zT_31 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_31) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    return (unsigned char)(0);
}

/* typeRegistryIsScalarC */
unsigned char zF_7B6AECEB_typeRegistryIsScala(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned char zT_4;
    unsigned char zT_7;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    unsigned char zT_17;
    unsigned char zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned char zT_37;
    unsigned char zT_40;
    unsigned char zT_43;
    unsigned char zT_46;
    unsigned char zT_49;
    unsigned char zT_52;
    unsigned char zT_55;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zT_33EF6BFB_TypeKind rv_k;
    if ((unsigned char)(tid == (unsigned int)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = tid == (unsigned int)(18);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = tid == (unsigned int)(0);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    zT_15 = zT_14.kind;
    rv_k = zT_15;
    zT_16 = rv_k;
    zT_17 = zF_6D4AC571_typeKindIsSignedInt(zT_16);
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_21 = rv_k;
    zT_22 = zF_C8A7A444_typeKindIsUnsignedI(zT_21);
    zT_20 = zT_22 != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_20 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_20) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_25 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_14;
    z_bb_13:
    zT_25 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_25) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_28 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type);
    goto z_bb_17;
    z_bb_16:
    zT_28 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_28) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_31 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type);
    goto z_bb_20;
    z_bb_19:
    zT_31 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_31) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_34 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_23;
    z_bb_22:
    zT_34 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_34) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_37 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type);
    goto z_bb_26;
    z_bb_25:
    zT_37 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_37) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_40 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_29;
    z_bb_28:
    zT_40 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_40) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_43 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_32;
    z_bb_31:
    zT_43 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_43) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_46 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_35;
    z_bb_34:
    zT_46 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_46) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_49 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_38;
    z_bb_37:
    zT_49 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_49) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_52 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_41;
    z_bb_40:
    zT_52 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_52) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_55 = rv_k == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_44;
    z_bb_43:
    zT_55 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_55) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    return (unsigned char)(0);
}

/* typeRegistryArrayByteSize */
zT_BAEE192E_Opt_10 zF_C35DA834_typeRegistryArrayBy(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_BAEE192E_Opt_10 zT_9;
    unsigned char zT_10;
    zT_BAEE192E_Opt_10 zT_13;
    unsigned int zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9.has_value = 0;
    return zT_9;
    z_bb_2:
    zT_10 = ty.state;
    if ((unsigned char)(zT_10 != (unsigned char)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    zT_14 = ty.size;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_BAEE192E_Opt_10 zT_8;
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    zT_5 = ty.kind;
    if ((unsigned char)(zT_5 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    unsigned char zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    if ((unsigned char)(zT_14 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    if ((unsigned char)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
unsigned char zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type));
}

/* typeRegistryIsErrorSet */
unsigned char zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    return (unsigned char)(zT_4 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type));
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_2DF01B61_FieldEntry* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_24;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fcount)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fcount)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = zT_16 + fstart;
    zT_22 = zT_17 - fstart;
    zT_23 = fstart <= zT_17;
    if (!(zT_23)) { pal_trap(); }
    zT_24.ptr = (zT_2DF01B61_FieldEntry*)zT_21;
    zT_24.len = zT_22;
    *out = zT_24;
    return;
}

/* typeRegistryIsPacked */
unsigned char zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_14 = ty.flags;
    return (unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) != (unsigned char)(0));
}

/* typeRegistryComputePackedLayout */
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_10;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_406493CE_StructPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_406493CE_StructPayload zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned short zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    zT_2DF01B61_FieldEntry zT_49;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_D155D06D_Type* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_D155D06D_Type zT_60;
    zT_33EF6BFB_TypeKind zT_61;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned char zT_67;
    unsigned char zT_68;
    zT_338B7C76_TypeRegistry* zT_73;
    unsigned int zT_74;
    unsigned int zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_E276DDD0_PackedBitField zT_83;
    zT_E276DDD0_PackedBitField zT_84;
    unsigned short zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned char zT_89;
    int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    zT_338B7C76_TypeRegistry* zT_96;
    unsigned int zT_97;
    zT_FA398D58_PackedStructInfo zT_98;
    zT_FA398D58_PackedStructInfo zT_100;
    unsigned short zT_101;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    unsigned int zT_109;
    unsigned char zT_111;
    unsigned int zT_114;
    zT_D155D06D_Type* zT_116;
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int total_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_10 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->st_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_24 = self->st_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    sp = zT_27;
    zT_29 = sp.fields_start;
    zT_30 = (unsigned int)zT_29;
    fstart = zT_30;
    zT_32 = sp.fields_count;
    zT_33 = (unsigned int)zT_32;
    fcount = zT_33;
    zT_35 = self->pk_len;
    zT_36 = (unsigned int)zT_35;
    pk_start = zT_36;
    zT_38 = 0;
    total_bits = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi = zT_41;
    goto z_bb_9;
    z_bb_9:
    if ((unsigned char)(fi < fcount)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_44 = self->fe_items;
    zT_45 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_49 = zT_44[zT_45];
    fe = zT_49;
    zT_51 = 1;
    w = zT_51;
    zT_52 = fe.type_id;
    zT_53 = self->types_len;
    if ((unsigned char)(zT_52 < (unsigned int)((unsigned int)zT_53))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_96 = self;
    zT_97 = ty.payload_idx;
    zT_100.pk_start = pk_start;
    zT_101 = (unsigned short)zig_cast_checked_u((zu64)fcount, 32u, 0u, 16u);
    zT_100.pk_count = zT_101;
    zT_100.total_bits = total_bits;
    zT_98 = zT_100;
    zF_41767D71_pkSetFields(zT_96, zT_97, zT_98);
    zT_103 = 7;
    zT_104 = zig_wrap_add_u(((zu64)(total_bits)), ((zu64)(zT_103)), 32u);
    zT_105 = zig_overflow_flag_add_u(((zu64)(total_bits)), ((zu64)(zT_103)), 32u);
    zT_107 = zT_105 == (unsigned int)(0);
    if (!(zT_107)) { pal_trap(); }
    zT_111 = 1;
    if (!(zT_111)) { pal_trap(); }
    zT_109 = zT_104 / (unsigned int)(8);
    sz = zT_109;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_12:
    zT_90 = 1;
    zT_91 = (unsigned int)zT_90;
    zT_92 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_91)), 32u);
    zT_93 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_91)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    fi = zT_92;
    goto z_bb_9;
    z_bb_13:
    zT_57 = self->types_items;
    zT_58 = fe.type_id;
    zT_59 = (unsigned int)zT_58;
    zT_60 = zT_57[zT_59];
    ft = zT_60;
    zT_61 = ft.kind;
    if ((unsigned char)(zT_61 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_82 = self;
    zT_84.bit_offset = total_bits;
    zT_85 = (unsigned short)zig_cast_checked_u((zu64)w, 32u, 0u, 16u);
    zT_84.bit_width = zT_85;
    zT_83 = zT_84;
    zF_E48D8B88_pkFieldAppend(zT_82, zT_83);
    zT_86 = zig_wrap_add_u(((zu64)(total_bits)), ((zu64)(w)), 32u);
    zT_87 = zig_overflow_flag_add_u(((zu64)(total_bits)), ((zu64)(w)), 32u);
    zT_89 = zT_87 == (unsigned int)(0);
    if (!(zT_89)) { pal_trap(); }
    total_bits = zT_86;
    goto z_bb_12;
    z_bb_15:
    zT_64 = ft.kind;
    if ((unsigned char)(zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_68 = ft.flags;
    zT_67 = (unsigned char)(zT_68 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_19;
    z_bb_18:
    zT_67 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_67) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_73 = self;
    zT_74 = fe.type_id;
    zT_76 = zF_CB27DBA4_typeRegistryGetPack(zT_73, zT_74);
    w = zT_76;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_16;
    z_bb_22:
    zT_77 = self;
    zT_78 = fe.type_id;
    zT_80 = zF_655972D5_typeRegistryIntWidt(zT_77, zT_78);
    zT_81 = (unsigned int)zT_80;
    w = zT_81;
    goto z_bb_21;
    z_bb_23:
    zT_114 = 1;
    sz = zT_114;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned short)(1);
    zT_116 = self->types_items;
    zT_116[idx] = ty;
    return;
}

/* typeRegistryGetPackedBitFields */
unsigned char zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned char zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_FA398D58_PackedStructInfo zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    unsigned int zT_46;
    zT_E276DDD0_PackedBitField* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    zT_E276DDD0_PackedBitField* zT_54;
    unsigned int zT_55;
    unsigned char zT_56;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_57;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_15 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = ty.payload_idx;
    zT_22 = self->st_len;
    if ((unsigned char)(zT_21 >= (unsigned int)((unsigned int)zT_22))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = ty.payload_idx;
    zT_28 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_26) >= zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_32 = self->pk_struct_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    psi = zT_35;
    zT_37 = psi.pk_start;
    zT_38 = (unsigned int)zT_37;
    pstart = zT_38;
    zT_40 = psi.pk_count;
    zT_41 = (unsigned int)zT_40;
    pcount = zT_41;
    zT_42 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_43 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    zT_46 = self->pk_len;
    if ((unsigned char)(zT_42 > zT_46)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_49 = self->pk_items;
    zT_50 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    zT_54 = zT_49 + pstart;
    zT_55 = zT_50 - pstart;
    zT_56 = pstart <= zT_50;
    if (!(zT_56)) { pal_trap(); }
    zT_57.ptr = (zT_E276DDD0_PackedBitField*)zT_54;
    zT_57.len = zT_55;
    *out = zT_57;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedTotalBits */
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_14;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_FA398D58_PackedStructInfo* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_FA398D58_PackedStructInfo zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_14 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_21 = self->st_len;
    if ((unsigned char)(zT_20 >= (unsigned int)((unsigned int)zT_21))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_25 = ty.payload_idx;
    zT_27 = self->pk_struct_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_25) >= zT_27)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(0);
    z_bb_10:
    zT_30 = self->pk_struct_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.total_bits;
    return zT_34;
}

/* typeRegistrySetPacked */
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    zT_6 = ty.flags;
    ty.flags = (unsigned char)(zT_6 | (unsigned char)(16));
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_9[zT_10] = ty;
    return;
}

/* typeRegistryComputePackedUnionLayout */
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_16;
    zT_AF9231A2_UnionPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_AF9231A2_UnionPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    zT_2DF01B61_FieldEntry* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_2DF01B61_FieldEntry zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D155D06D_Type* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_D155D06D_Type zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_62;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned int zT_71;
    zT_338B7C76_TypeRegistry* zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    unsigned int zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_E276DDD0_PackedBitField zT_78;
    zT_E276DDD0_PackedBitField zT_79;
    unsigned int zT_80;
    unsigned short zT_81;
    int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_338B7C76_TypeRegistry* zT_89;
    unsigned int zT_90;
    zT_FA398D58_PackedStructInfo zT_91;
    zT_FA398D58_PackedStructInfo zT_93;
    unsigned short zT_94;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned int zT_102;
    unsigned char zT_104;
    unsigned int zT_107;
    zT_D155D06D_Type* zT_109;
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int pk_start;
    unsigned int max_bits;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    unsigned int w;
    unsigned int sz;
    zT_D155D06D_Type ft;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = self->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = ty.payload_idx;
    zT_11 = self->un_len;
    if ((unsigned char)(zT_10 >= (unsigned int)((unsigned int)zT_11))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_16 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_14) >= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_19 = self->un_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    up = zT_22;
    zT_24 = up.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = up.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = self->pk_len;
    zT_31 = (unsigned int)zT_30;
    pk_start = zT_31;
    zT_33 = 0;
    max_bits = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    fi = zT_36;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_39 = self->fe_items;
    zT_40 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fi)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_39[zT_40];
    fe = zT_44;
    zT_46 = 1;
    w = zT_46;
    zT_47 = fe.type_id;
    zT_48 = self->types_len;
    if ((unsigned char)(zT_47 < (unsigned int)((unsigned int)zT_48))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_89 = self;
    zT_90 = ty.payload_idx;
    zT_93.pk_start = pk_start;
    zT_94 = (unsigned short)zig_cast_checked_u((zu64)fcount, 32u, 0u, 16u);
    zT_93.pk_count = zT_94;
    zT_93.total_bits = max_bits;
    zT_91 = zT_93;
    zF_0213D00C_pkUnSetFields(zT_89, zT_90, zT_91);
    zT_96 = 7;
    zT_97 = zig_wrap_add_u(((zu64)(max_bits)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(max_bits)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    zT_104 = 1;
    if (!(zT_104)) { pal_trap(); }
    zT_102 = zT_97 / (unsigned int)(8);
    sz = zT_102;
    if ((unsigned char)(sz == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_10:
    zT_83 = 1;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_84)), 32u);
    zT_86 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_84)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    fi = zT_85;
    goto z_bb_7;
    z_bb_11:
    zT_52 = self->types_items;
    zT_53 = fe.type_id;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zT_52[zT_54];
    ft = zT_55;
    zT_56 = ft.kind;
    if ((unsigned char)(zT_56 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_77 = self;
    zT_80 = 0;
    zT_79.bit_offset = zT_80;
    zT_81 = (unsigned short)zig_cast_checked_u((zu64)w, 32u, 0u, 16u);
    zT_79.bit_width = zT_81;
    zT_78 = zT_79;
    zF_E48D8B88_pkFieldAppend(zT_77, zT_78);
    if ((unsigned char)(w > max_bits)) goto z_bb_21; else goto z_bb_22;
    z_bb_13:
    zT_59 = ft.kind;
    if ((unsigned char)(zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_63 = ft.flags;
    zT_62 = (unsigned char)(zT_63 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_17;
    z_bb_16:
    zT_62 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_62) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_68 = self;
    zT_69 = fe.type_id;
    zT_71 = zF_CB27DBA4_typeRegistryGetPack(zT_68, zT_69);
    w = zT_71;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_72 = self;
    zT_73 = fe.type_id;
    zT_75 = zF_655972D5_typeRegistryIntWidt(zT_72, zT_73);
    zT_76 = (unsigned int)zT_75;
    w = zT_76;
    goto z_bb_19;
    z_bb_21:
    max_bits = w;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_10;
    z_bb_23:
    zT_107 = 1;
    sz = zT_107;
    goto z_bb_24;
    z_bb_24:
    ty.size = sz;
    ty.alignment = (unsigned short)(1);
    zT_109 = self->types_items;
    zT_109[idx] = ty;
    return;
}

/* typeRegistryGetPackedUnionBitFields */
unsigned char zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BCF34E4D_Slice_zT_E276DDD0_P* out) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_FA398D58_PackedStructInfo* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_FA398D58_PackedStructInfo zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned short zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    zT_E276DDD0_PackedBitField* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_E276DDD0_PackedBitField* zT_48;
    unsigned int zT_49;
    unsigned char zT_50;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_51;
    zT_D155D06D_Type ty;
    zT_FA398D58_PackedStructInfo psi;
    unsigned int pstart;
    unsigned int pcount;
    zT_4 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = self->un_len;
    if ((unsigned char)(zT_15 >= (unsigned int)((unsigned int)zT_16))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = ty.payload_idx;
    zT_22 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_20) >= zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = self->pk_un_items;
    zT_27 = ty.payload_idx;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zT_26[zT_28];
    psi = zT_29;
    zT_31 = psi.pk_start;
    zT_32 = (unsigned int)zT_31;
    pstart = zT_32;
    zT_34 = psi.pk_count;
    zT_35 = (unsigned int)zT_34;
    pcount = zT_35;
    zT_36 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_40 = self->pk_len;
    if ((unsigned char)(zT_36 > zT_40)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_43 = self->pk_items;
    zT_44 = zig_wrap_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_45 = zig_overflow_flag_add_u(((zu64)(pstart)), ((zu64)(pcount)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_43 + pstart;
    zT_49 = zT_44 - pstart;
    zT_50 = pstart <= zT_44;
    if (!(zT_50)) { pal_trap(); }
    zT_51.ptr = (zT_E276DDD0_PackedBitField*)zT_48;
    zT_51.len = zT_49;
    *out = zT_51;
    return (unsigned char)(1);
}

/* typeRegistryGetPackedUnionTotalBits */
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_FA398D58_PackedStructInfo* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_FA398D58_PackedStructInfo zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type ty;
    zT_3 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = self->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_14 = ty.payload_idx;
    zT_15 = self->un_len;
    if ((unsigned char)(zT_14 >= (unsigned int)((unsigned int)zT_15))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(0);
    z_bb_6:
    zT_19 = ty.payload_idx;
    zT_21 = self->pk_un_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_19) >= zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(0);
    z_bb_8:
    zT_24 = self->pk_un_items;
    zT_25 = ty.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.total_bits;
    return zT_28;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_2DF01B61_FieldEntry* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_24;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = zig_wrap_add_u(((zu64)(fstart)), ((zu64)(fcount)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(fstart)), ((zu64)(fcount)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = zT_16 + fstart;
    zT_22 = zT_17 - fstart;
    zT_23 = fstart <= zT_17;
    if (!(zT_23)) { pal_trap(); }
    zT_24.ptr = (zT_2DF01B61_FieldEntry*)zT_21;
    zT_24.len = zT_22;
    *out = zT_24;
    return;
}

/* pointerQualifiersMonotone */
unsigned char zF_08C13644_pointerQualifiersMo(unsigned char src_flags, unsigned char tgt_flags, unsigned char mask) {
    return (unsigned char)((unsigned char)((unsigned char)(src_flags & mask) & (unsigned char)(~(unsigned char)(tgt_flags & mask))) == (unsigned char)(0));
}

/* typeRegistryTypesEquiv */
unsigned char zF_3130DDCF_typeRegistryTypesEq(zT_338B7C76_TypeRegistry* self, unsigned int a, unsigned int b) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned char zT_8;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_3 = self;
    zT_4 = a;
    zT_5 = b;
    zT_8 = zF_4D8FED56_typesEquivRec(zT_3, zT_4, zT_5, (unsigned int)(0));
    return zT_8;
}

/* typesEquivRec */
unsigned char zF_4D8FED56_typesEquivRec(zT_338B7C76_TypeRegistry* self, unsigned int a, unsigned int b, unsigned int depth) {
    unsigned int zT_10;
    unsigned int zT_14;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_0B10E8E9_OptionalPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_0B10E8E9_OptionalPayload zT_46;
    zT_0B10E8E9_OptionalPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_0B10E8E9_OptionalPayload zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_42C2D6BF_EUPayload* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    zT_42C2D6BF_EUPayload zT_81;
    zT_42C2D6BF_EUPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_42C2D6BF_EUPayload zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_91;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    zT_33EF6BFB_TypeKind zT_103;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_E834303C_ArrayPayload* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_E834303C_ArrayPayload zT_120;
    zT_E834303C_ArrayPayload* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_E834303C_ArrayPayload zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_130;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned char zT_140;
    zT_33EF6BFB_TypeKind zT_142;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_155;
    unsigned char zT_156;
    zT_0BB2A741_SlicePayload* zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    zT_0BB2A741_SlicePayload zT_163;
    zT_0BB2A741_SlicePayload* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_0BB2A741_SlicePayload zT_168;
    zT_338B7C76_TypeRegistry* zT_169;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned char zT_179;
    zT_33EF6BFB_TypeKind zT_181;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_666DC2E1_TuplePayload* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_666DC2E1_TuplePayload zT_198;
    zT_666DC2E1_TuplePayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_666DC2E1_TuplePayload zT_203;
    unsigned short zT_204;
    unsigned short zT_205;
    int zT_209;
    unsigned short zT_210;
    unsigned short zT_211;
    unsigned int* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned char zT_221;
    unsigned int zT_222;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned char zT_231;
    unsigned int zT_232;
    zT_338B7C76_TypeRegistry* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned char zT_241;
    unsigned char zT_242;
    int zT_245;
    unsigned short zT_246;
    unsigned short zT_247;
    unsigned int zT_248;
    unsigned char zT_250;
    zT_33EF6BFB_TypeKind zT_252;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_0317B1D5_FnPayload* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_0317B1D5_FnPayload zT_269;
    zT_0317B1D5_FnPayload* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    zT_0317B1D5_FnPayload zT_274;
    unsigned short zT_275;
    unsigned short zT_276;
    unsigned char zT_279;
    unsigned char zT_280;
    zT_338B7C76_TypeRegistry* zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    unsigned char zT_294;
    int zT_298;
    unsigned short zT_299;
    unsigned short zT_300;
    unsigned int* zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned char zT_310;
    unsigned int zT_311;
    unsigned int* zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned char zT_320;
    unsigned int zT_321;
    zT_338B7C76_TypeRegistry* zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned char zT_330;
    unsigned char zT_331;
    int zT_334;
    unsigned short zT_335;
    unsigned short zT_336;
    unsigned int zT_337;
    unsigned char zT_339;
    zig_poison_fill((void*)&zT_242, (unsigned int)sizeof zT_242);
    zig_poison_fill((void*)&zT_294, (unsigned int)sizeof zT_294);
    zig_poison_fill((void*)&zT_331, (unsigned int)sizeof zT_331);
    zT_D155D06D_Type ta;
    zT_D155D06D_Type tb;
    zT_0B10E8E9_OptionalPayload oa;
    zT_0B10E8E9_OptionalPayload ob;
    zT_42C2D6BF_EUPayload ea;
    zT_42C2D6BF_EUPayload eb;
    zT_E834303C_ArrayPayload aa;
    zT_E834303C_ArrayPayload ab;
    zT_0BB2A741_SlicePayload sa;
    zT_0BB2A741_SlicePayload sb;
    zT_666DC2E1_TuplePayload pa;
    zT_666DC2E1_TuplePayload pb;
    unsigned short ei;
    unsigned int xa;
    unsigned int xb;
    zT_0317B1D5_FnPayload fa;
    zT_0317B1D5_FnPayload fb;
    unsigned short fi;
    unsigned int xa2;
    unsigned int xb2;
    z_bb_0:
    if ((unsigned char)(a == b)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_10 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)a) >= zT_10)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_14 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)b) >= zT_14)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_18 = self->types_items;
    zT_19 = (unsigned int)a;
    zT_20 = zT_18[zT_19];
    ta = zT_20;
    zT_22 = self->types_items;
    zT_23 = (unsigned int)b;
    zT_24 = zT_22[zT_23];
    tb = zT_24;
    zT_25 = ta.kind;
    zT_26 = tb.kind;
    if ((unsigned char)(zT_25 != zT_26)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_29 = ta.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ta.payload_idx;
    zT_33 = self->opt_len;
    if ((unsigned char)(zT_32 >= (unsigned int)((unsigned int)zT_33))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_64 = ta.kind;
    if ((unsigned char)(zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_37 = tb.payload_idx;
    zT_38 = self->opt_len;
    if ((unsigned char)(zT_37 >= (unsigned int)((unsigned int)zT_38))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_43 = self->opt_items;
    zT_44 = ta.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    oa = zT_46;
    zT_48 = self->opt_items;
    zT_49 = tb.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    ob = zT_51;
    zT_52 = self;
    zT_56 = oa.payload;
    zT_57 = ob.payload;
    zT_58 = 1;
    zT_59 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    self = zT_52;
    a = zT_56;
    b = zT_57;
    depth = zT_59;
    goto z_bb_0;
    z_bb_17:
    zT_67 = ta.payload_idx;
    zT_68 = self->eu_len;
    if ((unsigned char)(zT_67 >= (unsigned int)((unsigned int)zT_68))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_103 = ta.kind;
    if ((unsigned char)(zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    zT_72 = tb.payload_idx;
    zT_73 = self->eu_len;
    if ((unsigned char)(zT_72 >= (unsigned int)((unsigned int)zT_73))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_78 = self->eu_items;
    zT_79 = ta.payload_idx;
    zT_80 = (unsigned int)zT_79;
    zT_81 = zT_78[zT_80];
    ea = zT_81;
    zT_83 = self->eu_items;
    zT_84 = tb.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    eb = zT_86;
    zT_87 = ea.error_set;
    zT_88 = eb.error_set;
    if ((unsigned char)(zT_87 != zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    zT_91 = self;
    zT_95 = ea.payload;
    zT_96 = eb.payload;
    zT_97 = 1;
    zT_98 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    self = zT_91;
    a = zT_95;
    b = zT_96;
    depth = zT_98;
    goto z_bb_0;
    z_bb_25:
    zT_106 = ta.payload_idx;
    zT_107 = self->array_len;
    if ((unsigned char)(zT_106 >= (unsigned int)((unsigned int)zT_107))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_142 = ta.kind;
    if ((unsigned char)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_111 = tb.payload_idx;
    zT_112 = self->array_len;
    if ((unsigned char)(zT_111 >= (unsigned int)((unsigned int)zT_112))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(0);
    z_bb_30:
    zT_117 = self->array_items;
    zT_118 = ta.payload_idx;
    zT_119 = (unsigned int)zT_118;
    zT_120 = zT_117[zT_119];
    aa = zT_120;
    zT_122 = self->array_items;
    zT_123 = tb.payload_idx;
    zT_124 = (unsigned int)zT_123;
    zT_125 = zT_122[zT_124];
    ab = zT_125;
    zT_126 = aa.length;
    zT_127 = ab.length;
    if ((unsigned char)(zT_126 != zT_127)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (unsigned char)(0);
    z_bb_32:
    zT_130 = self;
    zT_134 = aa.elem;
    zT_135 = ab.elem;
    zT_136 = 1;
    zT_137 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_136)), 32u);
    zT_138 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_136)), 32u);
    zT_140 = zT_138 == (unsigned int)(0);
    if (!(zT_140)) { pal_trap(); }
    self = zT_130;
    a = zT_134;
    b = zT_135;
    depth = zT_137;
    goto z_bb_0;
    z_bb_33:
    zT_145 = ta.payload_idx;
    zT_146 = self->slice_len;
    if ((unsigned char)(zT_145 >= (unsigned int)((unsigned int)zT_146))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_181 = ta.kind;
    if ((unsigned char)(zT_181 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_35:
    return (unsigned char)(0);
    z_bb_36:
    zT_150 = tb.payload_idx;
    zT_151 = self->slice_len;
    if ((unsigned char)(zT_150 >= (unsigned int)((unsigned int)zT_151))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(0);
    z_bb_38:
    zT_155 = ta.flags;
    zT_156 = tb.flags;
    if ((unsigned char)(zT_155 != zT_156)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(0);
    z_bb_40:
    zT_160 = self->slice_items;
    zT_161 = ta.payload_idx;
    zT_162 = (unsigned int)zT_161;
    zT_163 = zT_160[zT_162];
    sa = zT_163;
    zT_165 = self->slice_items;
    zT_166 = tb.payload_idx;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zT_165[zT_167];
    sb = zT_168;
    zT_169 = self;
    zT_173 = sa.elem;
    zT_174 = sb.elem;
    zT_175 = 1;
    zT_176 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_175)), 32u);
    zT_177 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_175)), 32u);
    zT_179 = zT_177 == (unsigned int)(0);
    if (!(zT_179)) { pal_trap(); }
    self = zT_169;
    a = zT_173;
    b = zT_174;
    depth = zT_176;
    goto z_bb_0;
    z_bb_41:
    zT_184 = ta.payload_idx;
    zT_185 = self->tup_len;
    if ((unsigned char)(zT_184 >= (unsigned int)((unsigned int)zT_185))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_252 = ta.kind;
    if ((unsigned char)(zT_252 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_43:
    return (unsigned char)(0);
    z_bb_44:
    zT_189 = tb.payload_idx;
    zT_190 = self->tup_len;
    if ((unsigned char)(zT_189 >= (unsigned int)((unsigned int)zT_190))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(0);
    z_bb_46:
    zT_195 = self->tup_items;
    zT_196 = ta.payload_idx;
    zT_197 = (unsigned int)zT_196;
    zT_198 = zT_195[zT_197];
    pa = zT_198;
    zT_200 = self->tup_items;
    zT_201 = tb.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    pb = zT_203;
    zT_204 = pa.elems_count;
    zT_205 = pb.elems_count;
    if ((unsigned char)(zT_204 != zT_205)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(0);
    z_bb_48:
    zT_209 = 0;
    zT_210 = (unsigned short)zT_209;
    ei = zT_210;
    goto z_bb_49;
    z_bb_49:
    zT_211 = pa.elems_count;
    if ((unsigned char)(ei < zT_211)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = self->xt_items;
    zT_215 = pa.elems_start;
    zT_216 = (unsigned int)zT_215;
    zT_217 = (unsigned int)ei;
    zT_218 = zig_wrap_add_u(((zu64)(zT_216)), ((zu64)(zT_217)), 32u);
    zT_219 = zig_overflow_flag_add_u(((zu64)(zT_216)), ((zu64)(zT_217)), 32u);
    zT_221 = zT_219 == (unsigned int)(0);
    if (!(zT_221)) { pal_trap(); }
    zT_222 = zT_214[zT_218];
    xa = zT_222;
    zT_224 = self->xt_items;
    zT_225 = pb.elems_start;
    zT_226 = (unsigned int)zT_225;
    zT_227 = (unsigned int)ei;
    zT_228 = zig_wrap_add_u(((zu64)(zT_226)), ((zu64)(zT_227)), 32u);
    zT_229 = zig_overflow_flag_add_u(((zu64)(zT_226)), ((zu64)(zT_227)), 32u);
    zT_231 = zT_229 == (unsigned int)(0);
    if (!(zT_231)) { pal_trap(); }
    zT_232 = zT_224[zT_228];
    xb = zT_232;
    zT_233 = self;
    zT_234 = xa;
    zT_235 = xb;
    zT_237 = 1;
    zT_238 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_237)), 32u);
    zT_239 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_237)), 32u);
    zT_241 = zT_239 == (unsigned int)(0);
    if (!(zT_241)) { pal_trap(); }
    zT_236 = zT_238;
    zT_242 = zF_4D8FED56_typesEquivRec(zT_233, zT_234, zT_235, zT_236);
    if ((unsigned char)(!zT_242)) goto z_bb_53; else goto z_bb_54;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    zT_245 = 1;
    zT_246 = (unsigned short)zT_245;
    zT_247 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_246)), 16u);
    zT_248 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_246)), 16u);
    zT_250 = zT_248 == (unsigned int)(0);
    if (!(zT_250)) { pal_trap(); }
    ei = zT_247;
    goto z_bb_49;
    z_bb_53:
    return (unsigned char)(0);
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_255 = ta.payload_idx;
    zT_256 = self->fn_len;
    if ((unsigned char)(zT_255 >= (unsigned int)((unsigned int)zT_256))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    return (unsigned char)(0);
    z_bb_57:
    return (unsigned char)(0);
    z_bb_58:
    zT_260 = tb.payload_idx;
    zT_261 = self->fn_len;
    if ((unsigned char)(zT_260 >= (unsigned int)((unsigned int)zT_261))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(0);
    z_bb_60:
    zT_266 = self->fn_items;
    zT_267 = ta.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    fa = zT_269;
    zT_271 = self->fn_items;
    zT_272 = tb.payload_idx;
    zT_273 = (unsigned int)zT_272;
    zT_274 = zT_271[zT_273];
    fb = zT_274;
    zT_275 = fa.params_count;
    zT_276 = fb.params_count;
    if ((unsigned char)(zT_275 != zT_276)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (unsigned char)(0);
    z_bb_62:
    zT_279 = fa.flags_packed;
    zT_280 = fb.flags_packed;
    if ((unsigned char)(zT_279 != zT_280)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    zT_283 = self;
    zT_284 = fa.return_type;
    zT_285 = fb.return_type;
    zT_289 = 1;
    zT_290 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_289)), 32u);
    zT_291 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_289)), 32u);
    zT_293 = zT_291 == (unsigned int)(0);
    if (!(zT_293)) { pal_trap(); }
    zT_286 = zT_290;
    zT_294 = zF_4D8FED56_typesEquivRec(zT_283, zT_284, zT_285, zT_286);
    if ((unsigned char)(!zT_294)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (unsigned char)(0);
    z_bb_66:
    zT_298 = 0;
    zT_299 = (unsigned short)zT_298;
    fi = zT_299;
    goto z_bb_67;
    z_bb_67:
    zT_300 = fa.params_count;
    if ((unsigned char)(fi < zT_300)) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_303 = self->xt_items;
    zT_304 = fa.params_start;
    zT_305 = (unsigned int)zT_304;
    zT_306 = (unsigned int)fi;
    zT_307 = zig_wrap_add_u(((zu64)(zT_305)), ((zu64)(zT_306)), 32u);
    zT_308 = zig_overflow_flag_add_u(((zu64)(zT_305)), ((zu64)(zT_306)), 32u);
    zT_310 = zT_308 == (unsigned int)(0);
    if (!(zT_310)) { pal_trap(); }
    zT_311 = zT_303[zT_307];
    xa2 = zT_311;
    zT_313 = self->xt_items;
    zT_314 = fb.params_start;
    zT_315 = (unsigned int)zT_314;
    zT_316 = (unsigned int)fi;
    zT_317 = zig_wrap_add_u(((zu64)(zT_315)), ((zu64)(zT_316)), 32u);
    zT_318 = zig_overflow_flag_add_u(((zu64)(zT_315)), ((zu64)(zT_316)), 32u);
    zT_320 = zT_318 == (unsigned int)(0);
    if (!(zT_320)) { pal_trap(); }
    zT_321 = zT_313[zT_317];
    xb2 = zT_321;
    zT_322 = self;
    zT_323 = xa2;
    zT_324 = xb2;
    zT_326 = 1;
    zT_327 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_326)), 32u);
    zT_328 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_326)), 32u);
    zT_330 = zT_328 == (unsigned int)(0);
    if (!(zT_330)) { pal_trap(); }
    zT_325 = zT_327;
    zT_331 = zF_4D8FED56_typesEquivRec(zT_322, zT_323, zT_324, zT_325);
    if ((unsigned char)(!zT_331)) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    zT_334 = 1;
    zT_335 = (unsigned short)zT_334;
    zT_336 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_335)), 16u);
    zT_337 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_335)), 16u);
    zT_339 = zT_337 == (unsigned int)(0);
    if (!(zT_339)) { pal_trap(); }
    fi = zT_336;
    goto z_bb_67;
    z_bb_71:
    return (unsigned char)(0);
    z_bb_72:
    goto z_bb_70;
}

/* typeRegistryIsAssignable */
unsigned char zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_17;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char zT_39;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned char zT_48;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    unsigned char zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    unsigned char zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    unsigned char zT_64;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_79;
    zT_33EF6BFB_TypeKind zT_83;
    unsigned char zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_112BF819_PtrPayload* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_112BF819_PtrPayload zT_94;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D155D06D_Type zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    zT_33EF6BFB_TypeKind zT_109;
    zT_0B10E8E9_OptionalPayload* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    zT_0B10E8E9_OptionalPayload zT_116;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_121;
    zT_33EF6BFB_TypeKind zT_123;
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char zT_130;
    zT_33EF6BFB_TypeKind zT_131;
    zT_42C2D6BF_EUPayload* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_42C2D6BF_EUPayload zT_138;
    zT_42C2D6BF_EUPayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_42C2D6BF_EUPayload zT_143;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned char zT_147;
    zT_338B7C76_TypeRegistry* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_33EF6BFB_TypeKind zT_158;
    zT_42C2D6BF_EUPayload* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_42C2D6BF_EUPayload zT_165;
    zT_338B7C76_TypeRegistry* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned char zT_170;
    zT_33EF6BFB_TypeKind zT_172;
    unsigned char zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    zT_33EF6BFB_TypeKind zT_180;
    unsigned char zT_183;
    zT_33EF6BFB_TypeKind zT_184;
    zT_112BF819_PtrPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_112BF819_PtrPayload zT_191;
    zT_112BF819_PtrPayload* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_112BF819_PtrPayload zT_196;
    unsigned char zT_198;
    unsigned char zT_199;
    unsigned char zT_200;
    unsigned int zT_203;
    unsigned char zT_204;
    unsigned int zT_205;
    unsigned int zT_208;
    unsigned char zT_211;
    unsigned char zT_216;
    unsigned char zT_217;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    unsigned char zT_227;
    unsigned char zT_232;
    unsigned char zT_233;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned char zT_241;
    unsigned char zT_242;
    unsigned char zT_247;
    unsigned char zT_248;
    zT_33EF6BFB_TypeKind zT_254;
    unsigned char zT_257;
    zT_33EF6BFB_TypeKind zT_258;
    unsigned char zT_262;
    unsigned char zT_263;
    unsigned char zT_264;
    unsigned int zT_267;
    unsigned char zT_268;
    unsigned char zT_269;
    unsigned char zT_274;
    unsigned char zT_275;
    zT_0BB2A741_SlicePayload* zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    zT_0BB2A741_SlicePayload zT_284;
    zT_0BB2A741_SlicePayload* zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_0BB2A741_SlicePayload zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char zT_293;
    unsigned char zT_295;
    unsigned char zT_300;
    unsigned char zT_301;
    zT_0BB2A741_SlicePayload* zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    zT_0BB2A741_SlicePayload zT_310;
    zT_0BB2A741_SlicePayload* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_0BB2A741_SlicePayload zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned char zT_319;
    unsigned char zT_320;
    unsigned char zT_325;
    unsigned char zT_326;
    zT_33EF6BFB_TypeKind zT_332;
    unsigned char zT_335;
    zT_33EF6BFB_TypeKind zT_336;
    unsigned char zT_340;
    unsigned char zT_341;
    unsigned char zT_342;
    unsigned int zT_345;
    unsigned char zT_346;
    zT_112BF819_PtrPayload* zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_112BF819_PtrPayload zT_351;
    zT_0BB2A741_SlicePayload* zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    zT_0BB2A741_SlicePayload zT_356;
    zT_D155D06D_Type* zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    zT_D155D06D_Type zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    zT_E834303C_ArrayPayload* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    zT_E834303C_ArrayPayload zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned char zT_373;
    zT_33EF6BFB_TypeKind zT_375;
    unsigned char zT_378;
    zT_33EF6BFB_TypeKind zT_379;
    unsigned char zT_383;
    unsigned char zT_384;
    unsigned char zT_385;
    unsigned int zT_388;
    unsigned char zT_389;
    unsigned char zT_390;
    unsigned char zT_395;
    unsigned char zT_396;
    zT_112BF819_PtrPayload* zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    zT_112BF819_PtrPayload zT_405;
    zT_112BF819_PtrPayload* zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    zT_112BF819_PtrPayload zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned char zT_414;
    unsigned char zT_416;
    unsigned char zT_421;
    unsigned char zT_422;
    zT_112BF819_PtrPayload* zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    zT_112BF819_PtrPayload zT_431;
    zT_112BF819_PtrPayload* zT_433;
    unsigned int zT_434;
    unsigned int zT_435;
    zT_112BF819_PtrPayload zT_436;
    unsigned int zT_437;
    unsigned int zT_438;
    unsigned char zT_440;
    unsigned char zT_441;
    unsigned char zT_446;
    unsigned char zT_447;
    zT_33EF6BFB_TypeKind zT_453;
    unsigned char zT_456;
    zT_33EF6BFB_TypeKind zT_457;
    unsigned char zT_461;
    unsigned char zT_462;
    unsigned char zT_463;
    unsigned int zT_466;
    unsigned char zT_467;
    zT_E834303C_ArrayPayload* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    zT_E834303C_ArrayPayload zT_472;
    zT_0BB2A741_SlicePayload* zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_0BB2A741_SlicePayload zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned char zT_481;
    unsigned char zT_483;
    unsigned char zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned char zT_492;
    zT_33EF6BFB_TypeKind zT_494;
    unsigned char zT_497;
    zT_33EF6BFB_TypeKind zT_498;
    unsigned char zT_502;
    unsigned char zT_503;
    unsigned char zT_504;
    unsigned int zT_507;
    unsigned char zT_508;
    zT_E834303C_ArrayPayload* zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    zT_E834303C_ArrayPayload zT_513;
    zT_112BF819_PtrPayload* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    zT_112BF819_PtrPayload zT_518;
    unsigned int zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    zT_33EF6BFB_TypeKind zT_524;
    unsigned char zT_527;
    zT_33EF6BFB_TypeKind zT_528;
    unsigned char zT_532;
    unsigned char zT_533;
    unsigned char zT_534;
    unsigned int zT_537;
    unsigned char zT_538;
    zT_112BF819_PtrPayload* zT_540;
    unsigned int zT_541;
    unsigned int zT_542;
    zT_112BF819_PtrPayload zT_543;
    zT_112BF819_PtrPayload* zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    zT_112BF819_PtrPayload zT_548;
    zT_D155D06D_Type* zT_550;
    unsigned int zT_551;
    unsigned int zT_552;
    zT_D155D06D_Type zT_553;
    zT_33EF6BFB_TypeKind zT_554;
    zT_E834303C_ArrayPayload* zT_558;
    unsigned int zT_559;
    unsigned int zT_560;
    zT_E834303C_ArrayPayload zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    unsigned char zT_565;
    zT_33EF6BFB_TypeKind zT_567;
    unsigned char zT_570;
    zT_33EF6BFB_TypeKind zT_571;
    zT_E834303C_ArrayPayload* zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    zT_E834303C_ArrayPayload zT_578;
    zT_E834303C_ArrayPayload* zT_580;
    unsigned int zT_581;
    unsigned int zT_582;
    zT_E834303C_ArrayPayload zT_583;
    unsigned int zT_584;
    unsigned int zT_585;
    unsigned char zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    zT_33EF6BFB_TypeKind zT_592;
    unsigned char zT_595;
    zT_33EF6BFB_TypeKind zT_596;
    unsigned char zT_600;
    unsigned char zT_601;
    unsigned char zT_602;
    unsigned int zT_605;
    unsigned char zT_606;
    zT_0BB2A741_SlicePayload* zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    zT_0BB2A741_SlicePayload zT_611;
    zT_112BF819_PtrPayload* zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    zT_112BF819_PtrPayload zT_616;
    unsigned int zT_617;
    unsigned int zT_618;
    unsigned char zT_620;
    zT_33EF6BFB_TypeKind zT_622;
    unsigned char zT_625;
    zT_33EF6BFB_TypeKind zT_626;
    zT_0B10E8E9_OptionalPayload* zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    zT_0B10E8E9_OptionalPayload zT_633;
    zT_D155D06D_Type* zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    zT_D155D06D_Type zT_638;
    zT_33EF6BFB_TypeKind zT_639;
    zT_338B7C76_TypeRegistry* zT_642;
    unsigned int zT_643;
    unsigned int zT_645;
    unsigned char zT_649;
    unsigned char zT_652;
    unsigned char zT_655;
    zT_33EF6BFB_TypeKind zT_659;
    unsigned char zT_662;
    zT_33EF6BFB_TypeKind zT_663;
    zT_666DC2E1_TuplePayload* zT_667;
    unsigned int zT_668;
    unsigned int zT_669;
    zT_666DC2E1_TuplePayload zT_670;
    zT_666DC2E1_TuplePayload* zT_672;
    unsigned int zT_673;
    unsigned int zT_674;
    zT_666DC2E1_TuplePayload zT_675;
    unsigned short zT_676;
    unsigned short zT_677;
    unsigned char zT_680;
    int zT_682;
    unsigned short zT_683;
    unsigned short zT_684;
    unsigned int* zT_687;
    unsigned int zT_688;
    unsigned int zT_689;
    unsigned int zT_690;
    unsigned int zT_691;
    unsigned char zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    unsigned int* zT_697;
    unsigned int zT_698;
    unsigned int zT_699;
    unsigned int zT_700;
    unsigned int zT_701;
    unsigned char zT_703;
    unsigned int zT_704;
    unsigned int zT_705;
    unsigned int zT_707;
    unsigned char zT_709;
    zT_D155D06D_Type* zT_710;
    unsigned int zT_711;
    zT_D155D06D_Type zT_712;
    zT_33EF6BFB_TypeKind zT_713;
    unsigned char zT_716;
    unsigned int zT_718;
    unsigned char zT_720;
    zT_D155D06D_Type* zT_721;
    unsigned int zT_722;
    zT_D155D06D_Type zT_723;
    zT_33EF6BFB_TypeKind zT_724;
    unsigned char zT_727;
    zT_338B7C76_TypeRegistry* zT_728;
    unsigned int zT_729;
    unsigned int zT_730;
    unsigned char zT_731;
    unsigned char zT_733;
    int zT_734;
    unsigned short zT_735;
    unsigned short zT_736;
    unsigned int zT_737;
    unsigned char zT_739;
    zT_33EF6BFB_TypeKind zT_741;
    unsigned char zT_744;
    zT_33EF6BFB_TypeKind zT_745;
    zT_666DC2E1_TuplePayload* zT_749;
    unsigned int zT_750;
    unsigned int zT_751;
    zT_666DC2E1_TuplePayload zT_752;
    zT_E834303C_ArrayPayload* zT_754;
    unsigned int zT_755;
    unsigned int zT_756;
    zT_E834303C_ArrayPayload zT_757;
    unsigned short zT_758;
    unsigned int zT_760;
    unsigned char zT_763;
    int zT_765;
    unsigned short zT_766;
    unsigned short zT_767;
    zT_338B7C76_TypeRegistry* zT_769;
    unsigned int zT_770;
    unsigned int zT_771;
    unsigned int* zT_772;
    unsigned int zT_773;
    unsigned int zT_774;
    unsigned int zT_775;
    unsigned int zT_776;
    unsigned char zT_778;
    unsigned int zT_779;
    unsigned char zT_782;
    unsigned char zT_784;
    int zT_785;
    unsigned short zT_786;
    unsigned short zT_787;
    unsigned int zT_788;
    unsigned char zT_790;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_107, (unsigned int)sizeof zT_107);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_170, (unsigned int)sizeof zT_170);
    zig_poison_fill((void*)&zT_204, (unsigned int)sizeof zT_204);
    zig_poison_fill((void*)&zT_268, (unsigned int)sizeof zT_268);
    zig_poison_fill((void*)&zT_346, (unsigned int)sizeof zT_346);
    zig_poison_fill((void*)&zT_389, (unsigned int)sizeof zT_389);
    zig_poison_fill((void*)&zT_467, (unsigned int)sizeof zT_467);
    zig_poison_fill((void*)&zT_508, (unsigned int)sizeof zT_508);
    zig_poison_fill((void*)&zT_538, (unsigned int)sizeof zT_538);
    zig_poison_fill((void*)&zT_606, (unsigned int)sizeof zT_606);
    zig_poison_fill((void*)&zT_731, (unsigned int)sizeof zT_731);
    zig_poison_fill((void*)&zT_782, (unsigned int)sizeof zT_782);
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned char es_ok;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    unsigned char qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload s_sl2;
    zT_0BB2A741_SlicePayload t_sl2;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload s_pp2;
    zT_112BF819_PtrPayload t_pp2;
    zT_112BF819_PtrPayload pp;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_D155D06D_Type opt_ty;
    zT_666DC2E1_TuplePayload s_tup;
    zT_666DC2E1_TuplePayload t_tup;
    unsigned char ok;
    unsigned short k;
    unsigned int se;
    unsigned int te;
    zT_666DC2E1_TuplePayload tup;
    z_bb_0:
    if ((unsigned char)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_17 = src.kind;
    if ((unsigned char)(zT_17 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_21 = src.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self;
    zT_26 = target;
    zT_27 = zF_3087E0A5_typeRegistryIsNumer(zT_25, zT_26);
    zT_24 = zT_27;
    goto z_bb_9;
    z_bb_8:
    zT_24 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    zT_29 = src.kind;
    if ((unsigned char)(zT_29 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_32 = target == (unsigned int)(14);
    goto z_bb_14;
    z_bb_13:
    zT_32 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_32) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_36 = self;
    zT_37 = source;
    zT_38 = zF_3290E9C4_typeRegistryIsInteg(zT_36, zT_37);
    if (zT_38) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_40 = self;
    zT_41 = target;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_40, zT_41);
    zT_39 = zT_42;
    goto z_bb_19;
    z_bb_18:
    zT_39 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_39) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_43 = source != (unsigned int)(19);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_46 = self;
    zT_47 = source;
    zT_48 = zF_B664AC19_typeRegistryIsUnsig(zT_46, zT_47);
    zT_49 = self;
    zT_50 = target;
    zT_51 = zF_B664AC19_typeRegistryIsUnsig(zT_49, zT_50);
    if ((unsigned char)(zT_48 == zT_51)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(source == (unsigned int)(15))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_54 = self;
    zT_55 = source;
    zT_56 = zF_655972D5_typeRegistryIntWidt(zT_54, zT_55);
    zT_57 = self;
    zT_58 = target;
    zT_59 = zF_655972D5_typeRegistryIntWidt(zT_57, zT_58);
    zT_53 = zT_56 < zT_59;
    goto z_bb_27;
    z_bb_26:
    zT_53 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_53) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    zT_64 = target == (unsigned int)(16);
    goto z_bb_32;
    z_bb_31:
    zT_64 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_64) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    zT_68 = src.kind;
    if ((unsigned char)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_71 = self;
    zT_72 = target;
    zT_73 = zF_AD61DB1B_typeRegistryIsPoint(zT_71, zT_72);
    if (zT_73) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_83 = src.kind;
    if ((unsigned char)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_75 = tgt.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_79 = tgt.kind;
    if ((unsigned char)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_87 = tgt.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_45;
    z_bb_44:
    zT_86 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_86) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_91 = self->ptr_items;
    zT_92 = tgt.payload_idx;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    tpp = zT_94;
    zT_96 = self->types_items;
    zT_97 = tpp.base;
    zT_98 = (unsigned int)zT_97;
    zT_99 = zT_96[zT_98];
    bt = zT_99;
    zT_100 = bt.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_109 = tgt.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_48:
    zT_103 = self;
    zT_104 = source;
    zT_105 = tpp.base;
    zT_107 = zF_3130DDCF_typeRegistryTypesEq(zT_103, zT_104, zT_105);
    if (zT_107) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    return (unsigned char)(1);
    z_bb_51:
    goto z_bb_49;
    z_bb_52:
    zT_113 = self->opt_items;
    zT_114 = tgt.payload_idx;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zT_113[zT_115];
    opt = zT_116;
    zT_117 = self;
    zT_118 = source;
    zT_119 = opt.payload;
    zT_121 = zF_683AEB7F_typeRegistryIsAssig(zT_117, zT_118, zT_119);
    if (zT_121) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_127 = src.kind;
    if ((unsigned char)(zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_54:
    return (unsigned char)(1);
    z_bb_55:
    zT_123 = src.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    return (unsigned char)(1);
    z_bb_57:
    goto z_bb_53;
    z_bb_58:
    zT_131 = tgt.kind;
    zT_130 = zT_131 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_60;
    z_bb_59:
    zT_130 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_130) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_135 = self->eu_items;
    zT_136 = src.payload_idx;
    zT_137 = (unsigned int)zT_136;
    zT_138 = zT_135[zT_137];
    eu_src = zT_138;
    zT_140 = self->eu_items;
    zT_141 = tgt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    eu_tgt = zT_143;
    zT_145 = eu_src.error_set;
    zT_146 = eu_tgt.error_set;
    zT_147 = zT_145 == zT_146;
    es_ok = zT_147;
    if ((unsigned char)(!es_ok)) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_158 = tgt.kind;
    if ((unsigned char)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_63:
    zT_149 = self;
    zT_150 = eu_src.error_set;
    zT_151 = eu_tgt.error_set;
    zT_154 = zF_E35E11A5_errorSetIsSubset(zT_149, zT_150, zT_151);
    es_ok = zT_154;
    goto z_bb_64;
    z_bb_64:
    if (es_ok) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_155 = eu_src.payload;
    zT_156 = eu_tgt.payload;
    return (unsigned char)(zT_155 == zT_156);
    z_bb_66:
    goto z_bb_62;
    z_bb_67:
    zT_162 = self->eu_items;
    zT_163 = tgt.payload_idx;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zT_162[zT_164];
    eu = zT_165;
    zT_166 = self;
    zT_167 = source;
    zT_168 = eu.payload;
    zT_170 = zF_683AEB7F_typeRegistryIsAssig(zT_166, zT_167, zT_168);
    if (zT_170) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_172 = src.kind;
    if ((unsigned char)(zT_172 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_176 = tgt.kind;
    zT_175 = zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_73;
    z_bb_72:
    zT_175 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_175) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    return (unsigned char)(1);
    z_bb_75:
    zT_180 = src.kind;
    if ((unsigned char)(zT_180 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_184 = tgt.kind;
    zT_183 = zT_184 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_78;
    z_bb_77:
    zT_183 = 0;
    goto z_bb_78;
    z_bb_78:
    if (zT_183) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_188 = self->ptr_items;
    zT_189 = tgt.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    tgt_pp = zT_191;
    zT_193 = self->ptr_items;
    zT_194 = src.payload_idx;
    zT_195 = (unsigned int)zT_194;
    zT_196 = zT_193[zT_195];
    src_pp = zT_196;
    zT_198 = src.flags;
    zT_199 = tgt.flags;
    zT_203 = 2;
    zT_200 = zT_203;
    zT_204 = zF_08C13644_pointerQualifiersMo(zT_198, zT_199, zT_200);
    qok = zT_204;
    zT_205 = tgt_pp.base;
    if ((unsigned char)(zT_205 == (unsigned int)(1))) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_254 = tgt.kind;
    if ((unsigned char)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_81:
    return qok;
    z_bb_82:
    zT_208 = src_pp.base;
    if ((unsigned char)(zT_208 == (unsigned int)(1))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    return qok;
    z_bb_84:
    zT_211 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_211 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_217 = src.flags;
    zT_216 = (unsigned char)(zT_217 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_87;
    z_bb_86:
    zT_216 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_216) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_222 = src_pp.base;
    zT_223 = tgt_pp.base;
    if ((unsigned char)(zT_222 == zT_223)) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    zT_227 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_227 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_90:
    zT_225 = qok;
    goto z_bb_92;
    z_bb_91:
    zT_225 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_225) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned char)(1);
    z_bb_94:
    goto z_bb_89;
    z_bb_95:
    zT_233 = src.flags;
    zT_232 = (unsigned char)(zT_233 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_97;
    z_bb_96:
    zT_232 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_232) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_238 = src_pp.base;
    zT_239 = tgt_pp.base;
    if ((unsigned char)(zT_238 == zT_239)) goto z_bb_100; else goto z_bb_101;
    z_bb_99:
    goto z_bb_80;
    z_bb_100:
    zT_242 = src.flags;
    if ((unsigned char)((unsigned char)(zT_242 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_104; else goto z_bb_103;
    z_bb_101:
    zT_241 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_241) goto z_bb_106; else goto z_bb_107;
    z_bb_103:
    zT_248 = tgt.flags;
    zT_247 = (unsigned char)(zT_248 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_105;
    z_bb_104:
    zT_247 = 1;
    goto z_bb_105;
    z_bb_105:
    zT_241 = zT_247;
    goto z_bb_102;
    z_bb_106:
    return (unsigned char)(1);
    z_bb_107:
    goto z_bb_99;
    z_bb_108:
    zT_258 = src.kind;
    zT_257 = zT_258 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_110;
    z_bb_109:
    zT_257 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_257) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_262 = src.flags;
    zT_263 = tgt.flags;
    zT_267 = 2;
    zT_264 = zT_267;
    zT_268 = zF_08C13644_pointerQualifiersMo(zT_262, zT_263, zT_264);
    qok = zT_268;
    zT_269 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_269 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_332 = tgt.kind;
    if ((unsigned char)(zT_332 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_136; else goto z_bb_137;
    z_bb_113:
    zT_275 = src.flags;
    zT_274 = (unsigned char)(zT_275 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_115;
    z_bb_114:
    zT_274 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_274) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_281 = self->slice_items;
    zT_282 = src.payload_idx;
    zT_283 = (unsigned int)zT_282;
    zT_284 = zT_281[zT_283];
    s_sl = zT_284;
    zT_286 = self->slice_items;
    zT_287 = tgt.payload_idx;
    zT_288 = (unsigned int)zT_287;
    zT_289 = zT_286[zT_288];
    t_sl = zT_289;
    zT_290 = s_sl.elem;
    zT_291 = t_sl.elem;
    if ((unsigned char)(zT_290 == zT_291)) goto z_bb_118; else goto z_bb_119;
    z_bb_117:
    zT_295 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_295 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_123; else goto z_bb_124;
    z_bb_118:
    zT_293 = qok;
    goto z_bb_120;
    z_bb_119:
    zT_293 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_293) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    return (unsigned char)(1);
    z_bb_122:
    goto z_bb_117;
    z_bb_123:
    zT_301 = src.flags;
    zT_300 = (unsigned char)(zT_301 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_125;
    z_bb_124:
    zT_300 = 0;
    goto z_bb_125;
    z_bb_125:
    if (zT_300) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_307 = self->slice_items;
    zT_308 = src.payload_idx;
    zT_309 = (unsigned int)zT_308;
    zT_310 = zT_307[zT_309];
    s_sl2 = zT_310;
    zT_312 = self->slice_items;
    zT_313 = tgt.payload_idx;
    zT_314 = (unsigned int)zT_313;
    zT_315 = zT_312[zT_314];
    t_sl2 = zT_315;
    zT_316 = s_sl2.elem;
    zT_317 = t_sl2.elem;
    if ((unsigned char)(zT_316 == zT_317)) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_112;
    z_bb_128:
    zT_320 = src.flags;
    if ((unsigned char)((unsigned char)(zT_320 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_132; else goto z_bb_131;
    z_bb_129:
    zT_319 = 0;
    goto z_bb_130;
    z_bb_130:
    if (zT_319) goto z_bb_134; else goto z_bb_135;
    z_bb_131:
    zT_326 = tgt.flags;
    zT_325 = (unsigned char)(zT_326 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_133;
    z_bb_132:
    zT_325 = 1;
    goto z_bb_133;
    z_bb_133:
    zT_319 = zT_325;
    goto z_bb_130;
    z_bb_134:
    return (unsigned char)(1);
    z_bb_135:
    goto z_bb_127;
    z_bb_136:
    zT_336 = src.kind;
    zT_335 = zT_336 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_138;
    z_bb_137:
    zT_335 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_335) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_340 = src.flags;
    zT_341 = tgt.flags;
    zT_345 = 2;
    zT_342 = zT_345;
    zT_346 = zF_08C13644_pointerQualifiersMo(zT_340, zT_341, zT_342);
    qok = zT_346;
    zT_348 = self->ptr_items;
    zT_349 = src.payload_idx;
    zT_350 = (unsigned int)zT_349;
    zT_351 = zT_348[zT_350];
    src_pp = zT_351;
    zT_353 = self->slice_items;
    zT_354 = tgt.payload_idx;
    zT_355 = (unsigned int)zT_354;
    zT_356 = zT_353[zT_355];
    sl = zT_356;
    zT_358 = self->types_items;
    zT_359 = src_pp.base;
    zT_360 = (unsigned int)zT_359;
    zT_361 = zT_358[zT_360];
    src_pointee = zT_361;
    zT_362 = src_pointee.kind;
    if ((unsigned char)(zT_362 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_375 = tgt.kind;
    if ((unsigned char)(zT_375 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_148; else goto z_bb_149;
    z_bb_141:
    zT_366 = self->array_items;
    zT_367 = src_pointee.payload_idx;
    zT_368 = (unsigned int)zT_367;
    zT_369 = zT_366[zT_368];
    arr = zT_369;
    zT_370 = arr.elem;
    zT_371 = sl.elem;
    if ((unsigned char)(zT_370 == zT_371)) goto z_bb_143; else goto z_bb_144;
    z_bb_142:
    goto z_bb_140;
    z_bb_143:
    zT_373 = qok;
    goto z_bb_145;
    z_bb_144:
    zT_373 = 0;
    goto z_bb_145;
    z_bb_145:
    if (zT_373) goto z_bb_146; else goto z_bb_147;
    z_bb_146:
    return (unsigned char)(1);
    z_bb_147:
    goto z_bb_142;
    z_bb_148:
    zT_379 = src.kind;
    zT_378 = zT_379 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_150;
    z_bb_149:
    zT_378 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_378) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_383 = src.flags;
    zT_384 = tgt.flags;
    zT_388 = 2;
    zT_385 = zT_388;
    zT_389 = zF_08C13644_pointerQualifiersMo(zT_383, zT_384, zT_385);
    qok = zT_389;
    zT_390 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_390 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    zT_453 = src.kind;
    if ((unsigned char)(zT_453 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_176; else goto z_bb_177;
    z_bb_153:
    zT_396 = src.flags;
    zT_395 = (unsigned char)(zT_396 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_155;
    z_bb_154:
    zT_395 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_395) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_402 = self->ptr_items;
    zT_403 = src.payload_idx;
    zT_404 = (unsigned int)zT_403;
    zT_405 = zT_402[zT_404];
    s_pp = zT_405;
    zT_407 = self->ptr_items;
    zT_408 = tgt.payload_idx;
    zT_409 = (unsigned int)zT_408;
    zT_410 = zT_407[zT_409];
    t_pp = zT_410;
    zT_411 = s_pp.base;
    zT_412 = t_pp.base;
    if ((unsigned char)(zT_411 == zT_412)) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_416 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_416 & (unsigned int)(2)) != (unsigned char)(0))) goto z_bb_163; else goto z_bb_164;
    z_bb_158:
    zT_414 = qok;
    goto z_bb_160;
    z_bb_159:
    zT_414 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_414) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (unsigned char)(1);
    z_bb_162:
    goto z_bb_157;
    z_bb_163:
    zT_422 = src.flags;
    zT_421 = (unsigned char)(zT_422 & (unsigned int)(2)) == (unsigned char)(0);
    goto z_bb_165;
    z_bb_164:
    zT_421 = 0;
    goto z_bb_165;
    z_bb_165:
    if (zT_421) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    zT_428 = self->ptr_items;
    zT_429 = src.payload_idx;
    zT_430 = (unsigned int)zT_429;
    zT_431 = zT_428[zT_430];
    s_pp2 = zT_431;
    zT_433 = self->ptr_items;
    zT_434 = tgt.payload_idx;
    zT_435 = (unsigned int)zT_434;
    zT_436 = zT_433[zT_435];
    t_pp2 = zT_436;
    zT_437 = s_pp2.base;
    zT_438 = t_pp2.base;
    if ((unsigned char)(zT_437 == zT_438)) goto z_bb_168; else goto z_bb_169;
    z_bb_167:
    goto z_bb_152;
    z_bb_168:
    zT_441 = src.flags;
    if ((unsigned char)((unsigned char)(zT_441 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_172; else goto z_bb_171;
    z_bb_169:
    zT_440 = 0;
    goto z_bb_170;
    z_bb_170:
    if (zT_440) goto z_bb_174; else goto z_bb_175;
    z_bb_171:
    zT_447 = tgt.flags;
    zT_446 = (unsigned char)(zT_447 & (unsigned char)(1)) != (unsigned char)(0);
    goto z_bb_173;
    z_bb_172:
    zT_446 = 1;
    goto z_bb_173;
    z_bb_173:
    zT_440 = zT_446;
    goto z_bb_170;
    z_bb_174:
    return (unsigned char)(1);
    z_bb_175:
    goto z_bb_167;
    z_bb_176:
    zT_457 = tgt.kind;
    zT_456 = zT_457 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_178;
    z_bb_177:
    zT_456 = 0;
    goto z_bb_178;
    z_bb_178:
    if (zT_456) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_461 = src.flags;
    zT_462 = tgt.flags;
    zT_466 = 2;
    zT_463 = zT_466;
    zT_467 = zF_08C13644_pointerQualifiersMo(zT_461, zT_462, zT_463);
    qok = zT_467;
    zT_469 = self->array_items;
    zT_470 = src.payload_idx;
    zT_471 = (unsigned int)zT_470;
    zT_472 = zT_469[zT_471];
    arr = zT_472;
    zT_474 = self->slice_items;
    zT_475 = tgt.payload_idx;
    zT_476 = (unsigned int)zT_475;
    zT_477 = zT_474[zT_476];
    sl = zT_477;
    zT_478 = arr.elem;
    zT_479 = sl.elem;
    if ((unsigned char)(zT_478 == zT_479)) goto z_bb_181; else goto z_bb_182;
    z_bb_180:
    zT_494 = src.kind;
    if ((unsigned char)(zT_494 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_194; else goto z_bb_195;
    z_bb_181:
    zT_481 = qok;
    goto z_bb_183;
    z_bb_182:
    zT_481 = 0;
    goto z_bb_183;
    z_bb_183:
    if (zT_481) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    return (unsigned char)(1);
    z_bb_185:
    zT_483 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_483 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_489 = arr.elem;
    zT_490 = sl.elem;
    zT_488 = zT_489 == zT_490;
    goto z_bb_188;
    z_bb_187:
    zT_488 = 0;
    goto z_bb_188;
    z_bb_188:
    if (zT_488) goto z_bb_189; else goto z_bb_190;
    z_bb_189:
    zT_492 = qok;
    goto z_bb_191;
    z_bb_190:
    zT_492 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_492) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    return (unsigned char)(1);
    z_bb_193:
    goto z_bb_180;
    z_bb_194:
    zT_498 = tgt.kind;
    zT_497 = zT_498 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_196;
    z_bb_195:
    zT_497 = 0;
    goto z_bb_196;
    z_bb_196:
    if (zT_497) goto z_bb_197; else goto z_bb_198;
    z_bb_197:
    zT_502 = src.flags;
    zT_503 = tgt.flags;
    zT_507 = 2;
    zT_504 = zT_507;
    zT_508 = zF_08C13644_pointerQualifiersMo(zT_502, zT_503, zT_504);
    qok = zT_508;
    zT_510 = self->array_items;
    zT_511 = src.payload_idx;
    zT_512 = (unsigned int)zT_511;
    zT_513 = zT_510[zT_512];
    arr = zT_513;
    zT_515 = self->ptr_items;
    zT_516 = tgt.payload_idx;
    zT_517 = (unsigned int)zT_516;
    zT_518 = zT_515[zT_517];
    pp = zT_518;
    zT_519 = arr.elem;
    zT_520 = pp.base;
    if ((unsigned char)(zT_519 == zT_520)) goto z_bb_199; else goto z_bb_200;
    z_bb_198:
    zT_524 = src.kind;
    if ((unsigned char)(zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_204; else goto z_bb_205;
    z_bb_199:
    zT_522 = qok;
    goto z_bb_201;
    z_bb_200:
    zT_522 = 0;
    goto z_bb_201;
    z_bb_201:
    if (zT_522) goto z_bb_202; else goto z_bb_203;
    z_bb_202:
    return (unsigned char)(1);
    z_bb_203:
    goto z_bb_198;
    z_bb_204:
    zT_528 = tgt.kind;
    zT_527 = zT_528 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_206;
    z_bb_205:
    zT_527 = 0;
    goto z_bb_206;
    z_bb_206:
    if (zT_527) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_532 = src.flags;
    zT_533 = tgt.flags;
    zT_537 = 2;
    zT_534 = zT_537;
    zT_538 = zF_08C13644_pointerQualifiersMo(zT_532, zT_533, zT_534);
    qok = zT_538;
    zT_540 = self->ptr_items;
    zT_541 = src.payload_idx;
    zT_542 = (unsigned int)zT_541;
    zT_543 = zT_540[zT_542];
    sp = zT_543;
    zT_545 = self->ptr_items;
    zT_546 = tgt.payload_idx;
    zT_547 = (unsigned int)zT_546;
    zT_548 = zT_545[zT_547];
    tp = zT_548;
    zT_550 = self->types_items;
    zT_551 = sp.base;
    zT_552 = (unsigned int)zT_551;
    zT_553 = zT_550[zT_552];
    spo = zT_553;
    zT_554 = spo.kind;
    if ((unsigned char)(zT_554 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_209; else goto z_bb_210;
    z_bb_208:
    zT_567 = src.kind;
    if ((unsigned char)(zT_567 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_216; else goto z_bb_217;
    z_bb_209:
    zT_558 = self->array_items;
    zT_559 = spo.payload_idx;
    zT_560 = (unsigned int)zT_559;
    zT_561 = zT_558[zT_560];
    arr = zT_561;
    zT_562 = arr.elem;
    zT_563 = tp.base;
    if ((unsigned char)(zT_562 == zT_563)) goto z_bb_211; else goto z_bb_212;
    z_bb_210:
    goto z_bb_208;
    z_bb_211:
    zT_565 = qok;
    goto z_bb_213;
    z_bb_212:
    zT_565 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_565) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    return (unsigned char)(1);
    z_bb_215:
    goto z_bb_210;
    z_bb_216:
    zT_571 = tgt.kind;
    zT_570 = zT_571 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_218;
    z_bb_217:
    zT_570 = 0;
    goto z_bb_218;
    z_bb_218:
    if (zT_570) goto z_bb_219; else goto z_bb_220;
    z_bb_219:
    zT_575 = self->array_items;
    zT_576 = src.payload_idx;
    zT_577 = (unsigned int)zT_576;
    zT_578 = zT_575[zT_577];
    s_arr = zT_578;
    zT_580 = self->array_items;
    zT_581 = tgt.payload_idx;
    zT_582 = (unsigned int)zT_581;
    zT_583 = zT_580[zT_582];
    t_arr = zT_583;
    zT_584 = s_arr.elem;
    zT_585 = t_arr.elem;
    if ((unsigned char)(zT_584 == zT_585)) goto z_bb_221; else goto z_bb_222;
    z_bb_220:
    zT_592 = src.kind;
    if ((unsigned char)(zT_592 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_226; else goto z_bb_227;
    z_bb_221:
    zT_588 = s_arr.length;
    zT_589 = t_arr.length;
    zT_587 = zT_588 == zT_589;
    goto z_bb_223;
    z_bb_222:
    zT_587 = 0;
    goto z_bb_223;
    z_bb_223:
    if (zT_587) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    return (unsigned char)(1);
    z_bb_225:
    goto z_bb_220;
    z_bb_226:
    zT_596 = tgt.kind;
    zT_595 = zT_596 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_228;
    z_bb_227:
    zT_595 = 0;
    goto z_bb_228;
    z_bb_228:
    if (zT_595) goto z_bb_229; else goto z_bb_230;
    z_bb_229:
    zT_600 = src.flags;
    zT_601 = tgt.flags;
    zT_605 = 2;
    zT_602 = zT_605;
    zT_606 = zF_08C13644_pointerQualifiersMo(zT_600, zT_601, zT_602);
    qok = zT_606;
    zT_608 = self->slice_items;
    zT_609 = src.payload_idx;
    zT_610 = (unsigned int)zT_609;
    zT_611 = zT_608[zT_610];
    sl = zT_611;
    zT_613 = self->ptr_items;
    zT_614 = tgt.payload_idx;
    zT_615 = (unsigned int)zT_614;
    zT_616 = zT_613[zT_615];
    pp = zT_616;
    zT_617 = sl.elem;
    zT_618 = pp.base;
    if ((unsigned char)(zT_617 == zT_618)) goto z_bb_231; else goto z_bb_232;
    z_bb_230:
    zT_622 = src.kind;
    if ((unsigned char)(zT_622 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_236; else goto z_bb_237;
    z_bb_231:
    zT_620 = qok;
    goto z_bb_233;
    z_bb_232:
    zT_620 = 0;
    goto z_bb_233;
    z_bb_233:
    if (zT_620) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (unsigned char)(1);
    z_bb_235:
    goto z_bb_230;
    z_bb_236:
    zT_626 = tgt.kind;
    zT_625 = zT_626 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_238;
    z_bb_237:
    zT_625 = 0;
    goto z_bb_238;
    z_bb_238:
    if (zT_625) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    zT_630 = self->opt_items;
    zT_631 = tgt.payload_idx;
    zT_632 = (unsigned int)zT_631;
    zT_633 = zT_630[zT_632];
    opt = zT_633;
    zT_635 = self->types_items;
    zT_636 = opt.payload;
    zT_637 = (unsigned int)zT_636;
    zT_638 = zT_635[zT_637];
    opt_ty = zT_638;
    zT_639 = opt_ty.kind;
    if ((unsigned char)(zT_639 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_241; else goto z_bb_242;
    z_bb_240:
    if ((unsigned char)(source == (unsigned int)(8))) goto z_bb_243; else goto z_bb_244;
    z_bb_241:
    zT_642 = self;
    zT_643 = source;
    zT_645 = opt.payload;
    self = zT_642;
    source = zT_643;
    target = zT_645;
    goto z_bb_0;
    z_bb_242:
    goto z_bb_240;
    z_bb_243:
    zT_649 = target == (unsigned int)(14);
    goto z_bb_245;
    z_bb_244:
    zT_649 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_649) goto z_bb_247; else goto z_bb_246;
    z_bb_246:
    if ((unsigned char)(source == (unsigned int)(14))) goto z_bb_249; else goto z_bb_250;
    z_bb_247:
    zT_652 = 1;
    goto z_bb_248;
    z_bb_248:
    if (zT_652) goto z_bb_252; else goto z_bb_253;
    z_bb_249:
    zT_655 = target == (unsigned int)(8);
    goto z_bb_251;
    z_bb_250:
    zT_655 = 0;
    goto z_bb_251;
    z_bb_251:
    zT_652 = zT_655;
    goto z_bb_248;
    z_bb_252:
    return (unsigned char)(1);
    z_bb_253:
    zT_659 = src.kind;
    if ((unsigned char)(zT_659 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_254; else goto z_bb_255;
    z_bb_254:
    zT_663 = tgt.kind;
    zT_662 = zT_663 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type);
    goto z_bb_256;
    z_bb_255:
    zT_662 = 0;
    goto z_bb_256;
    z_bb_256:
    if (zT_662) goto z_bb_257; else goto z_bb_258;
    z_bb_257:
    zT_667 = self->tup_items;
    zT_668 = src.payload_idx;
    zT_669 = (unsigned int)zT_668;
    zT_670 = zT_667[zT_669];
    s_tup = zT_670;
    zT_672 = self->tup_items;
    zT_673 = tgt.payload_idx;
    zT_674 = (unsigned int)zT_673;
    zT_675 = zT_672[zT_674];
    t_tup = zT_675;
    zT_676 = s_tup.elems_count;
    zT_677 = t_tup.elems_count;
    if ((unsigned char)(zT_676 == zT_677)) goto z_bb_259; else goto z_bb_260;
    z_bb_258:
    zT_741 = src.kind;
    if ((unsigned char)(zT_741 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_279; else goto z_bb_280;
    z_bb_259:
    zT_680 = 1;
    ok = zT_680;
    zT_682 = 0;
    zT_683 = (unsigned short)zT_682;
    k = zT_683;
    goto z_bb_261;
    z_bb_260:
    goto z_bb_258;
    z_bb_261:
    zT_684 = s_tup.elems_count;
    if ((unsigned char)(k < zT_684)) goto z_bb_262; else goto z_bb_263;
    z_bb_262:
    zT_687 = self->xt_items;
    zT_688 = s_tup.elems_start;
    zT_689 = (unsigned int)k;
    zT_690 = zig_wrap_add_u(((zu64)(zT_688)), ((zu64)(zT_689)), 32u);
    zT_691 = zig_overflow_flag_add_u(((zu64)(zT_688)), ((zu64)(zT_689)), 32u);
    zT_693 = zT_691 == (unsigned int)(0);
    if (!(zT_693)) { pal_trap(); }
    zT_694 = (unsigned int)zT_690;
    zT_695 = zT_687[zT_694];
    se = zT_695;
    zT_697 = self->xt_items;
    zT_698 = t_tup.elems_start;
    zT_699 = (unsigned int)k;
    zT_700 = zig_wrap_add_u(((zu64)(zT_698)), ((zu64)(zT_699)), 32u);
    zT_701 = zig_overflow_flag_add_u(((zu64)(zT_698)), ((zu64)(zT_699)), 32u);
    zT_703 = zT_701 == (unsigned int)(0);
    if (!(zT_703)) { pal_trap(); }
    zT_704 = (unsigned int)zT_700;
    zT_705 = zT_697[zT_704];
    te = zT_705;
    zT_707 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)se) < zT_707)) goto z_bb_265; else goto z_bb_266;
    z_bb_263:
    if (ok) goto z_bb_277; else goto z_bb_278;
    z_bb_264:
    zT_734 = 1;
    zT_735 = (unsigned short)zT_734;
    zT_736 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_735)), 16u);
    zT_737 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_735)), 16u);
    zT_739 = zT_737 == (unsigned int)(0);
    if (!(zT_739)) { pal_trap(); }
    k = zT_736;
    goto z_bb_261;
    z_bb_265:
    zT_710 = self->types_items;
    zT_711 = (unsigned int)se;
    zT_712 = zT_710[zT_711];
    zT_713 = zT_712.kind;
    zT_709 = zT_713 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_267;
    z_bb_266:
    zT_709 = 0;
    goto z_bb_267;
    z_bb_267:
    if (zT_709) goto z_bb_268; else goto z_bb_269;
    z_bb_268:
    zT_716 = 0;
    ok = zT_716;
    goto z_bb_263;
    z_bb_269:
    zT_718 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)te) < zT_718)) goto z_bb_270; else goto z_bb_271;
    z_bb_270:
    zT_721 = self->types_items;
    zT_722 = (unsigned int)te;
    zT_723 = zT_721[zT_722];
    zT_724 = zT_723.kind;
    zT_720 = zT_724 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_272;
    z_bb_271:
    zT_720 = 0;
    goto z_bb_272;
    z_bb_272:
    if (zT_720) goto z_bb_273; else goto z_bb_274;
    z_bb_273:
    zT_727 = 0;
    ok = zT_727;
    goto z_bb_263;
    z_bb_274:
    zT_728 = self;
    zT_729 = se;
    zT_730 = te;
    zT_731 = zF_683AEB7F_typeRegistryIsAssig(zT_728, zT_729, zT_730);
    if ((unsigned char)(!zT_731)) goto z_bb_275; else goto z_bb_276;
    z_bb_275:
    zT_733 = 0;
    ok = zT_733;
    goto z_bb_263;
    z_bb_276:
    goto z_bb_264;
    z_bb_277:
    return (unsigned char)(1);
    z_bb_278:
    goto z_bb_260;
    z_bb_279:
    zT_745 = tgt.kind;
    zT_744 = zT_745 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_281;
    z_bb_280:
    zT_744 = 0;
    goto z_bb_281;
    z_bb_281:
    if (zT_744) goto z_bb_282; else goto z_bb_283;
    z_bb_282:
    zT_749 = self->tup_items;
    zT_750 = src.payload_idx;
    zT_751 = (unsigned int)zT_750;
    zT_752 = zT_749[zT_751];
    tup = zT_752;
    zT_754 = self->array_items;
    zT_755 = tgt.payload_idx;
    zT_756 = (unsigned int)zT_755;
    zT_757 = zT_754[zT_756];
    arr = zT_757;
    zT_758 = tup.elems_count;
    zT_760 = arr.length;
    if ((unsigned char)((unsigned int)((unsigned int)zT_758) == zT_760)) goto z_bb_284; else goto z_bb_285;
    z_bb_283:
    return (unsigned char)(0);
    z_bb_284:
    zT_763 = 1;
    ok = zT_763;
    zT_765 = 0;
    zT_766 = (unsigned short)zT_765;
    k = zT_766;
    goto z_bb_286;
    z_bb_285:
    goto z_bb_283;
    z_bb_286:
    zT_767 = tup.elems_count;
    if ((unsigned char)(k < zT_767)) goto z_bb_287; else goto z_bb_288;
    z_bb_287:
    zT_769 = self;
    zT_772 = self->xt_items;
    zT_773 = tup.elems_start;
    zT_774 = (unsigned int)k;
    zT_775 = zig_wrap_add_u(((zu64)(zT_773)), ((zu64)(zT_774)), 32u);
    zT_776 = zig_overflow_flag_add_u(((zu64)(zT_773)), ((zu64)(zT_774)), 32u);
    zT_778 = zT_776 == (unsigned int)(0);
    if (!(zT_778)) { pal_trap(); }
    zT_779 = (unsigned int)zT_775;
    zT_770 = zT_772[zT_779];
    zT_771 = arr.elem;
    zT_782 = zF_683AEB7F_typeRegistryIsAssig(zT_769, zT_770, zT_771);
    if ((unsigned char)(!zT_782)) goto z_bb_290; else goto z_bb_291;
    z_bb_288:
    if (ok) goto z_bb_292; else goto z_bb_293;
    z_bb_289:
    zT_785 = 1;
    zT_786 = (unsigned short)zT_785;
    zT_787 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_786)), 16u);
    zT_788 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_786)), 16u);
    zT_790 = zT_788 == (unsigned int)(0);
    if (!(zT_790)) { pal_trap(); }
    k = zT_787;
    goto z_bb_286;
    z_bb_290:
    zT_784 = 0;
    ok = zT_784;
    goto z_bb_288;
    z_bb_291:
    goto z_bb_289;
    z_bb_292:
    return (unsigned char)(1);
    z_bb_293:
    goto z_bb_285;
}

/* errorSetIsSubset */
unsigned char zF_E35E11A5_errorSetIsSubset(zT_338B7C76_TypeRegistry* self, unsigned int src, unsigned int tgt) {
    unsigned int zT_12;
    unsigned int zT_16;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_0B73C507_ErrorSetPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B73C507_ErrorSetPayload zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned short zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_54;
    unsigned int zT_55;
    int zT_59;
    unsigned int zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_71;
    int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zT_D155D06D_Type sty;
    zT_D155D06D_Type tty;
    zT_0B73C507_ErrorSetPayload sp;
    unsigned int sstart;
    unsigned int scount;
    unsigned int i;
    if ((unsigned char)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    if ((unsigned char)(src == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    if ((unsigned char)(tgt == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_12 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src) >= zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_16 = self->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tgt) >= zT_16)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_20 = self->types_items;
    zT_21 = (unsigned int)src;
    zT_22 = zT_20[zT_21];
    sty = zT_22;
    zT_24 = self->types_items;
    zT_25 = (unsigned int)tgt;
    zT_26 = zT_24[zT_25];
    tty = zT_26;
    zT_27 = sty.kind;
    if ((unsigned char)(zT_27 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_31 = tty.kind;
    if ((unsigned char)(zT_31 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_35 = sty.payload_idx;
    zT_37 = self->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_35) >= zT_37)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_41 = self->es_items;
    zT_42 = sty.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    sp = zT_44;
    zT_46 = sp.tags_start;
    zT_47 = (unsigned int)zT_46;
    sstart = zT_47;
    zT_49 = sp.tags_count;
    zT_50 = (unsigned int)zT_49;
    scount = zT_50;
    zT_51 = zig_wrap_add_u(((zu64)(sstart)), ((zu64)(scount)), 32u);
    zT_52 = zig_overflow_flag_add_u(((zu64)(sstart)), ((zu64)(scount)), 32u);
    zT_54 = zT_52 == (unsigned int)(0);
    if (!(zT_54)) { pal_trap(); }
    zT_55 = self->xn_len;
    if ((unsigned char)(zT_51 > zT_55)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_59 = 0;
    zT_60 = (unsigned int)zT_59;
    i = zT_60;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(i < scount)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = self;
    zT_63 = tgt;
    zT_65 = self->xn_items;
    zT_66 = zig_wrap_add_u(((zu64)(sstart)), ((zu64)(i)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(sstart)), ((zu64)(i)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_64 = zT_65[zT_66];
    zT_71 = zF_D2ECD176_typeRegistryErrorSe(zT_62, zT_63, zT_64);
    if ((unsigned char)(zT_71 == (unsigned int)(4294967295u))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    zT_75 = 1;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_76)), 32u);
    zT_78 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_76)), 32u);
    zT_80 = zT_78 == (unsigned int)(0);
    if (!(zT_80)) { pal_trap(); }
    i = zT_77;
    goto z_bb_19;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    goto z_bb_22;
}

/* canLiteralFitInType */
unsigned char zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    unsigned char zT_6;
    unsigned char zT_13;
    zT_C69B2266_i64 zT_18;
    zT_C69B2266_i64 zT_19;
    zT_C69B2266_i64 zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_35;
    unsigned char zT_42;
    unsigned char zT_49;
    zT_C69B2266_i64 zT_58;
    zT_C69B2266_i64 zT_59;
    zT_C69B2266_i64 zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned char zT_65;
    unsigned char zT_72;
    unsigned char zT_77;
    if ((unsigned char)(target == (unsigned int)(4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-128))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(target == (unsigned int)(5))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_6 = value <= (zT_C69B2266_i64)(127);
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    if ((unsigned char)(value >= (zT_C69B2266_i64)((zT_C69B2266_i64)-32768))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(target == (unsigned int)(6))) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_13 = value <= (zT_C69B2266_i64)(32767);
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    zT_18 = (zT_C69B2266_i64)-2147483647;
    zT_19 = 1;
    zT_20 = zig_wrap_sub_s(((z64)(zT_18)), ((z64)(zT_19)), 64u);
    zT_21 = zig_overflow_flag_sub_s(((z64)(zT_18)), ((z64)(zT_19)), 64u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    if ((unsigned char)(value >= zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    if ((unsigned char)(target == (unsigned int)(7))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_25 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_15;
    z_bb_14:
    zT_25 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_25;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    if ((unsigned char)(target == (unsigned int)(8))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((unsigned char)(target == (unsigned int)(9))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_35 = value <= (zT_C69B2266_i64)(255);
    goto z_bb_22;
    z_bb_21:
    zT_35 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_35;
    z_bb_23:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    if ((unsigned char)(target == (unsigned int)(10))) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_42 = value <= (zT_C69B2266_i64)(65535);
    goto z_bb_27;
    z_bb_26:
    zT_42 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_42;
    z_bb_28:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    if ((unsigned char)(target == (unsigned int)(11))) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_49 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_32;
    z_bb_31:
    zT_49 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_49;
    z_bb_33:
    return (unsigned char)(value >= (zT_C69B2266_i64)(0));
    z_bb_34:
    if ((unsigned char)(target == (unsigned int)(12))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_58 = (zT_C69B2266_i64)-2147483647;
    zT_59 = 1;
    zT_60 = zig_wrap_sub_s(((z64)(zT_58)), ((z64)(zT_59)), 64u);
    zT_61 = zig_overflow_flag_sub_s(((z64)(zT_58)), ((z64)(zT_59)), 64u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    if ((unsigned char)(value >= zT_60)) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((unsigned char)(target == (unsigned int)(13))) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_65 = value <= (zT_C69B2266_i64)(2147483647);
    goto z_bb_39;
    z_bb_38:
    zT_65 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_65;
    z_bb_40:
    if ((unsigned char)(value >= (zT_C69B2266_i64)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    if ((unsigned char)(target == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_72 = value <= (zT_C69B2266_i64)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_72 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_72;
    z_bb_45:
    zT_77 = target == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_77 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_77) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return (unsigned char)(1);
    z_bb_49:
    return (unsigned char)(0);
}

/* __module_init */
void zF_780653D2___module_init_9(void) {
    zT_CEC2984A_NameMangler zT_0;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_CEC2984A_NameMangler = zT_0;
    return;
}

/* EOF */
