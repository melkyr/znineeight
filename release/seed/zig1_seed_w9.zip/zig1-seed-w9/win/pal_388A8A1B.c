#include "pal_388A8A1B.h"
void* fopen();
int fseek();
int ftell();
int fclose();
int fseek();
int fclose();
unsigned int fread();
int fclose();
void* fopen();
int fclose();
int pal_dir_exists();
int write();
int write();
unsigned int pal_file_open();
int pal_file_write();
int pal_file_read();
int pal_file_close();
void* fopen();
int fclose();
unsigned int fwrite();
unsigned int fread();
int fseek();
int pal_get_default_lib_path();
void c_exit();
int const zG_B95DA1F7_SEEK_END = (int)(2);
int const zG_0DBDF58A_SEEK_SET = (int)(0);
unsigned char* const zG_970FEF1B_MODE_READ = (unsigned char*)"rb";
unsigned int const zG_CC81CC5F_INVALID_FD = (unsigned int)(4294967295u);
int const zG_56B712B8_FILE_OPEN_WRITE = (int)(0);
int const zG_84626E91_FILE_OPEN_READ = (int)(1);
int zG_F46B0200_saved_argc;
unsigned char** zG_096B230F_saved_argv;
unsigned int zG_EE253928_g_markers_enabled;
unsigned int const zG_0669C4FA_g_markers_debug = (unsigned int)(0);
/* readFile */
zT_19E1FCCD_Opt_484 zF_5B859C63_readFile(zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    int zT_25;
    zT_19E1FCCD_Opt_484 zT_27;
    int zT_28;
    unsigned char zT_29;
    unsigned char zT_31;
    unsigned char* zT_33;
    unsigned char* zT_34;
    int zT_35;
    unsigned char zT_37;
    unsigned char* zT_38;
    zT_94D5F27B_Opt_455 zT_40;
    unsigned char zT_41;
    void* zT_42;
    zT_19E1FCCD_Opt_484 zT_43;
    void* zT_45;
    int zT_47;
    int zT_48;
    unsigned int zT_50;
    int zT_51;
    void* zT_53;
    int zT_54;
    int zT_55;
    void* zT_57;
    int zT_58;
    zT_19E1FCCD_Opt_484 zT_59;
    void* zT_60;
    int zT_62;
    int zT_63;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_68;
    zT_3E40CD83_Sand* zT_70;
    zT_FDFD82FD_EU_362 zT_75;
    unsigned char zT_76;
    unsigned char* zT_77;
    void* zT_78;
    int zT_79;
    zT_19E1FCCD_Opt_484 zT_80;
    unsigned char* zT_83;
    unsigned char* zT_85;
    unsigned int zT_87;
    void* zT_88;
    int zT_89;
    unsigned int zT_91;
    void* zT_92;
    int zT_93;
    zT_19E1FCCD_Opt_484 zT_95;
    int zT_96;
    unsigned char* zT_97;
    unsigned int zT_98;
    unsigned char zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    zT_19E1FCCD_Opt_484 zT_101;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    void* f;
    int size;
    unsigned int sz;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int read;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_66, (unsigned int)sizeof zT_66);
    zig_poison_fill((void*)&zT_75, (unsigned int)sizeof zT_75);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    zig_poison_fill((void*)&zT_95, (unsigned int)sizeof zT_95);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1: ;
    zT_8 = path.len;
    if ((unsigned char)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_13 = (unsigned char*)path.ptr;
    zT_14 = path.len;
    zT_15 = i < zT_14;
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_13[i];
    zT_18 = i < (unsigned int)(512);
    if (!(zT_18)) { pal_trap(); }
    c_path[i] = zT_16;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    i = zT_21;
    goto z_bb_4;
    z_bb_3: ;
    zT_25 = 511;
    if ((unsigned char)(i >= (unsigned int)zT_25)) goto z_bb_8; else goto z_bb_9;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6: ;
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8: ;
    zT_27.has_value = 0;
    return zT_27;
    z_bb_9: ;
    zT_28 = 0;
    zT_29 = (unsigned char)zT_28;
    zT_31 = i < (unsigned int)(512);
    if (!(zT_31)) { pal_trap(); }
    c_path[i] = zT_29;
    zT_35 = 0;
    zT_37 = (unsigned int)zT_35 < (unsigned int)(512);
    if (!(zT_37)) { pal_trap(); }
    zT_38 = c_path + zT_35;
    zT_33 = zT_38;
    zT_34 = zG_970FEF1B_MODE_READ;
        zT_40.value = (void*)fopen(zT_33, zT_34);
    zT_40.has_value = zT_40.value != 0;
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_11; else goto z_bb_10;
    z_bb_10: ;
    zT_43.has_value = 0;
    return zT_43;
    z_bb_11: ;
    if (!(zT_40.has_value)) { pal_trap(); }
    zT_42 = zT_40.value;
    goto z_bb_12;
    z_bb_12: ;
    f = zT_42;
    zT_45 = f;
    zT_48 = 0;
    zT_50 = 2;
    zT_47 = zT_50;
    zT_51 = fseek(zT_45, (int)((int)zT_48), zT_47);
    (void)zT_51;
    zT_53 = f;
    zT_54 = ftell(zT_53);
    size = zT_54;
    zT_55 = 0;
    if ((unsigned char)(size <= zT_55)) goto z_bb_13; else goto z_bb_14;
    z_bb_13: ;
    zT_57 = f;
    zT_58 = fclose(zT_57);
    (void)zT_58;
    zT_59.has_value = 0;
    return zT_59;
    z_bb_14: ;
    zT_60 = f;
    zT_63 = 0;
    zT_65 = 0;
    zT_62 = zT_65;
    zT_66 = fseek(zT_60, (int)((int)zT_63), zT_62);
    (void)zT_66;
    zT_68 = (unsigned int)zig_cast_checked_u((zu64)size, 32u, 1u, 32u);
    sz = zT_68;
    zT_70 = alloc;
    zT_75 = zF_1395EB68_sandAlloc(zT_70, (unsigned int)((unsigned int)sz), (unsigned int)(1));
    zT_76 = zT_75.is_error;
    if (zT_76) goto z_bb_15; else goto z_bb_16;
    z_bb_15: ;
    zT_78 = f;
    zT_79 = fclose(zT_78);
    (void)zT_79;
    zT_80.has_value = 0;
    return zT_80;
    z_bb_16: ;
    zT_77 = zT_75.data.payload;
    goto z_bb_17;
    z_bb_17: ;
    raw = zT_77;
    zT_83 = (unsigned char*)raw;
    buf = zT_83;
    zT_85 = buf;
    zT_89 = 1;
    zT_87 = sz;
    zT_88 = f;
    zT_91 = fread(zT_85, (unsigned int)((unsigned int)zT_89), zT_87, zT_88);
    read = zT_91;
    zT_92 = f;
    zT_93 = fclose(zT_92);
    (void)zT_93;
    if ((unsigned char)(read != sz)) goto z_bb_18; else goto z_bb_19;
    z_bb_18: ;
    zT_95.has_value = 0;
    return zT_95;
    z_bb_19: ;
    zT_96 = 0;
    zT_97 = buf + zT_96;
    zT_98 = sz - zT_96;
    zT_99 = (unsigned int)zT_96 <= sz;
    if (!(zT_99)) { pal_trap(); }
    zT_100.ptr = (unsigned char*)zT_97;
    zT_100.len = zT_98;
    zT_101.has_value = 1;
    zT_101.value = zT_100;
    return zT_101;
}

/* fileExists */
unsigned char zF_852C5C93_fileExists(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_846744CC_Arr_unsigned_char_5 zT_2;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char zT_9;
    int zT_10;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_27;
    unsigned char zT_28;
    unsigned char zT_30;
    unsigned char* zT_32;
    unsigned char* zT_33;
    int zT_34;
    unsigned char zT_36;
    unsigned char* zT_37;
    zT_94D5F27B_Opt_455 zT_39;
    unsigned char zT_40;
    void* zT_41;
    void* zT_44;
    int zT_45;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    void* f;
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1: ;
    zT_7 = path.len;
    if ((unsigned char)(i < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_12 = (unsigned char*)path.ptr;
    zT_13 = path.len;
    zT_14 = i < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    zT_17 = i < (unsigned int)(512);
    if (!(zT_17)) { pal_trap(); }
    c_path[i] = zT_15;
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    i = zT_20;
    goto z_bb_4;
    z_bb_3: ;
    zT_24 = 511;
    if ((unsigned char)(i >= (unsigned int)zT_24)) goto z_bb_8; else goto z_bb_9;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_10 = 511;
    zT_9 = i < (unsigned int)zT_10;
    goto z_bb_7;
    z_bb_6: ;
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8: ;
    return (unsigned char)(0);
    z_bb_9: ;
    zT_27 = 0;
    zT_28 = (unsigned char)zT_27;
    zT_30 = i < (unsigned int)(512);
    if (!(zT_30)) { pal_trap(); }
    c_path[i] = zT_28;
    zT_34 = 0;
    zT_36 = (unsigned int)zT_34 < (unsigned int)(512);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = c_path + zT_34;
    zT_32 = zT_37;
    zT_33 = zG_970FEF1B_MODE_READ;
        zT_39.value = (void*)fopen(zT_32, zT_33);
    zT_39.has_value = zT_39.value != 0;
    zT_40 = zT_39.has_value;
    if (zT_40) goto z_bb_11; else goto z_bb_10;
    z_bb_10: ;
    return (unsigned char)(0);
    z_bb_11: ;
    if (!(zT_39.has_value)) { pal_trap(); }
    zT_41 = zT_39.value;
    goto z_bb_12;
    z_bb_12: ;
    f = zT_41;
    zT_44 = f;
    zT_45 = fclose(zT_44);
    (void)zT_45;
    return (unsigned char)(1);
}

/* dirExists */
unsigned char zF_8CC05F84_dirExists(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_846744CC_Arr_unsigned_char_5 zT_2;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char zT_9;
    int zT_10;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_27;
    unsigned char zT_28;
    unsigned char zT_30;
    unsigned char* zT_31;
    int zT_32;
    unsigned char zT_34;
    unsigned char* zT_35;
    int zT_36;
    int zT_37;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1: ;
    zT_7 = path.len;
    if ((unsigned char)(i < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_12 = (unsigned char*)path.ptr;
    zT_13 = path.len;
    zT_14 = i < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_12[i];
    zT_17 = i < (unsigned int)(512);
    if (!(zT_17)) { pal_trap(); }
    c_path[i] = zT_15;
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    i = zT_20;
    goto z_bb_4;
    z_bb_3: ;
    zT_24 = 511;
    if ((unsigned char)(i >= (unsigned int)zT_24)) goto z_bb_8; else goto z_bb_9;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_10 = 511;
    zT_9 = i < (unsigned int)zT_10;
    goto z_bb_7;
    z_bb_6: ;
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8: ;
    return (unsigned char)(0);
    z_bb_9: ;
    zT_27 = 0;
    zT_28 = (unsigned char)zT_27;
    zT_30 = i < (unsigned int)(512);
    if (!(zT_30)) { pal_trap(); }
    c_path[i] = zT_28;
    zT_32 = 0;
    zT_34 = (unsigned int)zT_32 < (unsigned int)(512);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = c_path + zT_32;
    zT_31 = zT_35;
    zT_36 = pal_dir_exists(zT_31);
    zT_37 = 0;
    return (unsigned char)(zT_36 != zT_37);
}

/* stdout_write */
void zF_D3019AEE_stdout_write(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned char* zT_2;
    int zT_3;
    int zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_4 = 1;
    zT_7 = (unsigned char*)msg.ptr;
    zT_2 = zT_7;
    zT_9 = msg.len;
    zT_3 = (int)zig_cast_checked_s((zu64)zT_9, 32u, 0u, 32u);
    zT_11 = write((int)((int)zT_4), zT_2, zT_3);
    (void)zT_11;
    return;
}

/* stderr_write */
void zF_E4B2EF19_stderr_write(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned char* zT_2;
    int zT_3;
    int zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_4 = 2;
    zT_7 = (unsigned char*)msg.ptr;
    zT_2 = zT_7;
    zT_9 = msg.len;
    zT_3 = (int)zig_cast_checked_s((zu64)zT_9, 32u, 0u, 32u);
    zT_11 = write((int)((int)zT_4), zT_2, zT_3);
    (void)zT_11;
    return;
}

/* fileOpen */
unsigned int zF_39FE21EF_fileOpen(zT_8F083A69_Slice_zT_0B42B2F8_u path, int flags) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    int zT_25;
    int zT_28;
    unsigned char zT_29;
    unsigned char zT_31;
    unsigned char* zT_32;
    int zT_33;
    int zT_34;
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1: ;
    zT_8 = path.len;
    if ((unsigned char)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_13 = (unsigned char*)path.ptr;
    zT_14 = path.len;
    zT_15 = i < zT_14;
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_13[i];
    zT_18 = i < (unsigned int)(512);
    if (!(zT_18)) { pal_trap(); }
    c_path[i] = zT_16;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    i = zT_21;
    goto z_bb_4;
    z_bb_3: ;
    zT_25 = 511;
    if ((unsigned char)(i >= (unsigned int)zT_25)) goto z_bb_8; else goto z_bb_9;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6: ;
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8: ;
    return (unsigned int)(4294967295u);
    z_bb_9: ;
    zT_28 = 0;
    zT_29 = (unsigned char)zT_28;
    zT_31 = i < (unsigned int)(512);
    if (!(zT_31)) { pal_trap(); }
    c_path[i] = zT_29;
    zT_34 = 0;
    zT_36 = (unsigned int)zT_34 < (unsigned int)(512);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = c_path + zT_34;
    zT_32 = zT_37;
    zT_33 = flags;
    zT_38 = pal_file_open(zT_32, zT_33);
    return zT_38;
}

/* fileWrite */
void zF_3276D7B6_fileWrite(unsigned int fd, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned int zT_2;
    unsigned char* zT_3;
    unsigned char* zT_6;
    unsigned int zT_8;
    int zT_10;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zT_2 = fd;
    zT_6 = (unsigned char*)msg.ptr;
    zT_3 = zT_6;
    zT_8 = msg.len;
    zT_10 = pal_file_write(zT_2, zT_3, (unsigned int)((unsigned int)zT_8));
    (void)zT_10;
    return;
}

/* fileRead */
unsigned int zF_7579A8D7_fileRead(unsigned int fd, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11;
    int zT_12;
    unsigned int zT_15;
    int got;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_3 = fd;
    zT_7 = (unsigned char*)buf.ptr;
    zT_4 = zT_7;
    zT_9 = buf.len;
    zT_11 = pal_file_read(zT_3, zT_4, (unsigned int)((unsigned int)zT_9));
    got = zT_11;
    zT_12 = 0;
    if ((unsigned char)(got < zT_12)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return (unsigned int)(4294967295u);
    z_bb_2: ;
    zT_15 = (unsigned int)zig_cast_checked_u((zu64)got, 32u, 1u, 32u);
    return zT_15;
}

/* fileClose */
void zF_B30B1D79_fileClose(unsigned int fd) {
    unsigned int zT_1;
    int zT_2;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = fd;
    zT_2 = pal_file_close(zT_1);
    (void)zT_2;
    return;
}

/* streamOpen */
zT_94D5F27B_Opt_455 zF_A1EF0C49_streamOpen(zT_8F083A69_Slice_zT_0B42B2F8_u path, unsigned char* mode) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    int zT_25;
    zT_94D5F27B_Opt_455 zT_27;
    int zT_28;
    unsigned char zT_29;
    unsigned char zT_31;
    unsigned char* zT_33;
    unsigned char* zT_34;
    int zT_35;
    unsigned char zT_37;
    unsigned char* zT_38;
    zT_94D5F27B_Opt_455 zT_39;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    zT_94D5F27B_Opt_455 f;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1: ;
    zT_8 = path.len;
    if ((unsigned char)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2: ;
    zT_13 = (unsigned char*)path.ptr;
    zT_14 = path.len;
    zT_15 = i < zT_14;
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_13[i];
    zT_18 = i < (unsigned int)(512);
    if (!(zT_18)) { pal_trap(); }
    c_path[i] = zT_16;
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    i = zT_21;
    goto z_bb_4;
    z_bb_3: ;
    zT_25 = 511;
    if ((unsigned char)(i >= (unsigned int)zT_25)) goto z_bb_8; else goto z_bb_9;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6: ;
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7: ;
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8: ;
    zT_27.has_value = 0;
    return zT_27;
    z_bb_9: ;
    zT_28 = 0;
    zT_29 = (unsigned char)zT_28;
    zT_31 = i < (unsigned int)(512);
    if (!(zT_31)) { pal_trap(); }
    c_path[i] = zT_29;
    zT_35 = 0;
    zT_37 = (unsigned int)zT_35 < (unsigned int)(512);
    if (!(zT_37)) { pal_trap(); }
    zT_38 = c_path + zT_35;
    zT_33 = zT_38;
    zT_34 = mode;
        zT_39.value = (void*)fopen(zT_33, zT_34);
    zT_39.has_value = zT_39.value != 0;
    f = zT_39;
    return f;
}

/* streamClose */
void zF_D4EBC9A3_streamClose(void* file) {
    void* zT_1;
    int zT_2;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = file;
    zT_2 = fclose(zT_1);
    (void)zT_2;
    return;
}

/* streamWrite */
void zF_6B472DDC_streamWrite(void* file, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_7;
    void* zT_10;
    unsigned char* zT_12;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_33;
    unsigned int wrote;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_3 = buf.len;
    if ((unsigned char)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_12 = (unsigned char*)buf.ptr;
    zT_7 = zT_12;
    zT_15 = buf.len;
    zT_10 = file;
    zT_17 = fwrite(zT_7, (unsigned int)(1), (unsigned int)((unsigned int)zT_15), zT_10);
    wrote = zT_17;
    zT_19 = buf.len;
    if ((unsigned char)(wrote != (unsigned int)((unsigned int)zT_19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_23 = (unsigned char*)"short write on spill stream (streamWrite)";
    zT_25 = 41;
    zT_24.ptr = (unsigned char*)zT_23;
    zT_24.len = zT_25;
    emsg = zT_24;
    zT_27 = (unsigned char*)"pal.zig";
    zT_29 = 7;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    ef = zT_28;
    zT_30 = emsg;
    zT_31 = ef;
    zT_33 = 120;
    zF_6D97D338_panicHandler(zT_30, zT_31, (unsigned int)((unsigned int)zT_33));
    goto z_bb_4;
    z_bb_4: ;
    return;
}

/* streamRead */
void zF_9D6FEB45_streamRead(void* file, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_7;
    void* zT_10;
    unsigned char* zT_12;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_33;
    unsigned int got;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_3 = buf.len;
    if ((unsigned char)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return;
    z_bb_2: ;
    zT_12 = (unsigned char*)buf.ptr;
    zT_7 = zT_12;
    zT_15 = buf.len;
    zT_10 = file;
    zT_17 = fread(zT_7, (unsigned int)(1), (unsigned int)((unsigned int)zT_15), zT_10);
    got = zT_17;
    zT_19 = buf.len;
    if ((unsigned char)(got != (unsigned int)((unsigned int)zT_19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3: ;
    zT_23 = (unsigned char*)"short read on spill stream (streamRead)";
    zT_25 = 39;
    zT_24.ptr = (unsigned char*)zT_23;
    zT_24.len = zT_25;
    emsg = zT_24;
    zT_27 = (unsigned char*)"pal.zig";
    zT_29 = 7;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    ef = zT_28;
    zT_30 = emsg;
    zT_31 = ef;
    zT_33 = 130;
    zF_6D97D338_panicHandler(zT_30, zT_31, (unsigned int)((unsigned int)zT_33));
    goto z_bb_4;
    z_bb_4: ;
    return;
}

/* streamSeek */
void zF_25D60F31_streamSeek(void* file, int offset) {
    void* zT_3;
    int zT_4;
    int zT_5;
    unsigned int zT_6;
    int zT_7;
    int zT_8;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_21;
    int rc;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_3 = file;
    zT_4 = offset;
    zT_6 = 0;
    zT_5 = zT_6;
    zT_7 = fseek(zT_3, zT_4, zT_5);
    rc = zT_7;
    zT_8 = 0;
    if ((unsigned char)(rc != zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_11 = (unsigned char*)"fseek failed on spill stream (streamSeek)";
    zT_13 = 41;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    emsg = zT_12;
    zT_15 = (unsigned char*)"pal.zig";
    zT_17 = 7;
    zT_16.ptr = (unsigned char*)zT_15;
    zT_16.len = zT_17;
    ef = zT_16;
    zT_18 = emsg;
    zT_19 = ef;
    zT_21 = 139;
    zF_6D97D338_panicHandler(zT_18, zT_19, (unsigned int)((unsigned int)zT_21));
    goto z_bb_2;
    z_bb_2: ;
    return;
}

/* getDefaultLibPath */
int zF_BEB0BFA8_getDefaultLibPath(unsigned char* buf, int bufsize) {
    unsigned char* zT_2;
    int zT_3;
    int zT_4;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_2 = buf;
    zT_3 = bufsize;
    zT_4 = pal_get_default_lib_path(zT_2, zT_3);
    return zT_4;
}

/* exit */
void zF_CDED1A85_exit(unsigned char code) {
    c_exit((int)((int)code));
    goto z_bb_1;
    z_bb_1: ;
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2: ;
    goto z_bb_4;
    z_bb_3: ;
    return;
    z_bb_4: ;
    goto z_bb_1;
}

/* initArgs */
void zF_4DE8E0A6_initArgs(int argc, unsigned char** argv) {
    zG_F46B0200_saved_argc = argc;
    zG_096B230F_saved_argv = argv;
    return;
}

/* argCount */
int zF_EEF840BE_argCount(void) {
    return zG_F46B0200_saved_argc;
}

/* argGet */
unsigned char* zF_70B5BFF1_argGet(int i) {
    unsigned int zT_2;
    unsigned char* zT_3;
    zT_2 = (unsigned int)zig_cast_checked_u((zu64)i, 32u, 1u, 32u);
    zT_3 = zG_096B230F_saved_argv[zT_2];
    return zT_3;
}

/* markersEnabled */
void zF_3C88665D_markersEnabled(unsigned int on) {
    zG_EE253928_g_markers_enabled = on;
    return;
}

/* isMarkersEnabled */
unsigned char zF_F632D1ED_isMarkersEnabled(void) {
    int zT_1;
    zT_1 = 0;
    return (unsigned char)(zG_EE253928_g_markers_enabled != (unsigned int)zT_1);
}

/* markerWrite */
void zF_48AC7B3A_markerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    (void)msg;
    return;
}

/* markerWriteInt */
void zF_C914CB83_markerWriteInt(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int value) {
    (void)prefix;
    (void)value;
    return;
}

/* markerWriteInt64 */
void zF_C405AFC1_markerWriteInt64(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_79FAE712_u64 value) {
    (void)prefix;
    (void)value;
    return;
}

/* measureMarkerWrite */
void zF_B5478454_measureMarkerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    if ((unsigned char)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    goto z_bb_2;
    z_bb_2: ;
    return;
}

/* measureMarkerWriteInt */
void zF_95B5C5CD_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5826BFC7_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    unsigned char zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_5826BFC7_Arr_unsigned_char_1 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    if ((unsigned char)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    s_p = prefix;
    zT_6 = s_p;
    zF_B5478454_measureMarkerWrite(zT_6);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        buf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = value;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)buf) + zT_14;
    zT_16 = (unsigned int)(12) - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A7504564_itoa(zT_10, zT_11);
    vlen = zT_18;
    zT_20 = 12;
    zT_21 = (unsigned int)vlen;
    zT_22 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = 1;
    zT_27 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    start = zT_27;
    zT_34 = 11;
    zT_35 = (unsigned char*)((unsigned char*)buf) + start;
    zT_36 = zT_34 - start;
    zT_37 = start <= zT_34;
    if (!(zT_37)) { pal_trap(); }
    zT_38.ptr = (unsigned char*)zT_35;
    zT_38.len = zT_36;
    zT_31 = zT_38;
    zF_B5478454_measureMarkerWrite(zT_31);
    zT_40 = (unsigned char*)"\n";
    zT_42 = 1;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    s_nl = zT_41;
    zT_43 = s_nl;
    zF_B5478454_measureMarkerWrite(zT_43);
    goto z_bb_2;
    z_bb_2: ;
    return;
}

/* measureMarkerWriteInt64 */
void zF_C9DDBF0F_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_79FAE712_u64 value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_4428DEE2_Arr_unsigned_char_2 zT_8;
    zT_79FAE712_u64 zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    unsigned char zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_4428DEE2_Arr_unsigned_char_2 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    if ((unsigned char)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    s_p = prefix;
    zT_6 = s_p;
    zF_B5478454_measureMarkerWrite(zT_6);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    {
    unsigned int _i = 0;
    while (_i < 24) {
        buf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = value;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)buf) + zT_14;
    zT_16 = (unsigned int)(24) - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A3999586_itoa64(zT_10, zT_11);
    vlen = zT_18;
    zT_20 = 24;
    zT_21 = (unsigned int)vlen;
    zT_22 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = 1;
    zT_27 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    start = zT_27;
    zT_34 = 23;
    zT_35 = (unsigned char*)((unsigned char*)buf) + start;
    zT_36 = zT_34 - start;
    zT_37 = start <= zT_34;
    if (!(zT_37)) { pal_trap(); }
    zT_38.ptr = (unsigned char*)zT_35;
    zT_38.len = zT_36;
    zT_31 = zT_38;
    zF_B5478454_measureMarkerWrite(zT_31);
    zT_40 = (unsigned char*)"\n";
    zT_42 = 1;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    s_nl = zT_41;
    zT_43 = s_nl;
    zF_B5478454_measureMarkerWrite(zT_43);
    goto z_bb_2;
    z_bb_2: ;
    return;
}

/* __module_init */
void zF_780653D2___module_init_6(void) {
    zT_3E40CD83_Sand zT_0;
    int zT_1;
    int zT_3;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_3E40CD83_Sand = zT_0;
    zT_1 = 0;
    zG_F46B0200_saved_argc = (int)((int)zT_1);
    zT_3 = 0;
    zG_EE253928_g_markers_enabled = (unsigned int)((unsigned int)zT_3);
    return;
}

/* EOF */
