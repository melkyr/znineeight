#include "hash_02AFCD13.h"
/* mapCapacityFromHint */
unsigned int zF_ADD0ED80_mapCapacityFromHint(unsigned int hint) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int needed;
    unsigned int cap;
    if ((unsigned char)(hint == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = 4;
    zT_6 = zig_wrap_mul_u(((zu64)(hint)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_mul_u(((zu64)(hint)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = 2;
    zT_11 = zig_wrap_add_u(((zu64)(zT_6)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_add_u(((zu64)(zT_6)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_18 = 1;
    if (!(zT_18)) { pal_trap(); }
    zT_16 = zT_11 / (unsigned int)(3);
    needed = zT_16;
    zT_20 = 8;
    cap = zT_20;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(cap < needed)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = 2;
    zT_23 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    cap = zT_23;
    goto z_bb_6;
    z_bb_5:
    return cap;
    z_bb_6:
    goto z_bb_3;
}

/* fnv1a */
unsigned int zF_B22E025B_fnv1a(zT_8F083A69_Slice_zT_0B42B2F8_u data) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned char* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int hash;
    unsigned char byte;
    zT_2 = 2166136261u;
    zT_3 = (unsigned int)zT_2;
    hash = zT_3;
    zT_4 = data.ptr;
    zT_5 = data.len;
    zT_6 = 0;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(zT_6 < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    byte = zT_4[zT_6];
    zT_10 = hash ^ (unsigned int)((unsigned int)byte);
    hash = zT_10;
    zT_11 = 16777619;
    zT_12 = hash * zT_11;
    hash = zT_12;
    goto z_bb_4;
    z_bb_3:
    return hash;
    z_bb_4:
    zT_14 = zT_6 + (unsigned int)(1);
    zT_6 = zT_14;
    goto z_bb_1;
}

/* u32ToU32MapInit */
zT_21D3708C_U32ToU32Map zF_58BDA2DE_u32ToU32MapInit(zT_3E40CD83_Sand* alloc) {
    zT_21D3708C_U32ToU32Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.keys = (unsigned int*)zT_2;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1.values = (unsigned int*)zT_3;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u32ToU32MapInitCap */
zT_21D3708C_U32ToU32Map zF_619D56E6_u32ToU32MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_7;
    zT_21D3708C_U32ToU32Map zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_FDFD82FD_EU_362 zT_19;
    unsigned char zT_20;
    unsigned char* zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_3E40CD83_Sand* zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    zT_FDFD82FD_EU_362 zT_47;
    unsigned char zT_48;
    unsigned char* zT_49;
    int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zT_21D3708C_U32ToU32Map zT_62;
    unsigned int* zT_63;
    unsigned int* zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_58BDA2DE_u32ToU32MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_13 = 4;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_11 = zT_14;
    zT_19 = zF_1395EB68_sandAlloc(zT_10, zT_11, (unsigned int)(4));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_21 = zT_19.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_21;
    zT_24 = alloc;
    zT_27 = 4;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_25 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_24, zT_25, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_35;
    zT_38 = alloc;
    zT_41 = 1;
    zT_42 = zig_wrap_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_43 = zig_overflow_flag_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    zT_39 = zT_42;
    zT_47 = zF_1395EB68_sandAlloc(zT_38, zT_39, (unsigned int)(4));
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_49 = zT_47.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_49;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    zi = zT_53;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_55 = 0;
    raw_occ[zi] = zT_55;
    goto z_bb_15;
    z_bb_14:
    zT_63 = (unsigned int*)raw_keys;
    zT_62.keys = zT_63;
    zT_64 = (unsigned int*)raw_vals;
    zT_62.values = zT_64;
    zT_65 = (unsigned char*)raw_occ;
    zT_62.occupied = zT_65;
    zT_62.capacity = cap;
    zT_66 = 0;
    zT_62.count = zT_66;
    zT_62.alloc = alloc;
    return zT_62;
    z_bb_15:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zi = zT_58;
    goto z_bb_12;
}

/* u32ToU32MapGet */
zT_BAEE192E_Opt_10 zF_F3EE5998_u32ToU32MapGet(zT_21D3708C_U32ToU32Map* self, unsigned int key) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int* zT_23;
    unsigned int zT_24;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned int zT_31;
    zT_BAEE192E_Opt_10 zT_32;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_8 = 1;
    zT_9 = zig_wrap_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    mask = zT_9;
    zT_15 = (unsigned int)((unsigned int)key) & mask;
    i = zT_15;
    goto z_bb_3;
    z_bb_3:
    zT_16 = self->occupied;
    zT_17 = zT_16[i];
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = self->keys;
    zT_21 = zT_20[i];
    if ((unsigned char)(zT_21 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_23 = self->values;
    zT_24 = zT_23[i];
    zT_25.has_value = 1;
    zT_25.value = zT_24;
    return zT_25;
    z_bb_8:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_31 = zT_27 & mask;
    i = zT_31;
    goto z_bb_6;
}

/* u32ToU32MapGrow */
void zF_A54BFE8F_u32ToU32MapGrow(zT_21D3708C_U32ToU32Map* self) {
    unsigned int zT_2;
    unsigned int* zT_4;
    unsigned int* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_FDFD82FD_EU_362 zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_FDFD82FD_EU_362 zT_45;
    unsigned char zT_46;
    unsigned char* zT_47;
    zT_3E40CD83_Sand* zT_50;
    unsigned int zT_51;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_FDFD82FD_EU_362 zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned char* zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned int zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned char zT_96;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned char zT_101;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned char zT_108;
    unsigned int zT_109;
    unsigned int* zT_110;
    unsigned int* zT_111;
    unsigned char zT_112;
    unsigned char* zT_113;
    unsigned int zT_114;
    int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int old_cap;
    unsigned int* old_keys;
    unsigned int* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    unsigned int k;
    unsigned int v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_12 = zT_15;
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_20 = self->alloc;
    zT_24 = 4;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_21 = zT_25;
    zT_30 = zF_1395EB68_sandAlloc(zT_20, zT_21, (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_32;
    zT_35 = self->alloc;
    zT_39 = 4;
    zT_40 = zig_wrap_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_36 = zT_40;
    zT_45 = zF_1395EB68_sandAlloc(zT_35, zT_36, (unsigned int)(4));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_47 = zT_45.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_47;
    zT_50 = self->alloc;
    zT_54 = 1;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_51 = zT_55;
    zT_60 = zF_1395EB68_sandAlloc(zT_50, zT_51, (unsigned int)(4));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_62 = zT_60.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_62;
    self->keys = (unsigned int*)((unsigned int*)raw_keys);
    self->values = (unsigned int*)((unsigned int*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    zi = zT_70;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_72 = 0;
    zT_73 = self->occupied;
    zT_73[zi] = zT_72;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    zi = zT_76;
    goto z_bb_16;
    z_bb_15:
    zT_81 = 0;
    zT_82 = (unsigned int)zT_81;
    ri = zT_82;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_84 = old_occupied[ri];
    if ((unsigned char)(zT_84 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_88 = old_keys[ri];
    k = zT_88;
    zT_90 = old_values[ri];
    v = zT_90;
    zT_92 = 1;
    zT_93 = zig_wrap_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_94 = zig_overflow_flag_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_96 = zT_94 == (unsigned int)(0);
    if (!(zT_96)) { pal_trap(); }
    mask2 = zT_93;
    zT_99 = (unsigned int)((unsigned int)k) & mask2;
    idx = zT_99;
    goto z_bb_23;
    z_bb_22:
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    ri = zT_123;
    goto z_bb_20;
    z_bb_23:
    zT_100 = self->occupied;
    zT_101 = zT_100[idx];
    if ((unsigned char)(zT_101 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_104 = 1;
    zT_105 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_104)), 32u);
    zT_106 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_104)), 32u);
    zT_108 = zT_106 == (unsigned int)(0);
    if (!(zT_108)) { pal_trap(); }
    zT_109 = zT_105 & mask2;
    idx = zT_109;
    goto z_bb_26;
    z_bb_25:
    zT_110 = self->keys;
    zT_110[idx] = k;
    zT_111 = self->values;
    zT_111[idx] = v;
    zT_112 = 1;
    zT_113 = self->occupied;
    zT_113[idx] = zT_112;
    zT_114 = self->count;
    zT_115 = 1;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zig_wrap_add_u(((zu64)(zT_114)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(zT_114)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    self->count = zT_117;
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u32ToU32MapGetOrAddDense */
unsigned int zF_8879E7FF_u32ToU32MapGetOrAdd(zT_21D3708C_U32ToU32Map* self, unsigned int key) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned char zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_BAEE192E_Opt_10 got;
    unsigned int v;
    unsigned int code;
    zT_3 = self;
    zT_4 = key;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    got = zT_5;
    zT_6 = got.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(got.has_value)) { pal_trap(); }
    v = got.value;
    return v;
    z_bb_2:
    zT_9 = self->count;
    zT_10 = (unsigned int)zT_9;
    zT_11 = 1;
    zT_12 = zig_wrap_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    code = zT_12;
    zT_16 = self;
    zT_17 = key;
    zT_18 = code;
    zF_26476265_u32ToU32MapPut(zT_16, zT_17, zT_18);
    return code;
}

/* u32ToU32MapPut */
void zF_26476265_u32ToU32MapPut(zT_21D3708C_U32ToU32Map* self, unsigned int key, unsigned int value) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_21D3708C_U32ToU32Map* zT_16;
    unsigned int zT_17;
    zT_21D3708C_U32ToU32Map* zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_30;
    unsigned char* zT_31;
    unsigned char zT_32;
    unsigned int* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned int* zT_45;
    unsigned int* zT_46;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_4 = 4;
    zT_5 = zig_wrap_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    zT_9 = self->capacity;
    zT_10 = 3;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    if ((unsigned char)(zT_5 >= zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zF_A54BFE8F_u32ToU32MapGrow(zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_17 = self->capacity;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = self;
    zF_A54BFE8F_u32ToU32MapGrow(zT_20);
    goto z_bb_4;
    z_bb_4:
    zT_22 = self->capacity;
    zT_23 = 1;
    zT_24 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    mask = zT_24;
    zT_30 = (unsigned int)((unsigned int)key) & mask;
    i = zT_30;
    goto z_bb_5;
    z_bb_5:
    zT_31 = self->occupied;
    zT_32 = zT_31[i];
    if ((unsigned char)(zT_32 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = self->keys;
    zT_36 = zT_35[i];
    if ((unsigned char)(zT_36 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_45 = self->keys;
    zT_45[i] = key;
    zT_46 = self->values;
    zT_46[i] = value;
    zT_47 = 1;
    zT_48 = self->occupied;
    zT_48[i] = zT_47;
    zT_49 = self->count;
    zT_50 = 1;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zig_wrap_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    self->count = zT_52;
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_38 = self->values;
    zT_38[i] = value;
    return;
    z_bb_10:
    zT_39 = 1;
    zT_40 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_40 & mask;
    i = zT_44;
    goto z_bb_8;
}

/* u32ToU32MapClear */
void zF_117BCE21_u32ToU32MapClear(zT_21D3708C_U32ToU32Map* self) {
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned char zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int i;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->capacity;
    if ((unsigned char)(i < zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_7 = self->occupied;
    zT_7[i] = zT_6;
    goto z_bb_4;
    z_bb_3:
    self->count = (unsigned int)(0);
    return;
    z_bb_4:
    zT_8 = 1;
    zT_9 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    i = zT_9;
    goto z_bb_1;
}

/* u64ToU32MapInit */
zT_A4CE86B7_U64ToU32Map zF_986226E1_u64ToU32MapInit(zT_3E40CD83_Sand* alloc) {
    zT_A4CE86B7_U64ToU32Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.keys = (zT_79FAE712_u64*)zT_2;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1.values = (unsigned int*)zT_3;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u64ToU32MapInitCap */
zT_A4CE86B7_U64ToU32Map zF_CE4144CF_u64ToU32MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_7;
    zT_A4CE86B7_U64ToU32Map zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_FDFD82FD_EU_362 zT_19;
    unsigned char zT_20;
    unsigned char* zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_3E40CD83_Sand* zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    zT_FDFD82FD_EU_362 zT_47;
    unsigned char zT_48;
    unsigned char* zT_49;
    int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zT_A4CE86B7_U64ToU32Map zT_62;
    zT_79FAE712_u64* zT_63;
    unsigned int* zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_986226E1_u64ToU32MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_13 = 8;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_11 = zT_14;
    zT_19 = zF_1395EB68_sandAlloc(zT_10, zT_11, (unsigned int)(4));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_21 = zT_19.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_21;
    zT_24 = alloc;
    zT_27 = 4;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_25 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_24, zT_25, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_35;
    zT_38 = alloc;
    zT_41 = 1;
    zT_42 = zig_wrap_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_43 = zig_overflow_flag_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    zT_39 = zT_42;
    zT_47 = zF_1395EB68_sandAlloc(zT_38, zT_39, (unsigned int)(4));
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_49 = zT_47.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_49;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    zi = zT_53;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_55 = 0;
    raw_occ[zi] = zT_55;
    goto z_bb_15;
    z_bb_14:
    zT_63 = (zT_79FAE712_u64*)raw_keys;
    zT_62.keys = zT_63;
    zT_64 = (unsigned int*)raw_vals;
    zT_62.values = zT_64;
    zT_65 = (unsigned char*)raw_occ;
    zT_62.occupied = zT_65;
    zT_62.capacity = cap;
    zT_66 = 0;
    zT_62.count = zT_66;
    zT_62.alloc = alloc;
    return zT_62;
    z_bb_15:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zi = zT_58;
    goto z_bb_12;
}

/* u64ToU32MapGet */
zT_BAEE192E_Opt_10 zF_A05A7BE1_u64ToU32MapGet(zT_A4CE86B7_U64ToU32Map* self, zT_79FAE712_u64 key) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    zT_79FAE712_u64 zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    zT_79FAE712_u64* zT_23;
    zT_79FAE712_u64 zT_24;
    unsigned int* zT_26;
    unsigned int zT_27;
    zT_BAEE192E_Opt_10 zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_35;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_8 = 1;
    zT_9 = zig_wrap_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    mask = zT_9;
    zT_15 = key & (zT_79FAE712_u64)(4294967295u);
    zT_16 = (unsigned int)zig_cast_checked_u((zu64)zT_15, 64u, 0u, 32u);
    zT_18 = (unsigned int)((unsigned int)zT_16) & mask;
    i = zT_18;
    goto z_bb_3;
    z_bb_3:
    zT_19 = self->occupied;
    zT_20 = zT_19[i];
    if ((unsigned char)(zT_20 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_23 = self->keys;
    zT_24 = zT_23[i];
    if ((unsigned char)(zT_24 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_35.has_value = 0;
    return zT_35;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_26 = self->values;
    zT_27 = zT_26[i];
    zT_28.has_value = 1;
    zT_28.value = zT_27;
    return zT_28;
    z_bb_8:
    zT_29 = 1;
    zT_30 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    zT_34 = zT_30 & mask;
    i = zT_34;
    goto z_bb_6;
}

/* u64ToU32MapGrow */
void zF_FE9D19D4_u64ToU32MapGrow(zT_A4CE86B7_U64ToU32Map* self) {
    unsigned int zT_2;
    zT_79FAE712_u64* zT_4;
    unsigned int* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_FDFD82FD_EU_362 zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_FDFD82FD_EU_362 zT_45;
    unsigned char zT_46;
    unsigned char* zT_47;
    zT_3E40CD83_Sand* zT_50;
    unsigned int zT_51;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_FDFD82FD_EU_362 zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned char* zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_79FAE712_u64 zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned char zT_96;
    zT_79FAE712_u64 zT_99;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char* zT_103;
    unsigned char zT_104;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned char zT_111;
    unsigned int zT_112;
    zT_79FAE712_u64* zT_113;
    unsigned int* zT_114;
    unsigned char zT_115;
    unsigned char* zT_116;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int old_cap;
    zT_79FAE712_u64* old_keys;
    unsigned int* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    zT_79FAE712_u64 k;
    unsigned int v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_12 = zT_15;
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_20 = self->alloc;
    zT_24 = 8;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_21 = zT_25;
    zT_30 = zF_1395EB68_sandAlloc(zT_20, zT_21, (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_32;
    zT_35 = self->alloc;
    zT_39 = 4;
    zT_40 = zig_wrap_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_36 = zT_40;
    zT_45 = zF_1395EB68_sandAlloc(zT_35, zT_36, (unsigned int)(4));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_47 = zT_45.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_47;
    zT_50 = self->alloc;
    zT_54 = 1;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_51 = zT_55;
    zT_60 = zF_1395EB68_sandAlloc(zT_50, zT_51, (unsigned int)(4));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_62 = zT_60.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_62;
    self->keys = (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw_keys);
    self->values = (unsigned int*)((unsigned int*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    zi = zT_70;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_72 = 0;
    zT_73 = self->occupied;
    zT_73[zi] = zT_72;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    zi = zT_76;
    goto z_bb_16;
    z_bb_15:
    zT_81 = 0;
    zT_82 = (unsigned int)zT_81;
    ri = zT_82;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_84 = old_occupied[ri];
    if ((unsigned char)(zT_84 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_88 = old_keys[ri];
    k = zT_88;
    zT_90 = old_values[ri];
    v = zT_90;
    zT_92 = 1;
    zT_93 = zig_wrap_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_94 = zig_overflow_flag_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_96 = zT_94 == (unsigned int)(0);
    if (!(zT_96)) { pal_trap(); }
    mask2 = zT_93;
    zT_99 = k & (zT_79FAE712_u64)(4294967295u);
    zT_100 = (unsigned int)zig_cast_checked_u((zu64)zT_99, 64u, 0u, 32u);
    zT_102 = (unsigned int)((unsigned int)zT_100) & mask2;
    idx = zT_102;
    goto z_bb_23;
    z_bb_22:
    zT_124 = 1;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    ri = zT_126;
    goto z_bb_20;
    z_bb_23:
    zT_103 = self->occupied;
    zT_104 = zT_103[idx];
    if ((unsigned char)(zT_104 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_107 = 1;
    zT_108 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_107)), 32u);
    zT_109 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_107)), 32u);
    zT_111 = zT_109 == (unsigned int)(0);
    if (!(zT_111)) { pal_trap(); }
    zT_112 = zT_108 & mask2;
    idx = zT_112;
    goto z_bb_26;
    z_bb_25:
    zT_113 = self->keys;
    zT_113[idx] = k;
    zT_114 = self->values;
    zT_114[idx] = v;
    zT_115 = 1;
    zT_116 = self->occupied;
    zT_116[idx] = zT_115;
    zT_117 = self->count;
    zT_118 = 1;
    zT_119 = (unsigned int)zT_118;
    zT_120 = zig_wrap_add_u(((zu64)(zT_117)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_add_u(((zu64)(zT_117)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    self->count = zT_120;
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u64ToU32MapPut */
void zF_B6EB812C_u64ToU32MapPut(zT_A4CE86B7_U64ToU32Map* self, zT_79FAE712_u64 key, unsigned int value) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    unsigned int zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_79FAE712_u64 zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned char* zT_34;
    unsigned char zT_35;
    zT_79FAE712_u64* zT_38;
    zT_79FAE712_u64 zT_39;
    unsigned int* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    unsigned int zT_47;
    zT_79FAE712_u64* zT_48;
    unsigned int* zT_49;
    unsigned char zT_50;
    unsigned char* zT_51;
    unsigned int zT_52;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_4 = 4;
    zT_5 = zig_wrap_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    zT_9 = self->capacity;
    zT_10 = 3;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    if ((unsigned char)(zT_5 >= zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zF_FE9D19D4_u64ToU32MapGrow(zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_17 = self->capacity;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = self;
    zF_FE9D19D4_u64ToU32MapGrow(zT_20);
    goto z_bb_4;
    z_bb_4:
    zT_22 = self->capacity;
    zT_23 = 1;
    zT_24 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    mask = zT_24;
    zT_30 = key & (zT_79FAE712_u64)(4294967295u);
    zT_31 = (unsigned int)zig_cast_checked_u((zu64)zT_30, 64u, 0u, 32u);
    zT_33 = (unsigned int)((unsigned int)zT_31) & mask;
    i = zT_33;
    goto z_bb_5;
    z_bb_5:
    zT_34 = self->occupied;
    zT_35 = zT_34[i];
    if ((unsigned char)(zT_35 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_38 = self->keys;
    zT_39 = zT_38[i];
    if ((unsigned char)(zT_39 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_48 = self->keys;
    zT_48[i] = key;
    zT_49 = self->values;
    zT_49[i] = value;
    zT_50 = 1;
    zT_51 = self->occupied;
    zT_51[i] = zT_50;
    zT_52 = self->count;
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(zT_52)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(zT_52)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    self->count = zT_55;
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_41 = self->values;
    zT_41[i] = value;
    return;
    z_bb_10:
    zT_42 = 1;
    zT_43 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_44 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_42)), 32u);
    zT_46 = zT_44 == (unsigned int)(0);
    if (!(zT_46)) { pal_trap(); }
    zT_47 = zT_43 & mask;
    i = zT_47;
    goto z_bb_8;
}

/* u32ToU64MapInit */
zT_89877D19_U32ToU64Map zF_A8016047_u32ToU64MapInit(zT_3E40CD83_Sand* alloc) {
    zT_89877D19_U32ToU64Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.keys = (unsigned int*)zT_2;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zT_1.values = (zT_79FAE712_u64*)zT_3;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u32ToU64MapInitCap */
zT_89877D19_U32ToU64Map zF_9FD4CEE5_u32ToU64MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_7;
    zT_89877D19_U32ToU64Map zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_FDFD82FD_EU_362 zT_19;
    unsigned char zT_20;
    unsigned char* zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_3E40CD83_Sand* zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    zT_FDFD82FD_EU_362 zT_47;
    unsigned char zT_48;
    unsigned char* zT_49;
    int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    zT_89877D19_U32ToU64Map zT_62;
    unsigned int* zT_63;
    zT_79FAE712_u64* zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_47, (unsigned int)sizeof zT_47);
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_A8016047_u32ToU64MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_13 = 4;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(cap)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_11 = zT_14;
    zT_19 = zF_1395EB68_sandAlloc(zT_10, zT_11, (unsigned int)(4));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_21 = zT_19.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_21;
    zT_24 = alloc;
    zT_27 = 8;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(cap)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_25 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_24, zT_25, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_35 = zT_33.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_35;
    zT_38 = alloc;
    zT_41 = 1;
    zT_42 = zig_wrap_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_43 = zig_overflow_flag_mul_u(((zu64)(zT_41)), ((zu64)(cap)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    zT_39 = zT_42;
    zT_47 = zF_1395EB68_sandAlloc(zT_38, zT_39, (unsigned int)(4));
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_49 = zT_47.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_49;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    zi = zT_53;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_55 = 0;
    raw_occ[zi] = zT_55;
    goto z_bb_15;
    z_bb_14:
    zT_63 = (unsigned int*)raw_keys;
    zT_62.keys = zT_63;
    zT_64 = (zT_79FAE712_u64*)raw_vals;
    zT_62.values = zT_64;
    zT_65 = (unsigned char*)raw_occ;
    zT_62.occupied = zT_65;
    zT_62.capacity = cap;
    zT_66 = 0;
    zT_62.count = zT_66;
    zT_62.alloc = alloc;
    return zT_62;
    z_bb_15:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zi = zT_58;
    goto z_bb_12;
}

/* u32ToU64MapGet */
zT_BBEE1AC1_Opt_11 zF_6233601B_u32ToU64MapGet(zT_89877D19_U32ToU64Map* self, unsigned int key) {
    unsigned int zT_2;
    zT_BBEE1AC1_Opt_11 zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned int* zT_20;
    unsigned int zT_21;
    zT_79FAE712_u64* zT_23;
    zT_79FAE712_u64 zT_24;
    zT_BBEE1AC1_Opt_11 zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned int zT_31;
    zT_BBEE1AC1_Opt_11 zT_32;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_8 = 1;
    zT_9 = zig_wrap_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_u(((zu64)(zT_7)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    mask = zT_9;
    zT_15 = (unsigned int)((unsigned int)key) & mask;
    i = zT_15;
    goto z_bb_3;
    z_bb_3:
    zT_16 = self->occupied;
    zT_17 = zT_16[i];
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = self->keys;
    zT_21 = zT_20[i];
    if ((unsigned char)(zT_21 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_23 = self->values;
    zT_24 = zT_23[i];
    zT_25.has_value = 1;
    zT_25.value = zT_24;
    return zT_25;
    z_bb_8:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_31 = zT_27 & mask;
    i = zT_31;
    goto z_bb_6;
}

/* u32ToU64MapGrow */
void zF_28C8D766_u32ToU64MapGrow(zT_89877D19_U32ToU64Map* self) {
    unsigned int zT_2;
    unsigned int* zT_4;
    zT_79FAE712_u64* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_FDFD82FD_EU_362 zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    zT_FDFD82FD_EU_362 zT_45;
    unsigned char zT_46;
    unsigned char* zT_47;
    zT_3E40CD83_Sand* zT_50;
    unsigned int zT_51;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    zT_FDFD82FD_EU_362 zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned char* zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned int zT_88;
    zT_79FAE712_u64 zT_90;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned char zT_96;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned char zT_101;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned char zT_108;
    unsigned int zT_109;
    unsigned int* zT_110;
    zT_79FAE712_u64* zT_111;
    unsigned char zT_112;
    unsigned char* zT_113;
    unsigned int zT_114;
    int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    unsigned int old_cap;
    unsigned int* old_keys;
    zT_79FAE712_u64* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    unsigned int k;
    zT_79FAE712_u64 v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(old_cap)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_12 = zT_15;
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_20 = self->alloc;
    zT_24 = 4;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_24)), ((zu64)(new_cap)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_21 = zT_25;
    zT_30 = zF_1395EB68_sandAlloc(zT_20, zT_21, (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_32 = zT_30.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_32;
    zT_35 = self->alloc;
    zT_39 = 8;
    zT_40 = zig_wrap_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(zT_39)), ((zu64)(new_cap)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_36 = zT_40;
    zT_45 = zF_1395EB68_sandAlloc(zT_35, zT_36, (unsigned int)(4));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_47 = zT_45.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_47;
    zT_50 = self->alloc;
    zT_54 = 1;
    zT_55 = zig_wrap_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_56 = zig_overflow_flag_mul_u(((zu64)(zT_54)), ((zu64)(new_cap)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_51 = zT_55;
    zT_60 = zF_1395EB68_sandAlloc(zT_50, zT_51, (unsigned int)(4));
    zT_61 = zT_60.is_error;
    if (zT_61) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_62 = zT_60.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_62;
    self->keys = (unsigned int*)((unsigned int*)raw_keys);
    self->values = (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    zi = zT_70;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_72 = 0;
    zT_73 = self->occupied;
    zT_73[zi] = zT_72;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    zi = zT_76;
    goto z_bb_16;
    z_bb_15:
    zT_81 = 0;
    zT_82 = (unsigned int)zT_81;
    ri = zT_82;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_84 = old_occupied[ri];
    if ((unsigned char)(zT_84 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_88 = old_keys[ri];
    k = zT_88;
    zT_90 = old_values[ri];
    v = zT_90;
    zT_92 = 1;
    zT_93 = zig_wrap_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_94 = zig_overflow_flag_sub_u(((zu64)(new_cap)), ((zu64)(zT_92)), 32u);
    zT_96 = zT_94 == (unsigned int)(0);
    if (!(zT_96)) { pal_trap(); }
    mask2 = zT_93;
    zT_99 = (unsigned int)((unsigned int)k) & mask2;
    idx = zT_99;
    goto z_bb_23;
    z_bb_22:
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    ri = zT_123;
    goto z_bb_20;
    z_bb_23:
    zT_100 = self->occupied;
    zT_101 = zT_100[idx];
    if ((unsigned char)(zT_101 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_104 = 1;
    zT_105 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_104)), 32u);
    zT_106 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_104)), 32u);
    zT_108 = zT_106 == (unsigned int)(0);
    if (!(zT_108)) { pal_trap(); }
    zT_109 = zT_105 & mask2;
    idx = zT_109;
    goto z_bb_26;
    z_bb_25:
    zT_110 = self->keys;
    zT_110[idx] = k;
    zT_111 = self->values;
    zT_111[idx] = v;
    zT_112 = 1;
    zT_113 = self->occupied;
    zT_113[idx] = zT_112;
    zT_114 = self->count;
    zT_115 = 1;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zig_wrap_add_u(((zu64)(zT_114)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(zT_114)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    self->count = zT_117;
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u32ToU64MapPut */
void zF_75699BAA_u32ToU64MapPut(zT_89877D19_U32ToU64Map* self, unsigned int key, zT_79FAE712_u64 value) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_89877D19_U32ToU64Map* zT_16;
    unsigned int zT_17;
    zT_89877D19_U32ToU64Map* zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_30;
    unsigned char* zT_31;
    unsigned char zT_32;
    unsigned int* zT_35;
    unsigned int zT_36;
    zT_79FAE712_u64* zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned int* zT_45;
    zT_79FAE712_u64* zT_46;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_4 = 4;
    zT_5 = zig_wrap_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_mul_u(((zu64)(zT_3)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    zT_9 = self->capacity;
    zT_10 = 3;
    zT_11 = zig_wrap_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    if ((unsigned char)(zT_5 >= zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zF_28C8D766_u32ToU64MapGrow(zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_17 = self->capacity;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = self;
    zF_28C8D766_u32ToU64MapGrow(zT_20);
    goto z_bb_4;
    z_bb_4:
    zT_22 = self->capacity;
    zT_23 = 1;
    zT_24 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    mask = zT_24;
    zT_30 = (unsigned int)((unsigned int)key) & mask;
    i = zT_30;
    goto z_bb_5;
    z_bb_5:
    zT_31 = self->occupied;
    zT_32 = zT_31[i];
    if ((unsigned char)(zT_32 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = self->keys;
    zT_36 = zT_35[i];
    if ((unsigned char)(zT_36 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_45 = self->keys;
    zT_45[i] = key;
    zT_46 = self->values;
    zT_46[i] = value;
    zT_47 = 1;
    zT_48 = self->occupied;
    zT_48[i] = zT_47;
    zT_49 = self->count;
    zT_50 = 1;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zig_wrap_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(zT_49)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    self->count = zT_52;
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_38 = self->values;
    zT_38[i] = value;
    return;
    z_bb_10:
    zT_39 = 1;
    zT_40 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_40 & mask;
    i = zT_44;
    goto z_bb_8;
}

/* __module_init */
void zF_780653D2___module_init_12(void) {
    zT_3E40CD83_Sand zT_0;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zG_3E40CD83_Sand = zT_0;
    return;
}

/* EOF */
