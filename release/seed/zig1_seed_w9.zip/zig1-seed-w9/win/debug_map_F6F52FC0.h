#ifndef ZIG_MODULE_DEBUG_MAP_F6F52FC0_H
#define ZIG_MODULE_DEBUG_MAP_F6F52FC0_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "spill_store_AC8E76BA.h"
#include "lir_64CB5435.h"
#include "source_manager_0C564FCF.h"
#include "name_mangler_27ED89E2.h"
#include "string_interner_51340A9F.h"
#include "module_registry_03A5D1FC.h"
#include "type_registry_8EE489B8.h"
#include "growable_array_6014E5AF.h"


/* Forward declarations */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_DEE7AA30_magicSyms(void);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4FFC9427_magicLines(void);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_ED717857_magicCnames(void);
unsigned int zF_E2575727_minUsize(unsigned int, unsigned int);
int zF_7814455F_strCompare(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_C615AE29_DebugSpanStore zF_A1EED937_debugSpanStoreInit(void);
void zF_D0C0DC7A_debugSpanIndexEnsur(zT_C615AE29_DebugSpanStore*, unsigned int);
void zF_7FA61CF5_debugSpanStoreOpen(zT_C615AE29_DebugSpanStore*, zT_3E40CD83_Sand*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_33C87494_debugSpanSort(zT_34BFE5CB_Slice_zT_10BDA76C_D);
void zF_FE62D392_debugStoreWriteU32(zT_C615AE29_DebugSpanStore*, unsigned int);
void zF_BB256CBD_debugSpanStoreAppen(zT_C615AE29_DebugSpanStore*, unsigned int, zT_34BFE5CB_Slice_zT_10BDA76C_D);
zT_E03A1DC3_Opt_204 zF_92DA876F_debugSpanStoreLooku(zT_C615AE29_DebugSpanStore*, unsigned int);
unsigned int zF_CC56B3A5_debugStoreReadU32(zT_C615AE29_DebugSpanStore*, unsigned int);
void zF_9C00E029_debugSpanStoreRead(zT_C615AE29_DebugSpanStore*, zT_4C3DEF60_DebugFnSpanIndex, zT_34BFE5CB_Slice_zT_10BDA76C_D);
void zF_BE98E387_debugSpanStoreClose(zT_C615AE29_DebugSpanStore*);
unsigned int zF_AA3D1D7E_debugSpanLookup(zT_34BFE5CB_Slice_zT_10BDA76C_D, unsigned int, unsigned int);
zT_8B83E3B4_DebugSymbolList zF_5779AF56_debugSymbolListInit(zT_3E40CD83_Sand*);
void zF_7E8D0B2A_debugSymbolListEnsu(zT_8B83E3B4_DebugSymbolList*, unsigned int);
void zF_3CC05A74_debugSymbolListAppe(zT_8B83E3B4_DebugSymbolList*, zT_1001656C_DebugSymbol);
zT_E23A20E9_Opt_206 zF_C72C1B0F_debugSymbolFindFn(zT_8B83E3B4_DebugSymbolList*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_D3EB6303_StringInterner*);
void zF_D70BEADC_debugOutOpen(zT_BEF92BCA_DebugOutFile*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_C9405045_debugOutWriteU16(zT_BEF92BCA_DebugOutFile*, unsigned short);
void zF_D53BE5FB_debugOutWriteU32(zT_BEF92BCA_DebugOutFile*, unsigned int);
void zF_BFE5287E_debugOutWriteBytes(zT_BEF92BCA_DebugOutFile*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_D8B6F339_debugOutWriteStr16P(zT_BEF92BCA_DebugOutFile*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_5C16527D_debugOutWriteStr16(zT_BEF92BCA_DebugOutFile*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_4A7C5D00_debugOutClose(zT_BEF92BCA_DebugOutFile*, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_DEDDFC41_DebugMapWriter zF_CCB1E6BF_debugMapWriterInit(void);
void zF_ED14666D_debugMapWriterOpen(zT_DEDDFC41_DebugMapWriter*, zT_3E40CD83_Sand*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_FFA3F32B_debugMapWriterBegin(zT_DEDDFC41_DebugMapWriter*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_1565BCB0_debugMapFlushLast(zT_DEDDFC41_DebugMapWriter*);
void zF_6CD06D0D_debugMapWriterAddRu(zT_DEDDFC41_DebugMapWriter*, unsigned int, unsigned int, unsigned int);
void zF_B7665FFF_debugMapWriterEndLi(zT_DEDDFC41_DebugMapWriter*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_D560F1C1_debugModuleStem(zT_CEC2984A_NameMangler*, zT_D3EB6303_StringInterner*, zT_072B53A6_ModuleRegistry*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7A9322C_debugSymbolSrcFile(zT_1001656C_DebugSymbol, zT_227EDE07_SourceManager*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_EA891367_debugSymbolName(zT_1001656C_DebugSymbol, zT_D3EB6303_StringInterner*);
unsigned char zF_48A32BF5_debugSymbolLess(zT_1001656C_DebugSymbol, zT_1001656C_DebugSymbol, zT_227EDE07_SourceManager*, zT_D3EB6303_StringInterner*);
unsigned char zF_D5054183_debugCnameLess(zT_1001656C_DebugSymbol, zT_1001656C_DebugSymbol, zT_D3EB6303_StringInterner*);
void zF_48EEEA4F_debugMapWriterClose(zT_DEDDFC41_DebugMapWriter*, zT_3E40CD83_Sand*, zT_39D2FAA1_Slice_zT_1001656C_D, zT_227EDE07_SourceManager*, zT_CEC2984A_NameMangler*, zT_D3EB6303_StringInterner*, zT_072B53A6_ModuleRegistry*, zT_338B7C76_TypeRegistry*);
/* Storage globals (extern decls) */
extern unsigned int const zG_24C75564_HEADER_LEN;
extern unsigned int const zG_D3BBB9B7_VERSION;

#endif /* ZIG_MODULE_DEBUG_MAP_F6F52FC0_H */
