#include "debug_map_F6F52FC0.h"
unsigned int const zG_24C75564_HEADER_LEN = (unsigned int)(20);
unsigned int const zG_D3BBB9B7_VERSION = (unsigned int)(1);
/* magicSyms */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_DEE7AA30_magicSyms(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGsy";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* magicLines */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4FFC9427_magicLines(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGln";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* magicCnames */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_ED717857_magicCnames(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGcn";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* minUsize */
unsigned int zF_E2575727_minUsize(unsigned int a, unsigned int b) {
    if ((unsigned char)(a < b)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return a;
    z_bb_2:
    return b;
}

/* strCompare */
int zF_7814455F_strCompare(zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    int zT_22;
    int zT_23;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    int zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    int zT_46;
    int zT_47;
    unsigned int zT_50;
    unsigned int zT_52;
    int zT_54;
    int zT_56;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    unsigned int n;
    unsigned int i;
    zT_3 = a.len;
    zT_4 = b.len;
    zT_9 = zF_E2575727_minUsize(zT_3, zT_4);
    n = zT_9;
    zT_11 = 0;
    i = zT_11;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = a.ptr;
    zT_14 = a.len;
    zT_15 = i < zT_14;
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_13[i];
    zT_17 = b.ptr;
    zT_18 = b.len;
    zT_19 = i < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[i];
    if ((unsigned char)(zT_16 < zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_42 = a.len;
    zT_44 = b.len;
    if ((unsigned char)(zT_42 < zT_44)) goto z_bb_9; else goto z_bb_10;
    z_bb_4:
    zT_36 = 1;
    zT_37 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_36)), 32u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    i = zT_37;
    goto z_bb_1;
    z_bb_5:
    zT_22 = 1;
    zT_23 = -zT_22;
    return (int)((int)zT_23);
    z_bb_6:
    zT_25 = a.ptr;
    zT_26 = a.len;
    zT_27 = i < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    zT_29 = b.ptr;
    zT_30 = b.len;
    zT_31 = i < zT_30;
    if (!(zT_31)) { pal_trap(); }
    zT_32 = zT_29[i];
    if ((unsigned char)(zT_28 > zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = 1;
    return (int)((int)zT_34);
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_46 = 1;
    zT_47 = -zT_46;
    return (int)((int)zT_47);
    z_bb_10:
    zT_50 = a.len;
    zT_52 = b.len;
    if ((unsigned char)(zT_50 > zT_52)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_54 = 1;
    return (int)((int)zT_54);
    z_bb_12:
    zT_56 = 0;
    return (int)((int)zT_56);
}

/* debugSpanStoreInit */
zT_C615AE29_DebugSpanStore zF_A1EED937_debugSpanStoreInit(void) {
    zT_C615AE29_DebugSpanStore zT_0;
    zT_D21A8776_SpillStore zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned char zT_6;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_0.index_items = (zT_4C3DEF60_DebugFnSpanIndex*)zT_2;
    zT_3 = 0;
    zT_0.index_len = zT_3;
    zT_4 = 0;
    zT_0.index_capacity = zT_4;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_0.alloc = (zT_3E40CD83_Sand*)zT_5;
    zT_6 = 0;
    zT_0.enabled = zT_6;
    return zT_0;
}

/* debugSpanIndexEnsure */
void zF_D0C0DC7A_debugSpanIndexEnsur(zT_C615AE29_DebugSpanStore* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_FDFD82FD_EU_362 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_4C3DEF60_DebugFnSpanIndex* zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_4C3DEF60_DebugFnSpanIndex* zT_36;
    zT_4C3DEF60_DebugFnSpanIndex zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int cap;
    unsigned char* raw;
    zT_4C3DEF60_DebugFnSpanIndex* dst;
    unsigned int i;
    zT_2 = self->index_capacity;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->index_capacity;
    cap = zT_5;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 16;
    cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_16 = self->alloc;
    zT_20 = 12;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(cap)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(cap)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_17 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_16, zT_17, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_10 = 2;
    zT_11 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_28 = zT_26.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_28;
    zT_31 = (zT_4C3DEF60_DebugFnSpanIndex*)raw;
    dst = zT_31;
    zT_33 = 0;
    i = zT_33;
    goto z_bb_12;
    z_bb_12:
    zT_34 = self->index_len;
    if ((unsigned char)(i < zT_34)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36 = self->index_items;
    zT_37 = zT_36[i];
    dst[i] = zT_37;
    goto z_bb_15;
    z_bb_14:
    self->index_items = dst;
    self->index_capacity = cap;
    return;
    z_bb_15:
    zT_38 = 1;
    zT_39 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    i = zT_39;
    goto z_bb_12;
}

/* debugSpanStoreOpen */
void zF_7FA61CF5_debugSpanStoreOpen(zT_C615AE29_DebugSpanStore* self, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    unsigned char* zT_4;
    zT_D21A8776_SpillStore* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    unsigned char* mode;
    self->alloc = alloc;
    zT_4 = "w+b";
    mode = zT_4;
    zT_5 = &self->spill;
    zT_7 = path;
    zT_8 = alloc;
    zT_9 = mode;
    zF_8AF94F71_spillOpen(zT_5, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_7, zT_8, zT_9);
    self->index_len = (unsigned int)(0);
    self->enabled = (unsigned char)(1);
    return;
}

/* debugSpanSort */
void zF_33C87494_debugSpanSort(zT_34BFE5CB_Slice_zT_10BDA76C_D spans) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_10BDA76C_DebugSpanEntry* zT_7;
    unsigned int zT_8;
    unsigned char zT_9;
    zT_10BDA76C_DebugSpanEntry zT_10;
    zT_10BDA76C_DebugSpanEntry* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned char zT_22;
    zT_10BDA76C_DebugSpanEntry zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_10BDA76C_DebugSpanEntry* zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    zT_10BDA76C_DebugSpanEntry* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_52;
    unsigned int i;
    zT_10BDA76C_DebugSpanEntry key;
    unsigned int j;
    zT_10BDA76C_DebugSpanEntry prev;
    unsigned char after;
    zT_2 = 1;
    i = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_4 = spans.len;
    if ((unsigned char)(i < zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = spans.ptr;
    zT_8 = spans.len;
    zT_9 = i < zT_8;
    if (!(zT_9)) { pal_trap(); }
    zT_10 = zT_7[i];
    key = zT_10;
    j = i;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_48 = 1;
    zT_49 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_48)), 32u);
    zT_50 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_48)), 32u);
    zT_52 = zT_50 == (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    i = zT_49;
    goto z_bb_1;
    z_bb_5:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = spans.ptr;
    zT_16 = 1;
    zT_17 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = spans.len;
    zT_22 = zT_17 < zT_21;
    if (!(zT_22)) { pal_trap(); }
    zT_23 = zT_15[zT_17];
    prev = zT_23;
    zT_25 = prev.bb;
    zT_26 = key.bb;
    if ((unsigned char)(zT_25 > zT_26)) goto z_bb_10; else goto z_bb_9;
    z_bb_7:
    zT_45 = spans.ptr;
    zT_46 = spans.len;
    zT_47 = j < zT_46;
    if (!(zT_47)) { pal_trap(); }
    zT_45[j] = key;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_29 = prev.bb;
    zT_30 = key.bb;
    if ((unsigned char)(zT_29 == zT_30)) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_28 = 1;
    goto z_bb_11;
    z_bb_11:
    after = zT_28;
    if ((unsigned char)(!after)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_33 = prev.inst;
    zT_34 = key.inst;
    zT_32 = zT_33 > zT_34;
    goto z_bb_14;
    z_bb_13:
    zT_32 = 0;
    goto z_bb_14;
    z_bb_14:
    zT_28 = zT_32;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_37 = spans.ptr;
    zT_38 = spans.len;
    zT_39 = j < zT_38;
    if (!(zT_39)) { pal_trap(); }
    zT_37[j] = prev;
    zT_40 = 1;
    zT_41 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_40)), 32u);
    zT_42 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_40)), 32u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    j = zT_41;
    goto z_bb_8;
}

/* debugStoreWriteU32 */
void zF_FE62D392_debugStoreWriteU32(zT_C615AE29_DebugSpanStore* self, unsigned int value) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_17;
    unsigned char zT_19;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned char zT_39;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_D21A8776_SpillStore zT_44;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = value & (unsigned int)(255);
    zT_6 = (unsigned char)zig_cast_checked_u((zu64)zT_5, 32u, 0u, 8u);
    zT_7 = 0;
    zT_9 = (unsigned int)zT_7 < (unsigned int)(4);
    if (!(zT_9)) { pal_trap(); }
    b[zT_7] = zT_6;
    zT_13 = 1;
    if (!(zT_13)) { pal_trap(); }
    zT_15 = (unsigned int)(value >> (unsigned int)(8)) & (unsigned int)(255);
    zT_16 = (unsigned char)zig_cast_checked_u((zu64)zT_15, 32u, 0u, 8u);
    zT_17 = 1;
    zT_19 = (unsigned int)zT_17 < (unsigned int)(4);
    if (!(zT_19)) { pal_trap(); }
    b[zT_17] = zT_16;
    zT_23 = 1;
    if (!(zT_23)) { pal_trap(); }
    zT_25 = (unsigned int)(value >> (unsigned int)(16)) & (unsigned int)(255);
    zT_26 = (unsigned char)zig_cast_checked_u((zu64)zT_25, 32u, 0u, 8u);
    zT_27 = 2;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(4);
    if (!(zT_29)) { pal_trap(); }
    b[zT_27] = zT_26;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_35 = (unsigned int)(value >> (unsigned int)(24)) & (unsigned int)(255);
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_35, 32u, 0u, 8u);
    zT_37 = 3;
    zT_39 = (unsigned int)zT_37 < (unsigned int)(4);
    if (!(zT_39)) { pal_trap(); }
    b[zT_37] = zT_36;
    zT_40 = &self->spill;
    zT_44 = self->spill;
    zT_41 = zT_44.cur;
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)b) + zT_48;
    zT_50 = (unsigned int)(4) - zT_48;
    zT_51.ptr = (unsigned char*)zT_49;
    zT_51.len = zT_50;
    zT_42 = zT_51;
    zF_BFB33631_spillWriteAt(zT_40, zT_41, zT_42);
    return;
}

/* debugSpanStoreAppend */
void zF_BB256CBD_debugSpanStoreAppen(zT_C615AE29_DebugSpanStore* self, unsigned int disk_offset, zT_34BFE5CB_Slice_zT_10BDA76C_D spans) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned int zT_8;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_11;
    zT_C615AE29_DebugSpanStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    zT_4C3DEF60_DebugFnSpanIndex zT_21;
    zT_D21A8776_SpillStore zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_C615AE29_DebugSpanStore* zT_27;
    unsigned int zT_30;
    zT_D21A8776_SpillStore* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_D21A8776_SpillStore zT_36;
    zT_10BDA76C_DebugSpanEntry* zT_39;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_4C3DEF60_DebugFnSpanIndex* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_4C3DEF60_DebugFnSpanIndex rec;
    zT_3 = self->enabled;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = spans.len;
    zT_6 = zT_8 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_11 = spans;
    zF_33C87494_debugSpanSort(zT_11);
    zT_12 = self;
    zT_14 = self->index_len;
    zT_15 = 1;
    zT_16 = zig_wrap_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(zT_14)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    zT_13 = zT_16;
    zF_D0C0DC7A_debugSpanIndexEnsur(zT_12, zT_13);
    zT_21.disk_offset = disk_offset;
    zT_22 = self->spill;
    zT_23 = zT_22.cur;
    zT_21.spill_offset = zT_23;
    zT_25 = spans.len;
    zT_26 = (unsigned int)zT_25;
    zT_21.count = zT_26;
    rec = zT_21;
    zT_27 = self;
    zT_30 = spans.len;
    zF_FE62D392_debugStoreWriteU32(zT_27, (unsigned int)((unsigned int)zT_30));
    zT_32 = &self->spill;
    zT_36 = self->spill;
    zT_33 = zT_36.cur;
    zT_39 = spans.ptr;
    zT_42 = spans.len;
    zT_43 = 12;
    zT_44 = zig_wrap_mul_u(((zu64)(zT_42)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(zT_42)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)zT_39) + zT_48;
    zT_50 = zT_44 - zT_48;
    zT_51 = (unsigned int)zT_48 <= zT_44;
    if (!(zT_51)) { pal_trap(); }
    zT_52.ptr = (unsigned char*)zT_49;
    zT_52.len = zT_50;
    zT_34 = zT_52;
    zF_BFB33631_spillWriteAt(zT_32, zT_33, zT_34);
    zT_53 = self->index_items;
    zT_54 = self->index_len;
    zT_53[zT_54] = rec;
    zT_55 = self->index_len;
    zT_56 = 1;
    zT_57 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    self->index_len = zT_57;
    return;
}

/* debugSpanStoreLookup */
zT_5EC03ACD_Opt_196 zF_92DA876F_debugSpanStoreLooku(zT_C615AE29_DebugSpanStore* self, unsigned int disk_offset) {
    unsigned char zT_2;
    zT_5EC03ACD_Opt_196 zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_4C3DEF60_DebugFnSpanIndex* zT_10;
    zT_4C3DEF60_DebugFnSpanIndex zT_11;
    unsigned int zT_12;
    zT_4C3DEF60_DebugFnSpanIndex* zT_14;
    zT_4C3DEF60_DebugFnSpanIndex zT_15;
    zT_5EC03ACD_Opt_196 zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_5EC03ACD_Opt_196 zT_22;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    unsigned int i;
    zT_2 = self->enabled;
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = 0;
    i = zT_7;
    goto z_bb_3;
    z_bb_3:
    zT_8 = self->index_len;
    if ((unsigned char)(i < zT_8)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->index_items;
    zT_11 = zT_10[i];
    zT_12 = zT_11.disk_offset;
    if ((unsigned char)(zT_12 == disk_offset)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_22.has_value = 0;
    return zT_22;
    z_bb_6:
    zT_17 = 1;
    zT_18 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    i = zT_18;
    goto z_bb_3;
    z_bb_7:
    zT_14 = self->index_items;
    zT_15 = zT_14[i];
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_8:
    goto z_bb_6;
}

/* debugStoreReadU32 */
unsigned int zF_CC56B3A5_debugStoreReadU32(zT_C615AE29_DebugSpanStore* self, unsigned int off) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14;
    unsigned char zT_16;
    unsigned char zT_17;
    int zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    int zT_32;
    unsigned char zT_34;
    unsigned char zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    int zT_45;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = &self->spill;
    zT_5 = off;
    zT_10 = 0;
    zT_11 = (unsigned char*)((unsigned char*)b) + zT_10;
    zT_12 = (unsigned int)(4) - zT_10;
    zT_13.ptr = (unsigned char*)zT_11;
    zT_13.len = zT_12;
    zT_6 = zT_13;
    zF_E9F67450_spillReadAt(zT_4, zT_5, zT_6);
    zT_14 = 0;
    zT_16 = (unsigned int)zT_14 < (unsigned int)(4);
    if (!(zT_16)) { pal_trap(); }
    zT_17 = b[zT_14];
    zT_19 = 1;
    zT_21 = (unsigned int)zT_19 < (unsigned int)(4);
    if (!(zT_21)) { pal_trap(); }
    zT_22 = b[zT_19];
    zT_23 = (unsigned int)zT_22;
    zT_24 = 8;
    zT_27 = 1;
    if (!(zT_27)) { pal_trap(); }
    zT_25 = zig_wrap_shl_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zig_overflow_flag_shl_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    zT_32 = 2;
    zT_34 = (unsigned int)zT_32 < (unsigned int)(4);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = b[zT_32];
    zT_36 = (unsigned int)zT_35;
    zT_37 = 16;
    zT_40 = 1;
    if (!(zT_40)) { pal_trap(); }
    zT_38 = zig_wrap_shl_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_41 = zig_overflow_flag_shl_u(((zu64)(zT_36)), ((zu64)(zT_37)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_45 = 3;
    zT_47 = (unsigned int)zT_45 < (unsigned int)(4);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = b[zT_45];
    zT_49 = (unsigned int)zT_48;
    zT_50 = 24;
    zT_53 = 1;
    if (!(zT_53)) { pal_trap(); }
    zT_51 = zig_wrap_shl_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_54 = zig_overflow_flag_shl_u(((zu64)(zT_49)), ((zu64)(zT_50)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    return (unsigned int)((unsigned int)((unsigned int)((unsigned int)((unsigned int)zT_17) | zT_25) | zT_38) | zT_51);
}

/* debugSpanStoreRead */
void zF_9C00E029_debugSpanStoreRead(zT_C615AE29_DebugSpanStore* self, zT_4C3DEF60_DebugFnSpanIndex rec, zT_34BFE5CB_Slice_zT_10BDA76C_D dst) {
    unsigned int zT_4;
    zT_C615AE29_DebugSpanStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_D21A8776_SpillStore* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    zT_10BDA76C_DebugSpanEntry* zT_36;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    unsigned int count;
    unsigned int n;
    unsigned int byte_len;
    zT_4 = dst.len;
    if ((unsigned char)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self;
    zT_9 = rec.spill_offset;
    zT_11 = zF_CC56B3A5_debugStoreReadU32(zT_8, zT_9);
    count = zT_11;
    zT_13 = (unsigned int)count;
    n = zT_13;
    zT_15 = dst.len;
    if ((unsigned char)(n > zT_15)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = dst.len;
    n = zT_18;
    goto z_bb_4;
    z_bb_4:
    zT_20 = 12;
    zT_21 = zig_wrap_mul_u(((zu64)(n)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(n)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    byte_len = zT_21;
    zT_25 = &self->spill;
    zT_29 = rec.spill_offset;
    zT_30 = 4;
    zT_31 = zig_wrap_add_u(((zu64)(zT_29)), ((zu64)(zT_30)), 32u);
    zT_32 = zig_overflow_flag_add_u(((zu64)(zT_29)), ((zu64)(zT_30)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_26 = zT_31;
    zT_36 = dst.ptr;
    zT_38 = 0;
    zT_39 = (unsigned char*)((unsigned char*)zT_36) + zT_38;
    zT_40 = byte_len - zT_38;
    zT_41 = (unsigned int)zT_38 <= byte_len;
    if (!(zT_41)) { pal_trap(); }
    zT_42.ptr = (unsigned char*)zT_39;
    zT_42.len = zT_40;
    zT_27 = zT_42;
    zF_E9F67450_spillReadAt(zT_25, zT_26, zT_27);
    return;
}

/* debugSpanStoreClose */
void zF_BE98E387_debugSpanStoreClose(zT_C615AE29_DebugSpanStore* self) {
    unsigned char zT_1;
    zT_D21A8776_SpillStore* zT_4;
    zT_1 = self->enabled;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_4);
    self->enabled = (unsigned char)(0);
    return;
}

/* debugSpanLookup */
unsigned int zF_AA3D1D7E_debugSpanLookup(zT_34BFE5CB_Slice_zT_10BDA76C_D spans, unsigned int bb, unsigned int inst) {
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_10BDA76C_DebugSpanEntry* zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    zT_10BDA76C_DebugSpanEntry zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int lo;
    unsigned int hi;
    unsigned int mid;
    zT_10BDA76C_DebugSpanEntry e;
    zT_4 = 0;
    lo = zT_4;
    zT_7 = spans.len;
    hi = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(lo < hi)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = zig_wrap_sub_u(((zu64)(hi)), ((zu64)(lo)), 32u);
    zT_11 = zig_overflow_flag_sub_u(((zu64)(hi)), ((zu64)(lo)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    zT_17 = 1;
    if (!(zT_17)) { pal_trap(); }
    zT_15 = zT_10 / (unsigned int)(2);
    zT_18 = zig_wrap_add_u(((zu64)(lo)), ((zu64)(zT_15)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(lo)), ((zu64)(zT_15)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    mid = zT_18;
    zT_23 = spans.ptr;
    zT_24 = spans.len;
    zT_25 = mid < zT_24;
    if (!(zT_25)) { pal_trap(); }
    zT_26 = zT_23[mid];
    e = zT_26;
    zT_27 = e.bb;
    if ((unsigned char)(zT_27 < bb)) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_30 = e.bb;
    if ((unsigned char)(zT_30 == bb)) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_29 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_11; else goto z_bb_13;
    z_bb_8:
    zT_33 = e.inst;
    zT_32 = zT_33 < inst;
    goto z_bb_10;
    z_bb_9:
    zT_32 = 0;
    goto z_bb_10;
    z_bb_10:
    zT_29 = zT_32;
    goto z_bb_7;
    z_bb_11:
    zT_35 = 1;
    zT_36 = zig_wrap_add_u(((zu64)(mid)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(mid)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    lo = zT_36;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_40 = e.bb;
    if ((unsigned char)(zT_40 > bb)) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_43 = e.bb;
    if ((unsigned char)(zT_43 == bb)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_20; else goto z_bb_22;
    z_bb_17:
    zT_46 = e.inst;
    zT_45 = zT_46 > inst;
    goto z_bb_19;
    z_bb_18:
    zT_45 = 0;
    goto z_bb_19;
    z_bb_19:
    zT_42 = zT_45;
    goto z_bb_16;
    z_bb_20:
    hi = mid;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_12;
    z_bb_22:
    zT_48 = e.span_start;
    return zT_48;
}

/* debugSymbolListInit */
zT_8B83E3B4_DebugSymbolList zF_5779AF56_debugSymbolListInit(zT_3E40CD83_Sand* allocator) {
    zT_8B83E3B4_DebugSymbolList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.items = (zT_1001656C_DebugSymbol*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* debugSymbolListEnsure */
void zF_7E8D0B2A_debugSymbolListEnsu(zT_8B83E3B4_DebugSymbolList* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_FDFD82FD_EU_362 zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_1001656C_DebugSymbol* zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_1001656C_DebugSymbol* zT_36;
    zT_1001656C_DebugSymbol zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int cap;
    unsigned char* raw;
    zT_1001656C_DebugSymbol* dst;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->capacity;
    cap = zT_5;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 32;
    cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_16 = self->allocator;
    zT_20 = 28;
    zT_21 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(cap)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(cap)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_17 = zT_21;
    zT_26 = zF_1395EB68_sandAlloc(zT_16, zT_17, (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_10 = 2;
    zT_11 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_28 = zT_26.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_28;
    zT_31 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_31;
    zT_33 = 0;
    i = zT_33;
    goto z_bb_12;
    z_bb_12:
    zT_34 = self->len;
    if ((unsigned char)(i < zT_34)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36 = self->items;
    zT_37 = zT_36[i];
    dst[i] = zT_37;
    goto z_bb_15;
    z_bb_14:
    self->items = dst;
    self->capacity = cap;
    return;
    z_bb_15:
    zT_38 = 1;
    zT_39 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    i = zT_39;
    goto z_bb_12;
}

/* debugSymbolListAppend */
void zF_3CC05A74_debugSymbolListAppe(zT_8B83E3B4_DebugSymbolList* self, zT_1001656C_DebugSymbol value) {
    zT_8B83E3B4_DebugSymbolList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_1001656C_DebugSymbol* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_7E8D0B2A_debugSymbolListEnsu(zT_2, zT_3);
    zT_10 = self->items;
    zT_11 = self->len;
    zT_10[zT_11] = value;
    zT_12 = self->len;
    zT_13 = 1;
    zT_14 = zig_wrap_add_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_add_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    self->len = zT_14;
    return;
}

/* debugSymbolFindFn */
zT_50C024C3_Opt_198 zF_C72C1B0F_debugSymbolFindFn(zT_8B83E3B4_DebugSymbolList* self, unsigned int module_id, zT_8F083A69_Slice_zT_0B42B2F8_u name, zT_D3EB6303_StringInterner* interner) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1001656C_DebugSymbol* zT_9;
    zT_1001656C_DebugSymbol zT_10;
    unsigned char zT_11;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_D3EB6303_StringInterner* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_22;
    int zT_23;
    zT_50C024C3_Opt_198 zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_50C024C3_Opt_198 zT_31;
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    unsigned int i;
    zT_1001656C_DebugSymbol s;
    zT_5 = 0;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self->items;
    zT_10 = zT_9[i];
    s = zT_10;
    zT_11 = s.kind;
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_31.has_value = 0;
    return zT_31;
    z_bb_4:
    zT_26 = 1;
    zT_27 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    i = zT_27;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = s.module_id;
    if ((unsigned char)(zT_14 != module_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = interner;
    zT_19 = s.name_id;
    zT_21 = zF_9134020D_stringInternerGet(zT_18, zT_19);
    zT_16 = zT_21;
    zT_17 = name;
    zT_22 = zF_7814455F_strCompare(zT_16, zT_17);
    zT_23 = 0;
    if ((unsigned char)(zT_22 == zT_23)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25.has_value = 1;
    zT_25.value = s;
    return zT_25;
    z_bb_10:
    goto z_bb_4;
}

/* debugOutOpen */
void zF_D70BEADC_debugOutOpen(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u magic) {
    zT_D21A8776_SpillStore zT_4;
    unsigned char* zT_6;
    zT_D21A8776_SpillStore* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand* zT_10;
    unsigned char* zT_11;
    zT_D21A8776_SpillStore* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_D21A8776_SpillStore zT_20;
    zT_B5AAF170_Arr_unsigned_char_4 zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_27;
    unsigned char zT_28;
    int zT_29;
    unsigned char zT_31;
    unsigned char zT_32;
    int zT_33;
    unsigned char zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned char zT_39;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_D21A8776_SpillStore zT_44;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_B5AAF170_Arr_unsigned_char_4 zT_53;
    int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    zT_D21A8776_SpillStore* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_D21A8776_SpillStore zT_66;
    int zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_D21A8776_SpillStore* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_D21A8776_SpillStore zT_78;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    unsigned char* mode;
    zT_B5AAF170_Arr_unsigned_char_4 ver;
    zT_B5AAF170_Arr_unsigned_char_4 zero;
    zT_4 = zF_22C79E6C_spillStoreInit();
    out->store = zT_4;
    zT_6 = "w+b";
    mode = zT_6;
    zT_7 = &out->store;
    zT_9 = path;
    zT_10 = alloc;
    zT_11 = mode;
    zF_8AF94F71_spillOpen(zT_7, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_9, zT_10, zT_11);
    out->count = (unsigned int)(0);
    zT_16 = &out->store;
    zT_20 = out->store;
    zT_17 = zT_20.cur;
    zT_18 = magic;
    zF_BFB33631_spillWriteAt(zT_16, zT_17, zT_18);
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        ver[_i] = zT_23[_i];
        _i++;
    }
}
    zT_24 = 1;
    zT_25 = 0;
    zT_27 = (unsigned int)zT_25 < (unsigned int)(4);
    if (!(zT_27)) { pal_trap(); }
    ver[zT_25] = zT_24;
    zT_28 = 0;
    zT_29 = 1;
    zT_31 = (unsigned int)zT_29 < (unsigned int)(4);
    if (!(zT_31)) { pal_trap(); }
    ver[zT_29] = zT_28;
    zT_32 = 0;
    zT_33 = 2;
    zT_35 = (unsigned int)zT_33 < (unsigned int)(4);
    if (!(zT_35)) { pal_trap(); }
    ver[zT_33] = zT_32;
    zT_36 = 0;
    zT_37 = 3;
    zT_39 = (unsigned int)zT_37 < (unsigned int)(4);
    if (!(zT_39)) { pal_trap(); }
    ver[zT_37] = zT_36;
    zT_40 = &out->store;
    zT_44 = out->store;
    zT_41 = zT_44.cur;
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)ver) + zT_48;
    zT_50 = (unsigned int)(4) - zT_48;
    zT_51.ptr = (unsigned char*)zT_49;
    zT_51.len = zT_50;
    zT_42 = zT_51;
    zF_BFB33631_spillWriteAt(zT_40, zT_41, zT_42);
    zT_54 = 0;
    zT_55 = 0;
    zT_53[zT_55] = zT_54;
    zT_56 = 0;
    zT_57 = 1;
    zT_53[zT_57] = zT_56;
    zT_58 = 0;
    zT_59 = 2;
    zT_53[zT_59] = zT_58;
    zT_60 = 0;
    zT_61 = 3;
    zT_53[zT_61] = zT_60;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zero[_i] = zT_53[_i];
        _i++;
    }
}
    zT_62 = &out->store;
    zT_66 = out->store;
    zT_63 = zT_66.cur;
    zT_70 = 0;
    zT_71 = (unsigned char*)((unsigned char*)zero) + zT_70;
    zT_72 = (unsigned int)(4) - zT_70;
    zT_73.ptr = (unsigned char*)zT_71;
    zT_73.len = zT_72;
    zT_64 = zT_73;
    zF_BFB33631_spillWriteAt(zT_62, zT_63, zT_64);
    zT_74 = &out->store;
    zT_78 = out->store;
    zT_75 = zT_78.cur;
    zT_82 = 0;
    zT_83 = (unsigned char*)((unsigned char*)zero) + zT_82;
    zT_84 = (unsigned int)(4) - zT_82;
    zT_85.ptr = (unsigned char*)zT_83;
    zT_85.len = zT_84;
    zT_76 = zT_85;
    zF_BFB33631_spillWriteAt(zT_74, zT_75, zT_76);
    return;
}

/* debugOutWriteU16 */
void zF_C9405045_debugOutWriteU16(zT_BEF92BCA_DebugOutFile* out, unsigned short value) {
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_3;
    unsigned int zT_6;
    unsigned char zT_7;
    int zT_8;
    unsigned char zT_10;
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_21;
    zT_D21A8776_SpillStore* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_D21A8776_SpillStore zT_26;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_BBAAFAE2_Arr_unsigned_char_2 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 2) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned int)((unsigned int)value) & (unsigned int)(255);
    zT_7 = (unsigned char)zig_cast_checked_u((zu64)zT_6, 32u, 0u, 8u);
    zT_8 = 0;
    zT_10 = (unsigned int)zT_8 < (unsigned int)(2);
    if (!(zT_10)) { pal_trap(); }
    b[zT_8] = zT_7;
    zT_15 = 1;
    if (!(zT_15)) { pal_trap(); }
    zT_17 = (unsigned int)((unsigned int)((unsigned int)value) >> (unsigned int)(8)) & (unsigned int)(255);
    zT_18 = (unsigned char)zig_cast_checked_u((zu64)zT_17, 32u, 0u, 8u);
    zT_19 = 1;
    zT_21 = (unsigned int)zT_19 < (unsigned int)(2);
    if (!(zT_21)) { pal_trap(); }
    b[zT_19] = zT_18;
    zT_22 = &out->store;
    zT_26 = out->store;
    zT_23 = zT_26.cur;
    zT_30 = 0;
    zT_31 = (unsigned char*)((unsigned char*)b) + zT_30;
    zT_32 = (unsigned int)(2) - zT_30;
    zT_33.ptr = (unsigned char*)zT_31;
    zT_33.len = zT_32;
    zT_24 = zT_33;
    zF_BFB33631_spillWriteAt(zT_22, zT_23, zT_24);
    return;
}

/* debugOutWriteU32 */
void zF_D53BE5FB_debugOutWriteU32(zT_BEF92BCA_DebugOutFile* out, unsigned int value) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_17;
    unsigned char zT_19;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned char zT_39;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_D21A8776_SpillStore zT_44;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = value & (unsigned int)(255);
    zT_6 = (unsigned char)zig_cast_checked_u((zu64)zT_5, 32u, 0u, 8u);
    zT_7 = 0;
    zT_9 = (unsigned int)zT_7 < (unsigned int)(4);
    if (!(zT_9)) { pal_trap(); }
    b[zT_7] = zT_6;
    zT_13 = 1;
    if (!(zT_13)) { pal_trap(); }
    zT_15 = (unsigned int)(value >> (unsigned int)(8)) & (unsigned int)(255);
    zT_16 = (unsigned char)zig_cast_checked_u((zu64)zT_15, 32u, 0u, 8u);
    zT_17 = 1;
    zT_19 = (unsigned int)zT_17 < (unsigned int)(4);
    if (!(zT_19)) { pal_trap(); }
    b[zT_17] = zT_16;
    zT_23 = 1;
    if (!(zT_23)) { pal_trap(); }
    zT_25 = (unsigned int)(value >> (unsigned int)(16)) & (unsigned int)(255);
    zT_26 = (unsigned char)zig_cast_checked_u((zu64)zT_25, 32u, 0u, 8u);
    zT_27 = 2;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(4);
    if (!(zT_29)) { pal_trap(); }
    b[zT_27] = zT_26;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_35 = (unsigned int)(value >> (unsigned int)(24)) & (unsigned int)(255);
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_35, 32u, 0u, 8u);
    zT_37 = 3;
    zT_39 = (unsigned int)zT_37 < (unsigned int)(4);
    if (!(zT_39)) { pal_trap(); }
    b[zT_37] = zT_36;
    zT_40 = &out->store;
    zT_44 = out->store;
    zT_41 = zT_44.cur;
    zT_48 = 0;
    zT_49 = (unsigned char*)((unsigned char*)b) + zT_48;
    zT_50 = (unsigned int)(4) - zT_48;
    zT_51.ptr = (unsigned char*)zT_49;
    zT_51.len = zT_50;
    zT_42 = zT_51;
    zF_BFB33631_spillWriteAt(zT_40, zT_41, zT_42);
    return;
}

/* debugOutWriteBytes */
void zF_BFE5287E_debugOutWriteBytes(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u bytes) {
    unsigned int zT_3;
    zT_D21A8776_SpillStore* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_D21A8776_SpillStore zT_10;
    zT_3 = bytes.len;
    if ((unsigned char)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = &out->store;
    zT_10 = out->store;
    zT_7 = zT_10.cur;
    zT_8 = bytes;
    zF_BFB33631_spillWriteAt(zT_6, zT_7, zT_8);
    return;
}

/* debugOutWriteStr16Pair */
void zF_D8B6F339_debugOutWriteStr16P(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_BEF92BCA_DebugOutFile* zT_24;
    unsigned short zT_25;
    zT_BEF92BCA_DebugOutFile* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    unsigned char zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_38;
    unsigned int zT_41;
    zT_BEF92BCA_DebugOutFile* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned char* zT_47;
    unsigned int zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int total;
    unsigned int la;
    unsigned int lb;
    zT_5 = a.len;
    zT_7 = b.len;
    zT_8 = zig_wrap_add_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_add_u(((zu64)(zT_5)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    total = zT_8;
    if ((unsigned char)(total > (unsigned int)(65535))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = 65535;
    total = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_17 = a.len;
    la = zT_17;
    if ((unsigned char)(la > total)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    la = total;
    goto z_bb_4;
    z_bb_4:
    zT_20 = zig_wrap_sub_u(((zu64)(total)), ((zu64)(la)), 32u);
    zT_21 = zig_overflow_flag_sub_u(((zu64)(total)), ((zu64)(la)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    lb = zT_20;
    zT_24 = out;
    zT_25 = (unsigned short)zig_cast_checked_u((zu64)total, 32u, 0u, 16u);
    zF_C9405045_debugOutWriteU16(zT_24, zT_25);
    zT_27 = out;
    zT_29 = a.ptr;
    zT_30 = a.len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = la - zT_31;
    zT_34 = (unsigned int)zT_31 <= la;
    if (!(zT_34)) { pal_trap(); }
    zT_35 = la <= zT_30;
    if (!(zT_35)) { pal_trap(); }
    zT_36.ptr = (unsigned char*)zT_32;
    zT_36.len = zT_33;
    zT_28 = zT_36;
    zF_BFE5287E_debugOutWriteBytes(zT_27, zT_28);
    zT_38 = b.len;
    if ((unsigned char)(lb > zT_38)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_41 = b.len;
    lb = zT_41;
    goto z_bb_6;
    z_bb_6:
    zT_42 = out;
    zT_44 = b.ptr;
    zT_45 = b.len;
    zT_46 = 0;
    zT_47 = zT_44 + zT_46;
    zT_48 = lb - zT_46;
    zT_49 = (unsigned int)zT_46 <= lb;
    if (!(zT_49)) { pal_trap(); }
    zT_50 = lb <= zT_45;
    if (!(zT_50)) { pal_trap(); }
    zT_51.ptr = (unsigned char*)zT_47;
    zT_51.len = zT_48;
    zT_43 = zT_51;
    zF_BFE5287E_debugOutWriteBytes(zT_42, zT_43);
    return;
}

/* debugOutWriteStr16 */
void zF_5C16527D_debugOutWriteStr16(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    unsigned int zT_4;
    unsigned int zT_7;
    zT_BEF92BCA_DebugOutFile* zT_8;
    unsigned short zT_9;
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int len;
    zT_4 = s.len;
    len = zT_4;
    if ((unsigned char)(len > (unsigned int)(65535))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = 65535;
    len = zT_7;
    goto z_bb_2;
    z_bb_2:
    zT_8 = out;
    zT_9 = (unsigned short)zig_cast_checked_u((zu64)len, 32u, 0u, 16u);
    zF_C9405045_debugOutWriteU16(zT_8, zT_9);
    zT_11 = out;
    zT_13 = s.ptr;
    zT_14 = s.len;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = len - zT_15;
    zT_18 = (unsigned int)zT_15 <= len;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = len <= zT_14;
    if (!(zT_19)) { pal_trap(); }
    zT_20.ptr = (unsigned char*)zT_16;
    zT_20.len = zT_17;
    zT_12 = zT_20;
    zF_BFE5287E_debugOutWriteBytes(zT_11, zT_12);
    return;
}

/* debugOutClose */
void zF_4A7C5D00_debugOutClose(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u magic) {
    zT_D21A8776_SpillStore zT_3;
    unsigned int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    zT_BEF92BCA_DebugOutFile* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_BEF92BCA_DebugOutFile* zT_14;
    unsigned int zT_15;
    zT_BEF92BCA_DebugOutFile* zT_17;
    unsigned int zT_18;
    zT_D21A8776_SpillStore* zT_19;
    unsigned int total;
    zT_3 = out->store;
    zT_4 = zT_3.cur;
    total = zT_4;
    zT_5 = &out->store;
    zF_56A911A9_spillSeek(zT_5, (unsigned int)(0));
    zT_9 = out;
    zT_10 = magic;
    zF_BFE5287E_debugOutWriteBytes(zT_9, zT_10);
    zT_11 = out;
    zF_D53BE5FB_debugOutWriteU32(zT_11, (unsigned int)(1));
    zT_14 = out;
    zT_15 = out->count;
    zF_D53BE5FB_debugOutWriteU32(zT_14, zT_15);
    zT_17 = out;
    zT_18 = total;
    zF_D53BE5FB_debugOutWriteU32(zT_17, zT_18);
    zT_19 = &out->store;
    zF_DB2CDC3B_spillClose(zT_19);
    return;
}

/* debugMapWriterInit */
zT_DEDDFC41_DebugMapWriter zF_CCB1E6BF_debugMapWriterInit(void) {
    zT_DEDDFC41_DebugMapWriter zT_0;
    zT_BEF92BCA_DebugOutFile zT_1;
    zT_D21A8776_SpillStore zT_2;
    unsigned int zT_3;
    zT_BEF92BCA_DebugOutFile zT_4;
    zT_D21A8776_SpillStore zT_5;
    unsigned int zT_6;
    zT_BEF92BCA_DebugOutFile zT_7;
    zT_D21A8776_SpillStore zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_2 = zF_22C79E6C_spillStoreInit();
    zT_1.store = zT_2;
    zT_3 = 0;
    zT_1.count = zT_3;
    zT_0.syms = zT_1;
    zT_5 = zF_22C79E6C_spillStoreInit();
    zT_4.store = zT_5;
    zT_6 = 0;
    zT_4.count = zT_6;
    zT_0.lines = zT_4;
    zT_8 = zF_22C79E6C_spillStoreInit();
    zT_7.store = zT_8;
    zT_9 = 0;
    zT_7.count = zT_9;
    zT_0.cnames = zT_7;
    zT_10 = 0;
    zT_0.enabled = zT_10;
    zT_11 = 0;
    zT_0.group_open = zT_11;
    zT_12 = 0;
    zT_0.group_count_offset = zT_12;
    zT_13 = 0;
    zT_0.group_run_count = zT_13;
    zT_14 = 0;
    zT_0.last_src_line = zT_14;
    zT_15 = 0;
    zT_0.last_out_start = zT_15;
    zT_16 = 0;
    zT_0.last_out_count = zT_16;
    zT_17 = 0;
    zT_0.has_last = zT_17;
    return zT_0;
}

/* debugMapWriterOpen */
void zF_ED14666D_debugMapWriterOpen(zT_DEDDFC41_DebugMapWriter* self, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u syms_path, zT_8F083A69_Slice_zT_0B42B2F8_u lines_path, zT_8F083A69_Slice_zT_0B42B2F8_u cnames_path) {
    zT_BEF92BCA_DebugOutFile* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_3E40CD83_Sand* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_BEF92BCA_DebugOutFile* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zT_5 = &self->syms;
    zT_6 = syms_path;
    zT_7 = alloc;
    zT_10 = zF_DEE7AA30_magicSyms();
    zT_8 = zT_10;
    zF_D70BEADC_debugOutOpen(zT_5, zT_6, zT_7, zT_8);
    zT_11 = &self->lines;
    zT_12 = lines_path;
    zT_13 = alloc;
    zT_16 = zF_4FFC9427_magicLines();
    zT_14 = zT_16;
    zF_D70BEADC_debugOutOpen(zT_11, zT_12, zT_13, zT_14);
    zT_17 = &self->cnames;
    zT_18 = cnames_path;
    zT_19 = alloc;
    zT_22 = zF_ED717857_magicCnames();
    zT_20 = zT_22;
    zF_D70BEADC_debugOutOpen(zT_17, zT_18, zT_19, zT_20);
    self->enabled = (unsigned char)(1);
    return;
}

/* debugMapWriterBeginLineGroup */
void zF_FFA3F32B_debugMapWriterBegin(zT_DEDDFC41_DebugMapWriter* self, zT_8F083A69_Slice_zT_0B42B2F8_u src_file, zT_8F083A69_Slice_zT_0B42B2F8_u out_base) {
    unsigned char zT_3;
    zT_BEF92BCA_DebugOutFile* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_BEF92BCA_DebugOutFile* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_BEF92BCA_DebugOutFile zT_17;
    zT_D21A8776_SpillStore zT_18;
    unsigned int zT_19;
    zT_BEF92BCA_DebugOutFile* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    zT_3 = self->enabled;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = &self->lines;
    zT_7 = src_file;
    zF_5C16527D_debugOutWriteStr16(zT_6, zT_7);
    zT_10 = ".c";
    zT_12 = 2;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    cext = zT_11;
    zT_13 = &self->lines;
    zT_14 = out_base;
    zT_15 = cext;
    zF_D8B6F339_debugOutWriteStr16P(zT_13, zT_14, zT_15);
    zT_17 = self->lines;
    zT_18 = zT_17.store;
    zT_19 = zT_18.cur;
    self->group_count_offset = zT_19;
    zT_20 = &self->lines;
    zF_D53BE5FB_debugOutWriteU32(zT_20, (unsigned int)(0));
    self->group_run_count = (unsigned int)(0);
    self->has_last = (unsigned char)(0);
    self->group_open = (unsigned char)(1);
    return;
}

/* debugMapFlushLast */
void zF_1565BCB0_debugMapFlushLast(zT_DEDDFC41_DebugMapWriter* self) {
    unsigned char zT_1;
    zT_BEF92BCA_DebugOutFile* zT_4;
    unsigned int zT_5;
    zT_BEF92BCA_DebugOutFile* zT_8;
    unsigned int zT_9;
    zT_BEF92BCA_DebugOutFile* zT_12;
    unsigned int zT_13;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_1 = self->has_last;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = &self->lines;
    zT_5 = self->last_src_line;
    zF_D53BE5FB_debugOutWriteU32(zT_4, zT_5);
    zT_8 = &self->lines;
    zT_9 = self->last_out_start;
    zF_D53BE5FB_debugOutWriteU32(zT_8, zT_9);
    zT_12 = &self->lines;
    zT_13 = self->last_out_count;
    zF_D53BE5FB_debugOutWriteU32(zT_12, zT_13);
    zT_16 = self->group_run_count;
    zT_17 = 1;
    zT_18 = zig_wrap_add_u(((zu64)(zT_16)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(zT_16)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    self->group_run_count = zT_18;
    self->has_last = (unsigned char)(0);
    return;
}

/* debugMapWriterAddRun */
void zF_6CD06D0D_debugMapWriterAddRu(zT_DEDDFC41_DebugMapWriter* self, unsigned int src_line, unsigned int out_start, unsigned int out_count) {
    unsigned char zT_4;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_DEDDFC41_DebugMapWriter* zT_33;
    zT_4 = self->enabled;
    if ((unsigned char)(zT_4 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = self->group_open;
    zT_7 = zT_8 == (unsigned char)(0);
    goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_7) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_11 = out_count == (unsigned int)(0);
    goto z_bb_6;
    z_bb_5:
    zT_11 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_11) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_14 = self->has_last;
    if ((unsigned char)(zT_14 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_18 = self->last_src_line;
    zT_17 = zT_18 == src_line;
    goto z_bb_11;
    z_bb_10:
    zT_17 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_17) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_21 = self->last_out_start;
    zT_22 = self->last_out_count;
    zT_23 = zig_wrap_add_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    zT_20 = zT_23 == out_start;
    goto z_bb_14;
    z_bb_13:
    zT_20 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_20) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_28 = self->last_out_count;
    zT_29 = zig_wrap_add_u(((zu64)(zT_28)), ((zu64)(out_count)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_28)), ((zu64)(out_count)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    self->last_out_count = zT_29;
    return;
    z_bb_16:
    zT_33 = self;
    zF_1565BCB0_debugMapFlushLast(zT_33);
    self->last_src_line = src_line;
    self->last_out_start = out_start;
    self->last_out_count = out_count;
    self->has_last = (unsigned char)(1);
    return;
}

/* debugMapWriterEndLineGroup */
void zF_B7665FFF_debugMapWriterEndLi(zT_DEDDFC41_DebugMapWriter* self) {
    unsigned char zT_1;
    unsigned char zT_4;
    unsigned char zT_5;
    zT_DEDDFC41_DebugMapWriter* zT_8;
    zT_BEF92BCA_DebugOutFile zT_10;
    zT_D21A8776_SpillStore zT_11;
    unsigned int zT_12;
    zT_D21A8776_SpillStore* zT_13;
    unsigned int zT_14;
    zT_BEF92BCA_DebugOutFile* zT_15;
    zT_BEF92BCA_DebugOutFile* zT_18;
    unsigned int zT_19;
    zT_D21A8776_SpillStore* zT_22;
    unsigned int zT_23;
    zT_BEF92BCA_DebugOutFile* zT_24;
    zT_BEF92BCA_DebugOutFile zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_BEF92BCA_DebugOutFile* zT_33;
    unsigned int end;
    zT_1 = self->enabled;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = self->group_open;
    zT_4 = zT_5 == (unsigned char)(0);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_8 = self;
    zF_1565BCB0_debugMapFlushLast(zT_8);
    zT_10 = self->lines;
    zT_11 = zT_10.store;
    zT_12 = zT_11.cur;
    end = zT_12;
    zT_15 = &self->lines;
    zT_13 = &zT_15->store;
    zT_14 = self->group_count_offset;
    zF_56A911A9_spillSeek(zT_13, zT_14);
    zT_18 = &self->lines;
    zT_19 = self->group_run_count;
    zF_D53BE5FB_debugOutWriteU32(zT_18, zT_19);
    zT_24 = &self->lines;
    zT_22 = &zT_24->store;
    zT_23 = end;
    zF_56A911A9_spillSeek(zT_22, zT_23);
    zT_26 = self->lines;
    zT_27 = zT_26.count;
    zT_28 = self->group_run_count;
    zT_29 = zig_wrap_add_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_33 = &self->lines;
    zT_33->count = zT_29;
    self->group_open = (unsigned char)(0);
    return;
}

/* debugModuleStem */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_D560F1C1_debugModuleStem(zT_CEC2984A_NameMangler* mangler, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, unsigned int module_id) {
    zT_072B53A6_ModuleRegistry* zT_5;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_6;
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_6E8D187B_ModuleEntry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_6E8D187B_ModuleEntry zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_CEC2984A_NameMangler* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u path_str;
    zT_5 = module_reg;
    zT_6 = zF_3452C137_moduleRegistryGetMo(zT_5);
    mods = zT_6;
    zT_8 = interner;
    zT_10 = mods.ptr;
    zT_11 = (unsigned int)module_id;
    zT_12 = mods.len;
    zT_13 = zT_11 < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_10[zT_11];
    zT_9 = zT_14.path_id;
    zT_16 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    path_str = zT_16;
    zT_17 = mangler;
    zT_18 = path_str;
    zT_19 = zF_C4A5232F_nameManglerMintModu(zT_17, zT_18);
    return zT_19;
}

/* debugSymbolSrcFile */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7A9322C_debugSymbolSrcFile(zT_1001656C_DebugSymbol sym, zT_227EDE07_SourceManager* source_man) {
    zT_227EDE07_SourceManager* zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = source_man;
    zT_3 = sym.src_file_id;
    zT_5 = zF_B7076474_sourceManagerGetFil(zT_2, zT_3);
    return zT_5;
}

/* debugSymbolName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_EA891367_debugSymbolName(zT_1001656C_DebugSymbol sym, zT_D3EB6303_StringInterner* interner) {
    zT_D3EB6303_StringInterner* zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2 = interner;
    zT_3 = sym.name_id;
    zT_5 = zF_9134020D_stringInternerGet(zT_2, zT_3);
    return zT_5;
}

/* debugSymbolLess */
unsigned char zF_48A32BF5_debugSymbolLess(zT_1001656C_DebugSymbol a, zT_1001656C_DebugSymbol b, zT_227EDE07_SourceManager* source_man, zT_D3EB6303_StringInterner* interner) {
    zT_1001656C_DebugSymbol zT_5;
    zT_227EDE07_SourceManager* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_1001656C_DebugSymbol zT_9;
    zT_227EDE07_SourceManager* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    int zT_16;
    int zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_1001656C_DebugSymbol zT_31;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_1001656C_DebugSymbol zT_35;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_40;
    int zT_41;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zT_8F083A69_Slice_zT_0B42B2F8_u af;
    zT_8F083A69_Slice_zT_0B42B2F8_u bf;
    int c;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_8F083A69_Slice_zT_0B42B2F8_u bn;
    zT_5 = a;
    zT_6 = source_man;
    zT_7 = zF_B7A9322C_debugSymbolSrcFile(zT_5, zT_6);
    af = zT_7;
    zT_9 = b;
    zT_10 = source_man;
    zT_11 = zF_B7A9322C_debugSymbolSrcFile(zT_9, zT_10);
    bf = zT_11;
    zT_13 = af;
    zT_14 = bf;
    zT_15 = zF_7814455F_strCompare(zT_13, zT_14);
    c = zT_15;
    zT_16 = 0;
    if ((unsigned char)(c < zT_16)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_19 = 0;
    if ((unsigned char)(c > zT_19)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_22 = a.src_line;
    zT_23 = b.src_line;
    if ((unsigned char)(zT_22 < zT_23)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_26 = a.src_line;
    zT_27 = b.src_line;
    if ((unsigned char)(zT_26 > zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_31 = a;
    zT_32 = interner;
    zT_33 = zF_EA891367_debugSymbolName(zT_31, zT_32);
    an = zT_33;
    zT_35 = b;
    zT_36 = interner;
    zT_37 = zF_EA891367_debugSymbolName(zT_35, zT_36);
    bn = zT_37;
    zT_38 = an;
    zT_39 = bn;
    zT_40 = zF_7814455F_strCompare(zT_38, zT_39);
    zT_41 = 0;
    return (unsigned char)(zT_40 < zT_41);
}

/* debugCnameLess */
unsigned char zF_D5054183_debugCnameLess(zT_1001656C_DebugSymbol a, zT_1001656C_DebugSymbol b, zT_D3EB6303_StringInterner* interner) {
    zT_1001656C_DebugSymbol zT_4;
    zT_D3EB6303_StringInterner* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_1001656C_DebugSymbol zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14;
    int zT_15;
    int zT_18;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_29;
    unsigned char zT_30;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_8F083A69_Slice_zT_0B42B2F8_u bn;
    int c;
    zT_4 = a;
    zT_5 = interner;
    zT_6 = zF_EA891367_debugSymbolName(zT_4, zT_5);
    an = zT_6;
    zT_8 = b;
    zT_9 = interner;
    zT_10 = zF_EA891367_debugSymbolName(zT_8, zT_9);
    bn = zT_10;
    zT_12 = an;
    zT_13 = bn;
    zT_14 = zF_7814455F_strCompare(zT_12, zT_13);
    c = zT_14;
    zT_15 = 0;
    if ((unsigned char)(c < zT_15)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_18 = 0;
    if ((unsigned char)(c > zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = a.module_id;
    zT_22 = b.module_id;
    if ((unsigned char)(zT_21 < zT_22)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_25 = a.module_id;
    zT_26 = b.module_id;
    if ((unsigned char)(zT_25 > zT_26)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_29 = a.kind;
    zT_30 = b.kind;
    return (unsigned char)(zT_29 < zT_30);
}

/* debugMapWriterClose */
void zF_48EEEA4F_debugMapWriterClose(zT_DEDDFC41_DebugMapWriter* self, zT_3E40CD83_Sand* alloc, zT_39D2FAA1_Slice_zT_1001656C_D symbols, zT_227EDE07_SourceManager* source_man, zT_CEC2984A_NameMangler* mangler, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* registry) {
    unsigned char zT_8;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_12;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_FDFD82FD_EU_362 zT_29;
    unsigned char zT_30;
    unsigned char* zT_31;
    zT_1001656C_DebugSymbol* zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    zT_1001656C_DebugSymbol* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    zT_1001656C_DebugSymbol zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned int zT_50;
    int zT_51;
    zT_1001656C_DebugSymbol* zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_55;
    unsigned int zT_57;
    unsigned int zT_59;
    zT_1001656C_DebugSymbol* zT_62;
    unsigned int zT_63;
    unsigned char zT_64;
    zT_1001656C_DebugSymbol zT_65;
    zT_1001656C_DebugSymbol zT_69;
    zT_1001656C_DebugSymbol zT_70;
    zT_227EDE07_SourceManager* zT_71;
    zT_D3EB6303_StringInterner* zT_72;
    zT_1001656C_DebugSymbol* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_1001656C_DebugSymbol zT_81;
    unsigned char zT_82;
    zT_1001656C_DebugSymbol* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned char zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    zT_1001656C_DebugSymbol zT_92;
    zT_1001656C_DebugSymbol* zT_93;
    unsigned int zT_94;
    unsigned char zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    zT_1001656C_DebugSymbol* zT_101;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned char zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    zT_1001656C_DebugSymbol* zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    zT_1001656C_DebugSymbol zT_118;
    zT_1001656C_DebugSymbol zT_120;
    zT_D3EB6303_StringInterner* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_CEC2984A_NameMangler* zT_124;
    zT_D3EB6303_StringInterner* zT_125;
    zT_072B53A6_ModuleRegistry* zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_1001656C_DebugSymbol zT_131;
    zT_227EDE07_SourceManager* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    zT_BEF92BCA_DebugOutFile* zT_135;
    zT_BAAAF94F_Arr_unsigned_char_1 zT_137;
    unsigned char zT_138;
    int zT_139;
    unsigned char zT_141;
    zT_BEF92BCA_DebugOutFile* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    int zT_146;
    unsigned char* zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    zT_BEF92BCA_DebugOutFile* zT_150;
    unsigned int zT_151;
    zT_BEF92BCA_DebugOutFile* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_BEF92BCA_DebugOutFile* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    zT_BEF92BCA_DebugOutFile* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned char zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_171;
    unsigned int zT_173;
    zT_3E40CD83_Sand* zT_177;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned char zT_186;
    zT_FDFD82FD_EU_362 zT_188;
    unsigned char zT_189;
    unsigned char* zT_190;
    zT_1001656C_DebugSymbol* zT_193;
    unsigned int zT_195;
    unsigned int zT_197;
    zT_1001656C_DebugSymbol* zT_199;
    unsigned int zT_200;
    unsigned char zT_201;
    zT_1001656C_DebugSymbol zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned char zT_207;
    unsigned int zT_209;
    int zT_210;
    zT_1001656C_DebugSymbol* zT_211;
    unsigned int zT_212;
    unsigned char zT_213;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_214;
    unsigned int zT_216;
    unsigned int zT_218;
    zT_1001656C_DebugSymbol* zT_221;
    unsigned int zT_222;
    unsigned char zT_223;
    zT_1001656C_DebugSymbol zT_224;
    zT_1001656C_DebugSymbol zT_228;
    zT_1001656C_DebugSymbol zT_229;
    zT_D3EB6303_StringInterner* zT_230;
    zT_1001656C_DebugSymbol* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned char zT_236;
    unsigned int zT_237;
    unsigned char zT_238;
    zT_1001656C_DebugSymbol zT_239;
    unsigned char zT_240;
    zT_1001656C_DebugSymbol* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned char zT_247;
    unsigned int zT_248;
    unsigned char zT_249;
    zT_1001656C_DebugSymbol zT_250;
    zT_1001656C_DebugSymbol* zT_251;
    unsigned int zT_252;
    unsigned char zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned char zT_258;
    zT_1001656C_DebugSymbol* zT_259;
    unsigned int zT_260;
    unsigned char zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned char zT_266;
    unsigned int zT_268;
    unsigned int zT_270;
    zT_1001656C_DebugSymbol* zT_273;
    unsigned int zT_274;
    unsigned char zT_275;
    zT_1001656C_DebugSymbol zT_276;
    zT_1001656C_DebugSymbol zT_278;
    zT_D3EB6303_StringInterner* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned char zT_282;
    unsigned char zT_285;
    zT_CEC2984A_NameMangler* zT_289;
    unsigned int zT_290;
    unsigned int zT_292;
    unsigned int zT_296;
    zT_D3EB6303_StringInterner* zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_CEC2984A_NameMangler* zT_301;
    zT_338B7C76_TypeRegistry* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_309;
    zT_D3EB6303_StringInterner* zT_310;
    unsigned int zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zT_BEF92BCA_DebugOutFile* zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    zT_BEF92BCA_DebugOutFile* zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    zT_BEF92BCA_DebugOutFile zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned char zT_325;
    zT_BEF92BCA_DebugOutFile* zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned char zT_331;
    zT_BEF92BCA_DebugOutFile* zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    zT_BEF92BCA_DebugOutFile* zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    zT_BEF92BCA_DebugOutFile* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_82, (unsigned int)sizeof zT_82);
    zig_poison_fill((void*)&zT_122, (unsigned int)sizeof zT_122);
    zig_poison_fill((void*)&zT_129, (unsigned int)sizeof zT_129);
    zig_poison_fill((void*)&zT_133, (unsigned int)sizeof zT_133);
    zig_poison_fill((void*)&zT_188, (unsigned int)sizeof zT_188);
    zig_poison_fill((void*)&zT_240, (unsigned int)sizeof zT_240);
    zig_poison_fill((void*)&zT_280, (unsigned int)sizeof zT_280);
    zig_poison_fill((void*)&zT_296, (unsigned int)sizeof zT_296);
    zig_poison_fill((void*)&zT_299, (unsigned int)sizeof zT_299);
    zig_poison_fill((void*)&zT_309, (unsigned int)sizeof zT_309);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_335, (unsigned int)sizeof zT_335);
    zig_poison_fill((void*)&zT_339, (unsigned int)sizeof zT_339);
    zig_poison_fill((void*)&zT_343, (unsigned int)sizeof zT_343);
    zT_39D2FAA1_Slice_zT_1001656C_D sym_copy;
    unsigned char* raw;
    unsigned int si;
    zT_1001656C_DebugSymbol* dst;
    unsigned int ci;
    unsigned int i;
    zT_1001656C_DebugSymbol key;
    unsigned int j;
    zT_1001656C_DebugSymbol s;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mstem;
    zT_8F083A69_Slice_zT_0B42B2F8_u sf;
    zT_BEF92BCA_DebugOutFile* out;
    zT_BAAAF94F_Arr_unsigned_char_1 kb;
    zT_39D2FAA1_Slice_zT_1001656C_D cn_copy;
    unsigned int cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u src_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mangled;
    unsigned int gmid;
    unsigned int mid;
    zT_8 = self->enabled;
    if ((unsigned char)(zT_8 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    sym_copy = zT_12;
    zT_14 = symbols.len;
    if ((unsigned char)(zT_14 > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = alloc;
    zT_21 = 28;
    zT_23 = symbols.len;
    zT_24 = zig_wrap_mul_u(((zu64)(zT_21)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_mul_u(((zu64)(zT_21)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_19 = zT_24;
    zT_29 = zF_1395EB68_sandAlloc(zT_18, zT_19, (unsigned int)(4));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_110 = 0;
    si = zT_110;
    goto z_bb_22;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_31 = zT_29.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_31;
    zT_34 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_34;
    zT_36 = 0;
    ci = zT_36;
    goto z_bb_8;
    z_bb_8:
    zT_38 = symbols.len;
    if ((unsigned char)(ci < zT_38)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_40 = symbols.ptr;
    zT_41 = symbols.len;
    zT_42 = ci < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_40[ci];
    dst[ci] = zT_43;
    goto z_bb_11;
    z_bb_10:
    zT_50 = symbols.len;
    zT_51 = 0;
    zT_52 = dst + zT_51;
    zT_53 = zT_50 - zT_51;
    zT_54 = (unsigned int)zT_51 <= zT_50;
    if (!(zT_54)) { pal_trap(); }
    zT_55.ptr = (zT_1001656C_DebugSymbol*)zT_52;
    zT_55.len = zT_53;
    sym_copy = zT_55;
    zT_57 = 1;
    i = zT_57;
    goto z_bb_12;
    z_bb_11:
    zT_44 = 1;
    zT_45 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    ci = zT_45;
    goto z_bb_8;
    z_bb_12:
    zT_59 = sym_copy.len;
    if ((unsigned char)(i < zT_59)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_62 = sym_copy.ptr;
    zT_63 = sym_copy.len;
    zT_64 = i < zT_63;
    if (!(zT_64)) { pal_trap(); }
    zT_65 = zT_62[i];
    key = zT_65;
    j = i;
    goto z_bb_16;
    z_bb_14:
    goto z_bb_4;
    z_bb_15:
    zT_104 = 1;
    zT_105 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_104)), 32u);
    zT_106 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_104)), 32u);
    zT_108 = zT_106 == (unsigned int)(0);
    if (!(zT_108)) { pal_trap(); }
    i = zT_105;
    goto z_bb_12;
    z_bb_16:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_69 = key;
    zT_73 = sym_copy.ptr;
    zT_74 = 1;
    zT_75 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_74)), 32u);
    zT_76 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_74)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    zT_79 = sym_copy.len;
    zT_80 = zT_75 < zT_79;
    if (!(zT_80)) { pal_trap(); }
    zT_81 = zT_73[zT_75];
    zT_70 = zT_81;
    zT_71 = source_man;
    zT_72 = interner;
    zT_82 = zF_48A32BF5_debugSymbolLess(zT_69, zT_70, zT_71, zT_72);
    if ((unsigned char)(!zT_82)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_101 = sym_copy.ptr;
    zT_102 = sym_copy.len;
    zT_103 = j < zT_102;
    if (!(zT_103)) { pal_trap(); }
    zT_101[j] = key;
    goto z_bb_15;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_84 = sym_copy.ptr;
    zT_85 = 1;
    zT_86 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_85)), 32u);
    zT_87 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_85)), 32u);
    zT_89 = zT_87 == (unsigned int)(0);
    if (!(zT_89)) { pal_trap(); }
    zT_90 = sym_copy.len;
    zT_91 = zT_86 < zT_90;
    if (!(zT_91)) { pal_trap(); }
    zT_92 = zT_84[zT_86];
    zT_93 = sym_copy.ptr;
    zT_94 = sym_copy.len;
    zT_95 = j < zT_94;
    if (!(zT_95)) { pal_trap(); }
    zT_93[j] = zT_92;
    zT_96 = 1;
    zT_97 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    j = zT_97;
    goto z_bb_19;
    z_bb_22:
    zT_112 = symbols.len;
    if ((unsigned char)(si < zT_112)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_115 = sym_copy.ptr;
    zT_116 = sym_copy.len;
    zT_117 = si < zT_116;
    if (!(zT_117)) { pal_trap(); }
    zT_118 = zT_115[si];
    s = zT_118;
    zT_120 = s;
    zT_121 = interner;
    zT_122 = zF_EA891367_debugSymbolName(zT_120, zT_121);
    nm = zT_122;
    zT_124 = mangler;
    zT_125 = interner;
    zT_126 = module_reg;
    zT_127 = s.module_id;
    zT_129 = zF_D560F1C1_debugModuleStem(zT_124, zT_125, zT_126, zT_127);
    mstem = zT_129;
    zT_131 = s;
    zT_132 = source_man;
    zT_133 = zF_B7A9322C_debugSymbolSrcFile(zT_131, zT_132);
    sf = zT_133;
    zT_135 = &self->syms;
    out = zT_135;
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    {
    unsigned int _i = 0;
    while (_i < 1) {
        kb[_i] = zT_137[_i];
        _i++;
    }
}
    zT_138 = s.kind;
    zT_139 = 0;
    zT_141 = (unsigned int)zT_139 < (unsigned int)(1);
    if (!(zT_141)) { pal_trap(); }
    kb[zT_139] = zT_138;
    zT_142 = out;
    zT_146 = 0;
    zT_147 = (unsigned char*)((unsigned char*)kb) + zT_146;
    zT_148 = (unsigned int)(1) - zT_146;
    zT_149.ptr = (unsigned char*)zT_147;
    zT_149.len = zT_148;
    zT_143 = zT_149;
    zF_BFE5287E_debugOutWriteBytes(zT_142, zT_143);
    zT_150 = out;
    zT_151 = s.src_line;
    zF_D53BE5FB_debugOutWriteU32(zT_150, zT_151);
    zT_153 = out;
    zT_154 = nm;
    zF_5C16527D_debugOutWriteStr16(zT_153, zT_154);
    zT_155 = out;
    zT_156 = mstem;
    zF_5C16527D_debugOutWriteStr16(zT_155, zT_156);
    zT_157 = out;
    zT_158 = sf;
    zF_5C16527D_debugOutWriteStr16(zT_157, zT_158);
    zT_159 = out->count;
    zT_160 = 1;
    zT_161 = zig_wrap_add_u(((zu64)(zT_159)), ((zu64)(zT_160)), 32u);
    zT_162 = zig_overflow_flag_add_u(((zu64)(zT_159)), ((zu64)(zT_160)), 32u);
    zT_164 = zT_162 == (unsigned int)(0);
    if (!(zT_164)) { pal_trap(); }
    out->count = zT_161;
    goto z_bb_25;
    z_bb_24:
    zig_poison_fill((void*)&zT_171, (unsigned int)sizeof zT_171);
    cn_copy = zT_171;
    zT_173 = symbols.len;
    if ((unsigned char)(zT_173 > (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_165 = 1;
    zT_166 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_165)), 32u);
    zT_167 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_165)), 32u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    si = zT_166;
    goto z_bb_22;
    z_bb_26:
    zT_177 = alloc;
    zT_180 = 28;
    zT_182 = symbols.len;
    zT_183 = zig_wrap_mul_u(((zu64)(zT_180)), ((zu64)(zT_182)), 32u);
    zT_184 = zig_overflow_flag_mul_u(((zu64)(zT_180)), ((zu64)(zT_182)), 32u);
    zT_186 = zT_184 == (unsigned int)(0);
    if (!(zT_186)) { pal_trap(); }
    zT_178 = zT_183;
    zT_188 = zF_1395EB68_sandAlloc(zT_177, zT_178, (unsigned int)(4));
    zT_189 = zT_188.is_error;
    if (zT_189) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_268 = 0;
    cn = zT_268;
    goto z_bb_45;
    z_bb_28:
    pal_trap();
    z_bb_29:
    zT_190 = zT_188.data.payload;
    goto z_bb_30;
    z_bb_30:
    raw = zT_190;
    zT_193 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_193;
    zT_195 = 0;
    ci = zT_195;
    goto z_bb_31;
    z_bb_31:
    zT_197 = symbols.len;
    if ((unsigned char)(ci < zT_197)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_199 = symbols.ptr;
    zT_200 = symbols.len;
    zT_201 = ci < zT_200;
    if (!(zT_201)) { pal_trap(); }
    zT_202 = zT_199[ci];
    dst[ci] = zT_202;
    goto z_bb_34;
    z_bb_33:
    zT_209 = symbols.len;
    zT_210 = 0;
    zT_211 = dst + zT_210;
    zT_212 = zT_209 - zT_210;
    zT_213 = (unsigned int)zT_210 <= zT_209;
    if (!(zT_213)) { pal_trap(); }
    zT_214.ptr = (zT_1001656C_DebugSymbol*)zT_211;
    zT_214.len = zT_212;
    cn_copy = zT_214;
    zT_216 = 1;
    i = zT_216;
    goto z_bb_35;
    z_bb_34:
    zT_203 = 1;
    zT_204 = zig_wrap_add_u(((zu64)(ci)), ((zu64)(zT_203)), 32u);
    zT_205 = zig_overflow_flag_add_u(((zu64)(ci)), ((zu64)(zT_203)), 32u);
    zT_207 = zT_205 == (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    ci = zT_204;
    goto z_bb_31;
    z_bb_35:
    zT_218 = cn_copy.len;
    if ((unsigned char)(i < zT_218)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_221 = cn_copy.ptr;
    zT_222 = cn_copy.len;
    zT_223 = i < zT_222;
    if (!(zT_223)) { pal_trap(); }
    zT_224 = zT_221[i];
    key = zT_224;
    j = i;
    goto z_bb_39;
    z_bb_37:
    goto z_bb_27;
    z_bb_38:
    zT_262 = 1;
    zT_263 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_262)), 32u);
    zT_264 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_262)), 32u);
    zT_266 = zT_264 == (unsigned int)(0);
    if (!(zT_266)) { pal_trap(); }
    i = zT_263;
    goto z_bb_35;
    z_bb_39:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_228 = key;
    zT_231 = cn_copy.ptr;
    zT_232 = 1;
    zT_233 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_232)), 32u);
    zT_234 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_232)), 32u);
    zT_236 = zT_234 == (unsigned int)(0);
    if (!(zT_236)) { pal_trap(); }
    zT_237 = cn_copy.len;
    zT_238 = zT_233 < zT_237;
    if (!(zT_238)) { pal_trap(); }
    zT_239 = zT_231[zT_233];
    zT_229 = zT_239;
    zT_230 = interner;
    zT_240 = zF_D5054183_debugCnameLess(zT_228, zT_229, zT_230);
    if ((unsigned char)(!zT_240)) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_259 = cn_copy.ptr;
    zT_260 = cn_copy.len;
    zT_261 = j < zT_260;
    if (!(zT_261)) { pal_trap(); }
    zT_259[j] = key;
    goto z_bb_38;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_242 = cn_copy.ptr;
    zT_243 = 1;
    zT_244 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_243)), 32u);
    zT_245 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_243)), 32u);
    zT_247 = zT_245 == (unsigned int)(0);
    if (!(zT_247)) { pal_trap(); }
    zT_248 = cn_copy.len;
    zT_249 = zT_244 < zT_248;
    if (!(zT_249)) { pal_trap(); }
    zT_250 = zT_242[zT_244];
    zT_251 = cn_copy.ptr;
    zT_252 = cn_copy.len;
    zT_253 = j < zT_252;
    if (!(zT_253)) { pal_trap(); }
    zT_251[j] = zT_250;
    zT_254 = 1;
    zT_255 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_254)), 32u);
    zT_256 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_254)), 32u);
    zT_258 = zT_256 == (unsigned int)(0);
    if (!(zT_258)) { pal_trap(); }
    j = zT_255;
    goto z_bb_42;
    z_bb_45:
    zT_270 = symbols.len;
    if ((unsigned char)(cn < zT_270)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_273 = cn_copy.ptr;
    zT_274 = cn_copy.len;
    zT_275 = cn < zT_274;
    if (!(zT_275)) { pal_trap(); }
    zT_276 = zT_273[cn];
    s = zT_276;
    zT_278 = s;
    zT_279 = interner;
    zT_280 = zF_EA891367_debugSymbolName(zT_278, zT_279);
    src_nm = zT_280;
    mangled = src_nm;
    zT_282 = s.kind;
    if ((unsigned char)(zT_282 == (unsigned char)(0))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    zT_332 = &self->syms;
    zT_335 = zF_DEE7AA30_magicSyms();
    zT_333 = zT_335;
    zF_4A7C5D00_debugOutClose(zT_332, zT_333);
    zT_336 = &self->cnames;
    zT_339 = zF_ED717857_magicCnames();
    zT_337 = zT_339;
    zF_4A7C5D00_debugOutClose(zT_336, zT_337);
    zT_340 = &self->lines;
    zT_343 = zF_4FFC9427_magicLines();
    zT_341 = zT_343;
    zF_4A7C5D00_debugOutClose(zT_340, zT_341);
    self->enabled = (unsigned char)(0);
    return;
    z_bb_48:
    zT_327 = 1;
    zT_328 = zig_wrap_add_u(((zu64)(cn)), ((zu64)(zT_327)), 32u);
    zT_329 = zig_overflow_flag_add_u(((zu64)(cn)), ((zu64)(zT_327)), 32u);
    zT_331 = zT_329 == (unsigned int)(0);
    if (!(zT_331)) { pal_trap(); }
    cn = zT_328;
    goto z_bb_45;
    z_bb_49:
    zT_285 = s.is_extern;
    if ((unsigned char)(zT_285 == (unsigned char)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    zT_313 = &self->cnames;
    zT_314 = src_nm;
    zF_5C16527D_debugOutWriteStr16(zT_313, zT_314);
    zT_316 = &self->cnames;
    zT_317 = mangled;
    zF_5C16527D_debugOutWriteStr16(zT_316, zT_317);
    zT_319 = self->cnames;
    zT_320 = zT_319.count;
    zT_321 = 1;
    zT_322 = zig_wrap_add_u(((zu64)(zT_320)), ((zu64)(zT_321)), 32u);
    zT_323 = zig_overflow_flag_add_u(((zu64)(zT_320)), ((zu64)(zT_321)), 32u);
    zT_325 = zT_323 == (unsigned int)(0);
    if (!(zT_325)) { pal_trap(); }
    zT_326 = &self->cnames;
    zT_326->count = zT_322;
    goto z_bb_48;
    z_bb_51:
    zT_301 = mangler;
    zT_302 = registry;
    zT_303 = s.name_id;
    zT_304 = s.module_id;
    zT_305 = s.type_id;
    zT_309 = zF_027E7C4F_nameManglerMangle_1(zT_301, zT_302, zT_303, zT_304, zT_305);
    gmid = zT_309;
    zT_310 = interner;
    zT_311 = gmid;
    zT_312 = zF_9134020D_stringInternerGet(zT_310, zT_311);
    mangled = zT_312;
    goto z_bb_50;
    z_bb_52:
    zT_289 = mangler;
    zT_290 = s.name_id;
    zT_292 = s.module_id;
    zT_296 = zF_713D1938_nameManglerMangle(zT_289, zT_290, (unsigned char)(0), zT_292);
    mid = zT_296;
    zT_297 = interner;
    zT_298 = mid;
    zT_299 = zF_9134020D_stringInternerGet(zT_297, zT_298);
    mangled = zT_299;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_50;
}

/* EOF */
