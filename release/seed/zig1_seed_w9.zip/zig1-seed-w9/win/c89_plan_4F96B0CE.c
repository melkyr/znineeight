#include "c89_plan_4F96B0CE.h"
/* carrierFromFacts */
unsigned int zF_453BF522_carrierFromFacts(unsigned char width_bits, unsigned char is_signed) {
    if ((unsigned char)(width_bits == (unsigned char)(32))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(is_signed != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(is_signed != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(6);
    z_bb_4:
    return (unsigned int)(10);
    z_bb_5:
    return (unsigned int)(7);
    z_bb_6:
    return (unsigned int)(11);
}

/* deriveConstCarrier */
unsigned int zF_48A5B64F_deriveConstCarrier(zT_338B7C76_TypeRegistry* reg, unsigned int semantic_tid, zT_79FAE712_u64 value, unsigned char width_bits, unsigned char is_signed) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned int zT_17;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_D155D06D_Type hty;
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)semantic_tid;
    zT_8 = zT_6[zT_7];
    hty = zT_8;
    zT_9 = hty.kind;
    if ((unsigned char)(zT_9 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(width_bits != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(semantic_tid == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_15 = width_bits;
    zT_16 = is_signed;
    zT_17 = zF_453BF522_carrierFromFacts(zT_15, zT_16);
    return zT_17;
    z_bb_4:
    if ((unsigned char)(value <= (zT_79FAE712_u64)(2147483647))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(6);
    z_bb_6:
    if ((unsigned char)(value <= (zT_79FAE712_u64)(4294967295u))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(10);
    z_bb_8:
    return (unsigned int)(11);
    z_bb_9:
    return (unsigned int)(13);
    z_bb_10:
    return semantic_tid;
}

/* spellInstOrd */
unsigned int zF_DD416DF8_spellInstOrd(zT_BBC23664_LirFunction* lir_fn, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_8;
    zT_88A68B1A_BasicBlock* zT_9;
    zT_88A68B1A_BasicBlock zT_10;
    zT_DAE4631D_LirInstArrayList zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int ord;
    unsigned int bi;
    zT_4 = 0;
    ord = zT_4;
    zT_6 = 0;
    bi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(bi < bb_idx)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = lir_fn->blocks;
    zT_9 = zT_8.items;
    zT_10 = zT_9[bi];
    zT_11 = zT_10.insts;
    zT_12 = zT_11.len;
    zT_13 = zig_wrap_add_u(((zu64)(ord)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_add_u(((zu64)(ord)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    ord = zT_13;
    goto z_bb_4;
    z_bb_3:
    zT_22 = zig_wrap_add_u(((zu64)(ord)), ((zu64)(ii)), 32u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(ord)), ((zu64)(ii)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    ord = zT_22;
    return (unsigned int)((unsigned int)ord);
    z_bb_4:
    zT_17 = 1;
    zT_18 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    bi = zT_18;
    goto z_bb_1;
}

/* spellPlanGrow */
void zF_E2B88A09_spellPlanGrow(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    zT_3E40CD83_Sand* zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    zT_FDFD82FD_EU_362 zT_24;
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_FDFD82FD_EU_362 zT_38;
    unsigned char zT_39;
    unsigned char* zT_40;
    zT_3E40CD83_Sand* zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    zT_FDFD82FD_EU_362 zT_52;
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    unsigned int* zT_62;
    zT_21D3708C_U32ToU32Map* zT_63;
    zT_21D3708C_U32ToU32Map zT_64;
    zT_21D3708C_U32ToU32Map* zT_65;
    zT_21D3708C_U32ToU32Map* zT_66;
    zT_21D3708C_U32ToU32Map zT_67;
    zT_21D3708C_U32ToU32Map* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_maps;
    unsigned char* raw_uac;
    unsigned int ndi;
    zT_3 = plan->fn_cap;
    if ((unsigned char)(zT_3 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_8 = plan->fn_cap;
    zT_9 = 2;
    zT_10 = zig_wrap_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_11 = zig_overflow_flag_mul_u(((zu64)(zT_8)), ((zu64)(zT_9)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    zT_6 = zT_10;
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_6;
    zT_15 = alloc;
    zT_18 = 4;
    zT_19 = zig_wrap_mul_u(((zu64)(zT_18)), ((zu64)(new_cap)), 32u);
    zT_20 = zig_overflow_flag_mul_u(((zu64)(zT_18)), ((zu64)(new_cap)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    zT_16 = zT_19;
    zT_24 = zF_1395EB68_sandAlloc(zT_15, zT_16, (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_26 = zT_24.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_26;
    zT_29 = alloc;
    zT_32 = 24;
    zT_33 = zig_wrap_mul_u(((zu64)(zT_32)), ((zu64)(new_cap)), 32u);
    zT_34 = zig_overflow_flag_mul_u(((zu64)(zT_32)), ((zu64)(new_cap)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_30 = zT_33;
    zT_38 = zF_1395EB68_sandAlloc(zT_29, zT_30, (unsigned int)(4));
    zT_39 = zT_38.is_error;
    if (zT_39) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_40 = zT_38.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_maps = zT_40;
    zT_43 = alloc;
    zT_46 = 24;
    zT_47 = zig_wrap_mul_u(((zu64)(zT_46)), ((zu64)(new_cap)), 32u);
    zT_48 = zig_overflow_flag_mul_u(((zu64)(zT_46)), ((zu64)(new_cap)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_44 = zT_47;
    zT_52 = zF_1395EB68_sandAlloc(zT_43, zT_44, (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_54 = zT_52.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_uac = zT_54;
    zT_57 = 0;
    ndi = zT_57;
    goto z_bb_13;
    z_bb_13:
    zT_58 = plan->fn_count;
    if ((unsigned char)(ndi < zT_58)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_60 = plan->fn_keys;
    zT_61 = zT_60[ndi];
    zT_62 = (unsigned int*)raw_keys;
    zT_62[ndi] = zT_61;
    zT_63 = plan->fn_maps;
    zT_64 = zT_63[ndi];
    zT_65 = (zT_21D3708C_U32ToU32Map*)raw_maps;
    zT_65[ndi] = zT_64;
    zT_66 = plan->uac_maps;
    zT_67 = zT_66[ndi];
    zT_68 = (zT_21D3708C_U32ToU32Map*)raw_uac;
    zT_68[ndi] = zT_67;
    goto z_bb_16;
    z_bb_15:
    plan->fn_keys = (unsigned int*)((unsigned int*)raw_keys);
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_maps);
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_uac);
    plan->fn_cap = new_cap;
    return;
    z_bb_16:
    zT_69 = 1;
    zT_70 = zig_wrap_add_u(((zu64)(ndi)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(ndi)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    ndi = zT_70;
    goto z_bb_13;
}

/* spellPlanInit */
void zF_D67A348C_spellPlanInit(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, unsigned int fn_hint) {
    int zT_3;
    int zT_4;
    int zT_5;
    int zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_21D3708C_U32ToU32Map zT_17;
    zT_3E40CD83_Sand* zT_21;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_FDFD82FD_EU_362 zT_30;
    unsigned char zT_31;
    unsigned char* zT_32;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    zT_FDFD82FD_EU_362 zT_44;
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_3E40CD83_Sand* zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_FDFD82FD_EU_362 zT_58;
    unsigned char zT_59;
    unsigned char* zT_60;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    unsigned char* raw_keys;
    unsigned char* raw_maps;
    unsigned char* raw_uac;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    plan->fn_keys = (unsigned int*)zT_3;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)zT_4;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)zT_5;
    plan->fn_count = (unsigned int)(0);
    plan->fn_cap = (unsigned int)(0);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    plan->typedef_order = (unsigned int*)zT_8;
    plan->typedef_order_len = (unsigned int)(0);
    zT_10 = alloc;
    zT_12 = 8;
    zT_13 = zig_wrap_add_u(((zu64)(fn_hint)), ((zu64)(zT_12)), 32u);
    zT_14 = zig_overflow_flag_add_u(((zu64)(fn_hint)), ((zu64)(zT_12)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_11 = zT_13;
    zT_17 = zF_619D56E6_u32ToU32MapInitCap(zT_10, zT_11);
    plan->fn_key_index = zT_17;
    if ((unsigned char)(fn_hint != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = alloc;
    zT_24 = 4;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_24)), ((zu64)(fn_hint)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_24)), ((zu64)(fn_hint)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_22 = zT_25;
    zT_30 = zF_1395EB68_sandAlloc(zT_21, zT_22, (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_32 = zT_30.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_32;
    zT_35 = alloc;
    zT_38 = 24;
    zT_39 = zig_wrap_mul_u(((zu64)(zT_38)), ((zu64)(fn_hint)), 32u);
    zT_40 = zig_overflow_flag_mul_u(((zu64)(zT_38)), ((zu64)(fn_hint)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_36 = zT_39;
    zT_44 = zF_1395EB68_sandAlloc(zT_35, zT_36, (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_46 = zT_44.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_maps = zT_46;
    zT_49 = alloc;
    zT_52 = 24;
    zT_53 = zig_wrap_mul_u(((zu64)(zT_52)), ((zu64)(fn_hint)), 32u);
    zT_54 = zig_overflow_flag_mul_u(((zu64)(zT_52)), ((zu64)(fn_hint)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    zT_50 = zT_53;
    zT_58 = zF_1395EB68_sandAlloc(zT_49, zT_50, (unsigned int)(4));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_60 = zT_58.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_uac = zT_60;
    plan->fn_keys = (unsigned int*)((unsigned int*)raw_keys);
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_maps);
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_uac);
    plan->fn_cap = fn_hint;
    goto z_bb_2;
}

/* spellPlanPlanFn */
void zF_72205F3D_spellPlanPlanFn(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, unsigned int fn_key, zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1317DCD6_C89SpellPlan* zT_8;
    zT_3E40CD83_Sand* zT_9;
    unsigned int zT_11;
    unsigned int* zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned int zT_14;
    zT_5D72FBF8_TempDeclArrayList zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_21D3708C_U32ToU32Map zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    zT_5D72FBF8_TempDeclArrayList zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zT_21D3708C_U32ToU32Map zT_33;
    zT_21D3708C_U32ToU32Map* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    zT_21D3708C_U32ToU32Map* zT_40;
    unsigned int zT_41;
    zT_BAEE192E_Opt_10 zT_43;
    unsigned char zT_44;
    zT_21D3708C_U32ToU32Map* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_5D72FBF8_TempDeclArrayList zT_55;
    unsigned int zT_56;
    zT_5D72FBF8_TempDeclArrayList zT_59;
    zT_1937645B_TempDecl* zT_60;
    zT_1937645B_TempDecl zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    zT_3E40CD83_Sand* zT_76;
    unsigned int zT_77;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_FDFD82FD_EU_362 zT_86;
    unsigned char zT_87;
    unsigned char* zT_88;
    unsigned int* zT_91;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101;
    unsigned int zT_102;
    zT_5D72FBF8_TempDeclArrayList zT_103;
    unsigned int zT_104;
    zT_5D72FBF8_TempDeclArrayList zT_107;
    zT_1937645B_TempDecl* zT_108;
    zT_1937645B_TempDecl zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_1CF28CA3_BasicBlockArrayList zT_130;
    unsigned int zT_131;
    zT_1CF28CA3_BasicBlockArrayList zT_134;
    zT_88A68B1A_BasicBlock* zT_135;
    zT_88A68B1A_BasicBlock* zT_136;
    unsigned int zT_138;
    zT_DAE4631D_LirInstArrayList zT_139;
    unsigned int zT_140;
    zT_DAE4631D_LirInstArrayList zT_143;
    zT_6BA597BC_LirInst* zT_144;
    zT_6BA597BC_LirInst zT_145;
    unsigned int zT_147;
    zT_79FAE712_u64 zT_149;
    unsigned char zT_151;
    unsigned char zT_153;
    unsigned char zT_155;
    unsigned char zT_157;
    unsigned char zT_159;
    unsigned int zT_161;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    zT_79FAE712_u64 zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    unsigned char zT_170;
    unsigned int zT_172;
    unsigned char zT_173;
    unsigned char zT_174;
    unsigned char zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    unsigned char zT_180;
    unsigned int zT_182;
    unsigned char zT_183;
    unsigned char zT_186;
    unsigned int zT_190;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_5D72FBF8_TempDeclArrayList zT_197;
    zT_1937645B_TempDecl* zT_198;
    unsigned int zT_199;
    zT_1937645B_TempDecl zT_200;
    unsigned int zT_201;
    zT_338B7C76_TypeRegistry* zT_205;
    unsigned int zT_206;
    zT_79FAE712_u64 zT_207;
    unsigned char zT_208;
    unsigned char zT_209;
    unsigned int zT_210;
    unsigned int zT_213;
    zT_21D3708C_U32ToU32Map* zT_214;
    unsigned char zT_219;
    unsigned char zT_222;
    zT_BBC23664_LirFunction* zT_226;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_BBC23664_LirFunction* zT_232;
    unsigned int* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned char zT_241;
    zT_21D3708C_U32ToU32Map* zT_247;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned char zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned char zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned char zT_265;
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zig_poison_fill((void*)&zT_210, (unsigned int)sizeof zT_210);
    zig_poison_fill((void*)&zT_230, (unsigned int)sizeof zT_230);
    zig_poison_fill((void*)&zT_236, (unsigned int)sizeof zT_236);
    zig_poison_fill((void*)&zT_241, (unsigned int)sizeof zT_241);
    unsigned int fi;
    unsigned int t2pos_max;
    unsigned int tm_i;
    zT_1937645B_TempDecl tm_td;
    unsigned char* t2pos_raw;
    unsigned int* t2pos;
    unsigned int tpi;
    unsigned int ord;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned int result;
    zT_79FAE712_u64 value;
    unsigned char ic_width;
    unsigned char ic_signed;
    unsigned char plan_kind;
    unsigned char uac_kind;
    unsigned char uac_op;
    unsigned int uac_lhs;
    unsigned int uac_rhs;
    zT_B6F925A1_anon_117071 ic;
    zT_03BF58FB_anon_116827 b;
    zT_F1C17B3C_anon_116835 u;
    zT_24F18406_anon_117023 c;
    unsigned int ht;
    unsigned int hpos;
    unsigned int carrier;
    unsigned int l_tyid;
    unsigned int r_tyid;
    unsigned char prom_side;
    zT_5 = plan->fn_count;
    zT_6 = plan->fn_cap;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = plan;
    zT_9 = alloc;
    zF_E2B88A09_spellPlanGrow(zT_8, zT_9);
    goto z_bb_2;
    z_bb_2:
    zT_11 = plan->fn_count;
    fi = zT_11;
    zT_12 = plan->fn_keys;
    zT_12[fi] = fn_key;
    zT_13 = alloc;
    zT_15 = lir_fn->hoisted_temps;
    zT_16 = zT_15.len;
    zT_17 = 16;
    zT_18 = zig_wrap_add_u(((zu64)(zT_16)), ((zu64)(zT_17)), 32u);
    zT_19 = zig_overflow_flag_add_u(((zu64)(zT_16)), ((zu64)(zT_17)), 32u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    zT_14 = zT_18;
    zT_22 = zF_619D56E6_u32ToU32MapInitCap(zT_13, zT_14);
    zT_23 = plan->fn_maps;
    zT_23[fi] = zT_22;
    zT_24 = alloc;
    zT_26 = lir_fn->hoisted_temps;
    zT_27 = zT_26.len;
    zT_28 = 16;
    zT_29 = zig_wrap_add_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    zT_25 = zT_29;
    zT_33 = zF_619D56E6_u32ToU32MapInitCap(zT_24, zT_25);
    zT_34 = plan->uac_maps;
    zT_34[fi] = zT_33;
    zT_35 = 1;
    zT_36 = zig_wrap_add_u(((zu64)(fi)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(fi)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    plan->fn_count = zT_36;
    zT_40 = &plan->fn_key_index;
    zT_41 = fn_key;
    zT_43 = zF_F3EE5998_u32ToU32MapGet(zT_40, zT_41);
    zT_44 = zT_43.has_value;
    if ((unsigned char)(!zT_44)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_46 = &plan->fn_key_index;
    zT_47 = fn_key;
    zF_26476265_u32ToU32MapPut(zT_46, zT_47, (unsigned int)((unsigned int)fi));
    goto z_bb_4;
    z_bb_4:
    zT_52 = 1;
    t2pos_max = zT_52;
    zT_54 = 0;
    tm_i = zT_54;
    goto z_bb_5;
    z_bb_5:
    zT_55 = lir_fn->hoisted_temps;
    zT_56 = zT_55.len;
    if ((unsigned char)(tm_i < zT_56)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_59 = lir_fn->hoisted_temps;
    zT_60 = zT_59.items;
    zT_61 = zT_60[tm_i];
    tm_td = zT_61;
    zT_62 = tm_td.temp_id;
    if ((unsigned char)(zT_62 >= t2pos_max)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_76 = alloc;
    zT_79 = 4;
    zT_80 = (unsigned int)t2pos_max;
    zT_81 = zig_wrap_mul_u(((zu64)(zT_79)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_mul_u(((zu64)(zT_79)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    zT_77 = zT_81;
    zT_86 = zF_1395EB68_sandAlloc(zT_76, zT_77, (unsigned int)(4));
    zT_87 = zT_86.is_error;
    if (zT_87) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_70 = 1;
    zT_71 = zig_wrap_add_u(((zu64)(tm_i)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(tm_i)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    tm_i = zT_71;
    goto z_bb_5;
    z_bb_9:
    zT_64 = tm_td.temp_id;
    zT_65 = 1;
    zT_66 = zig_wrap_add_u(((zu64)(zT_64)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(zT_64)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    t2pos_max = zT_66;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_88 = zT_86.data.payload;
    goto z_bb_13;
    z_bb_13:
    t2pos_raw = zT_88;
    zT_91 = (unsigned int*)t2pos_raw;
    t2pos = zT_91;
    zT_93 = 0;
    tpi = zT_93;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(tpi < t2pos_max)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_95 = 4294967295u;
    zT_96 = (unsigned int)tpi;
    t2pos[zT_96] = zT_95;
    goto z_bb_17;
    z_bb_16:
    zT_102 = 0;
    tm_i = zT_102;
    goto z_bb_18;
    z_bb_17:
    zT_97 = 1;
    zT_98 = zig_wrap_add_u(((zu64)(tpi)), ((zu64)(zT_97)), 32u);
    zT_99 = zig_overflow_flag_add_u(((zu64)(tpi)), ((zu64)(zT_97)), 32u);
    zT_101 = zT_99 == (unsigned int)(0);
    if (!(zT_101)) { pal_trap(); }
    tpi = zT_98;
    goto z_bb_14;
    z_bb_18:
    zT_103 = lir_fn->hoisted_temps;
    zT_104 = zT_103.len;
    if ((unsigned char)(tm_i < zT_104)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_107 = lir_fn->hoisted_temps;
    zT_108 = zT_107.items;
    zT_109 = zT_108[tm_i];
    tm_td = zT_109;
    zT_110 = tm_td.temp_id;
    if ((unsigned char)(zT_110 < t2pos_max)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_127 = 0;
    ord = zT_127;
    zT_129 = 0;
    bi = zT_129;
    goto z_bb_27;
    z_bb_21:
    zT_121 = 1;
    zT_122 = zig_wrap_add_u(((zu64)(tm_i)), ((zu64)(zT_121)), 32u);
    zT_123 = zig_overflow_flag_add_u(((zu64)(tm_i)), ((zu64)(zT_121)), 32u);
    zT_125 = zT_123 == (unsigned int)(0);
    if (!(zT_125)) { pal_trap(); }
    tm_i = zT_122;
    goto z_bb_18;
    z_bb_22:
    zT_113 = tm_td.temp_id;
    zT_114 = (unsigned int)zT_113;
    zT_115 = t2pos[zT_114];
    zT_112 = zT_115 == (unsigned int)(4294967295u);
    goto z_bb_24;
    z_bb_23:
    zT_112 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_112) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_118 = (unsigned int)tm_i;
    zT_119 = tm_td.temp_id;
    zT_120 = (unsigned int)zT_119;
    t2pos[zT_120] = zT_118;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_130 = lir_fn->blocks;
    zT_131 = zT_130.len;
    if ((unsigned char)(bi < zT_131)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_134 = lir_fn->blocks;
    zT_135 = zT_134.items;
    zT_136 = zT_135 + bi;
    bb = zT_136;
    zT_138 = 0;
    ii = zT_138;
    goto z_bb_31;
    z_bb_29:
    return;
    z_bb_30:
    zT_261 = 1;
    zT_262 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_261)), 32u);
    zT_263 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_261)), 32u);
    zT_265 = zT_263 == (unsigned int)(0);
    if (!(zT_265)) { pal_trap(); }
    bi = zT_262;
    goto z_bb_27;
    z_bb_31:
    zT_139 = bb->insts;
    zT_140 = zT_139.len;
    if ((unsigned char)(ii < zT_140)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_143 = bb->insts;
    zT_144 = zT_143.items;
    zT_145 = zT_144[ii];
    inst = zT_145;
    zT_147 = 4294967295u;
    result = zT_147;
    zT_149 = 0;
    value = zT_149;
    zT_151 = 0;
    ic_width = zT_151;
    zT_153 = 0;
    ic_signed = zT_153;
    zT_155 = 0;
    plan_kind = zT_155;
    zT_157 = 0;
    uac_kind = zT_157;
    zT_159 = 0;
    uac_op = zT_159;
    zT_161 = 0;
    uac_lhs = zT_161;
    zT_163 = 0;
    uac_rhs = zT_163;
    zT_164 = inst.tag;
switch (zT_164) {
case 44: goto z_bb_35;
case 12: goto z_bb_36;
case 13: goto z_bb_37;
case 38: goto z_bb_38;
default: goto z_bb_39;
}
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_256 = 1;
    zT_257 = zig_wrap_add_u(((zu64)(ii)), ((zu64)(zT_256)), 32u);
    zT_258 = zig_overflow_flag_add_u(((zu64)(ii)), ((zu64)(zT_256)), 32u);
    zT_260 = zT_258 == (unsigned int)(0);
    if (!(zT_260)) { pal_trap(); }
    ii = zT_257;
    goto z_bb_31;
    z_bb_35:
    ic = inst.payload.int_const._0;
    zT_166 = ic.result;
    result = zT_166;
    zT_167 = ic.value;
    value = zT_167;
    zT_168 = ic.width_bits;
    ic_width = zT_168;
    zT_169 = ic.is_signed;
    ic_signed = zT_169;
    zT_170 = 1;
    plan_kind = zT_170;
    goto z_bb_41;
    z_bb_36:
    b = inst.payload.binary._0;
    zT_172 = b.result;
    result = zT_172;
    zT_173 = 1;
    plan_kind = zT_173;
    zT_174 = 1;
    uac_kind = zT_174;
    zT_175 = b.op;
    uac_op = zT_175;
    zT_176 = b.lhs;
    uac_lhs = zT_176;
    zT_177 = b.rhs;
    uac_rhs = zT_177;
    goto z_bb_41;
    z_bb_37:
    u = inst.payload.unary._0;
    zT_179 = u.result;
    result = zT_179;
    zT_180 = 1;
    plan_kind = zT_180;
    goto z_bb_41;
    z_bb_38:
    c = inst.payload.int_cast._0;
    zT_182 = c.result;
    result = zT_182;
    zT_183 = 1;
    plan_kind = zT_183;
    goto z_bb_41;
    z_bb_39:
    goto z_bb_41;
    z_bb_41:
    if ((unsigned char)(plan_kind != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_186 = result != (unsigned int)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_186 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_186) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_190 = 4294967295u;
    ht = zT_190;
    if ((unsigned char)(result < t2pos_max)) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    if ((unsigned char)(uac_kind != (unsigned char)(0))) goto z_bb_53; else goto z_bb_54;
    z_bb_47:
    zT_193 = (unsigned int)result;
    zT_194 = t2pos[zT_193];
    hpos = zT_194;
    if ((unsigned char)(hpos != (unsigned int)(4294967295u))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    if ((unsigned char)(ht != (unsigned int)(4294967295u))) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    zT_197 = lir_fn->hoisted_temps;
    zT_198 = zT_197.items;
    zT_199 = (unsigned int)hpos;
    zT_200 = zT_198[zT_199];
    zT_201 = zT_200.type_id;
    ht = zT_201;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_205 = reg;
    zT_206 = ht;
    zT_207 = value;
    zT_208 = ic_width;
    zT_209 = ic_signed;
    zT_210 = zF_48A5B64F_deriveConstCarrier(zT_205, zT_206, zT_207, zT_208, zT_209);
    carrier = zT_210;
    zT_214 = plan->fn_maps;
    zT_213 = carrier;
    zF_26476265_u32ToU32MapPut((zT_21D3708C_U32ToU32Map*)(zT_214 + fi), (unsigned int)((unsigned int)ord), zT_213);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    zT_219 = uac_op >= (unsigned char)(10);
    goto z_bb_55;
    z_bb_54:
    zT_219 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_219) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_222 = uac_op < (unsigned char)(16);
    goto z_bb_58;
    z_bb_57:
    zT_222 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_222) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_226 = lir_fn;
    zT_227 = t2pos;
    zT_228 = t2pos_max;
    zT_229 = uac_lhs;
    zT_230 = zF_F9C1339C_hoistedEffType(zT_226, zT_227, zT_228, zT_229);
    l_tyid = zT_230;
    zT_232 = lir_fn;
    zT_233 = t2pos;
    zT_234 = t2pos_max;
    zT_235 = uac_rhs;
    zT_236 = zF_F9C1339C_hoistedEffType(zT_232, zT_233, zT_234, zT_235);
    r_tyid = zT_236;
    zT_238 = reg;
    zT_239 = l_tyid;
    zT_240 = r_tyid;
    zT_241 = zF_12E895CF_uacPromoteSide(zT_238, zT_239, zT_240);
    prom_side = zT_241;
    if ((unsigned char)(prom_side < (unsigned char)(2))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_251 = 1;
    zT_252 = zig_wrap_add_u(((zu64)(ord)), ((zu64)(zT_251)), 32u);
    zT_253 = zig_overflow_flag_add_u(((zu64)(ord)), ((zu64)(zT_251)), 32u);
    zT_255 = zT_253 == (unsigned int)(0);
    if (!(zT_255)) { pal_trap(); }
    ord = zT_252;
    goto z_bb_34;
    z_bb_61:
    zT_247 = plan->uac_maps;
    zF_26476265_u32ToU32MapPut((zT_21D3708C_U32ToU32Map*)(zT_247 + fi), (unsigned int)((unsigned int)ord), (unsigned int)((unsigned int)prom_side));
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
}

/* hoistedEffType */
unsigned int zF_F9C1339C_hoistedEffType(zT_BBC23664_LirFunction* lir_fn, unsigned int* t2pos, unsigned int t2pos_max, unsigned int temp_id) {
    unsigned int zT_7;
    unsigned int zT_8;
    zT_5D72FBF8_TempDeclArrayList zT_13;
    zT_1937645B_TempDecl* zT_14;
    unsigned int zT_15;
    zT_1937645B_TempDecl zT_16;
    unsigned int zT_17;
    unsigned char zT_20;
    unsigned int p;
    unsigned int eff;
    if ((unsigned char)(temp_id >= t2pos_max)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = (unsigned int)temp_id;
    zT_8 = t2pos[zT_7];
    p = zT_8;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_13 = lir_fn->hoisted_temps;
    zT_14 = zT_13.items;
    zT_15 = (unsigned int)p;
    zT_16 = zT_14[zT_15];
    zT_17 = zT_16.type_id;
    eff = zT_17;
    if ((unsigned char)(eff != (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = eff != (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_20 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_20) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return eff;
    z_bb_9:
    return (unsigned int)(0);
}

/* uacPromoteSide */
unsigned char zF_12E895CF_uacPromoteSide(zT_338B7C76_TypeRegistry* reg, unsigned int l_tyid, unsigned int r_tyid) {
    signed char zT_4;
    signed char zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    signed char zT_11;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_15;
    signed char zT_16;
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    signed char l_sgn;
    signed char r_sgn;
    zT_4 = (signed char)-1;
    l_sgn = zT_4;
    zT_6 = (signed char)-1;
    r_sgn = zT_6;
    if ((unsigned char)(l_tyid != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = reg;
    zT_10 = l_tyid;
    zT_11 = zF_DE90B14C_typeRegistryIntSign(zT_9, zT_10);
    l_sgn = zT_11;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(r_tyid != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = reg;
    zT_15 = r_tyid;
    zT_16 = zF_DE90B14C_typeRegistryIntSign(zT_14, zT_15);
    r_sgn = zT_16;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(l_sgn == (signed char)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = r_sgn == (signed char)(0);
    goto z_bb_7;
    z_bb_6:
    zT_19 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_22 = reg;
    zT_23 = r_tyid;
    zT_24 = zF_47244FDF_typeRegistryIntByte(zT_22, zT_23);
    zT_25 = reg;
    zT_26 = l_tyid;
    zT_27 = zF_47244FDF_typeRegistryIntByte(zT_25, zT_26);
    if ((unsigned char)(zT_24 >= zT_27)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return (unsigned char)(2);
    z_bb_10:
    if ((unsigned char)(l_sgn == (signed char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_32 = r_sgn == (signed char)(1);
    goto z_bb_15;
    z_bb_14:
    zT_32 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_35 = reg;
    zT_36 = l_tyid;
    zT_37 = zF_47244FDF_typeRegistryIntByte(zT_35, zT_36);
    zT_38 = reg;
    zT_39 = r_tyid;
    zT_40 = zF_47244FDF_typeRegistryIntByte(zT_38, zT_39);
    if ((unsigned char)(zT_37 >= zT_40)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_9;
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    goto z_bb_17;
}

/* spellPlanUac */
zT_BAEE192E_Opt_10 zF_54BC5F51_spellPlanUac(zT_1317DCD6_C89SpellPlan* plan, unsigned int fn_key, unsigned int inst_ord) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    unsigned char zT_7;
    unsigned int zT_10;
    zT_21D3708C_U32ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    unsigned int fi_v;
    zT_3 = &plan->fn_key_index;
    zT_4 = fn_key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_6.has_value)) { pal_trap(); }
    fi_v = zT_6.value;
    zT_11 = plan->uac_maps;
    zT_10 = inst_ord;
    zT_14 = zF_F3EE5998_u32ToU32MapGet((zT_21D3708C_U32ToU32Map*)(zT_11 + (unsigned int)((unsigned int)fi_v)), zT_10);
    return zT_14;
    z_bb_2:
    zT_15.has_value = 0;
    return zT_15;
}

/* spellPlanCarrier */
zT_BAEE192E_Opt_10 zF_1AA43196_spellPlanCarrier(zT_1317DCD6_C89SpellPlan* plan, unsigned int fn_key, unsigned int inst_ord) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6;
    unsigned char zT_7;
    unsigned int zT_10;
    zT_21D3708C_U32ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_14;
    zT_BAEE192E_Opt_10 zT_15;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    unsigned int fi_v;
    zT_3 = &plan->fn_key_index;
    zT_4 = fn_key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(zT_6.has_value)) { pal_trap(); }
    fi_v = zT_6.value;
    zT_11 = plan->fn_maps;
    zT_10 = inst_ord;
    zT_14 = zF_F3EE5998_u32ToU32MapGet((zT_21D3708C_U32ToU32Map*)(zT_11 + (unsigned int)((unsigned int)fi_v)), zT_10);
    return zT_14;
    z_bb_2:
    zT_15.has_value = 0;
    return zT_15;
}

/* tstTopologicalSort */
unsigned int* zF_1DD26D63_tstTopologicalSort(zT_338B7C76_TypeRegistry* reg, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_3;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    int zT_13;
    zT_FDFD82FD_EU_362 zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int* zT_20;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    int zT_32;
    zT_FDFD82FD_EU_362 zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int* zT_39;
    zT_338B7C76_TypeRegistry* zT_42;
    unsigned int zT_43;
    unsigned int* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_52;
    zT_3E40CD83_Sand* zT_54;
    unsigned int zT_55;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    int zT_62;
    zT_FDFD82FD_EU_362 zT_64;
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int* zT_69;
    zT_3E40CD83_Sand* zT_71;
    unsigned int zT_72;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_78;
    int zT_79;
    zT_FDFD82FD_EU_362 zT_81;
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int* zT_86;
    zT_3E40CD83_Sand* zT_88;
    unsigned int zT_89;
    int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    int zT_96;
    zT_FDFD82FD_EU_362 zT_98;
    unsigned char zT_99;
    unsigned char* zT_100;
    unsigned char* zT_103;
    unsigned int zT_105;
    unsigned char zT_107;
    int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    int zT_115;
    unsigned int zT_116;
    int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_123;
    unsigned int zT_124;
    int zT_125;
    int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_132;
    int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    int zT_140;
    unsigned int zT_141;
    unsigned int zT_144;
    int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned char zT_156;
    unsigned char zT_157;
    unsigned int zT_158;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned char zT_166;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned char zT_174;
    unsigned int zT_175;
    int zT_176;
    int zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned char zT_183;
    int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned char zT_189;
    unsigned int zT_191;
    unsigned char zT_193;
    unsigned int zT_196;
    int zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    unsigned char zT_202;
    int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned char zT_208;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_98, (unsigned int)sizeof zT_98);
    zig_poison_fill((void*)&zT_166, (unsigned int)sizeof zT_166);
    unsigned int tl;
    unsigned char* indegree_raw;
    unsigned int* indegree;
    unsigned int ti;
    unsigned char* edge_raw;
    unsigned int* edge_buf;
    unsigned char* result_raw;
    unsigned int* result;
    unsigned char* queue_raw;
    unsigned int* queue;
    unsigned char* popped_raw;
    unsigned char* popped;
    unsigned int zi;
    unsigned int qhead;
    unsigned int qtail;
    unsigned int ri;
    unsigned int cur;
    unsigned int tj;
    unsigned int ai;
    unsigned int idx;
    zT_3 = reg->types_len;
    tl = zT_3;
    zT_5 = alloc;
    zT_8 = 4;
    zT_9 = zig_wrap_mul_u(((zu64)(zT_8)), ((zu64)(tl)), 32u);
    zT_10 = zig_overflow_flag_mul_u(((zu64)(zT_8)), ((zu64)(tl)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_6 = zT_9;
    zT_13 = 4;
    zT_15 = zF_1395EB68_sandAlloc(zT_5, zT_6, (unsigned int)((unsigned int)zT_13));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_17 = zT_15.data.payload;
    goto z_bb_3;
    z_bb_3:
    indegree_raw = zT_17;
    zT_20 = (unsigned int*)indegree_raw;
    indegree = zT_20;
    zT_22 = 0;
    ti = zT_22;
    zT_24 = alloc;
    zT_27 = 4;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(tl)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(tl)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_25 = zT_28;
    zT_32 = 4;
    zT_34 = zF_1395EB68_sandAlloc(zT_24, zT_25, (unsigned int)((unsigned int)zT_32));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_36 = zT_34.data.payload;
    goto z_bb_6;
    z_bb_6:
    edge_raw = zT_36;
    zT_39 = (unsigned int*)edge_raw;
    edge_buf = zT_39;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)((unsigned int)((unsigned int)ti) < tl)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_42 = reg;
    zT_43 = ti;
    zT_44 = edge_buf;
    zT_45 = zF_F41AC8EB_typeRefs(zT_42, zT_43, zT_44);
    zT_46 = (unsigned int)ti;
    indegree[zT_46] = zT_45;
    goto z_bb_10;
    z_bb_9:
    zT_54 = alloc;
    zT_57 = 4;
    zT_58 = zig_wrap_mul_u(((zu64)(zT_57)), ((zu64)(tl)), 32u);
    zT_59 = zig_overflow_flag_mul_u(((zu64)(zT_57)), ((zu64)(tl)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zT_55 = zT_58;
    zT_62 = 4;
    zT_64 = zF_1395EB68_sandAlloc(zT_54, zT_55, (unsigned int)((unsigned int)zT_62));
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_47 = 1;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_48)), 32u);
    zT_50 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_48)), 32u);
    zT_52 = zT_50 == (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    ti = zT_49;
    goto z_bb_7;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_66 = zT_64.data.payload;
    goto z_bb_13;
    z_bb_13:
    result_raw = zT_66;
    zT_69 = (unsigned int*)result_raw;
    result = zT_69;
    zT_71 = alloc;
    zT_74 = 4;
    zT_75 = zig_wrap_mul_u(((zu64)(zT_74)), ((zu64)(tl)), 32u);
    zT_76 = zig_overflow_flag_mul_u(((zu64)(zT_74)), ((zu64)(tl)), 32u);
    zT_78 = zT_76 == (unsigned int)(0);
    if (!(zT_78)) { pal_trap(); }
    zT_72 = zT_75;
    zT_79 = 4;
    zT_81 = zF_1395EB68_sandAlloc(zT_71, zT_72, (unsigned int)((unsigned int)zT_79));
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_83 = zT_81.data.payload;
    goto z_bb_16;
    z_bb_16:
    queue_raw = zT_83;
    zT_86 = (unsigned int*)queue_raw;
    queue = zT_86;
    zT_88 = alloc;
    zT_91 = 1;
    zT_92 = zig_wrap_mul_u(((zu64)(zT_91)), ((zu64)(tl)), 32u);
    zT_93 = zig_overflow_flag_mul_u(((zu64)(zT_91)), ((zu64)(tl)), 32u);
    zT_95 = zT_93 == (unsigned int)(0);
    if (!(zT_95)) { pal_trap(); }
    zT_89 = zT_92;
    zT_96 = 1;
    zT_98 = zF_1395EB68_sandAlloc(zT_88, zT_89, (unsigned int)((unsigned int)zT_96));
    zT_99 = zT_98.is_error;
    if (zT_99) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_100 = zT_98.data.payload;
    goto z_bb_19;
    z_bb_19:
    popped_raw = zT_100;
    zT_103 = (unsigned char*)popped_raw;
    popped = zT_103;
    zT_105 = 0;
    zi = zT_105;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(zi < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_107 = 0;
    popped[zi] = zT_107;
    goto z_bb_23;
    z_bb_22:
    zT_115 = 0;
    zT_116 = (unsigned int)zT_115;
    qhead = zT_116;
    zT_118 = 0;
    zT_119 = (unsigned int)zT_118;
    qtail = zT_119;
    zT_120 = 0;
    ti = zT_120;
    goto z_bb_24;
    z_bb_23:
    zT_108 = 1;
    zT_109 = (unsigned int)zT_108;
    zT_110 = zig_wrap_add_u(((zu64)(zi)), ((zu64)(zT_109)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(zi)), ((zu64)(zT_109)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    zi = zT_110;
    goto z_bb_20;
    z_bb_24:
    if ((unsigned char)((unsigned int)((unsigned int)ti) < tl)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_123 = (unsigned int)ti;
    zT_124 = indegree[zT_123];
    zT_125 = 0;
    if ((unsigned char)(zT_124 == (unsigned int)zT_125)) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_140 = 0;
    zT_141 = (unsigned int)zT_140;
    ri = zT_141;
    goto z_bb_30;
    z_bb_27:
    zT_133 = 1;
    zT_134 = (unsigned int)zT_133;
    zT_135 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_134)), 32u);
    zT_136 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_134)), 32u);
    zT_138 = zT_136 == (unsigned int)(0);
    if (!(zT_138)) { pal_trap(); }
    ti = zT_135;
    goto z_bb_24;
    z_bb_28:
    queue[qtail] = ti;
    zT_127 = 1;
    zT_128 = (unsigned int)zT_127;
    zT_129 = zig_wrap_add_u(((zu64)(qtail)), ((zu64)(zT_128)), 32u);
    zT_130 = zig_overflow_flag_add_u(((zu64)(qtail)), ((zu64)(zT_128)), 32u);
    zT_132 = zT_130 == (unsigned int)(0);
    if (!(zT_132)) { pal_trap(); }
    qtail = zT_129;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    if ((unsigned char)(qhead < qtail)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_144 = queue[qhead];
    cur = zT_144;
    zT_145 = 1;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zig_wrap_add_u(((zu64)(qhead)), ((zu64)(zT_146)), 32u);
    zT_148 = zig_overflow_flag_add_u(((zu64)(qhead)), ((zu64)(zT_146)), 32u);
    zT_150 = zT_148 == (unsigned int)(0);
    if (!(zT_150)) { pal_trap(); }
    qhead = zT_147;
    result[ri] = cur;
    zT_151 = 1;
    zT_152 = (unsigned int)zT_151;
    zT_153 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_152)), 32u);
    zT_154 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_152)), 32u);
    zT_156 = zT_154 == (unsigned int)(0);
    if (!(zT_156)) { pal_trap(); }
    ri = zT_153;
    zT_157 = 1;
    zT_158 = (unsigned int)cur;
    popped[zT_158] = zT_157;
    zT_160 = 0;
    tj = zT_160;
    goto z_bb_34;
    z_bb_32:
    zT_191 = 0;
    ai = zT_191;
    goto z_bb_42;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    if ((unsigned char)((unsigned int)((unsigned int)tj) < tl)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_163 = reg;
    zT_164 = tj;
    zT_165 = cur;
    zT_166 = zF_8A421992_typeRefsContains(zT_163, zT_164, zT_165);
    if (zT_166) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_184 = 1;
    zT_185 = (unsigned int)zT_184;
    zT_186 = zig_wrap_add_u(((zu64)(tj)), ((zu64)(zT_185)), 32u);
    zT_187 = zig_overflow_flag_add_u(((zu64)(tj)), ((zu64)(zT_185)), 32u);
    zT_189 = zT_187 == (unsigned int)(0);
    if (!(zT_189)) { pal_trap(); }
    tj = zT_186;
    goto z_bb_34;
    z_bb_38:
    zT_168 = (unsigned int)tj;
    idx = zT_168;
    zT_169 = indegree[idx];
    zT_170 = 1;
    zT_171 = zig_wrap_sub_u(((zu64)(zT_169)), ((zu64)(zT_170)), 32u);
    zT_172 = zig_overflow_flag_sub_u(((zu64)(zT_169)), ((zu64)(zT_170)), 32u);
    zT_174 = zT_172 == (unsigned int)(0);
    if (!(zT_174)) { pal_trap(); }
    indegree[idx] = zT_171;
    zT_175 = indegree[idx];
    zT_176 = 0;
    if ((unsigned char)(zT_175 == (unsigned int)zT_176)) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    queue[qtail] = tj;
    zT_178 = 1;
    zT_179 = (unsigned int)zT_178;
    zT_180 = zig_wrap_add_u(((zu64)(qtail)), ((zu64)(zT_179)), 32u);
    zT_181 = zig_overflow_flag_add_u(((zu64)(qtail)), ((zu64)(zT_179)), 32u);
    zT_183 = zT_181 == (unsigned int)(0);
    if (!(zT_183)) { pal_trap(); }
    qtail = zT_180;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    if ((unsigned char)(ai < tl)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_193 = popped[ai];
    if ((unsigned char)(zT_193 == (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    return result;
    z_bb_45:
    zT_203 = 1;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zig_wrap_add_u(((zu64)(ai)), ((zu64)(zT_204)), 32u);
    zT_206 = zig_overflow_flag_add_u(((zu64)(ai)), ((zu64)(zT_204)), 32u);
    zT_208 = zT_206 == (unsigned int)(0);
    if (!(zT_208)) { pal_trap(); }
    ai = zT_205;
    goto z_bb_42;
    z_bb_46:
    zT_196 = (unsigned int)ai;
    result[ri] = zT_196;
    zT_197 = 1;
    zT_198 = (unsigned int)zT_197;
    zT_199 = zig_wrap_add_u(((zu64)(ri)), ((zu64)(zT_198)), 32u);
    zT_200 = zig_overflow_flag_add_u(((zu64)(ri)), ((zu64)(zT_198)), 32u);
    zT_202 = zT_200 == (unsigned int)(0);
    if (!(zT_202)) { pal_trap(); }
    ri = zT_199;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_45;
}

/* spellPlanPlanTypeOrder */
void zF_869C84A7_spellPlanPlanTypeOr(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned int* zT_5;
    unsigned int zT_6;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_3 = reg;
    zT_4 = alloc;
    zT_5 = zF_1DD26D63_tstTopologicalSort(zT_3, zT_4);
    plan->typedef_order = zT_5;
    zT_6 = reg->types_len;
    plan->typedef_order_len = zT_6;
    return;
}

/* EOF */
