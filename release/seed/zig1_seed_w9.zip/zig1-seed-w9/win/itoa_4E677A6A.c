#include "itoa_4E677A6A.h"
/* itoa */
unsigned int zF_A7504564_itoa(unsigned int value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    int zT_31;
    unsigned char zT_33;
    int zT_34;
    int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned char zT_52;
    unsigned char zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_60;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned int i;
    unsigned int v;
    unsigned int digit;
    zT_4 = buf.len;
    zT_5 = (unsigned int)zT_4;
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    i = zT_7;
    zT_11 = 0;
    zT_12 = (unsigned char)zT_11;
    zT_13 = (unsigned char*)buf.ptr;
    zT_14 = (unsigned int)i;
    zT_15 = buf.len;
    zT_16 = zT_14 < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_13[zT_14] = zT_12;
    v = value;
    zT_18 = 0;
    if ((unsigned char)(v == (unsigned int)zT_18)) goto z_bb_1; else goto z_bb_3;
    z_bb_1: ;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    i = zT_22;
    zT_26 = 48;
    zT_27 = (unsigned char*)buf.ptr;
    zT_28 = (unsigned int)i;
    zT_29 = buf.len;
    zT_30 = zT_28 < zT_29;
    if (!(zT_30)) { pal_trap(); }
    zT_27[zT_28] = zT_26;
    goto z_bb_2;
    z_bb_2: ;
    zT_62 = buf.len;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zig_wrap_sub_u(((zu64)(zT_63)), ((zu64)(i)), 32u);
    zT_65 = zig_overflow_flag_sub_u(((zu64)(zT_63)), ((zu64)(i)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_68 = 1;
    zT_69 = zig_wrap_sub_u(((zu64)(zT_64)), ((zu64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_sub_u(((zu64)(zT_64)), ((zu64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    return zT_69;
    z_bb_3: ;
    goto z_bb_4;
    z_bb_4: ;
    zT_31 = 0;
    if ((unsigned char)(v > (unsigned int)zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_5: ;
    zT_37 = 10;
    zT_40 = (unsigned int)zT_37 != (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_38 = v % zT_37;
    digit = zT_38;
    zT_41 = 10;
    zT_44 = (unsigned int)zT_41 != (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_42 = v / zT_41;
    v = zT_42;
    zT_45 = 1;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    i = zT_47;
    zT_51 = 48;
    zT_52 = (unsigned char)zig_cast_checked_u((zu64)digit, 32u, 0u, 8u);
    zT_53 = zig_wrap_add_u(((zu64)(zT_51)), ((zu64)(zT_52)), 8u);
    zT_54 = zig_overflow_flag_add_u(((zu64)(zT_51)), ((zu64)(zT_52)), 8u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    zT_57 = (unsigned char*)buf.ptr;
    zT_58 = (unsigned int)i;
    zT_59 = buf.len;
    zT_60 = zT_58 < zT_59;
    if (!(zT_60)) { pal_trap(); }
    zT_57[zT_58] = zT_53;
    goto z_bb_7;
    z_bb_6: ;
    goto z_bb_2;
    z_bb_7: ;
    goto z_bb_4;
    z_bb_8: ;
    zT_34 = 0;
    zT_33 = i > (unsigned int)zT_34;
    goto z_bb_10;
    z_bb_9: ;
    zT_33 = 0;
    goto z_bb_10;
    z_bb_10: ;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
}

/* itoa64 */
unsigned int zF_A3999586_itoa64(zT_79FAE712_u64 value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    int zT_31;
    unsigned char zT_33;
    int zT_34;
    int zT_37;
    zT_79FAE712_u64 zT_38;
    unsigned char zT_40;
    int zT_41;
    zT_79FAE712_u64 zT_42;
    unsigned char zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned char* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_61;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    unsigned int i;
    zT_79FAE712_u64 v;
    zT_79FAE712_u64 digit;
    zT_4 = buf.len;
    zT_5 = (unsigned int)zT_4;
    zT_6 = 1;
    zT_7 = zig_wrap_sub_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    i = zT_7;
    zT_11 = 0;
    zT_12 = (unsigned char)zT_11;
    zT_13 = (unsigned char*)buf.ptr;
    zT_14 = (unsigned int)i;
    zT_15 = buf.len;
    zT_16 = zT_14 < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_13[zT_14] = zT_12;
    v = value;
    zT_18 = 0;
    if ((unsigned char)(v == (zT_79FAE712_u64)zT_18)) goto z_bb_1; else goto z_bb_3;
    z_bb_1: ;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    i = zT_22;
    zT_26 = 48;
    zT_27 = (unsigned char*)buf.ptr;
    zT_28 = (unsigned int)i;
    zT_29 = buf.len;
    zT_30 = zT_28 < zT_29;
    if (!(zT_30)) { pal_trap(); }
    zT_27[zT_28] = zT_26;
    goto z_bb_2;
    z_bb_2: ;
    zT_63 = buf.len;
    zT_64 = (unsigned int)zT_63;
    zT_65 = zig_wrap_sub_u(((zu64)(zT_64)), ((zu64)(i)), 32u);
    zT_66 = zig_overflow_flag_sub_u(((zu64)(zT_64)), ((zu64)(i)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_69 = 1;
    zT_70 = zig_wrap_sub_u(((zu64)(zT_65)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_sub_u(((zu64)(zT_65)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    return zT_70;
    z_bb_3: ;
    goto z_bb_4;
    z_bb_4: ;
    zT_31 = 0;
    if ((unsigned char)(v > (zT_79FAE712_u64)zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_5: ;
    zT_37 = 10;
    zT_40 = (unsigned int)zT_37 != (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_38 = v % zT_37;
    digit = zT_38;
    zT_41 = 10;
    zT_44 = (unsigned int)zT_41 != (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_42 = v / zT_41;
    v = zT_42;
    zT_45 = 1;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    i = zT_47;
    zT_51 = 48;
    zT_52 = (unsigned int)zig_cast_checked_u((zu64)digit, 64u, 0u, 32u);
    zT_53 = (unsigned char)zig_cast_checked_u((zu64)zT_52, 32u, 0u, 8u);
    zT_54 = zig_wrap_add_u(((zu64)(zT_51)), ((zu64)(zT_53)), 8u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(zT_51)), ((zu64)(zT_53)), 8u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = (unsigned char*)buf.ptr;
    zT_59 = (unsigned int)i;
    zT_60 = buf.len;
    zT_61 = zT_59 < zT_60;
    if (!(zT_61)) { pal_trap(); }
    zT_58[zT_59] = zT_54;
    goto z_bb_7;
    z_bb_6: ;
    goto z_bb_2;
    z_bb_7: ;
    goto z_bb_4;
    z_bb_8: ;
    zT_34 = 0;
    zT_33 = i > (unsigned int)zT_34;
    goto z_bb_10;
    z_bb_9: ;
    zT_33 = 0;
    goto z_bb_10;
    z_bb_10: ;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
}

/* EOF */
