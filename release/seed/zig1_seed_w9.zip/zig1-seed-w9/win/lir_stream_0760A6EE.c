#include "lir_stream_0760A6EE.h"
static unsigned char* const zG_4417A8F5_READ_MODE = (unsigned char*)"rb";
static unsigned char* const zG_82B6E276_WRITE_MODE = (unsigned char*)"wb";
/* lirStreamInit */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void) {
    zT_7E7544E4_LirStream zT_0;
    zT_D21A8776_SpillStore zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.path_len = zT_2;
    zT_3 = 0;
    zT_0.write_offset = zT_3;
    return zT_0;
}

/* lirStreamBeginWrite */
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream* s, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned char zT_26;
    zT_D21A8776_SpillStore* zT_28;
    zT_0426DCE7_SpillBackend zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_3E40CD83_Sand* zT_31;
    unsigned char* zT_32;
    zT_0426DCE7_SpillBackend zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned char zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    unsigned int i;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = path.len;
    zT_13 = i < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[i];
    zT_15 = s->path;
    zT_17 = i < (unsigned int)(512);
    if (!(zT_17)) { pal_trap(); }
    zT_15[i] = zT_14;
    goto z_bb_4;
    z_bb_3:
    s->path_len = i;
    zT_23 = 0;
    zT_24 = s->path;
    zT_26 = i < (unsigned int)(512);
    if (!(zT_26)) { pal_trap(); }
    zT_24[i] = zT_23;
    s->write_offset = (unsigned int)(0);
    zT_28 = &s->spill;
    zT_37 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir));
    zT_29 = zT_37;
    zT_38 = s->path;
    zT_39 = s->path_len;
    zT_40 = 0;
    zT_41 = zT_38 + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_44 = (unsigned int)zT_40 <= zT_39;
    if (!(zT_44)) { pal_trap(); }
    zT_45 = zT_39 <= (unsigned int)(512);
    if (!(zT_45)) { pal_trap(); }
    zT_46.ptr = (unsigned char*)zT_41;
    zT_46.len = zT_42;
    zT_30 = zT_46;
    zT_31 = alloc;
    zT_32 = zG_82B6E276_WRITE_MODE;
    zF_8AF94F71_spillOpen(zT_28, zT_29, zT_30, zT_31, zT_32);
    return;
    z_bb_4:
    zT_18 = 1;
    zT_19 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    i = zT_19;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* lirStreamFinishWrite */
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* lirStreamBeginRead */
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream* s, zT_3E40CD83_Sand* alloc) {
    zT_D21A8776_SpillStore zT_2;
    zT_0426DCE7_SpillBackend zT_3;
    zT_D21A8776_SpillStore* zT_8;
    zT_D21A8776_SpillStore* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned char* zT_13;
    unsigned char* zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_2 = s->spill;
    zT_3 = zT_2.backend;
    if ((unsigned char)(zT_3 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = &s->spill;
    zT_8->cur = (unsigned int)(0);
    return;
    z_bb_2:
    zT_9 = &s->spill;
    zT_17 = s->path;
    zT_18 = s->path_len;
    zT_19 = 0;
    zT_20 = zT_17 + zT_19;
    zT_21 = zT_18 - zT_19;
    zT_23 = (unsigned int)zT_19 <= zT_18;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_18 <= (unsigned int)(512);
    if (!(zT_24)) { pal_trap(); }
    zT_25.ptr = (unsigned char*)zT_20;
    zT_25.len = zT_21;
    zT_11 = zT_25;
    zT_12 = alloc;
    zT_13 = zG_4417A8F5_READ_MODE;
    zF_8AF94F71_spillOpen(zT_9, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_11, zT_12, zT_13);
    return;
}

/* lirStreamEndRead */
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* wU32 */
void zF_FB050204_wU32(zT_7E7544E4_LirStream* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    int zT_17;
    unsigned char zT_19;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_29;
    unsigned char zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned char zT_39;
    zT_D21A8776_SpillStore* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = v & (unsigned int)(255);
    zT_6 = (unsigned char)zig_cast_checked_u((zu64)zT_5, 32u, 0u, 8u);
    zT_7 = 0;
    zT_9 = (unsigned int)zT_7 < (unsigned int)(4);
    if (!(zT_9)) { pal_trap(); }
    b[zT_7] = zT_6;
    zT_13 = 1;
    if (!(zT_13)) { pal_trap(); }
    zT_15 = (unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255);
    zT_16 = (unsigned char)zig_cast_checked_u((zu64)zT_15, 32u, 0u, 8u);
    zT_17 = 1;
    zT_19 = (unsigned int)zT_17 < (unsigned int)(4);
    if (!(zT_19)) { pal_trap(); }
    b[zT_17] = zT_16;
    zT_23 = 1;
    if (!(zT_23)) { pal_trap(); }
    zT_25 = (unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255);
    zT_26 = (unsigned char)zig_cast_checked_u((zu64)zT_25, 32u, 0u, 8u);
    zT_27 = 2;
    zT_29 = (unsigned int)zT_27 < (unsigned int)(4);
    if (!(zT_29)) { pal_trap(); }
    b[zT_27] = zT_26;
    zT_33 = 1;
    if (!(zT_33)) { pal_trap(); }
    zT_35 = (unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255);
    zT_36 = (unsigned char)zig_cast_checked_u((zu64)zT_35, 32u, 0u, 8u);
    zT_37 = 3;
    zT_39 = (unsigned int)zT_37 < (unsigned int)(4);
    if (!(zT_39)) { pal_trap(); }
    b[zT_37] = zT_36;
    zT_40 = &s->spill;
    zT_41 = s->write_offset;
    zT_47 = 0;
    zT_48 = (unsigned char*)((unsigned char*)b) + zT_47;
    zT_49 = (unsigned int)(4) - zT_47;
    zT_50.ptr = (unsigned char*)zT_48;
    zT_50.len = zT_49;
    zT_42 = zT_50;
    zF_BFB33631_spillWriteAt(zT_40, zT_41, zT_42);
    zT_51 = s->write_offset;
    zT_52 = 4;
    zT_53 = zig_wrap_add_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_54 = zig_overflow_flag_add_u(((zu64)(zT_51)), ((zu64)(zT_52)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    s->write_offset = zT_53;
    return;
}

/* wU8 */
void zF_56013A33_wU8(zT_7E7544E4_LirStream* s, unsigned char v) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_3;
    int zT_4;
    unsigned char zT_6;
    zT_D21A8776_SpillStore* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 0;
    zT_6 = (unsigned int)zT_4 < (unsigned int)(1);
    if (!(zT_6)) { pal_trap(); }
    b[zT_4] = v;
    zT_7 = &s->spill;
    zT_8 = s->write_offset;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)b) + zT_14;
    zT_16 = (unsigned int)(1) - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    zT_9 = zT_17;
    zF_BFB33631_spillWriteAt(zT_7, zT_8, zT_9);
    zT_18 = s->write_offset;
    zT_19 = 1;
    zT_20 = zig_wrap_add_u(((zu64)(zT_18)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(zT_18)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    s->write_offset = zT_20;
    return;
}

/* wBytes */
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream* s, unsigned char* ptr, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    if ((unsigned char)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13 = (unsigned int)zT_10 <= len;
    if (!(zT_13)) { pal_trap(); }
    zT_14.ptr = (unsigned char*)zT_11;
    zT_14.len = zT_12;
    zT_7 = zT_14;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_15 = s->write_offset;
    zT_16 = (unsigned int)len;
    zT_17 = zig_wrap_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_15)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    s->write_offset = zT_17;
    return;
}

/* rU32 */
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned int zT_22;
    int zT_23;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned char zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned char zT_38;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned char zT_51;
    unsigned char zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned int zT_61;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(4) - zT_11;
    zT_14.ptr = (unsigned char*)zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_16 = 0;
    v = zT_16;
    zT_17 = 0;
    zT_19 = (unsigned int)zT_17 < (unsigned int)(4);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = b[zT_17];
    zT_22 = v | (unsigned int)((unsigned int)zT_20);
    v = zT_22;
    zT_23 = 1;
    zT_25 = (unsigned int)zT_23 < (unsigned int)(4);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = b[zT_23];
    zT_27 = (unsigned int)zT_26;
    zT_28 = 8;
    zT_31 = 1;
    if (!(zT_31)) { pal_trap(); }
    zT_29 = zig_wrap_shl_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zig_overflow_flag_shl_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_34 = zT_32 == (unsigned int)(0);
    if (!(zT_34)) { pal_trap(); }
    zT_35 = v | zT_29;
    v = zT_35;
    zT_36 = 2;
    zT_38 = (unsigned int)zT_36 < (unsigned int)(4);
    if (!(zT_38)) { pal_trap(); }
    zT_39 = b[zT_36];
    zT_40 = (unsigned int)zT_39;
    zT_41 = 16;
    zT_44 = 1;
    if (!(zT_44)) { pal_trap(); }
    zT_42 = zig_wrap_shl_u(((zu64)(zT_40)), ((zu64)(zT_41)), 32u);
    zT_45 = zig_overflow_flag_shl_u(((zu64)(zT_40)), ((zu64)(zT_41)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = v | zT_42;
    v = zT_48;
    zT_49 = 3;
    zT_51 = (unsigned int)zT_49 < (unsigned int)(4);
    if (!(zT_51)) { pal_trap(); }
    zT_52 = b[zT_49];
    zT_53 = (unsigned int)zT_52;
    zT_54 = 24;
    zT_57 = 1;
    if (!(zT_57)) { pal_trap(); }
    zT_55 = zig_wrap_shl_u(((zu64)(zT_53)), ((zu64)(zT_54)), 32u);
    zT_58 = zig_overflow_flag_shl_u(((zu64)(zT_53)), ((zu64)(zT_54)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_61 = v | zT_55;
    v = zT_61;
    return v;
}

/* rU8 */
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream* s) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    unsigned char zT_17;
    unsigned char zT_18;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(1) - zT_11;
    zT_14.ptr = (unsigned char*)zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_15 = 0;
    zT_17 = (unsigned int)zT_15 < (unsigned int)(1);
    if (!(zT_17)) { pal_trap(); }
    zT_18 = b[zT_15];
    return zT_18;
}

/* rBytes */
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream* s, unsigned char* dst, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore zT_9;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    if ((unsigned char)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_9 = s->spill;
    zT_6 = zT_9.cur;
    zT_11 = 0;
    zT_12 = dst + zT_11;
    zT_13 = len - zT_11;
    zT_14 = (unsigned int)zT_11 <= len;
    if (!(zT_14)) { pal_trap(); }
    zT_15.ptr = (unsigned char*)zT_12;
    zT_15.len = zT_13;
    zT_7 = zT_15;
    zF_E9F67450_spillReadAt(zT_5, zT_6, zT_7);
    return;
}

/* lirStreamAppend */
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream* s, zT_BBC23664_LirFunction src_fn) {
    unsigned int zT_3;
    zT_7E7544E4_LirStream* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_7;
    unsigned int zT_8;
    zT_7E7544E4_LirStream* zT_10;
    unsigned int zT_11;
    zT_7E7544E4_LirStream* zT_13;
    unsigned char zT_14;
    zT_7E7544E4_LirStream* zT_16;
    unsigned char zT_17;
    zT_7E7544E4_LirStream* zT_19;
    unsigned char zT_20;
    zT_7E7544E4_LirStream* zT_22;
    unsigned char zT_23;
    zT_7E7544E4_LirStream* zT_25;
    unsigned char zT_26;
    zT_7E7544E4_LirStream* zT_28;
    unsigned char zT_29;
    zT_7E7544E4_LirStream* zT_31;
    zT_CFE23D0A_LirParamArrayList zT_33;
    unsigned int zT_34;
    zT_7E7544E4_LirStream* zT_36;
    zT_1CF28CA3_BasicBlockArrayList zT_38;
    unsigned int zT_39;
    zT_7E7544E4_LirStream* zT_41;
    zT_5D72FBF8_TempDeclArrayList zT_43;
    unsigned int zT_44;
    zT_7E7544E4_LirStream* zT_46;
    zT_9F514E82_SwitchCaseArrayList zT_48;
    unsigned int zT_49;
    zT_7E7544E4_LirStream* zT_51;
    zT_AC00B5F6_LirSideEntryArrayLi zT_53;
    unsigned int zT_54;
    zT_7E7544E4_LirStream* zT_56;
    zT_21D3708C_U32ToU32Map zT_58;
    unsigned int zT_59;
    zT_7E7544E4_LirStream* zT_61;
    zT_21D3708C_U32ToU32Map zT_63;
    unsigned int zT_64;
    zT_CFE23D0A_LirParamArrayList zT_66;
    unsigned int zT_67;
    zT_7E7544E4_LirStream* zT_70;
    unsigned int zT_72;
    zT_CFE23D0A_LirParamArrayList zT_73;
    zT_8779209D_LirParam* zT_74;
    zT_CFE23D0A_LirParamArrayList zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned int zT_84;
    zT_1CF28CA3_BasicBlockArrayList zT_85;
    unsigned int zT_86;
    zT_1CF28CA3_BasicBlockArrayList zT_89;
    zT_88A68B1A_BasicBlock* zT_90;
    zT_88A68B1A_BasicBlock* zT_91;
    zT_7E7544E4_LirStream* zT_92;
    unsigned int zT_93;
    zT_7E7544E4_LirStream* zT_95;
    unsigned char zT_96;
    zT_7E7544E4_LirStream* zT_98;
    zT_7E7544E4_LirStream* zT_101;
    zT_7E7544E4_LirStream* zT_104;
    zT_7E7544E4_LirStream* zT_107;
    zT_DAE4631D_LirInstArrayList zT_109;
    unsigned int zT_110;
    zT_DAE4631D_LirInstArrayList zT_112;
    unsigned int zT_113;
    zT_7E7544E4_LirStream* zT_116;
    unsigned int zT_118;
    zT_DAE4631D_LirInstArrayList zT_119;
    zT_6BA597BC_LirInst* zT_120;
    zT_DAE4631D_LirInstArrayList zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_133;
    zT_5D72FBF8_TempDeclArrayList zT_134;
    unsigned int zT_135;
    zT_7E7544E4_LirStream* zT_138;
    unsigned int zT_140;
    zT_5D72FBF8_TempDeclArrayList zT_141;
    zT_1937645B_TempDecl* zT_142;
    zT_5D72FBF8_TempDeclArrayList zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    zT_9F514E82_SwitchCaseArrayList zT_151;
    unsigned int zT_152;
    zT_7E7544E4_LirStream* zT_155;
    unsigned int zT_157;
    zT_9F514E82_SwitchCaseArrayList zT_158;
    zT_4BD97095_SwitchCase* zT_159;
    zT_9F514E82_SwitchCaseArrayList zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned char zT_167;
    zT_AC00B5F6_LirSideEntryArrayLi zT_168;
    unsigned int zT_169;
    zT_7E7544E4_LirStream* zT_172;
    unsigned int zT_174;
    zT_AC00B5F6_LirSideEntryArrayLi zT_175;
    zT_A8A5B231_LirSideEntry* zT_176;
    zT_AC00B5F6_LirSideEntryArrayLi zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned char zT_184;
    zT_21D3708C_U32ToU32Map zT_185;
    unsigned int zT_186;
    zT_21D3708C_U32ToU32Map zT_190;
    unsigned int zT_191;
    zT_7E7544E4_LirStream* zT_192;
    unsigned int zT_194;
    zT_21D3708C_U32ToU32Map zT_195;
    unsigned int* zT_196;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    unsigned char zT_202;
    zT_7E7544E4_LirStream* zT_203;
    unsigned int zT_205;
    zT_21D3708C_U32ToU32Map zT_206;
    unsigned int* zT_207;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned char zT_213;
    zT_7E7544E4_LirStream* zT_214;
    unsigned int zT_216;
    zT_21D3708C_U32ToU32Map zT_217;
    unsigned char* zT_218;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned char zT_224;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned char zT_230;
    zT_E7714190_LirSlot zT_231;
    unsigned int zT_232;
    unsigned int start;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int cap;
    unsigned int byte_len;
    zT_3 = s->write_offset;
    start = zT_3;
    zT_4 = s;
    zT_5 = src_fn.name_id;
    zF_FB050204_wU32(zT_4, zT_5);
    zT_7 = s;
    zT_8 = src_fn.module_id;
    zF_FB050204_wU32(zT_7, zT_8);
    zT_10 = s;
    zT_11 = src_fn.return_type;
    zF_FB050204_wU32(zT_10, zT_11);
    zT_13 = s;
    zT_14 = src_fn.is_extern;
    zF_56013A33_wU8(zT_13, zT_14);
    zT_16 = s;
    zT_17 = src_fn.is_pub;
    zF_56013A33_wU8(zT_16, zT_17);
    zT_19 = s;
    zT_20 = src_fn.is_variadic;
    zF_56013A33_wU8(zT_19, zT_20);
    zT_22 = s;
    zT_23 = src_fn.call_conv;
    zF_56013A33_wU8(zT_22, zT_23);
    zT_25 = s;
    zT_26 = src_fn.poison_uninit;
    zF_56013A33_wU8(zT_25, zT_26);
    zT_28 = s;
    zT_29 = src_fn.is_export;
    zF_56013A33_wU8(zT_28, zT_29);
    zT_31 = s;
    zT_33 = src_fn.params;
    zT_34 = zT_33.len;
    zF_FB050204_wU32(zT_31, (unsigned int)((unsigned int)zT_34));
    zT_36 = s;
    zT_38 = src_fn.blocks;
    zT_39 = zT_38.len;
    zF_FB050204_wU32(zT_36, (unsigned int)((unsigned int)zT_39));
    zT_41 = s;
    zT_43 = src_fn.hoisted_temps;
    zT_44 = zT_43.len;
    zF_FB050204_wU32(zT_41, (unsigned int)((unsigned int)zT_44));
    zT_46 = s;
    zT_48 = src_fn.switch_cases;
    zT_49 = zT_48.len;
    zF_FB050204_wU32(zT_46, (unsigned int)((unsigned int)zT_49));
    zT_51 = s;
    zT_53 = src_fn.side_table;
    zT_54 = zT_53.len;
    zF_FB050204_wU32(zT_51, (unsigned int)((unsigned int)zT_54));
    zT_56 = s;
    zT_58 = src_fn.temp_variant_sub_field;
    zT_59 = zT_58.capacity;
    zF_FB050204_wU32(zT_56, (unsigned int)((unsigned int)zT_59));
    zT_61 = s;
    zT_63 = src_fn.temp_variant_sub_field;
    zT_64 = zT_63.count;
    zF_FB050204_wU32(zT_61, (unsigned int)((unsigned int)zT_64));
    zT_66 = src_fn.params;
    zT_67 = zT_66.len;
    if ((unsigned char)(zT_67 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_70 = s;
    zT_73 = src_fn.params;
    zT_74 = zT_73.items;
    zT_76 = src_fn.params;
    zT_77 = zT_76.len;
    zT_78 = 12;
    zT_79 = zig_wrap_mul_u(((zu64)(zT_77)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_mul_u(((zu64)(zT_77)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    zT_72 = zT_79;
    zF_C2661A7D_wBytes(zT_70, (unsigned char*)((unsigned char*)zT_74), zT_72);
    goto z_bb_2;
    z_bb_2:
    zT_84 = 0;
    bi = zT_84;
    goto z_bb_3;
    z_bb_3:
    zT_85 = src_fn.blocks;
    zT_86 = zT_85.len;
    if ((unsigned char)(bi < zT_86)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_89 = src_fn.blocks;
    zT_90 = zT_89.items;
    zT_91 = zT_90 + bi;
    bb = zT_91;
    zT_92 = s;
    zT_93 = bb->id;
    zF_FB050204_wU32(zT_92, zT_93);
    zT_95 = s;
    zT_96 = bb->is_terminated;
    zF_56013A33_wU8(zT_95, zT_96);
    zT_98 = s;
    zF_56013A33_wU8(zT_98, (unsigned char)(0));
    zT_101 = s;
    zF_56013A33_wU8(zT_101, (unsigned char)(0));
    zT_104 = s;
    zF_56013A33_wU8(zT_104, (unsigned char)(0));
    zT_107 = s;
    zT_109 = bb->insts;
    zT_110 = zT_109.len;
    zF_FB050204_wU32(zT_107, (unsigned int)((unsigned int)zT_110));
    zT_112 = bb->insts;
    zT_113 = zT_112.len;
    if ((unsigned char)(zT_113 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_134 = src_fn.hoisted_temps;
    zT_135 = zT_134.len;
    if ((unsigned char)(zT_135 > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_129 = 1;
    zT_130 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_129)), 32u);
    zT_131 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_129)), 32u);
    zT_133 = zT_131 == (unsigned int)(0);
    if (!(zT_133)) { pal_trap(); }
    bi = zT_130;
    goto z_bb_3;
    z_bb_7:
    zT_116 = s;
    zT_119 = bb->insts;
    zT_120 = zT_119.items;
    zT_122 = bb->insts;
    zT_123 = zT_122.len;
    zT_124 = 32;
    zT_125 = zig_wrap_mul_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_126 = zig_overflow_flag_mul_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_128 = zT_126 == (unsigned int)(0);
    if (!(zT_128)) { pal_trap(); }
    zT_118 = zT_125;
    zF_C2661A7D_wBytes(zT_116, (unsigned char*)((unsigned char*)zT_120), zT_118);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_138 = s;
    zT_141 = src_fn.hoisted_temps;
    zT_142 = zT_141.items;
    zT_144 = src_fn.hoisted_temps;
    zT_145 = zT_144.len;
    zT_146 = 8;
    zT_147 = zig_wrap_mul_u(((zu64)(zT_145)), ((zu64)(zT_146)), 32u);
    zT_148 = zig_overflow_flag_mul_u(((zu64)(zT_145)), ((zu64)(zT_146)), 32u);
    zT_150 = zT_148 == (unsigned int)(0);
    if (!(zT_150)) { pal_trap(); }
    zT_140 = zT_147;
    zF_C2661A7D_wBytes(zT_138, (unsigned char*)((unsigned char*)zT_142), zT_140);
    goto z_bb_10;
    z_bb_10:
    zT_151 = src_fn.switch_cases;
    zT_152 = zT_151.len;
    if ((unsigned char)(zT_152 > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_155 = s;
    zT_158 = src_fn.switch_cases;
    zT_159 = zT_158.items;
    zT_161 = src_fn.switch_cases;
    zT_162 = zT_161.len;
    zT_163 = 16;
    zT_164 = zig_wrap_mul_u(((zu64)(zT_162)), ((zu64)(zT_163)), 32u);
    zT_165 = zig_overflow_flag_mul_u(((zu64)(zT_162)), ((zu64)(zT_163)), 32u);
    zT_167 = zT_165 == (unsigned int)(0);
    if (!(zT_167)) { pal_trap(); }
    zT_157 = zT_164;
    zF_C2661A7D_wBytes(zT_155, (unsigned char*)((unsigned char*)zT_159), zT_157);
    goto z_bb_12;
    z_bb_12:
    zT_168 = src_fn.side_table;
    zT_169 = zT_168.len;
    if ((unsigned char)(zT_169 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_172 = s;
    zT_175 = src_fn.side_table;
    zT_176 = zT_175.items;
    zT_178 = src_fn.side_table;
    zT_179 = zT_178.len;
    zT_180 = 32;
    zT_181 = zig_wrap_mul_u(((zu64)(zT_179)), ((zu64)(zT_180)), 32u);
    zT_182 = zig_overflow_flag_mul_u(((zu64)(zT_179)), ((zu64)(zT_180)), 32u);
    zT_184 = zT_182 == (unsigned int)(0);
    if (!(zT_184)) { pal_trap(); }
    zT_174 = zT_181;
    zF_C2661A7D_wBytes(zT_172, (unsigned char*)((unsigned char*)zT_176), zT_174);
    goto z_bb_14;
    z_bb_14:
    zT_185 = src_fn.temp_variant_sub_field;
    zT_186 = zT_185.capacity;
    if ((unsigned char)(zT_186 > (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_190 = src_fn.temp_variant_sub_field;
    zT_191 = zT_190.capacity;
    cap = zT_191;
    zT_192 = s;
    zT_195 = src_fn.temp_variant_sub_field;
    zT_196 = zT_195.keys;
    zT_198 = 4;
    zT_199 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_198)), 32u);
    zT_200 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_198)), 32u);
    zT_202 = zT_200 == (unsigned int)(0);
    if (!(zT_202)) { pal_trap(); }
    zT_194 = zT_199;
    zF_C2661A7D_wBytes(zT_192, (unsigned char*)((unsigned char*)zT_196), zT_194);
    zT_203 = s;
    zT_206 = src_fn.temp_variant_sub_field;
    zT_207 = zT_206.values;
    zT_209 = 4;
    zT_210 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_209)), 32u);
    zT_211 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_209)), 32u);
    zT_213 = zT_211 == (unsigned int)(0);
    if (!(zT_213)) { pal_trap(); }
    zT_205 = zT_210;
    zF_C2661A7D_wBytes(zT_203, (unsigned char*)((unsigned char*)zT_207), zT_205);
    zT_214 = s;
    zT_217 = src_fn.temp_variant_sub_field;
    zT_218 = zT_217.occupied;
    zT_220 = 1;
    zT_221 = zig_wrap_mul_u(((zu64)(cap)), ((zu64)(zT_220)), 32u);
    zT_222 = zig_overflow_flag_mul_u(((zu64)(cap)), ((zu64)(zT_220)), 32u);
    zT_224 = zT_222 == (unsigned int)(0);
    if (!(zT_224)) { pal_trap(); }
    zT_216 = zT_221;
    zF_C2661A7D_wBytes(zT_214, (unsigned char*)((unsigned char*)zT_218), zT_216);
    goto z_bb_16;
    z_bb_16:
    zT_226 = s->write_offset;
    zT_227 = zig_wrap_sub_u(((zu64)(zT_226)), ((zu64)(start)), 32u);
    zT_228 = zig_overflow_flag_sub_u(((zu64)(zT_226)), ((zu64)(start)), 32u);
    zT_230 = zT_228 == (unsigned int)(0);
    if (!(zT_230)) { pal_trap(); }
    byte_len = zT_227;
    zT_232 = src_fn.module_id;
    zT_231.module_id = zT_232;
    zT_231.disk_offset = start;
    zT_231.byte_len = byte_len;
    return zT_231;
}

/* emptyLirFunction */
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand* dst) {
    zT_BBC23664_LirFunction zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_CFE23D0A_LirParamArrayList zT_6;
    zT_3E40CD83_Sand* zT_7;
    zT_1CF28CA3_BasicBlockArrayList zT_8;
    zT_3E40CD83_Sand* zT_9;
    zT_5D72FBF8_TempDeclArrayList zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_9F514E82_SwitchCaseArrayList zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_AC00B5F6_LirSideEntryArrayLi zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zT_2 = 0;
    zT_1.name_id = zT_2;
    zT_3 = 0;
    zT_1.module_id = zT_3;
    zT_4 = 0;
    zT_1.return_type = zT_4;
    zT_5 = dst;
    zT_6 = zF_0ED358C0_lirParamArrayListIn(zT_5);
    zT_1.params = zT_6;
    zT_7 = dst;
    zT_8 = zF_2B78727D_basicBlockArrayList(zT_7);
    zT_1.blocks = zT_8;
    zT_9 = dst;
    zT_10 = zF_DE63156A_tempDeclArrayListIn(zT_9);
    zT_1.hoisted_temps = zT_10;
    zT_11 = dst;
    zT_12 = zF_64707188_switchCaseArrayList(zT_11);
    zT_1.switch_cases = zT_12;
    zT_13 = dst;
    zT_14 = zF_4231AD2C_lirSideEntryArrayLi(zT_13);
    zT_1.side_table = zT_14;
    zT_15 = dst;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_1.temp_variant_sub_field = zT_16;
    zT_17 = 0;
    zT_1.is_extern = zT_17;
    zT_18 = 0;
    zT_1.is_pub = zT_18;
    zT_19 = 0;
    zT_1.is_variadic = zT_19;
    zT_20 = 0;
    zT_1.call_conv = zT_20;
    zT_21 = 0;
    zT_1.poison_uninit = zT_21;
    zT_22 = 0;
    zT_1.is_export = zT_22;
    return zT_1;
}

/* lirStreamReadFunction */
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream* s, zT_E7714190_LirSlot slot, zT_3E40CD83_Sand* dst) {
    zT_3E40CD83_Sand* zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_9;
    unsigned int zT_10;
    zT_7E7544E4_LirStream* zT_12;
    unsigned int zT_13;
    zT_7E7544E4_LirStream* zT_15;
    unsigned int zT_16;
    zT_7E7544E4_LirStream* zT_18;
    unsigned char zT_19;
    zT_7E7544E4_LirStream* zT_21;
    unsigned char zT_22;
    zT_7E7544E4_LirStream* zT_24;
    unsigned char zT_25;
    zT_7E7544E4_LirStream* zT_27;
    unsigned char zT_28;
    zT_7E7544E4_LirStream* zT_30;
    unsigned char zT_31;
    zT_7E7544E4_LirStream* zT_33;
    unsigned char zT_34;
    zT_7E7544E4_LirStream* zT_36;
    unsigned int zT_37;
    zT_7E7544E4_LirStream* zT_39;
    unsigned int zT_40;
    zT_7E7544E4_LirStream* zT_42;
    unsigned int zT_43;
    zT_7E7544E4_LirStream* zT_45;
    unsigned int zT_46;
    zT_7E7544E4_LirStream* zT_48;
    unsigned int zT_49;
    zT_7E7544E4_LirStream* zT_51;
    unsigned int zT_52;
    zT_7E7544E4_LirStream* zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned char zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned char zT_102;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned char zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    zT_3E40CD83_Sand* zT_115;
    zT_CFE23D0A_LirParamArrayList zT_116;
    zT_3E40CD83_Sand* zT_120;
    unsigned int zT_121;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    zT_FDFD82FD_EU_362 zT_130;
    unsigned char zT_131;
    unsigned char* zT_132;
    zT_7E7544E4_LirStream* zT_137;
    unsigned int zT_139;
    zT_8779209D_LirParam* zT_140;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned char zT_147;
    zT_3E40CD83_Sand* zT_149;
    zT_1CF28CA3_BasicBlockArrayList zT_150;
    zT_3E40CD83_Sand* zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned char zT_162;
    zT_FDFD82FD_EU_362 zT_164;
    unsigned char zT_165;
    unsigned char* zT_166;
    zT_88A68B1A_BasicBlock* zT_169;
    unsigned int zT_173;
    zT_7E7544E4_LirStream* zT_177;
    unsigned int zT_178;
    zT_7E7544E4_LirStream* zT_180;
    unsigned char zT_181;
    zT_7E7544E4_LirStream* zT_182;
    unsigned char zT_183;
    zT_7E7544E4_LirStream* zT_184;
    unsigned char zT_185;
    zT_7E7544E4_LirStream* zT_186;
    unsigned char zT_187;
    zT_7E7544E4_LirStream* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned char zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    zT_3E40CD83_Sand* zT_201;
    zT_DAE4631D_LirInstArrayList zT_202;
    zT_3E40CD83_Sand* zT_206;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    zT_FDFD82FD_EU_362 zT_216;
    unsigned char zT_217;
    unsigned char* zT_218;
    zT_7E7544E4_LirStream* zT_223;
    unsigned int zT_225;
    zT_6BA597BC_LirInst* zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned char zT_233;
    zT_88A68B1A_BasicBlock zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned char zT_239;
    zT_3E40CD83_Sand* zT_241;
    zT_5D72FBF8_TempDeclArrayList zT_242;
    zT_3E40CD83_Sand* zT_246;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned char zT_254;
    zT_FDFD82FD_EU_362 zT_256;
    unsigned char zT_257;
    unsigned char* zT_258;
    zT_7E7544E4_LirStream* zT_263;
    unsigned int zT_265;
    zT_1937645B_TempDecl* zT_266;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned char zT_273;
    zT_3E40CD83_Sand* zT_275;
    zT_9F514E82_SwitchCaseArrayList zT_276;
    zT_3E40CD83_Sand* zT_280;
    unsigned int zT_281;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned char zT_288;
    zT_FDFD82FD_EU_362 zT_290;
    unsigned char zT_291;
    unsigned char* zT_292;
    zT_7E7544E4_LirStream* zT_297;
    unsigned int zT_299;
    zT_4BD97095_SwitchCase* zT_300;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char zT_307;
    zT_3E40CD83_Sand* zT_309;
    zT_AC00B5F6_LirSideEntryArrayLi zT_310;
    zT_3E40CD83_Sand* zT_314;
    unsigned int zT_315;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned char zT_322;
    zT_FDFD82FD_EU_362 zT_324;
    unsigned char zT_325;
    unsigned char* zT_326;
    zT_7E7544E4_LirStream* zT_331;
    unsigned int zT_333;
    zT_A8A5B231_LirSideEntry* zT_334;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned char zT_341;
    zT_3E40CD83_Sand* zT_343;
    zT_21D3708C_U32ToU32Map zT_344;
    unsigned int zT_348;
    zT_3E40CD83_Sand* zT_350;
    unsigned int zT_351;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    unsigned char zT_357;
    zT_FDFD82FD_EU_362 zT_359;
    unsigned char zT_360;
    unsigned char* zT_361;
    zT_3E40CD83_Sand* zT_364;
    unsigned int zT_365;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_369;
    unsigned char zT_371;
    zT_FDFD82FD_EU_362 zT_373;
    unsigned char zT_374;
    unsigned char* zT_375;
    zT_3E40CD83_Sand* zT_378;
    unsigned int zT_379;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned char zT_385;
    zT_FDFD82FD_EU_362 zT_387;
    unsigned char zT_388;
    unsigned char* zT_389;
    zT_7E7544E4_LirStream* zT_395;
    unsigned int zT_397;
    unsigned int* zT_398;
    unsigned int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned char zT_404;
    zT_7E7544E4_LirStream* zT_405;
    unsigned int zT_407;
    unsigned int* zT_408;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned char zT_414;
    zT_7E7544E4_LirStream* zT_415;
    unsigned int zT_417;
    unsigned char* zT_418;
    unsigned int zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    unsigned char zT_424;
    unsigned int zT_425;
    unsigned char* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_430;
    unsigned char* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    int zT_438;
    zT_3E40CD83_Sand* zT_440;
    zT_BBC23664_LirFunction zT_441;
    zT_BBC23664_LirFunction zT_442;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_178, (unsigned int)sizeof zT_178);
    zig_poison_fill((void*)&zT_181, (unsigned int)sizeof zT_181);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    zig_poison_fill((void*)&zT_187, (unsigned int)sizeof zT_187);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_202, (unsigned int)sizeof zT_202);
    zig_poison_fill((void*)&zT_216, (unsigned int)sizeof zT_216);
    zig_poison_fill((void*)&zT_242, (unsigned int)sizeof zT_242);
    zig_poison_fill((void*)&zT_256, (unsigned int)sizeof zT_256);
    zig_poison_fill((void*)&zT_276, (unsigned int)sizeof zT_276);
    zig_poison_fill((void*)&zT_290, (unsigned int)sizeof zT_290);
    zig_poison_fill((void*)&zT_310, (unsigned int)sizeof zT_310);
    zig_poison_fill((void*)&zT_324, (unsigned int)sizeof zT_324);
    zig_poison_fill((void*)&zT_344, (unsigned int)sizeof zT_344);
    zig_poison_fill((void*)&zT_359, (unsigned int)sizeof zT_359);
    zig_poison_fill((void*)&zT_373, (unsigned int)sizeof zT_373);
    zig_poison_fill((void*)&zT_387, (unsigned int)sizeof zT_387);
    zig_poison_fill((void*)&zT_441, (unsigned int)sizeof zT_441);
    unsigned int name_id;
    unsigned int module_id;
    unsigned int return_type;
    unsigned char is_extern;
    unsigned char is_pub;
    unsigned char is_variadic;
    unsigned char call_conv;
    unsigned char poison_uninit;
    unsigned char is_export;
    unsigned int params_count;
    unsigned int blocks_count;
    unsigned int hoisted_temps_count;
    unsigned int switch_cases_count;
    unsigned int side_table_count;
    unsigned int tvsf_capacity;
    unsigned int tvsf_count;
    unsigned int expected_len;
    zT_CFE23D0A_LirParamArrayList params;
    unsigned char* raw;
    zT_1CF28CA3_BasicBlockArrayList blocks;
    unsigned char* braw;
    zT_5D72FBF8_TempDeclArrayList hoisted_temps;
    zT_88A68B1A_BasicBlock* bitems;
    unsigned int bi;
    unsigned int bb_id;
    unsigned char bb_term;
    unsigned int insts_count;
    zT_DAE4631D_LirInstArrayList binsts;
    unsigned char* iraw;
    zT_9F514E82_SwitchCaseArrayList switch_cases;
    zT_AC00B5F6_LirSideEntryArrayLi side_table;
    zT_21D3708C_U32ToU32Map tvsf;
    unsigned int cap;
    unsigned char* kraw;
    unsigned char* vraw;
    unsigned char* oraw;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = dst;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_4 = &s->spill;
    zT_5 = slot.disk_offset;
    zF_56A911A9_spillSeek(zT_4, zT_5);
    zT_9 = s;
    zT_10 = zF_3E695161_rU32(zT_9);
    name_id = zT_10;
    zT_12 = s;
    zT_13 = zF_3E695161_rU32(zT_12);
    module_id = zT_13;
    zT_15 = s;
    zT_16 = zF_3E695161_rU32(zT_15);
    return_type = zT_16;
    zT_18 = s;
    zT_19 = zF_747E1168_rU8(zT_18);
    is_extern = zT_19;
    zT_21 = s;
    zT_22 = zF_747E1168_rU8(zT_21);
    is_pub = zT_22;
    zT_24 = s;
    zT_25 = zF_747E1168_rU8(zT_24);
    is_variadic = zT_25;
    zT_27 = s;
    zT_28 = zF_747E1168_rU8(zT_27);
    call_conv = zT_28;
    zT_30 = s;
    zT_31 = zF_747E1168_rU8(zT_30);
    poison_uninit = zT_31;
    zT_33 = s;
    zT_34 = zF_747E1168_rU8(zT_33);
    is_export = zT_34;
    zT_36 = s;
    zT_37 = zF_3E695161_rU32(zT_36);
    params_count = zT_37;
    zT_39 = s;
    zT_40 = zF_3E695161_rU32(zT_39);
    blocks_count = zT_40;
    zT_42 = s;
    zT_43 = zF_3E695161_rU32(zT_42);
    hoisted_temps_count = zT_43;
    zT_45 = s;
    zT_46 = zF_3E695161_rU32(zT_45);
    switch_cases_count = zT_46;
    zT_48 = s;
    zT_49 = zF_3E695161_rU32(zT_48);
    side_table_count = zT_49;
    zT_51 = s;
    zT_52 = zF_3E695161_rU32(zT_51);
    tvsf_capacity = zT_52;
    zT_54 = s;
    zT_55 = zF_3E695161_rU32(zT_54);
    tvsf_count = zT_55;
    zT_57 = 46;
    expected_len = zT_57;
    zT_58 = 12;
    zT_59 = zig_wrap_mul_u(((zu64)(params_count)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_mul_u(((zu64)(params_count)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    zT_63 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_59)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_59)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    expected_len = zT_63;
    zT_67 = 12;
    zT_68 = zig_wrap_mul_u(((zu64)(blocks_count)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_mul_u(((zu64)(blocks_count)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    zT_72 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_68)), 32u);
    zT_73 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_68)), 32u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    expected_len = zT_72;
    zT_76 = 8;
    zT_77 = zig_wrap_mul_u(((zu64)(hoisted_temps_count)), ((zu64)(zT_76)), 32u);
    zT_78 = zig_overflow_flag_mul_u(((zu64)(hoisted_temps_count)), ((zu64)(zT_76)), 32u);
    zT_80 = zT_78 == (unsigned int)(0);
    if (!(zT_80)) { pal_trap(); }
    zT_81 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_77)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_77)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    expected_len = zT_81;
    zT_85 = 16;
    zT_86 = zig_wrap_mul_u(((zu64)(switch_cases_count)), ((zu64)(zT_85)), 32u);
    zT_87 = zig_overflow_flag_mul_u(((zu64)(switch_cases_count)), ((zu64)(zT_85)), 32u);
    zT_89 = zT_87 == (unsigned int)(0);
    if (!(zT_89)) { pal_trap(); }
    zT_90 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_86)), 32u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_86)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    expected_len = zT_90;
    zT_94 = 32;
    zT_95 = zig_wrap_mul_u(((zu64)(side_table_count)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_mul_u(((zu64)(side_table_count)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    zT_99 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_95)), 32u);
    zT_100 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_95)), 32u);
    zT_102 = zT_100 == (unsigned int)(0);
    if (!(zT_102)) { pal_trap(); }
    expected_len = zT_99;
    if ((unsigned char)(tvsf_capacity > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_105 = 9;
    zT_106 = zig_wrap_mul_u(((zu64)(tvsf_capacity)), ((zu64)(zT_105)), 32u);
    zT_107 = zig_overflow_flag_mul_u(((zu64)(tvsf_capacity)), ((zu64)(zT_105)), 32u);
    zT_109 = zT_107 == (unsigned int)(0);
    if (!(zT_109)) { pal_trap(); }
    zT_110 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_106)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_106)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    expected_len = zT_110;
    goto z_bb_2;
    z_bb_2:
    zT_115 = dst;
    zT_116 = zF_0ED358C0_lirParamArrayListIn(zT_115);
    params = zT_116;
    if ((unsigned char)(params_count > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_120 = dst;
    zT_123 = (unsigned int)params_count;
    zT_124 = 12;
    zT_125 = zig_wrap_mul_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_126 = zig_overflow_flag_mul_u(((zu64)(zT_123)), ((zu64)(zT_124)), 32u);
    zT_128 = zT_126 == (unsigned int)(0);
    if (!(zT_128)) { pal_trap(); }
    zT_121 = zT_125;
    zT_130 = zF_1395EB68_sandAlloc(zT_120, zT_121, (unsigned int)(4));
    zT_131 = zT_130.is_error;
    if (zT_131) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_149 = dst;
    zT_150 = zF_2B78727D_basicBlockArrayList(zT_149);
    blocks = zT_150;
    if ((unsigned char)(blocks_count > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_132 = zT_130.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_132;
    params.items = (zT_8779209D_LirParam*)((zT_8779209D_LirParam*)raw);
    params.len = (unsigned int)((unsigned int)params_count);
    params.capacity = (unsigned int)((unsigned int)params_count);
    zT_137 = s;
    zT_140 = params.items;
    zT_142 = (unsigned int)params_count;
    zT_143 = 12;
    zT_144 = zig_wrap_mul_u(((zu64)(zT_142)), ((zu64)(zT_143)), 32u);
    zT_145 = zig_overflow_flag_mul_u(((zu64)(zT_142)), ((zu64)(zT_143)), 32u);
    zT_147 = zT_145 == (unsigned int)(0);
    if (!(zT_147)) { pal_trap(); }
    zT_139 = zT_144;
    zF_CF6758F4_rBytes(zT_137, (unsigned char*)((unsigned char*)zT_140), zT_139);
    goto z_bb_4;
    z_bb_8:
    zT_154 = dst;
    zT_157 = (unsigned int)blocks_count;
    zT_158 = 24;
    zT_159 = zig_wrap_mul_u(((zu64)(zT_157)), ((zu64)(zT_158)), 32u);
    zT_160 = zig_overflow_flag_mul_u(((zu64)(zT_157)), ((zu64)(zT_158)), 32u);
    zT_162 = zT_160 == (unsigned int)(0);
    if (!(zT_162)) { pal_trap(); }
    zT_155 = zT_159;
    zT_164 = zF_1395EB68_sandAlloc(zT_154, zT_155, (unsigned int)(4));
    zT_165 = zT_164.is_error;
    if (zT_165) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_241 = dst;
    zT_242 = zF_DE63156A_tempDeclArrayListIn(zT_241);
    hoisted_temps = zT_242;
    if ((unsigned char)(hoisted_temps_count > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_166 = zT_164.data.payload;
    goto z_bb_12;
    z_bb_12:
    braw = zT_166;
    zT_169 = (zT_88A68B1A_BasicBlock*)braw;
    bitems = zT_169;
    blocks.items = bitems;
    blocks.len = (unsigned int)((unsigned int)blocks_count);
    blocks.capacity = (unsigned int)((unsigned int)blocks_count);
    zT_173 = 0;
    bi = zT_173;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)blocks_count))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_177 = s;
    zT_178 = zF_3E695161_rU32(zT_177);
    bb_id = zT_178;
    zT_180 = s;
    zT_181 = zF_747E1168_rU8(zT_180);
    bb_term = zT_181;
    zT_182 = s;
    zT_183 = zF_747E1168_rU8(zT_182);
    (void)zT_183;
    zT_184 = s;
    zT_185 = zF_747E1168_rU8(zT_184);
    (void)zT_185;
    zT_186 = s;
    zT_187 = zF_747E1168_rU8(zT_186);
    (void)zT_187;
    zT_189 = s;
    zT_190 = zF_3E695161_rU32(zT_189);
    insts_count = zT_190;
    zT_191 = 32;
    zT_192 = zig_wrap_mul_u(((zu64)(insts_count)), ((zu64)(zT_191)), 32u);
    zT_193 = zig_overflow_flag_mul_u(((zu64)(insts_count)), ((zu64)(zT_191)), 32u);
    zT_195 = zT_193 == (unsigned int)(0);
    if (!(zT_195)) { pal_trap(); }
    zT_196 = zig_wrap_add_u(((zu64)(expected_len)), ((zu64)(zT_192)), 32u);
    zT_197 = zig_overflow_flag_add_u(((zu64)(expected_len)), ((zu64)(zT_192)), 32u);
    zT_199 = zT_197 == (unsigned int)(0);
    if (!(zT_199)) { pal_trap(); }
    expected_len = zT_196;
    zT_201 = dst;
    zT_202 = zF_C6E3B5BB_lirInstArrayListIni(zT_201);
    binsts = zT_202;
    if ((unsigned char)(insts_count > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_235 = 1;
    zT_236 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_235)), 32u);
    zT_237 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_235)), 32u);
    zT_239 = zT_237 == (unsigned int)(0);
    if (!(zT_239)) { pal_trap(); }
    bi = zT_236;
    goto z_bb_13;
    z_bb_17:
    zT_206 = dst;
    zT_209 = (unsigned int)insts_count;
    zT_210 = 32;
    zT_211 = zig_wrap_mul_u(((zu64)(zT_209)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_mul_u(((zu64)(zT_209)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    zT_207 = zT_211;
    zT_216 = zF_1395EB68_sandAlloc(zT_206, zT_207, (unsigned int)(4));
    zT_217 = zT_216.is_error;
    if (zT_217) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_234.id = bb_id;
    zT_234.insts = binsts;
    zT_234.is_terminated = bb_term;
    bitems[bi] = zT_234;
    goto z_bb_16;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_218 = zT_216.data.payload;
    goto z_bb_21;
    z_bb_21:
    iraw = zT_218;
    binsts.items = (zT_6BA597BC_LirInst*)((zT_6BA597BC_LirInst*)iraw);
    binsts.len = (unsigned int)((unsigned int)insts_count);
    binsts.capacity = (unsigned int)((unsigned int)insts_count);
    zT_223 = s;
    zT_226 = binsts.items;
    zT_228 = (unsigned int)insts_count;
    zT_229 = 32;
    zT_230 = zig_wrap_mul_u(((zu64)(zT_228)), ((zu64)(zT_229)), 32u);
    zT_231 = zig_overflow_flag_mul_u(((zu64)(zT_228)), ((zu64)(zT_229)), 32u);
    zT_233 = zT_231 == (unsigned int)(0);
    if (!(zT_233)) { pal_trap(); }
    zT_225 = zT_230;
    zF_CF6758F4_rBytes(zT_223, (unsigned char*)((unsigned char*)zT_226), zT_225);
    goto z_bb_18;
    z_bb_22:
    zT_246 = dst;
    zT_249 = (unsigned int)hoisted_temps_count;
    zT_250 = 8;
    zT_251 = zig_wrap_mul_u(((zu64)(zT_249)), ((zu64)(zT_250)), 32u);
    zT_252 = zig_overflow_flag_mul_u(((zu64)(zT_249)), ((zu64)(zT_250)), 32u);
    zT_254 = zT_252 == (unsigned int)(0);
    if (!(zT_254)) { pal_trap(); }
    zT_247 = zT_251;
    zT_256 = zF_1395EB68_sandAlloc(zT_246, zT_247, (unsigned int)(4));
    zT_257 = zT_256.is_error;
    if (zT_257) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_275 = dst;
    zT_276 = zF_64707188_switchCaseArrayList(zT_275);
    switch_cases = zT_276;
    if ((unsigned char)(switch_cases_count > (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    pal_trap();
    z_bb_25:
    zT_258 = zT_256.data.payload;
    goto z_bb_26;
    z_bb_26:
    raw = zT_258;
    hoisted_temps.items = (zT_1937645B_TempDecl*)((zT_1937645B_TempDecl*)raw);
    hoisted_temps.len = (unsigned int)((unsigned int)hoisted_temps_count);
    hoisted_temps.capacity = (unsigned int)((unsigned int)hoisted_temps_count);
    zT_263 = s;
    zT_266 = hoisted_temps.items;
    zT_268 = (unsigned int)hoisted_temps_count;
    zT_269 = 8;
    zT_270 = zig_wrap_mul_u(((zu64)(zT_268)), ((zu64)(zT_269)), 32u);
    zT_271 = zig_overflow_flag_mul_u(((zu64)(zT_268)), ((zu64)(zT_269)), 32u);
    zT_273 = zT_271 == (unsigned int)(0);
    if (!(zT_273)) { pal_trap(); }
    zT_265 = zT_270;
    zF_CF6758F4_rBytes(zT_263, (unsigned char*)((unsigned char*)zT_266), zT_265);
    goto z_bb_23;
    z_bb_27:
    zT_280 = dst;
    zT_283 = (unsigned int)switch_cases_count;
    zT_284 = 16;
    zT_285 = zig_wrap_mul_u(((zu64)(zT_283)), ((zu64)(zT_284)), 32u);
    zT_286 = zig_overflow_flag_mul_u(((zu64)(zT_283)), ((zu64)(zT_284)), 32u);
    zT_288 = zT_286 == (unsigned int)(0);
    if (!(zT_288)) { pal_trap(); }
    zT_281 = zT_285;
    zT_290 = zF_1395EB68_sandAlloc(zT_280, zT_281, (unsigned int)(4));
    zT_291 = zT_290.is_error;
    if (zT_291) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_309 = dst;
    zT_310 = zF_4231AD2C_lirSideEntryArrayLi(zT_309);
    side_table = zT_310;
    if ((unsigned char)(side_table_count > (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    pal_trap();
    z_bb_30:
    zT_292 = zT_290.data.payload;
    goto z_bb_31;
    z_bb_31:
    raw = zT_292;
    switch_cases.items = (zT_4BD97095_SwitchCase*)((zT_4BD97095_SwitchCase*)raw);
    switch_cases.len = (unsigned int)((unsigned int)switch_cases_count);
    switch_cases.capacity = (unsigned int)((unsigned int)switch_cases_count);
    zT_297 = s;
    zT_300 = switch_cases.items;
    zT_302 = (unsigned int)switch_cases_count;
    zT_303 = 16;
    zT_304 = zig_wrap_mul_u(((zu64)(zT_302)), ((zu64)(zT_303)), 32u);
    zT_305 = zig_overflow_flag_mul_u(((zu64)(zT_302)), ((zu64)(zT_303)), 32u);
    zT_307 = zT_305 == (unsigned int)(0);
    if (!(zT_307)) { pal_trap(); }
    zT_299 = zT_304;
    zF_CF6758F4_rBytes(zT_297, (unsigned char*)((unsigned char*)zT_300), zT_299);
    goto z_bb_28;
    z_bb_32:
    zT_314 = dst;
    zT_317 = (unsigned int)side_table_count;
    zT_318 = 32;
    zT_319 = zig_wrap_mul_u(((zu64)(zT_317)), ((zu64)(zT_318)), 32u);
    zT_320 = zig_overflow_flag_mul_u(((zu64)(zT_317)), ((zu64)(zT_318)), 32u);
    zT_322 = zT_320 == (unsigned int)(0);
    if (!(zT_322)) { pal_trap(); }
    zT_315 = zT_319;
    zT_324 = zF_1395EB68_sandAlloc(zT_314, zT_315, (unsigned int)(4));
    zT_325 = zT_324.is_error;
    if (zT_325) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_343 = dst;
    zT_344 = zF_58BDA2DE_u32ToU32MapInit(zT_343);
    tvsf = zT_344;
    if ((unsigned char)(tvsf_capacity > (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    pal_trap();
    z_bb_35:
    zT_326 = zT_324.data.payload;
    goto z_bb_36;
    z_bb_36:
    raw = zT_326;
    side_table.items = (zT_A8A5B231_LirSideEntry*)((zT_A8A5B231_LirSideEntry*)raw);
    side_table.len = (unsigned int)((unsigned int)side_table_count);
    side_table.capacity = (unsigned int)((unsigned int)side_table_count);
    zT_331 = s;
    zT_334 = side_table.items;
    zT_336 = (unsigned int)side_table_count;
    zT_337 = 32;
    zT_338 = zig_wrap_mul_u(((zu64)(zT_336)), ((zu64)(zT_337)), 32u);
    zT_339 = zig_overflow_flag_mul_u(((zu64)(zT_336)), ((zu64)(zT_337)), 32u);
    zT_341 = zT_339 == (unsigned int)(0);
    if (!(zT_341)) { pal_trap(); }
    zT_333 = zT_338;
    zF_CF6758F4_rBytes(zT_331, (unsigned char*)((unsigned char*)zT_334), zT_333);
    goto z_bb_33;
    z_bb_37:
    zT_348 = (unsigned int)tvsf_capacity;
    cap = zT_348;
    zT_350 = dst;
    zT_353 = 4;
    zT_354 = zig_wrap_mul_u(((zu64)(zT_353)), ((zu64)(cap)), 32u);
    zT_355 = zig_overflow_flag_mul_u(((zu64)(zT_353)), ((zu64)(cap)), 32u);
    zT_357 = zT_355 == (unsigned int)(0);
    if (!(zT_357)) { pal_trap(); }
    zT_351 = zT_354;
    zT_359 = zF_1395EB68_sandAlloc(zT_350, zT_351, (unsigned int)(4));
    zT_360 = zT_359.is_error;
    if (zT_360) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_425 = slot.byte_len;
    if ((unsigned char)(expected_len != zT_425)) goto z_bb_48; else goto z_bb_49;
    z_bb_39:
    pal_trap();
    z_bb_40:
    zT_361 = zT_359.data.payload;
    goto z_bb_41;
    z_bb_41:
    kraw = zT_361;
    zT_364 = dst;
    zT_367 = 4;
    zT_368 = zig_wrap_mul_u(((zu64)(zT_367)), ((zu64)(cap)), 32u);
    zT_369 = zig_overflow_flag_mul_u(((zu64)(zT_367)), ((zu64)(cap)), 32u);
    zT_371 = zT_369 == (unsigned int)(0);
    if (!(zT_371)) { pal_trap(); }
    zT_365 = zT_368;
    zT_373 = zF_1395EB68_sandAlloc(zT_364, zT_365, (unsigned int)(4));
    zT_374 = zT_373.is_error;
    if (zT_374) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    pal_trap();
    z_bb_43:
    zT_375 = zT_373.data.payload;
    goto z_bb_44;
    z_bb_44:
    vraw = zT_375;
    zT_378 = dst;
    zT_381 = 1;
    zT_382 = zig_wrap_mul_u(((zu64)(zT_381)), ((zu64)(cap)), 32u);
    zT_383 = zig_overflow_flag_mul_u(((zu64)(zT_381)), ((zu64)(cap)), 32u);
    zT_385 = zT_383 == (unsigned int)(0);
    if (!(zT_385)) { pal_trap(); }
    zT_379 = zT_382;
    zT_387 = zF_1395EB68_sandAlloc(zT_378, zT_379, (unsigned int)(4));
    zT_388 = zT_387.is_error;
    if (zT_388) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    pal_trap();
    z_bb_46:
    zT_389 = zT_387.data.payload;
    goto z_bb_47;
    z_bb_47:
    oraw = zT_389;
    tvsf.keys = (unsigned int*)((unsigned int*)kraw);
    tvsf.values = (unsigned int*)((unsigned int*)vraw);
    tvsf.occupied = (unsigned char*)((unsigned char*)oraw);
    tvsf.capacity = cap;
    tvsf.count = (unsigned int)((unsigned int)tvsf_count);
    zT_395 = s;
    zT_398 = tvsf.keys;
    zT_400 = 4;
    zT_401 = zig_wrap_mul_u(((zu64)(zT_400)), ((zu64)(cap)), 32u);
    zT_402 = zig_overflow_flag_mul_u(((zu64)(zT_400)), ((zu64)(cap)), 32u);
    zT_404 = zT_402 == (unsigned int)(0);
    if (!(zT_404)) { pal_trap(); }
    zT_397 = zT_401;
    zF_CF6758F4_rBytes(zT_395, (unsigned char*)((unsigned char*)zT_398), zT_397);
    zT_405 = s;
    zT_408 = tvsf.values;
    zT_410 = 4;
    zT_411 = zig_wrap_mul_u(((zu64)(zT_410)), ((zu64)(cap)), 32u);
    zT_412 = zig_overflow_flag_mul_u(((zu64)(zT_410)), ((zu64)(cap)), 32u);
    zT_414 = zT_412 == (unsigned int)(0);
    if (!(zT_414)) { pal_trap(); }
    zT_407 = zT_411;
    zF_CF6758F4_rBytes(zT_405, (unsigned char*)((unsigned char*)zT_408), zT_407);
    zT_415 = s;
    zT_418 = tvsf.occupied;
    zT_420 = 1;
    zT_421 = zig_wrap_mul_u(((zu64)(zT_420)), ((zu64)(cap)), 32u);
    zT_422 = zig_overflow_flag_mul_u(((zu64)(zT_420)), ((zu64)(cap)), 32u);
    zT_424 = zT_422 == (unsigned int)(0);
    if (!(zT_424)) { pal_trap(); }
    zT_417 = zT_421;
    zF_CF6758F4_rBytes(zT_415, (unsigned char*)((unsigned char*)zT_418), zT_417);
    goto z_bb_38;
    z_bb_48:
    zT_428 = "S-LIR byte_len mismatch on fault-in read";
    zT_430 = 40;
    zT_429.ptr = (unsigned char*)zT_428;
    zT_429.len = zT_430;
    emsg = zT_429;
    zT_432 = "lir_stream.zig";
    zT_434 = 14;
    zT_433.ptr = (unsigned char*)zT_432;
    zT_433.len = zT_434;
    ef = zT_433;
    zT_435 = emsg;
    zT_436 = ef;
    zT_438 = 306;
    zF_6D97D338_panicHandler(zT_435, zT_436, (unsigned int)((unsigned int)zT_438));
    zT_440 = dst;
    zT_441 = zF_FAE9AF21_emptyLirFunction(zT_440);
    return zT_441;
    z_bb_49:
    zT_442.name_id = name_id;
    zT_442.module_id = module_id;
    zT_442.return_type = return_type;
    zT_442.params = params;
    zT_442.blocks = blocks;
    zT_442.hoisted_temps = hoisted_temps;
    zT_442.switch_cases = switch_cases;
    zT_442.side_table = side_table;
    zT_442.temp_variant_sub_field = tvsf;
    zT_442.is_extern = is_extern;
    zT_442.is_pub = is_pub;
    zT_442.is_variadic = is_variadic;
    zT_442.call_conv = call_conv;
    zT_442.poison_uninit = poison_uninit;
    zT_442.is_export = is_export;
    return zT_442;
}

/* __module_init */
void zF_780653D2___module_init_11(void) {
    zT_3E40CD83_Sand zT_0;
    zT_BBC23664_LirFunction zT_1;
    zT_E7714190_LirSlot zT_2;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_E7714190_LirSlot = zT_2;
    return;
}

/* EOF */
