#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, zT_05D09430_Opt_436 scope, unsigned int source_file_id) {
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_F85C5DED_DiagnosticCollector* zT_11;
    zT_662E24C2_Opt_250 zT_12;
    zT_13D0AA3A_Opt_438 zT_13;
    zT_ABC1EBBE_TypeResolveEnv* zT_14;
    unsigned int zT_15;
    unsigned int zT_19;
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_7 = ct->store;
    zT_6.store = zT_7;
    zT_8 = ct->typereg;
    zT_6.typereg = zT_8;
    zT_9 = ct->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = ct->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = module_id;
    zT_6.source_file_id = source_file_id;
    zT_11 = ct->diag;
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    zT_6.diag = zT_12;
    zT_6.local_consts = scope;
    zT_13.has_value = 0;
    zT_6.local_types = zT_13;
    env = zT_6;
    zT_14 = (zT_ABC1EBBE_TypeResolveEnv*)&env;
    zT_15 = node_idx;
    zT_19 = zF_F2107C15_resolveTypeExprFull(zT_14, zT_15, (unsigned int)(0));
    return zT_19;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    zT_3C598AEF_SymbolKind zT_25;
    unsigned char zT_29;
    zT_3C598AEF_SymbolKind zT_30;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    if ((unsigned char)(ti < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(ti)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(ti)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    if ((unsigned char)(si < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    zT_22 = sym.type_id;
    if ((unsigned char)(zT_22 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_40 = 1;
    zT_41 = (unsigned int)zT_40;
    zT_42 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_41)), 32u);
    zT_43 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_41)), 32u);
    zT_45 = zT_43 == (unsigned int)(0);
    if (!(zT_45)) { pal_trap(); }
    si = zT_42;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    if ((unsigned char)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_30 = sym.kind;
    zT_29 = zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_34 = 1;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zig_wrap_add_u(((zu64)(cnt)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_add_u(((zu64)(cnt)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    cnt = zT_36;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned char zT_16;
    zT_072B53A6_ModuleRegistry* zT_18;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_20;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6E8D187B_ModuleEntry* zT_30;
    unsigned int zT_31;
    unsigned char zT_32;
    zT_6E8D187B_ModuleEntry zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    zT_6E8D187B_ModuleEntry* zT_48;
    unsigned int zT_49;
    unsigned char zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_3E40CD83_Sand* zT_54;
    zT_8EED1867_ResolvedTypeTable* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_66E7D2EF_CoercionTable* zT_62;
    zT_21D3708C_U32ToU32Map* zT_63;
    zT_21D3708C_U32ToU32Map* zT_64;
    zT_21D3708C_U32ToU32Map* zT_65;
    zT_D3EB6303_StringInterner* zT_66;
    zT_21D3708C_U32ToU32Map* zT_67;
    zT_21D3708C_U32ToU32Map* zT_68;
    zT_072B53A6_ModuleRegistry* zT_69;
    zT_A4CE86B7_U64ToU32Map* zT_70;
    zT_6E8D187B_ModuleEntry* zT_77;
    unsigned int zT_78;
    unsigned char zT_79;
    zT_6E8D187B_ModuleEntry zT_80;
    zT_38C12417_SemanticAnalyzer zT_91;
    int zT_93;
    unsigned int zT_94;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_22A7C88B_AstNode zT_108;
    zT_8143F551_AstKind zT_109;
    unsigned int zT_113;
    zT_6DCFC8DB_FrontResCtx* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_05D09430_Opt_436 zT_120;
    unsigned int zT_121;
    zT_6E8D187B_ModuleEntry* zT_122;
    unsigned int zT_123;
    unsigned char zT_124;
    zT_6E8D187B_ModuleEntry zT_125;
    zT_05D09430_Opt_436 zT_128;
    unsigned int zT_129;
    zT_8EED1867_ResolvedTypeTable* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    zT_8EED1867_ResolvedTypeTable* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_22A7C88B_AstNode zT_149;
    zT_8143F551_AstKind zT_150;
    unsigned char zT_154;
    zT_8143F551_AstKind zT_155;
    zT_38C12417_SemanticAnalyzer* zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    zT_8143F551_AstKind zT_164;
    zT_6E8D187B_ModuleEntry* zT_171;
    unsigned int zT_172;
    unsigned char zT_173;
    zT_6E8D187B_ModuleEntry zT_174;
    unsigned int zT_175;
    zT_79FAE712_u64 zT_176;
    zT_79FAE712_u64 zT_177;
    zT_79FAE712_u64 zT_178;
    unsigned int zT_179;
    unsigned char zT_181;
    zT_6B0A7D14_AstStore* zT_182;
    unsigned int zT_183;
    unsigned int zT_185;
    zT_79FAE712_u64 zT_186;
    zT_79FAE712_u64 zT_187;
    unsigned int zT_188;
    unsigned char zT_190;
    zT_338B7C76_TypeRegistry* zT_191;
    zT_79FAE712_u64 zT_192;
    unsigned int zT_193;
    zT_6B0A7D14_AstStore* zT_196;
    unsigned int zT_197;
    unsigned int zT_200;
    zT_3D7259E2_SymbolRegistry* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_6E8D187B_ModuleEntry* zT_206;
    unsigned int zT_207;
    unsigned char zT_208;
    zT_6E8D187B_ModuleEntry zT_209;
    zT_EAF7A2A2_Opt_953 zT_211;
    unsigned char zT_212;
    zT_3C598AEF_SymbolKind zT_214;
    zT_3D7259E2_SymbolRegistry* zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    zT_6E8D187B_ModuleEntry* zT_223;
    unsigned int zT_224;
    unsigned char zT_225;
    zT_6E8D187B_ModuleEntry zT_226;
    zT_6B0A7D14_AstStore* zT_228;
    unsigned int zT_229;
    unsigned int zT_231;
    zT_EAF7A2A2_Opt_953 zT_232;
    unsigned char zT_233;
    zT_3C598AEF_SymbolKind zT_235;
    unsigned char zT_241;
    zT_8EED1867_ResolvedTypeTable* zT_243;
    unsigned int zT_244;
    zT_BAEE192E_Opt_10 zT_246;
    unsigned char zT_249;
    unsigned char zT_252;
    unsigned int zT_255;
    unsigned char zT_259;
    unsigned char zT_260;
    unsigned char zT_263;
    zT_8EED1867_ResolvedTypeTable* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned char zT_270;
    zT_8EED1867_ResolvedTypeTable* zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned char zT_278;
    unsigned int zT_279;
    zT_8EED1867_ResolvedTypeTable* zT_283;
    unsigned int zT_284;
    zT_BAEE192E_Opt_10 zT_287;
    unsigned char zT_288;
    zT_8EED1867_ResolvedTypeTable* zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned char zT_299;
    unsigned char zT_302;
    unsigned char zT_305;
    zT_6B0A7D14_AstStore* zT_309;
    unsigned int zT_310;
    unsigned int zT_312;
    zT_3D7259E2_SymbolRegistry* zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    zT_6E8D187B_ModuleEntry* zT_318;
    unsigned int zT_319;
    unsigned char zT_320;
    zT_6E8D187B_ModuleEntry zT_321;
    zT_EAF7A2A2_Opt_953 zT_323;
    unsigned char zT_324;
    unsigned int zT_326;
    unsigned int zT_329;
    unsigned char zT_331;
    unsigned int zT_332;
    unsigned char zT_335;
    int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned char zT_341;
    int zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned char zT_347;
    int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned char zT_355;
    zT_3E40CD83_Sand* zT_356;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_128, (unsigned int)sizeof zT_128);
    zig_poison_fill((void*)&zT_129, (unsigned int)sizeof zT_129);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_163, (unsigned int)sizeof zT_163);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zig_poison_fill((void*)&zT_211, (unsigned int)sizeof zT_211);
    zig_poison_fill((void*)&zT_231, (unsigned int)sizeof zT_231);
    zig_poison_fill((void*)&zT_232, (unsigned int)sizeof zT_232);
    zig_poison_fill((void*)&zT_246, (unsigned int)sizeof zT_246);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    unsigned int ref_name;
    zT_EAF7A2A2_Opt_953 ref_sym;
    zT_3A105EF1_Symbol* rs;
    zT_EAF7A2A2_Opt_953 own_sym;
    zT_3A105EF1_Symbol* os;
    unsigned char need_set;
    unsigned int vex;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_EAF7A2A2_Opt_953 sym;
    zT_3A105EF1_Symbol* s;
    zT_1 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_6 = 1;
    zT_7 = zig_wrap_add_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_add_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    bound = zT_7;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    iter = zT_13;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < bound)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    changed = zT_16;
    zT_18 = ct->module_reg;
    zT_20 = zF_3452C137_moduleRegistryGetMo(zT_18);
    mods = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    mi = zT_23;
    goto z_bb_5;
    z_bb_3:
    zT_356 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_356);
    return;
    z_bb_4:
    zT_350 = 1;
    zT_351 = (unsigned int)zT_350;
    zT_352 = zig_wrap_add_u(((zu64)(iter)), ((zu64)(zT_351)), 32u);
    zT_353 = zig_overflow_flag_add_u(((zu64)(iter)), ((zu64)(zT_351)), 32u);
    zT_355 = zT_353 == (unsigned int)(0);
    if (!(zT_355)) { pal_trap(); }
    iter = zT_352;
    goto z_bb_1;
    z_bb_5:
    zT_25 = mods.len;
    if ((unsigned char)(mi < zT_25)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_27);
    zT_30 = mods.ptr;
    zT_31 = mods.len;
    zT_32 = mi < zT_31;
    if (!(zT_32)) { pal_trap(); }
    zT_33 = zT_30[mi];
    zT_34 = zT_33.ast_root;
    ast_root = zT_34;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_8:
    zT_342 = 1;
    zT_343 = (unsigned int)zT_342;
    zT_344 = zig_wrap_add_u(((zu64)(mi)), ((zu64)(zT_343)), 32u);
    zT_345 = zig_overflow_flag_add_u(((zu64)(mi)), ((zu64)(zT_343)), 32u);
    zT_347 = zT_345 == (unsigned int)(0);
    if (!(zT_347)) { pal_trap(); }
    mi = zT_344;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_38 = ct->store;
    zT_39 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    zT_43 = ct->store;
    zT_44 = ast_root;
    zT_46 = zF_152E19CB_astStoreNodeExtraCh(zT_43, zT_44);
    decls_n = zT_46;
    zT_48 = mods.ptr;
    zT_49 = mods.len;
    zT_50 = mi < zT_49;
    if (!(zT_50)) { pal_trap(); }
    zT_51 = zT_48[mi];
    zT_52 = zT_51.source_file_id;
    src_fid = zT_52;
    zT_54 = ct->scratch;
    zT_55 = ct->resolved_types;
    zT_56 = ct->diag;
    zT_57 = ct->typereg;
    zT_58 = ct->symbol_reg;
    zT_59 = ct->store;
    zT_77 = mods.ptr;
    zT_78 = mods.len;
    zT_79 = mi < zT_78;
    if (!(zT_79)) { pal_trap(); }
    zT_80 = zT_77[mi];
    zT_60 = zT_80.id;
    zT_61 = src_fid;
    zT_62 = ct->coercion_table;
    zT_63 = ct->enum_value_table;
    zT_64 = ct->tuple_index_table;
    zT_65 = ct->error_code_registry;
    zT_66 = ct->interner;
    zT_67 = ct->call_arg_types;
    zT_68 = ct->call_param_map;
    zT_69 = ct->module_reg;
    zT_70 = ct->suspending_fns;
    zT_91 = zF_84ADA681_semanticAnalyzerIni(zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67, zT_68, zT_69, zT_70);
    sa = zT_91;
    zT_93 = 0;
    zT_94 = (unsigned int)zT_93;
    di = zT_94;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_98 = ct->store;
    zT_99 = ast_root;
    zT_103 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)di));
    decl_idx = zT_103;
    zT_105 = ct->store;
    zT_106 = decl_idx;
    zT_108 = zF_FCDD1D35_astStoreNodeAt(zT_105, zT_106);
    decl = zT_108;
    zT_109 = decl.kind;
    if ((unsigned char)(zT_109 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_336 = 1;
    zT_337 = (unsigned int)zT_336;
    zT_338 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_337)), 32u);
    zT_339 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_337)), 32u);
    zT_341 = zT_339 == (unsigned int)(0);
    if (!(zT_341)) { pal_trap(); }
    di = zT_338;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_113 = decl.child_0;
    if ((unsigned char)(zT_113 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_117 = ct;
    zT_122 = mods.ptr;
    zT_123 = mods.len;
    zT_124 = mi < zT_123;
    if (!(zT_124)) { pal_trap(); }
    zT_125 = zT_122[mi];
    zT_118 = zT_125.id;
    zT_119 = decl.child_0;
    zT_128.has_value = 0;
    zT_120 = zT_128;
    zT_121 = src_fid;
    zT_129 = zF_EE3AA0D0_resolveTypeExpr(zT_117, zT_118, zT_119, zT_120, zT_121);
    rtype = zT_129;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_141 = decl.child_1;
    if ((unsigned char)(zT_141 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_132 = ct->resolved_types;
    zT_133 = decl.child_0;
    zT_134 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_132, zT_133, zT_134);
    zT_137 = ct->resolved_types;
    zT_138 = decl_idx;
    zT_139 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_137, zT_138, zT_139);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_145 = ct->store;
    zT_146 = decl.child_1;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    init = zT_149;
    zT_150 = init.kind;
    if ((unsigned char)(zT_150 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_155 = init.kind;
    zT_154 = zT_155 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_25;
    z_bb_24:
    zT_154 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_154) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_160 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_161 = decl_idx;
    zT_163 = zF_CC4377FA_semanticAnalyzerRes(zT_160, zT_161);
    init_type = zT_163;
    zT_164 = init.kind;
    if ((unsigned char)(zT_164 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    if ((unsigned char)(init_type != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_243 = ct->resolved_types;
    zT_244 = decl_idx;
    zT_246 = zF_999DCF51_resolvedTypeTableGe(zT_243, zT_244);
    vd_existing = zT_246;
    if ((unsigned char)(init_type != (unsigned int)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_30:
    zT_171 = mods.ptr;
    zT_172 = mods.len;
    zT_173 = mi < zT_172;
    if (!(zT_173)) { pal_trap(); }
    zT_174 = zT_171[mi];
    zT_175 = zT_174.id;
    zT_176 = (zT_79FAE712_u64)zT_175;
    zT_177 = Z98_U64_C(4294967296);
    zT_178 = zig_wrap_mul_u(((zu64)(zT_176)), ((zu64)(zT_177)), 64u);
    zT_179 = zig_overflow_flag_mul_u(((zu64)(zT_176)), ((zu64)(zT_177)), 64u);
    zT_181 = zT_179 == (unsigned int)(0);
    if (!(zT_181)) { pal_trap(); }
    zT_182 = ct->store;
    zT_183 = decl_idx;
    zT_185 = zF_8BA26B9E_astStoreNodePayload(zT_182, zT_183);
    zT_186 = (zT_79FAE712_u64)zT_185;
    zT_187 = zig_wrap_add_u(((zu64)(zT_178)), ((zu64)(zT_186)), 64u);
    zT_188 = zig_overflow_flag_add_u(((zu64)(zT_178)), ((zu64)(zT_186)), 64u);
    zT_190 = zT_188 == (unsigned int)(0);
    if (!(zT_190)) { pal_trap(); }
    ck = zT_187;
    zT_191 = ct->typereg;
    zT_192 = ck;
    zT_193 = init_type;
    zF_5E95558D_nameCachePut(zT_191, zT_192, zT_193);
    goto z_bb_31;
    z_bb_31:
    zT_196 = ct->store;
    zT_197 = decl.child_1;
    zT_200 = zF_53458827_astStoreIdentifier(zT_196, zT_197);
    ref_name = zT_200;
    zT_202 = ct->symbol_reg;
    zT_206 = mods.ptr;
    zT_207 = mods.len;
    zT_208 = mi < zT_207;
    if (!(zT_208)) { pal_trap(); }
    zT_209 = zT_206[mi];
    zT_203 = zT_209.id;
    zT_204 = ref_name;
    zT_211 = zF_A398987E_symbolRegistryQuali(zT_202, zT_203, zT_204);
    ref_sym = zT_211;
    zT_212 = ref_sym.has_value;
    if (zT_212) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    if (!(ref_sym.has_value)) { pal_trap(); }
    rs = ref_sym.value;
    zT_214 = rs->kind;
    if ((unsigned char)(zT_214 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_219 = ct->symbol_reg;
    zT_223 = mods.ptr;
    zT_224 = mods.len;
    zT_225 = mi < zT_224;
    if (!(zT_225)) { pal_trap(); }
    zT_226 = zT_223[mi];
    zT_220 = zT_226.id;
    zT_228 = ct->store;
    zT_229 = decl_idx;
    zT_231 = zF_8BA26B9E_astStoreNodePayload(zT_228, zT_229);
    zT_221 = zT_231;
    zT_232 = zF_A398987E_symbolRegistryQuali(zT_219, zT_220, zT_221);
    own_sym = zT_232;
    zT_233 = own_sym.has_value;
    if (zT_233) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    if (!(own_sym.has_value)) { pal_trap(); }
    os = own_sym.value;
    zT_235 = os->kind;
    if ((unsigned char)(zT_235 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    os->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_241 = 1;
    changed = zT_241;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_249 = init_type != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_249 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_249) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_252 = init_type != (unsigned int)(20);
    goto z_bb_45;
    z_bb_44:
    zT_252 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_252) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_255 = decl.child_0;
    if ((unsigned char)(zT_255 == (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    if ((unsigned char)(init_type == (unsigned int)(19))) goto z_bb_59; else goto z_bb_60;
    z_bb_48:
    zT_259 = 1;
    need_set = zT_259;
    zT_260 = vd_existing.has_value;
    if (zT_260) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_270 = vd_existing.has_value;
    if ((unsigned char)(!zT_270)) goto z_bb_57; else goto z_bb_58;
    z_bb_51:
    if (!(vd_existing.has_value)) { pal_trap(); }
    vex = vd_existing.value;
    if ((unsigned char)(vex == init_type)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    if ((unsigned char)(need_set != (unsigned char)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_263 = 0;
    need_set = zT_263;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_266 = ct->resolved_types;
    zT_267 = decl_idx;
    zT_268 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_266, zT_267, zT_268);
    goto z_bb_56;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_272 = ct->resolved_types;
    zT_273 = decl_idx;
    zT_274 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_272, zT_273, zT_274);
    goto z_bb_58;
    z_bb_58:
    goto z_bb_49;
    z_bb_59:
    zT_279 = decl.child_0;
    zT_278 = zT_279 != (unsigned int)(0);
    goto z_bb_61;
    z_bb_60:
    zT_278 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_278) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_283 = ct->resolved_types;
    zT_284 = decl.child_0;
    zT_287 = zF_999DCF51_resolvedTypeTableGe(zT_283, zT_284);
    mdt2 = zT_287;
    zT_288 = mdt2.has_value;
    if (zT_288) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    if ((unsigned char)(init_type != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_64:
    if (!(mdt2.has_value)) { pal_trap(); }
    mt2 = mdt2.value;
    if ((unsigned char)(mt2 != (unsigned int)(18))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_292 = ct->resolved_types;
    zT_293 = decl.child_1;
    zT_294 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_292, zT_293, zT_294);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_299 = init_type != (unsigned int)(1);
    goto z_bb_70;
    z_bb_69:
    zT_299 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_299) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_302 = init_type != (unsigned int)(18);
    goto z_bb_73;
    z_bb_72:
    zT_302 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_302) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_305 = init_type != (unsigned int)(20);
    goto z_bb_76;
    z_bb_75:
    zT_305 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_305) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_309 = ct->store;
    zT_310 = decl_idx;
    zT_312 = zF_8BA26B9E_astStoreNodePayload(zT_309, zT_310);
    name_id = zT_312;
    zT_314 = ct->symbol_reg;
    zT_318 = mods.ptr;
    zT_319 = mods.len;
    zT_320 = mi < zT_319;
    if (!(zT_320)) { pal_trap(); }
    zT_321 = zT_318[mi];
    zT_315 = zT_321.id;
    zT_316 = name_id;
    zT_323 = zF_A398987E_symbolRegistryQuali(zT_314, zT_315, zT_316);
    sym = zT_323;
    zT_324 = sym.has_value;
    if (zT_324) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    goto z_bb_27;
    z_bb_79:
    if (!(sym.has_value)) { pal_trap(); }
    s = sym.value;
    zT_326 = decl.child_0;
    if ((unsigned char)(zT_326 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_83;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    zT_329 = s->type_id;
    if ((unsigned char)(zT_329 != init_type)) goto z_bb_84; else goto z_bb_85;
    z_bb_82:
    goto z_bb_80;
    z_bb_83:
    zT_332 = s->type_id;
    if ((unsigned char)(zT_332 == (unsigned int)(0))) goto z_bb_86; else goto z_bb_87;
    z_bb_84:
    s->type_id = init_type;
    zT_331 = 1;
    changed = zT_331;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    s->type_id = init_type;
    zT_335 = 1;
    changed = zT_335;
    goto z_bb_87;
    z_bb_87:
    goto z_bb_82;
    z_bb_88:
    goto z_bb_3;
    z_bb_89:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id) {
    zT_3E40CD83_Sand* zT_6;
    zT_E2DF2801_LocalConstScope zT_8;
    zT_6DCFC8DB_FrontResCtx* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E2DF2801_LocalConstScope* zT_14;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zT_E2DF2801_LocalConstScope scope;
    zT_6 = ct->scratch;
    zT_8 = zF_F5EBC2FF_localConstScopeInit(zT_6);
    scope = zT_8;
    zT_9 = ct;
    zT_10 = module_id;
    zT_11 = node_idx;
    zT_12 = depth;
    zT_13 = source_file_id;
    zT_14 = (zT_E2DF2801_LocalConstScope*)&scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_9, zT_10, zT_11, zT_12, zT_13, zT_14);
    return;
}

/* resolveStmtTypesRec */
void zF_B1CC762C_resolveStmtTypesRec(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id, zT_E2DF2801_LocalConstScope* scope) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned int zT_17;
    int zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_05D09430_Opt_436 zT_24;
    unsigned int zT_25;
    zT_05D09430_Opt_436 zT_27;
    unsigned int zT_28;
    zT_8EED1867_ResolvedTypeTable* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned char zT_45;
    unsigned int zT_46;
    int zT_47;
    zT_E2DF2801_LocalConstScope* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_55;
    zT_8143F551_AstKind zT_56;
    unsigned char zT_60;
    zT_8143F551_AstKind zT_61;
    unsigned char zT_65;
    zT_8143F551_AstKind zT_66;
    unsigned int zT_70;
    int zT_71;
    zT_6B0A7D14_AstStore* zT_73;
    zT_D3EB6303_StringInterner* zT_74;
    unsigned int zT_75;
    unsigned char zT_79;
    zT_6DCFC8DB_FrontResCtx* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_05D09430_Opt_436 zT_85;
    unsigned int zT_86;
    zT_05D09430_Opt_436 zT_88;
    unsigned int zT_89;
    zT_8EED1867_ResolvedTypeTable* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    zT_8143F551_AstKind zT_97;
    unsigned int zT_102;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    zT_6DCFC8DB_FrontResCtx* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_E2DF2801_LocalConstScope* zT_118;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned char zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned char zT_135;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    unsigned int zT_142;
    int zT_143;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_150;
    zT_6DCFC8DB_FrontResCtx* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_E2DF2801_LocalConstScope* zT_156;
    unsigned int zT_158;
    int zT_159;
    unsigned char zT_161;
    zT_8143F551_AstKind zT_162;
    unsigned char zT_166;
    zT_6DCFC8DB_FrontResCtx* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_E2DF2801_LocalConstScope* zT_172;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_107, (unsigned int)sizeof zT_107);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_150, (unsigned int)sizeof zT_150);
    zig_poison_fill((void*)&zT_166, (unsigned int)sizeof zT_166);
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    unsigned int scope_base;
    unsigned int decls_n;
    unsigned int di;
    unsigned int cd;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = ct->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_13 = node.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = node.child_0;
    zT_18 = 0;
    if ((unsigned char)(zT_17 != (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_15; else goto z_bb_14;
    z_bb_5:
    zT_21 = ct;
    zT_22 = module_id;
    zT_23 = node.child_0;
    zT_27.has_value = 1;
    zT_27.value = scope;
    zT_24 = zT_27;
    zT_25 = source_file_id;
    zT_28 = zF_EE3AA0D0_resolveTypeExpr(zT_21, zT_22, zT_23, zT_24, zT_25);
    rtype = zT_28;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_40 = node.flags;
    if ((unsigned char)((unsigned char)(zT_40 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_31 = ct->resolved_types;
    zT_32 = node.child_0;
    zT_33 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_31, zT_32, zT_33);
    zT_36 = ct->resolved_types;
    zT_37 = node_idx;
    zT_38 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_36, zT_37, zT_38);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_46 = node.child_1;
    zT_47 = 0;
    zT_45 = zT_46 != (unsigned int)zT_47;
    goto z_bb_11;
    z_bb_10:
    zT_45 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_45) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = scope;
    zT_52 = ct->store;
    zT_53 = node_idx;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_52, zT_53);
    zT_50 = zT_55;
    zT_51 = node_idx;
    zF_DA915531_localConstScopePush(zT_49, zT_50, zT_51);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_61 = node.kind;
    zT_60 = zT_61 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_16;
    z_bb_15:
    zT_60 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_60) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_66 = node.kind;
    zT_65 = zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_19;
    z_bb_18:
    zT_65 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_65) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_70 = node.child_0;
    zT_71 = 0;
    if ((unsigned char)(zT_70 != (unsigned int)zT_71)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_97 = node.kind;
    if ((unsigned char)(zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_28; else goto z_bb_29;
    z_bb_22:
    zT_73 = ct->store;
    zT_74 = ct->interner;
    zT_75 = node.child_0;
    zT_79 = zF_54996FA4_typeResolverIsInfer(zT_73, zT_74, zT_75);
    if ((unsigned char)(!zT_79)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_82 = ct;
    zT_83 = module_id;
    zT_84 = node.child_0;
    zT_88.has_value = 1;
    zT_88.value = scope;
    zT_85 = zT_88;
    zT_86 = source_file_id;
    zT_89 = zF_EE3AA0D0_resolveTypeExpr(zT_82, zT_83, zT_84, zT_85, zT_86);
    rtype = zT_89;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_92 = ct->resolved_types;
    zT_93 = node.child_0;
    zT_94 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_92, zT_93, zT_94);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_102 = scope->count;
    scope_base = zT_102;
    zT_104 = ct->store;
    zT_105 = node_idx;
    zT_107 = zF_152E19CB_astStoreNodeExtraCh(zT_104, zT_105);
    decls_n = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    di = zT_110;
    goto z_bb_30;
    z_bb_29:
    zT_137 = 1;
    zT_138 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_137)), 32u);
    zT_139 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_137)), 32u);
    zT_141 = zT_139 == (unsigned int)(0);
    if (!(zT_141)) { pal_trap(); }
    cd = zT_138;
    zT_142 = node.child_0;
    zT_143 = 0;
    if ((unsigned char)(zT_142 != (unsigned int)zT_143)) goto z_bb_34; else goto z_bb_35;
    z_bb_30:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_113 = ct;
    zT_114 = module_id;
    zT_119 = ct->store;
    zT_120 = node_idx;
    zT_124 = zF_B10B1BC1_astStoreNodeExtraCh(zT_119, zT_120, (unsigned int)((unsigned int)di));
    zT_115 = zT_124;
    zT_125 = 1;
    zT_126 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_125)), 32u);
    zT_127 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_125)), 32u);
    zT_129 = zT_127 == (unsigned int)(0);
    if (!(zT_129)) { pal_trap(); }
    zT_116 = zT_126;
    zT_117 = source_file_id;
    zT_118 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_113, zT_114, zT_115, zT_116, zT_117, zT_118);
    goto z_bb_33;
    z_bb_32:
    scope->count = scope_base;
    goto z_bb_29;
    z_bb_33:
    zT_130 = 1;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_131)), 32u);
    zT_133 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_131)), 32u);
    zT_135 = zT_133 == (unsigned int)(0);
    if (!(zT_135)) { pal_trap(); }
    di = zT_132;
    goto z_bb_30;
    z_bb_34:
    zT_146 = node.kind;
    zT_150 = zF_C395F6FD_nodeChildIsNode(zT_146, (unsigned char)(0));
    zT_145 = zT_150;
    goto z_bb_36;
    z_bb_35:
    zT_145 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_145) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_151 = ct;
    zT_152 = module_id;
    zT_153 = node.child_0;
    zT_154 = cd;
    zT_155 = source_file_id;
    zT_156 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_151, zT_152, zT_153, zT_154, zT_155, zT_156);
    goto z_bb_38;
    z_bb_38:
    zT_158 = node.child_1;
    zT_159 = 0;
    if ((unsigned char)(zT_158 != (unsigned int)zT_159)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_162 = node.kind;
    zT_166 = zF_C395F6FD_nodeChildIsNode(zT_162, (unsigned char)(1));
    zT_161 = zT_166;
    goto z_bb_41;
    z_bb_40:
    zT_161 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_161) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_167 = ct;
    zT_168 = module_id;
    zT_169 = node.child_1;
    zT_170 = cd;
    zT_171 = source_file_id;
    zT_172 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_167, zT_168, zT_169, zT_170, zT_171, zT_172);
    goto z_bb_43;
    z_bb_43:
    return;
}

/* __module_init */
void zF_780653D2___module_init_16(void) {
    zT_3E40CD83_Sand zT_0;
    zT_D3EB6303_StringInterner zT_1;
    zT_F85C5DED_DiagnosticCollector zT_2;
    zT_8143F551_AstKind zT_3;
    zT_6B0A7D14_AstStore zT_4;
    zT_072B53A6_ModuleRegistry zT_5;
    zT_3D7259E2_SymbolRegistry zT_6;
    zT_338B7C76_TypeRegistry zT_7;
    zT_8EED1867_ResolvedTypeTable zT_8;
    zT_66E7D2EF_CoercionTable zT_9;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
