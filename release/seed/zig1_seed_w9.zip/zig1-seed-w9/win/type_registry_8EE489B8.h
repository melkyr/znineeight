#ifndef ZIG_MODULE_TYPE_REGISTRY_8EE489B8_H
#define ZIG_MODULE_TYPE_REGISTRY_8EE489B8_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "string_interner_51340A9F.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"
#include "name_mangler_27ED89E2.h"

#ifndef ZIG_STRUCT_zT_112BF819_PtrPayload
#define ZIG_STRUCT_zT_112BF819_PtrPayload
struct zT_112BF819_PtrPayload {
	unsigned int base;
};
#endif /* ZIG_STRUCT_zT_112BF819_PtrPayload */
#ifndef ZIG_STRUCT_zT_E834303C_ArrayPayload
#define ZIG_STRUCT_zT_E834303C_ArrayPayload
struct zT_E834303C_ArrayPayload {
	unsigned int elem;
	unsigned int length;
};
#endif /* ZIG_STRUCT_zT_E834303C_ArrayPayload */
#ifndef ZIG_STRUCT_zT_0BB2A741_SlicePayload
#define ZIG_STRUCT_zT_0BB2A741_SlicePayload
struct zT_0BB2A741_SlicePayload {
	unsigned int elem;
};
#endif /* ZIG_STRUCT_zT_0BB2A741_SlicePayload */
#ifndef ZIG_STRUCT_zT_0B10E8E9_OptionalPayload
#define ZIG_STRUCT_zT_0B10E8E9_OptionalPayload
struct zT_0B10E8E9_OptionalPayload {
	unsigned int payload;
};
#endif /* ZIG_STRUCT_zT_0B10E8E9_OptionalPayload */
#ifndef ZIG_STRUCT_zT_42C2D6BF_EUPayload
#define ZIG_STRUCT_zT_42C2D6BF_EUPayload
struct zT_42C2D6BF_EUPayload {
	unsigned int payload;
	unsigned int error_set;
};
#endif /* ZIG_STRUCT_zT_42C2D6BF_EUPayload */
#ifndef ZIG_STRUCT_zT_0B73C507_ErrorSetPayload
#define ZIG_STRUCT_zT_0B73C507_ErrorSetPayload
struct zT_0B73C507_ErrorSetPayload {
	unsigned int tags_start;
	unsigned short tags_count;
};
#endif /* ZIG_STRUCT_zT_0B73C507_ErrorSetPayload */
#ifndef ZIG_STRUCT_zT_0317B1D5_FnPayload
#define ZIG_STRUCT_zT_0317B1D5_FnPayload
struct zT_0317B1D5_FnPayload {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int params_start;
	unsigned short params_count;
	unsigned int return_type;
	unsigned char is_extern;
	unsigned char flags_packed;
};
#endif /* ZIG_STRUCT_zT_0317B1D5_FnPayload */
#ifndef ZIG_STRUCT_zT_406493CE_StructPayload
#define ZIG_STRUCT_zT_406493CE_StructPayload
struct zT_406493CE_StructPayload {
	unsigned int fields_start;
	unsigned short fields_count;
};
#endif /* ZIG_STRUCT_zT_406493CE_StructPayload */
#ifndef ZIG_STRUCT_zT_457ECFEE_EnumPayload
#define ZIG_STRUCT_zT_457ECFEE_EnumPayload
struct zT_457ECFEE_EnumPayload {
	unsigned int members_start;
	unsigned short members_count;
	unsigned int backing_type;
	unsigned char explicit_backing;
};
#endif /* ZIG_STRUCT_zT_457ECFEE_EnumPayload */
#ifndef ZIG_STRUCT_zT_AF9231A2_UnionPayload
#define ZIG_STRUCT_zT_AF9231A2_UnionPayload
struct zT_AF9231A2_UnionPayload {
	unsigned int fields_start;
	unsigned short fields_count;
	unsigned int tag_type;
};
#endif /* ZIG_STRUCT_zT_AF9231A2_UnionPayload */
#ifndef ZIG_STRUCT_zT_54FF90FA_TaggedUnionPayload
#define ZIG_STRUCT_zT_54FF90FA_TaggedUnionPayload
struct zT_54FF90FA_TaggedUnionPayload {
	unsigned int tag_type;
	unsigned int fields_start;
	unsigned short fields_count;
};
#endif /* ZIG_STRUCT_zT_54FF90FA_TaggedUnionPayload */
#ifndef ZIG_STRUCT_zT_666DC2E1_TuplePayload
#define ZIG_STRUCT_zT_666DC2E1_TuplePayload
struct zT_666DC2E1_TuplePayload {
	unsigned int elems_start;
	unsigned short elems_count;
};
#endif /* ZIG_STRUCT_zT_666DC2E1_TuplePayload */
#ifndef ZIG_STRUCT_zT_42E798B0_UnresolvedPayload
#define ZIG_STRUCT_zT_42E798B0_UnresolvedPayload
struct zT_42E798B0_UnresolvedPayload {
	unsigned int name_id;
	unsigned int module_id;
};
#endif /* ZIG_STRUCT_zT_42E798B0_UnresolvedPayload */
#ifndef ZIG_STRUCT_zT_2DF01B61_FieldEntry
#define ZIG_STRUCT_zT_2DF01B61_FieldEntry
struct zT_2DF01B61_FieldEntry {
	unsigned int name_id;
	unsigned int type_id;
	unsigned int offset;
};
#endif /* ZIG_STRUCT_zT_2DF01B61_FieldEntry */
#ifndef ZIG_STRUCT_zT_E276DDD0_PackedBitField
#define ZIG_STRUCT_zT_E276DDD0_PackedBitField
struct zT_E276DDD0_PackedBitField {
	unsigned int bit_offset;
	unsigned short bit_width;
};
#endif /* ZIG_STRUCT_zT_E276DDD0_PackedBitField */
#ifndef ZIG_STRUCT_zT_FA398D58_PackedStructInfo
#define ZIG_STRUCT_zT_FA398D58_PackedStructInfo
struct zT_FA398D58_PackedStructInfo {
	unsigned int pk_start;
	unsigned short pk_count;
	unsigned int total_bits;
};
#endif /* ZIG_STRUCT_zT_FA398D58_PackedStructInfo */
#ifndef ZIG_STRUCT_zT_D96DCDF2_EnumMember
#define ZIG_STRUCT_zT_D96DCDF2_EnumMember
struct zT_D96DCDF2_EnumMember {
	unsigned int name_id;
	zT_79FAE712_u64 value;
};
#endif /* ZIG_STRUCT_zT_D96DCDF2_EnumMember */
#ifndef ZIG_STRUCT_zT_FA84B422_FnParam
#define ZIG_STRUCT_zT_FA84B422_FnParam
struct zT_FA84B422_FnParam {
	unsigned int name_id;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_FA84B422_FnParam */

/* Forward declarations */
void zF_9091237C_typeDbOom(unsigned int, unsigned int);
void zF_B49E7F39_arrayGrow(unsigned char**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_67265B37_payloadEnsure(unsigned char**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int, unsigned int);
void zF_EC48931A_arrayReserve(unsigned char**, unsigned int*, zT_3E40CD83_Sand*, unsigned int, unsigned int);
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry*, zT_D155D06D_Type);
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry*, zT_112BF819_PtrPayload);
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry*, zT_E834303C_ArrayPayload);
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry*, zT_0BB2A741_SlicePayload);
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry*, zT_0B10E8E9_OptionalPayload);
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry*, zT_42C2D6BF_EUPayload);
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry*, zT_0B73C507_ErrorSetPayload);
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry*, zT_0317B1D5_FnPayload);
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry*, zT_406493CE_StructPayload);
void zF_925BA889_pkStructAppend(zT_338B7C76_TypeRegistry*, zT_FA398D58_PackedStructInfo);
void zF_E48D8B88_pkFieldAppend(zT_338B7C76_TypeRegistry*, zT_E276DDD0_PackedBitField);
void zF_41767D71_pkSetFields(zT_338B7C76_TypeRegistry*, unsigned int, zT_FA398D58_PackedStructInfo);
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry*, zT_457ECFEE_EnumPayload);
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry*, zT_AF9231A2_UnionPayload);
void zF_96B8622A_pkUnStructAppend(zT_338B7C76_TypeRegistry*, zT_FA398D58_PackedStructInfo);
void zF_0213D00C_pkUnSetFields(zT_338B7C76_TypeRegistry*, unsigned int, zT_FA398D58_PackedStructInfo);
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry*, zT_54FF90FA_TaggedUnionPayload);
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry*, zT_666DC2E1_TuplePayload);
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry*, zT_42E798B0_UnresolvedPayload);
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry*, zT_2DF01B61_FieldEntry);
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry*, zT_D96DCDF2_EnumMember);
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_534230F8_typeWidthBitsForKin(zT_33EF6BFB_TypeKind);
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry*, zT_33EF6BFB_TypeKind, unsigned int, unsigned int);
unsigned int zF_D2BAC673_alignUp(unsigned int, unsigned int);
void zF_8E7EC1C8_initArray(unsigned char**, unsigned int*, unsigned int*);
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand*, zT_D3EB6303_StringInterner*);
zT_338B7C76_TypeRegistry zF_28AE6613_typeRegistryInitSiz(zT_3E40CD83_Sand*, zT_D3EB6303_StringInterner*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry*, zT_79FAE712_u64);
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry*, zT_79FAE712_u64, unsigned int);
unsigned int zF_41B57F53_typeRegistryCNameId(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_6D108807_typeRegistryCNameId(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_28D4FDB0_typeSliceElementNam(zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08CFA1F1_typeCName(zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler*, unsigned int);
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char);
unsigned int zF_0C0306D6_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char, unsigned char);
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char);
unsigned int zF_827207A1_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char, unsigned char);
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char);
void zF_B75A61E8_optionalCompleteIfR(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_35E259CB_errorUnionCompleteI(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_C173376D_arrayCompleteIfRead(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned short);
zT_BAEE192E_Opt_10 zF_ACB4F3DB_typeRegistryTupleEl(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_D3BC911B_typeRegistryTupleOr(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned char, unsigned char, unsigned int, unsigned short, unsigned int, unsigned char);
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int, unsigned short);
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry*);
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_741B5264_parseArbIntWidth(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char*);
unsigned int zF_B8CF3697_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry*, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_014D7530_typeRegistryEnumBac(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_A3BA89EA_typeRegistryEnumHas(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_655972D5_typeRegistryIntWidt(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_01ED6537_typeRegistryIntIsSi(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, zT_33EF6BFB_TypeKind);
unsigned char zF_A42DCA4C_typeHasForwardDecl(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_E789C17A_typeNeedsFullDef(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_7AC9839C_typeRefPtrLeaf(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_E447DE16_typeRefEdgeTarget(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned char);
unsigned char zF_15186E0C_typeRefsSeenOut(unsigned int*, unsigned int, unsigned int, unsigned int);
unsigned int zF_DAC9FA8B_typeRefsNote(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned char, unsigned int*, unsigned int*, unsigned int, unsigned int, unsigned int);
unsigned int zF_07B0FCB6_typeRefsWalk(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int*, unsigned int, unsigned int, unsigned int);
unsigned int zF_F41AC8EB_typeRefs(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int*);
unsigned char zF_8A421992_typeRefsContains(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry*, unsigned int);
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_6D4AC571_typeKindIsSignedInt(zT_33EF6BFB_TypeKind);
unsigned char zF_C8A7A444_typeKindIsUnsignedI(zT_33EF6BFB_TypeKind);
unsigned int zF_450A9F7B_typeKindIntWidthByt(zT_33EF6BFB_TypeKind);
signed char zF_DE90B14C_typeRegistryIntSign(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_AA3DF530_typeRegistryIntNeed(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_47244FDF_typeRegistryIntByte(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_5534F51C_typeRegistryIntCarr(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_B608F1BF_typeRegistryIntCarr(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_AA5656C9_typeRegistryIsIntKi(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_7B6AECEB_typeRegistryIsScala(zT_338B7C76_TypeRegistry*, unsigned int);
zT_BAEE192E_Opt_10 zF_C35DA834_typeRegistryArrayBy(zT_338B7C76_TypeRegistry*, unsigned int);
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry*, unsigned int, zT_BF2E90D8_Slice_zT_2DF01B61_F*);
unsigned char zF_041ACB92_typeRegistryIsPacke(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_331152CD_typeRegistryCompute(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_7D87247C_typeRegistryGetPack(zT_338B7C76_TypeRegistry*, unsigned int, zT_BCF34E4D_Slice_zT_E276DDD0_P*);
unsigned int zF_CB27DBA4_typeRegistryGetPack(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_52816016_typeRegistrySetPack(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_62A8E268_typeRegistryCompute(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_E4243FA1_typeRegistryGetPack(zT_338B7C76_TypeRegistry*, unsigned int, zT_BCF34E4D_Slice_zT_E276DDD0_P*);
unsigned int zF_B80C4365_typeRegistryGetPack(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry*, unsigned int, zT_BF2E90D8_Slice_zT_2DF01B61_F*);
unsigned char zF_08C13644_pointerQualifiersMo(unsigned char, unsigned char, unsigned char);
unsigned char zF_3130DDCF_typeRegistryTypesEq(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_4D8FED56_typesEquivRec(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int);
unsigned char zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_E35E11A5_errorSetIsSubset(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64, unsigned int);
void zF_780653D2___module_init_10(void);
/* Storage globals (extern decls) */
extern zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
extern unsigned int const zG_D3698568_TYPE_VOID;
extern unsigned int const zG_98A640DA_TYPE_BOOL;
extern unsigned int const zG_F9BAA47F_TYPE_NORETURN;
extern unsigned int const zG_8A81E76F_TYPE_I8;
extern unsigned int const zG_51905DE6_TYPE_I16;
extern unsigned int const zG_DD95B778_TYPE_I32;
extern unsigned int const zG_518E1F4F_TYPE_I64;
extern unsigned int const zG_023BECD3_TYPE_U8;
extern unsigned int const zG_77674BAA_TYPE_U16;
extern unsigned int const zG_7B6BCF24_TYPE_U32;
extern unsigned int const zG_777894CB_TYPE_U64;
extern unsigned int const zG_5C2F9844_TYPE_ISIZE;
extern unsigned int const zG_916E46A8_TYPE_USIZE;
extern unsigned int const zG_1E69444C_TYPE_C_CHAR;
extern unsigned int const zG_FD27E511_TYPE_F32;
extern unsigned int const zG_712F5772_TYPE_F64;
extern unsigned int const zG_41346447_TYPE_NULL;
extern unsigned int const zG_7DF595D2_TYPE_UNDEFINED;
extern unsigned int const zG_718E9CA1_TYPE_INT_LIT;
extern unsigned int const zG_1E022DA6_TYPE_TYPE;
extern unsigned int const zG_A87EA08C_TYPE_VA_LIST;
extern unsigned int const zG_4FF9553F_SLICE_FIELD_PTR;
extern unsigned int const zG_4B466382_SLICE_FIELD_LEN;
extern unsigned int const zG_269BE98A_TU_FIELD_TAG;
extern unsigned int const zG_C0257238_TU_FIELD_PAYLOAD;
extern unsigned int const zG_C7DB4B56_FIRST_USER_TYPE;
extern unsigned char const zG_5FFE6058_VOLATILE_FLAG;
extern unsigned char const zG_53F06A4B_CONST_FLAG;
extern unsigned char const zG_DFDEC5C8_FN_FLAG_VARIADIC;
extern unsigned char const zG_A9D5651E_FN_FLAG_STDCALL;
extern zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;

#endif /* ZIG_MODULE_TYPE_REGISTRY_8EE489B8_H */
