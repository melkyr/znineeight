#include "mem_19CC4C40.h"
/* mem_eql */
unsigned char zF_B7662C9F_mem_eql(zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned char* zT_8;
    unsigned int zT_9;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned int zT_20;
    unsigned char c;
    unsigned int i;
    zT_3 = a.len;
    zT_5 = b.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1: ;
    return (unsigned char)(0);
    z_bb_2: ;
    zT_8 = (unsigned char*)a.ptr;
    zT_9 = a.len;
    i = 0;
    goto z_bb_3;
    z_bb_3: ;
    if ((unsigned char)(i < zT_9)) goto z_bb_4; else goto z_bb_5;
    z_bb_4: ;
    c = zT_8[i];
    zT_13 = (unsigned char*)b.ptr;
    zT_14 = b.len;
    zT_15 = i < zT_14;
    if (!(zT_15)) { pal_trap(); }
    zT_16 = zT_13[i];
    if ((unsigned char)(c != zT_16)) goto z_bb_7; else goto z_bb_8;
    z_bb_5: ;
    return (unsigned char)(1);
    z_bb_6: ;
    zT_20 = i + (unsigned int)(1);
    i = zT_20;
    goto z_bb_3;
    z_bb_7: ;
    return (unsigned char)(0);
    z_bb_8: ;
    goto z_bb_6;
}

/* binary_search */
unsigned int zF_1457D8A5_binary_search(zT_3CB0179A_Slice_zT_05F374B1_u offsets, unsigned int target) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned int zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    int zT_34;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned int lo;
    unsigned int hi;
    unsigned int mid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    lo = zT_4;
    zT_7 = offsets.len;
    zT_8 = (unsigned int)zT_7;
    hi = zT_8;
    goto z_bb_1;
    z_bb_1: ;
    if ((unsigned char)(lo < hi)) goto z_bb_2; else goto z_bb_3;
    z_bb_2: ;
    zT_11 = zig_wrap_sub_u(((zu64)(hi)), ((zu64)(lo)), 32u);
    zT_12 = zig_overflow_flag_sub_u(((zu64)(hi)), ((zu64)(lo)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    zT_15 = 2;
    zT_18 = (unsigned int)zT_15 != (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_16 = zT_11 / zT_15;
    zT_19 = zig_wrap_add_u(((zu64)(lo)), ((zu64)(zT_16)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(lo)), ((zu64)(zT_16)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    mid = zT_19;
    zT_23 = (unsigned int*)offsets.ptr;
    zT_24 = (unsigned int)mid;
    zT_25 = offsets.len;
    zT_26 = zT_24 < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_27 = zT_23[zT_24];
    if ((unsigned char)(zT_27 <= target)) goto z_bb_5; else goto z_bb_7;
    z_bb_3: ;
    zT_34 = 0;
    if ((unsigned char)(lo == (unsigned int)zT_34)) goto z_bb_8; else goto z_bb_10;
    z_bb_4: ;
    goto z_bb_1;
    z_bb_5: ;
    zT_29 = 1;
    zT_30 = zig_wrap_add_u(((zu64)(mid)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(mid)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    lo = zT_30;
    goto z_bb_6;
    z_bb_6: ;
    goto z_bb_4;
    z_bb_7: ;
    hi = mid;
    goto z_bb_6;
    z_bb_8: ;
    return (unsigned int)(0);
    return 0;
    z_bb_10: ;
    zT_37 = 1;
    zT_38 = zig_wrap_sub_u(((zu64)(lo)), ((zu64)(zT_37)), 32u);
    zT_39 = zig_overflow_flag_sub_u(((zu64)(lo)), ((zu64)(zT_37)), 32u);
    zT_41 = zT_39 == (unsigned int)(0);
    if (!(zT_41)) { pal_trap(); }
    return (unsigned int)((unsigned int)zT_38);
}

/* EOF */
