#include "analyzer_2FA863C8.h"
unsigned int const zG_73BDFDC5_PER_FUNC_BUDGET = (unsigned int)(524288);
/* identNameId */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zT_2 = store;
    zT_3 = node_idx;
    zT_4 = zF_53458827_astStoreIdentifier(zT_2, zT_3);
    return zT_4;
}

/* resolveOrigin */
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    zT_BAEE192E_Opt_10 zT_19;
    zT_7E2F335A_AnalyzerContext* zT_23;
    unsigned int zT_25;
    zT_7E2F335A_AnalyzerContext* zT_30;
    unsigned int zT_32;
    zT_BAEE192E_Opt_10 zT_37;
    zT_7E2F335A_AnalyzerContext* zT_41;
    unsigned int zT_43;
    zT_BAEE192E_Opt_10 zT_45;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx->store;
    zT_16 = expr_idx;
    zT_18 = zF_2E24BD6B_identNameId(zT_15, zT_16);
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = ctx;
    zT_25 = node.child_0;
    ctx = zT_23;
    expr_idx = zT_25;
    goto z_bb_0;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = ctx;
    zT_32 = node.child_0;
    ctx = zT_30;
    expr_idx = zT_32;
    goto z_bb_0;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = ctx;
    zT_43 = node.child_0;
    ctx = zT_41;
    expr_idx = zT_43;
    goto z_bb_0;
    z_bb_12:
    zT_45.has_value = 0;
    return zT_45;
}

/* classifyProvenance */
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11;
    zT_8143F551_AstKind zT_13;
    unsigned char zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_22A7C88B_AstNode zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    zT_7E2F335A_AnalyzerContext* zT_34;
    unsigned int zT_35;
    zT_BAEE192E_Opt_10 zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    zT_060CD1EB_SymbolTable* zT_43;
    unsigned int zT_44;
    zT_77F031D4_Opt_960 zT_46;
    unsigned char zT_47;
    zT_3C598AEF_SymbolKind zT_49;
    unsigned char zT_54;
    zT_3C598AEF_SymbolKind zT_55;
    unsigned char zT_60;
    zT_3C598AEF_SymbolKind zT_61;
    unsigned char zT_66;
    zT_2C0927B0_StateMap* zT_70;
    unsigned int zT_71;
    zT_43E16BE5_Opt_8 zT_72;
    unsigned char zT_73;
    unsigned char zT_76;
    unsigned char zT_87;
    unsigned char zT_91;
    zT_7E2F335A_AnalyzerContext* zT_132;
    unsigned int zT_133;
    zT_BAEE192E_Opt_10 zT_135;
    unsigned char zT_136;
    zT_2C0927B0_StateMap* zT_139;
    unsigned int zT_140;
    zT_43E16BE5_Opt_8 zT_141;
    unsigned char zT_142;
    zT_7E2F335A_AnalyzerContext* zT_150;
    unsigned int zT_151;
    zT_BAEE192E_Opt_10 zT_153;
    unsigned char zT_154;
    zT_2C0927B0_StateMap* zT_157;
    unsigned int zT_158;
    zT_43E16BE5_Opt_8 zT_159;
    unsigned char zT_160;
    zT_2C0927B0_StateMap* zT_168;
    unsigned int zT_169;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_173;
    zT_43E16BE5_Opt_8 zT_174;
    unsigned char zT_175;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_37, (unsigned int)sizeof zT_37);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_135, (unsigned int)sizeof zT_135);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zig_poison_fill((void*)&zT_159, (unsigned int)sizeof zT_159);
    zig_poison_fill((void*)&zT_173, (unsigned int)sizeof zT_173);
    zig_poison_fill((void*)&zT_174, (unsigned int)sizeof zT_174);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char t5_is_interior;
    zT_22A7C88B_AstNode t5_onode;
    zT_BAEE192E_Opt_10 found_name_id;
    unsigned int name_id;
    unsigned char t5_base;
    zT_77F031D4_Opt_960 sym;
    zT_3A105EF1_Symbol* s;
    zT_43E16BE5_Opt_8 pv;
    unsigned char v;
    zT_BAEE192E_Opt_10 base_id;
    unsigned int bid;
    zT_43E16BE5_Opt_8 result;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = expr_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = 0;
    t5_is_interior = zT_18;
    zT_19 = node.child_0;
    if ((unsigned char)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_46; else goto z_bb_47;
    z_bb_5:
    zT_23 = ctx->store;
    zT_24 = node.child_0;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_23, zT_24);
    t5_onode = zT_27;
    zT_28 = t5_onode.kind;
    if ((unsigned char)(zT_28 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_34 = ctx;
    zT_35 = node.child_0;
    zT_37 = zF_92A5586D_resolveOrigin(zT_34, zT_35);
    found_name_id = zT_37;
    zT_38 = found_name_id.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_32 = 1;
    t5_is_interior = zT_32;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    if (!(found_name_id.has_value)) { pal_trap(); }
    name_id = found_name_id.value;
    zT_41 = 255;
    t5_base = zT_41;
    zT_43 = ctx->symbols;
    zT_44 = name_id;
    zT_46 = zF_893B79A5_symbolTableLookup(zT_43, zT_44);
    sym = zT_46;
    zT_47 = sym.has_value;
    if (zT_47) goto z_bb_11; else goto z_bb_13;
    z_bb_10:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_11:
    if (!(sym.has_value)) { pal_trap(); }
    s = sym.value;
    zT_49 = s->kind;
    if ((unsigned char)(zT_49 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_local))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    if ((unsigned char)(t5_is_interior == (unsigned char)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_13:
    zT_70 = state;
    zT_71 = name_id;
    zT_72 = zF_2EC17ECC_stateMapGet(zT_70, zT_71);
    pv = zT_72;
    zT_73 = pv.has_value;
    if (zT_73) goto z_bb_23; else goto z_bb_25;
    z_bb_14:
    zT_54 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    t5_base = zT_54;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_55 = s->kind;
    if ((unsigned char)(zT_55 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_param))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_60 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param);
    t5_base = zT_60;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_61 = s->kind;
    if ((unsigned char)(zT_61 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_66 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global);
    t5_base = zT_66;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_23:
    if (!(pv.has_value)) { pal_trap(); }
    v = pv.value;
    t5_base = v;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_76 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    t5_base = zT_76;
    goto z_bb_24;
    z_bb_26:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global)))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external)))) goto z_bb_38; else goto z_bb_39;
    z_bb_28:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_29:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)))) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_87 = t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external));
    goto z_bb_32;
    z_bb_31:
    zT_87 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_87) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_91 = t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    goto z_bb_35;
    z_bb_34:
    zT_91 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_91) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_37:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_38:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external));
    z_bb_39:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global)))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_global));
    z_bb_41:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap)))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_43:
    if ((unsigned char)(t5_base == (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param)))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr));
    z_bb_45:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local));
    z_bb_46:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_heap));
    z_bb_47:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_132 = ctx;
    zT_133 = node.child_0;
    zT_135 = zF_92A5586D_resolveOrigin(zT_132, zT_133);
    base_id = zT_135;
    zT_136 = base_id.has_value;
    if (zT_136) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_54; else goto z_bb_55;
    z_bb_50:
    if (!(base_id.has_value)) { pal_trap(); }
    bid = base_id.value;
    zT_139 = state;
    zT_140 = bid;
    zT_141 = zF_2EC17ECC_stateMapGet(zT_139, zT_140);
    result = zT_141;
    zT_142 = result.has_value;
    if (zT_142) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_52:
    if (!(result.has_value)) { pal_trap(); }
    v = result.value;
    return v;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_150 = ctx;
    zT_151 = node.child_0;
    zT_153 = zF_92A5586D_resolveOrigin(zT_150, zT_151);
    base_id = zT_153;
    zT_154 = base_id.has_value;
    if (zT_154) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    if (!(base_id.has_value)) { pal_trap(); }
    bid = base_id.value;
    zT_157 = state;
    zT_158 = bid;
    zT_159 = zF_2EC17ECC_stateMapGet(zT_157, zT_158);
    result = zT_159;
    zT_160 = result.has_value;
    if (zT_160) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_58:
    if (!(result.has_value)) { pal_trap(); }
    v = result.value;
    return v;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_168 = state;
    zT_170 = ctx->store;
    zT_171 = expr_idx;
    zT_173 = zF_2E24BD6B_identNameId(zT_170, zT_171);
    zT_169 = zT_173;
    zT_174 = zF_2EC17ECC_stateMapGet(zT_168, zT_169);
    result = zT_174;
    zT_175 = result.has_value;
    if (zT_175) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
    z_bb_62:
    if (!(result.has_value)) { pal_trap(); }
    v = result.value;
    return v;
    z_bb_63:
    return (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown));
}

/* checkReturnProvenance */
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx, unsigned int ret_node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_5;
    zT_2C0927B0_StateMap* zT_6;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_22A7C88B_AstNode zT_28;
    unsigned char zT_31;
    unsigned char zT_34;
    zT_8143F551_AstKind zT_36;
    zT_7E2F335A_AnalyzerContext* zT_41;
    unsigned int zT_42;
    zT_BAEE192E_Opt_10 zT_44;
    unsigned char zT_45;
    zT_D3EB6303_StringInterner* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_D3EB6303_StringInterner* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_67;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_71;
    unsigned char zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_8143F551_AstKind zT_109;
    zT_7E2F335A_AnalyzerContext* zT_114;
    unsigned int zT_115;
    zT_BAEE192E_Opt_10 zT_117;
    unsigned char zT_118;
    zT_D3EB6303_StringInterner* zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    unsigned char* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_D3EB6303_StringInterner* zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_140;
    zT_F85C5DED_DiagnosticCollector* zT_142;
    int zT_144;
    unsigned char zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    zT_F85C5DED_DiagnosticCollector* zT_150;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned char* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167;
    zT_F85C5DED_DiagnosticCollector* zT_168;
    unsigned int zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    zT_7E2F335A_AnalyzerContext* zT_183;
    unsigned int zT_184;
    zT_BAEE192E_Opt_10 zT_185;
    unsigned char zT_186;
    zT_D3EB6303_StringInterner* zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    zT_D3EB6303_StringInterner* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_208;
    zT_F85C5DED_DiagnosticCollector* zT_210;
    int zT_212;
    unsigned char zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    zT_F85C5DED_DiagnosticCollector* zT_218;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_F85C5DED_DiagnosticCollector* zT_236;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    zT_7E2F335A_AnalyzerContext* zT_252;
    unsigned int zT_253;
    zT_BAEE192E_Opt_10 zT_255;
    unsigned char zT_256;
    zT_D3EB6303_StringInterner* zT_259;
    unsigned int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned char* zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    unsigned int zT_266;
    unsigned char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_D3EB6303_StringInterner* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_278;
    zT_F85C5DED_DiagnosticCollector* zT_280;
    int zT_282;
    unsigned char zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    zT_F85C5DED_DiagnosticCollector* zT_288;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned char* zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_F85C5DED_DiagnosticCollector* zT_306;
    unsigned int zT_310;
    unsigned int zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_185, (unsigned int)sizeof zT_185);
    zig_poison_fill((void*)&zT_192, (unsigned int)sizeof zT_192);
    zig_poison_fill((void*)&zT_217, (unsigned int)sizeof zT_217);
    zig_poison_fill((void*)&zT_255, (unsigned int)sizeof zT_255);
    zig_poison_fill((void*)&zT_262, (unsigned int)sizeof zT_262);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    unsigned char prov;
    zT_22A7C88B_AstNode rnode;
    unsigned int start;
    unsigned int end;
    zT_22A7C88B_AstNode expr_node;
    unsigned char pl;
    unsigned char ppa;
    zT_BAEE192E_Opt_10 name_opt;
    unsigned int nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u rp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli rparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_5 = ctx;
    zT_6 = state;
    zT_7 = expr_idx;
    zT_8 = zF_5542CD3C_classifyProvenance(zT_5, zT_6, zT_7);
    prov = zT_8;
    zT_10 = ctx->store;
    zT_11 = ret_node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    rnode = zT_13;
    zT_15 = rnode.span_start;
    start = zT_15;
    zT_17 = rnode.span_start;
    zT_18 = rnode.span_len;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    end = zT_20;
    zT_25 = ctx->store;
    zT_26 = expr_idx;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    expr_node = zT_28;
    zT_31 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_local);
    pl = zT_31;
    zT_34 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param_addr);
    ppa = zT_34;
    if ((unsigned char)(prov == pl)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_36 = expr_node.kind;
    if ((unsigned char)(zT_36 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(prov == ppa)) goto z_bb_13; else goto z_bb_14;
    z_bb_3:
    zT_41 = ctx;
    zT_42 = expr_node.child_0;
    zT_44 = zF_92A5586D_resolveOrigin(zT_41, zT_42);
    name_opt = zT_44;
    zT_45 = name_opt.has_value;
    if (zT_45) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_109 = expr_node.kind;
    if ((unsigned char)(zT_109 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    if (!(name_opt.has_value)) { pal_trap(); }
    nid = name_opt.value;
    zT_48 = ctx->interner;
    zT_49 = nid;
    zT_51 = zF_9134020D_stringInternerGet(zT_48, zT_49);
    nm = zT_51;
    zT_53 = "returning address of local variable '";
    zT_55 = 37;
    zT_54.ptr = (unsigned char*)zT_53;
    zT_54.len = zT_55;
    rp1 = zT_54;
    zT_57 = "'";
    zT_59 = 1;
    zT_58.ptr = (unsigned char*)zT_57;
    zT_58.len = zT_59;
    rp2 = zT_58;
    zT_62 = 0;
    zT_61[zT_62] = rp1;
    zT_63 = 1;
    zT_61[zT_63] = nm;
    zT_64 = 2;
    zT_61[zT_64] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_61[_i];
        _i++;
    }
}
    zT_69 = ctx->diag;
    zT_66 = zT_69->interner;
    zT_71 = 0;
    zT_73 = (unsigned int)zT_71 < (unsigned int)(3);
    if (!(zT_73)) { pal_trap(); }
    zT_74 = rparts + zT_71;
    zT_67 = zT_74;
    zT_76 = zF_8C4BFF7C_diagnosticBuilderMa(zT_66, zT_67, (unsigned int)(3));
    msg = zT_76;
    zT_77 = ctx->diag;
    zT_81 = start;
    zT_82 = end;
    zT_83 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_77, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_81, zT_82, zT_83);
    return;
    z_bb_6:
    zT_92 = "returning address of local variable";
    zT_94 = 35;
    zT_93.ptr = (unsigned char*)zT_92;
    zT_93.len = zT_94;
    dmsg = zT_93;
    zT_95 = ctx->diag;
    zT_99 = start;
    zT_100 = end;
    zT_101 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2020_RETURNING_ADDRESS_OF_LOCAL)), (unsigned int)(0), zT_99, zT_100, zT_101);
    return;
    z_bb_7:
    zT_114 = ctx;
    zT_115 = expr_node.child_0;
    zT_117 = zF_92A5586D_resolveOrigin(zT_114, zT_115);
    name_opt = zT_117;
    zT_118 = name_opt.has_value;
    if (zT_118) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_183 = ctx;
    zT_184 = expr_idx;
    zT_185 = zF_92A5586D_resolveOrigin(zT_183, zT_184);
    name_opt = zT_185;
    zT_186 = name_opt.has_value;
    if (zT_186) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if (!(name_opt.has_value)) { pal_trap(); }
    nid = name_opt.value;
    zT_121 = ctx->interner;
    zT_122 = nid;
    zT_124 = zF_9134020D_stringInternerGet(zT_121, zT_122);
    nm = zT_124;
    zT_126 = "returning slice of local array '";
    zT_128 = 32;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    rp1 = zT_127;
    zT_130 = "'";
    zT_132 = 1;
    zT_131.ptr = (unsigned char*)zT_130;
    zT_131.len = zT_132;
    rp2 = zT_131;
    zT_135 = 0;
    zT_134[zT_135] = rp1;
    zT_136 = 1;
    zT_134[zT_136] = nm;
    zT_137 = 2;
    zT_134[zT_137] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_134[_i];
        _i++;
    }
}
    zT_142 = ctx->diag;
    zT_139 = zT_142->interner;
    zT_144 = 0;
    zT_146 = (unsigned int)zT_144 < (unsigned int)(3);
    if (!(zT_146)) { pal_trap(); }
    zT_147 = rparts + zT_144;
    zT_140 = zT_147;
    zT_149 = zF_8C4BFF7C_diagnosticBuilderMa(zT_139, zT_140, (unsigned int)(3));
    msg = zT_149;
    zT_150 = ctx->diag;
    zT_154 = start;
    zT_155 = end;
    zT_156 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_150, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_154, zT_155, zT_156);
    return;
    z_bb_10:
    zT_165 = "returning slice of local array";
    zT_167 = 30;
    zT_166.ptr = (unsigned char*)zT_165;
    zT_166.len = zT_167;
    dmsg = zT_166;
    zT_168 = ctx->diag;
    zT_172 = start;
    zT_173 = end;
    zT_174 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_168, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6011_RETURNING_SLICE_OF_LOCAL)), (unsigned int)(0), zT_172, zT_173, zT_174);
    return;
    z_bb_11:
    if (!(name_opt.has_value)) { pal_trap(); }
    nid = name_opt.value;
    zT_189 = ctx->interner;
    zT_190 = nid;
    zT_192 = zF_9134020D_stringInternerGet(zT_189, zT_190);
    nm = zT_192;
    zT_194 = "returning pointer to local via variable '";
    zT_196 = 41;
    zT_195.ptr = (unsigned char*)zT_194;
    zT_195.len = zT_196;
    rp1 = zT_195;
    zT_198 = "'";
    zT_200 = 1;
    zT_199.ptr = (unsigned char*)zT_198;
    zT_199.len = zT_200;
    rp2 = zT_199;
    zT_203 = 0;
    zT_202[zT_203] = rp1;
    zT_204 = 1;
    zT_202[zT_204] = nm;
    zT_205 = 2;
    zT_202[zT_205] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_202[_i];
        _i++;
    }
}
    zT_210 = ctx->diag;
    zT_207 = zT_210->interner;
    zT_212 = 0;
    zT_214 = (unsigned int)zT_212 < (unsigned int)(3);
    if (!(zT_214)) { pal_trap(); }
    zT_215 = rparts + zT_212;
    zT_208 = zT_215;
    zT_217 = zF_8C4BFF7C_diagnosticBuilderMa(zT_207, zT_208, (unsigned int)(3));
    msg = zT_217;
    zT_218 = ctx->diag;
    zT_222 = start;
    zT_223 = end;
    zT_224 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_218, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_222, zT_223, zT_224);
    return;
    z_bb_12:
    zT_233 = "returning pointer to local via variable";
    zT_235 = 39;
    zT_234.ptr = (unsigned char*)zT_233;
    zT_234.len = zT_235;
    dmsg = zT_234;
    zT_236 = ctx->diag;
    zT_240 = start;
    zT_241 = end;
    zT_242 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_236, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6010_RETURNING_POINTER_VIA_VARIABLE)), (unsigned int)(0), zT_240, zT_241, zT_242);
    return;
    z_bb_13:
    zT_252 = ctx;
    zT_253 = expr_node.child_0;
    zT_255 = zF_92A5586D_resolveOrigin(zT_252, zT_253);
    name_opt = zT_255;
    zT_256 = name_opt.has_value;
    if (zT_256) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    return;
    z_bb_15:
    if (!(name_opt.has_value)) { pal_trap(); }
    nid = name_opt.value;
    zT_259 = ctx->interner;
    zT_260 = nid;
    zT_262 = zF_9134020D_stringInternerGet(zT_259, zT_260);
    nm = zT_262;
    zT_264 = "returning address of parameter '";
    zT_266 = 32;
    zT_265.ptr = (unsigned char*)zT_264;
    zT_265.len = zT_266;
    rp1 = zT_265;
    zT_268 = "'";
    zT_270 = 1;
    zT_269.ptr = (unsigned char*)zT_268;
    zT_269.len = zT_270;
    rp2 = zT_269;
    zT_273 = 0;
    zT_272[zT_273] = rp1;
    zT_274 = 1;
    zT_272[zT_274] = nm;
    zT_275 = 2;
    zT_272[zT_275] = rp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        rparts[_i] = zT_272[_i];
        _i++;
    }
}
    zT_280 = ctx->diag;
    zT_277 = zT_280->interner;
    zT_282 = 0;
    zT_284 = (unsigned int)zT_282 < (unsigned int)(3);
    if (!(zT_284)) { pal_trap(); }
    zT_285 = rparts + zT_282;
    zT_278 = zT_285;
    zT_287 = zF_8C4BFF7C_diagnosticBuilderMa(zT_277, zT_278, (unsigned int)(3));
    msg = zT_287;
    zT_288 = ctx->diag;
    zT_292 = start;
    zT_293 = end;
    zT_294 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_288, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_292, zT_293, zT_294);
    return;
    z_bb_16:
    zT_303 = "returning address of function parameter";
    zT_305 = 39;
    zT_304.ptr = (unsigned char*)zT_303;
    zT_304.len = zT_305;
    dmsg = zT_304;
    zT_306 = ctx->diag;
    zT_310 = start;
    zT_311 = end;
    zT_312 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_306, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2021_RETURNING_ADDRESS_OF_PARAM)), (unsigned int)(0), zT_310, zT_311, zT_312);
    return;
}

/* isAllocCall */
unsigned char zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_7E2F335A_AnalyzerContext* zT_14;
    unsigned int zT_16;
    zT_8143F551_AstKind zT_18;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28;
    zT_8143F551_AstKind zT_29;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_48;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_D3EB6303_StringInterner* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_D3EB6303_StringInterner* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sandAlloc;
    unsigned int sand_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_alloc;
    unsigned int sand2_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_alloc;
    unsigned int arena_nid;
    z_bb_0:
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = ctx;
    zT_16 = node.child_0;
    ctx = zT_14;
    expr_idx = zT_16;
    goto z_bb_0;
    z_bb_4:
    zT_18 = node.kind;
    if ((unsigned char)(zT_18 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_24 = ctx->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    callee = zT_28;
    zT_29 = callee.kind;
    if ((unsigned char)(zT_29 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_35 = ctx->store;
    zT_36 = node.child_0;
    zT_39 = zF_2E24BD6B_identNameId(zT_35, zT_36);
    name_id = zT_39;
    zT_41 = "sandAlloc";
    zT_43 = 9;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    s_sandAlloc = zT_42;
    zT_45 = ctx->interner;
    zT_46 = s_sandAlloc;
    zT_48 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    sand_nid = zT_48;
    if ((unsigned char)(name_id == sand_nid)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_52 = "sand_alloc";
    zT_54 = 10;
    zT_53.ptr = (unsigned char*)zT_52;
    zT_53.len = zT_54;
    s_sand_alloc = zT_53;
    zT_56 = ctx->interner;
    zT_57 = s_sand_alloc;
    zT_59 = zF_50C274AF_stringInternerInter(zT_56, zT_57);
    sand2_nid = zT_59;
    if ((unsigned char)(name_id == sand2_nid)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_63 = "arena_alloc";
    zT_65 = 11;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    s_arena_alloc = zT_64;
    zT_67 = ctx->interner;
    zT_68 = s_arena_alloc;
    zT_70 = zF_50C274AF_stringInternerInter(zT_67, zT_68);
    arena_nid = zT_70;
    if ((unsigned char)(name_id == arena_nid)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* isFreeCall */
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext* ctx, unsigned int expr_idx) {
    zT_BAEE192E_Opt_10 zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_BAEE192E_Opt_10 zT_14;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20;
    zT_8143F551_AstKind zT_21;
    zT_BAEE192E_Opt_10 zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_BAEE192E_Opt_10 zT_53;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58;
    zT_BAEE192E_Opt_10 zT_61;
    zT_6B0A7D14_AstStore* zT_63;
    unsigned int zT_64;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    zT_22A7C88B_AstNode zT_73;
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_81;
    zT_BAEE192E_Opt_10 zT_82;
    zT_BAEE192E_Opt_10 zT_83;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arena_free;
    unsigned int arena_free_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sand_free;
    unsigned int sand_free_nid;
    unsigned int args_n;
    unsigned int args1;
    zT_22A7C88B_AstNode ptr_arg;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14.has_value = 0;
    return zT_14;
    z_bb_4:
    zT_16 = ctx->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    callee = zT_20;
    zT_21 = callee.kind;
    if ((unsigned char)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_6:
    zT_27 = ctx->store;
    zT_28 = node.child_0;
    zT_31 = zF_2E24BD6B_identNameId(zT_27, zT_28);
    name_id = zT_31;
    zT_33 = "arena_free";
    zT_35 = 10;
    zT_34.ptr = (unsigned char*)zT_33;
    zT_34.len = zT_35;
    s_arena_free = zT_34;
    zT_37 = ctx->interner;
    zT_38 = s_arena_free;
    zT_40 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    arena_free_nid = zT_40;
    zT_42 = "sandFree";
    zT_44 = 8;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    s_sand_free = zT_43;
    zT_46 = ctx->interner;
    zT_47 = s_sand_free;
    zT_49 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    sand_free_nid = zT_49;
    if ((unsigned char)(name_id != arena_free_nid)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_51 = name_id != sand_free_nid;
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_53.has_value = 0;
    return zT_53;
    z_bb_11:
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_152E19CB_astStoreNodeExtraCh(zT_55, zT_56);
    args_n = zT_58;
    if ((unsigned char)(args_n < (unsigned int)(2))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_61.has_value = 0;
    return zT_61;
    z_bb_13:
    zT_63 = ctx->store;
    zT_64 = expr_idx;
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_63, zT_64, (unsigned int)(1));
    args1 = zT_68;
    zT_70 = ctx->store;
    zT_71 = args1;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_70, zT_71);
    ptr_arg = zT_73;
    zT_74 = ptr_arg.kind;
    if ((unsigned char)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_78 = ctx->store;
    zT_79 = args1;
    zT_81 = zF_2E24BD6B_identNameId(zT_78, zT_79);
    zT_82.has_value = 1;
    zT_82.value = zT_81;
    return zT_82;
    z_bb_15:
    zT_83.has_value = 0;
    return zT_83;
}

/* compositeNameId */
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner* interner, unsigned int base_id, unsigned int field_id) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_C4003E6D_Arr_unsigned_char_1 zT_12;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned char zT_45;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char* zT_62;
    unsigned int zT_63;
    unsigned char zT_64;
    unsigned char zT_65;
    unsigned char zT_67;
    int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    zT_D3EB6303_StringInterner* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    int zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zT_8F083A69_Slice_zT_0B42B2F8_u base_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u field_str;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int pos;
    unsigned int i;
    zT_4 = interner;
    zT_5 = base_id;
    zT_6 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    base_str = zT_6;
    zT_8 = interner;
    zT_9 = field_id;
    zT_10 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    field_str = zT_10;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    pos = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    i = zT_18;
    goto z_bb_1;
    z_bb_1:
    zT_20 = base_str.len;
    if ((unsigned char)(i < zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_25 = base_str.ptr;
    zT_26 = base_str.len;
    zT_27 = i < zT_26;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_25[i];
    zT_30 = pos < (unsigned int)(128);
    if (!(zT_30)) { pal_trap(); }
    buf[pos] = zT_28;
    zT_31 = 1;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    pos = zT_33;
    zT_37 = 1;
    zT_38 = (unsigned int)zT_37;
    zT_39 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    i = zT_39;
    goto z_bb_4;
    z_bb_3:
    if ((unsigned char)(pos < (unsigned int)(127))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_22 = pos < (unsigned int)(127);
    goto z_bb_7;
    z_bb_6:
    zT_22 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_22) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_45 = 46;
    zT_47 = pos < (unsigned int)(128);
    if (!(zT_47)) { pal_trap(); }
    buf[pos] = zT_45;
    zT_48 = 1;
    zT_49 = (unsigned int)zT_48;
    zT_50 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    pos = zT_50;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    i = zT_55;
    goto z_bb_10;
    z_bb_10:
    zT_57 = field_str.len;
    if ((unsigned char)(i < zT_57)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_62 = field_str.ptr;
    zT_63 = field_str.len;
    zT_64 = i < zT_63;
    if (!(zT_64)) { pal_trap(); }
    zT_65 = zT_62[i];
    zT_67 = pos < (unsigned int)(128);
    if (!(zT_67)) { pal_trap(); }
    buf[pos] = zT_65;
    zT_68 = 1;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_69)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_69)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    pos = zT_70;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    i = zT_76;
    goto z_bb_13;
    z_bb_12:
    zT_80 = interner;
    zT_84 = 0;
    zT_85 = (unsigned char*)((unsigned char*)buf) + zT_84;
    zT_86 = pos - zT_84;
    zT_87 = (unsigned int)zT_84 <= pos;
    if (!(zT_87)) { pal_trap(); }
    zT_88 = pos <= (unsigned int)(128);
    if (!(zT_88)) { pal_trap(); }
    zT_89.ptr = (unsigned char*)zT_85;
    zT_89.len = zT_86;
    zT_81 = zT_89;
    zT_90 = zF_50C274AF_stringInternerInter(zT_80, zT_81);
    return zT_90;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_59 = pos < (unsigned int)(127);
    goto z_bb_16;
    z_bb_15:
    zT_59 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_59) goto z_bb_11; else goto z_bb_12;
}

/* handleAllocCall */
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int init_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_2C0927B0_StateMap* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_480593AB_AllocState zT_11;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_4 = ctx;
    zT_5 = init_idx;
    zT_6 = zF_264B254A_isAllocCall(zT_4, zT_5);
    if ((unsigned char)(!zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = state;
    zT_9 = name_id;
    zT_11 = zT_480593AB_AllocState_allocated;
    zT_10 = zT_11;
    zF_ACCFA860_stateMapSet(zT_8, zT_9, zT_10);
    return;
}

/* handleFreeCall */
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_7E2F335A_AnalyzerContext* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_15;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_22A7C88B_AstNode zT_20;
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_480593AB_AllocState zT_28;
    zT_D3EB6303_StringInterner* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D3EB6303_StringInterner* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    int zT_55;
    unsigned char zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_F85C5DED_DiagnosticCollector* zT_61;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    zT_2C0927B0_StateMap* zT_83;
    unsigned int zT_84;
    unsigned char zT_85;
    zT_480593AB_AllocState zT_86;
    zT_D3EB6303_StringInterner* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_D3EB6303_StringInterner* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_109;
    int zT_111;
    unsigned char zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_F85C5DED_DiagnosticCollector* zT_117;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned char zT_137;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    unsigned int name_id;
    zT_43E16BE5_Opt_8 current;
    zT_22A7C88B_AstNode node;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_8F083A69_Slice_zT_0B42B2F8_u up2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u umsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli dparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_4 = ctx;
    zT_5 = expr_idx;
    zT_6 = zF_E445D5FB_isFreeCall(zT_4, zT_5);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return;
    z_bb_2:
    if (!(zT_6.has_value)) { pal_trap(); }
    zT_8 = zT_6.value;
    goto z_bb_3;
    z_bb_3:
    name_id = zT_8;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_13 = state;
    zT_14 = name_id;
    zT_15 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    current = zT_15;
    zT_17 = ctx->store;
    zT_18 = expr_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_17, zT_18);
    node = zT_20;
    zT_21 = current.has_value;
    if (zT_21) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    if (!(current.has_value)) { pal_trap(); }
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_88 = ctx->interner;
    zT_89 = name_id;
    zT_91 = zF_9134020D_stringInternerGet(zT_88, zT_89);
    pn = zT_91;
    zT_93 = "freeing untracked pointer '";
    zT_95 = 27;
    zT_94.ptr = (unsigned char*)zT_93;
    zT_94.len = zT_95;
    up1 = zT_94;
    zT_97 = "'";
    zT_99 = 1;
    zT_98.ptr = (unsigned char*)zT_97;
    zT_98.len = zT_99;
    up2 = zT_98;
    zT_102 = 0;
    zT_101[zT_102] = up1;
    zT_103 = 1;
    zT_101[zT_103] = pn;
    zT_104 = 2;
    zT_101[zT_104] = up2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_101[_i];
        _i++;
    }
}
    zT_109 = ctx->diag;
    zT_106 = zT_109->interner;
    zT_111 = 0;
    zT_113 = (unsigned int)zT_111 < (unsigned int)(3);
    if (!(zT_113)) { pal_trap(); }
    zT_114 = uparts + zT_111;
    zT_107 = zT_114;
    zT_116 = zF_8C4BFF7C_diagnosticBuilderMa(zT_106, zT_107, (unsigned int)(3));
    umsg = zT_116;
    zT_117 = ctx->diag;
    zT_121 = node.span_start;
    zT_131 = node.span_start;
    zT_132 = node.span_len;
    zT_133 = (unsigned int)zT_132;
    zT_134 = zig_wrap_add_u(((zu64)(zT_131)), ((zu64)(zT_133)), 32u);
    zT_135 = zig_overflow_flag_add_u(((zu64)(zT_131)), ((zu64)(zT_133)), 32u);
    zT_137 = zT_135 == (unsigned int)(0);
    if (!(zT_137)) { pal_trap(); }
    zT_122 = zT_134;
    zT_123 = umsg;
    (void)zF_C82559AC_diagnosticCollector(zT_117, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6006_FREEING_UNTRACKED)), (unsigned int)(0), zT_121, zT_122, zT_123);
    goto z_bb_7;
    z_bb_9:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_480593AB_AllocState_freed;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    return;
    z_bb_10:
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_freed))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = ctx->interner;
    zT_33 = name_id;
    zT_35 = zF_9134020D_stringInternerGet(zT_32, zT_33);
    pn = zT_35;
    zT_37 = "double free of pointer '";
    zT_39 = 24;
    zT_38.ptr = (unsigned char*)zT_37;
    zT_38.len = zT_39;
    dp1 = zT_38;
    zT_41 = "'";
    zT_43 = 1;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    dp2 = zT_42;
    zT_46 = 0;
    zT_45[zT_46] = dp1;
    zT_47 = 1;
    zT_45[zT_47] = pn;
    zT_48 = 2;
    zT_45[zT_48] = dp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        dparts[_i] = zT_45[_i];
        _i++;
    }
}
    zT_53 = ctx->diag;
    zT_50 = zT_53->interner;
    zT_55 = 0;
    zT_57 = (unsigned int)zT_55 < (unsigned int)(3);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = dparts + zT_55;
    zT_51 = zT_58;
    zT_60 = zF_8C4BFF7C_diagnosticBuilderMa(zT_50, zT_51, (unsigned int)(3));
    dmsg = zT_60;
    zT_61 = ctx->diag;
    zT_65 = node.span_start;
    zT_75 = node.span_start;
    zT_76 = node.span_len;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zig_wrap_add_u(((zu64)(zT_75)), ((zu64)(zT_77)), 32u);
    zT_79 = zig_overflow_flag_add_u(((zu64)(zT_75)), ((zu64)(zT_77)), 32u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    zT_66 = zT_78;
    zT_67 = dmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_61, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2005_DOUBLE_FREE)), (unsigned int)(0), zT_65, zT_66, zT_67);
    return;
    z_bb_12:
    zT_83 = state;
    zT_84 = name_id;
    zT_86 = zT_480593AB_AllocState_freed;
    zT_85 = zT_86;
    zF_ACCFA860_stateMapSet(zT_83, zT_84, zT_85);
    goto z_bb_7;
}

/* checkLeaksOnScopeExit */
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state) {
    zT_2C0927B0_StateMap* zT_3;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_6B392E0E_StateEntry* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_6B392E0E_StateEntry zT_14;
    unsigned char zT_15;
    zT_D3EB6303_StringInterner* zT_19;
    unsigned int zT_20;
    zT_6B392E0E_StateEntry* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_6B392E0E_StateEntry zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_43;
    zT_F85C5DED_DiagnosticCollector* zT_45;
    int zT_47;
    unsigned char zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zT_92FBD55B_Slice_zT_6B392E0E_S entries;
    unsigned int ei;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli lparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_3 = state;
    zT_4 = zF_F0E7F434_stateMapGetEntries(zT_3);
    entries = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    ei = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = entries.len;
    if ((unsigned char)(ei < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = entries.ptr;
    zT_12 = entries.len;
    zT_13 = ei < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[ei];
    zT_15 = zT_14.state;
    if ((unsigned char)(zT_15 == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_69 = 1;
    zT_70 = (unsigned int)zT_69;
    zT_71 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    ei = zT_71;
    goto z_bb_1;
    z_bb_5:
    zT_19 = ctx->interner;
    zT_22 = entries.ptr;
    zT_23 = entries.len;
    zT_24 = ei < zT_23;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_22[ei];
    zT_20 = zT_25.name_id;
    zT_27 = zF_9134020D_stringInternerGet(zT_19, zT_20);
    pn = zT_27;
    zT_29 = "memory leak: pointer '";
    zT_31 = 22;
    zT_30.ptr = (unsigned char*)zT_29;
    zT_30.len = zT_31;
    lp1 = zT_30;
    zT_33 = "' not freed";
    zT_35 = 11;
    zT_34.ptr = (unsigned char*)zT_33;
    zT_34.len = zT_35;
    lp2 = zT_34;
    zT_38 = 0;
    zT_37[zT_38] = lp1;
    zT_39 = 1;
    zT_37[zT_39] = pn;
    zT_40 = 2;
    zT_37[zT_40] = lp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        lparts[_i] = zT_37[_i];
        _i++;
    }
}
    zT_45 = ctx->diag;
    zT_42 = zT_45->interner;
    zT_47 = 0;
    zT_49 = (unsigned int)zT_47 < (unsigned int)(3);
    if (!(zT_49)) { pal_trap(); }
    zT_50 = lparts + zT_47;
    zT_43 = zT_50;
    zT_52 = zF_8C4BFF7C_diagnosticBuilderMa(zT_42, zT_43, (unsigned int)(3));
    lmsg = zT_52;
    zT_53 = ctx->diag;
    zT_59 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_53, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_59);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* handleAllocAssign */
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    zT_2C0927B0_StateMap* zT_27;
    unsigned int zT_28;
    zT_43E16BE5_Opt_8 zT_29;
    unsigned char zT_30;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_54;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_58;
    unsigned char zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_F85C5DED_DiagnosticCollector* zT_64;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_7E2F335A_AnalyzerContext* zT_86;
    unsigned int zT_87;
    unsigned char zT_88;
    zT_2C0927B0_StateMap* zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    zT_480593AB_AllocState zT_92;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    zT_22A7C88B_AstNode zT_99;
    zT_8143F551_AstKind zT_100;
    zT_2C0927B0_StateMap* zT_104;
    unsigned int zT_105;
    unsigned char zT_106;
    zT_480593AB_AllocState zT_107;
    zT_2C0927B0_StateMap* zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    zT_480593AB_AllocState zT_111;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zT_22A7C88B_AstNode node;
    unsigned int lhs_idx;
    unsigned int rhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int lhs_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u op1;
    zT_8F083A69_Slice_zT_0B42B2F8_u op2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli oparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    zT_22A7C88B_AstNode rhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_0;
    lhs_idx = zT_9;
    zT_11 = node.child_1;
    rhs_idx = zT_11;
    zT_13 = ctx->store;
    zT_14 = lhs_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    lhs_node = zT_16;
    zT_17 = lhs_node.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_22 = ctx->store;
    zT_23 = lhs_idx;
    zT_25 = zF_2E24BD6B_identNameId(zT_22, zT_23);
    lhs_name_id = zT_25;
    zT_27 = state;
    zT_28 = lhs_name_id;
    zT_29 = zF_2EC17ECC_stateMapGet(zT_27, zT_28);
    current = zT_29;
    zT_30 = current.has_value;
    if (zT_30) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    if (!(current.has_value)) { pal_trap(); }
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_86 = ctx;
    zT_87 = rhs_idx;
    zT_88 = zF_264B254A_isAllocCall(zT_86, zT_87);
    if (zT_88) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_35 = ctx->interner;
    zT_36 = lhs_name_id;
    zT_38 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    pn = zT_38;
    zT_40 = "memory leak: pointer '";
    zT_42 = 22;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    op1 = zT_41;
    zT_44 = "' overwritten before free";
    zT_46 = 25;
    zT_45.ptr = (unsigned char*)zT_44;
    zT_45.len = zT_46;
    op2 = zT_45;
    zT_49 = 0;
    zT_48[zT_49] = op1;
    zT_50 = 1;
    zT_48[zT_50] = pn;
    zT_51 = 2;
    zT_48[zT_51] = op2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        oparts[_i] = zT_48[_i];
        _i++;
    }
}
    zT_56 = ctx->diag;
    zT_53 = zT_56->interner;
    zT_58 = 0;
    zT_60 = (unsigned int)zT_58 < (unsigned int)(3);
    if (!(zT_60)) { pal_trap(); }
    zT_61 = oparts + zT_58;
    zT_54 = zT_61;
    zT_63 = zF_8C4BFF7C_diagnosticBuilderMa(zT_53, zT_54, (unsigned int)(3));
    lmsg = zT_63;
    zT_64 = ctx->diag;
    zT_68 = node.span_start;
    zT_78 = node.span_start;
    zT_79 = node.span_len;
    zT_80 = (unsigned int)zT_79;
    zT_81 = zig_wrap_add_u(((zu64)(zT_78)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(zT_78)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    zT_69 = zT_81;
    zT_70 = lmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_64, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6005_MEMORY_LEAK)), (unsigned int)(0), zT_68, zT_69, zT_70);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_89 = state;
    zT_90 = lhs_name_id;
    zT_92 = zT_480593AB_AllocState_allocated;
    zT_91 = zT_92;
    zF_ACCFA860_stateMapSet(zT_89, zT_90, zT_91);
    return;
    z_bb_8:
    if ((unsigned char)(rhs_idx != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_96 = ctx->store;
    zT_97 = rhs_idx;
    zT_99 = zF_FCDD1D35_astStoreNodeAt(zT_96, zT_97);
    rhs_node = zT_99;
    zT_100 = rhs_node.kind;
    if ((unsigned char)(zT_100 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_108 = state;
    zT_109 = lhs_name_id;
    zT_111 = zT_480593AB_AllocState_unknown;
    zT_110 = zT_111;
    zF_ACCFA860_stateMapSet(zT_108, zT_109, zT_110);
    return;
    z_bb_11:
    zT_104 = state;
    zT_105 = lhs_name_id;
    zT_107 = zT_480593AB_AllocState_untracked;
    zT_106 = zT_107;
    zF_ACCFA860_stateMapSet(zT_104, zT_105, zT_106);
    return;
    z_bb_12:
    goto z_bb_10;
}

/* handleOwnershipReturn */
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int ret_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_2C0927B0_StateMap* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_43E16BE5_Opt_8 zT_21;
    unsigned char zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_480593AB_AllocState zT_33;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_22A7C88B_AstNode node;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    if ((unsigned char)(ret_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = ret_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = state;
    zT_17 = ctx->store;
    zT_18 = ret_expr_idx;
    zT_20 = zF_2E24BD6B_identNameId(zT_17, zT_18);
    zT_16 = zT_20;
    zT_21 = zF_2EC17ECC_stateMapGet(zT_15, zT_16);
    current = zT_21;
    zT_22 = current.has_value;
    if (zT_22) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    if (!(current.has_value)) { pal_trap(); }
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = ret_expr_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_33 = zT_480593AB_AllocState_returned_val;
    zT_28 = zT_33;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* handleOwnershipPass */
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int fn_call_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35;
    zT_8143F551_AstKind zT_36;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_44;
    zT_2C0927B0_StateMap* zT_46;
    unsigned int zT_47;
    zT_43E16BE5_Opt_8 zT_48;
    unsigned char zT_49;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_480593AB_AllocState zT_56;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_D3EB6303_StringInterner* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    int zT_81;
    unsigned char zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned char zT_88;
    unsigned char zT_89;
    unsigned char zT_92;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    unsigned char zT_94;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_119;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zT_22A7C88B_AstNode node;
    unsigned int args_n;
    unsigned int ai;
    unsigned int args_i;
    zT_22A7C88B_AstNode arg_node;
    unsigned int arg_name_id;
    zT_43E16BE5_Opt_8 current;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmsg;
    unsigned char warn_lvl;
    if ((unsigned char)(fn_call_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = fn_call_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_15 = ctx->store;
    zT_16 = fn_call_idx;
    zT_18 = zF_152E19CB_astStoreNodeExtraCh(zT_15, zT_16);
    args_n = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    ai = zT_21;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = ctx->store;
    zT_26 = fn_call_idx;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_25, zT_26, (unsigned int)((unsigned int)ai));
    args_i = zT_30;
    zT_32 = ctx->store;
    zT_33 = args_i;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    arg_node = zT_35;
    zT_36 = arg_node.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    zT_114 = 1;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zig_wrap_add_u(((zu64)(ai)), ((zu64)(zT_115)), 32u);
    zT_117 = zig_overflow_flag_add_u(((zu64)(ai)), ((zu64)(zT_115)), 32u);
    zT_119 = zT_117 == (unsigned int)(0);
    if (!(zT_119)) { pal_trap(); }
    ai = zT_116;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_41 = ctx->store;
    zT_42 = args_i;
    zT_44 = zF_2E24BD6B_identNameId(zT_41, zT_42);
    arg_name_id = zT_44;
    zT_46 = state;
    zT_47 = arg_name_id;
    zT_48 = zF_2EC17ECC_stateMapGet(zT_46, zT_47);
    current = zT_48;
    zT_49 = current.has_value;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    if (!(current.has_value)) { pal_trap(); }
    c = current.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_8;
    z_bb_13:
    zT_53 = state;
    zT_54 = arg_name_id;
    zT_56 = zT_480593AB_AllocState_transferred;
    zT_55 = zT_56;
    zF_ACCFA860_stateMapSet(zT_53, zT_54, zT_55);
    zT_58 = ctx->interner;
    zT_59 = arg_name_id;
    zT_61 = zF_9134020D_stringInternerGet(zT_58, zT_59);
    pn = zT_61;
    zT_63 = "ownership of '";
    zT_65 = 14;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    tp1 = zT_64;
    zT_67 = "' transferred to function";
    zT_69 = 25;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    tp2 = zT_68;
    zT_72 = 0;
    zT_71[zT_72] = tp1;
    zT_73 = 1;
    zT_71[zT_73] = pn;
    zT_74 = 2;
    zT_71[zT_74] = tp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tparts[_i] = zT_71[_i];
        _i++;
    }
}
    zT_79 = ctx->diag;
    zT_76 = zT_79->interner;
    zT_81 = 0;
    zT_83 = (unsigned int)zT_81 < (unsigned int)(3);
    if (!(zT_83)) { pal_trap(); }
    zT_84 = tparts + zT_81;
    zT_77 = zT_84;
    zT_86 = zF_8C4BFF7C_diagnosticBuilderMa(zT_76, zT_77, (unsigned int)(3));
    tmsg = zT_86;
    zT_88 = 2;
    warn_lvl = zT_88;
    zT_89 = ctx->warn_all;
    if ((unsigned char)(zT_89 != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = 1;
    warn_lvl = zT_92;
    goto z_bb_16;
    z_bb_16:
    zT_93 = ctx->diag;
    zT_94 = warn_lvl;
    zT_97 = node.span_start;
    zT_106 = node.span_start;
    zT_107 = node.span_len;
    zT_108 = (unsigned int)zT_107;
    zT_109 = zig_wrap_add_u(((zu64)(zT_106)), ((zu64)(zT_108)), 32u);
    zT_110 = zig_overflow_flag_add_u(((zu64)(zT_106)), ((zu64)(zT_108)), 32u);
    zT_112 = zT_110 == (unsigned int)(0);
    if (!(zT_112)) { pal_trap(); }
    zT_98 = zT_109;
    zT_99 = tmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_93, zT_94, (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_INFO_7001_OWNERSHIP_TRANSFERRED)), (unsigned int)(0), zT_97, zT_98, zT_99);
    goto z_bb_14;
}

/* deferQueueEnsureCapacity */
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext* ctx, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_FDFD82FD_EU_362 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_7A19C4A5_DeferEntry* zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_7A19C4A5_DeferEntry* zT_44;
    zT_7A19C4A5_DeferEntry zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    unsigned int nc;
    unsigned char* raw;
    zT_7A19C4A5_DeferEntry* new_items;
    unsigned int i;
    zT_2 = ctx->defer_queue_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = ctx->defer_queue_cap;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(nc < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = ctx->defer_queue_cap;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    nc = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_23 = ctx->defer_queue_alloc;
    zT_27 = 12;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_35;
    zT_38 = (zT_7A19C4A5_DeferEntry*)raw;
    new_items = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    i = zT_41;
    goto z_bb_10;
    z_bb_10:
    zT_42 = ctx->defer_queue_len;
    if ((unsigned char)(i < zT_42)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_44 = ctx->defer_queue_items;
    zT_45 = zT_44[i];
    new_items[i] = zT_45;
    goto z_bb_13;
    z_bb_12:
    ctx->defer_queue_items = new_items;
    ctx->defer_queue_cap = nc;
    return;
    z_bb_13:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    i = zT_48;
    goto z_bb_10;
}

/* resetDeferQueue */
void zF_61F0EB83_resetDeferQueue(zT_7E2F335A_AnalyzerContext* ctx) {
    int zT_1;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    ctx->defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_1;
    ctx->defer_queue_len = (unsigned int)(0);
    ctx->defer_queue_cap = (unsigned int)(0);
    return;
}

/* analyzeSignature */
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6;
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_17;
    zT_5838FCFA_anon_324009 zT_18;
    zT_243D6A41_FnProto* zT_19;
    unsigned int zT_20;
    zT_243D6A41_FnProto zT_21;
    unsigned int zT_23;
    zT_79FAE712_u64 zT_24;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned short zT_32;
    zT_79FAE712_u64 zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    zT_79FAE712_u64 zT_37;
    unsigned int zT_39;
    int zT_41;
    unsigned int zT_42;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_55;
    unsigned int zT_57;
    zT_7E2F335A_AnalyzerContext* zT_60;
    unsigned int zT_61;
    zT_7E2F335A_AnalyzerContext* zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_73;
    zT_7E2F335A_AnalyzerContext* zT_76;
    unsigned int zT_77;
    zT_7E2F335A_AnalyzerContext* zT_80;
    unsigned int zT_81;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zT_22A7C88B_AstNode node;
    unsigned int proto_idx;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 param_payload;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned int type_expr;
    unsigned int ret_node;
    zT_3 = ctx->store;
    zT_4 = fn_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = fn_node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    proto_idx = zT_15;
    zT_17 = ctx->store;
    zT_18 = zT_17->fn_protos;
    zT_19 = zT_18.items;
    zT_20 = (unsigned int)proto_idx;
    zT_21 = zT_19[zT_20];
    proto = zT_21;
    zT_23 = proto.params_start;
    zT_24 = (zT_79FAE712_u64)zT_23;
    zT_25 = 32;
    zT_28 = zT_25 < (unsigned int)(64);
    if (!(zT_28)) { pal_trap(); }
    zT_26 = zig_wrap_shl_u(((zu64)(zT_24)), ((zu64)(zT_25)), 64u);
    zT_29 = zig_overflow_flag_shl_u(((zu64)(zT_24)), ((zu64)(zT_25)), 64u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_32 = proto.params_count;
    zT_34 = zT_26 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_32);
    param_payload = zT_34;
    zT_36 = ctx->store;
    zT_37 = param_payload;
    zT_39 = zF_03CE8CAB_astStoreGetExtraChi(zT_36, zT_37);
    params_n = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    pi = zT_42;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_46 = ctx->store;
    zT_49 = ctx->store;
    zT_50 = param_payload;
    zT_54 = zF_E5B10421_astStoreGetExtraChi(zT_49, zT_50, (unsigned int)((unsigned int)pi));
    zT_47 = zT_54;
    zT_55 = zF_FCDD1D35_astStoreNodeAt(zT_46, zT_47);
    pnode = zT_55;
    zT_57 = pnode.child_0;
    type_expr = zT_57;
    if ((unsigned char)(type_expr != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_73 = proto.return_type_node;
    ret_node = zT_73;
    if ((unsigned char)(ret_node != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_66 = 1;
    zT_67 = (unsigned int)zT_66;
    zT_68 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    pi = zT_68;
    goto z_bb_3;
    z_bb_7:
    zT_60 = ctx;
    zT_61 = type_expr;
    zF_E153ECE7_validateSignatureTy(zT_60, zT_61, (unsigned int)(0));
    goto z_bb_8;
    z_bb_8:
    zT_64 = ctx;
    zT_65 = type_expr;
    zF_11BB0278_rejectAnytypeType(zT_64, zT_65);
    goto z_bb_6;
    z_bb_9:
    zT_76 = ctx;
    zT_77 = ret_node;
    zF_E153ECE7_validateSignatureTy(zT_76, zT_77, (unsigned int)(1));
    goto z_bb_10;
    z_bb_10:
    zT_80 = ctx;
    zT_81 = ret_node;
    zF_11BB0278_rejectAnytypeType(zT_80, zT_81);
    return;
}

/* rejectAnytypeType */
void zF_11BB0278_rejectAnytypeType(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_27;
    zT_F85C5DED_DiagnosticCollector* zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned char zT_63;
    unsigned char zT_67;
    unsigned char zT_71;
    unsigned char zT_75;
    zT_7E2F335A_AnalyzerContext* zT_79;
    unsigned int zT_80;
    zT_7E2F335A_AnalyzerContext* zT_85;
    unsigned int zT_86;
    zT_7E2F335A_AnalyzerContext* zT_88;
    unsigned int zT_89;
    zT_7E2F335A_AnalyzerContext* zT_94;
    unsigned int zT_95;
    zT_6B0A7D14_AstStore* zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    zT_7E2F335A_AnalyzerContext* zT_113;
    unsigned int zT_114;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_107, (unsigned int)sizeof zT_107);
    zig_poison_fill((void*)&zT_120, (unsigned int)sizeof zT_120);
    zT_22A7C88B_AstNode tnode;
    zT_8143F551_AstKind kind;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    unsigned int ft_n;
    unsigned int ft_i;
    if ((unsigned char)(type_node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = ctx->store;
    zT_6 = type_node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    tnode = zT_8;
    zT_10 = tnode.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx->store;
    zT_16 = type_node_idx;
    zT_18 = zF_2E24BD6B_identNameId(zT_15, zT_16);
    name_id = zT_18;
    zT_20 = "anytype";
    zT_22 = 7;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    s_anytype = zT_21;
    zT_24 = ctx->interner;
    zT_25 = s_anytype;
    zT_27 = zF_50C274AF_stringInternerInter(zT_24, zT_25);
    anytype_nid = zT_27;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_10; else goto z_bb_9;
    z_bb_5:
    zT_29 = ctx->diag;
    zT_30 = type_node_idx;
    zT_32 = zF_4DD9DB2D_diagnosticCollector(zT_29, zT_30);
    if ((unsigned char)(!zT_32)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    return;
    z_bb_8:
    zT_35 = "anytype not supported in Z98";
    zT_37 = 28;
    zT_36.ptr = (unsigned char*)zT_35;
    zT_36.len = zT_37;
    amsg = zT_36;
    zT_38 = ctx->diag;
    zT_41 = ctx->source_file_id;
    zT_42 = tnode.span_start;
    zT_52 = tnode.span_start;
    zT_53 = tnode.span_len;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(zT_52)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(zT_52)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    zT_43 = zT_55;
    zT_44 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_38, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), zT_41, zT_42, zT_43, zT_44);
    goto z_bb_6;
    z_bb_9:
    zT_63 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_67 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_14;
    z_bb_13:
    zT_67 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_67) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_71 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_17;
    z_bb_16:
    zT_71 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_71) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_75 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_20;
    z_bb_19:
    zT_75 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_75) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_79 = ctx;
    zT_80 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_79, zT_80);
    return;
    z_bb_22:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_85 = ctx;
    zT_86 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_85, zT_86);
    zT_88 = ctx;
    zT_89 = tnode.child_1;
    zF_11BB0278_rejectAnytypeType(zT_88, zT_89);
    return;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_94 = ctx;
    zT_95 = tnode.child_0;
    zF_11BB0278_rejectAnytypeType(zT_94, zT_95);
    zT_97 = ctx->store;
    zT_98 = type_node_idx;
    zT_100 = zF_8BA26B9E_astStoreNodePayload(zT_97, zT_98);
    if ((unsigned char)(zT_100 != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    return;
    z_bb_27:
    zT_104 = ctx->store;
    zT_105 = type_node_idx;
    zT_107 = zF_152E19CB_astStoreNodeExtraCh(zT_104, zT_105);
    ft_n = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    ft_i = zT_110;
    goto z_bb_29;
    z_bb_28:
    return;
    z_bb_29:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_113 = ctx;
    zT_115 = ctx->store;
    zT_116 = type_node_idx;
    zT_120 = zF_B10B1BC1_astStoreNodeExtraCh(zT_115, zT_116, (unsigned int)((unsigned int)ft_i));
    zT_114 = zT_120;
    zF_11BB0278_rejectAnytypeType(zT_113, zT_114);
    goto z_bb_32;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = zig_wrap_add_u(((zu64)(ft_i)), ((zu64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(ft_i)), ((zu64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    ft_i = zT_123;
    goto z_bb_29;
}

/* validateSignatureNamed */
void zF_C745AF68_validateSignatureNa(zT_7E2F335A_AnalyzerContext* ctx, unsigned int name_id, unsigned int tnode_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8;
    zT_79FAE712_u64 zT_10;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_BAEE192E_Opt_10 zT_15;
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    unsigned char zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    unsigned char zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_52;
    unsigned char zT_53;
    zT_D3EB6303_StringInterner* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_F85C5DED_DiagnosticCollector* zT_86;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned char zT_106;
    zT_33EF6BFB_TypeKind zT_108;
    unsigned char zT_112;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_F85C5DED_DiagnosticCollector* zT_119;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned char zT_139;
    unsigned int zT_143;
    unsigned char* zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    unsigned int zT_149;
    zT_F85C5DED_DiagnosticCollector* zT_150;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned char zT_170;
    zT_D3EB6303_StringInterner* zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned char zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned char* zT_181;
    unsigned int zT_183;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_D3EB6303_StringInterner* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_194;
    zT_F85C5DED_DiagnosticCollector* zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_F85C5DED_DiagnosticCollector* zT_205;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_176, (unsigned int)sizeof zT_176);
    zig_poison_fill((void*)&zT_183, (unsigned int)sizeof zT_183);
    zig_poison_fill((void*)&zT_194, (unsigned int)sizeof zT_194);
    zig_poison_fill((void*)&zT_199, (unsigned int)sizeof zT_199);
    zT_22A7C88B_AstNode tnode;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 tid;
    unsigned int ttid;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_anytype;
    unsigned int anytype_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u t5_text;
    unsigned char t5_au;
    unsigned int t5_aw;
    zT_8F083A69_Slice_zT_0B42B2F8_u tname;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ip2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli iparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u imsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u wmsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u amsg;
    zT_5 = ctx->store;
    zT_6 = tnode_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    tnode = zT_8;
    zT_10 = (zT_79FAE712_u64)name_id;
    key = zT_10;
    zT_12 = ctx->registry;
    zT_13 = key;
    zT_15 = zF_0EB68360_nameCacheGet(zT_12, zT_13);
    tid = zT_15;
    zT_16 = tid.has_value;
    if (zT_16) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    if (!(tid.has_value)) { pal_trap(); }
    ttid = tid.value;
    zT_19 = ctx->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)ttid;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_5; else goto z_bb_4;
    z_bb_2:
    zT_187 = "anytype";
    zT_189 = 7;
    zT_188.ptr = (unsigned char*)zT_187;
    zT_188.len = zT_189;
    s_anytype = zT_188;
    zT_191 = ctx->interner;
    zT_192 = s_anytype;
    zT_194 = zF_50C274AF_stringInternerInter(zT_191, zT_192);
    anytype_nid = zT_194;
    if ((unsigned char)(name_id == anytype_nid)) goto z_bb_35; else goto z_bb_36;
    z_bb_3:
    zT_173 = ctx->interner;
    zT_174 = name_id;
    zT_176 = zF_9134020D_stringInternerGet(zT_173, zT_174);
    t5_text = zT_176;
    zT_178 = 0;
    t5_au = zT_178;
    zT_180 = t5_text;
    zT_181 = (unsigned char*)&t5_au;
    zT_183 = zF_741B5264_parseArbIntWidth(zT_180, zT_181);
    t5_aw = zT_183;
    if ((unsigned char)(t5_aw != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_4:
    zT_28 = ty.kind;
    if ((unsigned char)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_8; else goto z_bb_7;
    z_bb_5:
    zT_27 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_27) goto z_bb_22; else goto z_bb_23;
    z_bb_7:
    zT_33 = ty.kind;
    zT_32 = zT_33 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_32 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_32) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_38 = ty.kind;
    zT_37 = zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_12;
    z_bb_11:
    zT_37 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_37) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_43 = ty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_42 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_42) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_48 = ty.kind;
    zT_47 = zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_18;
    z_bb_17:
    zT_47 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_47) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_53 = ty.state;
    zT_52 = zT_53 != (unsigned char)(2);
    goto z_bb_21;
    z_bb_20:
    zT_52 = 0;
    goto z_bb_21;
    z_bb_21:
    zT_27 = zT_52;
    goto z_bb_6;
    z_bb_22:
    zT_57 = ctx->interner;
    zT_58 = name_id;
    zT_60 = zF_9134020D_stringInternerGet(zT_57, zT_58);
    tname = zT_60;
    zT_62 = "incomplete type '";
    zT_64 = 17;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    ip1 = zT_63;
    zT_66 = "' in function signature";
    zT_68 = 23;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    ip2 = zT_67;
    zT_71 = 0;
    zT_70[zT_71] = ip1;
    zT_72 = 1;
    zT_70[zT_72] = tname;
    zT_73 = 2;
    zT_70[zT_73] = ip2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        iparts[_i] = zT_70[_i];
        _i++;
    }
}
    zT_78 = ctx->diag;
    zT_75 = zT_78->interner;
    zT_80 = 0;
    zT_82 = (unsigned int)zT_80 < (unsigned int)(3);
    if (!(zT_82)) { pal_trap(); }
    zT_83 = iparts + zT_80;
    zT_76 = zT_83;
    zT_85 = zF_8C4BFF7C_diagnosticBuilderMa(zT_75, zT_76, (unsigned int)(3));
    imsg = zT_85;
    zT_86 = ctx->diag;
    zT_90 = tnode.span_start;
    zT_100 = tnode.span_start;
    zT_101 = tnode.span_len;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zig_wrap_add_u(((zu64)(zT_100)), ((zu64)(zT_102)), 32u);
    zT_104 = zig_overflow_flag_add_u(((zu64)(zT_100)), ((zu64)(zT_102)), 32u);
    zT_106 = zT_104 == (unsigned int)(0);
    if (!(zT_106)) { pal_trap(); }
    zT_91 = zT_103;
    zT_92 = imsg;
    (void)zF_C82559AC_diagnosticCollector(zT_86, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2011_INCOMPLETE_TYPE)), (unsigned int)(0), zT_90, zT_91, zT_92);
    goto z_bb_23;
    z_bb_23:
    zT_108 = ty.kind;
    if ((unsigned char)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_112 = is_return == (unsigned int)(0);
    goto z_bb_26;
    z_bb_25:
    zT_112 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_112) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_116 = "void not allowed as parameter type";
    zT_118 = 34;
    zT_117.ptr = (unsigned char*)zT_116;
    zT_117.len = zT_118;
    vmsg = zT_117;
    zT_119 = ctx->diag;
    zT_123 = tnode.span_start;
    zT_133 = tnode.span_start;
    zT_134 = tnode.span_len;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zig_wrap_add_u(((zu64)(zT_133)), ((zu64)(zT_135)), 32u);
    zT_137 = zig_overflow_flag_add_u(((zu64)(zT_133)), ((zu64)(zT_135)), 32u);
    zT_139 = zT_137 == (unsigned int)(0);
    if (!(zT_139)) { pal_trap(); }
    zT_124 = zT_136;
    zT_125 = vmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_119, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2010_VOID_PARAMETER)), (unsigned int)(0), zT_123, zT_124, zT_125);
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(is_return == (unsigned int)(1))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_143 = ty.size;
    if ((unsigned char)(zT_143 > (unsigned int)(64))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_2;
    z_bb_31:
    zT_147 = "return type exceeds 64 bytes; may cause issues on MSVC 6.0";
    zT_149 = 58;
    zT_148.ptr = (unsigned char*)zT_147;
    zT_148.len = zT_149;
    wmsg = zT_148;
    zT_150 = ctx->diag;
    zT_154 = tnode.span_start;
    zT_164 = tnode.span_start;
    zT_165 = tnode.span_len;
    zT_166 = (unsigned int)zT_165;
    zT_167 = zig_wrap_add_u(((zu64)(zT_164)), ((zu64)(zT_166)), 32u);
    zT_168 = zig_overflow_flag_add_u(((zu64)(zT_164)), ((zu64)(zT_166)), 32u);
    zT_170 = zT_168 == (unsigned int)(0);
    if (!(zT_170)) { pal_trap(); }
    zT_155 = zT_167;
    zT_156 = wmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_150, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7010_LARGE_RETURN)), (unsigned int)(0), zT_154, zT_155, zT_156);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    return;
    z_bb_34:
    goto z_bb_2;
    z_bb_35:
    zT_196 = ctx->diag;
    zT_197 = tnode_idx;
    zT_199 = zF_4DD9DB2D_diagnosticCollector(zT_196, zT_197);
    if ((unsigned char)(!zT_199)) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    return;
    z_bb_37:
    return;
    z_bb_38:
    zT_202 = "anytype not supported in Z98";
    zT_204 = 28;
    zT_203.ptr = (unsigned char*)zT_202;
    zT_203.len = zT_204;
    amsg = zT_203;
    zT_205 = ctx->diag;
    zT_208 = ctx->source_file_id;
    zT_209 = tnode.span_start;
    zT_219 = tnode.span_start;
    zT_220 = tnode.span_len;
    zT_221 = (unsigned int)zT_220;
    zT_222 = zig_wrap_add_u(((zu64)(zT_219)), ((zu64)(zT_221)), 32u);
    zT_223 = zig_overflow_flag_add_u(((zu64)(zT_219)), ((zu64)(zT_221)), 32u);
    zT_225 = zT_223 == (unsigned int)(0);
    if (!(zT_225)) { pal_trap(); }
    zT_210 = zT_222;
    zT_211 = amsg;
    (void)zF_C82559AC_diagnosticCollector(zT_205, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2012_ANYTYPE_NOT_SUPPORTED)), zT_208, zT_209, zT_210, zT_211);
    goto z_bb_36;
}

/* validateSignatureType */
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_node_idx, unsigned int is_return) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_7E2F335A_AnalyzerContext* zT_26;
    unsigned int zT_27;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_37;
    unsigned int zT_38;
    zT_7E2F335A_AnalyzerContext* zT_42;
    unsigned int zT_43;
    unsigned char zT_50;
    unsigned char zT_54;
    unsigned char zT_58;
    zT_7E2F335A_AnalyzerContext* zT_62;
    unsigned int zT_63;
    zT_7E2F335A_AnalyzerContext* zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_78;
    zT_6B0A7D14_AstStore* zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    int zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_97;
    zT_7E2F335A_AnalyzerContext* zT_98;
    unsigned int zT_99;
    zT_7E2F335A_AnalyzerContext* zT_102;
    unsigned int zT_103;
    int zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned char zT_109;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    zT_7E2F335A_AnalyzerContext* zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zT_22A7C88B_AstNode tnode;
    zT_8143F551_AstKind kind;
    unsigned int ft_n;
    unsigned int ft_i;
    unsigned int ft_p;
    unsigned int t5_mname;
    if ((unsigned char)(type_node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = type_node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    tnode = zT_9;
    zT_11 = tnode.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_19 = ctx->store;
    zT_20 = type_node_idx;
    zT_22 = zF_2E24BD6B_identNameId(zT_19, zT_20);
    zT_16 = zT_22;
    zT_17 = type_node_idx;
    zT_18 = is_return;
    zF_C745AF68_validateSignatureNa(zT_15, zT_16, zT_17, zT_18);
    return;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_26 = ctx;
    zT_27 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_26, zT_27, (unsigned int)(2));
    return;
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = tnode.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_12; else goto z_bb_11;
    z_bb_9:
    zT_37 = ctx;
    zT_38 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_37, zT_38, (unsigned int)(2));
    goto z_bb_10;
    z_bb_10:
    zT_42 = ctx;
    zT_43 = tnode.child_1;
    zF_E153ECE7_validateSignatureTy(zT_42, zT_43, (unsigned int)(2));
    return;
    z_bb_11:
    zT_50 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_13;
    z_bb_12:
    zT_50 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_50) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_54 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_16;
    z_bb_15:
    zT_54 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_54) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_58 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_19;
    z_bb_18:
    zT_58 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_58) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = ctx;
    zT_63 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_62, zT_63, (unsigned int)(2));
    return;
    z_bb_21:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_70 = ctx;
    zT_71 = tnode.child_0;
    zF_E153ECE7_validateSignatureTy(zT_70, zT_71, (unsigned int)(1));
    zT_75 = ctx->store;
    zT_76 = type_node_idx;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_75, zT_76);
    if ((unsigned char)(zT_78 != (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_30; else goto z_bb_31;
    z_bb_24:
    zT_82 = ctx->store;
    zT_83 = type_node_idx;
    zT_85 = zF_152E19CB_astStoreNodeExtraCh(zT_82, zT_83);
    ft_n = zT_85;
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    ft_i = zT_88;
    goto z_bb_26;
    z_bb_25:
    return;
    z_bb_26:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = ctx->store;
    zT_93 = type_node_idx;
    zT_97 = zF_B10B1BC1_astStoreNodeExtraCh(zT_92, zT_93, (unsigned int)((unsigned int)ft_i));
    ft_p = zT_97;
    zT_98 = ctx;
    zT_99 = ft_p;
    zF_E153ECE7_validateSignatureTy(zT_98, zT_99, (unsigned int)(2));
    zT_102 = ctx;
    zT_103 = ft_p;
    zF_11BB0278_rejectAnytypeType(zT_102, zT_103);
    goto z_bb_29;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_104 = 1;
    zT_105 = (unsigned int)zT_104;
    zT_106 = zig_wrap_add_u(((zu64)(ft_i)), ((zu64)(zT_105)), 32u);
    zT_107 = zig_overflow_flag_add_u(((zu64)(ft_i)), ((zu64)(zT_105)), 32u);
    zT_109 = zT_107 == (unsigned int)(0);
    if (!(zT_109)) { pal_trap(); }
    ft_i = zT_106;
    goto z_bb_26;
    z_bb_30:
    zT_114 = ctx->store;
    zT_115 = type_node_idx;
    zT_117 = zF_8BA26B9E_astStoreNodePayload(zT_114, zT_115);
    t5_mname = zT_117;
    if ((unsigned char)(t5_mname != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    return;
    z_bb_32:
    zT_120 = ctx;
    zT_121 = t5_mname;
    zT_122 = type_node_idx;
    zT_123 = is_return;
    zF_C745AF68_validateSignatureNa(zT_120, zT_121, zT_122, zT_123);
    goto z_bb_33;
    z_bb_33:
    return;
}

/* analyzeExpr */
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_F85C5DED_DiagnosticCollector* zT_37;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    zT_7E2F335A_AnalyzerContext* zT_94;
    zT_2C0927B0_StateMap* zT_95;
    unsigned int zT_96;
    zT_7E2F335A_AnalyzerContext* zT_101;
    zT_2C0927B0_StateMap* zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    unsigned int zT_112;
    int zT_114;
    unsigned int zT_115;
    zT_7E2F335A_AnalyzerContext* zT_118;
    zT_2C0927B0_StateMap* zT_119;
    unsigned int zT_120;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_126;
    int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_132;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_138;
    unsigned int zT_140;
    int zT_142;
    unsigned int zT_143;
    zT_7E2F335A_AnalyzerContext* zT_146;
    zT_2C0927B0_StateMap* zT_147;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_149;
    unsigned int zT_150;
    unsigned int zT_154;
    int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned char zT_160;
    zT_7E2F335A_AnalyzerContext* zT_165;
    unsigned int zT_166;
    int zT_169;
    zT_49E17557_Opt_2 zT_171;
    unsigned char zT_172;
    zT_6B0A7D14_AstStore* zT_174;
    unsigned int zT_175;
    unsigned int zT_177;
    zT_7E2F335A_AnalyzerContext* zT_180;
    zT_2C0927B0_StateMap* zT_181;
    unsigned int zT_182;
    unsigned int zT_184;
    zT_7E2F335A_AnalyzerContext* zT_187;
    zT_2C0927B0_StateMap* zT_188;
    unsigned int zT_189;
    zT_7E2F335A_AnalyzerContext* zT_191;
    zT_2C0927B0_StateMap* zT_192;
    unsigned int zT_193;
    zT_6B0A7D14_AstStore* zT_196;
    unsigned int zT_197;
    unsigned int zT_199;
    zT_2C0927B0_StateMap* zT_203;
    zT_3E40CD83_Sand* zT_204;
    zT_2C0927B0_StateMap* zT_206;
    zT_7E2F335A_AnalyzerContext* zT_207;
    zT_2C0927B0_StateMap* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_7E2F335A_AnalyzerContext* zT_212;
    zT_2C0927B0_StateMap* zT_213;
    unsigned int zT_214;
    zT_7E2F335A_AnalyzerContext* zT_216;
    zT_2C0927B0_StateMap* zT_217;
    unsigned int zT_218;
    unsigned int zT_220;
    zT_7E2F335A_AnalyzerContext* zT_223;
    zT_2C0927B0_StateMap* zT_224;
    unsigned int zT_225;
    zT_7E2F335A_AnalyzerContext* zT_230;
    zT_2C0927B0_StateMap* zT_231;
    unsigned int zT_232;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    zT_22A7C88B_AstNode zT_244;
    zT_8143F551_AstKind zT_245;
    zT_6B0A7D14_AstStore* zT_249;
    unsigned int zT_250;
    unsigned int zT_253;
    zT_2C0927B0_StateMap* zT_257;
    zT_3E40CD83_Sand* zT_258;
    zT_2C0927B0_StateMap* zT_260;
    zT_7E2F335A_AnalyzerContext* zT_261;
    zT_2C0927B0_StateMap* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    zT_7E2F335A_AnalyzerContext* zT_266;
    zT_2C0927B0_StateMap* zT_267;
    unsigned int zT_268;
    zT_7E2F335A_AnalyzerContext* zT_270;
    zT_2C0927B0_StateMap* zT_271;
    unsigned int zT_272;
    zT_7E2F335A_AnalyzerContext* zT_277;
    zT_2C0927B0_StateMap* zT_278;
    unsigned int zT_279;
    zT_6B0A7D14_AstStore* zT_282;
    unsigned int zT_283;
    zT_22A7C88B_AstNode zT_286;
    zT_8143F551_AstKind zT_287;
    zT_7E2F335A_AnalyzerContext* zT_292;
    zT_2C0927B0_StateMap* zT_293;
    unsigned int zT_294;
    unsigned char zT_296;
    zT_2C0927B0_StateMap* zT_297;
    unsigned int zT_298;
    unsigned char zT_299;
    zT_6B0A7D14_AstStore* zT_300;
    unsigned int zT_301;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char zT_308;
    zT_8143F551_AstKind zT_309;
    unsigned char zT_312;
    zT_7E2F335A_AnalyzerContext* zT_313;
    zT_2C0927B0_StateMap* zT_314;
    unsigned int zT_315;
    unsigned int zT_317;
    unsigned char zT_320;
    zT_8143F551_AstKind zT_321;
    unsigned char zT_324;
    zT_7E2F335A_AnalyzerContext* zT_325;
    zT_2C0927B0_StateMap* zT_326;
    unsigned int zT_327;
    unsigned int zT_329;
    unsigned char zT_332;
    zT_8143F551_AstKind zT_333;
    unsigned char zT_336;
    zT_7E2F335A_AnalyzerContext* zT_337;
    zT_2C0927B0_StateMap* zT_338;
    unsigned int zT_339;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_112, (unsigned int)sizeof zT_112);
    zig_poison_fill((void*)&zT_126, (unsigned int)sizeof zT_126);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_154, (unsigned int)sizeof zT_154);
    zig_poison_fill((void*)&zT_171, (unsigned int)sizeof zT_171);
    zig_poison_fill((void*)&zT_177, (unsigned int)sizeof zT_177);
    zig_poison_fill((void*)&zT_199, (unsigned int)sizeof zT_199);
    zig_poison_fill((void*)&zT_206, (unsigned int)sizeof zT_206);
    zig_poison_fill((void*)&zT_244, (unsigned int)sizeof zT_244);
    zig_poison_fill((void*)&zT_253, (unsigned int)sizeof zT_253);
    zig_poison_fill((void*)&zT_260, (unsigned int)sizeof zT_260);
    zig_poison_fill((void*)&zT_286, (unsigned int)sizeof zT_286);
    zig_poison_fill((void*)&zT_296, (unsigned int)sizeof zT_296);
    zig_poison_fill((void*)&zT_304, (unsigned int)sizeof zT_304);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_324, (unsigned int)sizeof zT_324);
    zig_poison_fill((void*)&zT_336, (unsigned int)sizeof zT_336);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned char st;
    unsigned int start;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    unsigned int args_n;
    unsigned int ai;
    unsigned int bargs_n;
    unsigned int bi;
    zT_49E17557_Opt_2 t5_ief;
    unsigned char iev;
    unsigned int t5_iecap;
    zT_2C0927B0_StateMap* t5_ies;
    unsigned int t5_ecap;
    zT_22A7C88B_AstNode capn;
    zT_2C0927B0_StateMap* t5_ecs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned char new_st;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_11 = node.kind;
    kind = zT_11;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_0;
    zT_20 = zF_0619AC1C_classifyExpr(zT_16, zT_17, zT_18);
    st = zT_20;
    zT_22 = node.span_start;
    start = zT_22;
    zT_24 = node.span_start;
    zT_25 = node.span_len;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(zT_24)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(zT_24)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    end = zT_27;
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_is_null))) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_34 = "definite null pointer dereference";
    zT_36 = 33;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    msg = zT_35;
    zT_37 = ctx->diag;
    zT_41 = start;
    zT_42 = end;
    zT_43 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_37, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_2004_DEFINITE_NULL_DEREF)), (unsigned int)(0), zT_41, zT_42, zT_43);
    goto z_bb_6;
    z_bb_6:
    return;
    z_bb_7:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_uninit))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_54 = "dereference of uninitialized pointer";
    zT_56 = 36;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    msg = zT_55;
    zT_57 = ctx->diag;
    zT_61 = start;
    zT_62 = end;
    zT_63 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_57, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6001_UNINIT_DEREF)), (unsigned int)(0), zT_61, zT_62, zT_63);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(st == (zT_E48CAD8A_PtrState)(zT_E48CAD8A_PtrState_maybe))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_74 = "potential null pointer dereference";
    zT_76 = 34;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    msg = zT_75;
    zT_77 = ctx->diag;
    zT_81 = start;
    zT_82 = end;
    zT_83 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_77, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_6002_POTENTIAL_NULL_DEREF)), (unsigned int)(0), zT_81, zT_82, zT_83);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_94 = ctx;
    zT_95 = state;
    zT_96 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_94, zT_95, zT_96);
    return;
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_101 = ctx;
    zT_102 = state;
    zT_103 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_101, zT_102, zT_103);
    return;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_109 = ctx->store;
    zT_110 = expr_idx;
    zT_112 = zF_152E19CB_astStoreNodeExtraCh(zT_109, zT_110);
    args_n = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned int)zT_114;
    ai = zT_115;
    goto z_bb_19;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_23; else goto z_bb_24;
    z_bb_19:
    if ((unsigned char)(ai < (unsigned int)((unsigned int)args_n))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_118 = ctx;
    zT_119 = state;
    zT_121 = ctx->store;
    zT_122 = expr_idx;
    zT_126 = zF_B10B1BC1_astStoreNodeExtraCh(zT_121, zT_122, (unsigned int)((unsigned int)ai));
    zT_120 = zT_126;
    zF_8D5B6C98_analyzeExpr(zT_118, zT_119, zT_120);
    goto z_bb_22;
    z_bb_21:
    return;
    z_bb_22:
    zT_127 = 1;
    zT_128 = (unsigned int)zT_127;
    zT_129 = zig_wrap_add_u(((zu64)(ai)), ((zu64)(zT_128)), 32u);
    zT_130 = zig_overflow_flag_add_u(((zu64)(ai)), ((zu64)(zT_128)), 32u);
    zT_132 = zT_130 == (unsigned int)(0);
    if (!(zT_132)) { pal_trap(); }
    ai = zT_129;
    goto z_bb_19;
    z_bb_23:
    zT_137 = ctx->store;
    zT_138 = expr_idx;
    zT_140 = zF_152E19CB_astStoreNodeExtraCh(zT_137, zT_138);
    bargs_n = zT_140;
    zT_142 = 0;
    zT_143 = (unsigned int)zT_142;
    bi = zT_143;
    goto z_bb_25;
    z_bb_24:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_29; else goto z_bb_30;
    z_bb_25:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)bargs_n))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_146 = ctx;
    zT_147 = state;
    zT_149 = ctx->store;
    zT_150 = expr_idx;
    zT_154 = zF_B10B1BC1_astStoreNodeExtraCh(zT_149, zT_150, (unsigned int)((unsigned int)bi));
    zT_148 = zT_154;
    zF_8D5B6C98_analyzeExpr(zT_146, zT_147, zT_148);
    goto z_bb_28;
    z_bb_27:
    return;
    z_bb_28:
    zT_155 = 1;
    zT_156 = (unsigned int)zT_155;
    zT_157 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_156)), 32u);
    zT_158 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_156)), 32u);
    zT_160 = zT_158 == (unsigned int)(0);
    if (!(zT_160)) { pal_trap(); }
    bi = zT_157;
    goto z_bb_25;
    z_bb_29:
    zT_165 = ctx;
    zT_166 = node.child_0;
    zT_169 = 0;
    zT_171 = zF_A1341A8A_analyzerFoldComptim(zT_165, zT_166, (unsigned int)((unsigned int)zT_169));
    t5_ief = zT_171;
    zT_172 = t5_ief.has_value;
    if (zT_172) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_45; else goto z_bb_46;
    z_bb_31:
    if (!(t5_ief.has_value)) { pal_trap(); }
    iev = t5_ief.value;
    zT_174 = ctx->store;
    zT_175 = expr_idx;
    zT_177 = zF_8BA26B9E_astStoreNodePayload(zT_174, zT_175);
    if ((unsigned char)(zT_177 == (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_191 = ctx;
    zT_192 = state;
    zT_193 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_191, zT_192, zT_193);
    zT_196 = ctx->store;
    zT_197 = expr_idx;
    zT_199 = zF_CE47A44A_captureNameIdOf(zT_196, zT_197);
    t5_iecap = zT_199;
    if ((unsigned char)(t5_iecap != (unsigned int)(0))) goto z_bb_40; else goto z_bb_42;
    z_bb_33:
    if (iev) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_180 = ctx;
    zT_181 = state;
    zT_182 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_180, zT_181, zT_182);
    goto z_bb_36;
    z_bb_36:
    return;
    z_bb_37:
    zT_184 = node.child_2;
    if ((unsigned char)(zT_184 != (unsigned int)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_187 = ctx;
    zT_188 = state;
    zT_189 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_187, zT_188, zT_189);
    goto z_bb_39;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_203 = state;
    zT_204 = ctx->alloc;
    zT_206 = zF_77086C9C_stateMapFork(zT_203, zT_204);
    t5_ies = zT_206;
    zT_207 = ctx;
    zT_208 = t5_ies;
    zT_209 = t5_iecap;
    zT_210 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_207, zT_208, zT_209, zT_210);
    zT_212 = ctx;
    zT_213 = t5_ies;
    zT_214 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_212, zT_213, zT_214);
    goto z_bb_41;
    z_bb_41:
    zT_220 = node.child_2;
    if ((unsigned char)(zT_220 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_216 = ctx;
    zT_217 = state;
    zT_218 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_216, zT_217, zT_218);
    goto z_bb_41;
    z_bb_43:
    zT_223 = ctx;
    zT_224 = state;
    zT_225 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_223, zT_224, zT_225);
    goto z_bb_44;
    z_bb_44:
    return;
    z_bb_45:
    zT_230 = ctx;
    zT_231 = state;
    zT_232 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_230, zT_231, zT_232);
    zT_235 = 0;
    t5_ecap = zT_235;
    zT_236 = node.child_2;
    if ((unsigned char)(zT_236 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_54; else goto z_bb_55;
    z_bb_47:
    zT_240 = ctx->store;
    zT_241 = node.child_2;
    zT_244 = zF_FCDD1D35_astStoreNodeAt(zT_240, zT_241);
    capn = zT_244;
    zT_245 = capn.kind;
    if ((unsigned char)(zT_245 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_payload_capture))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    if ((unsigned char)(t5_ecap != (unsigned int)(0))) goto z_bb_51; else goto z_bb_53;
    z_bb_49:
    zT_249 = ctx->store;
    zT_250 = node.child_2;
    zT_253 = zF_8BA26B9E_astStoreNodePayload(zT_249, zT_250);
    t5_ecap = zT_253;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_257 = state;
    zT_258 = ctx->alloc;
    zT_260 = zF_77086C9C_stateMapFork(zT_257, zT_258);
    t5_ecs = zT_260;
    zT_261 = ctx;
    zT_262 = t5_ecs;
    zT_263 = t5_ecap;
    zT_264 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_261, zT_262, zT_263, zT_264);
    zT_266 = ctx;
    zT_267 = t5_ecs;
    zT_268 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_266, zT_267, zT_268);
    goto z_bb_52;
    z_bb_52:
    return;
    z_bb_53:
    zT_270 = ctx;
    zT_271 = state;
    zT_272 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_270, zT_271, zT_272);
    goto z_bb_52;
    z_bb_54:
    zT_277 = ctx;
    zT_278 = state;
    zT_279 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_277, zT_278, zT_279);
    zT_282 = ctx->store;
    zT_283 = node.child_0;
    zT_286 = zF_FCDD1D35_astStoreNodeAt(zT_282, zT_283);
    lhs_node = zT_286;
    zT_287 = lhs_node.kind;
    if ((unsigned char)(zT_287 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_305 = node.child_0;
    if ((unsigned char)(zT_305 != (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    zT_292 = ctx;
    zT_293 = state;
    zT_294 = node.child_1;
    zT_296 = zF_0619AC1C_classifyExpr(zT_292, zT_293, zT_294);
    new_st = zT_296;
    zT_297 = state;
    zT_300 = ctx->store;
    zT_301 = node.child_0;
    zT_304 = zF_2E24BD6B_identNameId(zT_300, zT_301);
    zT_298 = zT_304;
    zT_299 = new_st;
    zF_ACCFA860_stateMapSet(zT_297, zT_298, zT_299);
    goto z_bb_57;
    z_bb_57:
    return;
    z_bb_58:
    zT_309 = kind;
    zT_312 = zF_C395F6FD_nodeChildIsNode(zT_309, (unsigned char)(0));
    zT_308 = zT_312;
    goto z_bb_60;
    z_bb_59:
    zT_308 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_308) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_313 = ctx;
    zT_314 = state;
    zT_315 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_313, zT_314, zT_315);
    goto z_bb_62;
    z_bb_62:
    zT_317 = node.child_1;
    if ((unsigned char)(zT_317 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_321 = kind;
    zT_324 = zF_C395F6FD_nodeChildIsNode(zT_321, (unsigned char)(1));
    zT_320 = zT_324;
    goto z_bb_65;
    z_bb_64:
    zT_320 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_320) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_325 = ctx;
    zT_326 = state;
    zT_327 = node.child_1;
    zF_8D5B6C98_analyzeExpr(zT_325, zT_326, zT_327);
    goto z_bb_67;
    z_bb_67:
    zT_329 = node.child_2;
    if ((unsigned char)(zT_329 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_333 = kind;
    zT_336 = zF_C395F6FD_nodeChildIsNode(zT_333, (unsigned char)(2));
    zT_332 = zT_336;
    goto z_bb_70;
    z_bb_69:
    zT_332 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_332) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_337 = ctx;
    zT_338 = state;
    zT_339 = node.child_2;
    zF_8D5B6C98_analyzeExpr(zT_337, zT_338, zT_339);
    goto z_bb_72;
    z_bb_72:
    return;
}

/* classifyExpr */
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int expr_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10;
    zT_8143F551_AstKind zT_12;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_79FAE712_u64 zT_44;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int zT_58;
    zT_43E16BE5_Opt_8 zT_59;
    unsigned char zT_60;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_79FAE712_u64 val;
    zT_43E16BE5_Opt_8 result;
    unsigned char v;
    if ((unsigned char)(expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(zT_E48CAD8A_PtrState_uninit);
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = expr_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = node.kind;
    kind = zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_6:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_14:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_41 = ctx->store;
    zT_42 = expr_idx;
    zT_44 = zF_678B9A72_astStoreIntValue(zT_41, zT_42);
    val = zT_44;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return (unsigned char)(zT_E48CAD8A_PtrState_is_null);
    z_bb_18:
    return (unsigned char)(zT_E48CAD8A_PtrState_safe);
    z_bb_19:
    zT_53 = state;
    zT_55 = ctx->store;
    zT_56 = expr_idx;
    zT_58 = zF_2E24BD6B_identNameId(zT_55, zT_56);
    zT_54 = zT_58;
    zT_59 = zF_2EC17ECC_stateMapGet(zT_53, zT_54);
    result = zT_59;
    zT_60 = result.has_value;
    if (zT_60) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    return (unsigned char)(zT_E48CAD8A_PtrState_maybe);
    z_bb_21:
    if (!(result.has_value)) { pal_trap(); }
    v = result.value;
    return v;
    z_bb_22:
    goto z_bb_20;
}

/* isNullExpr */
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_9;
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_79FAE712_u64 zT_21;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zT_22A7C88B_AstNode node;
    zT_79FAE712_u64 val;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = store;
    zT_20 = idx;
    zT_21 = zF_678B9A72_astStoreIntValue(zT_19, zT_20);
    val = zT_21;
    if ((unsigned char)(val == (zT_79FAE712_u64)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* isIdentExpr */
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_BAEE192E_Opt_10 zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_9;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zT_22A7C88B_AstNode node;
    if ((unsigned char)(idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_9 = node.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = store;
    zT_14 = idx;
    zT_15 = zF_2E24BD6B_identNameId(zT_13, zT_14);
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_4:
    zT_17.has_value = 0;
    return zT_17;
}

/* detectNullGuard */
zT_57CCFBBB_Opt_121 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore* store, unsigned int cond_idx) {
    zT_57CCFBBB_Opt_121 zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    int zT_19;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned char zT_26;
    zT_438E6589_NullGuard zT_28;
    unsigned char zT_29;
    zT_57CCFBBB_Opt_121 zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    int zT_36;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_42;
    unsigned char zT_43;
    zT_438E6589_NullGuard zT_45;
    unsigned char zT_46;
    zT_57CCFBBB_Opt_121 zT_47;
    zT_57CCFBBB_Opt_121 zT_48;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    int zT_57;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_BAEE192E_Opt_10 zT_63;
    unsigned char zT_64;
    zT_438E6589_NullGuard zT_66;
    unsigned char zT_67;
    zT_57CCFBBB_Opt_121 zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    int zT_74;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    zT_BAEE192E_Opt_10 zT_80;
    unsigned char zT_81;
    zT_438E6589_NullGuard zT_83;
    unsigned char zT_84;
    zT_57CCFBBB_Opt_121 zT_85;
    zT_57CCFBBB_Opt_121 zT_86;
    zT_438E6589_NullGuard zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    zT_57CCFBBB_Opt_121 zT_95;
    zT_6B0A7D14_AstStore* zT_100;
    unsigned int zT_101;
    zT_57CCFBBB_Opt_121 zT_103;
    unsigned char zT_104;
    zT_438E6589_NullGuard zT_106;
    unsigned int zT_107;
    int zT_108;
    unsigned char zT_109;
    unsigned char zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    unsigned char zT_114;
    zT_57CCFBBB_Opt_121 zT_115;
    zT_57CCFBBB_Opt_121 zT_116;
    zT_57CCFBBB_Opt_121 zT_117;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_80, (unsigned int)sizeof zT_80);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zT_22A7C88B_AstNode cond;
    zT_8143F551_AstKind ck;
    unsigned char n0;
    zT_BAEE192E_Opt_10 id1;
    unsigned char n1;
    unsigned int nid;
    zT_BAEE192E_Opt_10 id0;
    zT_57CCFBBB_Opt_121 inner;
    zT_438E6589_NullGuard g;
    if ((unsigned char)(cond_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_6 = store;
    zT_7 = cond_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    cond = zT_8;
    zT_10 = cond.kind;
    ck = zT_10;
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = store;
    zT_16 = cond.child_0;
    zT_18 = zF_F32BD543_isNullExpr(zT_15, zT_16);
    n0 = zT_18;
    zT_19 = 0;
    if ((unsigned char)(n0 != zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_13; else goto z_bb_14;
    z_bb_5:
    zT_22 = store;
    zT_23 = cond.child_1;
    zT_25 = zF_7B65B82E_isIdentExpr(zT_22, zT_23);
    id1 = zT_25;
    zT_26 = id1.has_value;
    if (zT_26) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_32 = store;
    zT_33 = cond.child_1;
    zT_35 = zF_F32BD543_isNullExpr(zT_32, zT_33);
    n1 = zT_35;
    zT_36 = 0;
    if ((unsigned char)(n1 != zT_36)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if (!(id1.has_value)) { pal_trap(); }
    nid = id1.value;
    zT_28.name_id = nid;
    zT_29 = 1;
    zT_28.is_not_null = zT_29;
    zT_30.has_value = 1;
    zT_30.value = zT_28;
    return zT_30;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_39 = store;
    zT_40 = cond.child_0;
    zT_42 = zF_7B65B82E_isIdentExpr(zT_39, zT_40);
    id0 = zT_42;
    zT_43 = id0.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_11:
    if (!(id0.has_value)) { pal_trap(); }
    nid = id0.value;
    zT_45.name_id = nid;
    zT_46 = 1;
    zT_45.is_not_null = zT_46;
    zT_47.has_value = 1;
    zT_47.value = zT_45;
    return zT_47;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_53 = store;
    zT_54 = cond.child_0;
    zT_56 = zF_F32BD543_isNullExpr(zT_53, zT_54);
    n0 = zT_56;
    zT_57 = 0;
    if ((unsigned char)(n0 != zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_24;
    z_bb_15:
    zT_60 = store;
    zT_61 = cond.child_1;
    zT_63 = zF_7B65B82E_isIdentExpr(zT_60, zT_61);
    id1 = zT_63;
    zT_64 = id1.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_70 = store;
    zT_71 = cond.child_1;
    zT_73 = zF_F32BD543_isNullExpr(zT_70, zT_71);
    n1 = zT_73;
    zT_74 = 0;
    if ((unsigned char)(n1 != zT_74)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if (!(id1.has_value)) { pal_trap(); }
    nid = id1.value;
    zT_66.name_id = nid;
    zT_67 = 0;
    zT_66.is_not_null = zT_67;
    zT_68.has_value = 1;
    zT_68.value = zT_66;
    return zT_68;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_77 = store;
    zT_78 = cond.child_0;
    zT_80 = zF_7B65B82E_isIdentExpr(zT_77, zT_78);
    id0 = zT_80;
    zT_81 = id0.has_value;
    if (zT_81) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_86.has_value = 0;
    return zT_86;
    z_bb_21:
    if (!(id0.has_value)) { pal_trap(); }
    nid = id0.value;
    zT_83.name_id = nid;
    zT_84 = 0;
    zT_83.is_not_null = zT_84;
    zT_85.has_value = 1;
    zT_85.value = zT_83;
    return zT_85;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_91 = store;
    zT_92 = cond_idx;
    zT_93 = zF_2E24BD6B_identNameId(zT_91, zT_92);
    zT_90.name_id = zT_93;
    zT_94 = 1;
    zT_90.is_not_null = zT_94;
    zT_95.has_value = 1;
    zT_95.value = zT_90;
    return zT_95;
    z_bb_24:
    if ((unsigned char)(ck == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_100 = store;
    zT_101 = cond.child_0;
    zT_103 = zF_8D299A60_detectNullGuard(zT_100, zT_101);
    inner = zT_103;
    zT_104 = inner.has_value;
    if (zT_104) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_117.has_value = 0;
    return zT_117;
    z_bb_27:
    if (!(inner.has_value)) { pal_trap(); }
    g = inner.value;
    zT_107 = g.name_id;
    zT_106.name_id = zT_107;
    zT_108 = 1;
    zT_109 = g.is_not_null;
    zT_110 = zig_wrap_sub_u(((zu64)(zT_108)), ((zu64)(zT_109)), 8u);
    zT_111 = zig_overflow_flag_sub_u(((zu64)(zT_108)), ((zu64)(zT_109)), 8u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    zT_114 = (unsigned char)zT_110;
    zT_106.is_not_null = zT_114;
    zT_115.has_value = 1;
    zT_115.value = zT_106;
    return zT_115;
    z_bb_28:
    zT_116.has_value = 0;
    return zT_116;
}

/* applyNullGuardRefinement */
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore* store, unsigned int cond_idx, zT_2C0927B0_StateMap* then_state, zT_2C0927B0_StateMap* else_state) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_57CCFBBB_Opt_121 zT_7;
    unsigned char zT_8;
    unsigned char zT_10;
    int zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    zT_E48CAD8A_PtrState zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_E48CAD8A_PtrState zT_22;
    zT_2C0927B0_StateMap* zT_23;
    unsigned int zT_24;
    unsigned char zT_25;
    zT_E48CAD8A_PtrState zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    unsigned char zT_30;
    zT_E48CAD8A_PtrState zT_32;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_57CCFBBB_Opt_121 guard;
    zT_438E6589_NullGuard g;
    zT_5 = store;
    zT_6 = cond_idx;
    zT_7 = zF_8D299A60_detectNullGuard(zT_5, zT_6);
    guard = zT_7;
    zT_8 = guard.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (!(guard.has_value)) { pal_trap(); }
    g = guard.value;
    zT_10 = g.is_not_null;
    zT_11 = 0;
    if ((unsigned char)(zT_10 != zT_11)) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_13 = then_state;
    zT_14 = g.name_id;
    zT_17 = zT_E48CAD8A_PtrState_safe;
    zT_15 = zT_17;
    zF_ACCFA860_stateMapSet(zT_13, zT_14, zT_15);
    zT_18 = else_state;
    zT_19 = g.name_id;
    zT_22 = zT_E48CAD8A_PtrState_is_null;
    zT_20 = zT_22;
    zF_ACCFA860_stateMapSet(zT_18, zT_19, zT_20);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = then_state;
    zT_24 = g.name_id;
    zT_27 = zT_E48CAD8A_PtrState_is_null;
    zT_25 = zT_27;
    zF_ACCFA860_stateMapSet(zT_23, zT_24, zT_25);
    zT_28 = else_state;
    zT_29 = g.name_id;
    zT_32 = zT_E48CAD8A_PtrState_safe;
    zT_30 = zT_32;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, zT_30);
    goto z_bb_4;
}

/* handleNullVarDecl */
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_7E2F335A_AnalyzerContext* zT_18;
    zT_2C0927B0_StateMap* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_E48CAD8A_PtrState zT_28;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int init_idx;
    unsigned char st;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = ctx->store;
    zT_10 = node_idx;
    zT_12 = zF_8BA26B9E_astStoreNodePayload(zT_9, zT_10);
    name_id = zT_12;
    zT_14 = node.child_1;
    init_idx = zT_14;
    if ((unsigned char)(init_idx != (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_18 = ctx;
    zT_19 = state;
    zT_20 = init_idx;
    zT_21 = zF_0619AC1C_classifyExpr(zT_18, zT_19, zT_20);
    st = zT_21;
    zT_22 = state;
    zT_23 = name_id;
    zT_24 = st;
    zF_ACCFA860_stateMapSet(zT_22, zT_23, zT_24);
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_25 = state;
    zT_26 = name_id;
    zT_28 = zT_E48CAD8A_PtrState_uninit;
    zT_27 = zT_28;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_2;
}

/* handleNullAssign */
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    unsigned int zT_9;
    zT_7E2F335A_AnalyzerContext* zT_11;
    zT_2C0927B0_StateMap* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21;
    zT_8143F551_AstKind zT_22;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zT_22A7C88B_AstNode node;
    unsigned int rhs;
    unsigned char rhs_state;
    unsigned int lhs_idx;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = node.child_1;
    rhs = zT_9;
    zT_11 = ctx;
    zT_12 = state;
    zT_13 = rhs;
    zT_14 = zF_0619AC1C_classifyExpr(zT_11, zT_12, zT_13);
    rhs_state = zT_14;
    zT_16 = node.child_0;
    lhs_idx = zT_16;
    zT_18 = ctx->store;
    zT_19 = lhs_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    lhs_node = zT_21;
    zT_22 = lhs_node.kind;
    if ((unsigned char)(zT_22 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_26 = state;
    zT_29 = ctx->store;
    zT_30 = lhs_idx;
    zT_32 = zF_2E24BD6B_identNameId(zT_29, zT_30);
    zT_27 = zT_32;
    zT_28 = rhs_state;
    zF_ACCFA860_stateMapSet(zT_26, zT_27, zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* executeDeferQueue */
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int target_depth, unsigned char is_error, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_7A19C4A5_DeferEntry* zT_17;
    zT_7A19C4A5_DeferEntry zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_7E2F335A_AnalyzerContext* zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned char zT_31;
    zT_7E2F335A_AnalyzerContext* zT_34;
    zT_2C0927B0_StateMap* zT_35;
    unsigned int zT_36;
    unsigned int idx;
    zT_7A19C4A5_DeferEntry entry;
    ctx->in_defer_exec = (unsigned char)(1);
    goto z_bb_1;
    z_bb_1:
    zT_6 = ctx->defer_queue_len;
    if ((unsigned char)(zT_6 > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = ctx->defer_queue_len;
    zT_11 = 1;
    zT_12 = zig_wrap_sub_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_sub_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    idx = zT_12;
    zT_17 = ctx->defer_queue_items;
    zT_18 = zT_17[idx];
    entry = zT_18;
    zT_19 = entry.scope_depth;
    if ((unsigned char)(zT_19 < target_depth)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    ctx->in_defer_exec = (unsigned char)(0);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    ctx->defer_queue_len = idx;
    zT_21 = entry.kind;
    if ((unsigned char)(zT_21 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_24 = ctx;
    zT_25 = state;
    zT_26 = entry.stmt_idx;
    visit_fn(zT_24, zT_25, zT_26);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_28 = entry.kind;
    if ((unsigned char)(zT_28 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_31 = is_error != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_31 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_31) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_34 = ctx;
    zT_35 = state;
    zT_36 = entry.stmt_idx;
    visit_fn(zT_34, zT_35, zT_36);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
}

/* walkBlock */
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int block_idx, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10;
    zT_8143F551_AstKind zT_11;
    zT_7E2F335A_AnalyzerContext* zT_15;
    zT_2C0927B0_StateMap* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_37;
    zT_2C0927B0_StateMap* zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    zT_7E2F335A_AnalyzerContext* zT_52;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_56;
    unsigned char zT_58;
    zT_7E2F335A_AnalyzerContext* zT_61;
    zT_2C0927B0_StateMap* zT_62;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zT_22A7C88B_AstNode node;
    unsigned int saved_depth;
    unsigned int children_n;
    unsigned int i;
    if ((unsigned char)(block_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = ctx->store;
    zT_8 = block_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = ctx;
    zT_16 = state;
    zT_17 = block_idx;
    visit_fn(zT_15, zT_16, zT_17);
    return;
    z_bb_4:
    zT_19 = ctx->current_depth;
    saved_depth = zT_19;
    zT_20 = ctx->current_depth;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zig_wrap_add_u(((zu64)(zT_20)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(zT_20)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    ctx->current_depth = zT_23;
    zT_28 = ctx->store;
    zT_29 = block_idx;
    zT_31 = zF_152E19CB_astStoreNodeExtraCh(zT_28, zT_29);
    children_n = zT_31;
    zT_33 = 0;
    zT_34 = (unsigned int)zT_33;
    i = zT_34;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_37 = ctx;
    zT_38 = state;
    zT_40 = ctx->store;
    zT_41 = block_idx;
    zT_45 = zF_B10B1BC1_astStoreNodeExtraCh(zT_40, zT_41, (unsigned int)((unsigned int)i));
    zT_39 = zT_45;
    visit_fn(zT_37, zT_38, zT_39);
    goto z_bb_8;
    z_bb_7:
    zT_52 = ctx;
    zT_53 = state;
    zT_54 = saved_depth;
    zT_56 = visit_fn;
    zF_332F08BB_executeDeferQueue(zT_52, zT_53, zT_54, (unsigned char)(0), zT_56);
    zT_58 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_58 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    i = zT_48;
    goto z_bb_5;
    z_bb_9:
    zT_61 = ctx;
    zT_62 = state;
    zF_628B7574_checkLeaksOnScopeEx(zT_61, zT_62);
    goto z_bb_10;
    z_bb_10:
    ctx->current_depth = saved_depth;
    return;
}

/* captureNameIdOf */
unsigned int zF_CE47A44A_captureNameIdOf(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8;
    zT_8143F551_AstKind zT_10;
    unsigned char zT_14;
    unsigned char zT_18;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_32;
    zT_8143F551_AstKind zT_33;
    unsigned char zT_37;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_49;
    unsigned char zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_63;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_44, (unsigned int)sizeof zT_44);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    unsigned int cap_idx;
    zT_22A7C88B_AstNode capn;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = store;
    zT_7 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_8;
    zT_10 = node.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_14 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_18 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_8;
    z_bb_7:
    zT_18 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_18) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = store;
    zT_24 = node_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_23, zT_24);
    cap_idx = zT_25;
    if ((unsigned char)(cap_idx == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_19; else goto z_bb_18;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    zT_30 = store;
    zT_31 = cap_idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    capn = zT_32;
    zT_33 = capn.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_38 = capn.kind;
    zT_37 = zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_15;
    z_bb_14:
    zT_37 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_37) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_42 = store;
    zT_43 = cap_idx;
    zT_44 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    return zT_44;
    z_bb_17:
    return (unsigned int)(0);
    z_bb_18:
    zT_49 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_20;
    z_bb_19:
    zT_49 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_49) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_53 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_23;
    z_bb_22:
    zT_53 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_53) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_57 = store;
    zT_58 = node_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    return zT_59;
    z_bb_25:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_prong))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_63 = node.child_1;
    return zT_63;
    z_bb_27:
    return (unsigned int)(0);
}

/* bindCaptureState */
void zF_C06E7771_bindCaptureState(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int name_id, unsigned int src_expr) {
    unsigned char zT_6;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    zT_E48CAD8A_PtrState zT_12;
    unsigned char zT_13;
    zT_7E2F335A_AnalyzerContext* zT_17;
    zT_2C0927B0_StateMap* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_7E2F335A_AnalyzerContext* zT_28;
    unsigned int zT_29;
    zT_BAEE192E_Opt_10 zT_30;
    unsigned char zT_31;
    zT_2C0927B0_StateMap* zT_34;
    unsigned int zT_35;
    zT_43E16BE5_Opt_8 zT_36;
    unsigned char zT_37;
    zT_2C0927B0_StateMap* zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_480593AB_AllocState zT_44;
    zT_2C0927B0_StateMap* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_480593AB_AllocState zT_48;
    zT_2C0927B0_StateMap* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    unsigned char prov;
    zT_BAEE192E_Opt_10 orig;
    unsigned int oid;
    zT_43E16BE5_Opt_8 cur;
    unsigned char c;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_6 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = state;
    zT_10 = name_id;
    zT_12 = zT_E48CAD8A_PtrState_safe;
    zT_11 = zT_12;
    zF_ACCFA860_stateMapSet(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_4:
    zT_13 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_13 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = ctx;
    zT_18 = state;
    zT_19 = src_expr;
    zT_20 = zF_5542CD3C_classifyProvenance(zT_17, zT_18, zT_19);
    prov = zT_20;
    zT_21 = state;
    zT_22 = name_id;
    zT_23 = prov;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_6;
    z_bb_6:
    zT_24 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_24 != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = ctx;
    zT_29 = src_expr;
    zT_30 = zF_92A5586D_resolveOrigin(zT_28, zT_29);
    orig = zT_30;
    zT_31 = orig.has_value;
    if (zT_31) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    return;
    z_bb_9:
    if (!(orig.has_value)) { pal_trap(); }
    oid = orig.value;
    zT_34 = state;
    zT_35 = oid;
    zT_36 = zF_2EC17ECC_stateMapGet(zT_34, zT_35);
    cur = zT_36;
    zT_37 = cur.has_value;
    if (zT_37) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    if (!(cur.has_value)) { pal_trap(); }
    c = cur.value;
    if ((unsigned char)(c == (zT_480593AB_AllocState)(zT_480593AB_AllocState_allocated))) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_41 = state;
    zT_42 = name_id;
    zT_44 = zT_480593AB_AllocState_allocated;
    zT_43 = zT_44;
    zF_ACCFA860_stateMapSet(zT_41, zT_42, zT_43);
    zT_45 = state;
    zT_46 = oid;
    zT_48 = zT_480593AB_AllocState_transferred;
    zT_47 = zT_48;
    zF_ACCFA860_stateMapSet(zT_45, zT_46, zT_47);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_49 = state;
    zT_50 = name_id;
    zT_51 = c;
    zF_ACCFA860_stateMapSet(zT_49, zT_50, zT_51);
    goto z_bb_14;
}

/* analyzerFoldComptimeBool */
zT_49E17557_Opt_2 zF_A1341A8A_analyzerFoldComptim(zT_7E2F335A_AnalyzerContext* ctx, unsigned int node_idx, unsigned int depth) {
    zT_49E17557_Opt_2 zT_5;
    zT_49E17557_Opt_2 zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    unsigned char zT_22;
    zT_49E17557_Opt_2 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_7E2F335A_AnalyzerContext* zT_28;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_8143F551_AstKind zT_38;
    zT_7E2F335A_AnalyzerContext* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_50;
    zT_49E17557_Opt_2 zT_51;
    unsigned char zT_52;
    unsigned char zT_54;
    zT_49E17557_Opt_2 zT_55;
    zT_49E17557_Opt_2 zT_56;
    zT_8143F551_AstKind zT_57;
    zT_7E2F335A_AnalyzerContext* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_49E17557_Opt_2 zT_70;
    unsigned char zT_71;
    unsigned char zT_74;
    zT_49E17557_Opt_2 zT_75;
    zT_7E2F335A_AnalyzerContext* zT_76;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_49E17557_Opt_2 zT_86;
    zT_8143F551_AstKind zT_87;
    zT_7E2F335A_AnalyzerContext* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned char zT_99;
    zT_49E17557_Opt_2 zT_100;
    unsigned char zT_101;
    unsigned char zT_103;
    zT_49E17557_Opt_2 zT_104;
    zT_7E2F335A_AnalyzerContext* zT_105;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    zT_49E17557_Opt_2 zT_115;
    zT_49E17557_Opt_2 zT_116;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zT_22A7C88B_AstNode n;
    unsigned char v;
    unsigned char l;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = ctx->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    n = zT_13;
    zT_14 = n.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_18 = n.flags;
    zT_22 = (unsigned char)(zT_18 & (unsigned char)(1)) != (unsigned char)(0);
    zT_23.has_value = 1;
    zT_23.value = zT_22;
    return zT_23;
    z_bb_6:
    zT_24 = n.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = ctx;
    zT_31 = n.child_0;
    zT_32 = 1;
    zT_33 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    ctx = zT_28;
    node_idx = zT_31;
    depth = zT_33;
    goto z_bb_0;
    z_bb_8:
    zT_38 = n.kind;
    if ((unsigned char)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_42 = ctx;
    zT_43 = n.child_0;
    zT_46 = 1;
    zT_47 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_46)), 32u);
    zT_48 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_46)), 32u);
    zT_50 = zT_48 == (unsigned int)(0);
    if (!(zT_50)) { pal_trap(); }
    zT_44 = zT_47;
    zT_51 = zF_A1341A8A_analyzerFoldComptim(zT_42, zT_43, zT_44);
    zT_52 = zT_51.has_value;
    if (zT_52) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_57 = n.kind;
    if ((unsigned char)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    if (!(zT_51.has_value)) { pal_trap(); }
    v = zT_51.value;
    zT_54 = !v;
    zT_55.has_value = 1;
    zT_55.value = zT_54;
    return zT_55;
    z_bb_12:
    zT_56.has_value = 0;
    return zT_56;
    z_bb_13:
    zT_61 = ctx;
    zT_62 = n.child_0;
    zT_65 = 1;
    zT_66 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_63 = zT_66;
    zT_70 = zF_A1341A8A_analyzerFoldComptim(zT_61, zT_62, zT_63);
    zT_71 = zT_70.has_value;
    if (zT_71) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_87 = n.kind;
    if ((unsigned char)(zT_87 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or))) goto z_bb_19; else goto z_bb_20;
    z_bb_15:
    if (!(zT_70.has_value)) { pal_trap(); }
    l = zT_70.value;
    if ((unsigned char)(!l)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_86.has_value = 0;
    return zT_86;
    z_bb_17:
    zT_74 = 0;
    zT_75.has_value = 1;
    zT_75.value = zT_74;
    return zT_75;
    z_bb_18:
    zT_76 = ctx;
    zT_79 = n.child_1;
    zT_80 = 1;
    zT_81 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_80)), 32u);
    zT_82 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_80)), 32u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    ctx = zT_76;
    node_idx = zT_79;
    depth = zT_81;
    goto z_bb_0;
    z_bb_19:
    zT_91 = ctx;
    zT_92 = n.child_0;
    zT_95 = 1;
    zT_96 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_95)), 32u);
    zT_97 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_95)), 32u);
    zT_99 = zT_97 == (unsigned int)(0);
    if (!(zT_99)) { pal_trap(); }
    zT_93 = zT_96;
    zT_100 = zF_A1341A8A_analyzerFoldComptim(zT_91, zT_92, zT_93);
    zT_101 = zT_100.has_value;
    if (zT_101) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_116.has_value = 0;
    return zT_116;
    z_bb_21:
    if (!(zT_100.has_value)) { pal_trap(); }
    l = zT_100.value;
    if (l) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_115.has_value = 0;
    return zT_115;
    z_bb_23:
    zT_103 = 1;
    zT_104.has_value = 1;
    zT_104.value = zT_103;
    return zT_104;
    z_bb_24:
    zT_105 = ctx;
    zT_108 = n.child_1;
    zT_109 = 1;
    zT_110 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_109)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_109)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    ctx = zT_105;
    node_idx = zT_108;
    depth = zT_110;
    goto z_bb_0;
}

/* paramTypeIsPointerLike */
unsigned char zF_42EA7E8C_paramTypeIsPointerL(zT_7E2F335A_AnalyzerContext* ctx, unsigned int type_expr_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9;
    zT_8143F551_AstKind zT_10;
    unsigned char zT_14;
    zT_8143F551_AstKind zT_15;
    unsigned char zT_19;
    zT_8143F551_AstKind zT_20;
    unsigned char zT_24;
    zT_8143F551_AstKind zT_25;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zT_22A7C88B_AstNode tnode;
    if ((unsigned char)(type_expr_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ctx->store;
    zT_7 = type_expr_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    tnode = zT_9;
    zT_10 = tnode.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_15 = tnode.kind;
    zT_14 = zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_5;
    z_bb_4:
    zT_14 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_14) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_20 = tnode.kind;
    zT_19 = zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_25 = tnode.kind;
    zT_24 = zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_11;
    z_bb_10:
    zT_24 = 1;
    goto z_bb_11;
    z_bb_11:
    return zT_24;
}

/* visitStatement */
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx, zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt, zT_68F0EBCB_FP_void_zT_7E2F335A visit_fn) {
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11;
    zT_8143F551_AstKind zT_13;
    unsigned char zT_17;
    zT_7E2F335A_AnalyzerContext* zT_22;
    unsigned int zT_23;
    int zT_26;
    zT_49E17557_Opt_2 zT_28;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_37;
    zT_2C0927B0_StateMap* zT_38;
    unsigned int zT_39;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_40;
    unsigned int zT_42;
    zT_7E2F335A_AnalyzerContext* zT_45;
    zT_2C0927B0_StateMap* zT_46;
    unsigned int zT_47;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_48;
    zT_7E2F335A_AnalyzerContext* zT_50;
    zT_2C0927B0_StateMap* zT_51;
    unsigned int zT_52;
    zT_2C0927B0_StateMap* zT_55;
    zT_3E40CD83_Sand* zT_56;
    zT_2C0927B0_StateMap* zT_58;
    zT_2C0927B0_StateMap* zT_60;
    zT_3E40CD83_Sand* zT_61;
    zT_2C0927B0_StateMap* zT_63;
    unsigned char zT_64;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_2C0927B0_StateMap* zT_69;
    zT_2C0927B0_StateMap* zT_70;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_7E2F335A_AnalyzerContext* zT_78;
    zT_2C0927B0_StateMap* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_7E2F335A_AnalyzerContext* zT_83;
    zT_2C0927B0_StateMap* zT_84;
    unsigned int zT_85;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_86;
    unsigned int zT_88;
    zT_7E2F335A_AnalyzerContext* zT_91;
    zT_2C0927B0_StateMap* zT_92;
    unsigned int zT_93;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_94;
    zT_2C0927B0_StateMap* zT_96;
    zT_2C0927B0_StateMap* zT_97;
    zT_2C0927B0_StateMap* zT_98;
    unsigned char zT_104;
    zT_7E2F335A_AnalyzerContext* zT_108;
    zT_2C0927B0_StateMap* zT_109;
    unsigned int zT_110;
    zT_2C0927B0_StateMap* zT_113;
    zT_3E40CD83_Sand* zT_114;
    zT_2C0927B0_StateMap* zT_116;
    zT_6B0A7D14_AstStore* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    zT_7E2F335A_AnalyzerContext* zT_122;
    zT_2C0927B0_StateMap* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_7E2F335A_AnalyzerContext* zT_127;
    zT_2C0927B0_StateMap* zT_128;
    unsigned int zT_129;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_130;
    zT_2C0927B0_StateMap* zT_132;
    zT_2C0927B0_StateMap* zT_133;
    zT_2C0927B0_StateMap* zT_134;
    zT_7E2F335A_AnalyzerContext* zT_140;
    zT_2C0927B0_StateMap* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    int zT_150;
    unsigned int zT_151;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_163;
    zT_22A7C88B_AstNode zT_164;
    zT_2C0927B0_StateMap* zT_166;
    zT_3E40CD83_Sand* zT_167;
    zT_2C0927B0_StateMap* zT_169;
    zT_6B0A7D14_AstStore* zT_171;
    unsigned int zT_172;
    zT_6B0A7D14_AstStore* zT_174;
    unsigned int zT_175;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_7E2F335A_AnalyzerContext* zT_181;
    zT_2C0927B0_StateMap* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_7E2F335A_AnalyzerContext* zT_186;
    zT_2C0927B0_StateMap* zT_187;
    unsigned int zT_188;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_189;
    zT_2C0927B0_StateMap* zT_191;
    zT_2C0927B0_StateMap* zT_192;
    zT_2C0927B0_StateMap* zT_193;
    unsigned char zT_196;
    zT_2C0927B0_StateMap* zT_199;
    zT_2C0927B0_StateMap* zT_200;
    int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned char zT_209;
    zT_2C0927B0_StateMap* zT_214;
    zT_3E40CD83_Sand* zT_215;
    zT_2C0927B0_StateMap* zT_217;
    zT_6B0A7D14_AstStore* zT_219;
    unsigned int zT_220;
    unsigned int zT_222;
    zT_7E2F335A_AnalyzerContext* zT_223;
    zT_2C0927B0_StateMap* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_7E2F335A_AnalyzerContext* zT_228;
    zT_2C0927B0_StateMap* zT_229;
    unsigned int zT_230;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_231;
    zT_2C0927B0_StateMap* zT_233;
    zT_2C0927B0_StateMap* zT_234;
    zT_2C0927B0_StateMap* zT_235;
    unsigned int zT_241;
    unsigned char zT_244;
    zT_7E2F335A_AnalyzerContext* zT_247;
    zT_2C0927B0_StateMap* zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned char zT_252;
    zT_7E2F335A_AnalyzerContext* zT_255;
    zT_2C0927B0_StateMap* zT_256;
    unsigned int zT_257;
    zT_7E2F335A_AnalyzerContext* zT_259;
    zT_2C0927B0_StateMap* zT_260;
    unsigned int zT_261;
    unsigned char zT_265;
    unsigned char zT_269;
    unsigned char zT_270;
    unsigned char zT_274;
    unsigned char zT_278;
    zT_7E2F335A_AnalyzerContext* zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned char zT_286;
    zT_7A19C4A5_DeferEntry zT_287;
    unsigned int zT_288;
    zT_7A19C4A5_DeferEntry* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned char zT_297;
    unsigned char zT_298;
    unsigned char zT_301;
    zT_7E2F335A_AnalyzerContext* zT_305;
    zT_2C0927B0_StateMap* zT_306;
    unsigned int zT_307;
    zT_7E2F335A_AnalyzerContext* zT_308;
    zT_2C0927B0_StateMap* zT_309;
    unsigned int zT_310;
    unsigned char zT_311;
    unsigned char zT_314;
    zT_7E2F335A_AnalyzerContext* zT_318;
    zT_2C0927B0_StateMap* zT_319;
    unsigned int zT_320;
    zT_7E2F335A_AnalyzerContext* zT_321;
    zT_2C0927B0_StateMap* zT_322;
    unsigned int zT_323;
    unsigned int zT_327;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    zT_22A7C88B_AstNode zT_335;
    zT_8143F551_AstKind zT_336;
    zT_7E2F335A_AnalyzerContext* zT_340;
    zT_2C0927B0_StateMap* zT_341;
    unsigned int zT_342;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_343;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_344;
    zT_7E2F335A_AnalyzerContext* zT_346;
    zT_2C0927B0_StateMap* zT_347;
    unsigned int zT_348;
    zT_7E2F335A_AnalyzerContext* zT_353;
    zT_2C0927B0_StateMap* zT_354;
    unsigned int zT_355;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_356;
    zT_7E2F335A_AnalyzerContext* zT_360;
    zT_2C0927B0_StateMap* zT_361;
    unsigned int zT_362;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_363;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_364;
    zT_7E2F335A_AnalyzerContext* zT_366;
    zT_2C0927B0_StateMap* zT_367;
    unsigned int zT_368;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_28, (unsigned int)sizeof zT_28);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_77, (unsigned int)sizeof zT_77);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_121, (unsigned int)sizeof zT_121);
    zig_poison_fill((void*)&zT_148, (unsigned int)sizeof zT_148);
    zig_poison_fill((void*)&zT_163, (unsigned int)sizeof zT_163);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_179, (unsigned int)sizeof zT_179);
    zig_poison_fill((void*)&zT_180, (unsigned int)sizeof zT_180);
    zig_poison_fill((void*)&zT_217, (unsigned int)sizeof zT_217);
    zig_poison_fill((void*)&zT_222, (unsigned int)sizeof zT_222);
    zig_poison_fill((void*)&zT_335, (unsigned int)sizeof zT_335);
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_49E17557_Opt_2 t5_fold;
    unsigned char tfv;
    zT_2C0927B0_StateMap* then_state;
    zT_2C0927B0_StateMap* else_state;
    unsigned int t5_cap;
    zT_2C0927B0_StateMap* body_state;
    unsigned int t5_wcap;
    unsigned int prongs_n;
    unsigned int si;
    zT_22A7C88B_AstNode prong;
    zT_2C0927B0_StateMap* ps;
    unsigned int t5_pcap;
    unsigned int t5_fcap;
    unsigned char dk;
    zT_22A7C88B_AstNode inner;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = ctx->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = node.kind;
    kind = zT_13;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_17 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture);
    goto z_bb_5;
    z_bb_4:
    zT_17 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_17) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_22 = ctx;
    zT_23 = node.child_0;
    zT_26 = 0;
    zT_28 = zF_A1341A8A_analyzerFoldComptim(zT_22, zT_23, (unsigned int)((unsigned int)zT_26));
    t5_fold = zT_28;
    zT_29 = t5_fold.has_value;
    if (zT_29) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return;
    z_bb_8:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_23; else goto z_bb_22;
    z_bb_9:
    if (!(t5_fold.has_value)) { pal_trap(); }
    tfv = t5_fold.value;
    zT_31 = ctx->store;
    zT_32 = node_idx;
    zT_34 = zF_8BA26B9E_astStoreNodePayload(zT_31, zT_32);
    if ((unsigned char)(zT_34 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_50 = ctx;
    zT_51 = state;
    zT_52 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_50, zT_51, zT_52);
    zT_55 = state;
    zT_56 = ctx->alloc;
    zT_58 = zF_77086C9C_stateMapFork(zT_55, zT_56);
    then_state = zT_58;
    zT_60 = state;
    zT_61 = ctx->alloc;
    zT_63 = zF_77086C9C_stateMapFork(zT_60, zT_61);
    else_state = zT_63;
    zT_64 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_64 != (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_11:
    if (tfv) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_37 = ctx;
    zT_38 = state;
    zT_39 = node.child_1;
    zT_40 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_37, zT_38, zT_39, zT_40);
    goto z_bb_14;
    z_bb_14:
    return;
    z_bb_15:
    zT_42 = node.child_2;
    if ((unsigned char)(zT_42 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = ctx;
    zT_46 = state;
    zT_47 = node.child_2;
    zT_48 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_45, zT_46, zT_47, zT_48);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_67 = ctx->store;
    zT_68 = node.child_0;
    zT_69 = then_state;
    zT_70 = else_state;
    zF_76DBB626_applyNullGuardRefin(zT_67, zT_68, zT_69, zT_70);
    goto z_bb_19;
    z_bb_19:
    zT_74 = ctx->store;
    zT_75 = node_idx;
    zT_77 = zF_CE47A44A_captureNameIdOf(zT_74, zT_75);
    t5_cap = zT_77;
    zT_78 = ctx;
    zT_79 = then_state;
    zT_80 = t5_cap;
    zT_81 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_78, zT_79, zT_80, zT_81);
    zT_83 = ctx;
    zT_84 = then_state;
    zT_85 = node.child_1;
    zT_86 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_83, zT_84, zT_85, zT_86);
    zT_88 = node.child_2;
    if ((unsigned char)(zT_88 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_91 = ctx;
    zT_92 = else_state;
    zT_93 = node.child_2;
    zT_94 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_91, zT_92, zT_93, zT_94);
    goto z_bb_21;
    z_bb_21:
    zT_96 = state;
    zT_97 = then_state;
    zT_98 = else_state;
    zF_143ACBA6_stateMapMergeStates(zT_96, zT_97, zT_98, (unsigned char)(99));
    goto z_bb_7;
    z_bb_22:
    zT_104 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture);
    goto z_bb_24;
    z_bb_23:
    zT_104 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_104) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_108 = ctx;
    zT_109 = state;
    zT_110 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_108, zT_109, zT_110);
    zT_113 = state;
    zT_114 = ctx->alloc;
    zT_116 = zF_77086C9C_stateMapFork(zT_113, zT_114);
    body_state = zT_116;
    zT_118 = ctx->store;
    zT_119 = node_idx;
    zT_121 = zF_CE47A44A_captureNameIdOf(zT_118, zT_119);
    t5_wcap = zT_121;
    zT_122 = ctx;
    zT_123 = body_state;
    zT_124 = t5_wcap;
    zT_125 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_122, zT_123, zT_124, zT_125);
    zT_127 = ctx;
    zT_128 = body_state;
    zT_129 = node.child_1;
    zT_130 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_127, zT_128, zT_129, zT_130);
    zT_132 = state;
    zT_133 = state;
    zT_134 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_132, zT_133, zT_134, (unsigned char)(99));
    goto z_bb_26;
    z_bb_26:
    goto z_bb_7;
    z_bb_27:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_140 = ctx;
    zT_141 = state;
    zT_142 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_140, zT_141, zT_142);
    zT_145 = ctx->store;
    zT_146 = node_idx;
    zT_148 = zF_152E19CB_astStoreNodeExtraCh(zT_145, zT_146);
    prongs_n = zT_148;
    zT_150 = 0;
    zT_151 = (unsigned int)zT_150;
    si = zT_151;
    goto z_bb_31;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_37; else goto z_bb_39;
    z_bb_31:
    if ((unsigned char)(si < (unsigned int)((unsigned int)prongs_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_155 = ctx->store;
    zT_158 = ctx->store;
    zT_159 = node_idx;
    zT_163 = zF_B10B1BC1_astStoreNodeExtraCh(zT_158, zT_159, (unsigned int)((unsigned int)si));
    zT_156 = zT_163;
    zT_164 = zF_FCDD1D35_astStoreNodeAt(zT_155, zT_156);
    prong = zT_164;
    zT_166 = state;
    zT_167 = ctx->alloc;
    zT_169 = zF_77086C9C_stateMapFork(zT_166, zT_167);
    ps = zT_169;
    zT_171 = ctx->store;
    zT_174 = ctx->store;
    zT_175 = node_idx;
    zT_179 = zF_B10B1BC1_astStoreNodeExtraCh(zT_174, zT_175, (unsigned int)((unsigned int)si));
    zT_172 = zT_179;
    zT_180 = zF_CE47A44A_captureNameIdOf(zT_171, zT_172);
    t5_pcap = zT_180;
    zT_181 = ctx;
    zT_182 = ps;
    zT_183 = t5_pcap;
    zT_184 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_181, zT_182, zT_183, zT_184);
    zT_186 = ctx;
    zT_187 = ps;
    zT_188 = prong.child_0;
    zT_189 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_186, zT_187, zT_188, zT_189);
    zT_191 = state;
    zT_192 = state;
    zT_193 = ps;
    zF_143ACBA6_stateMapMergeStates(zT_191, zT_192, zT_193, (unsigned char)(99));
    zT_196 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_196 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_204 = 1;
    zT_205 = (unsigned int)zT_204;
    zT_206 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_205)), 32u);
    zT_207 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_205)), 32u);
    zT_209 = zT_207 == (unsigned int)(0);
    if (!(zT_209)) { pal_trap(); }
    si = zT_206;
    goto z_bb_31;
    z_bb_35:
    zT_199 = state;
    zT_200 = ps;
    zF_619C0B6B_stateMapMergeInsert(zT_199, zT_200, (unsigned char)((unsigned char)(zT_480593AB_AllocState)(zT_480593AB_AllocState_unknown)));
    goto z_bb_36;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_214 = state;
    zT_215 = ctx->alloc;
    zT_217 = zF_77086C9C_stateMapFork(zT_214, zT_215);
    body_state = zT_217;
    zT_219 = ctx->store;
    zT_220 = node_idx;
    zT_222 = zF_CE47A44A_captureNameIdOf(zT_219, zT_220);
    t5_fcap = zT_222;
    zT_223 = ctx;
    zT_224 = body_state;
    zT_225 = t5_fcap;
    zT_226 = node.child_0;
    zF_C06E7771_bindCaptureState(zT_223, zT_224, zT_225, zT_226);
    zT_228 = ctx;
    zT_229 = body_state;
    zT_230 = node.child_1;
    zT_231 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_228, zT_229, zT_230, zT_231);
    zT_233 = state;
    zT_234 = state;
    zT_235 = body_state;
    zF_143ACBA6_stateMapMergeStates(zT_233, zT_234, zT_235, (unsigned char)(99));
    goto z_bb_38;
    z_bb_38:
    goto z_bb_29;
    z_bb_39:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_241 = node.child_0;
    if ((unsigned char)(zT_241 != (unsigned int)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_50; else goto z_bb_49;
    z_bb_43:
    zT_244 = ctx->lifetime_analysis_mode;
    if ((unsigned char)(zT_244 != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    zT_259 = ctx;
    zT_260 = state;
    zT_261 = node_idx;
    on_stmt(zT_259, zT_260, zT_261);
    goto z_bb_41;
    z_bb_45:
    zT_247 = ctx;
    zT_248 = state;
    zT_249 = node.child_0;
    zT_250 = node_idx;
    zF_8C7FC932_checkReturnProvenan(zT_247, zT_248, zT_249, zT_250);
    goto z_bb_46;
    z_bb_46:
    zT_252 = ctx->doublefree_analysis_mode;
    if ((unsigned char)(zT_252 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_255 = ctx;
    zT_256 = state;
    zT_257 = node.child_0;
    zF_65CAFC02_handleOwnershipRetu(zT_255, zT_256, zT_257);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_44;
    z_bb_49:
    zT_265 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_51;
    z_bb_50:
    zT_265 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_265) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_270 = ctx->in_defer_exec;
    zT_269 = zT_270 == (unsigned char)(0);
    goto z_bb_54;
    z_bb_53:
    zT_269 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_269) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_274 = 0;
    dk = zT_274;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_41;
    z_bb_57:
    zT_298 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_298 != (unsigned char)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    zT_278 = 1;
    dk = zT_278;
    goto z_bb_59;
    z_bb_59:
    zT_279 = ctx;
    zT_281 = ctx->defer_queue_len;
    zT_282 = 1;
    zT_283 = zig_wrap_add_u(((zu64)(zT_281)), ((zu64)(zT_282)), 32u);
    zT_284 = zig_overflow_flag_add_u(((zu64)(zT_281)), ((zu64)(zT_282)), 32u);
    zT_286 = zT_284 == (unsigned int)(0);
    if (!(zT_286)) { pal_trap(); }
    zT_280 = zT_283;
    zF_46BA7660_deferQueueEnsureCap(zT_279, zT_280);
    zT_287.kind = dk;
    zT_287.stmt_idx = node_idx;
    zT_288 = ctx->current_depth;
    zT_287.scope_depth = zT_288;
    zT_289 = ctx->defer_queue_items;
    zT_290 = ctx->defer_queue_len;
    zT_289[zT_290] = zT_287;
    zT_291 = ctx->defer_queue_len;
    zT_292 = 1;
    zT_293 = (unsigned int)zT_292;
    zT_294 = zig_wrap_add_u(((zu64)(zT_291)), ((zu64)(zT_293)), 32u);
    zT_295 = zig_overflow_flag_add_u(((zu64)(zT_291)), ((zu64)(zT_293)), 32u);
    zT_297 = zT_295 == (unsigned int)(0);
    if (!(zT_297)) { pal_trap(); }
    ctx->defer_queue_len = zT_294;
    goto z_bb_56;
    z_bb_60:
    zT_301 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl);
    goto z_bb_62;
    z_bb_61:
    zT_301 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_301) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_305 = ctx;
    zT_306 = state;
    zT_307 = node_idx;
    zF_B7AD2EEF_handleNullVarDecl(zT_305, zT_306, zT_307);
    zT_308 = ctx;
    zT_309 = state;
    zT_310 = node_idx;
    on_stmt(zT_308, zT_309, zT_310);
    goto z_bb_64;
    z_bb_64:
    goto z_bb_56;
    z_bb_65:
    zT_311 = ctx->null_analysis_mode;
    if ((unsigned char)(zT_311 != (unsigned char)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_314 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign);
    goto z_bb_68;
    z_bb_67:
    zT_314 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_314) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_318 = ctx;
    zT_319 = state;
    zT_320 = node_idx;
    zF_847AD0EF_handleNullAssign(zT_318, zT_319, zT_320);
    zT_321 = ctx;
    zT_322 = state;
    zT_323 = node_idx;
    on_stmt(zT_321, zT_322, zT_323);
    goto z_bb_70;
    z_bb_70:
    goto z_bb_64;
    z_bb_71:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_72; else goto z_bb_74;
    z_bb_72:
    zT_327 = node.child_0;
    if ((unsigned char)(zT_327 != (unsigned int)(0))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_80; else goto z_bb_82;
    z_bb_75:
    zT_331 = ctx->store;
    zT_332 = node.child_0;
    zT_335 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    inner = zT_335;
    zT_336 = inner.kind;
    if ((unsigned char)(zT_336 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_77; else goto z_bb_79;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_340 = ctx;
    zT_341 = state;
    zT_342 = node.child_0;
    zT_343 = on_stmt;
    zT_344 = visit_fn;
    zF_468ECC89_visitStatement(zT_340, zT_341, zT_342, zT_343, zT_344);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    zT_346 = ctx;
    zT_347 = state;
    zT_348 = node.child_0;
    zF_8D5B6C98_analyzeExpr(zT_346, zT_347, zT_348);
    goto z_bb_78;
    z_bb_80:
    zT_353 = ctx;
    zT_354 = state;
    zT_355 = node_idx;
    zT_356 = visit_fn;
    zF_0F6AFE81_walkBlock(zT_353, zT_354, zT_355, zT_356);
    goto z_bb_81;
    z_bb_81:
    goto z_bb_73;
    z_bb_82:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_360 = ctx;
    zT_361 = state;
    zT_362 = node.child_0;
    zT_363 = on_stmt;
    zT_364 = visit_fn;
    zF_468ECC89_visitStatement(zT_360, zT_361, zT_362, zT_363, zT_364);
    goto z_bb_84;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    zT_366 = ctx;
    zT_367 = state;
    zT_368 = node_idx;
    on_stmt(zT_366, zT_367, zT_368);
    goto z_bb_84;
}

/* onNullStmt */
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    (void)ctx;
    (void)state;
    (void)node_idx;
    return;
}

/* onLifetimeStmt */
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    zT_8143F551_AstKind zT_8;
    unsigned int zT_12;
    zT_7E2F335A_AnalyzerContext* zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_2C0927B0_StateMap* zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_22A7C88B_AstNode zT_46;
    zT_8143F551_AstKind zT_47;
    zT_7E2F335A_AnalyzerContext* zT_52;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    zT_2C0927B0_StateMap* zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    unsigned int zT_64;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_46, (unsigned int)sizeof zT_46);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zT_22A7C88B_AstNode node;
    unsigned char prov;
    zT_22A7C88B_AstNode lhs_node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = node.child_1;
    if ((unsigned char)(zT_12 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_16 = ctx;
    zT_17 = state;
    zT_18 = node.child_1;
    zT_20 = zF_5542CD3C_classifyProvenance(zT_16, zT_17, zT_18);
    prov = zT_20;
    zT_21 = state;
    zT_24 = ctx->store;
    zT_25 = node_idx;
    zT_27 = zF_8BA26B9E_astStoreNodePayload(zT_24, zT_25);
    zT_22 = zT_27;
    zT_23 = prov;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_28 = state;
    zT_31 = ctx->store;
    zT_32 = node_idx;
    zT_34 = zF_8BA26B9E_astStoreNodePayload(zT_31, zT_32);
    zT_29 = zT_34;
    zF_ACCFA860_stateMapSet(zT_28, zT_29, (unsigned char)((unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_unknown)));
    goto z_bb_4;
    z_bb_6:
    zT_42 = ctx->store;
    zT_43 = node.child_0;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    lhs_node = zT_46;
    zT_47 = lhs_node.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    return;
    z_bb_8:
    zT_52 = ctx;
    zT_53 = state;
    zT_54 = node.child_1;
    zT_56 = zF_5542CD3C_classifyProvenance(zT_52, zT_53, zT_54);
    prov = zT_56;
    zT_57 = state;
    zT_60 = ctx->store;
    zT_61 = node.child_0;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_58 = zT_64;
    zT_59 = prov;
    zF_ACCFA860_stateMapSet(zT_57, zT_58, zT_59);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_7;
}

/* onDoubleFreeStmt */
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7;
    zT_8143F551_AstKind zT_8;
    zT_7E2F335A_AnalyzerContext* zT_12;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    zT_8143F551_AstKind zT_21;
    zT_7E2F335A_AnalyzerContext* zT_25;
    zT_2C0927B0_StateMap* zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    zT_7E2F335A_AnalyzerContext* zT_32;
    zT_2C0927B0_StateMap* zT_33;
    unsigned int zT_34;
    zT_7E2F335A_AnalyzerContext* zT_35;
    zT_2C0927B0_StateMap* zT_36;
    unsigned int zT_37;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zT_22A7C88B_AstNode node;
    zT_4 = ctx->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = ctx;
    zT_13 = state;
    zT_16 = ctx->store;
    zT_17 = node_idx;
    zT_19 = zF_8BA26B9E_astStoreNodePayload(zT_16, zT_17);
    zT_14 = zT_19;
    zT_15 = node.child_1;
    zF_4330B9B8_handleAllocCall(zT_12, zT_13, zT_14, zT_15);
    goto z_bb_2;
    z_bb_2:
    zT_21 = node.kind;
    if ((unsigned char)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25 = ctx;
    zT_26 = state;
    zT_27 = node_idx;
    zF_67B7BB29_handleAllocAssign(zT_25, zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_32 = ctx;
    zT_33 = state;
    zT_34 = node_idx;
    zF_70D0501D_handleFreeCall(zT_32, zT_33, zT_34);
    zT_35 = ctx;
    zT_36 = state;
    zT_37 = node_idx;
    zF_9AFCA595_handleOwnershipPass(zT_35, zT_36, zT_37);
    goto z_bb_6;
    z_bb_6:
    return;
}

/* runSignatureAnalyzer */
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx) {
    zT_7E2F335A_AnalyzerContext* zT_2;
    unsigned int zT_3;
    zT_2 = ctx;
    zT_3 = fn_decl_idx;
    zF_2A06A757_analyzeSignature(zT_2, zT_3);
    return;
}

/* detectorVisit */
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext* ctx, zT_2C0927B0_StateMap* state, unsigned int node_idx) {
    zT_7E2F335A_AnalyzerContext* zT_3;
    zT_2C0927B0_StateMap* zT_4;
    unsigned int zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_6;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_9;
    zT_3 = ctx;
    zT_4 = state;
    zT_5 = node_idx;
    zT_6 = ctx->on_stmt_cb;
    zT_9 = zF_59D99CE2_detectorVisit;
    zT_7 = zT_9;
    zF_468ECC89_visitStatement(zT_3, zT_4, zT_5, zT_6, zT_7);
    return;
}

/* runNullAnalyzer */
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->null_analysis_mode = (unsigned char)(1);
    zT_7 = zF_43C99FB3_onNullStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = (zT_2C0927B0_StateMap*)&state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->null_analysis_mode = (unsigned char)(0);
    return;
}

/* runLifetimeAnalyzer */
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_decl_idx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_4;
    zT_2C0927B0_StateMap zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_19;
    zT_5838FCFA_anon_324009 zT_20;
    zT_243D6A41_FnProto* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_243D6A41_FnProto zT_27;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_30;
    zT_79FAE712_u64 zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned char zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned short zT_38;
    zT_79FAE712_u64 zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    zT_79FAE712_u64 zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_55;
    zT_79FAE712_u64 zT_56;
    unsigned int zT_60;
    zT_22A7C88B_AstNode zT_61;
    zT_8143F551_AstKind zT_62;
    unsigned char zT_68;
    zT_7E2F335A_AnalyzerContext* zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    unsigned char zT_74;
    zT_2C0927B0_StateMap* zT_75;
    unsigned int zT_76;
    unsigned char zT_77;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_82;
    zT_79FAE712_u64 zT_83;
    unsigned int zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_96;
    zT_7E2F335A_AnalyzerContext* zT_97;
    zT_2C0927B0_StateMap* zT_98;
    unsigned int zT_99;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_100;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_102;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zT_2C0927B0_StateMap state;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 pp;
    unsigned int params_n;
    unsigned int pi;
    zT_22A7C88B_AstNode pnode;
    unsigned char t5_pseed;
    zT_4 = ctx->alloc;
    zT_6 = zF_14665872_stateMapInit(zT_4);
    state = zT_6;
    zT_8 = ctx->store;
    zT_9 = fn_decl_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    zT_12 = ctx->store;
    zT_13 = fn_decl_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = ctx->store;
    zT_20 = zT_19->fn_protos;
    zT_21 = zT_20.items;
    zT_22 = ctx->store;
    zT_23 = fn_decl_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    proto = zT_27;
    zT_29 = proto.params_start;
    zT_30 = (zT_79FAE712_u64)zT_29;
    zT_31 = 32;
    zT_34 = zT_31 < (unsigned int)(64);
    if (!(zT_34)) { pal_trap(); }
    zT_32 = zig_wrap_shl_u(((zu64)(zT_30)), ((zu64)(zT_31)), 64u);
    zT_35 = zig_overflow_flag_shl_u(((zu64)(zT_30)), ((zu64)(zT_31)), 64u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_38 = proto.params_count;
    zT_40 = zT_32 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_38);
    pp = zT_40;
    zT_42 = ctx->store;
    zT_43 = pp;
    zT_45 = zF_03CE8CAB_astStoreGetExtraChi(zT_42, zT_43);
    params_n = zT_45;
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    pi = zT_48;
    goto z_bb_3;
    z_bb_2:
    ctx->lifetime_analysis_mode = (unsigned char)(1);
    zT_96 = zF_3D2EF2C5_onLifetimeStmt;
    ctx->on_stmt_cb = zT_96;
    zT_97 = ctx;
    zT_98 = (zT_2C0927B0_StateMap*)&state;
    zT_99 = fn_body_idx;
    zT_102 = zF_59D99CE2_detectorVisit;
    zT_100 = zT_102;
    zF_0F6AFE81_walkBlock(zT_97, zT_98, zT_99, zT_100);
    ctx->lifetime_analysis_mode = (unsigned char)(0);
    return;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)params_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_52 = ctx->store;
    zT_55 = ctx->store;
    zT_56 = pp;
    zT_60 = zF_E5B10421_astStoreGetExtraChi(zT_55, zT_56, (unsigned int)((unsigned int)pi));
    zT_53 = zT_60;
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    pnode = zT_61;
    zT_62 = pnode.kind;
    if ((unsigned char)(zT_62 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_param_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_89 = 1;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_90)), 32u);
    zT_92 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_90)), 32u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    pi = zT_91;
    goto z_bb_3;
    z_bb_7:
    zT_68 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_param);
    t5_pseed = zT_68;
    zT_69 = ctx;
    zT_70 = pnode.child_0;
    zT_72 = zF_42EA7E8C_paramTypeIsPointerL(zT_69, zT_70);
    if (zT_72) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_74 = (unsigned char)(zT_32E64562_Provenance)(zT_32E64562_Provenance_external);
    t5_pseed = zT_74;
    goto z_bb_10;
    z_bb_10:
    zT_75 = (zT_2C0927B0_StateMap*)&state;
    zT_79 = ctx->store;
    zT_82 = ctx->store;
    zT_83 = pp;
    zT_87 = zF_E5B10421_astStoreGetExtraChi(zT_82, zT_83, (unsigned int)((unsigned int)pi));
    zT_80 = zT_87;
    zT_88 = zF_8BA26B9E_astStoreNodePayload(zT_79, zT_80);
    zT_76 = zT_88;
    zT_77 = t5_pseed;
    zF_ACCFA860_stateMapSet(zT_75, zT_76, zT_77);
    goto z_bb_8;
}

/* runDoubleFreeAnalyzer */
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext* ctx, unsigned int fn_body_idx) {
    zT_3E40CD83_Sand* zT_3;
    zT_2C0927B0_StateMap zT_5;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_7;
    zT_7E2F335A_AnalyzerContext* zT_8;
    zT_2C0927B0_StateMap* zT_9;
    unsigned int zT_10;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_11;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_13;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_2C0927B0_StateMap state;
    zT_3 = ctx->alloc;
    zT_5 = zF_14665872_stateMapInit(zT_3);
    state = zT_5;
    ctx->doublefree_analysis_mode = (unsigned char)(1);
    zT_7 = zF_270EF995_onDoubleFreeStmt;
    ctx->on_stmt_cb = zT_7;
    zT_8 = ctx;
    zT_9 = (zT_2C0927B0_StateMap*)&state;
    zT_10 = fn_body_idx;
    zT_13 = zF_59D99CE2_detectorVisit;
    zT_11 = zT_13;
    zF_0F6AFE81_walkBlock(zT_8, zT_9, zT_10, zT_11);
    ctx->doublefree_analysis_mode = (unsigned char)(0);
    return;
}

/* runAllAnalyzers */
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext* ctx, unsigned int module_root_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6;
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_32;
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_3E40CD83_Sand* zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    zT_5838FCFA_anon_324009 zT_43;
    zT_243D6A41_FnProto* zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_243D6A41_FnProto zT_50;
    unsigned int zT_51;
    zT_7E2F335A_AnalyzerContext* zT_52;
    unsigned int zT_53;
    zT_3E40CD83_Sand* zT_54;
    zT_7E2F335A_AnalyzerContext* zT_56;
    unsigned char zT_57;
    zT_7E2F335A_AnalyzerContext* zT_60;
    unsigned int zT_61;
    zT_3E40CD83_Sand* zT_63;
    zT_7E2F335A_AnalyzerContext* zT_65;
    unsigned char zT_66;
    zT_7E2F335A_AnalyzerContext* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_3E40CD83_Sand* zT_73;
    zT_7E2F335A_AnalyzerContext* zT_75;
    unsigned char zT_76;
    zT_7E2F335A_AnalyzerContext* zT_79;
    unsigned int zT_80;
    zT_3E40CD83_Sand* zT_82;
    zT_7E2F335A_AnalyzerContext* zT_84;
    zT_3E40CD83_Sand* zT_85;
    unsigned int zT_86;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zT_22A7C88B_AstNode root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u bmsg;
    zT_3 = ctx->store;
    zT_4 = module_root_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    root = zT_6;
    zT_7 = root.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = ctx->store;
    zT_13 = module_root_idx;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    decls_n = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    di = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = ctx->store;
    zT_23 = module_root_idx;
    zT_27 = zF_B10B1BC1_astStoreNodeExtraCh(zT_22, zT_23, (unsigned int)((unsigned int)di));
    decl_idx = zT_27;
    zT_29 = ctx->store;
    zT_30 = decl_idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    decl = zT_32;
    zT_33 = decl.kind;
    if ((unsigned char)(zT_33 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    zT_115 = 1;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_116)), 32u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_116)), 32u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    di = zT_117;
    goto z_bb_3;
    z_bb_7:
    goto z_bb_6;
    z_bb_8:
    zT_37 = decl.child_0;
    if ((unsigned char)(zT_37 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_40 = ctx->alloc;
    zF_CB5A85E9_sandResetPeak(zT_40);
    zT_42 = ctx->store;
    zT_43 = zT_42->fn_protos;
    zT_44 = zT_43.items;
    zT_45 = ctx->store;
    zT_46 = decl_idx;
    zT_48 = zF_8BA26B9E_astStoreNodePayload(zT_45, zT_46);
    zT_49 = (unsigned int)zT_48;
    zT_50 = zT_44[zT_49];
    zT_51 = zT_50.name_id;
    ctx->current_fn_name = zT_51;
    zT_52 = ctx;
    zT_53 = decl_idx;
    zF_DDE69BF2_runSignatureAnalyze(zT_52, zT_53);
    zT_54 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_54);
    zT_56 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_56);
    zT_57 = ctx->skip_null_check;
    if ((unsigned char)(zT_57 == (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_60 = ctx;
    zT_61 = decl.child_0;
    zF_29CABD65_runNullAnalyzer(zT_60, zT_61);
    zT_63 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_63);
    zT_65 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_65);
    goto z_bb_12;
    z_bb_12:
    zT_66 = ctx->skip_lifetime_check;
    if ((unsigned char)(zT_66 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_69 = ctx;
    zT_70 = decl_idx;
    zT_71 = decl.child_0;
    zF_9B11D60F_runLifetimeAnalyzer(zT_69, zT_70, zT_71);
    zT_73 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_73);
    zT_75 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_75);
    goto z_bb_14;
    z_bb_14:
    zT_76 = ctx->skip_doublefree_check;
    if ((unsigned char)(zT_76 == (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_79 = ctx;
    zT_80 = decl.child_0;
    zF_D5F41043_runDoubleFreeAnalyz(zT_79, zT_80);
    zT_82 = ctx->alloc;
    zF_F1B3F8C2_sandReset(zT_82);
    zT_84 = ctx;
    zF_61F0EB83_resetDeferQueue(zT_84);
    goto z_bb_16;
    z_bb_16:
    zT_85 = ctx->alloc;
    zT_86 = zT_85->peak;
    if ((unsigned char)(zT_86 > (unsigned int)(524288))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_90 = "per-function analyzer budget exceeded";
    zT_92 = 37;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    bmsg = zT_91;
    zT_93 = ctx->diag;
    zT_97 = decl.span_start;
    zT_107 = decl.span_start;
    zT_108 = decl.span_len;
    zT_109 = (unsigned int)zT_108;
    zT_110 = zig_wrap_add_u(((zu64)(zT_107)), ((zu64)(zT_109)), 32u);
    zT_111 = zig_overflow_flag_add_u(((zu64)(zT_107)), ((zu64)(zT_109)), 32u);
    zT_113 = zT_111 == (unsigned int)(0);
    if (!(zT_113)) { pal_trap(); }
    zT_98 = zT_110;
    zT_99 = bmsg;
    (void)zF_C82559AC_diagnosticCollector(zT_93, (unsigned char)(1), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_WARN_7002_ANALYZER_BUDGET_EXCEEDED)), (unsigned int)(0), zT_97, zT_98, zT_99);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_6;
}

/* EOF */
