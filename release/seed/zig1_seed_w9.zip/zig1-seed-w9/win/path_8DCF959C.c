#include "path_8DCF959C.h"
/* normalizePath */
zT_662E24C2_Opt_250 zF_36F0DB6B_normalizePath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u src) {
    unsigned int zT_3;
    unsigned int zT_5;
    zT_662E24C2_Opt_250 zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned char zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int zT_29;
    int zT_31;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    int zT_46;
    unsigned int zT_47;
    unsigned char zT_48;
    unsigned char* zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    int zT_53;
    unsigned int zT_54;
    zT_894C14AF_Arr_unsigned_int_51 zT_56;
    int zT_58;
    unsigned int zT_59;
    int zT_61;
    unsigned int zT_63;
    int zT_69;
    unsigned int zT_70;
    int zT_72;
    unsigned int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_80;
    unsigned int zT_81;
    int zT_82;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    int zT_89;
    int zT_92;
    unsigned int zT_93;
    int zT_95;
    unsigned int zT_96;
    int zT_97;
    unsigned char zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    int zT_106;
    unsigned int zT_107;
    int zT_108;
    unsigned char zT_110;
    unsigned char* zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned char zT_117;
    unsigned char* zT_118;
    int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123;
    unsigned int zT_124;
    unsigned char zT_125;
    unsigned char zT_126;
    int zT_129;
    unsigned int zT_130;
    int zT_131;
    unsigned char zT_133;
    int zT_134;
    int zT_136;
    unsigned char zT_138;
    unsigned char* zT_139;
    int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_144;
    unsigned int zT_145;
    unsigned char zT_146;
    unsigned char zT_147;
    unsigned char zT_150;
    unsigned char* zT_151;
    unsigned int zT_152;
    unsigned char zT_153;
    int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char zT_159;
    int zT_160;
    unsigned char zT_163;
    int zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    int zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned char zT_178;
    unsigned int zT_179;
    unsigned char zT_180;
    unsigned char zT_181;
    unsigned char* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned char zT_186;
    unsigned int zT_187;
    unsigned char zT_188;
    int zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned char zT_198;
    int zT_199;
    int zT_201;
    int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned char zT_208;
    unsigned char zT_210;
    unsigned int zT_211;
    unsigned char zT_213;
    unsigned char* zT_214;
    int zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned char zT_219;
    unsigned int zT_220;
    unsigned char zT_221;
    unsigned char zT_222;
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned char zT_230;
    int zT_231;
    int zT_233;
    unsigned char zT_235;
    unsigned char* zT_236;
    int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned char zT_241;
    unsigned int zT_242;
    unsigned char zT_243;
    unsigned char zT_244;
    unsigned char zT_247;
    unsigned char* zT_248;
    unsigned int zT_249;
    unsigned char zT_250;
    int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned char zT_256;
    unsigned char zT_257;
    unsigned char* zT_258;
    unsigned int zT_259;
    unsigned char zT_260;
    int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned char zT_266;
    unsigned char zT_267;
    unsigned char* zT_268;
    unsigned int zT_269;
    unsigned char zT_270;
    int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned char zT_276;
    int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned char zT_281;
    int zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned char zT_287;
    int zT_288;
    unsigned char zT_290;
    unsigned char* zT_291;
    int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned char zT_296;
    unsigned int zT_297;
    unsigned char zT_298;
    unsigned char zT_299;
    int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned char zT_307;
    int zT_308;
    int zT_310;
    unsigned char zT_312;
    unsigned char* zT_313;
    int zT_314;
    unsigned int zT_315;
    unsigned char zT_316;
    int zT_317;
    unsigned int zT_318;
    unsigned char zT_319;
    unsigned char* zT_320;
    int zT_321;
    unsigned int zT_322;
    unsigned char zT_323;
    int zT_324;
    unsigned int zT_325;
    unsigned char* zT_326;
    unsigned int zT_327;
    int zT_328;
    unsigned char* zT_329;
    unsigned int zT_330;
    unsigned char zT_331;
    unsigned char zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    zT_662E24C2_Opt_250 zT_334;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    unsigned int i;
    unsigned int len;
    unsigned int out_len;
    unsigned int is_abs;
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int stack_len;
    unsigned int seg_start;
    unsigned int pos;
    unsigned int is_sep;
    unsigned int seg_len;
    unsigned int is_dot;
    unsigned int is_dotdot;
    unsigned int k;
    zT_3 = buf.len;
    zT_5 = src.len;
    if ((unsigned char)(zT_3 < zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    i = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = src.len;
    if ((unsigned char)(i < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = src.ptr;
    zT_15 = src.len;
    zT_16 = i < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[i];
    zT_18 = buf.ptr;
    zT_19 = buf.len;
    zT_20 = i < zT_19;
    if (!(zT_20)) { pal_trap(); }
    zT_18[i] = zT_17;
    goto z_bb_6;
    z_bb_5:
    zT_29 = src.len;
    len = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    out_len = zT_32;
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    is_abs = zT_35;
    zT_36 = 0;
    if ((unsigned char)(len > (unsigned int)zT_36)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    i = zT_23;
    goto z_bb_3;
    z_bb_7:
    zT_39 = buf.ptr;
    zT_40 = 0;
    zT_41 = buf.len;
    zT_42 = (unsigned int)zT_40 < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_39[zT_40];
    zT_38 = zT_43 == (unsigned char)(47);
    goto z_bb_9;
    z_bb_8:
    zT_38 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    is_abs = zT_47;
    zT_48 = 47;
    zT_49 = buf.ptr;
    zT_50 = 0;
    zT_51 = buf.len;
    zT_52 = (unsigned int)zT_50 < zT_51;
    if (!(zT_52)) { pal_trap(); }
    zT_49[zT_50] = zT_48;
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    out_len = zT_54;
    goto z_bb_11;
    z_bb_11:
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_56[_i];
        _i++;
    }
}
    zT_58 = 0;
    zT_59 = (unsigned int)zT_58;
    stack_len = zT_59;
    zT_61 = 1;
    if ((unsigned char)(is_abs == (unsigned int)zT_61)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = 1;
    goto z_bb_14;
    z_bb_13:
    zT_63 = 0;
    goto z_bb_14;
    z_bb_14:
    seg_start = zT_63;
    pos = seg_start;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(pos <= len)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    is_sep = zT_70;
    if ((unsigned char)(pos == len)) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_75;
    z_bb_18:
    zT_282 = 1;
    zT_283 = (unsigned int)zT_282;
    zT_284 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_283)), 32u);
    zT_285 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_283)), 32u);
    zT_287 = zT_285 == (unsigned int)(0);
    if (!(zT_287)) { pal_trap(); }
    pos = zT_284;
    goto z_bb_15;
    z_bb_19:
    zT_72 = 1;
    zT_73 = (unsigned int)zT_72;
    is_sep = zT_73;
    goto z_bb_20;
    z_bb_20:
    zT_82 = 1;
    if ((unsigned char)(is_sep == (unsigned int)zT_82)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_74 = buf.ptr;
    zT_75 = buf.len;
    zT_76 = pos < zT_75;
    if (!(zT_76)) { pal_trap(); }
    zT_77 = zT_74[pos];
    if ((unsigned char)(zT_77 == (unsigned char)(47))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_80 = 1;
    zT_81 = (unsigned int)zT_80;
    is_sep = zT_81;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_85 = zig_wrap_sub_u(((zu64)(pos)), ((zu64)(seg_start)), 32u);
    zT_86 = zig_overflow_flag_sub_u(((zu64)(pos)), ((zu64)(seg_start)), 32u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    seg_len = zT_85;
    zT_89 = 0;
    if ((unsigned char)(seg_len > (unsigned int)zT_89)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_92 = 0;
    zT_93 = (unsigned int)zT_92;
    is_dot = zT_93;
    zT_95 = 0;
    zT_96 = (unsigned int)zT_95;
    is_dotdot = zT_96;
    zT_97 = 1;
    if ((unsigned char)(seg_len == (unsigned int)zT_97)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_277 = 1;
    zT_278 = zig_wrap_add_u(((zu64)(pos)), ((zu64)(zT_277)), 32u);
    zT_279 = zig_overflow_flag_add_u(((zu64)(pos)), ((zu64)(zT_277)), 32u);
    zT_281 = zT_279 == (unsigned int)(0);
    if (!(zT_281)) { pal_trap(); }
    seg_start = zT_278;
    goto z_bb_25;
    z_bb_28:
    zT_100 = buf.ptr;
    zT_101 = buf.len;
    zT_102 = seg_start < zT_101;
    if (!(zT_102)) { pal_trap(); }
    zT_103 = zT_100[seg_start];
    zT_99 = zT_103 == (unsigned char)(46);
    goto z_bb_30;
    z_bb_29:
    zT_99 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_99) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_106 = 1;
    zT_107 = (unsigned int)zT_106;
    is_dot = zT_107;
    goto z_bb_32;
    z_bb_32:
    zT_108 = 2;
    if ((unsigned char)(seg_len == (unsigned int)zT_108)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_111 = buf.ptr;
    zT_112 = buf.len;
    zT_113 = seg_start < zT_112;
    if (!(zT_113)) { pal_trap(); }
    zT_114 = zT_111[seg_start];
    zT_110 = zT_114 == (unsigned char)(46);
    goto z_bb_35;
    z_bb_34:
    zT_110 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_110) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_118 = buf.ptr;
    zT_119 = 1;
    zT_120 = zig_wrap_add_u(((zu64)(seg_start)), ((zu64)(zT_119)), 32u);
    zT_121 = zig_overflow_flag_add_u(((zu64)(seg_start)), ((zu64)(zT_119)), 32u);
    zT_123 = zT_121 == (unsigned int)(0);
    if (!(zT_123)) { pal_trap(); }
    zT_124 = buf.len;
    zT_125 = zT_120 < zT_124;
    if (!(zT_125)) { pal_trap(); }
    zT_126 = zT_118[zT_120];
    zT_117 = zT_126 == (unsigned char)(46);
    goto z_bb_38;
    z_bb_37:
    zT_117 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_117) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_129 = 1;
    zT_130 = (unsigned int)zT_129;
    is_dotdot = zT_130;
    goto z_bb_40;
    z_bb_40:
    zT_131 = 0;
    if ((unsigned char)(is_dot == (unsigned int)zT_131)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_134 = 0;
    zT_133 = is_dotdot == (unsigned int)zT_134;
    goto z_bb_43;
    z_bb_42:
    zT_133 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_133) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_136 = 0;
    if ((unsigned char)(out_len > (unsigned int)zT_136)) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_27;
    z_bb_46:
    zT_199 = 1;
    if ((unsigned char)(is_dotdot == (unsigned int)zT_199)) goto z_bb_58; else goto z_bb_59;
    z_bb_47:
    zT_139 = buf.ptr;
    zT_140 = 1;
    zT_141 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_140)), 32u);
    zT_142 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_140)), 32u);
    zT_144 = zT_142 == (unsigned int)(0);
    if (!(zT_144)) { pal_trap(); }
    zT_145 = buf.len;
    zT_146 = zT_141 < zT_145;
    if (!(zT_146)) { pal_trap(); }
    zT_147 = zT_139[zT_141];
    zT_138 = zT_147 != (unsigned char)(47);
    goto z_bb_49;
    z_bb_48:
    zT_138 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_138) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_150 = 47;
    zT_151 = buf.ptr;
    zT_152 = buf.len;
    zT_153 = out_len < zT_152;
    if (!(zT_153)) { pal_trap(); }
    zT_151[out_len] = zT_150;
    zT_154 = 1;
    zT_155 = (unsigned int)zT_154;
    zT_156 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(zT_155)), 32u);
    zT_157 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(zT_155)), 32u);
    zT_159 = zT_157 == (unsigned int)(0);
    if (!(zT_159)) { pal_trap(); }
    out_len = zT_156;
    goto z_bb_51;
    z_bb_51:
    zT_160 = 512;
    if ((unsigned char)(stack_len < (unsigned int)zT_160)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_163 = stack_len < (unsigned int)(512);
    if (!(zT_163)) { pal_trap(); }
    stack[stack_len] = out_len;
    zT_164 = 1;
    zT_165 = (unsigned int)zT_164;
    zT_166 = zig_wrap_add_u(((zu64)(stack_len)), ((zu64)(zT_165)), 32u);
    zT_167 = zig_overflow_flag_add_u(((zu64)(stack_len)), ((zu64)(zT_165)), 32u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    stack_len = zT_166;
    goto z_bb_53;
    z_bb_53:
    zT_171 = 0;
    zT_172 = (unsigned int)zT_171;
    k = zT_172;
    goto z_bb_54;
    z_bb_54:
    if ((unsigned char)(k < seg_len)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_174 = buf.ptr;
    zT_175 = zig_wrap_add_u(((zu64)(seg_start)), ((zu64)(k)), 32u);
    zT_176 = zig_overflow_flag_add_u(((zu64)(seg_start)), ((zu64)(k)), 32u);
    zT_178 = zT_176 == (unsigned int)(0);
    if (!(zT_178)) { pal_trap(); }
    zT_179 = buf.len;
    zT_180 = zT_175 < zT_179;
    if (!(zT_180)) { pal_trap(); }
    zT_181 = zT_174[zT_175];
    zT_182 = buf.ptr;
    zT_183 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(k)), 32u);
    zT_184 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(k)), 32u);
    zT_186 = zT_184 == (unsigned int)(0);
    if (!(zT_186)) { pal_trap(); }
    zT_187 = buf.len;
    zT_188 = zT_183 < zT_187;
    if (!(zT_188)) { pal_trap(); }
    zT_182[zT_183] = zT_181;
    goto z_bb_57;
    z_bb_56:
    zT_195 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(seg_len)), 32u);
    zT_196 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(seg_len)), 32u);
    zT_198 = zT_196 == (unsigned int)(0);
    if (!(zT_198)) { pal_trap(); }
    out_len = zT_195;
    goto z_bb_45;
    z_bb_57:
    zT_189 = 1;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zig_wrap_add_u(((zu64)(k)), ((zu64)(zT_190)), 32u);
    zT_192 = zig_overflow_flag_add_u(((zu64)(k)), ((zu64)(zT_190)), 32u);
    zT_194 = zT_192 == (unsigned int)(0);
    if (!(zT_194)) { pal_trap(); }
    k = zT_191;
    goto z_bb_54;
    z_bb_58:
    zT_201 = 0;
    if ((unsigned char)(stack_len > (unsigned int)zT_201)) goto z_bb_60; else goto z_bb_62;
    z_bb_59:
    goto z_bb_45;
    z_bb_60:
    zT_203 = 1;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zig_wrap_sub_u(((zu64)(stack_len)), ((zu64)(zT_204)), 32u);
    zT_206 = zig_overflow_flag_sub_u(((zu64)(stack_len)), ((zu64)(zT_204)), 32u);
    zT_208 = zT_206 == (unsigned int)(0);
    if (!(zT_208)) { pal_trap(); }
    stack_len = zT_205;
    zT_210 = stack_len < (unsigned int)(512);
    if (!(zT_210)) { pal_trap(); }
    zT_211 = stack[stack_len];
    out_len = zT_211;
    if ((unsigned char)(out_len > is_abs)) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_231 = 0;
    if ((unsigned char)(is_abs == (unsigned int)zT_231)) goto z_bb_68; else goto z_bb_69;
    z_bb_63:
    zT_214 = buf.ptr;
    zT_215 = 1;
    zT_216 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_215)), 32u);
    zT_217 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_215)), 32u);
    zT_219 = zT_217 == (unsigned int)(0);
    if (!(zT_219)) { pal_trap(); }
    zT_220 = buf.len;
    zT_221 = zT_216 < zT_220;
    if (!(zT_221)) { pal_trap(); }
    zT_222 = zT_214[zT_216];
    zT_213 = zT_222 == (unsigned char)(47);
    goto z_bb_65;
    z_bb_64:
    zT_213 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_213) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_225 = 1;
    zT_226 = (unsigned int)zT_225;
    zT_227 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_226)), 32u);
    zT_228 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_226)), 32u);
    zT_230 = zT_228 == (unsigned int)(0);
    if (!(zT_230)) { pal_trap(); }
    out_len = zT_227;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_61;
    z_bb_68:
    zT_233 = 0;
    if ((unsigned char)(out_len > (unsigned int)zT_233)) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    goto z_bb_61;
    z_bb_70:
    zT_236 = buf.ptr;
    zT_237 = 1;
    zT_238 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_237)), 32u);
    zT_239 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_237)), 32u);
    zT_241 = zT_239 == (unsigned int)(0);
    if (!(zT_241)) { pal_trap(); }
    zT_242 = buf.len;
    zT_243 = zT_238 < zT_242;
    if (!(zT_243)) { pal_trap(); }
    zT_244 = zT_236[zT_238];
    zT_235 = zT_244 != (unsigned char)(47);
    goto z_bb_72;
    z_bb_71:
    zT_235 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_235) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_247 = 47;
    zT_248 = buf.ptr;
    zT_249 = buf.len;
    zT_250 = out_len < zT_249;
    if (!(zT_250)) { pal_trap(); }
    zT_248[out_len] = zT_247;
    zT_251 = 1;
    zT_252 = (unsigned int)zT_251;
    zT_253 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(zT_252)), 32u);
    zT_254 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(zT_252)), 32u);
    zT_256 = zT_254 == (unsigned int)(0);
    if (!(zT_256)) { pal_trap(); }
    out_len = zT_253;
    goto z_bb_74;
    z_bb_74:
    zT_257 = 46;
    zT_258 = buf.ptr;
    zT_259 = buf.len;
    zT_260 = out_len < zT_259;
    if (!(zT_260)) { pal_trap(); }
    zT_258[out_len] = zT_257;
    zT_261 = 1;
    zT_262 = (unsigned int)zT_261;
    zT_263 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(zT_262)), 32u);
    zT_264 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(zT_262)), 32u);
    zT_266 = zT_264 == (unsigned int)(0);
    if (!(zT_266)) { pal_trap(); }
    out_len = zT_263;
    zT_267 = 46;
    zT_268 = buf.ptr;
    zT_269 = buf.len;
    zT_270 = out_len < zT_269;
    if (!(zT_270)) { pal_trap(); }
    zT_268[out_len] = zT_267;
    zT_271 = 1;
    zT_272 = (unsigned int)zT_271;
    zT_273 = zig_wrap_add_u(((zu64)(out_len)), ((zu64)(zT_272)), 32u);
    zT_274 = zig_overflow_flag_add_u(((zu64)(out_len)), ((zu64)(zT_272)), 32u);
    zT_276 = zT_274 == (unsigned int)(0);
    if (!(zT_276)) { pal_trap(); }
    out_len = zT_273;
    goto z_bb_69;
    z_bb_75:
    zT_288 = 1;
    if ((unsigned char)(out_len > (unsigned int)zT_288)) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_302 = 1;
    zT_303 = (unsigned int)zT_302;
    zT_304 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_303)), 32u);
    zT_305 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_303)), 32u);
    zT_307 = zT_305 == (unsigned int)(0);
    if (!(zT_307)) { pal_trap(); }
    out_len = zT_304;
    goto z_bb_78;
    z_bb_77:
    zT_308 = 0;
    if ((unsigned char)(out_len == (unsigned int)zT_308)) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_291 = buf.ptr;
    zT_292 = 1;
    zT_293 = zig_wrap_sub_u(((zu64)(out_len)), ((zu64)(zT_292)), 32u);
    zT_294 = zig_overflow_flag_sub_u(((zu64)(out_len)), ((zu64)(zT_292)), 32u);
    zT_296 = zT_294 == (unsigned int)(0);
    if (!(zT_296)) { pal_trap(); }
    zT_297 = buf.len;
    zT_298 = zT_293 < zT_297;
    if (!(zT_298)) { pal_trap(); }
    zT_299 = zT_291[zT_293];
    zT_290 = zT_299 == (unsigned char)(47);
    goto z_bb_81;
    z_bb_80:
    zT_290 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_290) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_310 = 1;
    if ((unsigned char)(is_abs == (unsigned int)zT_310)) goto z_bb_84; else goto z_bb_86;
    z_bb_83:
    zT_326 = buf.ptr;
    zT_327 = buf.len;
    zT_328 = 0;
    zT_329 = zT_326 + zT_328;
    zT_330 = out_len - zT_328;
    zT_331 = (unsigned int)zT_328 <= out_len;
    if (!(zT_331)) { pal_trap(); }
    zT_332 = out_len <= zT_327;
    if (!(zT_332)) { pal_trap(); }
    zT_333.ptr = (unsigned char*)zT_329;
    zT_333.len = zT_330;
    zT_334.has_value = 1;
    zT_334.value = zT_333;
    return zT_334;
    z_bb_84:
    zT_312 = 47;
    zT_313 = buf.ptr;
    zT_314 = 0;
    zT_315 = buf.len;
    zT_316 = (unsigned int)zT_314 < zT_315;
    if (!(zT_316)) { pal_trap(); }
    zT_313[zT_314] = zT_312;
    zT_317 = 1;
    zT_318 = (unsigned int)zT_317;
    out_len = zT_318;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_319 = 46;
    zT_320 = buf.ptr;
    zT_321 = 0;
    zT_322 = buf.len;
    zT_323 = (unsigned int)zT_321 < zT_322;
    if (!(zT_323)) { pal_trap(); }
    zT_320[zT_321] = zT_319;
    zT_324 = 1;
    zT_325 = (unsigned int)zT_324;
    out_len = zT_325;
    goto z_bb_85;
}

/* isReservedDosDeviceName */
unsigned char zF_5FF93310_isReservedDosDevice(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned char* zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_56;
    int zT_57;
    unsigned char zT_59;
    int zT_60;
    zT_B5AAF170_Arr_unsigned_char_4 zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned char* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    unsigned char zT_76;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    unsigned char zT_93;
    int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned char zT_99;
    int zT_100;
    int zT_102;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_108;
    int zT_109;
    unsigned char zT_111;
    unsigned char zT_112;
    unsigned char zT_115;
    int zT_116;
    unsigned char zT_118;
    unsigned char zT_119;
    int zT_123;
    unsigned char zT_125;
    unsigned char zT_126;
    unsigned char zT_129;
    int zT_130;
    unsigned char zT_132;
    unsigned char zT_133;
    unsigned char zT_136;
    int zT_137;
    unsigned char zT_139;
    unsigned char zT_140;
    int zT_144;
    unsigned char zT_146;
    unsigned char zT_147;
    unsigned char zT_150;
    int zT_151;
    unsigned char zT_153;
    unsigned char zT_154;
    unsigned char zT_157;
    int zT_158;
    unsigned char zT_160;
    unsigned char zT_161;
    int zT_165;
    unsigned char zT_167;
    unsigned char zT_168;
    unsigned char zT_171;
    int zT_172;
    unsigned char zT_174;
    unsigned char zT_175;
    unsigned char zT_178;
    int zT_179;
    unsigned char zT_181;
    unsigned char zT_182;
    int zT_188;
    unsigned char zT_190;
    unsigned char zT_191;
    unsigned char zT_194;
    int zT_198;
    unsigned char zT_200;
    unsigned char zT_201;
    unsigned char zT_204;
    int zT_205;
    unsigned char zT_207;
    unsigned char zT_208;
    unsigned char zT_211;
    int zT_212;
    unsigned char zT_214;
    unsigned char zT_215;
    int zT_219;
    unsigned char zT_221;
    unsigned char zT_222;
    unsigned char zT_225;
    int zT_226;
    unsigned char zT_228;
    unsigned char zT_229;
    unsigned char zT_232;
    int zT_233;
    unsigned char zT_235;
    unsigned char zT_236;
    unsigned int base_start;
    unsigned int i;
    unsigned int stem_end;
    unsigned int n;
    zT_B5AAF170_Arr_unsigned_char_4 buf;
    unsigned char c;
    unsigned char d;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    base_start = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_8 = name.len;
    if ((unsigned char)(i < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = name.ptr;
    zT_11 = name.len;
    zT_12 = i < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[i];
    if ((unsigned char)(zT_13 == (unsigned char)(47))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_36 = name.len;
    stem_end = zT_36;
    i = base_start;
    goto z_bb_10;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_17 = name.ptr;
    zT_18 = name.len;
    zT_19 = i < zT_18;
    if (!(zT_19)) { pal_trap(); }
    zT_20 = zT_17[i];
    zT_16 = zT_20 == (unsigned char)(92);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    base_start = zT_24;
    goto z_bb_9;
    z_bb_9:
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_31 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_29)), 32u);
    zT_33 = zT_31 == (unsigned int)(0);
    if (!(zT_33)) { pal_trap(); }
    i = zT_30;
    goto z_bb_4;
    z_bb_10:
    zT_38 = name.len;
    if ((unsigned char)(i < zT_38)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_40 = name.ptr;
    zT_41 = name.len;
    zT_42 = i < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_40[i];
    if ((unsigned char)(zT_43 == (unsigned char)(46))) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    zT_53 = zig_wrap_sub_u(((zu64)(stem_end)), ((zu64)(base_start)), 32u);
    zT_54 = zig_overflow_flag_sub_u(((zu64)(stem_end)), ((zu64)(base_start)), 32u);
    zT_56 = zT_54 == (unsigned int)(0);
    if (!(zT_56)) { pal_trap(); }
    n = zT_53;
    zT_57 = 3;
    if ((unsigned char)(n != (unsigned int)zT_57)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    stem_end = i;
    goto z_bb_12;
    z_bb_15:
    zT_46 = 1;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_49 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_47)), 32u);
    zT_51 = zT_49 == (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    i = zT_48;
    goto z_bb_13;
    z_bb_16:
    zT_60 = 4;
    zT_59 = n != (unsigned int)zT_60;
    goto z_bb_18;
    z_bb_17:
    zT_59 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_59) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        buf[_i] = zT_64[_i];
        _i++;
    }
}
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    i = zT_66;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(i < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_69 = name.ptr;
    zT_70 = zig_wrap_add_u(((zu64)(base_start)), ((zu64)(i)), 32u);
    zT_71 = zig_overflow_flag_add_u(((zu64)(base_start)), ((zu64)(i)), 32u);
    zT_73 = zT_71 == (unsigned int)(0);
    if (!(zT_73)) { pal_trap(); }
    zT_74 = name.len;
    zT_75 = zT_70 < zT_74;
    if (!(zT_75)) { pal_trap(); }
    zT_76 = zT_69[zT_70];
    c = zT_76;
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_100 = 3;
    if ((unsigned char)(n == (unsigned int)zT_100)) goto z_bb_30; else goto z_bb_31;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_79 = c <= (unsigned char)(90);
    goto z_bb_27;
    z_bb_26:
    zT_79 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_79) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_82 = 65;
    zT_83 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_82)), 8u);
    zT_84 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_82)), 8u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    zT_87 = 97;
    zT_88 = zig_wrap_add_u(((zu64)(zT_83)), ((zu64)(zT_87)), 8u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(zT_83)), ((zu64)(zT_87)), 8u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    c = zT_88;
    goto z_bb_29;
    z_bb_29:
    zT_93 = i < (unsigned int)(4);
    if (!(zT_93)) { pal_trap(); }
    buf[i] = c;
    zT_94 = 1;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_95)), 32u);
    zT_97 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_95)), 32u);
    zT_99 = zT_97 == (unsigned int)(0);
    if (!(zT_99)) { pal_trap(); }
    i = zT_96;
    goto z_bb_24;
    z_bb_30:
    zT_102 = 0;
    zT_104 = (unsigned int)zT_102 < (unsigned int)(4);
    if (!(zT_104)) { pal_trap(); }
    zT_105 = buf[zT_102];
    if ((unsigned char)(zT_105 == (unsigned char)(99))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_188 = 3;
    zT_190 = (unsigned int)zT_188 < (unsigned int)(4);
    if (!(zT_190)) { pal_trap(); }
    zT_191 = buf[zT_188];
    d = zT_191;
    if ((unsigned char)(d < (unsigned char)(49))) goto z_bb_65; else goto z_bb_64;
    z_bb_32:
    zT_109 = 1;
    zT_111 = (unsigned int)zT_109 < (unsigned int)(4);
    if (!(zT_111)) { pal_trap(); }
    zT_112 = buf[zT_109];
    zT_108 = zT_112 == (unsigned char)(111);
    goto z_bb_34;
    z_bb_33:
    zT_108 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_108) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_116 = 2;
    zT_118 = (unsigned int)zT_116 < (unsigned int)(4);
    if (!(zT_118)) { pal_trap(); }
    zT_119 = buf[zT_116];
    zT_115 = zT_119 == (unsigned char)(110);
    goto z_bb_37;
    z_bb_36:
    zT_115 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_115) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    zT_123 = 0;
    zT_125 = (unsigned int)zT_123 < (unsigned int)(4);
    if (!(zT_125)) { pal_trap(); }
    zT_126 = buf[zT_123];
    if ((unsigned char)(zT_126 == (unsigned char)(112))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_130 = 1;
    zT_132 = (unsigned int)zT_130 < (unsigned int)(4);
    if (!(zT_132)) { pal_trap(); }
    zT_133 = buf[zT_130];
    zT_129 = zT_133 == (unsigned char)(114);
    goto z_bb_42;
    z_bb_41:
    zT_129 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_129) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_137 = 2;
    zT_139 = (unsigned int)zT_137 < (unsigned int)(4);
    if (!(zT_139)) { pal_trap(); }
    zT_140 = buf[zT_137];
    zT_136 = zT_140 == (unsigned char)(110);
    goto z_bb_45;
    z_bb_44:
    zT_136 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_136) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return (unsigned char)(1);
    z_bb_47:
    zT_144 = 0;
    zT_146 = (unsigned int)zT_144 < (unsigned int)(4);
    if (!(zT_146)) { pal_trap(); }
    zT_147 = buf[zT_144];
    if ((unsigned char)(zT_147 == (unsigned char)(97))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_151 = 1;
    zT_153 = (unsigned int)zT_151 < (unsigned int)(4);
    if (!(zT_153)) { pal_trap(); }
    zT_154 = buf[zT_151];
    zT_150 = zT_154 == (unsigned char)(117);
    goto z_bb_50;
    z_bb_49:
    zT_150 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_150) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_158 = 2;
    zT_160 = (unsigned int)zT_158 < (unsigned int)(4);
    if (!(zT_160)) { pal_trap(); }
    zT_161 = buf[zT_158];
    zT_157 = zT_161 == (unsigned char)(120);
    goto z_bb_53;
    z_bb_52:
    zT_157 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_157) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    return (unsigned char)(1);
    z_bb_55:
    zT_165 = 0;
    zT_167 = (unsigned int)zT_165 < (unsigned int)(4);
    if (!(zT_167)) { pal_trap(); }
    zT_168 = buf[zT_165];
    if ((unsigned char)(zT_168 == (unsigned char)(110))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_172 = 1;
    zT_174 = (unsigned int)zT_172 < (unsigned int)(4);
    if (!(zT_174)) { pal_trap(); }
    zT_175 = buf[zT_172];
    zT_171 = zT_175 == (unsigned char)(117);
    goto z_bb_58;
    z_bb_57:
    zT_171 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_171) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_179 = 2;
    zT_181 = (unsigned int)zT_179 < (unsigned int)(4);
    if (!(zT_181)) { pal_trap(); }
    zT_182 = buf[zT_179];
    zT_178 = zT_182 == (unsigned char)(108);
    goto z_bb_61;
    z_bb_60:
    zT_178 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_178) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    return (unsigned char)(1);
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    zT_194 = d > (unsigned char)(57);
    goto z_bb_66;
    z_bb_65:
    zT_194 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_194) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    return (unsigned char)(0);
    z_bb_68:
    zT_198 = 0;
    zT_200 = (unsigned int)zT_198 < (unsigned int)(4);
    if (!(zT_200)) { pal_trap(); }
    zT_201 = buf[zT_198];
    if ((unsigned char)(zT_201 == (unsigned char)(99))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_205 = 1;
    zT_207 = (unsigned int)zT_205 < (unsigned int)(4);
    if (!(zT_207)) { pal_trap(); }
    zT_208 = buf[zT_205];
    zT_204 = zT_208 == (unsigned char)(111);
    goto z_bb_71;
    z_bb_70:
    zT_204 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_204) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_212 = 2;
    zT_214 = (unsigned int)zT_212 < (unsigned int)(4);
    if (!(zT_214)) { pal_trap(); }
    zT_215 = buf[zT_212];
    zT_211 = zT_215 == (unsigned char)(109);
    goto z_bb_74;
    z_bb_73:
    zT_211 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_211) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    return (unsigned char)(1);
    z_bb_76:
    zT_219 = 0;
    zT_221 = (unsigned int)zT_219 < (unsigned int)(4);
    if (!(zT_221)) { pal_trap(); }
    zT_222 = buf[zT_219];
    if ((unsigned char)(zT_222 == (unsigned char)(108))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_226 = 1;
    zT_228 = (unsigned int)zT_226 < (unsigned int)(4);
    if (!(zT_228)) { pal_trap(); }
    zT_229 = buf[zT_226];
    zT_225 = zT_229 == (unsigned char)(112);
    goto z_bb_79;
    z_bb_78:
    zT_225 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_225) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_233 = 2;
    zT_235 = (unsigned int)zT_233 < (unsigned int)(4);
    if (!(zT_235)) { pal_trap(); }
    zT_236 = buf[zT_233];
    zT_232 = zT_236 == (unsigned char)(116);
    goto z_bb_82;
    z_bb_81:
    zT_232 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_232) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    return (unsigned char)(1);
    z_bb_84:
    return (unsigned char)(0);
}

/* EOF */
