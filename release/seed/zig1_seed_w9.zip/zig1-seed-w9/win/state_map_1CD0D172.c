#include "state_map_1CD0D172.h"
/* stateMapInit */
zT_2C0927B0_StateMap zF_14665872_stateMapInit(zT_3E40CD83_Sand* alloc) {
    zT_2C0927B0_StateMap zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_85A2F044_Opt_300 zT_5;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1.entries_items = (zT_6B392E0E_StateEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5.has_value = 0;
    zT_1.parent = zT_5;
    return zT_1;
}

/* stateMapEnsureCapacity */
void zF_A12CB78A_stateMapEnsureCapac(zT_2C0927B0_StateMap* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_81AD2998_EU_952 zT_33;
    unsigned char zT_34;
    unsigned char* zT_35;
    zT_6B392E0E_StateEntry* zT_38;
    zT_6B392E0E_StateEntry* zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_6B392E0E_StateEntry* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_45;
    zT_6B392E0E_StateEntry* zT_46;
    unsigned int zT_47;
    unsigned int zT_52;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    unsigned int nc;
    unsigned char* raw;
    zT_6B392E0E_StateEntry* new_items;
    zT_6B392E0E_StateEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    zT_7 = zig_wrap_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_8 = zig_overflow_flag_mul_u(((zu64)(zT_5)), ((zu64)(zT_6)), 32u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    if ((unsigned char)(nc < zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = self->entries_cap;
    zT_13 = 2;
    zT_14 = zig_wrap_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(zT_12)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_18 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 8;
    zT_21 = (unsigned int)zT_20;
    nc = zT_21;
    goto z_bb_6;
    z_bb_6:
    zT_23 = self->entries_alloc;
    zT_27 = 8;
    zT_28 = zig_wrap_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_29 = zig_overflow_flag_mul_u(((zu64)(zT_27)), ((zu64)(nc)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    zT_24 = zT_28;
    zT_33 = zF_1395EB68_sandAlloc(zT_23, zT_24, (unsigned int)(4));
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_35 = zT_33.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_35;
    zT_38 = (zT_6B392E0E_StateEntry*)raw;
    new_items = zT_38;
    zT_39 = self->entries_items;
    zT_40 = self->entries_len;
    zT_41 = 0;
    zT_42 = zT_39 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44 = (unsigned int)zT_41 <= zT_40;
    if (!(zT_44)) { pal_trap(); }
    zT_45.ptr = (zT_6B392E0E_StateEntry*)zT_42;
    zT_45.len = zT_43;
    zT_46 = zT_45.ptr;
    zT_47 = zT_45.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_47)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_46[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
    z_bb_13:
    zT_52 = i + (unsigned int)(1);
    i = zT_52;
    goto z_bb_10;
}

/* stateMapGet */
zT_43E16BE5_Opt_8 zF_2EC17ECC_stateMapGet(zT_2C0927B0_StateMap* self, unsigned int name_id) {
    unsigned int zT_3;
    int zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_6B392E0E_StateEntry* zT_12;
    zT_6B392E0E_StateEntry zT_13;
    unsigned int zT_14;
    zT_6B392E0E_StateEntry* zT_16;
    zT_6B392E0E_StateEntry zT_17;
    unsigned char zT_18;
    zT_43E16BE5_Opt_8 zT_19;
    zT_85A2F044_Opt_300 zT_20;
    unsigned char zT_21;
    zT_2C0927B0_StateMap* zT_23;
    unsigned int zT_24;
    zT_43E16BE5_Opt_8 zT_26;
    zig_poison_fill((void*)&zT_26, (unsigned int)sizeof zT_26);
    unsigned int i;
    zT_2C0927B0_StateMap* p;
    z_bb_0:
    zT_3 = self->entries_len;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    if ((unsigned char)(i > (unsigned int)zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    i = zT_8;
    zT_12 = self->entries_items;
    zT_13 = zT_12[i];
    zT_14 = zT_13.name_id;
    if ((unsigned char)(zT_14 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20 = self->parent;
    zT_21 = zT_20.has_value;
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_16 = self->entries_items;
    zT_17 = zT_16[i];
    zT_18 = zT_17.state;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    if (!(zT_20.has_value)) { pal_trap(); }
    p = zT_20.value;
    zT_23 = p;
    zT_24 = name_id;
    self = zT_23;
    name_id = zT_24;
    goto z_bb_0;
    z_bb_8:
    zT_26.has_value = 0;
    return zT_26;
}

/* stateMapSet */
void zF_ACCFA860_stateMapSet(zT_2C0927B0_StateMap* self, unsigned int name_id, unsigned char state) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_6B392E0E_StateEntry* zT_8;
    zT_6B392E0E_StateEntry zT_9;
    unsigned int zT_10;
    zT_6B392E0E_StateEntry* zT_12;
    zT_6B392E0E_StateEntry* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    zT_2C0927B0_StateMap* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_6B392E0E_StateEntry zT_28;
    zT_6B392E0E_StateEntry* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->entries_len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->entries_items;
    zT_9 = zT_8[i];
    zT_10 = zT_9.name_id;
    if ((unsigned char)(zT_10 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20 = self;
    zT_22 = self->entries_len;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(zT_22)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_21 = zT_24;
    zF_A12CB78A_stateMapEnsureCapac(zT_20, zT_21);
    zT_28.name_id = name_id;
    zT_28.state = state;
    zT_29 = self->entries_items;
    zT_30 = self->entries_len;
    zT_29[zT_30] = zT_28;
    zT_31 = self->entries_len;
    zT_32 = 1;
    zT_33 = (unsigned int)zT_32;
    zT_34 = zig_wrap_add_u(((zu64)(zT_31)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(zT_31)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    self->entries_len = zT_34;
    return;
    z_bb_4:
    zT_14 = 1;
    zT_15 = (unsigned int)zT_14;
    zT_16 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_17 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_15)), 32u);
    zT_19 = zT_17 == (unsigned int)(0);
    if (!(zT_19)) { pal_trap(); }
    i = zT_16;
    goto z_bb_1;
    z_bb_5:
    zT_12 = self->entries_items;
    zT_13 = zT_12 + i;
    zT_13->state = state;
    return;
    z_bb_6:
    goto z_bb_4;
}

/* stateMapFork */
zT_2C0927B0_StateMap* zF_77086C9C_stateMapFork(zT_2C0927B0_StateMap* self, zT_3E40CD83_Sand* scratch) {
    zT_3E40CD83_Sand* zT_3;
    zT_81AD2998_EU_952 zT_8;
    unsigned char zT_9;
    unsigned char* zT_10;
    zT_2C0927B0_StateMap* zT_13;
    int zT_14;
    zT_85A2F044_Opt_300 zT_17;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    unsigned char* raw;
    zT_2C0927B0_StateMap* child;
    zT_3 = scratch;
    zT_8 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)(24), (unsigned int)(4));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_10;
    zT_13 = (zT_2C0927B0_StateMap*)raw;
    child = zT_13;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    child->entries_items = (zT_6B392E0E_StateEntry*)zT_14;
    child->entries_len = (unsigned int)(0);
    child->entries_cap = (unsigned int)(0);
    child->entries_alloc = scratch;
    zT_17.has_value = 1;
    zT_17.value = self;
    child->parent = zT_17;
    return child;
}

/* stateMapMergeStates */
void zF_143ACBA6_stateMapMergeStates(zT_2C0927B0_StateMap* parent, zT_2C0927B0_StateMap* branch_a, zT_2C0927B0_StateMap* branch_b, unsigned char unknown_state) {
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_6B392E0E_StateEntry* zT_10;
    zT_6B392E0E_StateEntry zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_16;
    unsigned char zT_17;
    unsigned char zT_19;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_2C0927B0_StateMap* zT_31;
    unsigned int zT_32;
    zT_43E16BE5_Opt_8 zT_34;
    unsigned char zT_35;
    unsigned char zT_37;
    zT_2C0927B0_StateMap* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_6B392E0E_StateEntry* zT_55;
    zT_6B392E0E_StateEntry zT_56;
    zT_2C0927B0_StateMap* zT_57;
    unsigned int zT_58;
    zT_43E16BE5_Opt_8 zT_60;
    unsigned char zT_61;
    zT_2C0927B0_StateMap* zT_64;
    unsigned int zT_65;
    zT_43E16BE5_Opt_8 zT_67;
    unsigned char zT_68;
    unsigned char zT_70;
    zT_2C0927B0_StateMap* zT_72;
    unsigned int zT_73;
    unsigned char zT_74;
    int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned char zT_81;
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    unsigned int i;
    zT_6B392E0E_StateEntry entry;
    zT_43E16BE5_Opt_8 bs;
    unsigned int j;
    unsigned char b_state;
    zT_43E16BE5_Opt_8 ps;
    unsigned char ps_val;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = branch_a->entries_len;
    if ((unsigned char)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = branch_a->entries_items;
    zT_11 = zT_10[i];
    entry = zT_11;
    zT_13 = branch_b;
    zT_14 = entry.name_id;
    zT_16 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    bs = zT_16;
    zT_17 = bs.has_value;
    if (zT_17) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    j = zT_51;
    goto z_bb_15;
    z_bb_4:
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    i = zT_45;
    goto z_bb_1;
    z_bb_5:
    if (!(bs.has_value)) { pal_trap(); }
    b_state = bs.value;
    zT_19 = entry.state;
    if ((unsigned char)(b_state != zT_19)) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = parent;
    zT_32 = entry.name_id;
    zT_34 = zF_2EC17ECC_stateMapGet(zT_31, zT_32);
    ps = zT_34;
    zT_35 = ps.has_value;
    if (zT_35) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_21 = parent;
    zT_22 = entry.name_id;
    zT_23 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_25 = parent;
    zT_26 = entry.name_id;
    zT_27 = entry.state;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_9;
    z_bb_11:
    if (!(ps.has_value)) { pal_trap(); }
    ps_val = ps.value;
    zT_37 = entry.state;
    if ((unsigned char)(ps_val != zT_37)) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_6;
    z_bb_13:
    zT_39 = parent;
    zT_40 = entry.name_id;
    zT_41 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_39, zT_40, zT_41);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_52 = branch_b->entries_len;
    if ((unsigned char)(j < zT_52)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_55 = branch_b->entries_items;
    zT_56 = zT_55[j];
    entry = zT_56;
    zT_57 = branch_a;
    zT_58 = entry.name_id;
    zT_60 = zF_2EC17ECC_stateMapGet(zT_57, zT_58);
    zT_61 = zT_60.has_value;
    if ((unsigned char)(!zT_61)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return;
    z_bb_18:
    zT_76 = 1;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_77)), 32u);
    zT_79 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_77)), 32u);
    zT_81 = zT_79 == (unsigned int)(0);
    if (!(zT_81)) { pal_trap(); }
    j = zT_78;
    goto z_bb_15;
    z_bb_19:
    zT_64 = parent;
    zT_65 = entry.name_id;
    zT_67 = zF_2EC17ECC_stateMapGet(zT_64, zT_65);
    ps = zT_67;
    zT_68 = ps.has_value;
    if (zT_68) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    if (!(ps.has_value)) { pal_trap(); }
    ps_val = ps.value;
    zT_70 = entry.state;
    if ((unsigned char)(ps_val != zT_70)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_72 = parent;
    zT_73 = entry.name_id;
    zT_74 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_72, zT_73, zT_74);
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
}

/* stateMapMergeInsertMissing */
void zF_619C0B6B_stateMapMergeInsert(zT_2C0927B0_StateMap* parent, zT_2C0927B0_StateMap* branch, unsigned char insert_state) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_6B392E0E_StateEntry* zT_9;
    zT_6B392E0E_StateEntry zT_10;
    zT_2C0927B0_StateMap* zT_11;
    unsigned int zT_12;
    zT_43E16BE5_Opt_8 zT_14;
    unsigned char zT_15;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    unsigned int j;
    zT_6B392E0E_StateEntry entry;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    j = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = branch->entries_len;
    if ((unsigned char)(j < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = branch->entries_items;
    zT_10 = zT_9[j];
    entry = zT_10;
    zT_11 = parent;
    zT_12 = entry.name_id;
    zT_14 = zF_2EC17ECC_stateMapGet(zT_11, zT_12);
    zT_15 = zT_14.has_value;
    if ((unsigned char)(!zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    j = zT_23;
    goto z_bb_1;
    z_bb_5:
    zT_17 = parent;
    zT_18 = entry.name_id;
    zT_19 = insert_state;
    zF_ACCFA860_stateMapSet(zT_17, zT_18, zT_19);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* stateMapGetEntries */
zT_92FBD55B_Slice_zT_6B392E0E_S zF_F0E7F434_stateMapGetEntries(zT_2C0927B0_StateMap* self) {
    zT_6B392E0E_StateEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6B392E0E_StateEntry* zT_4;
    unsigned int zT_5;
    unsigned char zT_6;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_7;
    zT_1 = self->entries_items;
    zT_2 = self->entries_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6 = (unsigned int)zT_3 <= zT_2;
    if (!(zT_6)) { pal_trap(); }
    zT_7.ptr = (zT_6B392E0E_StateEntry*)zT_4;
    zT_7.len = zT_5;
    return zT_7;
}

/* EOF */
